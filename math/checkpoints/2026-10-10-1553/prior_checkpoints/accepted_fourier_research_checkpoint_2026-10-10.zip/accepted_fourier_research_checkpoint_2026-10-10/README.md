# Accepted Fourier research checkpoint — 10 October 2026

The [existing Google Sheet](https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit) remains the main tracker. This archive preserves accepted proofs, review receipts, controls and recorded results; it creates no replacement tracker.

## Start here

- [Correction-compatible separator theorem](research_cycle_1453/algebra_novelty/CORRECTION_COMPATIBLE_SEPARATOR_THEOREM.md) and [independent acceptance](research_cycle_1453/algebra_novelty/ROOT_INDEPENDENT_BRIDGE_REVIEW.json): sparse/diagonal and rank-t corrections under the inherited independently routed separator model.
- [Phase-separated packed tables](research_cycle_1453/packed_improvement/README.md) and [independent review](research_cycle_1453/packed_adversarial/SPLIT_TABLE_INDEPENDENT_REVIEW.md): charged setup refinement within the frozen finite-word approximation contract, with its extra-rounding proof and practical limits.
- [Amplitude-field theorem, canonical v2](research_cycle_1453/amplitude_fields/AMPLITUDE_FIELD_THEOREM_v2.md), [erratum](research_cycle_1453/amplitude_fields/CORE_ERRATUM.md), and [core review](research_cycle_1453/gauss_fusion_review/FUSION_CERTIFICATE_REVIEW.md): exact positive-amplitude field and depth-one palette scope.
- [Strict Gauss obstruction](research_cycle_1453/gauss_graph/RESOLVED_FIBER_OBSTRUCTION.md) and the separately accepted [aggregate-basis reduction](research_cycle_1453/gauss_graph/aggregate_basis/AGGREGATE_BASIS_REDUCTION.md), with [basis review](research_cycle_1453/gauss_fusion_review/AGGREGATE_BASIS_REVIEW_ADDENDUM.md): the pointwise law and square-invertible-endpoint assumptions must not be dropped.
- [Rational approximation boundary](research_cycle_1453/amplitude_fields/approximation_boundary/RATIONAL_APPROXIMATION_BOUNDARY.md) and [separate acceptance](research_cycle_1453/gauss_fusion_review/APPROXIMATION_REVIEW_RECEIPT.json): positive-rational three-phase approximation and two-ray limits, with no free endpoint gauges or fast-transform conclusion.
- [Random finite-alphabet DAG analysis](research_cycle_1453/random_dag/RESULT.md) and [independent review](research_cycle_1453/random_dag_review/INDEPENDENT_TRADEOFF_REVIEW.md): exact whole-block sharing, charged cold-table comparator, numerical-word accounting, and explicitly bounded distribution assumptions.

## Scope and versions

These are scoped mathematical results and consolidations. They do not establish a general exact-complex FFT improvement, practical speedup, unrestricted lower bound, or historical novelty. No discovery count or ranking is changed by this archive. The mechanisms and classical dependencies remain identified in the source manuscripts and [novelty audit](research_cycle_1453/algebra_novelty/NOVELTY_AUDIT.md).

The [Sheet verification receipt](research_sheet_1502/FINAL_VERIFICATION_RECEIPT.json) describes its 15:07 UTC cutoff. Aggregate-basis, rational-approximation and random-DAG supplements are accepted in this archive but were explicitly outside that Sheet update. No Sheet write or repository publication was performed for this preservation archive. The earlier [repository checkpoint](https://github.com/AgentSlop-Si/research/commit/1f38d2c08f16e5592df1aad170aaee861bae70b0) remains separately identified.

The theorem and control-source bytes are preserved. Five review/status files have clearly disclosed public-copy attribution edits; their canonical and exported hashes are separately recorded in [VERSION_LEDGER.json](VERSION_LEDGER.json). Original manifests and receipts retain canonical source hashes rather than silently replacing their historical bindings. The v1 amplitude draft and packed-review records are historical; use the canonical v2 amplitude draft, erratum, and unsuffixed final packed acceptance. Contemporaneous “pending review” sentences in frozen manuscripts are superseded by the accompanying hash-pinned receipts.

[ALLOWLIST.json](ALLOWLIST.json) enumerates the source files. [ACCEPTANCE_BINDINGS.json](ACCEPTANCE_BINDINGS.json) records source-hash verification. [DEPENDENCY_BINDINGS.json](DEPENDENCY_BINDINGS.json) identifies included earlier proof/control inputs and exact published matches. [EXPORT_MANIFEST.json](EXPORT_MANIFEST.json) and [SHA256SUMS](SHA256SUMS) bind the export. A plain filename or historical relative source path in a source report is provenance text unless made into a navigable link here.

## Preservation and controls

Only allowlisted UTF-8 research files and bounded dependencies are included. Research programs were neither executed nor imported while making this archive; recorded results are preserved evidence from the indicated earlier runs. Included programs remain inert source files. No runtime or performance reproduction is claimed. No cache, upload helper, private contact identifier, or private conversation link is included. Unfinished regular-jet work and later fusion work are outside this checkpoint.
