#!/usr/bin/env python3
"""Fresh exact-arithmetic falsification controls; no project program imports.
These controls are not an eager-table executor or a proof of asymptotic cost.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import hashlib, json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent.parent
counts={}

def ceil_log2(n):
    assert n>0
    return (n-1).bit_length()

def params(v,t):
    p=t+10+ceil_log2(v+1)
    E=2*v+p+5
    k=ceil_log2(E+1)
    b=2*(p+k+1)
    return p,E,k,b

# Huge logical lengths are represented only by logarithms and scalar counts.
# Cover every admissible precision at small v, then boundaries and fixed precisions.
low=0; checked=0; catalogue=0; widths=0
first={t:None for t in (2,8,16,53)}
for v in range(1,25001):
    ts=set(range(2,v+2)) if v<=256 else {2,3,8,16,53,v//128,max(2,v//64),v//4,v,v+1}
    # The guard transitions occur at a precision computed from p+k, so inspect it.
    lo,hi=2,v+2
    while lo<hi:
        mid=(lo+hi)//2
        if mid<=v+1 and 64*params(v,mid)[3]<=v: lo=mid+1
        else: hi=mid
    ts.update((lo-1,lo,lo+1))
    for t in sorted(t for t in ts if 2<=t<=v+1):
        checked+=1
        p,E,k,b=params(v,t)
        assert (1<<k)>=E+1
        assert 2*v+2*p+6 <= 12*(v+1)+32  # conservative whole-state numerator width
        widths+=1
        if 64*b>v: continue
        low+=1
        if t in first and first[t] is None: first[t]=v
        P=1<<((v//(16*b)).bit_length()-1)
        d=P.bit_length()-1; g=p+10
        assert P>=4 and 16*b*P<=v<32*b*P
        assert 128*p<=v and 2*b*P<=v//8
        assert 128*(g+2*b*P)<=17*v+1280
        assert b*P<=v//16
        # Every possible (id,key) lies below 2^(g+2bP), whether or not build succeeds.
        idmax=(1<<g)-2
        keymax=(1<<(2*b*P))-1
        address=(idmax<<(2*b*P))+keymax
        assert address.bit_length()<=g+2*b*P
        # Avoid materializing the full response tables; cardinality only.
        cardinality=((1<<g)-1)*(1<<(2*b*P))+d*(1<<(b*P))
        assert cardinality.bit_length()<=g+2*b*P+1
        # Actual long-span catalogue boundaries, including r>g when available.
        for r in sorted({1,2,g-1,g,g+1,g+5,v-d}):
            if not 1<=r<=v-d: continue
            s=min(r,g); shift=max(r-g,0); half=1<<(r-1)
            for a in sorted({0,1,half//2,max(0,half-2),half-1}):
                if a>=half: continue
                h=a>>shift; ident=(1<<(s-1))-1+h
                assert 0<=ident<(1<<g)-1
                for lane in sorted({0,P//2,P-1}):
                    actual=((1<<g)*(P*a+lane))//(P*(1<<r))
                    catalog=((1<<g)*(P*h+lane))//(P*(1<<s))
                    assert actual==catalog
                    catalogue+=1
counts.update(parameter_pairs=checked,low_guard_pairs=low,state_width_checks=widths,catalogue_boundary_equalities=catalogue,first_guard_v=first)

# Exact aggregate error inequalities and precision-domain guards across all small N.
all_len=0
for N in range(2,5001):
    n=ceil_log2(N+1); M=1<<ceil_log2(4*N); v=M.bit_length()-1
    H=1<<ceil_log2(2*N-1); k=H.bit_length()
    assert 4*N<=M<8*N and v in (n+1,n+2)
    assert 2*N<=H<4*N
    for t in range(2,n+1):
        q=t+(H.bit_length()-1)+ceil_log2(k)+13
        u=F(1,1<<q); eps=F(1,1<<t)
        assert 500*k*u<=1 and 4*k*u<=F(1,2)
        assert 2048*k*H*u<=eps/4
        assert 22*eps/1024<eps
        p=t+10+ceil_log2(v+1)
        assert 14*F(v+1,1<<p)<=14*eps/1024<eps
        s=t+16; h=16*s+1
        if t<=n//4 and t+10<=v+1 and M>=16*s and 2*h+2<M:
            assert t+10<=v+1
        all_len+=1
counts['all_length_precision_checks']=all_len

# Independently authored rational Machin/Taylor enclosures. Midpoint rounding
# is required only to be nearby, not to equal correctly rounded transcendental data.
def atan_interval(inv,n):
    value=sum((F((-1)**j,(2*j+1)*inv**(2*j+1)) for j in range(n)),F(0))
    nextterm=F((-1)**n,(2*n+1)*inv**(2*n+1))
    return min(value,value+nextterm),max(value,value+nextterm)
def pi_interval(n):
    a,b=atan_interval(5,n); c,d=atan_interval(239,n)
    return 16*a-4*d,16*b-4*c

def trig_point_interval(x,cosine,degree):
    # Taylor polynomial plus Lagrange remainder bounded by |x|^(m+1)/(m+1)!.
    total=F(0); power=F(1); factorial=1
    for j in range(degree+1):
        if (j%2==0)==cosine:
            total+=((-1)**(j//2))*power/factorial
        power*=x; factorial*=j+1
    rem=abs(power)/factorial
    return total-rem,total+rem

def phase_interval(order,index,bits):
    terms=bits+16
    pl,ph=pi_interval(terms)
    xlo=-2*ph*F(index,order); xhi=-2*pl*F(index,order)
    x=(xlo+xhi)/2; rad=(xhi-xlo)/2
    intervals=[]
    for cosine in (True,False):
        lo,hi=trig_point_interval(x,cosine,4*(bits+16))
        intervals.append((lo-rad,hi+rad))
    return intervals

def select_grid(interval,bits):
    lo,hi=interval; scale=1<<bits; midpoint=(lo+hi)/2
    # Nearest rational midpoint; rational exact ties are resolved upward.
    shifted=midpoint*scale+F(1,2)
    numerator=shifted.numerator//shifted.denominator
    selected=F(numerator,scale)
    return selected,max(abs(selected-lo),abs(selected-hi))

certified=0; exact_ties=0; max_ratio=F(0)
for order in (1,2,4,8,16,31):
    for index in sorted({0,1%order,order//4,order//2,(3*order)//4,order-1}):
        for bits in (12,20):
            for interval in phase_interval(order,index,bits):
                chosen,error=select_grid(interval,bits)
                assert error<F(1,1<<bits)
                max_ratio=max(max_ratio,error*(1<<bits)); certified+=1
                if interval[0]<=0<=interval[1]: exact_ties+=1
# Generic exact midpoint tie and boundary straddles are allowed and terminate.
for numerator in range(-8,9):
    center=F(2*numerator+1,2*(1<<12)); radius=F(1,16*(1<<12))
    chosen,error=select_grid((center-radius,center+radius),12)
    assert error<F(1,1<<12)
    certified+=1
counts['certified_phase_components']=certified
counts['zero_crossing_intervals']=exact_ties
counts['maximum_grid_error_ratio_rational']={'numerator_bits':max_ratio.numerator.bit_length(),'denominator_bits':max_ratio.denominator.bit_length(),'less_than_one':max_ratio<1}
# Check exact dyadic square-root enclosures used by both manuscripts.
squares=0
for Hbits in range(1,257):
    root=isqrt((1<<(2*Hbits))//2)
    assert 2*root*root<=1<<(2*Hbits)<2*(root+1)*(root+1)
    squares+=1
counts['square_root_enclosures']=squares

# Budget-instrumentation control: each simulated elementary instruction is
# checked before execution; each allocation is checked before use. One cannot
# treat a whole arbitrary-precision multiplication as an elementary instruction.
def budget_sim(work,allocations,cap):
    steps=0; live=0; maximum=0; finished=True
    for requested in allocations:
        if steps==cap or live+requested>cap: finished=False; break
        steps+=1;live+=requested;maximum=max(maximum,live)
    if finished:
        for _ in range(work):
            if steps==cap: finished=False;break
            steps+=1
    assert steps<=cap and maximum<=cap
    return finished,steps,maximum
budget_cases=0
for cap in range(1,65):
    for work in (0,cap-1,cap,cap+1,2*cap):
        for allocations in ([],[cap],[cap+1],[1]*cap,[1]*(cap+1),[cap//2,cap//2+1]):
            done,steps,live=budget_sim(work,allocations,cap)
            assert done==(sum(allocations)<=cap and len(allocations)+work<=cap)
            budget_cases+=1
counts['budget_abort_controls']=budget_cases

paths=[
 'packed_fft_candidate_1355/executor_derivation/DYADIC_PACKED_THEOREM.md',
 'packed_fft_candidate_1355/all_length_extension/CONDITIONAL_ALL_LENGTH_THEOREM.md',
 'packed_fft_candidate_1355/independent_audit/FROZEN_PROOF_REVIEW.md',
 'packed_fft_candidate_1355/all_length_independent_review/INDEPENDENT_ACCEPTANCE.md',
 'research_cycle_0958/algorithms/FINAL_THEOREM_AND_PROOF.md']
sources={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in paths}
result={'status':'PASS','fresh_controls_only':True,'source_programs_executed_or_imported':False,'eager_tables_allocated':False,'counts':counts,'sources':sources,'limitations':['Parameter and budget controls do not implement the theorem RAM.','Rational coefficient checks cover selected grid points, not every required coefficient.','No production executor, measured crossover, historical novelty, or fixed-hardware bound is certified.']}
(OUT/'FRESH_CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
