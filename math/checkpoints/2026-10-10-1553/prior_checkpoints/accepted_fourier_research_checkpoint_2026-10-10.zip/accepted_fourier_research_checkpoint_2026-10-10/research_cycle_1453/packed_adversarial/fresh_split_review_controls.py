#!/usr/bin/env python3
"""Independent exact split-table review controls; no source program execution."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
SOURCE=OUT.parent/'packed_improvement'/'SPLIT_TABLE_CONSTRUCTION.md'

checks=0; field_changes=0; built_entries=0

def odometer(width,groups,phase_maps):
    """Build using arbitrary noncontiguous input/output fields."""
    global field_changes,built_entries
    R=1<<width; m=len(groups); D=R**len(groups[0]); total=D**m
    digits=[0]*m; key=0; response=0; table={}; changes=0
    def replace(word,positions,values):
        for position,value in zip(positions,values):
            mask=(R-1)<<(width*position)
            word=(word&~mask)|(value<<(width*position))
        return word
    for i,group in enumerate(groups):
        response=replace(response,group,phase_maps[i]([0]*len(group)))
    table[key]=response
    for count in range(1,total):
        i=0
        while True:
            digits[i]+=1
            carry=digits[i]==D
            if carry: digits[i]=0
            ds=[(digits[i]>>(width*j))&(R-1) for j in range(len(groups[i]))]
            key=replace(key,groups[i],ds)
            response=replace(response,groups[i],phase_maps[i](ds))
            changes+=1
            if not carry: break
            i+=1
        assert key not in table
        table[key]=response
    assert len(table)==total
    assert changes==sum((total-1)//(D**i) for i in range(m))<2*total
    field_changes+=changes;built_entries+=total
    return table

def compare(width,groups,maps):
    global checks
    R=1<<width; table=odometer(width,groups,maps)
    # Independent literal lane extraction/reassembly from each raw key.
    for key,output in table.items():
        lanes=[(key>>(width*i))&(R-1) for i in range(sum(map(len,groups)))]
        result=[0]*len(lanes)
        for group,localmap in zip(groups,maps):
            values=localmap([lanes[i] for i in group])
            for position,value in zip(group,values):result[position]=value
        direct=sum(value<<(width*i) for i,value in enumerate(result))
        assert output==direct;checks+=1

# Phase-dependent unary words: arbitrary total maps of the correct codomain.
for phase in range(7):
    maps=[(lambda ds,q=phase+i:[(3*ds[0]+q)%4]) for i in range(4)]
    compare(2,[(0,),(1,),(2,),(3,)],maps)
# Two separate halves: each digit's fields are nonadjacent in the raw key.
def pair_map(ds):return [(ds[0]+3*ds[1])%4,(2*ds[0]+ds[1]+1)%4]
compare(2,[(0,3),(1,4),(2,5)],[pair_map]*3)
# Two literal stages' different within-word pairing patterns.
for groups in ([(0,1),(2,3)],[(0,2),(1,3)]):
    maps=[]
    for j in range(2):
        maps.append(lambda ds,q=j:pair_map([ds[0],(3*ds[1]+q)%4]))
    compare(2,groups,maps)

# Exact rational numerical majorants at the worst allowed u; every expression
# is monotone in u on [0,1/4]. sqrt(2)>7/5 is used only as a rational bound.
u=F(1,4); delta=u/128; h=1+u/512
assert u*(1+delta)+delta <= (1+F(5,512))*u
assert h*(1+delta)<1+u/32
coefficient=h*(1+F(5,512))+F(1,512)+1+u/32
assert coefficient<3
assert h<F(7,5) and F(7,5)**2<2
assert F(22,1024)<1

# Independent real floating toy witness: extra intermediate rounding matters.
values=[F(0)]+[sgn*(1+F(f,2))*F(2)**exponent for sgn in (-1,1) for exponent in (-1,0,1) for f in (0,1)]
def q(x):
    if x==0:return F(0)
    same=[z for z in values if z*x>=0 and abs(z)<=abs(x)]
    return max(same,key=abs)
a=b=F(1,2);c=s=F(3,4)
old=(q(s*(a+c*b)),q(s*(a-c*b)))
new=(q(s*(a+q(c*b))),q(s*(a-q(c*b))))
assert old==(F(1,2),F(0)) and new==(F(0),F(0))

thresholds=[]
for t,v in ((2,5120),(8,5888),(16,6912),(53,11904)):
    p=t+10+v.bit_length();k=(2*v+p+5).bit_length();b=2*(p+k+1)
    P=1<<((v//(16*b)).bit_length()-1);d=P.bit_length()-1;g=p+10
    R=1<<b;S=R**P;Q=1<<g
    oldcount=(Q-1)*S*S+d*S
    newcount=S*S+(Q-1+d)*S+Q*R+R*R
    assert P==4 and 0<newcount<oldcount
    assert (1<<(2*b*P))<newcount<(1<<(2*b*P+1))
    thresholds.append({'t':t,'v':v,'old_floor_log2':oldcount.bit_length()-1,'new_floor_log2':newcount.bit_length()-1})

result={'status':'PASS','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'fresh_controls_only':True,'source_programs_executed_or_imported':False,'exact_table_entries_checked':checks,'odometer_digit_changes':field_changes,'built_entries':built_entries,'worst_u_stage_error_coefficient':str(coefficient),'toy_non_equivalence':{'a':'1/2','b':'1/2','phase':'3/4','scale':'3/4','old':['1/2','0'],'split':['0','0']},'threshold_counts':thresholds,'limitations':['Toy maps certify field layout/total codomains, not the full transcendental executor.','The non-equivalence witness is a finite real floating toy alphabet, not a counterexample to the theorem error target.','Asymptotic preparation and error acceptance rely on the reviewed analytic proof.']}
(OUT/'SPLIT_REVIEW_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
