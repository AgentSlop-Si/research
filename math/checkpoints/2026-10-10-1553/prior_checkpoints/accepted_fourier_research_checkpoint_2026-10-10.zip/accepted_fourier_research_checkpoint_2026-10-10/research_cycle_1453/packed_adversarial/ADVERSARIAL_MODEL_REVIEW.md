# Adversarial review of the packed Fourier computational contract

10 October 2026. Independent re-derivation and boundary audit.

## Result

**SCOPED PASS at the mathematical proof level.** No counterexample or blocking gap was found in the frozen dyadic theorem or its paired all-length extension. This review does not take the previous acceptance as an assumption: it rechecks the catalogue, exact integer representations, coefficient certification, abort mechanism, finite-size uniformity argument, and the scalar Bluestein fallback directly.

The accepted conclusion is restricted to represented dyadic inputs of the prescribed polynomial dynamic range; a supplied integer precision exponent in the stated finite domain; growing, sufficiently wide `Theta_c(log N)`-bit words; and unit-cost integer multiplication/division on a fixed number of those words. It is an all-input relative-Euclidean approximation theorem with explicit output. No exact-complex, correctly-rounded, per-coordinate-relative, fixed-hardware, practical-speed, or historical-novelty conclusion is certified.

This review preserves all previously accepted files. The associated controls are newly authored and do not execute, import, compile, or convert any predecessor/source program into an executable representation.

## Frozen inputs

| Artifact | SHA-256 |
|---|---|
| `packed_fft_candidate_1355/executor_derivation/DYADIC_PACKED_THEOREM.md` | `bb40decffd28b87a88065880363ff099b0d22071ef976bc67a8195c9b9db6d6f` |
| `packed_fft_candidate_1355/all_length_extension/CONDITIONAL_ALL_LENGTH_THEOREM.md` | `71d85d704058bd245d14ce5aad65f747cb1a5b038e69510b21b41d3c8a217927` |
| `packed_fft_candidate_1355/independent_audit/FROZEN_PROOF_REVIEW.md` | `c8ccac0e576240c4b95dc9f9a58829b0fd33c17062526c5e19324a1a6156fb28` |
| `packed_fft_candidate_1355/all_length_independent_review/INDEPENDENT_ACCEPTANCE.md` | `cbd6224db8650509c18acc6658dadbc5b491dcb9f0d711829c2cc8c1c3545dcd` |
| `research_cycle_0958/algorithms/FINAL_THEOREM_AND_PROOF.md` | `c8a775230a824872c23fc48b351e03d63878154bcfb314a8cca689842e31fc8d` |

The earlier reviews and receipt were read as audit history. The canonical compiler's interpolation identity, coefficient construction, and spectral/rounding bounds were also read directly.

## 1. Addresses, keys, table cardinality, and representation

The complex code width is `b=2(p+k+1)`, with `E=2v+p+5` valid nonzero exponent fields and `k=ceil(log2(E+1))`. Using `E+1`, rather than `E`, keeps zero distinct even at exact powers of two. All padded exponent fields decode to zero, and every response is re-encoded canonically. Thus raw key enumeration does not leave malformed-code behavior undefined.

With the selected power of two `P`, the payload width is `bP<=v/16` and the pair-key/response width is `2bP<=v/8`. For the large table the maximum address is exactly `(Q-1)2^(2bP)-1`. Even before a successful preparation-cap check, this needs at most `g+2bP` bits, bounded by `17v/128+10` in the low-b branch. Counters up to `N+1` need `v+1` bits. Catalogue generation also computes products such as `Q(Ph+l)`; these use at most `2g+log2(P)+O(1)=O(v)` bits. This intermediate multiplication is within the stated model, not an unbounded address calculation.

Actual allocated preparation storage is capped at N words. Input, output, coefficients, working arrays, and scratch have a constant number of such arenas, so simultaneous storage is O(N), with addresses requiring `v+O_c(1)` bits. The unspecified sufficiently large fixed word constant must dominate those constants as well as the online operand constants. That is a legitimate fixed machine choice; it is not permission to increase word width instance by instance.

Every decoded state belongs to `2^(-v-2p) Z[i]`. Its largest lattice numerator has at most `2v+2p+O(1)` bits. A dyadic coefficient or scale multiplication adds only O(p+v) bits, and immediate quantization returns to the same alphabet. Exact interpolation sums add only `log2(number of terms)` carry bits, not a factor equal to the stencil length. This is the representation reason that the all-length wrapper can actually use the backend output in fixed-word arithmetic.

No table is justified merely because its number of rows is below N. The per-row construction work and polynomial-bit rational scratch must also pass the cap. Likewise, packing an output word does not make decoding all P lanes during preparation free.

## 2. Coefficient certification and rounding ties

The frozen dyadic manuscript no longer requires exact rounding of a transcendental value. If a certified interval has width at most a quarter of the grid spacing `Delta`, round its rational midpoint to the nearest grid point. Its distance from the true value is at most `Delta/2+Delta/8<Delta`. Exact ties of the rational midpoint can be broken deterministically. A sine/cosine value exactly on, or arbitrarily close to, a grid boundary does not force the interval routine to resolve an undecidable or unbounded exact-rounding test.

The elementary generator has an explicit uniform bound. L terms of each Machin arctangent series give exponentially small remainder; the bounded-angle sine/cosine Taylor truncation has a factorial remainder. The unreduced rational representations may be polynomially larger than a word, but their multiplication, division, comparison, and storage are explicitly charged as multiword work. The integer-square-root construction gives a one-grid-step enclosure of `1/sqrt(2)` without a transcendental primitive.

For the dyadic grid, `(2pi+sqrt(2))/1024 < 1/128`; for example `pi<22/7` and `sqrt(2)<10/7` already suffice. The resulting butterfly perturbation bound below `u/32` has margin. In the scalar fallback, the guard `K=p+v+20` gives `6N2^-K < u/131072`. Discarding the extra v guard bits would invalidate this recurrence argument; keeping them costs only a fixed number of the growing model words.

The inherited interpolation coefficients have a separately bounded denominator away from zero at every nonzero retained grid argument; the exact zero argument is evaluated by its limiting rational value. Certification there also needs nearby dyadics, not correctly rounded transcendental answers. The manuscript supplies enough guard bits and a polynomial interval-arithmetic bound.

## 3. The abort mechanism and uniformity

A sound implementation may simulate each elementary instruction of the coefficient/table builder with constant additional counter work, stopping before the next charged instruction or allocation would exceed its budget. Counter instrumentation changes constants only. It must not count an entire arbitrary-precision multiply or a bulk allocation as one elementary instruction. Partial tables are never read by execution. Arena reset is constant time; explicitly clearing at most N live slots is still O(N).

This is a computable uniform branch rule even without a numerical crossover threshold. In the low-b branch,

`Unbudgeted preparation <= C 2^(17v/128) (v+1)^K = o(2^v)`

for one fixed implementation and fixed constants C,K, uniformly over every admissible low-b precision. Consequently a failed low-b build implies `v<V0` for one fixed finite V0. Its scalar `O(Nv)` work is then `O(V0 Nb)`. In the high-b branch `v<64b`, so scalar work is directly `O(Nb)`. Neither argument discards small instances or invokes a run-time oracle for hidden constants.

Polynomial certificate work and scratch in the fallback are uniformly O(N) in the finite precision domain because each fixed polynomial in v is bounded by a fixed multiple of `2^v`, including the finite prefix. This is asymptotically legitimate, although it supplies no useful practical constant or feasible crossover.

For every supplied schedule `t=o(v)`, `b=Theta(t+log(v+1))=o(v)` and the low-b guard eventually holds. This does not say that a numerically small t makes the packed branch usable at ordinary sizes. The fresh parameter audit independently reconfirms the enormous necessary eligibility thresholds, beginning at `v=5120` for `t=2`. A guard pass still is not a completed-build certificate.

## 4. Numerical execution and clipping

Every large response implements independent butterflies; every small-span table implements one stage's disjoint butterflies. There is no hidden sequential P-stage error amplification within a response. The catalogue is complete: for r>g the exact phase index is constant across a word because the remainder `(Pc+l)/(P2^(r-g))` is in `[0,1)`. The id formula therefore needs no online pattern search or scalar gathering.

Including initial quantization, J=v+1 rounded stages give relative error at most `14uJ <= 14*epsilon/1024`. The first-clipping argument is valid: it uses only preceding unclipped stages, bounds the next full prequantized vector by less than `2sqrt(2N)`, and contradicts the clipping threshold `32N`. It does not silently apply the small-error quantizer inequality to saturated entries. Unreachable keys can and sometimes must clip, and their total response semantics remain defined.

Exact normalization and final exponent restoration do not change relative error. The input-format bound is indispensable: it guarantees exact lattice alignment, scanning, and scale metadata all occupy O_c(v) bits. Arbitrary real input or unbounded input exponents would not satisfy this contract.

## 5. All-length composition and the independent fallback

The wrapper makes one backend call at precision `T=t+10`, explicitly checks `T<=v+1`, and uses `M` between `4N` and `8N`. Treating the rounded backend as a single linear operator is unnecessary and would be unjustified; the proof uses its pointwise error guarantee on the actual padded input.

The inherited interpolation operators satisfy the required bounds on arbitrary backend errors, not only bandlimited vectors. The three propagated errors are `6rho+4rho+9rho`, and final quantization contributes at most `3rho`. The total `22rho<epsilon` is valid with the backend's actual output lattice. The wrapper builds its leading-bit helper before its successful O(N) normalization scan, so the fast path does not hide an earlier O(N log N) scan.

The wrapper's low-precision preparation is at most a fixed polynomial times `N^(1/4)+2^t(t+1)^2+1`. Under `t<=n/4` this is o(N), uniformly. Failure of a guard or budget is therefore confined to a finite n prefix. For `t>n/4`, the separately supplied scalar `O(Nn)` fallback is `O(Nt)`. The old quadratic fallback alone would not prove the strengthened uniform theorem.

The new scalar Bluestein fallback is internally sufficient. Its normalized identity uses `lambda=sqrt(H/N) U_H b`. The crude `||lambda||_infinity<=sqrt(2H)` bound is enough because the fallback deliberately pays `q=t+log2(H)+ceil(log2(k))+13` fractional bits. Three fixed-lattice scalar FFTs and two guarded root circles then produce total absolute error at most `2048kHu<=epsilon/4`; normalization gives input norm at least 1/2, so the requested relative target follows with slack. This does not transfer a low-precision black-box guarantee through Bluestein without paying the extra log H precision.

The optional arbitrary-t fallback changes the word width and retains polynomial certificate work/scratch. It is separate from the finite-domain improved theorem. No arbitrary-precision fast theorem follows from this review.

## 6. Implementation obligations and stopping boundary

A future implemented executor still must demonstrate all of the following:

1. Total decoding/quantization on every enumerated key, including invalid codes, underflow, and unreachable clipping.
2. Certified dyadic coefficient selection with the actual error margins, never silently replacing it with host floating trigonometry.
3. Complete accounting for elementary multiword operations, scratch allocation, abort, cleanup, and cold rebuilding.
4. The exact packed lane/payload order, complete catalogue address formula, bit-reversal convention, and final materialization.
5. Legal fixed-word widths for input alignment, coefficient products, table addresses, short sums, and output exponents.
6. Both scalar fallbacks and all precision/stencil guards at the exact stated scope.

The proof-level theorem does not depend on having that implementation today. Conversely, toy tests, numerical stress tests, or the present controls do not certify those production obligations. No accepted artifact is changed or widened by this review.

## 7. Fresh controls

`fresh_contract_controls.py` is an independently authored standard-library-only control. It evaluates exact integer parameter/address bounds and long-span boundary identities, exact rational aggregate error budgets, selected rational Machin/Taylor coefficient enclosures, exact square-root enclosures, and synthetic per-instruction/per-allocation abort boundaries. It allocates no eager response table and imports no research program.

The machine-readable `FRESH_CONTROL_RESULTS.json` records exact completed counts and source hashes. These finite controls are falsification evidence; the analytic arguments above establish the asymptotic scope. Split-table construction proposals, if reviewed, are recorded in a separate addendum and are not silently substituted into these frozen sources.
