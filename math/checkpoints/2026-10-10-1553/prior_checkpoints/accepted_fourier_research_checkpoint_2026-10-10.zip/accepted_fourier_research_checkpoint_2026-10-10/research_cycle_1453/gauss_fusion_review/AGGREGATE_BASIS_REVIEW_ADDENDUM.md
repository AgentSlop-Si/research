# Independent acceptance of the aggregate-basis continuation

10 October 2026. This is separate from the frozen core receipt.

The reviewed source is `gauss_graph/aggregate_basis/AGGREGATE_BASIS_REDUCTION.md`, SHA-256 `0a8ecb2787dd262c08e22bce3fbb1de50e6c0a45394811637da0cd011a9d3ee4`. It is accepted with its explicit square-invertible, prime-complex, separately colored middle-edge scope.

## Accepted statements

1. The aggregate identity forces B_t=ζ^q(t)(C⁻¹F)_[:,t](FA⁻¹)_[t,:]. Thus the exact edge objective is nnz(A)+nnz(C)+Σ_t r(t)s(t). Distinct latent coordinates may share matrix positions through separately counted parallel edges.
2. Prime Fourier uncertainty gives E≥2p²+p+Σ_t(r(t)−1)(s(t)−1)−δ_A−δ_C, where δ_X=nnz(X⁻¹)−nnz(X). The displayed strict inverse-expansion condition is necessary, not sufficient, for beating the dense Gauss count.
3. With A=F, any C whose inverse is no denser cannot improve 2p²+p. This includes invertible rank-one updates C=I+uv^T when every diagonal entry of C is nonzero. The qualifier cannot be dropped from the support argument: u=(1,1,1),v=(−1,1,1) gives nnz(C)=8 and nnz(C⁻¹)=9.
4. Every p=3 unit lower-bidiagonal C with nonzero subdiagonal parameters has E≥21. To obtain three zeros in C⁻¹F would require the parameter a to be both a cube root of unity and the negative of a cube root. This is impossible over C. The parameters a=b=−1 attain 21.
5. The supplied determinant expansion proves the required prime-Fourier nonvanishing-minor theorem correctly. The Vandermonde/factorial coefficient is nonzero modulo p, including the k=p endpoint. The uncertainty consequence follows from an invertible minor. This is classical material, not a new theorem attribution.

## Fresh independent controls

`fresh_basis_controls.py` imports only the reviewer's own newly authored cyclotomic arithmetic helper. It never imports or executes any constructor or uploaded source program. It passes:

- 44 exact rational/cyclotomic shared-basis cases at p=3,5,7,11
- 286 prime-complex uncertainty row controls
- Exact two-sided slice/objective checks at p=3,5,7
- All three p=3 root pairs in the forbidden bidiagonal configuration
- The 21-edge bidiagonal witness and 8-versus-9 rank-one qualifier counterexample

Full results are in `FRESH_BASIS_RESULTS.json`. These finite checks are controls; the all-parameter statements rest on the reviewed proofs.

No claim is accepted for arbitrary rectangular layers, a general two-sided minimizer, coefficient-generation complexity, finite-word work, historical priority, or a subquadratic Fourier construction. In particular, the one-sided A=F family already has p² boundary edges and cannot establish the desired asymptotic speedup.
