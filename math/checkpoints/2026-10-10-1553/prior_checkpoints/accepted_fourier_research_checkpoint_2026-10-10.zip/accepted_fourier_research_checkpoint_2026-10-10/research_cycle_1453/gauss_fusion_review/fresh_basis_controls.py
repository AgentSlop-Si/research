"""Independent exact controls for the shared-basis reduction.

Imports only this reviewer's own freshly authored arithmetic helper, never the
constructor's or uploaded source code.
"""
from fractions import Fraction as Q
from random import Random
from pathlib import Path
import json
from fresh_review_controls import Cyclotomic, linear_solve


def nnz(A):
    return sum(bool(x) for row in A for x in row)


def rank_one_pair(u, v):
    n = len(u)
    d = 1 + sum(x * y for x, y in zip(u, v))
    assert d
    C = [[Q(int(i == j)) + u[i] * v[j] for j in range(n)] for i in range(n)]
    Ci = [[Q(int(i == j)) - Q(u[i] * v[j], d) for j in range(n)] for i in range(n)]
    assert all(sum(C[i][k] * Ci[k][j] for k in range(n)) == int(i == j)
               for i in range(n) for j in range(n))
    return C, Ci


def rational_inverse(A):
    n = len(A)
    cols = [linear_solve(A, [int(i == j) for i in range(n)]) for j in range(n)]
    return [list(row) for row in zip(*cols)]


def right_fourier(E, A):
    return [[E.total(E.scale(E.root(k * j), A[i][k]) for k in range(E.p))
             for j in range(E.p)] for i in range(E.p)]


def main():
    cases = []
    row_checks = 0
    rng = Random(78193)
    for p in [3, 5, 7, 11]:
        E = Cyclotomic(p)
        matrices = []
        for _ in range(10):
            while True:
                u = [rng.randrange(-2, 3) for _ in range(p)]
                v = [rng.randrange(-2, 3) for _ in range(p)]
                if 1 + sum(x * y for x, y in zip(u, v)):
                    break
            matrices.append((*rank_one_pair(u, v), "rank_one"))
        C = [[Q(int(i == j or j == i + 1)) for j in range(p)] for i in range(p)]
        matrices.append((C, rational_inverse(C), "upper_bidiagonal"))
        for C, Ci, family in matrices:
            R = right_fourier(E, Ci)
            support_R = sum(x != E.zero for row in R for x in row)
            for i in range(p):
                assert sum(bool(x) for x in Ci[i]) + sum(x != E.zero for x in R[i]) >= p + 1
                row_checks += 1
            edges = p * p + nnz(C) + support_R
            floor = 2 * p * p + p + nnz(C) - nnz(Ci)
            assert edges >= floor
            if all(C[i][i] for i in range(p)) and family == "rank_one":
                assert nnz(Ci) <= nnz(C)
                assert edges >= 2 * p * p + p
            # Exact recovery of all Fourier columns after C times R.
            for i in range(p):
                for j in range(p):
                    actual = E.total(E.scale(R[k][j], C[i][k]) for k in range(p))
                    assert actual == E.root(i * j)
            cases.append({"p": p, "family": family, "nnz_C": nnz(C),
                          "nnz_C_inverse": nnz(Ci), "nnz_C_inverse_F": support_R,
                          "edges": edges, "uncertainty_floor": floor})
    C, Ci = rank_one_pair([1, 1, 1], [-1, 1, 1])
    assert nnz(C) == 8 and nnz(Ci) == 9
    two_sided = []
    for p in [3, 5, 7]:
        E = Cyclotomic(p)
        u, v = [1] + [0] * (p - 1), [0, 1] + [0] * (p - 2)
        C, Ci = rank_one_pair(u, v)
        A, Ai = rank_one_pair(v, u)
        R = right_fourier(E, Ci)
        S = [[E.total(E.scale(E.root(i * k), Ai[k][j]) for k in range(p))
              for j in range(p)] for i in range(p)]
        r = [sum(R[i][t] != E.zero for i in range(p)) for t in range(p)]
        s = [sum(S[t][j] != E.zero for j in range(p)) for t in range(p)]
        penalty = sum((x - 1) * (y - 1) for x, y in zip(r, s))
        delta = nnz(Ai) - nnz(A) + nnz(Ci) - nnz(C)
        edges = nnz(A) + nnz(C) + sum(x * y for x, y in zip(r, s))
        assert edges >= 2 * p * p + p + penalty - delta
        for t in range(p):
            left = [E.total(E.scale(R[k][t], C[i][k]) for k in range(p)) for i in range(p)]
            right = [E.total(E.scale(S[t][k], A[k][j]) for k in range(p)) for j in range(p)]
            assert all(left[i] == E.root(i * t) for i in range(p))
            assert all(right[j] == E.root(j * t) for j in range(p))
            assert sum(E.mul(R[i][t], S[t][j]) != E.zero for i in range(p) for j in range(p)) == r[t] * s[t]
        two_sided.append({"p": p, "edges": edges, "mixing_penalty": penalty,
                          "inverse_support_expansion": delta})
    E = Cyclotomic(3)
    lower = [[Q(1), Q(0), Q(0)], [Q(-1), Q(1), Q(0)], [Q(0), Q(-1), Q(1)]]
    lower_inv = rational_inverse(lower)
    RF = right_fourier(E, lower_inv)
    assert nnz(lower) == 5 and nnz(lower_inv) == 6
    assert sum(x != E.zero for row in RF for x in row) == 7
    assert 9 + 5 + 7 == 21
    for i in range(3):
        for j in range(i + 1, 3):
            r, s = E.root(i), E.root(j)
            a = E.mul(E.mul(r, s), E.inverse(E.add(r, s)))
            assert E.mul(E.mul(a, a), a) == E.scale(E.one, -1)
            assert a not in [E.root(k) for k in range(3)]
    result = {"all_assertions_passed": True, "exact_basis_cases": len(cases),
              "prime_complex_uncertainty_row_controls": row_checks,
              "cases": cases,
              "two_sided_gate_controls": two_sided,
              "bidiagonal_N3": {"equality_edges": 21, "forbidden_root_pairs": 3},
              "rank_one_qualifier_counterexample": {
                  "u": [1, 1, 1], "v": [-1, 1, 1], "nnz_C": 8,
                  "nnz_C_inverse": 9, "missing_hypothesis": "C has a zero diagonal entry"}}
    Path(__file__).with_name("FRESH_BASIS_RESULTS.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ["all_assertions_passed", "exact_basis_cases",
                                           "prime_complex_uncertainty_row_controls"]}))


if __name__ == "__main__":
    main()
