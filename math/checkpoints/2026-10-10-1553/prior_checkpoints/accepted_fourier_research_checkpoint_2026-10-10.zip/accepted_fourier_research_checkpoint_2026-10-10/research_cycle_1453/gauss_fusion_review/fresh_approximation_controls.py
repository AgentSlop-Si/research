"""Fresh independent rational three-phase approximation controls.

Exact equality and coefficient error certificates use rational/cyclotomic
arithmetic. The separate angle-grid sanity check is explicitly numerical.
"""
from fractions import Fraction as Q
from math import isqrt, ceil, cos, pi, sqrt
from pathlib import Path
import json
from fresh_review_controls import Cyclotomic


def main():
    exact = []
    eps = Q(1, 100)
    for p in [3, 5, 7, 11]:
        E = Cyclotomic(p)
        a = (p + 1) // 3
        palette = [0, a, p - a]
        gaps = [palette[1], palette[2] - palette[1], p - palette[2]]
        assert all(Q(1, 5) <= Q(g, p) <= Q(3, 7) for g in gaps)
        ceiling_sqrt = isqrt(p) + int(isqrt(p) ** 2 < p)
        D = ceil(2 * ceiling_sqrt / eps)
        reps = []
        worst_error = Q(0)
        for k in range(p):
            if k in palette:
                reps.append([(k, Q(1))])
                continue
            extended = palette + [p]
            left, right = next((l, r) for l, r in zip(extended, extended[1:]) if l < k < r)
            gap = right - left
            invden = E.inverse(E.sub(E.root(gap), E.root(-gap)))
            alpha = E.mul(E.sub(E.root(right - k), E.root(k - right)), invden)
            beta = E.mul(E.sub(E.root(k - left), E.root(left - k)), invden)
            assert E.add(E.mul(alpha, E.root(left)), E.mul(beta, E.root(right))) == E.root(k)
            rational_coeffs = []
            for c in [alpha, beta]:
                assert E.sign(c) > 0
                assert E.sign(E.sub(E.scale(E.one, Q(7, 2)), c)) >= 0
                lo, hi = E.interval(c)
                mid = (lo + hi) / 2
                rounded = Q((mid.numerator * D * 2 + mid.denominator) // (2 * mid.denominator), D)
                err = max(abs(lo - rounded), abs(hi - rounded))
                assert rounded > 0 and err <= Q(1, D)
                worst_error = max(worst_error, err)
                rational_coeffs.append(rounded)
            reps.append([(left % p, rational_coeffs[0]), (right % p, rational_coeffs[1])])
        # Entry error<=2/D implies relative operator error<=2*sqrt(p)/D.
        assert 4 * p <= eps * eps * D * D
        edges = sum(len(reps[i * j % p]) for i in range(p) for j in range(p))
        assert edges == 2 * p * p - 4 * p + 3
        exact.append({"p": p, "epsilon": str(eps), "common_denominator": D,
                      "bounded_triangle_palette": palette,
                      "exact_coefficients_certified_le_7_over_2": True,
                      "edge_count": edges, "rational_coefficients": [
                          [[r, str(c)] for r, c in rep] for rep in reps],
                      "coefficient_error_certified_le_1_over_D": True,
                      "relative_operator_error_certified_le_epsilon": True})
    # Exact scalar proof boundary: p/6+sqrt[p(p+1)/12]<=p/2 for p>=3
    # is equivalent to p+1<=4p/3 after moving and squaring positives.
    for p in [3, 5, 7, 11, 13, 17, 19, 23, 31, 43, 101]:
        assert p + 1 <= Q(4 * p, 3)
        assert Q(p - 1, 6 * p) >= Q(1, 9)
    E = Cyclotomic(3)
    half = E.scale(E.one, Q(1, 2))
    assert E.scale(E.add(E.root(1), E.root(-1)), Q(1, 2)) == E.scale(half, -1)
    # Independent floating-point grid only corroborates the all-angle proof.
    numerical = []
    for p in [3, 5, 7, 11, 17, 31, 101]:
        smallest = p
        for k in range(1000):
            theta = 2 * pi * k / 1000
            values = [cos(theta + 2 * pi * r / p) for r in range(p)]
            neg_sq = sum(min(0, x) ** 2 for x in values)
            smallest = min(smallest, neg_sq)
            assert neg_sq + 1e-10 >= p / 6
        numerical.append({"p": p, "sampled_min_negative_squared_sum": smallest,
                          "proved_floor": str(Q(p, 6)), "proof_status": "numerical_control_only"})
    result = {"all_assertions_passed": True, "exact_rational_approximations": exact,
              "two_phase_uniform_relative_error_floor": "1/3",
              "assumptions": "depth one, at most two global phase rays, nonnegative real amplitudes, no free endpoint gauges",
              "numerical_angle_grids": numerical}
    Path(__file__).with_name("FRESH_APPROXIMATION_RESULTS.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"all_assertions_passed": True, "exact_prime_cases": len(exact),
                      "numerical_angles": 7000}))


if __name__ == "__main__":
    main()
