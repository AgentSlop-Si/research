"""Independently authored review controls. No source-package programs imported.

Exact rational cyclotomic arithmetic and certified real-embedding intervals.
Finite controls supplement the proofs; they do not extrapolate algorithms.
"""
from fractions import Fraction as Q
from math import factorial, gcd
from itertools import combinations, product
import json
from pathlib import Path


def linear_solve(rows, rhs):
    a = [[Q(x) for x in row] + [Q(y)] for row, y in zip(rows, rhs)]
    n = len(a)
    assert all(len(row) == n + 1 for row in a)
    for j in range(n):
        pivot = next(i for i in range(j, n) if a[i][j])
        a[j], a[pivot] = a[pivot], a[j]
        v = a[j][j]
        a[j] = [x / v for x in a[j]]
        for i in range(n):
            if i != j and a[i][j]:
                v = a[i][j]
                a[i] = [x - v * y for x, y in zip(a[i], a[j])]
    return [row[-1] for row in a]


def atan_interval(inv, terms):
    x = Q(1, inv)
    s = sum(((-1) ** k * x ** (2 * k + 1) / (2 * k + 1)
             for k in range(terms)), Q(0))
    term = (-1) ** terms * x ** (2 * terms + 1) / (2 * terms + 1)
    return min(s, s + term), max(s, s + term)


a5 = atan_interval(5, 90)
a239 = atan_interval(239, 30)
PI = (16 * a5[0] - 4 * a239[1], 16 * a5[1] - 4 * a239[0])


def cosine_interval(k, p):
    # Taylor at rational midpoint; cosine is 1-Lipschitz on R.
    k = min(k % p, (-k) % p)
    lo, hi = (2 * Q(k, p) * x for x in PI)
    mid = (lo + hi) / 2
    terms = 45
    center = sum(((-1) ** j * mid ** (2 * j) / factorial(2 * j)
                  for j in range(terms)), Q(0))
    error = abs(mid) ** (2 * terms) / factorial(2 * terms) + (hi - lo) / 2
    return center - error, center + error


class Cyclotomic:
    def __init__(self, p):
        self.p = p
        self.n = p - 1
        self.zero = tuple(Q(0) for _ in range(self.n))
        self.one = (Q(1),) + self.zero[1:]
        self.cos = [cosine_interval(k, p) for k in range(self.n)]

    def root(self, k):
        k %= self.p
        if k == self.n:
            return tuple(Q(-1) for _ in range(self.n))
        return tuple(Q(int(j == k)) for j in range(self.n))

    def add(self, a, b):
        return tuple(x + y for x, y in zip(a, b))

    def scale(self, a, c):
        return tuple(c * x for x in a)

    def sub(self, a, b):
        return self.add(a, self.scale(b, -1))

    def mul(self, a, b):
        c = [Q(0)] * self.p
        for i, x in enumerate(a):
            for j, y in enumerate(b):
                c[(i + j) % self.p] += x * y
        return tuple(c[i] - c[-1] for i in range(self.n))

    def total(self, xs):
        out = self.zero
        for x in xs:
            out = self.add(out, x)
        return out

    def inverse(self, a):
        cols = [self.mul(a, self.root(j)) for j in range(self.n)]
        return tuple(linear_solve(list(zip(*cols)), self.one))

    def interval(self, a):
        lo = hi = Q(0)
        for c, (x, y) in zip(a, self.cos):
            lo += c * (x if c >= 0 else y)
            hi += c * (y if c >= 0 else x)
        return lo, hi

    def sign(self, a):
        if a == self.zero:
            return 0
        lo, hi = self.interval(a)
        assert lo > 0 or hi < 0, "Unresolved interval: never guess sign"
        return 1 if lo > 0 else -1


def primitive_mod_p(p):
    return next(g for g in range(2, p)
                if len({pow(g, k, p) for k in range(p - 1)}) == p - 1)


def field_palette_controls():
    results = []
    targets = 0
    for p in [3, 5, 7, 11, 13, 17]:
        E = Cyclotomic(p)
        g = primitive_mod_p(p)
        for h in range(2, p):
            if (p - 1) % h or h % 2:
                continue
            H = {pow(g, j * ((p - 1) // h), p) for j in range(h)}
            remaining = set(range(1, p))
            cosets = []
            while remaining:
                C = sorted({min(remaining) * x % p for x in H})
                cosets.append(C)
                remaining.difference_update(C)
            periods = [E.total(E.root(r) for r in C) for C in cosets]
            assert E.total(periods) == E.scale(E.one, -1)
            assert E.total(E.mul(x, x) for x in periods) == E.scale(E.one, p - h)
            negative = next(j for j, eta in enumerate(periods) if E.sign(eta) < 0)
            C = cosets[negative]
            eta = periods[negative]
            palette = [0] + C
            assert E.add(E.scale(eta, -1), E.total(E.root(r) for r in C)) == E.zero
            # Periods form an L/Q basis. C provides an E/L basis.
            cols = [E.mul(E.root(r), period) for r in C for period in periods]
            assert len(cols) == p - 1
            A = list(zip(*cols))
            representation_counts = []
            for target in range(p):
                solution = linear_solve(A, E.root(target))
                m = len(periods)
                coeffs = [E.total(E.scale(periods[k], solution[j * m + k])
                                  for k in range(m)) for j in range(h)]
                # Shift coefficients along the explicit positive relation.
                t = E.zero
                for c in coeffs:
                    candidate = E.scale(c, -1)
                    if E.sign(E.sub(candidate, t)) > 0:
                        t = candidate
                out_coeffs = [E.mul(t, E.scale(eta, -1))] + [E.add(c, t) for c in coeffs]
                assert all(E.sign(c) >= 0 for c in out_coeffs)
                actual = E.total(E.mul(c, E.root(r)) for c, r in zip(out_coeffs, palette))
                assert actual == E.root(target)
                count = sum(c != E.zero for c in out_coeffs)
                assert count == (1 if target in palette else h)
                representation_counts.append(count)
                targets += 1
            edges = sum(representation_counts[i * j % p] for i in range(p) for j in range(p))
            assert edges == 2 * p - 1 + h * (p - 1) * (p - h)
            positive_period = None
            if h < p - 1:
                j = next(j for j, period in enumerate(periods) if E.sign(period) > 0)
                inv = E.inverse(periods[j])
                assert E.sign(inv) > 0
                assert E.mul(inv, E.total(E.root(r) for r in cosets[j])) == E.one
                positive_period = cosets[j]
            results.append({"p": p, "h": h, "palette": palette,
                            "minimal_palette_size": h + 1,
                            "exact_direct_edges": edges,
                            "positive_period_coverage_counterexample": positive_period,
                            "signs_certified_by_rational_intervals": True})
    return {"cases": results, "exact_target_representations": targets}


def prime(n):
    return n >= 2 and all(n % d for d in range(2, int(n ** 0.5) + 1))


def field_for(n):
    q = next(q for q in range(n + 1, 10000, n) if prime(q))
    w = next(w for w in range(2, q) if pow(w, n, q) == 1 and
             all(pow(w, d, q) != 1 for d in range(1, n) if n % d == 0))
    return q, w


def weyl_status(M, w, q):
    n = len(M)
    base = all(M[i][0] == 1 for i in range(n))
    covariance = all(M[i][(j + 1) % n] == pow(w, i, q) * M[i][j] % q
                     for i in range(n) for j in range(n))
    return {"base_column": base, "covariance": covariance}


def gauss_weyl_controls():
    results = []
    total = 0
    for n in [3, 5, 7, 9, 15]:
        q, w = field_for(n)
        half = pow(2, -1, n)
        G = sum(pow(w, -half * t * t % n, q) for t in range(n)) % q
        assert G
        F = [[pow(w, i * j % n, q) for j in range(n)] for i in range(n)]
        M = []
        perturbed = []
        for i in range(n):
            row = []
            bad = []
            for j in range(n):
                fiber = [pow(w, (-half * t * t + (i + j) * t) % n, q)
                         for t in range(n)]
                prefactor = pow(G, -1, q) * pow(w, -half * (i * i + j * j) % n, q) % q
                row.append(prefactor * sum(fiber) % q)
                bad.append(prefactor * (sum(fiber) + fiber[0]) % q)
            M.append(row)
            perturbed.append(bad)
        assert M == F
        assert weyl_status(M, w, q) == {"base_column": True, "covariance": True}
        assert perturbed != F
        assert not weyl_status(perturbed, w, q)["covariance"]
        row_scaled = [[(2 if i == 0 else 1) * x % q for x in row] for i, row in enumerate(F)]
        base_only = [row[:] for row in F]
        base_only[0][1] = (base_only[0][1] + 1) % q
        assert weyl_status(row_scaled, w, q) == {"base_column": False, "covariance": True}
        assert weyl_status(base_only, w, q) == {"base_column": True, "covariance": False}
        # A nonseparable pairwise multiplier preserves complete weighted fibers,
        # but cannot be removed by row/column diagonal corrections.
        lam = [[2 if (i, j) == (0, 0) else 1 for j in range(n)] for i in range(n)]
        assert (lam[0][0] * lam[1][1] - lam[0][1] * lam[1][0]) % q != 0
        # Fresh evaluation of the aggregate/pointwise separating shear.
        # C=I+E_01 and B_t=chirp(t)*(C^-1 chi_t)*e_t^T.
        for t in range(n):
            chi = [pow(w, i * t % n, q) for i in range(n)]
            inv_chi = chi[:]
            inv_chi[0] = (chi[0] - chi[1]) % q
            restored = inv_chi[:]
            restored[0] = (inv_chi[0] + inv_chi[1]) % q
            assert restored == chi
            chirp = pow(w, -half * t * t % n, q)
            for i in range(n):
                for j in range(n):
                    actual_slice = chirp * restored[i] * pow(w, t * j % n, q) % q
                    expected_slice = pow(w, (-half * t * t + (i + j) * t) % n, q)
                    assert actual_slice == expected_slice
        # V_1 serves outputs0,1 with ratio1 for all t, incompatible with any
        # fixed output gauge and varying primitive-root character ratio.
        assert pow(w, 1, q) != 1
        assert n * n + (n + 1) + (n * n - 1) == 2 * n * n + n
        total += n * n
        results.append({"N": n, "field": q, "root": w, "gauss": G,
                        "exact_entries": n * n, "same_phase_amplitude_failure": True,
                        "weyl_halves_independently_necessary": True,
                        "nonseparable_fiber_multiplier_rejected": True,
                        "aggregate_shear_escapes_pointwise_gauges": True})
    # A two-prime finite-field pass is not a complex symbolic certificate.
    q1, q2 = 7, 13
    perturbation = q1 * q2
    assert perturbation % q1 == perturbation % q2 == 0 and perturbation != 0
    return {"cases": results, "exact_entries": total,
            "two_field_false_positive_integer_perturbation": perturbation}


def color_coverage_controls():
    # Independently enumerate N=2 supports with exactly two U and two V.
    # Every middle edge carries one color, and a mixed U or V has one color.
    # This exhausts a bounded model, not arbitrary-width graphs.
    n = 2
    subsets = [(0,), (1,), (0, 1)]
    tested = accepted = 0
    minimum = None
    for J in product(subsets, repeat=2):
        for I in product(subsets, repeat=2):
            for labels in product((-1, 0, 1), repeat=4):
                tested += 1
                middle = [(u, v, labels[2 * u + v]) for u in range(2) for v in range(2)
                          if labels[2 * u + v] >= 0]
                if any(len(J[u]) > 1 and len({t for a, v, t in middle if a == u}) > 1
                       for u in range(2)):
                    continue
                if any(len(I[v]) > 1 and len({t for u, b, t in middle if b == v}) > 1
                       for v in range(2)):
                    continue
                coverage = {(i, j, t) for u, v, t in middle for i in I[v] for j in J[u]}
                if len(coverage) != n ** 3:
                    continue
                accepted += 1
                edges = sum(map(len, J)) + sum(map(len, I)) + len(middle)
                assert edges >= 2 * n * n + n
                minimum = edges if minimum is None else min(minimum, edges)
    assert accepted and minimum == 10
    # The phase subtraction rule is an annihilator condition at composite N.
    composite = []
    for n, A, B in [(9, [0, 3, 6], [0, 3, 6]), (15, [0, 5, 10], [0, 3, 6, 9, 12])]:
        assert all((a - aa) * (b - bb) % n == 0 for a, aa in product(A, repeat=2)
                   for b, bb in product(B, repeat=2))
        assert len(A) > 1 and len(B) > 1
        composite.append({"N": n, "input_set": A, "latent_set": B})
    # Exhaustive subset check of |J||T|<=N under pairwise annihilation.
    annihilator_cases = 0
    for n in range(2, 10):
        for mask in range(1, 1 << (n - 1)):
            A = [0] + [j for j in range(1, n) if mask >> (j - 1) & 1]
            T = [t for t in range(n) if all(a * t % n == 0 for a in A)]
            assert len(A) * len(T) <= n
            annihilator_cases += 1
    return {"bounded_N2_supports": tested, "complete_supports": accepted,
            "minimum_edges": minimum, "composite_single_color_counterexamples": composite,
            "annihilator_subset_controls": annihilator_cases}


def f5_cone_and_amplitudes():
    E = Cyclotomic(5)
    q = E.add(E.root(1), E.root(4))
    lam = E.add(q, E.one)
    assert E.sign(q) > 0 and E.sign(lam) > 0
    assert E.add(E.mul(q, q), q) == E.one
    assert E.mul(lam, E.add(E.root(1), E.root(4))) == E.one
    assert E.mul(lam, E.add(E.one, E.root(2))) == E.root(1)
    assert E.mul(lam, E.add(E.one, E.root(3))) == E.root(4)
    palette = [0, 2, 3]
    gaps = [palette[j + 1] - palette[j] for j in range(2)] + [5 + palette[0] - palette[-1]]
    span = 5 - max(gaps)
    assert 2 * span > 5
    lo, hi = E.interval(q)
    denom = 10 ** 10
    short_interval = [Q(lo.numerator * denom // lo.denominator, denom),
                      Q(-((-hi.numerator * denom) // hi.denominator), denom)]
    assert 0 < short_interval[0] <= lo <= hi <= short_interval[1]
    return {"all_identities_exact": True, "palette": palette, "edges": 33,
            "shortest_arc_turns": [span, 5], "narrow_phase_cone_inapplicable": True,
            "q_positive_interval": [str(x) for x in short_interval]}


def main():
    report = {"authorship": "Fresh independent reviewer program; no source imports or execution",
              "amplitude_fields": field_palette_controls(),
              "gauss_weyl": gauss_weyl_controls(),
              "routing_colors": color_coverage_controls(),
              "F5": f5_cone_and_amplitudes(),
              "all_assertions_passed": True}
    path = Path(__file__).with_name("FRESH_REVIEW_RESULTS.json")
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"all_assertions_passed": True,
                      "field_cases": len(report["amplitude_fields"]["cases"]),
                      "exact_field_targets": report["amplitude_fields"]["exact_target_representations"],
                      "gauss_entries": report["gauss_weyl"]["exact_entries"],
                      "bounded_supports": report["routing_colors"]["bounded_N2_supports"]}, indent=2))


if __name__ == "__main__":
    main()
