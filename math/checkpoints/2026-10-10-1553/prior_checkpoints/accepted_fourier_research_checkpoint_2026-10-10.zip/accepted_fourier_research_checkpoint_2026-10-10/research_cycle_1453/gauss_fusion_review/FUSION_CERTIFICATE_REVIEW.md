# Independent review of weighted Gauss, routing, and Weyl certificates

10 October 2026. Local research review. No external writes. No supplied program was executed or imported.

## Immediate decision

The proposed fusion has a valid conditional theorem, but no sparse Fourier construction follows from the reviewed source. Three logically separate objects must be supplied: an actual weighted execution graph, an exact transfer identity for that graph, and its complete construction/evaluation ledger. A superconcentrator supports the necessary routing; it does not construct Fourier weights. A positive irrational phase palette changes the coefficient grammar; it does not reduce the depth-one quadratic edge count.

Two new restricted conclusions survive independent adversarial review:

1. For an odd prime p and a real coefficient field K, the minimum global pth-root phase palette for a depth-one positive-K-amplitude realization of F_p is h+1, where h=[Q(ζ_p):K∩Q(ζ_p)]. In that minimum-palette class, the minimum direct edge count is (2p−1)+h(p−1)(p−h). This remains quadratic, and becomes 33 for p=5 and h=2.
2. In the strict depth-three model with a latent label on every middle edge and a pointwise character-rectangle law, complete nonzero fibers force at least 2p²+p edges. This holds for actual arbitrary nonzero complex weights. A separate formal every-path exponent law also implies the bound. The dense Gauss construction attains it. This rejects the proposed sparse fusion in these particular pointwise grammars. The aggregate weighted-fiber problem remains open here.

Neither assertion is promoted to an unrestricted FFT lower bound or a historical-priority claim.

## 1. Source scope and preserved conclusions

The review reads `new_source_audit/TECHNICAL_AUDIT_v2.md`, the exact Gauss source text, the Schur-support review, and the phase-cone review. It independently reconstructs the F5 identities and checks the new construction/field drafts as they become available. The prior conclusions remain sound within their stated models:

- The prime unit-root path-count theorem and its positive-rational extension do not apply unchanged to arbitrary positive real amplitudes.
- Prime-complex-Fourier total nonsingularity forces superconcentrator support. The fixed-weight converse fails. Generic totally nonsingular weights are not Fourier weights.
- The half-rectangle exposed by a triangular Schur baseline is a necessary subproblem, not a complete Fourier or Schur algorithm.
- A common entrywise cone of width W<π gives the accepted normalized spectral obstruction. Failure of a cone test is inconclusive.
- The Weyl conditions M e_0=1 and MS=DM jointly certify Fourier, with the stated shift and root conventions. Neither alone does.

The odd-composite Gauss identity itself is valid. Prime-only routing or cyclotomic-count consequences must not be imported into that composite setting without a separate proof.

## 2. Correct sufficient aggregate certificate

Let N be odd, ω a primitive Nth root in C, and G=Σ_t ω^(−t²/2). Use a finite scalar DAG with distinct/disjoint source and sink terminals, all its actual coefficients and all parallel edges accounted for. Partition the FULL path multiset for each pair (i,j) into fibers P_ijt. Set

    H_t[i,j] = Σ_(P∈P_ijt) ∏_(e∈P) w_e.

A sufficient certificate is

    H_t[i,j] = a_i b_j ω^(−t²/2+(i+j)t+ρ_i+σ_j),

with every a_i,b_j nonzero and independent of t. Then the raw graph transfer is

    T[i,j] = G a_i b_j ω^(ρ_i+i²/2) ω^(σ_j+j²/2) ω^(ij).

The explicitly charged diagonal endpoint corrections therefore recover F_N. The usual character-orthogonality proof gives |G|²=N and hence G≠0. No termwise unit amplitude, unique path, or absence of cancellation is required for this aggregate identity.

An equivalent symbolic slice certificate is

    H_0 = u v^T,
    H_(t+1) = ω^(−t−1/2) D H_t D,
    u_i=a_iω^ρ_i, v_j=b_jω^σ_j,
    D=diag(1,ω,...,ω^(N−1)),

for every residue t, with cyclic indexing. Induction gives the desired slices. This is a concrete way to pursue a certificate without asserting a phase law for each individual path.

For strict X→U→V→Y graphs, write A for X→U, B for U→V, and C for V→Y. If middle-edge labels define the fibers, let B_t be the corresponding edge-mask matrix, including parallel-edge sums, and prove H_t=C B_t A. A candidate may establish the slice recurrence after aggregation even when individual paths do not have its phase. Any stronger local-intertwiner identity must be separately verified rather than assumed from support.

If the proposed amplitude is λ_ij instead of a_i b_j, diagonal endpoint correction is possible exactly when the nonzero matrix [λ_ij] has rank one, equivalently all its multiplicative 2×2 cross-ratios are one. A t-independent but nonseparable multiplier is not sufficient.

## 3. Sharp obstruction for the pointwise-character version

### Actual complex-weight model

The constructor's final draft uses an improved intrinsic hypothesis. Write A[u,j], B_e, C[i,v] for the nonzero weights along a path through a middle edge e=(u,v), whose label is t. Fix global nonzero endpoint gauges a_i,b_j. For each middle edge require a nonzero scalar η_e such that

    C[i,v] B_e A[u,j] = η_e a_i b_j ζ^((i+j)t)

for every input/output pair in that middle edge's rectangle. Dividing two equations gives

    A[u,j]/A[u,j′] = (b_j/b_j′) ζ^((j−j′)t).

Repeating for a different middle edge at u forces its label to agree whenever j≠j′. The analogous output ratio does the same for V. This is valid with arbitrary complex amplitudes because it constrains actual products. The prime local-rigidity and counting proof below therefore applies. Ordinary single outer-layer edges per matrix entry suffice; parallel middle edges are explicitly counted.

### A separate formal exponent certificate

Let p be prime and use a strict four-layer graph X→U→V→Y. Every middle edge e=(u,v) has a label t_e∈F_p. Each edge also has a residue exponent. For EVERY path X_j→u→v→Y_i through e, require

    α_uj+β_e+γ_iv = q(t_e)+(i+j)t_e+ρ_i+σ_j mod p.

Here q is any fixed function, not necessarily quadratic. Every (i,j,t) must have at least one path, as is necessary for a nonzero aggregate fiber. Zero-weight/irrelevant edges may be pruned. Parallel edges count as separate edges. The exponent-label law is an additional certificate restriction; it is not implied by transfer equality, full rank, or the aggregate slice formula.

If edge amplitudes are arbitrary complex numbers, their phases may absorb the entire exponent label. Thus this is a syntactic label theorem in that coefficient grammar, not a theorem about actual physical phases. For positive real amplitudes the labels coincide with the root phases. Arbitrary nonzero amplitude choices do not affect the graph-count implication once the displayed label law is imposed explicitly.

### Phase subtraction

If u has two distinct input neighbors j,j′, subtraction gives

    α_uj−α_uj′−σ_j+σ_j′ = (j−j′)t_e.

The left side is independent of the outgoing middle edge, and j−j′ is invertible. Therefore all active middle edges out of u have the same label. Dually, any v with two distinct output neighbors is single-label. Endpoint gauges cancel in the required comparisons and do not evade this conclusion.

### Counting

Call u mixed if it has at least two distinct input neighbors and call v mixed if it has at least two distinct output neighbors. All other active U/V vertices are singleton attachments. Charge each input→mixed-U edge and mixed-V→output edge to its unique middle-edge label; charge each middle edge to its own label. Keep singleton terminal attachments in a separate global ledger.

For a label t, contract the singleton attachments. Full fiber coverage connects every one of the 2p terminals through t-paths. Every active mixed vertex lies on such a path. The resulting undirected multigraph is connected, so if k_t is its number of mixed vertices, its charged edge count is at least 2p+k_t−1.

- If k_t≥2, the charge is at least 2p+1.
- If k_t=1, the charge is at least 2p.
- If k_t=0, every input/output pair needs its own contracted middle edge, so the charge is at least p²≥2p.

If every t has k_t≥2, the total charge is at least p(2p+1). Otherwise some t lacks mixed vertices on at least one side. Each of the p terminals on that side then needs a distinct singleton attachment, giving at least p additional global edges. Since every color has charge at least 2p, the same 2p²+p total follows.

The dense Gauss graph has p² input edges, p diagonal middle edges, and p² output edges, so this lower bound is attained within the grammar. It is stronger than the generic depth-three support bound only because it imposes the special every-path-label condition.

### Composite and aggregate boundaries

For composite N, subtraction gives only

    (j−j′)(t−t′)=0 mod N.

At N=9, both the input set and latent set can be {0,3,6}; at N=15 they can be {0,5,10} and {0,3,6,9,12}. These sets contain several elements and obey the condition. The prime single-label implication therefore fails. More generally the annihilator condition yields |J||T|≤N, not single-label mixing.

Aggregate fibers may achieve their phase through cancellation among paths with different exponents. The preceding proof does not cover them. An explicit gauge-robust counterexample is A=F_p, C=I+E_01, and

    B_t=ζ^(−t²/2)(C⁻¹χ_t)e_t^T,    χ_t[i]=ζ^(it).

Then C B_t A=ζ^(−t²/2)χ_tχ_t^T, so the aggregate fibers are exact. However V_1 has output neighbors 0 and 1 with equal weights and receives every label t. Pointwise characters would require 1=(a_0/a_1)ζ^(−t). Label 0 forces the ratio to be one, while label 1 contradicts primitivity. No fixed endpoint gauges repair this failure. Its edge count remains 2p²+p; it separates hypotheses and does not beat the bound.

The proof also does not cover path-dependent labels that cannot be assigned to middle edges, deeper implementations, arbitrary gauges mixed into the graph without respecting the law, or a graph used only for a Schur rectangle. No such broader conclusion is accepted.

## 4. Real-field phase palettes

Let p be odd prime, E=Q(ζ_p), K⊂R, L=K∩E, H=Gal(E/L), and h=|H|=[E:L]. Since L is real, −1∈H and h is even. The compositum KE/K is Galois and its restriction group is H; equivalently [KE:K]=h.

Any h distinct pth roots are linearly independent over L and over K. Indeed, applying the h automorphisms in H to a putative relation gives an h×h prime Fourier minor, which is nonzero by Chebotarev. For K, use the corresponding extensions fixing K or base change through the compositum. This is the substantive classical input; [Tao, Lemma 1.3](https://arxiv.org/pdf/math/0308286) provides the explicit prime-Fourier minor statement.

### Minimum palette h+1

If a palette positively spans all p roots, summing their positive representations gives a nonzero nonnegative dependence among palette roots, because Σ_rζ^r=0. A palette of at most h roots is independent, so at least h+1 phases are necessary.

For a multiplicative coset C of H, let η_C=Σ_(r∈C)ζ^r∈L. The periods are real and sum to −1, so some η_C<0. The h+1-phase palette {1}∪{ζ^r:r∈C} has the strictly positive dependence

    (−η_C)·1 + Σ_(r∈C)ζ^r = 0.

Its rank is h. Express any root in an h-element L-basis subset and add a sufficiently large L-multiple of the positive relation to make the coefficients nonnegative. Choosing the first coefficient to reach zero leaves at most h summands. Every root outside the palette needs at least h summands by independence, so it needs exactly h. All coefficients are in L⊂K.

This is an existence statement with an explicit algebraic certificate; it is not a near-linear coefficient-generation algorithm. Ordering, representation, and field-operation costs still require a computational model.

The draft's stronger positivity-descent statement is also sound. In an L-basis of E the linear constraints for a prescribed palette and target have coefficients in L. Given a feasible K-solution, retain its strictly positive support. Row-reduce over L and approximate its free real parameters by rationals closely enough that every retained coordinate stays positive. The resulting solution lies in L. In the zero-dimensional case it already lies in L. Thus enlargement of K with unchanged K∩E does not change these finite positive-cone feasibility questions.

### Coverage iff L=Q

If L=Q, the minimal polynomial over K remains Φ_p, so for nonnegative K-coefficients Σ_rc_rζ^r=ζ^k, comparison gives c_r=t+1[r=k] with t≥0. Thus the target phase must appear.

If L≠Q, h<p−1. The exact period identities are

    Σ_Cη_C=−1,    Σ_Cη_C²=p−h>1.

The second identity follows by writing r=x, s=xz with z∈H: the z=−1 term contributes p−1, and each of the other h−1 terms contributes −1. If all periods were nonpositive, their sum −1 would force their squared sum to be at most one. Hence some η_C>0, and

    1 = (1/η_C) Σ_(r∈C)ζ^r

represents the target without phase 1 using exactly h positive L-amplitude terms. This proves the sharp field boundary. Merely adjoining an unrelated irrational number does not necessarily change it; the intersection L is controlling.

For a fixed real number field K, p∤disc(K) guarantees L=Q. Indeed, p is totally ramified in Q(ζ_p), hence in every nontrivial intermediate field; ramification-index multiplicativity would then force p to ramify in K. This elementary deduction from the classical cyclotomic ramification theorem limits possible exceptions to finitely many primes. The reviewed draft cites [Milne, Algebraic Number Theory, Proposition 6.2(c)](https://www.jmilne.org/math/CourseNotes/ANTc.pdf). It does not say that every discriminant prime is an exception.

### Exact edge count in the minimum-palette class

Phase 0 occurs 2p−1 times in F_p; every nonzero phase occurs p−1 times. A palette of h+1 phases containing phase 0 is optimal among minimum-size palettes: its own phases cost one edge each, while each missing phase costs at least h. The constructed positive circuit attains this lower bound, giving

    E_min = (2p−1)+h(p−1)(p−h).

A minimum-size palette omitting phase 0 instead costs an additional p(h−1). Even at h=2, the formula is 2p²−4p+3. This result sharpens the scope warning: the smallest permissible palette still produces a quadratic direct circuit.

### F5 and the cone gate

For ζ=exp(2πi/5), set q=ζ+ζ⁴>0 and λ=1+q>0. The exact identities q²+q=1 and λ(1+ζ²)=ζ, λ(1+ζ³)=ζ⁴ give the 33-edge palette {1,ζ²,ζ³}. Its shortest containing arc has width 6π/5>π. It therefore lies outside the narrow-cone theorem; there is no conflict.

More generally any strictly positive zero relation among odd-order roots precludes containment in a closed semicircle. If there were a containing closed half-plane through the origin, a supporting real functional would force every root onto its boundary; that would require antipodal roots, unavailable at odd order. Clearing this obstruction is not a sparse-construction certificate.

## 5. Weyl and failure certificates

For S e_j=e_(j+1 mod N) and D=diag(ω^i), the identities M e_0=1 and MS=DM imply M e_j=D^j1 and therefore M=F_N. For a row-scaled Fourier matrix diag(a)F_N, covariance holds while the base column fails unless a=1. A perturbation only of column 1 preserves the base column while generally breaking covariance. Both conditions must be established for the actual corrected candidate.

Two symbolic matrix identities need not be cheap to verify merely because there are two displayed equations. Their representation and proof must exploit the graph structure; otherwise covariance still contains N² scalar equalities. A short theorem can have a large computational certificate.

The following are rejected implication patterns:

- Correct per-path exponents ⇒ correct aggregate amplitude. Doubling only the t=0 contribution changes the result without changing any labels.
- Complete weighted fibers with arbitrary λ_ij ⇒ diagonal correction. A multiplier matrix equal to one except λ_00=2 has a nonzero 2×2 determinant.
- Full-rank/support-compatible ⇒ Fourier. The Weyl identities remain unproved.
- Two finite-field passes ⇒ a complex identity. Adding an integer multiple of both field characteristics gives a concrete false positive under both reductions.
- Positive irrational amplitudes ⇒ sub-N-log-N work. The exact minimum-palette direct construction is quadratic.
- Every Fourier graph ⇒ complete Gauss fibers. The p² direct-edge Fourier graph has one path per terminal pair, so it cannot partition those paths into p nonzero fibers.

## 6. Proof-certificate checklist and stopping rule

Accept an exact sparse construction only when all applicable items are supplied:

1. **Domain:** supported lengths, characteristic, primitive-root convention, scalar field, coefficient representation, permitted preprocessing, and exact output normalization.
2. **Execution graph:** uniform vertices/edges/terminal generator; acyclicity and true edge-depth; all fan-in, fan-out, parallel edges, external gauges, routing, and fixed constants included.
3. **Actual fibers:** exhaustive partition of the real path multiset, or masks B_t with proof H_t=C B_t A. No missing or repeated paths; no uncharged route oracle.
4. **Amplitude:** an exact aggregate identity or slice recurrence, with nonzero separable endpoint multiplier and explicit normalization. A phase-only statement is insufficient.
5. **Weyl:** the base column and full cyclic covariance for the final corrected matrix, with index directions and endpoint permutations explicitly reconciled.
6. **Support:** valid necessary minors/flows in the actual field; distinguish total nonsingularity from invertibility, and distinguish support feasibility from weight synthesis.
7. **Schur, if used:** identify the actual zero rectangle, legal inverses, the complete correction, all remaining outputs, branch solves, injection/extraction, and any shared calculations.
8. **Phase grammar:** declare positivity, amplitude field, actual root palette, every-path versus aggregate laws, common effective cone after gauges, and whether middle-edge labels exist.
9. **Cost:** graph and weight generation, arithmetic evaluation, normalization, all outputs, memory liveness, root preparation, finite-word/bit costs if claimed, and no precomputed dense target table charged as free.
10. **Tests:** independently authored exact controls; amplitude perturbations, nonseparable endpoint multipliers, Weyl-half failures, composite annihilator cases, and source identity. Finite tests supplement rather than replace all-length proof.

Stop with “conditional construction target” when a graph or its exact aggregate identity is absent. Stop with “restricted impossibility” only when the candidate is shown to satisfy the exact hypotheses of the corresponding obstruction. Passing an obstruction is not success.

## 7. Fresh control record

The accompanying `fresh_review_controls.py` was written independently for this review and imports only the Python standard library. It does not execute, import, or reuse source-package code. It checks cyclotomic identities by rational arithmetic in Q[x]/Φ_p and certifies all real signs by rational Machin/Taylor intervals, refusing unresolved signs. Exact finite-field and finite-support controls are separately labeled. The complete output is `FRESH_REVIEW_RESULTS.json`.

Counts and draft-specific cross-review status are finalized in `REVIEW_RECEIPT.json` after the runs and sibling-draft checks finish.

## 8. Shared-basis aggregate continuation

The following algebraic reduction has been independently checked. When A=F_p and C is an arbitrary invertible p×p output basis, the exact aggregate fiber identity uniquely forces

    B_t=ζ^(−t²/2)(C⁻¹χ_t)e_t^T.

Its literal edge ledger is

    E=p²+nnz(C)+nnz(C⁻¹F_p).

For each nonzero row x of C⁻¹, the prime-complex Fourier uncertainty inequality gives nnz(x)+nnz(xF_p)≥p+1. Summing rows yields

    E≥2p²+p+nnz(C)−nnz(C⁻¹).

Thus no C whose inverse is no denser than C improves the dense Gauss edge count in this one-sided family. If C=I+uv^T is invertible and every diagonal entry of C is nonzero, Sherman–Morrison preserves every off-diagonal zero/nonzero position in its inverse; inverse diagonal entries may become zero. Therefore nnz(C⁻¹)≤nnz(C), and this rank-one-update family is excluded. The nonvanishing-diagonal qualifier matters and is retained.

For arbitrary invertible p×p A,C, set R=C⁻¹F_p and S=F_pA⁻¹. The aggregate identity forces B_t=ζ^(−t²/2)r_t s_t^T, where r_t is column t of R and s_t^T is row t of S. The literal edge count becomes

    E=nnz(A)+nnz(C)+Σ_t nnz(r_t)nnz(s_t).

Distinct t may contribute parallel middle edges in the same matrix position; each is counted separately. No disjoint matrix-position assumption is required. This is an exact objective reduction, not a proof that its minimum is 2p²+p. Both-sided bases, wider hidden layers, and noninvertible rectangular representations remain open here. Prime-complex uncertainty cannot automatically be imported into arbitrary finite-field specializations.
