"""Fresh independent controls for finite-alphabet radix-2 subproblem sharing.

Standard library only. Does not import, execute, or compile repository programs.
Run from any directory: python /absolute/path/fresh_controls.py
"""

import cmath
import hashlib
import itertools
import json
import math
import platform
import random
import statistics
import time
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent


def levels(n):
    return [1 << j for j in range(n.bit_length())]


def distinct_strided(x):
    n = len(x)
    return {m: len({tuple(x[r + (n // m) * j] for j in range(m))
                    for r in range(n // m)}) for m in levels(n)}


def ids_counts(x):
    # IDs at length m are indexed by the residue r modulo N/m.
    n = len(x)
    initial = {v: i for i, v in enumerate(sorted(set(x)))}
    old = [initial[v] for v in x]
    out = {1: len(initial)}
    calls = 0
    for m in levels(n)[1:]:
        count = n // m
        intern = {}
        new = []
        for r in range(count):
            pair = (old[r], old[r + count])
            if pair not in intern:
                intern[pair] = len(intern)
            new.append(intern[pair])
            calls += 1
        out[m] = len(intern)
        old = new
    assert calls == n - 1
    return out


def butterflies(counts):
    return sum((m // 2) * u for m, u in counts.items() if m > 1)


def exact_eu(n, m, q):
    k = q ** m
    return k * (1 - Fraction(k - 1, k) ** (n // m))


def approx_eu(n, m, q, copies=1):
    samples = copies * n // m
    logk = m * math.log2(q)
    # Here omitted collisions are below 2^-80 relative to the sample count.
    if logk > math.log2(samples) + 80:
        return float(samples)
    p = 2.0 ** (-logk)
    return -math.expm1(samples * math.log1p(-p)) / p


def threshold(n, q):
    if n < q:
        return None
    t = 1
    while (2 * t) * q ** (2 * t) <= n:
        t *= 2
    return t


def merge(even, odd):
    m = 2 * len(even)
    half = m // 2
    out = [0j] * m
    for k in range(half):
        z = cmath.exp(-2j * math.pi * k / m) * odd[k]
        out[k] = even[k] + z
        out[k + half] = even[k] - z
    return out


def direct_dft(x):
    n = len(x)
    return [sum(v * cmath.exp(-2j * math.pi * j * k / n)
                for j, v in enumerate(x)) for k in range(n)]


def dag_fft(x):
    n = len(x)
    labels = {v: i for i, v in enumerate(sorted(set(x)))}
    old_id = [labels[v] for v in x]
    old_values = [[complex(v)] for v in sorted(set(x))]
    count_by_size = {1: len(labels)}
    peak_scalar_slots = len(old_values)
    for m in levels(n)[1:]:
        count = n // m
        table = {}
        new_id = []
        new_values = []
        for r in range(count):
            key = (old_id[r], old_id[r + count])
            if key not in table:
                table[key] = len(new_values)
                new_values.append(merge(old_values[key[0]], old_values[key[1]]))
            new_id.append(table[key])
        slots = (m // 2) * len(old_values) + m * len(new_values)
        peak_scalar_slots = max(peak_scalar_slots, slots)
        assert slots <= 2 * n
        count_by_size[m] = len(table)
        old_id, old_values = new_id, new_values
    return old_values[old_id[0]], count_by_size, peak_scalar_slots


def make_all_tables(q, cutoff):
    old = {(v,): [complex(v)] for v in range(q)}
    prep_b = 0
    allocated_payload = len(old)
    peak_payload = len(old)
    for m in levels(cutoff)[1:]:
        new = {}
        for word in itertools.product(range(q), repeat=m):
            new[word] = merge(old[word[::2]], old[word[1::2]])
            prep_b += m // 2
        current_payload = m * len(new)
        peak_payload = max(peak_payload, allocated_payload + current_payload)
        old = new
        allocated_payload = current_payload
    assert prep_b == sum((m // 2) * q ** m for m in levels(cutoff)[1:])
    return old, prep_b, peak_payload


def table_fft(x, cutoff, table):
    n = len(x)
    groups = n // cutoff
    old = [list(table[tuple(x[r + groups * j] for j in range(cutoff))])
           for r in range(groups)]
    m = cutoff
    online_b = 0
    while m < n:
        m *= 2
        count = n // m
        new = [merge(old[r], old[r + count]) for r in range(count)]
        online_b += (m // 2) * count
        old = new
    assert online_b == (n // 2) * ((n // cutoff).bit_length() - 1)
    return old[0], online_b


def main():
    started = time.perf_counter()
    report = {
        "scope": "Fresh finite controls only; no predecessor program executed or imported.",
        "python": platform.python_version(),
        "control_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "exhaustive": [],
    }
    total_sequences = 0
    for q, sizes in ((2, (1, 2, 4, 8, 16)), (4, (1, 2, 4, 8))):
        for n in sizes:
            sums = {m: 0 for m in levels(n)}
            for x in itertools.product(range(q), repeat=n):
                a = ids_counts(x)
                b = distinct_strided(x)
                assert a == b
                for m in sums:
                    sums[m] += a[m]
            checked = q ** n
            total_sequences += checked
            for m, total in sums.items():
                assert Fraction(total, checked) == exact_eu(n, m, q)
            report["exhaustive"].append({"q": q, "N": n, "sequences": checked,
                "E_unique_by_size": {str(m): str(Fraction(v, checked)) for m, v in sums.items()},
                "E_butterflies": str(sum(Fraction((m // 2) * v, checked)
                                          for m, v in sums.items() if m > 1))})
    report["exhaustive_sequences"] = total_sequences

    bound_cases = 0
    max_normalized_difference = -math.inf
    min_normalized_difference = math.inf
    max_cold_gap = 0.0
    for q in (2, 3, 4, 16, 256):
        for logn in range(1, 257):
            n = 1 << logn
            t = threshold(n, q)
            if t is None:
                continue
            eb = sum((m / 2) * approx_eu(n, m, q) for m in levels(n)[1:])
            upper_baseline = (n / 2) * (logn - (t.bit_length() - 1))
            delta = (eb - upper_baseline) / n
            assert -2 / 7 - 1e-12 <= delta <= 4 / 7 + 1e-12, (q, logn, delta)
            ct = sum((m // 2) * q ** m for m in levels(t)[1:])
            cold_gap = (ct + upper_baseline - eb) / n
            assert -1e-12 <= cold_gap <= 6 / 7 + 1e-12
            min_normalized_difference = min(min_normalized_difference, delta)
            max_normalized_difference = max(max_normalized_difference, delta)
            max_cold_gap = max(max_cold_gap, cold_gap)
            bound_cases += 1
    report["dyadic_bound_sweep"] = {"cases": bound_cases,
        "min_normalized_remainder": min_normalized_difference,
        "max_normalized_remainder": max_normalized_difference,
        "max_cold_tabulation_minus_expected_dag_div_N": max_cold_gap,
        "note": "Floating evaluation of exact formula; negligible collision tails bounded before truncation."}

    report["random_occupancy"] = []
    rng = random.Random(1453)
    for q, n, trials in ((2, 4096, 64), (4, 4096, 64), (16, 4096, 64), (2, 16384, 32)):
        values = []
        for _ in range(trials):
            x = [rng.randrange(q) for _ in range(n)]
            values.append(butterflies(ids_counts(x)))
        expected = sum((m / 2) * approx_eu(n, m, q) for m in levels(n)[1:])
        report["random_occupancy"].append({"q": q, "N": n, "trials": trials,
            "sample_mean": statistics.mean(values), "exact_formula_float": expected,
            "sample_stdev": statistics.stdev(values), "baseline": n * (n.bit_length() - 1) // 2,
            "raw_butterflies": values})

    report["numerical_execution"] = []
    for q, cutoff in ((2, 1), (2, 2), (2, 4), (2, 8), (4, 2), (4, 4)):
        tab, cb, peak_table = make_all_tables(q, cutoff)
        worst = 0.0
        cases = 0
        for n in (8, 16, 32, 64):
            if cutoff > n:
                continue
            for _ in range(5):
                x = [rng.randrange(q) for _ in range(n)]
                yd, counts, peak = dag_fft(x)
                yt, ob = table_fft(x, cutoff, tab)
                ref = direct_dft(x)
                err = max(max(abs(a - b) for a, b in zip(yd, ref)),
                          max(abs(a - b) for a, b in zip(yt, ref)))
                worst = max(worst, err)
                assert err < 1e-8
                assert counts == distinct_strided(x)
                assert butterflies(counts) <= cb + ob
                cases += 1
        report["numerical_execution"].append({"q": q, "cutoff": cutoff,
            "cases": cases, "cold_table_butterflies": cb,
            "peak_adjacent_table_complex_slots": peak_table,
            "max_absolute_error_vs_direct_DFT": worst})

    report["two_input_controls"] = []
    for n in (8, 32, 256, 4096):
        x = [rng.randrange(2) for _ in range(n)]
        y = [rng.randrange(2) for _ in range(n)]
        cx, cy = distinct_strided(x), distinct_strided(y)
        paired = distinct_strided(list(zip(x, y)))
        union = {}
        for m in levels(n):
            stride = n // m
            sets = [{tuple(z[r + stride * j] for j in range(m))
                     for r in range(stride)} for z in (x, y)]
            union[m] = len(sets[0] | sets[1])
        bu, bs, bj = butterflies(union), butterflies(cx) + butterflies(cy), 2 * butterflies(paired)
        assert bu <= bs <= bj
        packed_counts = ids_counts([a + 2 * b for a, b in zip(x, y)])
        assert packed_counts == paired
        report["two_input_controls"].append({"N": n, "shared_scalar_cache_B": bu,
            "separate_caches_B": bs, "paired_two_transform_B": bj,
            "packed_one_complex_transform_B": butterflies(paired)})

    # Packed real-pair recovery, including self-conjugate DC/Nyquist bins.
    unpack_max = 0.0
    for n in (2, 4, 8, 16, 32, 64):
        x = [rng.randrange(2) for _ in range(n)]
        y = [rng.randrange(2) for _ in range(n)]
        z = direct_dft([a + 1j * b for a, b in zip(x, y)])
        fx, fy = direct_dft(x), direct_dft(y)
        ux = [(z[k] + z[-k % n].conjugate()) / 2 for k in range(n)]
        uy = [(z[k] - z[-k % n].conjugate()) / (2j) for k in range(n)]
        err = max(max(abs(a - b) for a, b in zip(ux, fx)),
                  max(abs(a - b) for a, b in zip(uy, fy)))
        assert err < 1e-8
        unpack_max = max(unpack_max, err)
    report["packed_recovery_max_absolute_error"] = unpack_max

    report["expected_binary_examples"] = []
    for logn in (8, 12, 16, 20, 24, 32, 64, 128, 256):
        n = 1 << logn
        eb = sum((m / 2) * approx_eu(n, m, 2) for m in levels(n)[1:])
        baseline = n * logn / 2
        report["expected_binary_examples"].append({"log2_N": logn, "threshold": threshold(n, 2),
            "E_B_div_N": eb / n, "saved_fraction": 1 - eb / baseline,
            "main_term_div_N": (logn - math.log2(logn)) / 2})
    report["elapsed_seconds"] = time.perf_counter() - started
    report["status"] = "PASS"
    (HERE / "FRESH_RESULTS.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "exhaustive_sequences": total_sequences,
                      "bound_cases": bound_cases, "elapsed_seconds": report["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
