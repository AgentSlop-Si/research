# Random finite-alphabet FFT sharing: exact counts, charged costs, and limits

10 October 2026. A scoped mathematical analysis and fresh independent controls.

## Result

For a length-`N=2^L` vector of independent uniform binary symbols, merge identical **whole ordered subproblems at the same length** in the usual radix-2 decimation-in-time FFT. If a butterfly means one operation taking `(a,b)` to `(a+wb,a−wb)`, then

\[
\mathbb E U_m=2^m[1-(1-2^{-m})^{N/m}],\qquad
\mathbb E B_N=\frac12\sum_{m=2,4,\ldots,N}m\mathbb E U_m
=\frac N2(\log_2N-\log_2\log_2N)+O(N).
\]

Thus the saving against the specified ordinary radix-2 circuit is
`(N/2) log2 log2 N + O(N)` butterflies, and the remaining expected work is **Theta(N log N)**. The saved fraction tends to zero. This does not establish a better asymptotic FFT complexity class.

The structural DAG has only `Theta(N/log N)` nodes on average, but node count is not evaluation cost: a length-`m` node materializes `m` coefficients. A program retaining every node's spectrum uses expected `Theta(N log N)` scalar slots. A level-by-level program releases old spectra and has deterministic `O(N)` peak scalar storage.

Structural planning can be done in expected `O(N)` time with exact child-ID-pair hash keys, or deterministic `O(N)` word-RAM time by dense-ID counting sorts. Reading and hashing every raw length-`m` vector at every level instead costs `Theta(N log N)` symbol visits.

A universal finite-alphabet leaf table achieves the same displayed leading butterfly count **for every input** with `O(N)` charged cold setup and `O(N)` space. On iid uniform inputs its cold butterfly count exceeds the ideal DAG's expectation by at most `6N/7`. Neither this table construction nor the sharing primitive is claimed historically novel.

## 1. Exact model and strided positions

Let the input alphabet consist of `q>=2` distinct fixed values. Initially assume each input symbol is uniform on that alphabet and independent of every other symbol. At a dyadic length `m`, put `n=N/m`. The recursive subproblem with residue `r` is

\[
X_{m,r}=(x_r,x_{r+n},\ldots,x_{r+(m-1)n}),\quad 0\le r<n.
\]

The `n` index sets partition the input. Consequently these whole ordered words are independent and uniformly distributed among `K=q^m` possibilities. They are not overlapping substrings. Dependencies between different FFT levels do not affect any expectation below, because only linearity of expectation is used across levels.

The even and odd children of `X_{m,r}` are exactly `X_{m/2,r}` and `X_{m/2,r+n}`. Therefore child-ID pairs are position-independent exact signatures. The merge coefficients depend on `m` and output index `k`, not on `r`:

\[
Y_{m,r}[k]=E[k]+\omega_m^k O[k],\qquad
Y_{m,r}[k+m/2]=E[k]-\omega_m^k O[k].
\]

Equality of two whole input words permits reuse of their full transforms. The full mathematical DFT is invertible, so exact equality of complete spectra cannot produce additional whole-vector equivalences beyond equal inputs. Individual scalar outputs can collide, and symmetry/zero/constant-input reductions can save additional operations, but those are different algorithms and are not counted here. Hash-function collisions must be resolved by exact pair comparison; they are not the useful equal-subproblem collisions.

`U_m` denotes the number of distinct words at length `m`, including `U_1` for leaves. Each distinct non-leaf is evaluated exactly once using `m/2` butterflies. The algorithm counts trivial twiddle factors and all-zero merges in the same way as its radix-2 comparator. No bit-complexity or exact-transcendental-storage conclusion follows merely from a butterfly count.

## 2. Exact occupancies and butterfly expectation

For each word `w` among the `K=q^m` possibilities, let `I_w` indicate that at least one of the `n` subproblems equals it. Then

\[
U_m=\sum_w I_w,\quad
\Pr(I_w=1)=1-(1-1/K)^n,
\]

and hence

\[
\boxed{\mathbb E U_m=q^m[1-(1-q^{-m})^{N/m}].}\tag{1}
\]

This holds at `m=1`, `m=N`, and all intervening dyadic levels. In particular `U_N=1`. The total expected number of non-leaf butterflies is exactly

\[
\boxed{\mathbb E B_N=\frac12\sum_{m=2,4,\ldots,N}
m q^m[1-(1-q^{-m})^{N/m}].}\tag{2}
\]

For any `n` iid draws from `K` equally probable types,

\[
0\le n-\mathbb E U\le\binom n2/K.\tag{3}
\]

Indeed, if a type occurs `c` times, its duplicate excess is `c-1`, bounded by `binom(c,2)` when `c>=1`. Sum over types and take expectations. Also `U<=min(n,K)` pointwise.

## 3. Explicit dyadic-threshold bounds

For `N>=q`, define `t` to be the largest dyadic integer satisfying

\[
tq^t\le N.\tag{4}
\]

There are `L−log2 t` levels strictly above `t`. Call their ordinary butterfly count

\[
H=\frac N2(L-\log_2t).
\]

The small-level contribution satisfies

\[
0\le \frac12\sum_{2\le m\le t}m\mathbb E U_m
\le C_t:=\frac12\sum_{2\le m\le t}mq^m\le\frac{4N}{7}.\tag{5}
\]

The sums are over dyadic `m`. To obtain the last bound, consecutive terms `a_m=mq^m`, starting at `m=2`, satisfy `a_{2m}/a_m=2q^m>=8`. Thus the sum is at most `(8/7)tq^t`; the factor `1/2` gives `(4/7)N`. If `t=1`, the sum is empty and the inequality holds.

For upper levels, use (3):

\[
0\le H-\frac12\sum_{m>t}m\mathbb E U_m
\le\frac N4\sum_{m>t}\frac{N}{mq^m}
\le\frac{2N}{7}.\tag{6}
\]

Maximality of `t` makes the first summand `N/(2t q^{2t})<1`. Every subsequent summand is at most one eighth its predecessor, because all these `m` are at least 2. This proves the explicit bounds

\[
\boxed{
\frac N2(L-\log_2t)-\frac{2N}{7}
\le\mathbb E B_N\le
\frac N2(L-\log_2t)+\frac{4N}{7}.}\tag{7}
\]

The finitely many cases `N<q` can be evaluated directly using (2). They do not enter the fixed-alphabet asymptotic statement.

Set `s=log_q N`. For `s>=4`,

\[
s/4\le t\le s.\tag{8}
\]

The upper inequality follows from (4). If `t<s/4`, then `2t<s/2`, and `log_q(2t)<=log2(s/2)<=s/2`. Therefore `(2t)q^{2t}<N`, contradicting maximality. This proves `log2 t=log2 log_q N+O(1)`, with dyadic rounding explicitly included. Substitution gives

\[
\boxed{\mathbb E B_N
=\frac N2(\log_2N-\log_2\log_qN)+O(N).}\tag{9}
\]

For fixed `q`, changing `log_q N` to `log2 N` changes only the `O(N)` term. The binary formula in the result follows. The continuous solution of `aq^a=N` is near `log_qN−log_q log_qN`, but replacing the dyadic cutoff by that real solution without an `O(N)` allowance would be unjustified: a one-level change costs `N/2` butterflies.

These are bounds for this whole-subproblem-sharing algorithm, not lower bounds on every possible FFT algorithm for binary inputs.

## 4. Structural size, payload, and complete bookkeeping

Let `D=sum_m U_m` include leaves. The upper levels satisfy `sum_{m>t}U_m<=sum_{m>t}N/m<N/t`; the lower levels satisfy `sum_{m<=t}U_m<=sum_{m<=t}q^m<=2q^t<=2N/t`. At `m=2t`, maximality gives `K>n`, so (3) gives `E U_{2t}>=n/2=N/(4t)`. This level exists because `tq^t<=N` implies `2t<=N`. Thus

\[
N/(4t)\le\mathbb E D\le3N/t,
\qquad \mathbb E D=\Theta(N/\log N)\quad(q\text{ fixed}).\tag{10}
\]

This does not permit skipping inspection of the `N` supplied symbols.

### Exact signatures

Read the input once and give its fixed alphabet symbols exact IDs. At each size `m`, use the ordered pair of the two previous-level child IDs as the key. There are exactly

\[
\sum_{m=2,4,\ldots,N}N/m=N-1
\]

parent occurrences to classify, regardless of the amount of sharing. A standard exact dictionary with constant expected time per constant-word key therefore costs expected `O(N)` total word operations, separately from spectrum arithmetic.

There is also a deterministic version. Use dense IDs `0,...,U_{m/2}−1` at the previous level. For `n=N/m` parent pairs, `U_{m/2}<=2n`. Two stable counting-sort passes sort pairs lexicographically in `O(n+U_{m/2})=O(n)` time and space, including histogram initialization. Group equal adjacent pairs, assign dense parent IDs, and scatter IDs to the original `r` order. Sum over levels to obtain deterministic `O(N)` structural planning on a word RAM with `Omega(log N)`-bit words. This algorithm is an instance of standard bottom-up tree compaction; it is not a new hashing primitive.

This planner can also produce the exact ledger `B_N=sum_m (m/2)U_m` before any numeric FFT execution. It therefore supports an `O(N)`-overhead choice among explicitly costed schedules, including a warm existing leaf table. A cold universal table cannot improve the DAG's *butterfly count* under the present convention, as Section 5 proves; its practical advantage could come from smaller control overhead or more regular memory access. A real dispatcher needs measured, comparable cost weights rather than treating the butterfly ledger as a wall-clock oracle.

By contrast, materializing each input subvector as its own `m`-symbol key and rescanning it for every occurrence reads `N` symbols per level, hence `Theta(N log N)` symbol visits. Packing each full word into an arbitrary-size integer does not make its construction, copying, or multiword hash free. Random fingerprints without exact collision resolution are not an exact substitute for the ID-pair method.

### Arithmetic, movement, and roots

For each unique parent, read its two child spectra and write its `m` outputs. These movements take `Theta(m)` scalar accesses per node, hence `Theta(B_N)` total. Trivial twiddles can be optimized in an implementation, but must be optimized comparably in the baseline before measuring a speedup. Input reading, occurrence-ID construction, initial allocation, and final output have an additional `O(N)` cost. Thus an actual implementation in the stated arithmetic/word model has `O(N+B_N)` work and, for the explicit merge schedule, `Omega(N+B_N)` work.

The mathematical arithmetic model must specify its coefficient access. If a primitive `N`th root is supplied, all needed roots/powers can be generated in `O(N)` charged field operations and `O(N)` scalar storage, shared by both algorithms. Exact irrational roots are not finite ordinary machine words. With floating coefficients, fixed-precision root generation and its errors belong to the numerical implementation; with precision growing, its bit cost must be charged separately. The occupancy and butterfly identities are independent of that root-generation contract. They do not silently prove exact finite-word computation over arbitrary complex inputs.

### Storage

If every unique spectrum remains cached, its exact scalar payload is

\[
S=\sum_{m=1,2,\ldots,N}mU_m=U_1+2B_N.\tag{11}
\]

Therefore expected retained payload is `N(log2N−log2 log_qN)+O(N)`, which is `Theta(N log N)` scalar slots. The structural graph alone is smaller: `O(D)` records, with expected `Theta(N/log N)` records. Scalar slots and word records should not be conflated, especially in a bit-complexity model.

A breadth-first evaluation needs only two adjacent levels. At any length `m`, `mU_m<=N` pointwise. Keep previous-level spectra, current-level spectra, their occurrence-ID arrays, and the current intern/sort workspace. Release older spectra and IDs at the level barrier. At most `2N` numerical spectrum slots are simultaneously live, plus `O(N)` input, root, ID, and scratch words. This is **deterministic `O(N)` peak storage for every input**, while preserving the same `B_N` count.

## 5. A memory-budgeted cold leaf-table construction

For any dyadic cutoff `b<=N`, prepare the transforms of **all** `q^b` length-`b` words. Do not compute each transform independently with a separate `b log b` FFT. Instead prepare all dyadic sizes up to `b` bottom-up.

At size `m`, enumerate the `q^m` words, obtain each even/odd child index in the already constructed size-`m/2` table, and do `m/2` butterflies. Scanning all `m` base-`q` digits to form the two child addresses is allowed and charged. It costs `O(m)` per row, no more than the row's output work. The total charged preparation is

\[
C_b=\frac12\sum_{m=2,4,\ldots,b}mq^m
\quad\text{butterflies},\qquad O(bq^b)\text{ total arithmetic/word work}.
\]

Two adjacent table levels use `O(bq^b)` scalar slots. Every row has `b` outputs: a count of `q^b` table entries alone hides a factor `b`. Keys fit `O(log N)` bits when `bq^b<=N`, and the digit-scan construction avoids a free arbitrary bit-deinterleave assumption.

Online, gather each actual strided block `X_{b,r}`, form its exact alphabet code in `O(b)` word work, and copy the selected row into the level-`b` workspace. There are `N/b` blocks, so input gathering, key formation, and **copying all N coefficients** cost `O(N)`. Then perform the normal upper FFT levels. There is no unit-cost output-vector oracle. The upper butterfly count is exactly

\[
B_{\mathrm{upper}}=\frac N2\log_2(N/b).\tag{12}
\]

The residue layout from Section 1 lets successive levels read child indices `r` and `r+N/m` directly, so no uncharged global permutation is required. One may instead use an explicitly charged ordinary FFT permutation.

Choose `b=t` from (4). Cold preparation and table storage are `O(N)`, and online input/output materialization is `O(N)`. The complete cold arithmetic count is

\[
C_t+\frac N2\log_2(N/t)
=\frac N2(\log_2N-\log_2\log_qN)+O(N).\tag{13}
\]

This holds for **every** finite-alphabet input, with `O(N)` peak storage. For a specific input `x`,

\[
B_{\mathrm{DAG}}(x)\le C_b+B_{\mathrm{upper}}
\]

because each lower DAG level has at most `q^m` unique words and each upper level at most `N/m`. At `b=t`, (5) and (6) imply the useful uniform-iid expectation comparison

\[
0\le C_t+B_{\mathrm{upper}}-\mathbb E B_{\mathrm{DAG}}\le6N/7.\tag{14}
\]

This additive comparison does **not** extend to structured inputs: an all-equal input has `U_m=1` and `B_N=N−1`, while universal tabulation still performs all upper stages.

For a hard table-storage budget `M` scalar slots, use the largest dyadic `b` satisfying a chosen implementation's full constant-factor allowance `c bq^b<=M` (or no table if it cannot fit). The explicit tradeoff is setup `O(bq^b)`, storage `O(N+bq^b)`, and online work `O(N)+(N/2)log2(N/b)` butterflies. For `M=N^alpha` with fixed `0<alpha<=1`, `b=Theta(log N)`, so the same leading saved-stage count follows. A hardware-fixed `M` only allows a fixed `b`, saving `O(N)` butterflies; a fixed practical cutoff does not realize a growing `N log log N` saving. Cold setup must not be omitted or amortized unless the workload actually reuses it.

A stricter explicit comparator may retain every lower table and set `T_b=q+sum_{2<=m<=b}mq^m`. Choose the largest dyadic `b` with `T_b<=N`; this is an exact `N`-cell numeric payload budget, separate from roots and working buffers. For sufficiently large fixed-`q` instances, `b` is either `t` or `t/2`: the latter satisfies `T_{t/2}<=2(t/2)q^{t/2}<=tq^t<=N`. Its charged cold count is `C_b=(T_b−q)/2<=N/2`; at most one additional upper stage gives `0<=C_b+B_upper−E B_DAG<=9N/7`. Thus the precise numeric-cell budget has the same asymptotic conclusion as the simpler constant-factor `O(N)` construction.

## 6. Nonuniform fixed alphabets

For iid symbols with fixed probabilities `p_1,...,p_q`, replace (1) by

\[
\mathbb E U_m=\sum_{w\in[q]^m}[1-(1-P(w))^{N/m}],\quad
P(w)=\prod_jp_{w_j}.\tag{15}
\]

The deterministic upper bound `U_m<=q^m` is unchanged. If at least two symbols have positive probability, `rho=sum_i p_i^2<1`, and two independent words coincide with probability `rho^m`. Hence

\[
N/m-\mathbb E U_m\le\binom{N/m}{2}\rho^m.
\]

Take an upper cutoff equal to the first dyadic `u>=log_{1/rho}N`. For `m>=u`, the sum of the weighted collision bounds is `O(N)`, while the number of these upper levels is `log2N−log2 log N+O_p(1)`. Combining this lower bound with the universal upper bound proves the same leading expression

`E B_N=(N/2)(log2N−log2 log2N)+O_p(N)`.

The constants depend on the fixed distribution. This argument does not cover a distribution whose mass becomes concentrated at one symbol as `N` grows. For the degenerate one-symbol distribution, `B_N=N−1` exactly under this counting convention.

## 7. Two independent inputs: three distinct meanings of sharing

Let `x` and `y` be independent uniform `q`-symbol inputs of length `N`.

### A. One scalar-subproblem cache shared by both FFTs

At length `m` there are `2N/m` independent words from an alphabet of `q^m` types. Thus

\[
\mathbb E U^{\mathrm{union}}_m=q^m[1-(1-q^{-m})^{2N/m}],
\quad B_{\mathrm{union}}=\tfrac12\sum_m mU^{\mathrm{union}}_m.
\]

Its expected butterfly count is

`N(log2N−log2 log_qN)+O(N)`.

The gain from sharing between the two caches, beyond using one cache separately for each input, is exactly

\[
\frac12\sum_m m q^m[1-(1-q^{-m})^{N/m}]^2=O(N).
\]

Split the sum at (4): below it bound the square by 1; above it use `1−(1−1/K)^n<=n/K`. The same geometric sums prove the stated bound. There is no uniform `Theta(N)` lower bound asserted here; dyadic gaps can make the gain smaller.

### B. A DAG keyed by the ordered pair of input subproblems

Now each coordinate is one of `q^2` pairs. If `V_m` is the number of distinct paired words,

\[
\mathbb E V_m=q^{2m}[1-(1-q^{-2m})^{N/m}].
\]

If each paired node separately evaluates both transforms, it costs `m` scalar-complex butterflies, so `J=sum_m mV_m`. This is twice the scalar formula with alphabet size `q^2`. It still has expectation `N(log2N−log2 log_qN)+O(N)`. Pointwise,

`B_union <= B_separate_x + B_separate_y <= J`.

Matching both input words is a stricter requirement than matching either individually. Counting a paired node as one scalar transform would hide a factor two.

### C. One genuinely packed complex FFT

For real numeric alphabets, set `z=x+i y`. The packed input has `q^2` distinct complex symbols, so its one-FFT count is `B_pack=(1/2)sum_m mV_m`. Recover the two transforms by

\[
X_k=(Z_k+\overline{Z_{(-k)\bmod N}})/2,\qquad
Y_k=(Z_k-\overline{Z_{(-k)\bmod N}})/(2i).
\]

Packing and explicit recovery each cost `O(N)`. For two binary inputs the occupancy alphabet is **four**, not two. Here

`E B_pack=(N/2)(log2N−log2 log2N)+O(N)`.

The leading factor-two saving against *two ordinary complex FFTs* is the conventional real-pair packing opportunity; it is not evidence that paired DAG caching invented that gain. Optimized real-input FFTs and Hermitian half-spectrum storage are also necessary practical comparators. This real-pair packing is unrelated to the research repository's growing-word, quantized approximate packed-butterfly theorem; their representation and accuracy models must not be combined silently.

## 8. Prior art and provenance boundaries

- **Cooley and Tukey (1965)** supplies the ordinary factorized FFT background: [original paper](https://web.stanford.edu/class/cme324/classics/cooley-tukey.pdf). The present count is a specialization of its radix-2 recursive schedule, not a new transform factorization.
- **Flajolet, Sipala, and Steyaert (1990), Proposition 1**, explicitly discusses exact tree compaction by child identifiers, expected-linear hashing, and deterministic-linear bottom-up sorting: [author-hosted paper, pp. 3–4](https://algo.inria.fr/flajolet/Publications/FlSiSt90.pdf). Its random-tree asymptotics concern different tree distributions; their bounds must not be substituted for this fixed complete tree with random leaf labels.
- **Filliatre and Conchon (2006)** treats structurally equal values and maximal sharing as hash-consing: [authors' workshop abstract](https://gallium.inria.fr/ml2006/accepted/5.html). This supports the methodological connection, not the novelty of a specific FFT occupancy formula.
- **Frigo (1999), Section 5**, describes DFT expression-DAG simplification, common-subexpression elimination and memoized graph traversal: [A Fast Fourier Transform Compiler](https://www.fftw.org/pldi99.pdf). Its compile-time symbolic codelet sharing must be distinguished from caching realized random input words. This is especially direct prior art for describing FFT DAG machinery as established.
- **Arlazarov, Dinitz, Kronrod, and Faradzhev (1970)** is a classical tabulation-method antecedent: [original publication record and paper access](https://www.mathnet.ru/php/archive.phtml?jrnid=dan&option_lang=eng&paperid=35675&wshow=paper). The cold finite-alphabet tables here use the same broad strategy of enumerating small discrete configurations. This is not a claim that this source already proves the precise FFT theorem above.
- The official **FFTW** documentation explains Hermitian redundancy and the benefit of a real-input transform: [real-data transform documentation](https://www.fftw.org/fftw3_doc/One_002dDimensional-DFTs-of-Real-Data.html). Fair timing comparisons should account for it.

The local prior artifact `fft_selective/original/fft_collision_research.py` already contains the binary occupancy expression and whole-DAG prototype. Its root program was read as inert text only, never imported or run. The earlier `fft_selective/README.md` and `c_experiment/ADAPTIVE_README.md` already report substantially more practical native lookup/codelet comparisons than the fresh finite controls here. Those historical measurements are not relabeled as fresh evidence. The present addition is a rigorous consolidation: it supplies the explicit dyadic asymptotic proof, cost separation, deterministic planning option, storage schedule, and charged all-input table comparison.

A targeted primary-source search did not establish a new historical priority claim for this exact formulation. The appropriate conclusion is an independently verified specialization of established FFT, occupancy, compaction, and tabulation ideas.

## 9. Fresh controls and what they establish

`fresh_controls.py` is newly authored standard-library code; it does not import, execute, compile, or transform any predecessor program into executable form. It checks:

1. Exact rational occupancies by exhaustive binary inputs through `N=16` and four-symbol inputs through `N=8`, comparing strided-word equality with independent pair-ID construction.
2. The dyadic bounds and cold-table comparison across five alphabets and dyadic lengths through `N=2^256`, using stable numerical evaluation and explicitly negligible collision-tail truncation.
3. Fresh iid occupancy samples, without treating sampling as a proof.
4. Levelwise DAG and cold table output correctness against independently written direct DFT summation, plus exact butterfly counters and the `2N` live-spectrum bound.
5. Shared-cache, separate-cache, paired-DAG and packed-alphabet count distinctions, and complex unpacking including DC/Nyquist bins.

The completed counts, raw samples, errors, and source hash are in `FRESH_RESULTS.json`; `FRESH_STDOUT.txt` contains the run receipt. These are finite falsification controls, not a proof of asymptotic complexity or a practical speed claim. In particular the illustrative Python implementation uses tuple tables and repeated `cmath.exp` calls; it is not the performance implementation prescribed by the full word/arithmetic accounting above.

## Bottom line

Random bits do create many repeated small FFT subproblems. That observation has a clean exact occupancy law and a genuine additive `Theta(N log log N)` butterfly saving under the specified radix-2 comparison. It does not make the full explicit FFT sub-`N log N`. Efficient signatures and levelwise reclamation prevent bookkeeping and retained intermediate arrays from erasing the algorithmic advantage, and a charged finite-alphabet lookup construction obtains the same leading saving without runtime hash tables.
