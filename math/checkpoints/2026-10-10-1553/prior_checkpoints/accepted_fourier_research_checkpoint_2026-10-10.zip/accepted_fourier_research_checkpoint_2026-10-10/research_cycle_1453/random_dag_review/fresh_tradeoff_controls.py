"""Independent controls. Never imports or executes predecessor research code."""

from cmath import exp
from fractions import Fraction
from itertools import product
from math import log2, pi
from pathlib import Path
import hashlib
import json
import random


def levels(N):
    m = 2
    while m <= N:
        yield m
        m *= 2


def stable_count(items, coordinate, width):
    counts = [0] * width
    for item in items:
        counts[item[coordinate]] += 1
    total = 0
    for i, count in enumerate(counts):
        counts[i], total = total, total + count
    output = [None] * len(items)
    for item in items:
        position = counts[item[coordinate]]
        output[position] = item
        counts[item[coordinate]] += 1
    return output


def dense_id_graph(x, q):
    N = len(x)
    ids = list(x)
    width = q
    records = []
    work_units = 0
    for m in levels(N):
        n = N // m
        pairs = [(ids[r], ids[r+n], r) for r in range(n)]
        ordered = stable_count(stable_count(pairs, 1, width), 0, width)
        new_ids = [0] * n
        previous = None
        next_id = -1
        for a, b, r in ordered:
            if (a, b) != previous:
                next_id += 1
                previous = (a, b)
            new_ids[r] = next_id
        distinct = next_id + 1
        expected = len({tuple(x[r+n*t] for t in range(m)) for r in range(n)})
        assert distinct == expected
        # All alphabet IDs may occur at level 1; later dense ranges <=2n.
        assert width <= max(q, 2*n)
        work_units += n + width
        records.append((m, distinct))
        ids, width = new_ids, distinct
    return records, work_units


def table_cells(q, b):
    return q + sum(m * q**m for m in levels(b))


def table_cost(q, b):
    return sum((m // 2) * q**m for m in levels(b))


def strict_cutoff(N, q, budget):
    b = 1
    for m in levels(N):
        if table_cells(q, m) > budget:
            break
        b = m
    return b


def cold_total(N, q, b):
    return table_cost(q, b) + N // 2 * (N.bit_length() - b.bit_length())


def expected_B_exact(N, q):
    result = Fraction(0)
    for m in levels(N):
        K = q**m
        n = N // m
        expected_unique = K * (1 - Fraction(K - 1, K)**n)
        result += m // 2 * expected_unique
    return result


def encode(v, q):
    z = 0
    place = 1
    for value in v:
        z += value * place
        place *= q
    return z


def decode(z, m, q):
    a = []
    for _ in range(m):
        a.append(z % q)
        z //= q
    return a


def universal_leaf_table(q, b):
    # All writes, butterflies and scalar table entries are reported separately.
    table = {1: [complex(k) for k in range(q)]}
    butterflies = 0
    written = q
    for m in levels(b):
        previous = table[m // 2]
        current = [None] * (m * q**m)
        roots = [exp(-2j*pi*k/m) for k in range(m // 2)]
        for code in range(q**m):
            digits = decode(code, m, q)
            even = encode(digits[::2], q) * (m // 2)
            odd = encode(digits[1::2], q) * (m // 2)
            for k in range(m // 2):
                a = previous[even+k]
                z = roots[k] * previous[odd+k]
                current[code*m+k] = a + z
                current[code*m+k+m//2] = a - z
                butterflies += 1
                written += 2
        table[m] = current
    assert butterflies == table_cost(q, b)
    assert written == table_cells(q, b)
    return table[b], butterflies, written


def lookup_fft(x, q, b, table):
    N = len(x)
    n = N // b
    previous = []
    key_reads = 0
    copied_cells = 0
    for r in range(n):
        block = []
        for t in range(b):
            block.append(x[r+n*t])
            key_reads += 1
        start = b * encode(block, q)
        previous.append(list(table[start:start+b]))
        copied_cells += b
    butterflies = 0
    m = 2*b
    while m <= N:
        n = N // m
        current = []
        for r in range(n):
            even, odd = previous[r], previous[r+n]
            output = [0j] * m
            for k in range(m // 2):
                z = exp(-2j*pi*k/m) * odd[k]
                output[k] = even[k] + z
                output[k+m//2] = even[k] - z
                butterflies += 1
            current.append(output)
        previous = current
        m *= 2
    assert butterflies == N // 2 * (N.bit_length() - b.bit_length())
    assert key_reads == copied_cells == N
    return previous[0], butterflies


def direct_dft(x):
    N = len(x)
    return [sum(a * exp(-2j*pi*k*t/N) for t, a in enumerate(x)) for k in range(N)]


def run():
    exact_cases = []
    pointwise_checks = 0
    dense_checks = 0
    for q, N in ((2, 2), (2, 4), (2, 8), (3, 4), (4, 4)):
        total = 0
        for x in product(range(q), repeat=N):
            records, work = dense_id_graph(x, q)
            count = sum(m//2*u for m, u in records)
            total += count
            dense_checks += 1
            for b in [1, *levels(N)]:
                assert count <= cold_total(N, q, b)
                pointwise_checks += 1
            assert work <= 3*N + q
        empirical = Fraction(total, q**N)
        theoretical = expected_B_exact(N, q)
        assert empirical == theoretical
        exact_cases.append({"q": q, "N": N, "inputs": q**N,
                            "expected_butterflies": str(theoretical)})

    rng = random.Random(73460291)
    accuracy_cases = []
    worst_error = 0.0
    for q, N in ((2, 8), (2, 16), (2, 64), (2, 128), (3, 16), (3, 64)):
        b = strict_cutoff(N, q, N)
        table, preparation, cells = universal_leaf_table(q, b)
        assert cells <= N
        for label in ("all_zero", "constant", "period_two", "random_1", "random_2"):
            if label == "all_zero":
                x = [0] * N
            elif label == "constant":
                x = [q-1] * N
            elif label == "period_two":
                x = [i % 2 for i in range(N)]
            else:
                x = [rng.randrange(q) for _ in range(N)]
            spectrum, online = lookup_fft(x, q, b, table)
            reference = direct_dft(x)
            error = max(abs(a-bb) for a, bb in zip(spectrum, reference))
            worst_error = max(worst_error, error)
            assert error < 1e-9
            records, work = dense_id_graph(x, q)
            dag = sum(m//2*u for m, u in records)
            assert dag <= preparation + online
            assert work <= 3*N + q
            dense_checks += 1
            pointwise_checks += 1
            accuracy_cases.append({"q": q, "N": N, "b": b, "input": label,
                                   "table_cells": cells, "preparation_butterflies": preparation,
                                   "online_butterflies": online, "dag_butterflies": dag,
                                   "absolute_error": error})

    budgets = []
    for q in (2, 3, 4, 16):
        for L in (8, 16, 32, 64, 128, 256):
            N = 1 << L
            for numerator, denominator in ((1, 4), (1, 2), (1, 1)):
                S = 1 << (L * numerator // denominator)
                b = strict_cutoff(N, q, S)
                if S < q:
                    continue
                T = table_cells(q, b)
                assert T <= S
                if b < N:
                    assert table_cells(q, 2*b) > S
                assert 2*table_cost(q, b) + q == T
                budgets.append({"q": q, "L": L, "budget_power": f"{numerator}/{denominator}",
                                "budget_cells": str(S), "b": b, "table_cells": str(T),
                                "stages_saved": b.bit_length()-1,
                                "cold_butterflies": str(cold_total(N,q,b))})

    # Adversarial scope controls: dependence changes occupancy; growing alphabets
    # eliminate the claimed fixed-alphabet log-log saving at a representative size.
    N = 256
    constant_count = sum(m//2 for m in levels(N))
    assert constant_count == N-1
    baseline = Fraction(N//2 * (N.bit_length()-1))
    q = N
    growing_deficit_upper = sum(Fraction(N//m*(N//m-1), 2*q**m) * (m//2)
                                for m in levels(N))
    assert growing_deficit_upper < 1

    result = {
        "status": "PASS",
        "scope": "Fresh controls only; no predecessor program executed/imported. No timing or exact-complex execution claim.",
        "exact_enumeration": exact_cases,
        "dense_pair_id_construction_cases": dense_checks,
        "pointwise_dag_le_cold_lookup_checks": pointwise_checks,
        "lookup_accuracy_cases": accuracy_cases,
        "maximum_absolute_error": worst_error,
        "strict_numeric_table_budget_cases": budgets,
        "boundary_controls": {
            "all_equal_N": N, "all_equal_DAG_butterflies": constant_count,
            "growing_alphabet_q_equals_N": q,
            "standard_butterflies": int(baseline),
            "expected_saving_upper": float(growing_deficit_upper)
        }
    }
    path = Path(__file__).with_name("FRESH_TRADEOFF_RESULTS.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "dense_cases": dense_checks,
                      "pointwise_checks": pointwise_checks, "accuracy_cases": len(accuracy_cases),
                      "budget_cases": len(budgets), "max_error": worst_error}))


if __name__ == "__main__":
    run()
