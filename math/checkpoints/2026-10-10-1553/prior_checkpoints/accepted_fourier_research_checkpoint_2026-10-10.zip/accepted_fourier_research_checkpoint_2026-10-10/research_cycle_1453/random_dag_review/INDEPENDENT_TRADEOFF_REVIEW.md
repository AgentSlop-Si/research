# Independent review: random finite-alphabet radix-2 DAGs

10 October 2026. Review of the mathematical model supplied by the parallel analysis lane. Only newly authored controls in this directory were executed; no predecessor/source program was imported, executed, compiled, or converted into an executable representation. No external state was written.

## Verdict

**SCOPED PASS:** for independent uniform samples from a fixed alphabet of q≥2 distinct values, N=2^L, and exact equality sharing of whole ordered radix-2 subproblems,

    E B = (N/2) [log₂ N − log₂ log_q N] + O_q(N).

In particular, binary inputs save (N/2)log₂log₂N+O(N) butterflies against the stipulated full radix-2 count NL/2. The algorithm remains Θ(N log N) in expected butterfly work; its relative saving tends to zero. This is neither an exact-bit-complexity theorem nor a practical speed claim.

The necessary control is a cold-built universal leaf lookup table with an explicit numeric storage budget. It has the same leading butterfly count, for every input, and its charged cold count exceeds the random DAG's expectation by only O(N). The DAG can still be substantially better on structured inputs. Historical novelty of the exact occupancy refinement remains unestablished.

## 1. Which blocks are independent?

At size m=2^j let n=N/m and define the ordered block

    X_{m,r} = (x_r, x_{r+n}, …, x_{r+(m−1)n}),  0≤r<n.

These are a partition of the N sample positions: each index has exactly one residue r modulo n. Consequently the n size-m blocks are independent and uniform among K=q^m words. Disjointness at one level is sufficient. Different levels need not be independent, because only linearity of expectation is used across levels.

The even and odd children of X_{m,r} are X_{m/2,r} and X_{m/2,r+n}. Thus the indexing actually matches the radix-2 DIT recursion. A block's transform depends on its ordered values and length, not its original offset. Twiddles belong to the local length-m combine and agree for all equal size-m blocks.

There is no allowance for treating overlapping sliding windows as independent. Nonuniform alphabets instead have E U_m=Σ_w[1−(1−p_w)^n], not the uniform formula. A q that grows with N needs its own analysis.

For U_m distinct words at level m, occupancy indicators give exactly

    E U_m = K [1−(1−1/K)^n].

The stipulated count is B=Σ_{m=2,4,…,N}(m/2)U_m. It counts one standard two-output butterfly for every paired even/odd frequency, including trivial twiddles or values. It is not the minimal arithmetic count after zero, sign, real-symmetry, or other simplifications.

## 2. Explicit dyadic threshold audit

Let t be the largest dyadic positive integer with t q^t≤N, and assume N is large enough that it exists. Handle the finite omitted prefix separately; the asymptotic result fixes q.

Low levels m≤t satisfy U_m≤q^m. For successive terms a_m=mq^m, a_{m/2}/a_m=1/(2q^{m/2})≤1/8 when both m and m/2 occur in the butterfly sum. Therefore

    Σ_{2≤m≤t}(m/2)E U_m ≤ (4/7)tq^t ≤ 4N/7.

For the upper levels, write their deficit from N/2 as (m/2)(n−E U_m). The number of excess duplicate draws is at most the number of equal unordered pairs, so

    0≤n−E U_m≤n(n−1)/(2q^m),
    deficit_m≤N²/(4m q^m).

The first upper-level ratio N/(m q^m) is below one by maximality of t. Its ratio upon doubling m is 1/(2q^m)≤1/8. Summing gives total upper deficit≤2N/7. Hence the stronger valid bounds are

    (N/2)(L−log₂t)−2N/7 ≤ E B
      ≤ (N/2)(L−log₂t)+4N/7.

The candidate's weaker upper error 2N/3 is also valid. Since t=Θ_q(log_qN), replacing log₂t with log₂log_qN costs O_q(1), hence O_q(N) butterflies. The discrete dyadic threshold is essential: this argument does not justify a fixed linear-N correction or a finer o(N) error.

## 3. Exact planning without hash assumptions

Equal data blocks are mathematical collisions; hash-table bucket collisions are an implementation issue. A hash match alone must never certify equality. An exact dictionary on ordered pairs of child IDs may use hashing with equality checks, but its running-time guarantee then depends on the dictionary model.

An exact deterministic alternative has linear total planning cost on a word RAM with O(log N)-bit IDs:

1. Start from the fixed alphabet's canonical symbol IDs.
2. At a level containing n parent occurrences, form the n ordered pairs of child IDs. The previous level has at most 2n distinct IDs, represented densely.
3. Sort the pairs by two stable counting-sort passes. Both keys range over at most 2n values, so histogram initialization, all input scans, sorting, and scatter together take O(n) operations.
4. Group consecutive equal pairs and assign new dense IDs. Record one child pair for each group.

There are N−1 parent occurrences in total, so total work is O(N), including histogram initialization and clearing. A comparison-tree dictionary instead can introduce an O(N log N) planning term; naive re-reading/hashing of every entire length-m block introduces Θ(N log N) sample visits. Those implementations should not inherit the linear-planning claim.

The first alphabet pass costs O(N) for a known fixed alphabet. The controls below verify dense IDs against independently formed exact strided tuples; they do not execute an existing DAG implementation.

## 4. Graph size is not spectrum storage

The number of unique structural nodes is ΣU_m, whereas storing every unique transformed vector costs ΣmU_m=2B numeric cells, plus any leaves. For fixed q, the simple bound U_m≤min(q^m,N/m) shows ΣU_m=O_q(N/log N) for every input. Under the uniform random model, the first level above t has at least half its occurrence count in expectation, establishing the matching expected Ω_q(N/log N) lower bound.

By contrast, retaining all unique spectra costs Θ(N log N) numeric cells in expectation. This remains true although the structural graph is much smaller. A levelwise evaluation can discard a completed child level: each length-m layer contains mU_m≤N cells, and its next layer contains at most N. Therefore a constant number of level buffers, IDs, and metadata suffice for O(N) live words under the numerical-word model. This does not mean O(N) bits or fixed-size exact complex numbers.

The whole-block model gives B=N−1 for an all-equal vector. Its retained spectra are only O(N) cells; the random-input storage claim must not be asserted for all inputs.

## 5. Matching strictly budgeted leaf lookup

Fix a numerical table-cell budget S. For dyadic b define

    T_b = q + Σ_{m=2,4,…,b} m q^m,
    C_b = Σ_{m=2,4,…,b} (m/2)q^m = (T_b−q)/2.

Choose the largest b≤N with T_b≤S, taking b=1 when no larger table fits (and handle the fixed prefix S<q separately). The table contains every q-ary word's transform at each size through b. Build bottom-up: a length-m word's even/odd words index the previously built length-m/2 table; performing m/2 butterflies constructs its m output cells. This charges exactly C_b butterflies and T_b cell writes, including the q alphabet leaves. Address decoding, allocation, and metadata have separate charged O(T_b+b) word-model costs. Twiddle construction and storage must follow the same explicit numerical model used by the FFT comparator; a butterfly count does not make exact roots a zero-cost oracle. Here the number of entries is a budget on numerical payload cells; platform-specific objects and coefficient representations require their own accounting.

For one input, gather the N/b ordered strided b-blocks, encode their keys, and copy all b transform entries per block. That is N sample reads and N copied spectrum cells. Finish the upper radix-2 stages without equality sharing, at exactly

    A_online = (N/2)log₂(N/b)

butterflies. The complete cold butterfly count is C_b+A_online. Warm-use comparisons must report C_b separately rather than hide it. Input, output, and working buffers remain O(N), independent of the extra table budget.

For every input x, not merely on average,

    B_DAG(x) ≤ C_b + A_online,

because U_m≤q^m below the cutoff and U_m≤N/m above it. For the strict budget S=N and sufficiently large N, the selected b is either t or t/2. Thus

    0 ≤ C_b + A_online − E B_DAG ≤ 9N/7,

using C_b≤N/2, at most one extra N/2 stage, and the audited upper-level deficit≤2N/7. In particular both cold methods have

    (N/2)[log₂N−log₂log_qN]+O_q(N)

butterflies with O(N) live numerical-word storage. Any fixed polynomial table budget S=N^α, α>0, still gives b=Θ_{q,α}(log N) and the same leading term; the linear-N correction changes. A fixed-size table saves only a fixed number of stages.

This comparison controls what is attributable to random block sharing. It does not prove equal wall time, equal cache behavior, or table optimality. On structured inputs the DAG can have B=O(N), while the generic lookup control still has Θ(N log N) work.

## 6. Finite-alphabet and representation boundaries

- Uniform fixed q and independence are assumptions, not conclusions derived from a small observed alphabet.
- With q=N, the q^{-m} factor makes even the expected total collision saving O(1); the fixed-q log-log saving no longer applies. The finite control N=q=256 bounds the expected saving below one butterfly.
- The algorithm branches on sample equality, so the classical general-input linear FFT-circuit model is not automatically the same model. No contradiction with a lower bound is established or needed here.
- Numeric FFT work is measured in butterflies or ideal fixed-cost arithmetic. Exact complex twiddles, growing algebraic representations, finite-precision errors, and bit complexity require additional contracts. The fresh complex128-style controls are checks of indexing and the implementation idea, not an exact-arithmetic proof.
- Reading the input and explicitly materializing N output bins cost Ω(N) scalar accesses in the stated representation. Returning a shared pointer or compressed DAG is not equivalent to output materialization.

## 7. Prior-art calibration

This limited primary-source check establishes conceptual comparators, not historical priority for the exact theorem.

- Matteo Frigo, *A Fast Fourier Transform Compiler* (PLDI 1999), §5, describes DFT expression DAG simplification, bottom-up common-subexpression elimination, and memoized graph traversal. It supports treating DAG sharing/CSE as established machinery. Its symbolic codelet optimization is not this random realized-input occupancy analysis. https://www.fftw.org/pldi99.pdf
- Frigo and Johnson, *The Design and Implementation of FFTW3* (Proceedings of the IEEE 2005), §IV-E, describes memoization of transform plans. The planner's problem includes shape and layout rather than sample values; citing its memoization as prior realization of the present data-dependent reuse would conflate distinct things. The paper also distinguishes operation counts from machine performance. https://www.fftw.org/fftw-paper-ieee.pdf
- Eugene Myers, *A Four Russians Algorithm for Regular Expression Pattern Matching* (JACM 1992), introduction, explains exhaustive small-subproblem precomputation followed by lookup and explicitly states its RAM-model assumptions. It is primary evidence for the generic tabulation paradigm, not an FFT-specific version of the theorem. https://publications.mpi-cbg.de/Myers_1992_6336.pdf

The existing local `fft_selective/README.md` was read only as historical project context. It already records finite-size binary leaf-table and arithmetic-codelet comparisons and cautions that lookup performance depends on size and memory traffic. Those experiments were not rerun or independently re-certified here. No practical-speed or novelty claim is added by this review.

## 8. Fresh evidence and scope

`fresh_tradeoff_controls.py` is newly authored, standard-library-only code. Its JSON output records:

- 643 dense-ID construction cases, including exhaustive binary N≤8 and selected q=3,4 cases.
- 2,121 pointwise inequalities B_DAG≤C_b+A_online, across all possible cutoffs in the exhaustive cases.
- Exact rational agreement between enumerated expectations and the occupancy expression.
- 30 cold-table/full-output cases, including constant, periodic, and random data, with N≤128; maximum absolute discrepancy from a direct DFT was 6.281×10^−13.
- 71 strict numeric-table budget cases with q∈{2,3,4,16}, log₂N through 256, and budgets N^{1/4}, N^{1/2}, and N. Large cases check integers and counts only; no huge tables are allocated.
- Adversarial all-equal and growing-alphabet boundaries.

The controls passed. The proofs establish the asymptotic claims; finite tests are only falsification evidence. The source manuscript's final file binding is recorded separately in the review receipt after its completed text is available.

## 9. Completed candidate manuscript: additional audit

The completed `random_dag/RESULT.md` was read in full as text. Its threshold convention is t q^t≤N, with an O(N) table-storage allowance, and its gap 6N/7 follows from C_t≤4N/7 plus the upper-level duplicate deficit≤2N/7. This is consistent with the review's stricter cap T_b≤N and conservative 9N/7 gap; the numerical constants belong to different explicit budget conventions. The candidate handles N<q directly and states N≥q before defining t.

The candidate's fixed nonuniform distribution extension also passes. With collision probability rho=Σp_i²<1, length-m words have pair-collision probability rho^m. Upper levels starting at the first dyadic u≥log_{1/rho}N lose only O_p(N) butterflies, while the all-input tabulation bound supplies the matching upper estimate. Distribution-dependent constants cannot be made uniform as rho approaches one with N; the candidate excludes that regime and handles a one-symbol distribution separately.

The two-input distinctions pass:

- A cache shared by two independent inputs sees 2N/m independent words; its exact cross-cache gain is (1/2)Σ_m m q^m[1−(1−q^{−m})^{N/m}]²=O(N). No uniform Ω(N) gain is established, and the candidate does not assert one.
- A node keyed by both inputs has an alphabet of size q² and requires two scalar transforms. Per level, U_union≤U_x+U_y≤2V, proving the stated cost ordering.
- For real alphabets, x+iy gives one genuine packed complex FFT with q² distinct symbols; conjugate recovery at opposite frequencies costs O(N). This conventional packing advantage must be compared with real-input FFTs and remains separate from the project's unrelated finite-word approximate packing theorem.

All these are mathematical checks of the declared models. The candidate's own fresh executable was not run or imported by this reviewer.

The final dispatcher paragraph also passes at its stated accounting scope. Dense-ID planning determines each U_m and therefore the exact butterfly ledger before numerical execution. Selecting among a fixed set of schedules with available comparable cost formulas adds only O(N) planning overhead. A warm table can be compared under a deliberately warm cost model; the charged cold table never has fewer butterflies than the DAG. Neither the exact ledger nor an assumed weighting of operations is a verified wall-time oracle, as the candidate explicitly warns.

Final candidate hash checked: `60efd612850f431a13e29f31cc3019b8b3539e54ccce0d5130dfa8a5713b833d`. This is a rigorous consolidation of existing occupancy and sharing ideas; no new research identity, counter increment, or historical novelty determination is implied by this review.
