#!/usr/bin/env python3
"""Fresh, standalone rational-interval controls for the approximation boundary.
Only standard library imports. No uploaded or previously supplied program is imported.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial,isqrt
from pathlib import Path
import json,time
OUT=Path(__file__).resolve().parent

def outward(lo,hi,digits=60):
    d=10**digits
    return F((lo*d).__floor__(),d),F((hi*d).__ceil__(),d)
def atan_interval(q,n=56):
    s=sum((F((-1)**j,(2*j+1)*q**(2*j+1)) for j in range(n)),F(0))
    t=F((-1)**n,(2*n+1)*q**(2*n+1))
    return min(s,s+t),max(s,s+t)
a,b=atan_interval(5);c,d=atan_interval(239)
PI=outward(16*a-4*d,16*b-4*c,65)

def add(x,y):return x[0]+y[0],x[1]+y[1]
def mul(x,y):
    q=[a*b for a in x for b in y];return min(q),max(q)
def scale(c,x):return (c*x[0],c*x[1]) if c>=0 else (c*x[1],c*x[0])
def divpos(x,y):
    assert y[0]>0
    return mul(x,(1/y[1],1/y[0]))

@lru_cache(None)
def trig(p,r,kind):
    r%=p
    if r==0:return (F(1),F(1)) if kind=='cos' else (F(0),F(0))
    exact_cos={F(1,2):F(-1),F(1,3):F(-1,2),F(2,3):F(-1,2),F(1,6):F(1,2),F(5,6):F(1,2),F(1,4):F(0),F(3,4):F(0)}
    if kind=='cos' and F(r,p) in exact_cos:
        z=exact_cos[F(r,p)];return z,z
    if r>p//2:r-=p
    angle=scale(F(2*r,p),PI);x=sum(angle)/2;bound=max(abs(t) for t in angle)
    n=64
    if kind=='cos':
        z=sum(((-1)**j*x**(2*j)/factorial(2*j) for j in range(n)),F(0))
        err=bound**(2*n)/factorial(2*n)+(angle[1]-angle[0])/2
    else:
        z=sum(((-1)**j*x**(2*j+1)/factorial(2*j+1) for j in range(n)),F(0))
        err=bound**(2*n+1)/factorial(2*n+1)+(angle[1]-angle[0])/2
    return outward(z-err,z+err)

def interval_error(p,k,rep):
    # Exact expansion of |sum q_r zeta^r-zeta^k|^2; all inputs dyadic.
    items=list(rep.items());ans=(F(1),F(1))
    for r,q in items:
        ans=add(ans,(q*q,q*q));ans=add(ans,scale(-2*q,trig(p,r-k,'cos')))
    for i,(r,q) in enumerate(items):
        for s,t in items[i+1:]:ans=add(ans,scale(2*q*t,trig(p,r-s,'cos')))
    return ans

def make_case(p,B):
    a=(p+1)//3;S=[0,a,p-a];cuts=S+[p];reps={};eps=F(1,2**B);Q=2**(B+2)
    max_upper=F(0);coefficients=0
    for k in range(p):
        if k in S:reps[k]={k:F(1)};continue
        i=next(i for i in range(3) if cuts[i]<k<cuts[i+1]);u,v=cuts[i:i+2];gap=v-u
        assert F(1,5)<=F(gap,p)<=F(3,7)
        den=trig(p,gap,'sin');assert den[0]>=F(2,7)
        left=divpos(trig(p,v-k,'sin'),den)
        right=divpos(trig(p,k-u,'sin'),den)
        rep={}
        for r,I in [(u,left),(v%p,right)]:
            assert I[0]>0 and I[1]<=F(7,2)
            assert I[1]-I[0]<F(1,2**(B+4))
            # Midpoint nearest-even quantization with two guard bits.
            q=F(max(0,round((I[0]+I[1])*Q/2)),Q)
            assert max(abs(q-I[0]),abs(q-I[1]))<F(1,2**(B+2))
            assert 0<=q<4 and q.numerator.bit_length()<=B+4
            if q:rep[r]=q;coefficients+=1
        assert len(rep)<=2
        reps[k]=rep
        lo,hi=interval_error(p,k,rep)
        assert hi<eps*eps, (p,B,k,hi,eps*eps)
        max_upper=max(max_upper,hi)
    edges=0;frobenius_upper=F(0)
    errors={k:(F(0) if k in S else interval_error(p,k,reps[k])[1]) for k in range(p)}
    for i in range(p):
        for j in range(p):
            k=i*j%p;assert errors[k]<=eps*eps
            edges+=len(reps[k]);frobenius_upper+=errors[k]
    assert edges<=2*p*p-4*p+3
    assert frobenius_upper<=p*p*eps*eps
    return {'p':p,'B':B,'actual_fraction_bits':B+2,'palette':S,'entrywise_error_target':str(eps),
            'max_entry_error_squared_upper':str(max_upper),'frobenius_error_squared_upper':str(frobenius_upper),
            'edges':edges,'edge_bound':2*p*p-4*p+3,'root_checks':p,'entry_checks':p*p,
            'coefficients':{str(k):{str(r):str(q) for r,q in rep.items()} for k,rep in reps.items()}}

def sharp_two_phase(p):
    def circular_distance(x,y):
        r=(x-y)%p;return min(r,p-r)
    # Rotation/reflection reduces all C(p,2) palettes to these separation classes.
    data=[]
    for a in range(1,(p+1)//2):
        worst=F(0);worst_targets=[]
        for k in range(p):
            if 0<=k<=a:score=F(0)
            else:score=min(F(p,4),F(min(circular_distance(k,0),circular_distance(k,a))))
            if score>worst:worst=score;worst_targets=[k]
            elif score==worst:worst_targets.append(k)
        data.append({'a':a,'worst_sine_argument_units':str(worst),'targets':worst_targets})
    optimum=min(F(x['worst_sine_argument_units']) for x in data)
    expected=F(p,4) if p%4==3 else F(p-1,4)
    assert optimum==expected
    assert F(data[-1]['worst_sine_argument_units'])==expected
    if p%4==1:assert all(F(x['worst_sine_argument_units'])==F(p,4) for x in data[:-1])
    return {'p':p,'separation_classes_checked':len(data),'equivalent_palettes_checked':p*(p-1)//2,
            'sharp_infimum':'1' if p%4==3 else 'cos(pi/(2p))','attaining_separation':(p-1)//2,'classes':data}

def operator_halfplane(p):
    checked=0
    for j in range(8*p):
        Q=(F(0),F(0));total=(F(0),F(0));squares=(F(0),F(0));negative=0
        for r in range(p):
            t=(j+8*r)%(8*p);I=trig(8*p,t,'cos');total=add(total,I)
            if I[0]>=0:J=(I[0]*I[0],I[1]*I[1])
            elif I[1]<=0:J=(I[1]*I[1],I[0]*I[0])
            else:J=(F(0),max(I[0]*I[0],I[1]*I[1]))
            squares=add(squares,J)
            if 2*p<t<6*p:
                negative+=1;Q=add(Q,J)
        assert negative<=(p+1)//2
        assert total[0]<=0<=total[1] and squares[0]<=F(p,2)<=squares[1]
        assert Q[0]>=F(p,6)
        checked+=1
    assert F(p-1,6*p)>=F(1,9)
    return {'p':p,'orientations_checked':checked,'proved_relative_spectral_lower_bound_squared':str(F(p-1,6*p))}

def prime(p):return p>1 and all(p%d for d in range(2,isqrt(p)+1))
def main():
    t=time.monotonic();primes=[p for p in range(3,102,2) if prime(p)]
    selected=[3,5,7,11,13,17,19,29,43,67,101]
    cases=[]
    for p in selected:
        for B in [2,4,8,12,20]:
            c=make_case(p,B);cases.append(c);print('PASS',p,B,c['edges'],flush=True)
    sharp=[sharp_two_phase(p) for p in primes]
    operator=[operator_halfplane(p) for p in [3,5,7,11,13,17,19]]
    result={'status':'PASS','arithmetic':'Exact rational interval certificates from Machin and Taylor bounds; no floating-point equality/positivity/error thresholds',
            'construction_cases':len(cases),'root_checks':sum(c['root_checks'] for c in cases),
            'fourier_entry_checks':sum(c['entry_checks'] for c in cases),'sharp_two_phase_primes':len(sharp),
            'two_phase_separation_classes':sum(c['separation_classes_checked'] for c in sharp),
            'equivalent_two_phase_palettes':sum(c['equivalent_palettes_checked'] for c in sharp),
            'operator_halfplane_orientations':sum(c['orientations_checked'] for c in operator),
            'operator_halfplane_certificates':operator,
            'source_programs_executed':False,'source_programs_imported':False,
            'seconds':round(time.monotonic()-t,3),'construction_certificates':cases,'sharp_two_phase_certificates':sharp}
    (OUT/'FRESH_RATIONAL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['construction_certificates','sharp_two_phase_certificates']},indent=2))
if __name__=='__main__':main()
