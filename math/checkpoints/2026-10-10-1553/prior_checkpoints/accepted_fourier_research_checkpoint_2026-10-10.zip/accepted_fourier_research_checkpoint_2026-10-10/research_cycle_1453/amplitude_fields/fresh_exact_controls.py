#!/usr/bin/env python3
"""Fresh exact controls; imports only the Python standard library.
No source-package code is read, imported, or executed.  Algebra is Q[X]/Phi_p.
All claimed positivity is certified by rational intervals, never floating point.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from math import factorial
import hashlib, json, pathlib, time

OUT = pathlib.Path(__file__).resolve().parent

def trim(a):
    a=list(a)
    while a and not a[-1]: a.pop()
    return a

def padd(a,b):
    c=[F(0)]*max(len(a),len(b))
    for i,x in enumerate(a): c[i]+=x
    for i,x in enumerate(b): c[i]+=x
    return trim(c)

def pmul(a,b):
    if not a or not b:return []
    c=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return trim(c)

def pdiv(a,b):
    a=trim(a);b=trim(b);q=[F(0)]*max(0,len(a)-len(b)+1)
    assert b
    while len(a)>=len(b):
        i=len(a)-len(b);c=a[-1]/b[-1];q[i]=c
        for j,x in enumerate(b):a[i+j]-=c*x
        a=trim(a)
    return trim(q),a

def atan_bounds(q,n=40):
    s=sum((F((-1)**k,(2*k+1)*q**(2*k+1)) for k in range(n)),F(0))
    next_term=F((-1)**n,(2*n+1)*q**(2*n+1))
    return min(s,s+next_term),max(s,s+next_term)

def round_interval(lo,hi,digits=40):
    d=10**digits
    return F((lo*d).__floor__(),d),F((hi*d).__ceil__(),d)

a,b=atan_bounds(5);c,d=atan_bounds(239)
PI_LO,PI_HI=round_interval(16*a-4*d,16*b-4*c,45)
assert F(31415,10000)<PI_LO<PI_HI<F(31416,10000)

@lru_cache(None)
def cos_bounds(p,r):
    r%=p
    if r==0:return F(1),F(1)
    # Evenness reduces angles to [0,pi], accelerating the Taylor certificate.
    r=min(r,p-r)
    lo=2*PI_LO*r/p;hi=2*PI_HI*r/p;x=(lo+hi)/2
    n=48
    s=sum(((-1)**j*x**(2*j)/factorial(2*j) for j in range(n)),F(0))
    error=hi**(2*n)/factorial(2*n)+(hi-lo)/2
    return round_interval(s-error,s+error)

class Cyclo:
    def __init__(self,p):
        self.p=p;self.n=p-1
        self.zero=(F(0),)*self.n
        self.one=(F(1),)+(F(0),)*(self.n-1)
    def scalar(self,x):return (F(x),)+(F(0),)*(self.n-1)
    def root(self,r):
        r%=self.p
        if r==self.n:return (F(-1),)*self.n
        return tuple(F(i==r) for i in range(self.n))
    def add(self,a,b):return tuple(x+y for x,y in zip(a,b))
    def neg(self,a):return tuple(-x for x in a)
    def sub(self,a,b):return self.add(a,self.neg(b))
    def mul(self,a,b):
        q=[F(0)]*self.p
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b):
                    if y:q[(i+j)%self.p]+=x*y
        return tuple(x-q[-1] for x in q[:-1])
    @lru_cache(None)
    def inv(self,a):
        assert a!=self.zero
        r0=[F(1)]*self.p;r1=trim(a);s0=[];s1=[F(1)]
        while r1:
            q,r=pdiv(r0,r1)
            r0,r1=r1,r
            s0,s1=s1,padd(s0,[-x for x in pmul(q,s1)])
        assert len(r0)==1
        _,r=pdiv([x/r0[0] for x in s0],[F(1)]*self.p)
        ans=tuple(r+[F(0)]*(self.n-len(r)))
        assert self.mul(a,ans)==self.one
        return ans
    def div(self,a,b):return self.mul(a,self.inv(b))
    def sigma(self,a,h):
        ans=self.zero
        for j,c in enumerate(a):
            if c:ans=self.add(ans,tuple(c*x for x in self.root(j*h)))
        return ans
    @lru_cache(None)
    def sign(self,a):
        assert self.sigma(a,-1)==a, 'not real'
        if a==self.zero:return 0
        lo=hi=F(0)
        for r,c in enumerate(a):
            l,u=cos_bounds(self.p,r)
            if c>=0:lo+=c*l;hi+=c*u
            else:lo+=c*u;hi+=c*l
        if lo>0:return 1
        if hi<0:return -1
        raise ArithmeticError('Rational sign interval inconclusive')
    def sums(self,seq):
        ans=self.zero
        for a in seq:ans=self.add(ans,a)
        return ans
    def solve(self,A,B):
        n=len(A);m=len(B[0]);M=[list(a)+list(b) for a,b in zip(A,B)]
        for j in range(n):
            i=next(i for i in range(j,n) if M[i][j]!=self.zero)
            M[j],M[i]=M[i],M[j]
            z=self.inv(M[j][j]);M[j]=[self.mul(x,z) for x in M[j]]
            for i in range(n):
                if i!=j and M[i][j]!=self.zero:
                    c=M[i][j]
                    M[i]=[self.sub(x,self.mul(c,y)) for x,y in zip(M[i],M[j])]
        assert all(M[i][j]==(self.one if i==j else self.zero) for i in range(n) for j in range(n))
        return [row[n:] for row in M]
    def encoded(self,a):return [str(x) for x in a]

def primitive(p):
    for g in range(2,p):
        if len({pow(g,j,p) for j in range(p-1)})==p-1:return g
    return 1

def subgroups(p):
    g=primitive(p)
    for h in range(2,p,2):
        if (p-1)%h==0:
            yield sorted({pow(g,j*(p-1)//h,p) for j in range(h)})

def orbit_cosets(p,H):
    todo=set(range(1,p));ans=[]
    while todo:
        C=sorted({min(todo)*h%p for h in H});ans.append(C);todo.difference_update(C)
    return ans

def check_field(p,H):
    E=Cyclo(p);h=len(H);cosets=orbit_cosets(p,H)
    eta=[E.sums(E.root(r) for r in C) for C in cosets]
    assert E.sums(eta)==E.scalar(-1)
    assert E.sums(E.mul(x,x) for x in eta)==E.scalar(p-h)
    assert all(E.sigma(x,a)==x for x in eta for a in H)
    signs=[E.sign(x) for x in eta]
    assert -1 in signs
    if h<p-1:assert 1 in signs
    else:assert signs==[-1]
    C=cosets[signs.index(-1)];period=eta[signs.index(-1)]
    palette=[0]+C
    relation=[E.neg(period)]+[E.one]*h
    assert all(E.sign(x)>0 for x in relation)
    assert E.sums(E.mul(x,E.root(r)) for x,r in zip(relation,palette))==E.zero
    # Minimal polynomial over the fixed field, directly as the orbit product.
    mp=[E.one]
    for a in H:
        q=[E.zero]*(len(mp)+1)
        for j,x in enumerate(mp):
            q[j]=E.sub(q[j],E.mul(x,E.root(a)));q[j+1]=E.add(q[j+1],x)
        mp=q
    assert all(E.sigma(x,a)==x for x in mp for a in H)
    assert E.sums(E.mul(x,E.root(j)) for j,x in enumerate(mp))==E.zero
    # Solve all targets simultaneously against an h-root basis using all H embeddings.
    if h==p-1:
        reps={k:{k:E.one} for k in range(p)}
    else:
        A=[[E.root(a*r) for r in C] for a in H]
        B=[[E.root(a*k) for k in range(p)] for a in H]
        X=E.solve(A,B);reps={}
        for k in range(p):
            if k in palette:reps[k]={k:E.one};continue
            b=[X[j][k] for j in range(h)]
            assert all(E.sigma(x,a)==x for x in b for a in H)
            smallest=E.zero
            for x in b:
                if E.sign(E.sub(x,smallest))<0:smallest=x
            t=E.neg(smallest)
            coeff=[E.mul(t,E.neg(period))]+[E.add(x,t) for x in b]
            assert all(E.sign(x)>=0 for x in coeff)
            reps[k]={r:x for r,x in zip(palette,coeff) if x!=E.zero}
            assert len(reps[k])==h
    for k,rep in reps.items():
        assert all(E.sign(x)>0 for x in rep.values())
        assert all(E.sigma(x,a)==x for x in rep.values() for a in H)
        assert E.sums(E.mul(x,E.root(r)) for r,x in rep.items())==E.root(k)
    # Verify every actual Fourier entry, and sharp edge count at minimum palette.
    edges=0
    for i in range(p):
        for j in range(p):
            rep=reps[i*j%p]
            assert E.sums(E.mul(x,E.root(r)) for r,x in rep.items())==E.root(i*j)
            edges+=len(rep)
    expected=h*p*p-(h-1)*((h+2)*p-(h+1))
    assert edges==expected
    coverage=None
    if h<p-1:
        D=cosets[signs.index(1)];q=E.inv(eta[signs.index(1)])
        assert E.sign(q)>0 and 0 not in D and len(D)==h
        assert E.sums(E.mul(q,E.root(r)) for r in D)==E.one
        coverage={'omitted_target':0,'phases':D,'common_amplitude':E.encoded(q)}
    return {'p':p,'field_degree':(p-1)//h,'h':h,'minimal_palette':palette,
            'period_signs':signs,'edge_count':edges,'target_roots_checked':p,
            'fourier_entries_checked':p*p,'missing_target_certificate':coverage,
            'minimal_polynomial_coefficients':[E.encoded(x) for x in mp],
            'positive_relation':[E.encoded(x) for x in relation],
            'root_representations':{str(k):{str(r):E.encoded(x) for r,x in rep.items()} for k,rep in reps.items()}}

def check_explicit_triangle(p):
    E=Cyclo(p);a=(p-1)//2;S=[0,a,p-a];den=E.sub(E.root(a),E.root(-a));reps={}
    lam=E.neg(E.add(E.root(a),E.root(-a)));P=[E.one,lam]
    assert E.sign(lam)>0
    for n in range(2,p):P.append(E.sub(E.mul(lam,P[-1]),P[-2]))
    for k in range(p):
        if k in S:reps[k]={k:E.one};continue
        kk=min(k,p-k);phase=a if 2*k<p else p-a
        # Ratios of imaginary parts are real elements of the maximal real subfield.
        u=E.div(E.sub(E.root(a-kk),E.root(-(a-kk))),den)
        v=E.div(E.sub(E.root(kk),E.root(-kk)),den)
        assert E.sign(u)>0 and E.sign(v)>0
        assert u==P[2*kk] and v==P[2*kk-1]
        reps[k]={0:u,phase:v}
        assert E.add(u,E.mul(v,E.root(phase)))==E.root(k)
    edges=sum(len(reps[i*j%p]) for i in range(p) for j in range(p))
    assert edges==2*p*p-4*p+3
    return {'p':p,'palette':S,'edge_count':edges,'root_identities':p,'entry_checks':p*p,'single_generator_polynomial_coefficients_checked':True}

def main():
    start=time.monotonic();cases=[]
    for p in [3,5,7,11,13,17,19]:
        for H in subgroups(p):
            row=check_field(p,H);cases.append(row)
            print('PASS field',p,len(H),'palette',row['minimal_palette'],'edges',row['edge_count'],flush=True)
    triangles=[check_explicit_triangle(p) for p in [3,5,7,11,13,17,19,23,29,31,37,41,43]]
    # p=2 is separate: E=L=Q, h=1, phases {1,-1}, direct F2 has four edges.
    binary={'p':2,'h':1,'minimal_palette_size':2,'edge_count':4,'checked':True}
    assert 1*(-1)==-1 and 1+(-1)==0
    result={'status':'PASS','method':'Exact rational cyclotomic arithmetic; rational Machin/Taylor positivity certificates; standard-library-only fresh controls',
            'source_code_executed':False,'source_code_imported':False,
            'field_cases':len(cases),'field_root_checks':sum(x['target_roots_checked'] for x in cases),
            'field_entry_checks':sum(x['fourier_entries_checked'] for x in cases),
            'triangle_cases':len(triangles),'triangle_entry_checks':sum(x['entry_checks'] for x in triangles),
            'binary':binary,'seconds':round(time.monotonic()-start,3),'cases':cases,'explicit_triangles':triangles}
    (OUT/'FRESH_EXACT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['cases','explicit_triangles']},indent=2))
if __name__=='__main__':main()
