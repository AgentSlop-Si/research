# Sentence-level erratum to the pinned amplitude-field draft

The original draft is preserved as AMPLITUDE_FIELD_THEOREM_v1_REVIEWED.md, byte-for-byte pinned at SHA-256 8f586d704b8632e0ea4879c80c21fd789cdcc9332ff4f943d1c769264feecd0e. The main lower-bound proof is correct. One redundant sentence in section 4 incorrectly says the independence lemma plus any outside target alone proves the case |S|=h. That would involve h+1 roots.

Replace that sentence by:

> Equivalently, summing the target representations gives a nonzero nonnegative relation among the at most h palette roots, contradicting the independence lemma. The dimension proof clarifies the connection to classical positive bases.

The canonical AMPLITUDE_FIELD_THEOREM_v2.md makes only this sentence-level correction; AMPLITUDE_FIELD_THEOREM.md is an identical convenience copy. All conclusions and the main proof are unchanged. The amplitude-field cost corollary is kept separate.
