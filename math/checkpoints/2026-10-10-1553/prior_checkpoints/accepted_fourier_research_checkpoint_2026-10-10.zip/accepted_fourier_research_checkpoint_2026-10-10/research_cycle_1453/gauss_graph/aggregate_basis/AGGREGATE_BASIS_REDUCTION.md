# Aggregate Gauss fibers: exact basis optimization and a tested escape candidate

Date: 10 October 2026. A separate continuation; the resolved-fiber proof and its original controls are frozen.

## Result

Aggregate cancellation really escapes the pointwise rectangle theorem, but a shared basis change is not a free source of sparsity. For square hidden layers, the aggregate-fiber problem has an exact support objective. Prime Fourier uncertainty yields a quantitative necessary condition: **inverse-support expansion must exceed a two-sided mixing penalty before this model can beat 2p²+p edges**.

A single nonsingular rank-one shared basis update with nonvanishing diagonal cannot improve that count. The next small candidate, an arbitrary 3×3 invertible unit lower-bidiagonal basis, also cannot improve it, even though its inverse is denser. An explicit equality witness shows the obstruction is tight for that candidate. These are exact complex statements, not finite-field inferences or unrestricted lower bounds.

## 1. Exact aggregate-fiber optimization

Let p be an odd prime, F[i,j]=ζ^(ij), χ_t=(ζ^(it))_i, and q(t)=−t²/2 modulo p. Take strictly layered hidden sets U,V of exactly p vertices each. The input and output matrices A,C are invertible p×p complex matrices. We require, for every t,

    C B_t A = ζ^q(t) χ_t χ_t^T.                                 (1)

Every nonzero entry of B_t is one middle edge labeled t. Edges of different labels may be parallel. Thus different slices do **not** need disjoint matrix-entry supports: their edge identities are distinct, and all are charged. Multiple same-label edges at the same ordered pair can be combined; if their sum is zero, they are unnecessary. This reduction is specific to aggregate fibers and does not preserve the pointwise hypothesis from the first theorem.

Put

    R=C^(-1)F,          S=FA^(-1).

Writing r_t for column t of R and s_t^T for row t of S, equation (1) forces, uniquely,

    B_t=ζ^q(t) r_t s_t^T.                                       (2)

Conversely these slices always satisfy (1). Since R and S are invertible, every r_t and s_t is nonzero. Let r(t)=nnz(r_t) and s(t)=nnz(s_t). The exact minimum edge count for these particular A,C is

    E(A,C)=nnz(A)+nnz(C)+Σ_t r(t)s(t).                            (3)

This is both a lower and an upper count: each forced nonzero slice entry needs a middle edge, and one edge per entry constructs it. There is no charge for enumerated paths beyond those actual edges.

Equivalently optimize over invertible R,S:

    E=nnz(S^(-1)F)+nnz(FR^(-1))+Σ_t r(t)s(t).                    (4)

Summing (1) over t gives the same nonzero Gauss scalar and endpoint chirps as the original identity; folding those corrections into A and C preserves all edge counts. Equations (2)–(4) give an exact simultaneous rank-one/sparsity problem, not a claim that its minimum is known or that its coefficients can be prepared cheaply. Rectangular hidden layers and noninvertible endpoint matrices are outside this reduction.

## 2. The inverse-expansion gate

For any nonzero complex row h, prime Fourier uncertainty gives

    nnz(h)+nnz(hF)≥p+1.                                        (5)

Apply it to every row of C^(-1), and to every column of A^(-1). Therefore

    nnz(R)≥p(p+1)−nnz(C^(-1)),
    nnz(S)≥p(p+1)−nnz(A^(-1)).                                 (6)

Define the signed inverse-support expansions

    δ_C=nnz(C^(-1))−nnz(C),     δ_A=nnz(A^(-1))−nnz(A).

Since Σ_t r(t)=nnz(R), Σ_t s(t)=nnz(S), and

    r(t)s(t)−r(t)−s(t)=(r(t)−1)(s(t)−1)−1,

substitution into (3) proves

    E(A,C) ≥ 2p²+p + Σ_t (r(t)−1)(s(t)−1) − δ_A − δ_C.          (7)

In particular, beating 2p²+p requires the strict inequality

    δ_A+δ_C > Σ_t (r(t)−1)(s(t)−1).                             (8)

This is necessary, never sufficient. Inverse sparsity here is an algebraic diagnostic; computing an inverse is not treated as a free algorithmic step. If each inverse is no denser than its matrix, no improvement is possible. If both sides leave the same latent t spread over several coordinates, the explicit nonnegative product penalty increases the requirement.

## 3. One-sided output-basis changes and rank-one updates

Fixing A=F makes S=I. All middle slices are supported in their own columns, and (3) becomes exactly

    E(F,C)=p²+nnz(C)+nnz(C^(-1)F).                               (9)

This family can never be o(p²), because its input boundary already has p² edges. Improving its additive or constant cost is still a useful finite control, not a route to the target asymptotic bound by itself.

From (7),

    E(F,C)≥2p²+p+nnz(C)−nnz(C^(-1)).                            (10)

Now take C=I+uv^T, assume 1+v^Tu≠0 and assume every diagonal entry of C is nonzero. Sherman–Morrison gives

    C^(-1)=I−uv^T/(1+v^Tu).

The nonzero off-diagonal entries of C and C^(-1) have exactly the same support. C has all p diagonal entries, while its inverse has at most p. Hence nnz(C^(-1))≤nnz(C), and (10) proves

    E(F,C)≥2p²+p.

Thus this complete rank-one-update candidate fails for every odd prime and all allowed complex u,v. The nonvanishing-diagonal condition is explicit; dropping it is not covered by this argument. Indeed, at p=3, u=(1,1,1)^T and v=(−1,1,1)^T give an invertible C=I+uv^T with 8 nonzeros, but C^(-1)=I−uv^T/2 has 9. Its one-sided graph has 26 edges, so it supplies a qualifier control rather than an improvement.

The exact shear C=I+E_{0,1} attains equality: C has p+1 nonzeros, C^(-1)F has p²−1, and E=2p²+p. Its aggregate fibers have amplitude exactly one although its individual middle-edge rectangles do not have the required characters. It is a sharp scope control, not a support improvement.

## 4. The next explicit escape candidate also fails at p=3

Inverse-support expansion is necessary in the one-sided family, so test the smallest chain that has it:

    C = [[1,0,0], [a,1,0], [0,b,1]],          a,b≠0.

Then nnz(C)=5 and

    C^(-1) = [[1,0,0], [-a,1,0], [ab,-b,1]],

which has 6 nonzeros. The rows of D=C^(-1)F_3, evaluated at z∈{1,ζ,ζ²}, are

    1,                  z−a,                 z²−bz+ab.         (11)

The first row has no zeros. The second has at most one, and the third at most two. Suppose D had three zeros. Then a would be a cube root of unity, and the quadratic would vanish at two distinct cube roots r,s. Coefficient comparison gives

    b=r+s,        ab=rs,        a=rs/(r+s).

Because the third root is (rs)^(-1), r+s=−(rs)^(-1), so

    a=−(rs)².

This is the negative of a cube root, and cannot itself be a cube root in characteristic zero: its cube is −1. Contradiction. Thus D has at most two zeros, nnz(D)≥7, and

    E(F_3,C)=9+5+nnz(D)≥21=2·3²+3.

Equality is attained by a=b=−1. Its final polynomial is 1+z+z², with two zeros; the middle polynomial 1+z has none. This candidate genuinely has a denser inverse, yet cannot spend that expansion to improve support. This is a full proof for arbitrary nonzero complex a,b, rather than a parameter-grid claim.

## 5. Classical uncertainty input, with a self-contained argument

The external background is the prime Fourier nonvanishing-minor theorem, often called Chebotarev's theorem, and its uncertainty consequence. A primary source is Terence Tao, *An uncertainty principle for cyclic groups of prime order*, Mathematical Research Letters 12 (2005), 121–127: https://arxiv.org/abs/math/0308286 and https://intlpress.com/site/pub/files/_fulltext/journals/mrl/2005/0012/0001/MRL-2005-0012-0001-a011.pdf . No novelty is claimed for this input.

For completeness, take distinct integer representatives x_1,…,x_k and y_1,…,y_k in {0,…,p−1}. Define

    D(z)=det(z^(x_i y_j)),         m=k(k−1)/2.

Expanding z=e^w, multilinearity shows that the first possible nonzero power is w^m, obtained by using exponents 0,…,k−1. Its coefficient is

    V(x)V(y) / ∏_{r=0}^{k−1} r!,

where V denotes the Vandermonde product. That number is nonzero. Since e^w−1 has linear term w, D(z) is divisible by (z−1)^m in Z[z], and the quotient Q has that displayed value at z=1. Reducing modulo p is legitimate because every r! is invertible mod p; all Vandermonde factors are also nonzero mod p. Thus Q(1) is not divisible by p.

If D(ζ)=0, the minimal polynomial Φ_p(z)=1+z+…+z^(p−1) divides D(z). It is coprime to z−1 over Q, so it divides Q(z); since Φ_p is monic, this divisibility is in Z[z]. Then p=Φ_p(1) divides Q(1), a contradiction. Hence every square Fourier minor is nonzero.

Finally, if a nonzero h has k nonzero coordinates and hF has k zero coordinates, the corresponding k×k Fourier minor gives an invertible homogeneous system on those k entries of h, forcing them all to vanish. Therefore hF has at most k−1 zeros, proving (5). Transposition yields the column version used in (6).

## 6. Exact controls, cost, and stopping point

`fresh_basis_controls.py` is newly authored and standard-library-only. It executes/imports no uploaded or source research program and does not import the earlier control program. Its arithmetic is exact in Z[ζ_p]. It checks:

- complete aggregate fibers and exact edge counts for the one-sided shear;
- the p=3 bidiagonal equality witness and all root pairs that would be required by a forbidden three-zero configuration;
- complete two-sided slice identities and the edge count/mixing-penalty identity for deterministic exact shear-basis examples.

The symbolic proofs, not these finite examples, establish the all-parameter claims. No finite-field specialization is used to infer complex uncertainty.

All coefficient construction is accounted for: the displayed small witnesses and shear bases have explicit formulas; a general optimizer must still provide and charge the generation of A,C,R,S and every middle-edge coefficient. A generic dense matrix inverse, tensor assembly or nonlinear fit is not an O(p log log p) preprocessing algorithm. Literal storage is O(E); a sharper live-state bound needs a concrete evaluation schedule. No finite-word, numerical-stability, or bit-work improvement is proved.

This bounded continuation ends after the complete rank-one basis family, the exact p=3 bidiagonal candidate, and the support objective (3)–(8). The next actionable certificate is a concrete pair A,C satisfying (1), with **positive inverse-support expansion exceeding the mixing penalty**, E<2p²+p, and explicit coefficient generation. For asymptotic progress, both boundary matrices must also be subquadratic; keeping A=F cannot qualify. No further parameter search is claimed or left silently running.
