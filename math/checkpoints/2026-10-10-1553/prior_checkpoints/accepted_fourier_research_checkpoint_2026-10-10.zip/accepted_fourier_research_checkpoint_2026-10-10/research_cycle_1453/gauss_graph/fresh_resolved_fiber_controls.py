#!/usr/bin/env python3
"""Fresh standard-library controls; no source-project code imports or execution."""
import itertools
import json
from pathlib import Path

class Cyclotomic:
    """Q(zeta_p) integer subring, represented modulo 1+x+...+x^(p-1)."""
    def __init__(self, p):
        self.p = p
        self.zero = (0,) * (p-1)
        self.one = (1,) + (0,) * (p-2)
    def add(self, a, b): return tuple(x+y for x,y in zip(a,b))
    def neg(self, a): return tuple(-x for x in a)
    def sub(self, a, b): return self.add(a,self.neg(b))
    def scale(self, a, k): return tuple(k*x for x in a)
    def root(self, exponent):
        exponent %= self.p
        if exponent == self.p-1: return (-1,) * (self.p-1)
        a = [0] * (self.p-1); a[exponent] = 1
        return tuple(a)
    def mul(self, a, b):
        raw = [0] * self.p
        for i,x in enumerate(a):
            for j,y in enumerate(b): raw[(i+j)%self.p] += x*y
        tail = raw[-1]
        return tuple(x-tail for x in raw[:-1])
    def sum(self, xs):
        ans = self.zero
        for x in xs: ans = self.add(ans,x)
        return ans

def gauss_controls():
    count = 0
    entries = 0
    shear_count = 0
    data = []
    for p in [3,5,7,11,13]:
        R = Cyclotomic(p); half = pow(2,-1,p)
        gauss = R.sum(R.root(-half*t*t) for t in range(p))
        assert gauss != R.zero
        for i,j,t in itertools.product(range(p), repeat=3):
            path = R.mul(R.mul(R.root(j*t),R.root(-half*t*t)), R.root(i*t))
            assert path == R.root(-half*t*t+(i+j)*t)
            count += 1
        for i,j in itertools.product(range(p), repeat=2):
            total = R.sum(R.root(-half*t*t+(i+j)*t) for t in range(p))
            gauged = R.mul(total,R.root(-half*(i*i+j*j)))
            assert gauged == R.mul(gauss,R.root(i*j))
            entries += 1
        # C=I+E_01, A=F. Slice t has a single nonzero input-side column t.
        middle_edges = 0
        for t in range(p):
            chi = [R.root(i*t) for i in range(p)]
            cinv_chi = list(chi); cinv_chi[0] = R.sub(chi[0],chi[1])
            b = [R.mul(R.root(-half*t*t),z) for z in cinv_chi]
            middle_edges += sum(z != R.zero for z in b)
            for i,j in itertools.product(range(p), repeat=2):
                out = b[i]
                if i == 0: out = R.add(out,b[1])
                transfer = R.mul(out,R.root(t*j))
                assert transfer == R.root(-half*t*t+(i+j)*t)
                shear_count += 1
            if t:
                assert R.one != R.root(-t)  # Actual output ratio at V_1 violates (P).
        assert R.one != R.root(1)  # t=0 and t=1 force inconsistent fixed a_0/a_1.
        assert middle_edges == p*p-1
        assert p*p+(p+1)+middle_edges == 2*p*p+p
        data.append({'p':p, 'gauss_nonzero':True, 'sharp_edges':2*p*p+p,
                     'shear_middle_edges':middle_edges, 'shear_fiber_amplitude':1,
                     'shear_pointwise_condition':False,
                     'shear_any_fixed_gauges_possible':False})
    return {'dense_path_equalities':count,'gauged_fourier_equalities':entries,
            'aggregate_shear_equalities':shear_count,'lengths':data}

def rigidity_controls():
    checks = 0
    for p in [2,3,5,7,11,13,17,19]:
        for j,jj,t,tt in itertools.product(range(p),repeat=4):
            assert ((j-jj)*(t-tt)%p == 0) == (j == jj or t == tt)
            checks += 1
    for j,jj,t,tt in itertools.product([0,3,6],repeat=4):
        assert (j-jj)*(t-tt)%9 == 0
    # Exhaust all subsets in Z_N for N<=9 and check the annihilator product bound.
    annihilator_checks = 0
    for n in range(2,10):
        for mask in range(1,1<<n):
            J = [j for j in range(n) if mask>>j & 1]
            Dperp = [t for t in range(n) if all((j-J[0])*t%n == 0 for j in J)]
            assert len(J)*len(Dperp) <= n
            annihilator_checks += 1
    return {'prime_difference_checks':checks,'composite_9_counterexample':True,
            'annihilator_subset_checks':annihilator_checks}

def least_middle_cover(n, left_sets, right_sets):
    full = (1 << (n*n))-1
    rectangles = []
    for J in left_sets:
        for I in right_sets:
            rectangles.append(sum(1 << (i*n+j) for i in I for j in J))
    # Exact finite set-cover dynamic program, counting actual middle edges.
    dp = {0:0}
    for rectangle in rectangles:
        for mask,cost in list(dp.items()):
            extended = mask | rectangle
            if cost+1 < dp.get(extended,10**9): dp[extended] = cost+1
    return dp.get(full)

def canonical_support_minima():
    result = []
    total = 0
    for n in [2,3]:
        subsets = [tuple(i for i in range(n) if m>>i & 1) for m in range(1<<n)]
        mixed_options = [()] + [s for s in subsets if len(s)>=2]
        global_min = None; witness = None; feasible = 0
        # Singleton vertices are shared by all n coordinates. At most one mixed
        # U and one mixed V is permitted PER coordinate, each with any support.
        # Colors are independent once the singleton sets are fixed. Thus each
        # coordinate can use the same optimal cover without losing generality
        # for minimization in THIS BOUNDED CANONICAL FAMILY.
        for K,L in itertools.product(subsets,repeat=2):
            best = None; best_info = None
            for J,I in itertools.product(mixed_options,repeat=2):
                total += 1
                left = [(j,) for j in K] + ([J] if J else [])
                right = [(i,) for i in L] + ([I] if I else [])
                b = least_middle_cover(n,left,right)
                if b is None: continue
                feasible += 1
                local = len(J)+len(I)+b
                k = int(bool(J))+int(bool(I))
                assert local >= 2*n
                if k >= 2: assert local >= 2*n+1
                if best is None or local < best:
                    best = local; best_info = {'J':J,'I':I,'middle_edges':b}
            if best is not None:
                edges = len(K)+len(L)+n*best
                assert edges >= 2*n*n+n
                if global_min is None or edges < global_min:
                    global_min = edges
                    witness = {'singleton_inputs':K,'singleton_outputs':L,
                               'per_color':best_info}
        assert global_min == 2*n*n+n
        result.append({'n':n,'minimum_edges':global_min,'witness':witness,
                       'feasible_local_configurations':feasible})
    return {'examined_local_configurations':total,'canonical_minima':result,
            'scope':'At most one mixed U and one mixed V per coordinate; all singleton sets and supports enumerated.'}

def charge_scenarios():
    # All nonempty t-labelled unions of the three sharp templates, represented
    # by neighbor sets, followed by exact support and charge inspection.
    checked = 0
    for n in [2,3,5,7]:
        for templates in itertools.product(range(3),repeat=n):
            if n == 7 and checked > 4000: break
            A = set(); B = []; C = set()
            for t,style in enumerate(templates):
                if style == 0:
                    u=('mixed',t); v=('mixed',t)
                    A.update((j,u) for j in range(n)); C.update((v,i) for i in range(n))
                    B.append((u,v,t))
                elif style == 1:
                    v=('mixed',t); C.update((v,i) for i in range(n))
                    for j in range(n):
                        u=('single',j); A.add((j,u)); B.append((u,v,t))
                else:
                    u=('mixed',t); A.update((j,u) for j in range(n))
                    for i in range(n):
                        v=('single',i); C.add((v,i)); B.append((u,v,t))
            assert len(A)+len(B)+len(C) >= 2*n*n+n
            singleton_cost = sum(u[0]=='single' for j,u in A)+sum(v[0]=='single' for v,i in C)
            local=[]
            for t in range(n):
                bt = [(u,v) for u,v,z in B if z==t]
                um = {u for u,v in bt if u[0]=='mixed'}
                vm = {v for u,v in bt if v[0]=='mixed'}
                cost = len(bt)+sum(u in um for j,u in A)+sum(v in vm for v,i in C)
                assert cost >= 2*n+(len(um)+len(vm)>=2)
                for i,j in itertools.product(range(n),repeat=2):
                    assert any((j,u) in A and (v,i) in C for u,v in bt)
                local.append(cost)
            assert singleton_cost+sum(local)==len(A)+len(B)+len(C)
            checked += 1
    return {'template_graphs_checked':checked,'all_edge_charges_and_coverage_pass':True}

def main():
    answer = {'status':'PASS','fresh_code':True,'source_programs_executed':False,
              'gauss':gauss_controls(),'rigidity':rigidity_controls(),
              'support':canonical_support_minima(),'charging':charge_scenarios()}
    out = Path(__file__).with_name('FRESH_RESULTS.json')
    out.write_text(json.dumps(answer,indent=2)+'\n')
    print(json.dumps(answer,indent=2))

if __name__ == '__main__': main()
