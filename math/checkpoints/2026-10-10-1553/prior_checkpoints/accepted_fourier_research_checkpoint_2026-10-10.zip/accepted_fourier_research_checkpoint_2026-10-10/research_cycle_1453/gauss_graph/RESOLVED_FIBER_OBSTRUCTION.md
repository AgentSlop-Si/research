# A sharp obstruction for middle-edge-resolved Gauss fibers

Date: 10 October 2026. Fresh theory lane; accepted/source files are unchanged.

## Finding

For an odd prime p, the natural depth-three implementation in which a middle edge owns a latent Gauss coordinate and every path through that edge already has the correct two endpoint characters needs at least **2p²+p edges**. The direct dense Gauss construction attains this bound exactly. Arbitrary nonzero complex edge weights and cancellation between different middle edges are allowed in this theorem.

This closes one concrete construction candidate, not the full Gauss proposal. The repaired *aggregate* weighted-fiber identity does not imply the pointwise rectangle hypothesis below. A sparse construction must escape that hypothesis, or use a latent coordinate depending on more than its middle edge, change the depth, or abandon these fibers. No unrestricted Fourier lower bound or historical novelty claim is made.

## 1. Precise model

Let p be prime, ζ a primitive complex pth root, and X_j and Y_i be p distinct input and output vertices. Consider a strictly layered scalar linear network

    X → U → V → Y.

Its nonzero input and output edge weights are A[u,j] and C[i,v]. A middle edge e=(u,v) has nonzero weight B_e and a coordinate τ(e) in F_p. Parallel middle edges count separately. For simplicity the outer layers have at most one edge per ordered pair; the symbolic-label version below also permits parallel outer edges. Remove vertices and edges lying on no terminal path.

Write J_u={j:A[u,j]≠0} and I_v={i:C[i,v]≠0}. Fix nonzero endpoint gauges a_i,b_j. The **pointwise character-rectangle hypothesis** is that for every middle edge e there is a nonzero complex η_e such that, for every j∈J_u and i∈I_v,

    C[i,v] B_e A[u,j] = η_e a_i b_j ζ^((i+j)τ(e)).                 (P)

A quadratic factor ζ^(-τ(e)²/2) is absorbed in η_e. This condition says exactly that each middle-edge rectangle has the required endpoint characters, up to an edge-specific scalar. It is an equality of actual complex weights, not a choice of phase notation. It allows arbitrary complex amplitudes; there is no positivity or bounded-coefficient assumption.

Additionally require **fiber coverage**: for every i,j,t there is at least one path X_j→u→v→Y_i whose middle edge has τ(e)=t. Any repaired Gauss fiber law of the form

    Σ_{e:τ(e)=t} C[i,v]B_eA[u,j]
      = λ_ij ζ^(-t²/2+(i+j)t+ρ_i+σ_j),     λ_ij≠0,              (F)

implies coverage. The edge lower bound needs only coverage, not the amplitude identity, its t-independence, or separability of λ_ij. To recover Fourier using only endpoint gauges, the stronger (F) must still have λ_ij=a_i' b_j', or a separately charged correction. The theorem does not grant that for free.

## 2. Local rigidity

**Lemma 1.** If |J_u|≥2, all active middle edges leaving u have the same coordinate. Dually, if |I_v|≥2, all active middle edges entering v have the same coordinate.

**Proof.** Take distinct j,j'∈J_u and an edge e=(u,v) with coordinate t. Choose any i∈I_v. Dividing (P) for j and j' gives

    A[u,j]/A[u,j'] = (b_j/b_j') ζ^((j-j')t).

For another active edge leaving u, with coordinate s, the same quotient gives ζ^((j-j')(t-s))=1. Since p is prime and j≠j', t=s. Nonzero complex amplitudes cancel in this argument. The output argument is identical. ∎

Call U vertices with |J_u|≥2 and V vertices with |I_v|≥2 **mixed**. Every mixed vertex therefore belongs to one coordinate. Singleton U vertices have exactly one distinct input neighbor; singleton V vertices have exactly one distinct output neighbor.

## 3. Sharp edge bound

**Theorem 2.** Under (P) and fiber coverage, E≥2p²+p. This holds for every prime p≥2 for arbitrary character fibers; the Gauss specialization uses odd p.

**Proof.** Let s be the number of outer edges incident to singleton U or singleton V vertices. All other edges can be charged to a unique coordinate: charge a middle edge to its label, each input edge at a mixed U to that U's coordinate, and each output edge at a mixed V to that V's coordinate. Thus

    E = s + Σ_t L_t,

where L_t is the charged count for coordinate t.

For a fixed t, take its charged subgraph together with its singleton outer attachments. Contract each singleton U to its input and each singleton V to its output, and delete those singleton attachment edges. The resulting multigraph has all 2p terminals and k_t mixed internal vertices. Its edge count is exactly L_t. Coverage supplies a directed path between every input and every output. Every retained internal vertex lies on such a path. Consequently its underlying undirected multigraph is connected.

If k_t≥2, connectedness gives L_t≥2p+k_t−1≥2p+1. If k_t=1, it gives L_t≥2p. If k_t=0, all remaining edges go directly from inputs to outputs; coverage requires at least p² such edges, and p²≥2p for p≥2. Hence L_t≥2p always.

There are two exhaustive cases.

1. Every t has k_t≥2. Then E≥Σ_t(2p+1)=2p²+p.
2. Some t has k_t≤1. That coordinate has no mixed U or no mixed V. In the former case coverage requires a singleton U attached to each of the p distinct inputs; in the latter, a singleton V attached to each of the p distinct outputs. In either case s≥p, and E≥p+Σ_t2p=2p²+p.

No path multiplicity has been charged as arithmetic work. Only actual edges were counted. ∎

### Parallel outer edges

For the symbolic phase-label variant in §5, count all parallel outer edges. Contract a singleton vertex using one attachment and delete any other parallel attachments at that singleton as well. All those deleted edges are included in s, while the remaining charged graph still has exactly L_t edges. The proof is unchanged. The actual-weight formulation above intentionally uses ordinary matrix entries at the outer layers and does not need this qualification.

## 4. Tight construction and full cost ledger

For odd p, take U={u_t} and V={v_t}, one vertex of each kind for every t. Use

    A[t,j]=ζ^(jt),   B_{v_t,u_t}=ζ^(-t²/2),   C[i,t]=ζ^(it).

There are p²+p+p²=2p²+p edges. Each (i,j,t) has exactly one path and its weight is ζ^(-t²/2+(i+j)t). Thus (P) holds with a_i=b_j=1 and η_e=ζ^(-t²/2), and (F) holds with λ_ij=1.

Define G=Σ_tζ^(-t²/2). Completing the square yields

    Σ_t ζ^(-t²/2+(i+j)t)=G ζ^((i+j)²/2).

Also |G|²=p: put t=u+h in the product with its complex conjugate; the inner sum over u is p for h=0 and zero otherwise. Hence G≠0. Fold ζ^(-j²/2) into each corresponding input edge and G^(-1)ζ^(-i²/2) into each corresponding output edge. The resulting 2p²+p-edge graph computes every unnormalized Fourier output for arbitrary fresh inputs. The endpoint factors preserve (P), with new a_i,b_j.

Supported lengths: the dense construction and square-completion identity work for every odd N, including odd composites. The sharp obstruction is proved here for primes. No even-length reduction or all-length sparse construction is asserted.

Accounting, in a supplied-primitive-root exact-complex arithmetic model:

- Actual core and corrected graph edges: exactly 2p²+p, with endpoint gauges folded into edge weights.
- Explicit coefficient preparation: O(p²) arithmetic/indexing operations and writes. A root-power table, quadratic chirps, Gauss sum and its inverse need O(p) arithmetic operations; preparing all corrected edge weights is quadratic.
- Evaluation: O(p²) scalar arithmetic operations, with every edge charged. Edges of weight one may save a scalar multiplication, but not the literal edge count; this is not a lower bound for all possible arithmetic restructurings.
- Literal graph storage: O(p²) edge records/coefficients. A nested-loop implementation can generate the weights from O(p) root/chirp tables and use O(p) live complex values for input, the current layer, accumulators, and output. This storage statement includes an actual evaluation schedule rather than inferring it from implicit adjacency.
- Input/output writes: Θ(p), in addition to coefficient preparation and evaluation.
- Bit work: no unit-cost finite-word or bit-complexity claim. Exact arbitrary complex inputs have no prescribed finite encoding. Cyclotomic-coordinate control arithmetic below is a finite exact test representation, not a bound of O(p²) machine-word work for arbitrary exact inputs.

This is the existing dense identity, now shown optimal within the precisely stated pointwise middle-edge candidate. It is not a faster Fourier algorithm.

## 5. The explicit discrete phase grammar is also covered

Alternatively, assign formal exponents to all graph edges and require every path through e=(u,v) to obey

    α_uj + β_e + γ_iv
       = q(t)+(i+j)t+ρ_i+σ_j  (mod p),     t=τ(e).               (L)

Subtracting two input indices proves Lemma 1 directly, as does subtracting two output indices. Therefore coverage and (L) also imply the same sharp edge bound, regardless of any separately attached amplitude factors.

If amplitudes are arbitrary complex numbers, (L) must be treated as an **explicit label-certificate assumption**, not the intrinsic phase of a complex weight: a decomposition w_e=γ_eζ^α_e is noncanonical. In particular, the mere ability to write weights in that form provides no restriction and no lower bound. With positive-real amplitudes, (L) is an actual phase condition modulo p when the roots are fixed. The actual-complex hypothesis (P) avoids that ambiguity altogether.

## 6. Essential scope controls

### Aggregate fibers can mix incompatible characters at a vertex

Take A=F_p, with A[t,j]=ζ^(tj). Let C=I+E_{0,1}; its inverse is I−E_{0,1}. For each t write χ_t=(ζ^(it))_i and define a middle-edge slice

    B_t=ζ^(-t²/2) (C^(-1)χ_t) e_t^T.

Each nonzero entry of B_t is a middle edge labeled t. Since its nonzero entries lie in column t, distinct slices have disjoint middle-edge identities. Then

    C B_t A = ζ^(-t²/2) χ_t χ_t^T

exactly. All aggregate fibers have amplitude one. However V vertex 1 has output neighbors 0 and 1 with equal outgoing weights and receives edges for every t. Its two-output ratio is 1. If (P) held for any fixed gauges, it would force 1=(a_0/a_1)ζ^(-t) for every t. The t=0 edge forces a_0/a_1=1, while t=1 then contradicts primitivity. Thus no choice of fixed endpoint gauges repairs (P), and no use of Lemma 1 is legitimate for this graph.

This is an exact-complex scope counterexample to inferring the pointwise condition from the weighted-fiber identity. It is not a numerical fit. Its counts happen to be p² input edges, p+1 output edges and p²−1 middle edges, totaling the same 2p²+p. Thus it is not a counterexample to the edge inequality itself or a sparse construction. Its purpose is to locate the genuine escape route: cancellation within a coordinate fiber can defeat the local character rigidity.

### Composite rigidity fails

At N=9, a first-layer vertex may have input neighbors {0,3,6} while serving middle labels {0,3,6}, because every product of differences is divisible by 9. More generally, subtracting phase identities gives

    (j−j')(t−t')=0 mod N.

If D is the subgroup generated by input-index differences, J_u lies in a coset of D and the active labels lie in a coset of its annihilator D^⊥. Consequently |J_u|·|T_u|≤N. For prime N this gives singleton labels whenever |J_u|≥2; composite N need not. This local statement does not establish a composite global lower bound.

## 7. Fresh controls and provenance

`fresh_resolved_fiber_controls.py` is independently written, uses only the Python standard library, and imports or executes no uploaded/source research code. It performs:

- exact cyclotomic quotient-ring verification of the complete dense Gauss fibers and gauged Fourier identity;
- exact aggregate-fiber shear controls showing that (F) does not imply (P);
- exhaustive prime character-difference checks and the explicit composite counterexample;
- bounded exhaustive support minimization in a stated canonical family with shared singleton vertices and at most one mixed U and one mixed V per coordinate, including sharp witnesses at p=2,3;
- deterministic graph-family controls for the combinatorial charging argument.

Finite tests are controls, not the proof of the theorem. The theorem is the argument in §§2–3. The written proof and this script are fresh local deliverables; all accepted source files are left unchanged.

## 8. Source and next decisive question

The starting obligations were read from `new_source_audit/TECHNICAL_AUDIT_v2.md`, its public export, and the complete Gauss proposal. A targeted primary-source search also checked Alon–Pudlák's published depth-three superconcentrator result: https://www.sciencedirect.com/science/article/pii/S0022000005800273 and the author-hosted paper https://www.cs.tau.ac.il/~nogaa/PDFS/super2.pdf . That theorem supplies a support scale, not the pointwise or aggregate Fourier phases here. No historical novelty conclusion follows from this narrow search.

The decisive next question is now narrower: **can cancellation among several incompatible character rectangles within each single latent-t fiber give exact amplitude-one Gauss fibers on o(p²) total edges?** A candidate must exhibit its matrices A,C and disjointly middle-edge-supported slices B_t, prove C B_t A=ζ^(-t²/2)χ_tχ_t^T for every t, and charge preparation, storage and evaluation. Simply assigning the right character to every individual middle-edge rectangle is now a closed route at depth three.
