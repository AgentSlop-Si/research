#!/usr/bin/env python3
"""Independent exact basis controls. No nonstandard or research-code imports."""
import itertools
from fractions import Fraction
import json
from pathlib import Path

class Ring:
    def __init__(self,p):
        self.p=p; self.z=(0,)*(p-1); self.o=(1,)+(0,)*(p-2)
    def add(self,x,y): return tuple(a+b for a,b in zip(x,y))
    def neg(self,x): return tuple(-a for a in x)
    def sub(self,x,y): return self.add(x,self.neg(y))
    def mul(self,x,y):
        a=[0]*self.p
        for i,c in enumerate(x):
            for j,d in enumerate(y): a[(i+j)%self.p]+=c*d
        return tuple(c-a[-1] for c in a[:-1])
    def root(self,k):
        k%=self.p
        if k==self.p-1: return (-1,)*(self.p-1)
        a=[0]*(self.p-1); a[k]=1; return tuple(a)
    def total(self,xs):
        y=self.z
        for x in xs:y=self.add(y,x)
        return y

def identity(K):return [[K.o if i==j else K.z for j in range(K.p)] for i in range(K.p)]
def matmul(K,A,B):
    return [[K.total(K.mul(A[i][k],B[k][j]) for k in range(K.p))
             for j in range(K.p)] for i in range(K.p)]
def nnz(K,A):return sum(v!=K.z for row in A for v in row)
def fourier(K):return [[K.root(i*j) for j in range(K.p)] for i in range(K.p)]
def shear(K,i,j,k):
    A=identity(K); Ai=identity(K)
    A[i][j]=K.root(k); Ai[i][j]=K.neg(K.root(k))
    assert matmul(K,A,Ai)==identity(K)
    return A,Ai

def verify_slices(K,A,C,R,S):
    p=K.p; half=pow(2,-1,p); edges=0; checks=0
    for t in range(p):
        B=[[K.mul(K.root(-half*t*t),K.mul(R[v][t],S[t][u])) for u in range(p)] for v in range(p)]
        edges+=nnz(K,B)
        actual=matmul(K,matmul(K,C,B),A)
        expected=[[K.root(-half*t*t+(i+j)*t) for j in range(p)] for i in range(p)]
        assert actual==expected; checks+=p*p
    return edges,checks

def run():
    one_sided=[]; two_sided=[]; checks=0
    for p in [3,5,7]:
        K=Ring(p); F=fourier(K)
        C,Ci=shear(K,0,1,0); R=matmul(K,Ci,F); S=identity(K)
        middle,c=verify_slices(K,F,C,R,S); checks+=c
        E=nnz(K,F)+nnz(K,C)+middle
        assert E==2*p*p+p and nnz(K,R)==p*p-1
        one_sided.append({'p':p,'edges':E,'middle_edges':middle})
        for shift in range(3):
            A,Ai=shear(K,1,0,shift); C,Ci=shear(K,0,1,shift+1)
            R=matmul(K,Ci,F); S=matmul(K,F,Ai)
            assert matmul(K,C,R)==F and matmul(K,S,A)==F
            middle,c=verify_slices(K,A,C,R,S); checks+=c
            rs=[sum(R[i][t]!=K.z for i in range(p)) for t in range(p)]
            ss=[sum(S[t][j]!=K.z for j in range(p)) for t in range(p)]
            assert middle==sum(r*s for r,s in zip(rs,ss))
            delta=nnz(K,Ai)-nnz(K,A)+nnz(K,Ci)-nnz(K,C)
            penalty=sum((r-1)*(s-1) for r,s in zip(rs,ss))
            E=nnz(K,A)+nnz(K,C)+middle
            lower=2*p*p+p+penalty-delta
            assert E>=lower
            two_sided.append({'p':p,'shift':shift,'edges':E,'mixing_penalty':penalty,
                              'inverse_expansion':delta,'lower_bound':lower})
    # Exact p=3 inverse-expanding bidiagonal witness a=b=-1.
    K=Ring(3); F=fourier(K); C=identity(K); Ci=identity(K)
    C[1][0]=K.neg(K.o); C[2][1]=K.neg(K.o)
    Ci[1][0]=K.o; Ci[2][1]=K.o; Ci[2][0]=K.o
    assert matmul(K,C,Ci)==identity(K)
    D=matmul(K,Ci,F)
    middle,c=verify_slices(K,F,C,D,identity(K)); checks+=c
    assert (nnz(K,C),nnz(K,Ci),nnz(K,D))==(5,6,7)
    assert 9+nnz(K,C)+middle==21
    # Nonvanishing diagonal is necessary for inverse-no-denser rank-one claim.
    U=[1,1,1]; V=[-1,1,1]
    rankC=[[tuple(Fraction(int(i==j)+U[i]*V[j])*x for x in K.o) for j in range(3)] for i in range(3)]
    rankCi=[[tuple((Fraction(int(i==j))-Fraction(U[i]*V[j],2))*x for x in K.o) for j in range(3)] for i in range(3)]
    assert matmul(K,rankC,rankCi)==identity(K)
    rankD=matmul(K,rankCi,F)
    assert (nnz(K,rankC),nnz(K,rankCi),nnz(K,rankD))==(8,9,9)
    forbidden_checks=0
    for a_exp in range(3):
        for r,s in itertools.combinations(range(3),2):
            a=K.root(a_exp); b=K.add(K.root(r),K.root(s))
            assert K.mul(a,b)!=K.root(r+s)
            forbidden_checks+=1
    answer={'status':'PASS','source_code_imported_or_executed':False,
            'arithmetic':'Exact integer cyclotomic quotient ring; no finite-field inference.',
            'complete_fiber_entry_checks':checks,'one_sided_shears':one_sided,
            'two_sided_examples':two_sided,
            'rank_one_diagonal_scope_control':{'C_nonzeros':8,'C_inverse_nonzeros':9,'C_inverse_F_nonzeros':9,'edges':26},
            'bidiagonal_p3':{'C_nonzeros':5,'C_inverse_nonzeros':6,'C_inverse_F_nonzeros':7,
                             'edges':21,'forbidden_three_zero_checks':forbidden_checks}}
    Path(__file__).with_name('FRESH_BASIS_RESULTS.json').write_text(json.dumps(answer,indent=2)+'\n')
    print(json.dumps(answer,indent=2))
if __name__=='__main__':run()
