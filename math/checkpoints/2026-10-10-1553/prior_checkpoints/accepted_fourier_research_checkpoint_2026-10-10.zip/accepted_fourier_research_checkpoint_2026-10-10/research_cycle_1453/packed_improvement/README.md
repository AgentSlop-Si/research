# Completed candidate: phase-separated packed response tables

Status: **independently accepted at proof level**, with the scope below. The
construction file remains frozen at SHA256
`be8de35159ed47f2a5d0bad71937d83bb7053ef83ae6ce358c0dfd80add78ded`.
Its contemporaneous “pending independent review” wording is superseded only by
the separate hash-pinned review, not by an edit to the construction.

## Deliverables

- `SPLIT_TABLE_CONSTRUCTION.md`: complete construction, dense-key Cartesian expansion lemma, charged operations, all-input error, model/fallback scope, and exact table counts.
- `CONTROL_SCOPE.md`: executed-control coverage, limitations, and local-map non-equivalence witness.
- `check_split_tables.py`: newly authored standalone controls, standard library only.
- `CONTROL_RESULTS.json`, `CONTROL_STDOUT.txt`: final successful run.
- `IMMUTABLE_SOURCE_HASHES.txt`: the four read-only sources; all hashes rechecked successfully after the work.
- Independent review: `../packed_adversarial/SPLIT_TABLE_INDEPENDENT_REVIEW.md`, with its separate controls and hash pin.

## What improved

With R=2^b and S=R^P, old packed response storage is

    (Q-1)S^2+dS.

New packed response storage plus explicitly counted scalar helpers is

    S^2+(Q-1+d)S+QR+R^2.

A phase-dependent unary table is followed by a phase-independent Hadamard table.
An explicit digit odometer maintains keys and responses, paying masks, shifts,
lookups, writes, initialization, scalar helpers, and coefficient certificates.
Dyadic **table/coefficient preparation** is O(N^(1/8)) under the unchanged
low-precision guard. Input scanning/packing and output still cost O(N), and
complete cold transform time remains O(N(t+log log N)). Total space stays O(N).

The extra product rounding fits an all-input stage bound of
3u||z||+2sqrt(2N)tau and global relative error at most
22u(v+1)<2^-t. State width, exponent range, and output lattice are preserved.
Both intermediate and final clipping are excluded for reachable execution.

## Boundaries

- No coefficient-alphabet elimination is claimed; Q remains.
- No stronger asymptotic transform-time result is claimed.
- Large stages now need two lookups rather than one; no benchmark was made.
- The all-length compiler can use the new backend, but retains its own separate preparation charges. O(N^(1/8)) is not an all-length total-preparation claim.
- The unchanged t=2 first guard threshold remains N=2^5120. Even the improved table there exceeds 2^640 entries.
- Growing log-N words, unit-cost word arithmetic, finite represented inputs and normwise approximation are essential. No fixed-hardware, exact arbitrary-complex, coordinatewise relative-error, or correctly rounded claim follows.
- Extra rounding changes local responses. An exact valid-coefficient witness rejects universal bitwise identity of the local maps; the error proof supplies the replacement contract.
- Persistent packed FFT arrays and charged lookup preparation have prior art. No external priority claim is made.

Final controls: 51 complete Cartesian tables / 145,892 entries; 1,700 exact
packed-versus-scalar toy executions; 127,372 catalogue identities; all passed.
The independent reviewer also passed 6,400 separately authored table controls.
All source files stayed immutable; no external writes were made.
