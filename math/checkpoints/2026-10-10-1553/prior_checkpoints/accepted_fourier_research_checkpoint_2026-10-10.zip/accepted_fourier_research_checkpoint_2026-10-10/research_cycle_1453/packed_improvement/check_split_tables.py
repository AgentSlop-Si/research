#!/usr/bin/env python3
"""Fresh exact controls for split finite-state FFT tables, 2026-10-10.
No research/source programs are imported or executed. Not a performance test.
"""
from fractions import Fraction as F
from math import isqrt
import json
import random
from pathlib import Path

COUNTS = {}

def mark(name, amount=1):
    COUNTS[name] = COUNTS.get(name, 0) + amount

def pack_fields(parts):
    word = 0
    for value, offset, width in parts:
        assert 0 <= value < (1 << width)
        word |= value << offset
    return word


def build_cartesian(radix, groups, fields, local):
    """Complete table with arbitrary nonoverlapping input/output field positions.
    fields(i,digit) returns input field list; local(i,digit) output field list.
    Maintain actual key/output by replace-on-change. No prewritten table builder.
    """
    size = radix ** groups
    digits = [0] * groups
    key = 0
    value = 0
    input_masks, output_masks = [], []
    used_input = used_output = 0
    for i in range(groups):
        ip, op = fields(i, 0), local(i, 0)
        im = sum(((1 << w) - 1) << p for _, p, w in ip)
        om = sum(((1 << w) - 1) << p for _, p, w in op)
        assert used_input & im == 0 and used_output & om == 0
        used_input |= im
        used_output |= om
        input_masks.append(im)
        output_masks.append(om)
        key |= pack_fields(ip)
        value |= pack_fields(op)
    table = [None] * size
    changed = 0
    for iteration in range(size):
        assert 0 <= key < size
        assert table[key] is None
        table[key] = value
        if iteration + 1 == size:
            break
        i = 0
        while True:
            digits[i] += 1
            carry = digits[i] == radix
            if carry:
                digits[i] = 0
            key = (key & ~input_masks[i]) | pack_fields(fields(i, digits[i]))
            value = (value & ~output_masks[i]) | pack_fields(local(i, digits[i]))
            changed += 1
            if not carry:
                break
            i += 1
    expected = sum((size - 1) // (radix ** i) for i in range(groups))
    assert changed == expected and changed < 2 * size
    assert all(x is not None for x in table)
    mark('cartesian_tables')
    mark('cartesian_entries', size)
    mark('odometer_field_group_updates', changed)
    return table


def check_cartesian_general():
    for width in (1, 2, 3):
        radix = 1 << width
        for groups in (1, 2, 3, 4):
            for reverse in (False, True):
                perm = list(range(groups))[::(-1 if reverse else 1)]
                def fields(i, z):
                    return [(z, width * perm[i], width)]
                def local(i, z):
                    return [((z*z + 3*i + 1) % radix, width*i, width)]
                tab = build_cartesian(radix, groups, fields, local)
                for key, result in enumerate(tab):
                    expected = 0
                    for i in range(groups):
                        z = (key >> (width*perm[i])) & (radix-1)
                        expected |= ((z*z+3*i+1) % radix) << (width*i)
                    assert result == expected
                    mark('arbitrary_map_responses_checked')


# Tiny total complex alphabet: two 2-bit signed component codes.
# Codes 0,1,2,3 represent 0,+1,-1,0, respectively; code 3 is malformed.
# Truncation/upper clipping canonicalizes all output component codes.
B = 4
RADIX = 1 << B
VALUES = (F(0), F(1), F(-1), F(0))
TOY_Q = 8
COEFF = [(F(1), F(0)), (F(3,4), F(-3,4)), (F(0), F(-1)),
         (F(-3,4), F(-3,4)), (F(-1), F(0)), (F(-3,4), F(3,4)),
         (F(0), F(1)), (F(3,4), F(3,4))]
SCALE = F(3, 4)

def decode(z):
    return VALUES[z & 3], VALUES[(z >> 2) & 3]

def encode(z):
    def comp(x):
        return 0 if abs(x) < 1 else (1 if x > 0 else 2)
    return comp(z[0]) | (comp(z[1]) << 2)

def cmul(a, b):
    return a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0]

def hadd(a, b):
    return ((SCALE*(a[0]+b[0]), SCALE*(a[1]+b[1])),
            (SCALE*(a[0]-b[0]), SCALE*(a[1]-b[1])))

def scalar_tables():
    mul = [[encode(cmul(c, decode(z))) for z in range(RADIX)] for c in COEFF]
    had = []
    for b in range(RADIX):
        for a in range(RADIX):
            x, y = hadd(decode(a), decode(b))
            had.append(encode(x) | (encode(y) << B))
    mark('scalar_helper_entries', TOY_Q*RADIX + RADIX**2)
    return mul, had


def pair_input_fields(i, z, positions):
    x, y = positions[i]
    return [(z & (RADIX-1), B*x, B), (z >> B, B*y, B)]


def packed_tables(P, mul, had):
    d = P.bit_length()-1
    g = TOY_Q.bit_length()-1
    S = RADIX**P
    product = []
    patterns = []
    for s in range(1, g+1):
        for h in range(1 << (s-1)):
            phases = [TOY_Q*(P*h+l)//(P*(1<<s)) for l in range(P)]
            patterns.append(phases)
            tab = build_cartesian(RADIX, P,
                lambda i,z: [(z, B*i, B)],
                lambda i,z: [(mul[phases[i]][z], B*i, B)])
            product.append(tab)
    positions = [(i,P+i) for i in range(P)]
    def hlocal(i,z):
        ans = had[z]
        return [(ans & (RADIX-1),B*i,B), (ans>>B,B*(P+i),B)]
    hp = build_cartesian(RADIX**2, P,
        lambda i,z: pair_input_fields(i,z,positions), hlocal)
    small = []
    for ell in range(1,d+1):
        length = 1 << ell
        positions, phases = [], []
        for base in range(0,P,length):
            for j in range(length//2):
                positions.append((base+j,base+j+length//2))
                phases.append(TOY_Q*j//length)
        def slocal(i,z):
            aa,bb=z&(RADIX-1),z>>B
            ans=had[aa|(mul[phases[i]][bb]<<B)]
            left,right=positions[i]
            return [(ans&(RADIX-1),B*left,B),(ans>>B,B*right,B)]
        tab=build_cartesian(RADIX**2,P//2,
            lambda i,z: pair_input_fields(i,z,positions),slocal)
        small.append(tab)
        for key, out in enumerate(tab):
            lanes=[(key>>(B*l))&(RADIX-1) for l in range(P)]
            for base in range(0,P,length):
                for j in range(length//2):
                    phase=TOY_Q*j//length
                    left,right=base+j,base+j+length//2
                    ans=had[lanes[left]|(mul[phase][lanes[right]]<<B)]
                    lanes[left]=ans&(RADIX-1)
                    lanes[right]=ans>>B
            expected=sum(z<<(B*l) for l,z in enumerate(lanes))
            assert out==expected
            mark('small_stage_responses_checked')
    assert sum(map(len,product))+len(hp)+sum(map(len,small)) == S*S+(TOY_Q-1+d)*S
    # Independently scan literal stored key ordering, not odometer ordering.
    for pattern,tab in zip(patterns,product):
        for key,out in enumerate(tab):
            expected=sum(mul[pattern[l]][(key>>(B*l))&(RADIX-1)]<<(B*l) for l in range(P))
            assert out==expected
            mark('unary_packed_responses_checked')
    for key,out in enumerate(hp):
        lo,hi=key&(S-1),key>>(B*P)
        el=eh=0
        for l in range(P):
            aa=(lo>>(B*l))&(RADIX-1)
            bb=(hi>>(B*l))&(RADIX-1)
            z=had[aa|(bb<<B)]
            el|=(z&(RADIX-1))<<(B*l)
            eh|=(z>>B)<<(B*l)
        assert out==el|(eh<<(B*P))
        mark('hadamard_packed_responses_checked')
    return product,hp,small


def reverse(i,v):
    out=0
    for _ in range(v):
        out=(out<<1)|(i&1)
        i>>=1
    return out

def scalar_execute(codes,mul,had):
    n=len(codes); v=n.bit_length()-1
    z=[codes[reverse(i,v)] for i in range(n)]
    for ell in range(1,v+1):
        length=1<<ell
        for base in range(0,n,length):
            for j in range(length//2):
                aa=z[base+j];bb=z[base+j+length//2]
                phase=TOY_Q*j//length
                out=had[aa|(mul[phase][bb]<<B)]
                z[base+j]=out&(RADIX-1)
                z[base+j+length//2]=out>>B
    return z

def packed_execute(codes,P,tables):
    product,hp,small=tables
    assert all(0<=z<RADIX for z in codes)
    n=len(codes);v=n.bit_length()-1;d=P.bit_length()-1;g=TOY_Q.bit_length()-1
    words=[0]*(n//P); mask=(1<<(B*P))-1
    for i,code in enumerate(codes):
        target=reverse(i,v)
        words[target>>d]|=code<<(B*(target&(P-1)))
    for ell in range(1,v+1):
        if ell<=d:
            words=[small[ell-1][z] for z in words]
        else:
            r=ell-d;s=min(r,g);shift=max(r-g,0)
            baseid=(1<<(s-1))-1;span=1<<r;half=span//2
            for base in range(0,len(words),span):
                for a in range(half):
                    ident=baseid+(a>>shift)
                    for lane in range(P):
                        actual=TOY_Q*(P*a+lane)//(P*(1<<r))
                        catalogue=TOY_Q*(P*(a>>shift)+lane)//(P*(1<<s))
                        assert actual==catalogue
                        mark('catalogue_lane_identities')
                    b1=product[ident][words[base+a+half]]
                    out=hp[words[base+a]|(b1<<(B*P))]
                    words[base+a]=out&mask
                    words[base+a+half]=out>>(B*P)
    return [(words[i>>d]>>(B*(i&(P-1))))&(RADIX-1) for i in range(n)]


def check_executions(packings=(1,2)):
    mul,had=scalar_tables()
    rng=random.Random(145310)
    for P in packings:
        tables=packed_tables(P,mul,had)
        # All 2-input code vectors, including malformed component codes.
        for aa in range(RADIX if P<=2 else 0):
            for bb in range(RADIX):
                codes=[aa,bb]
                assert packed_execute(codes,P,tables)==scalar_execute(codes,mul,had)
                mark('packed_scalar_executions')
        for v in range(2,8):
            n=1<<v
            samples=[[0]*n,[RADIX-1]*n,[1]*n,[1 if i%2 else 2 for i in range(n)],
                     [1]+[0]*(n-1),[min(4,RADIX-1)]+[0]*(n-1)]
            samples += [[rng.randrange(RADIX) for _ in range(n)] for _ in range(60)]
            for codes in samples:
                assert packed_execute(codes,P,tables)==scalar_execute(codes,mul,had)
                mark('packed_scalar_executions')


def qfloat(x,p,emin,emax):
    if not x:
        return F(0)
    sign=1 if x>0 else -1
    a=abs(x)
    def pow2(e):
        return F(1<<e) if e>=0 else F(1,1<<(-e))
    if a<pow2(emin):
        return F(0)
    if a>=pow2(emax+1):
        return sign*F((1<<(p+1))-1)*pow2(emax-p)
    e=a.numerator.bit_length()-a.denominator.bit_length()
    if a<pow2(e):
        e-=1
    quantum=pow2(e-p)
    return sign*(a//quantum)*quantum


def falsify_bitwise_equivalence():
    # Legitimate accepted p for N=8, t=2; root is phase 1/8.
    v,t=3,2
    p=t+10+v.bit_length() # ceil(log2(v+1)) = 2 here
    assert p==14
    H=p+10
    sh=F(isqrt(1<<(2*H-1)),1<<H)
    # Exact certification sh <= 1/sqrt(2) < sh+2^-H.
    assert sh*sh<=F(1,2)<(sh+F(1,1<<H))**2
    coeff=(sh,-sh)
    quant=lambda z: tuple(qfloat(x,p,-v-p,v+4) for x in z)
    rng=random.Random(314159)
    for attempt in range(10000):
        def state():
            mant=(1<<p)+rng.randrange(1<<p)
            expo=rng.randrange(-3,4)
            return F(rng.choice((-1,1))*mant,1<<p)*(F(1<<expo) if expo>=0 else F(1,1<<(-expo)))
        a=(state(),state());b=(state(),state())
        cb=cmul(coeff,b)
        def finish(term):
            return (quant((sh*(a[0]+term[0]),sh*(a[1]+term[1]))),
                    quant((sh*(a[0]-term[0]),sh*(a[1]-term[1]))))
        old=finish(cb);new=finish(quant(cb))
        mark('bitwise_counterexample_trials')
        if old!=new:
            return {'N':8,'t':2,'p':p,'coefficient_real_and_s_hat':str(sh),
                    'coefficient_imag':str(-sh),'phase':'1/8',
                    'a':list(map(str,a)),'b':list(map(str,b)),
                    'one_rounding':[[str(z) for z in pair] for pair in old],
                    'split_rounding':[[str(z) for z in pair] for pair in new]}
    raise AssertionError('Failed to find rounding-noncommutation witness')


def ceil_log2(n):
    return (n-1).bit_length()

def threshold_counts():
    rows=[]
    for t,expected in ((2,5120),(8,5888),(16,6912),(53,11904)):
        for v in range(max(1,t-1),expected+1):
            p=t+10+ceil_log2(v+1)
            k=ceil_log2(2*v+p+6)
            b=2*(p+k+1)
            mark('guard_parameter_tests')
            if 64*b<=v:
                break
        assert v==expected
        P=1
        while 2*b*(2*P)<=v//8:
            P*=2
        assert P==4
        d=P.bit_length()-1;g=p+10;Q=1<<g;R=1<<b;S=1<<(b*P)
        old=(Q-1)*S*S+d*S
        new=S*S+(Q-1+d)*S+Q*R+R*R
        assert 1<<(g+2*b*P-1)<old<1<<(g+2*b*P)
        assert 1<<(2*b*P)<new<1<<(2*b*P+1)
        rows.append({'t':t,'v':v,'p':p,'b':b,'g':g,'P':P,
                     'old_floor_log2':old.bit_length()-1,
                     'new_floor_log2':new.bit_length()-1,
                     'coefficient_alphabet_preserved':True})
    return rows


def main():
    global B, RADIX, COEFF
    check_cartesian_general()
    check_executions()
    # Additional real-only four-code toy supports complete P=4 tables and
    # both small-span stages; no floating-error assertion is made for it.
    B, RADIX = 2, 4
    COEFF = [(F(4-j,4),F(0)) for j in range(8)]
    check_executions((4,))
    witness=falsify_bitwise_equivalence()
    thresholds=threshold_counts()
    report={'status':'PASS','counts':COUNTS,'thresholds':thresholds,
            'falsified_claim':'The split local map equals the original one-rounding local map on every state pair.',
            'exact_counterexample':witness,
            'scope':'Exact toy layout and arithmetic controls; no source-program execution; no full theorem-parameter eager tables; no benchmark.'}
    output=Path(__file__).with_name('CONTROL_RESULTS.json')
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    main()
