# Independent exact-control record

10 October 2026. All computations here execute only the newly authored
`check_split_tables.py`, with Python standard-library dependencies. No uploaded,
source, predecessor, or archived research program was run, imported, compiled,
or translated into executable form. Frozen manuscripts were read as text.

## Final run

Command: `python research_cycle_1453/packed_improvement/check_split_tables.py`

Result: PASS. The machine-readable output is `CONTROL_RESULTS.json`; the final
stdout is preserved in `CONTROL_STDOUT.txt`.

- 51 complete Cartesian tables, 145,892 entries written exactly once
- 152,715 changed digit groups, with the exact odometer count and <2*entries bound checked per table
- 10,100 responses of arbitrary independent finite maps, including reversed field placements
- 432 fully constructed scalar helper entries across two toy alphabets
- 3,696 unary packed responses checked against scalar composition
- 131,328 phase-independent Hadamard packed responses checked in literal key order
- 768 small-stage responses checked against direct scalar stage application
- 127,372 exact phase-catalogue lane identities
- 1,700 packed-versus-scalar executions through N=128, including complete length-2 code-vector enumeration, malformed codes, cancellation patterns, and P=4 with two intra-word stages
- 29,753 scalar parameter tests establish the four inherited first-guard thresholds and exact old/new entry-count power bounds

The main layout toy has a 4-bit complex alphabet with a malformed-zero alias in
each real component and exact rational coefficients. A second 2-bit real-only
alphabet permits complete P=4 tables. Neither toy claims the theorem's floating
error behavior; they isolate index/layout/table semantics. Arithmetic is exact
rational or integer arithmetic. Full-size eager tables were not allocated.

## Deliberately falsified stronger claim

A separate control uses the actual accepted floating encoding at N=8, t=2,
p=14, with a phase 1/8 coefficient and normalization constant

    s_hat = 11863283 / 16777216,
    c = s_hat * (1-i).

The exact inequalities s_hat^2 <= 1/2 < (s_hat+2^-24)^2 certify the allowed
coefficient approximation without evaluating a transcendental function.
Both input pairs in the JSON are exactly represented finite states. Direct
one-rounding and split two-rounding local maps differ. The first output real
component is -20215/8192 in the one-rounding map and -10107/4096 in the split map.
The difference is exactly 1/8192.

This falsifies bitwise equivalence of the **local maps on every state pair**.
It does not assert that the N=8 end-to-end programs take the packed branch:
they do not satisfy its guard. Nor does it establish a full-input reachable
execution counterexample between the two complete backend programs. The new
construction is justified by its separate normwise error proof, not by any
claim of bitwise identity.

## Test-development correction

The first expanded 2-bit/P=4 toy run exposed an invalid test fixture: two
sample vectors still used 4-bit-only code values. This caused an index error,
not a packed/scalar disagreement. The fixture now derives codes from its
alphabet size, and the packed executor asserts input-code validity. The full
final suite was rerun after this correction. This correction changed only the
fresh control program, not a frozen source or mathematical construction.

## Interpretation

These are mathematical falsification controls, not benchmark measurements.
They do not verify an implementation of the polynomial-time coefficient
certifier or execute the enormous literal preparation branch. The analytic
proof is needed for all-input error, asymptotic setup, and uniform fallbacks.
