# Source-grounded algebra/representation novelty audit

10 October 2026. Read-only review of the existing Google Sheet snapshots, accepted proofs, and latest staged intake. This report changes no Sheet, source, prior acceptance, or external artifact.

**Acceptance update, 15:01 UTC:** The independent reviewer reviewed the new bridge and issued a scoped PASS at the pinned theorem hash 79a5f64c11c47e39eb1fe90f7f6d51743dc9e4f1a9d89a5c505ce17835a86c0f. It checked the quantitative formulas and 16,128 additional exact integer cases. See `ROOT_INDEPENDENT_BRIDGE_REVIEW.json`. References below to a pending review record the author's original submission state; that review gate is now closed within the stated inherited-lemma dependency. External priority remains unresolved. The pinned theorem bytes are unchanged.

## Decision

**Prioritize TH-04/F018, the independently routed inverse-sum obstruction, as the strongest publishable research direction among the three requested families.** It applies to every complex flat unitary, not only the Fourier matrix. Its distinctive quantified content is an obstruction for sums whose branches have different sparse inverse graphs and independent row/column routes. Current evidence supports a specialized representation theorem with unresolved publication novelty, not a general FFT lower bound.

**C03 is a valid explicit algebraic formula with modest independent novelty significance.** Its arbitrary-matrix version is already independently accepted; reopening that audit would repeat closed work. Its mechanism is standard determinant/resultant/Newton-polygon algebra. The exact printed formula may be original, but the evidence does not establish that.

**The projective-curvature invariant is classical at its foundation.** The all-anchor exponent-determinant calculation is a specialized application. Its advertised single-Green Fourier non-equivalence is already implied by the elementary inverse-support argument below, under strictly weaker hypotheses. This does not invalidate the curvature identity; it limits the novelty attributable to that consequence.

## Authoritative current rows and closed work

The following references are to the existing Sheet, ID `1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU`, as captured in `research_sheet_1435/ALL_BOUNDED_FINAL.json` and its verification receipt. These are snapshot bindings, not a claim of a fresh live read.

| Claim | Existing row | Current status |
|---|---|---|
| TH-04 / F018 | Theorem register rows 15 / 26, gid 404576783 | Proof closed, R13/R30 |
| Q04 | Research queue row 7, gid 1877766156 | Proof closed; later Phase42 refinement already appended |
| C05 | Catalogue row 35, gid 214001001 | Historically accepted correction-inclusive one-layer obstruction |
| C03 / Q17 | Theorem register row 33 / Research queue row 20 | Proof closed, R15 |
| NEW-06 | New results row 9, gid 627764102 | Arbitrary-pencil closure already recorded |
| Primitive holonomy / classical curvature | Catalogue rows 8 / 18 | Specialized accepted calculation / classical invariant |
| Q19 | Research queue row 22 | Curvature-energy proof closed, R29; later phase-cone theorem appended |
| NF-01 | Fusion list row 12, gid 1242754826 | Classical interface; a new implication is still required |

The old Catalogue prose saying that C03's arbitrary-pencil proof awaits an independent audit is historical. Q17, R15, the current theorem register, and the exact accepted final proof supersede it. Likewise, Delvaux–Van Barel final-article comparison is already closed in the current register; this review does not reopen its old access blocker. Phase42's `N <= r(r+1)^r` result and its combined comparison with TH-04 were inspected in the 14:44 staged tree and remain accepted within their scope.

## 1. Reciprocal Hankel / diagonal-pencil resultant: C03

The exact accepted statement uses arbitrary square A,B over any commutative ring, D(w)=diag(1,w,...,w^(m-1)), and the fixed homogeneous degree-(m,m) Sylvester resultant of det(A-aDAD) and det(B-awDBD). With

    T=m^2(2m-1), v=m(m-1)(4m+1)/6, b=m(m-1)(2m-1)/6,

it proves reciprocal grade T, universal factor w^v(w-1)^(m^2), and residual form w^b V(w+w^(-1)), deg V<=b. Singular specializations and degree drops are allowed; they may increase valuation or annihilate the resultant.

The complete accepted proof is `research_cycle_0958/algebra/final_v1/PROOF_CLOSURE.md`, section A, SHA-256 f6412a2cb78457a2fddd62a6e688095cb82528b4457ad1454dbbe069179937d6. Its mixed-minor minimum, unequal Newton slopes, collision substitution, and integral reciprocal basis were read, not inferred from catalogue labels.

Primary comparison: Sturmfels, *On the Newton Polytope of the Resultant*, Theorems 2.1 and 4.1, supplies the general initial-form/extreme-term framework for monomial coefficient deformations. Nart, *Local computation of differents and discriminants*, section 3.1, Definition 3.1, explicitly uses the side contribution min(EH',E'H). The project's opposite-parity slopes remove equal-valuation cancellation. These establish classical proof mechanisms, not an exact printed match to this matrix family. Nart's local-field algorithm is not being applied outside its hypotheses.

The `b+1` reconstruction samples versus `T+1` conservative samples are useful, but both are cubic in m, with asymptotic sample ratio six. This alone does not establish an asymptotically stronger sparse-recovery algorithm. A stronger recovery theorem would have to charge node supply or field extension, resultant evaluation, candidate lifting, global validity certification, and degeneracies. **Disposition: incremental explicit formula/application; printed-formula priority undetermined.**

## 2. Fourier–Green representation: TH-04/F018 and C05

Accepted TH-04, `research_finalization_0923/matrix/FINAL_THEOREMS.md`, Theorem 2A, proves

    N <= qr*9^r+q(3^r-1),

for an exact sum of r independently routed inverse branches whose symmetric bipartite support lifts have weighted half-separators of size q. A free diagonal changes this to `4qr*9^r+2q(3^r-1)+2`. Invertible column-two matrices admit q=2. The proof's essential combination is a two-color separated rectangle selected successively across independent graphs, inverse-submatrix nullity, and flat-unitary stable rank.

Primary comparison: Vandebril–Van Barel's nullity theorem supplies the complementary inverse-rank identity. Chandrasekaran–Epperly–Govindarajan, *Graph-Induced Rank Structures*, section 2.1, Propositions 2.1–2.3, supplies inverse-rank preservation and algebraic closure. Its addition/product proposition is stated for matrices on the same graph. It does not itself state TH-04's common-rectangle selection across independently routed graph structures. Passing to the union of independent graphs need not preserve bounded separator size. This is a concrete distinction in hypotheses, not a proof of worldwide novelty.

The inspected latest Phase42 theorem gives the stronger small-r cutoff `N <= r(r+1)^r` for ordinary legal nonzero Hamiltonian cycles with independent monomial endpoints. It does not carry C05's arbitrary rank-t and row-degree-s corrections. Its asymptotic consequence is weaker than TH-04's already accepted logarithmic branch obstruction. No reopened Phase42 proof or enumeration was needed.

**Disposition: strongest specialized theorem family here; candidate application-level novelty, globally undetermined.** The unresolved correction-inclusive scope bridge is precise and tractable. It is supplied separately in `CORRECTION_COMPATIBLE_SEPARATOR_THEOREM.md` as a new derivation for independent review.

## 3. Projective curvature: what survives the novelty audit

The Phase37 accepted text proves that all anchored exponent-curvature determinants of a primitive-holonomy dyadic Green kernel are units modulo N, while Fourier's corresponding exponent matrix has rank one. The all-anchor step is a unimodular zero-sum-lattice basis change. This is a genuine explicit computation.

Primary comparison: the recent research article *Equivalence of complex Hadamard matrices* explicitly treats the four-entry Haagerup invariant and credits its introduction to Haagerup. On unit-modulus matrices its product form equals the usual cross-ratio form. Arbitrary nonzero row/column scaling cancellation follows directly from the ratio, so that broader scaling convention is not a new invariant either. The original Haagerup article's full text was not obtained in this pass; no full original-source comparison is claimed.

### Simpler stronger obstruction for the advertised consequence

Let G=(I-W)^(-1), with W a weighted permutation and I-W invertible. Then G^(-1)=I-W has at most two nonzeros in every row and column. Multiplication on either side by invertible monomial matrices preserves these support counts. If G were monomially equivalent to an N-by-N Fourier matrix with N>2, its inverse would be monomially equivalent to the inverse Fourier matrix, which has N nonzero entries in every row and column. Contradiction.

This argument requires neither dyadic size nor primitive holonomy, and permits arbitrary cycle decompositions and zero weights. Therefore the single-kernel non-equivalence consequence does not demonstrate additional representational power for curvature. Preserve the explicit all-anchor determinant as a possible diagnostic lemma, not the basis of a broad novelty claim.

Q19's later continuous energy and phase-cone results are different statements and are not refuted or subsumed by this sparse-inverse observation. Their proofs remain accepted. No novelty claim for those quantitative syntheses is cleared here.

## Precise theorem to finalize next

For a flat unitary, add an arbitrary rank-t term and a matrix with at most s nonzeros per row to TH-04's independently routed sum, optionally with a free diagonal. With delta=0 or 1 and d=s+1+delta, the draft derives

    N <= d^2(qr+t)9^r + dq(3^r-1)+2(d-1).

The only new structural step is to choose an initial `floor(N/d)`-square rectangle on which the sparse and diagonal corrections vanish, before applying the accepted two-color separator iteration. This improves the correction-inclusive asymptotic from C05's Omega(log log N) to Omega(log N) for fixed q,s,t and enlarges its routing scope. It also recovers both existing TH-04 formulas exactly at s=t=0.

**Remaining acceptance gate:** independent review of the correction-free rectangle's compatibility with independent routes and the integer threshold proof. Fresh controls pass 31,408 exhaustive small support instances, 31,360 exact integer-threshold instances, and 128 reductions to the two accepted TH-04 formulas. These corroborate the draft and do not substitute for review or priority research.

## Primary links and read depth

- [Sturmfels, original article](https://www.maths.tcd.ie/EMIS/journals/JACO/Volume3_2/m4496732732u7744.fulltext.pdf): Theorems 2.1, 4.1 and surrounding statements reopened.
- [Nart, original manuscript](https://arxiv.org/pdf/1205.1340): section 3.1 and Definition 3.1 reopened.
- [Graph-Induced Rank Structures](https://arxiv.org/html/1911.05858): section 2.1 and exact Propositions 2.1–2.3 reopened.
- [Vandebril–Van Barel, nullity note](https://www.cs.kuleuven.be/publicaties/rapporten/tw/TW397.pdf): primary note reopened; inherited comparison retained.
- [Equivalence of complex Hadamard matrices](https://link.springer.com/article/10.1007/s10801-026-01568-x): current research article's invariant discussion inspected; original Haagerup full text not obtained.

Searches did not establish an exact earlier match to the correction-inclusive independently routed theorem. A negative search is not evidence of novelty. Correctness, formula originality, conceptual significance, and publication suitability remain separate judgments.
