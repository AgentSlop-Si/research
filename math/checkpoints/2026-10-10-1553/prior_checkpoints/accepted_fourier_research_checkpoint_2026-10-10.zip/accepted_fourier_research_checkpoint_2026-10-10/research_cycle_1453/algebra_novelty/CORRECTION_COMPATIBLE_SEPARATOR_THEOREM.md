# Correction-compatible independently routed inverse sums

10 October 2026. New derivation for review. This is a scoped extension of the already accepted TH-04/F018 theorem, not a new acceptance receipt or a worldwide novelty claim. No supplied source program was executed.

## Statement

Let U be a complex N-by-N unitary matrix with every entry of modulus N^(-1/2). Let q,r >= 1, s,t >= 0 be integers. Consider

    M = delta*D + E + K + sum_{i=1}^r L_i Q_i^(-1) R_i,

where:

- delta is 0 or 1, and D is an arbitrary diagonal matrix;
- every row of E has at most s nonzero entries, with no restriction on its column degrees or coefficient sizes;
- rank(K) <= t;
- each Q_i is invertible and its symmetric bipartite support lift has a weighted half-separator of size at most q for every two-color marking required below;
- L_i and R_i have permutation-contained support, independently across branches. Their nonzero positions need not use matching row/column routes, and their values may be zero.

Put d=s+1+delta. Then exact equality U=M implies

    N <= d^2 (qr+t) 9^r + d q (3^r-1) + 2(d-1).                 (1)

In particular, for fixed q,s,t, exact representations require r=Omega(log N). This is a representation theorem for an additive grammar. It is not an unrestricted arithmetic-complexity lower bound.

For ordinary weighted-permutation Green inverses, Q_i=I-W_i has at most two nonzeros per column. The already accepted pseudoforest argument supplies q=2, including zero edge weights and arbitrary cycle decompositions. Thus (1) covers all the correction clauses of C05 while permitting independent unmatched routes.

## Dependency: the accepted two-color separator lemma

TH-04's proof supplies the following precise statement. Given equal sets of m target rows and columns, with m>=4q, one branch permits restrictions to equal sets of

    m_next = ceil((m-q)/3)

rows and columns such that its restricted inverse contribution has rank at most q. The bipartite lift marks the routed row and column positions in different vertex color classes. Previously obtained branch-rank bounds persist under further restrictions. Zero endpoint values do not break the argument.

For completeness, remove a q-vertex weighted half-separator from 2m marks. Trim each surviving color to m-q marks. Components then have total marked size at most m <= 4(m-q)/3. Group them into two sides, each of total size at least 2(m-q)/3. One cross orientation contains at least (m-q)/3 marks of each needed color. The nullity identity bounds the inverse rectangle's rank by q. This is inherited machinery, not a new lemma here.

## New bridge: first remove all sparse and diagonal corrections

Choose any p=floor(N/d) target rows A. Let F be the union of the column supports of E in these rows, together with A itself if delta=1. Then

    |F| <= (s+delta)p = (d-1)p,
    |{1,...,N} minus F| >= N-(d-1)p >= p.

Choose p target columns B outside F. On A-by-B, E vanishes, and D vanishes when present. This construction does not require bounded column degree, common branch routes, or nonzero endpoint masks. K remains and is charged by its rank t.

## Iteration and threshold

Starting from m_0=p, apply the accepted separator lemma successively to the r inverse branches. If each preceding m_j is at least 4q, the final square block has side m=m_r and rank at most

    R=qr+t.

Induction using ceil(x)>=x gives

    m_j >= p/3^j - (q/2)(1-3^(-j)).                            (2)

Write a=3^r and c=(d-1)+dq(a-1)/2. Since floor(N/d)>=(N-d+1)/d, (2) gives

    m >= (N-c)/(da).                                          (3)

Assume, towards a contradiction, that N>d^2 R a^2+2c. All selections are legal: for j<=r-1,

    m_j >= (N-d+1)/(d*3^j)-q/2
        > d R 3^(2r-j) - 1 - q/2
        >= 9q-1-q/2 >= 4q.

Also N>2c, so the lower bound in (3) is positive.

Every m-square block V of a flat unitary satisfies ||V||_F^2=m^2/N and ||V||_2<=1; consequently rank(V)>=m^2/N. If U=M, its selected block has rank at most R. Therefore (3) implies

    (N-c)^2 <= N*d^2 R a^2.

But

    (N-c)^2 - N*d^2 R a^2
      = N[N-(d^2 R a^2+2c)] + c^2 > 0,

a contradiction. Expanding 2c proves (1).

## Quantitative form

For any concrete N for which the same recurrence has m_j>=4q before each selection, the resulting block of M has rank at most R. Thus

    ||U-M||_F^2 >= max(0,m^2/N-R).

If m>R, also

    ||U-M||_2^2 >= max(0,(m^2/N-R)/(m-R)).

These follow by bounding the first R singular values of the selected U block by one and comparing its remaining singular values with the approximation error. No norm bound is assumed on E, K, the inverses, or their endpoints. For fixed q,r,s,t and N growing, the operator-error floor tends to (d*3^r)^(-1/2), and the relative Frobenius floor tends to (d*3^r)^(-1). No logarithmic branch lower bound at an arbitrary fixed positive tolerance follows from these fixed-r estimates.

## Reconciliation checks and examples

- s=t=delta=0 gives N<=qr9^r+q(3^r-1), exactly the accepted no-diagonal TH-04 formula.
- s=t=0, delta=1 gives N<=4qr9^r+2q(3^r-1)+2, exactly its accepted diagonal formula.
- For q=2, r=2, s=1, t=1, delta=1, (1) is N<=3697. C05's corresponding monotone-subsequence/Schur threshold is 85668; the new bound also allows independently unmatched routes.
- The later accepted Phase42 inequality N<=r(r+1)^r remains a better small-r result in its own nonzero Hamiltonian, uncorrected model. It is not weakened or superseded by the correction theorem.
- Fourier matrices are only one target family here. The proof works for every complex flat unitary, including other complex Hadamard matrices after normalization.

## Exact remaining gate

Independently review the new correction-free rectangle step and its compatibility with TH-04's independently routed two-color markings, then check the integer floor/threshold algebra above. The inherited separator/nullity proof is already accepted. Once this bridge is independently accepted, record it as a scope-strengthening of TH-04/F018 linked to C05, not as an additional unrelated discovery.

External priority still requires a statement-matched comparison for sparse-plus-low-rank corrections to independently routed inverse sums. This proof closes a concrete project-level scope gap; it does not establish that the extension is publication-novel.
