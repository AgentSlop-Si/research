"""Independent, standard-library controls. No source programs or source data imported."""
import itertools
import json
from pathlib import Path

base = Path(__file__).parent
counts = {"exhaustive_support_instances": 0, "integer_threshold_instances": 0,
          "accepted_formula_specializations": 0}

# Exhaustive supports, including highly unbalanced column degrees.
for n in range(1, 5):
    for s in range(0, min(n, 2) + 1):
        choices = [frozenset(c) for k in range(s + 1)
                   for c in itertools.combinations(range(n), k)]
        for rows in itertools.product(choices, repeat=n):
            for delta in (0, 1):
                d = s + 1 + delta
                p = n // d
                A = set(range(p))
                forbidden = set().union(*(rows[i] for i in A)) if A else set()
                if delta:
                    forbidden |= A
                available = [j for j in range(n) if j not in forbidden]
                assert len(available) >= p
                B = set(available[:p])
                assert all(not(rows[i] & B) for i in A)
                assert not delta or not(A & B)
                counts["exhaustive_support_instances"] += 1

# Use large exact integers: no floating-point inequalities or sampling of matrices.
examples = []
for q in range(1, 9):
    for r in range(1, 9):
        for s in range(0, 7):
            for t in range(0, 7):
                for delta in (0, 1):
                    d = s + 1 + delta
                    a, R = 3**r, q*r+t
                    twice_c = 2*(d-1)+d*q*(a-1)
                    assert twice_c % 2 == 0
                    c = twice_c // 2
                    threshold = d*d*R*a*a + twice_c
                    for extra in (1, 2, d, a, threshold+1):
                        n = threshold+extra
                        m = n//d
                        for j in range(r):
                            assert m >= 4*q
                            m = (m-q+2)//3
                        assert m*d*a >= n-c
                        assert m*m > n*R
                        counts["integer_threshold_instances"] += 1
                    if s == t == 0:
                        expected = (q*r*a*a+q*(a-1)) if not delta else (4*q*r*a*a+2*q*(a-1)+2)
                        assert threshold == expected
                        counts["accepted_formula_specializations"] += 1
                    if (q,r,s,t,delta)==(2,2,1,1,1):
                        examples.append({"q":q,"r":r,"s":s,"t":t,"delta":delta,"threshold":threshold})

result = {"status":"PASS", "checks":counts, "examples":examples,
          "scope":"Controls verify the new support-selection and integer-threshold algebra, not external novelty or an independent replay of the inherited inverse-separator theorem.",
          "source_program_execution":False}
(base/"BRIDGE_CONTROL_RESULTS.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
