# Independent review: two pencils in the improved support range

23 October 2026 UTC. **ACCEPT the narrow domain-composition addendum.** Neither accepted source theorem is modified.

Bound author object: `signed_bank_pencil_new_range_addendum_20261023_v1/ADDENDUM.md`, SHA-256 `da880d924870bc312dd8eff5ce57c5937104f1ffc7174dc191a4ddb458e190be`; author manifest `33b132b5aadb9476a452d4f844f231fc3076f741551bb376874aea02c59cbf8c`.

## Exact delta

The deterministic original-U two-pencil coefficient generator is now accepted for odd N, d>=4, **N>=6d-2**, over a field containing the supplied primitive N-th root, with characteristic not dividing N and an explicitly represented H+1-element distinct-scalar list. It returns an actual monic degree-m g in the unchanged original U with nonzero constant, ordinary squarefreeness and full original axis rank. Here m=N-d and H=d(d+1)+2m-1.

The cost remains O(N^5) field additions/multiplications, O(N^3) inversions and O(N^2) live field elements. This composes two already accepted ingredients; it does not improve the already accepted 5N/3 bank count, expected randomized coefficient cost, splitting/root-recovery cost, physical-bank application or FFT runtime.

## Complete hypothesis audit

I read the full addendum and compared the exact first-order support and old-range pencil theorem/review bytes. The first-order theorem supplies precisely the same enlarged envelope, exact fixed-divisor gcds including multiplicities, and joint c0,c1,cm independence on N>=6d-2. Its dimension lower bound is N-5d+8>=d+6, not the old 3d-2. The pencil proof never needs that old lower bound: it needs only those independent maps, gcd one after fixed-factor division, and O(N) upper dimension.

The two coprime-combination loops, multiplicity avoidance, irreducible pencils, characteristic-two separability, reciprocal determinant argument and final scalar avoidance are independent of the old 8d-10 inequality. The maximum-degree Euclid condition remains satisfied in both applications. The first pencil constructs a real auxiliary polynomial, and the second constructs an actual legal g, not merely generic existence.

Every remaining numerical use of the old range is preserved or improved:

- 2m-2-(N-1)=N-2d-1>=4d-3>0, so the actual reciprocal auxiliary witness has full axis rank.
- H-(2r+2)=d(d+1)+1>0, r=m-2, so all first-pencil trials fit the common scalar list; the combination-loop lists fit as well.
- N>2d+1, m>=2d-2 and 2(d-2)<N retain the inherited propagation, moment and disjoint axis-row conditions.
- d<=N/4 and Q>=N+1 imply 2H<(N+1)^2<=Q^2, so the same quadratic coefficient field has enough distinct scalars.

The full zero-leading slice is retained, so gcd(h0,W)=gcd(V1)=1 remains valid. The discriminant and axis-minor degree bounds do not change with the smaller support threshold. The structured q-binomial seed is not used to supply any guard; its known repeated-root counterexample is untouched.

The scalar-list interface is still substantive for arbitrary positive-characteristic infinite fields. Finite-field representation, O(Q^3) quadratic preparation and grid writes remain paid. The genuine splitting extension, actual roots, moments, amplitudes, all branch guards and full output costs are unchanged. The optional optimized choice d=floor((N+2)/6) merely uses the existing 5N/3 representation theorem with the newly available deterministic coefficient stage.

## Independent controls and binding

I freshly specialized the **reviewer-owned** pencil implementation to four strictly new-range fixtures: (N,d)=(29,5) over F233, (35,6) over F211, (51,8) over F256, and (63,10) over F4096. Each satisfies 6d-2<=N<8d-10. No author/historical scientific program was imported or executed.

The controls reconstruct the entire original U, both pencils, the actual auxiliary axis witness and every final original guard. All nonzero field inverses and exact root orders are checked; the final binary fixture verifies the F64 subfield containing q inside the actual quadratic coefficient field. Full coefficient vectors are recorded. Additional finite checks inspect the numerical margins for odd N<1000. Normal and optimized outputs are byte-identical. These are transcription controls supplementing the symbolic audit, not the all-parameter proof or physical-bank construction.

All addendum members and all 29 bound source members were hash-checked. This is a composition review, not a fresh historical-source audit. No repair is required. Broader owner status, historical novelty and all end-to-end limitations remain unchanged; the reviewer made no external writes.
