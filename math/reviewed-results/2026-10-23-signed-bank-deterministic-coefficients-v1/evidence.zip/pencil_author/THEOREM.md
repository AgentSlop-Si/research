# Deterministic guarded coefficient generation in the original signed-bank space

23 October 2026 UTC. Scientific candidate for independent review. No publication, self-acceptance, supplied-program replay, smaller bank count, efficient root-field construction, or FFT claim.

## 1. Exact scope and improvement

Retain the original gate: N odd, d>=4, N>=8d-10, m=N-d; k contains a primitive N-th root q and char(k) does not divide N. Let e=2^-1 mod N, h=4^-1 mod N, rho=q^e, C_j=q^(h j^2), and

D(z)=product_(i=2)^(d-1)(1-q^i z),
E={((C_j P(rho^j)+R(q^j))/D(q^j))_(j=0)^m : deg P<=3d-7, deg R<=d-2},
U=E^perp, U0={g in U:g(0)=0}.

All exponent fractions are inverses modulo N, not field fractions. Coefficients use the ordinary pairing. All D(q^j) are nonzero. This is the SAME original U, not a smaller artificial input class. The bank target remains the negative unnormalized Fourier matrix and the same 2m+2-bank architecture, with the same integer sign orientations, nonzero alpha roots of g, beta=1, and denominators -alpha^N.

THEOREM. Given a field containing q together with a supplied, explicitly represented list of H+1 distinct field elements, where H=d(d+1)+2m-1, one can deterministically construct a monic degree-m polynomial g in the original U such that g(0)!=0, gcd(g,g')=1, and rank X_N(g)=N. The coefficient stage takes O(N^5) field additions/multiplications, O(N^3) field inversions, and O(N^2) live field-element storage using dense elimination and polynomial Euclid. Every unsuccessful scalar trial is included. The list construction and field representation are separate, explicitly charged inputs.

For k=F_Q the unchanged quadratic coefficient field E0=F_(Q^2) has Q^2>2H, so a deterministic list exists and can be enumerated. Thus the old deterministic (H+1)^(dim U-1)-point affine search is replaced by polynomially many exact scalar tests. The pre-existing Las Vegas algorithm already takes expected O(N^3) coefficient-field work; this result does not improve that expected bound.

This is a coefficient generator, not an efficient compiler of the physical banks. The quadratic-field preparation, genuine splitting field, roots, amplitudes, weights, all outputs, and base-coordinate costs stay in the original paid ledger. In particular a generic degree-m polynomial can still require a very large splitting extension. No end-to-end polynomial-time or arithmetic advantage over Fourier/FFT evaluation follows.

## 2. Inherited exact facts, with unchanged proof dependencies

Use the all-characteristics theorem pinned in SOURCE_PINS.json, not the later bank-count improvement. Its Sections 3-5 prove, over an algebraic closure as well,

gcd(U)=t-1, gcd(U0)=t(t-1),

and independence of c0,c1,cm on U. Consequently

V0={g/[t(t-1)]:g in U0}, r=m-2,
V1={g/(t-1):g in U}, n=m-1

have gcd one; V0 has independent endpoint maps f->f(0) and f->coefficient_r(f), and has maximum degree r. V1 has maximum degree n.

For a monic g, X_N(g) has row a equal to (p_a,1,p_[-a]_N), where p_j is the coefficient vector of t^j mod g. It is polynomially defined even at g(0)=0. If f in V0 has degree r, nonzero endpoints, and gcd(f,rev_r f)=1, then g0=t(t-1)f, normalized to monic, satisfies rank X_N(g0)=N. This is the ORIGINAL reciprocal auxiliary witness argument, not a zero-node bank. It uses degree 2m-2>N-1. Every axis N-column minor has total coefficient degree at most d(d+1).

The construction below actually finds this auxiliary witness; it does not assert that the entire zero-constant slice is good.

## 3. A deterministic coprime-combination lemma

Let a be a nonzero polynomial of degree v, let b1,...,bs span a polynomial space W, and suppose gcd(a,b1,...,bs)=1. Starting at p=0, maintain d=gcd(a,p), with monic gcds. For each bi put d_new=gcd(d,bi). Choose a scalar lambda such that

gcd(a,p+lambda bi)=d_new,

then replace p and d accordingly. At the end gcd(a,p)=1.

At most v scalar values are forbidden at any step. This includes multiplicities: factor a over its coefficient field only for the PROOF. For each irreducible pi, divide a,p,bi by the pi-adic power in d_new. If pi still divides the resulting a, at least one of the resulting p,bi is nonzero modulo pi. The equation p+lambda bi=0 modulo pi has at most one scalar solution. If there is no cancellation, the pi-adic gcd multiplicity is exactly that prescribed by d_new. Each distinct irreducible contributes at most one forbidden scalar, and their number is at most v. The algorithm never factors a; it tests the displayed exact gcd equality. A list of v+1 distinct scalars therefore suffices per step.

If a nonzero linear functional phi on W must stay nonzero, first choose a basis member p with phi(p)!=0. The same induction can process every bi while additionally testing phi(p+lambda bi)!=0. At most one extra scalar is forbidden, so v+2 values suffice. The terminal gcd is still gcd(a,W)=1. Each choice is deterministic, e.g. the first successful element of the fixed list.

The lemma is not a heuristic and never discards a repeated irreducible factor without an exact gcd check. In both applications below every basis polynomial and maintained p has degree at most v=deg(a); under that explicit degree bound, dense polynomial Euclid costs O(v^2) field arithmetic and O(v) inversions per trial, uniformly including multiple roots. The abstract selection lemma alone does not bound the degrees of an arbitrary basis.

## 4. Construct the reciprocal axis witness

By endpoint independence, solve the two linear equations f0(0)=1 and coefficient_r(f0)=1 in V0. This is a consistent, paid linear solve. Let phi(f)=coefficient_r(f)-f(0), which is a nonzero functional on V0. Apply Section 3 to a=f0 and W=V0, preserving phi(p)!=0, to obtain f1 in V0 satisfying

gcd(f0,f1)=1, phi(f1)!=0.

Set F(Z,t)=f0(t)+Z f1(t). The polynomial F is irreducible in k(Z)[t]. Indeed it is primitive and linear in Z in k[t,Z]; any nontrivial factor independent of Z would divide both f0 and f1. Gauss's lemma then gives irreducibility over k(Z). Its degree is r and its constant coefficient is nonzero over that field.

If F and rev_r F had a common factor over k(Z), irreducibility and equal degrees would give rev_r F=lambda(Z) F. Reversing again gives lambda(Z)^2=1, hence lambda=+1 or -1, with the two identical in characteristic two. Either identity would force the endpoint pairs of f0 and f1 to be dependent. Explicitly the determinant f0(0) coefficient_r(f1)-coefficient_r(f0) f1(0)=phi(f1) is nonzero. Contradiction. Therefore

Res_t(F,rev_r F) != 0 in k[Z].

This resultant has Z-degree at most 2r. The product with F(Z,0) and coefficient_r(F) has degree at most 2r+2. Test at most 2r+3 distinct scalars; for each test endpoints and gcd(F,rev_r F), without computing a symbolic resultant. At least one succeeds. Divide by its nonzero leading coefficient to obtain monic f in V0. It has nonzero constant and gcd(f,rev_r f)=1. Therefore g0=t(t-1)f is a monic original-U axis witness.

All trials fit within the common H+1-element list since H>=2r+2. Also f(1)!=0: if f(1)=0 then rev_r f(1)=0, contradicting coprimality. Thus the auxiliary g0 has a simple fixed root 1, although no squarefreeness of f is required.

## 5. A second pencil meets EVERY original guard

Let h0=t f, a monic degree-n member of V1. Define W={h in V1:coefficient_n(h)=0}. Since h0 is monic, V1=k h0+W, and consequently gcd(h0,W)=gcd(V1)=1. Compute a basis of W and apply Section 3 without the extra functional to obtain h1 in W such that gcd(h0,h1)=1. In particular h1(0)!=0 because h0(0)=0.

Now put

h_Z=h0+Z h1, g_Z=(t-1)h_Z.

For every scalar Z, g_Z is monic of degree m and lies in the SAME U. The pencil h_Z is irreducible over k(Z) by the coprime-pair argument. Its ordinary derivative is not identically zero: the constant coefficient of h0' is f(0)!=0, so the coefficient of t in h_Z is a nonzero polynomial in Z, including in characteristic two. Thus h_Z is separable over k(Z). Since gcd(h0,h1)=1, h_Z(1) is not identically zero (in fact h0(1)=f(1)!=0). Hence g_Z is squarefree over k(Z).

Furthermore g_Z(0)=-Z h1(0) is a nonzero degree-one polynomial in Z. At Z=0, g_Z=g0 has full axis rank. Choose for the PROOF any axis N-column minor nonzero there. Its restriction to this pencil is nonzero and has degree at most d(d+1). The product of this minor, g_Z(0), and the monic degree-m discriminant has degree at most

H=d(d+1)+(2m-2)+1.

The product is nonzero, with no division by two or characteristic-zero lift. Therefore at most H scalar values fail at least one guard. Test the H+1-element list in fixed order, checking nonzero constant, gcd(g_Z,g_Z')=1, and rank X_N(g_Z)=N. A successful scalar is guaranteed. The algorithm need not know which theoretical axis minor was selected, and it never substitutes genericity for checking a candidate.

## 6. Paid arithmetic, fields, and output boundaries

Construct the exact E matrix and U basis by dense elimination: O(N^3) field arithmetic and O(N^2) storage. Polynomial division by t-1 or t(t-1), construction of V0,V1,W, and the endpoint solve fit the same bound.

Each coprime-combination loop has O(N) basis directions and O(N) scalar trials per direction. Each trial computes degree-O(N) gcds and coefficient/function evaluations, costing O(N^2) arithmetic and O(N) inversions. The two loops total O(N^4) arithmetic and O(N^3) inversions. Their scalar multiplication, candidate formation, reads, and writes are included.

The reciprocal pencil uses O(N) tests, each O(N^2) arithmetic and O(N) inversions. The final pencil uses at most H+1=O(N^2) tests. Each final test costs O(N^3) arithmetic and O(N) inversions, including gcd, construction of all quotient remainders, and full axis rank. This stage dominates at O(N^5) arithmetic and O(N^3) inversions. Storage is O(N^2) with streamed candidates and a reusable axis matrix. Read/write/address work is bounded by the same O(N^5), and writing the final m+1 coefficients is included. This is a conservative upper bound, not an optimal generator.

Finite fields: retain the original supplied certified F_Q interface and its O(Q^3) base-field quadratic-extension preparation. E0=F_(Q^2) contains q and has more than H+1 elements. Enumerate H+1 distinct polynomial-basis representations with O(H) field-element writes; integer counter and representation costs are additional, O(H log Q) bit output in a standard encoding. E0 arithmetic has the unchanged degree-two base-field costs. The new coefficient bound is polynomial in N in field arithmetic; the unchanged O(Q^3) setup is not polynomial in log Q. No unqualified bit-complexity assertion is made.

Infinite fields: the generator needs the stated list interface. In characteristic zero, 0,1,...,H supplies it using H additions, while coefficient bit growth is not bounded here. In positive characteristic, repeated addition of 1 need not provide the list. If an arbitrary infinite field has no supplied effective distinct-element operation, this is a genuine interface condition, not a free base-field algorithm. One may instead construct over a finite extension of F_p(q) as in the source, but that changes the coefficient-field claim and its preparation must be paid. Existence of a k-valued good polynomial over infinite k remains inherited, independent of the algorithmic interface.

After producing g, use the UNCHANGED original ledger: genuine splitting field or explicit m!-degree splitting overfield, actual distinct nonzero root recovery, Vandermonde moments, raw weights, original branch inverses, all output coordinates, and storage/base-coordinate expansion. No F020 result, formal root, derivative atom, zero-node bank, new generator, external endpoint map, or unpriced factoring oracle is used.

## 7. Exact q-binomial direction, and why it is not the proof of the guards

This separately records a genuinely structured full-degree member of U. It is not asserted to pass all guards. Put a=d-1, L=m-a=N-2d+1, and

A0(z)=sum_(j=0)^L [L choose j]_rho (-q^(h(1-2L)) z)^j,
Q(z)=product_(ell=0)^(d-2)(z-q^ell), A=Q A0,
g(z)=sum_(j=0)^m D(q^j) [z^j]A(z) z^j.

The q-binomial coefficients are legal because L<N, so every denominator 1-rho^u used is nonzero. Define the chirp coefficient transform C A=sum_j C_j [z^j]A z^j. The finite q-binomial theorem gives EXACTLY

C A0(z)=product_(i=0)^(L-1)(1-rho^(1-L+i) z),

whose roots are rho^0,...,rho^(L-1). The exponent check is

q^(h j^2) q^(h(1-2L)j)=rho^(j(j-1)/2+(1-L)j).

Also C(z^b A0)(z)=C_b z^b (C A0)(rho^b z). Thus C(Q A0) vanishes at rho^k for every 0<=k<=L-a-1. Since L-a=N-3d+2>=3d-6 under the original gate, this contains every required k=0,...,3d-7. Ordinary moments vanish because A(q^ell)=0 for ell=0,...,d-2. Therefore, coefficient by coefficient,

sum_j c_j C_j rho^(kj)/D(q^j)=0,
sum_j c_j q^(ell j)/D(q^j)=0,

for exactly the defining envelope ranges. The polynomial has degree m and nonzero constant, and can be normalized monic. It also vanishes at 1 because every member of U does.

This establishes membership, not squarefreeness or full axis rank. In fact universal squarefreeness is FALSE: at N=23,d=4 over F_47 with primitive q=32, the normalized seed has gcd(g,g')=t-1. Its degree is 19, its constant is 32, all original envelope moments vanish, and its axis rank is 23, but the required root 1 is repeated. SEED_FAILURE_CERTIFICATE.json gives all coefficients, every original moment, and the exact quotient by (t-1)^2. This is an admissible original-gate counterexample, not an artificial subclass. Although A0 is a scaled Rogers-Szego polynomial, g is D(T_q)(Q A0), where T_q A(z)=A(qz). The intervening multiplication by Q and nontrivial q-difference operator are not the polynomial/parameter correspondence needed to apply F020. Moreover the phase/degree and characteristic gates are different. No F020 squarefreeness claim is transported across those operations. The two-pencil algorithm above avoids this unproved leap and works in the entire original U.

## 8. Review and classical contribution boundary

The algebraic ingredients (coprime pencils, polynomial Euclid, resultant degree, finite scalar avoidance) are classical. The contribution is a constructive two-pencil use of the already-proved original signed-bank gcd and endpoint facts, producing the actual auxiliary axis witness and then a deterministic original-gate coefficient generator with a paid polynomial bound. It is not claimed historically novel, and it does not close the full cold compiler/root-field bottleneck or the broader Fourier owners.

Fresh finite exact controls and their results are separate artifacts. They are transcription/falsification evidence, not a substitute for the all-parameter proof above. Independent acceptance is required before the sole designated publisher changes any table or repository.
