#!/usr/bin/env python3
"""Fresh falsification scan of the exact Section 7 candidate, not theorem evidence."""
import control as C
import json, math

def primes(limit):
    for p in range(3,limit+1):
        if all(p%d for d in range(2,math.isqrt(p)+1)): yield p

def seed(F,N,d,q):
    m=N-d;h=pow(4,-1,N);rho=F.power(q,pow(2,-1,N));L=N-2*d+1
    qb=C.q_binomial_row(F,rho,L)
    zs=F.neg(F.power(q,h*(1-2*L)))
    A0=[F.mul(qb[j],F.power(zs,j)) for j in range(L+1)]
    Q=[1]
    for ell in range(d-1):Q=C.mul(F,Q,[F.neg(F.power(q,ell)),1])
    A=C.mul(F,Q,A0)
    g=[]
    for j in range(m+1):
        D=1
        for i in range(2,d):D=F.mul(D,F.sub(1,F.power(q,i+j)))
        g.append(F.mul(D,A[j]))
    g=C.scale(F,g,F.inv(g[-1]))
    return g

out=[];tested=0
for p in primes(2500):
    for N in range(23,min(64,p),2):
        if (p-1)%N:continue
        F=C.Field(p);q0=F.power(F.generator,(p-1)//N)
        for d in range(4,(N+10)//8+1):
            for u in range(1,N):
                if math.gcd(u,N)!=1:continue
                q=F.power(q0,u);g=seed(F,N,d,q);tested+=1
                gg=C.gcd(F,g,C.derivative(F,g))
                if gg != [1]:
                    out.append({'p':p,'N':N,'d':d,'q':q,'gcd_degree':len(gg)-1,'g':g,'gcd':gg})
                    if len(out)>=6:break
            if len(out)>=6:break
        if len(out)>=6:break
    if len(out)>=6:break
print(json.dumps({'tested':tested,'squarefree_failures':out,'scope':'Exact counterexamples only. No completeness claim.'},sort_keys=True,indent=2))
