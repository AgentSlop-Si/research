# Fresh exact controls and reproducibility

23 October 2026 UTC. These files were newly authored for this candidate. No historical or supplied scientific program was executed or imported. Python's normal and -O modes produce byte-identical JSON; every scientific check uses explicit conditionals, never removable assertions.

- control.py / CONTROL.json / CONTROL_OPT.json: 5,643 checks over nine fixtures. Orders N=23,29,33,35,43,51 and N=31 in characteristic two are included. The F_47 quadratic coefficient field uses a verified nonsquare modulus and retains the same primitive q=32 as the failed closed seed. The binary degree-ten field is certified by an injective cycle of all 1,023 nonzero residues, proving every nonzero residue is a unit.
- Each fixture constructs the exact original envelope, computes the actual U/U0/V0/V1/W bases, verifies gcd and endpoint prerequisites, performs multiplicity-aware scalar selection, builds the reciprocal axis witness, checks its full axis rank, constructs the second pencil, and tests every final guard. It saves the actual successful g coefficients, field representation parameters, and trial counts.
- A repeated-factor fixture explicitly tests the greedy gcd-combination invariant. No simple-root assumption is used in the lemma or algorithm.
- The exact q-binomial coefficient identity and all its claimed chirp/ordinary moments are tested separately from the successful pencil generator. Passing membership is never treated as passing the squarefree or axis guard.
- scan_seed.py / SEED_FALSIFICATION.json: a fresh exact falsification scan stopped after six squarefreeness counterexamples among 154 tested phase/parameter fixtures. It is not a classification or evidence of completeness.
- certify_seed_failure.py / SEED_FAILURE_CERTIFICATE.json: a direct exact certificate for N=23,d=4,F_47,q=32. It records every original envelope moment as zero, nonzero denominator values, a monic degree-19 seed with constant 32, axis rank 23, and gcd(g,g')=t-1. The quotient by (t-1)^2 is included. Normal and -O certificate outputs are identical.

These are coefficient/moment/guard controls, not executions of root-field preparation or physical bank reconstruction. The all-parameter proof is THEOREM.md, not the finite checks. No empirical timing or asymptotic acceleration follows from these fixtures.
