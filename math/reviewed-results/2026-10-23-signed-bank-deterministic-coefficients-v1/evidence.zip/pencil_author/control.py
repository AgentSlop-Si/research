#!/usr/bin/env python3
"""Fresh exact controls for the original-gate two-pencil coefficient generator.
No imports of historical scientific code, no numerical roots, no assert statements.
"""
import json
from pathlib import Path

CHECKS = 0

def check(condition, message):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise RuntimeError(message)

class Field:
    def __init__(self, p, binary_degree=None, modulus=None):
        self.p = p
        self.degree = binary_degree or 1
        self.size = p ** self.degree
        self.binary = binary_degree is not None
        if self.binary:
            check(p == 2, 'Binary representation has characteristic two')
            self.exp = []
            self.log = [-1] * self.size
            x = 1
            for i in range(self.size - 1):
                check(x != 0 and self.log[x] == -1, 'Nonzero generator cycle is injective')
                self.log[x] = i
                self.exp.append(x)
                x <<= 1
                if x & self.size:
                    x ^= modulus
            check(x == 1 and all(v >= 0 for v in self.log[1:]), 'All nonzero residues are units')
            self.exp += self.exp
            self.generator = 2
        else:
            check(all(p % j for j in range(2, int(p ** .5) + 1)), 'Prime coefficient modulus')
            self.generator = next(a for a in range(2, p) if len({pow(a, j, p) for j in range(1, p)}) == p - 1)
    def add(self, a, b): return a ^ b if self.binary else (a + b) % self.p
    def neg(self, a): return a if self.binary else (-a) % self.p
    def sub(self, a, b): return self.add(a, self.neg(b))
    def mul(self, a, b):
        if self.binary:
            return 0 if not a or not b else self.exp[self.log[a] + self.log[b]]
        return a * b % self.p
    def inv(self, a):
        if not a: raise ZeroDivisionError('Exact field inverse of zero')
        if self.binary: return self.exp[(self.size - 1 - self.log[a]) % (self.size - 1)]
        return pow(a, self.p - 2, self.p)
    def power(self, a, n):
        if n < 0: return self.power(self.inv(a), -n)
        z = 1
        while n:
            if n & 1: z = self.mul(z, a)
            a = self.mul(a, a)
            n >>= 1
        return z
    def integer(self, n): return n % self.p


class QuadraticField(Field):
    """Exact F_p[v]/(v^2-nu), with a verified nonsquare nu."""
    def __init__(self,p):
        self.p,self.degree,self.size,self.binary=p,2,p*p,False
        check(all(p%j for j in range(2,int(p**.5)+1)), 'Quadratic base is prime')
        self.nu=next(a for a in range(2,p) if pow(a,(p-1)//2,p)==p-1)
        check(pow(self.nu,(p-1)//2,p)==p-1,'Quadratic modulus has no base-field root')
    def add(self,a,b):
        p=self.p
        return ((a%p+b%p)%p)+p*((a//p+b//p)%p)
    def neg(self,a):
        p=self.p
        return (-a%p)+p*((- (a//p))%p)
    def mul(self,a,b):
        p=self.p;a0,a1=a%p,a//p;b0,b1=b%p,b//p
        return ((a0*b0+self.nu*a1*b1)%p)+p*((a0*b1+a1*b0)%p)
    def inv(self,a):
        if not a:raise ZeroDivisionError('Quadratic inverse of zero')
        p=self.p;a0,a1=a%p,a//p
        norm=(a0*a0-self.nu*a1*a1)%p
        if not norm:raise RuntimeError('Unexpected quadratic zero norm')
        z=pow(norm,p-2,p)
        return ((a0*z)%p)+p*((-a1*z)%p)

def trim(a):
    a = list(a)
    while a and not a[-1]: a.pop()
    return a

def add(F, a, b):
    c = [0] * max(len(a), len(b))
    for i, x in enumerate(a): c[i] = F.add(c[i], x)
    for i, x in enumerate(b): c[i] = F.add(c[i], x)
    return trim(c)

def scale(F, a, z): return trim([F.mul(x, z) for x in a])

def mul(F, a, b):
    if not a or not b: return []
    c = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): c[i+j] = F.add(c[i+j], F.mul(x, y))
    return trim(c)

def divmod_poly(F, a, b):
    a, b = trim(a), trim(b)
    if not b: raise ZeroDivisionError('Polynomial divisor is zero')
    q = [0] * max(0, len(a) - len(b) + 1)
    inv = F.inv(b[-1])
    while a and len(a) >= len(b):
        k = len(a) - len(b)
        z = F.mul(a[-1], inv)
        q[k] = z
        for j, y in enumerate(b): a[k+j] = F.sub(a[k+j], F.mul(z, y))
        a = trim(a)
    return trim(q), a

def exact_div(F, a, b):
    q, r = divmod_poly(F, a, b)
    check(not r, 'Exact fixed-divisor quotient')
    return q

def gcd(F, a, b):
    a, b = trim(a), trim(b)
    while b:
        a, b = b, divmod_poly(F, a, b)[1]
    return scale(F, a, F.inv(a[-1])) if a else []

def ev(F, a, x):
    z = 0
    for y in reversed(a): z = F.add(F.mul(z, x), y)
    return z

def derivative(F, a): return trim([F.mul(F.integer(i), a[i]) for i in range(1, len(a))])

def reverse(a, r): return trim(list(reversed(list(a) + [0] * (r+1-len(a)))))

def coeff(a, j): return a[j] if j < len(a) else 0

def rref(F, matrix, width):
    a = [list(row) for row in matrix]
    pivots = []
    row = 0
    for col in range(width):
        pivot = next((i for i in range(row, len(a)) if a[i][col]), None)
        if pivot is None: continue
        a[row], a[pivot] = a[pivot], a[row]
        z = F.inv(a[row][col])
        a[row] = [F.mul(z, x) for x in a[row]]
        for i in range(len(a)):
            if i == row or not a[i][col]: continue
            z = a[i][col]
            a[i] = [F.sub(x, F.mul(z, y)) for x, y in zip(a[i], a[row])]
        pivots.append(col)
        row += 1
        if row == len(a): break
    return a, pivots

def nullspace(F, matrix, width):
    a, pivots = rref(F, matrix, width)
    out = []
    for j in range(width):
        if j in pivots: continue
        v = [0] * width
        v[j] = 1
        for i, p in enumerate(pivots): v[p] = F.neg(a[i][j])
        out.append(trim(v))
    return out

def dot(F, a, b):
    z = 0
    for x, y in zip(a, b): z = F.add(z, F.mul(x, y))
    return z

def member(F, rows, g, message):
    for row in rows: check(dot(F, row, g) == 0, message)

def all_gcd(F, basis):
    g = []
    for b in basis: g = gcd(F, g, b)
    return g

def coprime_combination(F, a, basis, grid, phi=None):
    p = [] if phi is None else next(list(b) for b in basis if phi(b))
    d = gcd(F, a, p)
    trials = 0
    cap = len(a) + (1 if phi else 0)
    for b in basis:
        target = gcd(F, d, b)
        found = False
        for z in grid[:cap]:
            trials += 1
            candidate = add(F, p, scale(F, b, z))
            if phi is not None and not phi(candidate): continue
            if gcd(F, a, candidate) == target:
                p, d, found = candidate, target, True
                break
        check(found, 'Bounded scalar gcd selection succeeds')
        check(gcd(F, a, p) == d, 'Multiplicity-aware gcd invariant')
        if phi is not None: check(phi(p) != 0, 'Endpoint determinant stays nonzero')
    check(gcd(F, a, p) == [1], 'Terminal pair is coprime')
    return p, trials

def axis_rank(F, N, g):
    m = len(g) - 1
    check(g[-1] == 1, 'Axis remainder polynomial is monic')
    rems = [[1] + [0] * (m-1)]
    for j in range(1, N):
        old = rems[-1]
        top = old[-1]
        new = [0] + old[:-1]
        for i in range(m): new[i] = F.sub(new[i], F.mul(top, g[i]))
        rems.append(new)
    rows = [rems[a] + [1] + rems[(-a) % N] for a in range(N)]
    return len(rref(F, rows, 2*m+1)[1])

def q_binomial_row(F, rho, L):
    row = [1]
    for n in range(1, L+1):
        new = [1] + [0] * (n-1) + [1]
        for j in range(1, n):
            new[j] = F.add(row[j] if j < len(row) else 0, F.mul(F.power(rho, n-j), row[j-1]))
        row = new
    return row

def run_fixture(F, N, d, supplied_q=None):
    check(N % 2 == 1 and d >= 4 and N >= 8*d-10, 'Original gate unchanged')
    check((F.size - 1) % N == 0, 'Root order divides field unit order')
    q = F.power(F.generator, (F.size-1)//N) if supplied_q is None else supplied_q
    check(F.power(q, N) == 1, 'q^N=1')
    for i in range(1, N): check(F.power(q, i) != 1, 'q has exact order N')
    m, r, n = N-d, N-d-2, N-d-1
    H = d*(d+1)+2*m-1
    check(F.size > H, 'The explicit scalar grid is large enough')
    grid = list(range(H+1))
    e, h = pow(2, -1, N), pow(4, -1, N)
    rho = F.power(q, e)
    D, C = [], []
    for j in range(m+1):
        x = 1
        for i in range(2, d): x = F.mul(x, F.sub(1, F.power(q, i+j)))
        check(x != 0, 'Envelope denominator is nonzero')
        D.append(x)
        C.append(F.power(q, h*j*j))
    rows = [[F.mul(F.mul(C[j], F.power(rho, k*j)), F.inv(D[j])) for j in range(m+1)] for k in range(3*d-6)]
    rows += [[F.mul(F.power(q, ell*j), F.inv(D[j])) for j in range(m+1)] for ell in range(d-1)]
    U = nullspace(F, rows, m+1)
    delta0, deltam = [0]*(m+1), [0]*(m+1)
    delta0[0], deltam[m] = 1, 1
    U0 = nullspace(F, rows+[delta0], m+1)
    Wg = nullspace(F, rows+[deltam], m+1)
    tm1 = [F.neg(1), 1]
    V0 = [exact_div(F, g, [0, F.neg(1), 1]) for g in U0]
    V1 = [exact_div(F, g, tm1) for g in U]
    W = [exact_div(F, g, tm1) for g in Wg]
    check(all_gcd(F, V0) == [1], 'V0 gcd exactly one')
    check(all_gcd(F, V1) == [1], 'V1 gcd exactly one')
    for g in U: member(F, rows, g, 'Every computed kernel basis member satisfies original E')
    f0 = None
    for a in V0:
        if f0 is not None: break
        for b in V0:
            a0, ar, b0, br = coeff(a,0), coeff(a,r), coeff(b,0), coeff(b,r)
            det = F.sub(F.mul(a0,br), F.mul(b0,ar))
            if not det: continue
            x = F.mul(F.sub(br,b0),F.inv(det))
            y = F.mul(F.sub(a0,ar),F.inv(det))
            f0 = add(F,scale(F,a,x),scale(F,b,y))
            break
    check(f0 is not None and coeff(f0,0)==1 and coeff(f0,r)==1, 'Independent endpoints produce f0')
    phi = lambda f: F.sub(coeff(f,r),coeff(f,0))
    f1, first_trials = coprime_combination(F,f0,V0,grid,phi)
    f, reciprocal_trials = None, 0
    for z in grid[:2*r+3]:
        reciprocal_trials += 1
        candidate = add(F,f0,scale(F,f1,z))
        if not coeff(candidate,0) or not coeff(candidate,r): continue
        if gcd(F,candidate,reverse(candidate,r)) != [1]: continue
        f = scale(F,candidate,F.inv(candidate[-1]))
        break
    check(f is not None, 'Bounded reciprocal-pencil selection succeeds')
    check(ev(F,f,1)!=0, 'Reciprocal coprimality excludes root one')
    g0 = mul(F,[0,F.neg(1),1],f)
    member(F,rows,g0,'Auxiliary witness remains in original U')
    check(axis_rank(F,N,g0)==N, 'Auxiliary zero-constant polynomial has full axis rank')
    h0 = [0]+f
    check(coeff(derivative(F,h0),0)!=0,'Auxiliary residual has nonzero ordinary derivative')
    h1, second_trials = coprime_combination(F,h0,W,grid)
    check(len(h1)<=n and coeff(h1,0)!=0,'Second pencil is monic and moves away from zero root')
    g, final_trials = None, 0
    for z in grid:
        final_trials += 1
        candidate = mul(F,tm1,add(F,h0,scale(F,h1,z)))
        check(len(candidate)==m+1 and candidate[-1]==1,'Every final candidate has exact monic degree')
        member(F,rows,candidate,'Every final candidate remains in original U')
        if not candidate[0]: continue
        if gcd(F,candidate,derivative(F,candidate)) != [1]: continue
        if axis_rank(F,N,candidate)!=N: continue
        g = candidate
        break
    check(g is not None,'H+1 bounded final guard selection succeeds')
    check(ev(F,g,1)==0,'Final polynomial has required root one')
    check(gcd(F,g,derivative(F,g))==[1],'Final polynomial is squarefree')
    check(g[0]!=0 and len(g)==m+1,'Final polynomial has degree m and no zero root')
    # Independently form the q-binomial seed, verify its entire chirp identity,
    # and then evaluate every defining moment rather than infer membership.
    L, a = N-2*d+1, d-1
    qb = q_binomial_row(F,rho,L)
    zscale = F.neg(F.power(q,h*(1-2*L)))
    A0 = [F.mul(qb[j],F.power(zscale,j)) for j in range(L+1)]
    chirped = [F.mul(F.power(q,h*j*j),A0[j]) for j in range(L+1)]
    product = [1]
    for i in range(L): product = mul(F,product,[1,F.neg(F.power(rho,1-L+i))])
    check(chirped==product,'Full q-binomial chirp coefficient identity')
    Q = [1]
    for ell in range(d-1): Q = mul(F,Q,[F.neg(F.power(q,ell)),1])
    A = mul(F,Q,A0)
    for ell in range(d-1): check(ev(F,A,F.power(q,ell))==0,'Every ordinary moment vanishes')
    CA = [F.mul(C[j],A[j]) for j in range(m+1)]
    for k in range(L-a): check(ev(F,CA,F.power(rho,k))==0,'Every claimed chirp moment vanishes')
    seed = [F.mul(D[j],A[j]) for j in range(m+1)]
    seed = scale(F,seed,F.inv(seed[-1]))
    member(F,rows,seed,'Structured seed satisfies every original E constraint')
    check(seed[0]!=0 and len(seed)==m+1 and ev(F,seed,1)==0,'Structured seed degree and fixed-root guards')
    seed_sq = gcd(F,seed,derivative(F,seed))==[1]
    seed_rank = axis_rank(F,N,seed)
    return {'N':N,'d':d,'characteristic':F.p,'field_size':F.size,'q':q,'dim_U':len(U),'H':H,
            'coprime_trials_1':first_trials,'reciprocal_trials':reciprocal_trials,'coprime_trials_2':second_trials,
            'final_trials':final_trials,'g_coefficients':g,'structured_seed_squarefree':seed_sq,'structured_seed_axis_rank':seed_rank}

def multiplicity_controls():
    F = Field(101)
    a = mul(F,mul(F,[-1 % 101,1],[-1 % 101,1]),mul(F,[-2 % 101,1],[-2 % 101,1]))
    basis = [mul(F,[-1 % 101,1],[-1 % 101,1]),mul(F,[-2 % 101,1],[-2 % 101,1])]
    p,trials = coprime_combination(F,a,basis,list(range(10)))
    check(gcd(F,a,p)==[1],'Repeated-factor exact greedy test')
    return trials

if __name__=='__main__':
    fixtures = []
    for p,N,d in [(139,23,4),(233,29,4),(211,35,5),(331,33,5),(431,43,6),(307,51,7)]:
        fixtures.append(run_fixture(Field(p),N,d))
    fixtures.append(run_fixture(QuadraticField(47),23,4,supplied_q=32))
    F2 = Field(2,10,(1<<10)|(1<<3)|1)
    for d in (4,5): fixtures.append(run_fixture(F2,31,d))
    out = {'status':'PASS','checks':CHECKS,'multiplicity_trial_count':multiplicity_controls(),'fixtures':fixtures,
           'scope':'Fresh exact coefficient/moment/gcd/axis controls only; no root splitting, physical bank recovery, or runtime-speed claim.'}
    out['checks']=CHECKS
    print(json.dumps(out,sort_keys=True,indent=2))
