# Narrow operation-ledger replacement

Replace only the deterministic coefficient search in Section 3 of the pinned all-characteristics ledger.

Old: O((H+1)^(dim U-1) N^3) coefficient-field arithmetic on an explicit affine grid (or O((Q^2)^(dim U-1) N^3) full enumeration).

New: O(N^5) coefficient-field additions/multiplications, O(N^3) inversions, O(N^2) live field-element storage. This includes exact U basis construction; every trial in both gcd-combination loops; every reciprocal-pencil test; up to H+1 final constant/discriminant/axis tests; candidate coefficient generation; and reads/writes. The scalar grid is explicitly represented and paid. The method is deterministic and can be used over F_(Q^2), whose existing size guarantee suffices.

Unchanged: supplied base-field representation and certification; O(Q^3) elementary quadratic coefficient-field setup; genuine root-field or explicit m!-degree splitting-overfield construction; actual root recovery; all moments and weights; every physical branch parameter and denominator; full-output application; storage; base-coordinate/bit expansion. The old expected O(N^3) Las Vegas coefficient algorithm remains faster in expected field-operation count.

The two-pencil improvement removes deterministic coefficient enumeration as a separate exponential bottleneck. It does NOT remove the splitting-field/root-recovery bottleneck, produce an efficient full bank compiler, or imply an FFT gain. In an arbitrary infinite field, the theorem explicitly requires and prices a sufficiently large distinct-scalar interface rather than pretending it is supplied by repeated addition of 1.
