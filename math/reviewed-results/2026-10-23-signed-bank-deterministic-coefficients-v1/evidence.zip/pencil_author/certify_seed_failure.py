#!/usr/bin/env python3
"""Fresh exact original-envelope check of one closed-seed guard failure."""
import control as C
import json
F=C.Field(47);N,d,q=23,4,32;m=N-d;h=pow(4,-1,N);rho=F.power(q,pow(2,-1,N))
g=[32,46,22,39,46,21,24,38,35,4,40,1,32,30,1,31,5,44,25,1]
C.check(F.power(q,N)==1 and all(F.power(q,i)!=1 for i in range(1,N)),'Primitive original phase')
D=[]
for j in range(m+1):
    x=1
    for i in range(2,d):x=F.mul(x,F.sub(1,F.power(q,i+j)))
    C.check(x!=0,'Every original denominator is nonzero')
    D.append(x)
chirp=[];ordinary=[]
for k in range(3*d-6):
    row=[F.mul(F.mul(F.power(q,h*j*j),F.power(rho,k*j)),F.inv(D[j])) for j in range(m+1)]
    chirp.append(C.dot(F,row,g))
for ell in range(d-1):
    row=[F.mul(F.power(q,ell*j),F.inv(D[j])) for j in range(m+1)]
    ordinary.append(C.dot(F,row,g))
C.check(all(x==0 for x in chirp+ordinary),'Exact original U membership')
quotient,remainder=C.divmod_poly(F,g,[1,45,1])
C.check(not remainder,'Exact repeated-root factor (t-1)^2')
gg=C.gcd(F,g,C.derivative(F,g))
C.check(gg==[46,1],'Exact gcd(g,g prime)=t-1')
rank=C.axis_rank(F,N,g)
print(json.dumps({'status':'PASS_COUNTEREXAMPLE','N':N,'d':d,'field':47,'q':q,'g':g,
'ordinary_moments':ordinary,'chirp_moments':chirp,'D_values':D,'g_at_1':C.ev(F,g,1),
'gprime_at_1':C.ev(F,C.derivative(F,g),1),'gcd_g_gprime':gg,'quotient_by_t_minus_1_squared':quotient,
'axis_rank':rank,'checks':C.CHECKS,'scope':'The Section 7 exact original-U q-binomial seed fails squarefreeness in an admissible characteristic; the two-pencil theorem repairs its guard gap without using this seed.'},sort_keys=True,indent=2))
