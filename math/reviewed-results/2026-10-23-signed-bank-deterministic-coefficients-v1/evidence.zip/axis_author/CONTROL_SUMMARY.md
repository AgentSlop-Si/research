# Fresh exact controls

23 October 2026 UTC. These are transcription/falsification controls, not substitutes for the all-parameter proof. The standalone `control.py` was written for this candidate and executed locally. It imports or executes no historical/supplied program.

## Scope and results

All 518 comparisons between the ORIGINAL dense axis matrix X_N((t-1)h) and the affine truncated-Sylvester matrix passed. All 414 nonzero-constant comparisons with the complete gcd-locus fast criterion passed. All 31 reported relation certificates passed the two ORIGINAL divisibility checks and the scalar-column condition. Of the fast comparisons, 107 lie on a nontrivial reciprocal-gcd locus.

The original-gate controls independently rebuild the defining E rows, U, U0, V0, V1, both coprime-combination loops, the reciprocal witness, and the second pencil from scratch. They verify EVERY candidate in the stated 2N-element scalar list, rather than only the first successful point. Each candidate is checked for membership in the original U, nonzero constant, squarefreeness, original dense axis rank, and affine-matrix rank; those with nonzero constant also receive the fast test.

- N=23, d=4 over F47: primitive root q=2; dim U=11; 46 scalar trials inspected; first legal scalar 1. Five nonzero-constant candidates have a nontrivial reciprocal gcd. Two scalar candidates fail squarefreeness.
- N=25, d=4 over F101: primitive root q=5; dim U=13; 50 scalar trials inspected; first legal scalar 1. This is an odd COMPOSITE-N fixture. Two candidates have a nontrivial reciprocal gcd; one fails squarefreeness.
- N=29, d=4 over F59: primitive root q=3; dim U=17; 58 scalar trials inspected; first legal scalar 1. Five candidates have a nontrivial reciprocal gcd; four fail squarefreeness.
- N=31, d=5 over GF(2^10): primitive root q=14; dim U=14; 62 scalar trials inspected; first legal scalar 1. This is a characteristic-TWO fixture.
- N=33, d=5 over GF(2^10): primitive root q=10; dim U=16; 66 scalar trials inspected; first legal scalar 1. This is BOTH characteristic two and odd composite N.

The binary field is represented by x^10+x^3+1. The control checks that the powers of x enumerate every nonzero residue exactly once, establishing the implemented field/log table rather than assuming a representation. Root order is checked directly. Every listed original-gate fixture satisfies N>=8d-10. The program uses sufficiently large existing fields for these examples; the uniform theorem still retains the accepted quadratic coefficient-field interface and preparation cost.

The five zero-constant auxiliary witnesses are compared against the ORIGINAL dense X and affine matrix. Their reciprocal denominator Res(h,rev h) is nonzero, and the safely continued residue is verified to equal -f. They are never passed to the nonzero-constant fast routine or used as physical banks.

## Exceptional-locus and branch controls

Exhaustive controls inspect all monic h of the required degree for (N,d,k)=(7,2,F2), (11,3,F2), and (7,2,F3): 225 dense/affine comparisons and 126 nonzero-constant fast tests. These are explicitly ALGEBRAIC IDENTITY controls outside the original parameter gate. They include both full-rank and deficient axes, nontrivial reciprocal gcds, and normalized monic low-degree residues.

Ten targeted original-gate-parameter controls over F47 at N23,d4 and characteristic two at N31,d5 exercise ell below, equal to, and above d-1, repeated factors, reciprocal gcds not dividing H_N, and nontrivial reciprocal gcds dividing H_N. Their h are algebraic axis-test fixtures, not claimed to belong to U. Each is compared against actual dense X and the affine matrix. Reciprocal loci include full-rank and deficient axes, so blanket rejection is not being mistaken for an exact criterion.

One additional N8,d2,F17 identity-only fixture exercises ell=d-1 with D|H_N, producing a checked relation. It is clearly labeled even-N and does not enlarge the theorem's scope. In the original odd-N/admissible-characteristic gate that subcase is prevented by reciprocal-pair parity: a reciprocal gcd dividing H_N has even degree since its roots pair under inversion and neither 1 nor -1 is a root of H_N. But ell=d-1 would require deg D=N-2d, odd. The general case split is retained without relying on this simplification.

## Limitations

No empirical count is used as a uniform scalar bound. No roots of the legal g were recovered, no physical bank compiler or bank application was benchmarked, and no splitting-field or FFT claim was tested. The full cold cost remains in the pinned source ledger. `CONTROL.json` includes the tested h0/h1 pencils, all scalar guard outcomes, singular-case coefficients, and the hash of the fresh control source.
