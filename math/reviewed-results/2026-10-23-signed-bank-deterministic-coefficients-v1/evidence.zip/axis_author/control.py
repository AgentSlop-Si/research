#!/usr/bin/env python3
"""Fresh standalone exact controls. Does not import or execute historical code."""
import itertools, json, random, hashlib
from pathlib import Path

class Field:
    def __init__(self, p=None, binary_degree=None, modulus=None):
        self.p = p
        self.q = p if p else 1 << binary_degree
        self.description = f'F_{p}' if p else f'GF(2^{binary_degree}), modulus {modulus}'
        if not p:
            self.logs = [-1]*self.q
            self.exps = []
            x = 1
            for i in range(self.q-1):
                assert self.logs[x] == -1
                self.logs[x] = i
                self.exps.append(x)
                x <<= 1
                if x & self.q: x ^= modulus
            assert x == 1 and all(i >= 0 for i in self.logs[1:])
    def add(self,a,b): return (a+b)%self.p if self.p else a^b
    def neg(self,a): return (-a)%self.p if self.p else a
    def sub(self,a,b): return self.add(a,self.neg(b))
    def mul(self,a,b):
        if self.p: return a*b%self.p
        if a == 0 or b == 0: return 0
        return self.exps[(self.logs[a]+self.logs[b])%(self.q-1)]
    def inv(self,a):
        assert a
        return pow(a,-1,self.p) if self.p else self.exps[-self.logs[a]%(self.q-1)]
    def power(self,a,n):
        out=1
        while n:
            if n&1: out=self.mul(out,a)
            a=self.mul(a,a); n//=2
        return out

def trim(a):
    a=list(a)
    while a and a[-1]==0: a.pop()
    return a
def degree(a): return len(trim(a))-1
def add(a,b,F):
    return trim([F.add(a[i] if i<len(a) else 0,b[i] if i<len(b) else 0)
                 for i in range(max(len(a),len(b)))])
def scale(a,c,F): return trim([F.mul(x,c) for x in a])
def sub(a,b,F): return add(a,scale(b,F.neg(1),F),F)
def mul(a,b,F):
    if not a or not b: return []
    r=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): r[i+j]=F.add(r[i+j],F.mul(x,y))
    return trim(r)
def divrem(a,b,F):
    a=trim(a); b=trim(b); assert b
    q=[0]*max(0,len(a)-len(b)+1); inv=F.inv(b[-1])
    while a and len(a)>=len(b):
        k=len(a)-len(b); z=F.mul(a[-1],inv); q[k]=z
        for j,x in enumerate(b): a[k+j]=F.sub(a[k+j],F.mul(z,x))
        a=trim(a)
    return trim(q),a
def quotient(a,b,F):
    q,r=divrem(a,b,F); assert not r; return q
def monic(a,F): return scale(a,F.inv(a[-1]),F) if a else []
def gcd(a,b,F):
    while b: a,b=b,divrem(a,b,F)[1]
    return monic(a,F)
def inverse(a,h,F):
    r0,r1=h,a; s0,s1=[],[1]
    while r1:
        q,r=divrem(r0,r1,F)
        r0,r1=r1,r; s0,s1=s1,sub(s0,mul(q,s1,F),F)
    assert len(r0)==1
    return divrem(scale(s0,F.inv(r0[0]),F),h,F)[1]
def rev(a,n): return trim(list(reversed(a+[0]*(n+1-len(a)))))
def deriv(a,F):
    out=[]
    for i in range(1,len(a)):
        scalar=i%F.p if F.p else i%2
        out.append(F.mul(scalar,a[i]))
    return trim(out)
def evaluate(a,x,F):
    out=0
    for z in reversed(a): out=F.add(F.mul(out,x),z)
    return out
def rref(A,F):
    A=[list(row) for row in A]
    if not A: return A,[]
    piv=[]; row=0
    for col in range(len(A[0])):
        hit=next((i for i in range(row,len(A)) if A[i][col]),None)
        if hit is None: continue
        A[row],A[hit]=A[hit],A[row]
        z=F.inv(A[row][col]); A[row]=[F.mul(z,x) for x in A[row]]
        for i in range(len(A)):
            if i==row or not A[i][col]: continue
            z=A[i][col]
            A[i]=[F.sub(x,F.mul(z,y)) for x,y in zip(A[i],A[row])]
        piv.append(col); row+=1
        if row==len(A): break
    return A,piv
def rank(A,F): return len(rref(A,F)[1])
def nullspace(A,F):
    R,piv=rref(A,F); width=len(A[0]); out=[]
    for free in range(width):
        if free in piv: continue
        v=[0]*width; v[free]=1
        for i,p in enumerate(piv): v[p]=F.neg(R[i][free])
        out.append(trim(v))
    return out
def linear_combination(basis,coeff,F):
    out=[]
    for b,c in zip(basis,coeff): out=add(out,scale(b,c,F),F)
    return out
def solve(A,b,F):
    R,piv=rref([x+[y] for x,y in zip(A,b)],F); width=len(A[0])
    assert width not in piv
    out=[0]*width
    for row,p in zip(R,piv): out[p]=row[-1]
    return out
def axis_matrix(h,N,F):
    g=mul([F.neg(1),1],h,F); m=len(g)-1
    ps=[]; p=[1]+[0]*(m-1)
    for a in range(N):
        ps.append(p)
        top=p[-1]; p=[0]+p[:-1]
        for j in range(m): p[j]=F.sub(p[j],F.mul(top,g[j]))
    return [ps[a]+[1]+ps[-a%N] for a in range(N)]
def relation_matrix(h,N,d,F):
    n=len(h)-1; c=h[0] if h else 0; v=rev(h,n); H=[1]*N
    columns=[]
    for j in range(d):
        col=[0]*(j+1)+v
        if j==d-1: col=sub(col,scale(H,c,F),F)
        assert degree(col)<=N-2
        columns.append(col+[0]*(N-1-len(col)))
    for j in range(d):
        col=scale([0]*j+h,F.neg(1),F)
        columns.append(col+[0]*(N-1-len(col)))
    return [list(x) for x in zip(*columns)]
def fast_guard(h,N,d,F):
    n=len(h)-1; assert h[-1]==1 and h[0]
    v=rev(h,n); D=gcd(h,v,F); hb=quotient(h,D,F); ell=degree(hb)
    if ell<=d-2: return False, {'case':'homogeneous','gcd_degree':degree(D)},hb
    HD,rem=divrem([1]*N,D,F)
    if rem: return True, {'case':'nondivisible','gcd_degree':degree(D)},None
    vb=quotient(v,D,F); K=h[1:]
    rhs=scale(mul(K,HD,F),F.neg(1),F)
    b0=divrem(mul(inverse(vb,hb,F),rhs,F),hb,F)[1]
    if ell==d-1:
        return False, {'case':'borderline','gcd_degree':degree(D)},add(b0,hb,F)
    bad=degree(b0)==d-1 and b0[-1]==1
    return not bad, {'case':'normalized' if bad else 'high_or_nonmonic',
                     'gcd_degree':degree(D),'residue_degree':degree(b0)},b0 if bad else None
def check_h(h,N,d,F,counts):
    dense=rank(axis_matrix(h,N,F),F)==N
    syl=rank(relation_matrix(h,N,d,F),F)==2*d
    assert dense==syl, ('matrix_mismatch',F.description,N,d,h)
    counts['matrix_comparisons']+=1
    if h[0]:
        fast,detail,b=fast_guard(h,N,d,F)
        assert fast==dense,('fast_mismatch',F.description,N,d,h,detail)
        counts['fast_comparisons']+=1
        counts['cases'][detail['case']]=counts['cases'].get(detail['case'],0)+1
        if detail['gcd_degree']: counts['reciprocal_locus']+=1
        if not fast:
            a=rev(b,d-1); g=mul([F.neg(1),1],h,F); A=mul(g,a,F)
            assert degree(A)<N and not divrem(A,g,F)[1]
            J=[0]*N
            for i,x in enumerate(A): J[-i%N]=x
            assert not divrem(J,g,F)[1] and evaluate(A,1,F)==0
            counts['verified_relation_certificates']+=1
    return dense
def counts(): return dict(matrix_comparisons=0,fast_comparisons=0,reciprocal_locus=0,
                          verified_relation_certificates=0,cases={})
def coprime_combine(a,basis,scalars,F,phi=None):
    p=next(b for b in basis if phi(b)) if phi else []
    D=gcd(a,p,F); trials=0
    for b in basis:
        target=gcd(D,b,F)
        for lam in scalars:
            candidate=add(p,scale(b,lam,F),F); trials+=1
            if phi and not phi(candidate): continue
            if gcd(a,candidate,F)==target:
                p,D=candidate,target; break
        else: raise AssertionError('scalar_list_exhausted')
    assert D==[1]
    return p,trials
def construct_original(N,d,F):
    m=N-d; n=m-1; r=m-2; scalars=list(range(2*N)); assert len(scalars)<=F.q
    q=next(a for a in range(2,F.q) if F.power(a,N)==1
           and all(F.power(a,j)!=1 for j in range(1,N)))
    rho=F.power(q,pow(2,-1,N)); quarter=pow(4,-1,N)
    D=[1]
    for i in range(2,d): D=mul(D,[1,F.neg(F.power(q,i))],F)
    den=[evaluate(D,F.power(q,j),F) for j in range(m+1)]
    assert all(den)
    env=[]
    for a in range(3*d-6):
        env.append([F.mul(F.mul(F.power(q,(quarter*j*j)%N),F.power(rho,a*j)),
                          F.inv(den[j])) for j in range(m+1)])
    for a in range(d-1):
        env.append([F.mul(F.power(q,a*j),F.inv(den[j])) for j in range(m+1)])
    U=nullspace(env,F)
    U0=nullspace(env+[[1]+[0]*m],F)
    tfactor=[0,F.neg(1),1]
    V0=[quotient(u,tfactor,F) for u in U0]
    V1=[quotient(u,[F.neg(1),1],F) for u in U]
    at=lambda b,j:b[j] if j<len(b) else 0
    alpha=solve([[at(f,0) for f in V0],[at(f,r) for f in V0]],[1,1],F)
    f0=linear_combination(V0,alpha,F)
    phi=lambda f:F.sub(at(f,r),at(f,0))
    f1,ct1=coprime_combine(f0,V0,scalars,F,phi)
    first_trials=0
    for lam in scalars:
        first_trials+=1; cand=add(f0,scale(f1,lam,F),F)
        if at(cand,0) and at(cand,r) and gcd(cand,rev(cand,r),F)==[1]:
            f=monic(cand,F); break
    else: raise AssertionError('first_pencil_failed')
    h0=[0]+f
    W=[sub(h,scale(h0,at(h,n),F),F) for h in V1]
    W=[w for w in W if w]
    h1,ct2=coprime_combine(h0,W,scalars,F)
    assert h1[0] and degree(h1)<n
    assert gcd(h0,rev(h0,n),F)==[1]
    continuation=divrem(mul(inverse(rev(h0,n),h0,F),scale(mul(f,[1]*N,F),F.neg(1),F),F),h0,F)[1]
    assert continuation==scale(f,F.neg(1),F)
    stats=counts(); first_good=None; rows=[]
    for lam in scalars:
        h=add(h0,scale(h1,lam,F),F); g=mul([F.neg(1),1],h,F)
        axis=check_h(h,N,d,F,stats)
        sq=gcd(g,deriv(g,F),F)==[1]
        membership=all(sum_field([F.mul(x,y) for x,y in zip(row,g)],F)==0 for row in env)
        assert membership
        good=bool(h[0]) and sq and axis
        if good and first_good is None: first_good=lam
        rows.append({'lambda':lam,'constant_nonzero':bool(h[0]),'squarefree':sq,
                     'axis_full_rank':axis,'original_U':membership})
    assert first_good is not None
    return {'N':N,'d':d,'field':F.description,'q':q,'U_dimension':len(U),
            'combination_trials':[ct1,ct2],'first_pencil_trials':first_trials,
            'second_pencil_first_good_lambda':first_good,'h0':h0,'h1':h1,
            'boundary_continuation_minus_f':True,'comparisons':stats,'scalar_results':rows}
def sum_field(xs,F):
    out=0
    for x in xs: out=F.add(out,x)
    return out
def from_roots(roots,F):
    h=[1]
    for root in roots: h=mul(h,[F.neg(root),1],F)
    return h
def singular_controls():
    out=[]
    cases=[]
    for N,d,F in [(23,4,Field(p=47)),
                  (31,5,Field(binary_degree=10,modulus=(1<<10)|(1<<3)|1))]:
        n=N-d-1
        for ell in [0,d-2,d-1,d]:
            cases.append((f'repeated_reciprocal_ell_{ell}',N,d,F,
                          from_roots([1]*(n-ell)+[2]*ell,F),'original_gate_parameters'))
        q=next(a for a in range(2,F.q) if F.power(a,N)==1
               and all(F.power(a,j)!=1 for j in range(1,N)))
        z=next(a for a in range(2,F.q) if a not in [q,F.inv(q)] and F.mul(a,a)!=1)
        cases.append(('reciprocal_divisor_of_H',N,d,F,
                      from_roots([q,F.inv(q)]+[z]*(n-2),F),'original_gate_parameters'))
    # In the odd-N admissible-characteristic gate, ell=d-1 and D|H_N is
    # actually impossible by reciprocal-pair parity. An even-N identity-only
    # fixture exercises that otherwise valid general algebraic branch.
    F=Field(p=17)
    cases.append(('borderline_divisible',8,2,F,from_roots([2,9,4,13,3],F),
                  'algebraic_identity_only_even_N'))
    for name,N,d,F,h,scope in cases:
        stats=counts(); dense=check_h(h,N,d,F,stats)
        D=gcd(h,rev(h,len(h)-1),F)
        out.append({'name':name,'scope':scope,'N':N,'d':d,'field':F.description,
                    'h':h,'D':D,'ell':degree(h)-degree(D),
                    'D_divides_H_N':not bool(divrem([1]*N,D,F)[1]),
                    'h_repeated_factor_degree':degree(gcd(h,deriv(h,F),F)),
                    'axis_full_rank':dense,'comparisons':stats})
    return out
def main():
    output={'program_origin':'Fresh standalone implementation; no historical program import or execution.',
            'exhaustive_small':[],'original_gate_pencils':[],
            'singular_controls':singular_controls()}
    for p,N,d in [(2,7,2),(2,11,3),(3,7,2)]:
        F=Field(p=p); n=N-d-1; stats=counts()
        for coefficients in itertools.product(range(p),repeat=n):
            check_h(list(coefficients)+[1],N,d,F,stats)
        output['exhaustive_small'].append({'field':F.description,'N':N,'d':d,
                 'scope':'Algebraic identity control, not original parameter gate.',**stats})
    for N,d,F in [(23,4,Field(p=47)),(25,4,Field(p=101)),(29,4,Field(p=59)),
                  (31,5,Field(binary_degree=10,modulus=(1<<10)|(1<<3)|1)),
                  (33,5,Field(binary_degree=10,modulus=(1<<10)|(1<<3)|1))]:
        output['original_gate_pencils'].append(construct_original(N,d,F))
    p=Path(__file__).with_name('CONTROL.json')
    output['control_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    p.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'exhaustive':output['exhaustive_small'],
                      'original_pencils':[{'N':x['N'],'d':x['d'],'field':x['field'],
                        'trials':x['combination_trials'],'first_good':x['second_pencil_first_good_lambda'],
                        'comparisons':x['comparisons']} for x in output['original_gate_pencils']]},indent=2))
if __name__=='__main__': main()
