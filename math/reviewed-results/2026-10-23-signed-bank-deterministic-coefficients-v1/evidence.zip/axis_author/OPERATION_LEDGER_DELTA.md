# Coefficient-stage ledger delta only

23 October 2026 UTC. Candidate pending independent source-bound review.

Old accepted deterministic two-pencil coefficient bound: O(N^5) additions/multiplications, O(N^3) inversions, O(N^2) live storage. Its final pencil used O(N^2) scalar trials with O(N^3) dense axis testing per trial.

New candidate bound: O(N^4) additions/multiplications, O(N^3) inversions, O(N^2) live storage. The exact reciprocal-gcd test reduces a final candidate to O(N^2) arithmetic and O(N) inversions. A degree-2d truncated-Sylvester minor gives H_fast=2N-1 for all three original guards, so 2N distinct scalars suffice. The final scalar stage is O(N^3) arithmetic and O(N^2) inversions.

The TWO coprime-combination loops are still O(N^4) arithmetic and O(N^3) inversions in total and dominate the new deterministic coefficient-stage bound. Dense envelope setup remains O(N^3). Both failing and passing trials, coefficient generation, gcds, inverses, reductions, reads, writes, and the final coefficients are included. There is no claimed improvement to the existing expected O(N^3) Las Vegas coefficient bound.

No other source-ledger item is replaced. The quadratic coefficient-field setup remains O(Q^3) base-field arithmetic. The same genuine splitting-field requirement and enormous finite m!-overfield recipe remain paid. Actual root recovery, all amplitudes, raw weights, original branch inverses, output/storage coordinates, and base-coordinate expansion remain paid. The O(N^3) literal warm bank application and its exact multiplication/addition counts are unchanged. No end-to-end polynomial-time, smaller-bank, root-oracle, or FFT gain follows.
