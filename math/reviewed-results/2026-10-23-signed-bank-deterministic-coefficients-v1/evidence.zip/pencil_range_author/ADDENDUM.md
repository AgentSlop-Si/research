# Two-pencil coefficient generation in the improved original signed-bank range

23 October 2026 UTC. Separate compatibility/addendum candidate. Neither accepted source packet is modified. The prior independent pencil review accepted only its stated old range; the extension below is proved here and requires its own scoped review before publication.

## 1. Exact claim and byte-pinned inputs

Let N be odd, d>=4, N>=6d-2, and m=N-d. Let K contain a supplied primitive Nth root q, with characteristic not dividing N. Use exactly the original enlarged envelope

    D(z)=product_(i=2)^(d-1)(1-q^i z), rho=q^(2^-1 mod N), C_j=q^((4^-1 mod N)j^2),
    E={((C_j P(rho^j)+R(q^j))/D(q^j))_(j=0)^m : deg P<=3d-7, deg R<=d-2},
    U=E^perp, U0={g in U:g(0)=0}.

Given an explicitly represented list of H+1 distinct K-elements, H=d(d+1)+2m-1, the accepted two-pencil construction deterministically produces an actual monic degree-m g in this U with g(0)!=0, gcd(g,g')=1 and rank X_N(g)=N. Its coefficient-stage bound remains O(N^5) field additions/multiplications, O(N^3) inversions and O(N^2) live field elements, with all scalar trials included. The supplied-list/field-representation interface remains necessary.

For a supplied finite base field F_Q containing q, K=F_(Q^2) is sufficient, with the same separately charged quadratic-extension preparation. Combined with the accepted first-order representation theorem, the resulting legal g supports at most 2(N-d)+2 ORIGINAL signed banks over a genuine splitting extension. Choosing d=floor((N+2)/6) gives the already accepted 5N/3+O(1) bank count, not a further count improvement.

The exact source identities are:

- First-order author THEOREM.md: f45e740543fab9d42001cd3ee4cbc78bd2eacf266fed81b2362a47e3d5a5bb1e; AUTHOR_MANIFEST.json: 229581ad13d1ab87729a90cedda75a44f2e124fb567b909946af7e49ef6e495a.
- First-order independent REVIEW.md: b07002a9a7c3bb6b0e15db3682e32e7c891467892f4b5cc756fd5ebc64fa6b15; its MANIFEST.json: c8fc2d422e36da35d67ece7c647f3b60c164342e02c4184b22435a32a2219eb7.
- Two-pencil author THEOREM.md: 487180521ca6e29c038fd4deb1d79a2f9f60fe5039ed79233506a695013428ab; MANIFEST.json: 77d4a04fbfc41c5427c4872c0f6318227b2c5d226f05d6a2b9d7617b99635046.
- Two-pencil independent REVIEW.md: e5280e3adf81605c09def53a214081da4a017372569711d0a593a1ab4647b604; its MANIFEST.json: 7fa6d6e18e0148a452b89e14251306a9416163b428931c26ab36a799c99e4ef5.

SOURCE_PINS.json records exact paths, byte sizes and SHA-256 identities and verifies all 29 manifest members of these four packets. Both independent reviews were read in full as inert text. No author or historical scientific program was imported or executed.

## 2. What changes in the hypotheses, and what does not

The old pencil theorem's N>=8d-10 gate enters its construction through inherited facts about this exact U. Its own Sections 3-5 do not use the old support proof or its larger dimension lower bound. First-order Sections 3-7, as independently accepted, now supply all of the following on N>=6d-2, also after algebraic closure:

1. Every original denominator D(q^j) is nonzero, and this unchanged U lies in the kernel of every required original whole-left recurrence row.
2. gcd(U)=t-1 and gcd(U0)=t(t-1), with the multiplicities exactly as written.
3. The coefficient maps c0,c1,cm are jointly independent on U; c1,cm are independent on U0.
4. X_N(g) is polynomially defined for every monic g, including g(0)=0. Its N-column minors have coefficient degree at most d(d+1).

The actual available dimension bound is dim U>=N-5d+8>=d+6, not the old 3d-2 estimate. The algorithms need only the stated independent functionals, exact gcd facts and the upper bound dim U<=m+1=O(N). Thus no old dimension lower bound is being smuggled into a basis count or a solvability claim.

Set r=m-2, n=m-1, V0=U0/[t(t-1)] and V1=U/(t-1). Division by the fixed divisors is an injective linear map, not a restriction to a new polynomial dictionary. Both residual spaces have gcd one. Their maximum degrees are exactly r and n, respectively: cm remains a nonzero functional, and V0's constant/leading maps are -c1 and cm, hence independent. In particular r>0. These statements hold over K, not only over an algebraic closure.

## 3. First pencil, maximum-degree Euclid, and the actual axis witness

The coprime-combination lemma in pencil Section 3 is characteristic-free and independent of N,d. For fixed a of degree v, and a basis B of a space with gcd(a,B)=1, maintain the exact monic gcd d0=gcd(a,p), and choose lambda so that

    gcd(a,p+lambda b)=gcd(d0,b).

For each irreducible factor of a, divide out the minimum required multiplicity. Any remaining excess cancellation excludes at most one scalar. Thus v+1 distinct scalars suffice, or v+2 if preserving a nonzero linear functional. This proof accounts for multiplicities and does not factor a algorithmically. The Euclidean cost O(v^2) arithmetic/O(v) inversions additionally requires every basis polynomial and maintained p to have degree at most v; we verify that separately in both applications.

Independent endpoints make the equations f0(0)=coefficient_r(f0)=1 solvable in V0. Put phi(f)=coefficient_r(f)-f(0), a nonzero functional. Apply the combination lemma to a=f0, B a basis of V0, preserving phi. Here deg a=r is the maximum degree of V0, so every actual Euclidean operand has degree at most r. It returns f1 with gcd(f0,f1)=1 and phi(f1)!=0.

The pencil F=f0+Z f1 is irreducible over K(Z): a nontrivial factor independent of Z in a factorization in K[t,Z] would divide both f0 and f1. Its degree is r and its constant is nonzero in K(Z). If F and rev_r(F)=t^r F(1/t) shared a factor, irreducibility would give rev_r(F)=lambda F. Reversing twice gives lambda^2=1, so lambda is 1 or -1, also in characteristic two where these coincide. This would force the endpoint pairs of f0 and f1 to be dependent, contradicting their determinant phi(f1)!=0.

Therefore Res(F,rev_r F) is a nonzero polynomial of Z-degree at most 2r. Together with its constant and leading guards, the bad-scalar polynomial has degree at most 2r+2. Test 2r+3 distinct scalars and normalize the first success to obtain monic f in V0 with nonzero endpoints and gcd(f,rev_r f)=1. This uses a sublist of the common list because

    H-(2r+2)=d(d+1)+1>0.

Now g0=t(t-1)f is an actual monic member of U0, not merely a generic possibility. Also f(1)!=0, because otherwise f and its reversal share the root 1. The inherited axis argument is valid at this actual zero-constant witness: a row dependence A of degree <=N-1 is divisible by g0 and its cyclic reversal. Since A(0)=0, that reversal condition forces rev_r(f) to divide A. The pairwise coprime factors t, t-1, f, rev_r(f) have total degree 2m-2, while

    (2m-2)-(N-1)=N-2d-1 >=4d-3>0.

Hence A=0, and rank X_N(g0)=N. No squarefreeness of f was used. The zero root of g0 is solely an auxiliary degeneration and is never a physical bank node.

## 4. The zero-leading slice and all final guards

Let h0=t f in V1. It is monic of exact degree n. Define W={h in V1:coefficient_n(h)=0}. Since V1=K h0 direct-sum W,

    gcd(h0,W)=gcd(V1)=1.

This is the whole zero-leading slice, not an arbitrary selected subspace. Its dimension is dim U-1, and every member has degree at most n-1. The second combination lemma, with a=h0 and a basis of W, therefore satisfies the explicit operand-degree bound v=n and yields h1 in W with gcd(h0,h1)=1. In particular h1(0)!=0. Its n+1 scalar trials, and the first combination's r+2 trials, fit because H>=n=r+1.

For every Z, set h_Z=h0+Z h1 and g_Z=(t-1)h_Z. This is an affine pencil in the SAME monic degree-m slice of U. Coprimality makes h_Z irreducible over K(Z). The constant coefficient of h0' is f(0)!=0, so h_Z' is not identically zero, including in characteristic two. Thus h_Z is separable over K(Z). Moreover h_Z(1) is nonzero already at Z=0 since h0(1)=f(1)!=0. Consequently g_Z is squarefree over K(Z), and g_Z(0)=-Z h1(0) is a nonzero linear polynomial.

At Z=0 the axis has rank N, so some N-column minor restricts to a nonzero polynomial in Z. Its degree is at most d(d+1). To check that bound explicitly, coefficients of t^j mod a monic degree-m g have total degree at most max(0,j-m+1). The nonconstant row maxima of X_N are d,...,1 on rows 1,...,d and 1,...,d on rows m,...,N-1. These ranges remain disjoint because N>2d. Summing gives d(d+1). Restriction to the affine pencil cannot increase this degree.

The ordinary monic discriminant has degree at most 2m-2 in every characteristic, and is nonzero on this pencil by separability, even if it is a square in characteristic two. Multiplying that discriminant, the constant guard and the chosen axis minor gives a nonzero polynomial of Z-degree at most H. Thus testing all H+1 supplied scalars by actual nonzero-constant, ordinary-gcd and full-axis-rank checks must succeed. The algorithm need not identify the proof's minor. No genericity assumption replaces verification of the returned g.

## 5. Field size, old-range uses, and paid costs

N>=6d-2 and d>=4 imply N>=23, d<=N/4, m>=2d-2, N>2d+1 and 2(d-2)<N. These cover all retained fixed-divisor propagation, endpoint, axis and physical moment inequalities. In particular the new first-order source establishes the needed gcd facts without reusing the old annihilator's 8d-10 count.

For F_Q containing q, N divides Q-1, so Q>=N+1. Since

    H=d^2-d+2N-1 <= N^2/16+2N-1 < (N+1)^2/2 <= Q^2/2,

the quadratic coefficient field has more than H+1 elements. The strict middle inequality follows, for N>=23, from 7N^2/16-N+3/2>0. The existing O(Q^3) elementary quadratic-extension preparation and O(H) represented-element writes remain charged; this is not a polynomial-in-log(Q) setup claim. An arbitrary infinite field still needs the effective distinct-scalar interface. In characteristic zero, 0,...,H works; in positive characteristic repeated addition of 1 does not generally supply it. Changing coefficient field to obtain a list is not free.

For completeness, the old theorem's separate q-binomial section is NOT a prerequisite of either pencil. Its range inequality L-a=N-3d+2>=3d-6 also holds in the new range, where its left side is at least 3d. Its exhibited repeated-root counterexample and refusal to infer universal squarefreeness remain untouched. No structured-seed shortcut, F020 transport or new seed theorem is used here. The old gate's other appearances are scope labels and descriptions of its baseline deterministic grid, not additional mathematical conditions.

All matrix dimensions remain O(N). Basis/elimination preparation costs O(N^3); the two combination loops cost O(N^4) arithmetic and O(N^3) inversions; the reciprocal pencil costs O(N^3) arithmetic; and at most H+1=O(N^2) final rank tests, each O(N^3) arithmetic/O(N) inversions, give O(N^5) arithmetic/O(N^3) inversions overall. Candidate formation, failed trials, coefficient output and reads/writes fit these bounds. Streaming leaves O(N^2) live field elements. This changes ONLY deterministic coefficient selection in Section 3 of the first-order operation ledger (SHA-256 abc2f7bedcd39c630069a3f2764bf81972690ca51c5fd086a1a151963bdb72bf), with the exact same narrow scope as the pencil ledger delta (SHA-256 114adbaa27eba084d722933633e09f6604f55aa662e485246048a5d87a040954).

Genuine splitting/root recovery, Vandermonde moments, amplitudes/raw weights, all original branch denominators and physical outputs remain unchanged. The existing expected O(N^3) randomized coefficient algorithm is not improved. Literal warm application remains cubic: 2BN^2 multiplications and 2BN^2-BN-N additions for B<=2m+2 over the actual splitting field. No efficient full compiler, polynomial splitting degree, novelty, optimum, broader-owner closure or FFT claim follows.

## 6. Fresh evidence strictly outside the old domain

The new self-contained fresh_controls.py was written from the definitions, without importing or executing any source-packet scientific program. Normal Python and python -O outputs are byte-identical, with 14,030 explicit checks. Every fixture satisfies 6d-2<=N<8d-10:

- N=29,d=5, F233: old threshold 30, dim U=12, H=77.
- N=35,d=6, F211: old threshold 38, dim U=13, H=99; composite N.
- N=51,d=8, F256 defined by x^8+x^4+x^3+x+1: old threshold 54, dim U=19, H=157; characteristic two and composite N.
- N=63,d=10, F4096 defined by x^12+x^6+x^4+x+1, with q in the F64 subfield: old threshold 70, dim U=21, H=215; characteristic two, composite N and an actual quadratic coefficient field over a finite input field containing q.

Controls certify the binary defining polynomials, all nonzero field inverses, exact order of q, original denominators, every U/U0 basis member, exact fixed-divisor gcds, independent endpoints, both constructive combination loops and their maximum-degree operands, the entire zero-leading slice, actual g0 full axis rank, and every final legal-g guard. Full f0,f1,f,g0,h1,g coefficients and trial counts are recorded in CONTROL.json. Each fixture happens to pass the final pencil at its second scalar; this is not a uniform two-trial guarantee. No huge splitting field, physical bank arrays or accelerated Fourier evaluator were computed. These are bounded transcription controls; the proof above establishes the uniform domain extension.
