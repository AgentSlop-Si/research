#!/usr/bin/env python3
"""Fresh, self-contained exact transcription controls. No scientific-source imports.
Ascending coefficients throughout. All checks survive python -O.
"""
import hashlib, json, pathlib

CHECKS = 0

def check(ok, msg):
    global CHECKS
    CHECKS += 1
    if not ok:
        raise RuntimeError(msg)

def factors(n):
    ans=[]; p=2
    while p*p<=n:
        if n%p==0:
            ans.append(p)
            while n%p==0: n//=p
        p+=1
    if n>1: ans.append(n)
    return ans

def bitmul(a,b,mod):
    c=0; top=1<<(mod.bit_length()-1)
    while b:
        if b&1: c^=a
        b>>=1; a<<=1
        if a&top: a^=mod
    return c

def bitpow(a,n,mod):
    ans=1
    while n:
        if n&1: ans=bitmul(ans,a,mod)
        a=bitmul(a,a,mod); n>>=1
    return ans

def bitrem(a,b):
    while a and a.bit_length()>=b.bit_length():
        a ^= b<<(a.bit_length()-b.bit_length())
    return a

def bitgcd(a,b):
    while b: a,b=b,bitrem(a,b)
    return a

class Field:
    def __init__(self, p=None, modulus=None):
        self.p=p; self.modulus=modulus
        if p is not None:
            check(p>=2 and all(p%d for d in range(2,int(p**0.5)+1)), 'prime modulus')
            self.order=p; self.char=p
        else:
            degree=modulus.bit_length()-1; self.order=1<<degree; self.char=2
            check(bitpow(2,1<<degree,modulus)==2, 'binary Frobenius criterion')
            for ell in factors(degree):
                check(bitgcd(bitpow(2,1<<(degree//ell),modulus)^2,modulus)==1, 'binary irreducibility criterion')
            generator=next(a for a in range(2,self.order) if all(bitpow(a,(self.order-1)//ell,modulus)!=1 for ell in factors(self.order-1)))
            self.generator=generator; self.logs=[-1]*self.order; self.exps=[]; a=1
            for i in range(self.order-1):
                check(self.logs[a]==-1, 'primitive enumerator has no repeat')
                self.logs[a]=i; self.exps.append(a); a=bitmul(a,generator,modulus)
            check(a==1 and all(x>=0 for x in self.logs[1:]), 'primitive enumerator covers field')
            self.exps*=2
        for a in range(1,self.order): check(self.mul(a,self.inv(a))==1, 'all nonzero inverses')
        if self.modulus is not None:
            for a in range(self.order):
                b=(a*73+19)%self.order
                check(self.mul(a,b)==bitmul(a,b,self.modulus), 'independent multiplication transcription')
    def add(self,a,b): return (a+b)%self.p if self.p else a^b
    def neg(self,a): return (-a)%self.p if self.p else a
    def sub(self,a,b): return self.add(a,self.neg(b))
    def mul(self,a,b):
        if self.p: return a*b%self.p
        return self.exps[self.logs[a]+self.logs[b]] if a and b else 0
    def inv(self,a):
        if not a: raise ZeroDivisionError()
        return pow(a,self.p-2,self.p) if self.p else self.exps[self.order-1-self.logs[a]]
    def pow(self,a,n):
        if self.p: return pow(a,n,self.p)
        if n==0: return 1
        if not a: return 0
        return self.exps[self.logs[a]*n%(self.order-1)]
    def scalar(self,n): return n%self.char

class Exact:
    def __init__(self,F): self.F=F; self.max_euclid_degree=0
    def trim(self,a):
        a=list(a)
        while a and a[-1]==0: a.pop()
        return a
    def add(self,a,b):
        return self.trim([self.F.add(a[i] if i<len(a) else 0,b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
    def scale(self,a,s): return self.trim([self.F.mul(s,x) for x in a])
    def mul(self,a,b):
        if not a or not b: return []
        out=[0]*(len(a)+len(b)-1)
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b):
                    if y: out[i+j]=self.F.add(out[i+j],self.F.mul(x,y))
        return self.trim(out)
    def divmod(self,a,b):
        a=self.trim(a); b=self.trim(b)
        if not b: raise ZeroDivisionError()
        q=[0]*max(0,len(a)-len(b)+1); iv=self.F.inv(b[-1])
        while a and len(a)>=len(b):
            shift=len(a)-len(b); x=self.F.mul(a[-1],iv); q[shift]=x
            for j,y in enumerate(b): a[shift+j]=self.F.sub(a[shift+j],self.F.mul(x,y))
            a=self.trim(a)
        return self.trim(q),a
    def monic(self,a): return self.scale(a,self.F.inv(a[-1])) if a else []
    def gcd(self,a,b):
        a=self.trim(a); b=self.trim(b)
        self.max_euclid_degree=max(self.max_euclid_degree,len(a)-1,len(b)-1)
        while b: a,b=b,self.divmod(a,b)[1]
        return self.monic(a)
    def gcd_all(self,seq):
        a=[]
        for b in seq: a=self.gcd(a,b)
        return a
    def exact_div(self,a,b):
        q,r=self.divmod(a,b); check(not r,'exact fixed-divisor quotient'); return q
    def derivative(self,a): return self.trim([self.F.mul(self.F.scalar(i),a[i]) for i in range(1,len(a))])
    def value(self,a,x):
        out=0
        for c in reversed(a): out=self.F.add(self.F.mul(out,x),c)
        return out
    def pad(self,a,n): return list(a)+[0]*(n-len(a))
    def rref(self,A,width=None):
        A=[list(row) for row in A]
        if not A: return A,[]
        width=len(A[0]) if width is None else width; piv=[]; r=0
        for c in range(width):
            s=next((s for s in range(r,len(A)) if A[s][c]),None)
            if s is None: continue
            A[r],A[s]=A[s],A[r]; iv=self.F.inv(A[r][c]); A[r]=[self.F.mul(x,iv) for x in A[r]]
            for s in range(len(A)):
                if s!=r and A[s][c]:
                    f=A[s][c]; A[s]=[self.F.sub(x,self.F.mul(f,y)) for x,y in zip(A[s],A[r])]
            piv.append(c); r+=1
            if r==len(A): break
        return A,piv
    def kernel(self,A,width):
        R,piv=self.rref(A); free=[j for j in range(width) if j not in piv]; out=[]
        for j in free:
            v=[0]*width; v[j]=1
            for i,c in enumerate(piv): v[c]=self.F.neg(R[i][j])
            out.append(v)
        return out
    def rank(self,A): return len(self.rref(A)[1])
    def solve(self,A,b):
        R,piv=self.rref([row+[x] for row,x in zip(A,b)],len(A[0]))
        check(all(any(row[:-1]) or not row[-1] for row in R),'consistent endpoint solve')
        x=[0]*len(A[0])
        for i,p in enumerate(piv): x[p]=R[i][-1]
        return x
    def lincomb(self,B,c):
        a=[]
        for b,x in zip(B,c): a=self.add(a,self.scale(b,x))
        return a
    def dot(self,a,b):
        out=0
        for x,y in zip(a,b): out=self.F.add(out,self.F.mul(x,y))
        return out
    def axis(self,g,N):
        m=len(g)-1; remainders=[]; a=[1]
        for j in range(N):
            remainders.append(self.pad(a,m)); a=self.divmod([0]+a,g)[1]
        return [remainders[j]+[1]+remainders[(-j)%N] for j in range(N)]
    def combine(self,a,B,scalars,phi=None):
        v=len(a)-1; check(all(len(b)-1<=v for b in B),'Euclid operand degree qualifier')
        p=[] if phi is None else list(next(b for b in B if phi(b)))
        d=self.gcd(a,p); tries=[]
        for b in B:
            target=self.gcd(d,b); count=0
            for lam in scalars[:v+1+(phi is not None)]:
                candidate=self.add(p,self.scale(b,lam)); count+=1
                if (phi is None or phi(candidate)) and self.gcd(a,candidate)==target:
                    p=candidate; d=target; break
            else: raise RuntimeError('combination list exhausted')
            check(len(p)-1<=v,'maintained operand degree bound'); tries.append(count)
        check(d==[1] and self.gcd(a,p)==[1],'terminal coprime combination')
        if phi is not None: check(phi(p)!=0,'preserved endpoint functional')
        return p,tries

def run_fixture(N,d,F,coefficient_base_order=None):
    X=Exact(F); m=N-d; r=m-2; n=m-1; H=d*(d+1)+2*m-1
    check(N%2==1 and d>=4 and 6*d-2<=N<8*d-10,'strictly new-domain fixture')
    check(F.order>H,'represented scalar-list cardinality')
    scalars=list(range(H+1)); check(len(set(scalars))==H+1,'distinct scalar list')
    q=next(x for x in range(2,F.order) if F.pow(x,N)==1 and all(F.pow(x,N//p)!=1 for p in factors(N)))
    check(all(F.pow(q,j)!=1 for j in range(1,N)),'exact primitive order, all powers')
    rho=F.pow(q,pow(2,-1,N)); h=pow(4,-1,N)
    D=[1]
    for i in range(2,d): D=X.mul(D,[1,F.neg(F.pow(q,i))])
    E=[]; denominators=[X.value(D,F.pow(q,j)) for j in range(m+1)]
    check(all(denominators),'original envelope denominators')
    for k in range(3*d-6):
        E.append([F.mul(F.pow(q,(h*j*j+pow(2,-1,N)*k*j)%N),F.inv(denominators[j])) for j in range(m+1)])
    for ell in range(d-1):
        E.append([F.mul(F.pow(q,ell*j),F.inv(denominators[j])) for j in range(m+1)])
    U=X.kernel(E,m+1); U0=X.kernel(E+[[1]+[0]*m],m+1)
    check(len(U)>=N-5*d+8>=d+6,'replacement dimension bound')
    for u in U:
        check(all(X.dot(row,u)==0 for row in E),'every full-U basis member passes original moments')
    for u in U0:
        check(u[0]==0 and all(X.dot(row,u)==0 for row in E),'every zero-constant-slice basis member passes original moments')
    check(X.rank([[u[j] for u in U] for j in (0,1,m)])==3,'joint original endpoint independence')
    tm1=[F.neg(1),1]; ttm1=[0,F.neg(1),1]
    check(X.gcd_all(U)==tm1,'exact original fixed divisor U')
    check(X.gcd_all(U0)==ttm1,'exact original fixed divisor U0')
    V0=[X.exact_div(u,ttm1) for u in U0]; V1=[X.exact_div(u,tm1) for u in U]
    check(X.gcd_all(V0)==[1] and X.gcd_all(V1)==[1],'both residual gcds')
    endpoint=[[b[0] if b else 0 for b in V0],[b[r] if len(b)>r else 0 for b in V0]]
    check(X.rank(endpoint)==2,'V0 endpoint independence')
    f0=X.lincomb(V0,X.solve(endpoint,[1,1])); check(len(f0)==r+1 and f0[0]==1 and f0[-1]==1,'normalized f0')
    phi=lambda a:F.sub(a[r] if len(a)>r else 0,a[0] if a else 0)
    f1,first_loop=X.combine(f0,V0,scalars,phi)
    check(phi(f1)!=0,'nonzero endpoint determinant, including characteristic two')
    check(H>=2*r+2 and H>=n and H>=r+1,'all scalar sublists fit')
    reciprocal_trials=0
    for z in scalars[:2*r+3]:
        candidate=X.add(f0,X.scale(f1,z)); reciprocal_trials+=1
        if len(candidate)==r+1 and candidate[0] and X.gcd(candidate,candidate[::-1])==[1]:
            f=X.monic(candidate); reciprocal_scalar=z; break
    else: raise RuntimeError('reciprocal pencil failed')
    g0=X.mul(ttm1,f); check(g0[0]==0 and len(g0)==m+1 and g0[-1]==1,'auxiliary zero-root witness only')
    check(X.value(f,1)!=0,'simple fixed root of auxiliary witness')
    check(2*m-2>N-1 and N>2*d+1,'new-range axis witness degree')
    check(X.rank(X.axis(g0,N))==N,'actual full original auxiliary axis rank')
    check(all(X.dot(row,X.pad(g0,m+1))==0 for row in E),'auxiliary original U membership')
    h0=[0]+f
    Wc=X.kernel([[b[n] if len(b)>n else 0 for b in V1]],len(V1))
    W=[X.lincomb(V1,c) for c in Wc]
    check(len(W)==len(V1)-1 and all(len(w)<=n for w in W),'zero-leading slice actual basis')
    check(X.gcd_all([h0]+W)==[1],'coprimality of h0 and entire zero-leading slice')
    h1,second_loop=X.combine(h0,W,scalars)
    check(h1[0]!=0,'second pencil breaks zero root')
    check(X.derivative(h0)[0]==f[0]!=0,'ordinary derivative survives in every characteristic')
    final_trials=0; failure_counts={'zero_constant':0,'nonsquarefree':0,'axis_rank':0}
    for z in scalars:
        g=X.mul(tm1,X.add(h0,X.scale(h1,z))); final_trials+=1
        check(len(g)==m+1 and g[-1]==1,'every pencil member monic of maximum degree')
        check(all(X.dot(row,X.pad(g,m+1))==0 for row in E),'every tested final member in original U')
        if not g[0]: failure_counts['zero_constant']+=1; continue
        if X.gcd(g,X.derivative(g))!=[1]: failure_counts['nonsquarefree']+=1; continue
        if X.rank(X.axis(g,N))!=N: failure_counts['axis_rank']+=1; continue
        final_scalar=z; break
    else: raise RuntimeError('final pencil exhausted')
    check(final_trials<=H+1,'final scalar guarantee')
    check(g[0]!=0 and X.gcd(g,X.derivative(g))==[1] and X.rank(X.axis(g,N))==N,'all final exact guards')
    check(X.max_euclid_degree<=m,'all observed Euclidean operands degree O(N)')
    Q=coefficient_base_order or F.order
    check((Q-1)%N==0 and Q>=N+1,'finite input field root size')
    check(Q*Q>2*H and Q*Q>=H+1,'quadratic coefficient field list margin')
    if coefficient_base_order:
        check(F.order==Q*Q and F.pow(q,Q)==q,'genuine quadratic coefficient field over q subfield')
    return {'N':N,'d':d,'m':m,'r':r,'n':n,'H':H,'new_gate':6*d-2,'old_gate':8*d-10,
            'strictly_outside_old_range':True,'characteristic':F.char,'field_order':F.order,
            'binary_modulus':F.modulus,'input_field_order':Q,'q':q,'dim_U':len(U),'dim_U0':len(U0),
            'dim_W':len(W),'first_combination_trials':first_loop,'second_combination_trials':second_loop,
            'reciprocal_trials':reciprocal_trials,'reciprocal_scalar':reciprocal_scalar,
            'final_trials':final_trials,'final_scalar':final_scalar,'failed_final_guards':failure_counts,
            'maximum_observed_euclid_degree':X.max_euclid_degree,'f0':f0,'f1':f1,'f':f,'g0':g0,'h1':h1,'g':g}

def main():
    results=[run_fixture(29,5,Field(p=233)),run_fixture(35,6,Field(p=211)),
             run_fixture(51,8,Field(modulus=0x11b)),run_fixture(63,10,Field(modulus=0x1053),64)]
    output={'status':'PASS','checks':CHECKS,'fixtures':results,
            'author_or_historical_scientific_code_executed_or_imported':False,
            'splitting_fields_or_physical_bank_arrays_computed':False,
            'scope':'Fresh full original-U two-pencil coefficient controls strictly below old gate, not a substitute for proof.'}
    print(json.dumps(output,indent=2,sort_keys=True))
if __name__=='__main__': main()
