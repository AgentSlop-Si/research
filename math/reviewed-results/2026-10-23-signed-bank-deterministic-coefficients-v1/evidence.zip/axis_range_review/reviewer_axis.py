"""Fresh axis proof controls; reused arithmetic is prior reviewer-owned, not author code."""
import itertools,json,pathlib
from reviewer_arithmetic import Fld,trim,axis,build,member,ck,cnt

def ps(F,a,b):return F.pa(a,F.sc(b,F.neg(1)))
def invmod(F,a,h):
 r0,r1=h,F.dv(a,h)[1];v0,v1=[0],[1]
 while r1!=[0]:
  q,r=F.dv(r0,r1);r0,r1=r1,r;v0,v1=v1,ps(F,v0,F.pm(q,v1))
 ck(len(r0)==1 and r0[0]!=0,'inverse gcd certificate')
 return F.dv(F.sc(v0,F.power(r0[0],-1)),h)[1]
def fast(F,h,N,d):
 c=h[0];n=len(h)-1;s=d-1
 if not c:raise ValueError('nonzero constant required')
 v=trim(h[::-1]);D=F.gc(h,v);hb=F.dv(h,D)[0];ell=len(hb)-1
 if ell<s:return False,hb,'ell<s'
 H=[1]*N;Hdiv,rem=F.dv(H,D)
 if rem!=[0]:return True,None,'D_not_divide_H'
 vb=F.dv(v,D)[0];K=h[1:]
 b0=F.dv(F.pm(invmod(F,vb,hb),F.sc(F.pm(K,Hdiv),F.neg(1))),hb)[1]
 if ell==s:return False,F.pa(b0,hb),'ell=s'
 bad=len(b0)==s+1 and b0[-1]==1
 return not bad,b0 if bad else None,'ell>s_bad' if bad else 'ell>s_full'
def affine(F,h,N,d):
 n=len(h)-1;c=h[0];v=trim(h[::-1]);cols=[]
 for s in range(d):
  a=[0]*(s+1)+v
  if s==d-1:a=ps(F,a,F.sc([1]*N,c))
  ck(len(trim(a))<=N-1,'top degree cancels')
  cols.append(a+[0]*(N-1-len(a)))
 for s in range(d):
  a=F.sc([0]*s+h,F.neg(1));cols.append(a+[0]*(N-1-len(a)))
 return [[cols[j][i] for j in range(2*d)] for i in range(N-1)]
def certificate(F,h,N,d,b):
 bp=b+[0]*(d-len(b));a=bp[::-1];g=F.pm([F.neg(1),1],h);A=F.pm(g,a)
 ck(A!=[0] and len(A)<=N,'nonzero relation degree')
 J=[A[0]]+[0]*(N-1)
 for j in range(1,len(A)):J[N-j]=A[j]
 ck(F.dv(A,g)[1]==[0] and F.dv(J,g)[1]==[0] and F.ev(A,1)==0,'original three relation conditions')
 X=axis(F,g,N);beta=A+[0]*(N-len(A))
 for col in range(len(X[0])):
  total=0
  for z,row in zip(beta,X):total=F.add(total,F.mul(z,row[col]))
  ck(total==0,'certificate on literal X')
def test(F,h,N,d,label):
 g=F.pm([F.neg(1),1],h);X=axis(F,g,N);M=affine(F,h,N,d)
 dense=len(F.rr(X)[1])==N;aff=len(F.rr(M)[1])==2*d
 ck(dense==aff,'literal X affine M equivalence')
 if h[0]:
  passed,b,branch=fast(F,h,N,d);ck(passed==dense,'fast exact rank decision')
  if b is not None:certificate(F,h,N,d,b)
 else:branch='zero_constant_affine_only'
 return {'label':label,'N':N,'d':d,'field':F.q,'branch':branch,'full_rank':dense}
