"""Scoped composition controls, using only reviewer-owned mathematics routines/data."""
from reviewer_axis import *
import hashlib
P=pathlib.Path('pencil_range_review/CONTROL.json')
records=[]
for f in json.loads(P.read_text())['fixtures']:
 F=Fld(f['characteristic'],{256:0x11b,4096:0x1053}.get(f['field_size'],0))
 N,d,q=f['N'],f['d'],f['q'];m=N-d;r=m-2;n=m-1
 ck(6*d-2<=N<8*d-10,'strictly new domain')
 ck(F.power(q,N)==1 and all(F.power(q,j)!=1 for j in range(1,N)),'original primitive root')
 if F.q==4096:ck(F.power(q,64)==q and sum(F.power(x,64)==x for x in range(F.q))==64,'actual quadratic subfield interface')
 E,_,_=build(F,N,d,q);h0,rem=F.dv(f['axis_witness'],[F.neg(1),1]);ck(rem==[0],'original witness division');h1=f['h1']
 good=[]
 for lam in [0,1,2,3,2*N-1]:
  h=F.pa(h0,F.sc(h1,lam));g=F.pm([F.neg(1),1],h);member(F,E,g)
  rec=test(F,h,N,d,'new_domain_scalar_'+str(lam));records.append(rec)
  if g[0] and F.gc(g,F.deriv(g))==[1] and fast(F,h,N,d)[0]:good.append(lam)
 ck(bool(good),'actual fully guarded point in new list')
for d in range(4,151):
 for N in range(6*d-2,8*d+11):
  if N%2==0:continue
  m=N-d;r=m-2;n=m-1
  ck(N-1-2*d==r-(d-1)==N-2*d-1>=4*d-3>0,'minor and witness margin')
  ck(n-(d-1)>=4*d-2>0,'normalized residue margin')
  ck(max(r+2,n+1,2*r+3)<=2*N and 2*d+1+2*m-2==2*N-1,'all scalar-list consumers')
a=pathlib.Path('axis_range_author')
for item in json.loads((a/'MANIFEST.json').read_text())['files']:
 b=(a/item['path']).read_bytes();ck(len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'],'author member binding')
def bind(x):
 if isinstance(x,dict):
  if 'path' in x and 'sha256' in x:
   b=pathlib.Path(x['path']).read_bytes();ck(hashlib.sha256(b).hexdigest()==x['sha256'],'selected source binding')
  for v in x.values():bind(v)
 elif isinstance(x,list):
  for v in x:bind(v)
bind(json.loads((a/'SOURCE_PINS.json').read_text()))
print(json.dumps({'status':'PASS','author_code_executed':False,'reviewer_routines_and_fixture_data_reused':True,'checks':sum(cnt.values()),'categories':dict(sorted(cnt.items())),'records':records},indent=2,sort_keys=True))
