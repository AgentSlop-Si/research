"""Fresh reviewer implementation of the two pencils in the exact original envelope."""
from collections import Counter
from math import gcd as igcd
import json
cnt=Counter()
def ck(v,label):
 cnt[label]+=1
 if not v:raise RuntimeError(label)
class Fld:
 def __init__(self,p,mod=0):self.p=p;self.mod=mod;self.q=p if not mod else 1<<(mod.bit_length()-1)
 def add(self,a,b):return (a+b)%self.p if not self.mod else a^b
 def neg(self,a):return -a%self.p if not self.mod else a
 def sub(self,a,b):return self.add(a,self.neg(b))
 def mul(self,a,b):
  if not self.mod:return a*b%self.p
  r=0
  while b:
   if b&1:r^=a
   b>>=1;a<<=1
   if a>=self.q:a^=self.mod
  return r
 def power(self,a,n):
  if n<0:
   ck(a!=0,'guarded inverse');return self.power(self.power(a,self.q-2),-n)
  r=1
  while n:
   if n&1:r=self.mul(r,a)
   a=self.mul(a,a);n//=2
  return r
 def sc(self,a,s):return trim([self.mul(x,s) for x in a])
 def pa(self,a,b):return trim([self.add(a[j] if j<len(a) else 0,b[j] if j<len(b) else 0) for j in range(max(len(a),len(b)))])
 def pm(self,a,b):
  r=[0]*(len(a)+len(b)-1)
  for i,x in enumerate(a):
   for j,y in enumerate(b):r[i+j]=self.add(r[i+j],self.mul(x,y))
  return trim(r)
 def dv(self,a,b):
  a=a[:];out=[0]*max(1,len(a)-len(b)+1);iv=self.power(b[-1],-1)
  while a!=[0] and len(a)>=len(b):
   d=len(a)-len(b);c=self.mul(a[-1],iv);out[d]=c
   for j,v in enumerate(b):a[j+d]=self.sub(a[j+d],self.mul(c,v))
   trim(a)
  return trim(out),a
 def gc(self,a,b):
  while b!=[0]:a,b=b,self.dv(a,b)[1]
  return self.sc(a,self.power(a[-1],-1)) if a!=[0] else [0]
 def ev(self,a,x):
  v=0
  for c in a[::-1]:v=self.add(self.mul(v,x),c)
  return v
 def deriv(self,a):return trim([self.mul(j%self.p,a[j]) for j in range(1,len(a))] or [0])
 def rr(self,rows):
  a=[r[:] for r in rows];r=0;piv=[]
  for col in range(len(a[0])):
   z=next((j for j in range(r,len(a)) if a[j][col]),None)
   if z is None:continue
   a[r],a[z]=a[z],a[r];a[r]=self.sc(a[r],self.power(a[r][col],-1));a[r]+=[0]*(len(rows[0])-len(a[r]))
   for j in range(len(a)):
    if j!=r and a[j][col]:
     f=a[j][col];a[j]=[self.sub(v,self.mul(f,u)) for v,u in zip(a[j],a[r])]
   piv.append(col);r+=1
   if r==len(a):break
  return a,piv
 def ker(self,rows):
  a,piv=self.rr(rows);out=[]
  for free in range(len(rows[0])):
   if free in piv:continue
   z=[0]*len(rows[0]);z[free]=1
   for i,c in enumerate(piv):z[c]=self.neg(a[i][free])
   out.append(trim(z))
  return out

def trim(a):
 while len(a)>1 and a[-1]==0:a.pop()
 return a

def axis(F,g,N):
 m=len(g)-1;rema=[[1]+[0]*(m-1)]
 for j in range(1,N):
  r=F.dv([0]+rema[-1],g)[1];rema.append(r+[0]*(m-len(r)))
 return [rema[a]+[1]+rema[(-a)%N] for a in range(N)]

def build(F,N,d,q):
 m=N-d;hh=pow(4,-1,N);ee=pow(2,-1,N);rho=F.power(q,ee)
 D=[1]
 for i in range(2,d):D=F.pm(D,[1,F.neg(F.power(q,i))])
 Dvals=[F.ev(D,F.power(q,j)) for j in range(m+1)]
 ck(all(Dvals),'original denominator guards')
 E=[]
 for a in range(3*d-6):E.append([F.mul(F.power(q,hh*j*j+ee*a*j),F.power(Dvals[j],-1)) for j in range(m+1)])
 for a in range(d-1):E.append([F.mul(F.power(q,a*j),F.power(Dvals[j],-1)) for j in range(m+1)])
 return E,D,Dvals

def member(F,E,g):
 for row in E:
  val=0
  for x,y in zip(row,g+[0]*(len(row)-len(g))):val=F.add(val,F.mul(x,y))
  ck(val==0,'exact original U equation')

def combo(F,a,W,grid,phi=None):
 p=[0] if phi is None else next(b[:] for b in W if phi(b))
 dd=F.gc(a,p)
 for b in W:
  target=F.gc(dd,b);ok=False
  for x in grid[:len(a)+(1 if phi else 0)]:
   test=F.pa(p,F.sc(b,x));cnt['gcd scalar trials']+=1
   if F.gc(a,test)==target and (phi is None or phi(test)):
    p=test;dd=target;ok=True;break
  ck(ok,'bounded greedy scalar avoidance')
 ck(dd==[1] and F.gc(a,p)==[1],'terminal coprime combination')
 return p
fixtures=[]
for N,d,F in [(23,4,Fld(139)),(35,5,Fld(281)),(51,4,Fld(2,0x11b))]:
 ck(all(F.mul(x,F.power(x,-1))==1 for x in range(1,F.q)),'field inverse census')
 q=next(x for x in range(2,F.q) if F.power(x,N)==1 and all(F.power(x,k)!=1 for k in range(1,N)))
 m=N-d;r=m-2;n=m-1;H=d*(d+1)+2*m-1;grid=list(range(H+1))
 ck(H<F.q and N>=8*d-10,'original domain and represented scalar list')
 E,D,Dv=build(F,N,d,q);U=F.ker(E);U0=F.ker(E+[[1]+[0]*m]);lin=[F.neg(1),1]
 V0=[];V1=[]
 for u in U0:
  v,rem=F.dv(u,[0,F.neg(1),1]);ck(rem==[0],'U0 exact forced-factor division');V0.append(v)
 for u in U:
  v,rem=F.dv(u,lin);ck(rem==[0],'U exact forced-factor division');V1.append(v)
 def lead(v):return v[r] if len(v)>r else 0
 pair=next((a,b) for a in V0 for b in V0 if F.sub(F.mul(a[0],lead(b)),F.mul(b[0],lead(a))))
 a,b=pair;det=F.sub(F.mul(a[0],lead(b)),F.mul(b[0],lead(a)));iv=F.power(det,-1)
 aa=F.mul(F.sub(lead(b),b[0]),iv);bb=F.mul(F.sub(a[0],lead(a)),iv)
 f0=F.pa(F.sc(a,aa),F.sc(b,bb));ck(f0[0]==1 and lead(f0)==1,'paid endpoint solution')
 phi=lambda v:F.sub(lead(v),v[0]);f1=combo(F,f0,V0,grid,phi)
 for val in grid[:2*r+3]:
  f=F.pa(f0,F.sc(f1,val));cnt['reciprocal scalar trials']+=1
  if len(f)==r+1 and f[0] and F.gc(f,trim(f[::-1]))==[1]:break
 else:raise RuntimeError('reciprocal pencil')
 f=F.sc(f,F.power(f[-1],-1));g0=F.pm([0,F.neg(1),1],f);member(F,E,g0)
 ck(len(F.rr(axis(F,g0,N))[1])==N,'actual auxiliary axis rank')
 ck(F.ev(f,1)!=0,'auxiliary simple fixed root')
 h0=[0]+f;W=[]
 for v in V1:
  l=v[n] if len(v)>n else 0
  w=F.pa(v,F.sc(h0,F.neg(l)))
  if w!=[0]:W.append(w)
 h1=combo(F,h0,W,grid);ck(len(h1)<=n and h1[0]!=0,'second pencil endpoints')
 for val in grid:
  g=F.pm(lin,F.pa(h0,F.sc(h1,val)));cnt['final scalar trials']+=1
  if not g[0] or F.gc(g,F.deriv(g))!=[1]:continue
  if len(F.rr(axis(F,g,N))[1])!=N:continue
  break
 else:raise RuntimeError('final pencil')
 member(F,E,g);ck(len(g)==m+1 and g[-1]==1 and g[0] and F.gc(g,F.deriv(g))==[1],'all final original guards')
 fixtures.append({'N':N,'d':d,'field_size':F.q,'characteristic':F.p,'q':q,'H':H,'U_dimension':len(U),'f0':f0,'f1':f1,'axis_witness':g0,'h1':h1,'chosen_final_scalar':val,'g':g})
# Repeated irreducible multiplicities: target is the exact gcd, not squarefree support.
F=Fld(139);a=F.pm(F.pm([F.neg(1),1],[F.neg(1),1]),[F.neg(2),1]);W=[[1,1],[F.neg(1),1]]
z=combo(F,a,W,list(range(10)));ck(F.gc(a,z)==[1],'multiplicity-aware selection')
# Mutation: coprime pair alone does not prevent a fixed reversal pencil.
for lam in [0,1,2,17]:
 pal=[1,lam,1]
 ck(F.gc(pal,pal[::-1])!=[1],'missing endpoint determinant detected')
ck(F.gc([1,0,1],[0,1])==[1],'coprime alone insufficient for reciprocal guard')
x1=[F.neg(1),1];x2=[F.neg(2),1];p2=F.pm(x1,x1)
a=F.pm(F.pm(p2,x1),F.pm(x2,x2));b=F.pm(p2,[0,1])
target=F.gc(F.gc(a,p2),b)
ck(target==F.gc(a,p2),'multiplicity target retains repeated factor')
ck(F.gc(a,F.pa(p2,F.sc(b,F.neg(1))))!=target,'multiplicity-increasing cancellation detected')
# Independent original structured seed and its actual admissible failure.
F=Fld(47);N=23;d=4;q=32;m=N-d;E,D,Dv=build(F,N,d,q)
h=pow(4,-1,N);rho=F.power(q,pow(2,-1,N));L=N-2*d+1
coef=[1];base=F.neg(F.power(q,h*(1-2*L)%N))
for j in range(1,L+1):coef.append(F.mul(coef[-1],F.mul(F.sub(1,F.power(rho,L-j+1)),F.power(F.sub(1,F.power(rho,j)),-1))))
A0=[F.mul(c,F.power(base,j)) for j,c in enumerate(coef)];Q=[1]
for i in range(d-1):Q=F.pm(Q,[F.neg(F.power(q,i)),1])
A=F.pm(Q,A0);g=[F.mul(c,Dv[j]) for j,c in enumerate(A)];g=F.sc(g,F.power(g[-1],-1));member(F,E,g)
ck(F.gc(g,F.deriv(g))==[46,1],'structured seed repeated root detected')
ck(len(F.rr(axis(F,g,N))[1])==N and g[0]==32,'seed rank does not imply squarefree')
# Exact chirp polynomial product, not a transported F020 theorem.
prod=[1]
for i in range(L):prod=F.pm(prod,[1,F.neg(F.power(rho,(1-L+i)%N))])
ck([F.mul(F.power(q,h*j*j),c) for j,c in enumerate(A0)]==prod,'finite q-binomial chirp identity')
print(json.dumps({'status':'PASS','independent':True,'author_code_executed':False,'checks':sum(cnt.values()),'categories':dict(sorted(cnt.items())),'fixtures':fixtures,'seed_failure':{'N':N,'d':d,'field_size':47,'q':q,'g':g,'gcd':[46,1],'axis_rank':N},'limits':'No splitting field or physical bank arrays are instantiated; the controls verify the coefficient-stage theorem only.'},indent=2,sort_keys=True))
