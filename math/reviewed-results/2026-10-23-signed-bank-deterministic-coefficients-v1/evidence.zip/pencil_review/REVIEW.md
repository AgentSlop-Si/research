# Independent review: deterministic original-U coefficient generation

23 October 2026 UTC. **ACCEPT the scoped coefficient-stage theorem and narrow operation-ledger replacement.** No full bank compiler, root-field speedup, historical novelty or FFT claim is accepted.

## 1. Frozen scope and baseline

Author directory: `signed_bank_deterministic_pencil_20261023_v1`.

- THEOREM.md SHA-256: `487180521ca6e29c038fd4deb1d79a2f9f60fe5039ed79233506a695013428ab`.
- MANIFEST.json SHA-256: `77d4a04fbfc41c5427c4872c0f6318227b2c5d226f05d6a2b9d7617b99635046`.
- OPERATION_LEDGER_DELTA.md SHA-256: `114adbaa27eba084d722933633e09f6604f55aa662e485246048a5d87a040954`.

The domain remains odd N, d>=4, N>=8d-10, m=N-d, a field containing a primitive N-th root q, and characteristic not dividing N. The exact enlarged envelope E and U=E^perp are unchanged. The new algorithm requires an explicitly represented list of H+1 distinct coefficient-field elements, H=d(d+1)+2m-1. It returns an actual monic degree-m g in U with nonzero constant, gcd(g,g')=1, and full original axis rank X_N(g)=N.

I compared the exact accepted all-characteristics baseline theorem and operation ledger. That baseline already proves gcd(U)=t-1, gcd(U0)=t(t-1), joint endpoint independence, the reciprocal auxiliary-axis argument, and degree at most H for a simultaneous guard product. It gives an expected O(N^3) randomized coefficient stage and a deterministic grid with exponentially many points. The new proof constructively replaces only the latter by polynomially many one-parameter tests. It does not supersede the expected randomized bound.

This review does not silently extend the stated domain to the newer N>=6d-2 theorem. It does not lower the 2m+2 bank bound, solve actual root recovery, or supply an efficient splitting field. The genuine extension, physical bank definitions, sign orientations, branch denominators and output costs remain as in the baseline. Optional later coordinate notes are not included in this acceptance.

## 2. Exact coprime-combination algorithm

Let a have degree v, and let W be spanned by b_i with gcd(a,W)=1. Maintaining d=gcd(a,p), the next target is d_new=gcd(d,b_i). For each irreducible pi dividing a, divide by the pi-adic multiplicity in d_new. If a still contains pi, at least one of p,b_i has nonzero reduction, so p+lambda b_i has excess pi multiplicity for at most one field scalar lambda. If all of a's pi multiplicity is already in d_new, no condition is needed. This treats multiplicities exactly, not just distinct support. There are at most v forbidden scalars. Testing v+1 scalars and comparing exact monic gcds therefore finds the next p without factoring a.

For a preserved nonzero linear functional, start at a basis vector on which it is nonzero and exclude at most one additional scalar at each step. Processing the whole basis still terminates at gcd one. This is valid over arbitrary characteristic and does not assume an infinite field. The candidate's explicit degree qualifier is necessary for its Euclidean cost: in its two actual applications both operands have degree at most v, so dense Euclid is O(v^2) arithmetic and O(v) inversions per trial. The abstract selection lemma alone has no such degree bound.

## 3. First pencil: find the actual original auxiliary axis witness

Let V0=U0/[t(t-1)], r=m-2. Its independent endpoint functionals make the paid equations f0(0)=lead_r(f0)=1 solvable. The functional phi(f)=lead_r(f)-f(0) is nonzero on V0. Apply the exact combination algorithm to f0 and V0 while preserving phi. This gives gcd(f0,f1)=1 and phi(f1)!=0.

F=f0+Z f1 is irreducible in k(Z)[t]. A factorization in k[t,Z] of a primitive polynomial of degree one in Z would have a Z-independent factor dividing both f0 and f1; this is impossible. Gauss's lemma then applies. Its t-degree is r and its constant coefficient is nonzero over k(Z).

If F shared a factor with rev_r F, irreducibility and equal degree would give rev_r F=lambda F. Reversal is an involution, so lambda^2=1 in k(Z), hence lambda is +1 or -1, with the two identical in characteristic two. This forces dependent endpoint pairs. Their determinant is exactly phi(f1), a contradiction. Therefore the reciprocal resultant is nonzero as a polynomial in Z. Its degree is at most 2r; adjoining the constant and leading factors gives degree at most 2r+2. The first successful one of 2r+3 scalar trials produces a full-degree polynomial with nonzero endpoints and coprime reversal. Normalization preserves V0.

The resulting g0=t(t-1)f is an actual monic original-U axis witness by the accepted reciprocal argument, which uses 2m-2>N-1. It is only an auxiliary polynomial: its zero root is never made into a physical bank. No squarefreeness of f is assumed. Coprime reversal implies f(1)!=0, so g0's root at 1 is simple.

Endpoint independence cannot be omitted. A coprime pair such as t^2+1 and t can generate an entirely self-reciprocal pencil; the fresh controls explicitly detect this failure of the weaker argument.

## 4. Second pencil: simultaneously satisfy all original guards

Let h0=t f in V1=U/(t-1), monic of degree n=m-1. The subspace W of degree below n complements k h0, so gcd(h0,W)=gcd(V1)=1. A second exact combination gives h1 in W coprime to h0. Since t divides h0, h1(0) is nonzero.

The pencil h_Z=h0+Z h1 is irreducible over k(Z), and its ordinary derivative is nonzero there: the t coefficient of h0 equals f(0)!=0, so that coefficient cannot vanish identically as a polynomial in Z, even in characteristic two. Irreducibility therefore implies separability over k(Z). Also h_Z(1) is nonzero, already at Z=0. Thus g_Z=(t-1)h_Z is generically squarefree, monic of degree m, and always lies in the same U. Its constant is the nonzero polynomial -Z h1(0).

At Z=0 the original axis matrix has full rank. Consequently some N-column minor restricts to a nonzero polynomial in Z of degree at most d(d+1). The monic discriminant has total degree at most 2m-2 in every characteristic, and is nonzero here. Their product with the constant has degree at most H. Thus at most H scalars fail a guard. Testing the supplied H+1-element list by exact nonzero-constant, ordinary-gcd and full-rank checks is guaranteed to succeed. The implementation does not need to identify the theoretical nonzero minor. No genericity assertion substitutes for final candidate verification.

## 5. Cost and field accounting

The operation-ledger replacement is justified:

- Original E construction, U/V0/V1/W bases and endpoint solve: O(N^3) field arithmetic and O(N^2) storage.
- Each of the two combination loops: O(N) directions times O(N) scalar trials, each O(N^2) arithmetic and O(N) inversions, hence O(N^4) arithmetic and O(N^3) inversions in total order.
- Reciprocal pencil: O(N) tests, each within O(N^2) arithmetic and O(N) inversions.
- Final pencil: at most H+1=O(N^2) tests, each including all quotient remainders, gcd and the entire original axis rank, within O(N^3) arithmetic and O(N) inversions.

Therefore the conservative total is O(N^5) additions/multiplications, O(N^3) inversions and O(N^2) live field elements. Candidate formation, unsuccessful trials, scalar/function tests, reads/writes and final coefficient output fit these bounds. The claimed improvement is deterministic coefficient search only.

For a supplied finite base field F_Q, the accepted bound Q^2>2H makes its existing quadratic coefficient extension large enough. The O(Q^3) elementary preparation of that extension is unchanged and is not polynomial in log Q. Enumerating H+1 distinct represented extension elements and its bit-output cost are charged. The new field-operation theorem does not make arbitrary field representation free.

For an infinite field the list interface is explicit. Characteristic zero permits 0,...,H by H additions, without a bit-growth assertion. In positive characteristic repeated addition of 1 does not produce such a list. An arbitrary ineffective infinite field is therefore not misrepresented as having a free deterministic coefficient algorithm. Passing to a finite extension of F_p(q) changes the coefficient-field claim and must be paid.

All splitting-field/root-recovery, moment/amplitude, actual branch-inverse, all-output, storage and base-coordinate costs remain unchanged. The existing expected O(N^3) Las Vegas coefficient option remains asymptotically faster in expected field operations. No FFT or end-to-end compiler gain is inferred.

## 6. Structured q-binomial direction and actual failure

I independently checked the finite q-binomial exponent identity. With L=N-2d+1, the chirp transform of the stated A0 is the product with roots rho^0,...,rho^(L-1). Multiplying by Q of degree d-1 shifts the transformed argument by rho^b; the common surviving roots include all required chirp moments because L-(d-1)>=3d-6. The ordinary moments vanish at the required q powers from Q. Coefficientwise multiplication by the nonzero D(q^j) therefore gives a full-degree original-U polynomial with nonzero constant.

Membership is not guard survival. I reconstructed the exact N=23,d=4,F_47,q=32 seed independently and found the reported constant 32, full axis rank 23, and gcd(g,g')=t-1. Thus the fixed root 1 is genuinely repeated even though the original moments and axis guard pass. The proof correctly avoids transferring F020 across multiplication by Q, the nontrivial q-difference operator, changed phase/degree and characteristic. This finite counterexample refutes the universal seed-squarefreeness claim only, not the two-pencil algorithm.

## 7. Independent controls and evidence limits

`fresh_controls.py` is a fresh independent implementation, not an author-program replay. Its 5,295 explicit checks pass identically under normal Python and python -O. It constructs the full original E and U, both pencils and all actual final guards at N=23,d=4 over F_139; N=35,d=5 over F_281; and N=51,d=4 over F_256 using the irreducible AES polynomial. Each fixture has a genuinely represented H+1-element list. Field inverses and the exact order of q are checked. Full coefficient vectors, auxiliary witnesses and final scalars are recorded.

Additional controls reject omitted endpoint independence, verify a multiplicity-increasing cancellation against the exact target gcd, and independently reproduce the structured seed's repeated root and chirp product. They do not construct a splitting field or literal physical bank arrays and cannot be used as evidence of an end-to-end compiler speedup. The uniform proof above, not these finite instances, establishes the theorem.

All candidate-manifest members and selected baseline source hashes were checked. Author controls remain separately labeled author evidence. No author or historical scientific program was executed. The review requested only the explicit degree qualifier in the Euclidean cost, now incorporated in the bound final theorem; no construction repair remains.

## 8. Verdict

Accept the deterministic original-U coefficient generator, its exact original-domain guards, its supplied-list interface, the bounded structured-direction membership/failure statements, and only the narrow deterministic-search ledger replacement. Keep original bank count, genuine root-field obligations, randomized baseline, cost limitations, historical attribution caution and broader owner statuses unchanged. External publication remains solely the designated publisher's responsibility.
