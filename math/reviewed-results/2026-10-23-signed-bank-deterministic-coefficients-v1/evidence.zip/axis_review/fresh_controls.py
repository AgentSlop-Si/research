"""Fresh axis proof controls; reused arithmetic is prior reviewer-owned, not author code."""
import itertools,json,pathlib
from reviewer_arithmetic import Fld,trim,axis,build,member,ck,cnt

def ps(F,a,b):return F.pa(a,F.sc(b,F.neg(1)))
def invmod(F,a,h):
 r0,r1=h,F.dv(a,h)[1];v0,v1=[0],[1]
 while r1!=[0]:
  q,r=F.dv(r0,r1);r0,r1=r1,r;v0,v1=v1,ps(F,v0,F.pm(q,v1))
 ck(len(r0)==1 and r0[0]!=0,'inverse gcd certificate')
 return F.dv(F.sc(v0,F.power(r0[0],-1)),h)[1]
def fast(F,h,N,d):
 c=h[0];n=len(h)-1;s=d-1
 if not c:raise ValueError('nonzero constant required')
 v=trim(h[::-1]);D=F.gc(h,v);hb=F.dv(h,D)[0];ell=len(hb)-1
 if ell<s:return False,hb,'ell<s'
 H=[1]*N;Hdiv,rem=F.dv(H,D)
 if rem!=[0]:return True,None,'D_not_divide_H'
 vb=F.dv(v,D)[0];K=h[1:]
 b0=F.dv(F.pm(invmod(F,vb,hb),F.sc(F.pm(K,Hdiv),F.neg(1))),hb)[1]
 if ell==s:return False,F.pa(b0,hb),'ell=s'
 bad=len(b0)==s+1 and b0[-1]==1
 return not bad,b0 if bad else None,'ell>s_bad' if bad else 'ell>s_full'
def affine(F,h,N,d):
 n=len(h)-1;c=h[0];v=trim(h[::-1]);cols=[]
 for s in range(d):
  a=[0]*(s+1)+v
  if s==d-1:a=ps(F,a,F.sc([1]*N,c))
  ck(len(trim(a))<=N-1,'top degree cancels')
  cols.append(a+[0]*(N-1-len(a)))
 for s in range(d):
  a=F.sc([0]*s+h,F.neg(1));cols.append(a+[0]*(N-1-len(a)))
 return [[cols[j][i] for j in range(2*d)] for i in range(N-1)]
def certificate(F,h,N,d,b):
 bp=b+[0]*(d-len(b));a=bp[::-1];g=F.pm([F.neg(1),1],h);A=F.pm(g,a)
 ck(A!=[0] and len(A)<=N,'nonzero relation degree')
 J=[A[0]]+[0]*(N-1)
 for j in range(1,len(A)):J[N-j]=A[j]
 ck(F.dv(A,g)[1]==[0] and F.dv(J,g)[1]==[0] and F.ev(A,1)==0,'original three relation conditions')
 X=axis(F,g,N);beta=A+[0]*(N-len(A))
 for col in range(len(X[0])):
  total=0
  for z,row in zip(beta,X):total=F.add(total,F.mul(z,row[col]))
  ck(total==0,'certificate on literal X')
def test(F,h,N,d,label):
 g=F.pm([F.neg(1),1],h);X=axis(F,g,N);M=affine(F,h,N,d)
 dense=len(F.rr(X)[1])==N;aff=len(F.rr(M)[1])==2*d
 ck(dense==aff,'literal X affine M equivalence')
 if h[0]:
  passed,b,branch=fast(F,h,N,d);ck(passed==dense,'fast exact rank decision')
  if b is not None:certificate(F,h,N,d,b)
 else:branch='zero_constant_affine_only'
 return {'label':label,'N':N,'d':d,'field':F.q,'branch':branch,'full_rank':dense}
records=[]
# Reuse exact DATA from independent original-U pencil construction, not author results.
P=pathlib.Path('pencil_review/CONTROL.json')
old=json.loads(P.read_text())
for f in old['fixtures']:
 F=Fld(f['characteristic'],0x11b if f['field_size']==256 else 0)
 N,d,q=f['N'],f['d'],f['q'];n=N-d-1
 E,_,_=build(F,N,d,q)
 h0,rem=F.dv(f['axis_witness'],[F.neg(1),1]);ck(rem==[0],'old reviewer fixture h0 exact')
 h1=f['h1'];M0=affine(F,h0,N,d)
 fpoly=h0[1:];v0=trim(h0[::-1]);bstar=F.dv(F.sc(F.pm(fpoly,[1]*N),F.neg(1)),h0)[1]
 bstar=F.dv(F.pm(bstar,invmod(F,v0,h0)),h0)[1]
 ck(bstar==F.sc(fpoly,F.neg(1)),'safe boundary continuation minus f')
 good=[]
 for lam in [0,1,2,3,2*N-1]:
  h=F.pa(h0,F.sc(h1,lam));g=F.pm([F.neg(1),1],h);member(F,E,g)
  records.append(test(F,h,N,d,'original_U_pencil_'+str(lam)))
  Ml=affine(F,h,N,d);M1=affine(F,F.pa(h0,h1),N,d)
  ck(all(a==F.add(b,F.mul(lam,F.sub(c,b))) for R,A,B in zip(Ml,M0,M1) for a,b,c in zip(R,A,B)),'affine parameter identity')
  if h[0] and F.gc(g,F.deriv(g))==[1] and fast(F,h,N,d)[0]:good.append(lam)
 ck(bool(good),'original guarded point within 2N list')
 ck(2*(N-d)-1<=2*N and 2*d+2*(N-d)-1==2*N-1,'scalar list bound')
# Legal-gate reciprocal-gcd and repeated-factor loci. q is a genuine Nth root.
F=Fld(139);N,d=23,4;n=N-d-1;q=old['fixtures'][0]['q']
for ell in [0,1,2,3,4,8,18]:
 h=[1]
 for j in range(n-ell):h=F.pm(h,[F.neg(1),1])
 for j in range(ell):h=F.pm(h,[F.neg(2),1])
 records.append(test(F,h,N,d,'repeated_factor_ell_'+str(ell)))
for omit in [[1,2,3,4],[1,22,2,21],[1,22,2,3]]:
 h=[1]
 for j in range(1,N):
  if j not in omit:h=F.pm(h,[F.neg(F.power(q,j)),1])
 records.append(test(F,h,N,d,'HN_root_subset_'+str(omit)))
# Complete small-field algebraic identities; outside generator domain, explicitly so.
# These exercise exceptional branches independent of prime-root or squarefree hypotheses.
branches={}
for N,d,F in [(7,2,Fld(2)),(8,2,Fld(3)),(9,3,Fld(2))]:
 n=N-d-1
 for coeff in itertools.product(range(F.q),repeat=n):
  h=list(coeff)+[1]
  r=test(F,h,N,d,'algebra_only')
  branches[r['branch']]=branches.get(r['branch'],0)+1
# Explicit ell=s algebraic branch, outside the odd-N generator domain.
F=Fld(5);h=F.pm([1,0,0,0,1],[3,1])
r=test(F,h,8,2,'algebra_only_ell_equals_s');records.append(r)
ck(r['branch']=='ell=s' and not r['full_rank'],'ell equals s branch exercised')
try:
 fast(F,[0,1,1],7,4)
except ValueError:
 ck(True,'zero constant rejected by fast inverse test')
else:raise RuntimeError('zero constant not rejected')
# Mutation: dropping D|H_N wrongly predicts deficiency when ell=s.
F=Fld(139);h=[1]
for j in range(15):h=F.pm(h,[F.neg(1),1])
for j in range(3):h=F.pm(h,[F.neg(2),1])
res=fast(F,h,23,4)
ck(res[0] and res[2]=='D_not_divide_H','D divisibility omission mutation detected')
print(json.dumps({'status':'PASS','author_code_executed':False,'prior_reviewer_arithmetic_reused':True,'checks':sum(cnt.values()),'categories':dict(sorted(cnt.items())),'original_and_exceptional_records':records,'small_algebra_only_branch_counts':branches,'limits':'No root-field construction or physical bank compilation. Algebra-only small cases do not enlarge the generator domain.'},indent=2,sort_keys=True))
