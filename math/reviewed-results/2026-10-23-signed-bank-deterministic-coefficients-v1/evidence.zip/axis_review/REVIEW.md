# Independent review: exact original-axis guard and deterministic coefficient bound

Date: 2026-10-23 UTC. Verdict: **ACCEPT**, with the original parameter and field-interface scope retained.

## 1. Binding, source scope, and actual improvement

Author packet: `signed_bank_fast_axis_guard_20261023_v1`.

- THEOREM.md SHA-256: `54a19739c708ea5d0e38e9fd18408ff7bf50ccfb5849f800ece67ac9829959dc`.
- OPERATION_LEDGER_DELTA.md SHA-256: `78e88da68d6f61fc0f59cece47760b2bd17ba9f3e7ff956f4d9eb4e673de64a7`.
- The exact author manifest and all member/source checks are recorded in BINDINGS.json.

This review accepts an exact O(N^2) axis full-row-rank test, a degree-2d axis minor on the existing second pencil, a 2N-element scalar list for the complete guarded generator, and a resulting deterministic coefficient-stage bound of O(N^4) field additions/multiplications, O(N^3) inversions, and O(N^2) storage.

The domain here is N odd, d>=4, N>=8d-10, m=N-d, a supplied field containing a primitive Nth root q, and characteristic not dividing N. The ORIGINAL envelope E, U=E-perp, bank architecture, coefficient guards and effective distinct-element interface are unchanged. The later N>=6d-2 composition is not incorporated by this acceptance.

The baseline deterministic two-pencil theorem is SHA-256 `487180521ca6e29c038fd4deb1d79a2f9f60fe5039ed79233506a695013428ab`, with its separate independent acceptance in `signed_bank_pencil_independent_20261023`. Its guaranteed coefficient bound was O(N^5), not the pre-existing expected O(N^3) Las Vegas bound. The new result improves the former only. All-characteristics original theorem `d994217b228c62bf36c3b0d66d55657733f42fe64aa286d33a95e0e82d23358c` and full ledger `41c18c4ab22e95f3b36ae14366f0896ea13a239f44532b08cea92fd0028a54f5` remain intact.

No new smaller bank count, root-field algorithm, end-to-end Fourier advantage, bit bound, whole-owner closure, or historical novelty is accepted.

## 2. Independent derivation from the actual axis matrix

Let g=(t-1)h be monic of degree m and put n=m-1, c=h(0), v=rev_n(h), and H_N=sum_(j=0)^(N-1)t^j. A left relation beta on the original row vectors (p_a,1,p_[-a mod N]) corresponds to A=sum beta_a t^a of degree at most N-1. Its three conditions are precisely

    g divides A, A(1)=0, g divides J_N A,
    J_N A=t^N A(1/t)+A(0)(1-t^N).

Write A=(t-1)h a and b=rev_(d-1)(a), with padded reversal and deg a<=d-1. Direct expansion gives

    J_N A=(t-1)[c b_(d-1) H_N-t v b].

Thus nonzero axis relations are in bijection with nonzero polynomials b of degree at most s=d-1 satisfying

    t v b = c b_s H_N modulo h.                         (R)

The scalar-column condition is automatic because g divides A and g(1)=0. This identity does not assume squarefreeness, nonzero constant, or a favorable characteristic. The padding and the special cyclic coefficient at zero are essential and are retained.

For c!=0, t is invertible modulo h and h=tK+c with K=(h-c)/t. Consequently (R) is equivalent to

    v b = -K H_N b_s modulo h.                         (R')

This normalization uses the original nonzero-constant guard explicitly; it is not applied at c=0.

## 3. Exhaustive reciprocal-gcd decision, with multiplicities

Let D=gcd(h,v), hbar=h/D, vbar=v/D, and ell=deg hbar. The following independently checked case split is exact.

- If ell<s, b=hbar is a nonzero solution with b_s=0, hence the axis is deficient.
- If ell>=s, a solution with b_s=0 would have hbar dividing b of degree at most s-1, so must be zero. Any nonzero solution can therefore be scaled to b_s=1.
- A normalized solution requires D dividing K H_N. Since h=tK+c and c!=0 imply gcd(K,h)=1, this is equivalent to D dividing H_N, with every multiplicity retained. Failure of that divisibility gives full axis rank.
- If D divides H_N, ordinary extended Euclid in k[t]/hbar gives the unique residue

      b0 = [vbar^(-1)(-K(H_N/D))] modulo hbar,
      deg b0<ell.

  Every normalized congruence solution is b0+hbar z. At ell=s, b0+hbar is monic of degree s and gives a relation. At ell>s, degree at most s is possible only for b0 itself, and the axis is deficient exactly when b0 is monic of degree s.

The quotient coprimality gcd(hbar,vbar)=1 follows by removing the exact minimum multiplicity of every irreducible factor. No squarefree simplification or generic exclusion is used. Returned b polynomials reverse back to actual original-axis relation certificates.

In the original odd-N, characteristic-not-dividing-N domain, the special ell=s, D|H_N branch is in fact impossible: a reciprocal D dividing the squarefree H_N has roots in inverse pairs, with neither 1 nor -1 present, hence even degree; but deg D=n-s=N-2d is odd. The algorithm does not rely on this extra observation and correctly includes the algebraically possible branch outside that domain.

## 4. The zero-constant witness and the linear-degree scalar guard

The accepted first pencil supplies a monic degree-r polynomial f, r=m-2=n-1, with f(0)!=0 and gcd(f,rev_r f)=1. The second pencil is h_Z=t f+Z h1, with deg h1<n and gcd(t f,h1)=1.

At zero, v0=rev_r f has constant coefficient one. Therefore gcd(t f,v0)=1. The safe expression [-K_Z H_N v_Z^(-1)] modulo h_Z continues to Z=0, where it equals -f: indeed f(H_N-v0) is divisible by t f since H_N(0)=v0(0)=1. This is not an inversion of t at the singular boundary. Its degree-n-1 coefficient is -1, also nonzero in characteristic two.

I also checked the optional Cramer construction: the equation v B+h Q=-K H_N, with deg B<n and deg Q<n+d, gives a square matrix of order 2n+d. Eliminating the highest d quotient coefficients leaves the padded Sylvester determinant, equal up to sign to Res(h,v). The indicated numerator has degree at most 2n+d and is nonzero at zero. This is valid, but not needed for the smaller primary guard below.

Return to the division-free relation (R) and write

    t v b-c b_s H_N-h w=0.

The coefficient of t^(N-1)=t^(n+d) cancels identically between the first two terms. Their difference has degree at most N-2; since h is monic, deg w<=d-1. Thus the coefficient map on pairs (b,w), both of degree less than d, is an (N-1)-by-2d matrix M(h). Its entries are affine in Z along h_Z. A kernel vector with b=0 has w=0, so its kernel is exactly the original relation space. This gives full column rank of M if and only if full row rank of the ORIGINAL X, even at c=0.

At h0=t f the equation cancels a common t and becomes rev_r(f)b=f w. Coprimality forces f dividing b, but r>d-1 throughout the stated domain. Therefore the matrix has full column rank at zero. Some 2d-row minor is nonzero there and is a nonzero scalar polynomial of degree at most 2d.

The inherited pencil is generically squarefree in every permitted characteristic, and c_Z=Z h1(0) is a nonzero linear polynomial. Multiplying the chosen axis minor, c_Z, and the monic degree-m discriminant gives a nonzero polynomial of degree at most

    2d+1+(2m-2)=2N-1.

Every scalar failing an original guard is among its zeros. Therefore 2N distinct represented scalars suffice. The generator does not need to compute the minor or resultant; it tests the actual guards and may accept points where the particular sufficient minor happens to vanish. The first pencil and both coprime-combination loops need fewer than 2N distinct choices, so no larger hidden list remains.

## 5. Complete paid cost comparison

All gcds, exact divisions, one extended-Euclid inverse, and remainders in the fast test involve degree-O(N) polynomials. Schoolbook Euclid and multiplication give O(N^2) field arithmetic, O(N) inversions, and O(N) temporary elements per test, including repeated-factor and reciprocal-gcd cases. Testing g(0) and gcd(g,g') adds no larger order. At most 2N final trials therefore cost O(N^3) arithmetic and O(N^2) inversions.

The original envelope/nullspace and endpoint solves still cost O(N^3). Critically, EACH of the two coprime-combination loops still has O(N) basis directions and O(N) trials per direction, with O(N^2) gcd arithmetic and O(N) inversions per trial. Together these cost O(N^4) arithmetic and O(N^3) inversions and dominate the total. The first reciprocal pencil costs O(N^3) arithmetic. Streamed candidate storage and envelope data require O(N^2) live field elements. Failed trials, coefficient reads/writes, candidate formation, and final coefficient output are included.

The finite coefficient field remains F_(Q^2), with the original O(Q^3) base-field preparation. Since Q>=N+1, it contains the required 2N distinct scalars. Infinite positive-characteristic fields still require a supplied effective distinct-element list; repeated addition of one is not silently used there.

The actual bank compilation ledger is unchanged. In particular the genuine m!-degree overfield recipe, potentially enormous splitting field, root scan, root checks, axis amplitudes, sector/weight solves, branch preparation, full outputs and extension-coordinate expansion remain paid. The original warm counts 2BN^2 multiplications and 2BN^2-BN-N additions, B=2m+2, are unchanged. This is a real deterministic coefficient-stage improvement, not an end-to-end polynomial-time or FFT claim.

## 6. Independent controls and scope limitations

Fresh reviewer code compares the new criterion with both independently assembled original dense X and the division-free affine M. Low-level arithmetic routines and exact original-U fixture data are reused from this reviewer's prior accepted pencil review, explicitly identified and hash-bound; no author or historical scientific code was imported or executed.

Normal and optimized runs are byte-identical and record 15,035 checks. They include 317 literal-X/affine-M comparisons, 209 fast criterion comparisons, 43 explicit original-axis relation certificates (681 individual column equations), 155 original-U moment equations, and all case branches. Actual original-gate pencil fixtures are N=23 over F139, N=35 over F281, and N=51 over F256, including composite order and characteristic two. Each includes the c=0 witness, legal guarded points, affine dependence, and the exact boundary continuation -f.

Repeated-factor and reciprocal exceptional loci are tested in the original N=23,d=4 domain, including D not dividing H_N and H_N-root subsets on both sides of the dimension boundary. Small finite exhaustive fixtures separately exercise the algebraic identities outside the generator domain. A labeled N=8,F5 fixture covers ell=s,D|H_N; it is not credited as a new legal generator instance. A mutation omitting the D|H_N test is detected, and the normalized fast inverse test explicitly rejects c=0 while M continues to decide it correctly.

These finite checks validate implementations and exceptional cases, not the universal proof. No splitting field, root-bank array, or online speedup was instantiated or asserted. No external repository or table state was changed by this review.
