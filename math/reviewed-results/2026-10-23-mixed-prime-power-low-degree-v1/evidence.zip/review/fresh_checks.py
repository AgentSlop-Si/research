"""Independent original-index, exact cyclotomic controls; no author code imported."""
from pathlib import Path
from functools import lru_cache
from itertools import combinations
import json,hashlib
P=Path('/workspace/shared/prime_square_mixed_low_degree_20261023_frozen_v1');O=Path(__file__).parent
checks=0;gram_entries=0;fiber_checks=0;cross_nonempty=0

def ck(b,s):
 global checks
 checks+=1
 if not b:raise RuntimeError(s)
def trim(a):
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def divide(a,b):
 a=a[:];q=[0]*max(1,len(a)-len(b)+1)
 while len(a)>=len(b) and any(a):
  c=a[-1];k=len(a)-len(b);q[k]=c
  for j,t in enumerate(b):a[k+j]-=c*t
  trim(a)
 return trim(q),trim(a)
@lru_cache(None)
def phi(n):
 a=[-1]+[0]*(n-1)+[1]
 for d in range(1,n):
  if n%d==0:
   a,r=divide(a,list(phi(d)));ck(r==[0],'cyclotomic exact division')
 return tuple(a)
@lru_cache(None)
def mon(n,e):
 e%=n;return tuple(divide([0]*e+[1],list(phi(n)))[1]+[0]*(len(phi(n))-1-len(divide([0]*e+[1],list(phi(n)))[1])))
def zero(n,exponents):
 a=[0]*(len(phi(n))-1)
 for e in exponents:
  for j,t in enumerate(mon(n,e)):a[j]+=t
 return not any(a)
def scalar_value(n,exponents):
 a=[0]*(len(phi(n))-1)
 for e in exponents:
  for j,t in enumerate(mon(n,e)):a[j]+=t
 return a

def mask(n,d):return [{c for c in range(n) if c%(n//d)==r//d} for r in range(n)]
def twisted(m,q,d):
 n=m*q;em=q*pow(q,-1,m);eq=m*pow(m,-1,q)
 out=[set() for _ in range(n)]
 for x in range(m):
  for b in range(q):
   r=(x*em+b*eq)%n
   for y in range(m):
    if y%(m//d)==x//d:
     v=(b+y)%q;out[r].add((y*em+v*eq)%n)
 return out

def validate(R,m,q,d,positive=True,boundary=False):
 global gram_entries,fiber_checks,cross_nonempty
 n=m*q;em=q*pow(q,-1,m);eq=m*pow(m,-1,q)
 cols=[{r for r in range(n) if c in R[r]} for c in range(n)]
 ck(all(len(s)==d for s in R+cols),'regularity')
 origbad=erasebad=0
 for i in range(n):
  for j in range(n):
   overlap=R[i]&R[j]
   ex=[c*(j-i) for c in overlap]
   ee=[(c%m)*((j-i)%m) for c in overlap]
   a=scalar_value(n,ex);b=scalar_value(m,ee)
   ok=a==[d if i==j else 0]+[0]*(len(a)-1)
   ek=b==[d if i==j else 0]+[0]*(len(b)-1)
   origbad+=not ok;erasebad+=not ek;gram_entries+=2
   if positive:ck(ok,'original row Gram')
   if positive and not boundary:ck(ek,'erased row Gram')
   overlap=cols[i]&cols[j]
   a=scalar_value(n,[r*(j-i) for r in overlap]);b=scalar_value(m,[(r%m)*((j-i)%m) for r in overlap])
   ok=a==[d if i==j else 0]+[0]*(len(a)-1);ek=b==[d if i==j else 0]+[0]*(len(b)-1)
   origbad+=not ok;erasebad+=not ek;gram_entries+=2
   if positive:ck(ok,'original column Gram')
   if positive and not boundary:ck(ek,'erased column Gram')
   if positive and not boundary and i%q!=j%q:
    ck(len(overlap)<q,'strict short overlap')
    ck(len({r%q for r in overlap})<q,'missing fiber')
    if overlap:cross_nonempty+=1
    for b0 in range(q):
     ck(zero(m,[(r%m)*((j-i)%m) for r in overlap if r%q==b0]),'zero coefficient after erasure')
     fiber_checks+=1
 for r in range(n):
  for c in range(n):ck((r*c-em*(r%m)*(c%m)-eq*(r%q)*(c%q))%n==0,'original CRT phase')
 if boundary:ck(origbad==0 and erasebad>0,'boundary erasure failure')
 if not positive:ck(origbad>0,'regularity alone rejected')
 return {'N':n,'m':m,'q':q,'d':d,'original_bad_Gram_entries':origbad,'erased_bad_Gram_entries':erasebad,'boundary':boundary,'positive':positive}

# Scope and immutable source bindings.
manifest=json.loads((P/'MANIFEST.json').read_text())
for fn,v in manifest.items():
 data=(P/fn).read_bytes();ck(len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256'],'candidate binding '+fn)
for v in json.loads((P/'SOURCE_BINDINGS.json').read_text()):
 data=(P/'sources'/v['name']).read_bytes();ck(hashlib.sha256(data).hexdigest()==v['sha256'],'source '+v['name'])
 if 'git_blob_sha' in v:ck(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==v['git_blob_sha'],'Git blob '+v['name'])
records=[]
for p,a,q in [(2,2,3),(2,2,5),(2,3,5),(3,2,5),(3,2,7),(5,2,7)]:
 m=p**a;n=m*q
 for j in range(a+1):
  d=p**j
  if d<q:
   records.append(validate(mask(n,d),m,q,d))
 # A genuinely repeated-label square with cross-q overlaps, not only a disjoint support test.
 records.append(validate(twisted(m,q,p),m,q,p))
 if n<=63:records.append(validate(mask(n,q),m,q,q,boundary=True))
for m,q,d in [(4,5,3),(9,5,2)]:
 n=m*q;records.append(validate([{(r+j)%n for j in range(d)} for r in range(n)],m,q,d,positive=False))
# Exhaustive short subset erasure under one primitive character, independent of matrix existence.
subsets=vanish=0
for m,q in [(4,3),(4,5)]:
 n=m*q
 for k in range(q):
  for sub in combinations(range(n),k):
   subsets+=1
   if zero(n,sub):
    vanish+=1
    for b in range(q):ck(zero(m,[r%m for r in sub if r%q==b]),'short vanishing subset fiber')
ck(cross_nonempty>0,'nonempty cross-q cases exercised')
result={'status':'SCOPED_PASS','active_checks':checks,'full_Gram_entries_evaluated':gram_entries,'separate_fiber_zero_checks':fiber_checks,'nonempty_cross_q_column_intersections':cross_nonempty,'short_subsets_enumerated':subsets,'vanishing_short_subsets':vanish,'fixtures':records,'author_or_historical_code_executed':False,'weighted_descent_source_interface':'accepted arbitrary square size, repeated labels, k_i=0 => exponent bound a; not re-executed'}
(O/'CONTROL.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='fixtures'},indent=2))
