#!/usr/bin/env python3
"""Fresh exact controls for the short-overlap prime-character erasure.
No author/historical program is imported or executed. Standard library only.
"""
from functools import lru_cache
from itertools import combinations
from collections import Counter
from pathlib import Path
import hashlib,json,math
ROOT=Path(__file__).resolve().parent

def require(ok,msg):
    if not ok: raise RuntimeError(msg)

def divide(a,b):
    a=a[:]
    q=[0]*max(1,len(a)-len(b)+1)
    for k in range(len(a)-len(b),-1,-1):
        t=a[k+len(b)-1]
        require(t%b[-1]==0,'nonintegral polynomial division')
        t//=b[-1];q[k]=t
        for j,x in enumerate(b):a[k+j]-=t*x
    require(not any(a),'nonexact polynomial division')
    while len(q)>1 and q[-1]==0:q.pop()
    return q

@lru_cache(None)
def cyclo(n):
    a=[-1]+[0]*(n-1)+[1]
    for d in range(1,n):
        if n%d==0:a=divide(a,list(cyclo(d)))
    return tuple(a)

@lru_cache(None)
def root_basis(n):
    phi=cyclo(n);f=len(phi)-1;out=[]
    for exponent in range(n):
        a=[0]*max(f,exponent+1);a[exponent]=1
        for k in range(len(a)-1,f-1,-1):
            t=a[k]
            if t:
                for j,x in enumerate(phi):a[k-f+j]-=t*x
        out.append(tuple((i,x) for i,x in enumerate(a[:f]) if x))
    return tuple(out)

@lru_cache(500000)
def residue(n,exponents):
    a=Counter()
    for exponent,multiplicity in exponents:
        for j,x in root_basis(n)[exponent%n]:a[j]+=multiplicity*x
    return tuple(sorted((j,x) for j,x in a.items() if x))

def rootsum(n,exponents):
    return residue(n,tuple(sorted(Counter(x%n for x in exponents).items())))

def grams(n,supports,order,phase):
    cols=[{i for i,s in enumerate(supports) if j in s} for j in range(n)]
    degrees=[len(s) for s in supports]
    require(len(set(degrees))==1,'nonregular row control')
    d=degrees[0]
    out={'degree':d,'row_regular':True,'column_regular':all(len(s)==d for s in cols),
         'row_entries':n*n,'column_entries':n*n,'row_failures':0,'column_failures':0}
    for side,ss in [('row',supports),('column',cols)]:
        first=None
        for i in range(n):
            for j in range(n):
                common=ss[i]&ss[j]
                es=[(phase(i,k)-phase(j,k))%order for k in common] if side=='row' else [(phase(k,i)-phase(k,j))%order for k in common]
                z=rootsum(order,es)
                want=((0,d),) if i==j else ()
                if z!=want:
                    out[side+'_failures']+=1
                    if first is None:first={'indices':[i,j],'overlap':sorted(common),'residue':z}
        if first is not None:out[side+'_first_failure']=first
    return out

def divisor_mask(n,d):
    require(n%d==0,'not a divisor')
    m=n//d
    return [{c for c in range(n) if c%m==r//d} for r in range(n)]

def regular_nearmask(n,d):
    return [{(r+j)%n for j in range(d)} for r in range(n)]

def check_case(p,a,q,d,negative=False,boundary=False,twisted=False):
    m=p**a;n=m*q
    em=q*pow(q,-1,m);eq=m*pow(m,-1,q)
    require((em+eq)%n==1 and em*eq%n==0,'CRT failure')
    invq=pow(q,-1,m)
    support=regular_nearmask(n,d) if negative else divisor_mask(n,d)
    if twisted:
        # A row-dependent original square mask, using independently shifted
        # q-labels for every m-coordinate column. In each fixed row q-label
        # block, the q-factor is a column phase. No arbitrary phases are put
        # into the original matrix; its entries remain zeta_N^(r*c).
        h=m//d
        support=[{c for c in range(n) if (c%m)%h==(r%m)//d and c%q==(r%q+c%m)%q} for r in range(n)]
    for r in range(n):
        for c in range(n):
            require((em*(r%m)*(c%m)+eq*(r%q)*(c%q)-r*c)%n==0,'literal phase failure')
    original=grams(n,support,n,lambda r,c:r*c%n)
    erased=grams(n,support,m,lambda r,c:invq*(r%m)*(c%m)%m)
    if negative:
        require(original['column_regular'],'negative lost regularity')
        require(original['row_failures'] and original['column_failures'],'negative did not fail both Grams')
    else:
        require(original['column_regular'] and not original['row_failures'] and not original['column_failures'],'positive original Gram failure')
        if boundary:
            require(erased['row_failures'] and erased['column_failures'],'boundary did not distinguish erasure guard')
        else:
            require(d<q and erased['column_regular'] and not erased['row_failures'] and not erased['column_failures'],'low-degree erasure failure')
            # Every nonzero-difference column overlap with q-character present
            # must vanish separately in every row q-label after erasure.
            cols=[{r for r in range(n) if c in support[r]} for c in range(n)]
            checks=0;nonempty_cross_q=0
            for c in range(n):
                for e in range(n):
                    if (c-e)%q==0:continue
                    common=cols[c]&cols[e]
                    if common:nonempty_cross_q+=1
                    require(len(common)<q,'missing coefficient unavailable')
                    for b in range(q):
                        z=rootsum(m,[invq*(r%m)*((c-e)%m) for r in common if r%q==b])
                        require(not z,'fiber coefficient nonzero')
                        checks+=1
            erased['fiber_checks']=checks
            erased['nonempty_cross_q_overlaps']=nonempty_cross_q
            if twisted:require(nonempty_cross_q>0,'twisted control has no nonempty cross-q overlap')
    return {'p':p,'a':a,'q':q,'N':n,'d':d,'kind':'negative' if negative else 'boundary' if boundary else 'twisted_positive' if twisted else 'positive','original':original,'erased':erased,'literal_crt_checks':n*n}

def subset_checks(p,a,q):
    m=p**a;n=m*q;im=pow(q,-1,m)
    total=zeros=0
    for k in range(q):
        for s in combinations(range(n),k):
            total+=1
            if rootsum(n,s):continue
            zeros+=1
            # zeta_N^r = alpha^(r mod m) beta^(r mod q).
            for b in range(q):
                require(not rootsum(m,[im*(r%m) for r in s if r%q==b]),'short support fiber failure')
            require(not rootsum(m,[im*(r%m) for r in s]),'short support erasure failure')
    return {'p':p,'a':a,'q':q,'subsets_below_q':total,'vanishing_subsets':zeros}

def source_checks():
    ans=[]
    for e in json.loads((ROOT/'SOURCE_BINDINGS.json').read_text()):
        b=(ROOT/'sources'/e['name']).read_bytes()
        require(hashlib.sha256(b).hexdigest()==e['sha256'],'source SHA256 mismatch')
        if e.get('git_blob_sha'):
            g=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
            require(g==e['git_blob_sha'],'source Git blob mismatch')
        ans.append(e['name'])
    return ans

def main():
    cases=[]
    for p,a,q in [(2,2,3),(2,2,5),(3,2,5),(3,2,11),(5,2,7),(2,3,5),(2,3,11),(3,3,5)]:
        for b in range(a+1):
            d=p**b
            if d<q:cases.append(check_case(p,a,q,d))
    for p,a,q in [(2,2,3),(2,2,5),(3,2,5),(3,2,11)]:cases.append(check_case(p,a,q,q,boundary=True))
    for p,a,q,d in [(2,2,5,3),(3,2,5,2),(3,2,5,4),(3,2,11,6),(3,2,11,10),(5,2,7,6)]:cases.append(check_case(p,a,q,d,negative=True))
    for p,a,q,d in [(2,2,5,4),(3,2,5,3),(3,2,11,9),(5,2,7,5)]:cases.append(check_case(p,a,q,d,twisted=True))
    subsets=[subset_checks(2,2,3),subset_checks(2,2,5),subset_checks(3,1,5)]
    out={'claim':'Exact controls only, not a mask census or proof of universal theorem.','historical_execution':False,'sources_verified':source_checks(),'cases':cases,'short_support_exhaustions':subsets,
         'counts':{'positive_cases':sum(x['kind'] in ('positive','twisted_positive') for x in cases),'twisted_positive_cases':sum(x['kind']=='twisted_positive' for x in cases),'boundary_cases':sum(x['kind']=='boundary' for x in cases),'negative_cases':sum(x['kind']=='negative' for x in cases),'original_gram_entries':sum(x['original']['row_entries']+x['original']['column_entries'] for x in cases),'erased_gram_entries':sum(x['erased']['row_entries']+x['erased']['column_entries'] for x in cases),'literal_crt_checks':sum(x['literal_crt_checks'] for x in cases),'fiber_checks':sum(x['erased'].get('fiber_checks',0) for x in cases),'short_subsets':sum(x['subsets_below_q'] for x in subsets)}}
    text=json.dumps(out,indent=2,sort_keys=True)+'\n'
    (ROOT/'RESULTS.json').write_text(text)
    print(json.dumps(out['counts'],sort_keys=True))
if __name__=='__main__':main()
