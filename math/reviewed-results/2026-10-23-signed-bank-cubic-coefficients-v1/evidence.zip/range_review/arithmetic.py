"""Fresh reviewer implementation of the two pencils in the exact original envelope."""
from collections import Counter
from math import gcd as igcd
import json
cnt=Counter()
def ck(v,label):
 cnt[label]+=1
 if not v:raise RuntimeError(label)
class Fld:
 def __init__(self,p,mod=0):self.p=p;self.mod=mod;self.q=p if not mod else 1<<(mod.bit_length()-1)
 def add(self,a,b):return (a+b)%self.p if not self.mod else a^b
 def neg(self,a):return -a%self.p if not self.mod else a
 def sub(self,a,b):return self.add(a,self.neg(b))
 def mul(self,a,b):
  if not self.mod:return a*b%self.p
  r=0
  while b:
   if b&1:r^=a
   b>>=1;a<<=1
   if a>=self.q:a^=self.mod
  return r
 def power(self,a,n):
  if n<0:
   ck(a!=0,'guarded inverse');return self.power(self.power(a,self.q-2),-n)
  r=1
  while n:
   if n&1:r=self.mul(r,a)
   a=self.mul(a,a);n//=2
  return r
 def sc(self,a,s):return trim([self.mul(x,s) for x in a])
 def pa(self,a,b):return trim([self.add(a[j] if j<len(a) else 0,b[j] if j<len(b) else 0) for j in range(max(len(a),len(b)))])
 def pm(self,a,b):
  r=[0]*(len(a)+len(b)-1)
  for i,x in enumerate(a):
   for j,y in enumerate(b):r[i+j]=self.add(r[i+j],self.mul(x,y))
  return trim(r)
 def dv(self,a,b):
  a=a[:];out=[0]*max(1,len(a)-len(b)+1);iv=self.power(b[-1],-1)
  while a!=[0] and len(a)>=len(b):
   d=len(a)-len(b);c=self.mul(a[-1],iv);out[d]=c
   for j,v in enumerate(b):a[j+d]=self.sub(a[j+d],self.mul(c,v))
   trim(a)
  return trim(out),a
 def gc(self,a,b):
  while b!=[0]:a,b=b,self.dv(a,b)[1]
  return self.sc(a,self.power(a[-1],-1)) if a!=[0] else [0]
 def ev(self,a,x):
  v=0
  for c in a[::-1]:v=self.add(self.mul(v,x),c)
  return v
 def deriv(self,a):return trim([self.mul(j%self.p,a[j]) for j in range(1,len(a))] or [0])
 def rr(self,rows):
  a=[r[:] for r in rows];r=0;piv=[]
  for col in range(len(a[0])):
   z=next((j for j in range(r,len(a)) if a[j][col]),None)
   if z is None:continue
   a[r],a[z]=a[z],a[r];a[r]=self.sc(a[r],self.power(a[r][col],-1));a[r]+=[0]*(len(rows[0])-len(a[r]))
   for j in range(len(a)):
    if j!=r and a[j][col]:
     f=a[j][col];a[j]=[self.sub(v,self.mul(f,u)) for v,u in zip(a[j],a[r])]
   piv.append(col);r+=1
   if r==len(a):break
  return a,piv
 def ker(self,rows):
  a,piv=self.rr(rows);out=[]
  for free in range(len(rows[0])):
   if free in piv:continue
   z=[0]*len(rows[0]);z[free]=1
   for i,c in enumerate(piv):z[c]=self.neg(a[i][free])
   out.append(trim(z))
  return out

def trim(a):
 while len(a)>1 and a[-1]==0:a.pop()
 return a

def axis(F,g,N):
 m=len(g)-1;rema=[[1]+[0]*(m-1)]
 for j in range(1,N):
  r=F.dv([0]+rema[-1],g)[1];rema.append(r+[0]*(m-len(r)))
 return [rema[a]+[1]+rema[(-a)%N] for a in range(N)]

def build(F,N,d,q):
 m=N-d;hh=pow(4,-1,N);ee=pow(2,-1,N);rho=F.power(q,ee)
 D=[1]
 for i in range(2,d):D=F.pm(D,[1,F.neg(F.power(q,i))])
 Dvals=[F.ev(D,F.power(q,j)) for j in range(m+1)]
 ck(all(Dvals),'original denominator guards')
 E=[]
 for a in range(3*d-6):E.append([F.mul(F.power(q,hh*j*j+ee*a*j),F.power(Dvals[j],-1)) for j in range(m+1)])
 for a in range(d-1):E.append([F.mul(F.power(q,a*j),F.power(Dvals[j],-1)) for j in range(m+1)])
 return E,D,Dvals

def member(F,E,g):
 for row in E:
  val=0
  for x,y in zip(row,g+[0]*(len(row)-len(g))):val=F.add(val,F.mul(x,y))
  ck(val==0,'exact original U equation')

