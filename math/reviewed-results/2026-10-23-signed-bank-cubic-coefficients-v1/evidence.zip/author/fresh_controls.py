#!/usr/bin/env python3
"""Fresh standalone exact controls. No historical imports or program execution."""
import json, itertools

class Field:
    def __init__(self, p, binary=False):
        self.p=p; self.binary=binary; self.order=256 if binary else p
        self.ops={'add':0,'mul':0,'inv':0}
    def add(self,a,b):
        self.ops['add']+=1
        return a^b if self.binary else (a+b)%self.p
    def neg(self,a): return a if self.binary else (-a)%self.p
    def sub(self,a,b): return self.add(a,self.neg(b))
    def rawmul(self,a,b):
        if not self.binary:return a*b%self.p
        z=0
        while b:
            if b&1:z^=a
            b>>=1;a<<=1
            if a&256:a^=0x11b
        return z
    def mul(self,a,b):self.ops['mul']+=1;return self.rawmul(a,b)
    def power(self,a,n):
        z=1
        while n:
            if n&1:z=self.mul(z,a)
            a=self.mul(a,a);n//=2
        return z
    def inv(self,a):
        if not a:raise ArithmeticError('zero inverse')
        self.ops['inv']+=1;z=1;n=self.order-2
        while n:
            if n&1:z=self.rawmul(z,a)
            a=self.rawmul(a,a);n//=2
        return z
    def scalar(self,n):return (n&1) if self.binary else n%self.p

def tr(a):
    a=list(a)
    while a and not a[-1]:a.pop()
    return a

def deg(a):return len(tr(a))-1

def add(F,a,b):return tr([F.add(a[i] if i<len(a) else 0,b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def scale(F,a,c):return tr([F.mul(x,c) for x in a])
def sub(F,a,b):return add(F,a,scale(F,b,F.neg(1)))
def mul(F,a,b):
    if not a or not b:return []
    z=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):z[i+j]=F.add(z[i+j],F.mul(x,y))
    return tr(z)
def divrem(F,a,b):
    a=tr(a);b=tr(b)
    if not b:raise ArithmeticError('zero divisor')
    z=[0]*max(0,len(a)-len(b)+1);iv=F.inv(b[-1])
    while len(a)>=len(b):
        j=len(a)-len(b);c=F.mul(a[-1],iv);z[j]=c
        for k,x in enumerate(b):a[j+k]=F.sub(a[j+k],F.mul(c,x))
        a=tr(a)
    return tr(z),a

def quotient(F,a,b):
    q,r=divrem(F,a,b)
    if r:raise ArithmeticError('inexact division')
    return q

def gcd(F,a,b):
    a=tr(a);b=tr(b)
    while b:a,b=b,divrem(F,a,b)[1]
    return scale(F,a,F.inv(a[-1])) if a else []

def invmod(F,a,m):
    r0,r1=tr(m),divrem(F,a,m)[1];s0,s1=[],[1]
    while r1:
        q,r=divrem(F,r0,r1);r0,r1=r1,r;s0,s1=s1,sub(F,s0,mul(F,q,s1))
    if deg(r0)!=0:raise ArithmeticError('nonunit')
    return divrem(F,scale(F,s0,F.inv(r0[0])),m)[1]

def evaluate(F,a,x):
    z=0
    for c in reversed(a):z=F.add(F.mul(z,x),c)
    return z

def dot(F,a,b):
    z=0
    for x,y in zip(a,b):z=F.add(z,F.mul(x,y))
    return z

def rref(F,rows,n):
    A=[list(r)+[0]*(n-len(r)) for r in rows];piv=[];r=0
    for c in range(n):
        k=next((j for j in range(r,len(A)) if A[j][c]),None)
        if k is None:continue
        A[r],A[k]=A[k],A[r]
        iv=F.inv(A[r][c]);A[r]=[F.mul(x,iv) for x in A[r]]
        for j in range(len(A)):
            if j!=r and A[j][c]:
                z=A[j][c];A[j]=[F.sub(x,F.mul(z,y)) for x,y in zip(A[j],A[r])]
        piv.append(c);r+=1
        if r==len(A):break
    return A,piv

def nullspace(F,rows,n):
    A,piv=rref(F,rows,n);out=[]
    for j in range(n):
        if j in piv:continue
        z=[0]*n;z[j]=1
        for i,c in enumerate(piv):z[c]=F.neg(A[i][j])
        out.append(tr(z))
    return out

def combine(F,basis,cs):
    z=[]
    for b,c in zip(basis,cs):z=add(F,z,scale(F,b,c))
    return z

def select(F,a,basis,scalars,phi=None):
    """Actual reverse-chain algorithm, with strict exact checks and trial logs."""
    a=scale(F,tr(a),F.inv(a[-1]));A=a;chain=[];scan=0
    for j,b in enumerate(basis):
        if A==[1]:break
        D=gcd(F,A,b);scan+=1
        if D!=A:chain.append((A,D,j));A=D
    if A!=[1]:raise ArithmeticError('common gcd is not one')
    nz=[z for z in scalars if z]
    if len(set(nz))!=len(nz):raise ArithmeticError('duplicate scalar')
    if not chain:
        P=[]
    else:P=list(basis[chain[-1][2]])
    trials=[]
    for A,D,j in reversed(chain[:-1]):
        delta=deg(A)-deg(D);fail=[];chosen=None
        for lam in nz[:delta+1]:
            C=add(F,basis[j],scale(F,P,lam));E=gcd(F,A,C)
            if E==[1]:chosen=(lam,C);break
            fail.append({'lambda':lam,'gcd':E})
        if chosen is None:raise ArithmeticError('unwind budget exhausted')
        for x in fail:
            if gcd(F,D,x['gcd'])!=[1]:raise ArithmeticError('D overlap')
        for x,y in itertools.combinations(fail,2):
            if gcd(F,x['gcd'],y['gcd'])!=[1]:raise ArithmeticError('failure overlap')
        if sum(deg(x['gcd']) for x in fail)>delta:raise ArithmeticError('degree charge failed')
        lam,P=chosen;trials.append({'modulus_degree':deg(A),'next_degree':deg(D),'delta':delta,'failures':fail,'accepted_lambda':lam})
    repair=None
    if phi is not None and not phi(P):
        u=next((b for b in basis if phi(b)),None)
        if u is None:raise ArithmeticError('zero functional')
        D=gcd(F,a,u);delta=deg(a)-deg(D);fail=[]
        for lam in nz[:delta+1]:
            C=add(F,u,scale(F,P,lam));E=gcd(F,a,C)
            if E==[1]:P=C;repair={'delta':delta,'failures':fail,'accepted_lambda':lam};break
            fail.append({'lambda':lam,'gcd':E})
        else:raise ArithmeticError('repair budget exhausted')
    if gcd(F,a,P)!=[1]:raise ArithmeticError('terminal noncoprime')
    if phi is not None and not phi(P):raise ArithmeticError('functional lost')
    if sum(len(x['failures'])+1 for x in trials)>2*deg(a)-1:raise ArithmeticError('global budget failed')
    return P,{'scan_gcds':scan,'chain_degrees':[deg(a)]+[deg(x[1]) for x in chain], 'unwind':trials,'repair':repair}

def fast_axis(F,N,d,g):
    h=quotient(F,g,[F.neg(1),1]);n=deg(h);c=h[0] if h else 0
    if not c:raise ArithmeticError('axis precondition')
    v=list(reversed(h));D=gcd(F,h,v);hb=quotient(F,h,D);ell=deg(hb);s=d-1
    if ell<s:return False
    H=[1]*N;HD,rem=divrem(F,H,D)
    if rem:return True
    if ell==s:return False
    vb=quotient(F,v,D);K=h[1:]
    b0=divrem(F,scale(F,mul(F,mul(F,K,HD),invmod(F,vb,hb)),F.neg(1)),hb)[1]
    return not (deg(b0)==s and b0[-1]==1)

def exact_axis_rank(F,N,g):
    m=deg(g);powers=[];p=[1]
    for j in range(N):powers.append(p+[0]*(m-len(p)));p=divrem(F,[0]+p,g)[1]
    rows=[powers[a]+[1]+powers[(-a)%N] for a in range(N)]
    return len(rref(F,rows,2*m+1)[1])

def primitive(F,N):
    for q in range(1,F.order):
        if F.power(q,N)==1 and all(F.power(q,j)!=1 for j in range(1,N)):return q
    raise ArithmeticError('no primitive root')

def original_fixture(F,N,d):
    m=N-d;r=m-2;n=m-1;q=primitive(F,N);e=pow(2,-1,N);h=pow(4,-1,N);rho=F.power(q,e)
    den=[]
    for j in range(m+1):
        z=1
        for i in range(2,d):z=F.mul(z,F.sub(1,F.power(q,(i+j)%N)))
        if not z:raise ArithmeticError('envelope denominator')
        den.append(F.inv(z))
    E=[]
    for k in range(3*d-6):E.append([F.mul(den[j],F.power(q,(h*j*j+e*k*j)%N)) for j in range(m+1)])
    for k in range(d-1):E.append([F.mul(den[j],F.power(q,(k*j)%N)) for j in range(m+1)])
    U=nullspace(F,E,m+1)
    if not U:raise ArithmeticError('empty U')
    for g in U:
        if evaluate(F,g,1):raise ArithmeticError('missing fixed root')
    coeffs=nullspace(F,[[b[0] if b else 0 for b in U]],len(U))
    U0=[combine(F,U,c+[0]*(len(U)-len(c))) for c in coeffs]
    V0=[quotient(F,g,[0,F.neg(1),1]) for g in U0]
    V1=[quotient(F,g,[F.neg(1),1]) for g in U]
    def end(b):return (b[0] if b else 0,b[r] if len(b)>r else 0)
    pair=None
    for a,b in itertools.combinations(V0,2):
        a0,ar=end(a);b0,br=end(b);det=F.sub(F.mul(a0,br),F.mul(ar,b0))
        if det:pair=(a,b,a0,ar,b0,br,det);break
    if pair is None:raise ArithmeticError('endpoint dependence')
    a,b,a0,ar,b0,br,det=pair;iv=F.inv(det)
    f0=add(F,scale(F,a,F.mul(F.sub(br,b0),iv)),scale(F,b,F.mul(F.sub(a0,ar),iv)))
    if end(f0)!=(1,1):raise ArithmeticError('endpoint solve')
    def phi(b):a0,ar=end(b);return F.sub(ar,a0)
    scalars=list(range(2*N));f1,log1=select(F,f0,V0,scalars,phi)
    f=None;reciprocal_trials=0
    for z in scalars[:2*r+3]:
        reciprocal_trials+=1;Fz=add(F,f0,scale(F,f1,z))
        if deg(Fz)!=r or not Fz[0]:continue
        if gcd(F,Fz,list(reversed(Fz)))==[1]:f=scale(F,Fz,F.inv(Fz[-1]));break
    if f is None:raise ArithmeticError('reciprocal pencil exhausted')
    h0=[0]+f
    Wc=nullspace(F,[[b[n] if len(b)>n else 0 for b in V1]],len(V1))
    W=[combine(F,V1,c+[0]*(len(V1)-len(c))) for c in Wc]
    h1,log2=select(F,h0,W,scalars)
    accepted=None;final_trials=0;guard_log=[]
    for z in scalars:
        final_trials+=1;hz=add(F,h0,scale(F,h1,z));g=mul(F,[F.neg(1),1],hz)
        if not g[0]:guard_log.append('zero');continue
        derivative=tr([F.mul(F.scalar(j),g[j]) for j in range(1,len(g))])
        if gcd(F,g,derivative)!=[1]:guard_log.append('repeated');continue
        if not fast_axis(F,N,d,g):guard_log.append('axis');continue
        accepted=(z,g);guard_log.append('accepted');break
    if accepted is None:raise ArithmeticError('final pencil exhausted')
    z,g=accepted
    if deg(g)!=m or g[-1]!=1 or not g[0]:raise ArithmeticError('degree or endpoint')
    moments=[dot(F,row,g) for row in E]
    if any(moments):raise ArithmeticError('escaped ORIGINAL U')
    rank=exact_axis_rank(F,N,g)
    if rank!=N:raise ArithmeticError('original axis rank')
    return {'field':'GF(256), modulus 0x11b' if F.binary else 'F'+str(F.p),'N':N,'d':d,'q':q,'dim_U':len(U),'g':g,'all_original_moments':moments,'literal_axis_rank':rank,'first_combination':log1,'second_combination':log2,'reciprocal_trials':reciprocal_trials,'final_trials':final_trials,'guard_log':guard_log,'field_operation_counts_including_controls':F.ops}

def run():
    out={'description':'Fresh standalone controls; no historical imports or execution. Finite checks support but do not prove the universal theorem. No roots or banks constructed.','exhaustive':{},'adversarial':[],'original_fixtures':[]}
    binary=Field(2,True)
    for x in range(1,256):
        if binary.rawmul(x,binary.inv(x))!=1:raise ArithmeticError('binary field inverse')
    out['binary_field_nonzero_inverse_checks']=255
    F=Field(5);count=0;repair_count=0;fail_count=0;max_trials=0
    for v in [1,2]:
        polys=[tr(x) for x in itertools.product(range(5),repeat=v)]
        for low in itertools.product(range(5),repeat=v):
            a=list(low)+[1]
            for b,c in itertools.product(polys,repeat=2):
                if gcd(F,gcd(F,a,b),c)!=[1]:continue
                basis=[b,c];phi=(lambda x:x[0] if x else 0) if any(x and x[0] for x in basis) else None
                P,log=select(F,a,basis,list(range(5)),phi);count+=1
                repair_count+=int(log['repair'] is not None)
                fail_count+=sum(len(x['failures']) for x in log['unwind'])+(len(log['repair']['failures']) if log['repair'] else 0)
                max_trials=max(max_trials,sum(len(x['failures'])+1 for x in log['unwind']))
    out['exhaustive']={'field':'F5','monic_modulus_degrees':[1,2],'all_ordered_pairs_degree_less_than_modulus':True,'coprime_pair_cases':count,'functional_repairs':repair_count,'failed_trials_paid':fail_count,'max_unwind_trials':max_trials}
    F=Field(11);a=[0,1]
    for j in range(1,6):a=mul(F,a,[F.neg(j),1])
    p,log=select(F,a,[[0,1],[1]],[0,10,9,8,7,6,1,2,3,4,5])
    if len(log['unwind'][0]['failures'])!=5:raise ArithmeticError('tight control not tight')
    out['adversarial'].append({'name':'tight five-failure degree-drop charge','a':a,'p':p,'log':log})
    F=Field(5);p,log=select(F,[1,0,1],[[0,1],[1]],[2,3,1,0,4],lambda p:p[0] if p else 0)
    if len(log['repair']['failures'])!=2:raise ArithmeticError('repair tightness')
    out['adversarial'].append({'name':'tight functional repair with two failed values','p':p,'log':log})
    F=Field(11);a=[1]
    for root,mult in [(0,3),(1,2),(2,4)]:
        for _ in range(mult):a=mul(F,a,[F.neg(root),1])
    p,log=select(F,a,[[0,10,1],[0,1],[1]],[0,10,1,2,3,4,5,6,7,8,9])
    out['adversarial'].append({'name':'unequal repeated irreducible multiplicities 3,2,4','a':a,'p':p,'log':log})
    F=Field(2,True);a=[1]+[0]*7+[1]
    p,log=select(F,a,[[1,0,0,0,1],[1]],list(range(12)))
    out['adversarial'].append({'name':'inseparable characteristic-two modulus (t+1)^8','a':a,'p':p,'log':log})
    for F,N,d in [(Field(139),23,4),(Field(281),35,5),(Field(2,True),51,6)]:out['original_fixtures'].append(original_fixture(F,N,d))
    print(json.dumps(out,indent=2,sort_keys=True))

if __name__=='__main__':run()
