# Coefficient-stage ledger delta only

23 October 2026 UTC. Candidate pending independent review; original parameter gate retained.

Accepted fast-axis baseline: O(N^4) coefficient-field additions/multiplications, O(N^3) inversions, O(N^2) live storage. The two forward coprime-combination loops dominate because each pays O(N) trials for each of O(N) directions.

New reverse-descent candidate: prepare the strict gcd chain once, then traverse it backward. At a level with modulus-degree drop Delta, at most Delta+1 nonzero-scalar trials are needed. The failed gcds are pairwise coprime and coprime to the next chain divisor, with all multiplicities retained. The drops telescope. A single optional endpoint-functional repair uses at most another O(N) trials. Thus each combination has O(N) total degree-O(N) gcd trials rather than O(N^2).

Both combination loops now cost O(N^3) additions/multiplications and O(N^2) inversions. Ordinary schoolbook Euclid is used; no fast multiplication, half-gcd, factorization, or extension-field oracle is imported. Failed trials, current moduli, full-length candidate generation/reduction, coefficient reads/writes, and optional functional repair are included.

Dense original envelope and endpoint setup, the first reciprocal pencil, and the accepted 2N-trial fast-axis final pencil also each fit O(N^3) arithmetic and O(N^2) inversions. COMPLETE new deterministic coefficient-stage total: O(N^3) additions/multiplications, O(N^2) inversions, O(N^2) live storage. This matches rather than improves the old expected O(N^3) Las Vegas bound.

The same 2N distinct represented scalars suffice. The original U and original N>=8d-10 gate remain exact. The separate new-range composition is not used by this packet. No source ledger entry beyond the coprime-combination routines is replaced.

All cold field, genuine splitting-field, actual root, amplitude, weight, branch-inverse, output-coordinate, and extension/base-coordinate costs remain unchanged and paid. The existing O(Q^3) finite quadratic coefficient-field setup and enormous m!-overfield recipe remain. The literal warm O(N^3) bank application is unchanged. No full compiler/FFT improvement or bank-count improvement is claimed.
