# Fresh exact controls

23 October 2026 UTC. The executable fresh_controls.py was authored from scratch for this packet. It imports only Python standard-library json and itertools. No historical research program, author arithmetic module, saved fixture, or prior scientific script was imported or executed. Existing theorem and review prose were read as source material.

Normal and python -O runs produce byte-identical CONTROL.json and CONTROL_OPT.json. Checks use explicit exceptions, not removable assertions.

1. Exhaustive F5 selection checks: all monic moduli of degrees 1 and 2, and every ordered pair of polynomials of smaller degree, restricted to collective gcd one. There are 15,120 cases. Where the constant coefficient is a nonzero functional on the span, it is also required nonzero in the output. The run includes 1,904 actual functional repairs and 720 failed scalar trials, all charged and logged in the aggregate.
2. Tight unwind control: modulus t product_(j=1)^5(t-j) over F11, with basis t,1 and a deliberately adverse scalar ordering. Five consecutive values fail, exactly meeting the degree-drop budget before the sixth succeeds. The recorded failed gcds have distinct supports and retain their exact coefficients.
3. Tight functional repair: modulus t^2+1 over F5, basis t,1, and constant-coefficient functional. The initially coprime output t has zero functional. Two deliberately adverse repair values fail, then the third succeeds with both requirements intact.
4. Repeated multiplicities: t^3(t-1)^2(t-2)^4 over F11. The strict chain and all accepted/failed gcds retain exact multiplicities; no squarefree preprocessing is used.
5. Inseparable characteristic-two modulus: (t+1)^8 over GF256, with a degree-four repeated-factor direction and a constant. The algorithm succeeds without derivatives or root extraction. The field is represented using x^8+x^4+x^3+x+1 (0x11b); all 255 nonzero elements have their multiplicative inverses checked.
6. Full ORIGINAL-U generator fixtures, assembled from the defining chirped envelope rather than copied fixtures:
   - N=23, d=4, F139, primitive q=6. Original U has dimension 11. Output degree 19; literal original-axis rank 23.
   - N=35, d=5, F281, primitive q=4. Original U has dimension 18. Output degree 30; literal original-axis rank 35. This is composite root order.
   - N=51, d=6, GF256, primitive q=2. Original U has dimension 29. Output degree 45; literal original-axis rank 51. This is characteristic two and composite root order.

Every original-gate fixture checks all original envelope moments, the exact fixed root, endpoint solve, both coprime contracts, nonzero endpoint functional, reciprocal witness, final nonzero constant, squarefreeness, accepted fast-axis decision, and independently assembled dense original X rank. Both original pencils and all their tested failures are recorded. These three fixtures happen to have direct coprime basis choices; the exhaustive and adversarial controls separately exercise actual reverse traversal and repair failures.

Per-fixture field-operation counters include control verification work and are not asymptotic benchmarks or claimed optimized compiler counts. The all-parameter complexity comes from THEOREM.md, not a fitted timing.

No splitting field, physical-bank root array, bank weights, or online computation was built. These finite checks support transcription and exceptional-case coverage; they do not replace the all-parameter proof or independent review.
