"""Reviewer-authored reverse selection, using reviewer-owned field/axis helpers."""
from arithmetic import *
import itertools,hashlib,pathlib
calls=[]
def combo(F,a,W,grid,phi=None):
 v=len(a)-1;nonzero=[x for x in grid if x]
 ck(len(set(grid))==len(grid) and len(grid)>=v+2 and len(nonzero)>=v+1,'represented scalar interface')
 a=F.sc(a,F.power(a[-1],-1));As=[a];ps=[];scan=0
 for b in W:
  scan+=1;D=F.gc(As[-1],b)
  if D!=As[-1]:As.append(D);ps.append(b)
  if D==[1]:break
 ck(As[-1]==[1] and ps,'strict chain reaches one')
 P=ps[-1][:];trials=0;failures=0
 for i in range(len(ps)-2,-1,-1):
  A,D,p=As[i],As[i+1],ps[i];drop=len(A)-len(D);failed=[]
  ck(F.gc(D,P)==[1],'reverse induction invariant')
  for lam in nonzero[:drop+1]:
   C=F.pa(p,F.sc(P,lam));g=F.gc(A,C);trials+=1
   if g==[1]:P=C;break
   failures+=1
   ck(F.gc(D,g)==[1] and all(F.gc(e,g)==[1] for e in failed),'failed gcds pairwise coprime with D')
   failed.append(g)
   ck(sum(len(e)-1 for e in failed)<=drop,'multiplicity-aware failed-degree charge')
  else:raise RuntimeError('degree-drop trial bound')
 ck(trials<=v+len(ps)-1 and F.gc(a,P)==[1],'telescoping unwind trials')
 repair=0
 if phi is not None and phi(P)==0:
  u=next(b for b in W if phi(b));D=F.gc(a,u);drop=v-(len(D)-1)
  for lam in nonzero[:drop+1]:
   C=F.pa(u,F.sc(P,lam));repair+=1
   ck(phi(C)==phi(u)!=0,'functional repair invariant')
   if F.gc(a,C)==[1]:P=C;break
   failures+=1
  else:raise RuntimeError('functional trial bound')
 ck(F.gc(a,P)==[1] and (phi is None or phi(P)!=0),'complete combination contract')
 ck(scan<=len(W) and trials+repair<=3*v,'total linear scalar trials')
 calls.append({'v':v,'basis_size':len(W),'strict_drops':len(ps),'unwind_trials':trials,'repair_trials':repair,'failed_trials':failures})
 return P
# Tight reverse failure: degree drop two is charged twice, then succeeds.
F=Fld(7);a=[1]
for x in [1,2,3]:a=F.pm(a,[F.neg(x),1])
z=combo(F,a,[[6,1],[1]],[0,6,5,1,2])
ck(calls[-1]['unwind_trials']==3 and calls[-1]['failed_trials']==2,'tight degree-drop example')
# Tight optional functional repair: three failed distinct gcds, then success.
z=combo(F,a,[[0,1],[1]],[0,6,3,2,1],lambda b:b[0])
ck(calls[-1]['repair_trials']==4 and calls[-1]['failed_trials']==3,'tight functional-repair example')
# Exhaust ordered low-degree pairs over F3, with repeated moduli included.
F=Fld(3);exhaust=0
for v in [1]:
 polynomials=[trim(list(c)) for c in itertools.product(range(3),repeat=v)]
 for coeff in itertools.product(range(3),repeat=v):
  a=list(coeff)+[1]
  for b,c in itertools.product(polynomials,repeat=2):
   if F.gc(F.gc(a,b),c)!=[1]:continue
   W=[b,c];z=combo(F,a,W,[0,1,2]);ck(any(F.pa(F.sc(b,x),F.sc(c,y))==z for x in range(3) for y in range(3)),'same original span')
   if b[0] or c[0]:combo(F,a,W,[0,1,2],lambda z:z[0])
   exhaust+=1
# A different complete exhaustive field/domain from the author: F7, degree<=2.
F=Fld(7)
for v in [1,2]:
 polynomials=[trim(list(c)) for c in itertools.product(range(7),repeat=v)]
 for coeff in itertools.product(range(7),repeat=v):
  a=list(coeff)+[1]
  for b,c in itertools.product(polynomials,repeat=2):
   if F.gc(F.gc(a,b),c)!=[1]:continue
   z=combo(F,a,[b,c],list(range(v+2)))
   ck(any(F.pa(F.sc(b,x),F.sc(c,y))==z for x in range(7) for y in range(7)),'same original span')
   if b[0] or c[0]:combo(F,a,[b,c],list(range(v+2)),lambda z:z[0])
   exhaust+=1
# Repeated and inseparable characteristic-two example, with full multiplicity.
F=Fld(2,0x13);a=F.pm(F.pm([1,0,1],[1,0,1]),[4,0,1]);W=[[1,0,1],[4,0,1]]
z=combo(F,a,W,list(range(10)))
ck(F.gc(a,F.deriv(a))==a and F.gc(a,z)==[1],'inseparable modulus supported')
# Newly reconstruct ORIGINAL U and both pencils; no author fixture is read.
fixtures=[]
for N,d,F in [(23,4,Fld(139)),(35,5,Fld(281)),(51,6,Fld(2,0x11b))]:
 q=next(x for x in range(2,F.q) if F.power(x,N)==1 and all(F.power(x,j)!=1 for j in range(1,N)))
 m=N-d;r=m-2;n=m-1;grid=list(range(2*N));ck(N>=8*d-10 and len(grid)<=F.q,'original generator gate')
 E,_,_=build(F,N,d,q);U=F.ker(E);U0=F.ker(E+[[1]+[0]*m]);lin=[F.neg(1),1]
 V0=[F.dv(g,[0,F.neg(1),1])[0] for g in U0];V1=[F.dv(g,lin)[0] for g in U]
 lead=lambda z:z[r] if len(z)>r else 0
 a,b=next((a,b) for a in V0 for b in V0 if F.sub(F.mul(a[0],lead(b)),F.mul(b[0],lead(a))))
 det=F.sub(F.mul(a[0],lead(b)),F.mul(b[0],lead(a)));iv=F.power(det,-1)
 f0=F.pa(F.sc(a,F.mul(F.sub(lead(b),b[0]),iv)),F.sc(b,F.mul(F.sub(a[0],lead(a)),iv)))
 ck(f0[0]==lead(f0)==1,'actual endpoint solve')
 f1=combo(F,f0,V0,grid,lambda z:F.sub(lead(z),z[0]))
 for lam in grid[:2*r+3]:
  f=F.pa(f0,F.sc(f1,lam))
  if len(f)==r+1 and f[0] and F.gc(f,trim(f[::-1]))==[1]:break
 else:raise RuntimeError('reciprocal pencil')
 f=F.sc(f,F.power(f[-1],-1));h0=[0]+f;g0=F.pm(lin,h0);member(F,E,g0)
 ck(len(F.rr(axis(F,g0,N))[1])==N,'actual zero-constant axis witness')
 W=[]
 for z in V1:
  w=F.pa(z,F.sc(h0,F.neg(z[n] if len(z)>n else 0)))
  if w!=[0]:W.append(w)
 h1=combo(F,h0,W,grid)
 for lam in grid:
  g=F.pm(lin,F.pa(h0,F.sc(h1,lam)))
  if g[0] and F.gc(g,F.deriv(g))==[1] and len(F.rr(axis(F,g,N))[1])==N:break
 else:raise RuntimeError('final original guards')
 member(F,E,g);ck(g[-1]==1 and len(g)==m+1,'monic full-degree output')
 fixtures.append({'N':N,'d':d,'field_size':F.q,'q':q,'g':g,'h1':h1,'f':f,'chosen_scalar':lam,'axis_rank':N})
print(json.dumps({'status':'PASS','author_code_executed':False,'reused_reviewer_arithmetic':True,'checks':sum(cnt.values()),'categories':dict(sorted(cnt.items())),'exhaustive_cases':exhaust,'combination_calls':len(calls),'failed_trials':sum(c['failed_trials'] for c in calls),'repair_calls':sum(c['repair_trials']>0 for c in calls),'max_trial_ratio_to_v':max((c['unwind_trials']+c['repair_trials'])/c['v'] for c in calls),'fixtures':fixtures},indent=2,sort_keys=True))
