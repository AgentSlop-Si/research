# Independent review: reverse gcd descent

23 October 2026 UTC. Verdict: ACCEPT, with the exact scope below. This is an independent mathematical and operation-count review, not a historical novelty finding. No author scientific program or historical program was executed.

## Bound claim and accepted baseline

Author theorem: `signed_bank_reverse_gcd_descent_20261023_v1/THEOREM.md`, SHA-256 `d455cb9bc049c12de23d616e2c608a28b9b01a2208f51c74aaf3c21ec7ff4f8a`. Author manifest: `d6e66d1935f84528a3947eb891b2892e209a9ac4cef39a1b0ff04a604a40ad65`. All seven author members and all seven selected original/accepted source pins were checked byte-for-byte; BINDINGS.json records them and the reviewer arithmetic provenance.

The accepted domain here is ONLY odd N, d >= 4, N >= 8d-10, char(k) not dividing N, a supplied primitive Nth root, the exact original envelope E and U=E-perp, and the supplied effective list of 2N distinct coefficient-field scalars. The separate N >= 6d-2 composition is not incorporated by implication.

The accepted fast-axis baseline has deterministic coefficient work O(N^4) additions/multiplications, O(N^3) inversions and O(N^2) live field elements. Its two forward coprime-selection loops are the bottleneck. This theorem replaces those loops, obtaining COMPLETE deterministic coefficient work O(N^3) additions/multiplications, O(N^2) inversions and O(N^2) live field elements. This matches the previously accepted expected O(N^3) Las Vegas arithmetic bound, not a new faster expected bound.

## Independent algebraic proof

Let a be monic of degree v >= 1 and let the given polynomials b_j, of degree at most L >= v, span W with gcd(a,W)=1. Scanning the original basis and recording only strict decreases constructs A_0=a and A_i=gcd(A_(i-1),p_i), ending in A_l=1. Every p_i is an original basis member; l <= v and at most s basis gcds were used.

Initialize P=p_l, so gcd(A_(l-1),P)=1. During reverse traversal at level i, gcd(D,P)=1 where A=A_(i-1), D=A_i=gcd(A,p_i). For a nonzero scalar lambda define e_lambda=gcd(A,p_i+lambda P). A factor common to D and e_lambda would divide P, contrary to gcd(D,P)=1. A factor common to e_lambda and e_mu for distinct scalars would divide P and p_i, hence D, again impossible. Thus all failed gcds are pairwise coprime and coprime to D. Since they and D divide A, their product, with their actual multiplicities, divides A. Consequently the total degrees of failed gcds are at most deg A-deg D=Delta. At most Delta trials fail, so Delta+1 distinct nonzero candidates suffice.

Each success preserves the same scalar span W and establishes gcd(A,P)=1 for the next reverse level. The sum of all strict degree drops is v. Including success trials, the reverse traversal uses at most v+l-1 <= 2v-1 gcd trials; the omitted terminal base level only improves this conservative bound. This is a genuine amortized reduction, not a bound charged independently by v at every level.

For an additional nonzero linear functional phi, first complete the unconstrained construction. If phi(P)=0, choose an original basis element u with phi(u) != 0. Every u+lambda P has the same nonzero phi value. Apply the same argument to a, u and D=gcd(a,u): at most v-deg D failed gcds and one success. The case a divides u is legal and succeeds on the first nonzero scalar. A list of v+2 distinct scalars provides v+1 nonzero values, even if it includes zero. The proof needs neither separability, factorization as an algorithm, characteristic-zero differentiation, nor a perfect field.

In the first original pencil, a=f0 has degree r=m-2 and endpoints one, W is the exact V0, and phi(f)=coefficient_r(f)-f(0). The accepted endpoint independence makes phi nonzero; the new lemma gives exactly gcd(f0,f1)=1 and phi(f1) != 0. In the second original pencil, a=h0=tf, W is the degree-(m-1) leading-coefficient kernel in the exact V1. The already accepted decomposition V1=k h0+W implies gcd(h0,W)=1. The lemma returns exactly the same required h1, including h1(0) != 0. No changed coefficient space, denominator guard, field restriction, or unproved root claim is introduced. The reciprocal pencil and final fast-axis guard remain the accepted ones.

## Independent complete cost check

A schoolbook gcd of a divisor of a and a degree-at-most-L candidate costs O(L^2) additions/multiplications and O(L) inversions, including initial reduction when the candidate degree exceeds the current modulus. There are at most s preparation gcds, O(v) total reverse trials and O(v) optional repair trials. Every full candidate vector costs O(L) to form; basis/functional scans cost O(sL), and coefficient comparisons and output writes fit the same bounds. Thus the lemma costs O((s+v)L^2) arithmetic and O((s+v)L) inversions. Basis storage is O(sL), the strict divisor chain O(v^2), and streamed candidates and Euclid buffers O(L); original basis indices avoid duplicate polynomial storage.

For both actual applications, s,v,L=O(N). Both complete selection routines therefore cost O(N^3) arithmetic and O(N^2) inversions, not O(N^4). Dense construction of the original spaces/endpoints already fits O(N^3). The original reciprocal pencil has O(N) schoolbook quadratic tests. The accepted final guard likewise has at most 2N quadratic tests. All of these fit the same cubic arithmetic and quadratic inversion bounds; none remains an uncounted quartic bottleneck. Their scalar lists fit the same 2N-element interface, since v+2 <= N+1 and 2m-1 < 2N.

The coefficient-field setup, explicit scalar-list representation, genuine splitting field, actual distinct nonzero roots, weights, amplitudes, branch inverses, extension/base-coordinate conversion, and output costs are NOT removed. In particular, the finite quadratic-field O(Q^3) setup and the conservative factorial-degree overfield recipe remain. The literal warm application and bank count 2m+2 do not improve. There is no accepted end-to-end polynomial-time compiler or Fourier/FFT acceleration in this review.

## Fresh independent controls and limitations

The new selection implementation in fresh_controls.py was written independently of the author. arithmetic.py is an explicitly bound reuse of this reviewer's prior field, polynomial, original-envelope and literal-axis helpers, not an author control. No author fixture/output was used to assemble the three new full generators.

Normal and optimized Python executions are required to agree byte-for-byte; checks use explicit exceptions, not assertions erased by optimization. They cover 115,608 exhaustive collective-gcd-one cases over F3 and F7, with monic moduli through degree two in F7, both unconstrained and endpoint-functional variants. They validate the same scalar span, failed-gcd coprimality and multiplicity charge, reverse invariant, telescoping trial bound, optional functional preservation, and exact final gcd. Tight examples require all permitted failed trials at a reverse level and at the optional repair. A characteristic-two inseparable modulus checks that no separability was silently used.

Fresh original-U constructions at (N,d)=(23,4) over F139, (35,5) over F281, and (51,6) over GF256 reconstruct the exact envelope, both pencils, all original moment equations, monicity, nonzero constant, squarefreeness, and literal dense axis ranks 23,35,51. Dense ranks are independent controls, not substituted for the accepted quadratic axis algorithm in the complexity claim. The resulting coefficient vectors are retained in CONTROL.json.

The final controls report 4,428,007 checks, 229,209 combination calls, 4,865 failed scalar trials, and 12,061 functional repairs. These are implementation/stress controls; the all-parameter and operation-count conclusions rest on the proof above. No bank arrays, splitting extension, or actual root recovery were instantiated, and no such execution is claimed.

## Publication scope

Accept only this old-range deterministic coefficient-stage improvement and exact selection lemma. Preserve all source field/root/application caveats. No parent problem closure, new bank count, new-range composition, historical novelty clearance, or asymptotic FFT claim is licensed. The author packet needs no mathematical repair for this scope.
