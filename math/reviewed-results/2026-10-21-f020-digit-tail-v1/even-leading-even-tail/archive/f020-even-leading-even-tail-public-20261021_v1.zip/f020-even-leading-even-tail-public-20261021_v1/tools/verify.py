#!/usr/bin/env python3
"""Strict offline public-byte, source-binding, archive and negative-control checks."""
from pathlib import Path,PurePosixPath
import argparse,base64,copy,hashlib,html,io,itertools,json,os,re,shutil,stat,sys,tempfile,urllib.parse,zipfile,warnings,struct,zlib
ROOT=Path(__file__).resolve().parents[1]
PACKAGE='f020-even-leading-even-tail-public-20261021_v1'
ANCHORS={'README.md': 'a335d1cc8f7f6601cfe39c3140556e1d4e9f470ce37ec4b1c2cb9569e46f50b8', 'REPLAY_POLICY.json': '33737ea9da41d34eb32ebabddc31427d2e54248053c5f363bd0d753d447edaea', 'SCOPE.json': '6ed0aa86801eb1e195ec4a96414e94506756f55b12ba6c0b4520caee3836ca40', 'provenance/ACCEPTANCE_BINDING.json': '2d1f005af3c9c402bb4d44f1c194db026366f92269313de1ec44caa2d27586a4', 'provenance/DEPENDENCIES.json': 'c2ddc9541293c87e43f6833d8935d3c30aa93edf72f964d1e4a3898e24490ed2', 'provenance/SOURCE_INVENTORY.json': '0c3a9f86d2619172779511eaaae2cd41b68c5267233bb69ff31bb36d58bc0f28', 'provenance/TOOLING_ORIGIN.json': '6cb6f346475d2d9072b2466df7915ad7aa99572a9ba4f7e89d7797a0c1919bce', 'requirements.txt': 'f1875458a8627f4b3dba74388cd6c3cb4785ded1f653d6acd6c07f0fe467a5a6', 'tools/failure_controls.py': 'cbc6ac16c4b93a516c277bbb86482f69ef37bce3ff8e372d150f5c1150a9f784', 'tools/isolation_probe.py': '72d5de70d66071672ab219e6fe3929d7130880697ea7422d27854d9e96e998a4', 'tools/replay.py': '461d3f2147b480bf372e9eac983f682538c18d10c54faae76a727427c8cabce8', 'tools/run_case.py': '50a7eeff602963d53767a499ad4c81a55763e094fbf8efc14e052f79bade9eb1'}
SOURCES={'author': '3e8b8d80451bc5a7d720d19e2870926d50473e64ffe26e2ecdcd31eeecdc5004', 'independent-review': 'bbae14d01d0a8498aa552374284f570bfd36b623500ecd07852c0869c3aae099'}
DEP_SHA='c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe'
HEX=re.compile('[0-9a-f]{64}\\Z')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def ident(b):return {'bytes':len(b),'sha256':sha(b)}
def pairs(items):
 d={}
 for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def loads(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def read(p):return loads(p.read_bytes())
def exact(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if type(a)is list:return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def same(a,b,msg):need(exact(a,b),msg)
def keys(d,k):need(type(d)is dict and d.keys()==set(k),'object fields')
def identity(d):
 keys(d,('bytes','sha256'));need(type(d['bytes'])is int and d['bytes']>=0,'length type');need(type(d['sha256'])is str and HEX.fullmatch(d['sha256'])is not None,'digest format')
def route(s):
 need(type(s)is str and bool(s) and '\\' not in s and not any(ord(c)<32 or ord(c)==127 for c in s),'path spelling')
 p=PurePosixPath(s);need(not p.is_absolute() and str(p)==s and not any(t in ('.','..','') for t in p.parts) and ':' not in s,'unsafe path')
 need('__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'),'bytecode forbidden');return s
def inventory(root):
 need(root.is_dir() and not root.is_symlink(),'root type');files=set();fold=set()
 for p in root.rglob('*'):
  need(not p.is_symlink(),'symlink forbidden');rel=route(p.relative_to(root).as_posix());need(rel.casefold() not in fold,'case collision');fold.add(rel.casefold())
  if p.is_file():files.add(rel)
  else:need(p.is_dir(),'nonregular member')
 return files
def text_variants(text):
 seen=set();queue=[text]
 while queue:
  s=queue.pop()
  if s in seen:continue
  seen.add(s);yield s
  need(len(seen)<100000,'escaped-text budget')
  for t in (html.unescape(s),urllib.parse.unquote(s),s.replace('\\/','/'),re.sub(r'\\(?:u([0-9a-fA-F]{4})|x([0-9a-fA-F]{2}))',lambda m:chr(int(m[1] or m[2],16)),s)):
   if t not in seen:queue.append(t)
  if s.lstrip().startswith(('{','[','"')):
   try:v=loads(s)
   except (ValueError,TypeError):pass
   else:
    def strings(v):
     if type(v)is str:yield v
     elif type(v)is list:
      for x in v:yield from strings(x)
     elif type(v)is dict:
      for k,x in v.items():yield k;yield from strings(x)
    queue.extend(t for t in strings(v) if t not in seen)
  for token in re.findall(r'(?<![A-Za-z0-9+/_-])[A-Za-z0-9+/_-]{24,}={0,2}(?![A-Za-z0-9+/_-])',s):
   try:t=base64.b64decode(token+'='*((-len(token))%4),altchars=b'-_',validate=True).decode('utf8')
   except (ValueError,UnicodeError):continue
   if t not in seen and all(c.isprintable() or c in '\r\n\t' for c in t):queue.append(t)
def privacy(name,raw,depth=0):
 need(depth<=4,'recursive archive depth')
 if name.endswith('.zip') or raw[:4]==b'PK\x03\x04':
  members=zip_members(raw)
  for n,b in members.items():privacy(n,b,depth+1)
  return
 try:text=raw.decode('utf8')
 except UnicodeError:raise ValueError('unclassified binary member: '+name)
 if name.endswith('.json'):loads(text)
 tokens=['/'+p+'/' for p in ('work'+'space','home','root','tmp','users','mnt','media')]+['cloud'+'_threads','collaboration'+'.','mcp'+'__','user_message'+'.','/'+'agent_notes'+'/','/'+'user_notes'+'/','dream'+'_notes','delivery'+'_context','thread'+'_id','lib'+'file_','codex'+':','chatgpt'+'.com']
 for s in itertools.chain(text_variants(name),text_variants(text)):
  local_scan=s.lower().replace('https://users.math.msu.edu'+'/'+'users'+'/bsagan/', 'verified-public-citation/')
  need(not any(t in local_scan for t in tokens),'private locator or coordination text: '+name)
  need(re.search(r'[A-Za-z]:[\\/](?:Users|Documents)[\\/]',s,re.I)is None,'private drive locator')
  need(re.search('-----BEGIN '+r'(?:RSA |EC |OPENSSH )?PRIVATE KEY-----',s)is None,'key marker')
  need(re.search(r'(?:gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{32,})',s)is None,'credential marker')
  extra=['file'+':'+ '//','sandbox'+':'+ '//','sediment'+':'+ '//','functions'+'.exec','cloud'+'_browser_handoff','library'+'_file_id','/'+'var'+'/folders/']
  need(not any(t.lower() in s.lower() for t in extra),'private scheme or coordination marker')
  need(re.search(r'Bearer\s+[A-Za-z0-9._-]{20,}',s,re.I)is None,'bearer marker')
  need(re.search(r'\b(?:password|api_key|client_secret|access_token|refresh_token)\s*[=:]\s*[\"\'][^\"\']{12,}',s,re.I)is None,'credential assignment')
def envelope(raw):
 need(len(raw)>=22 and raw[-22:-18]==b'PK\x05\x06','exact terminal EOCD required')
 sig,disk,cdisk,n1,n2,cdsize,cdoff,comment=struct.unpack('<4s4H2IH',raw[-22:]);need(disk==cdisk==comment==0 and n1==n2 and n2<=3000,'single disk non-ZIP64 envelope');need(cdoff+cdsize==len(raw)-22,'central directory envelope')
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  infos=z.infolist();need(len(infos)==n2,'EOCD entry count');pos=0;central=cdoff
  for i in infos:
   need(i.header_offset==pos and pos+30<=cdoff,'local span contiguity')
   h=struct.unpack('<4s5H3I2H',raw[pos:pos+30]);sig,version,flags,method,tm,dt,crc,cs,us,ns,xs=h
   need(sig==b'PK\x03\x04' and version<=20 and flags&~0x800==0 and method in (0,8),'local header profile');need(flags==i.flag_bits and method==i.compress_type and crc==i.CRC and cs==i.compress_size and us==i.file_size and xs==0,'local header consistency')
   name=raw[pos+30:pos+30+ns];need(name.decode('utf8' if flags&0x800 else 'cp437')==i.orig_filename,'local name consistency');start=pos+30+ns+xs;end=start+cs;need(end<=cdoff,'local data span');comp=raw[start:end]
   if method==8:
    d=zlib.decompressobj(-15);data=d.decompress(comp,64*1024**2+1);need(d.eof and not d.unused_data and not d.unconsumed_tail,'exact deflate stream envelope');data+=d.flush()
   else:data=comp
   need(len(data)==us and zlib.crc32(data)&0xffffffff==crc,'local data length/CRC')
   need(central+46<=len(raw)-22 and raw[central:central+4]==b'PK\x01\x02','central record span');ch=struct.unpack('<4s6H3I5H2I',raw[central:central+46]);need(ch[3]==flags and ch[4]==method and ch[7]==crc and ch[8]==cs and ch[9]==us and ch[10]==ns and ch[11]==ch[12]==ch[13]==0 and ch[16]==pos,'central/local consistency');need(raw[central+46:central+46+ns]==name,'central name identity');central+=46+ns;pos=end
  need(pos==cdoff and central==len(raw)-22,'no ZIP prefix, suffix, gap or hidden record')

def zip_members(raw):
 envelope(raw)
 out={};fold=set()
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  need(not z.comment,'archive comment forbidden');infos=z.infolist();need(len(infos)<=3000 and sum(i.file_size for i in infos)<=64*1024**2,'archive budget')
  for i in infos:
   need(i.orig_filename==i.filename and not i.comment and not i.extra,'hidden member metadata');n=route(i.filename);need(not i.is_dir() and not i.flag_bits&1,'directory/encrypted archive entry');need(n not in out and n.casefold() not in fold,'duplicate/case archive entry')
   need(stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG),'archive member type');fold.add(n.casefold());out[n]=z.read(i)
  for n in out:need(not any('/'.join(n.split('/')[:j]).casefold() in fold for j in range(1,len(n.split('/')))),'archive file/directory conflict')
  need(z.testzip() is None,'CRC failure')
 return out
def extract(raw,dest):
 need(not dest.exists() and not dest.is_symlink(),'extraction destination exists');members=canonical_members(raw)
 for n,b in members.items():privacy(n,b)
 dest.mkdir(parents=True)
 try:
  for n,b in members.items():
   p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 except Exception:shutil.rmtree(dest);raise
 return len(members)
def canonical_zip(members):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w',compression=zipfile.ZIP_STORED) as z:
  for n,data in sorted(members.items()):
   route(n);i=zipfile.ZipInfo(n,(1980,1,1,0,0,0));i.create_system=3;i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_STORED;z.writestr(i,data)
 return b.getvalue()
def canonical_members(raw):
 members=zip_members(raw);need(raw==canonical_zip(members),'noncanonical archive bytes');need({n.split('/')[0] for n in members}=={PACKAGE},'archive package root');return members

def source_check(root):
 inv=read(root/'provenance/SOURCE_INVENTORY.json');same(inv['source_manifest_sha256'],SOURCES,'frozen source identities')
 need(inv['scientific_bytes_changed'] is False and inv['original_manifest_bytes_preserved'] is True and inv['original_seal_bytes_preserved'] is True,'source preservation')
 by={};modes={'verbatim':0,'locator_projection':0};occurrences=0
 for row in inv['files']:
  n=route(row['collection']+'/'+row['source_path']);need(n==row['stored_path'] and n not in by,'source route uniqueness');by[n]=row
  identity(row['original']);identity(row['exported']);raw=(root/n).read_bytes();same(ident(raw),row['exported'],'source exported identity');need(row['mode'] in modes,'source mode');modes[row['mode']]+=1
  if row['mode']=='verbatim':same(row['original'],row['exported'],'verbatim scientific identity');same(row['changes'],[],'verbatim changes')
  else:
   need(n.endswith('.json') and '/provenance/' not in n,'administrative projection scope');context=raw;size=row['original']['bytes'];need(bool(row['changes']),'nonempty projections')
   for i,c in enumerate(row['changes']):
    keys(c,('kind','old_locator_bytes','old_locator_sha256','new_locator','count','context_marker'));need(c['kind']=='operational_locator_only' and type(c['count'])is int and c['count']>=1,'projection type');identity({'bytes':c['old_locator_bytes'],'sha256':c['old_locator_sha256']});new=c['new_locator'].encode();need(raw.count(new)==c['count'],'projection replacement count');need(c['context_marker']==f'<OPERATIONAL_LOCATOR_{i}>','projection marker');context=context.replace(new,c['context_marker'].encode());size+=(len(new)-c['old_locator_bytes'])*c['count'];occurrences+=c['count']
   need(len(raw)==size and sha(context)==row['unchanged_context_sha256'],'projection unchanged context')
 omitted={}
 for row in inv['omissions']:
  n=route(row['collection']+'/'+row['source_path']);need(n not in by and n not in omitted,'omission uniqueness');identity(row['original']);omitted[n]=row
  need(PurePosixPath(row['source_path']).parts.count('dependencies')>=2 or n.endswith(('.zip','.log')),'omission outside declared historical scope')
 for role in inv['manifest_roles']:
  prefix=role['collection']+('/'+role['root'] if role['root']!='.' else '');mb=(root/prefix/'MANIFEST.json').read_bytes();m=loads(mb);need(sha(mb)==role['manifest_sha256']==read(root/prefix/'SEAL.json')['manifest_sha256'],'source manifest/seal');names={'MANIFEST.json','SEAL.json'}
  for row in m['files']:
   n=route(row['path']);need(n not in names,'source inventory duplicate');names.add(n);declared=by.get(prefix+'/'+n) or omitted.get(prefix+'/'+n);need(declared is not None,'undeclared missing original source');same(declared['original'],{k:row[k] for k in ('bytes','sha256')},'original source binding')
  retained={n[len(prefix)+1:] for n in by if n.startswith(prefix+'/')};missing={n[len(prefix)+1:] for n in omitted if n.startswith(prefix+'/')};same(retained|missing,names,'exact original source inventory accounting');same(role['omitted_original_paths'],sorted(missing),'exact source omissions');need(role['original_inventory_completely_retained'] is (not missing),'honest completeness role')
  if role['root']=='.':need(role['manifest_sha256']==SOURCES[role['collection']],'source root anchor')
 for coll in SOURCES:need(inventory(root/coll)=={n[len(coll)+1:] for n in by if n.startswith(coll+'/')},'retained source exact set')
 return {'retained_files':len(by),'projected_files':modes['locator_projection'],'projected_locator_occurrences':occurrences,'omitted_original_files':len(omitted),'original_inventory_roles':inv['manifest_roles']}

def semantics(root):
 v=read(root/'independent-review/VERDICT.json');scope=read(root/'SCOPE.json');accept=read(root/'provenance/ACCEPTANCE_BINDING.json');binding=read(root/'author/SOURCE_BINDINGS.json');claim=read(root/'author/CLAIM_SCOPE.json')
 need(v['verdict']==accept['mathematical_verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE','exact mathematical acceptance');need(accept['author_manifest_sha256']==SOURCES['author'] and accept['review_manifest_sha256']==SOURCES['independent-review'],'acceptance source identities')
 need(v.get('author_manifest_sha256',v.get('candidate_manifest_sha256'))==SOURCES['author'],'review accepted exact author manifest')
 need(v.get('author_report_sha256',v.get('candidate_report_sha256'))==sha((root/'author/REPORT.md').read_bytes()),'review accepted exact author proof')
 same(accept['author_report'],ident((root/'author/REPORT.md').read_bytes()),'author report identity');same(accept['review_report'],ident((root/'independent-review'/route(accept['review_report_path'])).read_bytes()),'review report identity');same(accept['review_verdict'],ident((root/'independent-review/VERDICT.json').read_bytes()),'verdict identity');same(scope['accepted_verdict'],v,'complete scope verdict');same(scope['author_claim'],claim,'complete author scope')
 need(accept['public_packaging_independently_accepted']is False,'no public self-acceptance')
 for k in ['all_general_c_derivative_pivots_retained','Mprime_full_disk_bound_retained','both_prime_boundaries_included','complete_low_and_high_clusters','original_P_H_squarefree','original_algebraic_square_CD_nonzero_at_every_P_root','global_F020_F023_open','public_byte_audit_pending']:need(scope[k]is True,'scope '+k)
 for k in ['zero_root','arbitrary_n_claim','FFT_or_cost_claim','historical_novelty_claim']:need(scope[k]is False,'scope '+k)
 need(scope['high_root_count']=='c*p^r; cL in each of beta disks' and scope['low_root_count']=='d' and scope['low_derivative_value']=='(n-1)/2' and scope['H_derivative_multiplier_residue']=='(-1)^(c/2+d/2-1)*i','counts/values/unit distinctions')
 pins={x['name']:x['manifest_sha256']for x in binding['sources']};need(set(pins)=={'general-author','general-review','c2-even-author','c2-even-review','c4-plus2-author','c4-plus2-review'},'six exact accepted source roles')
 for row in binding['sources']:
  need(row['copy']=='dependencies/'+row['name'],'source path');need(sha((root/'author'/row['copy']/'MANIFEST.json').read_bytes())==row['manifest_sha256'],'source pin')
 for rev,au,key in [('general-review','general-author','author_manifest_sha256'),('c2-even-review','c2-even-author','candidate_manifest_sha256'),('c4-plus2-review','c4-plus2-author','author_manifest_sha256')]:
  ar=root/'author/dependencies'/au;vr=read(root/'author/dependencies'/rev/'VERDICT.json');need(vr['verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE' and vr[key]==pins[au],'accepted dependency author binding')
  for k in ('candidate_report_sha256','author_report_sha256'):
   if k in vr:need(vr[k]==sha((ar/'REPORT.md').read_bytes()),'accepted dependency report binding')
 ga=root/'author/dependencies/general-author';gb=read(ga/'SOURCE_BINDINGS.json');same(gb['mathematical_dependencies'],[],'omitted history not mathematical premise');need(gb['archive_sha256']==DEP_SHA,'historical archive identity')
 need(sha((ga/'REPORT.md').read_bytes())=='639b35b0b603fccc44a57c1f5321fc7efc5c9007510b0cd12d714eefc0d5820c','exact general-c coefficientwise authority')
 need(binding['source_programs_executed']is False,'no inherited replay inflation')
 p=read(root/'REPLAY_POLICY.json');need(p['historical_programs_freshly_replayed']is False and p['original_inventory_wrappers_replayed']is False,'no replay inflation');same(p['scientific_source_adapters'],[],'no scientific source adapters');same(p['timing_exceptions'],[],'no output exceptions')
 d=read(root/'provenance/DEPENDENCIES.json');need(d['public_delivery_includes_complete_six_historical_trees']is False and d['historical_inclusion_statements_in_exact_reports_apply_to_original_candidate_not_this_compact_delivery']is True,'partial history disclosure')

def integrity(root=ROOT):
 actual=inventory(root);m=read(root/'MANIFEST.json');seal=read(root/'SEAL.json');keys(m,('schema_version','package','files'));keys(seal,('algorithm','manifest','manifest_sha256','file_count'));need(type(m['schema_version'])is int and m['schema_version']==1 and m['package']==PACKAGE,'manifest schema');need(seal['algorithm']=='SHA-256' and seal['manifest']=='MANIFEST.json' and seal['manifest_sha256']==sha((root/'MANIFEST.json').read_bytes()),'public manifest seal');need(type(seal['file_count'])is int and seal['file_count']==len(actual),'public file count');names=[]
 for row in m['files']:
  keys(row,('path','bytes','sha256'));n=route(row['path']);identity({k:row[k]for k in ('bytes','sha256')});names.append(n);same(ident((root/n).read_bytes()),{k:row[k]for k in ('bytes','sha256')},'public member identity: '+n)
 need(names==sorted(set(names)) and actual==set(names)|{'MANIFEST.json','SEAL.json'} and not {'MANIFEST.json','SEAL.json'}&set(names),'exact public inventory')
 dirs={str(p.relative_to(root)) for p in root.rglob('*') if p.is_dir()};expected_dirs={str(p) for n in actual for p in PurePosixPath(n).parents if str(p)!='.'};need(dirs==expected_dirs,'extra directory')
 for n,h in ANCHORS.items():need(sha((root/n).read_bytes())==h,'fixed administrative/scientific anchor: '+n)
 for n in sorted(actual):privacy(n,(root/n).read_bytes())
 src=source_check(root);semantics(root)
 return {'status':'PASS','public_regular_files':len(actual),'source_representation':src,'optimized_python':bool(sys.flags.optimize),'public_packaging_independently_accepted':False}

def reseal(root):
 files=[{'path':p,**ident((root/p).read_bytes())} for p in sorted(inventory(root)-{'MANIFEST.json','SEAL.json'})];(root/'MANIFEST.json').write_text(json.dumps({'schema_version':1,'package':PACKAGE,'files':files},indent=2,sort_keys=True)+'\n');(root/'SEAL.json').write_text(json.dumps({'algorithm':'SHA-256','manifest':'MANIFEST.json','manifest_sha256':sha((root/'MANIFEST.json').read_bytes()),'file_count':len(files)+2},indent=2,sort_keys=True)+'\n')
def negatives(root=ROOT):
 integrity(root);rows=[]
 for kind in ['changed_proof','missing_file','extra_file','extra_directory','symlink_file','symlink_directory','rehashed_proof','duplicate_json_key','unsafe_path','duplicate_manifest_member','wrong_seal','boolean_byte_count','negative_byte_count','float_byte_count','nonfinite_json']:
  with tempfile.TemporaryDirectory(prefix='public-inventory-mutant-') as td:
   d=Path(td)/'copy';shutil.copytree(root,d)
   if kind=='changed_proof':(d/'author/REPORT.md').write_bytes(b'changed')
   elif kind=='missing_file':(d/'author/REPORT.md').unlink()
   elif kind=='extra_file':(d/'EXTRA').write_text('extra')
   elif kind=='extra_directory':(d/'EXTRA').mkdir()
   elif kind=='symlink_file':(d/'author/REPORT.md').unlink();(d/'author/REPORT.md').symlink_to(root/'author/REPORT.md')
   elif kind=='symlink_directory':(d/'LINK').symlink_to(root/'author',target_is_directory=True)
   elif kind=='rehashed_proof':(d/'author/REPORT.md').write_bytes(b'changed');reseal(d)
   elif kind=='duplicate_json_key':p=d/'MANIFEST.json';p.write_text(p.read_text().replace('{','{"files": [],',1));s=read(d/'SEAL.json');s['manifest_sha256']=sha(p.read_bytes());(d/'SEAL.json').write_text(json.dumps(s))
   elif kind=='wrong_seal':s=read(d/'SEAL.json');s['manifest_sha256']='0'*64;(d/'SEAL.json').write_text(json.dumps(s))
   else:
    m=read(d/'MANIFEST.json')
    if kind=='unsafe_path':m['files'][0]['path']='../outside'
    elif kind=='boolean_byte_count':m['files'][0]['bytes']=True
    elif kind=='negative_byte_count':m['files'][0]['bytes']=-1
    elif kind=='float_byte_count':m['files'][0]['bytes']=float(m['files'][0]['bytes'])
    elif kind=='nonfinite_json':m['files'][0]['bytes']=float('nan')
    else:m['files'].append(m['files'][0])
    p=d/'MANIFEST.json';p.write_text(json.dumps(m));s=read(d/'SEAL.json');s['manifest_sha256']=sha(p.read_bytes());(d/'SEAL.json').write_text(json.dumps(s))
   rejected=False
   try:integrity(d)
   except (ValueError,OSError,KeyError,TypeError):rejected=True
   need(rejected,'accepted inventory mutant '+kind);rows.append({'mutation':kind,'rejected':True})
 members={PACKAGE+'/'+n:(root/n).read_bytes() for n in inventory(root)};raw=canonical_zip(members)
 tests={'prefix':b'prefix'+raw,'suffix':raw+b'suffix','eocd_comment':raw[:-2]+b'\x01\x00'+b'x'}
 for kind in ['compressed','timestamp','member_extra','archive_symlink','unsafe_archive_path','duplicate_archive_member','case_collision']:
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:
   for i,(n,data) in enumerate(sorted(members.items())):
    info=zipfile.ZipInfo('../escape' if kind=='unsafe_archive_path' and i==0 else n,(1981,1,1,0,0,0) if kind=='timestamp' and i==0 else (1980,1,1,0,0,0));info.create_system=3;info.external_attr=(0o120777 if kind=='archive_symlink' and i==0 else 0o100644)<<16;info.compress_type=zipfile.ZIP_DEFLATED if kind=='compressed' else zipfile.ZIP_STORED
    if kind=='member_extra' and i==0:info.extra=b'\x01\x00\x00\x00'
    z.writestr(info,data)
   if kind in ('duplicate_archive_member','case_collision'):
    n,data=next(iter(sorted(members.items())));n=n if kind=='duplicate_archive_member' else n.upper()
    with warnings.catch_warnings():warnings.simplefilter('ignore');z.writestr(n,data)
  tests[kind]=b.getvalue()
 for kind,data in tests.items():
  rejected=False
  try:canonical_members(data)
  except (ValueError,OSError,zipfile.BadZipFile,UnicodeError,struct.error):rejected=True
  need(rejected,'accepted archive mutant '+kind);rows.append({'mutation':'archive_'+kind,'rejected':True})
 canonical_members(raw);integrity(root);return {'status':'PASS','optimized_python':bool(sys.flags.optimize),'mutations':rows,'original_unchanged':True}
def main():
 p=argparse.ArgumentParser();p.add_argument('--archive');p.add_argument('--expect-sha256');p.add_argument('--extract');p.add_argument('--negative-controls',action='store_true');a=p.parse_args()
 if a.archive:
  need(a.expect_sha256 is not None and HEX.fullmatch(a.expect_sha256),'trusted archive digest required');raw=Path(a.archive).read_bytes();need(sha(raw)==a.expect_sha256,'archive SHA-256 mismatch');canonical_members(raw)
  if a.extract:
   dest=Path(a.extract);extract(raw,dest);out=integrity(dest/PACKAGE)
  else:
   with tempfile.TemporaryDirectory(prefix='exact-zip-check-')as td:dest=Path(td)/'new';extract(raw,dest);out=integrity(dest/PACKAGE)
 else:need(not a.extract and not a.expect_sha256,'archive required');out=integrity()
 if a.negative_controls:out['negative_controls']=negatives()
 print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('FAIL: '+str(e),file=sys.stderr);sys.exit(1)
