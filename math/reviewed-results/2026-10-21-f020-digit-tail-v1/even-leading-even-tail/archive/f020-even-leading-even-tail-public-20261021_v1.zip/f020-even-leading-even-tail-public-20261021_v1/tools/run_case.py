#!/usr/bin/env python3
"""Run exact scientific source bytes. Never rewrite scientific code or its output."""
from pathlib import Path
import json,shutil,subprocess,sys
I=Path('/input');W=Path('/work')
def need(b,m):
 if not b:raise RuntimeError(m)
def main():
 role=sys.argv[1];need(role in ('author','review'),'unknown role');d=W/(role+('_optimized' if sys.flags.optimize else ''));d.mkdir()
 rel='author/check_controls.py' if role=='author' else 'independent-review/independent_controls.py';source=I/rel;script=d/source.name;shutil.copyfile(source,script);need(script.read_bytes()==source.read_bytes(),'scientific source changed')
 flags=[sys.executable,'-I','-B']+(['-O']if sys.flags.optimize else[])
 probe="import json,sys\nfired=False\ntry: assert False\nexcept AssertionError: fired=True\nprint(json.dumps({'optimize':sys.flags.optimize,'debug':__debug__,'assert_executed':fired},sort_keys=True))"
 obs=subprocess.run(flags+['-c',probe],capture_output=True,check=False);need(obs.returncode==0 and obs.stderr==b'','optimization probe failed');state=json.loads(obs.stdout);expected={'optimize':int(bool(sys.flags.optimize)),'debug':not bool(sys.flags.optimize),'assert_executed':not bool(sys.flags.optimize)};need(state==expected,'actual child optimization behavior mismatch');(d/'OPTIMIZATION.json').write_bytes(obs.stdout)
 args=flags+[str(script)]
 p=subprocess.run(args,cwd=d,stdout=subprocess.PIPE,stderr=subprocess.PIPE);sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr)
 (d/'RESULTS.json').write_bytes(p.stdout)
 need(p.returncode==0,'scientific child failed');need(p.stderr==b'','scientific stderr differs from empty frozen reference')
if __name__=='__main__':main()
