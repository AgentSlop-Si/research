#!/usr/bin/env python3
"""Exercise actual CLI failures/interruption durability; never alter frozen input."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,signal,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
def need(b,m):
 if not b:raise RuntimeError(m)
def read(p):return json.loads(p.read_bytes())
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--archive',required=True);ap.add_argument('--expect-sha256',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
 out=Path(a.output).resolve();need(out!=ROOT and ROOT not in out.parents and not out.exists(),'Output must be new and outside frozen input');out.mkdir(parents=True)
 spec=importlib.util.spec_from_file_location('replay_support',ROOT/'tools/replay.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
 result=out/'FAILURE_CONTROLS.json';r.put(result,{'status':'FAIL','phase':'RUNNING','completion_is_not_established':True})
 try:
  archive=Path(a.archive).resolve();pin=hashlib.sha256(archive.read_bytes()).hexdigest();need(pin==a.expect_sha256,'trusted archive digest mismatch');before={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in ROOT.rglob('*')if p.is_file()};rows=[]
  def args(dest,digest=pin):return [str(ROOT/'tools/replay.py'),'--archive',str(archive),'--expect-sha256',digest,'--output',str(dest)]
  def run(label,argv,env=None,timeout=30):
   with (out/(label+'.stdout')).open('wb')as stdout,(out/(label+'.stderr')).open('wb')as stderr:p=subprocess.run([sys.executable,'-I','-B']+argv,stdout=stdout,stderr=stderr,timeout=timeout,env=env)
   return p.returncode
  target=out/'wrong_digest';rc=run('wrong_digest',args(target,'0'*64));rec=read(target/'REPLAY_RESULT.json');need(rc!=0 and rec['status']=='FAIL','bad pin did not fail durably');rows.append({'case':'wrong_digest','returncode':rc,'durable_status':'FAIL'})
  target=out/'existing_output';target.mkdir();sentinel=target/'preserve';sentinel.write_bytes(b'do not replace');rc=run('existing_output',args(target));need(rc!=0 and sentinel.read_bytes()==b'do not replace' and list(target.iterdir())==[sentinel],'existing output changed');rows.append({'case':'existing_output','returncode':rc,'unchanged':True})
  target=out/'completed_success';rc=run('completed_success',args(target),timeout=300);need(rc==0 and read(target/'REPLAY_RESULT.json')['status']=='PASS','actual successful replay required before preservation test');snapshot={p.relative_to(target).as_posix():p.read_bytes()for p in target.rglob('*')if p.is_file()};rc=run('preserve_success_receipts',args(target));need(rc!=0 and snapshot=={p.relative_to(target).as_posix():p.read_bytes()for p in target.rglob('*')if p.is_file()},'successful-run evidence overwritten');rows.append({'case':'preserve_success_receipts','returncode':rc,'actual_completed_replay_unchanged':True,'all_success_receipts_and_logs_unchanged':True})
  rc=run('missing_digest',[str(ROOT/'tools/replay.py'),'--archive',str(archive),'--output',str(out/'missing_digest')]);need(rc!=0 and not(out/'missing_digest').exists(),'missing digest accepted');rows.append({'case':'missing_digest','returncode':rc,'not_started':True})
  # Deliberately failing launchers exercise real nonzero/timeout subprocess paths.
  # They exit or sleep; no scientific work is run without the required sandbox.
  for label,body,timeout_expected in [('launcher_nonzero','import sys; print("intentional launcher failure",file=sys.stderr); sys.exit(17)',False),('launcher_timeout','import time; time.sleep(35)',True)]:
   bin_dir=out/(label+'_bin');bin_dir.mkdir();launcher=bin_dir/'bwrap';launcher.write_text('#!'+sys.executable+'\n'+body+'\n');launcher.chmod(0o700);env=dict(os.environ);env['PATH']=str(bin_dir);target=out/label;rc=run(label,args(target),env=env,timeout=60);rec=read(target/'REPLAY_RESULT.json');command=read(target/'isolation_probe/RESULT.json');need(rc!=0 and rec['status']=='FAIL' and command['status']=='FAIL' and command['child_started']is True,'launcher failure not durable');need(command['timed_out']is timeout_expected,'wrong launcher timeout status')
   if timeout_expected:need(rec.get('failure_type')=='TimeoutExpired' and command['returncode']!=0,'timeout failed to kill actual child')
   else:need(command['returncode']==17,'nonzero launcher status not preserved')
   need((target/'isolation_probe/STDOUT.txt').exists() and(target/'isolation_probe/STDERR.txt').exists(),'launcher raw logs lost');rows.append({'case':label,'returncode':rc,'child_returncode':command['returncode'],'timed_out':timeout_expected,'durable_status':'FAIL','actual_subprocess_failure':True,'raw_logs_retained':True,'scientific_work_executed':False})
  # Both signals are sent only after a real scientific replay child has started.
  for label,sig in [('caught_term',signal.SIGTERM),('uncatchable_kill',signal.SIGKILL)]:
   target=out/label;proc=None
   try:
    with (out/(label+'.stdout')).open('wb')as stdout,(out/(label+'.stderr')).open('wb')as stderr:
     proc=subprocess.Popen([sys.executable,'-I','-B']+args(target),stdout=stdout,stderr=stderr,start_new_session=True);limit=time.monotonic()+180
     while True:
      need(proc.poll()is None,'replay finished before interruption');need(time.monotonic()<limit,'interruption probe wait expired');q=target/'review_controls/RESULT.json'
      if q.exists():
       running=read(q)
       if running.get('phase')=='RUNNING' and running.get('child_started')is True:break
      time.sleep(.005)
     initial=read(target/'REPLAY_RESULT.json');need(initial['status']=='FAIL' and initial['phase']=='RUNNING','missing durable initial FAIL');os.kill(proc.pid,sig);rc=proc.wait(timeout=20)
   finally:
    if proc is not None and proc.poll()is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   rec=read(target/'REPLAY_RESULT.json');need(rec['status']=='FAIL','interrupted replay falsely passed');need((target/'review_controls/STDOUT.txt').exists() and (target/'review_controls/STDERR.txt').exists(),'raw logs not retained')
   if sig==signal.SIGTERM:need(rec.get('failure_type')=='InterruptedError' and 'phase'not in rec,'caught signal not terminal FAIL')
   else:need(rec['phase']=='RUNNING' and rec['completion_is_not_established']is True,'uncatchable kill not visibly incomplete')
   rows.append({'case':label,'returncode':rc,'durable_receipt':rec,'raw_logs_retained':True,'interrupted_actual_scientific_child':True})
  # Retry into the killed run must refuse without changing its original failure receipt or logs.
  target=out/'uncatchable_kill';snapshot={p.relative_to(target).as_posix():p.read_bytes()for p in target.rglob('*')if p.is_file()};rc=run('preserve_failed_receipts',args(target));need(rc!=0 and snapshot=={p.relative_to(target).as_posix():p.read_bytes()for p in target.rglob('*')if p.is_file()},'failed-run evidence overwritten');rows.append({'case':'preserve_failed_receipts','returncode':rc,'all_failed_receipts_and_logs_unchanged':True})
  after={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in ROOT.rglob('*')if p.is_file()};need(before==after and hashlib.sha256(archive.read_bytes()).hexdigest()==pin,'frozen input changed');report={'status':'PASS','input_zip_sha256':pin,'cases':rows,'frozen_input_unchanged':True};r.put(result,report);print(json.dumps(report,indent=2,sort_keys=True))
 except BaseException as e:r.put(result,{'status':'FAIL','failure_type':type(e).__name__,'incomplete_or_failed_is_never_PASS':True});raise
if __name__=='__main__':main()
