# Independent review of the leading-two scope assembly

21 October 2026 UTC. **ACCEPTED AS AN EXACT ASSEMBLY OF ESTABLISHED RESULTS.**

No essential repair, new mathematical computation, or unresolved source/parameter gap is needed for the stated union. This is an audit of the scope assembly, not a fresh replay of its component mathematical proofs and not acceptance of a future publication or delivery package.

## Immutable target

The reviewed scope map is the exact 8,995-byte `PUBLIC_SCOPE_MAP.md`, retained here as `REVIEWED_SCOPE_MAP.md`:

- Scope-map SHA-256: `c916d5b664e9a98b6ecc5c1e141907e44da1f939af79b8baf8f4d7a6cd41228e`.
- Assembly manifest SHA-256: `aca9cfea5c2f1250a32b630ddaf728eae1e561f953d7f0db721c7e14ecbf383a`.

The accepted conclusion is exactly this: for every odd prime p >= 3, integers r >= 2 and s > r, integer 0 <= d < p, n = 2p^r+d, and characteristic-zero primitive p^s-th root q, the original P_n and Gaussian H_n are squarefree, and the original algebraic-square Christoffel–Darboux kernel is nonzero at every P_n root.

The author did not change the frozen map during this review. The reviewer supplied no mathematical repair and modified no component input.

## 1. Source bytes and acceptance roles

I read the actual component statements, the relevant accepting reviews, the d=0 portable author/review text, and the p=3 inheritance statements. An independently written read-only checker verified 32 exact manifest trees from the two tail candidates/reviews and their nested retained sources, plus the scope-assembly inventory. It checked safe paths, duplicate keys/members, file and directory sets, absence of symlinks, byte lengths, SHA-256 digests, and seals. It did not import or execute any component mathematical program.

The independently checked top-level pins are:

- Even-tail candidate: `c7b391df43fc8fb0fb14fab06ddd1d4e722d791469fc2593017ef27d8d9a88d3`.
- Even-tail accepting review: `419d478b906e68600983a1b209ed53e0f05c532875d409398ee7ae9e168cb012`.
- Uniform double-tail-lift candidate: `58d896c0e672d3363f2cb5948b7cad268648ec9414ca0d57476b8ab26920f43c`.
- Its accepting review: `0a3d7ace672e07401c79c034bef5725804a5e6b10a1a5ffc13f067e13bdaef7f`.

The d=0 source was not inferred from a first-two-digit or r=1 theorem. It is the separately accepted theorem whose own statement is n=2p^r for all odd p, r>=2 and s>r. Its original author/review manifest identities are `b407a5fe2b13690b5bcb6fc14d24e1496b27ec683be548cc6c68598ffa91fbb6` and `55a208d001d9a566377c7939fdb5b6ebbce8d97f18d55faf707468e5ff1157e1`.

These original manifest identities are provenance pins, not hashes of the presently retained projected manifests. The actual d=0 scientific text is in the accepted comparison archive with SHA-256 `c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe`. I checked its 453 bound root members, its nested 408-member accepted-theorem inventory, and the 363-member leading-two portable inventory. Their respective manifest hashes are `952a6175b389b582ab4ae28491a380fa9cc8d699a45f8af0f2ea9b9240241bf8`, `80a47c38808e2064893e56d4ad99ff580e5d340a1c841c4aa85797d16d99e5e9`, and `4f7a26b247d12df5490d155de2743113a6752853e9df804b4aace08c7b9dd2ee`.

The leading-two acceptance and full 352-row source ledger distinguish 344 exact exports, seven public projections, and one omitted administrative file. Each exported byte count/hash was checked. The original report pin is `232918eb924abc7a92f1a56610d7f96858440388023608c50e3d493bf4d791fc`; the retained projected report actually hashes to `cf5e92c832d6f387154c2df0508cf59ff3438a1a25a4d88b62a74b9544dc59e6`. The original accepting review report pin is `e7799b205a827dbf2054edf9af4d979f1a6a8db82aa4d598d4074d79afc7be37`; its retained projection hashes to `5d8358343d9ef92e008c2c9002c2e4b94a83983615bb3fdedac7f0762338f5bd`. The accepting verdict is unchanged at `cfb5b5379f2b020a9ee978a4f83033969be9fea23b30d46f88675764abd69463`.

The disclosed projections concern locators and contributor/administrative wording, with scientific content preserved according to the accepted ledger. This review verifies the retained projections and their existing acceptance bridge; it does not claim to have recovered or independently compared undistributed original private bytes. That limitation is explicit and is not an unresolved mathematical source gap. The scope map describes it correctly.

The general-adjacent author uses that archive as provenance and proves its own coefficientwise facts. Here the direct, separately accepted leading-two theorem is the d=0 premise. The general-adjacent c=2,r=2 obstruction concerns degree 2p^2+1, not degree 2p^2, and is not imported as a missing d=0 or even-tail case.

## 2. The complete partition

Every integer 0<=d<p belongs to exactly one of the following three sets.

1. **d=0.** The direct leading-two theorem covers every stated p,r,s and phase. It supplies all 2N high roots, original P/H squarefreeness, and kernel nonvanishing.
2. **Positive odd d.** For p>=5, the accepted odd-tail criterion covers r>=3. At r=2 it covers all cases except the simultaneous conditions p divides d!!-(d-1)!! and p divides 2d+1. Since 0<2d+1<2p, the latter divisibility is equivalent here to p=2d+1. The accepted uniform lift has exactly that remaining hypothesis, together with the first divisibility. It supplies all 2p remaining central roots, not only a scalar test or one branch. For odd d and p>=5 the simultaneous locus forces p>=7. Thus the p>=7 restriction of the lift leaves no p=5 gap.
3. **Positive even d.** The accepting even-tail review covers every even 2<=d<p with no unresolved prime/tail exception. This includes d=p-1 and the smallest p=3,d=2 case. Previously accepted +2 and +4 results are overlaps, not additional scope or novelty credit.

There is no missing positive d between these classes and no appeal to extension from r=1. This partition proves the assembled sector directly from the accepted scopes; finite test coverage plays no role.

## 3. The p=3 boundary

There are exactly three admissible digits when p=3:

- d=0 is covered by the direct leading-two theorem, including r=2.
- d=1,r>=3 is covered by the accepted general-adjacent theorem with c=2<p. Its r>=3 branch is unconditional and uses the stated original normalizations.
- d=1,r=2 is covered by the accepted original P_19 central completion, not by the p>=5 odd-tail first correction or p>=7 double lift. Its central derivative valuation is 76/3 for every s>2 and primitive characteristic-zero phase. The earlier accepted partial result supplies the zero and noncentral roots.
- d=2 is covered by the uniform even-tail theorem, including the extreme digit d=p-1.

For the P_19 inheritance I independently checked the central-family ZIP hash `667b37740cd2229082899e726a6efdb7e2be8b2e5d177eed5d3869bbcb79ec4e`, all 38 bound public members, and manifest `c06eac3ddea8e228e239f338d756d16e1fc1b0c9f2535fd624f2b49c8a8ca24b`. Its explicit acceptance binding points to author `072e4134daea3f759d79550c891027abb0410ed38aac6826635fee085f730147` and review `b7583a6324271df5defc71514c871562a88c62cfb69ed736b62d3814abebff47`. The author/report/review/verdict bytes match those pins, and the 29-row ledger distinguishes 27 verbatim exports, one locator projection, and one excluded operational request. No P_19 computation was rerun.

## 4. Root counts, zero roots, and constant terms

All three sources use N=p^r, B=r(p-1)p^(r-1)/2, K=N+2B, E=N/2+2B, and D=N+E-p. The common beta high disks contain 2L boundary roots each, beta*2L=2N. Those counts retain multiplicity until the original derivative arguments prove simplicity. The repeated residual in a high disk is not used as a simple-root Hensel premise.

The zero/low partition differs by parity and the map preserves it:

- d=0 has no low roots and no exact P zero.
- Odd d=2m+1 has one exact simple P zero, d-1 nonzero low roots, and 2N high roots. Its zero derivative value is K+m. The high-disk count concerns the quotient P_n/X; the zero is not counted a second time as a central boundary root.
- Even d=2m>=2 has d nonzero low roots and 2N high roots, with no P zero.

The low roots have value 1/2 and the high-root X values are at least 1, so these counts are disjoint and exhaust degree n.

The scope map's extension of the even constant-term formula to d=0 is correct and needs no new theorem. Directly from the original recurrence, P_(2N)(0)=(-1)^N times the product of (1-q^j) over odd 1<=j<2N. Since p is odd, the even indices contribute W(N) to W(2N); the accepted identity W(2N)=2W(N) gives value W(N)=N+2B=K. For positive even d=2m, the accepted tail formula multiplies this by its unit-normalized matching constant of value m. Hence v(P_n(0))=K+m and no even case has an exact P zero.

The odd P zero corresponds to the H root z=-1. It is not H(0); H_n(0)=1 always. The map makes this distinction explicitly.

## 5. Normalizations, phases, and the kernel

The common recurrence is exactly P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1). Gaussian H and w_j=product_(u=1)^j(1-q^u) agree across the sources. The valuation convention is v(q-1)=1 in an algebraic p-adic embedding, so v(p)=(p-1)p^(s-1). No comparison silently changes to v(p)=1.

The degree bound is uniform: pN-(2N+d)=(p-2)N-d>0 since N>=p^2 and d<=p-1. Therefore n<p^(r+1)<=p^s, even for p=3,d=p-1,s=r+1. Every recurrence edge and CD denominator used before degree n is nonzero.

Every derivative conclusion concerns the original ordinary characteristic-zero derivative with its integer factors retained, not a q-derivative or a derivative of an inseparable residual. The even low/high derivative values N+m-1/2 and D+m match the accepted theorem. The d=0 all-root value D matches the direct theorem. The odd-tail map correctly makes no single constant all-root derivative claim and retains the special P_19 central value.

The exact identity H_n(v0^2)=v0^n P_n(v0+v0^(-1)) gives, after ordinary differentiation and evaluation at a root, a unit multiplier between corresponding P/H derivatives. The branch near i is unramified for odd p; its multiplier residue is i^(n-1). Thus the equal valuations in the map are valid without asserting equality of normalized units. Dropping the prefactor derivative away from a root would not be justified, and the map does not do so.

All three accepted sources give every characteristic-zero primitive phase. Their p-adic arguments use each phase's own t=q-1 and transfer algebraic nonvanishing by embeddings/conjugacy. The union introduces no fixed-phase, fixed-s, or unrelated finite-characteristic extrapolation.

At a P_n root xi, the original CD identity is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
      = P_n'(xi) P_(n-1)(xi) / w_(n-1).

Consecutive-polynomial coprimality follows from the nonzero recurrence edges and P_0=1. Together with the accepted simplicity, every factor on the right is nonzero. The squares remain algebraic squares; no positivity, absolute-value substitution, or complex interlacing premise enters.

## 6. Disposition and exclusions

The frozen scope map is accepted without amendment. `SOURCE_AUDIT.json` records the actual byte checks. The source checker is reproducible and uses only standard-library inventory/hash operations; its output was rechecked after review without executing component controls. The copied map and this review package are public-safe, with no private source locators copied into them.

This verdict accepts only the exact assembly n=2p^r+d, 0<=d<p, odd p>=3,r>=2,s>r in characteristic zero. It gives no new acceptance for p=2, r<2, s<=r, d>=p, nonzero intermediate digits, other leading digits, composite orders, arbitrary n, unrelated finite-characteristic reductions, deeper root geometry beyond the component statements, global F020/F023 closure, historical novelty, FFT/cost gains, external annotations, repository writes, publication, or delivery. These exclusions do not assert that all excluded cases are unresolved elsewhere.

No external write occurred, and all frozen inputs were preserved.
