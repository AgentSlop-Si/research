#!/usr/bin/env python3
"""Read-only independent exact inventory verifier; never executes source code."""
import argparse,hashlib,json
from pathlib import Path,PurePosixPath

def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify(root,expected):
    root=Path(root)
    need(not root.is_symlink(),'symlink root')
    for f in root.rglob('*'):need(not f.is_symlink(),'symlink '+str(f.relative_to(root)))
    m=root/'MANIFEST.json';need(sha(m)==expected,'manifest pin mismatch')
    manifest=json.loads(m.read_text());rows=manifest['files'];seen=set()
    for row in rows:
        name=row['path'];q=PurePosixPath(name)
        need(not q.is_absolute() and '..' not in q.parts and name not in seen,'unsafe or repeated path')
        seen.add(name);p=root/name;data=p.read_bytes()
        need(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'bound bytes mismatch '+name)
    actual={str(f.relative_to(root)) for f in root.rglob('*') if f.is_file()}
    need(actual==seen|{'MANIFEST.json','SEAL.json'},'inventory mismatch')
    expected_dirs={str(d) for name in actual for d in PurePosixPath(name).parents if str(d)!='.'}
    actual_dirs={str(d.relative_to(root)) for d in root.rglob('*') if d.is_dir()}
    need(actual_dirs==expected_dirs,'directory inventory mismatch')
    need(json.loads((root/'SEAL.json').read_text())['manifest_sha256']==expected,'seal mismatch')
    return {'manifest_sha256':expected,'manifest_bound_files':len(rows),'total_files':len(actual),'all_bytes_and_inventory':'PASS'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('manifest_sha256');ap.add_argument('--dependencies',action='store_true');args=ap.parse_args()
    result={'candidate':verify(args.root,args.manifest_sha256)}
    if args.dependencies:
        for key,pin in [('general-author','e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7'),('general-review','a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7')]:result[key]=verify(args.root/'dependencies'/key,pin)
        d=args.root/'dependencies';verdict=json.loads((d/'general-review/VERDICT.json').read_text());binding=json.loads((d/'general-review/SOURCE_BINDING.json').read_text())
        need(verdict['verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE','source not accepted')
        need(verdict['author_manifest_sha256']==result['general-author']['manifest_sha256']==binding['author_manifest_sha256'],'author review identity mismatch')
        need(binding['author_report_sha256']==sha(d/'general-author/REPORT.md'),'source report binding mismatch')
        result['author_review_binding']='PASS';result['accepted_programs_executed']=False
    print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
