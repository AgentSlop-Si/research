#!/usr/bin/env python3
import argparse,copy,hashlib,json,shutil,tempfile,zipfile
from pathlib import Path
from verify_inventory import verify


def sha(b):return hashlib.sha256(b).hexdigest()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('candidate');ap.add_argument('--manifest',required=True);ap.add_argument('--output',required=True);ap.add_argument('--accepted-comparison');args=ap.parse_args();root=Path(args.candidate)
    inventory=verify(root,args.manifest)
    sb=json.loads((root/'SOURCE_BINDINGS.json').read_text());zb=(root/sb['dependency_archive']).read_bytes();assert sha(zb)==sb['archive_sha256']
    assert sha(zb)=='c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe','comparison differs from pinned preceding accepted source'
    if args.accepted_comparison:assert zb==Path(args.accepted_comparison).read_bytes(),'comparison bytes differ'
    with zipfile.ZipFile(root/sb['dependency_archive']) as z:
        paths=[i.filename for i in z.infolist() if not i.is_dir()];assert len(paths)==len(set(paths))
        prefix=sb['archive_root'];mb=z.read(prefix+'MANIFEST.json');assert sha(mb)==sb['manifest_sha256'];m=json.loads(mb)
        for item in m['files']:
            b=z.read(prefix+item['path']);assert sha(b)==item['sha256'] and len(b)==item['bytes']
        assert len(m['files'])==sb['verified_manifest_entries']
        for item in sb['files']:
            assert z.read(item['archive_path'])==(root/item['copy']).read_bytes()
    mutations=['proof_edit','bound_file_deleted','unlisted_file_added','seal_mismatch','rehashed_replacement','symlink_replacement']
    outcomes=[]
    for mutation in mutations:
        with tempfile.TemporaryDirectory(prefix='adjacent-inventory-tamper-') as td:
            d=Path(td)/'candidate';shutil.copytree(root,d)
            if mutation=='proof_edit':(d/'REPORT.md').write_bytes((d/'REPORT.md').read_bytes()+b'\nTAMPER\n')
            if mutation=='bound_file_deleted':(d/'REPORT.md').unlink()
            if mutation=='unlisted_file_added':(d/'UNBOUND.txt').write_text('must reject')
            if mutation=='seal_mismatch':(d/'SEAL.json').write_text(json.dumps({'manifest_sha256':'0'*64}))
            if mutation=='rehashed_replacement':
                p=d/'REPORT.md';p.write_bytes(p.read_bytes()+b'\nTAMPER\n');mf=json.loads((d/'MANIFEST.json').read_text())
                for item in mf['files']:
                    if item['path']=='REPORT.md':item.update(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
                (d/'MANIFEST.json').write_text(json.dumps(mf));(d/'SEAL.json').write_text(json.dumps({'manifest_sha256':sha((d/'MANIFEST.json').read_bytes())}))
            if mutation=='symlink_replacement':
                p=d/'REPORT.md';b=p.read_bytes();p.unlink();outside=Path(td)/'redirect.md';outside.write_bytes(b);p.symlink_to(outside)
            try:verify(d,args.manifest)
            except (AssertionError,FileNotFoundError) as exc:outcomes.append({'mutation':mutation,'rejected':True,'reason':str(exc)})
            else:raise AssertionError('tamper accepted: '+mutation)
    result={'status':'PASS','manifest_sha256':args.manifest,'exact_file_count':inventory['file_count'],'provenance_archive_sha256':sha(zb),'provenance_manifest_entries':len(m['files']),'provenance_matches_preceding_accepted_bytes':True,'tamper_controls':outcomes,'scope':'All modifications performed on disposable copies; frozen candidate and sources left unchanged.'}
    Path(args.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
