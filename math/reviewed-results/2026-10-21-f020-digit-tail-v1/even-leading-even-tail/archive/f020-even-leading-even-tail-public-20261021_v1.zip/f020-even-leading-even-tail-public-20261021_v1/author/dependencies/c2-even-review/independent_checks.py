"""Independent, standard-library, finite falsification controls.

No candidate/predecessor program is imported or executed. The uniform argument
is in REPORT.md; these exact fixtures are not a proof by parameter census.
"""
from fractions import Fraction
from itertools import combinations
import hashlib
import json
import sys


def need(ok, message):
    if not ok:
        raise ValueError(message)


# Multivariate integer polynomials: exponent 0 is X; exponent j is edge a_j.
def add(a, b, scale=1):
    c = dict(a)
    for k, v in b.items():
        c[k] = c.get(k, 0) + scale * v
        if not c[k]:
            del c[k]
    return c


def mul(a, b):
    c = {}
    for k, v in a.items():
        for l, w in b.items():
            e = tuple(x+y for x, y in zip(k, l))
            c[e] = c.get(e, 0) + v*w
    return {k: v for k, v in c.items() if v}


def deriv(a):
    out = {}
    for k, v in a.items():
        if k[0]:
            out[(k[0]-1,) + k[1:]] = v*k[0]
    return out


def matching(d, start, degree=None):
    out = {}
    if degree is None:
        degree = d if start == 1 else d-1
    for count in range(degree//2+1):
        for chosen in combinations(range(start, d), count):
            if any(y == x+1 for x, y in zip(chosen, chosen[1:])):
                continue
            ex = [0]*d
            ex[0] = degree-2*count
            for j in chosen:
                ex[j] = 1
            out[tuple(ex)] = (-1)**count
    return out


def specialize_edges(a):
    # a_j/t -> -j at X=tau*Z. After its homogeneous t grade
    # is removed, this is an ordinary integer Z polynomial.
    c = {}
    for ex, v in a.items():
        for j in range(1, len(ex)):
            v *= (-j)**ex[j]
        c[ex[0]] = c.get(ex[0], 0) + v
    return {k:v for k,v in c.items() if v}


def dense(sparse):
    return [sparse.get(k, 0) for k in range(max(sparse, default=0)+1)]


def trim(a):
    while len(a)>1 and a[-1] == 0:
        a.pop()
    return a


def padd(a, b, k=1, p=None):
    c = [0]*max(len(a), len(b))
    for j, v in enumerate(a): c[j] += v
    for j, v in enumerate(b): c[j] += k*v
    if p: c = [v % p for v in c]
    return trim(c)


def pmul(a, b):
    c = [0]*(len(a)+len(b)-1)
    for j,v in enumerate(a):
        for k,w in enumerate(b): c[j+k] += v*w
    return trim(c)


def pdiff(a):
    return trim([j*a[j] for j in range(1,len(a))] or [0])


def pgcd(a, b, p):
    a = trim([x%p for x in a]); b = trim([x%p for x in b])
    while b != [0]:
        while len(a)>=len(b) and a != [0]:
            v = a[-1]*pow(b[-1], -1, p)%p
            shift = len(a)-len(b)
            for j,x in enumerate(b): a[j+shift]=(a[j+shift]-v*x)%p
            trim(a)
        a,b=b,a
    return [x*pow(a[-1], -1, p)%p for x in a]


def hermites(n):
    a = [[1], [0,1]]
    for j in range(1,n): a.append(padd([0]+a[-1],a[-2],j))
    return a[:n+1]


def primes(n):
    return [p for p in range(3,n+1,2) if all(p%d for d in range(2,int(p**.5)+1))]


def tail_controls():
    out=[]; mutants=0
    for d in range(2,15,2):
        z = (0,)*d
        X = {(1,)+(0,)*(d-1):1}
        T0,T1,U0,U1={z:1},X,{}, {z:1}
        for j in range(1,d):
            ex=[0]*d; ex[j]=1; edge={tuple(ex):1}
            T0,T1=T1,add(mul(X,T1),mul(edge,T0),-1)
            U0,U1=U1,add(mul(X,U1),mul(edge,U0),-1)
        T,U=T1,U1
        need(T==matching(d,1),f'T matching d={d}')
        need(U==matching(d,2),f'U matching d={d}')
        for ex in T:
            need(ex[0]%2==0 and ex[0]+2*sum(ex[1:])==d,'T parity/grade')
        for ex in U:
            need(ex[0]%2==1 and ex[0]+2*sum(ex[1:])==d-1,'U parity/grade')
        W=add(mul(deriv(U),T),mul(U,deriv(T)),-1)
        need(all(ex[0]%2==0 and ex[0]+2*sum(ex[1:])==2*d-2 for ex in W),'W grade')
        # Expand S=T*F'-T'*F in the independent labels A,A',M,M'.
        S_A=add(mul(T,deriv(T)),mul(deriv(T),T),-1)
        S_Ap=mul(T,T)
        S_M=add(mul(T,deriv(U)),mul(deriv(T),U),-1)
        S_Mp=mul(T,U)
        need(not S_A and S_Ap==mul(T,T) and S_M==W and S_Mp==mul(T,U),'full witness')
        need(bool(W) and bool(S_Mp),'omitted-correction mutants must differ')
        need(S_Ap!=T,'unsquared-T mutant')
        mutants += 3
        m=d//2; H=hermites(d)
        t,u,w=map(specialize_edges,(T,U,W))
        need(dense(t)==H[d], 'T low Hermite')
        V0,V1=[0],[1]
        for j in range(1,d): V0,V1=V1,padd([0]+V1,V0,j)
        need(dense(u)==V1,'associated U recurrence')
        c=H[d][0]; b=V1[1]
        need(w.get(0)==c*b,'W leading coefficient')
        # For x>=1, minimal monomial weights occur at the constant/linear
        # endpoint. The slope in x is nonnegative, so checking x=1 proves
        # the lower inequality for every x>=1 for each symbolic monomial.
        need(min(ex[0]+sum(ex[1:]) for ex in T)==m,'T bound')
        need(min(ex[0]+sum(ex[1:]) for ex in U)>=m,'U bound')
        need(min(ex[0]+sum(ex[1:]) for ex in W)>=2*m-1,'W bound')
        need(min(ex[0]+sum(ex[1:]) for ex in deriv(U))>=m-1,'U prime bound')
        need(min(ex[0]+sum(ex[1:]) for ex in deriv(T))>=m,'T prime bound')
        out.append({'d':d,'T_terms':len(T),'U_terms':len(U),'W_terms':len(W),'c_m':c,'b_m':b})
    # Preserve the degree while changing only the associated edge start.
    need(matching(4,1,3)!=matching(4,2),'wrong-U-edge mutant'); mutants+=1
    return {'rows':out,'negative_controls_rejected':mutants}


def low_controls():
    H=hermites(100)
    count=0; cancellations=[]
    V=[[0],[1]]
    for j in range(1,100): V.append(padd([0]+V[-1],V[-2],j))
    b=0; double=1
    for m in range(1,51):
        if m>1: double*=2*m-2
        b=double+(2*m-1)*b
        need(V[2*m][1]==b,'b recurrence')
    for p in primes(101):
        for d in range(2,p,2):
            need(H[d][0]%p!=0 and pgcd(H[d],pdiff(H[d]),p)==[1], 'low gcd/constant')
            need(H[d][-1]==1 and pdiff(H[d])==[d*x for x in H[d-1]],'Hermite derivative')
            count+=1
            if V[d][1]%p==0: cancellations.append([p,d])
    need([11,6] in cancellations and [31,8] in cancellations and [5,4] in cancellations,'known cancellations')
    rows=[]
    for p,r in [(3,2),(3,3),(5,2),(5,3),(7,2),(11,2),(13,2),(17,2),(19,2)]:
        N=p**r; top=2*N+p-1
        q0,q1,rr0,rr1=[1],[0,1],[0],[1]
        for j in range(1,top):
            q2=padd([0]+q1,q0,j,p)
            rr2=padd(padd(q1,[0]+rr1,p=p),rr0,j,p)
            q0,q1,rr0,rr1=q1,q2,rr1,rr2
            d=j+1-2*N
            if d>=2 and d%2==0:
                need(q1==[0]*(2*N)+[x%p for x in H[d]],'low original recurrence')
                expected=trim([0]*(2*N)+[d*x%p for x in H[d-1]])
                need(rr1==expected,'separate original derivative recurrence')
                need(rr1!=[0],'drop-low-derivative mutant')
        rows.append({'p':p,'r':r,'n_max':top,'even_tails':(p-1)//2})
    return {'gcd_pairs':count,'b_recurrence_through_m':50,'auxiliary_cancellations_through_p101':cancellations,'original_rows':rows}


def coordinate_controls():
    # Laurent-polynomial evaluation of the exact P/H identity at rational q.
    def la(a,b,k=1):
        c=dict(a)
        for j,v in b.items(): c[j]=c.get(j,0)+k*v
        return {j:v for j,v in c.items() if v}
    def lm(a,b):
        c={}
        for j,v in a.items():
            for k,w in b.items(): c[j+k]=c.get(j+k,0)+v*w
        return {j:v for j,v in c.items() if v}
    q=Fraction(2,3); P=[[1],[0,1]]; H=[[1],[1,1]]
    for j in range(1,12):
        P.append(padd([0]+P[-1],P[-2],-(1-q**j)))
        prev=H[-1]; n=j+1
        H.append([ (prev[k] if k<len(prev) else 0)+(q**(n-k)*prev[k-1] if k else 0) for k in range(n+1)])
    powers=[{0:Fraction(1)}]; X={-1:Fraction(1),1:Fraction(1)}
    for n in range(1,13):powers.append(lm(powers[-1],X))
    cd=[0]; w=Fraction(1)
    for n in range(1,13):
        lp={}
        for j,c in enumerate(P[n]):lp=la(lp,{k+n:v*c for k,v in powers[j].items()})
        need(lp=={2*j:v for j,v in enumerate(H[n]) if v}, 'original H/P')
        # Differentiate identity in Laurent v, retaining n*P prefactor.
        lhs={k-1:k*v for k,v in lp.items() if k}
        rhs={}
        base={}
        for j,c in enumerate(P[n]):base=la(base,{k+n-1:n*v*c for k,v in powers[j].items()})
        dx={0:1,-2:-1}
        dp={}
        for j,c in enumerate(pdiff(P[n])):dp=la(dp,{k+n:v*c for k,v in powers[j].items()})
        rhs=la(base,lm(dp,dx))
        need(lhs==rhs,'ordinary H/P prefactor derivative')
        cd=padd(cd,[x/w for x in pmul(P[n-1],P[n-1])])
        wr=padd(pmul(pdiff(P[n]),P[n-1]),pmul(P[n],pdiff(P[n-1])),-1)
        need(cd==[x/w for x in wr],'full original algebraic-square CD')
        w*=1-q**n
    return {'q':'2/3','degrees':list(range(1,13)),'identities':['H/P','ordinary derivative including prefactor','full algebraic-square CD']}


def main():
    result={'schema':'independent-uniform-even-tail-checks-v1','tail':tail_controls(),'low':low_controls(),'coordinate':coordinate_controls(),'uniform_proof_is_REPORT_not_finite_controls':True,'author_or_predecessor_programs_executed':False}
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__': main()
