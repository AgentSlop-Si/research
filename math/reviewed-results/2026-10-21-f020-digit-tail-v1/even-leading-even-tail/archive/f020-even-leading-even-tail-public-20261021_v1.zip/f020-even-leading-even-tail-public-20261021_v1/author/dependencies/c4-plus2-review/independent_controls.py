#!/usr/bin/env python3
"""Independent exact controls for n=4*p^r+2, not a proof by finite tests.
No candidate or predecessor module is imported or executed.
"""
import argparse,hashlib,json,math,time
from fractions import Fraction as F
from pathlib import Path

def need(x,label):
    if not x: raise RuntimeError(label)

def prime(p):
    return p>=2 and all(p%d for d in range(2,math.isqrt(p)+1))

def hermite_mod(n,p):
    a=[1];b=[0,1]
    if n==0:return a
    for j in range(1,n):
        c=[0]+b
        for k,v in enumerate(a):c[k]=(c[k]+j*v)%p
        a,b=b,c
    return b

def residue_control():
    rows=[]
    for p in [5,7,11,13,17,19]:
        for r in [2,3,4]:
            N=p**r;n=4*N+2
            # Avoid high-degree formal tests when formula proves the same pattern.
            if n>6000: continue
            v=hermite_mod(n,p)
            expected={4*N:1,4*N+2:1}
            need({k:x for k,x in enumerate(v) if x}==expected,'low residue')
            dv={k-1:k*x%p for k,x in enumerate(v) if k and k*x%p}
            need(dv=={4*N+1:2},'low ordinary derivative residue')
            rows.append({'p':p,'r':r,'n':n,'nonzero_residue_degree':2,'low_derivative_initial':'+2Z'})
    return rows

class Ring:
    def __init__(self,p,r,s):
        self.p,self.r,self.s=p,r,s;self.N=p**r;self.qorder=p**s;self.e=(p-1)*p**(s-1)
        self.B=r*(p-1)*p**(r-1)//2
        self.K=2*self.N+4*self.B;self.E=F(3*self.N,2)+4*self.B;self.D=F(5*self.N,2)+4*self.B-p
        self.h=int((self.D+3)//self.e)+1;self.mod=p**self.h
        self.zero=[0]*self.qorder;self.one=[1]+[0]*(self.qorder-1)
        self.convert_cache={}
    def add(self,a,b):return [(x+y)%self.mod for x,y in zip(a,b)]
    def scale(self,a,k):return [k*x%self.mod for x in a]
    def edge(self,a,j):
        d=j%self.qorder;m=self.mod
        return [(a[k]-a[(k-d)%self.qorder])%m for k in range(self.qorder)]
    def value_unit(self,a):
        key=tuple(a)
        if key in self.convert_cache:return self.convert_cache[key]
        L=self.qorder//self.p;e=self.e;m=self.mod
        # q^(e+j)=-sum_(u=0)^(p-2)q^(uL+j)
        z=[(a[k]-a[e+k%L])%m for k in range(e)]
        t=[0]*e
        for i,c in enumerate(z):
            if c:
                comb=1
                for k in range(i+1):
                    t[k]=(t[k]+c*comb)%m
                    comb=comb*(i-k)//(k+1) if k<i else 1
        best=None;unit=None
        for j,c in enumerate(t):
            if c:
                o=0
                while c%self.p==0:o+=1;c//=self.p
                value=j+self.e*o
                if best is None or value<best:best=value;unit=c*(-1 if o%2 else 1)%self.p
        ans=(best,unit);self.convert_cache[key]=ans;return ans
    def original(self,n):
        prev={0:self.one};cur={1:self.one};keep={0:prev,1:cur}
        targets={4*self.N-1,4*self.N,4*self.N+1,n}
        for j in range(1,n):
            nxt={k+1:v[:] for k,v in cur.items()}
            for k,v in prev.items():nxt[k]=self.add(nxt.get(k,self.zero),self.scale(self.edge(v,j),-1))
            prev,cur=cur,nxt
            if j+1 in targets:keep[j+1]=cur
        return keep
    def poly_add(self,a,b):
        out={k:v[:] for k,v in a.items()}
        for k,v in b.items():out[k]=self.add(out.get(k,self.zero),v)
        return out
    def x(self,a,d=1):return {k+d:v for k,v in a.items()}
    def d(self,a):return {k-1:self.scale(v,k) for k,v in a.items() if k}
    def poly_edge(self,a,j,sign=1):return {k:self.scale(self.edge(v,j),sign) for k,v in a.items()}
    def T(self,a):return self.poly_add(self.x(a,2),self.poly_edge(a,4*self.N+1,-1))
    def initial(self,a,rho):
        best=None;terms={};pairs=[]
        for k,v in a.items():
            w,u=self.value_unit(v)
            if w is None:continue
            g=F(w)+rho*k;pairs.append([k,w,u,str(g)])
            if best is None or g<best:best=g;terms={k:u}
            elif g==best:terms[k]=u
        return best,terms,pairs

def cyclotomic_case(p,r,s):
    start=time.monotonic();R=Ring(p,r,s);N=R.N;n=4*N+2;data=R.original(n)
    A,M,G=data[4*N],data[4*N-1],data[n]
    exact=R.poly_add(R.T(A),R.poly_edge(R.x(M),4*N,-1))
    need(exact==G,'original +2 transfer identity')
    S=R.poly_add(R.T(R.d(G)),{k:R.scale(v,-2) for k,v in R.x(G).items()})
    terms=R.poly_add(R.T(R.T(R.d(A))),R.poly_edge(R.poly_add(R.x(M,2),R.poly_edge(M,4*N+1)),4*N))
    terms=R.poly_add(terms,R.poly_edge(R.T(R.x(R.d(M))),4*N,-1))
    need(S==terms,'fraction-free full witness identity')
    rho=F(p,2) # These exact central controls deliberately use r=2.
    wa,ia,_=R.initial(A,rho);wg,ig,_=R.initial(G,rho);ws,isu,spairs=R.initial(S,rho)
    wraw,iraw,_=R.initial(R.d(G),rho)
    eps=(-1)**((p-1)//2)
    need(wa==R.K and ia=={0:3%p,2*p:6%p,4*p:1},'c4 central A initial')
    need(wg==R.K+1 and ig==ia,'new F central initial')
    expect={p:-12*eps%p,3*p:-4*eps%p}
    need(ws==R.D+2 and isu==expect,'new S central derivative sum')
    need(wraw<R.D+1,'earlier raw whole-disk derivative control')
    wm,im,_=R.initial(M,rho);wmp,imp,_=R.initial(R.d(M),rho)
    need(wm==R.E and im=={p:3*eps%p,3*p:eps%p},'neighbor both terms')
    need(wmp>=R.E,'neighbor ordinary derivative bound')
    return {'p':p,'r':r,'s':s,'n':n,'ring':'(Z/p^h)[q]/(q^(p^s)-1), reduced to canonical cyclotomic basis at inspection','precision_h':R.h,'precision_cutoff':R.h*R.e,'ramification_e':R.e,'K':str(R.K),'E':str(R.E),'D':str(R.D),'F_weight':str(wg),'F_initial':ig,'S_weight':str(ws),'S_initial':isu,'raw_F_derivative_weight':str(wraw),'M_derivative_weight':str(wmp),'both_derivative_pivots_retained':True,'rootwise_F_derivative_value':str(R.D+1),'elapsed_seconds':round(time.monotonic()-start,6)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    result={'status':'PASS','finite_controls_not_uniform_proof':True,'supplied_modules_executed':False,'low_residue_controls':residue_control(),'cyclotomic_new_target_controls':[cyclotomic_case(*x) for x in [(5,2,3),(5,2,4),(7,2,3)]]}
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','cases':len(result['cyclotomic_new_target_controls'])}))
if __name__=='__main__':main()
