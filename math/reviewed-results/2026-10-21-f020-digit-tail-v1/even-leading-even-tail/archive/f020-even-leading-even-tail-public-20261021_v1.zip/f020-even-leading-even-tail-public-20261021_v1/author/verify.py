#!/usr/bin/env python3
"""Read-only exact inventories and NEW controls; no dependency code is executed."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys

PINS={
 'general-author':'e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7',
 'general-review':'a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7',
 'c2-even-author':'c7b391df43fc8fb0fb14fab06ddd1d4e722d791469fc2593017ef27d8d9a88d3',
 'c2-even-review':'419d478b906e68600983a1b209ed53e0f05c532875d409398ee7ae9e168cb012',
 'c4-plus2-author':'07682f06811d03a7df5cfdf966b885c206af0fc30b2414b8609b89eafe28a653',
 'c4-plus2-review':'940a49a2c461813aea78c76a410b8615efc16ab21f4b7d7e1aa2578cc7e0382b'}


def need(c,msg):
    if not c:raise RuntimeError(msg)


def sha(data):return hashlib.sha256(data).hexdigest()
def readjson(path):return json.loads(path.read_text())


def inventory(root,pin=None):
    need(not root.is_symlink(),'symlink root: '+str(root))
    allpaths=list(root.rglob('*'))
    need(not any(p.is_symlink() for p in allpaths),'symlink entry')
    manifest=root/'MANIFEST.json'; raw=manifest.read_bytes();digest=sha(raw)
    if pin:need(digest==pin,'external manifest pin mismatch: '+root.name)
    data=json.loads(raw); rows=data['files']; expected={'MANIFEST.json','SEAL.json'}
    need(isinstance(rows,list),'manifest list required')
    for row in rows:
        name=row['path']; pp=PurePosixPath(name)
        need(isinstance(name,str) and not pp.is_absolute() and '..' not in pp.parts and str(pp)==name,'unsafe path')
        need(name not in expected,'duplicate or self-bound entry')
        expected.add(name)
        path=root/name
        need(path.is_file(),'missing bound file: '+str(path))
        blob=path.read_bytes()
        need(len(blob)==row['bytes'],'size mismatch: '+name)
        need(sha(blob)==row['sha256'],'hash mismatch: '+name)
    got={p.relative_to(root).as_posix() for p in allpaths if p.is_file()}
    need(got==expected,'file inventory mismatch: '+root.name+' '+str(sorted(got^expected)))
    seal=readjson(root/'SEAL.json')
    need(seal['manifest_sha256']==digest,'seal mismatch')
    if 'directories' in data:
        dirs={p.relative_to(root).as_posix() for p in allpaths if p.is_dir()}
        need(dirs==set(data['directories']),'directory inventory mismatch')
    return {'manifest_sha256':digest,'bound_files':len(rows),'files_with_manifest_and_seal':len(expected)}


def sources(root):
    bindings=readjson(root/'SOURCE_BINDINGS.json')
    rows=bindings['sources']
    need({x['name'] for x in rows}==set(PINS),'source name mismatch')
    result={}
    for row in rows:
        name=row['name']
        need(row['copy']=='dependencies/'+name,'source copy mismatch')
        need(row['manifest_sha256']==PINS[name],'binding pin mismatch')
        result[name]=inventory(root/row['copy'],PINS[name])
    for name,key,author in [('general-review','author_manifest_sha256','general-author'),
                            ('c2-even-review','candidate_manifest_sha256','c2-even-author'),
                            ('c4-plus2-review','author_manifest_sha256','c4-plus2-author')]:
        v=readjson(root/'dependencies'/name/'VERDICT.json')
        need(v['verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE','nonaccepting source verdict')
        need(v[key]==PINS[author],'review/author manifest binding mismatch')
        reportsha=sha((root/'dependencies'/author/'REPORT.md').read_bytes())
        for reportkey in ('candidate_report_sha256','author_report_sha256'):
            if reportkey in v:need(v[reportkey]==reportsha,'review/report binding mismatch')
    need(sha((root/'dependencies/general-author/REPORT.md').read_bytes())=='639b35b0b603fccc44a57c1f5321fc7efc5c9007510b0cd12d714eefc0d5820c','general report')
    need(sha((root/'dependencies/general-review/INDEPENDENT_REVIEW.md').read_bytes())=='67dc7c923f4e0ace97b9246c9303a2fa3633eeaadea850449a22a9f62c0355f0','general review report')
    return {'status':'PASS','inventories':result,'all_three_accepting_bindings':'PASS','source_programs_executed':False}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--expect-manifest')
    ap.add_argument('--sources-only',action='store_true')
    ap.add_argument('--replay',action='store_true')
    args=ap.parse_args(); root=args.root
    result={'sources':sources(root)}
    if not args.sources_only:
        need(bool(args.expect_manifest),'provide the independently supplied --expect-manifest pin')
        result['candidate']=inventory(root,args.expect_manifest)
    if args.replay:
        need(not args.sources_only,'freeze verification required before replay')
        expected=(root/'CONTROL_RESULTS.json').read_bytes()
        replay=[]
        for flags in ([],['-O']):
            proc=subprocess.run([sys.executable,*flags,'-B',str(root/'check_controls.py')],
                capture_output=True,timeout=60,check=False)
            need(proc.returncode==0,'new control replay failed: '+proc.stderr.decode())
            need(proc.stdout==expected,'new control replay bytes differ')
            replay.append({'optimized':bool(flags),'result_sha256':sha(proc.stdout),'byte_exact':True})
        result['new_control_replays']=replay
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':main()
