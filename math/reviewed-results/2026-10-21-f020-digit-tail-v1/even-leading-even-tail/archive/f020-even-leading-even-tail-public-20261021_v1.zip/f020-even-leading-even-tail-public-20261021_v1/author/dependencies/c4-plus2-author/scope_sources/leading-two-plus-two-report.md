# The first even tail after a leading two

Author candidate, 21 October 2026 UTC. This is a bounded-family proof in the ORIGINAL F020 normalization, awaiting independent review. It is not acceptance, arbitrary-degree closure, a historical novelty claim, or an FFT/cost claim.

## 1. Exact theorem

Let p be any odd prime, r>=2, s>r, N=p^r, n=2N+2, and let q have exact characteristic-zero order p^s. Retain exactly

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_j(z)=sum_a [j choose a]_q z^a.

In an algebraic p-adic embedding put t=q-1 and normalize v(t)=1. Write

    e=v(p)=(p-1)p^(s-1), B=r(p-1)p^(r-1)/2,
    K=N+2B, E=N/2+2B, D=3N/2+2B-p=N+E-p,
    h=floor(r/2), beta=p^h, L=N/beta,
    rho=beta/2 if r is even,
    rho=p^(h-1)(2p-1)/2 if r is odd.

Then every root of original P_n is simple. The complete root partition and ORIGINAL ordinary derivative valuations are:

1. Two low roots with v(X)=1/2. If tau^2=t and X=tau Z, their residues are the two roots Z^2=-1, and

       v(P_n'(X))=N+1/2,
       P_n'(X)/tau^(2N+1) -> 2 Z^(2N+1)=-2Z !=0.

2. Exactly 2L high roots on the boundary of EACH of the beta disjoint disks

       v(X-x_a)>=rho,
       x_a=i(q^(a/2)-q^(-a/2)), 0<=a<beta,

   with square roots near 1 and i^2=-1. All these 2N roots satisfy

       v(P_n'(X))=D+1.

   Their values are v(X)=rho centrally and p^ord_p(a) otherwise. The root counts retain multiplicity until the derivative proof. The central roots at p=3 are included without a special deeper lift.

There is no root at zero: v(P_n(0))=K+1. Original H_n has the same root multiplicities and ordinary derivative valuations under its exact coordinate correspondence. The original algebraic-square Christoffel-Darboux kernel is nonzero at every P_n root. These assertions hold for every s>r and every primitive phase.

No assertion here covers even tails d>=4, odd tails by this new proof, other leading digits, r=1, p=2, s<=r, composite orders, arbitrary n, or global F020/F023 closure.

## 2. Accepted coefficientwise source, not an odd-parity extrapolation

The complete frozen general-author and general-review packages are retained under dependencies. Their manifest SHA-256 values are respectively

    e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7
    a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7.

The review accepts the precise general leading-digit coefficientwise proof and is bound to those author bytes. We use its Sections 2-5, specialized to c=2, not its theorem's adjacent-degree conclusion. The source proves these inputs uniformly for all odd p, INCLUDING p=3, r>=2, s>r. Put

    A=P_(2N), M=P_(2N-1), a=1-q^(2N), b=1-q^(2N+1).

On each stated high disk, coefficientwise Gauss weight gives:

    weight(A)=K, residual(A) is a unit times M_2(Zbar)=Zbar^2+1,
    weight(M)=E, residual(M) is a nonzero scalar times Zbar,
    weight(A')=D, residual(A') is a nonzero scalar times Zbar,
    weight(M')>=E,
    Zbar=alpha_a Y^L, alpha_a!=0, X=x_a+lambda Y, v(lambda)=rho.

The residual root locus Zbar^2+1=0 has Zbar!=0. Consequently M and A' have EXACT values E and D at every point of that locus, not only at roots of an earlier polynomial. The derivative estimates concern original ordinary characteristic-zero derivatives, obtained before reduction. They do not differentiate an inseparable residual.

For reference, the exact Newton identities behind the accepted input are

    w_j=product_(u=1)^j(1-q^u), Q_j=product_(u=1)^j(1-q^(2u)),
    N_j(z)=product_(u=0)^(j-1)(z+q^u),
    H_b=sum_(k=b mod 2) w_b N_k/[w_k Q_((b-k)/2)],
    H_b'=sum_(k=b mod 2,k>=1) sum_(0<=u<k)
       w_b z^(k-u-1)N_u/[Q_((b-k)/2)w_u(1-q^(k-u))].

The source's cap R(j)<=W(j)/2, with W(j)=sum_(u=1)^j p^ord_p(u), has equality only at multiples of N on the required range. Its full ordinary derivative score has its unique maximum at k-u=p^2. For c=2 the unique equality pivot has u=N, k=N+p^2. Thus the nonzero A' residual is valid even for p=3. The source separately bounds EVERY M' term. None of the odd-tail scalar jets, root-depth improvements, or cancellation corrections is needed here.

## 3. Exact even-tail transfer and root geometry

Two steps of the ORIGINAL recurrence give the identity

    F:=P_(2N+2)=T A-a X M, T=X^2-b.                    (3.1)

The growth check is explicit:

    2N+2<pN<=p^s,

because (p-2)N>=9>2. Thus every recurrence edge and every q-factorial denominator used is nonzero. Since 2<p and 2N+1 is a p-unit,

    v(a)=N, a/t^N -> -2,
    v(b)=1, b/t -> -1.

Every entire high disk has Gauss weight of X equal to x>=1: x=rho centrally, x=p^ord_p(a) noncentrally. Hence X^2/t has positive weight, and

    T/t -> 1, weight(T)=1.

In particular T is an analytic unit after scaling by t on each full high disk and has no zero there. The exact perturbation in (3.1) has weight at least

    N+E+x = K+N/2+x > K+1,

since N/2+x-1>0. Thus F has weight K+1 and the same residual root polynomial as A, up to a nonzero scalar. It has degree 2L in the scaled disk variable and nonzero constant, with every higher-degree coefficient of strictly greater normalized weight. Closed-disk Newton/Weierstrass counting therefore gives exactly 2L roots counted with multiplicity in each disk, all on its boundary. This is not simple-root Hensel applied to Zbar^2+1 after the inseparable substitution Y^L.

The centers are mutually separated at distance valuation at most p^(h-1)<rho, so these beta disks are disjoint. Their counts sum to 2N. At each new high root, the residual locus is Zbar^2+1=0, and the exact M,A' values from Section 2 therefore apply. This is the required new-root feedback; there is no need to assert a deeper central root displacement.

At X=0, F(0)=-b A(0). The accepted central constant initial is a unit, so v(A(0))=K and v(F(0))=K+1. Equivalently the exact even-degree constant product is nonzero. The odd-tail exact-zero factor is ABSENT.

## 4. Full original derivative, with a fraction-free root witness

It is useful first to keep the whole analytic transfer J=F/T=A-aRM, where R=X/T. Exact differentiation yields

    R'=(T-2X^2)/T^2=-(X^2+b)/T^2,
    J'=A'-aR'M-aRM'.                                  (4.1)

At every high root, v(R)=x-1 and v(R')=-1, since v(X^2)>v(b)=1. The three terms of J' have respectively

    D, N+E-1, >=N+E+x-1.

Since D=N+E-p, the latter two exceed D by p-1 and at least p+x-1. These are positive for EVERY odd p, including p=3. Hence v(J')=D exactly. At a root J=0, F'=T J', giving v(F')=D+1.

For a polynomial-only verification that retains ALL terms, eliminate the derivative of the tail factor by defining the exact witness

    S=T F'-2X F
      =T^2 A'+a(X^2+b)M-aTXM'.                        (4.2)

Its three terms have values at any new high root

    D+2, N+E+1, >=N+E+x+1.

The first is uniquely minimal with the same gaps p-1 and p+x-1. Thus v(S)=D+2; at a root F=0, S=T F', so again v(F')=D+1. This form avoids any division in the computational controls.

The cancellation mechanism of the odd tail does NOT extend. There the correction containing M/X^2 can tie A'. Here R' has fixed value -1 on every high disk, rather than -2x, leaving a uniform p-1 gap. In particular the prior central p=3 odd-tail difficulty is not inherited.

IMPORTANT: no whole-disk bound v(F')>=D+1 is asserted. F'=T'J+TJ' contains a T'J term away from the root locus, which can occur earlier. Only S, J', and the rootwise F' statement have the indicated bounds. This distinction is retained by the controls.

At r=2, let mu^2=t^p, X=mu Y, epsilon=(-1)^((p-1)/2). The accepted central residuals are

    A/t^K -> (Y^2+1)^p,
    A'/(t^(3B)mu^p) -> -2 epsilon Y^p.

Hence at each new central root Y^2=-1 residually,

    P_n'/(t^(3B+1)mu^p) -> -2 epsilon Y^p !=0.

The normalization has value D+1. This is an original root derivative unit, and it remains nonzero at p=3.

## 5. Exactly two simple low roots

Set tau^2=t and evolve the scaled original recurrence and its separately differentiated characteristic-zero recurrence:

    Q_j(Z)=tau^(-j)P_j(tau Z),
    V_j(Z)=tau^(1-j)P_j'(tau Z),
    Q_(j+1)=ZQ_j-[(1-q^j)/t]Q_(j-1),
    V_(j+1)=Q_j+ZV_j-[(1-q^j)/t]V_(j-1),
    Q_0=1, Q_1=Z, V_0=0, V_1=1.

They are integral coefficientwise. Since -(1-q^j)/t reduces to j modulo p, including zero when p|j, their reductions are the integer Hermite recurrence M_(j+1)=ZM_j+jM_(j-1) and its actual derivative recurrence.

The elementary integer coefficient formula

    M_j=j! sum_k Z^(j-2k)/[2^k k!(j-2k)!]

gives M_p=Z^p modulo p. Starting at each multiple of p and using the recurrence proves M_(ap+b)=Z^(ap)M_b for 0<=b<p. In particular, because 2<p,

    Q_n -> Z^(2N)(Z^2+1),
    V_n -> 2Z^(2N+1).

The latter is justified by the original differentiated recurrence, not used to infer anything about the high zero residual. Each of the two nonzero roots Z^2=-1 is simple since p is odd and 2Z!=0. Hensel lifting gives one simple low root per residual class, with v(X)=1/2 and the valuation and unit in Section 1. These roots lie outside all high disks.

The total degree is exhausted:

    2 + beta*(2L) = 2+2N = n.

There are no missing clusters, no unresolved central branches, and no exact zero.

## 6. Original H, algebraic-square kernel, and all phases

The unchanged coordinate identities are

    H_n(v0^2)=v0^n P_n(X), X=v0+v0^(-1),
    H_n'(z)=v0^(n-2)[(n/2)P_n+(v0-v0^(-1))P_n'/2].

All P roots are small and not +/-2, and all H roots are near -1 and nonzero. The branch v0 near i gives an analytic isometry covering the roots with multiplicity; its coordinate derivatives are units for every odd p. At a root the prefactor contribution proportional to P_n vanishes EXACTLY. Thus H root derivative values equal P root derivative values. The multiplier has residue i^(n-1)=-i, since N is odd. No equality of normalized H/P units is silently assumed.

All recurrence edges 1-q^j for 1<=j<n are nonzero. If P_n and P_(n-1) had a common root, backwards propagation through the exact recurrence would give a root of P_0=1, impossible. At any P_n root xi, the ORIGINAL identity is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
       =P_n'(xi)P_(n-1)(xi)/w_(n-1) !=0.

The squares are algebraic squares, NOT absolute-value squares. No Hermitian positivity, real interlacing, or replacement polynomial is used.

Every invoked coefficientwise source lemma includes the original mixed-characteristic lattice and e=(p-1)p^(s-1), uniformly for s>r. The new transfer uses exact integral identities, unit comparisons, and strict inequalities only; it discards no p-divisible coefficient and introduces no finite-precision lift that could fail at the minimal s. The controls retain p-divisibility and p/t^e=-1 explicitly but do not replace the uniform proof. For any primitive phase choose an algebraic p-adic embedding; the same t-normalized arguments apply. Injectivity and Galois conjugacy transfer nonvanishing to every characteristic-zero primitive phase.

## 7. Verification, resource accounting, and stopping point

The proof is Sections 2-6, not a finite search. check_controls.py uses only Python's standard library and verifies exact rational identities, the fraction-free witness, scaled recurrence/ordinary-derivative residues, selected complete Newton weight tables, and four bounded ORIGINAL cyclotomic recurrence cases. The latter compute the full original polynomial before extracting central coefficientwise initials. They preserve ordinary integer derivative multipliers, finite precision strictly beyond every inspected threshold, and the nonzero residue of p/t^e. The controls deliberately exhibit an earlier whole-disk F' term at p=3 rather than substituting its scalar or whole-disk value for the rootwise result.

The accepted dependencies are copied unchanged and checked against pinned manifests and their review binding. The candidate has a complete immutable inventory, cold replay, and negative mutation tests. A fresh independent reviewer must assess the exact bytes, all-root counts, p=3 boundary, polynomial witness and root substitution, original H/kernel transfer, and every all-phase premise. This candidate does not accept itself.

No algorithmic speedup is claimed. Computing all P_j coefficients by ordinary recurrence takes quadratic-many coefficient updates in n over the coefficient ring. The diagnostic cyclic-ring implementation stores O(n*p^s) residue entries and uses O(n^2*p^s) scalar residue updates, with O(n*e^2) schoolbook q-to-t conversion. It computes no transform and proves no FFT complexity assertion. Source inventory/replay and all tests are part of the actual local verification cost, not hidden preprocessing.

The exact completed mathematical target is n=2p^r+2, odd p>=3, r>=2, s>r. Scope inspection distinguishes it from the already accepted all-odd-tail sector and from r=1 two-digit work. This is a new scoped proof package relative to those retained predecessors, not a claim of historical novelty or global F020 completion. No external repository, native document, Library item, table, or accepted source is changed.
