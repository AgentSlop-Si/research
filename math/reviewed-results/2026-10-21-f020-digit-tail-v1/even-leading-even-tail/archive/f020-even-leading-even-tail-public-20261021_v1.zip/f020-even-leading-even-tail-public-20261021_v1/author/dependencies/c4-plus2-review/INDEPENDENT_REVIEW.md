# Independent review: leading four with tail two

## Status

ACCEPTED WITHIN THE EXACT STATED SCOPE. The frozen author manifest SHA-256 is 07682f06811d03a7df5cfdf966b885c206af0fc30b2414b8609b89eafe28a653; its REPORT.md SHA-256 is 5875c7d6ffb3986e676a28fb75c25b8fb988bfc9e49e9d48f2b030eaf3ea043f. All 53 inventory-bound files, the manifest and seal were verified, with no unlisted files, directories or symlinks. This acceptance binds those exact bytes. No essential mathematical repair was supplied by this reviewer and no author file was changed. Public packaging, external publication and delivery are separate gates, not actions or acceptances implied here.

## Precisely reviewed theorem

The degree is n=4p^r+2, with p prime, p>=5, r>=2, s>r and q any characteristic-zero primitive p^s-th root. The definitions remain

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_n(z)=sum_k [n choose k]_q z^k,
    w_j=product_(u=1)^j(1-q^u).

Let N=p^r, t=q-1 and v(t)=1. Put B=r(p-1)p^(r-1)/2, K=2N+4B, E=3N/2+4B and D=5N/2+4B-p. The claimed and reviewed outcome is:

- Two low roots, each simple, with v(X)=1/2 and ordinary derivative value 2N+1/2.
- Exactly 4L high roots, counted with multiplicity before the derivative argument, on the boundary of every one of the beta stated disks. Here h=floor(r/2), beta=p^h, L=N/beta, rho=beta/2 for even r and rho=p^(h-1)(2p-1)/2 for odd r. Their centers are i(q^(a/2)-q^(-a/2)), 0<=a<beta, with square roots near 1.
- Every high root has nonzero ordinary derivative of value D+1. Central roots have X-value rho; other high roots have X-value p^ord_p(a).
- There is no zero P root; v(P_n(0))=K+1.
- The original H polynomial has the corresponding multiplicities and derivative valuations. The original algebraic-square Christoffel-Darboux kernel is nonzero at every P root.

No arbitrary-degree, arbitrary-digit, global F020/F023, FFT, algorithmic improvement, or historical novelty conclusion is accepted. No statement about an unrelated auxiliary characteristic is licensed. The proof does not cover a new leading digit other than four, a tail other than two, p=3, r=1, s<=r, or composite orders.

## Source authority and scope exclusion

The mathematical source is the accepted general adjacent package's coefficientwise Sections 2–5, specialized directly at c=4. Its adjacent-degree squarefreeness conclusion is not used as a premise. The source author manifest is e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7; the accepting review manifest is a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7. The source author report is 639b35b0b603fccc44a57c1f5321fc7efc5c9007510b0cd12d714eefc0d5820c.

I independently checked all bytes, sizes, seals, and exact inventories: 13 bound author files plus manifest/seal, and 19 bound review files plus manifest/seal. The accepting verdict and source-binding record bind that exact author manifest and report. No accepted source program or accepted control was executed. The comparison archive c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe is provenance retained inside this checked author package, not a replacement for its coefficientwise proof.

The retained single-leading-digit family has zero tail, and adjacent families have tail one. Their residues modulo p exclude tail two. The leading-two sector has 2p^u+d with 0<=d<p. Equality with the new degree forces d=2 and 2p^u=4p^r, impossible for p>=5. Thus this target is outside those retained accepted scopes, even allowing the source exponent to vary. The predecessor leading-two even-tail argument supplies a transfer pattern, not c=4 input authority or new theorem credit.

## Uniform mathematical review

### 1. Exact coefficientwise inputs and both pivots

For A=P_(4N) and M=P_(4N-1), the accepted source supplies, on every complete disk, the weights K and E with root residual M_4(Z)=Z^4+6Z^2+3 and neighbor residual a nonzero scalar times 4M_3(Z), where M_3(Z)=Z^3+3Z and Z=alpha_a Y^L. It also supplies the original ordinary derivative A' at weight D with the full residual 4M_3, and the entire-polynomial lower bound wt(M')>=E. The H/P conversion preserves these coefficientwise bounds; the A-prefactor error has weight at least re+K>D, with e=(p-1)p^(s-1).

I checked the source derivation rather than inferring these statements from its final theorem. The derivative score has increment p^2, but that does not identify a single derivative term. The two equality pairs are (m,k)=(N,N+p^2) and (3N,3N+p^2). Their actual residues are 12Z and 4Z^3 under the common normalization, and must be summed. At r=2, the second pair has k=4N, including the p=5 prime boundary. The neighbor likewise has two equality terms. The source's separate M' proof checks every term, using the strict cap or N-level carry for its two apparent borderline increments; no c=2 bound is silently reused.

The resultant is Res(M_4,M_3)=108, a unit for every allowed p. Directly, M_3 vanishes at zero or Z^2=-3; M_4 there is respectively 3 or -6. Therefore both M and A' have exact values E and D on the M_4 residual root locus. Individual derivative summands can cancel elsewhere, but not on that locus. This is the exact input needed at the new roots, not merely at old roots.

### 2. Complete high clusters

Write a=1-q^(4N), b=1-q^(4N+1), and T=X^2-b. Two original recurrence steps give F=P_(4N+2)=TA-aXM. The strict bound n<pN<=p^s follows from pN-n=(p-4)N-2>=23, including p=5. Consequently all recurrence edges and denominators in the argument are nonzero. The edge values are v(a)=N and v(b)=1, with initial units -4 and -1.

The Gauss weight x of X on a high disk is rho centrally or p^ord_p(a) noncentrally, hence x>=1. Thus T/t has constant residual 1 and is an analytic unit throughout the disk. The perturbation has weight at least N+E+x=K+N/2+x>K+1. The F residual is therefore the A residual multiplied by a unit, with degree exactly 4L, nonzero constant, and every higher scaled coefficient strictly above the minimum.

The closed-disk Newton count yields 4L roots including multiplicity, all with nonzero scaled residue. Four distinct residual locations each have multiplicity L because M_4 is separable and L is a p-power. This is not a simple-root Hensel argument applied to an inseparable residual. Distinct centers have distance valuation at most p^(h-1)<rho, so the disk counts are disjoint and total 4N. These are roots of F, and their residual equation is precisely M_4=0, which supplies the exact neighbor and derivative values just established.

At zero, F(0)=-bA(0); the unit constant 3 of the A residual gives value K+1. There is no exact zero or quotient-root omission.

### 3. Full derivative transfer and uniform positive margin

On a full high disk put J=F/T=A-aRM, R=X/T. Exact differentiation gives R'=-(X^2+b)/T^2 and J'=A'-aR'M-aRM'. At a new high root, R and R' have values x-1 and -1. The three derivative terms consequently have values D, N+E-1 and at least N+E+x-1. Since D=N+E-p, the correction gaps are p-1 and at least p+x-1. They are strictly positive at every central and noncentral root, including p=5, where the first gap is four.

The fraction-free identity independently confirms every sign and term:

    S=T F'-2X F=T^2 A'+a(X^2+b)M-aTXM'.

At a new high root its term values are D+2, N+E+1 and at least N+E+x+1. The same strict gaps prove v(S)=D+2, and S=TF' at the root yields v(F')=D+1.

The root equation is essential. The whole-disk F' can have an earlier 2XF/T contribution, so the proof properly does not assign its whole-disk weight D+1. This distinction is exhibited by the independent actual cyclotomic controls. No central-depth improvement, no evaluation at a surrogate scalar, and no +1 cancellation lemma is needed. The +1 correction depends on X^(-2); the present derivative correction has fixed value -1, explaining the different behavior.

### 4. The central boundary p=5

At r=2 let mu^2=t^p and epsilon=(-1)^((p-1)/2). The exact source normalizations give A/t^K -> M_4(Y^p), M/(t^(4B)mu^(3p)) -> epsilon M_3(Y^p), and A'/(t^(5B)mu^(3p)) -> -4epsilon M_3(Y^p). The S initial is the last polynomial under its additional factor t^2. The rootwise F' initial under t^(5B+1)mu^(3p) is therefore -4epsilon(Y^(3p)+3Y^p), nonzero on the root residual.

For p=5 the actual root initial is Y^20+Y^10+3 and the derivative/witness initial is Y^15+3Y^5. Their coprimality follows from the uniform Hermite argument, not a sampled gcd. K=130, E=235/2, D=275/2, the high derivative value is 277/2, and the low derivative value is 101/2. The five disks contribute twenty roots apiece, and the central residual classes each account for five roots. Mixed characteristic matters here: at s=3, e=100 is below several tested weights. The original ordinary derivative is retained before valuation.

### 5. Two low roots and exhaustion

The scaled original recurrences for Q_j=tau^(-j)P_j(tau Z) and V_j=tau^(1-j)P_j'(tau Z), tau^2=t, are coefficientwise integral. Their edge quotient reduces to j modulo p. The Hermite block relation gives Q_n -> Z^(4N)(Z^2+1); the separately differentiated recurrence gives V_n -> 2Z^(4N+1). At the nonzero residual roots Z^2=-1, the derivative is +2Z, not the predecessor's -2Z, since Z^(4N)=1.

The two nonzero residual roots are simple and lift uniquely in their residue classes over the algebraically closed valued field. Each has X-value 1/2 and derivative value (n-1)/2=2N+1/2. No simplicity conclusion is drawn from the repeated zero residual. These low roots lie outside every high disk. The total 2+beta(4L)=n exhausts the original degree, so no root or cluster remains unresolved.

### 6. H, algebraic squares, and every phase

The exact H/P identity and its ordinary derivative are used with the branch v_0 near i. Its coordinate derivatives are units because p is odd and the roots reduce to X=0 and z=-1. It bijects the root multisets. At a root the prefactor term proportional to P_n is exactly zero; the remaining derivative multiplier has residue i^(n-1)=+i. Equal valuations do not mean equality of normalized H/P units.

Every recurrence edge up to degree n is nonzero. A common P_n/P_(n-1) root would propagate backwards to P_0=1. The ordinary Christoffel-Darboux identity consequently gives, at each root xi,

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
      =P_n'(xi)P_(n-1)(xi)/w_(n-1) !=0.

These are algebraic squares, with no positivity or absolute-value replacement. All source and new estimates apply to the actual mixed-characteristic valuation for every s>r. The same argument uses each primitive phase's t=q-1; injectivity and algebraic conjugacy transfer the nonvanishing to every characteristic-zero primitive phase.

## Independent controls

The separately authored independent_controls.py imports neither candidate nor predecessor code. It computes the full original P recurrence in (Z/p^h)[q]/(q^(p^s)-1), reduces each inspected coefficient to the canonical cyclotomic basis, and makes the exact q=1+t substitution. Coefficient weights j+e*ord_p(c_j) are distinct modulo e, and the leading unit p/t^e=-1 is retained. Precision is strictly beyond all reported thresholds. Ordinary derivative integer multipliers are taken before valuation. No X-truncated surrogate is used.

New-target cases (p,r,s)=(5,2,3), (5,2,4), (7,2,3) pass the exact F transfer and full S identity and produce the complete expected F/S initials, including both derivative contributions. They also verify the neighbor derivative bound and exhibit the earlier whole-disk F' weight. At (5,2,3), those weights are F:131, S:279/2 and raw F':265/2; thus the raw bound cannot replace the rootwise conclusion 277/2. Ten further low scaled-recurrence rows cover the changed low-unit sign.

These bounded controls are falsification and transcription evidence only. The uniform proof is the preceding coefficientwise transfer and exhaustive root count, not a finite census. No accepted control was rerun and no source or external state was modified.


## Final replay and integrity gates

The frozen author verifier cold-replayed only its new control program under both normal and optimized Python; outputs were byte-identical to its frozen expected result. Its read-only verifier also checked the complete retained comparison archive and source identities. Historical source control programs were not executed.

This review’s separately written suite cold-replayed under normal and optimized Python. All scientific fields exactly matched the retained independent result; only the three per-case elapsed_seconds values were treated as nonsemantic timing. Each run was bounded by 60 CPU seconds, 90 wall seconds, 1 GiB address space and 8 MiB output. Raw receipts are retained.

Seven disposable-copy mutations were rejected by the independent external-pin verifier: proof-byte modification, missing bound file, unlisted file, wrong seal, symlink replacement, unlisted directory, and a fully rehashed replacement still presented under the original immutable pin. The final untouched candidate was reverified after those tests.

The immutable source inventories and wrappers require the complete original source trees. A future projected public package must not claim those original inventories verify a partially retained tree, and must explicitly account for any omitted provenance-only bytes. That does not alter the scientific acceptance bound above.

## Final conclusion

The exact n=4p^r+2 theorem is accepted for all stated primes, exponents and primitive phases. No c=4 coefficientwise input or central missing lemma remains. The uniform p-1 margin, full two-pivot sum, exhaustive low/high partition, original H transfer and algebraic-square kernel argument all pass. Finite controls support transcription and falsification only; they are not the proof.
