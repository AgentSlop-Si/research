#!/usr/bin/env python3
"""Disposable negative inventory mutations of this candidate, never sources."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("new_uniform_even_inventory", ROOT / "verify.py")
verify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)


def encoded(x):
    return (json.dumps(x, indent=2, sort_keys=True) + "\n").encode()


def run(pin):
    baseline = verify.check_tree(ROOT, pin)
    mutations = ["changed_report", "missing_report", "extra_file", "extra_directory", "symlink", "changed_seal", "fully_rehashed_replacement", "duplicate_member", "unsafe_path", "negative_bytes", "boolean_bytes", "duplicate_json_key"]
    results = []
    for mutation in mutations:
        with tempfile.TemporaryDirectory(prefix="f020-uniform-even-negative-") as temporary:
            target = Path(temporary) / "candidate"
            shutil.copytree(ROOT, target)
            manifest = json.loads((target / "MANIFEST.json").read_bytes())
            seal = json.loads((target / "SEAL.json").read_bytes())
            test_pin, rebase = pin, False
            if mutation == "changed_report":
                with (target / "REPORT.md").open("a") as f:
                    f.write("\nChanged for disposable test.\n")
            elif mutation == "missing_report":
                (target / "REPORT.md").unlink()
            elif mutation == "extra_file":
                (target / "UNLISTED.txt").write_text("extra\n")
            elif mutation == "extra_directory":
                (target / "unlisted-empty-directory").mkdir()
            elif mutation == "symlink":
                (target / "LINK").symlink_to("REPORT.md")
            elif mutation == "changed_seal":
                seal["manifest_sha256"] = "0" * 64
                (target / "SEAL.json").write_bytes(encoded(seal))
            elif mutation == "fully_rehashed_replacement":
                (target / "REPORT.md").write_text("Forged replacement.\n")
                for row in manifest["files"]:
                    if row["path"] == "REPORT.md":
                        b = (target / "REPORT.md").read_bytes()
                        row.update(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
                (target / "MANIFEST.json").write_bytes(encoded(manifest))
                seal["manifest_sha256"] = hashlib.sha256(encoded(manifest)).hexdigest()
                (target / "SEAL.json").write_bytes(encoded(seal))
            elif mutation == "duplicate_member":
                manifest["files"].append(dict(manifest["files"][0]))
                rebase = True
            elif mutation == "unsafe_path":
                manifest["files"][0]["path"] = "../outside.txt"
                rebase = True
            elif mutation == "negative_bytes":
                manifest["files"][0]["bytes"] = -1
                rebase = True
            elif mutation == "boolean_bytes":
                manifest["files"][0]["bytes"] = True
                rebase = True
            elif mutation == "duplicate_json_key":
                raw = encoded(manifest)
                raw = b'{"files": [],\n' + raw[1:]
                (target / "MANIFEST.json").write_bytes(raw)
                test_pin = hashlib.sha256(raw).hexdigest()
                seal["manifest_sha256"] = test_pin
                (target / "SEAL.json").write_bytes(encoded(seal))
            if rebase:
                raw = encoded(manifest)
                (target / "MANIFEST.json").write_bytes(raw)
                test_pin = hashlib.sha256(raw).hexdigest()
                seal["manifest_sha256"] = test_pin
                (target / "SEAL.json").write_bytes(encoded(seal))
            try:
                verify.check_tree(target, test_pin)
            except (RuntimeError, OSError, ValueError) as error:
                results.append({"mutation": mutation, "status": "REJECTED", "reason": str(error).replace(str(target), "<candidate>"), "test_pin_rebased_to_reach_schema": rebase or mutation == "duplicate_json_key"})
            else:
                raise RuntimeError("Mutation escaped verification: " + mutation)
    verify.need(verify.check_tree(ROOT, pin) == baseline, "Candidate changed during negative tests")
    return {"status": "PASS", "candidate_manifest_sha256": pin, "mutations": results, "candidate_unchanged": True, "predecessor_controls_executed": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-manifest", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()
    data = encoded(run(args.expected_manifest))
    if args.output:
        path = Path(args.output).resolve()
        verify.need(path != ROOT and ROOT not in path.parents, "Receipt must be outside frozen candidate")
        path.write_bytes(data)
    print(data.decode(), end="")


if __name__ == "__main__":
    main()
