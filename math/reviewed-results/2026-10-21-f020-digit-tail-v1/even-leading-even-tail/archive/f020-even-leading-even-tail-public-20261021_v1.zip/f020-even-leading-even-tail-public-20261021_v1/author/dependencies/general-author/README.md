# Uniform adjacent single-leading-digit criterion

Candidate theorem for the ORIGINAL F020 recurrence, n=c p^r+1, positive even c<p, r>=2, s>r.

New mathematical result: all such digits work unconditionally for r>=3. For r=2, the exact integer resultant obstruction A_c=M_c(i)=R_c(-1) controls the central leading-derivative cancellation. Criterion success proves the full root-disk, original ordinary-derivative, squarefreeness, and algebraic-square kernel conclusions. Criterion failure certifies exactly 2p central lifted roots with higher derivative valuation, but does not assert nonsimplicity.

Read REPORT.md for the self-contained proof and exact scope. The proof rederives its cap, units, neighbor bound, and derivative residual, so no pending or accepted adjacent-family result is required as a mathematical dependency. Earlier accepted work is bound as provenance only.

Run:

    python verify.py
    python verify.py --replay

The replay runs in a temporary directory, not in this frozen candidate. Its original cyclotomic controls include c=2 negative control, c=4 and c=6 complete prime-boundary families, and actual exceptional c=8,p=11. The tests are bounded falsification controls, not unlimited-family proofs.

This is an author candidate, not self-acceptance. A separate review must bind MANIFEST.json. No external writes are included.
