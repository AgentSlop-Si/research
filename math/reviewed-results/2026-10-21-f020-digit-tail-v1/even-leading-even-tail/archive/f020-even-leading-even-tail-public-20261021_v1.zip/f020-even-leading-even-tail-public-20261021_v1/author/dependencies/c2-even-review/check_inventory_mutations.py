"""Independent disposable negative controls for verify_inventory.py."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile

sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('own_inventory',Path(__file__).with_name('verify_inventory.py'))
inventory=importlib.util.module_from_spec(spec);spec.loader.exec_module(inventory)


def encoded(x): return (json.dumps(x,indent=2,sort_keys=True)+'\n').encode()


def main():
    inventory.need(len(sys.argv)==3,'usage: check_inventory_mutations.py ROOT MANIFEST_SHA256')
    root=Path(sys.argv[1]); pin=sys.argv[2]
    baseline=inventory.verify(root,pin); out=[]
    names=['changed_report','missing_report','extra_file','extra_empty_directory','symlink','bad_seal','fully_rehashed_replacement','duplicate_member','unsafe_path','negative_bytes','boolean_bytes','duplicate_json_key']
    for name in names:
        with tempfile.TemporaryDirectory(prefix='independent-even-tail-mutation-') as td:
            target=Path(td)/'copy';shutil.copytree(root,target)
            m=json.loads((target/'MANIFEST.json').read_bytes()); s=json.loads((target/'SEAL.json').read_bytes())
            test_pin=pin; rebase=False
            if name=='changed_report': (target/'REPORT.md').write_bytes((target/'REPORT.md').read_bytes()+b'\nchanged\n')
            elif name=='missing_report': (target/'REPORT.md').unlink()
            elif name=='extra_file': (target/'extra.txt').write_text('x')
            elif name=='extra_empty_directory': (target/'empty').mkdir()
            elif name=='symlink': (target/'link').symlink_to('REPORT.md')
            elif name=='bad_seal':
                s['manifest_sha256']='0'*64;(target/'SEAL.json').write_bytes(encoded(s))
            elif name=='fully_rehashed_replacement':
                (target/'REPORT.md').write_text('substituted proof\n')
                for row in m['files']:
                    if row['path']=='REPORT.md':
                        b=(target/'REPORT.md').read_bytes();row.update(bytes=len(b),sha256=inventory.sha(b))
                b=encoded(m);(target/'MANIFEST.json').write_bytes(b)
                s['manifest_sha256']=inventory.sha(b);(target/'SEAL.json').write_bytes(encoded(s))
            elif name=='duplicate_member':m['files'].append(dict(m['files'][0]));rebase=True
            elif name=='unsafe_path':m['files'][0]['path']='../REPORT.md';rebase=True
            elif name=='negative_bytes':m['files'][0]['bytes']=-1;rebase=True
            elif name=='boolean_bytes':m['files'][0]['bytes']=True;rebase=True
            elif name=='duplicate_json_key':
                raw=b'{"files": [],'+encoded(m)[1:];(target/'MANIFEST.json').write_bytes(raw)
                test_pin=inventory.sha(raw);s['manifest_sha256']=test_pin;(target/'SEAL.json').write_bytes(encoded(s))
            if rebase:
                b=encoded(m);(target/'MANIFEST.json').write_bytes(b)
                test_pin=inventory.sha(b);s['manifest_sha256']=test_pin;(target/'SEAL.json').write_bytes(encoded(s))
            try: inventory.verify(target,test_pin)
            except (ValueError,OSError) as exc:
                # Keep receipts portable: the reason is the actual gate,
                # without a temporary absolute directory.
                reason=str(exc).replace(str(target),'COPY')
                out.append({'mutation':name,'status':'REJECTED','reason':reason,'schema_pin_rebased':rebase or name=='duplicate_json_key'})
            else: raise ValueError('mutation escaped: '+name)
    inventory.need(inventory.verify(root,pin)==baseline,'source changed')
    print(json.dumps({'candidate_manifest_sha256':pin,'mutations':out,'source_unchanged':True,'status':'PASS'},indent=2,sort_keys=True))


if __name__=='__main__':main()
