#!/usr/bin/env python3
"""Strict read-only inventory/source check; optionally cold-replay NEW controls only."""
import argparse,hashlib,json,os,stat,subprocess,sys,zipfile
from pathlib import Path,PurePosixPath

ROOT=Path(__file__).resolve().parent
PINS={'general-author':'e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7','general-review':'a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7'}
REPORT='639b35b0b603fccc44a57c1f5321fc7efc5c9007510b0cd12d714eefc0d5820c'
ARCHIVE='c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe'
AM='952a6175b389b582ab4ae28491a380fa9cc8d699a45f8af0f2ea9b9240241bf8'

def need(b,m):
    if not b:raise RuntimeError(m)
def digest(b):return hashlib.sha256(b).hexdigest()
def pairs(items):
    d={}
    for k,v in items:
        need(k not in d,'duplicate JSON key');d[k]=v
    return d
def parse(b):return json.loads(b,object_pairs_hook=pairs)
def read(p):return parse(p.read_bytes())
def safe(s):
    p=PurePosixPath(s);need(isinstance(s,str) and s and not p.is_absolute() and '\\' not in s and all(x not in ('','.','..') for x in s.split('/')),'unsafe member');return s
def entries(m):
    rows=m['files'];names=[safe(x['path']) for x in rows];need(len(set(names))==len(names),'duplicate manifest member');return rows,names
def tree(path,pin=None):
    data=(path/'MANIFEST.json').read_bytes();m=parse(data)
    if pin:need(digest(data)==pin,'source manifest pin')
    need(read(path/'SEAL.json')['manifest_sha256']==digest(data),'manifest seal')
    rows,names=entries(m);expected=set(names)|{'MANIFEST.json','SEAL.json'}
    actual=set();dirs=set()
    for p in path.rglob('*'):
        need(not p.is_symlink(),'symlink rejected')
        rel=p.relative_to(path).as_posix()
        if p.is_file():actual.add(rel)
        elif p.is_dir():dirs.add(rel)
        else:raise RuntimeError('special member rejected')
    need(actual==expected,'exact file set')
    wantdirs=set()
    for name in expected:
        for parent in PurePosixPath(name).parents:
            if str(parent)!='.':wantdirs.add(str(parent))
    need(dirs==wantdirs,'exact directory set')
    for row in rows:
        b=(path/row['path']).read_bytes();need(len(b)==row['bytes'] and digest(b)==row['sha256'],'member bytes: '+row['path'])
    return {'manifest_sha256':digest(data),'files':len(rows)}
def archive_check(path):
    need(digest(path.read_bytes())==ARCHIVE,'archive hash')
    with zipfile.ZipFile(path) as z:
        names=z.namelist();need(len(names)==len(set(names)),'duplicate ZIP member')
        need(all(not x.is_dir() for x in z.infolist()),'unexpected ZIP directory')
        for x in z.infolist():
            safe(x.filename);need(not stat.S_ISLNK(x.external_attr>>16),'ZIP symlink')
        prefix='f020-single-leading-digit-comparison/'
        data=z.read(prefix+'MANIFEST.json');need(digest(data)==AM,'archive manifest pin')
        m=parse(data);rows,rel=entries(m)
        need(set(names)=={prefix+x for x in set(rel)|{'MANIFEST.json','SEAL.json'}},'archive exact set')
        need(parse(z.read(prefix+'SEAL.json'))['manifest_sha256']==AM,'archive seal')
        for row in rows:
            b=z.read(prefix+row['path']);need(len(b)==row['bytes'] and digest(b)==row['sha256'],'archive member bytes')
        # Public projection is separately identified, not conflated with original pins.
        src=ROOT/'dependencies/general-author/sources'
        for local,inside in (('LEADING_C_REPORT.md','dependencies/accepted-theorem/author/REPORT.md'),('LEADING_C_ACCEPTANCE.json','dependencies/accepted-theorem/ACCEPTANCE.json')):
            need((src/local).read_bytes()==z.read(prefix+inside),'comparison source identity')
        return {'sha256':ARCHIVE,'manifest_sha256':AM,'members_bound':len(rows)}
def limits():
    import resource
    resource.setrlimit(resource.RLIMIT_CPU,(60,60))
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE,(1024**2,1024**2))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--replay',action='store_true');a=ap.parse_args()
    out={'status':'PASS','candidate':tree(ROOT),'accepted_sources':{n:tree(ROOT/'dependencies'/n,pin) for n,pin in PINS.items()}}
    src=ROOT/'dependencies';need(digest((src/'general-author/REPORT.md').read_bytes())==REPORT,'general report pin')
    binding=read(src/'general-review/SOURCE_BINDING.json');verdict=read(src/'general-review/VERDICT.json')
    need(binding['author_manifest_sha256']==PINS['general-author'] and binding['author_report_sha256']==REPORT,'review report binding')
    need(verdict['author_manifest_sha256']==PINS['general-author'] and verdict['verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE','review acceptance binding')
    sb=read(ROOT/'SOURCE_BINDINGS.json');need(sb['mathematical_dependencies']==PINS,'source dependency identity')
    for row in sb['scope_and_comparison_sources']:
        b=(ROOT/safe(row['copy'])).read_bytes();need(len(b)==row['bytes'] and digest(b)==row['sha256'],'scope source binding')
    out['comparison_archive']=archive_check(src/'general-author/sources/accepted-single-leading-digit-comparison.zip')
    out['accepted_programs_executed']=False
    if a.replay:
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
        result=subprocess.run([sys.executable,'-B',str(ROOT/'check_controls.py')],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90,preexec_fn=limits)
        need(result.returncode==0,'new control replay: '+result.stderr.decode())
        need(result.stdout==(ROOT/'CONTROL_RESULTS.json').read_bytes(),'exact new control replay bytes')
        out['new_control_replay']='PASS_EXACT'
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
