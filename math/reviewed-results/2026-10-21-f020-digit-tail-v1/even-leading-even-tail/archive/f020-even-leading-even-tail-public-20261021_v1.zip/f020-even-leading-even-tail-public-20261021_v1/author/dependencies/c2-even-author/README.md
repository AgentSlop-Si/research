# Uniform even tails after a leading two

Author candidate, not self-accepted. The proposed theorem covers n=2p^r+d for every odd prime p, r>=2, s>r, even 2<=d<p, and every characteristic-zero primitive p^s phase. It preserves the original P/H definitions and algebraic-square Christoffel-Darboux kernel.

REPORT.md gives the uniform proof. Its exact tail recurrence and fraction-free witness yield derivative gaps p-1 and p+x-1 independent of d. The low Hermite resultant has no prime divisor above d. Auxiliary tail cancellations, including d=6,p=11 and d=8,p=31, are classified and harmless. There is no unresolved mathematical exceptional pair inside the theorem's scope.

The already accepted +2 and +4 cases are retained, not newly credited. All admissible even tails d>=6 are the additional scope. There is no arbitrary-degree, global F020/F023, historical-novelty, or FFT/cost claim.

Files:

- REPORT.md: theorem, coefficientwise source boundary, proof, and scope.
- CLAIM_SCOPE.json and SCOPE_AUDIT.md: machine-readable scope and exclusions.
- check_controls.py: fresh short-tail exact symbolic and low-residue diagnostics.
- CONTROL_RESULTS.json and CONTROL_RUN.log: deterministic fresh results.
- verify.py: strict inventories, accepting source bindings, and capped new-control replay.
- check_freeze_controls.py: disposable negative inventory mutations.
- SOURCE_BINDINGS.json and SOURCE_VERIFICATION.json: immutable source pins and checked inventories.
- dependencies: complete unchanged +4 author/review, containing complete +2 and general coefficientwise author/review packages.
- REVIEW_REQUEST.md: independent review gates.

Verification requires Python 3.10+ standard library only. Use the externally supplied manifest pin, not a newly computed replacement pin:

    python -I -B verify.py --expected-manifest EXTERNAL_PIN --replay
    python -I -B verify.py --expected-manifest EXTERNAL_PIN --replay --optimized
    python -I -B check_freeze_controls.py --expected-manifest EXTERNAL_PIN

The verifier writes no receipt unless --output is given, and then requires an output path outside this frozen directory. Replay copies only the NEW check_controls.py into a disposable directory. It does not execute any accepted-source code. Python -I, resource limits, and a disposable directory are not an OS or network sandbox.

The scientific proof, not the finite checks, establishes the stated uniform family. Independent acceptance and later public-package verification remain separate gates. No external write occurs in this local candidate.
