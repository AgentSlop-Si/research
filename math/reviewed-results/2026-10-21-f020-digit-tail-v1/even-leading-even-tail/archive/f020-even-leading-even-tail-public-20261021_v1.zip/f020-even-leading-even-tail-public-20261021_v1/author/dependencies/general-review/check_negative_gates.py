#!/usr/bin/env python3
"""Explicit algebraic falsification gates, separate from immutable-file tampering."""
import argparse,json
from pathlib import Path

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--results',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();j=json.loads(Path(a.results).read_text());rows=j['fields']['rows'];bad=next(x for x in rows if (x['c'],x['p'],x['r'])==(8,11,2));c2=[x for x in rows if x['c']==2 and x['r']==2]
    ints=lambda d:{int(k):v for k,v in d.items()};M=ints(bad['M']);actual=ints(bad['F_derivative']);p=bad['p'];c=bad['c']
    wrong_c4={};wrong_sign={};without_tie={}
    for k,v in M.items():
        wrong_c4[k]=-4*v%p;wrong_c4[k-2]=-4*v%p
        wrong_sign[k]=-c*v%p;wrong_sign[k-2]=c*v%p
        without_tie[k-2]=-c*v%p
    assert actual!=wrong_c4 and actual!=wrong_sign and actual!=without_tie and actual
    assert all(x['gcd_degree']==2 for x in c2) and bad['gcd_degree']==2
    cases=j['elementary']['explicit_cases'];boundary=next(x for x in cases if (x['c'],x['p'])==(16,17));assert boundary['A_integer']%17==0 and boundary['residual_gcd_degree']==2
    # This check rejects use of coefficient reduction modulo p as if exact at the required weight.
    assert bad['K_twice']>2*(p-1)*p*p and bad['D_twice']>2*(p-1)*p*p
    report={'status':'PASS','rejected_mutations':['copy c=4 scalar into general c','replace Y^2+1 by Y^2-1','omit Y^2+1 tie factor','differentiate the characteristic-p root residual instead of the ordinary derivative','claim c=2 criterion passes','claim no exceptional prime-boundary pair','use mod-p coefficient precision at above-ramification thresholds'],'exception_c8_p11_original_recurrence_gcd_degree':bad['gcd_degree'],'c2_all_prime_cancellation_has_uniform_proof':'A_2=0, R_2(U)=U+1; finite controls also retain the cancellation','no_inference':'A positive residual gcd is not a proof of multiple characteristic-zero roots.'}
    Path(a.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
