# Independent review package

The exact author candidate bound by `SOURCE_BINDING.json` is accepted within its stated even-c adjacent-family scope. Read `INDEPENDENT_REVIEW.md` and `VERDICT.json` first. The exceptional-prime statement is leading ordinary-derivative cancellation, not nonsquarefreeness.

`controls/` contains the original independent test results, clean capped replay results/receipts, author cold-replay receipt, exact source and candidate inventories, and mutation/negative-gate evidence. Nothing in this review changes or uploads author files.

Verify this review's exact inventory:

    PYTHONDONTWRITEBYTECODE=1 python verify_inventory.py <review-directory> --expected <review-manifest-sha256>

Reproduce the independent controls in a clean temporary directory, with output outside the frozen review:

    PYTHONDONTWRITEBYTECODE=1 python replay_independent.py --script independent_controls.py --reference controls/RESULTS.json --outdir <outside-output-directory>

Check the exact author inventory and disposable-copy tamper controls:

    PYTHONDONTWRITEBYTECODE=1 python check_freeze_controls.py <author-directory> --manifest e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7 --output <outside-output.json>

Optionally add `--accepted-comparison <previously-accepted-comparison.zip>` for a byte-for-byte comparison against that separate source copy; the pinned archive hash is always checked.

Replay the algebraic negative controls:

    PYTHONDONTWRITEBYTECODE=1 python check_negative_gates.py --results controls/RESULTS.json --output <outside-output.json>

The tests are finite falsification controls. The review's acceptance rests on the uniform proof audit as well as exact frozen-byte replay. Python 3.12.14, NumPy 2.3.5, and SymPy 1.14.0 were used. Keep generated output outside frozen inventories and disable bytecode writes.
