# F020 leading-four plus-two candidate

Exact scope: n=4p^r+2, primes p>=5, r>=2, s>r, and every characteristic-zero primitive p^s phase. Original P and Gaussian H are squarefree; the original algebraic-square CD kernel is nonzero at every P root.

Read REPORT.md for the proof. Its coefficientwise inputs come directly from the accepted general-c theorem, not extrapolation of c=2. All two derivative pivots, the p=5 boundary, two low roots, every high cluster, and original H/P units are retained. No central second-layer input is needed: the even-tail witness leaves a strict p-1 derivative gap.

This is a frozen author candidate awaiting independent review. No historical novelty, arbitrary-n/global-F020, or FFT claim is made. Accepted source programs are retained as historical bytes only and are never run by this verifier. No external write is performed.

Read-only verification with Python 3 standard library:

    python -B verify.py
    python -B verify.py --replay

The second command replays only the new bounded controls, with CPU/memory/file-size/time limits. It writes nothing. Controls are falsification checks, not a uniform proof. To save output, redirect it OUTSIDE this frozen directory.

SOURCE_BINDINGS.json distinguishes direct mathematical sources from scope/provenance comparisons, and original identities from projected public identities. MANIFEST.json binds every retained file except itself and SEAL.json; SEAL.json binds the manifest.
