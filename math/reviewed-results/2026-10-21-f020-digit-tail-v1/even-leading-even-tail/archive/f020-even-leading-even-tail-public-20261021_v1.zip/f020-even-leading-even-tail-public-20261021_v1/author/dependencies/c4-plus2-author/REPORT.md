# Leading four with the first positive even tail

Author candidate, 21 October 2026 UTC. This is a scoped extension of retained accepted results, not independent acceptance, historical novelty, or a claim about arbitrary F020 degrees. No external state is changed.

## 1. Exact theorem

Let p>=5 be prime, r>=2, s>r, N=p^r, n=4N+2, and q be any characteristic-zero primitive p^s-th root. Use the ORIGINAL definitions

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_j(z)=sum_k [j choose k]_q z^k,
    w_j=product_(u=1)^j(1-q^u).

In an algebraic p-adic embedding set t=q-1 and v(t)=1. Define

    e=v(p)=(p-1)p^(s-1), B=r(p-1)p^(r-1)/2,
    K=2N+4B, E=3N/2+4B, D=5N/2+4B-p=N+E-p,
    h=floor(r/2), beta=p^h, L=N/beta,
    rho=beta/2                         if r is even,
    rho=p^(h-1)(2p-1)/2                if r is odd.

THEOREM. Both original P_n and H_n are squarefree, and the original algebraic-square Christoffel-Darboux kernel is nonzero at every P_n root. The complete P_n root partition is:

- Two simple low roots with v(X)=1/2. For tau^2=t and X=tau Z, their distinct residues satisfy Z^2=-1, and their ORIGINAL ordinary derivatives satisfy

      v(P_n'(X))=2N+1/2,
      P_n'(X)/tau^(4N+1) -> 2Z^(4N+1)=2Z !=0.

- In each of the beta pairwise disjoint closed disks

      v(X-x_a)>=rho,
      x_a=i(q^(a/2)-q^(-a/2)), 0<=a<beta, i^2=-1,

  with the square roots congruent to 1, exactly 4L roots lie on the boundary. These 4N roots are simple and satisfy

      v(P_n'(X))=D+1.

  Their X-values are rho centrally and p^ord_p(a) otherwise. Counts include multiplicity until simplicity is proved.

There is no exact zero root, and v(P_n(0))=K+1. Corresponding H_n root multiplicities and ordinary derivative valuations agree, with its actual unit multiplier kept in Section 7. Every assertion includes p=5, every s>r, and every primitive phase.

This theorem makes no assertion for other leading digits, tails beyond +2, p=2 or 3, r<2, s<=r, composite orders, arbitrary n or intermediate digits, unrelated finite characteristics, global F020/F023 closure, FFT/cost improvement, or historical novelty. Exclusions are not claims that all those cases are unresolved elsewhere.

## 2. Scope audit and the exact accepted c=4 inputs

The retained single-leading-digit theorem has degree c*p^r, the general adjacent theorem and central lift have degree c*p^r+1, and the assembled leading-two sector has degree 2*p^r+d, 0<=d<p. Our degree 4*p^r+2 is in none of these stated families. Modulo p its digit is 2, not 0 or 1; its remaining leading digit is 4, not 2. Reading the accepted leading-two +2 and uniform even-tail proofs identifies a reusable transfer, but does NOT license replacing their coefficient 2 by 4 in an input lemma.

Instead we invoke the accepted GENERAL coefficientwise theorem's Sections 2-5 directly at c=4. The complete unchanged author and accepting-review packages are copied under dependencies with manifest SHA-256 identities

    author: e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7
    review: a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7.

The exact author report SHA-256 is

    639b35b0b603fccc44a57c1f5321fc7efc5c9007510b0cd12d714eefc0d5820c.

Its reviewer explicitly audits the coefficientwise lemmas, including their off-root P derivative transfer. Its adjacent-degree squarefreeness conclusion is not our premise. The nested accepted single-leading-digit comparison archive has SHA-256 c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe and public report SHA-256 4b603ec48cd71adb5edc22d2d5b851e8854bcd179f7913a7c0fb913529c2c120. Those are provenance identities, not substitutes for the coefficientwise source or hashes of undistributed original private manifests. The source acceptance file records original and projected identities separately.

Put

    A=P_(4N), M=P_(4N-1), a=1-q^(4N), b=1-q^(4N+1),
    M_4(Z)=Z^4+6Z^2+3, M_3(Z)=Z^3+3Z.

On EVERY full high disk, in its scaled coordinate Y, the needed accepted inputs are exactly:

(I1) Coefficientwise wt(A)=K, with residual a nonzero scalar times M_4(Zbar), where Zbar=alpha_a Y^L and alpha_a!=0. Its residual degree is 4L, its constant term is a unit, and all higher coefficients have greater normalized weight.

(I2) Coefficientwise wt(M)=E, with residual a nonzero scalar times 4 M_3(Zbar).

(I3) Coefficientwise wt(A')=D, with residual a nonzero scalar times 4 M_3(Zbar). This is the ORIGINAL ordinary characteristic-zero derivative, including its integer factors before reduction.

(I4) Coefficientwise wt(M')>=E on the entire disk, not merely at earlier roots.

(I5) The actual H/P analytic coordinate change on the branch near i is an isometry. The A-prefactor derivative has weight at least r*e+K>D, and is retained before being discarded by this strict inequality.

All of these are in the accepted general theorem at c=4<p; none is imported by analogy from c=2. Their Newton content is important. Write Q_j=product_(u=1)^j(1-q^(2u)), N_j(z)=product_(u=0)^(j-1)(z+q^u), W(j)=sum_(u=1)^j p^ord_p(u). The exact expansions used by the source are

    H_b=sum_(k=b mod 2) w_b N_k/[w_k Q_((b-k)/2)],
    H_b'=sum_(k=b mod 2,k>=1) sum_(0<=m<k)
        w_b z^(k-m-1)N_m/[Q_((b-k)/2)w_m(1-q^(k-m))].

The half-W cap has equality only at multiples of N on 0<=j<=4N. A has THREE Newton pivots k=0,2N,4N, whose unit sum is M_4, not M_2. The derivative score has its unique increment k-m=p^2, but TWO equality pairs:

    (m,k)=(N,N+p^2), (3N,3N+p^2).

Writing A0=(N-p^2)/2 and omega^2=w_N, their actual shifted-factorial units after normalization by [w_N/(Q_A0*(1-q^(p^2)))]*omega^3 are respectively 12 Zbar and 4 Zbar^3. Their SUM is 4 M_3(Zbar). At p=5,r=2, the second pivot is the endpoint k=4N and is included. Neither pivot may be silently dropped.

The neighbor has exactly k=N,3N as Newton equality indices, and their sum gives the same Hermite factor. The accepted complete M' proof excludes every possible lower competitor, including the apparent increment-1 and increment-p borderlines by strict cap or a strict N-level floor carry. It is not a bound only on those two pivots.

The exact resultant Res(M_4,M_3)=1^1*2^2*3^3=108 is a unit for every p>=5. Equivalently, M_3=0 requires either Zbar=0, where M_4=3, or Zbar^2=-3, where M_4=-6; neither is zero in this range. Thus cancellation between the two derivative pivots is possible at other boundary points, but NEVER on the M_4 root locus. At every point of that locus, including the new roots constructed below,

    v(M)=E, v(A')=D.                                      (2.1)

No additional c=4 coefficientwise lemma is missing. The new work is the exact transfer, feedback at its new root locus, and the full low/high partition. No new central-root depth assumption or central second-layer lemma is required.

## 3. Exact two-step transfer and all high-root clusters

Two applications of the ORIGINAL recurrence give

    F:=P_(4N+2)=T A-a X M, T=X^2-b.                        (3.1)

The degree bound holds even at the prime boundary p=5:

    pN-(4N+2)=(p-4)N-2>=25-2=23>0.

Every recurrence edge and Newton denominator is therefore nonzero. Since 4<p and 4N+1 is a p-unit,

    v(a)=N, a/t^N -> -4, v(b)=1, b/t -> -1.

On every full high disk the Gauss weight of X is x>=1, equal to rho centrally and p^ord_p(a) otherwise. Therefore X^2/t has strictly positive weight, and

    T/t -> 1, wt(T)=1.

So T/t is an analytic unit throughout each high disk. The perturbation in (3.1) has weight at least

    N+E+x=K+N/2+x>K+1,

with gap N/2+x-1>0. Hence F has weight K+1 and residual a nonzero scalar times M_4(alpha_a Y^L). It has degree 4L with nonzero constant in Y, and all higher coefficients have positive normalized weight. Closed-disk Newton/Weierstrass counting gives exactly 4L roots counted with multiplicity in each disk, all on its boundary. There are four distinct residual root locations, each of multiplicity L, since M_4 is separable modulo p. We do not apply simple-root Hensel to an inseparable Y-residual.

The centers have pairwise distance of valuation at most p^(h-1)<rho. Thus the beta disks are disjoint and provide 4N high roots. At every one of THESE new roots the M_4 residual equation holds, so (2.1) applies. This is not substituting an old polynomial's root into F.

At zero, F(0)=-b A(0). The central constant residual of A is 3 times a nonzero scalar, so v(A(0))=K and v(F(0))=K+1. No exact zero has been factored out or counted.

## 4. Every derivative term and the uniform gap

On each high disk set J=F/T=A-aRM with R=X/T. Ordinary characteristic-zero differentiation gives

    R'=-(X^2+b)/T^2,
    J'=A'-aR'M-aRM'.                                     (4.1)

At a new high root, v(R)=x-1 and v(R')=-1 because v(X^2)>v(b)=1. The three terms in (4.1) have values

    D, N+E-1, >=N+E+x-1.

Since D=N+E-p, their latter two gaps over the first are p-1 and at least p+x-1. Both are strictly positive, uniformly; at p=5 the first is 4. Therefore v(J')=D. At a root J=0, F'=T J', proving

    v(F')=D+1.                                          (4.2)

The equivalent fraction-free identity retains every term and is useful for direct original-recurrence checks:

    S=T F'-2X F
      =T^2 A'+a(X^2+b)M-aTXM'.                           (4.3)

At each new high root the three right-hand terms have values D+2, N+E+1 and at least N+E+x+1, with the same strict gaps. Thus v(S)=D+2, and S=T F' at a root proves (4.2) without division.

There is intentionally NO assertion that the whole-disk F' has weight D+1. Away from roots F'=T'J+TJ' contains the extra T'J term. Removing it uses the exact root equation or (4.3), never an approximate root.

This explains why the adjacent +1 obstruction is irrelevant: its derivative contains M/X^2 and can tie A' centrally. Here R' has fixed value -1, not -2x, leaving a p-1 gap. The general central second-layer source concerns that different +1 tie, not this transfer.

## 5. Explicit central r=2 check, including p=5 and both pivots

For r=2, B=N-p and rho=p/2. Let mu^2=t^p, X=mu Y and epsilon=(-1)^((p-1)/2). The accepted c=4 ORIGINAL normalizations give

    A(mu Y)/t^K -> M_4(Y^p)=(Y^4+6Y^2+3)^p,
    M(mu Y)/(t^(4B)*mu^(3p)) -> epsilon M_3(Y^p),
    A'(mu Y)/(t^(5B)*mu^(3p)) -> -4 epsilon M_3(Y^p).

The first derivative normalization has value D. From (4.3), the corresponding normalized S initial is exactly -4 epsilon M_3(Y^p), after division by t^(5B+2)*mu^(3p). At an F root, division by T/t with residue 1 therefore yields

    P_n'(mu Y)/(t^(5B+1)*mu^(3p))
       -> -4 epsilon [Y^(3p)+3Y^p] !=0.                   (5.1)

This concerns the rootwise original derivative, not the derivative of M_4(Y^p), which would vanish in characteristic p. The nonzero assertion follows from the coprimality already proved. No deeper value of U+1, no scalar evaluation at X^2=-t^p, and no choice of a preferred central branch is used.

At p=5 specifically, the base/root initial is Y^20+Y^10+3, and the derivative/witness initial is Y^15+3Y^5. Their gcd is 1. Here K=130, E=235/2, D=275/2; the high-root derivative value is 277/2, and the low-root value is 101/2. These values exceed or interact with e=100 at s=3, so retaining actual mixed-characteristic coefficients is essential. There are five high disks, twenty roots in each, and two low roots. The central four residual root locations each account for five roots, not one.

## 6. Exactly two simple low roots and no omitted roots

Let tau^2=t and define from the original polynomials and their ordinary derivatives

    Q_j(Z)=tau^(-j)P_j(tau Z),
    V_j(Z)=tau^(1-j)P_j'(tau Z).

Their integral coefficientwise recurrences are

    Q_(j+1)=ZQ_j-[(1-q^j)/t]Q_(j-1),
    V_(j+1)=Q_j+ZV_j-[(1-q^j)/t]V_(j-1),
    Q_0=1, Q_1=Z, V_0=0, V_1=1.

The negative edge quotient reduces to j modulo p, including zero when p divides j. Thus reductions obey M_(j+1)=ZM_j+jM_(j-1) and its differentiated recurrence. The integer Hermite coefficient formula gives M_p=Z^p modulo p. Block induction in the recurrence then gives M_(ap+b)=Z^(ap)M_b for 0<=b<p: the j=ap edge vanishes, and the within-block recurrence starts again with 1,Z. Consequently

    Q_n -> Z^(4N)(Z^2+1), V_n -> 2Z^(4N+1).

The V reduction is independently warranted by the original differentiated recurrence; it is not a proof of simplicity above the repeated zero residual. The two nonzero roots Z^2=-1 are simple since 2Z!=0. Simple-root Hensel supplies one simple root in each of these two classes, v(X)=1/2, and the derivative value and residue in Section 1. Here Z^(4N)=1, so the low residue is +2Z, not the -2Z belonging to the c=2 predecessor.

These roots are disjoint from the high disks, whose X-values are at least 1. Finally

    2+beta*(4L)=4N+2=n.

The degree is exhausted, with no unresolved cluster or exact zero.

## 7. Original H, every phase, and the algebraic-square kernel

The exact coordinate identities are

    H_n(v0^2)=v0^n P_n(X), X=v0+v0^(-1),
    H_n'(z)=v0^(n-2)[(n/2)P_n+(v0-v0^(-1))P_n'/2].

Modulo the maximal ideal P_n=X^n and H_n=(1+z)^n, so every P root is small and is not +/-2, while every H root is near -1 and is nonzero. The branch v0 near i has unit derivatives in both coordinate maps. It bijects the root multisets and preserves multiplicities and derivative valuations. At a root the prefactor term proportional to P_n vanishes EXACTLY. The derivative multiplier residue is i^(n-1)=i, not the -i of the leading-two +2 case. Equal valuations are not asserted equal normalized H/P units.

Every source bound and every new identity uses the actual mixed-characteristic field with e=(p-1)p^(s-1), uniformly for s>r. No p-divisible coefficient is discarded before valuation, and no finite experiment at s=r+1 is extrapolated. For every primitive phase choose its algebraic p-adic embedding and use its own t=q-1. The same bounds apply; injectivity and algebraic conjugacy give the characteristic-zero assertions in every primitive embedding.

Every edge 1-q^j, 1<=j<n, is nonzero. A common root of P_n and P_(n-1) would propagate backwards in the original recurrence to P_0=1, impossible. The ORIGINAL ordinary Christoffel-Darboux identity at a P_n root xi is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
       =P_n'(xi)P_(n-1)(xi)/w_(n-1) !=0.

These are algebraic squares, not absolute-value squares. The proof invokes neither positivity, real-rootedness, interlacing, nor Fourier arguments.

## 8. Verification and the next gate

Sections 2-7 are the proof. The c=4 coefficientwise inputs are covered by accepted general sources, whose author/review inventories and bindings are checked read-only; their programs are NOT executed. The retained leading-two +2 transfer supplies the pattern, with its original credit and scope kept separate. The necessary c=4 multi-pivot and constant-term differences, low residue sign, and H/P multiplier have all been explicitly handled here.

The new bounded controls verify the exact two-step recurrence and fraction-free identity, the c=4 two-pivot sum and resultant, low differentiated recurrences, and the original mixed-characteristic n=102 and n=198 recurrences at (p,r,s)=(5,2,3),(7,2,3). They check the new F and witness S, keeping integer derivative factors and p/t^e=-1. They are transcription/falsification checks, not proof of uniformity. Source programs and previous finite controls are not rerun.

The candidate is frozen with exact source bindings, a full inventory, and a read-only replay verifier. The next gate is independent review of these exact bytes, especially the off-root coefficientwise c=4 input, sum of both pivots, p=5 endpoint, high-root feedback, fraction-free witness, and all-root partition. Until that gate accepts the candidate, this remains an author result. No external repository, Library item, native document, source package, or accepted theorem has been edited.
