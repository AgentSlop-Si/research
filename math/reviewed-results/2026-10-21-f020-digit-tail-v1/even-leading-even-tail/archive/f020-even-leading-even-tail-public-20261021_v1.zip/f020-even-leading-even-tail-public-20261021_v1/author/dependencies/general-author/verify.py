#!/usr/bin/env python3
"""Read-only frozen inventory and optional resource-capped cold control replay."""
from pathlib import Path
import argparse, hashlib, json, os, resource, shutil, subprocess, sys, tempfile, time, zipfile
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(180,180))
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,64*1024**2))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--replay',action='store_true');ap.add_argument('--output');args=ap.parse_args()
    mb=(ROOT/'MANIFEST.json').read_bytes();m=json.loads(mb);seal=json.loads((ROOT/'SEAL.json').read_text())
    assert sha(mb)==seal['manifest_sha256']
    known={'MANIFEST.json','SEAL.json'}
    for f in m['files']:
        b=(ROOT/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path'];known.add(f['path'])
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    assert actual==known,{'missing':sorted(known-actual),'unexpected':sorted(actual-known)}
    sb=json.loads((ROOT/'SOURCE_BINDINGS.json').read_text());zb=(ROOT/sb['dependency_archive']).read_bytes();assert sha(zb)==sb['archive_sha256']
    with zipfile.ZipFile(ROOT/sb['dependency_archive']) as z:
        smb=z.read(sb['archive_root']+'MANIFEST.json');assert sha(smb)==sb['manifest_sha256'];sm=json.loads(smb)
        for f in sm['files']:
            b=z.read(sb['archive_root']+f['path']);assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
        assert len(sm['files'])==sb['verified_manifest_entries']
        for f in sb['files']:
            b=z.read(f['archive_path']);assert b==(ROOT/f['copy']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
    result={'status':'integrity_pass','author_manifest_sha256':sha(mb),'manifest_entries_verified':len(m['files']),'provenance_entries_verified':len(sm['files']),'mathematical_dependencies':[],'self_acceptance':False}
    if args.replay:
        st=time.monotonic()
        with tempfile.TemporaryDirectory(prefix='f020-uniform-adjacent-cold-') as tmp:
            p=Path(tmp);shutil.copyfile(ROOT/'check_controls.py',p/'check_controls.py')
            env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
            cp=subprocess.run([sys.executable,str(p/'check_controls.py')],cwd=p,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240,preexec_fn=limits)
            assert cp.returncode==0,cp.stdout
            got=(p/'CONTROL_RESULTS.json').read_bytes();assert got==(ROOT/'CONTROL_RESULTS.json').read_bytes(),'Cold replay mismatch'
            result.update(status='integrity_and_cold_replay_pass',control_results_sha256=sha(got),replay_stdout=cp.stdout,wall_seconds=round(time.monotonic()-st,3),caps={'cpu_seconds':180,'wall_seconds':240,'address_space_bytes':1024**3,'output_bytes':64*1024**2,'numerical_threads':1})
    if args.output:
        dest=Path(args.output).resolve();assert ROOT not in dest.parents and dest!=ROOT,'Receipt must be outside frozen candidate';dest.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
