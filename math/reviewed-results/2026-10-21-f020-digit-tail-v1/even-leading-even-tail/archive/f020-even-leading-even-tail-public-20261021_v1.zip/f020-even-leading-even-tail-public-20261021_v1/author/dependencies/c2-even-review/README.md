# Uniform even-tail independent review

`REPORT.md` is the mathematical review. `VERDICT.json` and `SOURCE_BINDING.json` bind it to the exact accepted author candidate and its complete predecessor source trees. Acceptance is limited to the stated characteristic-zero even-tail family; a later public-package or delivery audit is separate.

The programs use only the Python standard library. They do not install packages, access the network, or execute accepted predecessor controls.

## Replay

Preserve this complete review directory and the complete author directory, including the author's nested dependencies. Supply externally verified manifest pins; do not obtain trust merely by reading a possibly substituted seal.

From the review directory, with a sibling author directory named `author`:

    python -I -B verify_review.py --expected-manifest REVIEW_SHA256 --author-root ../author --expected-author-manifest c7b391df43fc8fb0fb14fab06ddd1d4e722d791469fc2593017ef27d8d9a88d3 --replay
    python -I -B -O verify_review.py --expected-manifest REVIEW_SHA256 --author-root ../author --expected-author-manifest c7b391df43fc8fb0fb14fab06ddd1d4e722d791469fc2593017ef27d8d9a88d3 --replay --optimized

The optional `--output` receipt must be outside the frozen review. The independent scientific program has no output-file option; it emits deterministic JSON to stdout:

    python -I -B independent_checks.py

Its exact reference is `controls/INDEPENDENT_RESULTS.json`. The standalone inventory and mutation interfaces are:

    python -I -B verify_inventory.py ROOT EXTERNAL_MANIFEST_SHA256
    python -I -B check_inventory_mutations.py ROOT EXTERNAL_MANIFEST_SHA256

Both emit JSON to stdout. The mutation checker uses only disposable copies and never modifies ROOT. It can check the author or this review. The author's new verifier and controls remain in the author package; none of its accepted predecessor programs is needed for execution.

All finite computations are falsification controls, not substitutes for the uniform proof. Recorded replay timings and resource limits do not imply an asymptotic improvement or an OS/network sandbox.
