# Independent review request

Review the exact immutable manifest bytes and REPORT.md. Do not execute accepted source programs or rerun accepted control suites. The new controls are small symbolic/residue falsification checks, not the uniform proof.

Priority checks:

1. General-author e19104be... and accepting-review a7990e62... cover coefficientwise A,M,A',M' for every allowed c, unconditionally with respect to the adjacent criterion. Check complete c/2 derivative pivots, both c=4 pivots, the r=2 endpoint, and the full neighbor-derivative bound.
2. Exact T/U transfer, associated U edge start, and both terms in the fraction-free witness. Check every ordinary derivative factor before reduction.
3. High-tail constant unit at d=p-1, whole-disk estimates, residual feedback at new roots, gaps p-1 and p+x-1, and absence of an unsupported whole-disk F' assertion.
4. General-c actual central units and the H/P multiplier (-1)^(c/2+d/2-1)i. Adjacent obstruction primes and associated-tail coefficient cancellations must not be ignored or treated as nonsimplicity.
5. Complete cN+d root count, c locations with L multiplicity per high disk, low Hermite separability including d=p-1, no zero root, every phase/s, original H and algebraic-square CD.
6. Exact source and candidate inventories, review-to-author bindings, new cold replay, negative controls, and honest scope/credit exclusions.

No reviewer repair should silently change author files. Report a blocker or missing lemma precisely if one is found. Final acceptance must bind the frozen candidate manifest and report hashes.
