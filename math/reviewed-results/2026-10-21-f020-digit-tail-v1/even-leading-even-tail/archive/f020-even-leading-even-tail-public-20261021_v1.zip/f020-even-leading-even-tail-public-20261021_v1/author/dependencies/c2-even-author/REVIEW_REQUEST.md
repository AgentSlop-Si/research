# Independent review request

Please review the externally pinned complete candidate, not a mutable draft. Do not edit accepted dependencies or execute their controls.

Required mathematical checks:

1. Read the actual accepted +2/+4 identities and nested general coefficientwise inputs. Verify that A', M and M' estimates hold on full disks and that the exact values hold on the new residual root locus, including p=3.
2. Verify both tail recurrences, especially U_d's missing a_1, its degree d-1 and odd parity for even d. Verify the complete polynomial witness S_d=T_d F'-T_d'F, not a shortcut using a whole-disk F' estimate.
3. Check all coefficient edge grades and the decisive constant c_m. Confirm that x>=1 on each full disk and that high-tail auxiliary cancellations can only improve the bounds.
4. Verify the explicit auxiliary cancellation recurrence b_m and condition p|b_m. Check that no exact U/W weight is asserted where it fails, including d=6,p=11 and d=8,p=31.
5. Verify high-root counts by closed-disk Newton/Weierstrass, disjoint disks, boundary values, new-root feedback, and the two derivative gaps p-1 and p+x-1.
6. Check the scaled original and separately differentiated low recurrences. Verify the characteristic-p block identity and low Hermite resultant/discriminant, especially d=p-1. Do not use simple-root Hensel on the repeated high zero residue.
7. Check complete degree exhaustion, no zero root, all ordinary derivative valuations, all-phase/mixed-characteristic quantifiers, and exact original H coordinate and algebraic-square kernel transfer.
8. Distinguish the empty unresolved exceptional set INSIDE the stated range from excluded d>=p and other scopes. Do not infer global F020/F023 closure or historical novelty.

Artifact checks: verify six pinned complete source inventories and review/report bindings; verify the exact candidate inventory; run only the new short-tail controls and independent controls you write; perform cold/optimized replay and negative inventory gates as useful. Finite data is control only, not a proof of the uniform quantifiers.

Return a short outcome first, with exact manifest/report hashes, all essential repairs or qualifications, and the complete review artifact. Do not self-accept this author package or silently replace its scientific bytes.
