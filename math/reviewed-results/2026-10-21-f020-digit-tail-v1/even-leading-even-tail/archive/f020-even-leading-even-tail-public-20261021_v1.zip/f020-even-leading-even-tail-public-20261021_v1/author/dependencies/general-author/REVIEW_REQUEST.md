# Fresh review requested

Bind this exact author MANIFEST.json, not an unsealed draft. Independently inspect the uniform proof in REPORT.md and cold-replay controls in a separate directory. Do not alter this candidate.

Please concentrate on:
- The all-even-c neighbor derivative bound, including j=1,p and prime-boundary c=p-1.
- The off-root coordinate derivative prefactor and ordinary derivative normalization.
- The r=2 scalar ratio and general-c phases in equations (22)-(27), rather than extrapolating c=4.
- Exact integer criterion and resultant sign convention; p>c makes consecutive Hermite residuals coprime.
- The difference between criterion failure, higher ordinary derivative valuation, and actual multiple roots.
- The c=2 negative control and the actual cyclotomic exceptional c=8,p=11 control.
- Truncation/precision justification in the mixed-characteristic controls, including p/t^e=-1 and derivative integer factors.
- Denominators, original kernel normalization, and the absence of all-n/F023/FFT/novelty claims.

The proof is self-contained; copied accepted single-leading-digit sources are provenance rather than essential lemmas. No c=4 candidate dependency is needed. Give a scoped verdict, exact source binding, and independent replay evidence. If an essential repair is needed, reject this frozen version and request a new candidate; do not quietly edit it.
