#!/usr/bin/env python3
"""New exact short-tail controls. Standard library only; no supplied module imports."""
import json
from math import factorial


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def add(a, b, scale=1):
    out=dict(a)
    for k,v in b.items():
        out[k]=out.get(k,0)+scale*v
        if not out[k]: del out[k]
    return out


def mul(a,b):
    out={}
    for ka,va in a.items():
        for kb,vb in b.items():
            k=tuple(x+y for x,y in zip(ka,kb))
            out[k]=out.get(k,0)+va*vb
    return {k:v for k,v in out.items() if v}


def deriv(a):
    out={}
    for k,v in a.items():
        if k[0]:
            t=list(k); t[0]-=1
            out[tuple(t)]=k[0]*v
    return out


def symbolic(d):
    nv=d+5
    one={(0,)*nv:1}
    def var(j):
        k=[0]*nv;k[j]=1
        return {tuple(k):1}
    x=var(0); edges={j:var(j+1) for j in range(d)}
    A,Ap,M,Mp=[var(d+1+j) for j in range(4)]
    ts=[one,x]; us=[{},one]
    for j in range(1,d):
        ts.append(add(mul(x,ts[-1]),mul(edges[j],ts[-2]),-1))
        us.append(add(mul(x,us[-1]),mul(edges[j],us[-2]),-1))
    def matching(start,degree):
        out={}
        def visit(j, chosen):
            if j>=d:
                k=[0]*nv;k[0]=degree-2*len(chosen)
                for edge in chosen: k[edge+1]=1
                out[tuple(k)]=(-1)**len(chosen)
                return
            visit(j+1,chosen)
            visit(j+2,chosen+[j])
        visit(start,[])
        return out
    T,U=ts[d],us[d]
    need(T==matching(1,d),'T independent matching')
    need(U==matching(2,d-1),'U independent matching and edge start')
    for poly,degree in [(T,d),(U,d-1)]:
        for k in poly:
            need(k[0]+2*sum(k[1:d+1])==degree,'matching coefficient grade')
    F=add(mul(T,A),mul(mul(edges[0],U),M),-1)
    Fp=add(add(mul(deriv(T),A),mul(T,Ap)),
           mul(edges[0],add(mul(deriv(U),M),mul(U,Mp))),-1)
    S=add(mul(T,Fp),mul(deriv(T),F),-1)
    W=add(mul(deriv(U),T),mul(U,deriv(T)),-1)
    lead=mul(mul(T,T),Ap)
    corr1=mul(mul(edges[0],W),M)
    corr2=mul(mul(mul(edges[0],U),T),Mp)
    rhs=add(add(lead,corr1,-1),corr2,-1)
    need(S==rhs,'fraction-free witness')
    negatives={
      'omit_W_correction':add(lead,corr2,-1),
      'omit_Mprime_correction':add(lead,corr1,-1),
      'replace_T_squared_by_T':add(add(mul(T,Ap),corr1,-1),corr2,-1),
      'drop_TprimeF_subtraction':mul(T,Fp)
    }
    for name,wrong in negatives.items(): need(wrong!=S,'failed negative: '+name)
    # Plausible false alternative: the ordinary tail of degree d-1 starts at b_1.
    wrong0,wrong1=one,x
    for j in range(1,d-1): wrong0,wrong1=wrong1,add(mul(x,wrong1),mul(edges[j],wrong0),-1)
    need(wrong1!=U,'wrong associated edge start not rejected')
    return {'d':d,'T_terms':len(T),'U_terms':len(U),'witness_terms':len(S),
            'independent_matching':'PASS','witness':'PASS',
            'negative_controls_rejected':list(negatives)+['wrong_U_edge_start']}


def uadd(a,b,scale=1,p=None):
    z=dict(a)
    for k,v in b.items():
        z[k]=z.get(k,0)+scale*v
        if p: z[k]%=p
        if not z[k]:del z[k]
    return z


def ux(a):return {k+1:v for k,v in a.items()}
def uscale(a,z,p=None):return {k:(v*z if p is None else v*z%p) for k,v in a.items() if (v*z if p is None else v*z%p)}
def udiff(a):return {k-1:k*v for k,v in a.items() if k}
def umod(a,p):return {k:v%p for k,v in a.items() if v%p}


def hermite(n):
    a,b={0:1},{1:1}
    if n==0:return a
    for j in range(1,n):a,b=b,uadd(ux(b),a,j)
    return b


def associated(n):
    a,b={},{0:1}
    if n==0:return a
    for j in range(1,n):a,b=b,uadd(ux(b),a,j)
    return b


def urem(a,b,p):
    a=umod(a,p);b=umod(b,p)
    if not b:raise ZeroDivisionError
    n=max(b); inv=pow(b[n],-1,p)
    while a and max(a)>=n:
        k=max(a)-n; v=a[k+n]*inv%p
        a=uadd(a,{j+k:w for j,w in b.items()},-v,p)
    return a


def ugcd(a,b,p):
    a,b=umod(a,p),umod(b,p)
    while b:a,b=b,urem(a,b,p)
    return uscale(a,pow(a[max(a)],-1,p),p) if a else {}


def low_recurrence(n,p):
    # Evolve polynomial and ordinary derivative residues as two independent states.
    a,b={0:1},{1:1}; da,db={},{0:1}
    for j in range(1,n):
        nb=uadd(ux(b),a,j,p)
        nd=uadd(uadd(b,ux(db),p=p),da,j,p)
        a,b,da,db=b,nb,db,nd
    return b,db


def value_i(a):
    # Only used for even Hermite polynomials, so this is the exact integer M_c(i).
    need(all(k%2==0 for k in a),'even polynomial required')
    return sum(v*(-1)**(k//2) for k,v in a.items())


def controls():
    out={'status':'PASS','uniform_proof_is_not_finite_controls':True,
         'accepted_programs_executed':False,'symbolic':[symbolic(d) for d in (6,8)]}
    pivots=[]
    for c in (4,6,8,10,12,16,18):
        got={}
        terms=[]
        for l in range(1,c,2):
            u=(c-1-l)//2; coefficient=factorial(c)//(factorial(l)*2**u*factorial(u))
            got[l]=coefficient;terms.append([l,coefficient])
        want=uscale(hermite(c-1),c)
        need(got==want,'complete derivative pivot sum')
        need({c-1:got[c-1]}!=want,'single-pivot negative')
        need(udiff(hermite(c))==want,'integer ordinary derivative identity')
        pivots.append({'c':c,'pivot_count':len(terms),'pairs_l_and_coefficient':terms})
    out['complete_pivot_sums']=pivots
    aux=[]
    prev=0; even_df=1
    for m in range(1,9):
        if m>1:even_df*=2*m-2
        bm=even_df+(2*m-1)*prev;prev=bm
        need(associated(2*m).get(1,0)==bm,'associated linear recurrence')
        C=1
        for j in range(1,2*m,2):C*=j
        need(hermite(2*m).get(0)==C,'constant matching unit')
        aux.append({'d':2*m,'C_m':C,'b_m':bm})
    out['tail_constants_and_auxiliary_coefficients']=aux
    fixtures=[(7,6,6),(11,8,6),(13,12,12),(17,16,16),(19,10,8)]
    rows=[]
    for p,c,d in fixtures:
        N=p*p;n=c*N+d;m=d//2;B=N-p
        H=hermite(c);Hm=hermite(c-1);low=hermite(d);lowm=hermite(d-1)
        need(ugcd(H,Hm,p)=={0:1},'high consecutive Hermite gcd')
        frob={k*p:v%p for k,v in H.items() if v%p}
        dfrob={k*p:v%p for k,v in Hm.items() if v%p}
        need(ugcd(frob,dfrob,p)=={0:1},'central root/witness gcd')
        q,qd=low_recurrence(n,p)
        wantq={k+c*N:v%p for k,v in low.items() if v%p}
        wantd={k+c*N:d*v%p for k,v in lowm.items() if d*v%p}
        need(q==wantq,'original low polynomial residue')
        need(qd==wantd,'separately evolved ordinary low derivative residue')
        need(bool(qd),'discarded low derivative negative')
        need(ugcd(low,uscale(lowm,d),p)=={0:1},'low derivative gcd')
        C=aux[m-1]['C_m'];bm=aux[m-1]['b_m']
        need(C%p!=0 and c%p!=0,'boundary decisive units')
        epsilon=(-1)**((p-1)//2)
        actual=(-c*C*epsilon)%p
        copied=(-2*C*epsilon)%p
        need(actual!=copied,'copied c2 central scalar negative')
        hsign=(-1)**(c//2+m-1);copied_hsign=(-1)**m
        if c%4==0:need(hsign!=copied_hsign,'copied c2 H multiplier negative')
        K=c*N//2+c*B
        twoE=(c-1)*N+2*c*B
        twoD=(c+1)*N+2*c*B-2*p
        need(2*N+twoE+4*m-2-(twoD+4*m)==2*(p-1),'first witness gap')
        need(d+p**1*(c*N//p)==n,'degree check')
        rows.append({'p':p,'c':c,'d':d,'r':2,'minimal_s':3,'n':n,
         'high_total':c*N,'disks':p,'roots_per_high_disk':c*p,'low_count':d,
         'high_derivative_twice_value':twoD+2*m,'low_derivative_twice_value':n-1,
         'constant_value':K+m,'adjacent_obstruction_mod_p':value_i(H)%p,
         'auxiliary_b_m_mod_p':bm%p,'decisive_C_m_mod_p':C%p,
         'central_derivative_scalar_mod_p':actual,'H_multiplier_i_sign':hsign,
         'high_gcd_degree':0,'low_gcd_degree':0,
         'both_prime_boundaries':c==p-1 and d==p-1})
    out['fresh_residue_fixtures']=rows
    out['negative_controls_rejected']= ['single_selected_derivative_pivot','copied_c2_central_scalar',
       'copied_c2_H_multiplier_when_c_divisible_by_four','discarded_low_ordinary_derivative']
    return out


if __name__=='__main__':
    print(json.dumps(controls(),indent=2,sort_keys=True))
