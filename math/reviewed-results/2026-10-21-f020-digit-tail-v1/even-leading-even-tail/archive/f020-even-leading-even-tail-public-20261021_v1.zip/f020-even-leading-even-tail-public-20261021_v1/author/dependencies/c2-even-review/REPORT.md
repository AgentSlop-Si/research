# Independent review: uniform even tails after the leading digit two

21 October 2026 UTC. **ACCEPTED WITHIN THE EXACT STATED SCOPE.** No essential mathematical repair was supplied. The author and accepted dependencies were not changed. This accepts a frozen mathematical candidate, not a later public archive, publication, or delivery state.

## Exact artifact and theorem binding

The candidate is `f020-uniform-even-tail-candidate-20261021_v1`.

- Author manifest SHA-256: `c7b391df43fc8fb0fb14fab06ddd1d4e722d791469fc2593017ef27d8d9a88d3`.
- Author `REPORT.md` SHA-256: `bbd3966bc29ed35b3dc45831251d1aa58943139530d2e814f6511fade2965247`, 20,537 bytes.
- Exact author inventory: 128 bound files, plus its manifest and seal, in 15 directories. All byte counts, hashes, exact file/directory sets, and absence of symlinks were independently verified.

Let p be an odd prime, r>=2, s>r, N=p^r, and n=2N+d with d=2m and 2<=d<p. For every characteristic-zero primitive p^s-th root q, retain the original recurrence

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1)

and the original Gaussian H_n, original ordinary derivatives, and algebraic-square Christoffel-Darboux kernel. In a p-adic embedding set t=q-1, v(t)=1 and

    e=(p-1)p^(s-1), B=r(p-1)p^(r-1)/2,
    K=N+2B, E=N/2+2B, D=N+E-p.

Exactly d roots have value 1/2. For tau^2=t their distinct nonzero X/tau residues are the roots of

    M_d(Z)=d! sum_(k=0)^(d/2) Z^(d-2k)/(2^k k! (d-2k)!).

At them the original P_n derivative value is N+m-1/2, with normalized unit d Z^(2N) M_(d-1)(Z).

The other 2N roots are exactly 2L boundary roots in each of beta disjoint disks about x_a=i(q^(a/2)-q^(-a/2)), 0<=a<beta, with the square roots of q^a near 1, where

    h=floor(r/2), beta=p^h, L=N/beta,
    rho=beta/2 if r is even,
    rho=p^(h-1)(2p-1)/2 if r is odd.

Every high root has original derivative value D+m. Its X-value is rho centrally and p^ord_p(a) noncentrally. There is no zero root and v(P_n(0))=K+m. All original P_n and H_n roots are simple, corresponding ordinary H/P derivative valuations agree with their coordinate unit retained, and the original algebraic-square CD kernel is nonzero at every P_n root.

There is no unresolved exceptional prime or even tail within this scope. The previously accepted d=2 and d=4 specializations are not new credit; the extension is the simultaneous unrestricted admissible even-tail range d>=6. This verdict excludes p=2, d>=p, new odd-tail work, r=1 as new work, s<=r, composite orders, other leading digits, arbitrary degrees, arbitrary auxiliary finite characteristics, global F020/F023 closure, FFT or algorithmic-cost improvement, and historical novelty.

## Source boundary: coefficientwise facts, not an adjacent simplicity conclusion

The complete +4 author/review packages have manifest pins `034f2bc80d57645a26c29e9741c3f990bb4ee70a7d3bfb50be418e6b61abbe3d` and `464d13793dbd212d4b56e631ce009949fc55c966ed4396e26014f3a5b48725a5`. The nested +2 pair has pins `7c6c4cc80ff940e1b3a620727a096befc18d214770a9d27afb0cd3cb7372bc29` and `1bb903312caa601b4f5fff2a24e8dbad6fcc157f440639759eebbe22799800e0`. The nested general coefficientwise pair has pins `e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7` and `a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7`.

I read the original reports and accepting reviews, checked all six complete inventory trees, and checked the three accepting review-to-author/report bindings. No accepted predecessor program was executed. The general theorem's adjacent c=2,r=2 exception is not imported as simplicity or used to exclude a case here. Its Sections 2-5 establish the coefficientwise inputs separately from that adjacent exception.

For A=P_(2N), M=P_(2N-1), on each full supplied high disk the imported facts are

    wt(A)=K, in(A)=unit*(Zbar^2+1),
    wt(M)=E, in(M)=unit*Zbar,
    wt(A')=D, in(A')=unit*Zbar,
    wt(M')>=E, Zbar=alpha_a Y^L, alpha_a nonzero.

The A residual has a nonzero constant and degree 2L, and all higher coefficients have strictly greater weight. Every derivative here is the original characteristic-zero derivative, not the derivative of a reduced inseparable polynomial. Consequently M and A' have exact values E,D at **any point** of the residual locus Zbar^2+1=0. This is stronger than a statement only at A's own roots and applies at the new tail roots.

The source's uniform score argument checks the potentially delicate endpoints: its digitwise cap has equality only at 0,N,2N; its full Gaussian ordinary derivative has unique best increment p^2 and, for c=2, unique pivot m=N,k=N+p^2. When r=2 this is exactly k=2N, a legal endpoint. For M', the only candidate half-unit excesses have increments 1 or p. A strict cap deficit or the N-level carry removes both, yielding the full-disk bound E. In the original H/P conversion the prefactor derivative is retained; the A contribution has weight at least re+K>D. All these facts apply to p=3 and the smallest permitted s=r+1.

## Exact tail indexing, edge grades, and the decisive unit

Write a_j=1-q^(2N+j). The exact paired tail recurrence has

    T_0=1, T_1=X, U_0=0, U_1=1,
    T_(j+1)=X T_j-a_j T_(j-1),
    U_(j+1)=X U_j-a_j U_(j-1).

Induction in the original recurrence, with initial values A and XA-a_0M, gives

    F=P_(2N+d)=T_d A-a_0 U_d M.

The edge a_1 is correctly absent from U_d. In particular U_2=X and U_4=X^3-(a_2+a_3)X. Its degree is d-1, not d.

There is no denominator or zero-edge problem: n<pN<=p^s follows from (p-2)N-d>0, including p=3,d=2. Thus v(a_0)=N and a_0/t^N reduces to -2. For 1<=j<d<p, v(a_j)=1 and a_j/t reduces to -j.

The path-matching expansion makes the uniformity in d transparent. A T_(2m) monomial X^(2k) uses exactly m-k short edges. A U_(2m) monomial X^(2k+1) uses exactly m-1-k short edges. These are identities of multivariate polynomials before specialization, so cancellation cannot reduce the lower valuation bounds. The T constant is its unique perfect matching:

    T_(2m)(0)=(-1)^m a_1 a_3 ... a_(2m-1),
    T_(2m)(0)/t^m -> c_m=(2m-1)!!.

Every odd factor in c_m is below p, even at d=p-1. Therefore c_m is always a unit in the claimed range.

On every high disk x=wt(X)>=1. The central value is rho; noncentral values are p^ord_p(a)<rho. The weight of each nonconstant T term is at least m+k(2x-1)>m. Thus T_d/t^m has nonzero constant residual c_m on the entire disk, is an analytic unit there, and cannot vanish at any new high root. The graded U expansion and **ordinary** differentiation give

    wt(U_d)>=x+m-1, wt(U_d')>=m-1,
    wt(T_d')>=x+m-1.

With W_d=U_d'T_d-U_dT_d', both contributions are retained. Their lower bounds are 2m-1 and 2m+2x-2, respectively, so wt(W_d)>=2m-1. All inequalities remain true when any coefficient or point value vanishes. No generic-noncancellation premise has entered.

## High counts, all-term witness, and rootwise derivative values

The perturbation a_0 U_d M has weight at least N+E+x+m-1. Its gap above K+m is N/2+x-1>0. Thus F has the same normalized residual as A, multiplied by c_m. Its residual degree is exactly 2L, its constant is nonzero, and every higher coefficient is strictly above that level. The closed-disk Newton/Weierstrass count gives exactly 2L roots with multiplicity, all with nonzero Y residue and hence on the boundary. It does not require a simple residual in Y.

Distinct centers have separation valuation at most p^(h-1)<rho. Their disks are disjoint; these counts total 2N. At each such new root Zbar^2+1=0, so the imported coefficientwise residuals give the exact M and A' values E,D there.

Direct ordinary differentiation and subtraction give the complete polynomial identity

    S_d=T_d F'-T_d'F
       =T_d^2 A'-a_0 W_d M-a_0 U_d T_d M'.

At a new high root the first term has exact value D+2m. The two corrections have respective lower bounds

    N+E+2m-1 = D+2m+(p-1),
    N+E+x+2m-1 = D+2m+(p+x-1).

Both gaps are strictly positive for every supplied disk, and neither deteriorates with d. Thus v(S_d)=D+2m. Substituting F=0 in the exact identity gives S_d=T_dF', so v(F')=D+m. This proves high simplicity without assuming it in the root count.

The witness also has coefficientwise initial c_m^2 times that of A', nonzero on the residual root locus. This is not a whole-disk assertion wt(F')>=D+m: the T_d'F term can occur earlier away from roots. Its exact elimination before evaluating at a root is essential and is present in the author proof.

At r=2 the original central units are consistent with the accepted source. For mu^2=t^p and epsilon=(-1)^((p-1)/2), A(mu Y)/t^K reduces to (Y^2+1)^p and A'(mu Y)/(t^(3B)mu^p) to -2 epsilon Y^p. The new rootwise F' unit is -2 c_m epsilon Y^p with normalization t^(3B+m)mu^p. It is nonzero on the central residual roots, including p=3,d=2. No derivative of the repeated residual was substituted for it.

Since U_d is odd, F(0)=T_d(0)A(0), with value K+m. Hence an exact zero root is absent.

## Auxiliary cancellations and the empty exceptional set

The associated low-scale U residual satisfies V_0=0,V_1=1,V_(j+1)=ZV_j+jV_(j-1). At even d=2m its linear coefficient is

    b_0=0, b_m=(2m-2)!!+(2m-1)b_(m-1).

This follows by differentiating the V recurrence at zero and using V_(2m-1)(0)=(2m-2)!!. The leading possible U and W contributions are b_m X t^(m-1) and c_m b_m t^(2m-1). Since c_m is a unit, their first-tier cancellation is exactly p|b_m. The examples (p,d)=(5,4),(11,6),(31,8) satisfy that condition. Additional higher cancellations can only raise these weights.

The proof uses lower bounds for U and W, not equalities. Therefore p|b_m creates no unresolved root-lift obligation. In contrast, T's decisive constant never cancels for d<p. The high perturbation gap and both derivative gaps are positive throughout. Together with low Hermite separability below, these exhaust the proposed gates. Thus the no-exception conclusion is actually justified; it is not inferred from a finite list of tested prime/tail pairs. Outside d<p, the decisive constant and low separability may fail and no extension is accepted.

## Low recurrence, characteristic-p boundary, and degree exhaustion

Set Q_j=tau^(-j)P_j(tau Z) and R_j=tau^(1-j)P_j'(tau Z). The author evolves both original recurrences separately:

    Q_(j+1)=ZQ_j-[(1-q^j)/t]Q_(j-1),
    R_(j+1)=Q_j+ZR_j-[(1-q^j)/t]R_(j-1).

All coefficients are integral, and -[(1-q^j)/t] reduces to j modulo p, also when p divides j. Thus the reduction is M_(j+1)=ZM_j+jM_(j-1), together with its ordinary derivative recurrence.

The integer coefficient formula gives M_p=Z^p modulo p: every nonleading numerator contains p and each denominator is a unit. Starting with M_(ap), the coefficient at j=ap vanishes. Propagating the recurrence across the block gives M_(ap+b)=M_(ap)M_b through b=p, and M_(ap+p)=M_(ap)M_p. Induction gives M_(ap+b)=Z^(ap)M_b. This spells out the block endpoint implicit in the author argument, not a replacement assumption.

Since p divides 2N and d<p, the low reductions are

    Q_n -> Z^(2N)M_d(Z),
    R_n -> d Z^(2N)M_(d-1)(Z).

The integer identities M_d'=dM_(d-1) and M_j=ZM_(j-1)+(j-1)M_(j-2) imply gcd(M_d,M_(d-1))=1 in characteristic p: a common root propagates backward through the nonzero multipliers d-1,...,1 to M_0=1. Because d is a unit, M_d is squarefree, and because its constant is c_m it has no zero root. The stated exact formulas also check:

    Res(M_d,M_(d-1))=product_(j=1)^(d-1) j^j,
    Disc(M_d)=(-1)^(d(d-1)/2) product_(j=1)^d j^j.

The resultant follows recursively by the monic root-product formula; the discriminant follows from the derivative identity. Every possibly bad prime is at most d. There is no omitted characteristic-p degeneracy for d=p-1.

Simple-root Hensel lifting is used only for these d distinct nonzero low residues. It supplies exactly one root per residue, value 1/2, and the nonzero derivative unit above. Those roots lie outside every high disk because high X-values are at least 1. The multiplicity-aware total d+beta*(2L)=d+2N=n exhausts the monic degree. There are no further clusters, low residues, or zero roots.

## Original H, original algebraic-square CD kernel, and phases

The exact coordinate identities are

    H_n(v0^2)=v0^n P_n(X), X=v0+v0^(-1),
    H_n'(z)=v0^(n-2)[(n/2)P_n+(v0-v0^(-1))P_n'/2].

All proved P roots have positive valuation, hence are not +/-2. The branch v0 near i gives an analytic isometry to z near -1 with unit coordinate derivatives. It maps the n counted P roots to n distinct H roots and degree n exhausts H. At a root the P_n prefactor term vanishes exactly. The remaining multiplier is a unit with residue i^(n-1)=(-1)^m i. Equality of derivative valuations is valid; equality of normalized P/H units is not asserted.

All recurrence edges through n-1 are nonzero. A common P_n,P_(n-1) root would propagate back to P_0=1. The original telescoping CD identity at a P_n root xi is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
      =P_n'(xi)P_(n-1)(xi)/w_(n-1),
    w_j=product_(u=1)^j(1-q^u), w_0=1.

Every factor on the right is nonzero. These are algebraic squares, not absolute-value squares; no positivity, interlacing, or Hermitian replacement is used.

The proof uses the original mixed-characteristic lattice e=(p-1)p^(s-1). Integer p-divisibility can only raise the new bounds. For every primitive phase, its own t=q-1 provides the same unit and inequality argument in an algebraic p-adic embedding. Injectivity/Galois conjugacy transfers nonvanishing to every characteristic-zero primitive phase. This does not prove simplicity after reduction in arbitrary unrelated finite characteristics.

## Independent controls, replay, and limitations

The preceding uniform argument is the basis of acceptance. The separately written standard-library controls import no author/predecessor code and execute no accepted program. They check:

1. Exact generic-edge matching expansions against both tail recurrences for d=2,4,...,14; all edge grades/parities; all ordinary derivative factors; the complete fraction-free witness; and leading constants c_m,b_m. The d=14 W polynomial has 36,428 monomials, so this is actual finite algebra, not a zero-cost symbolic label.
2. Twenty-two explicit symbolic negative controls reject omission of either correction, substitution of T for T^2, and a wrong associated-edge start preserving degree. Separately evolved nonzero low derivatives also reject dropping that derivative.
3. The associated b_m recurrence through m=50, 567 permitted prime/tail low-Hermite gcd/constant fixtures through p=101, and nine complete original low/ordinary-derivative recurrence rows, including p=3, r=3 and d=p-1. These finite checks are not the uniform proof or an exhaustive exceptional-prime search.
4. Exact rational-q original H/P, complete ordinary prefactor derivative, and full algebraic-square CD identities through degree 12.

The author's new short-tail controls were inspected, then independently cold-replayed in normal and optimized Python, with byte-for-byte reference comparison. Only its new controls ran, not any predecessor programs or cyclotomic/all-phase rescans. The independent controls likewise pass cold replay in normal and optimized Python with exact stdout comparison. Replay uses isolated Python, disposable directories and stated resource limits; it is not an OS/network sandbox. Recorded timing is diagnostic, not a complexity bound.

The independent inventory verifier rejects twelve disposable mutations: changed/missing proof, extra file, extra empty directory, symlink, bad seal, fully rehashed replacement under the original external pin, duplicate member, unsafe path, negative or boolean byte count, and duplicate JSON key. Schema tests rebase only the disposable test pin to reach the intended gate. Normal and optimized mutation outputs agree byte-for-byte. Complete candidate and accepted-source inventories are rechecked without altering them.

The package contains reproducible scripts and retained receipts with actual hashes. Source verification, polynomial arithmetic, gcd work and replay are real work, not free preprocessing. No Fourier transform is computed and no asymptotic improvement is established.

## Final verdict

The frozen author candidate proves every asserted root-count, ordinary-derivative, original H/P, and original algebraic-square-kernel claim within n=2p^r+d, p odd prime, r>=2, s>r, even 2<=d<p, all characteristic-zero primitive phases. No essential proof repair or unresolved internal exception remains. No author/dependency bytes or external repository/document were modified. A distinct public-package/delivery audit remains separate from this mathematical acceptance.
