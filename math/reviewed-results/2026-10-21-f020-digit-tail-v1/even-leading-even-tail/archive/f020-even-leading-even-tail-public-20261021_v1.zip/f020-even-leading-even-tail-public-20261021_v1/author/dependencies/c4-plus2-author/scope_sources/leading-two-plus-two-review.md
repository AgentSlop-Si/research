# Independent review: first even tail after a leading two

21 October 2026 UTC. **ACCEPTED WITHIN THE EXACT STATED SCOPE.** No essential mathematical repair is required. The author candidate and its accepted sources remain unchanged. This review does not accept arbitrary degrees, later even tails, or global F020/F023 closure.

## Exact binding and result

The reviewed candidate is `f020-leading-two-plus-two-candidate-20261021_v1`.

- Candidate manifest SHA-256: `7c6c4cc80ff940e1b3a620727a096befc18d214770a9d27afb0cd3cb7372bc29`.
- Candidate report SHA-256: `261c545076813c7cddaa55b320a20fdfa3bed70b78039fb0f02b996341850a2c`, 13,054 bytes.
- Strict inventory: 59 bound files, plus manifest and seal. The complete file set, byte counts, hashes, and absence of symlinks were checked independently.
- Mathematical source author manifest: `e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7`.
- Mathematical source independent-review manifest: `a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7`.

Assume an odd prime p>=3, r>=2, s>r, N=p^r, n=2N+2, and any characteristic-zero primitive p^s-th root q. Preserve the original recurrence

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),

and the original Gaussian H, ordinary characteristic-zero derivatives, and algebraic-square Christoffel-Darboux kernel. In a p-adic embedding let t=q-1, v(t)=1, e=(p-1)p^(s-1), and

    B=r(p-1)p^(r-1)/2,
    K=N+2B, E=N/2+2B, D=3N/2+2B-p=N+E-p.

The accepted conclusion is exactly:

1. Two roots have v(X)=1/2. For tau^2=t and X=tau Z they have residual Z^2=-1, ordinary derivative value N+1/2, and actual normalized derivative unit 2Z^(2N+1)=-2Z.
2. With h=floor(r/2), beta=p^h, L=N/beta, rho=beta/2 for even r and rho=p^(h-1)(2p-1)/2 for odd r, each of the beta stated disjoint disks about x_a=i(q^(a/2)-q^(-a/2)) has precisely 2L boundary roots, initially counted with multiplicity. Every such root has ordinary derivative value D+1. Its X-value is rho centrally and p^ord_p(a) otherwise.
3. There is no zero root: v(P_n(0))=K+1. The above counts exhaust n, and all roots are simple.
4. Original H_n has the same root multiplicities and corresponding ordinary derivative valuations. The original algebraic-square CD kernel is nonzero at every original P_n root.

These conclusions include p=3 and every s>r and primitive phase. They do not cover even tails d>=4, r=1, other leading digits, p=2, s<=r, composite orders, arbitrary n, FFT/runtime improvement, historical novelty, or global closure. The r=1 family n=2p+2 is already contained in retained first-two-digit work and is not reclaimed.

## 1. Independent audit of inherited coefficientwise inputs

The retained general source is accepted for an adjacent-degree criterion, but the new proof uses its independently proved Sections 2-5, not an adjacent-degree simplicity conclusion. In particular it does not assume the old c=2 central odd-tail cancellation has disappeared.

Specialize the source to c=2, which is permitted for every odd prime including 3. Put A=P_(2N), M=P_(2N-1), a=1-q^(2N), b=1-q^(2N+1). On every required high disk the coefficientwise Gauss inputs are

    wt(A)=K, in(A)=unit*(Zbar^2+1),
    wt(M)=E, in(M)=unit*Zbar,
    wt(A')=D, in(A')=unit*Zbar,
    wt(M')>=E,
    Zbar=alpha_a Y^L, alpha_a nonzero.

These are valid on the whole disk as coefficientwise statements. Consequently the exact M and A' values hold at any point on the displayed residual root locus, not only at old A roots. That distinction is essential for the new F roots.

I reconstructed the source's weight argument. With W(m)=sum_(j<=m) p^ord_p(j), T(m)=sum_(j<=m) min(p^ord_p(j),rho), and R=W-T, the floor formulas are linear in the base-p digits below p^(r+1). At a digit p^d with h<=d<=r,

    R(p^d)=W(p^d)/2-(r-d)(p-1)p^(d-1)/2.

For d<h the deficit is strict as well. Thus on 0<=m<=2N the exact cap equality set is 0,N,2N. The block units give A's residual Zbar^2+1. Each complete N-block has exactly L variable factors, all other initial factors being nonzero constants; the disk centers are separated by valuation at most p^(h-1)<rho.

The exact Newton expansion is differentiated before reduction. Its derivative score is maximized first at d=k-u=p^j for fixed j=ord_p(k-u), then uniquely at j=2. Indeed g_j=p^j-j(p-1)p^(j-1)/2 has g_1>g_0, g_2>g_1, and is strictly decreasing afterward for all odd p. Cap equality and parity leave the sole c=2 pivot

    u=N, k=N+p^2.

It exists also at r=2, where k=2N and the remaining Q-index is zero. Its actual scalar is nonzero, yielding the Zbar derivative residual. There is no p=3 exception.

For the full M' expansion, the only apparent excess scores occur at derivative increments 1 and p, with excess 1/2. If u is not a multiple of N, the cap is strict. Otherwise parity makes u an even multiple of N, and the N-level floor term makes 2W(a0)<W(2a0) strict. Half-integrality therefore restores the bound wt(M')>=E for every term. This is not a bound on selected pivots only.

The source's H/P conversion keeps the prefactor derivative. For A it has weight at least re+K>D, since re>N/2-p already at the minimal s=r+1. For M its corresponding contribution has weight at least E. Thus the required ordinary P derivatives really inherit the stated coefficientwise inputs. They are not derivatives of the inseparable residual polynomial.

## 2. Exact transfer, all high disks, and the missing zero

Two original recurrence steps give, without a normalization change,

    F=P_(2N+2)=T A-a X M, T=X^2-b.

The index bound is strict: pN-(2N+2)=(p-2)N-2>=7. Therefore every recurrence edge and every inherited q-factorial denominator is nonzero. The edge valuations and actual units are v(a)=N, a/t^N -> -2, v(b)=1, b/t -> -1.

On a full high disk the Gauss weight x of X is rho centrally and p^ord_p(a) noncentrally; in particular x>=1. Hence T/t has initial 1 and is an analytic unit throughout that disk. The perturbation has weight at least N+E+x. Relative to the weight K+1 of TA its gap is

    N+E+x-(K+1)=N/2+x-1>0.

Thus F has exactly A's residual root polynomial up to a scalar unit. That residual has degree 2L and nonzero constant, and all higher coefficients have larger weight. The closed-disk Newton polygon therefore supplies exactly 2L roots on the boundary of each disk, counted with multiplicity; it supplies no root in the interior. This does not use simple-root Hensel on Y^L or presume separability.

There are beta disjoint disks, giving 2N roots. At every one the new root residual is Zbar^2+1=0, so Zbar is nonzero. The inherited exact values v(M)=E and v(A')=D therefore apply to these new roots. No deeper central displacement is needed, including at p=3.

At zero, F(0)=-b A(0). The base constant initial is nonzero and has value K, giving value K+1. Independently, the unchanged recurrence gives a nonzero even-degree constant product. No odd-polynomial exact-zero factor exists here.

## 3. Full ordinary derivative and the strict even-tail margin

The analytic quotient J=F/T=A-aRM, R=X/T, has

    R'=-(X^2+b)/T^2,
    J'=A'-aR'M-aRM'.

At each high root v(T)=1, v(R)=x-1, and v(R')=-1, because v(X^2)>v(b). The three terms have values

    D, N+E-1, at least N+E+x-1.

The correction gaps are exactly p-1 and at least p+x-1. Both are strictly positive for every odd p, including 3. Therefore v(J')=D, and at a root F'=TJ' has value D+1.

The fraction-free identity was independently expanded and checked with all terms retained:

    S=T F'-2X F
     =T^2 A'+a(X^2+b)M-aTXM'.

At a high root its terms have values D+2, N+E+1, and at least N+E+x+1. The same strict gaps show v(S)=D+2. Since S=TF' exactly on F=0, the same derivative conclusion follows without division.

This mechanism is genuinely different from the odd tail. The old M/X^2 correction can tie the base derivative, but here R' always has value -1. No odd-tail correction, scalar jet, or deeper lift is imported. In particular no central p=3 exception survives.

The candidate correctly avoids a whole-disk lower bound wt(F')>=D+1. The term 2XJ in F'=2XJ+TJ' may occur earlier away from roots. The independent exact controls confirm this: for p=3,r=2,s=3 the central whole-disk F' minimum is 45/2, whereas the actual high-root derivative value is 47/2. On the noncentral disks the minimum is 22. Only the witness or quotient derivative, followed by root substitution, proves the rootwise value.

At r=2 the actual inherited central derivative unit is

    A'/(t^(3B)mu^p) -> -2 epsilon Y^p,
    mu^2=t^p, epsilon=(-1)^((p-1)/2).

Multiplication by T/t -> 1 gives the claimed F' normalization t^(3B+1)mu^p. Its weight is D+1 and its value on Y^2=-1 is nonzero. The r=2 units and signs in the candidate are correct.

## 4. Two low roots, actual derivatives, and degree exhaustion

For tau^2=t, Q_j=tau^(-j)P_j(tau Z) and V_j=tau^(1-j)P_j'(tau Z) are integral. The second polynomial equals the actual Z derivative of Q_j, and its recurrence follows by differentiating the characteristic-zero recurrence before reduction.

The reductions satisfy M_(j+1)=Z M_j+j M_(j-1). In the integer formula for M_p, every nonleading coefficient contains p in its numerator and no p in its denominator, so M_p=Z^p modulo p. If M_(ap)=Z^(ap), the zero coefficient ap at the next step starts an independent block; induction through that block gives M_(ap+b)=Z^(ap)M_b. Therefore

    Q_n -> Z^(2N)(Z^2+1), V_n -> 2Z^(2N+1).

Each nonzero residual root has Z^2=-1 and derivative -2Z, nonzero for odd p. Ordinary Hensel lifting gives precisely one simple root in each of these two residual classes. Their X-values are 1/2 and their actual ordinary P derivative values are (n-1)/2=N+1/2. These roots are outside all high disks, whose points have valuation at least 1.

The count 2+beta*(2L)=2N+2 exhausts the monic degree. Thus no unexamined cluster or zero remains. This argument uses residue differentiation only where the reduced roots really are simple; it does not infer a high-root derivative from the zero high residual.

## 5. Original H, original algebraic-square kernel, and phases

The exact coordinate identities are

    H_n(v0^2)=v0^n P_n(v0+v0^(-1)),
    H_n'=v0^(n-2)[(n/2)P_n+(v0-v0^(-1))P_n'/2].

On the branch v0 near i, both coordinate derivatives are units because p is odd. All P roots proved above are small and hence not +/-2. The branch gives an analytic bijection of their local neighborhoods with the H roots near -1; degree n and the identity supply the complete correspondence. Multiplicities are preserved. At a root the prefactor term vanishes exactly, and the remaining multiplier is a unit with residue i^(n-1)=-i. Thus derivative valuations agree, without claiming identical normalized P and H units.

All original recurrence edges through n-1 are nonzero. A common root of P_n and P_(n-1) would propagate backward to P_0=1, which is impossible. Differentiating the original recurrence and telescoping the resulting Wronskian relation gives, at any root xi of P_n,

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
      =P_n'(xi)P_(n-1)(xi)/w_(n-1).

Every factor on the right is nonzero. These are algebraic squares, not absolute-value squares. No Hermitian, positivity, interlacing, or real-root assumption appears.

The proof uses the actual mixed-characteristic coefficientwise source with e=(p-1)p^(s-1), exact integral identities, and strict gaps. It makes no precision extrapolation as s varies. Each primitive phase can be embedded p-adically; all arguments apply to its own t=q-1. Injectivity and Galois conjugacy then give the asserted characteristic-zero nonvanishing at every phase. Valuation statements retain their specified p-adic normalization; they are not archimedean absolute-value claims.

## 6. Predecessor scope audit

The pinned all-odd-tail completion explicitly excludes even tails. The adjacent theorem is cp^r+1; the leading-digit theorem is cp^r. Neither implies 2p^r+2. Older low-tail packages with leading digit one likewise do not imply this family.

The retained first-two-digit theorem and its exact mathematical review cover 0<=b<min(p^2,p^s). Since 2p+2<p^2 for every odd p, including 8<9 at p=3, r=1 is already covered. For r>=2, 2p^r+2>p^2, so that theorem does not cover the new target. The retained later binding fixes the first-two-digit report/review bytes. The original separate first-two-digit final-byte receipt is not present; neither this review nor the author reconstructs or asserts that missing receipt.

This is a bounded audit of the retained predecessor scopes. It is not a literature novelty claim, a remote publication audit, or a claim that no other proof exists.

## 7. Independent controls, replay, integrity, and cost

The uniform proof above establishes the family. Finite checks only falsify transcription and implementation errors.

The independently written controls import no author or previous-review code. They compute the full unchanged recurrence in the direct Eisenstein basis t=q_base-1 modulo Phi_(p^s)(1+t) and p^m. This differs from the author's cyclic q-ring implementation. For convenient translation the controls use the exact algebraic re-expression B_j(U)=i^(-j)P_j(iU); it is explicitly derived from the original P recurrence and preserves all root derivative valuations. It is not a replacement theorem or normalization change.

All original integer derivative multipliers and p-divisibility are retained. The Eisenstein basis has distinct candidate coefficient values modulo e, and the actual leading unit p/t^e=-1 is used. Every precision ceiling is strictly higher than the inspected thresholds. Noncentral centers are computed exactly as q^(a/2)-q^(-a/2), with the inverse of 2 modulo the odd root order.

Completed independent tests:

- Exact rational-q tail and all-term witness identities at q=3/7 for seven even base degrees 2 through 14. An omitted factor 2X is rejected.
- Original Gaussian H/ordinary derivative and algebraic-square CD identities through degree 12.
- 52,360 complete Newton/ordinary-derivative pairs in six parameter rows, checking the exact cap equality set, the sole A' pivot, and every M' term.
- Four exact cyclotomic recurrence cases: (p,r,s,phase)=(3,2,3,1), (3,2,3,2), (5,2,3,1), (3,3,4,1), covering 11 central/noncentral disks. Each checks the low polynomial and ordinary derivative initials, every tested high disk's exact residual degree and constant, the full witness initial with its actual phase units, and gcd(F_initial,S_initial)=1.
- The invalid whole-disk F' shortcut is explicitly rejected at p=3.

The author's cold replay passed byte-for-byte under its stated caps. The independent cold replay passed byte-for-byte in 9.853 seconds under 60 CPU seconds, 90 wall seconds, 512 MiB address space, and 8 MiB output. Its deterministic semantic result SHA-256 is `dc228ec0b6596cdaca658b4083255e2d5d8c1256de37c0971cd989e0e74286b1`; the independent script SHA-256 is `23070c785639576858406da6c43ec9e2252c08d17f3175a98e01a299aa427fcd`.

Both mathematical dependency inventories, their review-to-author/report binding, and all 11 retained scope members were independently checked. Nine independent disposable inventory mutations were rejected: changed proof, missing member, unlisted member, symlink, changed seal, fully rehashed replacement, duplicate inventory member, unsafe path, and duplicate JSON key. The malformed-schema tests reach those checks under newly supplied test hashes; the replacement test retains the original external pin. Final sealed verification is retained separately. No candidate or accepted source was edited.

The candidate's stated ordinary-recurrence and diagnostic costs are appropriate. Neither its controls nor this review compute a Fourier transform or establish an asymptotic acceleration. Source verification, complete coefficient construction, translated-disk arithmetic, and replay are real verification work, not free preprocessing. No external repository, document, table, or Library write was performed.

## Final verdict

Every claimed mathematical assertion in the exact frozen candidate passes. No essential repair is needed. The newly accepted target is only n=2p^r+2 for odd p>=3, r>=2, s>r, all primitive phases, with the original P/H normalization and algebraic-square kernel. All later even tails and global F020/F023 closure remain outside this verdict.
