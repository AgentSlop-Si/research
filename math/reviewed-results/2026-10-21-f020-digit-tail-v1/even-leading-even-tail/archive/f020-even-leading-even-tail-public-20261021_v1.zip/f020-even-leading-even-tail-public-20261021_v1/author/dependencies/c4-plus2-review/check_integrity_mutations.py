#!/usr/bin/env python3
"""Disposable-copy integrity tests of this review's external-pin verifier."""
import argparse,hashlib,json,os,shutil,tempfile
from pathlib import Path
from verify_binding import verify
PIN='07682f06811d03a7df5cfdf966b885c206af0fc30b2414b8609b89eafe28a653'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();result=[]
    with tempfile.TemporaryDirectory(prefix='c4plus2-mutations-') as t:
        root=Path(t)/'candidate';shutil.copytree(args.candidate,root)
        for p in root.rglob('*'):p.chmod(0o755 if p.is_dir() else 0o644)
        root.chmod(0o755)
        verify(root,PIN)
        report=root/'REPORT.md';original=report.read_bytes();manifest=root/'MANIFEST.json';mb=manifest.read_bytes();seal=root/'SEAL.json';sb=seal.read_bytes()
        def reject(label):
            try:verify(root,PIN)
            except Exception as exc:result.append({'mutation':label,'rejected':True,'reason':str(exc)})
            else:raise RuntimeError('mutation accepted: '+label)
        report.write_bytes(original+b'\nChanged proof.\n');reject('proof_bytes');report.write_bytes(original)
        report.rename(root/'MISSING.md');reject('missing_bound_file');(root/'MISSING.md').rename(report)
        (root/'UNLISTED.txt').write_text('extra');reject('unlisted_file');(root/'UNLISTED.txt').unlink()
        seal.write_text(json.dumps({'manifest_sha256':'0'*64}));reject('seal_mismatch');seal.write_bytes(sb)
        report.unlink();report.symlink_to(root/'README.md');reject('symlink');report.unlink();report.write_bytes(original)
        (root/'empty_unlisted_directory').mkdir();reject('unlisted_directory');(root/'empty_unlisted_directory').rmdir()
        report.write_bytes(original+b'\nChanged proof.\n');m=json.loads(mb)
        for row in m['files']:
            if row['path']=='REPORT.md':row['bytes']=report.stat().st_size;row['sha256']=hashlib.sha256(report.read_bytes()).hexdigest()
        manifest.write_text(json.dumps(m,indent=2)+'\n');seal.write_text(json.dumps({'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}));reject('fully_rehashed_replacement_under_old_pin')
        report.write_bytes(original);manifest.write_bytes(mb);seal.write_bytes(sb);verify(root,PIN)
    args.output.write_text(json.dumps({'status':'PASS','author_files_modified':False,'source_programs_executed':False,'tests':result},indent=2,sort_keys=True)+'\n');print('PASS: seven disposable-copy integrity mutations rejected')
if __name__=='__main__':main()
