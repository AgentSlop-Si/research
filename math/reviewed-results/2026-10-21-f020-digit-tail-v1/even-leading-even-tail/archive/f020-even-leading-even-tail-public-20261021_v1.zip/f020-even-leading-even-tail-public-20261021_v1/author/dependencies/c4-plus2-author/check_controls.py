#!/usr/bin/env python3
"""New, bounded c=4,+2 controls. No accepted control program is imported/executed.
The cyclic-q -> primitive-cyclotomic -> t basis method follows the retained
leading-two +2 controls; the checked n=102,198 outputs and two-pivot gates are new.
Uses only Python standard library. No external writes or network.
"""
import json, math, sys
from pathlib import Path

def need(ok, msg):
    if not ok: raise RuntimeError(msg)
def vp(n,p):
    need(n!=0,'valuation of zero');v=0
    while n%p==0:n//=p;v+=1
    return v

def formal_identity():
    # Commutative formal ring in X,a,b,A,M,Ap,Mp.
    dim=7
    def var(k):
        e=[0]*dim;e[k]=1;return {tuple(e):1}
    def plus(*ps):
        out={}
        for poly in ps:
            for e,c in poly.items():out[e]=out.get(e,0)+c
        return {e:c for e,c in out.items() if c}
    def neg(poly):return {e:-c for e,c in poly.items()}
    def times(*ps):
        out={(0,)*dim:1}
        for poly in ps:
            nxt={}
            for e,c in out.items():
                for f,d in poly.items():
                    g=tuple(a+b for a,b in zip(e,f));nxt[g]=nxt.get(g,0)+c*d
            out={e:c for e,c in nxt.items() if c}
        return out
    def derivative(poly):
        out={}
        for e,c in poly.items():
            for k,target in ((0,None),(3,5),(4,6)):
                if e[k]:
                    f=list(e);f[k]-=1
                    if target is not None:f[target]+=1
                    f=tuple(f);out[f]=out.get(f,0)+c*e[k]
        return {e:c for e,c in out.items() if c}
    X,a,b,A,M,Ap,Mp=[var(k) for k in range(dim)]
    T=plus(times(X,X),neg(b));F=plus(times(T,A),neg(times(a,X,M)))
    original=plus(times(X,plus(times(X,A),neg(times(a,M)))),neg(times(b,A)))
    need(original==F,'two original recurrence steps')
    S=plus(times(T,derivative(F)),neg(times(derivative(T),F)))
    rhs=plus(times(T,T,Ap),times(a,plus(times(X,X),b),M),neg(times(a,T,X,Mp)))
    need(S==rhs,'full fraction-free ordinary witness')
    mutant=plus(times(T,derivative(F)),neg(times(X,F)))
    need(mutant!=S,'missing 2 in tail derivative must be rejected')
    return {'exact_two_step_identity':True,'exact_fraction_free_witness':True,'missing_2X_mutant_rejected':True}

def poly_add(a,b,p):
    out=[0]*max(len(a),len(b))
    for k,c in enumerate(a):out[k]=(out[k]+c)%p
    for k,c in enumerate(b):out[k]=(out[k]+c)%p
    return out

def low_controls():
    out=[]
    for p,r in ((5,2),(5,3),(7,2)):
        N=p**r;n=4*N+2;prev=[1];cur=[0,1];dprev=[0];dcur=[1]
        for j in range(1,n):
            nxt=poly_add([0]+cur,[j*x%p for x in prev],p)
            dnxt=poly_add(poly_add(cur,[0]+dcur,p),[j*x%p for x in dprev],p)
            prev,cur=cur,nxt;dprev,dcur=dcur,dnxt
        target=[0]*(n+1);target[4*N]=target[4*N+2]=1
        dtarget=[0]*n;dtarget[4*N+1]=2
        need(cur==target and dcur==dtarget,'c4 low original differentiated recurrence')
        need((2*N)%2==0,'low residual Z^(4N) must be +1')
        out.append({'p':p,'r':r,'n':n,'Q_nonzero':{str(k):c for k,c in enumerate(cur) if c},'V_nonzero':{str(k):c for k,c in enumerate(dcur) if c},'low_root_unit':'2Z, not -2Z','low_derivative_value_twice':4*N+1})
    return out

def trim(p):
    while len(p)>1 and p[-1]==0:p.pop()
    return p

def remainder(a,b,p):
    a=trim([x%p for x in a]);b=trim([x%p for x in b]);ib=pow(b[-1],-1,p)
    while a!=[0] and len(a)>=len(b):
        k=len(a)-len(b);c=a[-1]*ib%p
        for j,x in enumerate(b):a[j+k]=(a[j+k]-c*x)%p
        trim(a)
    return a

def gcd(a,b,p):
    a=trim(a[:]);b=trim(b[:])
    while b!=[0]:a,b=b,remainder(a,b,p)
    return [(x*pow(a[-1],-1,p))%p for x in a]

def determinant(a):
    from fractions import Fraction
    a=[[Fraction(x) for x in row] for row in a];d=Fraction(1)
    for k in range(len(a)):
        pivot=next((j for j in range(k,len(a)) if a[j][k]),None)
        if pivot is None:return 0
        if pivot!=k:a[k],a[pivot]=a[pivot],a[k];d=-d
        x=a[k][k];d*=x
        for j in range(k+1,len(a)):
            factor=a[j][k]/x
            for l in range(k+1,len(a)):a[j][l]-=factor*a[k][l]
    need(d.denominator==1,'integer determinant');return d.numerator

def pivot_controls():
    # Sylvester matrix for M4,M3, descending coefficients.
    f=[1,0,6,0,3];g=[1,0,3,0];mat=[]
    for k in range(3):mat.append([0]*k+f+[0]*(2-k))
    for k in range(4):mat.append([0]*k+g+[0]*(3-k))
    resultant=determinant(mat);need(resultant==108,'exact Hermite resultant')
    rows=[]
    for p,r in ((5,2),(5,3),(7,2)):
        N=p**r;B=r*(p-1)*p**(r-1)//2;K=2*N+4*B;E2=3*N+8*B;D2=5*N+8*B-2*p
        h=r//2;beta=p**h;L=N//beta;rho2=beta if r%2==0 else p**(h-1)*(2*p-1)
        pivots=[]
        for ell in (1,3):
            u=(3-ell)//2;coef=math.factorial(4)//(math.factorial(ell)*2**u*math.factorial(u))
            pivots.append({'m':ell*N,'k':ell*N+p*p,'residual_power':ell,'integer_coefficient':coef})
        need([(x['residual_power'],x['integer_coefficient']) for x in pivots]==[(1,12),(3,4)],'both derivative pivots')
        need(pivots[-1]['k']<=4*N,'last pivot in range')
        xs2={rho2}|{2*p**vp(a,p) for a in range(1,beta)}
        for x2 in xs2:
            need(2*N+E2+x2>2*K+2,'strict perturbation gap')
            need((2*N+E2+2)-(D2+4)==2*(p-1),'first witness gap')
            need((2*N+E2+x2+2)-(D2+4)==2*(p-1)+x2,'second witness gap')
        need(2+beta*4*L==4*N+2 and 4*N+2<p*N,'degree and cluster counts')
        need(gcd([3,0,6,0,1],[0,3,0,1],p)==[1],'no two-pivot cancellation on root locus')
        rows.append({'p':p,'r':r,'two_derivative_pivots':pivots,'last_is_endpoint':r==2,'first_witness_gap':p-1,'root_count':4*N+2,'high_disk_count':beta,'high_roots_per_disk':4*L})
    return {'exact_resultant':resultant,'rows':rows,'omitting_first_pivot_changes_polynomial':True}

class Cyclotomic:
    def __init__(self,p,s,power):
        self.p=p;self.s=s;self.power=power;self.mod=p**power;self.order=p**s;self.block=p**(s-1);self.e=(p-1)*self.block
        self.binoms=[[math.comb(d,j)%self.mod for j in range(d+1)] for d in range(self.e)]
    def recurrence(self,n):
        # Row k is the coefficient of X^(degree-2k), in the cyclic q basis.
        one=[0]*self.order;one[0]=1;previous=[one];current=[one[:]];saved={}
        for degree in range(1,n):
            nxt=[[0]*self.order for _ in range((degree+1)//2+1)]
            for k,row in enumerate(current):
                for d,c in enumerate(row):nxt[k][d]=(nxt[k][d]+c)%self.mod
            for k,row in enumerate(previous):
                for d,c in enumerate(row):
                    nxt[k+1][d]=(nxt[k+1][d]-c)%self.mod
                    pos=(d+degree)%self.order;nxt[k+1][pos]=(nxt[k+1][pos]+c)%self.mod
            previous,current=current,nxt
            if degree+1 in (n-2,n):saved[degree+1]=[row[:] for row in current]
        return saved
    def witness(self,poly,n):
        # S=(X^2-b)F'-2XF, b=1-q^(n-1). Every integer factor is retained.
        rows=[[0]*self.order for _ in range(len(poly)+1)]
        for k,row in enumerate(poly):
            power=n-2*k
            for d,c in enumerate(row):
                rows[k][d]=(rows[k][d]+(power-2)*c)%self.mod
                rows[k+1][d]=(rows[k+1][d]-power*c)%self.mod
                pos=(d+n-1)%self.order;rows[k+1][pos]=(rows[k+1][pos]+power*c)%self.mod
        # The final formally negative-power row is exactly zero.
        need(all(x==0 for x in rows[-1]),'zero negative-power witness row')
        return rows[:-1]
    def to_t(self,row):
        # First reduce mod Phi_(p^s); then q=1+t, retaining degree < e.
        base=row[:self.e]
        for j in range(self.block):
            c=row[self.e+j]
            for a in range(self.p-1):base[a*self.block+j]=(base[a*self.block+j]-c)%self.mod
        out=[0]*self.e
        for d,c in enumerate(base):
            if c:
                for j,b in enumerate(self.binoms[d]):out[j]=(out[j]+c*b)%self.mod
        return out
    def initial(self,poly,n,rho2,threshold2,derivative=False):
        out={};minimum=None
        for k,row in enumerate(poly):
            exponent=n-2*k;mult=exponent if derivative else 1;exponent-=int(derivative)
            if exponent<0 or mult==0:continue
            need(2*self.power*self.e+rho2*exponent>threshold2,'strict coefficient precision')
            vals=self.to_t([mult*c%self.mod for c in row]);best=None;unit=None
            for j,c in enumerate(vals):
                if c:
                    v=vp(c,self.p);wt=2*j+2*self.e*v+rho2*exponent
                    if best is None or wt<best:best=wt;unit=(c//self.p**v)*(-1)**v%self.p
            if best is not None:
                need(best>=threshold2,'coefficient below claimed threshold')
                minimum=best if minimum is None else min(minimum,best)
                if best==threshold2:out[exponent]=unit
        return out,minimum

def cyclotomic_controls():
    out=[]
    for p in (5,7):
        r=2;s=3;N=p*p;n=4*N+2;B=N-p;K=2*N+4*B;D2=5*N+8*B-2*p;e=(p-1)*p*p
        power=(D2+4)//(2*e)+1;ring=Cyclotomic(p,s,power);polys=ring.recurrence(n)
        Fi,Fmin=ring.initial(polys[n],n,p,2*K+2)
        Si,Smin=ring.initial(ring.witness(polys[n],n),n+1,p,D2+4)
        Di,_=ring.initial(polys[n-2],n-2,p,D2,derivative=True)
        expectedF={0:3%p,2*p:6%p,4*p:1};eps=(-1)**((p-1)//2)
        expectedS={p:(-12*eps)%p,3*p:(-4*eps)%p}
        need(Fi==expectedF,'new target original F initial')
        need(Si==expectedS and Si==Di,'new target witness with BOTH pivots')
        need(Fmin==2*K+2 and Smin==D2+4,'exact weights')
        f=[0]*(4*p+1);g=[0]*(3*p+1)
        for j,c in Fi.items():f[j]=c
        for j,c in Si.items():g[j]=c
        need(gcd(f,g,p)==[1],'new target F/S residuals are coprime')
        # Negative gate: dropping the lower pivot or copying c=2 units is wrong.
        need(Si!={3*p:(-4*eps)%p} and Fi!={0:1,2*p:1},'c2 extrapolation / missing pivot gate')
        out.append({'p':p,'r':r,'s':s,'n':n,'ramification':e,'coefficient_modulus_power':power,'coefficient_precision':power*e,'F_initial':Fi,'S_initial':Si,'base_ordinary_derivative_initial':Di,'F_value_twice':Fmin,'S_value_twice':Smin,'high_root_derivative_value_twice':D2+2,'F_S_residual_gcd':1,'missing_pivot_and_c2_mutants_rejected':True})
    return out

def main():
    result={'status':'PASS','finite_checks_are_not_uniform_proof':True,'accepted_programs_executed':False,'formal_transfer':formal_identity(),'two_pivot_and_scope_controls':pivot_controls(),'low_original_differentiated_recurrences':low_controls(),'new_original_cyclotomic_targets':cyclotomic_controls()}
    print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
