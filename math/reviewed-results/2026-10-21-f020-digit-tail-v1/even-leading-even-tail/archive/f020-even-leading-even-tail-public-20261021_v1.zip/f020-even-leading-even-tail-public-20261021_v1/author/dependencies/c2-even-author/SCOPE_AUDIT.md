# Scope comparison and stop conditions

The inspected +2 author/review explicitly proves n=2p^r+2 and excludes even d>=4. The inspected +4 author/review explicitly proves n=2p^r+4 and excludes other tails. Both are preserved byte-for-byte and accepted within their exact scopes. Their mathematical coefficientwise input is the nested general-author proof at c=2, not an odd-tail conclusion.

This candidate contains those two specializations but gives no new credit for them. Its new claimed scope is every remaining admissible even tail 6<=d<p at once, for r>=2 and s>r, all characteristic-zero primitive phases. In particular it is not a finite extension by selected small d. The separately completed odd-tail sector is neither imported nor altered.

The argument uses parity-specific tail polynomials. The even-tail decisive constant c_m=(2m-1)!! is a unit for p>d; the low Hermite discriminant has support only at primes <=d; and the full fraction-free derivative corrections have positive gaps p-1 and p+x-1. Auxiliary associated-Hermite slope cancellations p|b_m are explicitly retained and only improve these bounds. Consequently there is no unresolved exceptional set within the stated range.

At even d>=p+1, the decisive constant is divisible by p, so this proof does not extend. No assertion of nonsimplicity is made there. The proof also does not cover p=2, s<=r, composite orders, arbitrary base-p digit strings, different leading digits, or arbitrary degrees. The r=1 family is not newly claimed. It makes no all-finite-characteristic, historical-novelty, algorithmic-acceleration, FFT, or global F020/F023 statement.

The source inventories and accepting bindings were verified without executing any predecessor controls. All new finite checks are algebraic diagnostics, not replacements for a uniform proof. No unrelated supplied code is executed.

Stop conditions: this local author candidate stops at its exact frozen theorem and diagnostics. A separate reviewer must accept or reject these exact bytes. Public packaging and any external upload are distinct tasks and cannot be inferred from the author's self-assessment.
