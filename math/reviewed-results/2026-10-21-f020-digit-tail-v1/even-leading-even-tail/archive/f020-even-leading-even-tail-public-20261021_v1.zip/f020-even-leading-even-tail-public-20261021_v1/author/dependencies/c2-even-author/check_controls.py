#!/usr/bin/env python3
"""New short-tail controls only. No imports or execution of predecessor code."""
from fractions import Fraction
from itertools import combinations
from math import factorial, prod
from pathlib import Path
import argparse
import json


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sparse_add(a, b, scale=1):
    out = dict(a)
    for key, value in b.items():
        out[key] = out.get(key, 0) + scale * value
        if not out[key]:
            del out[key]
    return out


def sparse_mul(a, b):
    out = {}
    for x, u in a.items():
        for y, v in b.items():
            key = tuple(i + j for i, j in zip(x, y))
            out[key] = out.get(key, 0) + u * v
    return {k: v for k, v in out.items() if v}


def sparse_derivative(a):
    """Ordinary derivative: X'=1, A'=Ap, M'=Mp, edges constant."""
    out = {}
    for key, value in a.items():
        for source, target in ((0, None), (1, 3), (2, 4)):
            if key[source]:
                changed = list(key)
                changed[source] -= 1
                if target is not None:
                    changed[target] += 1
                t = tuple(changed)
                out[t] = out.get(t, 0) + value * key[source]
    return {k: v for k, v in out.items() if v}


def symbolic_row(d):
    width = d + 5
    zero = (0,) * width
    one = {zero: 1}

    def variable(index):
        x = list(zero)
        x[index] = 1
        return {tuple(x): 1}

    X, A, M, Ap, Mp = [variable(j) for j in range(5)]
    edge = [variable(j + 5) for j in range(d)]
    T = [one, X]
    U = [{}, one]
    F = [A, sparse_add(sparse_mul(X, A), sparse_mul(edge[0], M), -1)]
    for j in range(1, d):
        for seq in (T, U, F):
            seq.append(sparse_add(sparse_mul(X, seq[-1]), sparse_mul(edge[j], seq[-2]), -1))

    def matching(start, degree):
        out = {}
        for count in range((d - start + 2) // 2 + 1):
            for chosen in combinations(range(start, d), count):
                if any(b == a + 1 for a, b in zip(chosen, chosen[1:])):
                    continue
                exponent = degree - 2 * count
                if exponent < 0:
                    continue
                key = list(zero)
                key[0] = exponent
                for j in chosen:
                    key[j + 5] = 1
                out[tuple(key)] = (-1) ** count
        return out

    td, ud = T[d], U[d]
    need(td == matching(1, d), "T matching expansion")
    need(ud == matching(2, d - 1), "U shifted matching expansion")
    transfer = sparse_add(sparse_mul(td, A), sparse_mul(sparse_mul(edge[0], ud), M), -1)
    need(F[d] == transfer, "Original tail transfer")
    tp, up = sparse_derivative(td), sparse_derivative(ud)
    W = sparse_add(sparse_mul(up, td), sparse_mul(ud, tp), -1)
    S = sparse_add(sparse_mul(td, sparse_derivative(F[d])), sparse_mul(tp, F[d]), -1)
    first = sparse_mul(sparse_mul(td, td), Ap)
    second = sparse_mul(sparse_mul(edge[0], W), M)
    third = sparse_mul(sparse_mul(sparse_mul(edge[0], ud), td), Mp)
    witness = sparse_add(sparse_add(first, second, -1), third, -1)
    need(S == witness, "Complete fraction-free derivative witness")
    mutants = {
        "omit_M_correction": sparse_add(first, third, -1),
        "omit_Mprime_correction": sparse_add(first, second, -1),
        "replace_T_squared_by_T": sparse_add(sparse_add(sparse_mul(td, Ap), second, -1), third, -1),
    }
    for label, mutant in mutants.items():
        need(mutant != S, "Undetected mutant: " + label)
    wrong_u = matching(1, d - 1)
    if d >= 4:
        need(wrong_u != ud, "Undetected wrong associated-tail start")

    for key in td:
        need(key[0] % 2 == 0 and key[0] + 2 * sum(key[5:]) == d, "T edge grade")
    for key in ud:
        need(key[0] % 2 == 1 and key[0] + 2 * sum(key[5:]) == d - 1, "U edge grade")
    m = d // 2
    for x in (Fraction(1), Fraction(3, 2), Fraction(7, 2), Fraction(49, 2)):
        weight = lambda poly: min((key[0] * x + sum(key[5:]) for key in poly), default=float("inf"))
        need(weight(td) == m, "T weight")
        need(weight(ud) >= x + m - 1, "U weight")
        need(weight(up) >= m - 1 and weight(tp) >= x + m - 1, "Tail ordinary-derivative weights")
        need(weight(W) >= 2 * m - 1, "Wronskian weight")

    def edge_reduction(poly):
        out = [0] * (1 + max((key[0] for key in poly), default=0))
        for key, value in poly.items():
            factor = value * prod((-j) ** key[j + 5] for j in range(1, d))
            out[key[0]] += factor
        return trim(out)

    mt, vu = edge_reduction(td), edge_reduction(ud)
    need(mt == hermite(d), "Scaled T Hermite residual")
    need(vu == associated(d), "Scaled U associated-Hermite residual")
    c = prod(range(1, d, 2))
    b = vu[1]
    need(mt[0] == c, "Decisive constant")
    w_reduced = edge_reduction(W)
    need(w_reduced[0] == c * b, "Exact leading W cancellation coefficient")
    return {
        "d": d, "T_terms": len(td), "U_terms": len(ud),
        "witness_terms": len(S), "c_m": c, "b_m": b,
        "negative_mutants_rejected": list(mutants) + (["wrong_associated_tail_start"] if d >= 4 else []),
    }


def trim(a):
    a = list(a)
    while a and a[-1] == 0:
        a.pop()
    return a


def add(a, b, scalar=1, p=None):
    c = [0] * max(len(a), len(b))
    for j, x in enumerate(a):
        c[j] += x
    for j, x in enumerate(b):
        c[j] += scalar * x
    return trim([x % p for x in c] if p else c)


def derivative(a, p=None):
    b = [j * a[j] for j in range(1, len(a))]
    return trim([x % p for x in b] if p else b)


def hermite(n):
    out = [0] * (n + 1)
    for k in range(n // 2 + 1):
        out[n - 2 * k] = factorial(n) // (2**k * factorial(k) * factorial(n - 2 * k))
    return out


def associated(n):
    a, b = [], [1]
    if n == 0:
        return a
    for j in range(1, n):
        a, b = b, add([0] + b, a, j)
    return b


def remainder(a, b, p):
    a, b = trim([x % p for x in a]), trim([x % p for x in b])
    need(bool(b), "Division by zero polynomial")
    inv = pow(b[-1], -1, p)
    while len(a) >= len(b):
        c = a[-1] * inv % p
        offset = len(a) - len(b)
        for j in range(len(b)):
            a[j + offset] = (a[j + offset] - c * b[j]) % p
        a = trim(a)
    return a


def gcd(a, b, p):
    a, b = trim([x % p for x in a]), trim([x % p for x in b])
    while b:
        a, b = b, remainder(a, b, p)
    if not a:
        return []
    inv = pow(a[-1], -1, p)
    return [(x * inv) % p for x in a]


def low_original_row(p, r, d):
    n = 2 * p**r + d
    q0, q1, v0, v1 = [1], [0, 1], [], [1]
    for j in range(1, n):
        q2 = add([0] + q1, q0, j, p)
        v2 = add(add(q1, [0] + v1, p=p), v0, j, p)
        q0, q1, v0, v1 = q1, q2, v1, v2
    expected_q = [0] * (2 * p**r) + [x % p for x in hermite(d)]
    expected_v = [0] * (2 * p**r) + [(d * x) % p for x in hermite(d - 1)]
    expected_q, expected_v = trim(expected_q), trim(expected_v)
    need(q1 == expected_q, "Full low original recurrence residual")
    need(v1 == expected_v == derivative(q1, p), "Separately evolved original ordinary derivative")
    need(bool(v1), "Nonzero low derivative")
    need([] != expected_v, "Undetected omitted low ordinary derivative")
    md = [x % p for x in hermite(d)]
    need(md[0] != 0 and gcd(md, derivative(md, p), p) == [1], "Low residual squarefree and nonzero")
    return {"p": p, "r": r, "d": d, "n": n, "low_root_count": d, "derivative_twice_value": n - 1}


def run():
    symbolic = [symbolic_row(d) for d in range(2, 13, 2)]
    b, cancellation_rows = 0, []
    for row in symbolic:
        d, m = row["d"], row["d"] // 2
        b = prod(range(2, 2 * m, 2)) + (2 * m - 1) * b
        need(b == row["b_m"], "b_m scalar recurrence")
    for p, d in ((5, 4), (11, 6), (31, 8), (193, 10)):
        c = prod(range(1, d, 2))
        b = associated(d)[1]
        need(c % p != 0 and b % p == 0 and (c * b) % p == 0, "Harmless auxiliary cancellation fixture")
        need(gcd(hermite(d), derivative(hermite(d)), p) == [1], "No low collision at auxiliary cancellation")
        cancellation_rows.append({"p": p, "d": d, "c_mod_p": c % p, "b_m": b, "low_gcd_degree": 0})

    hermite_rows = []
    for p in (3, 5, 7, 11, 13, 31):
        for d in range(2, p, 2):
            md, predecessor = hermite(d), hermite(d - 1)
            need(derivative(md) == [d * x for x in predecessor], "Integer Appell identity")
            need(md[0] % p != 0 and gcd(md, derivative(md), p) == [1], "Characteristic-p low nondegeneracy")
            hermite_rows.append([p, d])
    forbidden = []
    for p, d in ((3, 4), (3, 6), (5, 6)):
        md = hermite(d)
        need(md[0] % p == 0 and len(gcd(md, derivative(md), p)) > 1, "Forbidden-range negative fixture")
        forbidden.append({"p": p, "d": d, "gcd_degree": len(gcd(md, derivative(md), p)) - 1})

    low = [low_original_row(*row) for row in ((7, 2, 6), (11, 2, 6), (11, 2, 10), (7, 3, 6))]
    gaps = []
    for p, r, d in ((3, 2, 2), (7, 2, 6), (7, 3, 6), (11, 2, 6), (31, 2, 8), (11, 3, 10)):
        N, m, h = p**r, d // 2, r // 2
        B = Fraction(r * (p - 1) * p**(r - 1), 2)
        K, E = N + 2 * B, Fraction(N, 2) + 2 * B
        D = N + E - p
        rho = Fraction(p**h, 2) if r % 2 == 0 else Fraction(p**(h - 1) * (2 * p - 1), 2)
        for x in {Fraction(1), rho}:
            root_gap = N + E + x + m - 1 - (K + m)
            gap_m = N + E + 2 * m - 1 - (D + 2 * m)
            gap_mp = N + E + x + 2 * m - 1 - (D + 2 * m)
            need(root_gap == Fraction(N, 2) + x - 1 > 0, "Root perturbation gap")
            need(gap_m == p - 1 > 0 and gap_mp == p + x - 1 > 0, "Both predecessor derivative gaps")
        need(2 * N + d < p * N, "Order bound")
        gaps.append({"p": p, "r": r, "d": d, "minimum_derivative_gap": p - 1})
    return {
        "status": "PASS_NEW_CONTROLS_ONLY",
        "symbolic_tail_rows": symbolic,
        "auxiliary_cancellation_rows": cancellation_rows,
        "low_Hermite_pairs": hermite_rows,
        "forbidden_range_negative_rows": forbidden,
        "full_low_recurrence_rows": low,
        "exact_weight_gap_rows": gaps,
        "predecessor_controls_executed": False,
        "full_cyclotomic_controls_repeated": False,
        "external_writes": False,
        "finite_controls_are_uniform_proof": False,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args()
    data = json.dumps(run(), indent=2, sort_keys=True) + "\n"
    if args.write:
        Path("CONTROL_RESULTS.json").write_text(data)
    print(data, end="")


if __name__ == "__main__":
    main()
