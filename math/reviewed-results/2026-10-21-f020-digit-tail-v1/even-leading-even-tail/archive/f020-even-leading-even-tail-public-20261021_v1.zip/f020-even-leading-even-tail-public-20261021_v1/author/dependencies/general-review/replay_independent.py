#!/usr/bin/env python3
import argparse,hashlib,json,os,resource,shutil,subprocess,sys,tempfile,time
from pathlib import Path


def scrub(x):
    if isinstance(x,dict):return {k:scrub(v) for k,v in x.items() if k!='elapsed_seconds'}
    if isinstance(x,list):return [scrub(v) for v in x]
    return x

def caps():
    resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--script',required=True);ap.add_argument('--reference',required=True);ap.add_argument('--outdir',required=True);args=ap.parse_args()
    out=Path(args.outdir);out.mkdir(parents=True,exist_ok=True);script=Path(args.script);start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='independent-adjacent-cold-') as td:
        d=Path(td);shutil.copyfile(script,d/'independent_controls.py')
        env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
        cp=subprocess.run([sys.executable,str(d/'independent_controls.py'),'--mode','all','--output',str(d/'RESULTS.json')],cwd=d,env=env,capture_output=True,text=True,timeout=180,preexec_fn=caps)
        (out/'INDEPENDENT_COLD_RUN.log').write_text(cp.stdout+cp.stderr)
        assert cp.returncode==0,(cp.returncode,cp.stdout,cp.stderr)
        data=(d/'RESULTS.json').read_bytes();ref=Path(args.reference).read_bytes()
        assert scrub(json.loads(data))==scrub(json.loads(ref)),'semantic cold replay mismatch'
        (out/'INDEPENDENT_COLD_RESULTS.json').write_bytes(data)
        normalized=(json.dumps(scrub(json.loads(data)),sort_keys=True,separators=(',',':'))+'\n').encode()
        receipt={'status':'PASS','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'semantic_results_sha256':hashlib.sha256(normalized).hexdigest(),'result_sha256':hashlib.sha256(data).hexdigest(),'elapsed_seconds':round(time.monotonic()-start,3),'caps':{'cpu_seconds':120,'wall_seconds':180,'address_space_bytes':2*1024**3,'output_bytes':32*1024**2,'numerical_threads':1},'comparison':'Exact JSON equality after removing timing-only elapsed_seconds fields','author_code_imported':False}
        (out/'INDEPENDENT_COLD_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
