#!/usr/bin/env python3
"""Bounded cold replay of this review's own controls only."""
import argparse,hashlib,json,os,resource,subprocess,sys,tempfile,time
from pathlib import Path

def normalized(data):
    if isinstance(data,dict):return {k:normalized(v) for k,v in data.items() if k!='elapsed_seconds'}
    if isinstance(data,list):return [normalized(v) for v in data]
    return data

def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024**2,8*1024**2))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();root=Path(__file__).resolve().parent
    expected=normalized(json.loads((root/'controls/INDEPENDENT_RESULTS.json').read_text()));receipts=[]
    with tempfile.TemporaryDirectory(prefix='c4plus2-independent-') as temp:
        temp=Path(temp)
        for opt in [False,True]:
            dest=temp/('optimized.json' if opt else 'normal.json');cmd=[sys.executable]+(['-O'] if opt else [])+[str(root/'independent_controls.py'),'--output',str(dest)]
            t=time.monotonic();proc=subprocess.run(cmd,cwd=temp,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'},text=True,capture_output=True,timeout=90,preexec_fn=limits)
            if proc.returncode!=0:raise RuntimeError(proc.stderr)
            actual=normalized(json.loads(dest.read_text()))
            if actual!=expected:raise RuntimeError('semantic cold-replay mismatch')
            receipts.append({'optimization':opt,'status':'PASS','semantic_output_equal':True,'elapsed_seconds':round(time.monotonic()-t,6)})
    result={'status':'PASS','accepted_programs_executed':False,'limits':{'cpu_seconds':60,'wall_seconds':90,'address_space_bytes':1024**3,'output_bytes':8*1024**2},'script_sha256':hashlib.sha256((root/'independent_controls.py').read_bytes()).hexdigest(),'semantic_result_sha256':hashlib.sha256(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'runs':receipts}
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print('PASS: own independent normal and optimized cold replays')
if __name__=='__main__':main()
