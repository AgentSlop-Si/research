# Uniform even-tail transfer after the leading digit two

Author candidate, 21 October 2026 UTC. Original F020 normalization. This report proves a uniform even-tail theorem from accepted coefficientwise inputs. It does not infer even parity from an odd-tail theorem, rerun accepted controls, accept itself, claim historical novelty, or claim global F020/F023 or FFT completion.

## 1. Statement and exact scope

Let p be an odd prime, r>=2, s>r, N=p^r, and d=2m satisfy 2<=d<p. Let q have exact characteristic-zero order p^s. Retain the ORIGINAL definitions

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_j(z)=sum_k [j choose k]_q z^k,
    n=2N+d.

In an algebraic p-adic embedding put t=q-1, v(t)=1, and define

    e=v(p)=(p-1)p^(s-1), B=r(p-1)p^(r-1)/2,
    K=N+2B, E=N/2+2B, D=N+E-p,
    h=floor(r/2), beta=p^h, L=N/beta,
    rho=beta/2                         if r is even,
    rho=p^(h-1)(2p-1)/2                if r is odd,
    c_m=(2m-1)!!.

THEOREM. The original P_n and H_n are squarefree, and the original algebraic-square Christoffel-Darboux kernel is nonzero at every P_n root, for all these parameters and every primitive phase. There is no unresolved exceptional prime or tail inside 2<=d<p, d even.

The complete P_n partition, including original ordinary-derivative values, is:

1. Exactly d low roots, all with v(X)=1/2. For tau^2=t and X=tau Z, their distinct nonzero residues are all the roots of

       M_d(Z)=d! sum_(k=0)^m Z^(d-2k)/(2^k k! (d-2k)!).

   At every such root,

       v(P_n'(X))=(n-1)/2=N+m-1/2,
       P_n'(X)/tau^(n-1) -> d Z^(2N) M_(d-1)(Z) !=0.

2. Exactly 2L high roots on the boundary of each of the beta disjoint disks

       v(X-x_a)>=rho,
       x_a=i(q^(a/2)-q^(-a/2)), 0<=a<beta, i^2=-1,

   with square roots of q^a congruent to 1. These 2N roots have

       v(P_n'(X))=D+m.

   Their X-values are rho in the central disk and p^ord_p(a) otherwise. Counts retain multiplicity until the derivative proof.

There is no zero root; v(P_n(0))=K+m. The corresponding original H_n root derivatives have the same valuations, with the exact coordinate multiplier retained below.

The statement contains the previously accepted +2 and +4 cases as specializations; those are not newly credited. Its added scope is all admissible even d>=6, simultaneously, not a finite collection of tested tails. Excluded are p=2, odd tails as new work, d>=p, r=1 as new work, s<=r, composite orders, other leading digits, arbitrary n, arbitrary auxiliary finite-characteristic simplicity, global F020/F023 closure, and algorithmic or historical-novelty claims. A fresh independent review of these exact candidate bytes is still required.

## 2. Accepted coefficientwise input and immutable provenance

The unchanged accepted +4 author/review packages are copied completely under dependencies, with manifest SHA-256 pins

    plus-four-author: 034f2bc80d57645a26c29e9741c3f990bb4ee70a7d3bfb50be418e6b61abbe3d
    plus-four-review: 464d13793dbd212d4b56e631ce009949fc55c966ed4396e26014f3a5b48725a5.

They contain unchanged complete +2 author/review packages with pins

    plus-two-author: 7c6c4cc80ff940e1b3a620727a096befc18d214770a9d27afb0cd3cb7372bc29
    plus-two-review: 1bb903312caa601b4f5fff2a24e8dbad6fcc157f440639759eebbe22799800e0.

The nested complete general coefficientwise author/review pins are

    general-author: e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7
    general-review: a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7.

All six inventories and review-to-author/report bindings are checked by newly written inventory code. No accepted control program is executed. The +2 and +4 reports, their independent reviews, and Sections 2-5 of the nested general report were read. We use the following coefficientwise facts specialized to c=2, not an adjacent or odd-tail simplicity conclusion.

Put A=P_(2N), M=P_(2N-1). On EACH full high disk X=x_a+lambda Y, v(lambda)=rho,

    wt(A)=K,    in(A)=unit*(Zbar^2+1),
    wt(M)=E,    in(M)=nonzero scalar*Zbar,
    wt(A')=D,   in(A')=nonzero scalar*Zbar,
    wt(M')>=E, Zbar=alpha_a Y^L, alpha_a!=0.

Here wt is the coefficientwise Gauss weight, in uses the actual scalar normalizations of the accepted source, and every derivative is an ordinary characteristic-zero derivative formed before reduction. The constant term of the normalized A residual is nonzero, and all coefficients above degree 2L have strictly greater weight. In particular v(A(0))=K on the central disk.

These facts hold for every odd p, including p=3. They imply the EXACT values v(M)=E and v(A')=D at every point of the residual locus Zbar^2+1=0, not merely at roots of a predecessor polynomial. This distinction licenses evaluation at the new tail roots.

For audit, the accepted proof derives the coefficientwise input from the exact Gaussian Newton expansion and its complete ordinary derivative. Its cap R(j)<=W(j)/2 has equality only at 0,N,2N on the relevant interval. The full A' score has unique increment p^2 and, for c=2, unique pivot u=N, k=N+p^2, including k=2N when r=2. Every M' term is bounded; the apparent increments 1 and p are eliminated by either strict cap deficit or an N-level floor carry. The H/P coordinate transfer retains the prefactor derivative, whose A contribution has weight at least re+K>D. These are mixed-characteristic coefficientwise statements, not differentiation of an inseparable residue.

## 3. The exact tail polynomials and a reusable sufficient criterion

Set a_j=1-q^(2N+j) for j>=0. Define two polynomials over the original coefficient field by

    T_0=1, T_1=X, U_0=0, U_1=1,
    T_(j+1)=X T_j-a_j T_(j-1),
    U_(j+1)=X U_j-a_j U_(j-1)             (j>=1).

Induction in the ORIGINAL recurrence gives, exactly and without renormalization,

    F:=P_(2N+d)=T_d A-a_0 U_d M.                              (3.1)

The second polynomial is indexed U_d and has degree d-1. For example U_2=X and U_4=X^3-(a_2+a_3)X, so its missing a_1 is deliberate. Define the complete fraction-free witness

    W_d=U_d'T_d-U_d T_d',
    S_d=T_d F'-T_d'F
       =T_d^2 A'-a_0 W_d M-a_0 U_d T_d M'.                    (3.2)

Every derivative of every factor is retained. This identity alone does not prove simplicity; the rootwise strict weight separation below does.

A reusable sufficient transfer criterion is the following. On each supplied high disk let x=wt(X), and suppose that for an integer m:

    (i)  wt(T_d)=m, with normalized residual a nonzero constant;
    (ii) wt(U_d)>=x+m-1, wt(W_d)>=2m-1;
    (iii) N/2+x-1>0 and p>1.

Together with the accepted A,M,A',M' input, these conditions give the same 2N high-root count as A and exact high derivative value D+m. If the low reduction is Z^(2N) M_d(Z), M_d has degree d, nonzero constant and gcd(M_d,M_d')=1, then d distinct low roots complete the degree and prove the whole assertion. This criterion is an explicit tail-polynomial and residue test independent of unknown lifted roots. Sections 4-7 prove every condition uniformly in the requested range.

## 4. Uniform tail weights, with no generic-noncancellation assumption

The order check is uniform:

    n=2N+d < pN <= p^s,
    (p-2)N-d >= (p-2)p^2-(p-1)>0.

Thus every original recurrence edge used and every imported denominator is nonzero. The exact initial edge data are

    v(a_0)=N, a_0/t^N -> -2,
    v(a_j)=1, a_j/t -> -j       (1<=j<=d-1<p).

Only the latter short-tail edges enter T_d and U_d. By induction, or the path-matching expansion of this tridiagonal recurrence, T_(2m) is even and its coefficient of X^(2k) is an integer sum of products of exactly m-k edges. Hence that coefficient has value at least m-k. Its constant is the single perfect matching

    T_(2m)(0)=(-1)^m a_1 a_3 ... a_(2m-1),
    T_(2m)(0)/t^m -> c_m=(2m-1)!! !=0 modulo p.              (4.1)

Similarly U_(2m) is odd and its coefficient of X^(2k+1) is an integer sum of products of exactly m-1-k edges. It has value at least m-1-k. The assertion includes zero coefficients, with value infinity. It follows by the same recurrence: multiplying by X increases degree by one without adding an edge, while the other summand adds one edge and shifts the index by two. The base cases T_0,T_1,U_0,U_1 establish both assertions.

The Gauss weight x of X on a full high disk is rho centrally and p^ord_p(a) noncentrally, so x>=1. Every nonconstant T term has weight at least

    m-k+2kx=m+k(2x-1)>m          (k>=1).

Therefore T_d/t^m has constant residual c_m and is an analytic unit everywhere on the disk, including all points later used as roots. The polynomial has no zero on these disks. Direct ordinary differentiation, retaining the integer multipliers, gives

    wt(U_d)>=x+m-1,
    wt(U_d')>=m-1,
    wt(T_d')>=x+m-1.

Consequently

    wt(U_d'T_d)>=2m-1,
    wt(U_d T_d')>=2m+2x-2 >=2m,
    wt(W_d)>=2m-1.                                           (4.2)

Every displayed inequality is valid even if some coefficients cancel modulo p or at individual points. No lower bound relies on any auxiliary coefficient being a unit. The only asserted decisive unit is c_m; all its odd factors are strictly below p. No large-d loss appears in these estimates.

## 5. Complete high-root counts and fraction-free derivative separation

By (3.1), the perturbation has coefficientwise weight at least

    N+E+x+m-1 = K+m+(N/2+x-1)>K+m.                          (5.1)

Thus wt(F)=K+m and its normalized residual is c_m times the accepted normalized A residual. Its residual degree in Y is 2L, its constant is nonzero, and all higher coefficients have strictly greater normalized weight. The closed-disk Newton/Weierstrass count gives exactly 2L roots counted with multiplicity in each disk, all with nonzero Y residue and thus all on the boundary. This is NOT a simple-root Hensel argument on the inseparable substitution Y^L.

The centers have pairwise separation valuation at most p^(h-1)<rho; their disks are disjoint. The counts total beta*2L=2N. At each new high root the residual equation is Zbar^2+1=0. Hence the accepted coefficientwise input gives the exact values E and D for M and A' at that new root.

At such a root the three terms in (3.2) have values

    T_d^2 A':       D+2m, exactly;
    -a_0 W_d M:     >=N+E+2m-1 = D+2m+(p-1);
    -a_0 U_d T_d M':>=N+E+x+2m-1 = D+2m+(p+x-1).

The gaps p-1 and p+x-1 are positive, independent of d, r, s, and all auxiliary cancellations. Therefore

    v(S_d)=D+2m.

At a root F=0 the exact polynomial identity S_d=T_d F' holds. Since v(T_d)=m everywhere on the disk,

    v(F')=D+m.                                               (5.2)

This proves the high roots are simple. It also provides the coefficientwise witness initial c_m^2 times that of A', nonzero on the entire residual root locus. No whole-disk claim wt(F')>=D+m is made. The term involving T_d' in F' can occur earlier away from roots; it is eliminated exactly by S_d before substituting F=0.

Equivalently, the analytic identity J=F/T_d=A-a_0(U_d/T_d)M has derivative

    J'=A'-a_0(W_d/T_d^2)M-a_0(U_d/T_d)M'.

The same gaps follow from wt(W_d/T_d^2)>=-1 and wt(U_d/T_d)>=x-1. The fraction-free proof above needs no division in its controls.

At zero, U_d(0)=0 and (4.1) gives F(0)=T_d(0)A(0), whence v(F(0))=K+m. There is no exact-zero factor in this even-tail argument.

For an actual central unit at r=2, let mu^2=t^p and epsilon=(-1)^((p-1)/2). The accepted original P units give

    A(mu Y)/t^K ->(Y^2+1)^p,
    A'(mu Y)/(t^(3B)mu^p) ->-2 epsilon Y^p.

Thus uniformly in d,

    F(mu Y)/t^(K+m) ->c_m (Y^2+1)^p,
    S_d(mu Y)/(t^(3B+2m)mu^p) ->-2 c_m^2 epsilon Y^p,
    F'(mu Y)/(t^(3B+m)mu^p) ->-2 c_m epsilon Y^p

in the final line at every high root. Its normalizing value is D+m, and the unit is nonzero, including p=3,d=2. The final line is rootwise, not a derivative of the repeated residue and not a whole-disk F' initial.

## 6. Exact auxiliary cancellation condition, and why it is harmless

To identify rather than ignore possible high-tail multiplier cancellations, define integer associated Hermite polynomials

    V_0=0, V_1=1, V_(j+1)=Z V_j+j V_(j-1).

The scaled tail U_d has residue V_d, whereas T_d has residue M_d. Put

    b_0=0,
    b_m=V_(2m)'(0)=(2m-2)!!+(2m-1)b_(m-1)       (m>=1),
    0!!=1.

Indeed V_(2m-1)(0)=(2m-2)!!, and differentiating the recurrence at zero gives the displayed recurrence for b_m. The first b_m are 1,5,33,279,2895,35685. The exact first-tier cancellation set is

    C_aux = {(p,d): d=2m<p, p odd prime, p divides b_m}.       (6.1)

This is an explicit finite integer test for each tail, not a census or a condition involving unknown roots. On any high disk the first possible U_d coefficient is b_m X t^(m-1), while the first possible W_d coefficient is the constant c_m b_m t^(2m-1). Thus outside C_aux these terms attain their stated weights, with nonzero initials. Inside C_aux the relevant normalized coefficients vanish and their weights strictly improve. The next terms and any deeper disk-specific cancellations may improve them further, never worsen them.

In particular d=4,p=5 has the accepted auxiliary cancellation; d=6,p=11 and d=8,p=31 are additional legitimate examples. They are not exceptions to (5.2). The proof uses only the bounds (4.2), for which zero is as safe as any higher value. No claim of an exact weight for W_d or U_d is made on C_aux, and no unresolved root-lift obligation is concealed there.

There are exactly three types of potential gates in this method:

1. The decisive high-tail unit could fail if p divides c_m. This never occurs for d<p. For even d>=p+1 it does occur, and no extension to that range is claimed.
2. A low Hermite residual could have a repeated or zero root. Section 7 rules both out for d<p, with its exact resultant/discriminant support. No characteristic-p Hermite degeneracy is assumed away.
3. The derivative corrections could tie the predecessor derivative. Their gaps are p-1 and p+x-1, strictly positive throughout this scope. Auxiliary cancellations only enlarge these gaps.

Accordingly the unresolved exceptional set INSIDE the theorem's stated range is empty. The sets outside the range are excluded scope, not alleged nonsimplicity and not solved by this proof.

## 7. All d low roots, including characteristic-p degeneracy checks

Let tau^2=t and separately evolve the original polynomial and its original ordinary derivative:

    Q_j(Z)=tau^(-j) P_j(tau Z),
    R_j(Z)=tau^(1-j) P_j'(tau Z),
    Q_(j+1)=ZQ_j-[(1-q^j)/t]Q_(j-1),
    R_(j+1)=Q_j+ZR_j-[(1-q^j)/t]R_(j-1),
    Q_0=1,Q_1=Z,R_0=0,R_1=1.

These recurrences are integral coefficientwise. Since -(1-q^j)/t reduces to j modulo p, including zero at p-divisible j, their reductions are M_(j+1)=ZM_j+jM_(j-1) and its ordinary derivative recurrence. The integer coefficient formula in Section 1 shows M_p=Z^p modulo p: every nonleading coefficient has numerator divisible by p and denominator prime to p. Starting at each multiple of p, where the recurrence coefficient vanishes, then propagating the next p-1 steps proves

    M_(ap+b)=Z^(ap) M_b        (a>=0, 0<=b<p).

Since p divides 2N and d<p,

    Q_n -> Z^(2N)M_d(Z),
    R_n -> d Z^(2N)M_(d-1)(Z).                              (7.1)

The second identity follows from the separately differentiated original recurrence; it does not infer a high-root derivative by differentiating an inseparable residue.

The elementary integer identities

    M_j=ZM_(j-1)+(j-1)M_(j-2),
    M_j'=jM_(j-1)

give gcd(M_d,M_(d-1))=1 over characteristic p when d<p: a common root propagates backward through nonzero coefficients d-1,...,1 to M_0=1. Since d is also a unit, M_d is squarefree. Since d is even, its constant is c_m, also a unit. Thus there are exactly d distinct NONZERO roots over the algebraically closed residue field. An exact integer check of the possible bad primes is

    Res(M_d,M_(d-1))=product_(j=1)^(d-1) j^j,
    Disc(M_d)=(-1)^(d(d-1)/2) product_(j=1)^d j^j.            (7.2)

The resultant follows inductively from the recurrence and the monic root-product definition; the discriminant follows from M_d'=dM_(d-1). Every possible prime divisor in (7.2) is <=d. There is no exceptional prime greater than d, including at the boundary d=p-1.

Simple-root Hensel lifting now applies to these d nonzero residue classes, giving exactly one low root per class and the nonzero unit in (7.1). Hence v(X)=1/2 and v(P_n')=(n-1)/2 there. This use of simple-root lifting is confined to the nonzero low classes, not the repeated zero residual. The low roots lie outside all high disks, where X-values are >=1.

The counts exhaust the full monic degree:

    d + beta*(2L)=d+2N=n.

There are no unaccounted clusters, no further low residues, and no exact zero. Combined with (5.2), this proves simplicity of every original P_n root.

## 8. Original H, algebraic-square kernel, and all primitive phases

The exact coordinate identities, with no normalization replacement, are

    H_n(v0^2)=v0^n P_n(X), X=v0+v0^(-1),
    H_n'(z)=v0^(n-2)[(n/2)P_n+(v0-v0^(-1))P_n'/2].

All P roots have positive valuation and so differ from +/-2. The branch v0 near i gives an analytic isometry with unit derivatives between the small X disk and z near -1. It maps the n roots just counted to n distinct H roots, preserving multiplicity before simplicity, and degree n exhausts H_n. At a root the term proportional to P_n vanishes EXACTLY. The remaining multiplier is a unit with residue

    i^(n-1)=(-1)^m i.

Thus corresponding ordinary P/H root-derivative valuations agree; normalized units are not silently identified.

Every recurrence edge 1-q^j, 1<=j<n, is nonzero by n<p^s. A common root of P_n and P_(n-1) would propagate backward to P_0=1, impossible. At every P_n root xi, the ORIGINAL Christoffel-Darboux identity is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
      = P_n'(xi)P_(n-1)(xi)/w_(n-1) !=0,
    w_j=product_(u=1)^j(1-q^u), w_0=1.

The squares are algebraic squares, not absolute-value squares. No positivity, Hermitian argument, real interlacing, or replacement family is used.

The accepted coefficientwise input uses the actual mixed-characteristic lattice e=(p-1)p^(s-1), uniformly for every s>r. Every new step is an exact integral identity, a unit statement, or a strict valuation inequality. In particular p-divisible coefficients are never replaced by a falsely nonzero residue or treated as decreasing value. For any primitive phase, an algebraic p-adic embedding and its own t=q-1 give the same proof. Injectivity/Galois conjugacy transfers nonvanishing to every characteristic-zero primitive phase. This does not claim simplicity after reduction in arbitrary unrelated finite characteristics.

## 9. New exact controls, resource boundary, and open gates

The proof is Sections 3-8 conditional only on the explicitly accepted coefficientwise input in Section 2. Finite controls are not the proof. A newly written standard-library checker performs only short-tail algebra and selected low-residue checks: independent subset-matching expansions against recurrences, the full symbolic fraction-free witness, degree/edge grades, associated-Hermite cancellation coefficients, boundary low-Hermite gcds, and separately evolved low original/ordinary-derivative residues. It does not rerun a predecessor program or repeat accepted cyclotomic or all-phase scans.

The checker includes negative controls: omit either correction term in S_d, change the associated-tail edge start, replace the squared T multiplier by T, or drop the low ordinary derivative. These are rejected on exact symbolic fixtures. Source-inventory and candidate-inventory checks are separate from mathematical checks and use pinned hashes; accepted sources remain unchanged. Cold replay runs the new checker only, including under optimized Python, with explicit checks rather than optimization-sensitive assertions.

The work computes no Fourier transform and provides no asymptotic improvement. Original full polynomial recurrence would require quadratic-many coefficient updates in n; our short-tail symbolic diagnostics perform their actual finite matching/recurrence/gcd work, and inventory verification and replay are not free preprocessing.

The mathematical exceptional set within the stated even-tail range is empty. The remaining gate is fresh independent review and, if later requested, a separate publication/delivery audit. No external repository, document, Library item, accepted source, or table is changed by this local candidate. No global F020/F023 completion is asserted.
