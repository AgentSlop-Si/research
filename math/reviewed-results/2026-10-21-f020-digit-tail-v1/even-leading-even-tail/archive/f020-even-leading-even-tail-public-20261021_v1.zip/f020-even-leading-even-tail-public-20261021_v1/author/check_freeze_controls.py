#!/usr/bin/env python3
"""Fresh disposable-copy freeze negatives; never runs dependency programs."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def need(c,msg):
    if not c:raise RuntimeError(msg)


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--expect-manifest',required=True)
    args=ap.parse_args();root=Path(__file__).resolve().parent
    need(digest(root/'MANIFEST.json')==args.expect_manifest,'source pin mismatch')
    cases=['proof_edit','missing_bound_file','extra_file','extra_empty_directory',
           'seal_mismatch','rehashed_replacement','symlink','source_report_edit']
    out=[]
    with tempfile.TemporaryDirectory(prefix='f020-even-leading-even-tail-') as td:
        for name in cases:
            trial=Path(td)/name;shutil.copytree(root,trial)
            # chmod only disposable copies if the frozen originals are read-only.
            for p in trial.rglob('*'):
                if p.is_file():p.chmod(0o644)
                elif p.is_dir():p.chmod(0o755)
            trial.chmod(0o755)
            if name=='proof_edit':
                with (trial/'REPORT.md').open('a') as f:f.write('\nUnauthorized edit.\n')
            elif name=='missing_bound_file':(trial/'CLAIM_SCOPE.json').unlink()
            elif name=='extra_file':(trial/'UNLISTED.txt').write_text('extra')
            elif name=='extra_empty_directory':(trial/'UNLISTED_DIRECTORY').mkdir()
            elif name=='seal_mismatch':
                s=json.loads((trial/'SEAL.json').read_text());s['manifest_sha256']='0'*64
                (trial/'SEAL.json').write_text(json.dumps(s))
            elif name=='rehashed_replacement':
                (trial/'REPORT.md').write_text('Replacement proof.\n')
                mf=json.loads((trial/'MANIFEST.json').read_text())
                for row in mf['files']:
                    if row['path']=='REPORT.md':
                        row['sha256']=digest(trial/'REPORT.md');row['bytes']=(trial/'REPORT.md').stat().st_size
                (trial/'MANIFEST.json').write_text(json.dumps(mf,sort_keys=True))
                s=json.loads((trial/'SEAL.json').read_text());s['manifest_sha256']=digest(trial/'MANIFEST.json')
                (trial/'SEAL.json').write_text(json.dumps(s))
            elif name=='symlink':
                (trial/'REPORT.md').unlink();(trial/'REPORT.md').symlink_to(root/'REPORT.md')
            elif name=='source_report_edit':
                with (trial/'dependencies/general-author/REPORT.md').open('a') as f:f.write('\nUnauthorized source edit.\n')
            proc=subprocess.run([sys.executable,'-B',str(root/'verify.py'),'--root',str(trial),
                '--expect-manifest',args.expect_manifest],capture_output=True,timeout=30)
            need(proc.returncode!=0,'mutation accepted: '+name)
            out.append({'mutation':name,'rejected':True})
    print(json.dumps({'status':'PASS','source_manifest_sha256':args.expect_manifest,'mutations':out},indent=2,sort_keys=True))


if __name__=='__main__':main()
