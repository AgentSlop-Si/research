#!/usr/bin/env python3
"""Strict inventory and hash verifier; no imports from candidate verifier."""
import argparse,hashlib,json
from pathlib import Path,PurePosixPath


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def verify(root,expected=None):
    root=Path(root);mp=root/'MANIFEST.json';sp=root/'SEAL.json';mh=digest(mp)
    if expected is not None:assert mh==expected,'unexpected manifest bytes'
    manifest=json.loads(mp.read_text());entries=manifest['files'];names=[]
    assert isinstance(entries,list)
    for item in entries:
        name=item['path'];rel=PurePosixPath(name)
        assert not rel.is_absolute() and '..' not in rel.parts and str(rel)==name,'unsafe path'
        assert name not in names and name not in ['MANIFEST.json','SEAL.json'],'duplicate or self-referential entry'
        names.append(name);p=root/name
        assert not p.is_symlink() and p.is_file(),'nonregular or missing file'
        assert p.stat().st_size==item['bytes'],'size mismatch: '+name
        assert digest(p)==item['sha256'],'digest mismatch: '+name
    assert json.loads(sp.read_text())['manifest_sha256']==mh,'seal mismatch'
    actual=[]
    for p in root.rglob('*'):
        assert not p.is_symlink(),'symlink in tree'
        if p.is_file():actual.append(p.relative_to(root).as_posix())
    assert set(actual)==set(names)|{'MANIFEST.json','SEAL.json'},'exact inventory mismatch'
    tree=[{'path':n,'bytes':(root/n).stat().st_size,'sha256':digest(root/n)} for n in sorted(actual)]
    return {'root':str(root),'manifest_sha256':mh,'file_count':len(actual),'inventory':tree}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root');ap.add_argument('--expected');args=ap.parse_args();print(json.dumps(verify(args.root,args.expected),indent=2))
