# F020 leading two scope assembly

21 October 2026 UTC. **Assembly of existing accepted results, not a new theorem, discovery, or publication.**

## Conclusion

The three accepted pieces do assemble to the following exact sector:

- n = 2p^r + d, every odd prime p >= 3, integers r >= 2 and s > r, and every integer 0 <= d < p;
- every characteristic-zero primitive p^s-th root q;
- squarefreeness of the original P_n and Gaussian H_n, and nonvanishing of the original algebraic-square Christoffel–Darboux kernel at every P_n root.

No source or parameter gap remains inside that sector. This conclusion is a set union of accepted theorems. No new proof computation, mathematical control replay, external write, or execution authorization is part of this audit. Acceptance of the component mathematics is not acceptance of a future public package or its delivery.

## Disjoint parameter partition

1. **d = 0.** The accepted leading-two theorem n = 2p^r applies directly, including p = 3 and r = 2. All 2p^r roots are high-disk boundary roots. There is no exact zero P root. The ordinary derivative valuation at every P or H root is D = 3p^r/2 + 2B - p, with B = r(p-1)p^(r-1)/2.
2. **Odd 1 <= d < p.** The accepted odd-tail criterion plus its accepted uniform double-obstruction lift cover this entire part. For p >= 5 and d = 2m+1, the criterion covers r >= 3 and, at r = 2, every case except the simultaneous divisibilities p | ((2m+1)!! - (2m)!!) and p | (4m+3). Because 0 < 2d+1 < 2p, the latter divisibility forces p = 2d+1. That is exactly the accepted lift's remaining locus. It forces p >= 7; at p = 5 it would require the inadmissible even d = 2. The lift supplies all 2p previously unresolved central roots, not merely a scalar-point calculation. The sole p = 3 odd tail is d = 1: r >= 3 is inherited from the accepted general adjacent theorem, and r = 2 from the separately accepted original P_19 completion, valid for every s > 2 with central derivative valuation 76/3. Root counts are one simple exact zero, d-1 simple low roots, and 2p^r high roots.
3. **Even 2 <= d < p.** The accepted uniform even-tail theorem applies without an exceptional prime or tail. It includes d = p-1 and p = 3, d = 2. Its d = 2 and d = 4 predecessors are retained, not new credit; the new work in that source was the simultaneous even d >= 6 range. There are d simple low roots and 2p^r high roots, with no exact zero P root. For d = 2m, their original derivative valuations are respectively p^r+m-1/2 and D+m.

These parts are disjoint and exhaust 0 <= d < p. In particular p = 3 has precisely d = 0, 1, 2, each covered by the stated accepted source. Previously accepted +1, +2, +3, +4 and other bounded specializations are overlaps within these sources, not extra degree families or extra theorem credit.

## Common conventions and boundary checks

Every source uses P_0 = 1, P_1 = X, P_(j+1) = X P_j - (1-q^j)P_(j-1), H_n(z) = sum_a [n choose a]_q z^a, and w_j = product_(u=1)^j (1-q^u). Here n < p^(r+1) <= p^s, also at p = 3 and d = p-1. Consequently all recurrence edges and displayed CD denominators before degree n are nonzero.

The valuation is chosen in an algebraic p-adic embedding, with t = q-1, v(t) = 1 and v(p) = (p-1)p^(s-1). All sources retain ordinary characteristic-zero derivatives and their integer factors before reduction. Neither differentiating an inseparable residual nor substituting a scalar evaluation for an actual root is licensed by this assembly. The same t-relative argument and algebraic conjugacy cover every primitive phase; no arbitrary auxiliary finite-characteristic assertion follows.

The common high-disk data are N = p^r, h = floor(r/2), beta = p^h, L = N/beta, rho = beta/2 for even r and rho = p^(h-1)(2p-1)/2 for odd r. Each of beta disjoint disks contains 2L high roots, counted with multiplicity before the respective ordinary-derivative proof. Their P centers are i(q^(a/2)-q^(-a/2)), with square roots near 1. The boundary X values are rho centrally and p^ord_p(a) otherwise. Low roots have X value 1/2 and are disjoint from the high disks. All counts exhaust the degree.

For odd d = 2m+1 the zero P root is simple with derivative value K+m, where K = N+2B. For even d = 2m, including d = 0, P_n(0) is nonzero with value K+m. The exact identity H_n(v0^2) = v0^n P_n(v0+v0^(-1)) transfers multiplicities and root-derivative valuations on the unramified branch near i. The prefactor derivative vanishes only after evaluation at a root; the remaining unit has residue i^(n-1). Thus equal derivative valuations do not mean equal normalized P/H units. The odd P zero corresponds to H's root z = -1; H_n(0) = 1 in all cases.

At any P_n root xi, the accepted identity is sum_(j=0)^(n-1) P_j(xi)^2/w_j = P_n'(xi)P_(n-1)(xi)/w_(n-1). These are algebraic squares, not absolute-value squares. Simplicity, consecutive-polynomial coprimality, and nonzero edges give the claimed nonvanishing, without positivity, interlacing, or a Fourier argument. No single all-root derivative value is asserted for the assembled odd-tail sector.

## Exact accepted source identities

All hashes below are SHA-256. Original accepted-source pins and deliberately projected public identities must not be conflated.

**Zero tail, direct leading-two theorem**

- Original author manifest: b407a5fe2b13690b5bcb6fc14d24e1496b27ec683be548cc6c68598ffa91fbb6
- Original author report: 232918eb924abc7a92f1a56610d7f96858440388023608c50e3d493bf4d791fc
- Original accepting review manifest: 55a208d001d9a566377c7939fdb5b6ebbce8d97f18d55faf707468e5ff1157e1
- Original accepting review report: e7799b205a827dbf2054edf9af4d979f1a6a8db82aa4d598d4074d79afc7be37
- Unchanged verdict: cfb5b5379f2b020a9ee978a4f83033969be9fea23b30d46f88675764abd69463
- Public projected author report: cf5e92c832d6f387154c2df0508cf59ff3438a1a25a4d88b62a74b9544dc59e6
- Public projected review report: 5d8358343d9ef92e008c2c9002c2e4b94a83983615bb3fdedac7f0762338f5bd
- Leading-two portable manifest: 4f7a26b247d12df5490d155de2743113a6752853e9df804b4aace08c7b9dd2ee

The coefficientwise general-adjacent chain retains this theorem through the accepted single-leading-digit comparison archive, SHA-256 c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe, whose manifest is 952a6175b389b582ab4ae28491a380fa9cc8d699a45f8af0f2ea9b9240241bf8. Its direct leading-two acceptance and projection ledger bind the original identities above to the portable scientific text. The general-adjacent author uses the archive as provenance only and re-proves its own coefficientwise lemmas. This audit invokes the separately accepted d = 0 theorem itself, not an extrapolation of the adjacent theorem or its c = 2, r = 2 criterion. Projected manifests are not claimed to hash to original manifest pins; undistributed original administrative bytes were not reconstructed.

**Odd-tail completed sector**

- Uniform lift author manifest: 58d896c0e672d3363f2cb5948b7cad268648ec9414ca0d57476b8ab26920f43c
- Author report: 89be6d8038493f791ad61ec4a9f34c28a7d71155be85ae95840ac5bacde607d0
- Accepting review manifest: 0a3d7ace672e07401c79c034bef5725804a5e6b10a1a5ffc13f067e13bdaef7f
- Retained odd-tail criterion author/review manifests: 3d4cce4aa5586a9f4ad82225d183f22d8aed3616b65b6fa34b8b0aab20aad565 / fb9b967054ded8ed059d51dc460aded01cc3c93ffd47b7917ae3614d590ce18d
- Separately inherited p = 3, r = 2 central author/review manifests: 072e4134daea3f759d79550c891027abb0410ed38aac6826635fee085f730147 / b7583a6324271df5defc71514c871562a88c62cfb69ed736b62d3814abebff47

**Even-tail completed sector**

- Author manifest: c7b391df43fc8fb0fb14fab06ddd1d4e722d791469fc2593017ef27d8d9a88d3
- Author report: bbd3966bc29ed35b3dc45831251d1aa58943139530d2e814f6511fade2965247
- Accepting review manifest: 419d478b906e68600983a1b209ed53e0f05c532875d409398ee7ae9e168cb012
- Accepting review report: 98e8c54edbfecdba7dec80230db07ca5d5e6fbde760fc21eada976645500e92c

Both tail chains retain the same coefficientwise general-adjacent author/review manifests e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7 / a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7. The r >= 3, p = 3 odd-tail inheritance is within that accepted theorem's stated sufficient scope. The even proof uses its coefficientwise facts separately from the unresolved adjacent r = 2 criterion, which is not a missing case in the even theorem.

## Remaining exclusions

This union alone makes no assertion for p = 2; r < 2; s <= r; tails d >= p or nonzero intermediate base-p digits; other leading digits; composite orders; arbitrary n; arbitrary unrelated finite characteristics; global F020/F023 closure; exact deeper geometry beyond each accepted source; historical novelty; faster FFTs or any algorithmic-cost improvement. These are exclusions from this assembly, not claims that every such case is unresolved by all other research. No external table annotation, repository change, publication, or execution permission has been issued.
