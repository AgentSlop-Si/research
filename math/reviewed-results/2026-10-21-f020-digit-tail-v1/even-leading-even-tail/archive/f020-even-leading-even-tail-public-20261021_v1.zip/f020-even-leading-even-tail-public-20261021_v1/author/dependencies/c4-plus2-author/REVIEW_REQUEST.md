# Independent-review gate

Review the exact frozen manifest, not a mutable draft. The requested outcome is acceptance within the precise n=4p^r+2, p>=5 prime, r>=2, s>r, all-primitive-characteristic-zero-phase scope, or an exact mathematical/source obstruction.

Priority checks:
1. Accepted general-c Sections 2-5 truly supply the coefficientwise off-root c=4 A,M,A',M' inputs. Do not infer them from the c=2 theorem.
2. Sum both derivative pivots 12Z+4Z^3, including the p=5,r=2 endpoint. Verify resultant 108 and exclude cancellation on the M4 root locus.
3. Check the exact F and S transfer, all derivative terms, p-1 gap, and use of the actual new-root equation rather than whole-disk F' bounds.
4. Verify all beta high clusters and two distinct simple low roots, the absence of zero, +2Z low residue, and +i H/P derivative multiplier.
5. Verify every primitive phase/minimal s, exact original H/P normalizations, and algebraic rather than absolute-value square kernel.
6. Bind all copied author/review bytes and source acceptance, then perform only minimal fresh c=4 target checks. Do not replay accepted predecessor controls.

The candidate supplies no missing central lemma: none is needed by this even-tail witness. If any additional c=4 input is necessary, identify its exact statement and do not silently repair or broaden the frozen candidate.
