# Independent review of the leading-four plus-two theorem

Accepted within the exact stated scope: n=4p^r+2, p>=5 prime, r>=2, s>r, every characteristic-zero primitive p^s phase. Read INDEPENDENT_REVIEW.md and VERDICT.json for the mathematical judgment and limits. SOURCE_BINDING.json identifies the exact frozen author candidate.

The independent scientific controls are standard-library Python and import no candidate or predecessor module. To replay them, write outside this frozen review:

    python -B independent_controls.py --output /chosen/output/results.json
    python -B replay_independent.py --output /chosen/output/replay.json

replay_independent.py compares every scientific field with controls/INDEPENDENT_RESULTS.json and excludes only nonsemantic elapsed_seconds timing values. The three current timing fields belong to the three cyclotomic cases. Retain raw output when reproducing results. Finite controls are not the uniform proof.

verify_binding.py and check_integrity_mutations.py are independent artifact-integrity tools for a COMPLETE original frozen candidate tree, not for a projected partial public source tree. They do not execute source programs. The latter mutates only disposable copies. The source inventory and seal are historical identity evidence if the original tree is not present in full.

This review changed no author/source file and performed no external write. Publication, any public projection and delivery require separate review.
