"""Verify the frozen review/author, then optionally cold replay own controls."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('own_inventory',ROOT/'verify_inventory.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)


def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(20,20))
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**2,2*1024**2))


def replay(optimized):
    start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='independent-even-tail-cold-') as td:
        target=Path(td)/'independent_checks.py';shutil.copyfile(ROOT/'independent_checks.py',target)
        command=[sys.executable,'-I','-B']+(['-O'] if optimized else [])+[str(target)]
        p=subprocess.run(command,cwd=td,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,preexec_fn=limits)
        v.need(p.returncode==0 and not p.stderr,'independent cold replay failed: '+p.stderr.decode(errors='replace'))
        v.need(len(p.stdout)<=2*1024**2,'independent stdout acceptance limit')
        v.need(p.stdout==(ROOT/'controls/INDEPENDENT_RESULTS.json').read_bytes(),'independent cold replay bytes differ')
    return {'status':'PASS_BYTE_FOR_BYTE','optimized':optimized,'result_sha256':v.sha(p.stdout),'wall_seconds':round(time.monotonic()-start,3),'caps':{'cpu_seconds':20,'wall_seconds':30,'address_space_bytes':512*1024**2,'regular_file_bytes':2*1024**2,'accepted_stdout_bytes_max':2*1024**2},'isolation':'Python -I, disposable directory, rlimits; not an OS/network sandbox'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--expected-manifest',required=True);ap.add_argument('--author-root',required=True);ap.add_argument('--expected-author-manifest',required=True);ap.add_argument('--replay',action='store_true');ap.add_argument('--optimized',action='store_true');ap.add_argument('--output');args=ap.parse_args()
    own=v.verify(ROOT,args.expected_manifest);author=v.verify(args.author_root,args.expected_author_manifest)
    binding=v.strict_json((ROOT/'SOURCE_BINDING.json').read_bytes())
    v.need(binding['candidate_manifest_sha256']==args.expected_author_manifest,'author pin mismatch to review')
    ar=Path(args.author_root)
    v.need(binding['candidate_report_sha256']==v.sha((ar/'REPORT.md').read_bytes()),'author report binding')
    sources={name:v.verify(ar/name,pin) for name,pin in binding['complete_source_pins'].items()}
    out={'status':'INTEGRITY_PASS','review':own,'author':author,'sources':sources,'predecessor_controls_executed':False}
    if args.replay:
        out['independent_cold_replay']=replay(args.optimized);out['status']='INTEGRITY_AND_INDEPENDENT_COLD_REPLAY_PASS'
        v.need(v.verify(ROOT,args.expected_manifest)==own and v.verify(ar,args.expected_author_manifest)==author,'frozen inputs changed')
    data=json.dumps(out,indent=2,sort_keys=True)+'\n'
    if args.output:
        dest=Path(args.output).resolve();v.need(dest!=ROOT and ROOT not in dest.parents,'output must be outside frozen review');dest.write_text(data)
    print(data,end='')


if __name__=='__main__':main()
