#!/usr/bin/env python3
"""Bounded exact falsification controls, not proofs of the unlimited family."""
from pathlib import Path
from fractions import Fraction as Q
import json, math, time
import numpy as np
import sympy as sp
OUT=Path(__file__).resolve().parent

def pp(p,j):
    if not j: raise ValueError('zero exponent')
    a=1
    while j%p==0: j//=p; a*=p
    return a

def W(p,m):
    ans=m; b=p
    while b<=m: ans+=(b-b//p)*(m//b); b*=p
    return ans

def params(p,r,c):
    N=p**r; B=r*(p-1)*p**(r-1)//2; beta=p**(r//2)
    rho=Q(beta,2) if r%2==0 else Q(p**(r//2-1)*(2*p-1),2)
    K=Q(c*N,2)+c*B;E=K-Q(N,2);D=K+Q(N,2)-p
    def T(m):
        return m+sum((p**a-p**(a-1))*(m//p**a) for a in range(1,r//2))+(rho-p**(r//2-1))*(m//beta)
    return N,B,beta,rho,K,E,D,T

def hermite(n):
    return {n-2*k:math.factorial(n)//(2**k*math.factorial(k)*math.factorial(n-2*k)) for k in range(n//2+1)}

def obstruction(c):return sum(a*(-1)**(j//2) for j,a in hermite(c).items())

def integer_controls():
    rows=[]
    cases=[(3,2,2),(3,3,2),(3,4,2),(5,2,2),(5,2,4),(5,3,4),(7,2,4),(7,2,6),(7,3,6),(11,2,8),(11,2,10),(13,2,12)]
    for p,r,c in cases:
        assert sp.isprime(p) and 2<=c<p and c%2==0
        N,B,beta,rho,K,E,D,T=params(p,r,c);b=c*N-1
        ws=[W(p,m) for m in range(b+1)];rs=[int(2*(ws[m]-T(m))) for m in range(b+1)]
        es=[0]+[pp(p,m) for m in range(1,b+1)]
        assert [m for m in range(b+1) if rs[m]==ws[m]]==list(range(0,b+1,N))
        pivots=[];maxbr=-1;pairs=0
        for k in range(1,b+1,2):
            base=2*ws[(b-k)//2];score=base+rs[k]
            assert score<=2*E
            if score==2*E:pivots.append(k)
            for m in range(k):
                v=base+rs[m]+2*es[k-m]
                assert v<=2*E,(p,r,c,k,m,v,E)
                maxbr=max(maxbr,v);pairs+=1
        assert pivots==list(range(N,c*N,2*N))
        assert W(p,(N-1)//2)==B
        assert all(W(p,b-j)==W(p,b)-W(p,j) for j in range(b+1))
        xset={rho}|{Q(pp(p,a)) for a in range(1,beta)}
        assert {x for x in xset if 2*x==p}==({rho} if r==2 else set())
        assert N+E-rho>K and D==N+E-p
        assert c*N+1<p**(r+1)
        rows.append(dict(p=p,r=r,c=c,boundary_prime=(p==c+1),N=N,rho=str(rho),K=str(K),E=str(E),D=str(D),pivots=pivots,derivative_pairs=pairs,maximum_subtracted_bracket=str(Q(maxbr,2))))
    return rows

def residual_controls():
    y,z,u=sp.symbols('y z u');rows=[]
    for c in range(2,25,2):
        mc=sum(a*z**j for j,a in hermite(c).items());mm=sum(a*z**j for j,a in hermite(c-1).items());rc=sum(a*u**(j//2) for j,a in hermite(c).items())
        A=obstruction(c)
        assert int(sp.resultant(rc,u+1,u))==(-1)**(c//2)*A
        cons=int(sp.resultant(mc,mm,z));expected=math.prod(j**j for j in range(1,c))
        assert cons==expected
        fs={} if A==0 else {str(p):e for p,e in sp.factorint(abs(A)).items()}
        primes=sorted(set([int(sp.nextprime(c)),int(sp.nextprime(c+5))]+[int(p) for p in fs if int(p)>c]))
        checks=[]
        for p in primes:
            g=sp.gcd(sp.Poly(rc,u,modulus=p),sp.Poly(u+1,u,modulus=p)).monic();want=1 if A%p==0 else 0
            assert g.degree()==want,(c,p,g,want)
            if want:assert g==sp.Poly(u+1,u,modulus=p)
            assert sp.gcd(sp.Poly(mc,z,modulus=p),sp.Poly(mm,z,modulus=p)).degree()==0
            explicit_y_gcd=None
            if p<=31:
                f=sp.Poly(sum(a*y**(j*p) for j,a in hermite(c).items()),y,modulus=p)
                d=sp.Poly(sum(a*(y**(j*p)+y**(j*p-2)) for j,a in hermite(c-1).items()),y,modulus=p)
                gy=sp.gcd(f,d).monic();assert gy.degree()==2*want
                if want:assert gy==sp.Poly(y*y+1,y,modulus=p)
                explicit_y_gcd=gy.degree()
            checks.append(dict(p=p,criterion_pass=A%p!=0,U_resultant_gcd_degree=g.degree(),explicit_Y_gcd_degree=explicit_y_gcd,boundary_prime=p==c+1))
        rows.append(dict(c=c,A=A,factorization=fs,exceptional_primes_gt_c='all odd primes' if A==0 else [int(p) for p in fs if int(p)>c],checks=checks))
    # Integer recurrence and an infinite nonzero subfamily, exact through a large finite control bound.
    a=[1,0]
    for m in range(2,101):a.append((2*m-2)*(2*a[-1]-(2*m-3)*a[-2]))
    for m in range(0,21):assert a[m]==obstruction(2*m)
    for k in range(1,51):
        v=0;b=abs(a[2*k])
        while b%2==0:b//=2;v+=1
        assert v==k
    return dict(rows=rows,obstruction_recurrence_controls_through_c=200,exact_even_index_two_adic_controls=True)

class FieldMod:
    """Actual Z/p^h[Q]/Phi_(p^s), truncated only in X, never in q."""
    def __init__(self,p,s,precision,maxX):
        self.p=p;self.s=s;self.order=p**s;self.gap=self.order//p;self.e=self.order-self.gap
        self.precision=precision;self.mod=p**precision;self.maxX=maxX
    def rot(self,a,k):
        padded=np.zeros((a.shape[0],self.order),dtype=np.int64);padded[:,:self.e]=a
        shifted=np.roll(padded,k%self.order,axis=1)
        low=shifted[:,:self.e].reshape(a.shape[0],self.p-1,self.gap)
        high=shifted[:,self.e:]
        return ((low-high[:,None,:]).reshape(a.shape[0],self.e))%self.mod
    def polys(self,n):
        shape=(self.maxX+1,self.e);old=np.zeros(shape,dtype=np.int64);cur=old.copy()
        old[0,0]=1;cur[1,0]=1;out={}
        for k in range(1,n):
            nxt=(self.rot(old,k)-old)%self.mod
            nxt[1:]=(nxt[1:]+cur[:-1])%self.mod
            old,cur=cur,nxt
            if k+1>=n-2:out[k+1]=cur.copy()
        return out
    def to_t(self,a):
        # Pascal transform q=1+t, exact modulo p^h. Products fit signed int64.
        e=self.e;mod=self.mod
        assert e*(mod-1)**2<2**63
        pas=np.zeros((e,e),dtype=np.int64);pas[0,0]=1
        for k in range(1,e):
            pas[k,0]=1;pas[k,1:k+1]=(pas[k-1,:k]+pas[k-1,1:k+1])%mod
        return (a@pas)%mod
    def initial(self,tpoly,rho,threshold,shift=0,derivative=False):
        out={};mins=[]
        for raw,row in enumerate(tpoly):
            deg=raw+shift
            if deg<0:assert not np.any(row);continue
            if derivative:
                if deg==0:continue
                mul=deg;targetdeg=deg-1
            else:mul=1;targetdeg=deg
            row=(row*mul)%self.mod
            vals=[]
            for j in np.flatnonzero(row):
                b=int(row[j]);o=0
                while b%self.p==0:b//=self.p;o+=1
                value=int(j)+o*self.e+targetdeg*rho
                vals.append((value,b*(-1)**o%self.p))
            if not vals:continue
            w,unit=min(vals)
            assert w>=threshold,(self.p,raw,shift,derivative,w,threshold)
            if w==threshold:out[targetdeg]=unit
            mins.append(dict(degree=targetdeg,weight=str(w),unit=unit))
        return out,mins

def actual_field(p,s,c):
    N,B,beta,rho,K,E,D,T=params(p,2,c);n=c*N+1;e=(p-1)*p**(s-1)
    maxweight=max(K+rho,D+rho,E+rho);precision=int(maxweight//e)+1
    maxX=int(maxweight//rho)+2
    f=FieldMod(p,s,precision,maxX)
    polys=f.polys(n);tt={k:f.to_t(v) for k,v in polys.items()}
    fp,fr=f.initial(tt[n],rho,K,shift=-1)
    dp,dr=f.initial(tt[n],rho,D,shift=-1,derivative=True)
    mp,mr=f.initial(tt[n-2],rho,E)
    pd,pdr=f.initial(tt[n-1],rho,D,derivative=True)
    md,mdr=f.initial(tt[n-2],rho,E,derivative=True)
    eps=(-1)**((p-1)//2);mc=hermite(c);mm=hermite(c-1)
    pred={j*p:a%p for j,a in mc.items() if a%p}
    # General exact central neighbor scalar has unit epsilon, independent of even c.
    mpred={j*p:eps*a%p for j,a in mm.items() if a%p}
    pdpred={j*p:-c*eps*a%p for j,a in mm.items() if a%p}
    dpred={}
    for j,a in mm.items():
        for b in [j*p,j*p-2]:dpred[b]=(dpred.get(b,0)-c*eps*a)%p
    dpred={j:a for j,a in dpred.items() if a}
    assert fp==pred,(p,s,c,'F',fp,pred)
    assert mp==mpred,(p,s,c,'M',mp,mpred)
    assert pd==pdpred,(p,s,c,'Pprime',pd,pdpred)
    assert dp==dpred,(p,s,c,'Fprime',dp,dpred)
    y=sp.Symbol('y');g=sp.gcd(sp.Poly(sum(a*y**j for j,a in fp.items()),y,modulus=p),sp.Poly(sum(a*y**j for j,a in dp.items()),y,modulus=p)).monic()
    assert g.degree()==(2 if obstruction(c)%p==0 else 0)
    return dict(p=p,r=2,s=s,c=c,n=n,ramification=e,coefficient_modulus=p**precision,precision_justification='Every omitted coefficient is divisible by p^precision and has valuation at least precision*e, strictly above every tested threshold; X truncation exceeds every relevant weighted degree.',X_truncation=maxX,K=str(K),E=str(E),D=str(D),actual_F=fp,actual_M=mp,actual_Pevenprime=pd,actual_Fprime=dp,actual_Mprime_at_E=md,residual_gcd_degree=g.degree(),coefficient_records={'F':fr,'M':mr,'Fprime':dr,'Pevenprime':pdr,'Mprime':mdr})

def rational_controls():
    X,Z,V=sp.symbols('X Z V');rows=[]
    for q in [sp.Rational(2),sp.Rational(-2),sp.Rational(1,2)]:
        P=[sp.Integer(1),X];H=[sp.Integer(1),1+Z];w=[sp.Integer(1)];Qq=[sp.Integer(1)];nn=[sp.Integer(1)];maxn=14
        for j in range(1,maxn+1):
            w.append(w[-1]*(1-q**j));Qq.append(Qq[-1]*(1-q**(2*j)));nn.append(sp.expand(nn[-1]*(Z+q**(j-1))))
        for j in range(1,maxn):
            P.append(sp.expand(X*P[-1]-(1-q**j)*P[-2]));H.append(sp.expand((1+Z)*H[-1]-Z*(1-q**j)*H[-2]))
        for n in range(1,maxn+1):
            assert sp.expand(H[n].subs(Z,V**2)-V**n*P[n].subs(X,V+1/V))==0
            cd=sum(P[j]**2/w[j] for j in range(n))
            assert sp.expand(cd-(sp.diff(P[n],X)*P[n-1]-P[n]*sp.diff(P[n-1],X))/w[n-1])==0
            val=sum(w[n]*nn[k]/(w[k]*Qq[(n-k)//2]) for k in range(n%2,n+1,2))
            der=sum(w[n]*Z**(k-m-1)*nn[m]/(Qq[(n-k)//2]*w[m]*(1-q**(k-m))) for k in range(n%2,n+1,2) for m in range(k))
            assert sp.expand(val-H[n])==sp.expand(der-sp.diff(H[n],Z))==0
        rows.append(dict(q=str(q),degrees=list(range(1,maxn+1)),original_H_P_Newton_ordinary_derivative_and_CD=True))
    return rows

if __name__=='__main__':
    result={}
    def save():(OUT/'CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    for label,fn in [('integer',integer_controls),('residual',residual_controls),('rational',rational_controls)]:
        st=time.monotonic();result[label]=fn();save();print(label,'PASS',round(time.monotonic()-st,3),flush=True)
    result['actual_cyclotomic']=[]
    for p,s,c in [(3,3,2),(5,3,4),(7,3,6),(11,3,8)]:
        st=time.monotonic();result['actual_cyclotomic'].append(actual_field(p,s,c));save();print('actual_cyclotomic',p,s,c,'PASS',round(time.monotonic()-st,3),flush=True)
    print('ALL BOUNDED EXACT CONTROLS PASS',flush=True)
