"""Strict independent inventory verifier. Never runs the checked programs."""
import hashlib
import json
import re
import sys
from pathlib import Path, PurePosixPath


def need(ok, message):
    if not ok: raise ValueError(message)


def strict_json(data):
    def pairs(items):
        out={}
        for k,v in items:
            need(k not in out,'duplicate JSON key: '+k)
            out[k]=v
        return out
    return json.loads(data,object_pairs_hook=pairs)


def sha(data): return hashlib.sha256(data).hexdigest()


def verify(root, pin):
    root=Path(root)
    need(not root.is_symlink(),'root symlink')
    mb=(root/'MANIFEST.json').read_bytes()
    need(sha(mb)==pin,'external manifest pin mismatch')
    manifest=strict_json(mb)
    need(isinstance(manifest.get('files'),list),'missing files list')
    # Reject links before following any declared member, including through
    # a symlink directory, rather than rejecting only after reading it.
    seen=set(); dirs=set()
    for p in root.rglob('*'):
        need(not p.is_symlink(),'symlink: '+str(p.relative_to(root)))
        relative=p.relative_to(root).as_posix()
        if p.is_dir(): dirs.add(relative)
        elif p.is_file(): seen.add(relative)
        else: raise ValueError('nonregular filesystem object')
    declared=set()
    for row in manifest['files']:
        name=row.get('path'); size=row.get('bytes'); digest=row.get('sha256')
        need(isinstance(name,str) and name and '\\' not in name,'invalid path')
        p=PurePosixPath(name)
        need(not p.is_absolute() and name==str(p) and all(x not in ('','.','..') for x in p.parts),'unsafe/noncanonical path')
        need(name not in ('MANIFEST.json','SEAL.json') and name not in declared,'duplicate/reserved member')
        need(type(size) is int and size>=0,'invalid byte count')
        need(isinstance(digest,str) and re.fullmatch('[0-9a-f]{64}',digest),'invalid digest')
        declared.add(name)
        target=root/name
        need(target.is_file() and not target.is_symlink(),'missing/nonregular member: '+name)
        data=target.read_bytes()
        need(len(data)==size and sha(data)==digest,'member bytes/hash mismatch: '+name)
    need(seen==declared|{'MANIFEST.json','SEAL.json'},'exact file set mismatch')
    expected_dirs=set()
    for name in seen:
        parent=PurePosixPath(name).parent
        while str(parent)!='.':
            expected_dirs.add(str(parent));parent=parent.parent
    need(dirs==expected_dirs,'exact directory set mismatch')
    seal=strict_json((root/'SEAL.json').read_bytes())
    need(seal.get('manifest_sha256')==pin,'seal mismatch')
    return {'manifest_sha256':pin,'files_bound':len(declared),'directories':len(dirs),'inventory':'PASS'}


def main():
    need(len(sys.argv)==3,'usage: verify_inventory.py ROOT MANIFEST_SHA256')
    print(json.dumps(verify(sys.argv[1],sys.argv[2]),indent=2,sort_keys=True))


if __name__=='__main__': main()
