# Uniform second layer at the adjacent central cancellation

Author candidate, 21 October 2026 UTC. ORIGINAL F020 normalization. This is a new general-c argument, not an exceptional-pair census, a repackaging of the accepted c=2 proof, or independent acceptance of its own claims.

## 1. Theorem and exact boundary

Let p be an odd prime, 2 <= c < p an even integer, s>2, and q a characteristic-zero primitive p^s-th root. Keep exactly

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_b(z)=sum_a [b choose a]_q z^a.

Choose an algebraic p-adic embedding, t=q-1, v(t)=1, and put

    N=p^2, B=p(p-1), d=B/2, rho=p/2,
    e=v(p)=(p-1)p^(s-1) >= pB,
    W=N+2B, K=cW/2,
    E=(c-1)N/2+cB, D=(c+1)N/2+cB-p,
    n=cN+1, F(X)=P_n(X)/X,
    X^2=t^p U, F(X)=t^K f(U).

Define the integer polynomials

    M_j(Z)=j! sum_(k=0)^floor(j/2) Z^(j-2k)/(2^k k! (j-2k)!),
    R_c(U)=sum_(k=0)^(c/2) c! U^(c/2-k)/(2^k k! (c-2k)!),
    A_c=R_c(-1), so M_c(Z)=R_c(Z^2).

THE NEW UNIFORM STATEMENT. Suppose p>=5 and p divides A_c. Every one of the 2p previously exceptional nonzero P_n roots, counted with multiplicity before simplicity, satisfies

    v(U+1)>1,
    v(f_U(U))=d+1,
    residue(f_U(U)/t^(d+1))=R_c'(-1)/8 != 0 in F_p,
    v(P_n'(X))=K+d+1,
    residue(P_n'(X)/t^(K+d+1))=-R_c'(-1)/4 != 0.       (1.1)

All derivatives are ORIGINAL ordinary characteristic-zero derivatives. No reduced inseparable polynomial is differentiated in place of them. There is no additional residual obstruction: R_c'(-1) is automatically a unit whenever p>c and A_c=0 mod p.

Together with the accepted general criterion and its unconditional disk geometry, this proves P_(cp^2+1) and H_(cp^2+1) squarefree, with nonzero original algebraic-square Christoffel-Darboux kernel at every P root, for every even 2<=c<p and s>2. The only p=3 possibility is c=2, handled by the already accepted exact P_19 proof, not by the new first-order calculation. There its exceptional ordinary P derivative value is 76/3, not K+d+1.

For p>=5 the complete original P derivative valuation/count statement is:

- Exact zero: value K, one root.
- Noncentral roots: value D+1, c p(p-1) roots.
- If p does not divide A_c: central roots have value K+d, c p roots.
- If p divides A_c: regular central roots have value K+d, (c-2)p roots; exceptional central roots have value K+d+1, 2p roots.

Counts include multiplicity until the derivative conclusions prove simplicity. Corresponding H derivatives have the same values. The theorem makes no claim for odd c, c>=p, s<=2, arbitrary n/digits, global F020/F023 closure, odd-composite orders, FFT/cost, or historical novelty. Exact root depths greater than 1 are not asserted in general.

## 2. Frozen sources and all imported facts

The full accepted general author package is copied in dependencies/general-author, with manifest SHA-256

    e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7.

Its full final independent review is copied in dependencies/general-review, manifest SHA-256

    a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7.

That review accepts the precise leading criterion and unconditional coefficientwise assertions, not nonsimplicity at the exceptions. The copied reports supply the complete derivation of the following facts; they are stated here so no hidden hypothesis is imported.

Use

    a_j=1-q^j, w_m=product_(j=1)^m a_j,
    Q_m=product_(j=1)^m (1-q^(2j)),
    N_m(z)=product_(j=0)^(m-1)(z+q^j),
    W(m)=sum_(j=1)^m p^ord_p(j).

All used indices are <=cN<p^3<=p^s. All denominators are nonzero, and v(a_j)=p^ord_p(j). The exact Newton identities are

    H_b=sum_(k=b mod 2) w_b N_k/(w_k Q_((b-k)/2)),             (2.1)
    H_b'=sum_(k=b mod 2,k>=1) sum_(m=0)^(k-1)
          w_b z^(k-m-1) N_m/[Q_((b-k)/2) w_m a_(k-m)].       (2.2)

They are identities over Q(q,z), obtained from the ordinary derivative of the Newton generating series. The coordinate identity is

    H_b(v0^2)=v0^b P_b(X), X=v0+v0^(-1), z=v0^2,
    H_b'=v0^(b-2)[(b/2)P_b+(v0-v0^(-1))P_b'/2].             (2.3)

Choose v0 near i with i^2=-1. The coordinate maps are analytic isometries on the relevant disks. In particular S=z+1 satisfies S=v0 X and S^2=z X^2.

There are p disjoint disks, indexed by 0<=a<p, centered at

    x_a=i(q^(a/2)-q^(-a/2)), with v(X-x_a)>=rho,

where the square roots are congruent to 1. Each contains cp boundary roots of F, counted with multiplicity, and these exhaust its degree cN. The central roots have v(X)=rho; all noncentral roots have v(X)=1. The exact zero of P_n is simple with derivative value K.

On the central disk let mu^2=t^p and X=mu Y. The coefficientwise residual and ORIGINAL derivative lower bound are

    F(mu Y)/t^K -> M_c(Y^p)=R_c(Y^2)^p,
    weight(F') >= D.                                        (2.4)

Thus f is integral coefficientwise on the unit U disk and f_U has coefficientwise value >=D-K+rho=d. This follows by differentiating in characteristic zero before reduction:

    F'(mu Y)=2t^K mu^(-1) Y f_U(Y^2).                        (2.5)

For M=P_(cN-1), on the residual root locus of F,

    v(M)=E,
    M(mu Y)/[t^(cB) mu^((c-1)p)] -> epsilon M_(c-1)(Y^p),
    epsilon=(-1)^((p-1)/2).                                 (2.6)

Moreover weight(M)>=E and weight(M')>=E on the entire closed disk. The full ordinary M' bound is also checked directly in Section 3 below.

The original quotient identity is

    F=P_(cN)-a_(cN) M/X.                                    (2.7)

The integer identities M_j'=jM_(j-1) and M_j=Z M_(j-1)+(j-1)M_(j-2) show M_c and M_(c-1) are coprime modulo p: a common root propagates to M_0=1, since all 1,...,c are units. The constant M_c(0) is a unit. Hence R_c is separable with nonzero constant. If A_c=0 mod p, then R_c'(-1)!=0, and (2.4) gives precisely 2p exceptional X roots with residual Y^2=-1. All other roots already have the accepted nonzero ordinary derivative. No simple-root Hensel lifting is assumed for the multiplicity-p residual factors.

The accepted c=2 public archive is copied verbatim with SHA-256

    667b37740cd2229082899e726a6efdb7e2be8b2e5d177eed5d3869bbcb79ec4e.

Only its p=3,c=2 theorem is required for the all-odd-p corollary. For p>=5 the new argument proves the statement directly for all c. The c8,p11 report is copied solely for a normalization comparison; none of its finite jets is a premise of the uniform proof.

## 3. Uniform central slack and EVERY competing ordinary derivative term

On the central boundary v(z+1)=rho. Every N_m factor with index divisible by p has value rho; all other factors have value 1. Therefore, exactly,

    T(m)=v(N_m)=m+(rho-1)ceil(m/p),
    Delta(m)=T(m)-W(m)/2.

Write m=lN+ap+b, 0<=a,b<p (with endpoint cN treated as a=b=0). Since

    W(m)=m+(p-1)floor(m/p)+(N-p)floor(m/N),

one obtains the exact identity

    2 Delta(m)=a(p-1)+b+(p-2)1_(b>0).                        (3.1)

Thus Delta=0 exactly at multiples of N, and otherwise Delta>=(p-1)/2. Set g=(p-1)/2; for p>=5, g>1. The formulas are valid also in the characteristic-p formal t-adic field used in Section 4.

### 3.1 The neighbor M

For b0=cN-1, W(b0)=2E. The k-th Newton term of H_b0, with a=(b0-k)/2, has value

    E+[W(b0)-2W(a)-W(k)]/2+Delta(k).                         (3.2)

The bracket is nonnegative because W is superadditive and W(2a)>=2W(a). Equality can occur only at k=lN with l odd, 1<=l<=c-1. These terms all attain E. Put

    u=(c-1-l)/2, A=(N-1)/2.

Then a=uN+A and their sum is

    S_-=sum_(l odd,1<=l<c) w_(cN-1) N_(lN)/[w_(lN) Q_(uN+A)]. (3.3)

Every omitted term has value >=E+g. This controls the entire neighbor, not one of its pivots.

For completeness the ordinary derivative bound follows termwise from (2.2). Writing j=k-m gives a lower bound

    E+W(j)/2-p^ord_p(j)+Delta(m).                             (3.4)

Here W(cN-1-j)=W(cN-1)-W(j), by reflection about cN. The bracket W(j)/2-p^ord_p(j) is nonnegative except possibly at j=1,p, where it is -1/2. If m is not a multiple of N, Delta(m)>=g resolves both cases. If m=lN, parity forces l even. For j=1,p, in 2a=(c-l)N-1-j the N-floor term of W(2a)-2W(a) is at least B, supplying an extra B/2 in (3.4). Thus EVERY ordinary derivative term has value >=E; after the unit coordinate change the prefactor term also has value >=E. Hence weight(M')>=E with all integer derivative factors retained.

### 3.2 The ordinary derivative of H_(cN)

For a term of (2.2), write j=k-m and a=(cN-k)/2. Superadditivity and

    W(cN-j)=cW-N-W(j-1)

give the following lower bound on its excess above D:

    p+W(j-1)/2-p^ord_p(j)+Delta(m).                           (3.5)

If ord_p(j)=0, the first three terms are >=p-1. If ord_p(j)=1, they are >=g, with the minimum at j=p. If ord_p(j)=2, the permitted indices are j=hN, 1<=h<=c; j=N gives zero, while every h>=2 gives at least W/2>g. There is no higher divisibility since j<=cN<p^3.

For j=N, the only possible zero-slack indices are m=lN with l odd, 1<=l<c; the even k=m+N parity excludes all other multiples of N. These are precisely the pivots

    S_D=sum_(l odd,1<=l<c)
          w_(cN) z^(N-1) N_(lN)/[Q_(uN) w_(lN) a_N].       (3.6)

They have value D term by term. EVERY other ordinary derivative term has value >=D+g. This is the uniform replacement for a fixed-p jet or unverified omission of nonpivot terms.

### 3.3 The even polynomial H_(cN)

Its k-th Newton term has value

    K+[W(cN)-2W((cN-k)/2)-W(k)]/2+Delta(k).                   (3.7)

The pivots are k=jN, j even, 0<=j<=c; all have value K. If k is not a multiple of N, the N-floor part of the bracket is at least B, and Delta(k)>=g. Thus every omitted term has value at least

    K+d+g=K+(p^2-1)/2 > K+p.                                (3.8)

For the N-floor assertion, write k=lN+v with 0<v<N: c-2floor((cN-k)/(2N))-l is either 1 or 2. All lower floor deficits are nonnegative. No large-c weakening occurs.

## 4. Uniform depth of the exceptional roots

We prove v(f(-1))>p without claiming an exact deeper root depth. First prove the corresponding order bound in characteristic p; then transfer the ORIGINAL integer polynomial using its coefficient lattice.

Throughout this section q=1+t in F_p((t)), extended algebraically to contain X with X^2=-t^p and v0 near i. Thus v(X)=v(z+1)=rho. All rational Newton identities remain legal: every q-factorial denominator is nonzero as a formal rational function.

### 4.1 A grouped product identity

For indeterminates Z,A,h in characteristic p,

    product_(a=0)^(p-1)(Z+A(1+h)^a)-(Z+A)^p
        is divisible by h^(p-1).                            (4.1)

Indeed, each intermediate coefficient contains the Gaussian binomial [p choose k]_(1+h), 1<=k<p. Its order at h=0 is p-1: only the numerator factor 1-(1+h)^p has order p, all other numerator and denominator factors have order 1. The extreme coefficient difference (1+h)^(p(p-1)/2)-1 has order >=p. This proves the polynomial divisibility, not merely a pointwise heuristic.

Put

    R0=product_(j=1)^(p-1)(q^j-1),
    D0=product_(1<=j<2p, j odd, j!=p)(1-q^j),
    C0=w_(2N)/Q_N=product_(j=1)^N(1-q^(2j-1)).

Grouping N_N by j=b+ap, 0<=a,b<p, uses h=q^p-1=t^p in (4.1). The relative error is at least p(p-2)/2>p in the b=0 group, and at least p(p-2)>p otherwise. Consequently

    N_N=N_p^p(1+error of value >p).                           (4.2)

For C0 group the odd indices as 2b+1+2ap. All groups not divisible by p have relative error >p by (4.1), with h=q^(2p)-1. The remaining group is EXACTLY

    product_(a=0)^(p-1)(1-q^(p(2a+1)))
         =[(1-q^p)D0]^p.

Multiplying gives

    C0=-t^N D0^(2p)(1+error of value >p).                     (4.3)

Write N_p=S R, S=z+1 and R=product_(j=1)^(p-1)(z+q^j). Replacing each z+q^j by q^j-1 has relative error rho-1>1. Also z=-1+error of value rho>1. Direct first-order multiplication gives

    R0/t^(p-1)=-(1+t/2+O(t^2)),
    D0/t^(p-1)=-(1+t/2+O(t^2)).                              (4.4)

Both index sets reduce to F_p^*, giving the constant -1. Their sums of (j-1)/2 are both 1/2 modulo p, giving the stated linear coefficient. Since S^2=-zt^p,

    N_p^2-t^p D0^2=-t^p(zR^2+D0^2)

has value strictly greater than (3p-2)+1. Its p-th power, (4.2), and (4.3) prove the crucial scalar relation

    v(N_N^2+C0)>W+p,  v(N_N^2)=v(C0)=W.                     (4.5)

This general scalar relation is the cancellation mechanism; it is not an extrapolation from c=2 roots.

### 4.2 All leading-digit pivots reduce to A_c

For 0<=h<=c, grouping q-factorials into N-blocks gives

    w_(hN)=h! w_N^h(1+error of value >=B),
    Q_(hN)=h! Q_N^h(1+error of value >=B),                    (4.6)

whenever the displayed Q index is used. For an internal index 0<i<N, shifting by lN changes its edge by a term of order N, whereas its original edge has order at most p; the relative order is >=N-p=B>p. At block endpoints the ratio is (l+1)+O(t^N), a unit since h<p. This proves (4.6) uniformly, including c=p-1. Similarly

    N_(jN)=N_N^j(1+error of value >=N-rho),                   (4.7)

because every original factor has value at most rho and a block shift changes it by order >=N. Here N-rho>p.

For the k=jN pivot of H_(cN), put u=(c-j)/2. Equations (4.6)-(4.7), and w_(2N)=2w_N^2(1+error >p), give

    w_(cN) N_(jN)/[w_(jN) Q_(uN)]
      = c! C0^u N_N^j/[j! 2^u u!] + error of value >K+p.    (4.8)

For j=0 the empty factors are exactly 1; the same formula applies. Since j is even, (4.5) replaces N_N^j by (-C0)^(j/2) with the same relative error. Summing (4.8) and including the complete nonpivot bound (3.8),

    H_(cN)(z)=C0^(c/2) A_c + error of value >K+p.             (4.9)

When p divides A_c, the first term is exactly zero in characteristic p. The unit prefactor in (2.3) therefore gives v(P_(cN)(X))>K+p.

The full neighbor bound (3.2) remains valid in this formal field, so

    v(a_(cN)M/X)>=N+E-rho=K+d>K+p.

By (2.7), F evaluated at X^2=-t^p has characteristic-p order >K+p.

### 4.3 Integer coefficient lattice and every s>2

Let m=cN/2. Before specialization, the coefficient of X^(2l) in the even polynomial P_(2m+1)/X is an integer polynomial in t, every monomial of which contains m-l recurrence edges. Each edge (1+t)^j-1 is divisible by t. Substitution X^2=-t^p therefore gives raw t degree at least

    m-l+pl=m+(p-1)l>=m.                                    (4.10)

Equivalently, the exact parity recurrence is

    E_0=O_0=1,
    E_k=t^p(U)O_(k-1)+[(1+t)^(2k-1)-1]E_(k-1),
    O_k=E_k+[(1+t)^(2k)-1]O_(k-1), 1<=k<=m,

with E_k=P_(2k), O_k=P_(2k+1)/X and X^2=t^p U. This also proves the lattice by induction.

After setting U=-1, F is an ORIGINAL integer polynomial in t. The characteristic-p calculation says all its coefficients of t degree <=K+p are divisible by p. Every such integer monomial has actual valuation at least e+m. For every allowed s and c,

    e+m-K >= pB-cB=(p-c)B >=B>p.                            (4.11)

Every coefficient not divisible by p has degree >K+p. Thus every term, including ALL discarded p-divisible terms and all cyclotomic effects, has actual value >K+p. We conclude

    v(f(-1))>p                                              (4.12)

at every primitive q phase and every s>2. The false shortcut e>K+p is unnecessary and can fail; the raw lattice (4.10) is essential.

### 4.4 All affected roots, not one branch

Write h(V)=f(-1+V)=sum_j a_j V^j. Translation preserves coefficientwise integrality of f and the >=d bound for its ordinary derivative. Its reduction is R_c(-1+V)^p; because R_c'(-1) is a unit, a_p is a unit and all lower coefficients reduce to zero. For 1<=j<p, j is a p-adic unit, so v(a_j)>=d. Also v(a_0)>p by (4.12).

At any exceptional root V with 0<v(V)<=1, the a_p V^p term is uniquely lowest: its value p v(V)<=p is below the constant, below every j<p term since d>p, and below all j>p terms by integrality. This contradicts h(V)=0. Hence EVERY one of the exceptional roots has

    v(U+1)=v(V)>1.                                         (4.13)

Multiplicity was not presumed or used in this argument.

## 5. Uniform first correction of the ORIGINAL derivative ratio

At any affected root M has exact value E by (2.6), so division by M is legal. Pair the l-th terms in (3.6) and (3.3). Their EXACT ratio is

    a_(cN) z^(N-1) Q_(uN+A)/[Q_(uN) a_N].                   (5.1)

For 1<=i<=A<N, the ratio of the shifted factor 1-q^(2uN+2i) to 1-q^(2i) is 1+error of value >=B. Thus

    Q_(uN+A)/Q_(uN)=Q_A(1+error of value >=B),               (5.2)

uniformly in u. This is why summing many pivots creates no new scalar obstruction. The complete nonpivot gaps g>1 in Section 3 ensure, at these points,

    H_(cN)'=a_(cN) z^(N-1) Q_A H_(cN-1)/a_N
                + error of value >D+1.                    (5.3)

Each summand's error has this bound individually, so cancellation among leading pivots cannot invalidate it. The sum H_(cN-1) has exact value E at the affected points.

Under the original ordinary coordinate formula (2.3), the prefactor derivative cN P_(cN) has value >=2e+K>D+1. Consequently (5.3) gives

    X^2 P_(cN)'/[a_(cN)M]
      =X^2 [2z^N/(z-1)] Q_A/a_N + error of value >1.         (5.4)

This is an ordinary derivative identity modulo a controlled error, not the derivative of the reduced residual.

The coordinate factor 2z^N/(z-1)=1+error of value >1 because z=-1+error of value rho>1. Also a_N/(-t^N)=1+error of value >1: all intermediate binomial coefficients of (1+t)^N are divisible by p, and e+1-N>1.

It remains to retain the ACTUAL first-order q-factorial coefficient. Put a=(p-1)/2, so A=ap+a. For an edge index not divisible by p,

    (1-q^j)/t=-j[1+(j-1)t/2]+error of relative value >1.

For j=p l<N, (1-q^j)/t^p=-l+error of value >1. This follows by reducing (1+t)^(pl) modulo p and using e+1-p>1 for the removed terms. Thus the p-divisible Q_A indices contribute no linear t correction. The leading product unit is -1: modulo p it is

    (-2)^A (-1)^a (a!)^2=-1

by Wilson, since A is divisible by p-1. The linear coefficient from all other factors is

    sum_(1<=j<=A,p not dividing j)(2j-1)/2
       =a/2+a^2/2=(p^2-1)/8=-1/8 mod p.

Constant and linear coefficient differences divisible by p have value >1 after normalization. Therefore, in the ORIGINAL mixed-characteristic field,

    Q_A/(-t^B)=1-t/8+error of value >1.                     (5.5)

Using N=B+p and X^2=t^p U, equation (5.4) becomes

    X^2 P_(cN)'/[a_(cN)M]=U(1-t/8)+error of value >1.        (5.6)

The exact ordinary derivative of (2.7) is

    F'=P_(cN)'-a_(cN)M'/X+a_(cN)M/X^2.                     (5.7)

Relative to the last term, the middle term has value at least rho>1 since v(M')>=E=v(M). By (4.13), U=-1+error of value >1. Therefore the whole bracket multiplying the last term of (5.7) is

    1+X^2P_(cN)'/[a_(cN)M]-X M'/M
         =t/8+error of value >1.                            (5.8)

Since v(a_(cN)M/X^2)=N+E-p=D, this proves v(F')=D+1 and v(P_n')=D+rho+1=K+d+1 at every affected root. ALL nonpivot ordinary derivative terms, the coordinate prefactor, and the M' term have now been bounded explicitly.

## 6. The normalized units and the accepted c8 comparison

From (2.5) and (5.7), write

    f_U(U)=[t^p a_(cN)M/(2X^3 t^K)]
           [1+X^2P_(cN)'/(a_(cN)M)-X M'/M].                (6.1)

The first bracket has value d. Using (2.6) and a_(cN)/t^N -> -c, its normalized residue is

    (-c epsilon/2) M_(c-1)(Y^p)/Y^3.                        (6.2)

At either exceptional residual Y with Y^2=-1, Y^p=epsilon Y. Since M_(c-1) is odd and M_c'(Y)=cM_(c-1)(Y)=2Y R_c'(-1), expression (6.2) is

    -c M_(c-1)(Y)/(2Y^3)=R_c'(-1).                          (6.3)

It is independent of the two choices of Y and is nonzero. Combining (5.8) with (6.3) proves the stated residue of f_U. At an F root, the EXACT original relation is

    P_n'(X)=X F'(X)=2U t^K f_U(U).                           (6.4)

Its normalized residue is therefore -R_c'(-1)/4, not R_c'(-1)/8.

For the accepted fixed case c=8,p=11,

    R_8(U)=U^4+28U^3+210U^2+420U+105,
    R_8(-1)=-132, R_8'(-1)=80=3 mod 11,
    K=1364, d=55,
    f_U/t^56 -> 80/8=10 mod 11,
    P_969'/t^1420 -> -80/4=2 mod 11.

These agree exactly with equations (5.1) and (5.2) of the accepted c8 report. Its sharper v(U+1)=5 is compatible with (4.13) but is not needed or claimed uniformly here. Its finite integer jets are not used to prove any assertion in Sections 3-6.

At an original H_n root, the derivative multiplier in (2.3) has residue i^(n-1)=(-1)^(c/2). Hence the exceptional H derivative residue, if wanted with this branch, is (-1)^(c/2) times the P residue; valuations are identical. At c=8 this factor is 1 and the accepted H residue 2 is recovered. There is no claim that the H and P units coincide for all even c.

## 7. Every phase, remaining disks, the p=3 boundary, and the kernel

All estimates used only v(t)=1, e>=(p-1)p^2, integer coefficients, and explicit residue units. The lattice argument treats the actual integer polynomial at every primitive q, rather than choosing one cyclotomic phase or testing s=3 and extrapolating. All exceptional residual branches and both X signs are included in (4.13), (5.8), and (6.3).

Noncentral disks, regular central roots, and the exact zero retain the accepted values stated in Section 1. The p=3 case has necessarily c=2. The accepted exact original P_19 certificate proves v(U+1)=4/3 and v(P_19')=76/3 uniformly for all e>=18. Here g=1, so the present first-order nonpivot exclusion would be false; the report does not use it. This is explicitly inherited work, not a new p=3 claim.

At any nonzero F root P_n'=X F', now nonzero. At zero, the accepted F(0) value K is finite. Thus P_n is squarefree. Modulo the maximal ideal P_n=X^n and H_n=(1+z)^n, so P roots are not +/-2 and H roots are nonzero. The coordinate maps (2.3) have unit derivatives and the P_n prefactor term vanishes exactly at roots. Multiplicities and ordinary derivative valuations therefore transfer to H_n.

Every original edge a_j for 1<=j<n is nonzero. A common root of P_n and P_(n-1) would propagate backward to P_0=1. The ORIGINAL ordinary Christoffel-Darboux identity at a root xi is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
        =P_n'(xi)P_(n-1)(xi)/w_(n-1).

Each right-hand factor is nonzero. These are algebraic squares, not absolute-value squares; no positivity, interlacing, real-rootedness, or Fourier assertion is used. Injectivity of the chosen algebraic p-adic embedding and Galois conjugacy transfer nonvanishing to all characteristic-zero primitive embeddings.

## 8. Controls, provenance of the argument, and review gate

The mathematical proof is uniform in c,p,s. The controls are deliberately bounded falsification/transcription checks, not an expanded census of exceptional pairs and not a substitute for the proof. They check every Newton/ordinary derivative index in a few structural fixtures, the exact central slack, grouped-product divisibility, block-factorial first-order arithmetic, the coefficient-lattice inequalities including the prime boundary c=p-1, and exact original two-jet consistency at already accepted c=2,p=5 and c=8,p=11 fixtures. The p=3 nonpivot gap is retained as a negative control. The latter jets serve solely to falsify normalization mistakes; the new uniform theorem does not depend on them.

The c=2 first-order scalar and grouped-product mechanism were read from its accepted report. The new ingredients are the uniform multi-pivot gaps and pairing, the block-factorial reduction of all H_(cN) pivots to C0^(c/2) A_c, and the general coefficient-lattice inequality (4.11). The c8 exact calculation is a comparison, not newly credited work. No historical novelty is claimed.

The candidate is frozen with a complete inventory, copied accepted dependencies, resource-capped read-only cold replay, and source hashes. A fresh reviewer must check the exact frozen proof, all uniform inequalities, original ordinary derivatives, and independent replay. Until that review accepts the exact bytes, this remains an author candidate. Previous sources remain unchanged. No upload, commit, or other external write is part of this work.
