#!/usr/bin/env python3
"""Pinned inventory verification and isolated replay of NEW controls only."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import resource
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
PINS = {
    "dependencies/plus-four-author": "034f2bc80d57645a26c29e9741c3f990bb4ee70a7d3bfb50be418e6b61abbe3d",
    "dependencies/plus-four-review": "464d13793dbd212d4b56e631ce009949fc55c966ed4396e26014f3a5b48725a5",
    "dependencies/plus-four-author/dependencies/plus-two-author": "7c6c4cc80ff940e1b3a620727a096befc18d214770a9d27afb0cd3cb7372bc29",
    "dependencies/plus-four-author/dependencies/plus-two-review": "1bb903312caa601b4f5fff2a24e8dbad6fcc157f440639759eebbe22799800e0",
    "dependencies/plus-four-author/dependencies/plus-two-author/dependencies/general-author": "e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7",
    "dependencies/plus-four-author/dependencies/plus-two-author/dependencies/general-review": "a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7",
}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, "Duplicate JSON key")
        out[key] = value
    return out


def parse(data):
    return json.loads(data, object_pairs_hook=unique)


def safe(name):
    need(isinstance(name, str), "Invalid path type")
    p = PurePosixPath(name)
    need(bool(name) and "\\" not in name and not p.is_absolute() and ".." not in p.parts and "." not in p.parts and str(p) == name, "Unsafe path")
    return p


def check_tree(root, pin):
    root = Path(root)
    need(root.is_dir() and not root.is_symlink(), "Invalid or symlink root")
    need(isinstance(pin, str) and len(pin) == 64 and all(c in "0123456789abcdef" for c in pin), "Invalid external pin")
    for path in root.rglob("*"):
        need(not path.is_symlink() and (path.is_file() or path.is_dir()), "Symlink or special member")
    data = (root / "MANIFEST.json").read_bytes()
    need(digest(data) == pin, "Externally pinned manifest mismatch")
    manifest = parse(data)
    seal = parse((root / "SEAL.json").read_bytes())
    need(seal.get("manifest_sha256") == pin, "Seal mismatch")
    need(isinstance(manifest.get("files"), list), "Invalid inventory schema")
    known = {"MANIFEST.json", "SEAL.json"}
    for row in manifest["files"]:
        need(isinstance(row, dict), "Invalid inventory row")
        name = row.get("path")
        path = safe(name)
        need(name not in known, "Duplicate inventory member")
        known.add(name)
        need(type(row.get("bytes")) is int and row["bytes"] >= 0, "Invalid byte count")
        sha = row.get("sha256")
        need(isinstance(sha, str) and len(sha) == 64 and all(c in "0123456789abcdef" for c in sha), "Invalid file digest")
        content = (root / path).read_bytes()
        need(len(content) == row["bytes"] and digest(content) == sha, "File mismatch: " + name)
    actual = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()}
    need(actual == known, "Exact inventory file set mismatch")
    expected_dirs = set()
    for name in known:
        expected_dirs.update(str(p) for p in PurePosixPath(name).parents if str(p) != ".")
    actual_dirs = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_dir()}
    need(actual_dirs == expected_dirs, "Unexpected or missing directory")
    if "directories" in manifest:
        dirs = manifest["directories"]
        need(isinstance(dirs, list) and len(set(dirs)) == len(dirs), "Invalid directory inventory")
        for name in dirs:
            safe(name)
        need(set(dirs) == actual_dirs, "Directory inventory mismatch")
    return {"manifest_sha256": pin, "files": len(manifest["files"]), "directories": len(actual_dirs)}


def sources(root=ROOT):
    binding = parse((root / "SOURCE_BINDINGS.json").read_bytes())
    need(binding["complete_source_pins"] == PINS, "Source pin schema mismatch")
    result = {name: check_tree(root / name, pin) for name, pin in PINS.items()}
    for author, reviewer, prefix in (
        ("dependencies/plus-four-author", "dependencies/plus-four-review", "candidate"),
        ("dependencies/plus-four-author/dependencies/plus-two-author", "dependencies/plus-four-author/dependencies/plus-two-review", "candidate"),
        ("dependencies/plus-four-author/dependencies/plus-two-author/dependencies/general-author", "dependencies/plus-four-author/dependencies/plus-two-author/dependencies/general-review", "author"),
    ):
        verdict = parse((root / reviewer / "VERDICT.json").read_bytes())
        bound = parse((root / reviewer / "SOURCE_BINDING.json").read_bytes())
        need(verdict["verdict"] == "ACCEPTED_WITHIN_EXACT_STATED_SCOPE", "Source is not accepted")
        need(verdict[prefix + "_manifest_sha256"] == bound[prefix + "_manifest_sha256"] == PINS[author], "Review-to-author binding")
        report_sha = digest((root / author / "REPORT.md").read_bytes())
        need(bound[prefix + "_report_sha256"] == report_sha, "Review-to-report binding")
        if prefix + "_report_sha256" in verdict:
            need(verdict[prefix + "_report_sha256"] == report_sha, "Verdict-to-report binding")
    need(binding["predecessor_controls_executed"] is False, "Predecessor replay prohibited")
    return result


def limits():
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE, (2 * 1024**2, 2 * 1024**2))


def replay(optimized=False):
    start = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="f020-uniform-even-replay-") as temp:
        directory = Path(temp)
        shutil.copyfile(ROOT / "check_controls.py", directory / "check_controls.py")
        command = [sys.executable, "-I", "-B"] + (["-O"] if optimized else []) + [str(directory / "check_controls.py"), "--write"]
        process = subprocess.run(command, cwd=directory, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30, preexec_fn=limits)
        need(process.returncode == 0, "New control replay failed: " + process.stdout.decode(errors="replace"))
        results = (directory / "CONTROL_RESULTS.json").read_bytes()
        need(results == (ROOT / "CONTROL_RESULTS.json").read_bytes(), "New replay result mismatch")
        need(process.stdout == (ROOT / "CONTROL_RUN.log").read_bytes(), "New replay stdout mismatch")
    return {"optimized": optimized, "status": "PASS_BYTE_FOR_BYTE", "result_sha256": digest(results), "wall_seconds": round(time.monotonic() - start, 3), "caps": {"cpu_seconds": 20, "wall_seconds": 30, "address_space_bytes": 256 * 1024**2, "output_bytes": 2 * 1024**2}, "isolation": "Python -I, disposable directory, rlimits; not an OS/network sandbox"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--expected-manifest", required=True)
    ap.add_argument("--replay", action="store_true")
    ap.add_argument("--optimized", action="store_true")
    ap.add_argument("--output")
    args = ap.parse_args()
    own, deps = check_tree(ROOT, args.expected_manifest), sources()
    result = {"status": "INTEGRITY_PASS", "candidate": own, "sources": deps, "self_acceptance": False, "predecessor_controls_executed": False, "external_writes": False}
    if args.replay:
        result["cold_replay"] = replay(args.optimized)
        need(check_tree(ROOT, args.expected_manifest) == own and sources() == deps, "Frozen inputs changed")
        result["status"] = "INTEGRITY_AND_NEW_COLD_REPLAY_PASS"
    data = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        path = Path(args.output).resolve()
        need(ROOT not in path.parents and path != ROOT, "Receipt must be outside frozen candidate")
        path.write_text(data)
    print(data, end="")


if __name__ == "__main__":
    main()
