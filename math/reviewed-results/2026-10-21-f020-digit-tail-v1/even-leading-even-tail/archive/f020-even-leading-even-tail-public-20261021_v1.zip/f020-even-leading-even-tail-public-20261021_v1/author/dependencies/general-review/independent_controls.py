#!/usr/bin/env python3
"""Independent controls authored for the general adjacent criterion review.
No candidate or prior-review code is imported. Finite checks do not prove the theorem.
"""
import argparse, hashlib, json, math, time
from pathlib import Path
import numpy as np
import sympy as sy


def vp(a,p):
    if not a: raise ValueError('valuation of zero')
    v=0
    while a%p==0: a//=p; v+=1
    return v


def data(p,c,r):
    N=p**r; h=r//2; beta=p**h
    rho2=beta if r%2==0 else p**(h-1)*(2*p-1)
    W=[0]; R2=[0]
    for j in range(1,c*N+2):
        x=p**vp(j,p); W.append(W[-1]+x); R2.append(R2[-1]+max(0,2*x-rho2))
    B=r*(p-1)*p**(r-1)//2
    return N,beta,rho2,W,R2,B


def polys(c):
    # Integer recurrence rather than the candidate's factorial formula.
    a=[1];b=[0,1]
    if c==0:return a
    for n in range(1,c):
        z=[0]+b
        for k,v in enumerate(a):z[k]+=n*v
        a,b=b,z
    return b


def elementary():
    output=[];count=0
    rows=[(p,c,2) for p in [3,5,7,11,13,17,19] for c in range(2,p,2)]
    rows += [(3,2,3),(3,2,4),(5,2,3),(5,4,3),(5,4,4),(7,6,3)]
    for p,c,r in rows:
        N,beta,rho2,W,R2,B=data(p,c,r); n=c*N;b=n-1
        K2=c*W[N];E2=K2-N;D2=E2+2*N-2*p
        assert all(a<=w for a,w in zip(R2[:n+1],W[:n+1]))
        assert [j for j in range(n+1) if R2[j]==W[j]]==list(range(0,n+1,N))
        assert all(W[b-j]==W[b]-W[j] for j in range(b+1))
        near=[2*W[b]-2*W[(b-k)//2]-R2[k] for k in range(1,b+1,2)]
        assert min(near)==E2
        assert [2*i+1 for i,x in enumerate(near) if x==E2]==list(range(N,n,2*N))
        ordinary=[2*p**vp(j,p)-W[j-1] for j in range(1,n+1)]
        assert max(ordinary)==2*p and [j+1 for j,v in enumerate(ordinary) if v==2*p]==[p*p]
        odd=[2*p**vp(j,p)-W[j] for j in range(1,b+1)]
        assert max(odd)==1 and [j+1 for j,v in enumerate(odd) if v==1]==[1,p]
        pairdata=None
        if n<=1000:
            eq=[];mmin=None
            for k in range(2,n+1,2):
                for m in range(k):
                    v=2*W[n]-2*W[(n-k)//2]-R2[m]-2*p**vp(k-m,p);count+=1
                    assert v>=D2
                    if v==D2:eq.append([k,m])
            assert eq==[[l*N+p*p,l*N] for l in range(1,c,2)]
            for k in range(1,b+1,2):
                for m in range(k):
                    v=2*W[b]-2*W[(b-k)//2]-R2[m]-2*p**vp(k-m,p);count+=1
                    assert v>=E2
                    mmin=v if mmin is None else min(v,mmin)
            pairdata={'base_equalities':eq,'neighbor_derivative_min_twice':mmin}
        assert rho2<N and (rho2==p)==(r==2)
        assert all(2*p**vp(a,p)!=p for a in range(1,beta))
        assert 2*r*(p-1)*p**r>N-2*p
        output.append({'p':p,'c':c,'r':r,'K_twice':K2,'E_twice':E2,'D_twice':D2,'rho_twice':rho2,'full_pair_data':pairdata})
    U=sy.Symbol('U');Z=sy.Symbol('Z');Y=sy.Symbol('Y');hermite=[]
    for p in sy.primerange(3,80):
        for c in range(2,p,2):
            mc=polys(c);mm=polys(c-1)
            f=sy.Poly(sum(v*Z**j for j,v in enumerate(mc)),Z,modulus=p)
            g=sy.Poly(sum(v*Z**j for j,v in enumerate(mm)),Z,modulus=p)
            assert sy.gcd(f,g).degree()==0
            assert f.diff()==g.mul_ground(c)
            rc=sy.Poly(sum(v*U**(j//2) for j,v in enumerate(mc) if v),U,modulus=p)
            assert sy.gcd(rc,rc.diff()).degree()==0 and int(rc.eval(0))%p
            A=sum(v*(-1)**(j//2) for j,v in enumerate(mc) if v)
            assert (sy.gcd(rc,sy.Poly(U+1,U,modulus=p)).degree()==1)==(A%p==0)
            hermite.append({'p':int(p),'c':c,'A_mod_p':A%p})
    special=[]
    for c,p in [(2,3),(2,5),(2,7),(4,5),(6,7),(8,11),(10,19),(12,311),(14,719),(16,17),(16,29)]:
        mc=polys(c);mm=polys(c-1)
        A=sum(v*(-1)**(j//2) for j,v in enumerate(mc) if v)
        root=sy.Poly(sum(v*Y**(j*p) for j,v in enumerate(mc) if v),Y,modulus=p) if p<=19 else None
        eps=(-1)**((p-1)//2)
        ds={}
        for j,v in enumerate(mm):
            if v:
                for k in [j*p,j*p-2]:ds[k]=(ds.get(k,0)-c*eps*v)%p
        der=sy.Poly(sum(v*Y**j for j,v in ds.items()),Y,modulus=p)
        if root is not None:
            gd=sy.gcd(root,der).degree()
        else:
            rc=sy.Poly(sum(v*U**(j//2) for j,v in enumerate(mc) if v),U,modulus=p)
            gd=2*sy.gcd(rc,sy.Poly(U+1,U,modulus=p)).degree()
            assert sy.gcd(rc,rc.diff()).degree()==0
        assert gd==(2 if A%p==0 else 0)
        assert (A==0)==(c==2) # Only this explicitly listed range, no universal inference.
        special.append({'c':c,'p':p,'A_integer':A,'residual_gcd_degree':gd,'cancellation_root_count':2*p if gd else 0,'gcd_method':'full_Y_polynomial' if root is not None else 'squarefree_R_and_Frobenius'})
    arithmetic=[]
    a=[1,0]
    for m in range(2,151):a.append((2*m-2)*(2*a[-1]-(2*m-3)*a[-2]))
    for m in range(2,151):
        direct=sum(v*(-1)**(j//2) for j,v in enumerate(polys(2*m)) if v)
        assert direct==a[m]
        if m%2==0:assert vp(a[m],2)==m//2
        else:assert vp(a[m],2)>=m//2+3
    for c in range(2,21,2):
        f=sy.Poly(sum(v*Z**j for j,v in enumerate(polys(c))),Z)
        g=sy.Poly(sum(v*Z**j for j,v in enumerate(polys(c-1))),Z)
        assert sy.resultant(f,g)==math.prod(j**j for j in range(1,c))
        rc=sy.Poly(sum(v*U**(j//2) for j,v in enumerate(polys(c)) if v),U)
        assert sy.resultant(rc,sy.Poly(U+1,U))==(-1)**(c//2)*a[c//2]
        arithmetic.append({'c':c,'A':a[c//2],'Hermite_resultant':int(sy.resultant(f,g))})
    return {'inequality_rows':output,'complete_term_pairs':count,'Hermite_checks':hermite,'explicit_cases':special,'resultants':arithmetic,'obstruction_recurrence_and_2adic_bound_max_c':300}


class Cyclotomic:
    def __init__(self,p,s,k):
        self.p=p;self.s=s;self.k=k;self.mod=p**k;self.order=p**s;self.step=p**(s-1);self.e=(p-1)*self.step
        self.convert=np.zeros((self.e,self.e),dtype=np.int64)
        for d in range(self.e):
            z=1
            for j in range(d+1):
                self.convert[d,j]=z%self.mod;z=z*(d-j)//(j+1)
        assert self.e*(self.mod-1)**2<2**63
    def recurrence(self,last):
        # Parity-compressed ordinary P recurrence in (Z/p^k)[q]/(q^order-1).
        before=np.zeros((1,self.order),dtype=np.int64);before[0,0]=1
        now=before.copy();saved={}
        for n in range(1,last):
            nxt=np.zeros(((n+1)//2+1,self.order),dtype=np.int64)
            nxt[:len(now)]+=now
            nxt[1:1+len(before)]-=before
            nxt[1:1+len(before)]+=np.roll(before,n,axis=1)
            nxt%=self.mod;before,now=now,nxt
            if n+1>=last-2:saved[n+1]=now.copy()
        return saved
    def coefficients(self,a):
        # Canonical quotient by Phi_(p^s)(q); then q=1+t, degree<e.
        z=a[:,:self.e].copy();tail=a[:,self.e:]
        for b in range(self.p-1):z[:,b*self.step:(b+1)*self.step]-=tail
        return ((z%self.mod)@self.convert)%self.mod
    def initial(self,a,degree,rho2,threshold2,derivative=False,divide_x=False):
        t=self.coefficients(a);out={};actual=None
        for index,row in enumerate(t):
            exponent=degree-2*index-(1 if divide_x else 0)
            if exponent<0:assert not np.any(row);continue
            multiplier=exponent if derivative else 1
            exponent-=int(derivative)
            if not multiplier:continue
            rawrow=(row*multiplier)%self.mod
            bound2=2*self.k*self.e+exponent*rho2
            assert bound2>threshold2
            best=None;unit=None
            for j,value in enumerate(rawrow):
                a0=int(value)
                if a0:
                    v=vp(a0,self.p);weight=2*(j+v*self.e)+exponent*rho2
                    if best is None or weight<best:best=weight;unit=(a0//self.p**v)*(-1)**v%self.p
            if best is None:continue
            assert best>=threshold2,(self.p,degree,exponent,best,threshold2)
            actual=best if actual is None else min(actual,best)
            if best==threshold2:out[exponent]=unit
        return dict(sorted(out.items())),actual


def fields():
    result=[]
    for p,c,r,s in [(3,2,2,3),(5,2,2,3),(5,4,2,3),(5,4,2,4),(7,6,2,3),(11,8,2,3),(3,2,3,4),(3,2,4,5),(5,4,3,4)]:
        start=time.monotonic();N,beta,rho2,W,R2,B=data(p,c,r);n=c*N
        K2=c*W[N];E2=K2-N;D2=E2+2*N-2*p;DF2=min(D2,2*N+E2-2*rho2)
        e=(p-1)*p**(s-1);k=max(K2,E2,D2)//(2*e)+2
        ring=Cyclotomic(p,s,k);values=ring.recurrence(n+1)
        F,_=ring.initial(values[n+1],n+1,rho2,K2,divide_x=True)
        P,_=ring.initial(values[n],n,rho2,K2)
        M,_=ring.initial(values[n-1],n-1,rho2,E2)
        DP,_=ring.initial(values[n],n,rho2,D2,derivative=True)
        DM,dmbest=ring.initial(values[n-1],n-1,rho2,E2,derivative=True)
        DF,_=ring.initial(values[n+1],n+1,rho2,DF2,derivative=True,divide_x=True)
        assert F==P and F.get(0,0)!=0
        mc=polys(c);mm=polys(c-1)
        if r==2:
            eps=(-1)**((p-1)//2)
            expF={j*p:v%p for j,v in enumerate(mc) if v%p}
            expM={j*p:eps*v%p for j,v in enumerate(mm) if v%p}
            expDP={j*p:-c*eps*v%p for j,v in enumerate(mm) if v%p}
            expDF={}
            for j,v in expM.items():
                for x in [j,j-2]:expDF[x]=(expDF.get(x,0)-c*v)%p
            expDF={j:v for j,v in expDF.items() if v}
            assert (F,M,DP,DF)==(expF,expM,expDP,expDF),(p,c,F,M,DP,DF,expF,expM,expDP,expDF)
            assert not DM
        else:
            expDF={j-2:-c*v%p for j,v in M.items() if v%p}
            assert DF==expDF
        Y=sy.Symbol('Y')
        poly=lambda a:sy.Poly(sum(v*Y**j for j,v in a.items()),Y,modulus=p)
        gd=sy.gcd(poly(F),poly(DF)).degree()
        A=sum(v*(-1)**(j//2) for j,v in enumerate(mc) if v)
        assert gd==(2 if r==2 and A%p==0 else 0)
        result.append({'p':p,'c':c,'r':r,'s':s,'precision_power':k,'precision_valuation':k*e,'K_twice':K2,'E_twice':E2,'D_twice':D2,'quotient_derivative_threshold_twice':DF2,'F':F,'M':M,'P_derivative':DP,'F_derivative':DF,'M_derivative_min_twice':dmbest,'gcd_degree':gd,'elapsed_seconds':round(time.monotonic()-start,3)})
    return {'arithmetic':'Original P recurrence with ordinary derivative multipliers; canonical cyclotomic q-to-t conversion, p/t^e residual -1, and certified finite precision strictly above thresholds. No candidate code imported.','rows':result}


def exact_identities():
    # Rational q=2/7 avoids any root-of-unity truncation; all equalities exact.
    q=sy.Rational(2,7);X,Z,V=sy.symbols('X Z V');P=[sy.Integer(1),X];H=[sy.Integer(1),1+Z];W=[sy.Integer(1)];Q=[sy.Integer(1)];N=[sy.Integer(1)]
    for j in range(1,11):
        W.append(W[-1]*(1-q**j));Q.append(Q[-1]*(1-q**(2*j)));N.append(sy.expand(N[-1]*(Z+q**(j-1))))
        if j<10:
            P.append(sy.expand(X*P[-1]-(1-q**j)*P[-2]));H.append(sy.expand((1+Z)*H[-1]-Z*(1-q**j)*H[-2]))
    for b in range(1,11):
        newton=sum(W[b]*N[k]/(W[k]*Q[(b-k)//2]) for k in range(b%2,b+1,2))
        derivative=sum(W[b]*Z**(k-m-1)*N[m]/(Q[(b-k)//2]*W[m]*(1-q**(k-m))) for k in range(b%2,b+1,2) for m in range(k))
        assert sy.expand(H[b]-newton)==0
        assert sy.expand(sy.diff(H[b],Z)-derivative)==0
        assert sy.expand(H[b].subs(Z,V**2)-V**b*P[b].subs(X,V+1/V))==0
        cd=sy.diff(P[b],X)*P[b-1]-P[b]*sy.diff(P[b-1],X)
        kernel=sum(P[j]**2/W[j] for j in range(b))
        assert sy.expand(cd/W[b-1]-kernel)==0
    return {'q':'2/7','max_degree':10,'Newton':'passed','ordinary_derivative':'passed','H_P':'passed','ordinary_algebraic_square_CD':'passed'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['elementary','fields','identities','all'],default='all');ap.add_argument('--output',required=True);args=ap.parse_args();t=time.monotonic();out={}
    if args.mode in ('all','elementary'):out['elementary']=elementary()
    if args.mode in ('all','fields'):out['fields']=fields()
    if args.mode in ('all','identities'):out['identities']=exact_identities()
    out['elapsed_seconds']=round(time.monotonic()-t,3);out['status']='PASS';Path(args.output).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':'PASS','elapsed_seconds':out['elapsed_seconds'],'output':args.output}))
if __name__=='__main__':main()
