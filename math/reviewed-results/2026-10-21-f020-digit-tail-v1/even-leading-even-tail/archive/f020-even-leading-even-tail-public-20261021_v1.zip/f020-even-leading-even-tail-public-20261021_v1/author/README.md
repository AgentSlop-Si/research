# Uniform even-leading, even-short-tail author candidate

Read REPORT.md for the exact theorem and proof. This candidate covers n=c*p^r+d for every odd prime p, even 2<=c<p, even 2<=d<p, r>=2, s>r, and every characteristic-zero primitive p^s phase. It proves original P/H squarefreeness and original algebraic-square CD nonvanishing from the explicitly accepted general-c coefficientwise inputs, with no adjacent-obstruction hypothesis.

High root count: cL in each of beta disjoint disks, total cN; derivative value D+d/2. Low root count: d; derivative value (n-1)/2. There is no zero root and v(P_n(0))=K+d/2. Both c=p-1 and d=p-1 are included. Prior c=2 even tails and c=4,d=2 retain their original credit. No arbitrary-n, global F020/F023, FFT/cost, or historical-novelty claim is made.

All accepted packages are preserved unchanged under dependencies. SOURCE_BINDINGS.json and SOURCE_VERIFICATION.json identify six pinned inventories and the three accepting-review bindings. No dependency program is executed.

To verify, supply the manifest hash received separately, not one inferred from an untrusted modified package:

    python -B verify.py --expect-manifest HASH --replay

This checks source and candidate inventories, then runs only the newly written check_controls.py under normal and optimized Python, comparing output bytes to CONTROL_RESULTS.json. It does not write inside the package. A further new script tests disposable-copy integrity mutations:

    python -B check_freeze_controls.py --expect-manifest HASH

The external postseal receipts are not part of this immutable candidate. Independent review of these exact bytes is still required; this is not self-acceptance. No external repository, document, or Library file was changed.
