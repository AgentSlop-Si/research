#!/usr/bin/env python3
"""Read-only exact inventory checker, independent of source programs."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, why):
    if not condition:
        raise ValueError(why)


def inventory(root, expected):
    require(root.is_dir() and not root.is_symlink(), "invalid package root")
    require(sha(root / "MANIFEST.json") == expected, "manifest pin changed")
    manifest = json.loads((root / "MANIFEST.json").read_text())
    seal = json.loads((root / "SEAL.json").read_text())
    require(seal["manifest_sha256"] == expected, "seal mismatch")
    rows = manifest["files"]
    listed = set()
    for row in rows:
        path = Path(row["path"])
        require(not path.is_absolute() and ".." not in path.parts, "unsafe path")
        require(path.as_posix() not in listed, "duplicate inventory path")
        listed.add(path.as_posix())
        full = root / path
        require(full.is_file() and not full.is_symlink(), "missing or symlink file")
        require(full.stat().st_size == row["bytes"], "size mismatch: " + path.as_posix())
        require(sha(full) == row["sha256"], "hash mismatch: " + path.as_posix())
    all_paths = list(root.rglob("*"))
    require(not any(x.is_symlink() for x in all_paths), "symlink in package")
    actual = {x.relative_to(root).as_posix() for x in all_paths if x.is_file()}
    require(actual == listed | {"MANIFEST.json", "SEAL.json"}, "inventory not exact")
    if "directories" in manifest:
        directories = {x.relative_to(root).as_posix() for x in all_paths if x.is_dir()}
        require(directories == set(manifest["directories"]), "directory inventory not exact")
    return {"manifest_sha256": expected, "listed_files": len(rows),
            "all_files": len(actual), "status": "PASS"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--pin")
    parser.add_argument("--originals", action="store_true")
    args = parser.parse_args()
    root = args.candidate
    result = {"sources": [], "source_programs_executed": False}
    for source in json.loads((root / "SOURCE_BINDINGS.json").read_text())["sources"]:
        observed = inventory(root / source["copy"], source["manifest_sha256"])
        observed["name"] = source["name"]
        if args.originals:
            original = Path(source["source_path"])
            inventory(original, source["manifest_sha256"])
            require((original / "MANIFEST.json").read_bytes() ==
                    (root / source["copy"] / "MANIFEST.json").read_bytes(), "original copy mismatch")
            observed["original_matches_copy"] = True
        result["sources"].append(observed)
    deps = root / "dependencies"
    review = json.loads((deps / "general-review" / "SOURCE_BINDING.json").read_text())
    general_pin = sha(deps / "general-author" / "MANIFEST.json")
    report_pin = sha(deps / "general-author" / "REPORT.md")
    require(review["author_manifest_sha256"] == general_pin, "general acceptance binding")
    require(review["author_report_sha256"] == report_pin, "general proof binding")
    for review_name, author_name, manifest_key in [
        ("general-review", "general-author", "author_manifest_sha256"),
        ("c2-even-review", "c2-even-author", "candidate_manifest_sha256"),
        ("c4-plus2-review", "c4-plus2-author", "author_manifest_sha256"),
    ]:
        verdict = json.loads((deps / review_name / "VERDICT.json").read_text())
        require(verdict["verdict"] == "ACCEPTED_WITHIN_EXACT_STATED_SCOPE", "source not accepted")
        require(verdict[manifest_key] == sha(deps / author_name / "MANIFEST.json"), "acceptance wrong author")
        for key in ["author_report_sha256", "candidate_report_sha256"]:
            if key in verdict:
                require(verdict[key] == sha(deps / author_name / "REPORT.md"), "acceptance wrong proof")
    result["all_three_accepting_bindings"] = "PASS"
    result["general_author_acceptance"] = "PASS"
    result["general_report_sha256"] = report_pin
    result["general_review_report_sha256"] = sha(deps / "general-review" / "INDEPENDENT_REVIEW.md")
    if args.pin:
        result["candidate"] = inventory(root, args.pin)
        result["candidate_report_sha256"] = sha(root / "REPORT.md")
    result["status"] = "PASS"
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
