# Independent review: even leading digits and even tails

The exact candidate identified by SOURCE_BINDING.json is accepted within the scope in VERDICT.json and INDEPENDENT_REVIEW.md. This is not public-package or delivery acceptance.

This review directory contains no private capture paths or raw private evidence. All dependency inventory results are retained in BINDING_RESULT.json. No accepted dependency code was executed.

## Reproduce independent checks

Python 3 standard library only:

    python -B independent_controls.py
    python -O -B independent_controls.py

Both outputs must match CONTROL_RESULTS.json byte-for-byte. These finite controls are not the uniform proof.

For the complete immutable original author candidate, not a reduced publication copy:

    python -B verify_binding.py PATH_TO_FULL_AUTHOR_CANDIDATE --pin 3e8b8d80451bc5a7d720d19e2870926d50473e64ffe26e2ecdcd31eeecdc5004
    python -B check_inventory_mutations.py PATH_TO_FULL_AUTHOR_CANDIDATE --pin 3e8b8d80451bc5a7d720d19e2870926d50473e64ffe26e2ecdcd31eeecdc5004

The optional --originals flag on verify_binding.py also checks the source locations supplied in the author's original provenance record; it is not required for portable verification. The mutation program edits only disposable copies. Use -B to avoid bytecode-cache files inside this sealed review.

MANIFEST.json enumerates every file other than itself and SEAL.json. SEAL.json pins the manifest.
