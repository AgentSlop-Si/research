#!/usr/bin/env python3
"""Exercise only the reviewer's inventory checker on disposable copies."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from verify_binding import inventory


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--pin", required=True)
    args = parser.parse_args()
    inventory(args.candidate, args.pin)
    rejected = []
    for kind in ["proof_edit", "missing_file", "unlisted_file", "seal_mismatch",
                 "symlink_file", "rehashed_replacement", "unlisted_directory", "changed_source_verdict"]:
        with tempfile.TemporaryDirectory() as name:
            root = Path(name) / "candidate"
            shutil.copytree(args.candidate, root)
            for x in [root, *root.rglob("*")]:
                x.chmod(0o755 if x.is_dir() else 0o644)
            proof = root / "REPORT.md"
            if kind == "proof_edit":
                proof.write_bytes(proof.read_bytes() + b"\nmutation\n")
            elif kind == "missing_file":
                proof.unlink()
            elif kind == "unlisted_file":
                (root / "EXTRA.txt").write_text("mutation")
            elif kind == "seal_mismatch":
                (root / "SEAL.json").write_text(json.dumps({"manifest_sha256": "0" * 64}))
            elif kind == "symlink_file":
                proof.unlink()
                proof.symlink_to("README.md")
            elif kind == "rehashed_replacement":
                proof.write_bytes(proof.read_bytes() + b"\nmutation\n")
                manifest = json.loads((root / "MANIFEST.json").read_text())
                for row in manifest["files"]:
                    if row["path"] == "REPORT.md":
                        row["bytes"] = proof.stat().st_size
                        row["sha256"] = hashlib.sha256(proof.read_bytes()).hexdigest()
                (root / "MANIFEST.json").write_text(json.dumps(manifest))
                (root / "SEAL.json").write_text(json.dumps({
                    "manifest_sha256": hashlib.sha256((root / "MANIFEST.json").read_bytes()).hexdigest()}))
            elif kind == "unlisted_directory":
                (root / "EXTRA_DIRECTORY").mkdir()
            elif kind == "changed_source_verdict":
                (root / "dependencies/general-review/VERDICT.json").write_text('{}\n')
            try:
                inventory(root, args.pin)
            except (ValueError, OSError, KeyError):
                rejected.append(kind)
            else:
                raise RuntimeError("mutation was accepted: " + kind)
    print(json.dumps({"status": "PASS", "rejected": rejected,
                      "originals_modified": False}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
