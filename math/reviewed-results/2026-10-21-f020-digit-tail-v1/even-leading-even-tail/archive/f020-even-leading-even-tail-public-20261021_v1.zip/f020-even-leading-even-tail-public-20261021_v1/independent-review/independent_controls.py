#!/usr/bin/env python3
"""Independent exact controls. No candidate or accepted program is imported."""
import json
from fractions import Fraction
from math import factorial


def require(x, reason):
    if not x:
        raise ValueError(reason)


def tidy(a):
    return {j: v for j, v in a.items() if v}


def plus(a, b, z=1, p=None):
    c = dict(a)
    for j, v in b.items():
        c[j] = c.get(j, 0) + z * v
    return tidy({j: v % p for j, v in c.items()} if p else c)


def scale(a, z):
    return tidy({j: z * v for j, v in a.items()})


def times(a, b):
    c = {}
    for j, v in a.items():
        for k, w in b.items():
            c[j + k] = c.get(j + k, 0) + v * w
    return tidy(c)


def dx(a):
    return tidy({j - 1: j * v for j, v in a.items() if j})


X = {1: 1}
ONE = {0: 1}


def matrix_product(a, b):
    return [[plus(times(a[i][0], b[0][j]), times(a[i][1], b[1][j]))
             for j in range(2)] for i in range(2)]


def tail_control(d):
    # Deliberately nonspecial exact rational edges. Matrix propagation is
    # independent of the proposed T/U recurrence implementation.
    edges = [Fraction((-1) ** j * (j * j + 3), j + 2) for j in range(d)]
    transition = [[ONE, {}], [{}, ONE]]
    for edge in edges:
        transition = matrix_product([[X, {0: -edge}], [ONE, {}]], transition)
    T, U = transition[0][0], scale(transition[0][1], -1 / edges[0])
    A = {0: 3, 1: -2, 3: 5, 5: 1}
    M = {0: 7, 2: 2, 4: -1}
    a, b = M, A
    for edge in edges:
        a, b = b, plus(times(X, b), a, -edge)
    F = plus(times(T, A), times(U, M), -edges[0])
    require(F == b, "transfer versus direct original recurrence")
    W = plus(times(dx(U), T), times(U, dx(T)), -1)
    actual = plus(times(T, dx(F)), times(dx(T), F), -1)
    main = times(times(T, T), dx(A))
    correction1 = scale(times(W, M), edges[0])
    correction2 = scale(times(times(U, T), dx(M)), edges[0])
    require(actual == plus(plus(main, correction1, -1), correction2, -1),
            "full ordinary-derivative witness")
    mutants = {
        "omit_W": plus(main, correction2, -1),
        "omit_Mprime": plus(main, correction1, -1),
        "wrong_T_power": plus(plus(times(T, dx(A)), correction1, -1), correction2, -1),
        "omit_TprimeF": times(T, dx(F)),
    }
    require(all(z != actual for z in mutants.values()), "witness negative controls")
    constant = Fraction((-1) ** (d // 2))
    for j in range(1, d, 2):
        constant *= edges[j]
    require(T.get(0) == constant, "unique constant matching")
    require(all(j % 2 == 0 for j in T), "even tail")
    require(all(j % 2 == 1 for j in U), "odd associated tail")
    return {"d": d, "matrix_transfer": "PASS", "witness": "PASS",
            "rejected_mutants": list(mutants)}


def hermite(n):
    # Factorial formula, independent of recurrence used by the author.
    return {n - 2 * k: factorial(n) // (2 ** k * factorial(k) * factorial(n - 2 * k))
            for k in range(n // 2 + 1)}


def remainder(a, b, p):
    a, b = plus({}, a, p=p), plus({}, b, p=p)
    while a and max(a) >= max(b):
        shift = max(a) - max(b)
        factor = a[max(a)] * pow(b[max(b)], -1, p) % p
        a = plus(a, {j + shift: v for j, v in b.items()}, -factor, p)
    return a


def gcd(a, b, p):
    a, b = plus({}, a, p=p), plus({}, b, p=p)
    while b:
        a, b = b, remainder(a, b, p)
    return plus({}, a, pow(a[max(a)], -1, p), p) if a else {}


def low_recurrences(p, n):
    # Differentiated recurrence is a separate state, not a derivative of
    # an inseparable final high-disk residual.
    a, b, da, db = ONE, X, {}, ONE
    for j in range(1, n):
        nb = plus(times(X, b), a, j, p)
        nd = plus(plus(b, times(X, db), p=p), da, j, p)
        a, b, da, db = b, nb, db, nd
    return b, db


def new_fixture(p, c, d, r):
    require(2 <= c < p and c % 2 == 0 and 2 <= d < p and d % 2 == 0, "scope")
    N, m = p ** r, d // 2
    n = c * N + d
    root, deriv = low_recurrences(p, n)
    target = {c * N + j: v % p for j, v in hermite(d).items()}
    dtarget = {c * N + j: d * v % p for j, v in hermite(d - 1).items()}
    require(root == tidy(target) and deriv == tidy(dtarget), "low original recurrence")
    require(gcd(hermite(d), hermite(d - 1), p) == ONE, "low Hermite gcd")
    require(gcd(hermite(c), hermite(c - 1), p) == ONE, "high Hermite gcd")
    B = Fraction(r * (p - 1) * p ** (r - 1), 2)
    K = Fraction(c * N, 2) + c * B
    E = Fraction((c - 1) * N, 2) + c * B
    D = Fraction((c + 1) * N, 2) + c * B - p
    require(D == N + E - p, "derivative gap arithmetic")
    h = r // 2
    rho = Fraction(p ** h, 2) if r % 2 == 0 else Fraction(p ** (h - 1) * (2 * p - 1), 2)
    beta = p ** h
    require(d + beta * c * (N // beta) == n, "complete count")
    require(Fraction(1, 2) < 1 <= rho < Fraction(N, 2), "root separation")
    require(n < p * N, "nonvanishing edges")
    require(N + E + 2 * m - 1 - (D + 2 * m) == p - 1, "first correction gap")
    require(N + E + rho + 2 * m - 1 - (D + 2 * m) == p + rho - 1, "second correction gap")
    C = hermite(d)[0] % p
    require(C != 0, "decisive tail unit")
    sign = (-1) ** (c // 2 + m - 1)
    require((n - 1) % 4 == (1 if sign == 1 else 3), "H/P multiplier")
    epsilon = (-1) ** ((p - 1) // 2)
    return {"p": p, "c": c, "d": d, "r": r, "n": n,
            "low_derivative_twice_value": n - 1,
            "high_derivative_twice_value": int(2 * (D + m)),
            "constant_value": int(K + m), "H_multiplier_i_sign": sign,
            "central_r2_unit_scalar_mod_p": (-c * C * epsilon) % p if r == 2 else None,
            "gcds_and_counts": "PASS"}


def main():
    pivots = []
    for c in (4, 6, 8, 12, 16, 20):
        summed = {l: factorial(c) // (factorial(l) * 2 ** ((c - 1 - l) // 2)
                   * factorial((c - 1 - l) // 2)) for l in range(1, c, 2)}
        require(summed == dx(hermite(c)) == scale(hermite(c - 1), c), "complete pivots")
        require({c - 1: c} != summed, "single-pivot mutant")
        pivots.append({"c": c, "count": len(summed), "coefficients": summed})
    # New combined c,d fixtures; predecessor high-degree controls are not rerun.
    fixtures = [(7, 4, 4, 2), (11, 10, 8, 2), (13, 10, 12, 2),
                (17, 16, 14, 2), (7, 6, 6, 3), (5, 4, 4, 4)]
    aux = []
    a, b = {}, ONE
    values = {}
    for j in range(1, 18):
        a, b = b, plus(times(X, b), a, j)
        if (j + 1) % 2 == 0:
            values[j + 1] = b.get(1, 0)
    for p, d in [(11, 6), (13, 12), (17, 16)]:
        require(values[d] % p == 0 and hermite(d)[0] % p != 0, "harmless auxiliary cancellation")
        aux.append({"p": p, "d": d, "auxiliary_linear_coefficient": values[d],
                    "decisive_constant_mod_p": hermite(d)[0] % p})
    result = {"status": "PASS", "uniform_proof_not_finite_controls": True,
              "accepted_programs_executed": False,
              "tail_matrix_controls": [tail_control(d) for d in (4, 6, 10)],
              "complete_pivot_controls": pivots,
              "new_combined_fixtures": [new_fixture(*row) for row in fixtures],
              "harmless_auxiliary_cancellations": aux}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
