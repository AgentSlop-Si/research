#!/usr/bin/env python3
"""Strict offline public-byte, source-binding, archive and negative-control checks."""
from pathlib import Path,PurePosixPath
import argparse,base64,copy,hashlib,html,io,itertools,json,os,re,shutil,stat,sys,tempfile,urllib.parse,zipfile,warnings,struct,zlib
ROOT=Path(__file__).resolve().parents[1]
PACKAGE='f020-odd-leading-odd-tail-public-20261021_v1'
ANCHORS={'README.md': '9a1bfa9e1c89df3e427e7e45ca901f451f94cb802de3cefa1674a6d145014d7c', 'REPLAY_POLICY.json': '4f80ede3be22ccc5987349e87a5d5e139be5ea17fe7a66aa807b504138e98f6a', 'SCOPE.json': 'fce9206d6ab225ac08229a2b4425fb75f14d92bc11ff6f94cd78583cc4163601', 'author/CLAIM_SCOPE.json': '22716a7f44bb744cac9f34be9b3f6fa53af123f8209ed0ef5194e34116684720', 'author/CONTROL_RESULTS.json': 'af4baddfdeb5efc5ea920429cd6955412817e967ea6edf70453acf46e610d1f7', 'author/MANIFEST.json': '82f93c18acf191ac58985357666e748f7e944fad3538c4a908faae811c87b392', 'author/README.md': '7ece24b255e85d2820f5dafa01f26a7d786d0459a803bce00e92ecf9ca07269c', 'author/REPORT.md': '692ac1ef6a5958c2ba29fecd84d309f1831f789acf45736467972eb3b256e890', 'author/REVIEW_REQUEST.md': '49ee2827323bcfd56fd301e1b887e977dd4e5b010dacf6820effe9a4de20d183', 'author/SCOPE_AUDIT.json': 'a5f315d4ff46475b3e57e563b58ac6a8347d3162f0bfc6174a99192d437eecc8', 'author/SEAL.json': 'd8b5ddd378d7ec52beac44f864edd6472d4d357e1de44624b32f2805bbb4d773', 'author/check_controls.py': 'a80405dc98c99949b196fbbafa8fd62b281c95cef222a05bd24b80a995adb5e1', 'author/requirements.txt': '11c495c6fd22a834f03652c1be83034c9a747b39e16b60ffae0249f92e6e4a09', 'author/sources/even-odd-tail-author/CLAIM_SCOPE.json': 'ba8bfc28badfd7491ef2803e3dd4e025c30770cf5e7d0f3425261e3707b59924', 'author/sources/even-odd-tail-author/MANIFEST.json': '0eefd9ffec434bd8d05eb8c5143a9025b7826f351863777867d7b27bb277603c', 'author/sources/even-odd-tail-author/REPORT.md': '2736127334ee95a7090f1ea293b05bdf61a7fc5f9f4afb1b996395b4e9c7fa37', 'author/sources/even-odd-tail-author/SEAL.json': 'c13b94bab452afa0935189119d5f0f9d926e6c19767211a3b61aa5d354797020', 'author/sources/even-odd-tail-review/INDEPENDENT_REVIEW.md': '6aa2bcae4b93d0d2cd60d86e6b8ec5f1ad8612d9a6d5063c041a6dbb459144be', 'author/sources/even-odd-tail-review/MANIFEST.json': 'dcab1f400e703a5977dc8f2c769a0b9b26da84498606b353e57b4a6f5d8920d0', 'author/sources/even-odd-tail-review/SEAL.json': 'bf405a86adb154fe78f86abca7db24b056f7e761ca20de5ba6c7a450ead496e9', 'author/sources/even-odd-tail-review/SOURCE_BINDING.json': 'a394b4477c131a114e34c819ed4550d47496e58c4cf8e6bf05a07399f7feb755', 'author/sources/even-odd-tail-review/VERDICT.json': 'c212ca36b6558be8b2c72676c630bd47e6e3883b57a6f9cb0ccffda6fd7197e6', 'author/sources/leading-digit-authority/leading-digit-acceptance.json': 'a740f4ddb4f682417c0fee0f4e55c032169a832a599d276843968366eacc931a', 'author/sources/leading-digit-authority/leading-digit-report.md': '4b603ec48cd71adb5edc22d2d5b851e8854bcd179f7913a7c0fb913529c2c120', 'author/sources/leading-digit-authority/leading-digit-review.md': 'cfdecc094d1051d5a8863cb8ec2efeedf2a803dc71e862dcff1f6602904db0d1', 'author/sources/leading-digit-authority/leading-digit-verdict.json': 'a5516be3ccb929caf9ee4bd6195a9d9aa22077cda8cb2c009ecf095de7895428', 'author/sources/odd-adjacent-author/CLAIM_SCOPE.json': '99a7e71519f2036740562d63fe519773e0dc88cac72495144155f03a0723d5ae', 'author/sources/odd-adjacent-author/MANIFEST.json': '438eb219f3534b41caa13905423c21afb2ae9fb777a8acdfa9b93438d126e032', 'author/sources/odd-adjacent-author/REPORT.md': '57ed78b499b62abe3b440ba8875736ebe12e1be2b29f35d1effce8e041b2fbec', 'author/sources/odd-adjacent-author/SEAL.json': '8ffec0aa67b8739aef59eb61293920f17ec9e70a30ce87621c0f743771c7c4a9', 'author/sources/odd-adjacent-review/INDEPENDENT_REVIEW.md': '1f911c60f90d3ea9226332bc21ab47697a4605bd2542ba529a9aadba59354322', 'author/sources/odd-adjacent-review/MANIFEST.json': 'a7deb7b69007940e8c7e49155701eabd22e7f81b01ba8012c5c94ee97a68be35', 'author/sources/odd-adjacent-review/SEAL.json': 'b030b8152729c59bc1bca3d97df5e725b156a00fd6d27550037ba0a1e7c2a1f5', 'author/sources/odd-adjacent-review/VERDICT.json': '76b3fe4907feea9d8b4310fa6f71c07f5af1b6dfef6ccd8897e289cf00250157', 'author/sources/odd-plus-two-author/CLAIM_SCOPE.json': '1956c7eed7957f55b20ba118afa20b6436c990e27649f186db7d985bce837aec', 'author/sources/odd-plus-two-author/MANIFEST.json': 'db295d917b83f18dc36ddf2f708eadf9e3203f0b60c3ddb5852fbb91a6ee28c4', 'author/sources/odd-plus-two-author/REPORT.md': '1c10fb9f9f6035ec3c56119a0e1c778e4c1f42eea0b72e630d7ed68c60fc0ff6', 'author/sources/odd-plus-two-author/SEAL.json': 'ad247fb6b763e91af82eee381544923e35adc42fdbe31114262c1282249b0173', 'author/sources/odd-plus-two-review/INDEPENDENT_REVIEW.md': 'f26812df643583fd21aeb52a92b7efe6d12ca5ec8e9d7b58760caf315b1d7a9c', 'author/sources/odd-plus-two-review/MANIFEST.json': '4cf46988f5cfac2432b1d8281432af8defa66334471b176156583da5a60e7316', 'author/sources/odd-plus-two-review/SEAL.json': '05d68bc25de7ac0a205fea77db4adca2809a110a0af10d56e432845b882dde43', 'author/sources/odd-plus-two-review/VERDICT.json': 'b9e3b7ac6dfdad27a07ca83291c355e76241432e12cf0e8e3cac4f1bfbfcc12e', 'independent-review/INDEPENDENT_RESULTS.json': '5768340531689c66dff8059a10e8278cbd1af74dec9eab37da6d45ce83993e6e', 'independent-review/INDEPENDENT_REVIEW.md': '605d160f3112fc3afef272957922eebc8b8a3790e8883f76acabc6367cc2e660', 'independent-review/MANIFEST.json': 'ac76a41ced862fc22d3b3b15091da5224932c4d0846f44851b612f35ca88c23c', 'independent-review/NEGATIVE_MATH_RESULTS.json': '58e462af23493751cce020f554458bc850573bc1b7bfc13e874b5d0586e051fd', 'independent-review/README.md': '01a32530cce9dc9bb5a850cbc55f869001a5b010c30eafff1501acfe5354010f', 'independent-review/SEAL.json': 'aa20c98e1920f35b08cd226eca732f714c9bf989b77128c047765c586f8ab5fb', 'independent-review/STRUCTURAL_RESULTS.json': '093c543c82870368d1ef56aa561cd8a5fdd7a69f58e0e53332e171a57071adb9', 'independent-review/VERDICT.json': 'f15aec43a57eeccd101f852faf06b65efa351604eea79f0d8d7378dd8cc133f8', 'independent-review/independent_checks.py': '27d3e89135d661199dac2b461c5234ea344d3605f7e9074ff987c02fcec61c55', 'independent-review/negative_math_controls.py': '5a124cf649b2197cd838916985f371db5f80ef0dfd4f5ee9ee3981e48fc2f049', 'independent-review/requirements.txt': '7bd6b8946940b79948c548c8048e545684b91c8edc9444d8dfc0c8f76a97c0a7', 'independent-review/structural_checks.py': '6e6058077509922589448f9a59e0af5dbf6795c55dd9f9f7a1c64be556ad34b1', 'provenance/ACCEPTANCE_BINDING.json': 'f3238221b0d41d1b09395080c04004d101f6ca62662777ae765d2d6e0239acee', 'provenance/DEPENDENCIES.json': 'aeb9e23e029e2e059c33f32e054aec57624ec2b7ba97e893470ad2fb1493453d', 'provenance/HISTORICAL_REFERENCES.json': '7ed51e40c48ef999ddffff246030d6a1b7128d69e0b7efbacefe0ad49c1c8aa8', 'provenance/LOCATOR_VALIDATION.json': '4e0a5aba615427ec4b0c729386aed02951542d0b683951682c5197e74978b4d4', 'provenance/SOURCE_INVENTORY.json': '317fa9a7f057bf5811c5364698aa39af1bb412c2db8a7781736664dc00868b20', 'provenance/TOOLING_ORIGIN.json': '8cf5d4f3f94b66652e087fa93128b69c1992d8788990091e9306783767742a58', 'provenance/projections/author/SOURCE_BINDINGS.json.public.json': '3a60c4c322f11bd198d7febf11297ff7ec566e4e59f6e776352c3293dada8f6e', 'provenance/projections/author/sources/even-odd-tail-author/SOURCE_BINDINGS.json.public.json': 'e2944442cfc5fb5f0158ae1c2e74fc274cb6de3856a69aecfeb958b7ae85c97f', 'provenance/projections/author/sources/odd-adjacent-author/SOURCE_BINDINGS.json.public.json': '506642ae3044326720575f90536d857ffa3fbc7e184e14e84fef37dc8c5cac98', 'provenance/projections/author/sources/odd-adjacent-review/SOURCE_BINDING.json.public.json': 'a19d31493494774c98671dcef5692405bda2d603c7858699a39ebd194ad4c46d', 'provenance/projections/author/sources/odd-plus-two-author/SOURCE_BINDINGS.json.public.json': 'a93f0d324fea83fbdd29d66dfa224ca9a373b27c66fcf5c06aa90d65d6300400', 'provenance/projections/author/sources/odd-plus-two-review/SOURCE_BINDING.json.public.json': '5165f7dda0789a083e4f3a412b2bdafa73e4030f53cd782a831dee0f85ffb584', 'provenance/projections/independent-review/SOURCE_BINDING.json.public.json': '2bfd3c81e8caee7026dd4f3691151f36ea3abc3a7210b104a4e9b92e0f8e5461', 'requirements.txt': '80c5a9e167416f00c56e0dd05a3d958e093c168bb1dc7ce08c3176fc5aa7f0a2', 'tools/failure_controls.py': 'a3901c35793a32fc6dffc9a4b137278b4d3d2863f7998f5f197f83003c860339', 'tools/isolation_probe.py': '72d5de70d66071672ab219e6fe3929d7130880697ea7422d27854d9e96e998a4', 'tools/replay.py': 'dc356defa956a7532195fcb4ffc55c8304603c345d7c78bb84cb330de9bd4cbf', 'tools/run_case.py': 'b00f6d925357735ef4e44bd01a67b2738b33a54b6a9cc0511ec6c16eb42a4c67'}
SOURCES={'author': '82f93c18acf191ac58985357666e748f7e944fad3538c4a908faae811c87b392', 'independent-review': 'ac76a41ced862fc22d3b3b15091da5224932c4d0846f44851b612f35ca88c23c'}
HEX=re.compile('[0-9a-f]{64}\\Z')
def need(ok,msg):
 if not ok:raise ValueError(msg)

def sha(b):return hashlib.sha256(b).hexdigest()

def ident(b):return {'bytes':len(b),'sha256':sha(b)}

def pairs(items):
 d={}
 for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
 return d

def loads(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))

def read(p):return loads(p.read_bytes())

def exact(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if type(a)is list:return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b

def same(a,b,msg):need(exact(a,b),msg)

def keys(d,k):need(type(d)is dict and d.keys()==set(k),'object fields')

def identity(d):
 keys(d,('bytes','sha256'));need(type(d['bytes'])is int and d['bytes']>=0,'length type');need(type(d['sha256'])is str and HEX.fullmatch(d['sha256'])is not None,'digest format')

def route(s):
 need(type(s)is str and bool(s) and '\\' not in s and not any(ord(c)<32 or ord(c)==127 for c in s),'path spelling')
 p=PurePosixPath(s);need(not p.is_absolute() and str(p)==s and not any(t in ('.','..','') for t in p.parts) and ':' not in s,'unsafe path')
 need('__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'),'bytecode forbidden');return s

def inventory(root):
 need(root.is_dir() and not root.is_symlink(),'root type');files=set();fold=set()
 for p in root.rglob('*'):
  need(not p.is_symlink(),'symlink forbidden');rel=route(p.relative_to(root).as_posix());need(rel.casefold() not in fold,'case collision');fold.add(rel.casefold())
  if p.is_file():files.add(rel)
  else:need(p.is_dir(),'nonregular member')
 return files

def text_variants(text):
 seen=set();queue=[text]
 while queue:
  s=queue.pop()
  if s in seen:continue
  seen.add(s);yield s
  need(len(seen)<100000,'escaped-text budget')
  for t in (html.unescape(s),urllib.parse.unquote(s),s.replace('\\/','/'),re.sub(r'\\(?:u([0-9a-fA-F]{4})|x([0-9a-fA-F]{2}))',lambda m:chr(int(m[1] or m[2],16)),s)):
   if t not in seen:queue.append(t)
  if s.lstrip().startswith(('{','[','"')):
   try:v=loads(s)
   except (ValueError,TypeError):pass
   else:
    def strings(v):
     if type(v)is str:yield v
     elif type(v)is list:
      for x in v:yield from strings(x)
     elif type(v)is dict:
      for k,x in v.items():yield k;yield from strings(x)
    queue.extend(t for t in strings(v) if t not in seen)
  for token in re.findall(r'(?<![A-Za-z0-9+/_-])[A-Za-z0-9+/_-]{24,}={0,2}(?![A-Za-z0-9+/_-])',s):
   try:t=base64.b64decode(token+'='*((-len(token))%4),altchars=b'-_',validate=True).decode('utf8')
   except (ValueError,UnicodeError):continue
   if t not in seen and all(c.isprintable() or c in '\r\n\t' for c in t):queue.append(t)

def privacy(name,raw,depth=0):
 need(depth<=4,'recursive archive depth')
 if name.endswith('.zip') or raw[:4]==b'PK\x03\x04':
  members=zip_members(raw)
  for n,b in members.items():privacy(n,b,depth+1)
  return
 try:text=raw.decode('utf8')
 except UnicodeError:raise ValueError('unclassified binary member: '+name)
 if name.endswith('.json'):loads(text)
 tokens=['/'+p+'/' for p in ('work'+'space','home','root','tmp','users','mnt','media')]+['cloud'+'_threads','collaboration'+'.','mcp'+'__','user_message'+'.','/'+'agent_notes'+'/','/'+'user_notes'+'/','dream'+'_notes','delivery'+'_context','thread'+'_id','lib'+'file_','codex'+':','chatgpt'+'.com']
 for s in itertools.chain(text_variants(name),text_variants(text)):
  local_scan=s.lower().replace('https://users.math.msu.edu'+'/'+'users'+'/bsagan/', 'verified-public-citation/')
  need(not any(t in local_scan for t in tokens),'private locator or coordination text: '+name)
  need(re.search(r'[A-Za-z]:[\\/](?:Users|Documents)[\\/]',s,re.I)is None,'private drive locator')
  need(re.search('-----BEGIN '+r'(?:RSA |EC |OPENSSH )?PRIVATE KEY-----',s)is None,'key marker')
  need(re.search(r'(?:gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{32,})',s)is None,'credential marker')
  extra=['file'+':'+ '//','sandbox'+':'+ '//','sediment'+':'+ '//','functions'+'.exec','cloud'+'_browser_handoff','library'+'_file_id','/'+'var'+'/folders/']
  need(not any(t.lower() in s.lower() for t in extra),'private scheme or coordination marker')
  need(re.search(r'Bearer\s+[A-Za-z0-9._-]{20,}',s,re.I)is None,'bearer marker')
  need(re.search(r'\b(?:password|api_key|client_secret|access_token|refresh_token)\s*[=:]\s*[\"\'][^\"\']{12,}',s,re.I)is None,'credential assignment')

def envelope(raw):
 need(len(raw)>=22 and raw[-22:-18]==b'PK\x05\x06','exact terminal EOCD required')
 sig,disk,cdisk,n1,n2,cdsize,cdoff,comment=struct.unpack('<4s4H2IH',raw[-22:]);need(disk==cdisk==comment==0 and n1==n2 and n2<=3000,'single disk non-ZIP64 envelope');need(cdoff+cdsize==len(raw)-22,'central directory envelope')
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  infos=z.infolist();need(len(infos)==n2,'EOCD entry count');pos=0;central=cdoff
  for i in infos:
   need(i.header_offset==pos and pos+30<=cdoff,'local span contiguity')
   h=struct.unpack('<4s5H3I2H',raw[pos:pos+30]);sig,version,flags,method,tm,dt,crc,cs,us,ns,xs=h
   need(sig==b'PK\x03\x04' and version<=20 and flags&~0x800==0 and method in (0,8),'local header profile');need(flags==i.flag_bits and method==i.compress_type and crc==i.CRC and cs==i.compress_size and us==i.file_size and xs==0,'local header consistency')
   name=raw[pos+30:pos+30+ns];need(name.decode('utf8' if flags&0x800 else 'cp437')==i.orig_filename,'local name consistency');start=pos+30+ns+xs;end=start+cs;need(end<=cdoff,'local data span');comp=raw[start:end]
   if method==8:
    d=zlib.decompressobj(-15);data=d.decompress(comp,64*1024**2+1);need(d.eof and not d.unused_data and not d.unconsumed_tail,'exact deflate stream envelope');data+=d.flush()
   else:data=comp
   need(len(data)==us and zlib.crc32(data)&0xffffffff==crc,'local data length/CRC')
   need(central+46<=len(raw)-22 and raw[central:central+4]==b'PK\x01\x02','central record span');ch=struct.unpack('<4s6H3I5H2I',raw[central:central+46]);need(ch[3]==flags and ch[4]==method and ch[7]==crc and ch[8]==cs and ch[9]==us and ch[10]==ns and ch[11]==ch[12]==ch[13]==0 and ch[16]==pos,'central/local consistency');need(raw[central+46:central+46+ns]==name,'central name identity');central+=46+ns;pos=end
  need(pos==cdoff and central==len(raw)-22,'no ZIP prefix, suffix, gap or hidden record')

def zip_members(raw):
 envelope(raw)
 out={};fold=set()
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  need(not z.comment,'archive comment forbidden');infos=z.infolist();need(len(infos)<=3000 and sum(i.file_size for i in infos)<=64*1024**2,'archive budget')
  for i in infos:
   need(i.orig_filename==i.filename and not i.comment and not i.extra,'hidden member metadata');n=route(i.filename);need(not i.is_dir() and not i.flag_bits&1,'directory/encrypted archive entry');need(n not in out and n.casefold() not in fold,'duplicate/case archive entry')
   need(stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG),'archive member type');fold.add(n.casefold());out[n]=z.read(i)
  for n in out:need(not any('/'.join(n.split('/')[:j]).casefold() in fold for j in range(1,len(n.split('/')))),'archive file/directory conflict')
  need(z.testzip() is None,'CRC failure')
 return out

def extract(raw,dest):
 need(not dest.exists() and not dest.is_symlink(),'extraction destination exists');members=canonical_members(raw)
 for n,b in members.items():privacy(n,b)
 dest.mkdir(parents=True)
 try:
  for n,b in members.items():
   p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 except Exception:shutil.rmtree(dest);raise
 return len(members)

def canonical_zip(members):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w',compression=zipfile.ZIP_STORED) as z:
  for n,data in sorted(members.items()):
   route(n);i=zipfile.ZipInfo(n,(1980,1,1,0,0,0));i.create_system=3;i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_STORED;z.writestr(i,data)
 return b.getvalue()

def canonical_members(raw):
 members=zip_members(raw);need(raw==canonical_zip(members),'noncanonical archive bytes');need({n.split('/')[0] for n in members}=={PACKAGE},'archive package root');return members

def reseal(root):
 files=[{'path':p,**ident((root/p).read_bytes())} for p in sorted(inventory(root)-{'MANIFEST.json','SEAL.json'})];(root/'MANIFEST.json').write_text(json.dumps({'schema_version':1,'package':PACKAGE,'files':files},indent=2,sort_keys=True)+'\n');(root/'SEAL.json').write_text(json.dumps({'algorithm':'SHA-256','manifest':'MANIFEST.json','manifest_sha256':sha((root/'MANIFEST.json').read_bytes()),'file_count':len(files)+2},indent=2,sort_keys=True)+'\n')

def negatives(root=ROOT):
 integrity(root);rows=[]
 for kind in ['changed_proof','missing_file','extra_file','extra_directory','symlink_file','symlink_directory','rehashed_proof','duplicate_json_key','unsafe_path','duplicate_manifest_member','wrong_seal','boolean_byte_count','negative_byte_count','float_byte_count','nonfinite_json']:
  with tempfile.TemporaryDirectory(prefix='public-inventory-mutant-') as td:
   d=Path(td)/'copy';shutil.copytree(root,d)
   if kind=='changed_proof':(d/'author/REPORT.md').write_bytes(b'changed')
   elif kind=='missing_file':(d/'author/REPORT.md').unlink()
   elif kind=='extra_file':(d/'EXTRA').write_text('extra')
   elif kind=='extra_directory':(d/'EXTRA').mkdir()
   elif kind=='symlink_file':(d/'author/REPORT.md').unlink();(d/'author/REPORT.md').symlink_to(root/'author/REPORT.md')
   elif kind=='symlink_directory':(d/'LINK').symlink_to(root/'author',target_is_directory=True)
   elif kind=='rehashed_proof':(d/'author/REPORT.md').write_bytes(b'changed');reseal(d)
   elif kind=='duplicate_json_key':p=d/'MANIFEST.json';p.write_text(p.read_text().replace('{','{"files": [],',1));s=read(d/'SEAL.json');s['manifest_sha256']=sha(p.read_bytes());(d/'SEAL.json').write_text(json.dumps(s))
   elif kind=='wrong_seal':s=read(d/'SEAL.json');s['manifest_sha256']='0'*64;(d/'SEAL.json').write_text(json.dumps(s))
   else:
    m=read(d/'MANIFEST.json')
    if kind=='unsafe_path':m['files'][0]['path']='../outside'
    elif kind=='boolean_byte_count':m['files'][0]['bytes']=True
    elif kind=='negative_byte_count':m['files'][0]['bytes']=-1
    elif kind=='float_byte_count':m['files'][0]['bytes']=float(m['files'][0]['bytes'])
    elif kind=='nonfinite_json':m['files'][0]['bytes']=float('nan')
    else:m['files'].append(m['files'][0])
    p=d/'MANIFEST.json';p.write_text(json.dumps(m));s=read(d/'SEAL.json');s['manifest_sha256']=sha(p.read_bytes());(d/'SEAL.json').write_text(json.dumps(s))
   rejected=False
   try:integrity(d)
   except (ValueError,OSError,KeyError,TypeError):rejected=True
   need(rejected,'accepted inventory mutant '+kind);rows.append({'mutation':kind,'rejected':True})
 members={PACKAGE+'/'+n:(root/n).read_bytes() for n in inventory(root)};raw=canonical_zip(members)
 tests={'prefix':b'prefix'+raw,'suffix':raw+b'suffix','eocd_comment':raw[:-2]+b'\x01\x00'+b'x'}
 for kind in ['compressed','timestamp','member_extra','archive_symlink','unsafe_archive_path','duplicate_archive_member','case_collision']:
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:
   for i,(n,data) in enumerate(sorted(members.items())):
    info=zipfile.ZipInfo('../escape' if kind=='unsafe_archive_path' and i==0 else n,(1981,1,1,0,0,0) if kind=='timestamp' and i==0 else (1980,1,1,0,0,0));info.create_system=3;info.external_attr=(0o120777 if kind=='archive_symlink' and i==0 else 0o100644)<<16;info.compress_type=zipfile.ZIP_DEFLATED if kind=='compressed' else zipfile.ZIP_STORED
    if kind=='member_extra' and i==0:info.extra=b'\x01\x00\x00\x00'
    z.writestr(info,data)
   if kind in ('duplicate_archive_member','case_collision'):
    n,data=next(iter(sorted(members.items())));n=n if kind=='duplicate_archive_member' else n.upper()
    with warnings.catch_warnings():warnings.simplefilter('ignore');z.writestr(n,data)
  tests[kind]=b.getvalue()
 for kind,data in tests.items():
  rejected=False
  try:canonical_members(data)
  except (ValueError,OSError,zipfile.BadZipFile,UnicodeError,struct.error):rejected=True
  need(rejected,'accepted archive mutant '+kind);rows.append({'mutation':'archive_'+kind,'rejected':True})
 canonical_members(raw);integrity(root);return {'status':'PASS','optimized_python':bool(sys.flags.optimize),'mutations':rows,'original_unchanged':True}

def main():
 p=argparse.ArgumentParser();p.add_argument('--archive');p.add_argument('--expect-sha256');p.add_argument('--extract');p.add_argument('--negative-controls',action='store_true');a=p.parse_args()
 if a.archive:
  need(a.expect_sha256 is not None and HEX.fullmatch(a.expect_sha256),'trusted archive digest required');raw=Path(a.archive).read_bytes();need(sha(raw)==a.expect_sha256,'archive SHA-256 mismatch');canonical_members(raw)
  if a.extract:
   dest=Path(a.extract);extract(raw,dest);out=integrity(dest/PACKAGE)
  else:
   with tempfile.TemporaryDirectory(prefix='exact-zip-check-')as td:dest=Path(td)/'new';extract(raw,dest);out=integrity(dest/PACKAGE)
 else:need(not a.extract and not a.expect_sha256,'archive required');out=integrity()
 if a.negative_controls:out['negative_controls']=negatives()
 print(json.dumps(out,indent=2,sort_keys=True))

def source_check(root):
 inv=read(root/'provenance/SOURCE_INVENTORY.json');same(inv['source_manifest_sha256'],SOURCES,'source pins');need(inv['scientific_bytes_changed']is False and inv['source_packages_intentionally_partial']is True,'partial source qualification')
 catalog={};stored=set()
 for row in inv['files']+inv['omissions']:
  key=row['collection']+'/'+route(row['source_path']);need(key not in catalog,'duplicate source declaration');catalog[key]=row;identity(row['original'])
  if 'stored_path'in row:
   n=route(row['stored_path']);need(n==key and n not in stored,'source path correspondence');stored.add(n);same(row['original'],row['exported'],'original/exported conservation');same(ident((root/n).read_bytes()),row['original'],'conserved source bytes')
  else:need(not(root/key).exists(),'omitted source unexpectedly present')
 for coll,pin in SOURCES.items():
  need(sha((root/coll/'MANIFEST.json').read_bytes())==pin==read(root/coll/'SEAL.json')['manifest_sha256'],'accepted source manifest pin')
  original=read(root/coll/'MANIFEST.json');expected={coll+'/'+x['path']for x in original['files']}|{coll+'/MANIFEST.json',coll+'/SEAL.json'}
  same({n for n in catalog if n.startswith(coll+'/')},expected,'every current source original retained or omitted')
  for row in original['files']:same(catalog[coll+'/'+row['path']]['original'],{k:row[k]for k in ('bytes','sha256')},'original manifest declaration')
 adapters=read(root/'provenance/DEPENDENCIES.json')['metadata_reading_adapters'];seen=set()
 for row in inv['locator_projections']:
  key=row['collection']+'/'+row['source_path'];p=root/route(row['projection_path']);o=read(p);same(o['original_identity'],catalog[key]['original'],'projection original identity');same(ident(p.read_bytes()),row['projected_identity'],'projection actual identity');same(o['original_public_relative_name'],key,'projection original role');need(o['scientific_content_changed']is False and o['removed_fields'],'narrow projection');same(adapters[key],row['projection_path'],'projection reading adapter');seen.add(key)
  for field in o['removed_fields']:need(field['json_pointer'].rsplit('/',1)[-1] in {'path','source_path','origin_path','origin','author_root'},'unexpected removed metadata field')
 same(seen,set(adapters),'every adapter exactly mapped')
 return {'retained_originals':len(inv['files']),'omitted_originals':len(inv['omissions']),'narrow_metadata_projections':len(seen),'historical_source_closure_claimed':False}

def historical_records(root):
 inv=read(root/'provenance/SOURCE_INVENTORY.json');catalog={r['collection']+'/'+r['source_path']:r for r in inv['files']+inv['omissions']};byhash={}
 for n,r in catalog.items():byhash.setdefault(r['original']['sha256'],[]).append({'original_name':n,'original_identity':r['original'],'disposition':'retained_verbatim'if 'stored_path'in r else'omitted_original','stored_path':r.get('stored_path'),'projection_path':r.get('projection_path')})
 files=sorted([r['stored_path']for r in inv['files']]+[r['projection_path']for r in inv['locator_projections']]);records=[];arrays=0;leaves=0
 def compact(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
 def pointer(k):return str(k).replace('~','~0').replace('/','~1')
 for name in files:
  p=root/name
  if p.suffix=='.json':
   entries=[]
   def walk(x,ptr=''):
    nonlocal arrays,leaves
    if type(x)is dict:
     for k,v in x.items():walk(v,ptr+'/'+pointer(k))
    elif type(x)is list:
     arrays+=1;entries.append({'json_pointer':ptr,'kind':'historical_array','rows':len(x),'canonical_value_sha256':sha(compact(x)),'qualification':'Every row is recursively scanned below; this historical array is not an active replay or source-completeness promise.'})
     for i,v in enumerate(x):walk(v,ptr+'/'+str(i))
    elif type(x)is str:
     leaves+=1;entry={'json_pointer':ptr,'kind':'historical_string','canonical_value_sha256':sha(compact(x)),'active_locator':False}
     if HEX.fullmatch(x):entry.update(kind='historical_identity',identity_matches=byhash.get(x,[]),qualification='Digest equality only; no original locator rebasing, fresh execution, omitted-byte availability or completeness is inferred.')
     elif re.search(r'path|file|source|script|output|manifest|url|uri|ref|archive|root|receipt',ptr,re.I) or re.search(r'\.(?:json|md|py|txt|zip|log)(?:$|[\s:])',x):entry.update(kind='historical_locator_or_reference',literal_value=x,qualification='Inactive original declaration. Use DEPENDENCIES and LOCATOR_VALIDATION for active reading/replay targets; unresolved subordinate sources remain explicitly partial.')
     else:entry['qualification']='Historical nonlocator text, unchanged.'
     entries.append(entry)
   walk(read(p));records.append({'path':name,'identity':ident(p.read_bytes()),'kind':'recursive_json_declarations','records':entries})
  elif p.suffix=='.md':
   entries=[]
   for lineno,line in enumerate(p.read_text().splitlines(),1):
    for match in re.finditer(r'(?<![A-Za-z0-9_])(?:[A-Za-z0-9_.-]+/)*[A-Za-z0-9_.-]+\.(?:md|json|py|txt|zip|log)\b',line):
     entries.append({'line':lineno,'literal_value':match.group(0),'active_locator':False,'qualification':'Frozen report/readme reference. The separately verified active map supersedes historical operational instructions; no missing original is claimed delivered.'})
   records.append({'path':name,'identity':ident(p.read_bytes()),'kind':'historical_text_references','records':entries})
 # Every original full inventory row receives a more precise same-base disposition.
 inventories=[]
 for name in files:
  if not name.endswith('/MANIFEST.json'):continue
  o=read(root/name)
  if type(o)is not dict or type(o.get('files'))is not list:continue
  rows=[]
  for i,r in enumerate(o['files']):
   need(type(r)is dict and all(k in r for k in ('path','sha256','bytes')),'historical manifest schema');target=str(PurePosixPath(name).parent/PurePosixPath(route(r['path'])));decl={k:r[k]for k in ('bytes','sha256')};identity(decl)
   if target in catalog:
    same(decl,catalog[target]['original'],'same-base historical declaration identity');disposition='retained_verbatim'if 'stored_path'in catalog[target]else'deliberately_omitted_current_original'
   else:disposition='not_present_in_supplied_partial_snapshot'
   rows.append({'index':i,'original_relative_path':r['path'],'declared_identity':decl,'disposition':disposition,'same_base_original_name':target,'identity_matches_elsewhere':byhash.get(r['sha256'],[]),'qualification':'No historical full-package closure or fresh dependency replay is claimed.'})
  inventories.append({'manifest':name,'identity':ident((root/name).read_bytes()),'rows':rows})
 return {'status':'PASS','qualification':'Exhaustive recursive scan of every retained original and separately named projected JSON, every array and string leaf including root arrays; every historical Markdown filename reference and every full-manifest member is classified. Historical instructions and locators are inactive. Only the separate active reading/replay map may be used operationally.','all_json_arrays_examined':arrays,'all_json_string_leaves_examined':leaves,'source_bytes_changed':False,'inventories':inventories,'documents':records}

def locator_records(root):
 deps=read(root/'provenance/DEPENDENCIES.json');inv=read(root/'provenance/SOURCE_INVENTORY.json');policy=read(root/'REPLAY_POLICY.json');targets={}
 def add(name,role):
  route(name);need((root/name).is_file()and not(root/name).is_symlink(),'active locator missing: '+name);targets.setdefault(name,[]).append(role)
 for x in deps['active_reading']:add(x,'primary_reading_or_public_tool')
 for x in deps['metadata_reading_adapters'].values():add(x,'narrow_metadata_reading_adapter')
 for src in deps['sources']:
  for row in src['files']:add(row['target'],'dependency_snapshot:'+src['name']);same(ident((root/row['target']).read_bytes()),row['target_identity'],'dependency target identity')
 for row in policy['current_scientific_programs']:
  add(row['script'],'current_scientific_replay_script:'+row['role']);add(row['reference'],'current_scientific_reference:'+row['role']);route(row['result'])
 records=[]
 for n,roles in sorted(targets.items()):records.append({'target':n,'roles':sorted(roles),'binding':'root_manifest_only_to_avoid_self_reference'if n in ('provenance/LOCATOR_VALIDATION.json','tools/verify.py')else'exact_file_identity',**({}if n in ('provenance/LOCATOR_VALIDATION.json','tools/verify.py')else{'identity':ident((root/n).read_bytes())})})
 outputs=[{'role':x['role'],'result_name':x['result'],'result_location':'new external replay directory only','not_an_input_locator':True}for x in policy['current_scientific_programs']]
 return {'status':'PASS','missing_active_targets':[],'records':records,'runtime_output_declarations':outputs,'historical_locators_active':False,'public_helpers_source':'tools directory; all root-manifest-bound','qualification':'Only listed original report/dependency targets and separately named metadata projections are active. Raw runtime diagnostics are not delivered.'}

def semantics(root):
 v=read(root/'independent-review/VERDICT.json');a=read(root/'provenance/ACCEPTANCE_BINDING.json');s=read(root/'SCOPE.json');c=read(root/'author/CLAIM_SCOPE.json')
 need(v['verdict']==a['mathematical_verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE','acceptance');same(s['accepted_verdict'],v,'entire exact verdict');same(s['author_claim'],c,'entire author claim');same(s['exact_family'],v['exact_scope'],'family');need(v['author_manifest_sha256']==SOURCES['author']and v['author_report_sha256']==sha((root/'author/REPORT.md').read_bytes()),'review binds exact author')
 for k,p in [('author_report','author/REPORT.md'),('review_report','independent-review/INDEPENDENT_REVIEW.md'),('review_verdict','independent-review/VERDICT.json')]:same(a[k],ident((root/p).read_bytes()),'accepted scientific identity')
 need(a['author_manifest_sha256']==SOURCES['author']and a['review_manifest_sha256']==SOURCES['independent-review']and a['public_packaging_independently_accepted']is False,'no self public-acceptance')
 need(s['normalization']['beta']=='p^floor(r/2)'and s['normalization']['L']=='N/beta','correct beta and L');need(s['root_counts']['high']=='cN+1'and s['root_counts']['shallow']=='d-1'and type(s['root_counts']['zero'])is int and s['root_counts']['zero']==0,'root accounting');need(s['inherited_d1_not_new_credit']is True and s['global_F020_F023_closed']is False and s['FFT_or_cost_claim']is False and s['historical_novelty_claim']is False,'scope boundary')
 for a_name,r_name in [('odd-adjacent-author','odd-adjacent-review'),('odd-plus-two-author','odd-plus-two-review'),('even-odd-tail-author','even-odd-tail-review')]:
  ap=root/'author/sources'/a_name;rp=root/'author/sources'/r_name;rv=read(rp/'VERDICT.json');need(rv['verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE'and rv['author_manifest_sha256']==sha((ap/'MANIFEST.json').read_bytes())and rv['author_report_sha256']==sha((ap/'REPORT.md').read_bytes()),'exact accepted dependency pair')
 old=read(root/'author/sources/odd-adjacent-review/MANIFEST.json');members={x['path']:x for x in old['files']}
 for p in (root/'author/sources/leading-digit-authority').iterdir():same(ident(p.read_bytes()),{k:members['sources/'+p.name][k]for k in ('bytes','sha256')},'leading-digit authority member')
 policy=read(root/'REPLAY_POLICY.json');same([x['role']for x in policy['current_scientific_programs']],['author','review','review_structural','review_negative_math'],'all four current programs');same(policy['scientific_source_adapters'],[],'no source edits');same(policy['output_comparison_exceptions'],[],'no comparison exceptions')
 for x in policy['current_scientific_programs']:
  b=(root/x['reference']).read_bytes();need(len(b)==x['stdout_bytes']and sha(b)==x['stdout_sha256']and x['result_from_stdout']is True,'exact stdout reference');need(x['stderr_bytes']==0 and x['stderr_sha256']==sha(b''),'empty stderr reference')
 same(read(root/'provenance/HISTORICAL_REFERENCES.json'),historical_records(root),'every historical path/hash/reference array and manifest qualified')
 same(read(root/'provenance/LOCATOR_VALIDATION.json'),locator_records(root),'all active locators valid')

def integrity(root=ROOT):
 actual=inventory(root);m=read(root/'MANIFEST.json');seal=read(root/'SEAL.json');keys(m,('schema_version','package','files'));keys(seal,('algorithm','manifest','manifest_sha256','file_count'));need(type(m['schema_version'])is int and m['schema_version']==1 and m['package']==PACKAGE,'manifest schema');need(seal['algorithm']=='SHA-256'and seal['manifest']=='MANIFEST.json'and seal['manifest_sha256']==sha((root/'MANIFEST.json').read_bytes()),'public seal');need(type(seal['file_count'])is int and seal['file_count']==len(actual),'file count');names=[]
 for row in m['files']:
  keys(row,('path','bytes','sha256'));n=route(row['path']);identity({k:row[k]for k in ('bytes','sha256')});names.append(n);same(ident((root/n).read_bytes()),{k:row[k]for k in ('bytes','sha256')},'member bytes: '+n)
 need(names==sorted(set(names))and actual==set(names)|{'MANIFEST.json','SEAL.json'}and not {'MANIFEST.json','SEAL.json'}&set(names),'exact public inventory');dirs={str(p.relative_to(root))for p in root.rglob('*')if p.is_dir()};expected={str(p)for n in actual for p in PurePosixPath(n).parents if str(p)!='.'};same(dirs,expected,'no extra directories')
 for n,h in ANCHORS.items():need(sha((root/n).read_bytes())==h,'fixed science/metadata anchor: '+n)
 for n in sorted(actual):privacy(n,(root/n).read_bytes())
 src=source_check(root);semantics(root);return {'status':'PASS','public_regular_files':len(actual),'source_representation':src,'optimized_python':bool(sys.flags.optimize),'public_packaging_independently_accepted':False}

if __name__=='__main__':
 try:main()
 except Exception as e:print('FAIL: '+str(e),file=sys.stderr);sys.exit(1)
