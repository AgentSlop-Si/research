# Requested independent review

Please check REPORT.md Sections 2-9 and bind the exact final manifest and report hashes. This author does not accept itself.

Focus: odd coefficientwise input including constant neighbor/derivative pivots; correct beta=p^floor(r/2) and L=N/beta; original finite tail and XT F'-(T+XT')F witness; cN+1 high/d-1 low exhaustive counts and absence of zero; arbitrary-alpha scalar estimate with ODD pivot sum and raw P_n lattice margin; odd operator 2U j_U-j and translation coefficients; first/second correction and p=5 boundary; nonzero ODD derivative units (no even-c Legendre factor); original predecessor determinant, kernel and discriminant; every s>r and primitive phase.

The p=7,c=3,d=3 double cancellation and p=13,c=5,d=11 first cancellation are explicit direct original-recurrence controls. Please use independent controls as well as cold replay. Check the immutable source/acceptance boundary, inherited d=1 credit, and exclusions. No external writes or table/repository changes are requested.
