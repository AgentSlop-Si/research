# Odd leading digit, odd short tail: bounded F020 candidate

REPORT.md proves the original P/H squarefreeness and original algebraic-square kernel statement for p prime, odd 3<=c<p, odd 1<=d<p, r>=2, s>r and n=c*p^r+d, every primitive characteristic-zero p^s phase. New coverage is d>=3; d=1 is inherited. No global owner closure, complexity, or historical-novelty claim.

The finite-tail transfer is F=T[XA-a(V/T)M], with F the original even polynomial, not a quotient. The root-compatible operator is XJ'-J. There are cN+1 high roots, d-1 shallow roots, no zero; the central cancellation R_c(-alpha) has a nonzero first correction unless p=2d+1, when the second correction is nonzero. The genuine p=7,c=3,d=3 second layer is included.

Reproduce from this directory with Python 3, NumPy and SymPy:

    python verify.py
    python -O verify.py
    python check_inventory_controls.py

verify.py is read-only and executes only the new check_controls.py. audit_sources.py is the author's source-capture utility: it reads/hashes the listed original source manifests and copies explicitly partial proof/review identity snapshots. It is not required for portable replay and should not be rerun in a frozen packet. No supplied source program is imported or executed.

The controls are diagnostics, not the uniform proof. Source snapshots are explicitly partial, never called complete source packages. Three exact accepting proof/review bindings are checked, and retained leading-digit authority snapshots are bound through the accepted odd-adjacent review manifest. A separate reviewer must accept these exact final candidate bytes.
