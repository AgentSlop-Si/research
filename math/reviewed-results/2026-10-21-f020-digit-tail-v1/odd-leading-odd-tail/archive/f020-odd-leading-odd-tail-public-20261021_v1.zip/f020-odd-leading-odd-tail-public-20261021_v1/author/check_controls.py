#!/usr/bin/env python3
"""New exact bounded controls. No source code is imported or executed."""
import json, math
from fractions import Fraction as F
import numpy as np
import sympy as s

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def jf(a,b):return [sum(a[k]*b[j-k] for k in range(j+1)) for j in range(3)]
def ja(a,b):return [a[j]+b[j] for j in range(3)]
def zeros():return [F(0)]*3

def tail_jets(m):
 # Exact rational 2-jets of X^1 f_(2m+1) and X^0 g_(2m+1).
 one=[F(1),F(0),F(0)];z=zeros()
 f0=[one,z];f1=[z,one];g0=[z,z];g1=[one,z]
 for j in range(1,2*m+1):
  edge=[F(j),F(j*(j-1),2),F(j*(j-1)*(j-2),6)]
  def step(prev,cur):return [jf(edge,prev[0]),ja(cur[0],jf(edge,prev[1]))]
  f0,f1=f1,step(f0,f1);g0,g1=g1,step(g0,g1)
 return f1[1],g1[0]

def hermite(n):
 return {n-2*u:math.factorial(n)//(2**u*math.factorial(u)*math.factorial(n-2*u)) for u in range(n//2+1)}
def rc(c):return {(k-1)//2:v for k,v in hermite(c).items()}
def ev(poly,x,p):return sum(v*pow(x,k,p) for k,v in poly.items())%p
def der(poly):return {k-1:k*v for k,v in poly.items() if k}
def modfrac(x,p):return x.numerator*pow(x.denominator,-1,p)%p
def df(d):return math.prod(range(d,0,-2))

def formal_identities():
 X,a,A,Ap,M,Mp=s.symbols('X a A Ap M Mp');out=[]
 for d in [1,3,5,7,9]:
  b=s.symbols('b1:'+str(d));f=[s.Integer(1),X];g=[s.Integer(0),s.Integer(1)]
  for j in range(1,d):f.append(s.expand(X*f[-1]-b[j-1]*f[-2]));g.append(s.expand(X*g[-1]-b[j-1]*g[-2]))
  T=s.cancel(f[d]/X);V=g[d]
  P=X*T*A-a*V*M
  Pp=(T+X*s.diff(T,X))*A+X*T*Ap-a*(s.diff(V,X)*M+V*Mp)
  W=s.expand(X*T*Pp-(T+X*s.diff(T,X))*P)
  rhs=s.expand(X**2*T**2*Ap+a*T*V*M-a*T*V*X*Mp-a*X*(s.diff(V,X)*T-V*s.diff(T,X))*M)
  need(s.expand(W-rhs)==0,f'witness d={d}')
  need(s.expand(f[d]*g[d-1]-f[d-1]*g[d]+s.prod(b))==0,f'determinant d={d}')
  # The missing -J term produces a nonzero discrepancy even at d=1.
  need(s.expand(X*T*Pp-X*s.diff(T,X)*P-rhs)!=0,'negative odd operator')
  if d>=3:need(s.expand(V-T)!=0,'negative V edge start')
  out.append(d)
 return {'odd_tails':out,'exact_fraction_free_witness':'PASS','tail_determinant':'PASS','wrong_operator_rejected':True,'wrong_V_edge_start_rejected':True}

def jets_and_arithmetic():
 for m in range(21):
  T,V=tail_jets(m);C=df(2*m+1);Bt=df(2*m)
  te=[F(C),C*F(m*(3*m-1),6),C*F(m*(m-1)*(45*m*m+35*m-22),360)]
  ve=[F(Bt),Bt*F(m*m,2),Bt*F(m*(m-1)*(9*m*m+13*m+1),72)]
  need(T==te and V==ve,f'tail rational jets m={m}')
  al=F(Bt,C);ratio=[V[0]/T[0]]
  ratio.append((V[1]-T[1]*ratio[0])/T[0]);ratio.append((V[2]-T[1]*ratio[1]-T[2]*ratio[0])/T[0])
  need(ratio==[al,al*F(m,6),al*F(m*(7*m-27),360)],f'kappa m={m}')
 mm=F(-3,4);need(mm*(7*mm-27)/360-F(9,128)==F(-1,320),'second correction')
 primes=[5,7,11,13,17,19,23,29,31,37,41,43];ob=[];tested=0
 Z=s.symbols('Z')
 for p in primes:
  for c in range(3,p,2):
   h=hermite(c);hm=hermite(c-1)
   need(s.gcd(s.Poly.from_dict({(k,):v for k,v in h.items()},Z,modulus=p),s.Poly.from_dict({(k,):v for k,v in hm.items()},Z,modulus=p)).degree()==0,'Hermite coprimeness')
   need(ev(rc(c),0,p)!=0,'odd zero simple')
   for d in range(1,p,2):
    al=modfrac(F(df(d-1),df(d)),p);R=rc(c);tested+=1
    if ev(R,-al,p)==0:
     need(ev(der(R),-al,p)!=0,'R derivative nonzero')
     b=2 if (2*d+1)%p==0 else 1
     if b==2:need(p==2*d+1 and p>=7,'second cancellation range')
     ob.append({'p':p,'c':c,'d':d,'alpha_mod_p':al,'correction':b})
 need({'p':7,'c':3,'d':3,'alpha_mod_p':3,'correction':2} in ob,'smallest second obstruction')
 need({'p':13,'c':5,'d':11,'alpha_mod_p':12,'correction':1} in ob,'first obstruction')
 return {'rational_jets_m':list(range(21)),'tested_parameter_triples':tested,'obstructions':ob,'second_coefficient':str(mm*(7*mm-27)/360-F(9,128)),'false_universal_first_correction_rejected':True}

def pd_add(a,b,p):
 out=dict(a)
 for k,v in b.items():out[k]=(out.get(k,0)+v)%p
 return {k:v for k,v in out.items() if v%p}
def pd_scale(a,x,p):return {k:v*x%p for k,v in a.items() if v*x%p}
def pd_shift(a):return {k+1:v for k,v in a.items()}
def shallow_controls():
 out=[]
 for p,c,r,d in [(5,3,2,3),(7,3,2,3),(7,5,2,5),(5,3,3,3),(13,5,2,11),(13,11,2,11)]:
  n=c*p**r+d;qm={0:1};q={1:1};dm={};dv={0:1}
  for j in range(1,n):
   nq=pd_add(pd_shift(q),pd_scale(qm,j,p),p)
   nd=pd_add(pd_add(q,pd_shift(dv),p),pd_scale(dm,j,p),p)
   qm,q=q,nq;dm,dv=dv,nd
  want={k+c*p**r:v%p for k,v in hermite(d).items() if v%p}
  wantd={k+c*p**r:d*v%p for k,v in hermite(d-1).items() if d*v%p}
  need(q==want and dv==wantd,f'shallow original recurrences {(p,c,r,d)}')
  out.append({'p':p,'c':c,'r':r,'d':d,'degree':n,'full_polynomial_and_ordinary_derivative':'PASS','low_roots':d-1,'high_roots':c*p**r+1,'total':n})
 return out

class Series:
 def __init__(self,p,prec):self.p=p;self.prec=prec
 def z(self):return np.zeros(self.prec,dtype=np.int64)
 def one(self):a=self.z();a[0]=1;return a
 def mul(self,a,b):return np.convolve(a,b)[:self.prec]%self.p
 def add(self,a,b):return (a+b)%self.p
 def sub(self,a,b):return (a-b)%self.p
 def scale(self,a,b):return a*(b%self.p)%self.p
 def val(self,a):
  nz=np.flatnonzero(a);return int(nz[0]) if len(nz) else None
 def shift(self,a,k):
  o=self.z()
  if k<self.prec:o[k:]=a[:self.prec-k]
  return o

def original_scalar(p,c,d,phase=1):
 N=p*p;B=N-p;E=(c-1)*N//2+c*B;m=(d-1)//2;S=(c*N+p)//2+c*B;delta=B//2
 al=modfrac(F(df(d-1),df(d)),p);R=rc(c);need(ev(R,-al,p)==0,'scalar test must be genuine obstruction')
 b=2 if (2*d+1)%p==0 else 1;base=N+E+2*m;prec=base+b+4
 ss=Series(p,prec);one=ss.one();q=ss.z()
 for j in range(phase+1):q[j]=math.comb(phase,j)%p
 local_t=ss.sub(q,one);y=ss.z()
 # In characteristic p, t_local^p is exact coefficientwise Frobenius.
 for j in range(1,min(phase+1,(prec-1)//p+1)):y[j*p]=-al*int(local_t[j])%p
 qp=one.copy();prev=one.copy();cur=one.copy();prev_y=ss.z();cur_y=ss.z();n=c*N+d
 for j in range(1,n):
  qp=ss.mul(qp,q);edge=ss.sub(qp,one)
  if j%2:
   nxt=ss.add(ss.mul(y,cur),ss.mul(edge,prev))
   ny=ss.add(ss.add(cur,ss.mul(y,cur_y)),ss.mul(edge,prev_y))
  else:
   nxt=ss.add(cur,ss.mul(edge,prev));ny=ss.add(cur_y,ss.mul(edge,prev_y))
  prev,cur=cur,nxt;prev_y,cur_y=cur_y,ny
 Fv,Fy=cur,cur_y
 # Tail f_j uses shifted edges q^(cN+j), retaining ordinary y derivative.
 fp=one.copy();fc=one.copy();fpy=ss.z();fcy=ss.z();qp=one.copy()
 for j in range(c*N):qp=ss.mul(qp,q)
 for j in range(1,d):
  qp=ss.mul(qp,q);edge=ss.sub(qp,one)
  if j%2:
   fn=ss.add(ss.mul(y,fc),ss.mul(edge,fp));fny=ss.add(ss.add(fc,ss.mul(y,fcy)),ss.mul(edge,fpy))
  else:fn=ss.add(fc,ss.mul(edge,fp));fny=ss.add(fcy,ss.mul(edge,fpy))
  fp,fc=fc,fn;fpy,fcy=fcy,fny
 T,Ty=fc,fcy
 W=ss.sub(ss.mul(T,ss.sub(ss.scale(ss.mul(y,Fy),2),Fv)),ss.scale(ss.mul(ss.mul(y,Ty),Fv),2))
 value=ss.val(W);expect=base+b;need(value==expect,f'original scalar witness valuation {(p,c,d,phase)} got {value} expected {expect}')
 Rp=ev(der(R),-al,p);Bt=df(d-1)%p
 unit=modfrac(-F(Bt*Bt*Rp*(2*d+1),12),p) if b==1 else modfrac(F(Bt*Bt*Rp,160),p)
 need(int(W[value])==unit*pow(phase,value,p)%p,'original scalar witness unit')
 fv=ss.val(Fv);need(fv is None or fv>S+m+b*p,'original scalar F lift')
 need((p-1)*p*p+n//2>prec-1,'scalar original mixed-characteristic lattice margin')
 return {'p':p,'c':c,'d':d,'phase':phase,'precision_exclusive':prec,'scalar_F_value':fv,'scalar_F_strict_lower_bound':S+m+b*p,'witness_value':value,'witness_local_t_unit':unit,'witness_base_t_unit':int(W[value]),'correction':b,'raw_degree_lower_bound':n//2,'minimal_e':(p-1)*p*p,'mixed_characteristic_lattice_margin':(p-1)*p*p+n//2-(prec-1),'diagnostic_only':'scalar witness is not substituted for ordinary derivative at a root; all-root transfer is proved in report'}

def central_polynomial_control():
 p,c,d=7,3,3;N=p*p;B=N-p;m=1;n=c*N+d;S=(c*N+p)//2+c*B;scale=S+m
 cap=2*((scale-n//2)//(p-1))+2 # even cap beyond the all-coefficient raw threshold
 prec=scale+1;ss=Series(p,prec);one=ss.one();qp=one.copy();q=ss.one();q[1]=1
 prev={0:one.copy()};cur={1:one.copy()}
 for j in range(1,n):
  qp=ss.mul(qp,q);edge=ss.sub(qp,one);nxt={k+1:v.copy() for k,v in cur.items() if k+1<=cap}
  for k,v in prev.items():nxt[k]=ss.add(nxt.get(k,ss.z()),ss.mul(edge,v))
  prev,cur=cur,nxt
 residual={}
 for k,coeff in cur.items():
  need(k%2==0,'even F parity');idx=scale-p*k//2
  if idx>=0:
   need(not np.any(coeff[:idx]),f'coefficient has value below claimed central weight {k}')
   if coeff[idx]:residual[k]=int(coeff[idx])
 epsilon=(-1)**((p-1)//2);C=df(d);want={}
 for ku,v in rc(c).items():want[p+1+2*p*ku]=(-epsilon*C*v)%p
 want={k:v for k,v in want.items() if v}
 need(residual==want,f'complete central residual {residual} versus {want}')
 need(n//2+(p-1)*(cap+2)//2>scale,'all omitted coefficients excluded by raw bound')
 def edge_val(j):
  a=1
  while j%p==0:j//=p;a*=p
  return a
 constant_value=sum(edge_val(j) for j in range(1,n,2))
 need(n<p**3 and constant_value==N+(c-1)*N//2+c*B+m,'nonzero original constant product')
 return {'p':p,'c':c,'d':d,'degree':n,'central_scale':scale,'retained_X_degree':cap,'residual':residual,'all_omitted_coefficients_excluded_by_raw_edge_count':True,'original_constant_value':constant_value,'wrong_exact_zero_count_rejected':True}

def main():
 out={'status':'PASS','formal_identities':formal_identities(),'jets_and_arithmetic':jets_and_arithmetic(),'shallow_original_recurrences':shallow_controls(),'central_complete_polynomial':central_polynomial_control(),'original_scalar_controls':[original_scalar(7,3,3,1),original_scalar(7,3,3,2),original_scalar(13,5,11,1)],'source_programs_executed':False,'finite_controls_are_not_uniform_proof':True}
 print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':main()
