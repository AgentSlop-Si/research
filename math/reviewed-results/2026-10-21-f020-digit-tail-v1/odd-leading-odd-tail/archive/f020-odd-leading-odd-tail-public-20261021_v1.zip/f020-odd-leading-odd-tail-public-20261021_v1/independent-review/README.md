# Independent odd-leading odd-tail F020 review

This local review accepts only the exact bounded theorem and exact candidate bytes identified in VERDICT.json and SOURCE_BINDING.json. See INDEPENDENT_REVIEW.md for the mathematical review. The proof is uniform; finite controls are supplementary diagnostics, not universal evidence by enumeration. No supplied program was executed.

Read-only integrity check:

    python verify_review.py
    python -O verify_review.py

Fresh reviewer-authored exact controls:

    python independent_checks.py
    python structural_checks.py
    python negative_math_controls.py

Their JSON outputs must match the recorded corresponding results. Python 3.12.14 and NumPy 2.3.5 were used; requirements.txt records NumPy. All program checks use explicit exceptions, not assert statements, and normal/optimized replay outputs were compared byte-for-byte.

The read-only audit_inventory.py may inspect the separately supplied original candidate directory and its exact live source inventories. It never executes candidate/source programs. Source identities are partial provenance bindings, not a claim that this review contains a standalone copy of every accepted dependency. No external write, public packaging acceptance, global closure, historical priority, or FFT/cost assertion is included.
