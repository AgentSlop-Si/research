#!/usr/bin/env python3
"""Fresh reviewer-authored controls. No producer/source program is imported."""
import json, math, hashlib
from pathlib import Path
from fractions import Fraction as F
import numpy as np


def need(ok, msg):
    if not ok: raise RuntimeError(msg)


def df(k):
    return math.prod(range(k,0,-2))


def rc(c,u):
    return sum(F(math.factorial(c),2**j*math.factorial(j)*math.factorial(c-2*j))*u**((c-1)//2-j) for j in range((c-1)//2+1))


def mod(q,p):
    q=F(q); return q.numerator*pow(q.denominator,-1,p)%p


def scal(p,c,d):
    N=p*p; B=N-p; m=(d-1)//2; alpha=mod(F(df(d-1),df(d)),p)
    E=(c-1)*N//2+c*B; S=(c*N+p)//2+c*B+m; limit=N+E+2*m+2*p+6
    z=np.zeros(limit+1,dtype=np.int64); one=z.copy();one[0]=1
    def add(a,b):return (a+b)%p
    def sub(a,b):return (a-b)%p
    def mul(a,b):return np.convolve(a,b)[:limit+1]%p
    def xp(a):
        out=z.copy(); out[p:]=(-alpha*a[:-p])%p; return out
    def edge(j):
        v=z.copy()
        for k in range(1,min(j,limit)+1):v[k]=-math.comb(j,k)%p
        return v
    def val(a):
        nz=np.flatnonzero(a); return int(nz[0]) if len(nz) else None
    old=one.copy();cur=one.copy(); oldd=z.copy();curd=one.copy(); M=None
    for j in range(1,c*N+d):
        e=edge(j)
        nxt=sub(xp(cur) if j%2 else cur,mul(e,old))
        nxtd=sub(add(cur,curd if j%2 else xp(curd)),mul(e,oldd))
        old,cur=cur,nxt;oldd,curd=curd,nxtd
        if j+1==c*N-1:M=cur.copy()
    P,DP=cur,curd
    # f_d is an odd tail; T=f_d/X, DT=f_d' at this scalar.
    old=one.copy();cur=one.copy();oldd=z.copy();curd=one.copy()
    for j in range(1,d):
        e=edge(c*N+j)
        nxt=sub(xp(cur) if j%2 else cur,mul(e,old))
        nxtd=sub(add(cur,curd if j%2 else xp(curd)),mul(e,oldd))
        old,cur=cur,nxt;oldd,curd=curd,nxtd
    T,DT=cur,curd
    # For J=P/T, (XJ'-J)/(aM) = (X^2 DP*T-P*DT)/(T^2*a*M).
    numerator=sub(mul(xp(DP),T),mul(P,DT))
    denominator=mul(mul(mul(T,T),edge(c*N)),M)
    vd=val(denominator);vn=val(numerator)
    need(vd==N+E+2*m,'denominator lattice')
    lift=2 if p==2*d+1 else 1
    need(vn==vd+lift,'full ordinary bracket valuation')
    actual=int(numerator[vn])*pow(int(denominator[vd]),-1,p)%p
    expected=mod(-F(alpha,320) if lift==2 else F(alpha*(2*d+1),24),p)
    need(actual==expected,'full ordinary bracket unit')
    need(val(P) is None or val(P)>S+lift*p,'scalar lifting margin')
    return dict(p=p,c=c,d=d,n=c*N+d,scalar_normalizer=S,scalar_value=val(P),claimed_scalar_lower_strict=S+lift*p,bracket_valuation=lift,bracket_unit=actual,expected_unit=expected,denominator_value=vd,truncation=limit)


def tails():
    results=[]
    for m in range(1,18):
        # Independent exhaustive maximal matching recurrence on edge path.
        allmatches=[]
        def visit(nextedge,chosen):
            if nextedge>2*m:
                if len(chosen)==m:allmatches.append(tuple(chosen))
                return
            visit(nextedge+1,chosen)
            if not chosen or nextedge-chosen[-1]>1:visit(nextedge+1,chosen+[nextedge])
        # m>=12 avoid exponential enumeration: exact list follows path complement.
        if m<12:visit(1,[])
        else:allmatches=[tuple(list(range(1,2*l,2))+list(range(2*l+2,2*m+1,2))) for l in range(m+1)]
        need(len(allmatches)==m+1,'tail match count')
        def jet(indices):
            base=math.prod(indices)
            a=[F(j-1,2) for j in indices]
            b=[F((j-1)*(j-2),6) for j in indices]
            return (F(base),base*sum(a),base*(sum(b)+sum(a[i]*a[j] for i in range(len(a)) for j in range(i))))
        T=tuple(sum(jet(q)[k] for q in allmatches) for k in range(3))
        V=jet(range(2,2*m+1,2))
        a0=V[0]/T[0];a1=(V[1]-T[1]*a0)/T[0];a2=(V[2]-T[1]*a1-T[2]*a0)/T[0]
        need(a0==F(df(2*m),df(2*m+1)),'tail alpha')
        need(a1/a0==F(m,6),'tail first jet')
        need(a2/a0==F(m*(7*m-27),360),'tail second jet')
        need(F(m*(7*m-27),360)-F(9,128)==F((4*m+3)*(28*m-129),5760)-F(1,320),'second-correction symbolic factor')
        results.append(dict(m=m,matchings=len(allmatches),jet=['1',str(a1/a0),str(a2/a0)]))
    return results


def arithmetic():
    obs=[]
    for p in [5,7,11,13,17,19,23,29,31,37,41,43]:
        for c in range(3,p,2):
            for d in range(3,p,2):
                alpha=F(df(d-1),df(d));value=mod(rc(c,-alpha),p)
                if not value: obs.append(dict(p=p,c=c,d=d,lift=2 if p==2*d+1 else 1))
                B=p*(p-1)
                for lift in ([1,2] if p>=7 else [1]):
                    margin=(p-c)*B-F(p-1,2)
                    need(margin>lift*p,'original even-target transfer margin')
                h=1;beta=p**h;L=p*p//beta
                need((beta-1)*c*L+c*L+1+d-1==c*p*p+d,'all root accounting')
    need(obs[0]==dict(p=7,c=3,d=3,lift=2),'smallest simultaneous pair')
    return obs


def main():
    out={'method':'New independent controls only; no supplied programs run; exact integer/rational and finite-field arithmetic. Finite tests supplement, not replace, the uniform proof.','tail_jets':tails(),'arithmetic_obstructions':arithmetic(),'original_recurrence_controls':[scal(7,3,3),scal(13,5,11)]}
    print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':main()
