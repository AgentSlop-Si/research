#!/usr/bin/env python3
"""Explicit counterchecks against the plausible overclaims reviewed here."""
import json
from fractions import Fraction as F

def need(ok,msg):
 if not ok:raise RuntimeError(msg)

def mod(x,p):
 x=F(x);return x.numerator*pow(x.denominator,-1,p)%p

out=[]
def reject(name,countercheck):
 need(countercheck,name+' was not rejected');out.append({'mutation':name,'status':'REJECTED_BY_EXACT_COUNTERCHECK'})
p=7;alpha=mod(F(2,3),p)
reject('Borrow the even-c2 residual U+1 for odd c3',(-alpha+3)%p==0 and (-alpha+1)%p!=0)
reject('Discard the central interior class',3*49+1!=3*49)
reject('Claim an exact zero root for the original even P150',all(2**j-1>0 for j in range(1,150,2)))
reject('Start the V matching edge set at 1',mod(F(1,3),p)!=alpha)
reject('Use beta=p^ceil(r/2) at p5,r3 with the unchanged rho',F(5)>=F(9,2))
reject('Omit the constant odd Aprime pivot',3%7!=0)
reject('Use the even operator bound wt(j_U)>=delta',mod(F(4)*3**7,7)!=0)
reject('Ignore the short-tail first-jet contribution',mod(F(alpha,8),p)!=0 and mod(F(alpha*7,24),p)==0)
reject('Treat the p7,c3,d3 first correction as a unit',mod(F(alpha*7,24),p)==0)
reject('Reverse the second correction sign',mod(-F(alpha,320),p)!=mod(F(alpha,320),p))
reject('Use a sign-independent even-c derivative unit at both Y signs',p>2 and (-1)%p!=1)
print(json.dumps({'negative_controls':out,'count':len(out),'scope':'Bounded mathematical mutations only; not a proof by testing.'},sort_keys=True,indent=2))
