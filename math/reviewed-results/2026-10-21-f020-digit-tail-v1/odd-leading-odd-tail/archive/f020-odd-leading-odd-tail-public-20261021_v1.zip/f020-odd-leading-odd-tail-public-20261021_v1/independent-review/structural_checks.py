#!/usr/bin/env python3
"""Independent all-term valuation and low recurrence controls."""
import json
from math import factorial

def need(ok,msg):
 if not ok:raise RuntimeError(msg)

def controls(p,c,r):
 N=p**r;B=r*(p-1)*p**(r-1)//2;K2=c*N+2*c*B;E=(c-1)*N//2+c*B;D=N+E-p
 h=r//2;beta=p**h;L=N//beta;rho2=beta if r%2==0 else p**(h-1)*(2*p-1)
 n=c*N
 vp=[0]
 for j in range(1,n+1):
  k=j;v=1
  while k%p==0:k//=p;v*=p
  vp.append(v)
 W=[0]
 for v in vp[1:]:W.append(W[-1]+v)
 T2=[0]
 for j in range(n):T2.append(T2[-1]+(rho2 if j==0 else min(2*vp[j],rho2)))
 out={'p':p,'c':c,'r':r,'beta':beta,'L':L,'rho_twice':rho2}
 for role,b,target2,parity in [('A',n,K2,1),('M',n-1,2*E,0)]:
  vals=[(2*W[b]-2*W[k]-2*W[(b-k)//2]+T2[k],k) for k in range(b%2,b+1,2)]
  need(min(v for v,k in vals)==target2,role+' weight')
  piv=[k for v,k in vals if v==target2]
  need(piv==[j*N for j in range(parity,c+1,2)],role+' parity pivots')
  if r==2:
   gap=min(v-target2 for v,k in vals if v!=target2)
   need(gap>=(B+p-1 if role=='A' else p-1),'complete nonpivot gap')
   out[role+'_nonpivot_gap_twice']=gap
  out[role+'_pivots']=piv
 for role,b,target2 in [('Aprime',n,2*D),('Mprime',n-1,2*E)]:
  lowest=None;piv=[];second=None;terms=0
  for k in range(b%2,b+1,2):
   a=(b-k)//2
   for m in range(k):
    v=2*W[b]-2*W[a]-2*W[m]-2*vp[k-m]+T2[m];terms+=1
    need(v>=target2,role+' full ordinary derivative bound')
    if lowest is None or v<lowest:lowest=v
    if v==target2:piv.append((k,m))
    elif second is None or v<second:second=v
  if role=='Aprime':
   need(piv==[(j*N+p*p,j*N) for j in range(0,c,2)],'complete ordinary Aprime pivots')
   if r==2:need(second-target2>=p-1,'ordinary derivative nonpivot gap')
  out[role]={'terms':terms,'minimum_twice':lowest,'pivot_count':len(piv),'next_gap_twice':None if second is None else second-target2}
 return out

def low(p,c,r,d):
 n=c*p**r+d
 def add(a,b):
  out=[0]*max(len(a),len(b))
  for j,v in enumerate(a):out[j]=(out[j]+v)%p
  for j,v in enumerate(b):out[j]=(out[j]+v)%p
  return out
 def sc(a,k):return [(v*k)%p for v in a]
 A0=[1];A1=[0,1];D0=[0];D1=[1]
 for j in range(1,n):
  A0,A1=A1,add([0]+A1,sc(A0,j))
  D0,D1=D1,add(add(A0,[0]+D1),sc(D0,j))
 # Explicit Hermite coefficients, separate from recurrence.
 expected=[0]*(n+1)
 for u in range(d//2+1):expected[c*p**r+d-2*u]=(factorial(d)//(2**u*factorial(u)*factorial(d-2*u)))%p
 derivative=[j*expected[j]%p for j in range(1,n+1)]
 need(A1==expected,'low original polynomial recurrence')
 need(D1[:n]==derivative and all(v==0 for v in D1[n:]),'low original derivative recurrence')
 return {'p':p,'c':c,'r':r,'d':d,'n':n,'passed':True}

print(json.dumps({'all_term_cases':[controls(*q) for q in [(5,3,2),(7,3,2),(7,5,2),(13,11,2),(5,3,3)]], 'low_original_derivative_cases':[low(*q) for q in [(5,3,2,3),(7,3,2,3),(7,5,2,5),(13,5,2,11),(5,3,3,3)]]},indent=2,sort_keys=True))
