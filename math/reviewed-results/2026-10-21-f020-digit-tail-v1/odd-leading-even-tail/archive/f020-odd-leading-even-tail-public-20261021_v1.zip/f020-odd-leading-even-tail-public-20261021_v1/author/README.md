# F020 odd-leading even tails: author candidate

The bounded theorem covers odd 3<=c<p and even 2<=d<p in n=c p^r+d, r>=2, s>r, every original primitive p^s-th phase. New credit is restricted to even d>=4. The already accepted d=2, all-leading d=0, odd tails, and even-c sectors are not newly credited.

REPORT.md proves complete high/shallow/zero counts, original ordinary derivative and predecessor values, original H squarefreeness, original algebraic-square kernel values, and equal discriminant values. Unlike even leading digits, the central interior contains one simple exact zero. No small-prime or r=2 mathematical exception remains. The p=5,c=3,d=4 auxiliary cancellation is explicitly retained and shown harmless.

This is an author candidate, not self-acceptance. A separate independent review must bind the final manifest and report. No external state or accepted source has been changed.

Reproduce using Python 3 and SymPy as pinned in requirements.txt:

    python -B verify.py
    python -O -B verify.py
    python -B check_inventory_controls.py

Only newly authored local scripts execute. Source snapshots are explicitly partial documentary evidence, and the original zero-tail authority is an unchanged archive. SOURCE_BINDINGS.json pins all live source inventories, four accepting author/reviewer pairs, and the prior zero-tail archive. Verification requires those bound live source paths for the read-only source re-audit. It never executes or imports source programs.

Finite controls are diagnostics, not the uniform proof. Their exact scope is in CONTROL_RESULTS.json and REPORT.md Section 10. Inventories and replay results must not be confused with mathematical acceptance, public packaging acceptance, historical novelty, global closure, or a cost claim.
