"""New exact diagnostics, not a proof of the uniform theorem. No source import."""
import hashlib,itertools,json,math,sys
from fractions import Fraction
import sympy as sp

def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def herm(j,z):
    return sum(math.factorial(j)//(2**u*math.factorial(u)*math.factorial(j-2*u))*z**(j-2*u) for u in range(j//2+1))
def df(j):return math.prod(range(j,0,-2))
def monicdict(expr,z,p):return {int(k[0]):int(v)%p for k,v in sp.Poly(expr,z,modulus=p).terms() if int(v)%p}

def symbolic():
    x,a,A,Ap,M,Mp=sp.symbols('x a A Ap M Mp');b=sp.symbols('b0:14');T=[sp.Integer(1),x];U=[sp.Integer(0),sp.Integer(1)]
    for j in range(1,12):T.append(sp.expand(x*T[-1]-b[j]*T[-2]));U.append(sp.expand(x*U[-1]-b[j]*U[-2]))
    rows=[];neg=[]
    for d in range(2,13,2):
        def matching(lo,hi,degree):
            ans=0
            for size in range((hi-lo+2)//2+1):
                for inds in itertools.combinations(range(lo,hi+1),size):
                    if all(inds[k+1]-inds[k]>1 for k in range(len(inds)-1)):
                        ans+=(-1)**size*x**(degree-2*size)*math.prod(b[j] for j in inds)
            return sp.expand(ans)
        require(T[d]==matching(1,d-1,d),'T matching')
        require(U[d]==matching(2,d-1,d-1),'U matching')
        t,u=T[d],U[d];tp,up=sp.diff(t,x),sp.diff(u,x);F=t*A-a*u*M;Fp=tp*A+t*Ap-a*up*M-a*u*Mp;W=up*t-u*tp
        rhs=t*t*Ap-a*W*M-a*u*t*Mp
        require(sp.expand(t*Fp-tp*F-rhs)==0,'fraction-free identity')
        determinant=sp.expand(t*U[d-1]-T[d-1]*u)
        require(sp.expand(determinant+math.prod(b[j] for j in range(1,d)))==0,'tail determinant')
        m=d//2;require(sp.expand(t.subs(x,0)-(-1)**m*math.prod(b[j] for j in range(1,d,2)))==0,'constant matching')
        subs={b[j]:-j for j in range(1,d)}
        require(sp.expand(t.subs(subs)-herm(d,x))==0,'tail Hermite')
        if d==4:
            require(sp.expand(u-(x**3-(b[2]+b[3])*x))==0,'U4 edge start')
            bad=[rhs+a*u*t*Mp,t*Ap-a*W*M-a*u*t*Mp,t*t*Ap+a*W*M-a*u*t*Mp]
            for label,expr in zip(['omit_Mprime','lose_T_square','wrong_W_sign'],bad):
                require(sp.expand(t*Fp-tp*F-expr)!=0,'negative escaped '+label);neg.append(label)
            require(sp.expand(t*Fp-rhs)!=0,'off-root Fprime negative');neg.append('omit_Tprime_F_off_root')
            require(sp.expand(u-(x**3-(b[1]+b[2])*x))!=0,'edge-start negative');neg.append('wrong_U_edge_start')
        rows.append({'d':d,'matching':'PASS','witness':'PASS','determinant':'PASS','constant':df(d-1),'auxiliary_linear':int(sp.diff(u.subs(subs),x).subs(x,0))})
    # Original algebraic-square CD, no positivity or quotient polynomial.
    cd=[]
    for n in range(2,10):
        P=[sp.Integer(1),x];edges=[0]+[j*j+1 for j in range(1,n)]
        for j in range(1,n):P.append(sp.expand(x*P[-1]-edges[j]*P[-2]))
        lhs=sum(P[j]**2*math.prod(edges[k] for k in range(j+1,n)) for j in range(n))
        rhs=sp.diff(P[n],x)*P[n-1]-P[n]*sp.diff(P[n-1],x)
        require(sp.expand(lhs-rhs)==0,'original CD');cd.append(n)
    return {'tails':rows,'negative_controls_rejected':neg,'original_cleared_CD_degrees':cd}

def add(*polys,p):
    out={}
    for poly in polys:
        for k,v in poly.items():out[k]=(out.get(k,0)+v)%p
    return {k:v for k,v in out.items() if v}
def scalar(poly,s,p):return {k:(v*s)%p for k,v in poly.items() if v*s%p}
def shift(poly,j):return {k+j:v for k,v in poly.items()}
def shallow():
    rows=[];z=sp.Symbol('z')
    for p,c,d,r in [(5,3,4,2),(5,3,4,3),(7,3,4,2),(7,5,6,2),(11,9,6,2),(13,11,12,2),(17,15,16,2)]:
        N=p**r;n=c*N+d;Q0,Q1={0:1},{1:1};V0,V1={}, {0:1};prev=None
        for j in range(1,n):
            Q2=add(shift(Q1,1),scalar(Q0,j,p),p=p)
            V2=add(Q1,shift(V1,1),scalar(V0,j,p),p=p)
            Q0,Q1=Q1,Q2;V0,V1=V1,V2
        expected=shift(monicdict(herm(d,z),z,p),c*N)
        ep=scalar(shift(monicdict(herm(d-1,z),z,p),c*N),d,p)
        require(Q1==expected,'full shallow polynomial');require(V1==ep,'separate ordinary derivative')
        require(Q0==shift(monicdict(herm(d-1,z),z,p),c*N),'full shallow predecessor')
        require(sp.gcd(sp.Poly(herm(d,z),z,modulus=p),sp.Poly(herm(d-1,z),z,modulus=p)).degree()==0,'shallow gcd')
        B=r*(p-1)*p**(r-1)//2;E=(c-1)*N//2+c*B;D=N+E-p;m=d//2
        high=D+m;pred=N+E+m-1;den=c*N+2*c*B+d-1
        require(high+pred-den==N-p,'high kernel')
        require(n-1-den==-2*c*B,'shallow kernel')
        require(c*N*high+d*(n-1)//2==c*N*(D+d)+d*(d-1)//2,'discriminant')
        beta=p**(r//2);L=N//beta
        require((beta-1)*c*L+(c-1)*L+(L-1)+1==c*N,'zero-inclusive counts')
        require(n%2==1 and expected.get(0,0)==0,'original odd parity')
        rows.append({'p':p,'c':c,'d':d,'r':r,'n':n,'full_original_shallow_terms':sorted(Q1.items()),'full_ordinary_derivative_terms':sorted(V1.items()),'high_derivative':high,'high_predecessor':pred,'high_kernel':N-p,'shallow_kernel':-2*c*B,'discriminant':c*N*(D+d)+d*(d-1)//2,'beta':beta,'L':L,'central_nonzero_interior_count':L-1})
    return rows

def residuals():
    z=sp.Symbol('z');rows=[];cancel=[];count=0
    primes=list(sp.primerange(5,44))
    aux={};b=0
    for m in range(1,22):b=df(2*m-2)+(2*m-1)*b;aux[m]=b
    for p in primes:
        for c in range(3,p,2):
            hc=sp.Poly(herm(c,z),z,modulus=p);hm=sp.Poly(herm(c-1,z),z,modulus=p)
            require(hc.eval(0)==0 and hm.eval(0)!=0,'odd residual-zero constant')
            require(sp.gcd(hc,hm).degree()==0 and sp.gcd(hc,hc.diff()).degree()==0,'complete odd gcd')
            for d in range(4,p,2):
                C=df(d-1)%p;require(C!=0,'tail constant unit')
                require(sp.gcd(hc,hm.mul_ground(c*C)).degree()==0,'whole central derivative residual')
                require((c*C*int(hm.eval(0)))%p!=0,'zero derivative unit')
                count+=1
        for d in range(4,p,2):
            if aux[d//2]%p==0:cancel.append({'p':p,'d':d,'auxiliary_coefficient':aux[d//2],'decisive_constant_unit':df(d-1)%p})
    require(any(a['p']==5 and a['d']==4 for a in cancel),'smallest cancellation missing')
    # Inherited adjacent obstruction is harmless: R_11(-1)=0 mod 13.
    r11=sp.div(herm(11,z),z,z)[0];require(int(sp.rem(r11,z*z+1,z))%13==0,'adjacent fixture absent')
    # Reject dropping constant pivot or copying even-c sign, plus wrong zero geometry.
    hc=sp.Poly(herm(3,z),z,modulus=5);correct=sp.Poly(3*df(3)*herm(2,z),z,modulus=5)
    require(correct.eval(0)!=0,'correct zero unit')
    bad=correct-sp.Poly(int(correct.eval(0)),z,modulus=5)
    require(bad.eval(0)==0,'missing constant negative')
    require(correct!=correct.mul_ground(-1),'copied even-c scalar negative')
    require(hc.eval(0)==0,'zero-free negative')
    return {'primes':primes,'all_odd_c_even_d_combinations_checked':count,'auxiliary_cancellations':cancel,'inherited_p13_c11_obstruction_harmless':True,'negative_controls_rejected':['drop_constant_ordinary_pivot','copy_even_c_minus_epsilon_unit_at_p5','assert_odd_c_zero_free']}

# Original recurrence in F_p[t,X], with exact weighted truncation.
def badd(A,B,p):
    out=dict(A)
    for k,v in B.items():out[k]=(out.get(k,0)+v)%p
    return {k:v for k,v in out.items() if v}
def bmul(A,B,p,cap):
    out={}
    for (x,t),v in A.items():
        for (y,u),w in B.items():
            k=(x+y,t+u)
            if p*k[0]+2*k[1]<=cap:out[k]=(out.get(k,0)+v*w)%p
    return {k:v for k,v in out.items() if v}
def bder(A,p):return {(x-1,t):v*x%p for (x,t),v in A.items() if x and v*x%p}
def bnegative(A,p):return {k:-v%p for k,v in A.items()}
def binit(A,p):
    v=min(p*x+2*t for x,t in A)
    return v,{x:a for (x,t),a in A.items() if p*x+2*t==v}
def central_original():
    p,c,d,r,s=5,3,4,2,3;N=p*p;B=p*(p-1);m=d//2;n=c*N+d;E=(c-1)*N//2+c*B;D=N+E-p
    target=2*(D+2*m);cap=target+p-2*m
    edges={j:{(0,k):math.comb(j,k)%p for k in range(1,j+1) if math.comb(j,k)%p} for j in range(1,n)}
    P0={(0,0):1};P1={(1,0):1};record={0:P0,1:P1}
    for j in range(1,n):
        XP={(x+1,t):a for (x,t),a in P1.items() if p*(x+1)+2*t<=cap}
        P0,P1=P1,badd(XP,bmul(edges[j],P0,p,cap),p)
        if j+1 in [c*N-1,c*N,c*N+1,n-1,n]:record[j+1]=P1
    F=record[n];T0={(0,0):1};T1={(1,0):1}
    for j in range(1,d):
        T0,T1=T1,badd({(x+1,t):a for (x,t),a in T1.items()},bmul(edges[c*N+j],T0,p,cap),p)
    S=badd(bmul(T1,bder(F,p),p,target),bnegative(bmul(bder(T1,p),F,p,target),p),p)
    fval,finit=binit(F,p);sval,sinit=binit(S,p)
    require((fval,finit)==(c*N+2*c*B+d,{5:1,15:2}),'original central F initial')
    require((sval,sinit)==(target,{0:2,10:2}),'original central witness initial')
    zder={(x,t):a for (x,t),a in bder(F,p).items() if x==0};zval,zunit=binit(zder,p)
    require(zval==2*(D+m) and zunit=={0:4},'original zero derivative')
    # Mod-p discarded integer coefficients have this lower bound in original mixed characteristic.
    e=(p-1)*p**(s-1);raw=(n+d-1)//2;margin=e+raw-target//2
    require(margin>0,'mixed-characteristic lattice margin')
    # Any term beyond cap stays beyond the witness target after derivative and tail multiplication.
    require(cap-p+2*m==target,'weighted cutoff bound')
    # Degree bound independent of cancellation excludes all omitted X degrees from retained cap.
    xcap=(cap-n)//(p-1)
    require(n+(p-1)*(xcap+1)>cap,'raw omitted X-degree bound')
    # Fprime itself has a lower off-root term; the witness cancellation is necessary.
    fpval,_=binit(bder(F,p),p);require(fpval<2*(D+m),'off-root wrong-profile negative')
    return {'p':p,'c':c,'d':d,'r':r,'s':s,'phase_parameter':'actual t=q-1; formal q=1+t','original_degree':n,'maximum_retained_doubled_weight':cap,'largest_X_degree_permitted_by_raw_bound':xcap,'omitted_term_bound':'coefficient of X^l has t-order >=(n-l)/2; n+(p-1)l>cap excludes omitted degrees','central_F_doubled_weight':fval,'central_F_initial':finit,'central_witness_doubled_weight':sval,'central_witness_initial':sinit,'zero_derivative_doubled_value':zval,'zero_derivative_unit':zunit[0],'mixed_characteristic_discarded_p_margin':margin,'off_root_Fprime_doubled_weight':fpval,'correct_rootwise_derivative_doubled_value':2*(D+m),'negative_controls_rejected':['claim_rootwise_Fprime_profile_off_roots']}

def main():return {'status':'PASS','finite_controls_not_uniform_proof':True,'source_programs_executed':False,'symbolic':symbolic(),'shallow':shallow(),'residual':residuals(),'central_original':central_original()}
if __name__=='__main__':
    try:print(json.dumps(main(),sort_keys=True,indent=2))
    except Exception as exc:print(str(exc),file=sys.stderr);sys.exit(1)
