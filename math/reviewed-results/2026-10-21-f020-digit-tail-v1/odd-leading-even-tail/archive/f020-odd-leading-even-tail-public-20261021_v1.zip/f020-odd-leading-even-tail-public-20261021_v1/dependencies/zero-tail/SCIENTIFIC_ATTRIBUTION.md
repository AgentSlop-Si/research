# Scientific attribution and audit separation

The polynomial families and standard identities are classical. This packet asserts neither historical priority nor novelty and makes no FFT complexity or speed claim. The complete leading-two dependency retains the classical-source context and literature qualifications for the continuous q-Hermite normalization, Gaussian and Christoffel–Darboux identities, Hensel lifting and Newton polygons. No fresh exhaustive literature search is claimed.

## Contributions to the single-leading-digit theorem

A research collaborator proposed the previously unproved general n=c p^r block-factorial and Hermite mechanism. The author verified the complete uniform theorem: exact equality sets, block and shifted-factorial phase/unit identities, root cover, odd-c strict-interior counts, Hermite coprimeness, and transfers to the original H/P ordinary derivatives, discriminants, and algebraic-square kernel. The accepted leading-two work supplied the half-W cap, ordinary-derivative score, and exact-arithmetic infrastructure; these inherited contributions remain credited.

The separate reviewer knew the proposed scope early and built independent controls, but supplied no essential derivational lemma and requested no mathematical change to the completed frozen proof. An early unfrozen derivative-value transcription was corrected before the audit, as expressly recorded in the review. Progress reports before freeze were not final acceptance. The completed independent review verified all ten frozen author-manifest entries, bound the exact author source identities, and accepted only the stated single-leading-digit family.

Neutral public role naming preserves the proposed-mechanism contribution and author verification rather than presenting the proof as unaided or conflating collaboration with the fresh final audit. SOURCE_LEDGER.json identifies every such replacement by hashes and counts. Earlier collaborator/developmental-review/final-review boundaries remain unchanged in the retained dependency.
