# Attribution and separation

A research collaborator proposed the previously unproved general n=c p^r block-factorial and Hermite mechanism. The author of this candidate verified the complete uniform theorem, including the precise polynomial and ordinary-derivative equality sets, block and shifted-factorial phase/unit identities, complete root cover, odd-c strict-interior root counts, Hermite coprimeness, and original H/P/discriminant/kernel transfers.

The accepted leading-two proof and its independent audit supplied the half-W cap and the one-variable ordinary-derivative score. They are included byte-for-byte as background evidence. The finite checker adapts the accepted leading-two rational-identity and cyclotomic-arithmetic infrastructure, with new general-c equality and exact unit comparisons.

A separate audit track was told the proposed scope early. It reported that its independent controls had passed and no defect had been identified, but did not provide an essential lemma or derivational help. Its final disposition must bind the frozen candidate bytes; preliminary favorable reports are not acceptance. If the auditor identifies a defect or causes a mathematical change, that contribution and the changed bytes must be disclosed.

This package does not enlarge global F020/F023 status, does not prove arbitrary intermediate digits, and does not authorize external writes. All new author work is separate from the accepted packages.
