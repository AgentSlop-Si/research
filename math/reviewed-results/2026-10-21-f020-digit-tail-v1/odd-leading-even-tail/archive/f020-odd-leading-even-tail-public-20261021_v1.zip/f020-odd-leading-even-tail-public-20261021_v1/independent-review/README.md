# Independent accepted review of odd-leading even tails

Read INDEPENDENT_REVIEW.md and VERDICT.json first. The exact author manifest is bound in SOURCE_BINDING.json. New coverage is only odd 3<=c<p, even 4<=d<p, r>=2, s>r, every primitive phase; d=2 and all previously accepted sectors are inherited.

Run python verify.py, or python -O verify.py. The verifier executes only the two newly written review programs. Supplied author/dependency code is never imported or executed. Source auditing reads the original local packages at their bound paths. Run with --inventory-only for an artifact-only inventory check.

The sources subdirectory is explicitly a partial documentary snapshot; its copied author manifest describes the complete original package, not that partial directory. Finite controls do not replace the uniform proof. The modulo-251 bad reduction is retained and explained, not hidden. No external write, global closure, historical novelty, or cost claim is made.
