#!/usr/bin/env python3
"""Exact-ZIP, durable, capped current-program replay with kernel isolation."""
from pathlib import Path
import argparse,re,hashlib,importlib.util,json,math,os,platform,resource,shutil,signal,struct,subprocess,sys,tempfile,time
ROOT=Path(__file__).resolve().parents[1]
OUT=None
COMMANDS=[]
def need(x,msg):
 if not x:raise ValueError(msg)
def H(b):return hashlib.sha256(b).hexdigest()
def put(p,x):
 temp=p.with_name(p.name+'.pending')
 with temp.open('w') as f:
  f.write(json.dumps(x,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 temp.replace(p)
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def stop(signum,frame):raise InterruptedError('Replay received signal '+str(signum))
def main():
 global OUT
 p=argparse.ArgumentParser();p.add_argument('--archive',required=True);p.add_argument('--expect-sha256',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 requested=Path(a.output).absolute();need(not requested.is_symlink(),'Output symlink forbidden');out=requested.resolve();need(out!=ROOT and ROOT not in out.parents and not out.exists(),'Output must be new and outside the frozen input');out.mkdir(parents=True);OUT=out
 put(out/'REPLAY_RESULT.json',{'status':'FAIL','phase':'RUNNING','completion_is_not_established':True})
 for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,stop)
 spec=importlib.util.spec_from_file_location('public_verify',ROOT/'tools/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 need(v.HEX.fullmatch(a.expect_sha256),'trusted archive digest required');archive=Path(a.archive).resolve();raw=archive.read_bytes();raw_archive=raw;need(H(raw)==a.expect_sha256,'archive SHA-256 mismatch')
 need(platform.system()=='Linux' and platform.machine()=='x86_64','Retained replay profile requires Linux x86-64');need(shutil.which('bwrap'),'bubblewrap is required; no weaker fallback')
 need(sys.version_info[:2]==(3,12),'CPython 3.12 required; see requirements')
 put(out/'ENVIRONMENT.json',{'python':sys.version.split()[0],'system':platform.system(),'architecture':platform.machine(),'kernel_release':platform.release()})
 # x86-64 architecture guard, x32 rejection, native network/io_uring syscall denial.
 denied=list(range(41,56))+[288,299,307,425,426,427]
 ins=[(0x20,0,0,4),(0x15,1,0,0xc000003e),(0x06,0,0,0x80000000),(0x20,0,0,0),(0x45,0,1,0x40000000),(0x06,0,0,0x00050001)]
 for n in denied:ins.extend([(0x15,0,1,n),(0x06,0,0,0x00050001)])
 ins.append((0x06,0,0,0x7fff0000));filt=b''.join(struct.pack('HBBI',*x) for x in ins)
 put(out/'ISOLATION_POLICY.json',{'method':'bubblewrap mount/PID/IPC/UTS namespaces plus architecture-checked kernel seccomp','network_namespace_used':False,'network_policy':'Socket, network and io_uring syscalls return EPERM; inherited descriptors except policy and standard streams are closed.','denied_x86_64_syscalls':denied,'seccomp_bpf_sha256':H(filt),'runtime_mounts':'Read-only operating-system libraries and active Python runtime','input_mount':'Exact safely extracted delivery ZIP, read-only at /input','writable_mount':'Fresh replay directory at /work and private temporary filesystem','original_workspace_mounted':False,'weaker_fallback':False})
 put(out/'INPUT_ARCHIVE.json',{'sha256':H(raw),'bytes':len(raw),'package_root':v.PACKAGE,'caller_supplied_trusted_digest_matched':True})
 with tempfile.TemporaryDirectory(prefix='odd-leading-even-tail-mount-replay-') as td:
  tmp=Path(td);extract=tmp/'extract';v.canonical_members(raw);v.extract(raw,extract);need({x.name for x in extract.iterdir()}=={v.PACKAGE},'ZIP package root');stage=extract/v.PACKAGE
  put(out/'INTEGRITY_BEFORE.json',v.integrity(stage));before={n:v.ident((stage/n).read_bytes()) for n in v.inventory(stage)}
  need((stage/'tools/replay.py').read_bytes()==Path(__file__).read_bytes(),'Runner is not the exact ZIP runner');need((stage/'tools/verify.py').read_bytes()==(ROOT/'tools/verify.py').read_bytes(),'Verifier is not the exact ZIP verifier')
  (out/'INPUT_MANIFEST.json').write_bytes((stage/'MANIFEST.json').read_bytes())
  work=tmp/'work';work.mkdir();sentinel=tmp/'host-sentinel';sentinel.write_text('must remain inaccessible');policy=tmp/'seccomp.bpf';policy.write_bytes(filt)
  mounts=list(dict.fromkeys(str(Path(p)) for p in ['/usr','/lib','/lib64',sys.prefix] if Path(p).exists()))
  def run(label,args,cpu=60,wall=90,memory=1024**3,expected_returncode=0):
   target=out/label;target.mkdir();cap={'cpu_seconds':cpu,'wall_seconds':wall,'address_space_bytes':memory,'file_size_bytes':64*1024**2,'core_bytes':0,'numerical_threads':1}
   def limits():
    for name,n in [(resource.RLIMIT_CPU,cpu),(resource.RLIMIT_AS,memory),(resource.RLIMIT_FSIZE,64*1024**2),(resource.RLIMIT_CORE,0)]:resource.setrlimit(name,(n,n))
   rec={'label':label,'logical_arguments':args,'caps':cap,'status':'FAIL','phase':'RUNNING','expected_returncode':expected_returncode};put(target/'RESULT.json',rec)
   proc=None;started=time.monotonic();error=None;rc=None;timed_out=False
   with policy.open('rb') as f:
    cmd=['bwrap','--die-with-parent','--new-session','--unshare-user','--unshare-pid','--unshare-ipc','--unshare-uts']
    for x in mounts:cmd+=['--ro-bind',x,x]
    cmd+=['--ro-bind',str(stage),'/input','--bind',str(work),'/work','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--chdir','/work','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--setenv','OPENBLAS_NUM_THREADS','1','--setenv','OMP_NUM_THREADS','1','--setenv','MKL_NUM_THREADS','1','--setenv','NUMEXPR_NUM_THREADS','1','--setenv','PYTHONDONTWRITEBYTECODE','1','--setenv','PYTHONHASHSEED','0','--seccomp',str(f.fileno()),sys.executable,'-I','-B']+args
    replacements={str(stage):'<STAGED_EXACT_ZIP_INPUT>',str(work):'<REPLAY_WORK_DIRECTORY>',str(sentinel):'<UNMOUNTED_HOST_SENTINEL>',str(ROOT):'<ORIGINAL_RUNNER_DIRECTORY>',str(ROOT.parent):'<ORIGINAL_PARENT_DIRECTORY>',str(archive):'<ORIGINAL_ARCHIVE>',sys.executable:'<PYTHON_EXECUTABLE>',sys.prefix:'<PYTHON_RUNTIME>',str(f.fileno()):'<SECCOMP_POLICY_FD>'}
    rec['logical_arguments']=[replacements.get(x,x) for x in args];rec['normalized_argv']=[replacements.get(x,x) for x in cmd];put(target/'RESULT.json',rec)
    try:
     with (target/'STDOUT.txt').open('wb') as stdout,(target/'STDERR.txt').open('wb') as stderr:
      proc=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,pass_fds=(f.fileno(),),preexec_fn=limits,start_new_session=True)
      rec['child_started']=True;rec['child_pid']=proc.pid;put(target/'RESULT.json',rec)
      try:rc=proc.wait(timeout=wall)
      except subprocess.TimeoutExpired:timed_out=True;raise
    except BaseException as e:error=e
    finally:
     if proc is not None and proc.poll() is None:
      os.killpg(proc.pid,signal.SIGKILL);proc.wait()
     if proc is not None:rc=proc.returncode
     rec.update(phase='FINISHED',status='PASS' if error is None and not timed_out and rc==expected_returncode else 'FAIL',returncode=rc,timed_out=timed_out,elapsed_wall_seconds=round(time.monotonic()-started,6),stdout_sha256=H((target/'STDOUT.txt').read_bytes()) if (target/'STDOUT.txt').exists() else None,stderr_sha256=H((target/'STDERR.txt').read_bytes()) if (target/'STDERR.txt').exists() else None)
     if error:rec['failure_type']=type(error).__name__
     put(target/'RESULT.json',rec);COMMANDS.append(rec);put(out/'COMMANDS.json',COMMANDS)
   if error:raise error
   need(rec['status']=='PASS',label+' failed; durable raw logs and result retained')
   return (target/'STDOUT.txt').read_bytes()
  run('isolation_probe',['/input/tools/isolation_probe.py',str(sentinel),str(ROOT),str(ROOT.parent),str(archive)],15,30)
  run('isolation_probe_optimized',['-O','/input/tools/isolation_probe.py',str(sentinel),str(ROOT),str(ROOT.parent),str(archive)],15,30)
  for optimized in [False,True]:
   prefix=['-O']if optimized else[];suffix='_optimized'if optimized else''
   run('public_integrity'+suffix,prefix+['/input/tools/verify.py'],30,60)
   run('public_negative_controls'+suffix,prefix+['/input/tools/verify.py','--negative-controls'],90,120)
  comparisons=[];(out/'scientific_outputs').mkdir()
  for spec in v.read(stage/'REPLAY_POLICY.json')['current_scientific_programs']:
   for optimized in [False,True]:
    role=spec['role'];label=role+('_optimized' if optimized else '');args=(['-O']if optimized else[])+['/input/tools/run_case.py',role]
    stdout=run(label+'_controls',args,180,210,1024**3);data=(work/label/spec['result']).read_bytes();ref=(stage/spec['reference']).read_bytes()
    (out/'scientific_outputs'/(label+'.json')).write_bytes(data)
    need(data==ref,'scientific result bytes differ: '+label)
    need(len(stdout)==spec['stdout_bytes'] and H(stdout)==spec['stdout_sha256'],'scientific stdout bytes differ')
    stderr=(out/(label+'_controls')/'STDERR.txt').read_bytes();need(len(stderr)==spec['stderr_bytes'] and H(stderr)==spec['stderr_sha256'],'scientific stderr bytes differ')
    result={'case':label,'result_byte_exact':True,'stdout_byte_exact':True,'stdout_sha256':H(stdout)}
    result.update(optimized_python=optimized,script_sha256=H((stage/spec['script']).read_bytes()),result_sha256=H(data),reference_sha256=H(ref),raw_result_bytes_preserved=True,raw_stdout_bytes_preserved=True,program_arithmetic_unchanged=True)
    optimization=(work/label/'OPTIMIZATION.json').read_bytes();(out/'scientific_outputs'/(label+'_OPTIMIZATION.json')).write_bytes(optimization);state=v.loads(optimization);v.same(state,{'optimize':int(optimized),'debug':not optimized,'assert_executed':not optimized},'actual child optimization semantics');result['actual_child_optimization_probe']=state;result['scientific_stderr_byte_exact']=True;result['stderr_sha256']=H(stderr);result['scientific_stderr_empty']=(stderr==b'')
    comparisons.append(result)
  put(out/'OUTPUT_COMPARISONS.json',{'scientific':comparisons,'historical_programs_freshly_replayed':False,'original_inventory_wrappers_replayed':False,'scientific_source_adapters':[],'output_comparison_exceptions':[],'current_independent_review_controls_replayed':True})
  run('public_integrity_after',['/input/tools/verify.py']);need(v.exact(before,{n:v.ident((stage/n).read_bytes()) for n in v.inventory(stage)}),'exact frozen input changed');put(out/'INTEGRITY_AFTER.json',v.integrity(stage))
  result={'status':'PASS','input_zip_sha256':H(raw_archive),'input_zip_bytes':len(raw_archive),'public_manifest_sha256':before['MANIFEST.json']['sha256'],'author_result_and_stdout_byte_exact_comparisons':2,'review_result_and_stdout_byte_exact_comparisons':2,'current_independent_review_controls_replayed':True,'raw_result_bytes_preserved_outside_delivery':True,'result_or_stdout_exceptions':[],'current_scientific_programs_unchanged_normal_and_optimized':True,'public_inventory_and_mutations_pass_normal_and_optimized':True,'original_inventory_wrappers_replayed':False,'scientific_source_adapters':[],'retained_source_files':len(v.read(stage/'provenance/SOURCE_INVENTORY.json')['files']),'omitted_original_files':len(v.read(stage/'provenance/SOURCE_INVENTORY.json')['omissions']),'omitted_historical_inventory_closed':False,'historical_programs_freshly_replayed':False,'original_workspace_inaccessible':True,'native_network_denial_verified':True,'input_write_rejection_verified_both_modes':True,'kernel_isolation':True,'public_packaging_independently_accepted':False,'commands_completed':len(COMMANDS)}
  put(out/'REPLAY_RESULT.json',result);print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':
 try:main()
 except BaseException as e:
  if OUT is not None:put(OUT/'REPLAY_RESULT.json',{'status':'FAIL','failure_type':type(e).__name__,'commands_completed':len(COMMANDS),'incomplete_or_failed_is_never_PASS':True,'raw_command_logs_retained':True})
  print('FAIL: '+str(e),file=sys.stderr);sys.exit(1)
