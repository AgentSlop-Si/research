#!/usr/bin/env python3
"""Actively test inaccessible host paths, immutable input, and native network denial."""
import ctypes,errno,json,os,socket,sys
from pathlib import Path
def need(b,m):
 if not b:raise RuntimeError(m)
paths=sys.argv[1:];need(len(paths)>=3,'host probe arguments required')
for p in paths:
 need(not Path(p).exists(),'original host locator exposed')
 try:os.open(p,os.O_RDONLY)
 except OSError as e:need(e.errno in(errno.ENOENT,errno.EACCES),'unexpected host-open errno')
 else:raise RuntimeError('original host open succeeded')
for family in(socket.AF_INET,socket.AF_INET6,socket.AF_UNIX):
 try:socket.socket(family,socket.SOCK_STREAM)
 except OSError as e:need(e.errno==errno.EPERM,'unexpected Python socket errno')
 else:raise RuntimeError('Python socket succeeded')
libc=ctypes.CDLL(None,use_errno=True);libc.socket.argtypes=[ctypes.c_int]*3
for family in(2,10,1):
 ctypes.set_errno(0);fd=libc.socket(family,1,0);need(fd==-1 and ctypes.get_errno()==errno.EPERM,'native network not denied')
need(Path('/input/author/REPORT.md').is_file(),'input not readable')
try:os.open('/input/WRITE_PROBE',os.O_WRONLY|os.O_CREAT,0o600)
except OSError as e:need(e.errno in(errno.EROFS,errno.EACCES,errno.EPERM),'unexpected immutable-input errno')
else:raise RuntimeError('input was writable')
Path('/work/probe.txt').write_text('writable isolated replay directory')
print(json.dumps({'status':'PASS','unmounted_host_paths_checked':len(paths),'python_socket_families_denied':3,'native_libc_socket_families_denied':3,'input_readable':True,'input_write_rejected':True,'isolated_output_writable':True}))
