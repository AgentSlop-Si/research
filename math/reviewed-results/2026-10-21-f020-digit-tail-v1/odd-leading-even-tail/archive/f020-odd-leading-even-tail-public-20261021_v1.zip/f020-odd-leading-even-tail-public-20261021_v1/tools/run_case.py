#!/usr/bin/env python3
"""Invoke exact scientific sources; only operational paths and stdout capture are adapted."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
I=Path('/input');W=Path('/work')
def need(b,m):
 if not b:raise RuntimeError(m)
def main():
 role=sys.argv[1];specs=json.loads((I/'REPLAY_POLICY.json').read_bytes())['current_scientific_programs'];choices={x['role']:x for x in specs};need(role in choices,'unsupported replay role');spec=choices[role];d=W/(role+('_optimized'if sys.flags.optimize else''));d.mkdir()
 source=I/spec['script'];script=d/source.name;shutil.copyfile(source,script);need(script.read_bytes()==source.read_bytes(),'scientific source changed')
 if spec.get('copy_reference_beside_script'):
  shutil.copyfile(I/spec['reference'],d/spec['result'])
 flags=[sys.executable,'-I','-B']+(['-O']if sys.flags.optimize else[])
 probe="import json,sys\nfired=False\ntry: assert False\nexcept AssertionError: fired=True\nprint(json.dumps({'optimize':sys.flags.optimize,'debug':__debug__,'assert_executed':fired},sort_keys=True))"
 obs=subprocess.run(flags+['-c',probe],capture_output=True,check=False);need(obs.returncode==0 and obs.stderr==b'','optimization probe failed');state=json.loads(obs.stdout);expected={'optimize':int(bool(sys.flags.optimize)),'debug':not bool(sys.flags.optimize),'assert_executed':not bool(sys.flags.optimize)};need(state==expected,'actual child optimization mismatch');(d/'OPTIMIZATION.json').write_bytes(obs.stdout)
 p=subprocess.run(flags+[str(script)]+spec.get('arguments',[]),cwd=d,stdout=subprocess.PIPE,stderr=subprocess.PIPE);sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr)
 need(p.returncode==0,'scientific child failed');need(len(p.stderr)==spec['stderr_bytes'] and hashlib.sha256(p.stderr).hexdigest()==spec['stderr_sha256'],'scientific stderr byte mismatch');
 if spec.get('result_from_stdout'):(d/spec['result']).write_bytes(p.stdout)
 need((d/spec['result']).is_file(),'scientific result missing')
if __name__=='__main__':main()
