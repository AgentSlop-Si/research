# ALG-010 prime-field cold realization candidate

A complete represented-prime-field realization of the existing first-order
q-linear Fourier recognizer, with paid root, failure, singular, encoding and
bit costs. Original source and completed comparison are preserved as inert
text. This is a classical engineering/bit-cost child, not novel Fourier
mathematics, a practical-speed claim or parent closure.

Read REPORT.md for the exact contracts and proof. Fresh reference code is
prime_field_executor.py. Run `python -B fresh_controls.py` for independent
rank/dense-oracle controls of this fresh implementation. No historical project
program is imported or executed. CONTROL_RESULTS.json and CONTROLS.log record
the last run; MANIFEST.json binds the candidate bytes.

Main bounds in the stated bit-cost random-access model:
- Supplied exact root: T_prime(p)+O(Nb^2+b^3), O(Nb) represented data bits.
- Any returned primitive root: same expected bound with <=4b expected unbiased
  bits, but no finite deterministic worst-case time without a cap.
- Actual reference prime validation is deterministic trial division, with
  O((1+sqrt(p))b^2) cost, not a free prime or hidden polynomial-time validator.

Only a separately reviewed scoped acceptance may close this child. ALG-010
remains open at its existing status/priority; arbitrary-field, numerical,
prescribed-unavailable-root, complete-priority and other parent gates remain.
No external file, table, repository or publication state was changed.
