"""Fresh ALG-010 prime-field realization. Standard library only; no old imports.
Exact reference, not a timing claim. Prime validation is actual trial division.
"""
from math import isqrt

class Field:
    def __init__(self, p):
        self.p = p
        self.count = dict(add=0, mul=0, inv=0)
    def add(self,a,b):
        self.count['add'] += 1
        return (a+b)%self.p
    def sub(self,a,b): return self.add(a,-b)
    def mul(self,a,b):
        self.count['mul'] += 1
        return a*b%self.p
    def power(self,a,e):
        r=1
        while e:
            if e&1: r=self.mul(r,a)
            e >>= 1
            if e: a=self.mul(a,a)
        return r
    def inv(self,a):
        if a%self.p==0: raise ZeroDivisionError
        self.count['inv'] += 1
        return self.power(a,self.p-2)
    def batch_inv(self, values):
        if not values: return []
        pref=[1]
        for a in values:
            if a==0: raise ZeroDivisionError
            pref.append(self.mul(pref[-1],a))
        z=self.inv(pref[-1]); out=[0]*len(values)
        for i in range(len(values)-1,-1,-1):
            out[i]=self.mul(z,pref[i]); z=self.mul(z,values[i])
        return out

def validate_prime(p):
    if type(p) is not int or p<2: raise ValueError('modulus is not prime')
    divisions=0
    if p%2==0:
        if p!=2: raise ValueError('modulus is not prime')
        return dict(method='trial_division',modulus_tests=1)
    for d in range(3,isqrt(p)+1,2):
        divisions+=1
        if p%d==0: raise ValueError('modulus is not prime')
    return dict(method='trial_division',modulus_tests=divisions+1)

def acquire_root(F,N,draw_bits,max_candidates=None,max_draws=None):
    """draw_bits(b) must return b independent unbiased random bits as an int.
    Caps return ROOT_LIMIT, never DECLINE or mathematical infeasibility.
    """
    p=F.p; b=p.bit_length(); draws=candidates=0
    for cap in (max_candidates,max_draws):
        if cap is not None and (type(cap) is not int or cap<0):
            raise ValueError('root caps must be nonnegative integers')
    while True:
        if max_candidates is not None and candidates>=max_candidates:
            return None,dict(status='ROOT_LIMIT',draws=draws,candidates=candidates,bits=draws*b)
        if max_draws is not None and draws>=max_draws:
            return None,dict(status='ROOT_LIMIT',draws=draws,candidates=candidates,bits=draws*b)
        a=draw_bits(b); draws+=1
        if type(a) is not int or not 0<=a<(1<<b): raise ValueError('invalid bit draw')
        if not 1<=a<p: continue
        if max_candidates is not None and candidates>=max_candidates:
            return None,dict(status='ROOT_LIMIT',draws=draws,candidates=candidates,bits=draws*b)
        candidates+=1
        q=F.power(a,(p-1)//N)
        if F.power(q,N//2)!=1:
            return q,dict(status='FOUND',draws=draws,candidates=candidates,bits=draws*b)
        if max_candidates is not None and candidates>=max_candidates:
            return None,dict(status='ROOT_LIMIT',draws=draws,candidates=candidates,bits=draws*b)

def discover(F,x,Q):
    piv={}
    for i in range(len(x)-1):
        row=[x[i],F.mul(Q[i],x[i]),x[i+1],F.mul(Q[i],x[i+1])]
        for j in sorted(piv):
            f=row[j]
            if f:
                row=[F.sub(row[k],F.mul(f,piv[j][k])) for k in range(4)]
        j=next((j for j,a in enumerate(row) if a),None)
        if j is None: continue
        if len(piv)==3: return None
        scale=F.inv(row[j]); piv[j]=[F.mul(a,scale) for a in row]
    free=next(j for j in range(4) if j not in piv)
    v=[0]*4; v[free]=1
    for j in sorted(piv,reverse=True):
        v[j]=0
        for k in range(j+1,4): v[j]=F.sub(v[j],F.mul(piv[j][k],v[k]))
    return v

def cycle_solve(F,A,B,c):
    """Solve A_i z_i+B_i z_(i+1)=c_i in the original one-zero-band class.
    Return a particular solution and either None or one nonzero kernel vector.
    """
    n=len(A)
    if not any(B):
        nz=[i for i,a in enumerate(A) if a]; zz=[i for i,a in enumerate(A) if not a]
        if len(zz)>1: raise ValueError('outside one-zero diagonal contract')
        inv=F.batch_inv([A[i] for i in nz]); y=[0]*n
        for i,a in zip(nz,inv): y[i]=F.mul(c[i],a)
        h=None
        if zz:
            i=zz[0]
            if c[i]: raise ArithmeticError('inconsistent diagonal system')
            h=[0]*n; h[i]=1
        return y,h
    zz=[i for i,b in enumerate(B) if not b]
    if len(zz)>1: raise ValueError('outside one-zero edge contract')
    start=(zz[0]+1)%n if zz else 0
    order=[(start+j)%n for j in range(n)]
    inv=F.batch_inv([B[i] for i in order[:-1]])
    alpha=[0]*n; beta=[0]*n; alpha[start]=1
    for j,i in enumerate(order[:-1]):
        k=order[j+1]
        alpha[k]=F.mul(-F.mul(A[i],alpha[i]),inv[j])
        beta[k]=F.mul(F.sub(c[i],F.mul(A[i],beta[i])),inv[j])
    last=order[-1]
    coeff=F.add(F.mul(A[last],alpha[last]),B[last])
    rhs=F.sub(c[last],F.mul(A[last],beta[last]))
    if coeff:
        t=F.mul(rhs,F.inv(coeff))
        return [F.add(beta[i],F.mul(alpha[i],t)) for i in range(n)],None
    if rhs: raise ArithmeticError('inconsistent cyclic system')
    return beta,alpha

def evaluate(p,x,q=None,draw_bits=None,max_candidates=None,max_draws=None):
    """Full input validation; exact prime check; supplied or acquired root.
    No general-FFT fallback: DECLINE means the family was exactly rejected.
    """
    if type(x) is not list: raise ValueError('input must be a canonical list')
    N=len(x)
    if N<4 or N&(N-1): raise ValueError('N must be dyadic and >=4')
    pv=validate_prime(p)
    if (p-1)%N: raise ValueError('N does not divide p-1')
    if any(type(a) is not int or not 0<=a<p for a in x):
        raise ValueError('noncanonical field input')
    F=Field(p); rr={'status':'SUPPLIED','draws':0,'candidates':0,'bits':0}
    if q is None:
        if draw_bits is None: raise ValueError('root or random-bit supplier required')
        q,rr=acquire_root(F,N,draw_bits,max_candidates,max_draws)
        if q is None: return dict(status='ROOT_LIMIT',root=rr,prime=pv,counts=F.count)
    if type(q) is not int or not 0<q<p: raise ValueError('noncanonical root')
    Q=[1]
    for i in range(N): Q.append(F.mul(Q[-1],q))
    if Q[N]!=1 or Q[N//2]==1: raise ValueError('root does not have exact order N')
    Q.pop(); coeff=discover(F,x,Q)
    if coeff is None:
        return dict(status='DECLINE',q=q,root=rr,prime=pv,counts=F.count)
    p0,p1,r0,r1=coeff
    A=[F.add(p0,F.mul(p1,Q[i])) for i in range(N)]
    B=[F.add(r0,F.mul(r1,Q[i])) for i in range(N)]
    residual=[F.add(F.mul(A[i],x[i]),F.mul(B[i],x[(i+1)%N])) for i in range(N)]
    if any(residual[:-1]): raise AssertionError('discovery residual failed')
    JA=[F.add(p0,F.mul(r0,Q[-k%N])) for k in range(N)]
    JB=[F.add(p1,F.mul(r1,Q[(-k-1)%N])) for k in range(N)]
    forcing=[F.mul(residual[-1],Q[-k%N]) for k in range(N)]
    y,h=cycle_solve(F,JA,JB,forcing)
    singular=h is not None
    if singular:
        _,v=cycle_solve(F,A,B,[0]*N)
        if v is None: raise AssertionError('similarity kernel mismatch')
        j=next(i for i,a in enumerate(v) if a)
        num=F.mul(N%p,x[j]); den=0; w=1; step=Q[-j%N]
        for k in range(N):
            num=F.sub(num,F.mul(w,y[k])); den=F.add(den,F.mul(w,h[k]))
            w=F.mul(w,step)
        if den==0: raise AssertionError('zero anchor')
        t=F.mul(num,F.inv(den))
        y=[F.add(y[k],F.mul(t,h[k])) for k in range(N)]
    return dict(status='ACCEPT',q=q,output=y,coefficients=coeff,singular=singular,
                source_boundary=residual[-1],root=rr,prime=pv,counts=F.count)

def encode_result(p,result):
    """Concrete result encoding with caller-known p,N; fixed-width big endian.
    R=ROOT_LIMIT; D=DECLINE followed by q; A=ACCEPT followed by q and all N outputs.
    """
    width=(p.bit_length()+7)//8
    if result['status']=='ROOT_LIMIT': return b'R'
    prefix=b'D' if result['status']=='DECLINE' else b'A'
    body=[result['q']]+(result['output'] if result['status']=='ACCEPT' else [])
    return prefix+b''.join(a.to_bytes(width,'big') for a in body)
