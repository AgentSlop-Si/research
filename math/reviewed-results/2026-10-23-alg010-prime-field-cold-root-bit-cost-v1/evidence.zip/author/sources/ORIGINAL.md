# Detecting and evaluating first-order q-linear inputs

9 October 2026. A cold exact full-Fourier fast path with automatic parameter
discovery and explicit treatment of singular transformed recurrences.
This is an adaptive exact-field algorithm for a restricted input family.
It does not give an input-independent sub-N-log-N evaluator for arbitrary
fresh inputs, a bit-complexity improvement, or a numerical-stability result.

## Acceptance theorem

Supply dyadic N>=4, a primitive Nth root q in an exact field, and the complete
fresh input x. The code validates the supplied root using a paid power table.
It accepts exactly when there is a nonzero quadruple (p0,p1,r0,r1) satisfying

    (p0+p1*q^i)*x_i + (r0+r1*q^i)*x_(i+1) = 0,  0<=i<N-1.

On every accepted input it computes all N exact Fourier outputs in O(N)
field operations and word work, with O(N) live field-element storage.
All relation discovery, inversions, operator preparation, endpoint correction,
singular-case recovery and output writes are included. Unstructured inputs
decline in O(N) work and require a general fallback.

For nonvanishing denominator this is the finite sequence with ratio
`x_(i+1)/x_i = -(p0+p1*q^i)/(r0+r1*q^i)`. The implementation also handles zero
coordinates and vanished coefficients directly. The family includes geometric
sequences, quadratic-phase chirps, and general linear-fractional q-ratios.
It includes fully dense fresh vectors. This statement is not a priority claim
for q-difference equations or Fourier shift/modulation identities.

## Discovery and finite-boundary identity

The N-1 observed rows

    [x_i, q^i*x_i, x_(i+1), q^i*x_(i+1)]

form a four-column homogeneous system. Streaming exact elimination keeps at
most four rows. Rank four proves no such relation exists; otherwise a nonzero
null vector supplies the parameters. Every source equation is checked again
while forming the complete cyclic residual. Sorting at most four pivot rows
has constant cost. No ratio search, approximate zero test or cached transform
is used.

Let D=diag(q^i), and let S shift the input forward cyclically. Define

    L=p0*I+p1*D+r0*S+r1*D*S.

With F[k,i]=q^(ki), the identities F D=shift_forward F and
F S=diag(q^-k) F prove F L=J F, where

    (J y)_k = (p0+r0*q^-k)*y_k
              + (p1+r1*q^(-k-1))*y_(k+1).

The first N-1 coordinates of u=Lx vanish. Its last coordinate is explicitly
computed, retaining the cyclic boundary that an infinite recurrence omits.
Consequently `(F u)_k=u_(N-1)*q^-k`, which is constructed in N multiplications.
The desired result solves `J y=F u`.

## Linear cyclic solve, including zeros and singularity

Both L and J are cyclic bidiagonal matrices. Their upper-diagonal coefficients
are a polynomial of degree at most one evaluated on distinct powers of q.
Thus that diagonal is either identically zero or has at most one zero.

If it is not identically zero, start just after its zero if present, or at
index zero otherwise. All N-1 forward edges on the resulting path are
nonzero. Express every coordinate as `y_i=alpha_i*t+beta_i` by one forward
scan. The final cyclic equation determines t or leaves one free parameter.
This remains valid when a diagonal coefficient vanishes and makes some
alpha_i zero. If the upper diagonal is identically zero, solve the diagonal
system directly. Its nonzero degree-one coefficient has at most one zero.
The nonzero parameter quadruple ensures neither whole operator is zero.
Therefore the nullity is always at most one, not an assumption about an
arbitrary sparse matrix.

When J is nonsingular this already determines F x. When J is singular, let
`y=y_part+t*h`, with h the computed nonzero target kernel. Solve L v=0 by
the same linear scan and choose an index j with v_j!=0. Fourier similarity
implies h is a nonzero scalar multiple of F v. Hence

    sum_k q^(-kj)*h_k != 0.

The actual supplied input provides the additional exact constraint

    sum_k q^(-kj)*y_k = N*x_j.

One full weighted sum fixes t, and a linear pass writes the complete output.
The sum, division, source-kernel construction and correction are all paid.
This is explicit input side information, not measurement-only reconstruction;
it does not contradict the attached joint-Galois conditioning theorem.

## Complete work and model

The primitive-root table and validation cost N field multiplications. The
four-column discovery uses at most a constant number of arithmetic operations
per input row, plus constant-size back substitution. Preparing both operators,
forming/checking the full residual, and its Fourier forcing costs 12N field
operations. In the nonzero-edge cycle branch the target solve costs 9N-1
operations when nonsingular, or 7N-3 when singular before its extra constraint.
Singular source-kernel recovery and the input constraint add at most 13N+2,
including one integer embedding. Diagonal branches cost no more. These loop
bounds establish the linear total; no asymptotic inference from timings is
needed. Comparisons, indexing, copying and N output writes add O(N) word work.

All inversions are explicitly counted, including query-dependent inversions
used by parameter discovery. This is adaptive rational arithmetic, not a
fixed linear circuit. Root construction, field-element bit representations
and floating-point error control remain separate costs. Nothing here gives
a stable floating-point implementation for all accepted parameters.

## Reproduce

Run `python3 run_audit.py` using standard-library Python. The self-contained
exact field helpers are copied from the earlier finite-boundary checkpoint;
their field construction is outside the supplied-root evaluation ledgers.

The audit passes 380 exact full outputs, including 244 singular reconstructions,
60 unstructured declines, eight degenerate-cycle controls and four invalid
root/shape controls. It covers three prime fields and small characteristic-zero
cyclotomic fields, complete basis vectors, geometric modes, dense chirps and
general ratio examples. Every accepted output is compared with an independent
dense Fourier-matrix oracle. An outer field wrapper observes every algorithmic
arithmetic call and confirms the recorded stage totals. Finite tests check
the implementation; the argument above supplies the all-length theorem.
