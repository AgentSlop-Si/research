"""Independent dense/rank oracles against fresh implementation, no old imports."""
import itertools,json,random
from pathlib import Path
from prime_field_executor import Field,evaluate,cycle_solve,acquire_root,encode_result
R=random.Random(202610230410)

def rank(A,p):
    A=[r[:] for r in A]; rank=0
    if not A:return 0
    for j in range(len(A[0])):
        k=next((k for k in range(rank,len(A)) if A[k][j]%p),None)
        if k is None:continue
        A[rank],A[k]=A[k],A[rank];a=pow(A[rank][j],p-2,p)
        A[rank]=[x*a%p for x in A[rank]]
        for k in range(rank+1,len(A)):
            a=A[k][j]
            A[k]=[(u-a*v)%p for u,v in zip(A[k],A[rank])]
        rank+=1
        if rank==len(A):break
    return rank

def oracle(p,q,x):
    n=len(x)
    return [sum(pow(q,k*j,p)*a for j,a in enumerate(x))%p for k in range(n)]
def root(p,n):return next(q for q in range(2,p) if pow(q,n,p)==1 and pow(q,n//2,p)!=1)
S={'cases':0,'accepted':0,'declined':0,'singular':0,'nonzero_boundary':0,'coordinates':0,'max_inverses':0,'cyclic_systems':0,'root_distribution_checks':[],'bad_inputs':0}

def check(p,n,x):
    q=root(p,n); r=evaluate(p,x,q=q)
    M=[[x[i],pow(q,i,p)*x[i]%p,x[i+1],pow(q,i,p)*x[i+1]%p] for i in range(n-1)]
    yes=rank(M,p)<4
    assert (r['status']=='ACCEPT')==yes,(p,n,x,r)
    encoded=encode_result(p,r); width=(p.bit_length()+7)//8
    assert len(encoded)==1+width*(n+1 if yes else 1)
    if yes:
        assert [int.from_bytes(encoded[1+width*(k+1):1+width*(k+2)],'big') for k in range(n)]==r['output']
    S['cases']+=1
    if yes:
        assert r['output']==oracle(p,q,x),(p,n,x,r)
        S['accepted']+=1;S['singular']+=r['singular'];S['nonzero_boundary']+=r['source_boundary']!=0;S['coordinates']+=n
    else:S['declined']+=1
    S['max_inverses']=max(S['max_inverses'],r['counts']['inv'])
    assert r['counts']['inv']<=6
    b=p.bit_length()
    # Deliberately generous closed ledger including Fermat inverse powers.
    assert r['counts']['add']+r['counts']['mul']<=200*n+20*b,(r,n,b)

for x in itertools.product(range(5),repeat=4):check(5,4,list(x))
for p,n in [(17,8),(17,16),(97,8),(97,16),(97,32),(257,64),(257,128),(257,256)]:
    q=root(p,n)
    check(p,n,[0]*n)
    for j in range(min(n,16)):
        x=[0]*n;x[j]=1;check(p,n,x)
    for a in range(min(n,16)):check(p,n,[pow(q,a*j,p) for j in range(n)])
    for _ in range(40):check(p,n,[R.randrange(p) for j in range(n)])
    made=0
    while made<50:
        pp=[R.randrange(p) for _ in range(4)]
        if not any(pp):continue
        p0,p1,r0,r1=pp;x=[R.randrange(p)];bad=False
        for i in range(n-1):
            t=pow(q,i,p);a=(p0+p1*t)%p;b=(r0+r1*t)%p
            if b:x.append(-a*x[-1]*pow(b,p-2,p)%p)
            elif a*x[-1]%p:bad=True;break
            else:x.append(R.randrange(p))
        if bad:continue
        check(p,n,x);made+=1

p=5;n=4;q=2
for coeff in itertools.product(range(p),repeat=4):
    if not any(coeff):continue
    a,b,c,d=coeff;A=[(a+b*pow(q,i,p))%p for i in range(n)];B=[(c+d*pow(q,i,p))%p for i in range(n)]
    z=[R.randrange(p) for _ in range(n)];v=[(A[i]*z[i]+B[i]*z[(i+1)%n])%p for i in range(n)]
    y,h=cycle_solve(Field(p),A,B,v)
    assert all((A[i]*y[i]+B[i]*y[(i+1)%n])%p==v[i] for i in range(n))
    mat=[[((A[i] if j==i else 0)+(B[i] if j==(i+1)%n else 0))%p for j in range(n)] for i in range(n)]
    assert (h is not None)==(rank(mat,p)<n)
    if h is not None:
        assert any(h);assert all((A[i]*h[i]+B[i]*h[(i+1)%n])%p==0 for i in range(n))
    S['cyclic_systems']+=1

for p,n in [(5,4),(17,4),(17,8),(17,16),(97,32),(257,256)]:
    candidates=[pow(a,(p-1)//n,p) for a in range(1,p)]
    good=[q for q in candidates if pow(q,n//2,p)!=1]
    assert len(good)==(p-1)//2
    assert all(pow(q,n,p)==1 for q in good)
    assert len(set(good))==n//2
    S['root_distribution_checks'].append({'p':p,'N':n,'valid_candidates':p-1,'primitive_trials':len(good),'distinct_primitive_roots':len(set(good))})

p=17;n=8;b=p.bit_length();fail=next(a for a in range(1,p) if pow(pow(a,2,p),4,p)==1);good=next(a for a in range(1,p) if pow(pow(a,2,p),4,p)!=1)
stream=iter([0,17,31,fail,good]);rr=evaluate(p,[1]*n,draw_bits=lambda _:next(stream))
assert rr['status']=='ACCEPT' and rr['root']==dict(status='FOUND',draws=5,candidates=2,bits=25)
assert rr['output']==oracle(p,rr['q'],[1]*n)
limited=evaluate(p,[1]*n,draw_bits=lambda _:fail,max_candidates=3)
assert limited['status']=='ROOT_LIMIT' and limited['root']['candidates']==3
limited2=evaluate(p,[1]*n,draw_bits=lambda _:0,max_draws=7)
assert limited2['status']=='ROOT_LIMIT' and limited2['root']['draws']==7
S['scripted_root_success']=rr['root'];S['candidate_cap']=limited['root'];S['draw_cap']=limited2['root']
for p,x,q in [(15,[0]*4,2),(17,[0]*6,2),(7,[0]*4,2),(17,[0]*8,1),(17,[0]*8,4),(17,[0]*7+[17],2),(17,[0]*7+[0.0],2),(17,[0]*7+[True],2),(17,[0]*8,-1)]:
    try:evaluate(p,x,q=q)
    except ValueError:S['bad_inputs']+=1
    else:raise AssertionError(('bad input accepted',p,x,q))
S['status']='PASS';S['implementation']='fresh prime_field_executor.py';S['historical_code_executed']=False
Path(__file__).with_name('CONTROL_RESULTS.json').write_text(json.dumps(S,indent=2)+'\n')
print(json.dumps(S,indent=2))
