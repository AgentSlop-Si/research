"""Independent mathematical controls. Imports no candidate or historical code.

The reconstruction uses division-free streaming elimination, then pays for
normalizing at most three stored rows. A separate dense RREF and direct Fourier
oracle determine acceptance and all outputs. This is not execution coverage of
the candidate Python module, which is inspected only as inert source text.
"""
from collections import Counter
from fractions import Fraction
from itertools import product
from math import isqrt
from pathlib import Path
import hashlib
import json
import random

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent / 'alg010_prime_field_cold_20261023_v1'
RNG = random.Random(202610230507)
COUNTS = Counter()
WITNESSES = {}

class Arithmetic:
    def __init__(self, p):
        self.p = p
        self.inversions = 0
        self.products = 0
        self.sums = 0
    def times(self, a, b):
        self.products += 1
        return a*b % self.p
    def plus(self, a, b):
        self.sums += 1
        return (a+b) % self.p
    def inverse(self, a):
        assert a % self.p
        self.inversions += 1
        # Fresh left-to-right Fermat powering, distinct from candidate loop.
        value = 1
        for digit in bin(self.p-2)[2:]:
            value = self.times(value, value)
            if digit == '1':
                value = self.times(value, a)
        return value
    def invert_list(self, xs):
        if not xs:
            return []
        prefixes = [1]
        for x in xs:
            assert x != 0
            prefixes.append(self.times(prefixes[-1], x))
        remaining = self.inverse(prefixes[-1])
        answer = []
        for j in reversed(range(len(xs))):
            answer.append(self.times(prefixes[j], remaining))
            remaining = self.times(remaining, xs[j])
        return answer[::-1]

def rref(matrix, p, width=None):
    """Independent full dense elimination oracle; no operation claim."""
    width = width if width is not None else len(matrix[0])
    a = [row[:] for row in matrix]
    pivot_columns = []
    r = 0
    for j in range(width):
        k = next((k for k in range(r, len(a)) if a[k][j] % p), None)
        if k is None:
            continue
        a[r], a[k] = a[k], a[r]
        z = pow(a[r][j], -1, p)
        a[r] = [u*z % p for u in a[r]]
        for k in range(len(a)):
            if k != r:
                z = a[k][j]
                a[k] = [(u-z*v) % p for u,v in zip(a[k], a[r])]
        pivot_columns.append(j)
        r += 1
        if r == len(a):
            break
    return a, pivot_columns

def relation_matrix(p, q, xs):
    return [[xs[i], pow(q,i,p)*xs[i]%p, xs[i+1], pow(q,i,p)*xs[i+1]%p]
            for i in range(len(xs)-1)]

def relation(A, rows):
    kept = []
    for source_row in rows:
        row = source_row[:]
        for column, basis in sorted(kept):
            pivot, coefficient = basis[column], row[column]
            row = [A.plus(A.times(pivot,u), -A.times(coefficient,v))
                   for u,v in zip(row,basis)]
        column = next((j for j,u in enumerate(row) if u), None)
        if column is not None:
            if len(kept) == 3:
                return None
            kept.append((column,row))
    used = {j for j,_ in kept}
    # Highest free column deliberately differs from the candidate's choice.
    free = max(set(range(4))-used)
    result = [int(j == free) for j in range(4)]
    for column, row in sorted(kept, reverse=True):
        dot = 0
        for j in range(column+1,4):
            dot = A.plus(dot, A.times(row[j], result[j]))
        result[column] = A.times(-dot, A.inverse(row[column]))
    return result

def bidiagonal(A, diagonal, upper, rhs):
    n = len(rhs)
    if not any(upper):
        positions = [i for i in range(n) if diagonal[i]]
        missing = sorted(set(range(n))-set(positions))
        assert len(missing) <= 1
        invs = A.invert_list([diagonal[i] for i in positions])
        answer = [0]*n
        for i, z in zip(positions,invs):
            answer[i] = A.times(z, rhs[i])
        kernel = None
        if missing:
            assert rhs[missing[0]] == 0
            kernel = [int(i == missing[0]) for i in range(n)]
        return answer,kernel
    cuts = [i for i in range(n) if upper[i] == 0]
    assert len(cuts) <= 1
    # Use a nonzero alternative starting position in the fully nonzero case.
    first = (cuts[0]+1)%n if cuts else n//2
    order = [(first+j)%n for j in range(n)]
    inverse_edges = A.invert_list([upper[i] for i in order[:-1]])
    pairs = [(0,0)]*n
    pairs[first] = (1,0)
    for j,z in enumerate(inverse_edges):
        i = order[j]
        alpha,beta = pairs[i]
        pairs[order[j+1]] = (A.times(-A.times(diagonal[i],alpha),z),
                            A.times(A.plus(rhs[i],-A.times(diagonal[i],beta)),z))
    last = order[-1]
    alpha,beta = pairs[last]
    closure = A.plus(A.times(diagonal[last],alpha),upper[last])
    remainder = A.plus(rhs[last],-A.times(diagonal[last],beta))
    if closure:
        parameter = A.times(remainder,A.inverse(closure))
        return [A.plus(v,A.times(u,parameter)) for u,v in pairs],None
    assert remainder == 0
    return [v for u,v in pairs],[u for u,v in pairs]

def trial_prime(p):
    if type(p) is not int or p < 2:
        raise ValueError('prime modulus required')
    tests = 1
    if p % 2 == 0:
        if p != 2:
            raise ValueError('composite')
        return tests
    d = 3
    while d*d <= p:
        tests += 1
        if p%d == 0:
            raise ValueError('composite')
        d += 2
    return tests

def reconstruct(p, q, xs):
    if type(xs) is not list:
        raise ValueError('list required')
    n = len(xs)
    if n < 4 or n & (n-1):
        raise ValueError('dyadic N >= 4 required')
    prime_tests = trial_prime(p)
    if (p-1)%n:
        raise ValueError('incompatible N')
    if any(type(x) is not int or x < 0 or x >= p for x in xs):
        raise ValueError('noncanonical input')
    if type(q) is not int or q <= 0 or q >= p:
        raise ValueError('noncanonical root')
    A = Arithmetic(p)
    table = [1]
    for _ in range(n):
        table.append(A.times(table[-1],q))
    if table[-1] != 1 or table[n//2] == 1:
        raise ValueError('root order')
    params = relation(A, relation_matrix(p,q,xs))
    if params is None:
        return {'status':'D','q':q,'inversions':A.inversions,'prime_tests':prime_tests}
    a,b,c,d = params
    source_diag = [A.plus(a,A.times(b,t)) for t in table[:-1]]
    source_edge = [A.plus(c,A.times(d,t)) for t in table[:-1]]
    residual = [A.plus(A.times(source_diag[i],xs[i]),
                       A.times(source_edge[i],xs[(i+1)%n])) for i in range(n)]
    assert residual[:-1] == [0]*(n-1)
    target_diag = [A.plus(a,A.times(c,table[(-k)%n])) for k in range(n)]
    target_edge = [A.plus(b,A.times(d,table[(-k-1)%n])) for k in range(n)]
    forcing = [A.times(residual[-1],table[(-k)%n]) for k in range(n)]
    values, kernel = bidiagonal(A,target_diag,target_edge,forcing)
    singular = kernel is not None
    if singular:
        _, original_kernel = bidiagonal(A,source_diag,source_edge,[0]*n)
        assert original_kernel is not None
        anchor = max(i for i,x in enumerate(original_kernel) if x)
        weight, step, denominator, difference = 1,table[(-anchor)%n],0,A.times(n%p,xs[anchor])
        for value,h in zip(values,kernel):
            denominator = A.plus(denominator,A.times(weight,h))
            difference = A.plus(difference,-A.times(weight,value))
            weight = A.times(weight,step)
        assert denominator
        coefficient = A.times(difference,A.inverse(denominator))
        values = [A.plus(value,A.times(coefficient,h)) for value,h in zip(values,kernel)]
    return {'status':'A','q':q,'output':values,'params':params,'singular':singular,
            'boundary':residual[-1],'inversions':A.inversions,'prime_tests':prime_tests}

def dense_fourier(p,q,x):
    return [sum(pow(q,k*i,p)*v for i,v in enumerate(x))%p for k in range(len(x))]

def wire(p,result):
    if result['status'] == 'R':
        return b'R'
    width = (p.bit_length()+7)//8
    values = [result['q']] + result.get('output',[])
    return result['status'].encode()+b''.join(v.to_bytes(width,'big') for v in values)

def check_vector(p,q,x):
    got = reconstruct(p,q,x)
    _,pivots = rref(relation_matrix(p,q,x),p)
    assert (got['status'] == 'A') == (len(pivots) < 4)
    assert got['inversions'] <= 6
    COUNTS['vectors'] += 1
    COUNTS['max_inversions'] = max(COUNTS['max_inversions'],got['inversions'])
    width = (p.bit_length()+7)//8
    packed = wire(p,got)
    assert int.from_bytes(packed[1:1+width],'big') == q
    if got['status'] == 'D':
        COUNTS['rank_four_declines'] += 1
        assert len(packed) == 1+width
        WITNESSES.setdefault('decline',{'p':p,'q':q,'x':x})
    else:
        COUNTS['accepts'] += 1
        COUNTS['coordinates'] += len(x)
        assert got['output'] == dense_fourier(p,q,x)
        assert len(packed) == 1+(len(x)+1)*width
        unpacked = [int.from_bytes(packed[1+i*width:1+(i+1)*width],'big')
                    for i in range(len(x)+1)]
        assert unpacked == [q]+got['output']
        COUNTS['singular'] += got['singular']
        COUNTS['nonzero_boundary'] += bool(got['boundary'])
        if got['inversions'] == 6:
            WITNESSES.setdefault('six_inversions',{'p':p,'q':q,'x':x,'result':got})
    return got

def sampling(p,n,draws,cap_candidates=None,cap_draws=None):
    used,nonzero = 0,0
    source = iter(draws)
    while ((cap_candidates is None or nonzero < cap_candidates) and
           (cap_draws is None or used < cap_draws)):
        a = next(source)
        used += 1
        assert type(a) is int and 0 <= a < 2**p.bit_length()
        if a == 0 or a >= p:
            continue
        nonzero += 1
        q = pow(a,(p-1)//n,p)
        if pow(q,n//2,p) != 1:
            return 'FOUND',q,used,nonzero
    return 'ROOT_LIMIT',None,used,nonzero

def run():
    expected = {'MANIFEST.json':'de2f60d8d2f8f9a168e8776aad776b2beb76ebdb211ba75a122d719f55a9a488',
                'REPORT.md':'2000241f7fe236608648cedb61fc70b994fb8b19849d72aa6b951eee78e319a2'}
    for name,digest in expected.items():
        assert hashlib.sha256((CANDIDATE/name).read_bytes()).hexdigest() == digest
    for entry in json.loads((CANDIDATE/'MANIFEST.json').read_text())['files']:
        data = (CANDIDATE/entry['path']).read_bytes()
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        COUNTS['bound_candidate_files'] += 1
    pinned = json.loads((HERE/'sources/PINNED_FETCH.json').read_text())['structuredContent']
    raw = pinned['content'].encode()
    assert hashlib.sha256(raw).hexdigest() == '952f1d290c9b71058687de0c663a58ec7883b0465edf12cf72496e1fcce7b2d6'
    (HERE/'sources/ORIGINAL_REMOTE.md').write_bytes(raw)
    assert json.loads((HERE/'sources/CURRENT_ROW.json').read_text())['structuredContent'] == json.loads((CANDIDATE/'sources/LIVE_ROW.json').read_text())['structuredContent']
    # Every raw vector and both primitive roots at the minimum endpoint.
    for q in (2,3):
        for x in product(range(5),repeat=4):
            check_vector(5,q,list(x))
    for p,n in ((17,8),(17,16),(41,8),(97,16),(97,32),(257,64),(257,128),(257,256)):
        q = next(a for a in range(2,p) if pow(a,n,p)==1 and pow(a,n//2,p)!=1)
        vectors = [[0]*n]
        vectors += [[int(i==j) for i in range(n)] for j in {0,1,n//2,n-2,n-1}]
        vectors += [[pow(q,k*i,p) for i in range(n)] for k in {0,1,n//2,n-1}]
        vectors += [[pow(q,(i*(i-1)//2)%n,p) for i in range(n)]]
        for _ in range(35):
            vectors.append([RNG.randrange(p) for _ in range(n)])
        for _ in range(35):
            a,b,c,d = [RNG.randrange(p) for _ in range(4)]
            if not any((a,b,c,d)):
                continue
            vals = [RNG.randrange(1,p)]
            for i in range(n-1):
                numerator = (a+b*pow(q,i,p))*vals[-1]%p
                denominator = (c+d*pow(q,i,p))%p
                if denominator:
                    vals.append(-numerator*pow(denominator,-1,p)%p)
                elif numerator == 0:
                    vals.append(RNG.randrange(p))
                else:
                    break
            if len(vals) == n:
                vectors.append(vals)
        for x in vectors:
            check_vector(p,q,x)
        # Explicit source and transform bind to the supplied root, not a hidden one.
        x = [int(i==1) for i in range(n)]
        other = pow(q,3,p)
        assert dense_fourier(p,q,x) != dense_fourier(p,other,x)
        check_vector(p,other,x)
        COUNTS['root_binding_pairs'] += 1
    # Exhaustive coefficient operators, both primitive roots, all source anchors.
    for q in (2,3):
        for coeff in product(range(5),repeat=4):
            if not any(coeff):
                continue
            a,b,c,d = coeff
            diag = [(a+b*pow(q,i,5))%5 for i in range(4)]
            edge = [(c+d*pow(q,i,5))%5 for i in range(4)]
            target_diag = [(a+c*pow(q,(-k)%4,5))%5 for k in range(4)]
            target_edge = [(b+d*pow(q,(-k-1)%4,5))%5 for k in range(4)]
            matrix = [[(diag[i] if i==j else 0)+(edge[i] if (i+1)%4==j else 0) for j in range(4)] for i in range(4)]
            _,pivots = rref(matrix,5)
            assert len(pivots) >= 3
            for j in range(4):
                witness = [int(i==j) for i in range(4)]
                rhs = [sum(u*v for u,v in zip(row,witness))%5 for row in matrix]
                transformed = dense_fourier(5,q,witness)
                assert dense_fourier(5,q,rhs) == [(target_diag[k]*transformed[k]+target_edge[k]*transformed[(k+1)%4])%5 for k in range(4)]
                COUNTS['similarity_basis_checks'] += 1
                arithmetic = Arithmetic(5)
                particular,h = bidiagonal(arithmetic,diag,edge,rhs)
                assert [sum(u*v for u,v in zip(row,particular))%5 for row in matrix] == rhs
                assert (h is not None) == (len(pivots)==3)
                if h is not None:
                    assert any(h)
                    assert all(sum(u*v for u,v in zip(row,h))%5 == 0 for row in matrix)
                assert arithmetic.inversions <= (1 if h is not None else 2)
                COUNTS['cycle_systems'] += 1
    # Exhaustive root-map fibers and exact raw/candidate tails, not random evidence.
    for p,n in ((5,4),(17,4),(17,8),(17,16),(41,8),(97,32),(257,256)):
        fibers = Counter(pow(a,(p-1)//n,p) for a in range(1,p))
        assert len(fibers)==n and set(fibers.values())=={(p-1)//n}
        successful = [a for a in range(1,p) if pow(pow(a,(p-1)//n,p),n//2,p)!=1]
        assert len(successful)==(p-1)//2
        probability = Fraction(len(successful),2**p.bit_length())
        assert probability >= Fraction(1,4)
        assert p.bit_length()/probability <= 4*p.bit_length()
        for limit in (0,1,2,5):
            raw_failure = (1-probability)**limit
            assert raw_failure <= Fraction(3,4)**limit
            assert Fraction(1,2)**limit == Fraction(2**limit,4**limit)
        COUNTS['root_population_cases'] += 1
    assert sampling(17,8,[0,31,1,3],cap_draws=4)==('FOUND',9,4,2)
    assert sampling(17,8,[0,31,1,3],cap_candidates=1)==('ROOT_LIMIT',None,3,1)
    assert sampling(17,8,[0,31,1,3],cap_draws=2)==('ROOT_LIMIT',None,2,0)
    assert sampling(17,8,[],cap_draws=0)==('ROOT_LIMIT',None,0,0)
    assert wire(17,{'status':'R'}) == b'R'
    COUNTS['root_limit_scripts'] = 5
    # Exact finite probability checks of the cap semantics at p=5,N=4.
    for limit in range(5):
        failures = sum(sampling(5,4,seq,cap_candidates=limit)[0]=='ROOT_LIMIT'
                       for seq in product(range(1,5),repeat=limit))
        assert Fraction(failures,4**limit)==Fraction(1,2)**limit
        COUNTS['exact_candidate_tail_checks'] += 1
    for draws in range(5):
        failures = sum(sampling(5,4,seq,cap_draws=draws)[0]=='ROOT_LIMIT'
                       for seq in product(range(8),repeat=draws))
        assert Fraction(failures,8**draws)==Fraction(3,4)**draws
        COUNTS['exact_raw_tail_checks'] += 1
        for candidates in range(4):
            failures = sum(sampling(5,4,seq,cap_candidates=candidates,cap_draws=draws)[0]=='ROOT_LIMIT'
                           for seq in product(range(8),repeat=draws))
            assert Fraction(failures,8**draws) <= Fraction(1,2)**candidates+Fraction(3,4)**draws
            COUNTS['combined_cap_union_checks'] += 1
    arithmetic = Arithmetic(17)
    assert arithmetic.invert_list([])==[] and arithmetic.inversions==0
    all_inverses = arithmetic.invert_list(list(range(1,17)))
    assert arithmetic.inversions==1
    assert all(i*v%17==1 for i,v in enumerate(all_inverses,1))
    COUNTS['batch_inverse_controls'] = 2
    for p in range(2,400):
        is_prime = all(p%d for d in range(2,isqrt(p)+1))
        try:
            tests = trial_prime(p)
            assert is_prime
            assert tests == (1 if p==2 else 1+len(range(3,isqrt(p)+1,2)))
        except ValueError:
            assert not is_prime
        COUNTS['prime_validation_cases'] += 1
    invalid = [(5,2,[]),(5,2,[0]),(5,2,[0]*2),(13,2,[0]*6),(17,2,[0]*3),
               (9,2,[0]*4),(2,1,[0]*4),(7,2,[0]*4),(True,2,[0]*4),
               (5,0,[0]*4),(5,1,[0]*4),(5,4,[0]*4),(5,5,[0]*4),
               (5,2,[0,0,0,5]),(5,2,[0,0,0,-1]),(5,2,[0,0,0,False]),
               (5,2,[0,0,0,0.0]),(5,2,(0,0,0,0)),(5,True,[0]*4)]
    for args in invalid:
        try:
            reconstruct(*args)
        except ValueError:
            COUNTS['malformed_cases'] += 1
        else:
            raise AssertionError(('unexpectedly accepted',args))
    # A family actually changes when the discovered primitive root changes.
    p,n,q = 17,8,2
    for _ in range(10000):
        a,b,c,d = [RNG.randrange(p) for _ in range(4)]
        x = [1]
        for i in range(n-1):
            denominator=(c+d*pow(q,i,p))%p
            if not denominator:
                break
            x.append(-(a+b*pow(q,i,p))*x[-1]*pow(denominator,-1,p)%p)
        if len(x)==n and len(rref(relation_matrix(p,pow(q,3,p),x),p)[1])==4:
            assert len(rref(relation_matrix(p,q,x),p)[1])<4
            WITNESSES['root_dependent_family']={'p':p,'N':n,'q_accept':q,'q_decline':pow(q,3,p),'x':x}
            break
    assert 'root_dependent_family' in WITNESSES
    output = {'status':'PASS','method':'fresh independent reconstruction plus dense oracles; no candidate/historical code executed',
              'counts':dict(COUNTS),'witnesses':WITNESSES}
    (HERE/'CONTROL_RESULTS.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))

if __name__ == '__main__':
    run()
