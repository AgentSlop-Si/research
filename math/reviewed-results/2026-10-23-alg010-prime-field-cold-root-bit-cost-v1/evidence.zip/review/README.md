# ALG-010 independent represented-prime-field review

Verdict: ACCEPT_SCOPED for the prime-field cold-root/bit-cost child only. ALG-010 remains TO RESEARCH at priority 42. The exact accepted scope and diagnostic clarification are in INDEPENDENT_REVIEW.md and VERDICT.json.

Reproduce fresh mathematical controls with `python -B independent_controls.py` from this directory while the sibling frozen candidate directory is present. No candidate or historical code is imported or executed. Candidate files are read only to verify bytes; the original source and exact live row are independently bound. Full output and family acceptance are compared with fresh dense oracles.

No arbitrary-input acceleration, novelty, practical-speed claim or whole-owner closure. Any-root DECLINE is relative to the returned root, not the union of all root-dependent families. Trial-division primality is paid. Uncapped root acquisition has no deterministic worst-case bound, and the frozen reference keeps diagnostic counters whose tariff must be charged.
