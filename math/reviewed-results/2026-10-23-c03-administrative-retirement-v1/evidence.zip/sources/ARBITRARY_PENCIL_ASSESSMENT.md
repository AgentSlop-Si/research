# Focused novelty comparison addendum

10 October 2026 UTC • Follow-up to the initial publication assessment

## Findings that change the assessment

1. The Phase21 factorization is not intrinsically a Hankel theorem. Its full universal factor and reciprocity package holds for arbitrary square coefficient matrices in the same diagonal-scaling pencils. A direct proof appears below. This narrows the possible original contribution to a specific explicit resultant formula and its recovery application; it does not support a claim of a new general elimination method. The initial report's rank 3 should therefore be read more cautiously: a potentially useful specialized theorem or note, with standalone publication strength still unestablished.

2. The exact valuation calculation is an instance of established Newton-polygon/resultant machinery. This does not show that the project's exact closed-form exponents have already been published. It does show why a search limited to “Hankel interpolation” would overstate the novelty gap.

3. The sharp endpoint minimax theorem still has a distinct, plausible contribution after checking the most relevant accessible citation chain. The bit-reversal rank-one block structure is old; the identifiable contribution is the universal independent-endpoint lower bound and the matching exact value N/4+1. The final 2008 Delvaux–Van Barel article has not been obtained in full, so the priority comparison remains incomplete rather than being declared cleared.

The initial report and its machine-readable ranking are preserved. No pending restricted-family Green construction has been promoted to accepted status in this addendum.

## A general diagonal-pencil lemma behind Phase21

This is a new assessment-level derivation, not a separately accepted review package or a historical novelty claim. The proof is included to make the comparison checkable.

Let A and B be arbitrary m-by-m matrices over a commutative ring, indexed from 0, and put D(w)=diag(1,w,...,w^(m-1)). Define

    P_0(a,w)=det(A-a D(w) A D(w)),
    P_1(a,w)=det(B-a w D(w) B D(w)),
    R(w)=Res_a(P_0,P_1),

where the resultant always uses the degree-m homogeneous Sylvester convention, including after specialization. Let

    D_total=m^2(2m-1),
    v=m(m-1)(4m+1)/6,
    b=m(m-1)(2m-1)/6.

Then the same identities hold:

    w^D_total R(1/w)=(-1)^(m^2) R(w),
    R(w)=w^v(w-1)^(m^2) U(w),
    w^(2b) U(1/w)=U(w),
    U(w)=w^b V(w+w^(-1)),   degree V<=b.

These are universal integral polynomial identities. No symmetry, Hankel condition or relation between A and B is needed. Setting A_ij=T_(i+j), B_ij=T_(i+j+1) recovers Phase21 with m=s+1.

### Proof of reciprocity

For e=0,1 and M=A,B, factor each entry of M_ij(1-a w^(-e-i-j)). Row and column scaling gives

    P_e(a,1/w)=(-a)^m w^(-E_e) P_e(1/a,w),
    E_e=m(e+m-1).

Reversing both degree-m polynomials in the homogeneous resultant contributes (-1)^(m^2). Homogeneity in their coefficients supplies exponent m(E_0+E_1)=D_total. This is the usual resultant transformation law.

### Proof of the collision factor

Set w=1+epsilon and a=1+epsilon t. Each matrix entry is divisible by epsilon, so both determinants are divisible by epsilon^m. Resultant homogeneity gives a factor epsilon^(2m^2), while the common affine variable substitution a=1+epsilon t scales the resultant by epsilon^(m^2). Thus R(1+epsilon) is divisible by epsilon^(m^2). This argument works without invertibility or genericity.

### Proof of the zero valuation

Work first with independent matrix-entry indeterminates over Q. The coefficient of a^j in P_e is a sum over j-element row and column index sets I,J, with terms

    (+/-) det M[I,J] det M[I^c,J^c]
          times w^(e*j+sum(I)+sum(J)).

The minimum exponent is j(j-1)+e*j, uniquely attained at I=J={0,...,j-1}. The associated product of complementary minors is generically nonzero. Therefore the Newton polygon has consecutive slopes e,e+2,...,e+2(m-1); the a-roots have the corresponding negative valuations.

The two slope sets have opposite parity. No pair has equal valuation, so the valuation of their difference is the smaller root valuation. The usual root-product formula for the resultant gives

    val_w R = D_total - sum_(i,j) max(2i,2j+1)
            = sum_(i,j) min(2i,2j+1)
            = m(m-1)(4m+1)/6 = v.

This proves generic exactness and universal divisibility. Because the original resultant has integral polynomial coefficients, the coefficient identities established over Q hold over Z and survive specialization to any commutative coefficient ring. The quotient after division by the monic universal factors remains integral.

### Quotient symmetry and a sharpness control

Divide the reciprocity identity by the universal factors. The remaining reciprocity grade is

    D_total-2v-m^2=2b.

The standard integral recurrence for w^k+w^(-k) expresses every invariant Laurent polynomial as a polynomial in w+w^(-1), giving V.

For A=B=I, there is a transparent special case:

    R(w)=product_(i,j)(w^(2j+1)-w^(2i)).

Its w-valuation is exactly v and its multiplicity at w=1 is exactly m^2 in characteristic zero. Up to sign, its reduced U is

    product_(l=0)^(m-1) [(w^(2l+1)-1)/(w-1)]^(2m-2l-1).

Thus the generic degree bound and both generic factor orders are sharp in the arbitrary-matrix family. This specialization is not an assertion that A=B=I comes from adjacent Hankel moments; the original Hankel-family sharpness at w=0 continues to rely on the accepted Phase21 proof. No generic-exact claim at w=1 for that narrower family is needed here.

Six fresh symbolic fixed-degree Sylvester controls for arbitrary integer matrix pairs at m=1,2,3 confirm the universal factors and both reciprocity identities, including singular coefficient-matrix draws. The diagonal exponent/multiplicity formulas were checked through m=8. These are small corroborating controls, not a replacement for the preceding proof. The newly written check_general_pencils.py imports installed SymPy only and imports or executes none of the submitted research code. Results are recorded in GENERAL_PENCIL_CONTROLS.json.

## What the primary literature already supplies

Sturmfels's *On the Newton Polytope of the Resultant* describes generic extreme terms and general initial forms through coherent mixed subdivisions (Theorems 2.1 and 4.1). This is the appropriate general framework for degree/valuation behavior of an eliminant under monomial coefficient deformations. The present matrix-minor calculation supplies the particular coefficient weights; the resultant valuation step is not a new mechanism. [Original paper](https://www.maths.tcd.ie/EMIS/journals/JACO/Volume3_2/m4496732732u7744.fulltext.pdf)

Nart's *Local computation of differents and discriminants*, Section 3, explicitly builds resultant valuations from Newton-polygon side contributions, with the basic contribution min(EH',E'H). When slopes do not coincide, the root-difference valuation is determined at this first level; coincident slopes require further refinement. His computational algorithm has local-field assumptions that should not be silently transferred to Q(matrix entries)((w)); the elementary unequal-valuation rule used above is independent of that algorithm's finite-residue-field setting. [Original paper](https://arxiv.org/pdf/1205.1340)

Uteshev–Baravy Theorem 6.2 treats resultant recovery through Hankel determinants built from sampled rational functions. Grigoriev–Singer–Karpinski treat sparse rational interpolation with unknown exponent bounds. Neither inspected theorem states the project's adjacent multiplicative-pencil formula. These are application-level neighbors, while Sturmfels/Newton-polygon theory is the closer proof-level comparison. [Uteshev–Baravy](https://arxiv.org/html/1603.08752), [Grigoriev–Singer–Karpinski](https://archive.mpim-bonn.mpg.de/id/eprint/2068/1/preprint_1990_10.pdf)

**Revised publication judgment.** The exact formula may be original, but the proof is a short specialization of standard determinant, valuation and reciprocal-polynomial facts. Its all-s universality and useful sample compression make it worth preserving. The case for a substantial standalone paper should come from a broader classification, a genuinely stronger recovery theorem, or a demonstrable algorithmic improvement beyond a constant-factor reduction in an O(s^3) interpolation degree. Correctness, novelty of the printed formula and publication significance remain separate questions.

## Focused comparison for the dyadic endpoint theorem

The target claim is

    min_(rho,sigma) q(P_rho F_(2^m) P_sigma^T)=2^(m-2)+1, m>=3.

The most important potential prior-art overlap is the upper construction, not the exact lower bound.

| Primary source | Actual result inspected | Relationship to the claimed minimax theorem |
|---|---|---|
| Delvaux–Van Barel, official TW470 preprint, Lemma 8 and Sections 3–4 | Double digit reversal gives simultaneous rank-one block grids at all prime-power levels; these support Fourier submatrix and FFT descriptions | Bit reversal and its rank-one hierarchy must be credited. The exact cut recurrence can plausibly be presented as a refinement/corollary of this established structure. It is not evidence that the ordering itself is new. |
| Delvaux–Van Barel, same preprint, Theorem 10 | A minimum transformed-support/Hamming-number statement for an individual vector with bounded support | This controls existence of a nonzero null vector, not the dimension of a simultaneous support subspace or the maximum complementary-cut rank over every endpoint ordering. It is not the same invariant. |
| Osgood–Siripuram–Wu, Theorem 4 and Theorem 9 | Prime-power universal sampling sets are characterized by balanced residue-class counts; associated additive support uncertainty | Full row-subset spark and one-vector support constraints do not directly evaluate this all-order minimax invariant. |
| Alexeev–Cahill–Mixon, Full Spark Frames, Theorem 9 | A selected-row prime-power Fourier submatrix is full spark exactly when its row indices are uniformly distributed over divisors | Again a precise full-spark characterization, not a lower bound for every rectangular cut under two arbitrary permutations. |
| Barnett, contiguous Fourier submatrices | Exponential condition-number lower bounds for contiguous rectangular Fourier blocks | Numerical near-rank deficiency is a different question from exact algebraic rank and arbitrary endpoint permutations. |

Primary links: [Delvaux–Van Barel preprint](https://www.cs.kuleuven.be/publicaties/rapporten/tw/TW470.pdf), [Osgood–Siripuram–Wu](https://arxiv.org/html/1204.0992), [Alexeev–Cahill–Mixon](https://arxiv.org/html/1110.3548), [Barnett](https://arxiv.org/html/2004.09643).

### Why the lower-bound delta is concrete

The basic first-moment bound for a (2L-1)-by-(2L+1) submatrix of F_(4L) yields only rank at least L. The project proves rank at least L+1 for every such submatrix at dyadic size. It does so by bounding the dimension d of vectors simultaneously supported on H and Fourier-supported on I, where |H|=|I|=2L+1, through a second moment of the time-frequency projection.

The arithmetic input is that an odd-size subset of a dyadic cyclic group has no nontrivial translation stabilizer. This forces every nonzero-shift autocorrelation below |H| and makes the second-moment bound strictly smaller than L+1. A universal lower bound then matches the bit-reversal upper value. That exact strengthening and sharp minimax match are the meaningful potential contribution.

The second-moment strategy itself belongs to established time-frequency concentration and uncertainty methods; a claim of inventing projection-trace uncertainty would be inappropriate. The focused search did not identify the exact N/4+1 theorem in the inspected sources. That is a bounded comparison, not a priority proof.

### Access and comparison boundary

The official institutional record for the final 2008 article was located at [KU Leuven](https://lirias.kuleuven.be/1537109). It links only to the publisher DOI for full text. The publisher abstract/metadata were accessible in search results, but direct full-article and PDF requests returned fetch errors. Consequently, the 23-page official 2006 preprint was compared in full relevant sections, while the 19-page final 2008 typeset article was not compared. No paywall or access restriction was bypassed.

The final-version comparison remains the clearest unresolved priority task for row 2. Obtaining a legitimate copy already held by the user or accessible through an authorized library would close that specific gap. No external document request or author contact has been sent.

## Current disposition

- Preserve the endpoint theorem as a high-priority candidate, emphasizing its sharp universal lower bound and exact minimax value.
- Reframe the resultant theorem as an explicit diagonal-pencil factorization with a sparse-recovery application. Keep its historical originality provisional and its standalone significance modest until the remaining contribution is sharpened.
- Do not alter the accepted theorem statements, proof seals or pending-review statuses based solely on this novelty analysis.
