#!/usr/bin/env python3
"""Reconstruct the complete logical certificate tree without duplicate archive objects."""
import argparse,json,shutil
from pathlib import Path
from verify import ROOT,check,verify

def materialize(destination,root=ROOT,require_seal=True):
 verify(root,require_seal);destination=destination.resolve();check(not destination.exists(),'Destination must not exist')
 check(not destination.is_relative_to(root),'Choose a destination outside this immutable release')
 data=json.loads((root/'SOURCES.json').read_text());destination.mkdir(parents=True)
 for name,item in data['files'].items():
  target=destination/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'objects'/item['sha256'],target)
 return {'status':'PASS','logical_files':len(data['files']),'destination':str(destination),'scientific_sources_unchanged':True,'locator_projections_documented_in':'SOURCES.json'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('destination',type=Path);a=p.parse_args();print(json.dumps(materialize(a.destination),indent=2))
