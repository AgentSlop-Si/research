#!/usr/bin/env python3
"""Explicit run-only adapter for historical original-byte inventory checks.

No stored scientific source is edited. Only file SHA-256 and file-size calls are
adapted. For a disclosed operational locator projection, return its already
verified ORIGINAL identity after checking the CURRENT public bytes. Other files
retain ordinary SHA-256/size semantics. This does not reconstruct private locators.
The receipt distinguishes original identities from actual public-file hashes.
"""
import ast,argparse,hashlib,json,os,runpy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()

def execute(script,arguments,receipt=None):
 data=json.loads((ROOT/'SOURCES.json').read_text());projections={}
 for name,item in data['files'].items():
  if 'operational_locator_projection'in item:
   value=(item['original_sha256'],item['original_bytes'],item['bytes'])
   if item['sha256']in projections:assert projections[item['sha256']]==value
   projections[item['sha256']]=value
 observed={};changes=[]
 def identity(path):
  b=Path(path).read_bytes();h=H(b)
  if h in projections:
   old,nold,n=projections[h];assert len(b)==n
   observed[h]={'public_sha256':h,'public_bytes':n,'original_sha256':old,'original_bytes':nold}
   return old,nold
  return h,len(b)
 def source_digest(path):return identity(path)[0]
 def source_size(path):return identity(path)[1]
 class Adapter(ast.NodeTransformer):
  def visit_Call(self,node):
   # hashlib.sha256(path.read_bytes()).hexdigest(), including imported aliases.
   if isinstance(node.func,ast.Attribute)and node.func.attr=='hexdigest'and not node.args:
    hashed=node.func.value
    if isinstance(hashed,ast.Call)and len(hashed.args)==1:
     fn=hashed.func
     if (isinstance(fn,ast.Name)and fn.id in ('sha256','H'))or(isinstance(fn,ast.Attribute)and fn.attr=='sha256'):
      arg=hashed.args[0]
      if isinstance(arg,ast.Call)and isinstance(arg.func,ast.Attribute)and arg.func.attr=='read_bytes'and not arg.args:
       changes.append({'line':node.lineno,'operation':'file_sha256_to_disclosed_original_identity'})
       return ast.copy_location(ast.Call(func=ast.Name(id='_source_digest',ctx=ast.Load()),args=[arg.func.value],keywords=[]),node)
   return self.generic_visit(node)
  def visit_Attribute(self,node):
   if node.attr=='st_size'and isinstance(node.value,ast.Call)and isinstance(node.value.func,ast.Attribute)and node.value.func.attr=='stat'and not node.value.args:
    changes.append({'line':node.lineno,'operation':'file_size_to_disclosed_original_identity'})
    return ast.copy_location(ast.Call(func=ast.Name(id='_source_size',ctx=ast.Load()),args=[node.value.func.value],keywords=[]),node)
   return self.generic_visit(node)
 script=script.resolve();raw=script.read_bytes();tree=ast.parse(raw,filename=str(script));tree=Adapter().visit(tree);ast.fix_missing_locations(tree)
 check_original=any(x['sha256']==H(raw)and x['sha256']==x['original_sha256']for x in data['files'].values())
 assert check_original,'The executed program must be an unchanged frozen source'
 sys.path.insert(0,str(script.parent));sys.argv=[str(script),*arguments]
 namespace={'__name__':'__main__','__file__':str(script),'__package__':None,'_source_digest':source_digest,'_source_size':source_size}
 exec(compile(tree,str(script),'exec'),namespace)
 result={'status':'PASS','source_sha256':H(raw),'adapter_scope':'Only operational file SHA-256 and size checks; no scientific expression or stored source edited.','syntactic_substitutions':changes,'projected_original_identities_used':list(observed.values())}
 if receipt:receipt.write_text(json.dumps(result,indent=2)+'\n')
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--receipt',type=Path);p.add_argument('script',type=Path);p.add_argument('arguments',nargs=argparse.REMAINDER);a=p.parse_args();execute(a.script,a.arguments,a.receipt)
