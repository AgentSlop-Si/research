#!/usr/bin/env python3
"""Fresh, capped, offline replay of the independently reviewed certificate chain."""
import argparse,concurrent.futures,hashlib,json,os,resource,subprocess,sys,tempfile,time
from pathlib import Path
from verify import ROOT,check,verify
from materialize import materialize
H=lambda b:hashlib.sha256(b).hexdigest()
CPU_SECONDS=1200;WALL_SECONDS=1800;MEMORY_BYTES=4*1024**3
TIMING_FIELDS={'seconds','elapsed_seconds','time_seconds','total_seconds'}

def jobs_for(group,d):
 J=[]
 def add(args,outputs=(),portable=False):J.append((args,list(outputs),portable))
 if group=='negative_chirp_cutoff_review_20261020':
  add(['rebuild_anchor.py'],['negative_anchor_rebuild.json','positive_anchor_control.json']);add(['adversarial_controls.py'],['adversarial_results.json']);add(['compare_frozen_data.py'],['frozen_data_comparison.json'])
 elif group=='negative_chirp_exception_review_20261020':
  for s,outs in [('recheck_frozen_inputs.py',['BOUND_FROZEN_INPUT_CHECK.json','ROW_FROZEN_INPUT_CHECK.json']),('recheck_block_obstructions.py',['REVIEWER_BLOCK_OBSTRUCTIONS.json']),('recheck_graph_coverage.py',['REVIEWER_GRAPH_COVERAGE.json']),('recheck_empty_pairs.py',['REVIEWER_EMPTY_PAIR_ELIMINANTS.json']),('check_author_row_witnesses.py',['REVIEWER_AUTHOR_ROW_WITNESSES.json']),('check_author_row_norms.py',['REVIEWER_AUTHOR_ROW_NORMS.json']),('recheck_small_bound_recipes.py',['REVIEWER_SMALL_BOUND_RECIPES.json']),('recheck_orbits.py',['REVIEWER_PAIR_ORBITS.json','REVIEWER_CANDIDATE_COUNT.json']),('recheck_symbolic_controls.py',['REVIEWER_SYMBOLIC_CONTROLS.json'])]:add([s],outs)
 elif group=='negative_chirp_rank_pilot_review_20261020':
  add(['check_pair7.py'],['REVIEWER_CORE.json']);add(['check_norms.py'],['REVIEWER_NORM_CERTIFICATES.json']);add(['check_orbit_and_mutations.py'],['REVIEWER_ORBIT_AND_MUTATIONS.json'])
 elif group=='negative_chirp_rank_cases_review_20261020':
  add(['review_dependencies.py'],['FROZEN_INPUT_AND_SYMMETRY_CHECK.json'])
  add(['review_six_branches.py'],[p.name for p in d.glob('REBUILD_*.json')]+[p.name for p in d.glob('NORMS_*.json')]);add(['reconcile_exact_outputs.py'],['RECONCILED_EXACT_NORMS.json']);add(['review_local_nonsingularity.py'],['LOCAL_NONSINGULARITY.json']);add(['review_controls.py'],['REVIEWER_CONTROLS.json'])
 elif group=='negative_chirp_rank_next_review_20261020':
  add(['rebuild_core.py'],['REVIEWER_CORE.json']);add(['check_norms.py'],[p.name for p in d.glob('REVIEWER_NORMS_*.json')]+['REVIEWER_NORM_SUMMARY.json']);add(['compare_author_norm_data.py'],['AUTHOR_NORM_DATA_COMPARISON.json']);add(['check_controls_and_orbits.py'],['REVIEWER_CONTROLS_AND_ORBITS.json'])
 elif group=='negative_chirp_rank_batch_three_review_20261020':
  add(['check_dependencies_and_orbits.py'],['DEPENDENCIES_AND_ORBITS.json'],True);add(['rebuild_independent.py'],['INDEPENDENT_ALGEBRA.json']);add(['boundary_and_mutation_controls.py'],['BOUNDARY_AND_MUTATION_CONTROLS.json'])
 elif group in ['negative_chirp_rank_batch_four_review_20261020','negative_chirp_rank_batch_five_review_20261020','negative_chirp_rank_batch_six_fresh_review_20261020','negative_chirp_rank_batch7_review_20261020','negative_chirp_rank_batch_eight_review_20261020']:
  if 'four_'in group:cases=[(f'{i:03d}',[str(i)])for i in (10,41,43)]
  elif 'five_'in group:cases=[('045_B0',['45','0']),('045_B1',['45','1']),('055',['55']),('057_B0',['57','0']),('057_B1',['57','1'])]
  elif 'six_'in group:cases=json.loads((d/'REVIEW_CASES.json').read_text())
  elif 'batch7_'in group:cases=[('080_B0',['80','0']),('080_B1',['80','1']),('083',['83']),('084_B0',['84','0']),('084_B1',['84','1'])]
  else:cases=[('086',['86']),('087_B0',['87','0']),('087_B1',['87','1']),('090',['90'])]
  add(['check_dependencies_and_orbits.py'],['DEPENDENCIES_AND_ORBITS.json'],True)
  for tag,args in cases:
   add(['rebuild_original_algebra.py',*args],['REBUILT_'+tag+'.json'])
   if 'four_'in group:add(['check_full_sylvester.py',*args],['DIRECT_SYLVESTER_'+tag+'.json'])
   add(['check_integer_wholeproof.py',tag],['INTEGER_SYLVESTER_'+tag+'.json','INTEGER_NORMS_'+tag+'.json'])
  for script,out in [('check_local_nonsingularity.py','LOCAL_NONSINGULARITY.json'),('check_boundary_controls.py','BOUNDARY_CONTROLS.json'),('check_bezout_encoding.py','BEZOUT_ENCODING_CONTROLS.json'),('check_integer_engine.py','INTEGER_ENGINE_CONTROLS.json'),('check_fresh_boundaries.py','FRESH_BOUNDARY_CONTROLS.json'),('check_projective_covariance.py','PROJECTIVE_COVARIANCE_CONTROLS.json'),('check_projective_model.py','PROJECTIVE_MODEL_CONTROLS.json'),('check_zero_witness.py','ZERO_WITNESS_070_B1_W0.json'),('compare_frozen_candidate.py','FROZEN_COEFFICIENT_RECONCILIATION.json'),('compare_local_checks.py','LOCAL_COEFFICIENT_RECONCILIATION.json')]:
   if (d/script).exists():add([script],[out])
 elif group=='negative_chirp_rank_batch_nine_review_20261020':
  add(['check_frozen_sources.py'],['FROZEN_SOURCE_CHECK.json'])
  for idx,branch,wi,name in json.loads((d/'REVIEW_CASES.json').read_text()):
   rows=json.loads((d/'frozen_candidate'/name).read_text())['minor_rows'];tag=f'{idx:03d}'+(''if branch is None else f'_B{branch}')+f'_W{wi}'
   add(['reviewer_core.py',str(idx),'none'if branch is None else str(branch),str(wi),json.dumps(rows)],['REBUILT_'+tag+'.json']);add(['check_arithmetic.py',tag],['INTEGER_SYLVESTER_'+tag+'.json','INTEGER_NORMS_'+tag+'.json'])
  for script,out in [('check_local_guards.py','LOCAL_GUARDS.json'),('compare_frozen.py','FROZEN_COEFFICIENT_RECONCILIATION.json'),('compare_local.py','LOCAL_COEFFICIENT_RECONCILIATION.json'),('check_fresh_controls.py','FRESH_CONTROLS.json')]:add([script],[out])
  add(['check_dependencies_orbits.py','--local-only'],['ORBITS.json'])
 elif group=='negative_chirp_original_fusion_20261020':
  add(['audit_fusion.py','--require-complete'],['DEPENDENCY_LEDGER.json','PAIR_COVERAGE.json','LEAF_GATE.json','FUSION_AUDIT.json'],True);add(['exact_controls.py'],['EXACT_CONTROLS.json'])
 else:raise ValueError('Unknown replay group: '+group)
 return J

def norm(v,fields):
 if isinstance(v,dict):return {k:(Path(x).name if k=='root'and isinstance(x,str)else norm(x,fields))for k,x in v.items()if k not in fields}
 if isinstance(v,list):return [norm(x,fields)for x in v]
 return v

def equal(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
 return a==b

def limit():
 resource.setrlimit(resource.RLIMIT_CPU,(CPU_SECONDS,CPU_SECONDS));resource.setrlimit(resource.RLIMIT_AS,(MEMORY_BYTES,MEMORY_BYTES));resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def run_group(group,require_seal):
 result=[];start=time.monotonic()
 with tempfile.TemporaryDirectory(prefix='chirp-certificate-replay-')as tmp:
  base=Path(tmp)/'source';materialize(base,require_seal=require_seal);d=base/group
  for args,outputs,portable in jobs_for(group,d):
   expected={n:(d/n).read_bytes()for n in outputs}
   for n in outputs:(d/n).unlink()
   adapter_receipt=Path(tmp)/'adapter.json'
   command=[sys.executable,'-B']+([str(ROOT/'portable_check.py'),'--receipt',str(adapter_receipt),str(d/args[0]),*args[1:]]if portable else args)
   t=time.monotonic();p=subprocess.run(command,cwd=d,capture_output=True,env={**os.environ,'PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1','PYTHONOPTIMIZE':''},timeout=WALL_SECONDS,preexec_fn=limit)
   check(p.returncode==0,group+' '+str(args)+' failed: '+p.stderr.decode(errors='replace')[-3500:]);compared=[]
   for name,b in expected.items():
    actual=(d/name).read_bytes();mode='byte_identical'
    if actual!=b:
     check(equal(norm(json.loads(actual),TIMING_FIELDS),norm(json.loads(b),TIMING_FIELDS)),group+' non-operational output mismatch: '+name)
     mode='all_fields_identical_except_measured_timings_and_recorded_root_locator'
    compared.append({'file':name,'comparison':mode,'expected_sha256':H(b),'replayed_sha256':H(actual),'bytes_after_explicit_operational_rebinding_sha256':H(b)})
    # Restore only after the new computation matches every mathematical field.
    # This keeps subsequent SHA-bound checks honest about the frozen inputs used.
    (d/name).write_bytes(b)
   rec={'command':args,'status':'PASS','elapsed_seconds':round(time.monotonic()-t,3),'stdout_sha256':H(p.stdout),'stderr_sha256':H(p.stderr),'outputs':compared}
   if portable:rec['explicit_inventory_projection_adapter']=json.loads(adapter_receipt.read_text())
   result.append(rec);print(group+' '+args[0]+' PASS',file=sys.stderr,flush=True)
 return {'group':group,'status':'PASS','elapsed_seconds':round(time.monotonic()-start,3),'commands':result}

def run(groups=None,jobs=2,require_seal=True):
 import sympy
 check(__debug__ and sys.version_info[:2]==(3,12)and sympy.__version__=='1.14.0','Requires Python 3.12, SymPy 1.14.0 and assertions enabled')
 check(1<=jobs<=3,'Use one to three concurrent groups');initial=verify(require_seal=require_seal);start=time.monotonic()
 if groups is None:groups=[p['directory']for p in json.loads((ROOT/'SOURCES.json').read_text())['packages']if 'review'in p['directory']and 'whole_theorem'not in p['directory']]
 with concurrent.futures.ThreadPoolExecutor(max_workers=jobs)as pool:results=list(pool.map(lambda g:run_group(g,require_seal),groups))
 check(verify(require_seal=require_seal)==initial,'Archive changed during replay')
 return {'status':'PASS','execution':'New independent replay, not historical receipts','fresh_directory_per_group':True,'scientific_program_bytes_unchanged':True,'frozen_inputs_restored_only_after_full_mathematical_comparison':True,'operational_exceptions':sorted(TIMING_FIELDS)+['root locator'],'limits':{'parallel_groups':jobs,'wall_seconds_per_command':WALL_SECONDS,'cpu_seconds_per_command':CPU_SECONDS,'address_space_bytes_per_command':MEMORY_BYTES},'python':sys.version.split()[0],'sympy':sympy.__version__,'group_count':len(results),'command_count':sum(len(r['commands'])for r in results),'elapsed_seconds':round(time.monotonic()-start,3),'groups':results}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--groups',nargs='+');p.add_argument('--jobs',type=int,default=2);p.add_argument('--output',type=Path,required=True);a=p.parse_args();check(not a.output.resolve().is_relative_to(ROOT),'Receipt must be outside immutable release');result=run(a.groups,a.jobs);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='groups'},indent=2))
