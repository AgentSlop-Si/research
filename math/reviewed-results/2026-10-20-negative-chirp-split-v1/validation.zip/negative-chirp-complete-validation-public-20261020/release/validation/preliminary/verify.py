#!/usr/bin/env python3
"""Verify public bytes, original source membership and disclosed locator projections."""
import argparse,hashlib,json,sys,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def check(ok,msg):
 if not ok:raise ValueError(msg)
def safe(name):
 p=PurePosixPath(name);check(not p.is_absolute() and '..'not in p.parts and str(p)==name and '\\'not in name,'Unsafe path: '+name);return p

def verify_sources(root=ROOT):
 data=json.loads((root/'SOURCES.json').read_text());files=data['files'];objects=set();projected=[]
 for name,item in files.items():
  safe(name);h=item['sha256'];check(len(h)==64 and all(c in '0123456789abcdef'for c in h),'Invalid digest')
  b=(root/'objects'/h).read_bytes();check(H(b)==h and len(b)==item['bytes'],'Public object mismatch: '+name);objects.add(h)
  if 'operational_locator_projection'in item:
   check(Path(name).suffix in ('.json','.log','.md'),'Scientific code projection forbidden: '+name)
   check(item['sha256']!=item['original_sha256'],'Unnecessary projection: '+name);projected.append(name)
  else:check(item['sha256']==item['original_sha256']and item['bytes']==item['original_bytes'],'Undisclosed source change: '+name)
 for package in data['packages']:
  base=package['directory'];key=base+'/'+package['manifest'];entry=files[key]
  check(entry['sha256']==package['manifest_sha256']==entry['original_sha256'],'Original manifest altered')
  manifest=json.loads((root/'objects'/entry['sha256']).read_text());members=manifest.get('files',manifest.get('payloads'))
  check(len(members)==package['frozen_payload_count'],'Payload count mismatch')
  seen=set()
  for item in members:
   rel=item['path'];safe(rel);check(rel not in seen,'Repeated original member');seen.add(rel)
   actual=files[base+'/'+rel];check(actual['original_sha256']==item['sha256']and actual['original_bytes']==item['bytes'],'Original membership mismatch: '+base+'/'+rel)
 actual_objects={p.name for p in (root/'objects').iterdir()if p.is_file()};check(objects==actual_objects,'Unexpected or missing objects')
 return {'status':'PASS','package_count':len(data['packages']),'logical_file_count':len(files),'unique_object_count':len(objects),'disclosed_operational_locator_projections':projected,'all_original_manifest_members_accounted_for':True,'scientific_code_and_algebra_unchanged':True}

def verify(root=ROOT,require_seal=True):
 result=verify_sources(root)
 if require_seal:
  seal=json.loads((root/'SEAL.json').read_text());mb=(root/'MANIFEST.json').read_bytes();check(H(mb)==seal['manifest_sha256'],'Public manifest hash mismatch')
  manifest=json.loads(mb);names=set()
  for item in manifest['files']:
   name=item['path'];safe(name);check(name not in names,'Duplicate public member');names.add(name);p=root/name
   check(p.is_file()and not p.is_symlink(),'Missing or linked public member: '+name);b=p.read_bytes();check(H(b)==item['sha256']and len(b)==item['bytes'],'Release-byte mismatch: '+name)
  actual={p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file()};check(actual==names|{'MANIFEST.json','SEAL.json'},'Unexpected public files')
  result['manifest_sha256']=seal['manifest_sha256'];result['release_seal_verified']=True
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--sources-only',action='store_true');a=p.parse_args();print(json.dumps(verify(require_seal=not a.sources_only),indent=2))
