# Negative chirp validation companion

This is a small evidence companion, not a replacement for the runnable complete certificate archive. It includes exact public copies of the narrow theorem, independent review, scope, inventories, full command evidence and packaging validation, plus the detached final archive audit. It deliberately omits the large content-addressed scientific objects. For verification, reconstruction and a new calculation replay, obtain negative-chirp-complete-certificates-public-20261020.zip and use its top-level README.

The main archive SHA-256 and size are recorded in MAIN_ARCHIVE.json. Everything under release/ is byte-identical to the corresponding member of that main archive. Its MANIFEST.json and SEAL.json describe the main archive, not this reduced companion. COMPANION_MANIFEST.json inventories this companion.

The scope is only the original eligible negative-chirp family. Validation evidence distinguishes 109 observed post-comparison leaf completions on unchanged preliminary inputs, 25 durably replayed repaired leaf commands, and six durably replayed fusion/whole-review commands. The preliminary orchestration failed for a missing copied manifest locator and is not represented as an overall PASS. Six declared exact-byte aliases provide those locators without scientific edits.
