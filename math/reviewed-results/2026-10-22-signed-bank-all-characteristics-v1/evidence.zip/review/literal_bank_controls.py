"""Fresh literal controls using only this review's new finite-field implementation."""
from independent_controls import Field
from pathlib import Path
import json

def run(N,p,mod):
 F=Field(p,mod);Q=F.Q;q=next(x for x in range(1,Q) if F.pow(x,N)==1 and all(F.pow(x,j)!=1 for j in range(1,N)))
 alpha=3;ainv=F.inv[alpha];delta=F.neg[F.pow(alpha,N)];ninv=F.inv[N%p]
 w=[(3*j+1)%Q for j in range(N)];results=[]
 def sm(xs):
  a=0
  for x in xs:a=F.add[a][x]
  return a
 for eps,de in [(1,1),(1,-1),(-1,1),(-1,-1)]:
  zeta=F.pow(q,eps*de);bank=[[0]*N for _ in range(N)];bad_direction=False
  for j in range(N):
   d=[F.sub(1,F.pow(q,(eps*de*j+de*i)%N)) for i in range(N)];i0=-eps*j%N
   for c in range(N):
    x=[int(i==c) for i in range(N)];v=[0]*N;v[(i0-eps)%N]=F.mul[F.neg[x[i0]]][ainv]
    for k in range(1,N):
     i=(i0-k*eps)%N;v[(i-eps)%N]=F.mul[F.sub(F.mul[d[i]][v[i]],x[i])][ainv]
    assert all(F.sub(F.mul[d[i]][v[i]],F.mul[alpha][v[(i-eps)%N]])==x[i] for i in range(N))
    # Wrong-direction schedule must fail at least one branch/RHS.
    vv=[0]*N;vv[(i0+eps)%N]=F.mul[F.neg[x[i0]]][ainv]
    for k in range(1,N):
     i=(i0+k*eps)%N;vv[(i+eps)%N]=F.mul[F.sub(F.mul[d[i]][vv[i]],x[i])][ainv]
    bad_direction |= any(F.sub(F.mul[d[i]][vv[i]],F.mul[alpha][vv[(i-eps)%N]])!=x[i] for i in range(N))
    for i in range(N):bank[i][c]=F.add[bank[i][c]][F.mul[F.mul[w[j]][ninv]][v[i]]]
  assert bad_direction
  h=[F.mul[sm(F.mul[w[j]][F.pow(zeta,j*l)] for j in range(N))][F.inv[F.mul[N%p][delta]]] for l in range(N)]
  ref=[[0]*N for _ in range(N)]
  for l in range(N):
   for r in range(N-l):
    gb=1
    for k in range(1,l+1):gb=F.mul[gb][F.mul[F.sub(1,F.pow(zeta,r+k))][F.inv[F.sub(1,F.pow(zeta,k))]]]
    z=F.mul[F.mul[h[l]][F.pow(alpha,r)]][gb]
    for c in range(N):
     i=(c+eps*r)%N;ref[i][c]=F.add[ref[i][c]][F.mul[z][F.pow(q,de*l*c)]]
  assert bank==ref
  missing_normalization_detected = any(F.mul[v][N%p]!=v for row in bank for v in row)
  if p!=2:assert missing_normalization_detected
  results.append({'epsilon':eps,'delta':de,'literal_matrix_entries_verified':N*N,'branch_rhs_solves_verified':N*N,'wrong_direction_rejected':bad_direction,'missing_1_over_N_detected':missing_normalization_detected})
 # Independently compare the literal negative Fourier matrix to Weyl chirp coefficients.
 hm=pow(4,-1,N);gm=F.mul[sm(F.pow(q,-j*j) for j in range(N))][ninv];fm=[[0]*N for _ in range(N)]
 for a in range(N):
  for b in range(N):
   z=F.mul[gm][F.pow(q,hm*(a+b)**2)]
   for c in range(N):fm[(a+c)%N][c]=F.add[fm[(a+c)%N][c]][F.mul[z][F.pow(q,b*c)]]
 assert all(fm[i][j]==F.pow(q,-i*j) for i in range(N) for j in range(N))
 assert any(fm[i][j]!=F.pow(q,i*j) for i in range(N) for j in range(N))
 return {'N':N,'p':p,'Q':Q,'q':q,'alpha':alpha,'orientation_checks':results,'negative_fourier_weyl_entries_verified':N*N,'wrong_fourier_sign_rejected':True}

if __name__=='__main__':
 out={'status':'PASS','fixtures':[run(31,2,[1,0,1,0,0,1]),run(7,29,[0,1])],'scope':'Original literal-bank identities and mutation controls; N=7 is a grammar control, not an instance of the N>=23 construction theorem.'}
 Path(__file__).with_name('LITERAL_BANK_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
