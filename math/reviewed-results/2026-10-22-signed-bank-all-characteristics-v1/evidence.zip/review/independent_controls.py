"""Fresh independent field controls; no historical program imports."""
from pathlib import Path
import json, random, hashlib

class Field:
 def __init__(self,p,mod):
  self.p=p; self.mod=mod; self.r=len(mod)-1; self.Q=p**self.r
  self.digits=[[a//p**j%p for j in range(self.r)] for a in range(self.Q)]
  self.add=[[sum(((x+y)%p)*p**j for j,(x,y) in enumerate(zip(self.digits[a],self.digits[b]))) for b in range(self.Q)] for a in range(self.Q)]
  self.neg=[sum((-x%p)*p**j for j,x in enumerate(self.digits[a])) for a in range(self.Q)]
  self.mul=[[self._mul(a,b) for b in range(self.Q)] for a in range(self.Q)]
  self.inv=[0]+[self.pow(a,self.Q-2) for a in range(1,self.Q)]
  assert all(self.mul[a][self.inv[a]]==1 for a in range(1,self.Q)), 'not a field'
 def _mul(self,a,b):
  c=[0]*(2*self.r-1)
  for i,x in enumerate(self.digits[a]):
   for j,y in enumerate(self.digits[b]): c[i+j]=(c[i+j]+x*y)%self.p
  for i in range(2*self.r-2,self.r-1,-1):
   z=c[i]
   for j in range(self.r+1): c[i-self.r+j]=(c[i-self.r+j]-z*self.mod[j])%self.p
  return sum(x*self.p**j for j,x in enumerate(c[:self.r]))
 def pow(self,a,n):
  if n<0:return self.pow(self.inv[a],-n)
  x=1
  while n:
   if n&1:x=self.mul[x][a]
   a=self.mul[a][a]; n//=2
  return x
 def sub(self,a,b):return self.add[a][self.neg[b]]

def rref(F,A):
 A=[row[:] for row in A]; nr=len(A); nc=len(A[0]) if nr else 0; piv=[]; k=0
 for c in range(nc):
  s=next((j for j in range(k,nr) if A[j][c]),None)
  if s is None:continue
  A[k],A[s]=A[s],A[k]; inv=F.inv[A[k][c]]; A[k]=[F.mul[v][inv] for v in A[k]]
  for j in range(nr):
   z=A[j][c]
   if j!=k and z:A[j]=[F.sub(v,F.mul[z][w]) for v,w in zip(A[j],A[k])]
  piv.append(c); k+=1
  if k==nr:break
 return A,piv

def null(F,A):
 R,p=rref(F,A); out=[]
 for c in range(len(A[0])):
  if c in p:continue
  v=[0]*len(A[0]);v[c]=1
  for j,k in enumerate(p):v[k]=F.neg[R[j][c]]
  out.append(v)
 return out

def trim(a):
 a=a[:]
 while a and not a[-1]:a.pop()
 return a

def rem(F,a,b):
 a=trim(a); b=trim(b)
 while len(a)>=len(b):
  z=F.mul[a[-1]][F.inv[b[-1]]]; k=len(a)-len(b)
  for j,v in enumerate(b):a[j+k]=F.sub(a[j+k],F.mul[z][v])
  a=trim(a)
 return a

def gcd(F,a,b):
 while b:a,b=b,rem(F,a,b)
 return [F.mul[v][F.inv[a[-1]]] for v in a] if a else []

def pd(F,a):return trim([F.mul[a[j]][j%F.p] for j in range(1,len(a))])
def dot(F,a,b):
 x=0
 for v,w in zip(a,b):x=F.add[x][F.mul[v][w]]
 return x

def go(N,p,mod):
 F=Field(p,mod); d=(N+10)//8;m=N-d; Q=F.Q
 q=next(x for x in range(1,Q) if F.pow(x,N)==1 and all(F.pow(x,j)!=1 for j in range(1,N)))
 qp=[F.pow(q,j) for j in range(N)]; h=pow(4,-1,N);e=pow(2,-1,N)
 def pw(j):return qp[j%N]
 den=[]
 for k in range(m+1):
  x=1
  for j in range(2,d):x=F.mul[x][F.sub(1,pw(j+k))]
  assert x;den.append(x)
 E=[]
 for j in range(3*d-6):E.append([F.mul[pw(h*k*k+e*j*k)][F.inv[den[k]]] for k in range(m+1)])
 for j in range(d-1):E.append([F.mul[pw(j*k)][F.inv[den[k]]] for k in range(m+1)])
 U=null(F,E); rank=len(rref(F,E)[1]);delta=[[int(j==i) for j in range(m+1)] for i in [0,1,m]]
 assert len(rref(F,E+delta)[1])==rank+3
 U0=null(F,E+[delta[0]])
 ug=[];u0g=[]
 for v in U:ug=gcd(F,ug,trim(v))
 for v in U0:u0g=gcd(F,u0g,trim(v))
 assert ug==[F.neg[1],1] and u0g==[0,F.neg[1],1]
 assert any(dot(F,v,[j%p for j in range(m+1)]) for v in U0)
 assert any(F.sub(F.neg[v[0]],v[1]) for v in U)
 def binom(r,l,z):
  if r+l>=N:return 0
  a=1;b=1
  for j in range(1,l+1):
   a=F.mul[a][F.sub(1,F.pow(z,r+j))];b=F.mul[b][F.sub(1,F.pow(z,j))]
  return F.mul[a][F.inv[b]]
 def G(eps,de,a,b):return binom(eps*a%N,de*b%N,pw(eps*de))
 def f(a,b):return pw(h*(a+b)**2)
 # Check actual rows directly, not only their envelope representation.
 nr=0
 for b in range(1,d-1):
  T=F.inv[G(-1,1,N-b,b)]
  for a in range(1,d-b):
   v=[F.mul[F.sub(f(a+k,b),F.mul[T][G(-1,1,a+k,b)])][F.inv[G(1,1,a+k,b)]] for k in range(m+1)]
   assert all(dot(F,v,u)==0 for u in U);nr+=1
 def remainders(g):
  return [rem(F,[0]*j+[1],g)+[0]*(m-len(rem(F,[0]*j+[1],g))) for j in range(N)]
 rng=random.Random(N*100+p);witness=None
 for attempt in range(1,1001):
  coeff=[rng.randrange(Q) for _ in U];g=[0]*(m+1)
  for c,v in zip(coeff,U):g=[F.add[a][F.mul[c][b]] for a,b in zip(g,v)]
  if not g[0] or not g[-1]:continue
  g=[F.mul[a][F.inv[g[-1]]] for a in g]
  if len(gcd(F,g,pd(F,g)))!=1:continue
  P=remainders(g);axis=[P[a]+[1]+P[-a%N] for a in range(N)]
  if len(rref(F,axis)[1])!=N:continue
  witness=(g,P,attempt);break
 assert witness is not None
 g,P,attempt=witness
 for b in range(N):
  M=[]
  for a in range(N):
   blocks=[]
   for eps,de,nodes in [(1,1,True),(-1,1,False),(1,-1,False),(-1,-1,True)]:
    z=G(eps,de,a,b)
    blocks += [F.mul[z][v] for v in P[eps*a%N]] if nodes else [z]
   M.append(blocks+[f(a,b)])
  _,piv=rref(F,M);assert 2*m+2 not in piv, (N,b)
 # The Gauss constant is nonzero, in all these small characteristics.
 minus=0;plus=0
 for j in range(N):minus=F.add[minus][pw(-j*j)];plus=F.add[plus][pw(j*j)]
 assert F.mul[minus][plus]==N%p
 return {'N':N,'p':p,'modulus_ascending':mod,'Q':Q,'q':q,'d':d,'m':m,'envelope_rank':rank,'kernel_dimension':len(U),'gcd_U':ug,'gcd_U0':u0g,'actual_recurrence_rows_checked':nr,'legal_polynomial':g,'sampling_attempt':attempt,'axis_rank':N,'physical_rows_checked':N,'gauss_product':F.mul[minus][plus],'guard_bound':d*(d+1)+2*m-1,'field_square_inequality':2*(d*(d+1)+2*m-1)<Q*Q}

if __name__=='__main__':
 records=[]
 for spec in [(31,2,[1,0,1,0,0,1]),(63,2,[1,1,0,0,0,0,1]),(31,5,[1,1,0,1]),(121,3,[1,2,0,0,0,1])]:
  r=go(*spec);records.append(r);print(json.dumps(r),flush=True)
 # Countercontrol: nonzero linear coefficient does not ensure squarefreeness.
 F=Field(2,[1,1,1]); bad=[1,1,1,1] # (t+1)^3, derivative t^2+1.
 assert bad[1] and len(gcd(F,bad,pd(F,bad)))>1
 out={'status':'PASS','fixtures':records,'nonzero_linear_coefficient_countercontrol':{'characteristic':2,'polynomial_ascending':bad,'gcd_with_derivative':gcd(F,bad,pd(F,bad))},'scope':'Fresh finite controls only; the uniform result rests on proof.'}
 Path(__file__).with_name('INDEPENDENT_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
