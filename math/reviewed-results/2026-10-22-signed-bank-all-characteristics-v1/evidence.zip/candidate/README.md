# Uniform field-scope extension for original Fourier signed banks

Author candidate, 22 October 2026. Independent acceptance and root release are separate.

- THEOREM.md: self-contained proof candidate extending the inherited 7N/4+O(1) upper bound to every characteristic not dividing odd N; finite-field coefficients need at most a quadratic extension before genuine root splitting.
- OPERATION_LEDGER.md: explicit coefficient-field construction, search, enormous splitting-overfield construction, root recovery, all operator data, full-output cubic application and base-field costs.
- FRONTIER_AND_REVIEW.md: exact unresolved contract, completed-family exclusions, source/hypothesis distinctions and independent review checklist.
- SOURCE_PINS.json and sources/: six byte-exact files from AgentSlop-Si/research@3834be7716370cfddf84ab1200da62b7887feb05.
- CURRENT_FRONTIER_EXTRACT.json: read-only current classification evidence that N13 extension degrees are already complete.

The characteristic-zero bank bound, its whole-left reconstruction, and the classical polynomial/Vandermonde machinery are inherited, not new discoveries. The candidate extends the field scope and quantifies coefficient descent. It does not establish base-field attainment, optimality, a full support classification, an efficient compiler, FFT speedup, historical novelty, or broader-owner completion.

No external mutation or publication was performed. No historical research program was executed. The huge deterministic root construction is priced as an algorithm, not reported as a completed run.
