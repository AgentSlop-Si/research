# Frontier, source coverage, and independent-review contract

22 October 2026. Candidate status only. No external mutation, table closure, publication, or parent-owner retirement is implied.

## Source-pinned frontier

Repository reference inspected: AgentSlop-Si/research commit 3834be7716370cfddf84ab1200da62b7887feb05. Six relevant mathematical source files were fetched at that exact commit and copied unchanged. SOURCE_PINS.json gives repository paths, verified Git blob SHA-1, byte counts, and SHA-256. All local source bytes match the advertised Git blobs, rather than merely carrying copied hash claims.

Current owner classification: CLASSIFICATION.json snapshot dated 22 October 2026, SHA-256 944adf53e5d26584aa506e3c753df0dd4d4214d5785fc9bbbd337a42d10ff34d. CURRENT_FRONTIER_EXTRACT.json preserves the exact four relevant rows and source identity. This is a read-only extraction, not a live table change or mathematical replay.

The current classification explicitly marks the original N=13, q=16, F53-extension degree question COMPLETE: B(F53)=18 and B(F_(53^a))=16 for every a>=2, with independently free cross singletons. It binds the accepted archive N13_magnetic_all_extension_degrees_PUBLIC_20261020.zip by SHA-256 7003528158be677215821ca050b3de4d59a77b8e882c756a31f7d7c49d80617d and THEOREM.md by SHA-256 7932142ec2eefc28b821ebfa436aa73ea694f190ed4951ebf59e26b57aa0da3f. Those archive bytes were not recovered or replayed for this candidate. Their current accepted status is inherited from the classification, not re-proved here.

Therefore neither an F_(53^7) sixteen-bank witness, the pinned repository's later degree-31 witness, nor another extension degree is a valid new task. The degree-31 report in sources/06_REPORT.md is historical evidence subordinate to the later completed degree classification. Its older statement that classification remains open is not adopted. The inherited raw degree-five recovery limitation remains unchanged.

The source frontier is stronger than fixed-N examples: sources/02_INDEPENDENT_REVIEW.md already accepts the all-odd-N>=23, characteristic-zero bound 2N-2floor((N+10)/8)+2, over a degree-m polynomial's splitting field, using (m,1,1,m) orientations. Its exact scope explicitly excludes positive-characteristic universality, base-field splitting, efficient preparation, and scalar FFT conclusions. Its positive-characteristic controls selected primes p>N and are corroboration, not the accepted universal statement.

sources/04_SIGNED_MAGNETIC_FUSION.md already has all-admissible-field original bank coefficients, support gates, linear-order lower bounds, and a coarse 4N-bank interpolation upper. These are not new results of this candidate. sources/03_WHOLE_LEFT_RANK_ENVELOPE.md contains the inherited whole-left completion mechanism. sources/05_REVIEW.md fixes the independently-free-cross-singleton interpretation and arbitrary-beta lower-bound bookkeeping; the current theorem is an upper bound, not a reuse or extension of its N13 numerical lower certificate.

## Precise unresolved contract selected

Can the already accepted uniform 7N/4+O(1) construction be proved in every characteristic not dividing odd N, with legal full-axis and full-sector reconstruction, and with finite-field coefficient selection and actual splitting-field costs made explicit?

The answer proposed in THEOREM.md is yes. The proof obtains generic separability from the existing joint sparse-functional exclusion, not from dimension heuristics or a false claim that every polynomial with a linear term is squarefree. It then bounds a nonzero combined guard by H=d(d+1)+2m-1 and uses F_(Q^2) for coefficient descent. This extends the accepted family’s field scope. It neither improves the bank constant nor invents a new restricted architecture.

The raw polynomial/recurrence mechanism is classical. No source or historical-priority claim says that positive-characteristic extension could not have been deduced earlier. This is a new-to-this-pinned-accepted-frontier scope extension, subject to independent review, not a worldwide novelty claim. No broad literature-clearance task was performed.

## Scientific dependence and operational restrictions

- The proof in THEOREM.md is self-contained for its new and inherited algebraic steps. Sources establish provenance and the already accepted frontier.
- No historical program was executed, imported, or compiled, and no historical witness was substituted for a new literal construction.
- The deterministic root construction in the ledger is a mathematical algorithm, not an actually executed gigantic computation.
- Newly authored exact controls are permissible as corroboration and should be labeled by author and scope. They do not replace the universal proof or establish an exhaustive finite census.
- The independent reviewer must retain its own evidence and verdict; same-author reasoning is not independent acceptance.
- No external mutation, publication, native table update, score/priority change, or broader owner closure is performed by this candidate.

## Independent review checklist

1. Confirm every source blob and the classification source pin. Distinguish current N13 completion from the older degree-31 source and preserve the raw degree-five limitation.
2. Verify the bank convention, Fourier sign, 1/N normalization, Weyl order S^aT^b, integer sign labels, phase q^(epsilon delta j), and legal guard 1-alpha^N-beta^N. Confirm characteristic-two signs mean inverse generator powers, not scalar sign distinctions.
3. Check all q-Gaussian product denominators and the all-field envelope identity. No division by 2,4,d,m, factorials, or characteristic-sensitive binomial coefficients is permitted in the field. Exponent inverses are modulo N only.
4. Recheck the sparse support {0,1,m} argument, exact shift orders, inclusive interval endpoints, degree bounds, and independence of c0,c1,cm. Check this is joint independence, not weaker separate nonvanishing.
5. Prove the exact fixed divisors over the algebraic closure. The derivative-at-1 contradiction uses N!=0; M^2 annihilates jD(q^j) even in characteristic two. No missing j=0 value may be assumed before recurrence propagation.
6. Audit the positive-characteristic repair: gcd(V1)=1; universal-polynomial irreducibility and primitivity; h1=-c0-c1 not identically zero; hence universal H'!=0 and irreducible H is separable. A linear coefficient by itself is insufficient for an arbitrary reducible polynomial.
7. Audit reciprocal reversal in characteristic two. lambda^2=1 still forces one fixed scalar lambda, and endpoint independence excludes its eigenspace. The illegal zero root is used only to witness a polynomial minor and never becomes a bank node.
8. Check the exact axis dependence identity, factor degrees, and all guard polynomials on the same monic affine space. No inference from reciprocal coprimality alone at a legal point is allowed.
9. Recheck the row-degree sum d(d+1), monic discriminant bound 2m-2, H, Q>=N+1, and Q^2>2H. Distinguish existence after coefficient extension from splitting in that same extension. Check deterministic and randomized search claims separately.
10. Confirm every positive, negative, and zero physical row is reconstructed in the original grammar. Cross singleton sectors remain effective. Same-sign ineffective banks can be omitted, so the count is an upper bound, not an unjustified exact allocation minimum.
11. Verify actual field construction, all failed candidates, root recovery, scalar extension, inversion costs, amplitudes, branch weights, operator data, all-output application, storage and addressing in OPERATION_LEDGER.md. Root-field degree may be huge; no free primitive-root, factorization, or fast transform oracle is allowed.
12. Independently check the beta=1 cyclic solve and exact warm count 2BN^2 multiplications and 2BN^2-BN-N additions, including input scaling, branch weights, per-bank accumulation and cross-bank accumulation. Verify coefficient preprocessing is separate and paid.
13. Falsify at least the characteristic-zero-only shortcut, an inseparable residual substitution, a repeated/zero support node, a missing axis condition, the Fourier sign or 1/N normalization, and an incorrect application recurrence direction where feasible. Controls are not universal proof substitutes.
14. State the verdict narrowly: uniform field-scope extension of the existing bound, with explicit expensive construction. No base-field attainment, exact minimum, full support classification, efficient root field, FFT win, historical novelty, or broader-owner closure follows.

## Suggested disposition after verification

If independently accepted, retain this as a bounded uniform field-scope result under the still-open signed-bank owners. Any source/table annotation should say precisely what field scope changed and that the bank constant is inherited. Publication and native record edits require separate root release after the independent verdict; this file supplies neither.
