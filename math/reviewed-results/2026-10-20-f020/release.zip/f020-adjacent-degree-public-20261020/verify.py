#!/usr/bin/env python3
"""Offline integrity, bounded current-control replay and adverse verification."""
from pathlib import Path, PurePosixPath
import argparse,copy,hashlib,io,json,math,os,re,shutil,stat,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parent
ANCHORS={'SCOPE.json': 'ba418d014a456799fb6b92f9d348da922807399491e59696191a4e1c03a265c0', 'REPLAY_CASES.json': '9b6fa931524dabb8870ca9f112303451eb886677151b251b4355322c385acd25', 'provenance/SOURCE_LEDGER.json': '1f10cbfa60f2245a61ccd9967efe02c64d6bdc329ddfee087aadc83a80f33f94', 'provenance/DEPENDENCY.json': '0c4ba172f5dcccd74170e71dd0c7f0e390b4533963033cf69e80ada2ca45c878', 'author/MANIFEST.json': 'b58aa5d90e5faf2fc3a85afbbe856fe244f819ffee9672248d89ad1a6cc183fc', 'author/REPORT.md': '18fcdfa5d1e88a44e09cbc130d2feb04129480d6f4dc0b84d624929f614195d4', 'independent-review/MANIFEST.json': '3ef43809ad247d951b0e34c1e9be5c013d68772d74cc45e6d2743a4215f9d5ea', 'independent-review/INDEPENDENT_REVIEW.md': '0608df18c1a33a354cf1398185f1cad379453a9b3916b9803d94e151cb350705', 'independent-review/VERDICT.json': '2bcb66f613080e2b6276d5c079370b9b0b1c630477d888a526b62dedc6e170ad'}
SOURCE_MANIFESTS={'author':'b58aa5d90e5faf2fc3a85afbbe856fe244f819ffee9672248d89ad1a6cc183fc','independent-review':'3ef43809ad247d951b0e34c1e9be5c013d68772d74cc45e6d2743a4215f9d5ea'}
ZIP_SHA='c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe'
DIGEST=re.compile(r'[0-9a-f]{64}\Z')
def need(v,msg):
 if not v:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def desc(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
def exact(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if type(a)is list:return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b

def pairs(xs):
 d={}
 for k,v in xs:need(k not in d,'duplicate JSON key: '+k);d[k]=v
 return d
def loads(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON constant')))
def read(p):return loads(p.read_text('utf-8'))
def keys(x,ks,label):need(type(x)is dict and x.keys()==set(ks),label+' fields')
def uint(x,label):need(type(x)is int and x>=0,label+' integer type/range')
def digest(x,label):need(type(x)is str and DIGEST.fullmatch(x) is not None,label+' digest')
def route(x):
 need(type(x)is str and bool(x) and '\\' not in x and '\0' not in x,'path type')
 p=PurePosixPath(x);need(not p.is_absolute() and str(p)==x and all(k not in ('','.','..') for k in p.parts),'unsafe route')
 need('__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'),'bytecode prohibited')
 return x

def identity(x):
 keys(x,('bytes','sha256'),'identity');uint(x['bytes'],'bytes');digest(x['sha256'],'sha256')
def inventory(root):
 actual=set()
 for p in root.rglob('*'):
  need(not p.is_symlink(),'symlink prohibited')
  if p.is_file():actual.add(route(p.relative_to(root).as_posix()))
  else:need(p.is_dir(),'nonregular filesystem member')
 return actual

def check_manifest(root):
 actual=inventory(root);m=read(root/'MANIFEST.json');s=read(root/'SEAL.json')
 keys(m,('schema_version','package','files'),'manifest');need(type(m['schema_version'])is int and m['schema_version']==1,'manifest schema');need(m['package']=='f020-adjacent-degree-public-20261020','manifest package');need(type(m['files'])is list,'manifest list')
 keys(s,('algorithm','manifest','manifest_sha256','file_count'),'seal');need(s['algorithm']=='SHA-256' and s['manifest']=='MANIFEST.json','seal scheme');digest(s['manifest_sha256'],'seal');uint(s['file_count'],'file count')
 need(sha((root/'MANIFEST.json').read_bytes())==s['manifest_sha256'],'manifest seal mismatch')
 names=[]
 for e in m['files']:
  keys(e,('path','bytes','sha256'),'member');route(e['path']);identity({k:e[k] for k in ('bytes','sha256')});names.append(e['path'])
  need(e['path'] not in ('MANIFEST.json','SEAL.json'),'self-referential manifest')
  need(exact(desc(root/e['path']),{k:e[k] for k in ('bytes','sha256')}),'member bytes/hash mismatch: '+e['path'])
 need(names==sorted(set(names)),'duplicate/unsorted members')
 need(actual==set(names)|{'MANIFEST.json','SEAL.json'} and len(actual)==s['file_count'],'exact inventory mismatch')
 return actual

def privacy_data(name,b):
 text=b.decode('utf-8')
 tokens=['/'+x+'/' for x in ('workspace','home','tmp','root')]+['cloud'+'_threads','collaboration'+'.','mcp'+'__','user_message'+'.','/'+'agent_notes'+'/','/'+'user_notes'+'/','dream'+'_notes','delivery'+'_context','thread'+'_id','lib'+'file_','codex'+':','chatgpt'+'.com']
 need(not any(t in name+'\n'+text for t in tokens),'private locator/coordination marker: '+name)
 need(re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',text) is None,'private key marker')
 need(re.search(r'(?:gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{32,})',text) is None,'credential marker')
 need(re.search(r'f020_[a-z_]+_20\d{6}',text) is None,'nonpublic source locator')
 if name.endswith('.json'):loads(text)

def unzip_checked(data,dst):
 names=[]
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  need(len(z.infolist())<=2000 and sum(i.file_size for i in z.infolist())<=40_000_000,'archive size limit')
  for i in z.infolist():
   need(not i.is_dir(),'unexpected directory archive member');name=route(i.filename);names.append(name)
   mode=i.external_attr>>16;need(stat.S_IFMT(mode) in (0,stat.S_IFREG),'nonregular archive member')
   need(not i.flag_bits&1,'encrypted archive member')
  need(len(names)==len(set(names)),'duplicate archive member')
  for i in z.infolist():
   b=z.read(i);p=dst/i.filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 return names

def environment():
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONOPTIMIZE',None);return env

def dependency(root,run_nested=True):
 d=read(root/'provenance/DEPENDENCY.json');raw=(root/d['archive']).read_bytes()
 need(sha(raw)==ZIP_SHA and len(raw)==d['bytes'],'retained archive identity')
 with tempfile.TemporaryDirectory(prefix='adjacent-dependency-') as t:
  out=Path(t);names=unzip_checked(raw,out);need(len(names)==d['archive_regular_files']==455,'dependency archive count')
  dep=out/d['root'];actual=inventory(dep);m=read(dep/'MANIFEST.json');s=read(dep/'SEAL.json')
  need(sha((dep/'MANIFEST.json').read_bytes())==d['root_manifest_sha256']==s['manifest_sha256'],'dependency root seal')
  need(sha((dep/'SEAL.json').read_bytes())==d['root_seal_sha256'],'dependency public seal identity')
  listed=[]
  for e in m['files']:
   keys(e,('path','bytes','sha256'),'dependency member');route(e['path']);identity({k:e[k] for k in ('bytes','sha256')});listed.append(e['path']);need(exact(desc(dep/e['path']),{k:e[k] for k in ('bytes','sha256')}),'dependency member hash')
  need(len(listed)==len(set(listed))==d['root_manifest_entries']==453 and actual==set(listed)|{'MANIFEST.json','SEAL.json'},'dependency exact inventory')
  for rel in sorted(actual):privacy_data(rel,(dep/rel).read_bytes())
  source=read(root/'author/SOURCE_BINDINGS.json');need(source['restored_public_zip_sha256']==ZIP_SHA and source['source_root_manifest_sha256']==d['root_manifest_sha256'],'author dependency binding')
  need(type(source['source_root_manifest_entries_verified'])is int and source['source_root_manifest_entries_verified']==453 and source['source_root_seal_verified'] is True and source['read_actual_sources'] is True,'author source verification types')
  need(len(source['files'])==7,'seven source copies required')
  for e in source['files']:
   route(e['copy']);route(e['source_public_relative_path']);want={k:e[k] for k in ('bytes','sha256')};identity(want)
   need(exact(desc(dep/e['source_public_relative_path']),want) and exact(desc(root/'author'/e['copy']),want) and e['top_manifest_entry_verified'] is True,'source copy identity')
  for r in d['inherited_receipts']:
   need(r['status']=='inherited_byte_bound_receipt_not_newly_executed','receipt execution label');need(exact(desc(out/route(r['archive_path'])),{k:r[k] for k in ('bytes','sha256')}),'inherited receipt identity')
  nested=None
  if run_nested:
   p=subprocess.run([sys.executable,str(dep/'verify_package.py')],cwd=out,env=environment(),capture_output=True,text=True,timeout=180)
   need(p.returncode==0,'dependency integrity checker failed: '+p.stderr[-1000:]);nested=loads(p.stdout);need(nested['status']=='PASS','dependency integrity status')
 return {'status':'PASS','archive_regular_files':455,'manifest_entries':453,'copied_sources_verified':7,'privacy_scanned_files':455,'inherited_receipts_verified':len(d['inherited_receipts']),'inherited_mathematical_programs_executed':0,'recursive_integrity':nested}

def source_ledger(root):
 l=read(root/'provenance/SOURCE_LEDGER.json');need(type(l['schema_version'])is int and l['schema_version']==1,'ledger schema');need(type(l['files'])is list,'ledger files')
 bysrc={};destinations=set();counts={'verbatim':0,'public_projection':0,'excluded':0}
 for e in l['files']:
  keys(e,('source_set','source_path','original','export_path','exported','mode','reason','changes'),'source ledger row');need(e['source_set'] in SOURCE_MANIFESTS,'source set');route(e['source_path']);identity(e['original']);k=(e['source_set'],e['source_path']);need(k not in bysrc,'duplicate source member');bysrc[k]=e
  need(e['mode'] in counts and type(e['reason'])is str and bool(e['reason']) and type(e['changes'])is list,'source mode/reason');counts[e['mode']]+=1
  if e['mode']=='excluded':need(k==('author','REVIEW_REQUEST.md') and e['export_path'] is None and e['exported'] is None and e['changes']==[],'unexpected source omission');continue
  route(e['export_path']);identity(e['exported']);need(e['export_path'] not in destinations,'duplicate export');destinations.add(e['export_path']);need(exact(desc(root/e['export_path']),e['exported']),'public source identity')
  if e['mode']=='verbatim':need(exact(e['original'],e['exported']) and e['changes']==[],'verbatim identity')
  else:
   need(k==('independent-review','README.md') and len(e['changes'])==1,'unapproved projection');c=e['changes'][0];keys(c,('kind','source_text_bytes','source_text_sha256','replacement','count'),'projection');uint(c['source_text_bytes'],'projection bytes');digest(c['source_text_sha256'],'projection source hash');need(type(c['count'])is int and c['count']==1 and c['kind']=='verification_locator','projection type/count');need(type(c['replacement'])is str and (root/e['export_path']).read_text().count(c['replacement'])==1,'projected locator missing');need(e['original']['bytes']+len(c['replacement'].encode())-c['source_text_bytes']==e['exported']['bytes'],'projection size accounting')
 for label,h in SOURCE_MANIFESTS.items():
  manifest=root/label/'MANIFEST.json';need(sha(manifest.read_bytes())==h,'frozen source manifest');need((root/label/'SEAL.sha256').read_text().split()==[h,'MANIFEST.json'],'frozen source seal');m=read(manifest);expected={'MANIFEST.json','SEAL.sha256'}
  for e in m['files']:
   route(e['path']);want={k:e[k] for k in ('bytes','sha256')};identity(want);need(e['path'] not in expected,'duplicate original source entry');expected.add(e['path']);need(exact(bysrc[(label,e['path'])]['original'],want),'original source manifest accounting')
  need({p for lab,p in bysrc if lab==label}==expected,'unaccounted source member')
 need(counts=={'verbatim':33,'public_projection':1,'excluded':1},'source retention counts')
 return counts

def integrity(root=ROOT,run_nested=True):
 need(sys.flags.optimize==0,'assertion-enabled Python required');actual=check_manifest(root)
 for rel,h in ANCHORS.items():need(sha((root/rel).read_bytes())==h,'fixed scientific/metadata anchor changed: '+rel)
 for rel in actual:
  if not rel.endswith('.zip'):privacy_data(rel,(root/rel).read_bytes())
 counts=source_ledger(root);s=read(root/'SCOPE.json');need(type(s['schema_version'])is int and s['schema_version']==1,'scope schema')
 for k in ['ordinary_derivatives','algebraic_squares']:need(s[k] is True,'scientific normalization')
 for k in ['full_r2_theorem','squarefreeness_counterexample','all_root_constant_derivative_valuation','arbitrary_degrees_or_digits','global_f020_f023_closure','fft_speed_or_complexity_claim','novelty_claim','external_publication_performed']:need(s[k] is False,'scope overclaim/type: '+k)
 v=read(root/'independent-review/VERDICT.json');need(v['verdict']==s['status']=='ACCEPTED_WITHIN_PRECISE_PARTIAL_SCOPE' and v['source_manifest_sha256']==SOURCE_MANIFESTS['author'] and v['source_report_sha256']==s['author_report_sha256'],'fresh verdict binding')
 need(type(v['source_entries_verified'])is int and v['source_entries_verified']==16 and v['proof_revisions_requested'] is False and v['essential_lemma_contribution_by_reviewer'] is False and v['mathematical_defects_found']==[],'fresh verdict conditions')
 need((root/'author/CONTROL_RESULTS.json').read_bytes()==(root/'independent-review/cold_replay/CONTROL_RESULTS.json').read_bytes(),'historical author replay receipt')
 dep=dependency(root,run_nested)
 return {'status':'PASS','public_files':len(actual),'source_files_accounted':35,'source_modes':counts,'accepted_scientific_and_metadata_anchors':len(ANCHORS),'privacy':'PASS','strict_json_and_manifest_types':'PASS','dependency':dep,'network_used':False,'new_mathematical_review':False}

def normalized_result(case,data):
 data=copy.deepcopy(data)
 if case['id']=='independent_central':
  need(type(data)is list and len(data)==6,'central case count')
  for row in data:
   need(type(row)is dict and 'runtime_seconds' in row,'missing declared timing');x=row.pop('runtime_seconds');need(type(x)is float and math.isfinite(x) and x>=0,'runtime_seconds type/range')
 return data

def compare_result(case,got,expected):need(exact(normalized_result(case,got),normalized_result(case,expected)),'strict replay result mismatch: '+case['id'])

def math_countercontrols(root):
 a=read(root/'author/CONTROL_RESULTS.json');tested=[]
 from fractions import Fraction
 for row in a['actual_cyclotomic']:
  p=row['p'];f={int(k):v for k,v in row['actual_quotient'].items()};d={int(k):v for k,v in row['actual_derivative'].items()}
  need(all(k*v%p==0 for k,v in f.items()),'repeated residue derivative should vanish')
  need(bool(d) and any(v%p for v in d.values()),'original ordinary derivative is not the residue derivative')
  rem=[0,0]
  for k,v in d.items():rem[k%2]=(rem[k%2]+v*(-1)**(k//2))%p
  need(rem==[0,0] and row['residual_gcd']=='Y**2 + 1','nontrivial residual gcd lost');tested.append([p,row['r'],row['s']])
 for row in a['integer']:
  tie=2*Fraction(row['rho'])==row['p'];need(tie==(row['r']==2),'central half-slope tie scope')
 need(len(tested)==4,'phase countercontrol inventory')
 return {'status':'PASS','four_central_phase_cases':tested,'repeated_residue_derivative_is_zero_but_original_derivative_residual_is_not':True,'nontrivial_common_factor_is_not_a_squarefreeness_counterexample':True,'half_slope_tie_only_r2':True}

def controls(root=ROOT):
 before=sha((root/'MANIFEST.json').read_bytes());cfg=read(root/'REPLAY_CASES.json');out=[]
 need(cfg['type_strict'] is True and cfg['only_new_adjacent_degree_controls'] is True and type(cfg['inherited_mathematical_programs_executed'])is int and cfg['inherited_mathematical_programs_executed']==0,'replay policy')
 with tempfile.TemporaryDirectory(prefix='adjacent-current-replay-') as t:
  base=Path(t)
  for case in cfg['cases']:
   dst=base/case['id'];dst.mkdir();script=dst/Path(case['script']).name;shutil.copyfile(root/case['script'],script)
   p=subprocess.run([sys.executable,str(script)],cwd=dst,env=environment(),capture_output=True,text=True,timeout=180)
   need(p.returncode==0,'current checker failed: '+case['id']+' '+p.stderr[-2000:]);got=read(dst/case['output']);expected=read(root/case['expected']);compare_result(case,got,expected)
   need(not list(dst.rglob('*.pyc')) and not list(dst.rglob('__pycache__')),'replay produced bytecode')
   out.append({'id':case['id'],'script_sha256':sha(script.read_bytes()),'frozen_output_sha256':sha((root/case['expected']).read_bytes()),'replayed_output_sha256':sha((dst/case['output']).read_bytes()),'mathematical_result_sha256':sha(json.dumps(normalized_result(case,got),sort_keys=True,separators=(',',':')).encode()),'all_mathematical_fields_exact_type_and_value_match':True,'ignored_json_fields':case['ignored_json_fields'],'stdout':p.stdout,'stderr':p.stderr})
 need(sha((root/'MANIFEST.json').read_bytes())==before,'release mutated')
 return {'status':'PASS','current_program_count':3,'inherited_mathematical_programs_executed':0,'results':out,'mathematical_countercontrols':math_countercontrols(root),'package_unchanged':True,'python':sys.version.split()[0]}

def reseal(root):
 m=read(root/'MANIFEST.json')
 for e in m['files']:
  p=root/e['path']
  if p.is_file():e.update(desc(p))
 (root/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');s=read(root/'SEAL.json');s['manifest_sha256']=sha((root/'MANIFEST.json').read_bytes());(root/'SEAL.json').write_text(json.dumps(s,indent=2)+'\n')

def negatives(root=ROOT):
 tests=[]
 def reject(name,fn):
  try:fn()
  except (ValueError,OSError,KeyError,TypeError,zipfile.BadZipFile):tests.append({'name':name,'rejected':True});return
  raise ValueError('negative control accepted: '+name)
 def changed(name,fn):
  with tempfile.TemporaryDirectory(prefix='adjacent-negative-') as t:
   dst=Path(t)/'release';shutil.copytree(root,dst);fn(dst);reject(name,lambda:integrity(dst,False))
 def mutate_json(r,path,key,value,rehash=True):
  d=read(r/path);d[key]=value;(r/path).write_text(json.dumps(d))
  if rehash:reseal(r)
 def mfentry(r,key,value):
  p=r/'MANIFEST.json';m=read(p);m['files'][0][key]=value;p.write_text(json.dumps(m));s=read(r/'SEAL.json');s['manifest_sha256']=sha(p.read_bytes());(r/'SEAL.json').write_text(json.dumps(s))
 changed('changed accepted proof byte',lambda r:(r/'author/REPORT.md').write_bytes((r/'author/REPORT.md').read_bytes()+b' '))
 changed('missing source copy',lambda r:(r/'author/sources/accepted_leading_two_REPORT.md').unlink())
 changed('unlisted member',lambda r:(r/'EXTRA.txt').write_text('extra'))
 changed('bytecode cache member',lambda r:((r/'__pycache__').mkdir(),(r/'__pycache__/extra.pyc').write_bytes(b'x')))
 changed('boolean byte count',lambda r:mfentry(r,'bytes',True))
 changed('string byte count',lambda r:mfentry(r,'bytes','1'))
 changed('negative byte count',lambda r:mfentry(r,'bytes',-1))
 changed('absolute member path',lambda r:mfentry(r,'path','/escape'))
 changed('traversal member path',lambda r:mfentry(r,'path','../escape'))
 changed('uppercase digest',lambda r:mfentry(r,'sha256','A'*64))
 changed('boolean schema version',lambda r:mutate_json(r,'MANIFEST.json','schema_version',True))
 changed('full r2 theorem after rehash',lambda r:mutate_json(r,'SCOPE.json','full_r2_theorem',True))
 changed('zero masquerading as false',lambda r:mutate_json(r,'SCOPE.json','fft_speed_or_complexity_claim',0))
 changed('squarefreeness counterexample after rehash',lambda r:mutate_json(r,'SCOPE.json','squarefreeness_counterexample',True))
 changed('global closure after rehash',lambda r:mutate_json(r,'SCOPE.json','global_f020_f023_closure',True))
 changed('modified proof after rehash',lambda r:((r/'author/REPORT.md').write_bytes((r/'author/REPORT.md').read_bytes()+b' '),reseal(r)))
 changed('duplicate JSON key after rehash',lambda r:((r/'SCOPE.json').write_text((r/'SCOPE.json').read_text().replace('"schema_version": 1,','"schema_version": 1, "schema_version": 1,',1)),reseal(r)))
 changed('private locator after rehash',lambda r:((r/'README.md').write_text((r/'README.md').read_text()+'\n/'+'workspace'+'/nonpublic\n'),reseal(r)))
 changed('source ledger changed after rehash',lambda r:mutate_json(r,'provenance/SOURCE_LEDGER.json','policy','Changed'))
 changed('dependency bytes changed after rehash',lambda r:((r/'dependencies/f020-single-leading-digit-comparison-2026-10-20.zip').write_bytes(b'bad'),reseal(r)))
 def symlink(r):
  p=r/'README.md';p.unlink();p.symlink_to('ATTRIBUTION.md')
 changed('symlink replacement',symlink)
 for kind in ['traversal','absolute','duplicate','symlink','cache']:
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:
   name={'traversal':'../bad','absolute':'/bad','duplicate':'ok','symlink':'link','cache':'__pycache__/a.pyc'}[kind]
   if kind=='symlink':
    i=zipfile.ZipInfo(name);i.create_system=3;i.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(i,'elsewhere')
   else:z.writestr(name,'x')
   if kind=='duplicate':
    import warnings
    with warnings.catch_warnings():warnings.simplefilter('ignore');z.writestr(name,'y')
  with tempfile.TemporaryDirectory(prefix='adjacent-zip-negative-') as t:reject('unsafe ZIP '+kind,lambda:unzip_checked(b.getvalue(),Path(t)))
 cfg=read(root/'REPLAY_CASES.json')
 for case in cfg['cases']:
  exp=read(root/case['expected']);bad=copy.deepcopy(exp)
  if case['id']=='author':bad['integer'][0]['p']=True
  else:bad[0]['p']=True
  reject(case['id']+' replay boolean/integer confusion',lambda:compare_result(case,bad,exp))
  bad=copy.deepcopy(exp)
  if case['id']=='author':bad['actual_cyclotomic'][0]['actual_derivative']['1']=0
  elif case['id']=='independent_integer':bad[0]['rho']='0'
  else:bad[0]['ordinary_derivative_residual']['1']=0
  reject(case['id']+' replay mathematical mutation',lambda:compare_result(case,bad,exp))
 case=cfg['cases'][2];exp=read(root/case['expected']);bad=copy.deepcopy(exp);bad[0]['runtime_seconds']=False;reject('declared timing field boolean type',lambda:compare_result(case,bad,exp))
 bad=copy.deepcopy(exp);bad[0].pop('runtime_seconds');reject('missing declared timing field',lambda:compare_result(case,bad,exp))
 bad=copy.deepcopy(exp);bad[0]['unexpected_field']=0;reject('extra replay field',lambda:compare_result(case,bad,exp))
 reject('duplicate JSON object key',lambda:loads('{"x":1,"x":1}'))
 reject('nonfinite JSON number',lambda:loads('{"x":NaN}'))
 need(not exact(True,1) and not exact(False,0) and not exact(1,1.0) and not exact([1],['1']),'strict scalar countercontrol')
 return {'status':'PASS','negative_case_count':len(tests),'cases':tests,'mathematical_countercontrols':math_countercontrols(root),'package_unchanged':True}

def main():
 p=argparse.ArgumentParser();p.add_argument('--integrity-only',action='store_true');p.add_argument('--controls',action='store_true');p.add_argument('--negative-controls',action='store_true');a=p.parse_args();result={'integrity':integrity()}
 if a.controls:result['controls']=controls()
 if a.negative_controls:result['negative_controls']=negatives()
 print(json.dumps(result,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:print(json.dumps({'status':'FAIL','reason':str(e)}),file=sys.stderr);sys.exit(1)
