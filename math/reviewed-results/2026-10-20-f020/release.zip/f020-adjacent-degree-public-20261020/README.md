# Adjacent-degree squarefreeness: a precisely partial result

20 October 2026 UTC. Standalone public research release with separate fresh mathematical review.

For n=2p^r+1, odd prime p, r>=3, s>r, and q a characteristic-zero primitive p^s root, this package proves squarefreeness of the original Rogers–Szegő H and q-Hermite P polynomials and nonvanishing of the original algebraic-square Christoffel–Darboux kernel at every root. Ordinary derivatives are used throughout.

For r=2, the exact zero and all noncentral roots are covered. Exactly 2p central nonzero roots remain unresolved. Their actual derivative-residual cancellation is a failure of this leading certificate, NOT a squarefreeness counterexample. No full r=2 result, arbitrary-degree extension, FFT-speed claim, novelty claim, or global F020/F023 closure is asserted.

## Reading and source identity

1. SCOPE.json gives the release boundary.
2. author/REPORT.md and independent-review/INDEPENDENT_REVIEW.md are the byte-identical accepted manuscript and fresh audit. independent-review/VERDICT.json binds the corrected author manifest. Candidate-era wording in the preserved author records is historical and is superseded by that fresh verdict.
3. author/sources/ preserves the seven exact cited public source copies.
4. dependencies/f020-single-leading-digit-comparison-2026-10-20.zip is the ENTIRE previously public dependency archive, byte-identical at SHA-256 c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe. Unzip it to read the full accepted proofs, reviews, credits and retained dependency controls. The source locator strings in author/SOURCE_BINDINGS.json are relative to its f020-single-leading-digit-comparison root. No network is needed.
5. provenance/SOURCE_LEDGER.json accounts for every frozen source member and distinguishes original from public hashes. Only the review README verification locator is projected; the superseded author review-request instruction is omitted. All scientific text, control programs, saved mathematical outputs and attribution remain unchanged. Original manifests/seals are historical source inventories, not public inventories; use the root verifier rather than the preserved historical source-only checker.

## Offline verification and replay

Use assertion-enabled Python 3.12 and SymPy 1.14.0. Install dependencies separately. The integrity verifier is standard-library only. Run from any working directory:

    python verify.py --integrity-only
    python verify.py --controls
    python verify.py --negative-controls

The verifier checks exact file inventory, safe routes, strict JSON types and duplicate-key rejection, fixed accepted hashes, source/projection accounting, original manifests, all seven source copies, and privacy. It securely extracts the retained dependency in a temporary directory and runs its read-only recursive integrity checker, not its mathematical replay programs.

Current replay executes exactly three new adjacent-degree scripts in disposable writable directories: the author checker once, the independently authored integer checker, and the independently authored actual-cyclotomic quotient checker. All mathematical fields and exact JSON types must match frozen receipts. Only the six explicitly named runtime_seconds values in the independent central checker may differ; their finite nonnegative float types are still checked. Log timings are nonmathematical. The historical audit's identical author replay and the prior dependency's receipts remain inherited, byte-bound evidence, not new executions or a new independent review.

Negative controls cover file/manifest/ZIP corruption, omitted and extra members, unsafe routes and symlinks, duplicate JSON keys, JSON type confusion, rehashed scope widening, source or projection changes, privacy leaks, and mutation of replay results. Mathematical countercontrols check the characteristic-p repeated-residual derivative, the nontrivial residual gcd and the r=2 half-slope tie rather than silently promoting a failed certificate to a counterexample.

The package is never modified during verification or replay. Bytecode caches are disabled and not distributed. Separately supplied release receipts bind the final ZIP, its cold extraction, the new replay, privacy scan and negative controls. Hashes establish byte integrity, not truth, identity, priority or cryptographic signatures.
