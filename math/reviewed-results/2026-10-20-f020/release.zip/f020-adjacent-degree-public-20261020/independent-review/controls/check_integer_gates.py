from pathlib import Path
OUT=Path(__file__).resolve().parent
"""Independent direct-sum integer gates; finite controls, not a uniform proof."""
import json
from fractions import Fraction as F

def run(p,r):
 N=p**r; beta=p**(r//2); rho=F(beta,2) if r%2==0 else F(p**(r//2-1)*(2*p-1),2); B=r*(p-1)*p**(r-1)//2
 power=[0]; W=[0]; R=[F(0)]
 for j in range(1,2*N+2):
  v=1;k=j
  while k%p==0:k//=p;v*=p
  power.append(v);W.append(W[-1]+v);R.append(R[-1]+max(F(0),v-rho))
 E=F(N,2)+2*B
 maxima=[]
 for k in range(1,2*N,2):
  score=W[(2*N-1-k)//2]+R[k]
  assert score<=E
  if score==E:maxima.append(k)
 assert maxima==[N]
 dmax=None; dpairs=0
 for k in range(1,2*N,2):
  for m in range(k):
   score=W[(2*N-1-k)//2]+R[m]+power[k-m]
   assert score<=E,(p,r,k,m,score,E)
   dmax=score if dmax is None else max(dmax,score);dpairs+=1
 # The complete outside-disk quotient covering inequality, not just endpoints.
 covermax=max(W[u]-R[2*u] for u in range(N))
 assert covermax<=F(N,2)-rho
 # Direct quotient Newton-term gate, not needed by the author's perturbation route.
 qmax=max(R[2*l]+power[2*l+1]+W[N-l] for l in range(N+1))
 assert qmax==W[N]+1
 assert [l for l in range(N+1) if R[2*l]+power[2*l+1]+W[N-l]==qmax]==[0,N]
 assert F(p,2)==rho if r==2 else F(p,2)<rho
 xvals={rho}|{F(power[a]) for a in range(1,beta)}
 equalities=[str(x) for x in xvals if 2*x==p]
 assert equalities==([str(rho)] if r==2 else [])
 return {'p':p,'r':r,'rho':str(rho),'neighbor_weight':str(E),'neighbor_polynomial_equality_indices':maxima,'derivative_pairs':dpairs,'derivative_score_max':str(dmax),'cover_score_max':str(covermax),'cover_bound':str(F(N,2)-rho),'quotient_endpoints_only':True,'derivative_tie_valuations':equalities}
if __name__=='__main__':
 cases=[(3,r) for r in range(2,6)]+[(5,r) for r in range(2,4)]+[(7,r) for r in range(2,4)]+[(11,2)]
 rows=[]
 for case in cases:
  row=run(*case);rows.append(row);print(case,'PASS',flush=True)
 open(OUT/'integer_gate_controls.json','w').write(json.dumps(rows,indent=2))
