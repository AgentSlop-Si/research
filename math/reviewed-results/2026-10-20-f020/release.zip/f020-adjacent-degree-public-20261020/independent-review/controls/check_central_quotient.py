from pathlib import Path
OUT=Path(__file__).resolve().parent
import math,json,time
from fractions import Fraction as F

def main(p,r,s):
 start=time.monotonic();N=p**r;n=2*N+1;order=p**s;gap=order//p;e=order-gap;h=r//2;beta=p**h;rho=F(beta,2) if r%2==0 else F(p**(h-1)*(2*p-1),2);B=r*(p-1)*p**(r-1)//2
 one=[1]+[0]*(e-1)
 def shift(v,k):
  out=[0]*e
  for j,b in enumerate(v):
   if not b:continue
   j=(j+k)%order
   if j<e:out[j]+=b
   else:
    for l in range(p-1):out[j-e+l*gap]-=b
  return out
 def val(v):
  cs=v[:]
  for a in range(e-2,-1,-1):
   for j in range(a,e-1):cs[j]+=cs[j+1]
  vals=[]
  for j,b in enumerate(cs):
   if not b:continue
   vp=0
   while b%p==0:vp+=1;b//=p
   vals.append((j+vp*e,b*(-1)**vp%p))
  return min(vals) if vals else None
 old=[one];cur=[[0]*e,one]
 for k in range(1,n):
  new=[[0]*e for _ in range(k+2)]
  for j,v in enumerate(cur):
   for a,b in enumerate(v):new[j+1][a]+=b
  for j,v in enumerate(old):
   sh=shift(v,k)
   for a,(x,y) in enumerate(zip(sh,v)):new[j][a]+=x-y
  old,cur=cur,new
 assert not any(cur[0]);Q=cur[1:]
 cv=[val(x) for x in Q]; vals=[(w+j*rho,j,u) for j,x in enumerate(cv) if x for w,u in [x]]
 dvals=[]
 for j,x in enumerate(cv):
  if not j or not x:continue
  w,u=x;jj=j;vp=0
  while jj%p==0:vp+=1;jj//=p
  dvals.append((w+(j-1)*rho+vp*e,j-1,u*jj*(-1)**vp%p))
 wt=min(x[0] for x in vals);dwt=min(x[0] for x in dvals)
 res={j:u for w,j,u in vals if w==wt};dres={j:u for w,j,u in dvals if w==dwt}
 if r==2:
  eps=(-1)**((p-1)//2)
  assert wt==N+2*B
  assert res=={0:1,2*p:1},res
  assert dwt==3*B+F(p*p,2)
  assert dres=={p-2:(-2*eps)%p,p:(-2*eps)%p},dres
 out={'p':p,'r':r,'s':s,'n':n,'rho':str(rho),'quotient_weight':str(wt),'quotient_residual':res,'derivative_weight':str(dwt),'ordinary_derivative_residual':dres,'coefficient_values':cv,'runtime_seconds':round(time.monotonic()-start,3)}
 print(json.dumps({k:v for k,v in out.items() if k!='coefficient_values'}),flush=True);return out
if __name__=='__main__':
 out=[main(*a) for a in [(3,2,3),(3,2,4),(5,2,3),(7,2,3),(3,3,4),(3,4,5)]]
 open(OUT/'central_quotient_controls.json','w').write(json.dumps(out,indent=2))
