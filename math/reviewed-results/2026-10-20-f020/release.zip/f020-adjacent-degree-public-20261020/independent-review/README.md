# F020 adjacent-degree independent review

This package accepts the exact new n=2p^r+1 partial theorem for r>=3 and the r=2 central obstruction, not a full r>=2 theorem or global F020 closure. Read INDEPENDENT_REVIEW.md and VERDICT.json for the exact scope and source bindings.

Verification of this public release: `python ../verify.py --integrity-only`. The preserved verify_package.py is the historical source-package checker; use the public verifier for the disclosed source projection and omission.

Independent controls are in controls/. They reconstruct the original P recurrence and its ordinary derivative with exact cyclotomic arithmetic, and check the finite integer gates by direct sums. Execute each checker in a writable copy; its JSON and log output are controls, not a proof of an unlimited family. Their output paths are relative to the checker location.

cold_replay/ contains an unchanged copy of the author's checker and the independently replayed results. Running it requires SymPy and Python 3. It writes into its own directory. Its resulting mathematical JSON exactly matches the frozen author's CONTROL_RESULTS.json; elapsed times in the log may differ.

No external writes or changes to prior accepted packages were performed in this review. A pre-freeze generated cache was excluded before the final source seal. No essential lemma or proof repair was contributed by the reviewer.
