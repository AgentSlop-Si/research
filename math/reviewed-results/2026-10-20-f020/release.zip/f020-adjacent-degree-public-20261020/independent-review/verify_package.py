#!/usr/bin/env python3
"""Verify this audit and optionally the exact reviewed candidate."""
import argparse,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(root):
 manifest=root/'MANIFEST.json'
 expected=(root/'SEAL.sha256').read_text().split()[0]
 assert sha(manifest)==expected,('manifest seal',root)
 data=json.loads(manifest.read_text())
 for ent in data['files']:
  path=root/ent['path']
  assert len(path.read_bytes())==ent['bytes'],path
  assert sha(path)==ent['sha256'],path
 return len(data['files'])
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--author',type=Path);args=parser.parse_args()
 n=verify(P);out={'audit_entries_verified':n}
 if args.author:
  v=json.loads((P/'VERDICT.json').read_text());a=args.author
  assert sha(a/'MANIFEST.json')==v['source_manifest_sha256']
  assert sha(a/'REPORT.md')==v['source_report_sha256']
  out['author_entries_verified']=verify(a)
 print(json.dumps(out,indent=2))
