# Contributions and limitations

The adjacent-degree author derived the odd-quotient perturbation argument, root-dependent derivative separation and the uniform central r=2 phase cancellation. The fresh independent reviewer audited those arguments, supplied challenge controls and independent finite confirmations, and requested no mathematical proof revision. The reviewer did not contribute an essential lemma; the author had independently derived the quotient mechanism and cancellation before receiving those confirmations. These contribution statements are preserved in the exact manuscript and fresh review.

The accepted leading-c, leading-two and low-digit results are explicitly imported, not reattributed. All original public source proofs, reviews, source-comparison qualifications and contributor credits are retained in the byte-identical dependency archive. Classical Rogers–Szegő/q-Hermite identities, Newton-polygon counting and Christoffel–Darboux identities retain their attribution. No new literature-priority claim is made.

The packaging verifier and replay receipts check distribution integrity and finite controls. They are not a replacement for the fresh mathematical review and do not close the remaining central r=2 cluster or any global research obligation.
