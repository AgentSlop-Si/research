#!/usr/bin/env python3
"""Bounded exact controls. They do not prove any unlimited parameter family."""
from fractions import Fraction as Q
from pathlib import Path
import json, math, time
import sympy as sp
OUT=Path(__file__).resolve().parent

def pp(p,j):
    if not j: raise ValueError('zero exponent')
    a=1
    while j%p==0: j//=p; a*=p
    return a

def W(p,m):
    ans=m; b=p
    while b<=m: ans+=(b-b//p)*(m//b); b*=p
    return ans

def params(p,r):
    N=p**r; B=r*(p-1)*p**(r-1)//2; beta=p**(r//2)
    rho=Q(beta,2) if r%2==0 else Q(p**(r//2-1)*(2*p-1),2)
    def T(m):
        return m+sum((p**a-p**(a-1))*(m//p**a) for a in range(1,r//2))+(rho-p**(r//2-1))*(m//beta)
    return N,B,beta,rho,T

def integer_controls():
    rows=[]
    for p,r in [(3,2),(3,3),(3,4),(3,5),(5,2),(5,3),(7,2),(7,3),(11,2)]:
        N,B,beta,rho,T=params(p,r); E=Q(N,2)+2*B; b=2*N-1
        R=lambda m:W(p,m)-T(m)
        pivots=[]
        for k in range(1,b+1,2):
            score=W(p,(b-k)//2)+R(k)
            assert score<=E
            if score==E:pivots.append(k)
        assert pivots==[N]
        pairs=0; mx=None
        for k in range(1,b+1,2):
            for m in range(k):
                val=W(p,(b-k)//2)+R(m)+pp(p,k-m)
                assert val<=E,(p,r,k,m,val,E)
                mx=val if mx is None else max(mx,val);pairs+=1
        assert rho<Q(N,2)
        assert (rho==Q(p,2))==(r==2)
        xset={rho}|{Q(pp(p,a)) for a in range(1,beta)}
        assert {x for x in xset if 2*x==p}==({rho} if r==2 else set())
        rows.append(dict(p=p,r=r,N=N,rho=str(rho),neighbor_weight=str(E),polynomial_pivots=pivots,derivative_pairs=pairs,derivative_max=str(mx),root_valuation_set=sorted(map(str,xset))))
    return rows

class Cyclotomic:
    def __init__(self,p,s):
        self.p=p;self.s=s;self.order=p**s;self.gap=self.order//p;self.e=self.order-self.gap
        self.one=[1]+[0]*(self.e-1)
    def rot(self,a,k):
        out=[0]*self.e;k%=self.order
        for j,v in enumerate(a):
            if not v:continue
            b=(j+k)%self.order
            if b<self.e:out[b]+=v
            else:
                for l in range(self.p-1):out[b-self.e+l*self.gap]-=v
        return out
    def valuation(self,a):
        if not any(a):return None
        b=a[:]
        # Exact Horner shift q=1+t, retaining all degree<e coefficients.
        for l in range(self.e-2,-1,-1):
            for j in range(l,self.e-1):b[j]+=b[j+1]
        vals=[]
        for j,v in enumerate(b):
            if not v:continue
            k=0
            while v%self.p==0:v//=self.p;k+=1
            vals.append((j+k*self.e,v*(-1)**k%self.p))
        return min(vals)
    def polynomials(self,n):
        old=[self.one];cur=[[0]*self.e,self.one]
        polys={0:old,1:cur}
        for k in range(1,n):
            nxt=[[0]*self.e for _ in range(k+2)]
            for j,a in enumerate(cur):nxt[j+1]=a[:]
            for j,a in enumerate(old):
                sh=self.rot(a,k)
                for l,(v,w) in enumerate(zip(sh,a)):nxt[j][l]+=v-w
            old,cur=cur,nxt
            if k+1>=n-2:polys[k+1]=cur
        return polys

def central_field(p,s):
    r=2;N,B,beta,rho,T=params(p,r);f=Cyclotomic(p,s);polys=f.polynomials(2*N+1)
    assert not any(polys[2*N+1][0]);F=polys[2*N+1][1:]
    weight=N+2*B;dw=3*B+Q(N,2);actual={};dactual={};records=[]
    for j,a in enumerate(F):
        v=f.valuation(a)
        if v is None:continue
        w,u=v;pw=w+j*rho
        assert pw>=weight
        if pw==weight:actual[j]=u
        dweight=None;du=None
        if j:
            j0=j;ordj=0
            while j0%p==0:j0//=p;ordj+=1
            dweight=w+ordj*f.e+(j-1)*rho;du=u*j0*(-1)**ordj%p
            assert dweight>=dw
            if dweight==dw:dactual[j-1]=du
        records.append(dict(degree=j,coefficient_weight=w,coefficient_unit=u,scaled_weight=str(pw),derivative_weight=str(dweight),derivative_unit=du))
    eps=(-1)**((p-1)//2);coef=(-2*eps)%p
    pred={0:1,2*p:1};dpred={p-2:coef,p:coef}
    assert actual==pred,(p,s,actual,pred)
    assert dactual==dpred,(p,s,dactual,dpred)
    Y=sp.Symbol('Y');a=sp.Poly(sum(v*Y**j for j,v in actual.items()),Y,modulus=p);b=sp.Poly(sum(v*Y**j for j,v in dactual.items()),Y,modulus=p)
    gcd=sp.gcd(a,b).monic();assert gcd==sp.Poly(Y**2+1,Y,modulus=p)
    # Constant coefficient proves the exact zero of original P_(2N+1) simple.
    assert f.valuation(F[0])[0]==weight
    return dict(p=p,r=2,s=s,degree=2*N+1,ramification=f.e,rho=str(rho),quotient_weight=weight,quotient_derivative_weight=str(dw),predicted_quotient=pred,actual_quotient=actual,predicted_derivative=dpred,actual_derivative=dactual,residual_gcd=str(gcd.as_expr()),records=records)

def finite_squarefree_witnesses():
    rows=[];X=sp.Symbol('X')
    for p,r,s in [(3,2,3),(3,2,4),(5,2,3),(7,2,3),(3,3,4),(3,4,5),(5,3,4)]:
        order=p**s;n=2*p**r+1;k=1
        while not sp.isprime(k*order+1):k+=1
        ell=k*order+1;g=int(sp.primitive_root(ell));q=pow(g,k,ell)
        assert pow(q,order,ell)==1 and pow(q,order//p,ell)!=1
        old=sp.Poly(1,X,modulus=ell);cur=sp.Poly(X,X,modulus=ell)
        for j in range(1,n):old,cur=cur,sp.Poly(X,X,modulus=ell)*cur-(1-pow(q,j,ell))*old
        gcd=sp.gcd(cur,cur.diff());assert gcd.degree()==0,(p,r,s,ell)
        rows.append(dict(p=p,r=r,s=s,n=n,residue_characteristic=ell,q=q,gcd_degree=gcd.degree(),scope='One exact good-prime witness for this cyclotomic specialization, not a uniform proof.'))
    return rows

def rational_controls():
    X,Z,V=sp.symbols('X Z V');rows=[]
    for q in [sp.Rational(2),sp.Rational(-2),sp.Rational(1,2)]:
        P=[sp.Integer(1),X];H=[sp.Integer(1),1+Z];w=[sp.Integer(1)]
        M=20
        for j in range(1,M+1):w.append(w[-1]*(1-q**j))
        for j in range(1,M):
            P.append(sp.expand(X*P[-1]-(1-q**j)*P[-2]));H.append(sp.expand((1+Z)*H[-1]-Z*(1-q**j)*H[-2]))
        for n in range(1,M+1):
            assert sp.expand(H[n].subs(Z,V**2)-V**n*P[n].subs(X,V+1/V))==0
            cd=sum(P[j]**2/w[j] for j in range(n))
            assert sp.expand(cd-(sp.diff(P[n],X)*P[n-1]-P[n]*sp.diff(P[n-1],X))/w[n-1])==0
        for N in range(1,10):
            F=sp.cancel(P[2*N+1]/X);G=sp.cancel(P[2*N-1]/X)
            assert sp.expand(F-P[2*N]+(1-q**(2*N))*G)==0
            assert sp.expand(sp.diff(F,X)-sp.diff(P[2*N],X)+(1-q**(2*N))*(sp.diff(P[2*N-1],X)/X-P[2*N-1]/X**2))==0
        rows.append(dict(q=str(q),degrees=list(range(1,M+1)),checks=['original H/P','ordinary algebraic-square CD','odd quotient','ordinary quotient derivative']))
    return rows

if __name__=='__main__':
    result={}
    def save(): (OUT/'CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    for label,fn in [('integer',integer_controls),('rational',rational_controls),('finite_squarefree_witnesses',finite_squarefree_witnesses)]:
        start=time.monotonic();result[label]=fn();save();print(label,'PASS',round(time.monotonic()-start,3),flush=True)
    result['actual_cyclotomic']=[]
    for p,s in [(3,3),(3,4),(5,3),(7,3)]:
        start=time.monotonic();result['actual_cyclotomic'].append(central_field(p,s));save();print('actual_cyclotomic',p,s,'PASS',round(time.monotonic()-start,3),flush=True)
    print('ALL BOUNDED EXACT CONTROLS PASS',flush=True)
