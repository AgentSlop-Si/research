# F020: a uniform leading-two family, n = 2 p^r

20 October 2026 UTC. Author candidate for a fresh independent audit. No external state was changed. The degree family here is distinct from the previously accepted pure-power and low-digit strips.

## 1. Statement in the original normalizations

Let p be any odd prime, r >= 2, s > r, N = p^r, n = 2N, and q a characteristic-zero primitive p^s-th root. Work in an algebraic p-adic embedding and normalize v(q-1) = 1. Set

    P_0 = 1, P_1 = X,
    P_(j+1) = X P_j - (1-q^j) P_(j-1),
    H_j(z) = sum_(a=0)^j [j choose a]_q z^a,
    w_j = (q;q)_j,
    B = r(p-1)p^(r-1)/2,
    h = floor(r/2), beta = p^h,
    rho = beta/2                              if r is even,
    rho = p^(h-1)(2p-1)/2                     if r is odd,
    D_2 = 3N/2 + 2B - p.

Then every root of BOTH original polynomials H_n and P_n is simple. Every original ordinary derivative at a root has valuation D_2, and

    v(Disc H_n) = v(Disc P_n) = 2N D_2.

There is an exact all-root geometric statement. The beta pairwise disjoint closed disks

    v(z+q^a) >= rho, 0 <= a < beta,

contain all H_n roots. Every root in a disk is on its boundary, not in its strict interior. Each disk contains exactly 2N/beta roots, counted with multiplicity before simplicity is proved. With lambda satisfying v(lambda)=rho, the normalized polynomial on a disk has residual

    1 + u_a Y^(2N/beta),  u_a != 0,

where z=-q^a+lambda Y. Its original ordinary derivative, at its own correct normalization, has residual a nonzero multiple of Y^(N/beta). Thus the repeated characteristic-p residual causes no gap: the original characteristic-zero derivative is proved nonzero on its root locus, by an exact identity before reduction.

In P coordinates the centers are

    x_a = i(q^(a/2)-q^(-a/2)), i^2=-1,

using the square root of q^a congruent to 1. All P_n roots satisfy v(X-x_a)=rho for a unique a modulo beta. The corresponding disk root counts are the same. In particular the central roots really have valuation p/2 when r=2; the earlier low-digit argument excluding that valuation is inapplicable here.

At every P_n root xi, the ORIGINAL algebraic-square kernel is nonzero:

    K_n(xi) = sum_(j=0)^(n-1) P_j(xi)^2/w_j != 0.

These are algebraic squares, not absolute-value squares. This theorem is uniform in all the stated p,r,s, not a finite degree ladder. It does not assert arbitrary leading digits, intermediate digits, arbitrary degrees below p^s, arbitrary odd-composite orders, or global F020/F023 closure.

## 2. Exact Newton and ordinary-derivative identities

Put

    W(m) = sum_(j=1)^m p^ord_p(j),
    N_k(z) = product_(j=0)^(k-1) (z+q^j), N_0=1.

Because n=2N < p^s, all factors and denominators used below are nonzero. For every positive j <= n,

    v(1-q^j) = p^ord_p(j).

In particular v(1-q^n)=N, NOT n. Also W(N)=N+2B and W(2N)=2W(N).

The exact both-parity Newton expansion and the ORDINARY z derivative are

    H_b(z) = sum_(0<=k<=b, k=b mod 2)
      w_b N_k(z) / [w_k (q^2;q^2)_((b-k)/2)],                 (2.1)

    H_b'(z) = sum_(k=b mod 2, k>=1) sum_(0<=m<k)
      w_b z^(k-m-1) N_m(z)
      / [(q^2;q^2)_((b-k)/2) w_m (1-q^(k-m))].              (2.2)

These may be derived over Q(q) as follows. Let E(x)=sum x^j/w_j. The identities

    E(qx)=(1-x)E(x),
    E(x)E(-x)=sum x^(2u)/(q^2;q^2)_u,
    E(zx)/E(-x)=sum N_k(z)x^k/w_k,
    (partial_z(E(zx)/E(-x)))/(E(zx)/E(-x))
       =sum_(j>=1) z^(j-1)x^j/(1-q^j)

give (2.1)-(2.2) by ordinary formal differentiation and coefficient comparison. Thus differentiation is performed in characteristic zero, not on the repeated residual polynomial, and is not a q derivative. The even k=0 term in (2.1) is retained throughout.

## 3. The new half-W digit inequality

Define the capped and tail sums

    T(m)=sum_(j=1)^m min(p^ord_p(j),rho),
    R(m)=W(m)-T(m).

Since p^(h-1)<rho<p^h, the exact floor formula is

    T(m)=m+sum_(b=1)^(h-1)(p^b-p^(b-1)) floor(m/p^b)
             +(rho-p^(h-1)) floor(m/p^h).                  (3.1)

The crucial inequality, different from the earlier pure-power inequality, is

    R(m) <= W(m)/2, 0 <= m <= 2N,
    equality exactly for m=0,N,2N.                         (3.2)

Here is its unlimited digit proof. Both W and R are linear in the base-p digits of m. For a<h, R(p^a)=0<W(p^a)/2. For h<=a<=r, direct substitution in (3.1), for EITHER parity of r, gives

    R(p^a) = W(p^a)/2 - (r-a)(p-1)p^(a-1)/2.               (3.3)

The second term is strictly positive for a<r and zero for a=r. Since 2N<p^(r+1), digitwise summation proves (3.2), including its exact equality cases. In particular T(N)=R(N)=W(N)/2 and T(2N)=R(2N)=W(N).

We also use superadditivity

    W(x)+W(y)<=W(x+y),                                    (3.4)

which follows immediately from the floor formula, and complementation

    R(x)+R(2N-1-x)=R(2N-1), 0<=x<2N.                     (3.5)

For (3.5), each p-power in the floor representation divides 2N. Finally,

    R(2N-1)=W(N)-N+rho.                                   (3.6)

Indeed R(2N)=W(N), and the last increment is N-rho.

A useful consequence, valid for every 1<=u<=N, is

    W(u)-R(2u-1)<=N-rho.                                  (3.7)

To prove it, put v=2N-2u. By (3.2)-(3.6),

    W(u)-R(2u-1)
      = W(u)+R(v)-R(2N-1)
      <= W(u)+W(v)/2-R(2N-1)
      <= W(2N)/2-R(2N-1)=N-rho.

The penultimate step uses 2W(u)<=W(2u) and (3.4). This proves the full comparison, not only its u=N endpoint.

## 4. Complete root cover, with the correct endpoint valuation

Suppose z is outside all disks v(z+q^a)>=rho, 0<=a<2N. Choose a maximizing delta=v(z+q^a)<rho. For j!=a,

    v(z+q^j)=min(delta,p^ord_p(j-a)).

When the two entries are equal, a larger result would contradict the maximizing choice; thus equality still holds. For every consecutive string of ell>=1 indices,

    sum v(z+q^j)<rho+T(ell-1).                            (4.1)

To verify this, count indices in residue classes modulo p^b, b<=h. The count is at most ceil(ell/p^b). The positive increments in (3.1), and ceil(ell/p^b)=1+floor((ell-1)/p^b), give rho+T(ell-1). Strictness follows either because an index in the top residue class has actual distance delta<rho, or because that top class is absent and its count is strictly below its upper bound. If delta<1 the same comparison remains strict.

Compare the term k=2N-2u of (2.1), 1<=u<=N, to the monic term N_(2N). The exact reflection identity is

    W(2N)-W(k)=N+W(2u-1),

because v(1-q^(2N))=N. Thus the difference of valuations is strictly greater than

    N-rho-W(u)+R(2u-1),

which is nonnegative by (3.7). Every nonmonic Newton term is strictly larger than the monic term, so H_(2N)(z) cannot vanish. This covers ALL roots without assuming simplicity. Centers modulo beta suffice, since centers congruent modulo beta differ by valuation at least beta>rho.

## 5. Exact boundary geometry and exclusion of strict interiors

On any closed rho-disk, the coefficientwise weight of N_k is at least T(k), by counting each residue class among k consecutive indices using its floor count. For 0<k<2N even, (3.2) is strict, since k cannot equal the odd integer N. Consequently

    W((2N-k)/2)+R(k)
      < W((2N-k)/2)+W(k)/2
      <= W(2N)/2=W(N).                                    (5.1)

Hence every such intermediate Newton term has weight strictly greater than W(N). The k=0 term is the nonzero constant

    A=w_(2N)/(q^2;q^2)_N, v(A)=W(N).

The monic term has weight T(2N)=W(N), since 2N is divisible by every relevant p-power, so all residue-class counts are exact. More explicitly, with z=-q^a+lambda Y and v(lambda)=rho, exactly M=2N/beta factors have index j congruent to a modulo beta. Each has leading term lambda Y, because all corresponding q^j-q^a have valuation >=beta>rho. All other factors have nonzero constant residual. Therefore

    H_(2N)(-q^a+lambda Y)/A -> 1+u_a Y^M, u_a!=0.          (5.2)

At any point strictly inside the disk, the M top-class factors have valuation >rho, making the monic term strictly larger than W(N). All intermediate terms remain strictly larger by (5.1), and the constant A is uniquely least. Thus there is NO root in a strict interior.

The standard root-counting form of the Newton polygon now says that the disk contains exactly M roots counted with multiplicity: the integral normalized polynomial (5.2) has a unit coefficient at degree M, all coefficients of higher degree in the maximal ideal, and nonzero constant residue. One can equivalently count its M roots of valuation zero after the Y substitution. The beta disks are disjoint and beta M=2N, in agreement with the independent all-root covering proof. The residual is a p^(r-h)-th power of a separable quadratic over an algebraically closed residue field. We do NOT apply simple-root lifting to that repeated power.

## 6. A unique ordinary-derivative pivot on every boundary

On a closed rho-disk, the (k,m) term of (2.2), k positive even, has weight at least

    W(2N)-[W((2N-k)/2)+R(m)+p^ord_p(k-m)].                 (6.1)

Set j=k-m and a=(2N-k)/2. Then m+2a+j=2N. By (3.2) and (3.4), the bracket is at most

    W(m)/2+W(a)+p^ord_p(j)
      <=W(2N-j)/2+p^ord_p(j)
      =N/2+2B+[p^ord_p(j)-W(j-1)/2].                       (6.2)

The reflection in the last equality is exact for 1<=j<=2N:

    W(2N-j)=W(2N)-N-W(j-1).

The last square bracket has its UNIQUE maximum p at j=p^2. At a fixed b=ord_p(j), strict increase of W shows that the unique maximizing j is p^b, and its value is

    g_b=p^b-b(p-1)p^(b-1)/2.

The consecutive differences are

    g_(b+1)-g_b = p^(b-1)(p-1)[p-b(p-1)]/2.

They are positive for b=0,1 and strictly negative for b>=2. The range includes b=2 because r>=2. This is a uniform maximization, not a finite search.

Equality in (6.2) also requires equality in (3.2) for m<2N, hence m=0 or N. If m=0 then j=k is even, so j=p^2 is impossible. If m=N and j=p^2, then k=N+p^2 is admissible and even. The remaining superadditivity equalities DO hold: (N-p^2)/2 has digits (p-1)/2 in positions 2 through r-1 and zero below, so doubling has no carries, and adding N has no carries. Thus the UNIQUE maximizing pair is

    (k,m)=(N+p^2,N),
    bracket maximum=W(N)/2+B+p.                           (6.3)

This is not the earlier pure-power pivot (p^2,0).

The surviving term is exactly

    C z^(p^2-1) N_N(z),
    C=w_(2N)/[(q^2;q^2)_((N-p^2)/2) w_N(1-q^(p^2))],
    v(C)=N+B-p.                                           (6.4)

On every boundary v(z+q^a)=rho, all residue counts for N_N are exact, and no factor can cancel: its factors have valuations rho or p-powers strictly below rho. Hence

    v(N_N)=T(N)=W(N)/2.

All other terms have strictly larger valuation by (6.1)-(6.3). The ordinary derivative therefore has exact valuation

    v(H_(2N)'(z))=N+B-p+W(N)/2=D_2

at EVERY point of EVERY boundary, in particular at all roots. More explicitly its disk residual is a nonzero multiple of Y^(N/beta), because N_N has that residual and z^(p^2-1) reduces to 1. Root residuals in (5.2) have Y!=0, so this derivative residual never vanishes on the root residual locus.

## 7. Transfer to original P derivatives, discriminants, and square kernels

The exact original coordinate identity is

    H_n(v0^2)=v0^n P_n(v0+v0^(-1)).

Modulo the maximal ideal, P_n reduces to X^n, so P_n has no roots at X=+/-2. Also H_n(0)=1. Over the relevant roots v0 reduces to +/-i, and both ordinary coordinate derivatives 2v0 and 1-v0^(-2) are units because p is odd. Differentiating the exact identity BEFORE evaluation at a root shows multiplicities and ordinary derivative valuations agree. Thus every P_n root is simple and its derivative has valuation D_2. The branch near i maps the stated P disks isometrically to the H disks.

Both original polynomials are monic, so their discriminants, up to sign, are products of their original derivatives at their roots. This proves the two discriminant valuations stated above.

All original recurrence edges 1-q^j, 1<=j<n, are nonzero. Consecutive P_n and P_(n-1) cannot share a root, since recurrence propagation would contradict P_0=1. The original ordinary Christoffel-Darboux identity at a P_n root gives

    K_n(xi)=P_n'(xi)P_(n-1)(xi)/w_(n-1).

Every factor on the right is nonzero. This proves precisely the algebraic-square kernel claim, without positivity, absolute values, real-rootedness, complex interlacing, or FFT arguments. Nonvanishing in the p-adic algebraic embedding transfers to the original algebraic polynomials, and to every characteristic-zero primitive embedding by Galois conjugacy.

## 8. Exact controls, attribution, and scope

The half-W inequality, full covering, strict-interior exclusion, and new derivative pivot are proved above uniformly. Finite checks are only transcription and falsification controls. The accompanying script independently reconstructs the original recurrences, verifies the Newton and ordinary CD identities over rational q, checks the digit and derivative inequalities on exact integer/rational grids, and reconstructs actual cyclotomic fields to verify the claimed translated residuals. The latter uses Z[q]/Phi_(p^s), then q=1+t coefficients of degree below e=phi(p^s), with exact weights j+e ord_p(c_j). Distinct j below e give distinct weights modulo e, so their minimum is exact even ABOVE the ramification threshold. No characteristic-p truncation or floating roots substitute for the actual field arithmetic.

The accepted pure-power and even low-digit reports and the fresh full-family low-digit review are retained byte-for-byte under sources and hash-bound in SOURCE_BINDINGS.json. They supply context and the previously checked original identities, but neither their degree family nor their derivative pivot is reused without proof. During this derivation a research collaborator suggested the cap-based covering inequality; the present proof verifies it independently through (3.2)-(3.7). The new unique pivot and the half-W digit proof were derived in this candidate work. This is route collaboration, not fresh independent acceptance. A separate auditor must bind the final frozen bytes before treating the candidate as accepted. MANIFEST.json and SEAL.sha256 bind the completed package. Global theorem scope and existing accepted packages are unchanged.
