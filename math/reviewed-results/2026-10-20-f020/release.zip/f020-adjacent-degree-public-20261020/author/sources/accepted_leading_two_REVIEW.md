# Independent adversarial audit: F020 leading-two family

Date: 20 October 2026 UTC.
Verdict: **ACCEPTED within the exact scope n = 2 p^r, p odd prime, r >= 2, s > r, q primitive of order p^s.**

This is a fresh audit of a completed proof, not participation in its derivation. The assignment explicitly identified the research collaborator's exploratory covering lead and asked for independent scrutiny. The author supplied the frozen package after the mathematical review and independent controls were underway. No mathematical revision was requested or needed. No external state was changed.

## 1. Frozen evidence and accepted scope

The reviewed source package is `author`.

- REPORT.md SHA-256: `232918eb924abc7a92f1a56610d7f96858440388023608c50e3d493bf4d791fc`.
- MANIFEST.json SHA-256 and package seal: `b407a5fe2b13690b5bcb6fc14d24e1496b27ec683be548cc6c68598ffa91fbb6`.
- All 12 files listed in that manifest were independently checked for byte length and SHA-256. The manifest seal matches SEAL.sha256.

Accepted conclusions, in the original normalizations P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1) and H_n(z)=sum_j [n choose j]_q z^j:

1. With N=p^r, h=floor(r/2), beta=p^h, and rho equal to beta/2 for even r or p^(h-1)(2p-1)/2 for odd r, all H_(2N) roots lie on the boundaries of the beta disjoint disks centered at -q^a, 0<=a<beta.
2. Every such disk contains exactly 2N/beta roots, with multiplicity allowed until the derivative argument proves simplicity.
3. Every original ordinary H derivative at a root has valuation D_2=3N/2+2B-p, where B=r(p-1)p^(r-1)/2. The same is true for the original ordinary P derivative at its roots.
4. Both original polynomials are squarefree, and both original discriminant valuations equal 2N D_2.
5. The original algebraic-square diagonal kernel sum_(j<2N) P_j(xi)^2/(q;q)_j is nonzero at every P_(2N) root xi.

This does not accept arbitrary leading digits, a proposed general n=c p^r Hermite mechanism, intermediate digits, arbitrary n<p^s, arbitrary odd-composite orders, or global F020/F023 closure. The previous low-digit assertion excluding v(X)=p/2 is not imported: central roots here really have valuation p/2 when r=2.

## 2. Exact identities and endpoint normalization

The both-parity geometric Newton expansion and its double-sum ordinary derivative identity are correct. I checked the generating-series derivation, including the logarithmic ordinary z derivative of E(zx)/E(-x). The even k=0 contribution is essential and is present. These are characteristic-zero identities before specialization, not identities obtained by differentiating a characteristic-p residual or by replacing d/dz with a q derivative.

All denominator exponents are positive and at most 2N<p^s. In particular q^2 remains of order p^s, and v((q^2;q^2)_u)=W(u). The endpoint valuation is v(1-q^(2N))=N, not 2N. This gives the exact reflection identities

- W(2N)-W(2N-2u)=N+W(2u-1), including u=N;
- W(2N-j)=W(2N)-N-W(j-1), including j=2N.

The frozen proof uses both endpoints correctly. W(2N)=2W(N) and W(N)=N+2B are also correct. No endpoint or missing constant-term correction is needed.

## 3. Half-W inequality, complement, and complete cover

The key cap is strictly between p^(h-1) and p^h for every allowed parameter, including p=3, r=2. Thus its truncated floor formula has strictly positive increments.

I independently derived, for h<=a<=r,

T(p^a)=p^(a-1)[h(p-1)+rho/p^(h-1)]
       =W(p^a)/2+(r-a)(p-1)p^(a-1)/2.

This proves the report's formula for R(p^a). For a<h, R(p^a)=0<W(p^a)/2. W and R are genuinely linear in the base-p digits, as follows directly from their floor formulas. Since m<=2p^r<p^(r+1), equality is possible precisely for m=0,N,2N. There is no missing high digit or exceptional p=3 case.

Each p-power in R divides 2N. Consequently its complement identity at 2N-1 is exact. The tail endpoint is R(2N-1)=W(N)-N+rho, because the final uncapped increment is N-rho. Combining this with the half-W inequality and superadditivity proves the full cover bound for every 1<=u<=N, not just its final endpoint. I checked that the superadditive step uses both 2W(u)<=W(2u) and W(2u)+W(2N-2u)<=W(2N).

Outside all proposed disks, the maximizing-center argument resolves possible equal-valuation cancellation: a cancellation raising a distance would contradict maximality. The strict consecutive-string estimate follows from residue-class counts and the positive top increment. It remains strict when delta<1 and when the top residue class is absent. Comparing every nonmonic Newton term with N_(2N) therefore gives strict domination, including k=0. This establishes the all-root cover without assuming squarefreeness or already knowing the number of roots in any disk.

The reduced center set has exactly beta disjoint disks. Congruent indices modulo beta give identical disks because their center distance has valuation at least beta>rho. Distinct indices modulo beta have center distance at most beta/p<rho.

## 4. Constant versus monic residual and boundary root counts

For 0<k<2N with k even, equality in R(k)<=W(k)/2 cannot occur: the only interior positive equality index is the odd integer N. Hence every intermediate term has weight strictly above W(N).

The two surviving terms are exactly:

- the actual constant A=w_(2N)/(q^2;q^2)_N, with valuation W(N);
- the actual monic term N_(2N), also with weight W(N).

After z=-q^a+lambda Y, v(lambda)=rho, exactly 2N/beta factors in the monic term have leading residual Y. All other factors have nonzero constant residue. Thus normalization by A gives exactly 1+u_a Y^(2N/beta), with u_a nonzero. There is no cancellation between these terms as polynomials: their surviving degrees differ. At a point strictly inside the disk the monic term's valuation rises, while the constant does not, excluding every strict-interior root.

The root count is valid despite the repeated residual. The translated normalized polynomial has unit coefficients at degrees 0 and M=2N/beta, all coefficients above M in the maximal ideal, and no coefficient of negative valuation. Its Newton polygon therefore has a horizontal initial segment of length M and no later horizontal continuation. It has exactly M roots of valuation zero and none of positive valuation. This argument counts multiplicity and does not invoke simple-root Hensel lifting of the repeated residual. The beta disk counts sum to 2N, consistently with the separate all-root cover.

## 5. Unique ordinary-derivative pivot and actual mixed characteristic

For j=k-m and a=(2N-k)/2, the bound

W(a)+R(m)+p^ord_p(j)
 <= W(2N-j)/2+p^ord_p(j)

is valid: first use half-W, then 2W(a)<=W(2a), then superadditivity. The reflected one-variable score is p^ord_p(j)-W(j-1)/2. At a fixed p-adic order its unique maximizing j is the smallest possible, p^b. The successive-score difference is positive for b=0,1 and negative for every b>=2. Hence j=p^2 is the unique global maximum, including the full range up to j=2N.

For equality in the double bound, m must be 0 or N. The m=0 possibility is excluded by k even and j=p^2 odd. The pair (k,m)=(N+p^2,N) is admissible, and the requisite superadditive equalities actually hold by the displayed no-carry digit expansions. Thus this is a truly unique pivot, not merely a candidate with the best known bound.

Its exact scalar C has valuation N+B-p. The remaining factor is z^(p^2-1)N_N(z). On every boundary N_N has valuation W(N)/2, and its residual is a nonzero multiple of Y^(N/beta). No individual factor can cancel on the boundary: rho is strictly between successive p-powers, whereas all center-difference valuations are p-powers. The z power has residue 1. All other ordinary-derivative summands have strictly higher weight. This proves D_2 and a nonzero derivative residual at every boundary point, not just at selected centers.

The polynomial residual forces Y nonzero at a root, precisely where the derivative residual is nonzero. The repeated characteristic-p root residual is therefore not used as a separability argument. The high-valuation scalar is retained in the original mixed-characteristic calculation. Nothing assumes D_2<e=v(p).

## 6. Original P normalization, discriminants, and kernel

The exact identity H_n(v0^2)=v0^n P_n(v0+v0^(-1)) has the correct original signs and factors. The branch v0 near i maps H disks isometrically to the stated X disks. Both coordinate derivatives 2v0 and 1-v0^(-2) are units because p is odd and v0 reduces to i. All P roots reduce to zero; none is at +/-2. H_n(0)=1 excludes the other singularity.

Differentiating this identity in characteristic zero and only then evaluating at a root kills the term proportional to P_n. Thus root derivative valuations transfer with only unit factors, even when D_2 exceeds the ramification threshold. No unjustified global P derivative residual, or bound comparing the discarded prefactor term with D_2 away from roots, is needed or claimed.

Both H_n and P_n are monic. Their discriminants are therefore, up to sign, products of the original ordinary derivatives at their roots, with no hidden leading coefficient. The value 2N D_2 follows.

The ordinary diagonal Christoffel-Darboux identity has the stated algebraic-square normalization. Consecutive P polynomials are coprime because every recurrence edge before degree 2N is nonzero. The kernel is the product of two nonzero factors divided by w_(2N-1), which is nonzero. No positivity, absolute-value square, or complex interlacing claim is used. Algebraic nonvanishing transfers to the other characteristic-zero primitive embeddings.

## 7. Independent controls, separate from the uniform proof

The review scripts do not import the author checker. The mathematical argument above, not the finite controls, establishes the unlimited family.

`check_independent.py` checks all m from 0 through 2N in 22 parameter pairs, totaling 181,246 m values; all cover indices; and the entire one-variable derivative range. It enumerates the complete double sum in 10 parameter pairs, including p=3 through r=5 and p=5 through r=4. The equality sets and the unique pivot match exactly.

For actual cyclotomic fields, it independently constructs the original Gaussian coefficients by their Pascal recursion in the full cyclic group algebra Z[q]/(q^(p^s)-1). Only at valuation extraction are coefficients reduced modulo Phi_(p^s), then converted to q=1+t. This differs from the author's direct reduced-ring H recurrence. Exact coefficient weights are j+e ord_p(c_j), with j<e; their distinct residues modulo e make the minimum exact. Units use p/t^e reducing to -1. Ordinary derivative coefficients explicitly include the p-adic valuation and unit of the integer differentiation factor.

Seventeen translated centers passed in the five field cases:

- p=3,r=2,s=3: D_2=45/2, e=18;
- p=3,r=2,s=4: D_2=45/2, e=54;
- p=3,r=3,s=4: D_2=183/2, e=54;
- p=5,r=2,s=3: D_2=145/2, e=100;
- p=3,r=4,s=5: D_2=669/2, e=162.

These tests verify the actual nonzero units of both polynomial residual coefficients against the exact constant and monic products, and the actual sole derivative residual coefficient against the pivot product. They do not merely check likely residual degrees. Three cases explicitly lie above the ramification threshold.

`check_formal_identities.py` independently checks both-parity Newton expansion, the N and H ordinary derivative identities, the original Laurent H/P normalization, and the full algebraic-square diagonal CD polynomial identity for degrees 1 through 18 at q=2,-2,2/3. All 54 exact rational q-degree pairs pass. These are transcription controls; the generating-series identities and recurrence arguments are verified separately above.

## 8. Final disposition

No mathematical defect was found in the frozen statement or proof. The proof closes the complete leading-two gate n=2p^r uniformly under the stated primitive odd-prime-power assumptions, with actual mixed-characteristic ordinary derivatives and the original square kernel. This scoped acceptance is bound to the exact source identities. Wider leading-digit or global claims remain unaccepted by this review.
