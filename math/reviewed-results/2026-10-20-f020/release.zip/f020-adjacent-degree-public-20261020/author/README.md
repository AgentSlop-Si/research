# F020 adjacent-degree partial theorem and mechanism obstruction

This candidate concerns only n=2p^r+1, odd p, r>=2, s>r, characteristic-zero primitive p^s root q, original Rogers–Szego/q-Hermite polynomials, ordinary derivatives, and the original algebraic-square CD kernel.

REPORT.md proves the full simple-root/kernel gate for r>=3. For r=2 it proves the complete root geometry, the exact zero root, and noncentral simplicity, then exhibits the actual central derivative cancellation that blocks this mechanism. It does NOT prove or disprove the full r=2 theorem.

Run python check_controls.py to reproduce bounded exact controls. They are not the proof. CONTROL_RESULTS.json and CONTROL_RUN.log record the author run. The script writes those two run artifacts only when invoked with shell log redirection as documented in REVIEW_REQUEST.md.

SOURCE_BINDINGS.json binds actual restored public source bytes. MANIFEST.json and SEAL.sha256 bind the frozen candidate. No prior sources or external services were modified.
