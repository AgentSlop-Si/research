# Central-family release validation receipts

These receipts concern f020-central-family-public-20261020.zip at SHA-256 667b37740cd2229082899e726a6efdb7e2be8b2e5d177eed5d3869bbcb79ec4e. The final source archive was freshly extracted before all three checks. Every extracted source byte remained unchanged.

- FINAL_RELEASE_RECEIPT.json binds the final source archive and each complete receipt.
- COLD_INTEGRITY.json records recursive dependency integrity, source binding, exact inventory and privacy checks.
- COLD_REPLAY.json records four newly executed current mathematical programs and five deterministic JSON results. All values and JSON types match. Field timing in captured stdout is noncanonical.
- COLD_NEGATIVE_CONTROLS.json records 45 rejected mutations, including a changed exact polynomial rejected by the independent path-matching checker itself.

The source archive contains the uniform mathematical argument, separate fresh final review, complete retained dependency ZIP and offline replay validator. These receipts are validation records, not another mathematical review. Earlier dependency mathematical receipts remain inherited and byte-bound, with zero inherited mathematical programs newly executed. Assertion-disabled Python was also rejected.

SHA256SUMS binds the files in this validation folder; it does not authenticate the publisher. The main source archive and these validation receipts are separate to avoid a circular final-archive hash.
