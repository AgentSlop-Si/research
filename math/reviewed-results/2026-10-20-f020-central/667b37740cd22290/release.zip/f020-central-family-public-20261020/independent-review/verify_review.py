#!/usr/bin/env python3
"""Verify this review, optionally bind/replay the exact frozen author source.
The --author directory must contain the author's original unprojected manifest.
All replay writes go to temporary copies. No original package is modified.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(root):
 m=json.loads((root/'MANIFEST.json').read_text())
 for row in m['files']:
  p=root/row['path'];assert p.is_file(),row['path']
  assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],row['path']
 return len(m['files'])
def run(cmd):subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--author',type=Path);ap.add_argument('--replay',action='store_true');args=ap.parse_args()
 count=manifest(ROOT);v=json.loads((ROOT/'VERDICT.json').read_text())
 assert (ROOT/'SEAL.sha256').read_text().split()[0]==digest(ROOT/'MANIFEST.json')
 out={'review_manifest_entries_verified':count,'review_manifest_sha256':digest(ROOT/'MANIFEST.json'),'status':v['status']}
 if args.author:
  a=args.author.resolve();assert digest(a/'MANIFEST.json')==v['candidate_manifest_sha256'];out['author_manifest_entries_verified']=manifest(a)
  assert digest(a/'REPORT.md')==v['candidate_report_sha256'];assert digest(a/'THREE_CERTIFICATE.json')==v['candidate_certificate_sha256']
 if args.replay:
  assert args.author,'--replay requires --author'
  with tempfile.TemporaryDirectory(prefix='central-family-review-') as td:
   temp=Path(td);a=temp/'author';c=temp/'controls';shutil.copytree(args.author,a);shutil.copytree(ROOT/'controls',c)
   run([sys.executable,str(a/'check_controls.py')])
   for name in ['CONTROL_RESULTS.json','THREE_CERTIFICATE.json']:assert (a/name).read_bytes()==(args.author/name).read_bytes(),name
   run([sys.executable,str(c/'check_independent_certificate.py'),str(a/'THREE_CERTIFICATE.json')])
   run([sys.executable,str(c/'check_adversarial_gates.py')])
   run([sys.executable,str(c/'inspect_central.py'),'3,3','3,4','3,5','5,3','5,4','7,3'])
   for name in ['INDEPENDENT_FIXED_POLYNOMIAL_CERTIFICATE.json','ADVERSARIAL_GATES.json','independent_centered_coefficients.json']:
    assert (c/name).read_bytes()==(ROOT/'controls'/name).read_bytes(),name
   out['cold_author_and_independent_replays']='PASS; all five deterministic result files byte-identical'
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
