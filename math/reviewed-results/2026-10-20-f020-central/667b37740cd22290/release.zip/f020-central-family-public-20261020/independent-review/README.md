# Fresh central-family review

This independently accepts the exact central-family author candidate bound in VERDICT.json, within the scope explained in INDEPENDENT_REVIEW.md. It does not modify prior accepted results or imply a wider F020 closure.

Verify this review alone:

    python verify_review.py

Verify the exact frozen author source as well:

    python verify_review.py --author /path/to/original/author

Cold-replay both the author controls and the independent controls:

    python verify_review.py --author /path/to/original/author --replay

The source directory must contain the original author MANIFEST.json with the exact digest in VERDICT.json. If a public package projects locator-only metadata, supply its preserved frozen-source copy for this check. Replays operate only in temporary writable copies. Python and SymPy 1.14.0 reproduce the recorded results; the three independent control programs themselves use only the Python standard library.

The report contains the uniform audit. Finite controls do not prove an unlimited family. The independently reconstructed fixed P_19 integer certificate is different: four exact polynomial identities, coupled with the explicit all-e>=18 bound, prove every s at p=3.

SOURCE_AND_REPLAY_VERIFICATION.json records the accepted dependencies and byte-identical cold replay. The controls include a direct 6,765-matching reconstruction, all-term Newton gaps, grouped-product tests, six full exact cyclotomic coefficient reconstructions, and adversarial derivative/gap/sign checks. No essential repair was supplied by this reviewer.
