# Central lift at n=2p²+1

Author candidate pending a fresh independent whole-proof review. REPORT.md is the complete mathematical argument. It resolves the previously omitted central 2p nonzero roots for all odd p and all s>2 without changing the original recurrence, derivative, or kernel.

Run `python check_controls.py` in a writable copy, not in this frozen directory. It requires Python 3 and the exact SymPy version in requirements.txt. The p=3 certificate is an exact fixed-polynomial identity with an explicit bound uniform in all e>=18. Other finite field and integer controls are auxiliary only.

SOURCE_BINDINGS.json binds the unchanged accepted partial package and independent audit. MANIFEST.json hashes every release file other than itself and SEAL.sha256. SEAL.sha256 binds the manifest. Nothing here is externally published or committed.
