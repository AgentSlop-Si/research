#!/usr/bin/env python3
"""Offline byte validation, bounded current-control replay and mutation tests."""
from pathlib import Path, PurePosixPath
import argparse, copy, hashlib, io, json, math, os, re, shutil, stat, subprocess, sys, tempfile, zipfile
ROOT=Path(__file__).resolve().parent
PACKAGE='f020-central-family-public-20261020'
ANCHORS={'README.md': 'd0596abfc2daf9c1165c157717f3bfd96c21cc2a25a53b34c9ce8b8a6d9425ac', 'ATTRIBUTION.md': 'de0ee2212864162b4896e254fc4a024114e5823ce6b8af93271e42a54c732b2a', 'SCOPE.json': '4d03b625fd515b2c7b76a3b877900644f711e4dc2a918302c20cceed24bba12b', 'REPLAY_CASES.json': '2223590e23bd52243ebce2b916f11e662bd6eca3903c27138365db8c403607a3', 'requirements.txt': '25f9f1fb1988b230147a1d3092d34e09c069eb7a6c6d6df46b3973b9f2d36efc', 'provenance/SOURCE_LEDGER.json': 'e11cb031be0ffaf363e4ef6e1fddb414e14261c89b825758aa750a6926462d71', 'provenance/DEPENDENCY.json': '0b0f0cf882671669c2daa41a7eb2a3ae4ceaae7634ba553d84e7539af43e2f67', 'provenance/ACCEPTANCE_BINDING.json': 'fe73eb0c79f29516d431f453950cb0e8018320389d585551f69a1b7f1581d8aa', 'author/MANIFEST.json': '072e4134daea3f759d79550c891027abb0410ed38aac6826635fee085f730147', 'author/REPORT.md': '192f8509aebe5c3dd23060faae8702789fa59e6aa09f19d26a5be8757cc75aed', 'independent-review/MANIFEST.json': 'b7583a6324271df5defc71514c871562a88c62cfb69ed736b62d3814abebff47', 'independent-review/INDEPENDENT_REVIEW.md': 'ca3f976541d08b40bf427fe0177a291549f3443ffa60ca6e14adabe16b5ea78f', 'independent-review/VERDICT.json': '638696cd9f7620d9e477e610d7a46de7601b81c63b9ed6e0e72e96c4ffc4c53c'}
SOURCE_MANIFESTS={'author': '072e4134daea3f759d79550c891027abb0410ed38aac6826635fee085f730147', 'independent-review': 'b7583a6324271df5defc71514c871562a88c62cfb69ed736b62d3814abebff47'}
ZIP_SHA='3cf2c2567755df12b394c8c28feb0faa54ed304d1f46cd070ceec3bb344ee600'
DIGEST=re.compile(r'[0-9a-f]{64}\Z')
def need(x,msg):
 if not x:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def desc(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
def exact(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if type(a)is list:return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def pairs(xs):
 d={}
 for k,v in xs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def loads(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON constant')))
def read(p):return loads(p.read_text('utf-8'))
def keys(x,ks,label):need(type(x)is dict and x.keys()==set(ks),label+' fields')
def uint(x,label):need(type(x)is int and x>=0,label+' integer type/range')
def identity(x):
 keys(x,('bytes','sha256'),'identity');uint(x['bytes'],'bytes');need(type(x['sha256'])is str and DIGEST.fullmatch(x['sha256'])is not None,'digest')
def route(x):
 need(type(x)is str and bool(x) and '\\' not in x and '\0' not in x,'path type')
 p=PurePosixPath(x);need(not p.is_absolute() and str(p)==x and all(k not in ('','.','..') for k in p.parts),'unsafe route')
 need('__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'),'bytecode prohibited');return x
def inventory(root):
 actual=set()
 for p in root.rglob('*'):
  need(not p.is_symlink(),'symlink prohibited')
  if p.is_file():actual.add(route(p.relative_to(root).as_posix()))
  else:need(p.is_dir(),'nonregular member')
 return actual
def manifest(root):
 actual=inventory(root);m=read(root/'MANIFEST.json');s=read(root/'SEAL.json')
 keys(m,('schema_version','package','files'),'manifest');need(type(m['schema_version'])is int and m['schema_version']==1 and m['package']==PACKAGE,'manifest schema/name');need(type(m['files'])is list,'manifest list')
 keys(s,('algorithm','manifest','manifest_sha256','file_count'),'seal');need(s['algorithm']=='SHA-256' and s['manifest']=='MANIFEST.json','seal scheme');uint(s['file_count'],'file count');need(type(s['manifest_sha256'])is str and sha((root/'MANIFEST.json').read_bytes())==s['manifest_sha256'],'seal hash')
 names=[]
 for e in m['files']:
  keys(e,('path','bytes','sha256'),'manifest member');route(e['path']);identity({k:e[k] for k in ('bytes','sha256')});names.append(e['path'])
  need(e['path'] not in ('MANIFEST.json','SEAL.json'),'manifest recursion');need(exact(desc(root/e['path']),{k:e[k] for k in ('bytes','sha256')}),'member identity: '+e['path'])
 need(names==sorted(set(names)) and actual==set(names)|{'MANIFEST.json','SEAL.json'} and len(actual)==s['file_count'],'exact inventory');return actual

def privacy(name,b):
 text=b.decode('utf-8');tokens=['/'+x+'/' for x in ('workspace','home','tmp','root')]+['cloud'+'_threads','collaboration'+'.','mcp'+'__','user_message'+'.','/'+'agent_notes'+'/','/'+'user_notes'+'/','dream'+'_notes','delivery'+'_context','thread'+'_id','lib'+'file_','codex'+':','chatgpt'+'.com']
 need(not any(t in name+'\n'+text for t in tokens),'private locator or coordination marker: '+name)
 need(re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',text)is None,'private key')
 need(re.search(r'(?:gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{32,})',text)is None,'credential marker')
 if name.endswith('.json'):loads(text)
def unzip_checked(raw,dst):
 names=[]
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  need(len(z.infolist())<=3000 and sum(i.file_size for i in z.infolist())<=50_000_000,'archive size')
  for i in z.infolist():
   need(not i.is_dir() and not i.flag_bits&1,'archive directory/encryption');names.append(route(i.filename));need(stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG),'archive file type')
  need(len(names)==len(set(names)),'archive duplicate')
  for i in z.infolist():
   p=dst/i.filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(i))
 return names

def environment():
 e=os.environ.copy();e['PYTHONDONTWRITEBYTECODE']='1';e.pop('PYTHONOPTIMIZE',None);return e

def source_ledger(root):
 l=read(root/'provenance/SOURCE_LEDGER.json');need(type(l['schema_version'])is int and l['schema_version']==1,'ledger schema');by={};dest=set();counts={'verbatim':0,'public_projection':0,'excluded':0}
 for e in l['files']:
  keys(e,('source_set','source_path','original','export_path','exported','mode','reason','changes'),'ledger row');need(e['source_set'] in SOURCE_MANIFESTS,'source set');route(e['source_path']);identity(e['original']);k=(e['source_set'],e['source_path']);need(k not in by,'duplicate source');by[k]=e
  need(e['mode'] in counts and type(e['reason'])is str and bool(e['reason']) and type(e['changes'])is list,'ledger mode');counts[e['mode']]+=1
  if e['mode']=='excluded':need(k==('author','REVIEW_REQUEST.md') and e['export_path']is None and e['exported']is None and e['changes']==[],'unexpected omission');continue
  route(e['export_path']);identity(e['exported']);need(e['export_path'] not in dest,'duplicate export');dest.add(e['export_path']);need(exact(desc(root/e['export_path']),e['exported']),'export identity')
  if e['mode']=='verbatim':need(exact(e['original'],e['exported']) and e['changes']==[],'verbatim mismatch')
  else:
   need(k==('author','SOURCE_BINDINGS.json') and len(e['changes'])==6,'unexpected projection');delta=0
   for c in e['changes']:
    keys(c,('kind','source_text_bytes','source_text_sha256','replacement','count'),'projection');need(c['kind']=='public_dependency_locator' and type(c['count'])is int and c['count']==1,'projection kind/count');uint(c['source_text_bytes'],'locator bytes');need(type(c['source_text_sha256'])is str and DIGEST.fullmatch(c['source_text_sha256']),'locator digest');need(type(c['replacement'])is str and (root/e['export_path']).read_text().count(c['replacement'])==1,'projected locator');delta+=len(c['replacement'].encode())-c['source_text_bytes']
   need(e['original']['bytes']+delta==e['exported']['bytes'],'projection byte accounting')
 for label,h in SOURCE_MANIFESTS.items():
  need(sha((root/label/'MANIFEST.json').read_bytes())==h,'source manifest binding');need((root/label/'SEAL.sha256').read_text().split()==[h,'MANIFEST.json'],'source manifest seal');m=read(root/label/'MANIFEST.json');expected={'MANIFEST.json','SEAL.sha256'}
  for e in m['files']:
   route(e['path']);want={k:e[k] for k in ('bytes','sha256')};identity(want);need(e['path'] not in expected,'source duplicate');expected.add(e['path']);need(exact(by[(label,e['path'])]['original'],want),'source inventory identity')
  need({p for lab,p in by if lab==label}==expected,'source inventory exactness')
 return counts

def dependency(root,run_nested=True):
 d=read(root/'provenance/DEPENDENCY.json');raw=(root/route(d['archive'])).read_bytes();need(sha(raw)==ZIP_SHA and len(raw)==d['bytes'],'dependency archive binding')
 with tempfile.TemporaryDirectory(prefix='central-dependency-') as t:
  out=Path(t);names=unzip_checked(raw,out);need(len(names)==d['archive_regular_files'],'dependency file count');dep=out/route(d['root']);need(sha((dep/'MANIFEST.json').read_bytes())==d['root_manifest_sha256'],'dependency root manifest');need(sha((dep/'SEAL.json').read_bytes())==d['root_seal_sha256'],'dependency root seal')
  for e in read(root/'author/SOURCE_BINDINGS.json')['bindings']:
   route(e['path']);identity({k:e[k] for k in ('bytes','sha256')});need(exact(desc(out/e['path']),{k:e[k] for k in ('bytes','sha256')}),'imported source identity')
  result=None
  if run_nested:
   p=subprocess.run([sys.executable,str(dep/'verify.py'),'--integrity-only'],cwd=out,env=environment(),capture_output=True,text=True,timeout=240);need(p.returncode==0,'recursive dependency integrity: '+p.stderr[-1000:]);result=loads(p.stdout);need(result['integrity']['status']=='PASS','recursive status')
 return {'status':'PASS','archive_files':len(names),'source_bindings_verified':6,'inherited_mathematical_programs_executed':0,'recursive_integrity':result}

def integrity(root=ROOT,run_nested=True):
 need(sys.flags.optimize==0,'assertion-enabled Python required');actual=manifest(root)
 for rel,h in ANCHORS.items():need(sha((root/rel).read_bytes())==h,'fixed content anchor: '+rel)
 for rel in actual:
  if not rel.endswith('.zip'):privacy(rel,(root/rel).read_bytes())
 counts=source_ledger(root);s=read(root/'SCOPE.json');need(s['status']=='ACCEPTED_WITHIN_EXACT_R2_CENTRAL_FAMILY_SCOPE','acceptance scope')
 for k in ('full_adjacent_r2_family','ordinary_characteristic_zero_derivatives','original_algebraic_square_kernel'):need(s[k]is True,'scope type/value '+k)
 for k in ('all_root_constant_derivative_valuation','arbitrary_n_or_digit_patterns','odd_composite_orders','global_f020_f023_closure','fft_speed_or_complexity_claim','novelty_claim','external_publication_performed'):need(s[k]is False,'scope type/value '+k)
 a=read(root/'provenance/ACCEPTANCE_BINDING.json');need(a['author_manifest_sha256']==SOURCE_MANIFESTS['author'] and a['review_manifest_sha256']==SOURCE_MANIFESTS['independent-review'],'review candidate binding');need(a['essential_fix_contributed_by_acceptance_reviewer']is False and a['proof_revisions_required']is False,'review finality')
 v=read(root/'independent-review/VERDICT.json');need(v['status']==a['review_verdict']=='ACCEPTED_WITHIN_EXACT_STATED_SCOPE' and v['candidate_manifest_sha256']==SOURCE_MANIFESTS['author'] and v['candidate_report_sha256']==a['author_report_sha256'],'exact review verdict');need(v['independence']['fresh_whole_argument_review']is True and v['independence']['essential_repairs_supplied']is False and v['independence']['author_proof_changed']is False and v['independence']['additional_fresh_review_required_for_reviewer_contribution']is False,'independent review conditions')
 dep=dependency(root,run_nested)
 return {'status':'PASS','public_files':len(actual),'source_modes':counts,'fixed_content_anchors':len(ANCHORS),'privacy':'PASS','strict_json_and_inventory':'PASS','dependency':dep,'network_used':False,'new_mathematical_review':False}

def compare(got,expected):need(exact(got,expected),'strict mathematical replay mismatch')
def controls(root=ROOT):
 need(sys.flags.optimize==0,'assertion-enabled Python required');import sympy;need(sympy.__version__=='1.14.0','SymPy 1.14.0 required');before={p:desc(root/p) for p in inventory(root)};cfg=read(root/'REPLAY_CASES.json');rows=[]
 need(cfg['inherited_mathematical_programs_executed']==0 and type(cfg['inherited_mathematical_programs_executed'])is int and cfg['type_strict']is True,'replay policy')
 with tempfile.TemporaryDirectory(prefix='central-current-replay-') as t:
  base=Path(t)
  for c in cfg['cases']:
   dst=base/route(c['id']);dst.mkdir()
   for file in c['inputs']:
    route(file['source']);route(file['destination']);p=dst/file['destination'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/file['source'],p)
   need(type(c['arguments'])is list and all(type(a)is str for a in c['arguments']),'replay arguments');p=subprocess.run([sys.executable,str(dst/route(c['entrypoint']))]+c['arguments'],cwd=dst,env=environment(),capture_output=True,text=True,timeout=600);need(p.returncode==0,'replay failed: '+c['id']+' '+p.stderr[-2000:]);outs=[]
   for o in c['outputs']:
    got=read(dst/route(o['generated']));expected=read(root/route(o['expected']));compare(got,expected);outs.append({'generated':o['generated'],'expected':o['expected'],'replayed':desc(dst/o['generated']),'frozen':desc(root/o['expected']),'exact_type_and_value_match':True})
   need(not list(dst.rglob('*.pyc')) and not list(dst.rglob('__pycache__')),'bytecode generated');rows.append({'id':c['id'],'outputs':outs,'stdout':p.stdout,'stderr':p.stderr})
 need(exact(before,{p:desc(root/p) for p in inventory(root)}),'package modified by replay')
 return {'status':'PASS','new_program_count':len(rows),'new_programs':rows,'inherited_mathematical_programs_executed':0,'package_unchanged':True,'python':sys.version.split()[0],'sympy':sympy.__version__}

def reseal(root):
 m=read(root/'MANIFEST.json')
 for e in m['files']:
  if (root/e['path']).is_file():e.update(desc(root/e['path']))
 (root/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');s=read(root/'SEAL.json');s['manifest_sha256']=sha((root/'MANIFEST.json').read_bytes());(root/'SEAL.json').write_text(json.dumps(s,indent=2)+'\n')
def negatives(root=ROOT):
 tests=[]
 def reject(name,fn):
  try:fn()
  except (ValueError,OSError,KeyError,TypeError,zipfile.BadZipFile):tests.append({'name':name,'rejected':True});return
  raise ValueError('negative control accepted: '+name)
 def changed(name,fn):
  with tempfile.TemporaryDirectory(prefix='central-negative-') as t:
   dst=Path(t)/'release';shutil.copytree(root,dst);fn(dst);reject(name,lambda:integrity(dst,False))
 def field(r,path,key,value):
  d=read(r/path);d[key]=value;(r/path).write_text(json.dumps(d));reseal(r)
 def member(r,key,value):
  p=r/'MANIFEST.json';m=read(p);m['files'][0][key]=value;p.write_text(json.dumps(m));s=read(r/'SEAL.json');s['manifest_sha256']=sha(p.read_bytes());(r/'SEAL.json').write_text(json.dumps(s))
 changed('corrupt manuscript byte',lambda r:(r/'author/REPORT.md').write_bytes((r/'author/REPORT.md').read_bytes()+b' '))
 changed('rehashed changed manuscript',lambda r:((r/'author/REPORT.md').write_bytes((r/'author/REPORT.md').read_bytes()+b' '),reseal(r)))
 changed('missing certificate',lambda r:(r/'author/THREE_CERTIFICATE.json').unlink())
 changed('unlisted member',lambda r:(r/'EXTRA.txt').write_text('extra'))
 changed('bytecode cache',lambda r:((r/'__pycache__').mkdir(),(r/'__pycache__/x.pyc').write_bytes(b'x')))
 for key,value,name in [('bytes',True,'boolean bytes'),('bytes','1','string bytes'),('bytes',-1,'negative bytes'),('path','../bad','traversal path'),('path','/bad','absolute path'),('sha256','A'*64,'uppercase digest')]:changed(name,lambda r,k=key,v=value:member(r,k,v))
 changed('boolean manifest schema',lambda r:field(r,'MANIFEST.json','schema_version',True))
 for k,v in [('global_f020_f023_closure',True),('fft_speed_or_complexity_claim',True),('novelty_claim',True),('full_adjacent_r2_family',1)]:changed('rehashed scope '+k,lambda r,k=k,v=v:field(r,'SCOPE.json',k,v))
 changed('rehashed acceptance contribution',lambda r:field(r,'provenance/ACCEPTANCE_BINDING.json','essential_fix_contributed_by_acceptance_reviewer',True))
 changed('rehashed private locator',lambda r:((r/'README.md').write_text((r/'README.md').read_text()+'\n/'+'workspace'+'/private\n'),reseal(r)))
 changed('rehashed source projection',lambda r:((r/'author/SOURCE_BINDINGS.json').write_bytes((r/'author/SOURCE_BINDINGS.json').read_bytes()+b' '),reseal(r)))
 changed('rehashed dependency corruption',lambda r:((r/'dependencies/f020-adjacent-degree-public-20261020.zip').write_bytes(b'bad'),reseal(r)))
 changed('duplicate JSON key',lambda r:((r/'SCOPE.json').write_text((r/'SCOPE.json').read_text().replace('"schema_version": 1,','"schema_version": 1, "schema_version": 1,',1)),reseal(r)))
 def sym(r):
  p=r/'README.md';p.unlink();p.symlink_to('ATTRIBUTION.md')
 changed('symlink',sym)
 for kind in ['traversal','absolute','duplicate','symlink','bytecode']:
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:
   name={'traversal':'../bad','absolute':'/bad','duplicate':'ok','symlink':'link','bytecode':'__pycache__/a.pyc'}[kind]
   if kind=='symlink':
    i=zipfile.ZipInfo(name);i.create_system=3;i.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(i,'other')
   else:z.writestr(name,'x')
   if kind=='duplicate':
    import warnings
    with warnings.catch_warnings():warnings.simplefilter('ignore');z.writestr(name,'y')
  with tempfile.TemporaryDirectory(prefix='central-zip-negative-') as t:reject('unsafe ZIP '+kind,lambda:unzip_checked(b.getvalue(),Path(t)))
 reject('duplicate JSON parser key',lambda:loads('{"x":1,"x":1}'));reject('nonfinite JSON parser number',lambda:loads('{"x":NaN}'))
 reject('privacy scanner rejects private locator',lambda:privacy('sample.txt',('/'+'workspace'+'/private').encode()))
 reject('privacy scanner rejects coordination marker',lambda:privacy('sample.txt',('collaboration'+'.send_message').encode()))
 for case in read(root/'REPLAY_CASES.json')['cases']:
  for o in case['outputs']:
   value=read(root/o['expected']);changed_value=copy.deepcopy(value)
   if type(value)is dict:changed_value['undeclared_field']=True
   else:changed_value.append(None)
   reject('replay extra field/member '+case['id']+'/'+o['generated'],lambda a=changed_value,b=value:compare(a,b))
 for a,b,n in [(True,1,'boolean versus integer'),(1.0,1,'float versus integer'),('1',1,'string versus integer'),([],{},'list versus object'),({'x':1},{'x':2},'mathematical coefficient mutation'),([1,2],[2,1],'reordered coefficient list')]:reject('strict replay '+n,lambda a=a,b=b:compare(a,b))
 cert=read(root/'author/THREE_CERTIFICATE.json');bad=copy.deepcopy(cert);bad['coefficients'][0]['integer_coefficients']['25']+=1;reject('p3 exact coefficient changed',lambda:compare(bad,cert))
 result=read(root/'author/CONTROL_RESULTS.json');bad=copy.deepcopy(result);bad['finite_original_cyclotomic_controls'][2]['normalized_V_jets'][1][1]=0;reject('nonzero first derivative unit replaced by zero',lambda:compare(bad,result))
 # Challenge the independent certificate checker itself, not just a hash/comparator.
 case=next(c for c in read(root/'REPLAY_CASES.json')['cases'] if c['id']=='independent_certificate')
 with tempfile.TemporaryDirectory(prefix='central-certificate-mutant-') as t:
  dst=Path(t)
  for file in case['inputs']:
   p=dst/file['destination'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/file['source'],p)
  target=dst/'THREE_CERTIFICATE.json';bad=read(target);bad['coefficients'][0]['integer_coefficients']['25']+=1;target.write_text(json.dumps(bad))
  p=subprocess.run([sys.executable,str(dst/case['entrypoint'])]+case['arguments'],cwd=dst,env=environment(),capture_output=True,text=True,timeout=180)
  need(p.returncode!=0 and 'AssertionError' in p.stderr,'independent checker accepted altered exact polynomial');tests.append({'name':'independent path-matching checker rejects changed author polynomial','rejected':True})
 return {'status':'PASS','negative_controls':tests,'rejected':len(tests),'package_unchanged':True,'new_mathematical_review':False}

def main():
 ap=argparse.ArgumentParser();g=ap.add_mutually_exclusive_group();g.add_argument('--integrity-only',action='store_true');g.add_argument('--controls',action='store_true');g.add_argument('--negative-controls',action='store_true');args=ap.parse_args();result=integrity()
 if args.controls:result={'status':'PASS','integrity':result,'controls':controls()}
 if args.negative_controls:result={'status':'PASS','integrity':result,'negative_controls':negatives()}
 print(json.dumps(result,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:print('FAIL: '+str(e),file=sys.stderr);sys.exit(1)
