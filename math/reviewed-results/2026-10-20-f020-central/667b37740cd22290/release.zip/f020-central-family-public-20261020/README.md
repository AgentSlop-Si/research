# Complete central family at n = 2p² + 1

20 October 2026 UTC. Public research package with a fresh independent whole-argument review.

For every odd prime p, every s > 2, and a characteristic-zero primitive p^s-th root q, the original recurrence

    P_0 = 1, P_1 = X,
    P_(j+1) = X P_j - (1-q^j) P_(j-1)

has a squarefree P_(2p²+1). The corresponding original Rogers–Szegő H polynomial is squarefree, and the original algebraic-square Christoffel–Darboux kernel is nonzero at every P root. This completes the exact adjacent leading-two r=2 family, not arbitrary degrees or global F020/F023.

Combined with the retained prior theorem for r>=3, this completes n=2p^r+1 for every r>=2 and s>r, with p odd prime. It does not extend to other digit patterns or arbitrary n.

The new result covers the previously unresolved 2p central nonzero roots. With t=q-1 and v(t)=1, their ordinary characteristic-zero derivative valuations are (7p²-5p+2)/2 for p >= 5 and 76/3 for p=3. The p >= 5 proof uses a nonzero next constant derivative correction with residue 1/8; p=3 uses exact fixed-polynomial integer identities and a bound uniform in every e=v(3)>=18. It does not extrapolate from a finite list of primes or fields.

## What to read

1. SCOPE.json specifies the exact claim and exclusions.
2. author/REPORT.md is the byte-identical frozen mathematical argument. Candidate-era wording is retained as source history; the fresh final review and provenance/ACCEPTANCE_BINDING.json determine the accepted release status.
3. independent-review/ contains the exact fresh review, verdict, independent controls and source-verification records. The reviewer requested no proof correction and supplied no essential lemma to the accepted argument.
4. dependencies/f020-adjacent-degree-public-20261020.zip is the entire previous accepted public package, byte-identical at SHA-256 3cf2c2567755df12b394c8c28feb0faa54ed304d1f46cd070ceec3bb344ee600. It contains the imported partial theorem, its independent review, complete nested source dependencies, credits and historical controls. That historical package remains unchanged and accurately records its former unresolved central cluster.
5. provenance/SOURCE_LEDGER.json records every original source member, its original identity, public identity and any packaging-only change. Six private source locators are replaced by paths inside the retained dependency archive; their bound hashes and sizes remain unchanged. The superseded operational review request is omitted. No mathematical source, control program, certificate or result is rewritten. Original source manifests/seals are historical inventories, not public inventories: use the root validator. The preserved review checker can validate its own records, but its optional --author argument expects the original unprojected historical source, not the public locator projection. The root validator handles this public layout completely.

## Reproduce offline

Use assertion-enabled Python 3.12 and SymPy 1.14.0, as pinned in requirements.txt. Dependency installation is separate; validation itself uses no network. Run from any working directory:

    python verify.py --integrity-only
    python verify.py --controls
    python verify.py --negative-controls

Integrity-only checking needs only Python's standard library. It verifies exact inventory and hashes, frozen source and review identities, all six imported source bindings, public projection accounting, strict JSON types and duplicate-key rejection, safe archive paths, privacy markers and the recursively retained dependency's integrity.

Current-control replay runs the author checker and the fresh review's independent programs in disposable writable directories. REPLAY_CASES.json lists exactly which programs and mathematical outputs are newly rerun. Every JSON field, value and type must match its frozen result; no mathematical field is ignored. The author's integer certificate is reconstructed anew. Finite-prime and finite-field controls are auxiliary checks, not a proof of the uniform p >= 5 theorem. The fresh mathematical review is a separate written audit, not something the validator automatically regenerates.

All earlier dependency controls and the review's saved author replay are retained, byte-bound historical receipts. They are not counted as new mathematical executions. The inherited packages receive recursive integrity checking only.

Mutation tests challenge corrupt or omitted files, extra files, unsafe ZIP paths, symlinks, duplicate JSON keys, type confusion, rehashed claim widening, changed manuscript or projection bytes, privacy leakage, dependency corruption and altered mathematical replay results. Validation and replay do not modify this release; caches are disabled. Separately supplied cold receipts bind the final ZIP and record execution from a fresh extraction.

## Limits

This package makes no arbitrary-n, other-digit-pattern, odd-composite-order, FFT-speed, complexity, novelty or global F020/F023 closure claim. Kernel terms are algebraic squares, not absolute-value squares. Hashes establish byte identity, not mathematical truth, authorship, priority or cryptographic signatures. See ATTRIBUTION.md and the unchanged imported records for contribution boundaries.
