#!/usr/bin/env python3
"""Fresh reviewer controls. Imports no candidate/historical scientific programs.
Exact controls use integers and Q[z]/Phi_N; numerical controls are labeled.
"""
import hashlib, itertools, json, math, random
from pathlib import Path
from fractions import Fraction as Fq
from collections import Counter
import numpy as np
import sympy as sp

BASE=Path('/workspace/shared/odd_codim2_uniform_gap_20261023')
COUNTS=Counter()
MAXRES={}
def require(v, message):
    if not v: raise RuntimeError(message)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def bindings():
    require(sha(BASE/'REPORT.md')=='77caa3fecaeef2d5dddab32a2a674c660fafa1040e52a43f17b2e059d4c1e359','changed report')
    require(sha(BASE/'MANIFEST.json')=='b31790efbd54b61da3cec2521264285152a0900cb59d8b02fbb099ee24f2dd51','changed manifest')
    for x in json.loads((BASE/'MANIFEST.json').read_text())['files']:
        p=BASE/x['path']; require(p.stat().st_size==x['size'] and sha(p)==x['sha256'],'manifest mismatch '+x['path'])
        COUNTS['manifest_members_checked']+=1
    for x in json.loads((BASE/'SOURCE_BINDINGS.json').read_text()):
        require(sha(BASE/x['local'])==sha(Path(x['original']))==x['sha256'],'source binding mismatch')
        COUNTS['original_source_bindings_checked']+=1

# Exact exhaustive support incidence, without row regularity.
def witness(pattern):
    for i in range(len(pattern)):
        for j in range(i):
            if len(pattern[i]&pattern[j])==1: return 'single', (j,i)
    groups={}
    for i,s in enumerate(pattern): groups.setdefault(s,[]).append(i)
    for ids in groups.values():
        if len(ids)>=3: return 'triple', ids[:3]
    return None,None

def incidence_controls():
    for n in (3,5):
        pairs=[frozenset(x) for x in itertools.combinations(range(n),2)]
        for pat in itertools.product(pairs,repeat=n):
            kind,ids=witness(pat)
            require(kind is not None,'odd incidence failure')
            COUNTS['exact_exhaustive_n'+str(n)]+=1
            COUNTS['exact_'+kind+'_certificates']+=1
            degrees=Counter(r for p in pat for r in p)
            if any(degrees[r]!=2 for r in range(n)): COUNTS['exact_irregular_masks']+=1
    rng=random.Random(37460219)
    for n in range(7,102,2):
        for mode in range(24):
            if mode%3==0:
                # Disjoint two-row blocks with multiplicities, forced triples.
                pairs=[frozenset((i,i+1)) for i in range(0,n-1,2)]
                pat=[rng.choice(pairs) for _ in range(n)]
            else: pat=[frozenset(rng.sample(range(n),2)) for _ in range(n)]
            kind,ids=witness(pat); require(kind is not None,'random odd incidence failure')
            COUNTS['exact_random_incidence']+=1
    for n in range(4,22,2):
        pat=[frozenset((2*(i//2),2*(i//2)+1)) for i in range(n)]
        require(witness(pat)[0] is None,'even negative should evade dichotomy')
        COUNTS['exact_even_negative_controls']+=1

class Cyclo:
    def __init__(self,n):
        self.n=n; x=sp.Symbol('x'); p=sp.Poly(sp.cyclotomic_poly(n,x),x)
        self.d=p.degree(); self.mod=[Fq(int(p.nth(i))) for i in range(self.d)]
        self.zero=(Fq(0),)*self.d; self.one=self.scalar(1)
        self.powers=[self.elem([0]*k+[1]) for k in range(n)]
    def scalar(self,a): return (Fq(a),)+(Fq(0),)*(self.d-1)
    def elem(self,a):
        a=list(map(Fq,a))+[Fq(0)]*max(0,self.d-len(a))
        for k in range(len(a)-1,self.d-1,-1):
            t=a[k]
            if t:
                for j,c in enumerate(self.mod): a[k-self.d+j]-=t*c
        return tuple(a[:self.d])
    def add(self,a,b): return tuple(x+y for x,y in zip(a,b))
    def neg(self,a): return tuple(-x for x in a)
    def sub(self,a,b): return self.add(a,self.neg(b))
    def scale(self,a,t): return tuple(x*t for x in a)
    def mul(self,a,b):
        if a==self.zero or b==self.zero: return self.zero
        v=[Fq(0)]*(2*self.d-1)
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b):
                    if y: v[i+j]+=x*y
        return self.elem(v)
    def conj(self,a):
        out=self.zero
        for k,t in enumerate(a): out=self.add(out,self.scale(self.powers[(-k)%self.n],t))
        return out

def exact_matrix_controls():
    for n in (3,5,7):
        R=Cyclo(n); z=R.zero; one=R.one
        def zero(): return [[z for _ in range(n)] for __ in range(n)]
        def ident(): return [[one if i==j else z for j in range(n)] for i in range(n)]
        def add(A,B): return [[R.add(a,b) for a,b in zip(ar,br)] for ar,br in zip(A,B)]
        def neg(A): return [[R.neg(a) for a in ar] for ar in A]
        def sub(A,B): return add(A,neg(B))
        def scale(A,t): return [[R.scale(a,t) for a in ar] for ar in A]
        def star(A): return [[R.conj(A[j][i]) for j in range(n)] for i in range(n)]
        def mul(A,B):
            out=zero()
            for i in range(n):
                for k in range(n):
                    if A[i][k]!=z:
                        for j in range(n): out[i][j]=R.add(out[i][j],R.mul(A[i][k],B[k][j]))
            return out
        I=ident(); W=[[R.powers[(-i*j)%n] for j in range(n)] for i in range(n)]
        require(mul(W,star(W))==scale(I,n),'exact Fourier normalization')
        for mode in range(3):
            D=zero()
            for i in range(n):
                D[i][i]=R.scalar(Fq(i+2,n+2))
                if mode and n>3:
                    for j in range(i+1,min(n,i+1+mode)):
                        D[i][j]=R.scale(R.powers[(i+2*j+mode)%n],Fq(mode+1,7+i+j))
            # Independent exact triangular inversion: M=(D^{-1})/sqrt(N).
            J=zero()
            for i in range(n-1,-1,-1):
                di=D[i][i][0]; J[i][i]=R.scalar(1/di)
                for j in range(i+1,n):
                    tot=z
                    for k in range(i+1,j+1): tot=R.add(tot,R.mul(D[i][k],J[k][j]))
                    J[i][j]=R.scale(tot,-1/di)
            require(mul(D,J)==I and mul(J,D)==I,'exact inverse')
            supports=[]
            for i in range(n):
                actual={j for j in range(n) if D[i][j]!=z}
                require(len(actual)<=n-2,'inverse row cardinality')
                pad=list(sorted(set(range(n))-actual,reverse=bool(mode%2)))
                S=actual|set(pad[:n-2-len(actual)]); supports.append(S)
                if len(actual)<n-2: COUNTS['exact_padded_smaller_rows']+=1
            V=[[W[j][i] if j in supports[i] else z for i in range(n)] for j in range(n)]
            Z=sub(W,V); q=Fq(n-2,n); a2=Fq(2,n)
            U=sub(scale(D,n*q),star(V)); L=sub(J,W)
            # Rigorous rational upper bound for ||E||_2^2 via coefficient l1 and Frobenius.
            lam=sum(sum(abs(c) for c in e)**2 for row in L for e in row)/n
            eps=lam-a2; H=sub(scale(I,lam),scale(mul(L,star(L)),Fq(1,n)))
            DD=mul(D,star(D)); P=scale(DD,q*eps*n)
            Q=add(scale(mul(mul(D,H),star(D)),q*n),scale(mul(U,star(U)),Fq(1,n)))
            K=sub(scale(mul(star(Z),Z),Fq(1,n)),scale(I,a2))
            rhs=add(sub(P,Q),scale(add(mul(U,Z),mul(star(Z),star(U))),Fq(1,n)))
            require(K==rhs,'exact stability matrix identity')
            require(all(P[i][i]==Q[i][i] for i in range(n)),'exact equal diagonal')
            for i in range(n):
                for j in range(n):
                    if j not in supports[i]: require(U[i][j]==z,'exact omitted support vanishing')
            UZ=mul(U,Z)
            for i in range(n):
                for j in range(n):
                    if i!=j and supports[i]==supports[j]:
                        require(UZ[i][j]==z,'exact same-support localized cancellation')
                        COUNTS['exact_same_support_cancellations']+=1
            wrongV=[[W[i][j] if j in supports[i] else z for j in range(n)] for i in range(n)]
            wrongOrientation=sub(scale(D,n*q),star(wrongV))
            if any(wrongOrientation[i][j]!=z for i in range(n) for j in range(n) if j not in supports[i]):
                COUNTS['exact_wrong_orientation_negative_controls']+=1
            # Inject a coefficient into a prohibited omitted position.
            t=min(set(range(n))-supports[0]); mutation=[row[:] for row in U]; mutation[0][t]=one
            require(mutation[0][t]!=z,'support mutation not detected')
            COUNTS['exact_omitted_support_mutation_controls']+=1
            # Wrong gain mutation is visibly different and fails the identity.
            wrongU=sub(scale(D,n),star(V))
            wrongQ=add(scale(mul(mul(D,H),star(D)),q*n),scale(mul(wrongU,star(wrongU)),Fq(1,n)))
            wrongRhs=add(sub(P,wrongQ),scale(add(mul(wrongU,Z),mul(star(Z),star(wrongU))),Fq(1,n)))
            require(wrongRhs!=K,'wrong q normalization escaped')
            COUNTS['exact_original_model_identities']+=1
            COUNTS['exact_wrong_gain_negative_controls']+=1

# Numerical controls use actual spectral norm, not the exact controls' surrogate.
def num_close(name,A,B,tol=8e-10,operation_scale=0.):
    err=float(np.linalg.norm(A-B)/max(1.,np.linalg.norm(A),np.linalg.norm(B),operation_scale))
    MAXRES[name]=max(err,MAXRES.get(name,0.))
    require(err<tol,'numerical residual '+name+' '+str(err))
def numerical_controls():
    rng=np.random.default_rng(230610)
    g=(math.sqrt(3)-1)/2
    for n in (3,5,7,9,11,15,21):
        W=np.exp(-2j*np.pi*np.outer(np.arange(n),np.arange(n))/n)/math.sqrt(n)
        q=(n-2)/n; a2=2/n
        for mode in range(30):
            # General flat unitary: preserve original Fourier in half the tests.
            if mode%2:
                left=np.exp(1j*rng.uniform(-math.pi,math.pi,n))
                right=np.exp(1j*rng.uniform(-math.pi,math.pi,n))
                F=W[rng.permutation(n),:][:,rng.permutation(n)]*left[:,None]*right[None,:]
                COUNTS['numerical_flat_unitary_extension_attempts']+=1
            else: F=W.copy()
            B=np.zeros((n,n),complex); S=[]
            if mode<4:
                # Arbitrary diagonal inverse, including badly conditioned cases.
                d=(rng.uniform(.2,2,n)+1j*rng.uniform(-1,1,n))
                if mode==0: d=np.geomspace(1e-5,1e5,n).astype(complex)
                B=np.diag(d)
                for i in range(n):
                    pad=rng.choice([j for j in range(n) if j!=i],n-3,replace=False)
                    S.append(set([i,*map(int,pad)]))
            else:
                # Arbitrary row omissions; union-cycle and identical-pair designs alternate.
                for i in range(n):
                    if mode%3==0: T={(2*(i//2))%(n-1),(2*(i//2)+1)%(n-1)}
                    elif mode%3==1: T={i,(i+1)%n}
                    else: T=set(map(int,rng.choice(n,2,replace=False)))
                    S.append(set(range(n))-T)
                    B[i,list(S[-1])]=F[list(S[-1]),i].conj()/q
                if mode%4:
                    for i in range(n):
                        ids=list(S[i]); B[i,ids]*=1+(.03+.05*(mode%4))*(rng.normal(size=len(ids))+1j*rng.normal(size=len(ids)))
                if mode%5==0 and n>3:
                    for i in range(n): B[i,min(S[i])]=0
            try: M=np.linalg.inv(B)
            except np.linalg.LinAlgError:
                COUNTS['numerical_singular_samples_skipped']+=1; continue
            if np.linalg.cond(B)>1e13:
                COUNTS['numerical_unreliable_samples_skipped']+=1; continue
            A=np.zeros((n,n),complex)
            for i in range(n): A[list(S[i]),i]=F[list(S[i]),i]
            C=F-A; E=M-F; rho=float(np.linalg.norm(E,2)); eps=rho*rho-a2
            H=rho*rho*np.eye(n)-E@E.conj().T; Y=q*B-A.conj().T
            P=q*eps*B@B.conj().T; Q=q*B@H@B.conj().T+Y@Y.conj().T
            K=C.conj().T@C-a2*np.eye(n)
            num_close('matrix_identity_operation_scaled',K,P-Q+Y@C+C.conj().T@Y.conj().T,operation_scale=np.linalg.norm(P)+np.linalg.norm(Q)+2*np.linalg.norm(Y@C))
            if np.linalg.cond(B)<1e4 and rho<10:
                num_close('matrix_identity_well_scaled_forward',K,P-Q+Y@C+C.conj().T@Y.conj().T)
            num_close('diagonal_identity',np.diag(P),np.diag(Q))
            x=np.linalg.norm(B,axis=1)
            require(eps>=-2e-10,'one-row floor')
            require(np.min(rho*rho-a2-(1/x-math.sqrt(q))**2)>-1e-6*max(1,rho*rho),'row norm inequality')
            for i in range(n):
                T=set(range(n))-S[i]
                require(np.max(np.abs(Y[i,list(T)]))<1e-14,'Y support mutation')
                if np.count_nonzero(B[i])<n-2: COUNTS['numerical_padded_smaller_rows']+=1
            # PSD assertions tolerate absolute roundoff on extreme scale.
            require(np.linalg.eigvalsh(H)[0]>-1e-8*max(1,rho*rho),'H PSD')
            bound=a2+g*g/(math.sqrt(n)+g/math.sqrt(q))**2
            require(rho*rho+1e-10>=bound,'main lower bound')
            if eps<q:
                COUNTS['numerical_epsilon_below_q']+=1
                u=math.sqrt(q*eps)/(math.sqrt(q)-math.sqrt(eps))
                require(max(x)<=1/(math.sqrt(q)-math.sqrt(eps))+1e-10,'inverse-row upper bound')
                require(math.sqrt(n)*u+1e-9>=g,'localized conclusion')
            pat=[frozenset(set(range(n))-s) for s in S]
            kind,ids=witness(pat)
            if kind=='single':
                i,j=ids; require(abs(abs(K[i,j])-1/n)<1e-12,'single-intersection phase independence')
                require(abs((Y@C)[i,j])<=np.linalg.norm(Y[i])/math.sqrt(n)+1e-12,'localized one coefficient')
            else:
                i,j,k=ids; G=C[:,[i,j,k]].conj().T@C[:,[i,j,k]]
                off=G-np.diag(np.diag(G)); require(np.max(np.abs(off))>=1/n-1e-12,'rank2 Gram certificate')
                require(abs((Y@C)[i,j])<1e-12,'same-support exact vanished cross term')
            COUNTS['numerical_'+kind+'_case']+=1
            COUNTS['numerical_admissible_matrix_samples']+=1
            COUNTS['numerical_flat_unitary_extension_samples' if mode%2 else 'numerical_original_Fourier_samples']+=1
            if np.linalg.cond(B)>1e8: COUNTS['numerical_ill_conditioned_samples']+=1

# Exact symbolic constants, relaxed historical sharpness, and endpoint separation.
def constants_and_relaxed_controls():
    x=sp.Symbol('x'); r=sp.sqrt(3); g=(r-1)/2
    require(sp.simplify(2*g*g+2*g-1)==0,'g polynomial')
    require(sp.simplify(g/(1+g)-(2-r))==0,'uniform constant ratio')
    require(sp.simplify(2+(2-r)**2-(9-4*r))==0,'uniform squared coefficient')
    require(sp.simplify(2+g*g-(3-r/2))==0,'asymptotic coefficient')
    require(27**2<3*16**2,'N3 lower bound strictly below exact 3/4')
    require(9**2>3*4**2 and 7**2>3*4**2,'constant positive and >2')
    COUNTS['exact_constant_certificates']=6
    # Historical relaxed-mask sharpness is not Delta sharpness.
    D=sp.Matrix([[1,1,1],[1,-1,0],[0,0,1]])
    K=D.T*D-2*sp.eye(3)
    require(sp.expand(K.charpoly(x).as_expr()-x*(x*x-2))==0,'historical relaxed sharpness')
    require([sum(v!=0 for v in D[:,j]) for j in range(3)]==[2,2,2],'column support')
    require([sum(v!=0 for v in D[i,:]) for i in range(3)]==[3,2,1],'irregular row control')
    COUNTS['exact_historical_relaxed_lemma_control']=1
    for n in range(3,2002,2):
        q=(n-2)/n; gf=float(g); rhs=gf/(math.sqrt(n)+gf/math.sqrt(q))
        require(rhs*rhs<q,'epsilon>=q branch')
        require(n*(2/n+rhs*rhs)>=float(9-4*r)-1e-13,'uniform weakening')
        COUNTS['numerical_constant_sweep']+=1

def main():
    bindings(); incidence_controls(); exact_matrix_controls(); numerical_controls(); constants_and_relaxed_controls(); bindings()
    print(json.dumps({'status':'PASS','counts':dict(sorted(COUNTS.items())),'max_scaled_numerical_residuals':MAXRES,'numerical_identity_tolerance':8e-10,'scope':'Exact integer/cyclotomic controls and explicitly numerical matrix checks. Finite controls corroborate, not prove, the infinite statements. Author and historical scientific programs were not run.'},indent=2,sort_keys=True))
if __name__=='__main__': main()
