# A polynomial inverse-row-sparsity gap at odd codimension two

Date: 2026-10-23 UTC. Candidate for independent review. Owner M-SPARSE-DEFECT remains TO RESEARCH. No historical novelty, exact optimum, full-budget quantitative classification, implementation, or Fourier/FFT improvement is claimed.

## 1. Concrete result in the original model

Let F[j,k]=N^(-1/2) exp(-2 pi i jk/N), and let Delta(N,s) be the infimum of ||M-F||_2 over all invertible complex N-by-N matrices M such that every row of M^(-1) has at most s nonzero entries. Supports, coefficients, and condition numbers remain arbitrary. The accepted source E_REVIEW.md, Sections 1-4, is the exact model and equality-criterion source.

Put

    h = sqrt(2+2 sqrt(2)) - sqrt(2+sqrt(2))
      = 0.3496091619130466... .

**Theorem.** For every odd integer N>=3,

    Delta(N,N-2)^2 >= 2/N + h^2/[N+h sqrt(N/(N-2))]^2
                      >= 2/N + 1/(16 N^2).                 (1.1)

In particular, this holds for every distinct odd semiprime N=pq. The previously accepted result gave only strict separation from sqrt(2/N) at this budget (apart from the independently solved N=3 case). The present result supplies an explicit polynomial-scale separation in the original simultaneous inverse-row model, not merely in a binary mask model.

The sharper displayed correction is asymptotic to h^2/N^2, where h^2=0.1222265660935428... . Thus the proved lower bound on the norm gap has order N^(-3/2). This is a lower-bound rate, not an assertion that the actual gap has that order or that the constant is optimal.

The exact semiprime classification remains the accepted source for other budgets. A robust quantitative extension of its full cycle-cancellation argument has not been proved here. The successful mechanism is instead a phase-insensitive global row-column incidence obstruction at omitted degree two, combined with quantitative equality stability.

## 2. Sharp phase-insensitive mask-defect lemma

**Lemma.** Let N be odd. Let C be any complex N-by-N matrix with exactly two nonzero entries in every column, each of modulus N^(-1/2). Row degrees need not be regular, and phases need not be Fourier phases. Then

    ||C* C - (2/N) I||_2 >= sqrt(2)/N.                    (2.1)

Proof. Regard each column as an edge joining its two supporting rows, allowing parallel edges and no loops. There are N edges on N vertices. One of the following two certificates must exist:

1. Three columns have the same two-element support. These three vectors lie in a two-dimensional coordinate space. A nonzero combination of them vanishes, so C has a nonzero kernel vector and C* C-(2/N)I has eigenvalue -2/N.
2. Some column has at least two other columns whose supports intersect its support in exactly one row. Its corresponding column in C* C-(2/N)I has at least two entries of modulus 1/N. The operator norm is therefore at least sqrt(2)/N.

To establish the dichotomy, first suppose some row has degree at least three. Choose three incident columns. If their other endpoints all agree, certificate 1 holds. Otherwise one of the three columns has an other endpoint different from both of the other two, giving certificate 2. If no row has degree at least three, the total degree 2N forces every row to have degree exactly two. Each component is then either a pair of parallel edges or a cycle of length at least three. Since N is odd, the components cannot all be parallel pairs. Any edge in a longer cycle gives certificate 2. This proves (2.1).

The constant sqrt(2) is sharp for this relaxed, phase-insensitive mask lemma. At N=3, take sqrt(N)C equal to

    [1  1  1]
    [1 -1  0]
    [0  0  1].

Its Gram defect has eigenvalues -sqrt(2),0,sqrt(2) before division by N. For every larger odd N, append (N-3)/2 copies of the unnormalized two-by-two Hadamard block. This is not claimed to be a fixed-Fourier mask, an inverse-row optimizer, or a sharpness example for (1.1).

## 3. Quantitative equality stability with arbitrary inverse rows

We establish the transfer in the original model without assuming a condition-number bound or norm error below one.

Fix any admissible M for a budget s, and put

    B=M^(-1), E=M-F, rho=||E||_2,
    q=s/N, a^2=1-q, epsilon=rho^2-a^2.

The inherited one-row floor gives epsilon>=0. Pad the support of every row b_i of B to an arbitrary set S_i of exactly s positions. This padding is only notation: coefficients outside the actual support stay zero. Define

    A[j,i]=F[j,i] 1_(j in S_i),
    C=F-A, Y=q B-A*, H=rho^2 I-E E*.

Thus every column of C has exactly d=N-s entries of modulus N^(-1/2), while H is positive semidefinite. No row regularity is imposed on A or C.

Write x_i=||b_i||_2>0 and z_i=(b_i F)_i. The identities b_i E=e_i-b_i F and ||b_i F||=x_i give

    b_i H b_i* = 2 Re(z_i)-1-(q-epsilon)x_i^2.

The row of A* indexed by i has squared norm q and agrees with the conjugate Fourier column on S_i. Since b_i vanishes outside S_i,

    ||Y_i||^2=q^2 x_i^2+q-2q Re(z_i).

Consequently the exact row identity is

    q b_i H b_i* + ||Y_i||^2 = q epsilon x_i^2.          (3.1)

Define the positive semidefinite matrices

    P=q epsilon B B*,
    Q=q B H B*+Y Y*,
    T=tr(P)=q epsilon ||B||_F^2.

Summing (3.1) gives tr(Q)=tr(P)=T. In particular,

    ||P-Q||_2<=T,    ||Y||_2<=||Y||_F<=sqrt(T).          (3.2)

Set K=C* C-a^2 I and k=||K||_2. Direct substitution of A*=qB-Y, using B E=I-BF, gives the exact identity

    K=P-Q+Y C+C* Y*.                                   (3.3)

Also ||C||_2^2<=a^2+k. Therefore

    k <= T+2 sqrt(T) sqrt(a^2+k).                       (3.4)

This is the useful stability estimate. It retains the simultaneous matrix constraint and arbitrary complex coefficient error. In particular it does not replace M by a Fourier submatrix or assume its supports are common.

If every column-weight-d Fourier mask has defect at least gamma>0, then k>=gamma. Solving (3.4) for sqrt(T), and noting that sqrt(a^2+2k)-sqrt(a^2+k) increases with k>0, yields

    sqrt(T) >= sqrt(a^2+2 gamma)-sqrt(a^2+gamma).        (3.5)

This transfer lemma does not itself supply a useful gamma for general d.

## 4. Direct inverse-row norm control

Cauchy-Schwarz on the padded support gives Re(z_i)<=sqrt(q) x_i. Since ||b_i E||<=rho x_i,

    rho^2 >= 1+x_i^(-2)-2 sqrt(q)/x_i
           = a^2+(x_i^(-1)-sqrt(q))^2.

Thus, if epsilon<q,

    x_i <= 1/[sqrt(q)-sqrt(epsilon)],
    T <= q N epsilon/[sqrt(q)-sqrt(epsilon)]^2.         (4.1)

This replaces any conditioning assumption by a conclusion forced by proximity to the inherited floor. If epsilon>=q, the final lower bound below is already automatic.

## 5. Proof of the quantitative theorem

Set s=N-2, q=(N-2)/N, and a^2=2/N. The phase-insensitive lemma applies to the padded complementary mask C, so gamma=sqrt(2)/N. Formula (3.5) becomes

    sqrt(T)>=h/sqrt(N).

When epsilon<q, combine this with (4.1) and put x=sqrt(epsilon):

    h/sqrt(N) <= sqrt(qN) x/[sqrt(q)-x].

Rearrangement gives

    x >= h/[N+h/sqrt(q)],
    epsilon >= h^2/[N+h/sqrt(q)]^2.                    (5.1)

When epsilon>=q, the right side of (5.1) is strictly smaller than q, so (5.1) still holds. Every admissible M therefore satisfies the sharp-form bound in (1.1), and taking the infimum preserves it. Compactness or attainment is not needed.

For the simpler constant, h>1/3 and 1/sqrt(q)<=N for N>=3. Hence

    h/[N+h/sqrt(q)] >= h/[N(1+h)] >= 1/(4N).

For completeness, h>1/3 follows by squaring the equivalent positive inequality sqrt(2+2r)>sqrt(2+r)+1/3, where r=sqrt(2). The final positive difference is 91/81-2r/3>0, since r<3/2. This proves (1.1) in full.

## 6. Exact scope, stop, and validation

The proof uses only unitarity and flat entry magnitudes of the target F. It therefore also applies to any flat unitary target of odd order, with the same definition of the inverse-row-sparsity infimum. The theorem is nevertheless stated first in the original Fourier model, and no further classification for arbitrary flat targets is claimed.

No polynomial gap for every nonexceptional semiprime budget follows. The accepted full semiprime proof relies on exact vanishing of potentially long root sums. Near vanishing does not, without a new robust global argument, force the exact full-cycle structure needed by that proof. This packet stops at the concrete odd codimension-two quantitative family and the reusable stability transfer. It neither substitutes an exponentially small cyclotomic-height estimate nor rebrands the already accepted strictness result.

Fresh self-authored controls accompany this report. They do not import or run historical scientific scripts. Exact integer support-graph checks exhaust all column-weight-two masks at N=3 and N=5, and randomized larger odd-order cases. Numerical controls separately check the matrix identities, inequalities, arbitrary complex perturbations of inverse rows, support padding, and relaxed-mask sharpness constructions. Numerical controls are explicitly arithmetic checks, not replacements for the proof. See RESULTS.json for counts and tolerances.

The source copies and final report are hash-bound by MANIFEST.json and SOURCE_BINDINGS.json. Independent review is required before acceptance. No external writes were performed. This packet creates no exact optimum, cost model, algorithm, FFT speedup, or historical-priority claim.
