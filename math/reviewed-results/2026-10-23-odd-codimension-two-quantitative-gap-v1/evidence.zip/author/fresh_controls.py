#!/usr/bin/env python3
"""New controls for the localized strengthening; no historical imports."""
import itertools,json,math,random
from collections import Counter
import numpy as np
rng=random.Random(202610230403)
nrng=np.random.default_rng(202610230403)
counts=Counter(); worst=0.0
g=(math.sqrt(3)-1)/2

def require(test,label):
    if not test: raise RuntimeError(label)

def witness(supports):
    ss=[set(x) for x in supports]
    for i in range(len(ss)):
        for j in range(i):
            if len(ss[i]&ss[j])==1:
                return 'single',(i,j)
    groups={}
    for i,s in enumerate(supports):groups.setdefault(s,[]).append(i)
    for inds in groups.values():
        if len(inds)>=3:return 'triple',tuple(inds[:3])
    return None,None

for n in (3,5):
    pairs=list(itertools.combinations(range(n),2))
    for supports in itertools.product(pairs,repeat=n):
        kind,inds=witness(supports)
        require(kind is not None,'integer dichotomy failed')
        counts[f'exhaustive_n{n}']+=1;counts[f'exhaustive_{kind}']+=1
for n in (7,9,15,21,35,77,143):
    for _ in range(200):
        supports=tuple(tuple(sorted(rng.sample(range(n),2))) for j in range(n))
        require(witness(supports)[0] is not None,'random integer dichotomy')
        counts['random_integer_masks']+=1
for n in (2,4,6,10,20):
    supports=tuple((2*(j//2),2*(j//2)+1) for j in range(n))
    require(witness(supports)[0] is None,'even counterexample not recognized')
    counts['even_negative_controls']+=1

def norm(x):return float(np.linalg.norm(x,2))
def near(x,y,label):
    global worst
    resid=norm(x-y)/max(1,norm(x),norm(y))
    require(resid<=2e-9,label);worst=max(worst,resid)

for n in (3,5,7,9,15,21,35,77):
    q=(n-2)/n;s=n-2;a2=2/n
    F=np.exp(-2j*np.pi*np.outer(np.arange(n),np.arange(n))/n)/math.sqrt(n)
    for trial in range(16):
        if trial<10 or trial>=14:
            supports=tuple(tuple(sorted(rng.sample(range(n),2))) for _ in range(n))
        else:
            # Three identical supports, then disjoint double-support groups.
            supports=((0,1),)*3+tuple((2+2*(j//2),3+2*(j//2)) for j in range(n-3))
        Astar=F.conj().T.copy()
        for i,T_i in enumerate(supports):Astar[i,list(T_i)]=0
        B=Astar/q
        noise=(nrng.normal(size=(n,n))+1j*nrng.normal(size=(n,n)))/math.sqrt(n)
        B=B+(0 if trial==0 else 0.015*(trial+1))*noise*(Astar!=0)
        if trial>=14:
            # Build an invertible one-supported-row matrix and pad each row.
            B=np.diag((0.8+0.2j)*(1+0.01*np.arange(n)))
            supports=tuple(tuple(sorted(rng.sample([j for j in range(n) if j!=i],2))) for i in range(n))
            Astar=F.conj().T.copy()
            for i,T_i in enumerate(supports):Astar[i,list(T_i)]=0
        if np.linalg.matrix_rank(B,tol=1e-12)<n:
            counts['singular_samples_skipped']+=1;continue
        require(np.all(np.count_nonzero(B,axis=1)<=s),'original row sparsity')
        M=np.linalg.inv(B);E=M-F;rho=norm(E);eps=rho*rho-a2
        A=Astar.conj().T;C=F-A;Y=q*B-Astar
        H=rho*rho*np.eye(n)-E@E.conj().T
        P=q*eps*(B@B.conj().T)
        Q=q*B@H@B.conj().T+Y@Y.conj().T
        K=C.conj().T@C-a2*np.eye(n)
        near(K,P-Q+Y@C+C.conj().T@Y.conj().T,'matrix identity')
        near(np.diag(np.diag(P)),np.diag(np.diag(Q)),'individual diagonal identity')
        for i in range(n):
            require(norm(Y[i:i+1,list(supports[i])])<1e-12,'Y support exclusion')
            counts['support_exclusion_checks']+=1
        kind,inds=witness(supports)
        if kind=='single':
            i,j=inds
            require(abs(abs(K[i,j])-1/n)<2e-12,'single-overlap magnitude')
            for r,t in [(i,j),(j,i)]:
                require(abs((Y@C)[r,t])<=np.linalg.norm(Y[r])/math.sqrt(n)+1e-10,'one-position localization')
        else:
            sub=K[np.ix_(inds,inds)]
            choices=[(abs(sub[i,j]),inds[i],inds[j]) for i in range(3) for j in range(i)]
            mag,i,j=max(choices)
            require(mag>=1/n-1e-12,'triple Gram lower bound')
            require(abs((Y@C)[i,j])<1e-12 and abs((Y@C)[j,i])<1e-12,'identical support cross terms')
        xi=np.linalg.norm(B[i]);xj=np.linalg.norm(B[j])
        require(abs((P-Q)[i,j])<=2*q*eps*xi*xj+1e-8,'PSD diagonal entry bound')
        if eps<q:
            u=math.sqrt(q*eps)/(math.sqrt(q)-math.sqrt(eps))
            require(np.max(np.linalg.norm(B,axis=1))<=1/(math.sqrt(q)-math.sqrt(eps))+1e-8,'inverse row norm')
            require(math.sqrt(n)*u>=g-1e-8,'localized quadratic')
            counts['epsilon_below_q']+=1
        require(eps>=g*g/(math.sqrt(n)+g/math.sqrt(q))**2-1e-8,'sharp form gap')
        require(rho*rho>=(9-4*math.sqrt(3))/n-1e-8,'uniform relative gap')
        counts[f'original_model_{kind}']+=1
        counts['original_matrix_controls']+=1
        if trial>=14:counts['strict_support_padding']+=1
        elif trial>0:counts['arbitrary_complex_coefficients']+=1

# The same-support Gram certificate cannot be replaced by a strict >1/N.
z=np.exp(2j*np.pi/3)
V=np.array([[1,1,1],[1,z,z*z]],complex)/math.sqrt(3)
G=V.conj().T@V
require(max(abs(G[i,j]) for i in range(3) for j in range(i))<=1/3+1e-12,'Gram sharp certificate')
counts['same_support_equality_control']+=1
# Support-localization is essential: changing Y outside its permitted support breaks it.
C=np.array([[1,1,0],[1,0,1],[0,1,1]],complex)/math.sqrt(3)
Y=np.zeros((3,3),complex);Y[0,0]=Y[0,2]=1
require(abs((Y@C)[0,1])>np.linalg.norm(Y[0])/math.sqrt(3),'missing support restriction mutation')
counts['support_mutation_rejected']+=1
for n in range(3,10002,2):
    q=(n-2)/n
    bound=g*g/(math.sqrt(n)+g/math.sqrt(q))**2
    require(bound>=(7-4*math.sqrt(3))/n-1e-14,'uniform constant reduction')
    counts['constant_sweep']+=1
print(json.dumps({'status':'PASS','counts':dict(sorted(counts.items())),
 'g':g,'uniform_squared_constant':9-4*math.sqrt(3),
 'asymptotic_squared_lower_bound_constant':2+g*g,
 'max_scaled_matrix_identity_residual':worst,'identity_tolerance':2e-9,
 'scope':'Integer support dichotomy is exact; complex matrix and coefficient controls are numerical, not a substitute for proof.'},indent=2,sort_keys=True))
