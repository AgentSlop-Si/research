#!/usr/bin/env python3
"""New independent original-matrix reconstruction; never imports producer code.
Cycle numerators are built by polynomial matrix powering, not path tracing.
Guard division is descending leading-term long division, then full multiplication back.
Only producer's already selected fixed square minors are replayed; no replacements.
"""
import hashlib,itertools,json,math,pathlib,sys,time
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=pathlib.Path(__file__).resolve().parent
P=65537
Z2=(0,0); Z4=(0,0,0,0)
I=np.eye(8,dtype=np.int64)
EXP=list(itertools.product(range(2),repeat=4))
MON=list(itertools.product(range(3),repeat=4))
COL={e:i for i,e in enumerate(MON)}
PAIRS=list(itertools.combinations(range(1,8),2))
SUM={e:[] for e in MON}
for a,e in enumerate(EXP):
 for b,f in enumerate(EXP):SUM[tuple(x+y for x,y in zip(e,f))].append((a,b))

def phash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def plus(e,f):return tuple(x+y for x,y in zip(e,f))
def pmul(a,b):
 c={}
 for e,A in a.items():
  for f,B in b.items():
   g=plus(e,f);C=A@B%P
   if g in c:c[g]=(c[g]+C)%P
   else:c[g]=C
 return {e:A for e,A in c.items() if A.any()}
def smul(a,b):
 c={}
 for e,A in a.items():
  for f,B in b.items():
   g=plus(e,f);C=A*B%P
   if g in c:c[g]=(c[g]+C)%P
   else:c[g]=C
 return {e:A for e,A in c.items() if A.any()}
def padd(a,b):
 c={e:A.copy() for e,A in a.items()}
 for e,B in b.items():c[e]=(c.get(e,0)+B)%P
 return {e:A for e,A in c.items() if A.any()}

def stage(st,e,ii):
 w=[1]*7+[(a+ii*b)*pow((a-ii*b)%P,-1,P)%P for a,b in st['gaussian_pairs']]
 shifts={7:(1,0),e:(0,1)};Bs=[];ds=[];hs=[]
 for b,cy in enumerate(st['cycles']):
  W={}
  for j,v in enumerate(cy):
   k=8*b+j;ex=shifts.get(k,Z2)
   W.setdefault(ex,np.zeros((8,8),dtype=np.int64))[v,cy[j-1]]=w[k]
  power={Z2:I};B={Z2:I}
  for n in range(1,8):power=pmul(W,power);B=padd(B,power)
  h=math.prod(w[8*b:8*b+8])%P;hs.append(h)
  move=tuple(sum(shifts[k][i] for k in shifts if k//8==b) for i in range(2))
  d={Z2:1}
  d[move]=(d.get(move,0)-h)%P
  # Independent cycle identity W^8=h*x^(moving variables)I.
  eighth=pmul(W,power)
  assert set(eighth)=={move} and np.array_equal(eighth[move],h*I%P)
  Bs.append(B);ds.append(d)
 A={}
 for b,B in enumerate(Bs):
  term=B
  for c,d in enumerate(ds):
   if c!=b:term=smul(term,d)
  A=padd(A,term)
 assert all(max(ex)<=1 for ex in A)
 return A,hs,w

def build(chart,edge0,edge1,ii):
 A,h0,w0=stage(chart['stages'][0],edge0,ii)
 B,h1,w1=stage(chart['stages'][1],edge1,ii)
 C,_,_=stage(chart['stages'][0],edge0,-ii%P)
 D,_,_=stage(chart['stages'][1],edge1,-ii%P)
 N={e+f:Y@X%P for e,X in A.items() for f,Y in B.items()}
 Nb={e+f:Y@X%P for e,X in C.items() for f,Y in D.items()}
 H={e:np.zeros((8,8),dtype=np.int64) for e in MON}
 for e,X in N.items():
  for f,Y in Nb.items():
   g=tuple(a+1-b for a,b in zip(e,f));H[g]=(H[g]+X*Y)%P
 # Explicit double-centering linear map avoids broadcast indexing ambiguity.
 L=np.column_stack((-np.ones(7,dtype=np.int64),np.eye(7,dtype=np.int64)))
 K={e:L@X@L.T%P for e,X in H.items()}
 hs=[h0[0],h0[edge0//8],h1[0],h1[edge1//8]]
 E={e:X.copy() for e,X in K.items()}
 for ax,h in enumerate(hs):
  # Descending long division by 1-h*x_ax. Leading coefficient is a unit.
  q={};R={e:X.copy() for e,X in E.items()}
  for ex in sorted(R,reverse=True):
   X=R[ex]
   if not X.any():continue
   assert ex[ax]>0,('nonzero remainder',ax,ex)
   ge=list(ex);ge[ax]-=1;ge=tuple(ge)
   Y=X*(-pow(h,-1,P))%P;q[ge]=Y
   R[ex][:]=0;R[ge]=(R.get(ge,0)-Y)%P
  assert not any(X.any() for X in R.values())
  E=q
 assert all(max(e)<=1 for e in E)
 # Full product reconstruction retains all outer coefficient positions.
 reconstructed=E
 for ax,h in enumerate(hs):
  step=list(Z4);step[ax]=1
  reconstructed=smul(reconstructed,{Z4:1,tuple(step):-h%P})
 for e in set(K)|set(reconstructed):assert np.array_equal(K.get(e,np.zeros((7,7),dtype=np.int64)),reconstructed.get(e,np.zeros((7,7),dtype=np.int64)))
 # Each coefficient is extracted from an independently formed polynomial product.
 arr=np.stack([E.get(e,np.zeros((7,7),dtype=np.int64)) for e in EXP])
 T=np.zeros((441,81),dtype=np.int64)
 for ri,((r,s),(c,d)) in enumerate(itertools.product(PAIRS,PAIRS)):
  prod=np.outer(arr[:,r-1,c-1],arr[:,s-1,d-1])-np.outer(arr[:,r-1,d-1],arr[:,s-1,c-1])
  for ex,pairs in SUM.items():T[ri,COL[ex]]=sum(int(prod[a,b]) for a,b in pairs)%P
 return T,N,E,hs,([h0,h1],[w0,w1])

def determinant(M):
 A=M.copy();d=1;n=len(A)
 for j in range(n):
  k=next((k for k in range(j,n) if A[k,j]),None)
  if k is None:return 0
  if k!=j:A[[j,k]]=A[[k,j]];d=-d%P
  z=int(A[j,j]);d=d*z%P
  fac=A[j+1:,j]*pow(z,-1,P)%P
  A[j+1:]=(A[j+1:]-fac[:,None]*A[j])%P
 return int(d)

def inv(A):
 V=np.concatenate((A.copy(),I.copy()),axis=1)
 for c in range(8):
  r=next((r for r in range(c,8) if V[r,c]),None)
  assert r is not None
  V[[c,r]]=V[[r,c]];V[c]=V[c]*pow(int(V[c,c]),-1,P)%P
  for r in range(8):
   if r!=c:V[r]=(V[r]-V[r,c]*V[c])%P
 return V[:,8:]

def direct_matrix_check(chart,e0,e1,ii,N,hs,stuff):
 # Four nonpole fixtures and five zero-coordinate algebraic controls, via actual inverses.
 allhs,weights=stuff;checks=0
 for x in [(1,1,1,1),(2,3,5,7),(11,13,17,19),(23,29,31,37),(0,1,1,1),(1,0,1,1),(1,1,0,1),(1,1,1,0),(0,0,0,0)]:
  Delta=1;stages=[]
  for t,edge in enumerate([e0,e1]):
   S=np.zeros((8,8),dtype=np.int64)
   for b,cy in enumerate(chart['stages'][t]['cycles']):
    W=np.zeros((8,8),dtype=np.int64);h=1
    for j,v in enumerate(cy):
     k=8*b+j;w=weights[t][k]
     if k==7:w=w*x[2*t]%P
     if k==edge:w=w*x[2*t+1]%P
     W[v,cy[j-1]]=w;h=h*w%P
    if h==1:break
    Delta=Delta*(1-h)%P;S=(S+inv((I-W)%P))%P
   else:stages.append(S);continue
   break
  if len(stages)!=2:continue
  val=np.zeros((8,8),dtype=np.int64)
  for ex,X in N.items():val=(val+X*(math.prod(pow(z,k,P) for z,k in zip(x,ex))%P))%P
  assert np.array_equal(val,Delta*(stages[1]@stages[0]%P)%P)
  checks+=1
 return checks

def main():
 assert all(P%d for d in range(2,math.isqrt(P)+1))
 chart=json.loads((ROOT/'candidate/sources/CHART.json').read_text())
 assert phash(ROOT/'candidate/sources/CHART.json')=='5528afbbd5b4008a5e0f79043870e72a613e0fd421288d2ce1e5dbffee1c9e98'
 assert chart['N']==8 and chart['product_order']=='M=S2*S1' and chart['sum_coefficients']==[1,1,1]
 assert chart['free_phase_indices']==list(range(7,24))
 for st in chart['stages']:
  assert all(sorted(c)==list(range(8)) for c in st['cycles'])
  for a,b in st['gaussian_pairs']:
   assert a*a+b*b and (a+256*b)%P and (a-256*b)%P
 assert 256*256%P==P-1
 results=[];start=time.time();checks=0
 cert_paths=['CERTIFICATES_PRIMARY.json','CERTIFICATES_CONJUGATE.json']
 for fname,ii in zip(cert_paths,[256,P-256]):
  certs=json.loads((ROOT/'candidate'/fname).read_text())
  assert len(certs)==256
  assert [c['encoded_coordinates'] for c in certs]==[[7,a,31,24+b] for a,b in itertools.product(range(8,24),repeat=2)]
  for c in certs:
   e0,e1=c['encoded_coordinates'][1],c['encoded_coordinates'][3]-24;assert c['encoded_coordinates']==[7,e0,31,24+e1]
   assert c['columns']==[list(e) for e in MON] and c['prime']==P and c['imaginary_embedding']==ii
   T,N,E,hs,stuff=build(chart,e0,e1,ii)
   assert all((1-h)%P for st in stuff[0] for h in st)
   assert c['rank']==81 and c['model_checks']['holonomies']==stuff[0]
   if 'active_guard_monomials' in c['model_checks']:
    expected=[]
    for j,h in enumerate(hs):
     ex=[0,0,0,0];ex[j]=1;expected.append([ex,h])
    assert c['model_checks']['active_guard_monomials']==expected
   assert c['model_checks']['numerator_nonzero_coefficients']==sum(int(np.count_nonzero(X)) for X in N.values())
   assert c['model_checks']['E_nonzero_coefficients']==sum(int(np.count_nonzero(X)) for X in E.values())
   digest=hashlib.sha256(T.astype('<u4').tobytes()).hexdigest()
   assert digest==c['equation_matrix_sha256'],('coefficient matrix mismatch',e0,e1,ii)
   rows=c['selected_rows'];assert len(rows)==81 and len(set(rows))==81 and all(0<=r<441 for r in rows)
   det=determinant(T[rows]);assert det and det==c['determinant_residue'],('det mismatch',e0,e1,ii,det)
   checks+=direct_matrix_check(chart,e0,e1,ii,N,hs,stuff)
   results.append({'edges':[e0,e1],'imaginary_embedding':ii,'matrix_sha256':digest,'fixed_minor_determinant':det,'division_and_full_product_check':True})
   if len(results)%32==0:print(len(results),round(time.time()-start,2),flush=True)
 report={'status':'PASS','instances':len(results),'unique_four_phase_labels':256,'prime':P,'embeddings':[256,P-256],'direct_inverse_evaluation_checks':checks,'candidate_hashes':{f:phash(ROOT/'candidate'/f) for f in cert_paths+['sources/CHART.json']},'instances_verified':results}
 (OUT/'INDEPENDENT_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS',len(results),'instances',checks,'inverse checks',round(time.time()-start,2))
if __name__=='__main__':main()
