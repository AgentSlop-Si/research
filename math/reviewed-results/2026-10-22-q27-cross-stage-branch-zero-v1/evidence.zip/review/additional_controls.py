#!/usr/bin/env python3
"""Fresh pole, determinant mutation and Cauchy-Binet controls."""
import importlib.util,pathlib,json,itertools,math
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('independent_review',HERE/'independent_review.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
P=v.P;chart=json.loads((v.ROOT/'candidate/sources/CHART.json').read_text())
def at(poly,x):
 A=np.zeros((8,8),dtype=np.int64)
 for ex,M in poly.items():A=(A+M*(math.prod(pow(z,k,P) for z,k in zip(x,ex))%P))%P
 return A
poles=0
for ii in [256,65281]:
 for e0,e1 in itertools.product(range(8,24),repeat=2):
  A,h0,_=v.stage(chart['stages'][0],e0,ii);B,h1,_=v.stage(chart['stages'][1],e1,ii)
  C,_,_=v.stage(chart['stages'][0],e0,-ii%P);D,_,_=v.stage(chart['stages'][1],e1,-ii%P)
  N={e+f:Y@X%P for e,X in A.items() for f,Y in B.items()}
  Nc={e+f:Y@X%P for e,X in C.items() for f,Y in D.items()}
  hs=[h0[0],h0[e0//8],h1[0],h1[e1//8]]
  for ax,h in enumerate(hs):
   x=[2,3,5,7];x[ax]=pow(h,-1,P)
   H=at(N,x)*at(Nc,[pow(z,-1,P) for z in x])%P*(math.prod(x)%P)%P
   if ax<2:assert np.all(H==H[:,0,None])
   else:assert np.all(H==H[0,None,:])
   poles+=1
# Nine-signed-original-minor formula verified on arbitrary matrices, not only candidate H.
rng=np.random.default_rng(922048);cb=0
for trial in range(9):
 H=rng.integers(0,P,size=(8,8),dtype=np.int64)
 L=np.column_stack((-np.ones(7,dtype=np.int64),np.eye(7,dtype=np.int64)))
 K=L@H@L.T%P
 for (r,s),(c,d) in itertools.product(v.PAIRS,v.PAIRS):
  rhs=0
  for (a,b),sgn1 in [((0,r),1),((0,s),-1),((r,s),1)]:
   for (e,f),sgn2 in [((0,c),1),((0,d),-1),((c,d),1)]:rhs+=sgn1*sgn2*(int(H[a,e])*int(H[b,f])-int(H[a,f])*int(H[b,e]))
  lhs=int(K[r-1,c-1])*int(K[s-1,d-1])-int(K[r-1,d-1])*int(K[s-1,c-1])
  assert (lhs-rhs)%P==0;cb+=1
T,N,E,hs,stuff=v.build(chart,8,8,256)
c=json.loads((v.ROOT/'candidate/CERTIFICATES_PRIMARY.json').read_text())[0]
B=T[c['selected_rows']].copy();B[:,0]=0
assert v.determinant(B)==0
B=T[c['selected_rows']].copy();B[1]=B[0]
assert v.determinant(B)==0
B=T[c['selected_rows']].copy();B[[0,1]]=B[[1,0]]
assert v.determinant(B)==(-47914)%P
out={'status':'PASS','pole_collapse_checks':poles,'nine_term_Cauchy_Binet_checks':cb,'mutations':{'constant_column_deleted':'REJECTED: determinant zero','duplicate_equation_row':'REJECTED: determinant zero','first_two_rows_swapped':'determinant negates as required'}}
(HERE/'ADDITIONAL_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
