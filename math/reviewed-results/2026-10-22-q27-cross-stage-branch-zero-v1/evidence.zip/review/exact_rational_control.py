#!/usr/bin/env python3
"""Independent Q(i) model/reciprocity control, authored for this review."""
import json,pathlib,itertools,math,time
import numpy as np
from sympy import QQ_I as Q
HERE=pathlib.Path(__file__).resolve().parent
chart=json.loads((HERE.parent/'candidate/sources/CHART.json').read_text())
zero=Q.zero;one=Q.one
I=np.array([[one if r==c else zero for c in range(8)] for r in range(8)],dtype=object)
Z=np.array([[zero]*8 for _ in range(8)],dtype=object)
def cj(q):return Q(q.x,-q.y)
def numerator(edges,x,conjugate=False):
 stages=[];D=[];hol=[];checks=0
 for t,e in enumerate(edges):
  gains=[one]*7+[Q(a,b)/Q(a,-b) for a,b in chart['stages'][t]['gaussian_pairs']]
  if conjugate:gains=[cj(q) for q in gains]
  Bs=[];guards=[];hs=[]
  for b,cy in enumerate(chart['stages'][t]['cycles']):
   W=Z.copy();h=one;h0=one
   for j,v in enumerate(cy):
    k=8*b+j;w=gains[k];h0*=w
    if k==7:w*=x[2*t]
    if k==e:w*=x[2*t+1]
    W[v,cy[j-1]]=w;h*=w
   V=I.copy();B=I.copy()
   for n in range(1,8):V=W@V;B=B+V
   assert np.array_equal(W@V,I*h)
   d=one-h
   assert np.array_equal((I-W)@B,I*d)
   Bs.append(B);guards.append(d);hs.append(h0);checks+=2
  Dt=math.prod(guards);At=Z.copy()
  for b,B in enumerate(Bs):At=At+B*math.prod(guards[:b]+guards[b+1:])
  stages.append(At);D.append(Dt);hol.append(hs)
 return stages[1]@stages[0],stages,D,hol,checks
start=time.time();checks=0;polechecks=0;reciprocity=0
for edges in [(8,8),(23,23)]:
 for vals in [(1,1,1,1),(2,3,5,7)]:
  x=[Q(v) for v in vals]
  N,A,D,hs,n=numerator(edges,x);checks+=n
  Nr,Ar,Dr,_,n=numerator(edges,[one/z for z in x],True);checks+=n
  c=[-one/math.prod(h) for h in hs]
  R=math.prod(x)
  assert np.array_equal(Nr*R,((I*(3*D[1])-A[1].T)@(I*(3*D[0])-A[0].T))*(c[1]*c[0]))
  for t in range(2):
   Rt=x[2*t]*x[2*t+1]
   assert Rt*Dr[t]==c[t]*D[t]
   assert np.array_equal(Ar[t]*Rt,(I*(3*D[t])-A[t].T)*c[t])
  reciprocity+=3
 # Exact pole checks, with the remaining variables uneventfully nonzero.
 hs=[hs[0][0],hs[0][edges[0]//8],hs[1][0],hs[1][edges[1]//8]]
 for ax,h in enumerate(hs):
  x=[Q(2),Q(3),Q(5),Q(7)];x[ax]=one/h
  N,_,_,_,n=numerator(edges,x);checks+=n
  Nr,_,_,_,n=numerator(edges,[one/z for z in x],True);checks+=n
  H=N*Nr*math.prod(x)
  if ax<2:assert np.all(H==H[:,0,None])
  else:assert np.all(H==H[0,None,:])
  polechecks+=1
out={'status':'PASS','field':'Q(i), exact Gaussian rationals','labels':[[7,8,31,32],[7,23,31,47]],'cycle_and_inverse_polynomial_checks':checks,'cleared_reciprocity_checks':reciprocity,'exact_pole_collapse_checks':polechecks,'seconds':round(time.time()-start,3),'scope':'Supplementary exact model checks, not a replacement for the uniform symbolic proof or all512 modular replays.'}
(HERE/'EXACT_RATIONAL_CONTROL.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
