#!/usr/bin/env python3
"""New Q(i) source, direct-inverse, pole and signed-minor controls."""
import hashlib, itertools, json, pathlib
from sympy import QQ_I, symbols, expand
from sympy.polys.matrices import DomainMatrix

HERE=pathlib.Path(__file__).resolve().parent
chart=json.loads((HERE/'sources/CHART.json').read_text())
Z=QQ_I.zero; O=QQ_I.one; I=QQ_I(0,1)
eye=DomainMatrix.eye((8,8),QQ_I).to_dense()
zero=DomainMatrix.zeros((8,8),QQ_I).to_dense()
def dm(rows):return DomainMatrix(rows,(8,8),QQ_I).to_dense()
def eq(a,b):return a.to_list()==b.to_list()
def ser(z):return [str(z.x),str(z.y)]
def conj(z):return QQ_I(z.x,-z.y)

def prepare():
    gains=[];hol=[]
    for st in chart['stages']:
        gs=[O]*7+[QQ_I(a,b)/QQ_I(a,-b) for a,b in st['gaussian_pairs']]
        assert all(g!=Z and g*conj(g)==O for g in gs)
        hs=[]
        for b in range(3):
            h=O
            for g in gs[8*b:8*b+8]:h*=g
            assert h!=O and h!=Z and h*conj(h)==O
            hs.append(h)
        gains.append(gs);hol.append(hs)
    return gains,hol

GAINS,HOLS=prepare()
def original(x):
    stages=[];As=[];Ds=[];guards=[];Bs=[];inverse_checks=0
    for t in range(2):
        gs=GAINS[t].copy();gs[7]*=x[2*t];gs[8]*=x[2*t+1]
        branch=[];ds=[];s=zero; legal=True
        for b,cyc in enumerate(chart['stages'][t]['cycles']):
            rows=[[Z for _ in range(8)] for _ in range(8)]
            h=O
            for j in range(8):
                rows[cyc[j]][cyc[j-1]]=gs[8*b+j];h*=gs[8*b+j]
            W=dm(rows);d=O-h;ds.append(d)
            power=eye;B=eye
            for _ in range(7):power=power*W;B=B+power
            assert eq(power*W,eye.scalarmul(h))
            assert eq((eye-W)*B,eye.scalarmul(d))
            branch.append(B)
            if d!=Z:
                G=(eye-W).inv()
                assert eq(G*(eye-W),eye) and eq((eye-W)*G,eye)
                assert eq(G.scalarmul(d),B)
                s=s+G;inverse_checks+=1
            else:legal=False
        A=zero;D=O
        for d in ds:D*=d
        for b in range(3):
            k=O
            for c in range(3):
                if c!=b:k*=ds[c]
            A=A+branch[b].scalarmul(k)
        stages.append(s if legal else None);As.append(A);Ds.append(D);guards.append(ds);Bs.append(branch)
    N=As[1]*As[0]
    c=O
    for hs in HOLS:
        z=O
        for h in hs:z*=h
        c*=-O/z
    Nt=((eye.scalarmul(3*Ds[1])-As[1].transpose())*(eye.scalarmul(3*Ds[0])-As[0].transpose())).scalarmul(c)
    n=N.to_list();nt=Nt.to_list();H=[[n[r][c]*nt[r][c] for c in range(8)] for r in range(8)]
    if all(s is not None for s in stages):
        assert eq(N,(stages[1]*stages[0]).scalarmul(Ds[1]*Ds[0]))
    return H,guards,inverse_checks

def main():
    assert chart['N']==8 and chart['product_order']=='M=S2*S1' and chart['sum_coefficients']==[1,1,1]
    assert chart['free_phase_indices']==list(range(7,24))
    assert [s['seed'] for s in chart['stages']]==[42420,42520]
    assert (HERE/'sources/CHART.json').read_bytes()==(HERE/'sources/REPOSITORY_CHART.json').read_bytes()
    controls=[]
    cases=[('frozen',[O]*4),('nontrivial_unit',[QQ_I(3,4)/5,-O,I,QQ_I(5,12)/13]),('all_zero',[Z]*4),('mixed_zero',[Z,O,Z,O])]
    for name,x in cases:
        H,guards,n=original(x)
        assert all(d!=Z for st in guards for d in st)
        controls.append({'case':name,'phases':[ser(z) for z in x],'direct_exact_inverse_checks':n,'N_equals_Delta_times_original_M':True,'unit_phases':all(z*conj(z)==O for z in x)})
    hs=[HOLS[0][0],HOLS[0][1],HOLS[1][0],HOLS[1][1]]
    for j,h in enumerate(hs):
        x=[O]*4;x[j]=O/h
        H,guards,n=original(x)
        assert sum(d==Z for st in guards for d in st)==1
        if j<2:assert all(H[r][c]==H[r][0] for r in range(8) for c in range(8))
        else:assert all(H[r][c]==H[0][c] for r in range(8) for c in range(8))
        assert all(H[r][c]-H[r][0]-H[0][c]+H[0][0]==Z for r in range(1,8) for c in range(1,8))
        assert H[0][0]!=Z  # Negative control: raw H entries are not guard-divisible.
        controls.append({'case':'original_pole_'+str(j),'direct_exact_inverse_checks_on_other_branches':n,'one_original_inverse_undefined':True,'collapse':'columns' if j<2 else 'rows','all_centered_entries_zero':True,'raw_H00_nonzero':True})
    h=symbols('h0:9');H=[list(h[0:3]),list(h[3:6]),list(h[6:9])]
    K=[[H[r][c]-H[r][0]-H[0][c]+H[0][0] for c in [1,2]] for r in [1,2]]
    lhs=K[0][0]*K[1][1]-K[0][1]*K[1][0]
    pairs=[(0,1),(0,2),(1,2)];signs=[1,-1,1]
    rhs=sum(signs[i]*signs[j]*(H[a][b]*H[r][c]-H[a][c]*H[r][b]) for i,(a,r) in enumerate(pairs) for j,(b,c) in enumerate(pairs))
    assert expand(lhs-rhs)==0
    out={'exact_field':'Q(i)','target_root_required':False,'all_34_gains_nonzero_norm_one':True,'all_6_frozen_holonomies_nonzero_not_one':True,'frozen_holonomies':[[ser(z) for z in st] for st in HOLS],'source_sha256':hashlib.sha256((HERE/'sources/CHART.json').read_bytes()).hexdigest(),'controls':controls,'nine_signed_original_minors_identity_symbolic':True,'finite_controls_are_supplementary_not_the_universal_proof':True}
    (HERE/'EXACT_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS: exact Q(i) source, 8 original-model controls, and symbolic nine-minor identity')

if __name__=='__main__':main()
