#!/usr/bin/env python3
"""Newly authored direct path-polynomial control. No historical code is imported.

Arithmetic is integral modulo 65537; every intermediate bound is < 2**63.
Run from any directory; source chart is resolved relative to this file.
"""
import argparse, hashlib, itertools, json, math, pathlib, time
import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
P = 65537
PAIRS = list(itertools.combinations(range(7), 2))
EXP2 = list(itertools.product(range(2), repeat=4))
EXP3 = list(itertools.product(range(3), repeat=4))
SUM = np.array([[EXP3.index(tuple(a+b for a,b in zip(e,f))) for f in EXP2] for e in EXP2])
BITS = [sum(e[j] << j for j in range(4)) for e in EXP2]

def stage(chart, t, coordinates, imag):
    """Return the fully cleared stage numerator indexed by variable bitmask."""
    gains = [1]*7 + [((a+imag*b)*pow((a-imag*b)%P,-1,P))%P for a,b in chart['stages'][t]['gaussian_pairs']]
    selected = {c-24*t:j for j,c in enumerate(coordinates) if c//24==t}
    hol, guards, branches = [], [], []
    for b, cyc in enumerate(chart['stages'][t]['cycles']):
        h = math.prod(gains[8*b:8*b+8])%P
        hol.append(h)
        active = sum(1 << selected[e] for e in selected if e//8==b)
        guard = {0:1}
        guard[active] = (guard.get(active,0)-h)%P
        guards.append(guard)
        B = np.zeros((16,8,8),dtype=np.int64)
        # Edge 8*b+j sends cyc[j-1] to cyc[j]. Every source emits paths 0..7.
        for start in range(8):
            v=cyc[start]; coeff=1; mask=0
            B[0,v,v]=1
            for length in range(1,8):
                j=(start+length)%8; e=8*b+j
                coeff=coeff*gains[e]%P
                if e in selected: mask |= 1 << selected[e]
                B[mask,cyc[j],v]=coeff
        branches.append(B)
    A = np.zeros((16,8,8),dtype=np.int64)
    for b,B in enumerate(branches):
        V=B.copy()
        for c in range(3):
            if c==b:continue
            U=np.zeros_like(V)
            for m in range(16):
                if not V[m].any():continue
                for n,coef in guards[c].items():
                    assert m&n==0
                    U[m|n]=(U[m|n]+V[m]*coef)%P
            V=U
        A=(A+V)%P
    return A,hol,guards,gains

def numerator(chart,coordinates,imag):
    a,h0,g0,w0=stage(chart,0,coordinates,imag)
    b,h1,g1,w1=stage(chart,1,coordinates,imag)
    N=np.zeros((16,8,8),dtype=np.int64)
    for i in range(16):
        if not b[i].any():continue
        for j in range(16):
            if not a[j].any():continue
            assert i&j==0
            N[i|j]=(N[i|j]+b[i]@a[j])%P
    return N,(h0,h1),(g0,g1),(w0,w1)

def build(chart,coordinates,imag=256):
    N,hol,guards,gains=numerator(chart,coordinates,imag)
    Nc,_,_,_=numerator(chart,coordinates,(-imag)%P)
    H=np.zeros((81,8,8),dtype=np.int64)
    for i,m in enumerate(BITS):
        for j,n in enumerate(BITS):
            k=SUM[i,j]
            H[k]=(H[k]+N[m]*Nc[15^n])%P
    H=H.reshape(3,3,3,3,8,8)
    K=(H[...,1:,1:]-H[...,1:,0,None]-H[...,None,0,1:]+H[...,0,0,None,None])%P
    active=[]
    for t in range(2):
        for b in range(3):
            e=tuple(int(c//24==t and (c%24)//8==b) for c in coordinates)
            if any(e):active.append((e,hol[t][b]))
    V=K.copy()
    order=sorted(EXP3,key=sum)
    for mask,h in active:
        Q=np.zeros_like(V)
        for e in order:
            Q[e]=V[e]
            if all(a>=b for a,b in zip(e,mask)):
                prev=tuple(a-b for a,b in zip(e,mask))
                Q[e]=(Q[e]+h*Q[prev])%P
        assert all(not Q[e].any() for e in EXP3 if any(a==2 and b for a,b in zip(e,mask))),('guard division',mask)
        V=Q
    assert all(not V[e].any() for e in EXP3 if 2 in e)
    E=V[:2,:2,:2,:2]
    # Full multiply-back, retaining every coefficient of the entire 3^4 cube.
    F={tuple([0]*4):1}
    for mask,h in active:
        U=dict(F)
        for e,coef in F.items():
            f=tuple(a+b for a,b in zip(e,mask)); U[f]=(U.get(f,0)-h*coef)%P
        F=U
    back=np.zeros_like(K)
    for e in EXP2:
        for f,coef in F.items():
            g=tuple(a+b for a,b in zip(e,f));back[g]=(back[g]+E[e]*coef)%P
    assert np.array_equal(back,K)
    T=np.zeros((441,81),dtype=np.int64)
    Ef=E.reshape(16,7,7)
    for w,((a,r),(b,c)) in enumerate(itertools.product(PAIRS,PAIRS)):
        for i in range(16):
            # 16 products per row. Reduction is done before additions.
            v=(Ef[i,a,b]*Ef[:,r,c]-Ef[i,a,c]*Ef[:,r,b])%P
            T[w,SUM[i]]=(T[w,SUM[i]]+v)%P
    return T, {'holonomies':hol,'active_guard_monomials':active,'all_frozen_guards_nonzero':all((1-h)%P for st in hol for h in st),'numerator_nonzero_coefficients':int(np.count_nonzero(N)),'E_nonzero_coefficients':int(np.count_nonzero(E))},N,E

def selected_minor(A):
    """Streaming exact elimination; selected original rows in ascending order.

    Full column rank selects exactly n original rows. The determinant of their
    matrix in that order is the product of their pivots (no row permutations).
    """
    pivots=[]; rows=[]; det=1
    for row_id,row in enumerate(A):
        v=row.copy()
        for p,u in pivots:
            if v[p]:v=(v-v[p]*u)%P
        nz=np.flatnonzero(v)
        if not len(nz):continue
        p=int(nz[0]);z=int(v[p]);det=det*z%P
        v=v*pow(z,-1,P)%P
        pivots.append((p,v));rows.append(row_id)
        if len(rows)==A.shape[1]:break
    # When pivots arrive in a nonascending order, reorder creates sign parity.
    perm=[p for p,_ in pivots]
    inversions=sum(perm[i]>perm[j] for i in range(len(perm)) for j in range(i+1,len(perm)))
    if inversions%2:det=-det%P
    return {'rank':len(rows),'selected_rows':rows,'pivot_columns':perm,'determinant_residue':int(det) if len(rows)==A.shape[1] else None}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--coordinates',type=int,nargs=4,default=[7,8,31,32]);ap.add_argument('--imag',type=int,default=256);ap.add_argument('--all',action='store_true');ap.add_argument('--output',default='CONTROL.json');args=ap.parse_args()
    data=(HERE/'sources/CHART.json').read_bytes();chart=json.loads(data)
    assert hashlib.sha256(data).hexdigest()=='5528afbbd5b4008a5e0f79043870e72a613e0fd421288d2ce1e5dbffee1c9e98'
    assert all(P%d for d in range(2,math.isqrt(P)+1))
    assert args.imag*args.imag%P==P-1
    assert all((a+args.imag*b)%P and (a-args.imag*b)%P for st in chart['stages'] for a,b in st['gaussian_pairs'])
    outputs=[];start=time.time()
    extras=list(range(8,24))+list(range(32,48))
    labels=[[7,a,31,b] for a in range(8,24) for b in range(32,48)] if args.all else [args.coordinates]
    for coords in labels:
        assert len(set(coords))==4 and 7 in coords and 31 in coords and all(c in extras+[7,31] for c in coords)
        T,info,N,E=build(chart,coords,args.imag)
        cert=selected_minor(T)
        cert.update({'encoded_coordinates':coords, 'prime':P,'imaginary_embedding':args.imag,'columns':EXP3,'model_checks':info,'equation_matrix_sha256':hashlib.sha256(T.astype('<u4').tobytes()).hexdigest()})
        outputs.append(cert)
        print(json.dumps({'coordinates':coords,'rank':cert['rank'],'det':cert['determinant_residue'],'seconds':round(time.time()-start,2)}),flush=True)
    pathlib.Path(args.output).write_text(json.dumps(outputs,indent=2)+'\n')

if __name__=='__main__':main()
