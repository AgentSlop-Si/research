# Reproduction

These are newly authored candidate controls, not historical source programs.
Use Python 3 with NumPy and SymPy; the author used NumPy 2.3.5 and SymPy 1.14.0.
No network connection or repository checkout is needed for the calculations.

From this candidate directory:

    python check_cross_stage.py --all --output CERTIFICATES_PRIMARY.json > PRIMARY.log
    python check_cross_stage.py --all --imag 65281 --output CERTIFICATES_CONJUGATE.json > CONJUGATE.log
    python exact_controls.py > EXACT_CONTROLS.log

The first two commands construct the entire model and all 441 equations for
each of 256 labels, divide all four original guards, check complete multiply-back,
and select the full 81-column coefficient minors. For an independent replay,
use the recorded row IDs rather than selecting replacement rows. Equation
matrix hashes are SHA256 of the441-by 81 row-major residue array, unsigned
little-endian 32-bit integers in 0,...,65536. Output logs contain elapsed time
and are not bit-reproducible; certificate JSON and exact-control JSON are
deterministic.

The final command checks all original gains and frozen holonomies exactly over
Q(i), verifies the repository and accepted-packet chart bytes agree, and runs
four legal original-inverse points (including nonunit zero-coordinate algebraic
controls) plus all four single-pole controls at the [7,8,31,32] label. The poles
are excluded from feasibility, not silently inverted. H00 is nonzero at those
poles while every double-centered entry is zero, a negative control showing
that raw H entries must not be substituted for the divided centered entries.
The nine-original-minor identity is independently expanded symbolically.

The exact symbolic argument is in PROOF.md. Finite evaluations are supplementary
model controls, not a proof of universal exclusion. The all 256 coefficient
certificates become characteristic-zero certificates only with the proved
support, coefficient-ring map, original-guard conditions and adjugate argument.

Source-program policy: the original chart is inert data. No predecessor source
program is bundled, imported, executed or compiled. The earlier accepted proof
and source boundaries are identified in SOURCE_BINDINGS.json. There are no
external writes, repository publications or table updates in these commands.
