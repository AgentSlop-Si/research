# ALG-076 adaptive-information gate candidate

Result: the sharp absolute Gaussian success ceiling extends from fixed linear sketches to transcript-adaptive noiseless complex-linear queries with an independent seed, almost surely finite transcript-based stopping, and a hard bound on total acquired complex rank.

Read REPORT.md for the full proof, exact scope, classical attribution, separate relative-error consequences and counterexamples to expected-rank or raw-input-direction substitutions. EXACT_CONTROLS.json records the newly authored exact rational controls. Original project source text is inert and is never executed.

Run only the newly authored control: python verify_adaptive_updates.py

Disposition: candidate for independent review. No external publication or table edits occurred. After scoped acceptance, complete only this adaptive-information subgate; preserve ALG-076 TO RESEARCH/42 and all other obligations. No novelty, universal FFT lower bound, production result or owner retirement is claimed.
