#!/usr/bin/env python3
"""New exact algebra controls; no historical source is executed or imported."""
from fractions import Fraction as F
from dataclasses import dataclass
import json
import random

@dataclass(frozen=True)
class C:
    re: F = F(0)
    im: F = F(0)
    def __post_init__(self):
        object.__setattr__(self, 're', F(self.re))
        object.__setattr__(self, 'im', F(self.im))
    @staticmethod
    def cast(v): return v if isinstance(v, C) else C(v)
    def __add__(self, o):
        o=C.cast(o); return C(self.re+o.re,self.im+o.im)
    __radd__=__add__
    def __neg__(self): return C(-self.re,-self.im)
    def __sub__(self,o): return self+-C.cast(o)
    def __rsub__(self,o): return C.cast(o)+-self
    def __mul__(self,o):
        o=C.cast(o); return C(self.re*o.re-self.im*o.im,self.re*o.im+self.im*o.re)
    __rmul__=__mul__
    def __truediv__(self,o):
        o=C.cast(o); s=o.re*o.re+o.im*o.im
        if not s: raise ZeroDivisionError
        return self*o.conj()*C(1/s)
    def conj(self): return C(self.re,-self.im)
    def abs2(self): return self.re*self.re+self.im*self.im

ZERO=C(); ONE=C(1)
def dot(a,b): return sum((u.conj()*v for u,v in zip(a,b)), ZERO)
def mv(A,v): return [sum((a*b for a,b in zip(row,v)),ZERO) for row in A]
def ident(n): return [[C(int(i==j)) for j in range(n)] for i in range(n)]
def sub(a,b): return [u-v for u,v in zip(a,b)]
def mm(A,B): return [[sum((A[i][j]*B[j][k] for j in range(len(B))),ZERO) for k in range(len(B[0]))] for i in range(len(A))]
def trace(A): return sum((A[i][i] for i in range(len(A))),ZERO)
def unit(n,j): return [C(int(i==j)) for i in range(n)]

def invariant(Q,m,x,past,r):
    n=len(x)
    assert Q==[[Q[j][i].conj() for j in range(n)] for i in range(n)]
    assert mm(Q,Q)==Q
    assert trace(Q)==C(n-r)
    assert mv(Q,m)==[ZERO]*n
    assert sub(x,m)==mv(Q,x)
    for a,z in past:
        assert mv(Q,a)==[ZERO]*n
        assert dot(a,m)==z

def query_from_history(n,j,hist,rng):
    """No x argument: a new query uses the independent seed and past only."""
    if j%5==0: return [ZERO]*n
    if j%5==2 and hist:
        a,z=hist[-1]
        return [C(2,1)*u for u in a]
    a=[C(rng.randrange(-2,3),rng.randrange(-2,3)) for _ in range(n)]
    if hist:
        # Bounded adaptive branch, and a transcript-dependent complex scalar.
        y=hist[-1][1]
        pivot=(0 if y.re>=0 else 1)%n
        a[pivot]=a[pivot]+C(1 if y.im>=0 else -1,1)
        a[(pivot+1)%n]=a[(pivot+1)%n]+y/(1+y.abs2())
    return a

def run_case(n,trial):
    rng=random.Random(10000*n+trial)
    x=[C(rng.randrange(-3,4),rng.randrange(-3,4)) for _ in range(n)]
    m=[ZERO]*n; Q=ident(n); hist=[]; r=0; zeros=0; positives=0
    # rank cap n-1, not a cap on number of scalar queries
    for j in range(1,2*n+8):
        a=query_from_history(n,j,hist,rng)
        if r==n-1:
            # Stay in observed span using transcript-known vectors only.
            a=[ZERO]*n if not hist else [C(1,1)*u for u in hist[0][0]]
        z=dot(a,x)
        v=mv(Q,a); lam=dot(a,v)
        assert lam.im==0 and lam.re>=0
        assert lam.re==sum(t.abs2() for t in v)
        assert mv(Q,v)==v
        if lam!=ZERO:
            innovation=z-dot(a,m)
            m=[u+t*innovation/lam for u,t in zip(m,v)]
            Q=[[Q[i][k]-v[i]*v[k].conj()/lam for k in range(n)] for i in range(n)]
            r+=1; positives+=1
        else:
            assert z==dot(a,m); zeros+=1
        hist.append((a,z))
        invariant(Q,m,x,hist,r)
        # A genuine transcript-based stop, after redundant-query coverage.
        if j>=n+3 and z.re<=0 and trial%3==0: break
    assert r<=n-1
    return {'queries':len(hist),'rank':r,'zero_innovations':zeros,'positive_innovations':positives}

def gamma_tail_coeff(d,t):
    acc=F(0); term=F(1)
    for j in range(d):
        if j: term*=t/F(j)
        acc+=term
    return acc

if __name__=='__main__':
    cases=[run_case(n,t) for n in range(2,8) for t in range(12)]
    # G_d(t)=1-exp(-t)*gamma_tail_coeff(d,t). Exact expected-rank counterexample.
    mixture=(gamma_tail_coeff(3,F(1))+gamma_tail_coeff(1,F(1)))/2
    claimed=gamma_tail_coeff(2,F(1))
    assert mixture==F(7,4) and claimed==2 and claimed-mixture==F(1,4)
    # Nonorthogonal proper-complex update, explicitly: a=(1,i), x=(2-i,3+2i).
    a=[C(1),C(0,1)]; x=[C(2,-1),C(3,2)]
    lam=dot(a,a); z=dot(a,x)
    assert lam==C(2)
    m=[v*z/lam for v in a]
    Q=[[C(int(i==j))-a[i]*a[j].conj()/lam for j in range(2)] for i in range(2)]
    invariant(Q,m,x,[(a,z)],1)
    # Forbidden raw-input-direction example with rational norm 5.
    x=[C(3),C(0,4),C()]; direction=[v/5 for v in x]
    assert dot(direction,direction)==ONE
    z=dot(direction,x)
    assert z==C(5) and [z*v for v in direction]==x
    out={'status':'PASS','new_program_only':True,'historical_programs_executed':False,
         'adaptive_rational_transcripts':len(cases),
         'total_queries':sum(c['queries'] for c in cases),
         'zero_innovations':sum(c['zero_innovations'] for c in cases),
         'positive_innovations':sum(c['positive_innovations'] for c in cases),
         'queries_exceed_rank_cases':sum(c['queries']>c['rank'] for c in cases),
         'projector_and_row_invariants':'exact Gaussian-rational arithmetic at every step',
         'expected_rank_counterexample_difference':'exp(-1)/4 > 0',
         'raw_input_direction_boundary':'one nominal query plus forbidden data-dependent direction reconstructs x',
         'probability_and_all_N_proof':'REPORT.md; not inferred from finite checks'}
    print(json.dumps(out,indent=2))
