#!/usr/bin/env python3
"""Fresh reviewer controls. No candidate or historical code is loaded or run."""
from fractions import Fraction as F
from math import factorial
import json

def q(r=0, i=0): return (F(r), F(i))
Z=q(); O=q(1)
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def neg(a): return (-a[0],-a[1])
def sub(a,b): return add(a,neg(b))
def conj(a): return (a[0],-a[1])
def mul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def div(a,b):
    den=b[0]*b[0]+b[1]*b[1]
    return (mul(a,conj(b))[0]/den,mul(a,conj(b))[1]/den)
def total(xs):
    ans=Z
    for x in xs: ans=add(ans,x)
    return ans
def inner(a,b): return total(mul(conj(x),y) for x,y in zip(a,b))
def vadd(a,b): return [add(x,y) for x,y in zip(a,b)]
def vsub(a,b): return [sub(x,y) for x,y in zip(a,b)]
def scale(c,a): return [mul(c,x) for x in a]
def eye(n): return [[O if i==j else Z for j in range(n)] for i in range(n)]
def mv(A,x): return [total(mul(a,b) for a,b in zip(row,x)) for row in A]
def adj(A): return [[conj(A[j][i]) for j in range(len(A))] for i in range(len(A[0]))]
def mm(A,B):
    return [[total(mul(A[i][k],B[k][j]) for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def rank(rows,n):
    # Independent exact elimination, not the recursive covariance formula.
    A=[r[:] for r in rows]; h=0
    for col in range(n):
        pivot=next((i for i in range(h,len(A)) if A[i][col]!=Z),None)
        if pivot is None: continue
        A[h],A[pivot]=A[pivot],A[h]
        c=A[h][col]; A[h]=[div(v,c) for v in A[h]]
        for i in range(len(A)):
            if i!=h: A[i]=vsub(A[i],scale(A[i][col],A[h]))
        h+=1
    return h

counts={'transcripts':0,'queries':0,'positive_innovations':0,'zero_innovations':0,
        'zero_time_stops':0,'early_history_stops':0,'full_rank_cases':0,
        'gamma_polynomial_checks':0,'dyadic_cost_checks':0}
for n in range(1,7):
  for trial in range(18):
    for seed in range(3):
      x=[q(((trial+2)*(j+3))%9-4,((trial+5)*(j+1))%7-3) for j in range(n)]
      m=[Z]*n; Q=eye(n); rows=[]; zs=[]
      counts['transcripts']+=1
      if seed==0 and trial%4==0:
        counts['zero_time_stops']+=1
        continue
      # Query rule below depends only on seed, previous observations, and j.
      # Full-rank cases are update controls, not hard-k<N theorem instances.
      cap=n if trial%6==0 else max(0,n-1)
      for j in range(4*cap+5):
        observed=zs[-1] if zs else Z
        if j%4==0 or cap==0: a=[Z]*n
        elif j%4==2 and rows: a=scale(q(2,-1),rows[-1])
        elif j%4==3 and rows: a=vadd(rows[-1],scale(q(-1,2),rows[1]))
        elif rank(rows,n)<cap:
            s=1 if observed[0]>=0 else -1
            a=[q((j+seed+2*h)%5-2,s*((2*j+h+seed)%3-1)) for h in range(n)]
        else: a=scale(q(-2,1),rows[1]) if len(rows)>1 else [Z]*n
        z=inner(a,x); v=mv(Q,a); lam=inner(a,v)
        assert lam[1]==0 and lam[0]>=0 and lam==inner(v,v)
        oldQ=[r[:] for r in Q]
        if lam!=Z:
            counts['positive_innovations']+=1
            eta=sub(z,inner(a,m))
            m=vadd(m,scale(div(eta,lam),v))
            Q=[[sub(Q[i][h],div(mul(v[i],conj(v[h])),lam)) for h in range(n)] for i in range(n)]
            # Conditional cross-covariance is zero; covariance is Schur update.
            assert mv(Q,a)==[Z]*n
            assert mm(Q,oldQ)==Q and mm(oldQ,Q)==Q
        else:
            counts['zero_innovations']+=1
            assert z==inner(a,m)
        rows.append(a); zs.append(z); counts['queries']+=1
        r=rank(rows,n)
        assert r<=cap and Q==adj(Q) and mm(Q,Q)==Q
        assert total(Q[h][h] for h in range(n))==q(n-r)
        assert mv(Q,m)==[Z]*n
        assert m==vsub(x,mv(Q,x))
        assert all(inner(a0,m)==z0 and mv(Q,a0)==[Z]*n for a0,z0 in zip(rows,zs))
        # Stopping depends on the just-observed data, not an unobserved input.
        if j>=2 and seed==2 and z[0]<0:
            counts['early_history_stops']+=1
            break
      if rank(rows,n)==n: counts['full_rank_cases']+=1

# Gamma derivative: P_{d-1}-P'_{d-1}=t^(d-1)/(d-1)!.
for d in range(1,33):
    P=[F(1,factorial(j)) for j in range(d)]
    D=[P[j]-(j+1)*P[j+1] if j<d-1 else P[j] for j in range(d)]
    assert D==[F(0)]*(d-1)+[F(1,factorial(d-1))]
    counts['gamma_polynomial_checks']+=1

# Expected-rank mixture at t=1: no floating exp or noninteger-rank substitution.
P1=F(1); P2=F(2); P3=F(5,2)
assert (P3+P1)/2==F(7,4)
assert P2-(P3+P1)/2==F(1,4)

# Fresh exact enclosure of inherited finite certificate, using e^1 only.
terms=48
lo=sum((F(1,factorial(j)) for j in range(terms+1)),F(0))
hi=lo+F(1,factorial(terms+1))*F(terms+2,terms+1)
bound=hi**208*F(20,33)**528 + F(5,4)**1024/lo**256
threshold=F(12,10**13)
assert bound<threshold

# Charge actual rows, including unit-size factors; a cap is not a row count.
for lk in range(0,10):
  for lm in range(0,10):
    K=2**lk; M=2**lm; N=K*M
    for R in (0,1,M,2*M+1):
      lhs=F(R*K*lk+N*lm,2)
      rhs=F(N,2)*(F(R,M)*lk+lm)
      assert lhs==rhs
      counts['dyadic_cost_checks']+=1
cap_cost=F(16*16*4+256*4,2)
actual_cost=F(1*16*4+256*4,2)
assert cap_cost>actual_cost

result={
 'status':'PASS', 'counts':counts,
 'expected_rank_counterexample_gap':'exp(-1)/4 > 0',
 'inherited_certificate':{'upper_bound_decimal_display_only':float(bound),
   'exact_rational_comparison':'strictly less than 12/10^13'},
 'query_cap_cost_witness':{'K':16,'M':16,'cap_rows':16,'executed_rows':1,
   'cap_butterflies':int(cap_cost),'executed_butterflies':int(actual_cost)},
 'limitations':'Algebra controls do not prove distributional conditioning or arbitrary stopping; independent mathematical argument is in REVIEW.md. No author/historical script was imported or executed.'}
print(json.dumps(result,indent=2))
