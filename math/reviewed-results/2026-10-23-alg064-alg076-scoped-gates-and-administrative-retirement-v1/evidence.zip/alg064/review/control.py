"""Independent verifier-owned exact controls. No candidate/historical imports or execution.
Complex least squares is solved through a 2L real normal system, not candidate's
2x2 complex inverse. All scientific checks remain active under Python -O.
"""
from fractions import Fraction as F
from dataclasses import dataclass
from random import Random
import hashlib,json,pathlib
ROOT=pathlib.Path('/workspace/shared/alg064_noisy_discovery_20261023_v1')
counts={}
def ck(test,tag):
    if not test: raise RuntimeError(tag)
    counts[tag]=counts.get(tag,0)+1
@dataclass(frozen=True)
class Q:
    a:F=F(0);b:F=F(0)
    def __post_init__(self):
        object.__setattr__(self,'a',F(self.a));object.__setattr__(self,'b',F(self.b))
    def __add__(u,v):
        if not isinstance(v,Q):v=Q(v)
        return Q(u.a+v.a,u.b+v.b)
    __radd__=__add__
    def __neg__(u):return Q(-u.a,-u.b)
    def __sub__(u,v):return u+-v
    def __mul__(u,v):
        if not isinstance(v,Q):v=Q(v)
        return Q(u.a*v.a-u.b*v.b,u.a*v.b+u.b*v.a)
    __rmul__=__mul__
    def bar(u):return Q(u.a,-u.b)
    def n2(u):return u.a*u.a+u.b*u.b
    def nu(u):return abs(u.a)+abs(u.b)
    def __pow__(u,n):
        v=Q(1)
        for _ in range(n):v=v*u
        return v
Z=Q();ONE=Q(1)
def dot(u,v):return sum((a.bar()*b for a,b in zip(u,v)),Z)
def sq(v):return sum((a.n2() for a in v),F(0))
def nu(v):return sum((a.nu() for a in v),F(0))
def solve(M,b):
    A=[list(row)+[v] for row,v in zip(M,b)]; n=len(b)
    for col in range(n):
        piv=next((i for i in range(col,n) if A[i][col]),None)
        if piv is None:return None
        A[col],A[piv]=A[piv],A[col]
        u=A[col][col];A[col]=[v/u for v in A[col]]
        for i in range(n):
            if i!=col:
                u=A[i][col];A[i]=[v-u*w for v,w in zip(A[i],A[col])]
    return [row[-1] for row in A]
def pow2(j):return F(2**j) if j>=0 else F(1,2**(-j))
def bracket(g):
    j=(g.numerator.bit_length()-g.denominator.bit_length())//2
    while pow2(2*j)>g:j-=1
    while pow2(2*j+2)<=g:j+=1
    return pow2(j)
def proposal(x,L):
    A=[x[j-L:j][::-1] for j in range(L,len(x))];b=x[L:]
    rows=[];rhs=[]
    for ar,t in zip(A,b):
        rows.extend([[v.a for v in ar]+[-v.b for v in ar], [v.b for v in ar]+[v.a for v in ar]])
        rhs.extend([-t.a,-t.b])
    M=[[sum((row[i]*row[j] for row in rows),F(0)) for j in range(2*L)] for i in range(2*L)]
    w=[sum((row[i]*v for row,v in zip(rows,rhs)),F(0)) for i in range(2*L)]
    s=solve(M,w)
    if s is None:return None
    c=[Q(s[i],s[i+L]) for i in range(L)]
    r=[t+sum((u*v for u,v in zip(row,c)),Z) for row,t in zip(A,b)]
    cols=list(zip(*A));G=[[dot(u,v) for v in cols] for u in cols]
    trace=sum((G[i][i].a for i in range(L)),F(0))
    determinant=G[0][0].a if L==1 else G[0][0].a*G[1][1].a-G[0][1].n2()
    gamma=determinant if L==1 else determinant/trace
    lo=bracket(gamma)
    ck(gamma>0 and lo*lo<=gamma<4*lo*lo,'sigma_bracket')
    ck(all(dot(col,r)==Z for col in cols),'full_normal_equations')
    ck(G[0][0].a>=lo*lo,'gram_shift_psd')
    if L==2:
        ck(G[1][1].a>=lo*lo and (G[0][0].a-lo*lo)*(G[1][1].a-lo*lo)>=G[0][1].n2(),'gram_shift_psd')
    return dict(c=c,r=r,A=A,s=lo,gram=G,trace=trace)
def residual(x,c,L):return [x[j]+sum((c[i-1]*x[j-i] for i in range(1,L+1)),Z) for j in range(L,len(x))]
def nearest(t,b):
    u=t*2**b
    return F((2*u.numerator+u.denominator)//(2*u.denominator),2**b)
def roundq(t,b):return Q(nearest(t.a,b),nearest(t.b,b))
def certify(x,L,p,epsilon):
    S=nu(x);tau=F(1,(2*len(x))**L)
    raw=max((v.denominator.bit_length()-1 for u in x for v in (u.a,u.b)),default=0)
    b=raw
    while pow2(-b)>epsilon*tau/(16*L*(S+1)):b+=1
    c=[roundq(u,b) for u in p['c']];r=residual(x,c,L);R=nu(r)
    ck(all((u-v).nu()<=pow2(-b) for u,v in zip(c,p['c'])),'coefficient_round_bound')
    ck(R<=nu(p['r'])+L*pow2(-b)*S,'whole_tail_round_bound')
    ck(nu(p['r'])>epsilon*tau/16 or R<=epsilon*tau/8,'sufficient_gate')
    # Verify the entire polynomial identity, not just rational Fourier nodes.
    C=[ONE]+c;product=[Z]*(len(x)+L)
    for i,u in enumerate(C):
        for j,v in enumerate(x):product[i+j]=product[i+j]+u*v
    P=product[:L];B=product[len(x):];bound=[u+v for u,v in zip(P,B)]
    expected=P+r+[Z]*L
    for j,v in enumerate(B):expected[len(x)+j]=expected[len(x)+j]+v
    ck(product==expected,'full_convolution_identity')
    for t in (ONE,Q(-1),Q(0,1),Q(0,-1)):
        if t**len(x)!=ONE:continue
        ev=lambda a:sum((v*t**i for i,v in enumerate(a)),Z)
        E=[Z]*L+r
        ck(ev(C)*ev(x)==ev(bound)+ev(E),'exact_node_interface')
    return R<=epsilon*tau/8,R,c,b
rng=Random(6402301);fixtures=[]
for N in (2,3,4,5,9,17,32):
    for L in (1,2):
        if N<=L:continue
        for _ in range(6):
            x=[Q(F(rng.randrange(-8,9),16),F(rng.randrange(-8,9),16)) for j in range(N)]
            fixtures.append((x,L,None,None,'generic'))
        stars=([Q(-1)], [Q(F(-1,2),F(1,2))]) if L==1 else ([Q(-2),Q(1)],[Q(F(-1,2)),Q(F(1,4),F(1,4))],[Q(-1),Q(0)])
        for star in stars:
            y=[Q(1),Q(F(3,2),F(1,2))][:L]
            while len(y)<N:y.append(-sum((star[i-1]*y[-i] for i in range(1,L+1)),Z))
            for bits in (0,16,80):
                e=[Z]*N if bits==0 else [Q(F(rng.randrange(-1,2),2**bits),F(rng.randrange(-1,2),2**bits)) for j in range(N)]
                fixtures.append(([u+v for u,v in zip(y,e)],L,star,nu(e),'model'))
for b in (12,100,300):
    fixtures.append(([Q(1),Q(1),Q(1),Q(1+F(1,2**b)),Q(1)],2,None,None,'near_rank_one'))
fixtures.extend([([Z]*7,2,None,None,'zero'),([Q(2**i) for i in range(8)],2,None,None,'rank_refusal_not_nonmembership'),([ONE,ONE]+[Z]*7,2,None,None,'degree_zero')])
accepted=nonzero=refused=rankfail=perturb=conditional=0; special={}
for index,(x,L,star,eta,tag) in enumerate(fixtures):
    p=proposal(x,L)
    if p is None:
        rankfail+=1
        if tag=='rank_refusal_not_nonmembership':ck(residual(x,[Q(-2),Z],2)==[Z]*6,'rank_refusal_not_nonmembership')
        continue
    for shift in ([Q(0)]*L,[Q(1)]*L,[Q(F(1,3),F(-1,5))]*L):
        d=[a+b for a,b in zip(p['c'],shift)]
        Ad=[sum((a*b for a,b in zip(row,shift)),Z) for row in p['A']]
        ck(sq(residual(x,d,L))==sq(p['r'])+sq(Ad),'ls_optimality_identity')
    ok,R,c,b=certify(x,L,p,F(1,8))
    accepted+=ok;nonzero+=bool(ok and R);refused+=not ok
    if tag=='degree_zero':ck(c==[Z,Z] and R==0,'declared_span_not_degree');special['zero_degree']=True
    if star is not None:
        bd=eta*(1+L*nu(star))/p['s']
        ck(sq([a-b for a,b in zip(p['c'],star)])<=bd*bd,'external_model_bound')
        a=eta/p['s']
        if L*a<1:
            bound=a*(1+L*nu(p['c']))/(1-L*a)
            ck(sq([a-b for a,b in zip(p['c'],star)])<=bound*bound,'observable_conditional_bound');conditional+=1
        ck(sq(p['r'])<=eta*eta*(1+L*nu(star))**2,'model_residual_optimality')
        # Rational sufficient class stronger than report's sqrt(2m) bound.
        if 2*(len(x)-L)*eta*(1+L*nu(star))<=F(1,8)*F(1,(2*len(x))**L)/16:
            ck(ok,'small_noise_acceptance')
    if index%3==0:
        e=[Q(F(rng.randrange(-1,2),2**24),F(rng.randrange(-1,2),2**24)) for _ in x]
        xp=[u+v for u,v in zip(x,e)];p2=proposal(xp,L)
        if p2 is not None:
            eta=nu(e);bound=L*eta*nu(p['r'])/(p2['s']**2)+eta*(1+L*nu(p['c']))/p2['s']
            ck(sq([a-b for a,b in zip(p2['c'],p['c'])])<=bound*bound,'proposal_map_bound');perturb+=1
# Explicit exact countercontrols: prefix fit, omitted conjugation, coarse grid,
# conditioning overclaim, and dangerous trajectory interpretation.
x=[ONE]*8+[Q(2)];p=proposal(x,1)
ck(p['c']!=[Q(-1)] and nu(p['r'])>0,'late_tail_changes_proposal')
ck(not certify(x,1,p,F(1,8))[0],'late_tail_residual_refusal')
x=[Q(1,1),Q(2,-1),Q(-1,2),Q(1,-2),Q(3,1)];p=proposal(x,1)
num=-sum((x[j-1]*x[j] for j in range(1,len(x))),Z);den=sum((x[j-1]*x[j-1] for j in range(1,len(x))),Z)
wrong=num*den.bar()*(1/den.n2())
ck(dot([u[0] for u in p['A']],residual(x,[wrong],1))!=Z,'wrong_conjugation_rejected')
x=[ONE]+[Q(F(1,2**j)) for j in range(1,12)];p=proposal(x,1)
ck(nu(residual(x,[roundq(u,0) for u in p['c']],1))>F(1,8)*F(1,2*len(x))/8,'coarse_rounding_rejected')
p=proposal([ONE,ONE,ONE,Q(1+F(1,2**100)),ONE],2)
g=p['gram'];bad=p['trace']
ck((g[0][0].a-bad)*(g[1][1].a-bad)-g[0][1].n2()>=0 and g[0][0].a-bad<0,'false_condition_bound_rejected')
x=[Z]+[Q(F(2**(j-1),2**80)) for j in range(1,65)]
ck(nu(residual(x,[Q(-2)],1))==F(1,2**80) and x[-1].a==F(2**63,2**80),'small_defect_large_trajectory_error')
# Check all frozen member and source byte/Git bindings without importing them.
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
for entry in manifest['public_files']+manifest['source_capture_files']:
    data=(ROOT/entry['path']).read_bytes();ck(hashlib.sha256(data).hexdigest()==entry['sha256'] and len(data)==entry['bytes'],'candidate_member_binding')
for entry in json.loads((ROOT/'SOURCE_REGISTER.json').read_text())['sources']:
    data=(ROOT/'sources'/entry['file']).read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    ck(blob==entry['git_blob']==entry['computed_git_blob'],'source_git_binding')
result={'status':'PASS','counts':counts,'total_checks':sum(counts.values()),'fixtures':len(fixtures),'accepted':accepted,'accepted_nonzero_residual':nonzero,'residual_refusal':refused,'rank_refusal':rankfail,'proposal_perturbations':perturb,'conditional_bounds':conditional,'method':'fresh reviewer-owned exact rational real-block solve; no author or historical program executed','no_dft_backend_executed':True}
print(json.dumps(result,indent=2,sort_keys=True))
