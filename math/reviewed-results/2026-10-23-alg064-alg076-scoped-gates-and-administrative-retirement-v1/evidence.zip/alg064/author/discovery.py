"""Fresh exact-reference noisy recurrence discovery. No historical imports.
Gaussian rational numbers are (real Fraction, imaginary Fraction).
This is NOT a floating-point normal-equations implementation.
"""
from fractions import Fraction as F
from math import isqrt

Z=(F(0),F(0)); ONE=(F(1),F(0))
def z(a=0,b=0):return (F(a),F(b))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def sub(a,b):return add(a,neg(b))
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def conj(a):return (a[0],-a[1])
def scale(a,s):return (a[0]*s,a[1]*s)
def norm2(a):return a[0]*a[0]+a[1]*a[1]
def nu(a):return abs(a[0])+abs(a[1])
def div(a,b):return scale(mul(a,conj(b)),1/norm2(b))
def dot(a,b):
 out=Z
 for x,y in zip(a,b):out=add(out,mul(conj(x),y))
 return out

def pow2(k):return F(2**k) if k>=0 else F(1,2**(-k))
def sqrt_floor_dyadic(q):
 """s>0, s^2<=q<4s^2, chosen without real sqrt."""
 if q<=0:raise ValueError('positive rational required')
 e=(q.numerator.bit_length()-q.denominator.bit_length())//2
 s=pow2(e)
 while s*s>q:s/=2
 while 4*s*s<=q:s*=2
 return s

def round_f(x,b):
 # nearest, ties toward +infinity. Absolute error <= 2^-b/2.
 y=x*2**b
 n=(2*y.numerator+y.denominator)//(2*y.denominator)
 return F(n,2**b)
def round_z(x,b):return (round_f(x[0],b),round_f(x[1],b))
def dyadic_exponent(x):
 b=0
 for w in x:
  for a in w:
   d=a.denominator
   if d&(d-1):raise ValueError('raw data must be complex dyadic')
   b=max(b,d.bit_length()-1)
 return b

def propose(x,L):
 """Full-tail least squares; exact rank and normal-residual certificates."""
 N=len(x)
 if L not in (1,2) or N<=L:raise ValueError('require L in {1,2}, N>L')
 cols=[[x[j-i] for j in range(L,N)] for i in range(1,L+1)]
 b=x[L:]
 G=[[dot(a,d) for d in cols] for a in cols]
 w=[neg(dot(a,b)) for a in cols]
 if L==1:
  det=G[0][0][0];trace=det
  if not det:return {'status':'rank_deficient','span':L}
  c=[scale(w[0],1/det)];gamma=det
 else:
  g00,g11=G[0][0][0],G[1][1][0]
  det=g00*g11-norm2(G[0][1]);trace=g00+g11
  if not det:return {'status':'rank_deficient','span':L}
  assert det>0 and trace>0
  c=[scale(sub(scale(w[0],g11),mul(G[0][1],w[1])),1/det),
     scale(sub(scale(w[1],g00),mul(G[1][0],w[0])),1/det)]
  gamma=det/trace
 residual=[]
 for j in range(L,N):
  v=x[j]
  for i in range(1,L+1):v=add(v,mul(c[i-1],x[j-i]))
  residual.append(v)
 assert all(dot(col,residual)==Z for col in cols)
 s=sqrt_floor_dyadic(gamma)
 return {'status':'proposal','span':L,'coefficients':c,'gram':G,
         'det':det,'trace':trace,'gamma':gamma,'sigma_lower':s,
         'residual':residual,'residual_nu':sum(map(nu,residual),F(0)),
         'residual_squared':sum(map(norm2,residual),F(0)),
         'condition_squared_upper':trace/(s*s)}

def coefficient_certificate(x,L,epsilon):
 """New interface stops at a fully verified rounded coefficient packet.
 Nonacceptance is not a nonmembership or impossibility certificate.
 """
 epsilon=F(epsilon);b=dyadic_exponent(x);N=len(x)
 if not 0<epsilon<=1:raise ValueError('0<epsilon<=1 required')
 q=propose(x,L)
 if q['status']!='proposal':return q
 S=sum(map(nu,x),F(0));tau=F(1,(2*N)**L)
 # Reserve half of inherited residual allowance for coefficient rounding.
 hmax=epsilon*tau/(16*L*(S+1));bc=max(b,0)
 while pow2(-bc)>hmax:bc+=1
 c=[ONE]+[round_z(t,bc) for t in q['coefficients']]
 r=[]
 for j in range(L,N):
  v=Z
  for i in range(L+1):v=add(v,mul(c[i],x[j-i]))
  r.append(v)
 R=sum(map(nu,r),F(0));A=[]
 for j in range(L):
  v=Z
  for i in range(j+1):v=add(v,mul(c[i],x[j-i]))
  for i in range(j+1,L+1):v=add(v,mul(c[i],x[N+j-i]))
  A.append(v)
 assert R<=q['residual_nu']+L*pow2(-bc)*S
 q.update({'status':'accepted_coefficients' if R<=epsilon*tau/8 else 'residual_refusal',
   'rounded_connection':c,'rounded_residual':r,'R':R,'A':A,'S':S,'tau':tau,
   'epsilon':epsilon,'coefficient_grid_bits':bc,'rounded_degree':max(i for i,t in enumerate(c) if t!=Z),
   'sufficient_residual_gate':q['residual_nu']<=epsilon*tau/16})
 return q

def model_error_bound(packet,eta,model_coefficients):
 """Rational conservative bound given EXTERNAL ||noise||_2 <= eta.
 Uses sqrt(L)<=L and ||c||_2<=sum nu(c). Does not verify a noise model.
 """
 L=packet['span'];s=packet['sigma_lower']
 return F(eta)*(1+L*sum(map(nu,model_coefficients),F(0)))/s

def self_bound(packet,eta):
 """Conditional coefficient proximity to ANY true L-recurrence model
 within eta in l2. Returns None if the contraction guard fails.
 """
 L=packet['span'];a=F(eta)/packet['sigma_lower']
 if L*a>=1:return None
 C=sum(map(nu,packet['coefficients']),F(0))
 return a*(1+L*C)/(1-L*a)
