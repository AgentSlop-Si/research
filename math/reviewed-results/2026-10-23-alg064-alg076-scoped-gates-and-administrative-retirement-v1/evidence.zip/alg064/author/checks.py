"""Fresh exact controls; imports only this submission's new discovery code."""
import json, hashlib, random
from pathlib import Path
from discovery import *

rng=random.Random(640023)
counts={'cases':0,'proposals':0,'accepted_coefficients':0,'residual_refusals':0,'rank_refusals':0,
        'normal_equations':0,'psd_condition_guards':0,'optimality_identities':0,
        'noise_model_bounds':0,'self_bounds':0,'boundary_identities':0,'nonzero_residual_acceptances':0}
rows=[]
def rowmul(x,L,j,c):
 out=x[j]
 for i in range(1,L+1):out=add(out,mul(c[i-1],x[j-i]))
 return out
def evalpoly(a,t):
 o=Z
 for v in a[::-1]:o=add(mul(o,t),v)
 return o
def make_model(N,L,c,seed):
 a=seed[:]
 while len(a)<N:
  q=Z
  for i in range(1,L+1):q=sub(q,mul(c[i-1],a[-i]))
  a.append(q)
 return a

def run_case(x,L,epsilon,label,model=None,cstar=None):
 counts['cases']+=1
 p=coefficient_certificate(x,L,epsilon)
 if label.startswith('late_defect'): assert p['status']!='accepted_coefficients'
 if p['status']=='rank_deficient':counts['rank_refusals']+=1;return
 counts['proposals']+=1;counts['normal_equations']+=1
 G=p['gram'];s=p['sigma_lower'];u=s*s
 if L==1:assert G[0][0][0]>=u
 else:
  assert G[0][0][0]>=u and G[1][1][0]>=u
  assert (G[0][0][0]-u)*(G[1][1][0]-u)>=norm2(G[0][1])
 counts['psd_condition_guards']+=1
 for _ in range(3):
  trial=[z(F(rng.randint(-5,5),4),F(rng.randint(-5,5),4)) for _ in range(L)]
  change=[sub(trial[i],p['coefficients'][i]) for i in range(L)]
  R1=sum((norm2(rowmul(x,L,j,trial)) for j in range(L,len(x))),F(0))
  Achange=[]
  for j in range(L,len(x)):
   v=Z
   for i in range(1,L+1):v=add(v,mul(change[i-1],x[j-i]))
   Achange.append(v)
  assert R1==p['residual_squared']+sum(map(norm2,Achange),F(0))
  counts['optimality_identities']+=1
 if model is not None:
  noise=[sub(a,b) for a,b in zip(x,model)]
  eta=sum(map(nu,noise),F(0)) # valid conservative l2 noise upper bound
  actual=sum((norm2(sub(a,b)) for a,b in zip(p['coefficients'],cstar)),F(0))
  bd=model_error_bound(p,eta,cstar)
  assert actual<=bd*bd;counts['noise_model_bounds']+=1
  sb=self_bound(p,eta)
  if sb is not None:assert actual<=sb*sb;counts['self_bounds']+=1
 if p['status']=='accepted_coefficients':
  counts['accepted_coefficients']+=1
  if p['R']>0:counts['nonzero_residual_acceptances']+=1
  assert p['R']<=F(epsilon)*p['tau']/8
 else:counts['residual_refusals']+=1
 # Transcribe full boundary/defect polynomial identity on several exact t^N=1 nodes.
 nodes=[ONE]
 if len(x)%2==0:nodes.append(z(-1))
 if len(x)%4==0:nodes += [z(0,1),z(0,-1)]
 for t in nodes:
  C=evalpoly(p['rounded_connection'],t);X=evalpoly(x,t);A=evalpoly(p['A'],t)
  tail=[Z]*L+p['rounded_residual']
  assert mul(C,X)==add(A,evalpoly(tail,t));counts['boundary_identities']+=1
 rows.append({'label':label,'N':len(x),'span':L,'status':p['status'],
  'residual_nu':str(p['R']),'sigma_lower':str(s),'grid_bits':p['coefficient_grid_bits']})

models=[(1,[z(-1)],[z(1)]),(1,[z(-2)],[z(F(1,16))]),
 (1,[z(0,-1)],[z(1,1)]), (2,[z(0),z(-1)],[z(1),z(2)]),
 (2,[z(-2),z(1)],[z(1),z(2)]), (2,[z(F(-1,2)),z(F(1,4))],[z(1),z(0,1)]),
 (2,[z(0),z(0)],[z(0),z(1)]),(2,[z(0,-1),z(F(-1,2))],[z(1),z(0,1)])]
for N in [4,5,8,13,16,31,64]:
 for L,c,seed in models:
  m=make_model(N,L,c,seed)
  for noisebits in [None,90,55,12]:
   noise=[Z for _ in m] if noisebits is None else [z(F(rng.randint(-2,2),2**noisebits),F(rng.randint(-2,2),2**noisebits)) for _ in m]
   x=[add(a,b) for a,b in zip(m,noise)]
   run_case(x,L,F(1,64),f'model_N{N}_L{L}_noise{noisebits}',m,c)
 # Late defect must be seen, independent of exact prefix.
 x=[z(1) for _ in range(N)];x[-1]=z(2)
 for L in [1,2]:run_case(x,L,F(1,128),f'late_defect_N{N}_L{L}')
 for L in [1,2]:run_case([Z]*N,L,F(1,64),f'zero_rank_N{N}_L{L}')
# Strongly ill-conditioned rank-two problem, not claimed uniformly stable.
for q in [10,40,100,300]:
 x=[z(1+F(k,2**q)) for k in range(8)]
 p=coefficient_certificate(x,2,F(1,64))
 assert p['status']=='accepted_coefficients' and p['sigma_lower']<F(1,2**(q-3))
 run_case(x,2,F(1,64),f'near_repeated_rank_q{q}')
# Residual alone is not stable reconstruction by recurrence iteration.
N=64;delta=F(1,2**80);x=[Z]+[z(delta*2**(j-1)) for j in range(1,N)]
res=[sub(x[j],scale(x[j-1],2)) for j in range(1,N)]
assert sum(map(nu,res),F(0))==delta
assert nu(x[-1])==delta*2**62
# Perturbation-map stability without any clean-model premise.
map_count=0
for N in [4,5,8,13,32,64]:
 for L in [1,2]:
  for trial in range(8):
   x=[z(F(rng.randint(-8,8),8),F(rng.randint(-8,8),8)) for _ in range(N)]
   dx=[z(F(rng.randint(-2,2),2**20),F(rng.randint(-2,2),2**20)) for _ in range(N)]
   xp=[add(a,b) for a,b in zip(x,dx)]
   p=propose(x,L);pp=propose(xp,L)
   if p['status']!='proposal' or pp['status']!='proposal':continue
   eta=sum(map(nu,dx),F(0));ss=pp['sigma_lower']
   bound=L*eta*p['residual_nu']/(ss*ss)+eta*(1+L*sum(map(nu,p['coefficients']),F(0)))/ss
   error=sum((norm2(sub(a,b)) for a,b in zip(p['coefficients'],pp['coefficients'])),F(0))
   assert error<=bound*bound
   map_count+=1
# Malformed domains.
negatives=0
for fn in [lambda:coefficient_certificate([z(F(1,3)),z(1)],1,F(1,4)),
 lambda:coefficient_certificate([z(1),z(2)],1,0),lambda:propose([z(1)],1),
 lambda:propose([z(1)]*5,3)]:
 try:fn();raise AssertionError('expected interface rejection')
 except ValueError:negatives+=1
out={'verdict':'PASS','counts':counts,'malformed_domain_rejections':negatives,
 'conditioning_controls':4,'perturbation_map_controls':map_count,'unstable_reconstruction_control':{'N':N,'residual_nu':str(delta),'propagation_gain':str(2**62)},
 'range':{'N_min':4,'N_max':64,'spans':[1,2],'max_grid_bits':max(r['grid_bits'] for r in rows)},
 'cases':rows,'historical_code_executed':False,'scope':'Exact-reference coefficient proposal/certificate, not a production or full DFT execution'}
Path('CHECK_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='cases'},indent=2))
