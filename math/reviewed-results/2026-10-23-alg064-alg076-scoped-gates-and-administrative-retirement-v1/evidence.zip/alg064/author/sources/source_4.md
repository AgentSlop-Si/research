# Independent Phase23 audit: real resolvents and exact structural coverage

9 October 2026. Scope: the supplied Phase23 checkpoint, against the already-audited Phase22 conventions. No uploaded program, test, lineage runner, binary, or bytecode was executed or imported. The nested Phase22 archive was hashed only. The accompanying checker and recurrence extension are independently authored and use only Python's standard library.

## Executive result

The central resolvent identity, its singular-character handling, the geometric detector on its stated base-field class, the sparse-difference identity, the Hankel obstruction, and the inverse-support count are correct. The running-root preparation fixes Phase22's per-frequency exponentiation cost issue. The source's binary fast-path bound is valid but can be sharpened substantially.

Two constructive results are fully proved and independently checked here:

1. For supported lengths N≥8 and the default difference thresholds (orders at most two, support at most two), the implemented combined fast path accepts exactly **N(N−1)+4** of the 2^N binary words. Its probability is therefore **[N(N−1)+4]/2^N**, improving the supplied upper bound with +34 to an exact count with +4.
2. Every raw length-N vector satisfying some fixed-coefficient recurrence of order at most two can be recognized and transformed in **O(N) field arithmetic**, without solving its characteristic polynomial. This covers repeated roots and irreducible quadratics excluded by the original geometric detector. At most two singular Fourier frequencies are evaluated directly, each in O(N), so those exceptions do not hide an FFT or an uncharged oracle.

The latter result is a broader special-input evaluator, not an arbitrary-input faster Fourier transform. Root/normalization preparation, field inversion implementation, modular arithmetic bit costs, and real-number precision remain distinct costs. No exact arbitrary-input, all-output o(N log N) algorithm, practical speedup, unrestricted Fourier lower bound, or integer-multiplication improvement follows.

The independent check suite passes. It includes every binary Hankel matrix through size 9, all binary words of lengths 4, 8, 12, and 16 for the acceptance predicates, exact transform comparisons through N=8192, every singular geometric character and inverse-support row through N=128, and repeated/irreducible/singular recurrence controls. Length 12 is a combinatorial predicate check, not a supported transform size in the supplied dyadic implementation.

## 1. Exact Green identity and singular cases

Use the Phase22 ordering and signs: F[j,k]=ω^(jk)/√N with ω=exp(−2πi/N), C=Q^−1 H^T F, positive sine rows in C, and CZ=RC for the cyclic right shift Z. Then Ce_k=R^k v for v=Ce_0. For g(z)=(1,z,…,z^(N−1))^T,

    (I−zR) Cg(z) = (I−z^N R^N)v = (1−z^N)v.

When z^N≠1, I−zR is invertible. The source's two endpoint denominators 1−z and 1+z and each rotation determinant 1−2zc+z² have the correct signs. The block solution on seed (a,0) is

    a (1−zc, zs)^T / (1−2zc+z²).

For a primitive Nth root over a field with characteristic not dividing N, the spectrum of R consists of the distinct Nth roots; these denominators are all nonzero under z^N≠1. The complex argument is the same spectral statement. Normalization requires invertible choices of √N and √2 in the field being used.

If z^N=1, exactly one f satisfies z=ω^−f, and Fg(z)=√N e_f. Applying Q^−1 H^T gives the source's endpoint values or its correctly signed cosine/sine pair. An orbit scan costs O(N), and writes of the full N-vector are also O(N). No discrete logarithm is needed. Over a field containing a primitive Nth root, these are all the roots of z^N−1.

For r supplied weighted geometric sequences, separate queries and accumulation cost O(rN), with O(N) working storage when processed one at a time. Reading/synthesizing the original vector is an additional O(rN) if one chooses to construct it. Learning the parameters is not included for arbitrary r. Sparse special spectra, shared work between queries, or a different arithmetic graph could behave differently; the rank argument below does not forbid those alternatives.

## 2. What the original detector does and does not recognize

The rank-one pass is complete for ordinary geometric sequences: a nonzero one has x_0≠0, node z=x_1/x_0, and all entries are verified. The zero sequence is handled separately.

For two distinct base-field nodes with nonzero amplitudes,

    Δ=x_1²−x_0x_2=−a_1 a_2 (z_1−z_2)²≠0.

Thus the first four samples determine the only possible order-two recurrence. Solving gives exactly the source's coefficients:

    u=(x_1x_2−x_0x_3)/Δ,
    v=(x_1x_3−x_2²)/Δ,
    x_(k+2)=u x_(k+1)+v x_k.

After checking every recurrence equation, two distinct roots of z²−uz−v and the recovered initial amplitudes reproduce every input coordinate by induction. This justifies omission of a redundant second full reconstruction pass. Coincident nodes or zero amplitudes reduce to rank one and are already covered.

The correct completeness statement is **at most two ordinary exponential components with nodes and weights in the working field**. A nonsquare discriminant can describe a perfectly valid order-two recurrence over that field whose exponential representation lies in a quadratic extension. A zero discriminant can describe (a+bk)z^k, or the nilpotent case supported in the first two coordinates. These are intentionally rejected by the uploaded detector; the fallback is correct. Thus low leading Hankel rank, recurrence order two, and split distinct-node exponential rank two should not be conflated.

In particular, low rank of just the leading Hankel matrix is only a necessary condition. The vector with its only nonzero entry at the final coordinate has a zero leading Hankel matrix but does not satisfy an order-two recurrence throughout. The checker includes this boundary counterexample.

## 3. Classical Hankel distribution and the correct lower-bound scope

For x_k=Σ_l a_l z_l^k and H[a,b]=x_(a+b), factor H=V diag(a_l) V^T. Hence rank(H)≤r. An order-r recurrence holding at every applicable input index similarly expresses each later Hankel column using its preceding r columns. The anti-diagonal unit witness proves that the determinant polynomial is nonzero; the stated large-field Schwartz–Zippel bound follows and is correctly kept separate from binary sampling.

The cited rank count was checked directly in the authors' primary paper: [García-Armas, Ghorpade and Ram, Theorem 5.1 and Corollary 5.6](https://arxiv.org/pdf/1011.1760), printed pages 6 and 9. For m×m Hankel matrices over F_q, the counts are 1 at rank zero, q^(2r−2)(q²−1) at 1≤r<m, and q^(2m−2)(q−1) at rank m. Their introduction attributes the nonsingular count and a more general result to Daykin. This independently verifies the checkpoint's attribution and formulas.

For q=2, summing the lower-rank counts gives 4^r for rank≤r<m. A length-N=2m binary word has two possible final bits for each leading Hankel matrix. Therefore

    Pr[rank_F2 H≤r] = 2^(2r−N+1),   0≤r<m.

A nonzero minor modulo two lifts to an odd, nonzero integer minor. Consequently rank_C H≥rank_F2 H. The probability bounds for low complex recurrence order or low complex geometric rank and the half-probability lower bound r≥N/2 are valid. They are necessary-description bounds. They do not prove the minimum geometric representation exists with that many terms, nor do they lower-bound the operation count of arbitrary Fourier algorithms.

The source's observation that evaluating r queries separately costs O(rN) does not prove that every algorithm exploiting r parameters must pay Ω(rN). A large-rank sparse input may have a trivial transform. The checkpoint already makes the important high-level distinction; it should remain explicit in all later claims.

## 4. Sparse cyclic differences, permutation scope, and support profile

For d=(I−Z)^a x and FZ=DF, the nonzero-frequency formula is correct:

    (Fx)_k = Σ_(j in supp d) d_j ω^(jk) / [√N (1−ω^k)^a],   k≠0.

The zero-frequency component is separately determined by the input sum. Reading and differentiating the raw input costs O(aN); each sparse numerator term costs O(N) by a running frequency progression. Preparing and batch-inverting 1−ω^k costs O(N) arithmetic plus one field inversion. Raising inverse factors to power a takes O(N log a) multiplications with repeated squaring, bounded by O(aN) for integer a≥1. Thus O(N(a+s)) is valid for one supplied order a and difference support s, with all N outputs included.

The source computes ω^j independently for each support entry. This adds O(s log N) field multiplications, absorbed in O(sN), though a precomputed root table avoids it. If the configurable adaptive driver tests every order 1,…,A by recomputing differences from scratch, its differentiation alone costs O(A²N). The stated linear adaptive result is for the default fixed A=2, not a uniform O(AN) implementation for growing A. This is a cost clarification, not an error in Theorem 5 for one order.

Permutation equivariance is also correct: with y=Px and Z_P=PZP^−1, one has (I−Z_P)^a y=P(I−Z)^a x. Sorting while retaining the standard shift changes the operator whose differences are being measured. This does not exclude algorithms using several independent orderings and paying for their associated transforms.

For the inverse C^T at dyadic N≥4, its row k has two nonzero endpoint entries. Among the N/2−1 sine/cosine pairs, sine zeros satisfy N|2jk and cosine zeros satisfy jk≡N/4 mod N/2. If k=2^v u with u odd and v<L−1, the two disjoint zero sets have 2^v−1 and 2^v members. Their sum yields N−2^(v+1)+1 nonzeros; k=0,N/2 gives N/2+1. In particular, odd k has N−1.

Multiplying matrices with at most s nonzeros per row multiplies the row-support upper bounds. Interleaved permutations and nonzero diagonal scalings have row support one. Thus a product of t invertible stages whose inverses have row support≤s must obey s^t≥N−1 if its product is C. For s≥2 this implies t≥ceil(log_s(N−1)); for s=1 such a factorization is impossible. This restricts that product architecture. It does not apply automatically to sums, branching arithmetic circuits, rectangular intermediates, or dense inverse stages.

## 5. Exact binary coverage: sharpening the source bound

The source's transition count is correct: choose any even subset of the N cycle edges and one initial bit. Thus exactly 2 binomial(N,s) binary words have s transitions when s is even, and none do when s is odd. Exactly N(N−1)+2 words have at most two transitions.

For every binary transition x_(k−1)→x_k, the next second difference x_(k+1)−2x_k+x_(k−1) is one of ±1,±2. It is nonzero over C and over F_998244353. Distinct transitions give distinct next positions. Hence second-difference support is at least first-difference support; the second-order≤2 detector adds no binary words beyond first-order≤2.

The remaining geometric predicate can be classified completely. On binary samples, a nonzero integer Δ is ±1. The first-four-sample formulas consequently yield integer u,v in {−1,0,1}; arithmetic modulo p>3 introduces no additional binary recurrence when all equations are checked. More explicitly, the only eight first-four-bit words with Δ≠0 are:

| Initial bits | u | v | Consequence |
|---|---:|---:|---|
| 0100 | 0 | 0 | Remaining bits zero; discriminant zero, rejected |
| 0101 | 0 | 1 | Alternating, accepted |
| 0110 | 1 | −1 | Fifth value −1, impossible for binary input |
| 0111 | 1 | 0 | Remaining bits one, accepted |
| 1010 | 0 | 1 | Alternating, accepted |
| 1011 | 1 | 1 | Fifth value 2, impossible |
| 1100 | 0 | 0 | Remaining bits zero; discriminant zero, rejected |
| 1101 | −1 | 1 | Fifth value −1, impossible |

The rank-one pass adds exactly all-zero, all-one, and the word 100…0. Together with the three accepted Δ≠0 cases, these are exactly six words for N≥5. All except the two alternating words have at most two cyclic transitions. For even N≥8, both alternating words have N transitions. Therefore the combined source predicate accepts exactly

    N(N−1)+2+2 = N(N−1)+4

binary words. The exact fast-path probability is [N(N−1)+4]/2^N. At N=8 this is 60/256; at N=16 it is 244/65536. The source's +34 union bound remains valid but is not tight. This classification also supplies the otherwise unstated bridge between the implemented modular predicate and the source's characteristic-zero/Hankel discussion; one must not assume arbitrary modular rank comparisons lift to characteristic zero without such an argument.

## 6. A root-free, fully charged recurrence extension

This is a standard generating-polynomial/annihilator construction specialized into an explicit complete evaluator. No claim of mathematical novelty is made.

### 6.1 Complete recognition of recurrence order at most two

First test zero and rank one as above. If Δ≠0, recover u,v and verify all recurrence equations. If Δ=0 after rank-one rejection, no order-two recurrence exists:

- If x_0=0, then Δ=x_1²=0 gives x_1=0. Any order-two recurrence would keep all subsequent values zero.
- If x_0≠0, set z=x_1/x_0. The condition Δ=0 gives x_2=z²x_0. The first recurrence equation forces z²=uz+v, so induction forces the entire sequence to equal x_0z^k, which the rank-one pass would have accepted.

Thus this recognizer is complete for the observed-vector property and costs O(N) field arithmetic plus a constant number of inversions. It never requires a square root.

### 6.2 Rational evaluation at every Fourier frequency

For a verified recurrence, define

    X(t)=Σ_(j=0)^(N−1) x_j t^j,
    Q(t)=1−ut−vt²,
    x_N=u x_(N−1)+v x_(N−2).

Coefficient comparison gives the exact polynomial identity

    Q(t)X(t)=x_0+(x_1−u x_0)t−t^N[x_N+v x_(N−1)t].

At t^N=1 its right side becomes the linear polynomial

    B(t)=(x_0−x_N)+(x_1−u x_0−v x_(N−1))t.

Evaluate Q and B at all t=ω^k. Where Q(t)≠0, compute X(t)=B(t)/Q(t), using one batch inversion for all regular frequencies. Since Q(0)=1 and deg Q≤2, it has at most two roots; at those exceptional frequencies evaluate X(t) directly by Horner's rule over the original input. Then multiply by 1/√N and apply the O(N) parity conversion to materialize every coordinate of Cx.

Charges after transform-root/normalization setup:

- raw recurrence recognition and verification: O(N);
- boundary coefficients: O(1);
- N frequency/root values, Q values, and numerators: O(N);
- regular denominator batch: O(N) multiplications and one inversion;
- exceptional evaluations: at most 2N Horner steps;
- normalization, parity conversion, and N output writes: O(N);
- working storage: O(N), including root/output arrays.

This evaluator works equally for a repeated nonzero root, a repeated zero root, an irreducible quadratic over the field, two Fourier-character roots, and generic split roots. It avoids false singular divisions. The code in `FieldTransform.recurrence2` implements precisely this algorithm; `infer_recurrence2` supplies the complete raw-input detector. The entry point `root_free_adaptive(x)` prepares the engine, detects the recurrence, executes this path when applicable, and uses the independent recursive FFT on rejection. It is a complete raw-input algorithm. The worst case remains O(N log N).

More generally, a supplied degree-r recurrence/filter Q gives Q(Z)x supported within its r boundary positions. Evaluating its sparse numerator and Q at N frequencies, with at most r exceptional root frequencies evaluated directly, gives an O(rN) field evaluator. Discovery of such a filter must be charged; this observation does not close the arbitrary-input gap. No further implementation or growing-r speedup is claimed here.

## 7. Arithmetic model, setup, and precision ledger

The original implementation is an exact modular analogue of the real transform. It is not an exact-real-number implementation. The field contains an element representing i; that does not make positivity, numerical norm bounds, or real orthogonality tests meaningful in this finite field.

The main fixed-field O(N) and O(rN) claims hold in the field-operation model with the stated setup qualification. There are several distinct charges:

- Running root powers and angle formation are O(N) multiplications/additions once a primitive root and normalization constants are available. The source correctly advances powers rather than exponentiating per angle.
- Computing z^N is O(log N) multiplications by repeated squaring, absorbed in O(N). One modular inversion by powering is O(log p) multiplications; Euclidean inversion has its own bit-operation cost. Batch inversion means one such inversion, not no inversion.
- The original rank-two detector uses a field square-root algorithm. Square root is not an elementary add/multiply operation in a general field. Tonelli–Shanks has additional p-dependent work, potentially O(log² p) modular multiplications with a supplied nonresidue, and nonresidue discovery must also be accounted for. The fixed supplied p has fixed parameters, so this does not change its N-dependent bound. A blanket uniform O(log p) charge for every square-root implementation is not established by the checkpoint.
- The source's prime supports only dyadic N≤2^23. Meaningful asymptotics with unbounded N need a field family and a charged method for selecting fields, roots/generators, square roots, and input encodings. A bounded fixed-modulus experiment alone cannot establish that uniform complexity theorem.
- Modular multiplications and reductions act on O(log p)-bit values. Input reduction also costs time proportional to the actual input representation; arbitrarily large supplied Python integers are not constant-cost field elements.
- Over C, the identity is exact algebra. Near roots of unity, the separate numerator and resolvent can have cancellation or poor conditioning even though C is orthogonal on real inputs. Batch products can also be unsuitable in floating point. No stable numerical implementation, bit-precision budget, or exact algebraic-number bit complexity is proved. Operation-count success is not a certified bit-complexity or practical-time speedup.

The new recurrence evaluator removes only the data-dependent quadratic square root. It does not remove transform-root/normalization preparation or solve the general precision problem.

## 8. Reproduction and provenance

Run from any directory:

    python /path/to/phase23_audit/independent_checks.py

Dependencies: Python 3.10+ standard library only. The program neither imports nor reads the supplied source tree or any prior audit. It writes `CHECK_RESULTS.json` beside itself. Its finite-field normalization uses independently selected consistent square-root signs; these may differ from the source routine's signs, so the controls certify the stated identities and reconstructed acceptance predicate, not execution of the uploaded module.

Observed controls include:

- 174,762 binary Hankel matrices, every rank count at m=1,…,9; integer Bareiss determinant/parity lifting also checked exhaustively through m=5;
- 69,904 binary words at lengths 4,8,12,16, all transition counts, second-difference support inequality, and the exact fast-path counts;
- 252 singular-character queries, 30 nonroot queries, and 252 inverse-support rows checked against direct polynomial-evaluation DFTs at N≤128;
- 18 independent direct-DFT versus recursive-FFT comparisons;
- 30 supplied two-exponential mixtures and 18 sparse-difference cases through N=8192;
- 36 recurrence-extension cases through N=8192, including irreducible discriminants, repeated roots, and zero, one, or two exceptional frequencies;
- 42 checks of the complete raw-input adaptive entry point, comprising those 36 accepted inputs and six arbitrary-vector FFT fallbacks;
- nine simultaneous-permutation controls.

All checks pass. All 13 entries of the source hash manifest match current source bytes. `SOURCE_INPUTS.json` records source identities and the inert nested archive. `RUN.log` records the observed invocation, and `SHA256SUMS.txt` seals the audit deliverables. The source's uploaded test-count and lineage-run claims are not independently reproduced here because the audit did not run uploaded code.

This completes the bounded audit. The exact coverage improvement and the complete root-free order-two recurrence executor are useful additions. They strengthen restricted-input understanding without presenting a uniform exact faster FFT.
