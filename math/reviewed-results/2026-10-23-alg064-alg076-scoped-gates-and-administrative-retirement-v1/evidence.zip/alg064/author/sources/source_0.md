# Phase 23: exact real-Fourier Green queries, adaptive rank-2 execution, and the binary collision barrier

**Date:** 2026-10-09  
**Research status:** Exact restricted-input algorithms; an exact classical Hankel-rank obstruction adapted to the user's collision hypothesis; reproducible finite-field implementations. **No new `o(N log N)` algorithm for arbitrary data, no improved integer-multiplication complexity, and no general noncommuting Green-network Fourier factorization.**

## 1. Conventions inherited from Phase 22

Let `N` be even, `h=N/2`, and `F_N[j,k]=exp(-2*pi*i*j*k/N)/sqrt(N)`.
Phase 22 proved `F_N=H_N Q_N C_N` with `H_N` the real reflection-pair change of basis, `Q_N=diag(1,...,1,-i,...,-i)`, and the real orthogonal residual `C_N`. It also established

`C_N Z = R_N C_N`, `v=C_N e_0`, and `R_N^N=I`,

where `R_N` consists of two scalar blocks `+1,-1` and one planar rotation

`[[cos theta_j, -sin theta_j], [sin theta_j, cos theta_j]]`

for each `1<=j<h`, with `theta_j=2*pi*j/N`. Both `R_N` and its inverse apply in `O(N)` scalar operations given the angles. In Phase 23, the angles are constructed in genuinely `O(N)` multiplications by a *running root-of-unity recurrence*, rather than one exponentiation per angle.

## 2. Exact Green resolvent theorem

**Theorem 1 (geometric Fourier residual).** For `g_N(z)=(1,z,...,z^(N-1))^T` and `z^N != 1`, we have

```
C_N g_N(z) = (1-z^N) (I-z R_N)^(-1) v.                (2.1)
```

**Proof.** The `k`th column of `C_N` equals `R_N^k v` by the covariance and seed equations. Thus

`C_N g_N(z) = sum_(k=0)^(N-1) z^k R_N^k v`.

Multiplying by `I-z R_N` telescopes to

`(I-z R_N) C_N g_N(z) = (I-z^N R_N^N)v=(1-z^N)v`.

Since `z^N != 1`, every eigenvalue of `z R_N` differs from 1, so the resolvent exists. QED.

**Explicit blocks.** On `+1` and `-1`, divide the first two seed components by `1-z` and `1+z`. On a frequency block with `c=cos theta_j`, `s=sin theta_j`, and seed `(a,0)`, solve

```
(I-z R_j)^(-1) (a,0)^T
 = (a / (1-2*z*c+z*z)) * (1-z*c, z*s)^T.
```

All denominators are nonzero when `z^N != 1`. Multiplying by the common factor `(1-z^N)` produces `C_N g_N(z)`. Computing `N/2+1` inverse denominators by prefix/suffix batch inversion uses `O(N)` field multiplications **and one field inversion**, not one exponentiation per frequency. Scalar root and normalization preparation, the `N` output writes, and all `O(N)` storage are counted.

**Singular case `z^N=1`.** Then `z=omega^(-f)` for one `f` mod `N`, and the normalized DFT of `g_N(z)` is `sqrt(N)*e_f`. Applying the `O(N)` reflection/phase postprocessing (in fact only up to two nonzero output coordinates) gives `C_N g_N(z)` exactly. An `O(N)` root-orbit scan finds `f`; no discrete-log oracle is assumed.

For `x_k=sum_(l=1)^r a_l z_l^k` with parameters **already supplied**, linearity gives an exact `O(rN)` field-operation executor, preprocessing `O(N)` once per transform size. Complex arithmetic has the same algebraic identity, but numerical stability and bit precision are separate issues.

## 3. Adaptive recognition of up to two exponential components

A rank-1 sequence has `x_k=a*z^k`. If `x_0!=0`, recover `a=x_0`, `z=x_1/x_0`, and verify every term with one linear pass. The zero sequence has rank 0.

A distinct-node rank-2 sequence satisfies

```
x_(k+2) = u*x_(k+1) + v*x_k,
```

where `u=z1+z2` and `v=-z1*z2`. Use the first four samples to solve for `u,v` with determinant `Delta=x1^2-x0*x2`. When `Delta!=0`, verify **all** recurrence equations, solve `z^2-u*z-v=0` by one field square root, and recover the two amplitudes from `x0,x1`. A failed check, a repeated root, or a nonsquare discriminant is **inconclusive for general low-rank recurrences** and routes to the ordinary FFT, rather than reporting an incorrect Green result.

This detector is `O(N)` with constant-field inversion/square-root preparation. Combined with the Green executor, a **raw full input vector** of exponential rank 0, 1, or 2 takes `O(N)` field work, rather than assuming its nodes and weights were handed to us. Arbitrary input falls back to the standard radix-two exact NTT followed by the Phase 22 parity postprocessing, costing `O(N log N)`.

`phase23_resolvent.py` implements this full adaptive algorithm over `F_998244353` for power-of-two sizes dividing `998244352` (the included tests use `N<=8192`). Its success is a restricted-input result, **not** an asymptotic worst-case improvement.

## 4. The precise obstruction to the growing-collision hypothesis

Let `N=2m` and define the leading Hankel matrix of a sequence `x` by

`H_m(x)[a,b]=x_(a+b)`, `0<=a,b<m`.

**Theorem 2.** If `x_k = sum_(l=1)^r a_l z_l^k`, then `rank(H_m(x))<=r` over any field containing those parameters. More generally, the same bound holds if the entire observed sequence satisfies any fixed-coefficient linear recurrence of order `r` at every applicable index.

**Proof.** Put `V[a,l]=z_l^a`. Then

`H_m(x)=V diag(a_1,...,a_r) V^T`.

Thus the matrix rank does not exceed `r`. Repeated poles, zero weights, and coincident nodes do not invalidate the upper bound. For a general order-`r` fixed-coefficient recurrence, every Hankel column after the first `r` is a fixed linear combination of the preceding `r` columns, yielding the same rank bound. QED.

The determinant is not identically zero: the binary input `x_(m-1)=1`, with all other inputs zero, gives the anti-identity Hankel matrix, with determinant `(-1)^(m(m-1)/2)`.

For independent uniformly sampled entries from a large field `F_p`, Schwartz–Zippel gives `Pr[H_m singular] <= m/p`. This probability statement **does not** apply directly to binary-valued inputs, which occupy only a two-element subset of `F_p`.

**Theorem 3 (binary collision counterpoint).** For independent fair binary inputs `x_0,...,x_(2m-1)`, the probability of a full-rank `m x m` Hankel matrix over `F_2` is exactly `1/2`, by Daykin's classical Hankel-matrix count (see the 2011 account by García-Armas, Ghorpade and Ram). Whenever the determinant is nonzero mod 2, it is an *odd nonzero integer* and so is also nonzero over `C`. Hence

```
Pr[ minimum complex exponential terms r >= N/2 ] >= 1/2.
```

The `m x m` Hankel determinant uses the first `2m-1` input bits; the last bit is immaterial for this necessary lower bound. This **does not** imply an `Omega(N^2)` lower bound on *all* FFT algorithms: a high-Hankel-rank input, such as the anti-identity witness, may still have a trivial FFT. The result limits the **sum-of-geometric-Green-query strategy** only.

**Sharper exact rank distribution (classical).** García-Armas, Ghorpade and Ram give for an `m x m` Hankel matrix over `F_2` exactly `3*4^(r-1)` matrices of rank `r` for `1<=r<m`, one rank-zero matrix, and `4^(m-1)` full-rank matrices. Consequently, for every `0<=r<m`,

```
Pr[ rank_F2(H_m) <= r ] = 4^r / 2^(2m-1) = 2^(2r-N+1).
```

For integer binary Hankel matrices, rank over `C` is **at least** rank over `F_2`: any nonzero minor modulo two is an odd, nonzero integer minor. Thus the probability that a uniform binary input has a complex fixed-recurrence order or geometric rank at most `r` is at most `2^(2r-N+1)`. In particular, for `N>=8`, exponential rank <=2 has probability at most `2^(5-N)`, and any `r=o(N)` is exponentially unlikely to cover a uniform binary input. These are restrictions on low-order *input descriptions*, not general FFT lower bounds.

**Exact check:** exhaustive enumeration of the `2^(2m-1)` binary Hankel matrices for `m=1,...,9` matches *every rank count*, and gives exactly half nonsingular at every size. The computation is reproducible in `audit.py`. Independently, 16 seeded random binary inputs at each `N=32,64,128,256` had full Hankel rank over `F_998244353`; that sample is not a substitute for the theorem.

## 5. Exact sparsity of the inverse real residual; a separate product obstruction

**Theorem 4.** For `N=2^L`, the number of nonzero entries in row `k` of `C_N^-1=C_N^T` is

- `N/2+1` for `k=0` or `k=N/2`;
- `N-2^(v_2(k)+1)+1` for all other `k`.

In particular, **every odd `k` has `N-1` nonzero entries**. Proof: the two scalar coordinates are always nonzero; each cosine/sine pair contributes one or two nonzeros. Sine vanishes when `N | 2jk`; cosine vanishes when `jk == N/4 (mod N/2)`. For `k=2^v*u`, `u` odd, `0<=v<L-1`, these conditions have exactly `2^v-1` and `2^v` solutions respectively among `1<=j<N/2`. Their zero sets are disjoint. For `k=0,N/2`, all sines vanish and all cosines remain.

**Corollary (restricted sparse-inverse product depth).** If `C_N` is a product of `t` invertible Green stages whose individual inverses have at most `s` nonzeros per row, allowing arbitrary interleaved coordinate permutations and nonzero diagonal gauges, then the inverse product has at most `s^t` nonzeros per row. Since `C_N^T` has an `N-1`-nonzero row,

`s^t >= N-1`, hence `t>=ceil(log_s(N-1))`.

For tridiagonal Green inverses, take `s=3`. This **does not** apply to noncommuting *sums* of Green inverses, whose inverses can be dense. The general inverse-support principle was already used for the full DFT in Phase 15; the new calculation gives the **exact** sparsity profile for the Phase 22 real residual.


## 6. A second exact Green class: sparse cyclic differences

Let `d=(I-Z)^a x` be the `a`th cyclic difference, and suppose `d` has `s` nonzero entries. Because `F_N Z = D_N F_N`,

```
F_N d = (I-D_N)^a F_N x.
```

At nonzero frequency index `k`, `1-omega^k` is invertible. With the DC component calibrated separately by the input sum,

```
(F_N x)[0] = sum_j x_j / sqrt(N),
(F_N x)[k] = (sum_(j in supp d) d_j omega^(j*k))
               / (sqrt(N)*(1-omega^k)^a),  k>0.
```

Each nonzero `d_j` contributes a geometric frequency progression that is accumulated into all N outputs in `O(N)` field arithmetic. The diagonal Green inversion over nonzero frequencies uses `O(N)` batch inversions. Phase22's `O(N)` reflection/phase postprocessing converts the Fourier output into `C_N x`.

**Theorem 5.** With `a` fixed or explicitly charged, the exact real residual transform takes `O(N(a+s))` field operations when the `a`th cyclic difference has support `s`. The raw input is read and differentiated in `O(aN)`, and all N outputs are materialized. The implementation recognizes `s<=2` for `a=1,2` in linear work and otherwise falls back to the conventional FFT. Piecewise-constant two-jump data and a length-N affine progression both use a linear-work branch. The analogous formula holds for higher `a`; the included test confirms a quadratic progression via its third cyclic difference.

**Permutation-equivariance obstruction.** If `y=P x`, then the correct conjugated shift is `Z_P=P Z P^-1`, and

```
(I-Z_P)^a y = P (I-Z)^a x.
```

Thus the number of nonzero cyclic differences **does not change** under a simultaneous data/shift permutation. Sorting a binary input may make differences with respect to the *standard* shift look sparse, but the transform becomes `C_N P^-1`, whose corresponding shift is `Z_P`, not the standard shift. Counting the sorted differences as free reuse would silently change the Fourier operator. This is a rigorous limit of this particular reordering strategy, not of arbitrary independently ordered Green networks.

**Exact binary transition counts.** For `N` i.i.d. fair binary values, let `S` be the number of cyclic transitions, equivalently the number of nonzero first differences. The set of flipped edges must be even, and choosing any even set plus the first bit fixes the entire cycle. Hence

```
Pr[S=s] = 2^(1-N) * binomial(N,s),  s even;
Pr[S=s] = 0,                         s odd.
```

In particular, `Pr[S<=2]=2^(1-N)*(1+binomial(N,2))`. Every binary transition at edge `k-1->k` forces the second cyclic difference at `k+1` to be nonzero: the zero condition would require the next binary value to equal `-1` or `2`, impossible. Thus support `(I-Z)^2 x` is **at least** `S`.

Our implemented adaptive executor chooses a linear Green path only if (i) the input has <=2 distinct exponential terms, or (ii) the first or second cyclic difference has <=2 nonzeros. Therefore, for `N>=8`, a union bound with the exact binary Hankel rank distribution yields

```
Pr[adaptive linear Green fast path on uniform binary input]
 <= 2^(5-N) + 2^(1-N)*(1+binomial(N,2))
 = [N(N-1)+34] / 2^N.
```

This shows an **exponentially small** fraction of uniform binary inputs meets the structural requirements of these two exact schemes, despite extensive short-block collisions. It is not a lower bound on algorithms outside the two recognized classes. Exhaustive binary transition distributions were independently checked for `N=4,8,12,16`.

## 7. What Phase 24 should do

The verified Green routes are exact and linear on (i) small exponential-rank inputs and (ii) fixed-order, sparse-cyclic-difference inputs. Both have rigorously exponentially small coverage under uniform binary inputs with the implemented thresholds, despite the many small-pair collisions.

The surviving architectural research target is to combine Green operators with **independent coordinate orderings and nonlinear-in-the-operator sharing**, not to cache small repeated butterflies or to reduce every input to a few geometric queries. Specifically, test exact real covariance `MZ=R_N M` with seed `Me0=v`, while counting the cost of input-dependent representation detection and all repeated Green operations. A Fourier factorization for a special input class must never be described as a uniform faster FFT.

## References and attribution

- Phase 22 `THEOREM.md`: parity decomposition and sparse real covariance identity; included as the previous full archive.
- M. García-Armas, S. R. Ghorpade, S. Ram, *Relatively prime polynomials and nonsingular Hankel matrices over finite fields*, Journal of Combinatorial Theory, Series A 118 (2011), 819–828. Count of invertible finite-field Hankel matrices and Daykin attribution: https://www.math.iitb.ac.in/~srg/preprints/JCT_OnlinePaper.pdf
- R. A. Rueppel, *Linear Complexity and Random Sequences*, 1986: related classical context for random binary recurrence complexity; this phase's exact Hankel count does not rely on reproving it.
- OpenAI, *An explicit power saving for the exact discrete Fourier transform* (September 25, 2026): a distinct uniform exact-register `o(N log N)` construction in the literature, not an algorithm derived or independently reconstructed here. https://github.com/openai/math/blob/main/preprints/An-explicit-power-saving-for-the-exact-discrete-Fourier-transform-September-25-2026/main.pdf
