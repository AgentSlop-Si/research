#!/usr/bin/env python3
"""Fresh exact certificate verifier. Standard library only; no archived code imports.
K = Q[a]/(a^4-a^2+1), with intended embedding a=(sqrt(3)-i)/2.
The finite-field Bezout identity proves Q is squarefree in characteristic zero.
"""
from fractions import Fraction as F
import json
from pathlib import Path

ZERO=(F(0),)*4
ONE=(F(1),F(0),F(0),F(0))
A=(F(0),F(1),F(0),F(0))
def add(x,y): return tuple(u+v for u,v in zip(x,y))
def neg(x): return tuple(-v for v in x)
def mul(x,y):
    v=[F(0)]*7
    for i,u in enumerate(x):
        for j,w in enumerate(y): v[i+j]+=u*w
    for k in range(6,3,-1):
        # a^k = a^(k-2) - a^(k-4)
        v[k-2]+=v[k];v[k-4]-=v[k]
    return tuple(v[:4])
def power(x,n):
    y=ONE
    for _ in range(n): y=mul(y,x)
    return y
AP=[power(A,k) for k in range(12)]
assert power(A,12)==ONE and power(A,6)==neg(ONE)
q=[AP[(k*k)%12] for k in range(6)]
c=[AP[(-k*k)%12] for k in range(6)]
conv=[ZERO]*6
for i in range(6):
    for j in range(6): conv[(i+j)%6]=add(conv[(i+j)%6],mul(q[i],c[j]))
assert conv==[(F(6),F(0),F(0),F(0))]+[ZERO]*5
# All-entry chirp calibration, with indices fixed and no extra permutations.
entry_results=[]
for i in range(6):
    for j in range(6):
        lhs=mul(mul(AP[(i*i)%12],c[(i-j)%6]),AP[(j*j)%12])
        rhs=AP[(2*i*j)%12]
        assert lhs==rhs
        assert c[(i-j)%6]!=ZERO
        entry_results.append({'i':i,'j':j,'equal':True})
# Degree, constant, and all gain/holonomy guard sources.
assert q[0]==ONE and q[5]==A and A!=ZERO
# Specialize a -> 2 modulo 13: Phi_12(2)=13, so this is a field-order map.
p=13
assert (2**4-2**2+1)%p==0
qm=[pow(2,k*k,p) for k in range(6)]
assert qm==[1,2,3,5,3,2]
dqm=[(k*qm[k])%p for k in range(1,6)]
u=[2,1,-2,4]
v=[6,-1,-6,-4,-6]
def pmul(x,y):
    out=[0]*(len(x)+len(y)-1)
    for i,a in enumerate(x):
        for j,b in enumerate(y): out[i+j]=(out[i+j]+a*b)%p
    return out
uq=pmul(u,qm);vdq=pmul(v,dqm)
bez=[((uq[i] if i<len(uq) else 0)+(vdq[i] if i<len(vdq) else 0))%p for i in range(max(len(uq),len(vdq)))]
assert bez==[1]+[0]*8
# Verify explicit known reciprocal root t=a^-1 of p(t)=t^5 Q(1/t).
t=AP[11]
pval=ZERO
for k in range(6): pval=add(pval,mul(q[k],power(t,5-k)))
assert pval==ZERO
receipt={
 'result':'PASS_EXACT_SYMBOLIC_CERTIFICATE',
 'target':'F6[row,column]=exp(-2*pi*sqrt(-1)*row*column/6), unnormalized negative-sign DFT',
 'size':6,'stage_terms':[2,3],'interstage_permutation':'identity',
 'cycle_orders':[[0,1,2,3,4,5]]*5,
 'field_relation':'a^4-a^2+1=0; intended a=(sqrt(3)-i)/2',
 'cyclic_product_QC':[str(x) for x in conv],
 'all_entry_checks':entry_results,
 'nonzero_output_entries':36,
 'Q_degree':5,'Q_constant':'1','Q_leading':'a',
 'squarefree_witness':{'prime':13,'a_image':2,'Q_coefficients':qm,'U_coefficients':u,'V_coefficients':v,'UQ_plus_VQprime':bez},
 'proof_guards':[
  'Q has exactly five distinct nonzero roots by degree, constant and squarefree witness.',
  'QC=6 modulo z^6-1 proves Q has no sixth-root-of-unity zero.',
  'Reciprocal roots t are nonzero, distinct, and satisfy t^6 != 1.',
  'g_s(v)=t_s^v and h_s=t_s^6 are nonzero; h_s != 1.',
  'All partial-fraction coefficients are nonzero products of nonzero root differences.',
  'Middle diagonal is I; outer diagonals are a^(i^2).',
  'M=C(P), so all 36 entries, including first row/column, are nonzero.'
 ],
 'online_arithmetic_upper_bound':{'complex_multiplications':77,'complex_additions':73,'division':'none after supplied exact constants','input_reads':6,'output_writes':6},
 'setup':'Factor one explicit quartic over Q(a), choose its roots in a splitting field, form finite products/quotients. Root construction is a separate algebraic preprocessing step, not hidden in online arithmetic.',
 'claims_not_made':['worldwide novelty','Fourier-specific minimal term count','general/all-length squarefreeness','fast parameter synthesis','FFT speedup','uniform conditioning']
}
path=Path(__file__).with_name('EXACT_RECEIPT.json')
path.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'result':receipt['result'],'all_entries':36,'Q_degree':5,'squarefree_modulus':13,'receipt':str(path)},indent=2))
