#!/usr/bin/env python3
"""Phase 56: exact finite-field Jacobian rank of dephased products of Green sums.
No claim that the image includes Fourier. Deterministic random witness for generic submersion.
"""
import json, sys
import numpy as np
from random import Random

def mod(x,p): return x%p

def green(order,d,h,p):
    n=len(order); pos=np.empty(n,dtype=np.int64)
    for k,v in enumerate(order):pos[v]=k
    d=np.asarray(d,dtype=np.int64)
    invd=np.array([pow(int(v),-1,p) for v in d],dtype=np.int64)
    base=d[:,None]*invd[None,:] % p
    mask=(pos[:,None]>=pos[None,:]); hol=np.where(mask,1,h)
    G=base*hol%p * pow((1-h)%p,-1,p)%p
    # derivative with respect to log(h): G * (h if lower else 1)/(1-h)
    Gh= G*np.where(mask,h,1)%p *pow((1-h)%p,-1,p)%p
    return G, Gh

def mul(A,B,p):return A@B%p

def sample_model(n,q1,q2,p,seed):
    rng=Random(seed)
    terms=[]
    for q in [q1,q2]:
        terms_stage=[]
        for _ in range(q):
            order=list(range(n));rng.shuffle(order)
            d=[rng.randrange(1,20) for _ in range(n)]
            h=rng.randrange(2,20);a=rng.randrange(1,20)
            G,Gh=green(order,d,h,p)
            terms_stage.append({'G':G,'Gh':Gh,'a':a,'order':order,'gauge':d,'holonomy':h})
        terms.append(terms_stage)
    D=np.array([rng.randrange(1,20) for _ in range(n)],dtype=np.int64)
    S=[]
    for ts in terms:
        A=sum((t['a']*t['G'] for t in ts),np.zeros((n,n),dtype=np.int64))%p
        S.append(A)
    M=mul(mul(S[1],np.diag(D),p),S[0],p)
    assert np.all(M!=0), 'resample random point'
    # Dephased log-cross ratios: log(Mij*M00/(Mi0*M0j))
    invM=np.vectorize(lambda x:pow(int(x),-1,p),otypes=[np.int64])(M)
    def vectorize(dM):
        F=dM*invM%p
        return ((F[1:,1:]+F[0,0]-F[1:,0,None]-F[0,None,1:])%p).ravel()
    jac=[]
    for which,ts in enumerate(terms):
        for t in ts:
            def emit(H):
                if which==0: mat=mul(mul(S[1],np.diag(D),p),H,p)
                else: mat=mul(mul(H,np.diag(D),p),S[0],p)
                jac.append(vectorize(mat))
            A=t['G']*t['a']%p
            # fix one gauge as global gauge redundancy
            for v in range(n-1):
                deriv=np.zeros((n,n),dtype=np.int64)
                deriv[v,:] = A[v,:]
                deriv[:,v] -= A[:,v]
                emit(deriv%p)
            emit(t['Gh']*t['a']%p)
            emit(A)
    for v in range(n):
        mat=S[1][:,v,None]*S[0][v,None,:]%p*D[v]%p
        jac.append(vectorize(mat))
    return np.array(jac,dtype=np.int64).T,{'n':n,'q1':q1,'q2':q2,'p':p,'seed':seed,
        'cycles':[[{'order':t['order'],'gauge':t['gauge'],'h':t['holonomy'],'a':t['a']} for t in ts] for ts in terms],
        'D':D.tolist(),'entry_00':int(M[0,0])}

def rank(A,p):
    A=A.copy()
    m,n=A.shape;r=0
    for col in range(n):
        rows=np.flatnonzero(A[r:,col]);
        if not len(rows):continue
        k=r+int(rows[0]);A[[r,k]]=A[[k,r]]
        inv=pow(int(A[r,col]),-1,p)
        A[r,col:]=(A[r,col:]*inv)%p
        ids=np.flatnonzero(A[r+1:,col])+r+1
        if len(ids):
            block=(A[ids,col:]-A[ids,col,None]*A[r,col:])%p
            A[ids,col:]=block
        r+=1
        if r==m:break
    return r

if __name__=='__main__':
    configs=[(5,2,2),(7,3,3),(8,3,4),(11,3,3),(11,4,4),(11,4,5),(11,5,5),(13,5,5),(13,6,6),(17,8,8),(19,9,9),(23,11,11),(31,15,15)]
    out=[]
    for n,q1,q2 in configs:
        row={'n':n,'terms':q1+q2,'q1':q1,'q2':q2,'target':(n-1)**2}
        ranks=[]
        for p in (65521,1000003):
            J,data=sample_model(n,q1,q2,p,560123)
            ranks.append(rank(J,p))
        row['ranks']=ranks;row['columns']=J.shape[1]
        row['gauge_dimension_ceiling']=(q1+q2)*(n+1)-n-2+1
        assert max(ranks)<= min(row['gauge_dimension_ceiling'],row['target'])
        print(json.dumps(row),flush=True);out.append(row)
    open('/mnt/data/phase56_work/jacobian_audit.json','w').write(json.dumps(out,indent=2)+'\n')
