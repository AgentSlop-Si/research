#!/usr/bin/env python3
"""Numeric experiment ONLY: local lifted path from random Green product to Fourier dephased target.
No exact existence claim unless separately interval-certified. Use gauge-fixed holomorphic coordinates.
"""
import argparse,sys,json
import numpy as np
from random import Random
from jacobian_probe import rank, sample_model

class Net:
 def __init__(self,n,q1,q2,seed=560123):
  self.n=n;self.qs=[q1,q2];self.orders=[];self.masks=[];self.meta=[]
  rng=Random(seed)
  for s,q in enumerate(self.qs):
   terms=[]
   for t in range(q):
    order=list(range(n));rng.shuffle(order)
    pos=np.empty(n,dtype=np.int64)
    for k,v in enumerate(order):pos[v]=k
    terms.append(pos[:,None]>=pos[None,:])
    # scalar fixed first term; first gauge all 1
    if t>0:
     for v in range(1,n):self.meta.append((s,t,'d',v))
    self.meta.append((s,t,'h',0))
    if t>0:self.meta.append((s,t,'c',0))
   self.masks.append(terms)
  for v in range(1,n):self.meta.append((-1,-1,'D',v))
  self.idx={k:i for i,k in enumerate(self.meta)}
  self.K=len(self.meta)
  self.rng=np.random.default_rng(seed)
 def initial(self):
  x=np.zeros(self.K,dtype=np.complex128)
  for i,(s,t,typ,v) in enumerate(self.meta):
   if typ=='h':x[i]=np.log(0.35)+0.15j*self.rng.normal()
   elif typ=='c':x[i]=0.07*self.rng.normal()+0.15j*self.rng.normal()
   else:x[i]=0.12*self.rng.normal()+0.12j*self.rng.normal()
  return x
 def calc(self,x,deriv=True):
  n=self.n
  stages=[];derivs=[]
  for s,q in enumerate(self.qs):
   ss=np.zeros((n,n),dtype=complex);Ds=[]
   for t in range(q):
    mask=self.masks[s][t]
    a=np.exp(x[self.idx[(s,t,'c',0)]]) if t>0 else 1
    h=np.exp(x[self.idx[(s,t,'h',0)]])
    g=np.ones(n,dtype=complex)
    if t>0:
     for v in range(1,n):g[v]=np.exp(x[self.idx[(s,t,'d',v)]])
    G=(g[:,None]/g[None,:]) * np.where(mask,1,h)/(1-h)
    A=a*G
    ss+=A
    if deriv:
     if t>0:
      for v in range(1,n):
       dg=np.zeros((n,n),dtype=complex)
       dg[v,:]=A[v,:]
       dg[:,v]-=A[:,v]
       Ds.append((self.idx[(s,t,'d',v)],dg))
     # holonomy derivative is rank-one outer product *a
     dh=(g[:,None]/g[None,:])*a*h/((1-h)**2)
     Ds.append((self.idx[(s,t,'h',0)],dh))
     if t>0:Ds.append((self.idx[(s,t,'c',0)],A))
   stages.append(ss);derivs.append(Ds)
  d=np.ones(n,dtype=complex)
  for v in range(1,n):d[v]=np.exp(x[self.idx[(-1,-1,'D',v)]])
  A,B=stages
  M=B@(d[:,None]*A)
  if not np.all(np.isfinite(M)) or np.min(np.abs(M))<1e-16:raise ValueError('degenerate matrix entries')
  Y=(M[1:,1:]*M[0,0]/(M[1:,0,None]*M[0,None,1:]))
  if not deriv:return Y,M
  invM=1/M
  jac=np.zeros(((n-1)**2,self.K),dtype=complex)
  def add(idx,H):
   T=H*invM
   differential=T[1:,1:]+T[0,0]-T[1:,0,None]-T[0,None,1:]
   jac[:,idx]=(Y*differential).ravel()
  for idx,H in derivs[0]:add(idx,B@(d[:,None]*H))
  for idx,H in derivs[1]:add(idx,H@(d[:,None]*A))
  for v in range(1,n):
   H=np.outer(B[:,v],A[v,:])*d[v]
   add(self.idx[(-1,-1,'D',v)],H)
  return Y,M,jac

def fit(n,q1,q2,seed,maxsteps=100):
 net=Net(n,q1,q2,seed)
 x=net.initial();Y0,_,J=net.calc(x)
 omega=np.exp(-2j*np.pi/n)
 target=omega**(np.arange(1,n)[:,None]*np.arange(1,n)[None,:])
 print('start',n,q1,q2,'variables',net.K,'start_rank',np.linalg.matrix_rank(J), 'initial_err',np.max(np.abs(Y0-target)),flush=True)
 # Newton solve via least-squares using QR underdetermined J
 s=0.0;steps=0;dist=target-Y0
 best=(1e99,None)
 history=[];h=0.04
 while s<1-1e-12 and steps<maxsteps:
  nexts=min(1.0,s+h)
  T=Y0+nexts*dist
  xp=x.copy();ok=False
  try:
   for it in range(12):
    Y,_,J=net.calc(xp)
    r=(Y-T).ravel(); err=np.max(abs(r))
    if err<1e-9:ok=True;break
    # min-norm corrected by row QR, J full row rank
    if not np.all(np.isfinite(J)):raise ValueError('nonfinite jac')
    dv=np.linalg.lstsq(J,-r,rcond=1e-10)[0]
    # safeguard log-param overflows and huge steps
    scale=min(1., 2.0/max(1e-10,np.max(np.abs(dv))))
    normold=np.linalg.norm(r)
    for k in range(14):
     fac=scale*2.**(-k)
     try:
      yt,_=net.calc(xp+fac*dv,False)
      newnorm=np.linalg.norm((yt-T).ravel())
     except (FloatingPointError,ValueError,OverflowError):newnorm=np.inf
     if newnorm < normold:break
    if newnorm>=normold:break
    xp=xp+fac*dv
   if ok:
    s=nexts;x=xp;steps+=1
    h=min(0.25,h*1.35)
    Y,_,_=net.calc(x)
    history.append({'s':s,'error':float(np.max(abs(Y-T))),'norm_x':float(np.linalg.norm(x)),'step':h})
    print('ACCEPT',len(history),f'{s:.5f}',f'{h:.5f}',f'{np.max(abs(Y-T)):.2e}',f'{np.linalg.norm(x):.1f}',flush=True)
   else:
    h*=0.5
    if h<1e-6:break
  except Exception as ex:
   print('EXCEPTION',str(ex),flush=True);h*=0.5
   if h<1e-6:break
 if history:
  Y,M,_=net.calc(x)
  finalerr=float(np.max(abs(Y-target)))
  print('FINAL',n,q1,q2,'progress',s,'target_error',finalerr,'accepted',len(history),'param_norm',float(np.linalg.norm(x)))
  receipt={'n':n,'q1':q1,'q2':q2,'progress':s,'final_error':finalerr,'history':history,'seed':seed}
  if s>1-1e-12 and finalerr<1e-8:
   receipt['parameters']={'real':x.real.tolist(),'imag':x.imag.tolist(),'metadata':net.meta,'cycle_boolean_masks':[list(map(lambda z:z.astype(int).tolist(),stage)) for stage in net.masks]}
  out=f'/mnt/data/phase56_work/fit_{n}_{q1}_{q2}.json'
  open(out,'w').write(json.dumps(receipt,indent=2)+'\n')
  return receipt

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--n',type=int,default=5);a.add_argument('--q',type=int,default=2);a.add_argument('--seed',type=int,default=560123);a.add_argument('--steps',type=int,default=100);v=a.parse_args();fit(v.n,v.q,v.q,v.seed,v.steps)
