# Phase 56 — Gauge dimension, two-stage Green universality, and certified small Fourier factorizations

**Date:** 12 October 2026  
**Status:** Exact algebraic parameter count; finite-field rank witnesses; five rigorous computer-assisted complex existence certificates for **finite** DFT lengths. **Not an all-length FFT algorithm, not an O(N) or o(N log N) FFT, and not a verified claim of external publication novelty.**

## 56.1. The matrix family

For each ordered Hamiltonian cycle `o=(v_0,...,v_(N−1))`, nonzero vertex gains `g_v`, nonzero cycle holonomy `h ≠ 1`, and scalar coefficient `a`, put

\[
G[o,g,h]_{ij}=\frac{g_i/g_j}{1-h}\begin{cases}1,&\operatorname{pos}_o(i)\ge\operatorname{pos}_o(j),\\h,&\operatorname{pos}_o(i)<\operatorname{pos}_o(j).\end{cases}
\]

It is the inverse of `I-W` for the weighted cyclic permutation `W` with edge gains `g_successor/g_predecessor`, plus holonomy `h` on the closing edge. Its matrix-free action uses one cyclic prefix sum:

\[
(Gx)_{v_k}=g_{v_k}\left(\sum_{j=0}^k x_{v_j}/g_{v_j}+\frac h{1-h}\sum_{j=0}^{N-1}x_{v_j}/g_{v_j}\right).
\]

Thus each term applies in `O(N)` arithmetic if its `N` gains, order, and holonomy have already been supplied. A stage is `S=\sum_{s=1}^q a_s G_s`. The two-stage class examined numerically and rigorously is

\[
M=S_2 D S_1,
\]

with nonzero arbitrary complex diagonal `D`, and unrestricted independent Hamiltonian cycle orders and edge gains for both stages. We allow two more external invertible diagonal masks `L,R` to achieve `F_N=L M R`, where `F_N[i,j]=exp(-2πi i j/N)` is the unnormalized DFT.

The **dephased Fourier equations**, equivalent to the existence of those outer masks when the first row and first column of `M` are nonzero, are:

\[
\boxed{\frac{M_{ij}M_{00}}{M_{i0}M_{0j}}=\omega^{ij},\qquad 1\le i,j<N,\quad\omega=e^{-2\pi i/N}.}
\tag{56.1}
\]

Given a solution, choose `L_i=1/M_{i0}` and `R_j=M_{00}/M_{0j}`. This reproduces every DFT entry, including the zeroth row and column.

## 56.2. Rank-one holonomy derivative

For fixed `g,o`, the derivative of a Green resolvent with respect to its holonomy is

\[
\boxed{\frac{\partial G_{ij}}{\partial h}=\frac{g_i/g_j}{(1-h)^2}.}\tag{56.2}
\]

It is rank one, independent of the relative cycle ordering of `i,j`. Gain logarithmic derivatives are

\[
\frac{\partial G}{\partial\log g_v}=E_vG-GE_v.
\tag{56.3}
\]

These formulas provide exact Jacobians without numerical differencing. The holonomy formula also follows from `d(I-W)^(-1)=G(dW)G`, because changing the closing edge is rank one.

## 56.3. Theorem: Gauge-corrected parameter dimension

Consider `d` stages of Green sums containing `T` resolvent terms in total, with invertible interstage diagonal masks and any *fixed* interstage permutations. Let external row and column diagonal multiplications be factored out; finite unions over intermediate permutations do not change algebraic dimension.

Each Green term supplies `N−1` independent gauge ratios (one common vertex gain is redundant), one holonomy, and one coefficient: **`N+1` complex parameters**. There are `(d−1)N` mask entries. The raw parameter count is `T(N+1)+(d−1)N`.

There are independent generic parameter symmetries preserving the external-diagonal-equivalence class of the resulting full matrix:

* `d(N−1)` dimensions: simultaneously conjugate every Green term in any stage by the same relative diagonal, transporting the conjugation into its adjacent diagonal masks; external factors are irrelevant in the quotient.
* `2d−1` further dimensions: one common scalar for each of the `d` sums, and one scalar for each of the `d−1` interstage masks. All act only by overall multiplication of `M`.

With normalized diagonal gauges these symmetries are independent, so

\[
\boxed{\dim\overline{\mathcal G}\le T(N+1)-N-d+1.}\tag{56.4}
\]

The dephased space of nonsingular-entry `N×N` matrices has dimension `(N−1)^2`. Consequently, if a family locally represents **generic** matrices, it must satisfy

\[
T(N+1)-N-d+1\ge(N-1)^2,
\quad\text{i.e.}\quad
\boxed{T\ge\left\lceil\frac{N^2-N+d}{N+1}\right\rceil.}\tag{56.5}
\]

For any depth `d≤N−1`, this gives `T≥N−1`.

**Scope:** generic matrix universality, not a lower bound for the *specific* Fourier matrix. Exceptional low-dimensional algebraic subfamilies can contain structured matrices (including FFT-type operators). The result does **not** prove an FFT lower bound.

## 56.4. Exact finite-field Jacobian witnesses

After gauge fixing the first Green term's vertex gains to one in each stage, fixing both first coefficients to one, and fixing the first middle-diagonal entry to one, the two-stage family has `T(N+1)−N−1` explicit holomorphic direct coordinates.

Let `Y_ij=M_ij M_00/(M_i0 M_0j)`, `i,j≥1`. For any infinitesimal matrix perturbation `dM`, the exact derivative is

\[
dY_{ij}=Y_{ij}\left(\frac{dM_{ij}}{M_{ij}}+\frac{dM_{00}}{M_{00}}-\frac{dM_{i0}}{M_{i0}}-\frac{dM_{0j}}{M_{0j}}\right).
\tag{56.6}
\]

The script `jacobian_probe.py` samples **integer** gains, coefficients, holonomies, and middle diagonals with deterministic seed `560123`, evaluates these derivatives *exactly* modulo two primes (`65521` and `1000003`), and performs exact modular Gaussian elimination. All denominators are nonzero in the audit fields. Any full nonzero modular minor therefore certifies a nonzero characteristic-zero rational minor.

| N | Stage terms | Rank over 65521 | Rank over 1000003 | Effective dimension bound | Full target dimension |
|---:|:---:|---:|---:|---:|---:|
| 5 | 2+2 | 16 | 16 | 18 | 16 |
| 7 | 3+3 | 36 | 36 | 40 | 36 |
| 8 | 3+4 | 49 | 49 | 54 | 49 |
| 11 | 3+3 | 60 | 60 | 60 | 100 |
| 11 | 4+4 | 84 | 84 | 84 | 100 |
| 11 | 4+5 | 96 | 96 | 96 | 100 |
| 11 | 5+5 | 100 | 100 | 108 | 100 |
| 13 | 5+5 | 126 | 126 | 126 | 144 |
| 13 | 6+6 | 144 | 144 | 154 | 144 |
| 17 | 8+8 | 256 | 256 | 270 | 256 |
| 19 | 9+9 | 324 | 324 | 340 | 324 |
| 23 | 11+11 | 484 | 484 | 504 | 484 |
| 31 | 15+15 | 900 | 900 | 928 | 900 |

The full ranks prove local dominance onto a Euclidean-open neighborhood of *some* matrix-equivalence classes for the listed sizes, and Zariski-dominance in characteristic zero. They do **not** by themselves prove that a Fourier matrix belongs to the image.

## 56.5. Theorem: Exact finite-size Fourier membership by a computer-assisted contraction

For each of the lengths listed below, `fit_N_q1_q2.json` contains a high-accuracy numerical center generated through a complex homotopy, and `root_candidate_N_q1_q2.json` contains a refined **finite-decimal** center `c`, the chosen active parameter indices, and a finite-decimal square preconditioner matrix `B`. The inactive direct parameters remain fixed at their recorded centers.

| N | Terms q1+q2 | Complex dephased equations | Domain radius ρ | Certified root radius r | B infinity upper | q upper |
|---:|---:|---:|---:|---:|---:|---:|
| 5 | 2+2 | 16 | 10^-12 | 10^-70 | 69 | <10^-3 |
| 7 | 3+3 | 36 | 10^-12 | 10^-70 | 30 | <10^-3 |
| 8 | 3+4 | 49 | 10^-12 | 10^-70 | 290 | <10^-3 |
| 11 | 5+5 | 100 | 10^-12 | 10^-70 | 344 | <10^-3 |
| 13 | 6+6 | 144 | 10^-14 | 10^-85 | 9142 | <10^-3 |

Here is the completely specified certificate method used by `certify_exact_roots.py`:

1. Treat all saved finite decimals as **exact rational complex coordinates**, not as approximate real-number assertions. Evaluate all dephased residuals `f(c)` and the selected Jacobian `J(c)` using 150-decimal-digit **outward-rounded complex interval arithmetic** (`mpmath.iv`), including an enclosing interval for `exp(-2πi/N)`.
2. Prove `||f(c)||∞<10^-80` (`10^-100` for `N=13`). Check every matrix entry has absolute value above the saved lower bound `m0`: respectively `.10`, `.04`, `.10`, `.10`, `.50`.
3. Round the selected Jacobian to a rational matrix `A0` with 50 digits after the decimal point. Prove by interval arithmetic that `||J(c)−A0||∞<10^-45`.
4. Convert `B` and `A0` to exact Gaussian-rational integer-scaled matrices. Verify **with exact integer arithmetic** that `||I−BA0||∞<10^-3`, bounding complex absolute values by the sum of real and imaginary magnitudes; independently bound `||B||∞` by the table entries. Thus `||I−BJ(c)||∞<10^-3+Bbound×10^-45`.
5. Bound each Green matrix, each stage and the full product uniformly throughout the larger parameter polydisc of radius `ρ`, using triangle inequalities on the saved finite-decimal gains and distances from all resolvent poles. Obtain `|M(z)−M(c)|<m0/2`, so every denominator defining `f(z)` remains nonzero. A rational uniform bound `H` on every `|f_i(z)|` then follows.
6. By the polydisc Cauchy estimate, for `||z−c||∞≤r<ρ/2`, every second partial derivative of `f` is bounded by `8H/ρ²`. Consequently the selected Jacobian obeys `||J(z)−J(c)||∞≤8m²H r/ρ²`, where `m=(N−1)^2`.
7. The **entirely rational** final inequality

\[
\boxed{q:=10^{-3}+B_{\max}10^{-45}+\frac{8B_{\max}m^2 H r}{\rho^2}<\frac12}
\]

and `Bmax ||f(c)||∞+q r<r` hold for all five saved examples. Therefore `T(z)=z−Bf(z)` maps the closed complex polydisc of radius `r` strictly into itself and is a contraction there. Banach's fixed-point theorem gives a **unique** fixed point in this polydisc. Because `||I−BJ(c)||∞<1`, both square matrices `B` and `J(c)` are nonsingular, and the fixed-point identity implies `f(z)=0`. Hence the full Fourier cross-ratios and, after the external calibration, **all Fourier entries** match exactly at the fixed point.

The certificate is an **existence theorem**. The exact complex gains need not have short closed forms; the finite-decimal centers isolate the roots, and the proof guarantees a genuine solution inside each stated box.

**Reproducibility caveat:** The mpmath interval engine and the exact integer source code must be trusted and can be independently audited. These are computer-assisted proofs, not hand-checked symbolic identities and not externally peer-reviewed theorems. The published novelty of this representation has not been established.

## 56.6. Completely separate matrix-free numerical cross-check

The standalone `verify_fourier_fit.py` reconstructs each numerical solution's cycle orders, gains and coefficients, applies every `G_s` using **prefix scans** instead of dense matrix multiplication or the homotopy/Jacobian implementation, and calibrates external diagonals. It verifies every Fourier matrix entry and also applies the transform to a deterministic complex vector.

| N | Green terms | Max matrix-entry error in independent double-precision check |
|---:|---:|---:|
| 5 | 4 | `1.74e-13` |
| 7 | 6 | `4.72e-13` |
| 8 | 7 | `4.64e-14` |
| 11 | 10 | `1.97e-13` |
| 13 | 12 | `4.66e-11` |

These floating-point errors **are not** the existence proofs; the interval/rational contraction checks above supply that guarantee. The `N=13` center is more numerically sensitive than the shorter cases. No uniform conditioning theorem is claimed.

## 56.7. Complexity and what remains open

Each weighted Hamiltonian Green term costs `O(N)` scalar arithmetic once its `O(N)` gain vector and cyclic order are supplied. The above constructions use **`T=N−1` terms**, so direct execution costs `O(N²)`, with additional numerical or exact-algebraic work to synthesize their many complex parameters. The phase-56 certificates are finite-size and provide **no all-length explicit formulas** for those gains.

Consequently, **no `O(N)` FFT, no `o(N log N)` general-input FFT, and no new integer-multiplication complexity bound** has been proved. What is genuinely established is a sharper gauge-dimension count, several exact local-dominance witnesses, and a new set of finite-size full Fourier existence certificates using only two Green-sum stages.

The next mathematical task is not another unrestricted optimizer fit. It is to discover a closed-form or recursively generated Fourier-specific gain pattern requiring `T=o(log N)` terms and fast preprocessing, or to establish a restricted no-go theorem for that possibility. In particular, full local dominance requiring `T≈N` does **not** explain Fourier's special algebraic structure.

## 56.8. Relation to established theory and novelty caution

Relevant established foundations include classical diagonal gauge and group actions, holomorphic implicit-function/Banach contraction methods, and the literature on displacement-rank matrices and structured factorization. In particular:

* Marko Huhtanen and Allan Perämäki, *Factoring Matrices into the Product of Circulant and Diagonal Matrices*, Journal of Fourier Analysis and Applications 21 (2015), 1018–1033; https://doi.org/10.1007/s00041-015-9395-0. They prove a generic circulant–diagonal matrix factorization theorem; it is **not** the same as a two-stage sum of independently gauged Hamiltonian-cycle resolvents.
* A. Bostan, C.-P. Jeannerod, C. Mouilleron, É. Schost, *On Matrices With Displacement Structure: Generalized Operators and Faster Algorithms*, SIAM Journal on Matrix Analysis and Applications, https://doi.org/10.1137/16M1062855.
* Prior project reports Phase 44 and Phase 55 are included in the historical archive/checkpoint. Their conclusions should be considered separately; Phase 56 does not imply a general complexity improvement.

An independent literature review is needed before describing the Phase 56 matrix-family certificates as publication-level novelty.
