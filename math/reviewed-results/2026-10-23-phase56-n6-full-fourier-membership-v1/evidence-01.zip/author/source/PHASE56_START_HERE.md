# Phase 57 Recovery Checkpoint — Start Here

**Phase 56 completed October 12, 2026. No asymptotic FFT speedup.**

## Core new results

1. **Gauge-corrected dimension:** for `d` stages with `T` independently weighted Hamiltonian Green terms, dephased output family has complex dimension at most `T(N+1)-N-d+1`, including arbitrary interstage monomial masks. Generic local universality with `d≤N−1` needs `T≥N−1`. This is **not** an FFT lower bound.
2. **Exact modular Jacobian witnesses** (`jacobian_probe.py`): full dephased Jacobian ranks in two primes for N=5,7,8,11,13,17,19,23,31 at `T=N−1` (balanced across 2 stages); lower-size N=11/13 families saturate their smaller dimension ceiling.
3. **Computer-assisted exact Fourier existence** (`certify_exact_roots.py` + saved roots): `F_N = L S2 D S1 R` for sizes N=5 (2+2 terms), N=7 (3+3), N=8 (3+4), N=11 (5+5), N=13 (6+6). All stages have independent complex vertex gauges, holonomies, scalars and cycle orders. Certificates use exact rational matrix-preconditioner audit, outward-rounded complex interval arithmetic, and Banach contraction for the full `(N−1)^2` cross-ratio system. Independent `O(TN)` prefix executor also verifies the numerical centers.
4. **Meaning:** five finite-size Fourier factorizations, no universal parameter synthesis and no improvement over standard `O(N log N)` FFT. Since `T=N−1`, direct execution would require `O(N²)` work at variable length.

## Reproduce from the lightweight ZIP

`python validate_phase56.py`

Or, to audit the crucial new claims individually:

```
python jacobian_probe.py
python verify_fourier_fit.py
python certify_exact_roots.py --n 5 --q 2
python certify_exact_roots.py --n 7 --q 3
python certify_exact_roots.py --n 8 --q 3 --q2 4
python certify_exact_roots.py --n 11 --q 5
python certify_exact_roots.py --n 13 --q 6
```

Dependencies: Python 3.10+, NumPy, mpmath. The original search/refinement is optional and uses SciPy. All proof witnesses are already included; **do not need to rerun optimization**.

## What to investigate next

* The present two-stage family reaches generic dimension with `T≈N`, which is too expensive for an FFT breakthrough. Search for special **Fourier-only** solutions with `T=o(log N)` and `O(N)`-constructible parameters (or prove specific impossibility results).
* Test whether the explicitly certified parameters across N=5,7,8,11,13 exhibit any graph-order or holonomy recurrence; a homogeneous or number-theoretic pattern would be more useful than just more numerical fits.
* Extend exact *global* Weyl covariance tests to multi-stage architectures while retaining noncommuting stages and outer monomial equivalence.
* Audit numerical conditioning (some N=13 parameters are large); avoid implying stable asymptotic algorithms.
* Independently peer-review the existence proof implementation and related matrix-factorization literature before any publication claim.
