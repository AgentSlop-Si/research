# Repeating chirp-block sketches: rigorous gains and obstructions

Derived 2026-10-09. These are algebraic proofs, not experiments. The family is the raw adjoint decoder in `AFFINE_RESONANCE.md`: N=KM, chirp σ(r,t)=e_M(a t²+s_r t), sketches y_r=Σ_t σ(r,t)x_(rM+t), and decoded output N^(-1/2)Σ_r e_K(-mr)y_rΣ_u conjugate(σ(r,u))e_N(-mu). Repetition means independent seeds followed by the specified aggregation. This does not exclude input-adaptive head removal, other decoders, or joint evaluation algorithms.

## 1. A spike prevents cheap arithmetic averaging, including for dyadic lengths

Take x=e_0 and an alias frequency m=qK. In units ||x||₁/√N, the true output is 1 and one decoded output is

Z = Σ_(u=0)^(M-1) e_M(-a u²-(b+q)u).

This is identical for shared slopes and affine slopes s_r=b+dr: only block zero is occupied. For uniform b, with **any fixed a**, character orthogonality gives

E Z=1,   E|Z|²=M,   E|Z-1|²=M-1.

No averaging over a=0 is needed here. For an odd prime M and any nonzero a, |Z|=√M. For M=2^L≥4 and odd a, |Z| is either zero or √(2M), each with probability 1/2. Thus these conclusions apply directly to the important power-of-two setting.

Let Z_1,...,Z_R be independent repeats (a may vary independently within these admissible sets) and W_j=Z_j-1. Then |W_j|≤√(2M)+1, E|W_j|²=M-1, and E|W_j|⁴≤8M². Independence and zero mean imply

E|R^(-1)Σ_j W_j|²=(M-1)/R,
E|R^(-1)Σ_j W_j|⁴≤8M²/R².

The second inequality follows by expanding the fourth moment: the cross terms are bounded by 3R(R-1)(M-1)², and the individual fourth moments contribute at most 8RM².

Paley–Zygmund applied to |R^(-1)ΣW_j|² therefore proves

**If R≤(M-1)/(2ε²), then P(|R^(-1)ΣZ_j-1|>ε)≥1/128.**

Indeed the fourth-moment ratio is at most 32 for M≥2, and using half the second moment costs another factor four. Hence confidence greater than 127/128 at even one fixed alias requires R=Ω(M/ε²). The bound is deliberately conservative.

The counterexample can be made strictly dense. Choose x=e_0+ηv with every coordinate of v nonzero. For any fixed finite R and M, each seed's linear decoder and the ℓ₁ normalization are continuous in η; the seed space is finite. Taking η sufficiently small preserves a version of the failure bound with a constant-factor stricter threshold, hence the same Ω(M/ε²) scaling. This says nothing against adaptive head removal, which is designed to cure this example.

### Cost consequence, carefully scoped

Even granting a separately evaluated shared decoder costing Θ(N+K log(K+1)), the required averaging count charges

Ω(ε^(-2)[NM+N log(K+1)])

for M≥2, up to constants replacing M by M-1. Since K=N/M, this cannot be o(N log N) at fixed ε: M+log(N/M) is Ω(log N). M=1 is exact and already uses an ordinary length-N FFT.

This is a limitation of that repeated-decoder implementation and its operation charge, **not an unconditional arithmetic lower bound**: joint evaluation could conceivably share work between seeds. For 1≤K≤M, the actual affine decoder in the accompanying `DECODER.md` has cost O(gcd(2a,M)N+N log(K+1)); uniformly nonzero prime a makes the gcd one, and odd dyadic a makes it two. This per-repeat O(N log(K+1)) affine decoder likewise does not yield a saving through this averaging guarantee: the charged expression is O(RN log(K+1)), with required R=Ω(M/ε²). The product M log(K+1)≥log(N+1). Merely improving the fixed-bin covariance does not remove this input obstruction.

## 2. An explicit raw coordinate-median obstruction (prime M)

For odd R, define the complex coordinatewise median by separately taking the real and imaginary order-statistic medians. On x=e_0, success at the chosen alias requires the real median to belong to [1-ε,1+ε]. The real median is one observed real value, so success implies some Re Z_j lies in that interval.

For prime M≥17, fixed nonzero a, and 0<ε≤1/2, completing the square represents Z as a fixed complex phase times √M times e_M(c(b+q)²), with nonzero c. The quadratic map has at most two preimages of any residue. An interval [1-ε,1+ε] on the real axis intersects this circle in two arcs with total angular length O(ε/√M); counting grid points gives the concrete bound

P(Re Z∈[1-ε,1+ε]) ≤ 4ε/√M + 8/M.

Consequently

P(coordinatewise median succeeds at this bin) ≤ R(4ε/√M+8/M).

In particular, for fixed ε and R=o(√M), its success probability tends to zero. This statement is for odd-sample order-statistic medians; it does not establish a lower bound for geometric medians, medians of averages, or even-sample averaging conventions. It also does not assert a dyadic counterpart.

## 3. Exact fixed-bin variance: shared versus affine slopes

For odd prime M, uniform independent a,b∈F_M including a=0, set

z_t(m)=Σ_(r=0)^(K-1) x_(rM+t)e_K(-mr).

The shared-slope decoder is unbiased and has exact variance

E|Xhat_m-X_m|² = (M-1)/N · Σ_t |z_t(m)|².

For affine slopes with uniform independent a,b,d∈F_M and K≤M, the exact variance is

E|Xhat_m-X_m|² = (M-1)||x||₂²/N.

Both formulas follow by averaging off-diagonal pairs: b equates differences, a equates sums because 2(t-u) is invertible, and d additionally equates block indices. The shared version retains coherent sums across blocks. The conditions on a and on prime M matter. With a instead uniform over F_M\{0}, unbiasedness survives and positivity gives the safe upper bounds obtained by replacing M-1 above by M. It is incorrect to retain the exact equality unchanged after conditioning out a=0.

Let ρ=||x||₂²/||x||₁². The affine fixed-bin failure bound at the final scale ε||x||₁/√N is at most (M-1)ρ/ε² (or Mρ/ε² when a≠0). For flat x, this is approximately 1/(Kε²). For a spike, it is approximately M/ε² and is useless, consistently with Section 1. The shared bound uses Σ|z_t|²/||x||₁²; at flat-input alias bins it is approximately one rather than 1/K.

## 4. Flat-input high moments expose rare affine resonances

For prime M, fixed a≠0, uniform independent b,d, flat x, and q≠0, the normalized alias error has magnitude

|A| = |K^(-1)Σ_(r=0)^(K-1) e_M(crd)|,   c=q/(2a)≠0.

For every positive integer h,

E|A|^(2h)=K^(-2h)·#{r_1+...+r_h ≡ s_1+...+s_h (mod M): all r_i,s_i∈{0,...,K-1}}.

When h(K-1)<M, Cauchy–Schwarz over the possible integer sums and fixing all but one s coordinate give

1/[h(K-1)+1] ≤ E|A|^(2h) ≤ 1/K.

Thus fixed-order high moments are Θ_h(1/K), **not K^(-h)**. Higher-moment arguments cannot silently treat the K block contributions as independent. The affine seed has rare coherent resonances. In contrast, the shared-slope flat alias error has magnitude exactly one for every nonzero a, so all its absolute moments equal one.

## 5. Repetitions can remove a moving bad bin, but currently consume the decoder saving

There is a genuine positive theorem for affine sketches. Let p=2(M-1)ρ/ε² in the uniform-a prime setting with K≤M (replace M-1 by M when a is sampled uniformly over the nonzero residues), and suppose p<1/4. For each frequency, Markov bounds the probability of error exceeding ε||x||₁/√(2N) by p. Take odd R independent sketches and coordinatewise medians. If a strict majority of sketches are within that radius, both coordinate medians are accurate enough for final complex error ε||x||₁/√N. A binomial union bound gives

P(any of N outputs fails) ≤ N(4p)^(R/2).

Therefore it suffices to take

R ≥ 2 log(N/δ)/log(1/(4p)), rounded upward to an odd integer.

For flat input, p≈2/(Kε²), so R=O(log(N/δ)/log(Kε²)) when Kε² grows. This rigorously removes the single-sketch moving resonance with fewer than log N repetitions. It extends to arbitrary inputs satisfying the stated ρ bound. It does **not** give a fresh arbitrary-input guarantee with that same small R.

With an implementable affine per-repeat decoder O(N log(K+1)), the resulting certified charge is

O(N log(K+1)·max{1, log(N/δ)/log(Kε²/C)}).

In its useful range, the logarithmic reduction in repetition count is canceled by the decoder's log K factor; for fixed ε and polynomial confidence this certification is O(N log N), not a sub-N log N breakthrough. This is a statement about the available sufficient guarantee and implementation, not a proof that no more favorable analysis or joint decoder exists.

For shared slopes, the flat alias output at each fixed nonzero q is uniform on the M unit roots (up to a root rotation) as b varies. Arithmetic averages therefore attain the usual O(ε^(-2)log(N/δ)) simultaneous alias guarantee, without a K improvement. This only covers aliases; it must not be promoted to a full-output arbitrary-input theorem.

## Bottom line

- Few independent affine sketches really can remove seed-dependent bad bins for diffuse inputs.
- Their high moments reflect rare O(1) resonances rather than independent-block concentration.
- Raw arithmetic averaging needs Ω(M/ε²) repeats on an arbitrary input, even for dyadic M; dense perturbations preserve this obstruction.
- Raw odd-sample coordinate medians also fail on the prime-modulus spike when R=o(√M).
- With the currently implementable O(N log K) affine decoder, the proven repetition benefit consumes rather than improves the FFT-scale cost.
- Remaining legitimate escape routes include adaptive head removal plus a genuinely sharper diffuse-tail theorem, or a joint decoder/aggregation method that shares work across seeds. Neither is established here.
