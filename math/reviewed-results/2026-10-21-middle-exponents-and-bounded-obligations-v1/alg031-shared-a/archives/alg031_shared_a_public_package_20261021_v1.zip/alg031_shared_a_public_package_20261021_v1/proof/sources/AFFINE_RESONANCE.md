# Exact resonances in the structured-slope block decoder

Derived from the uploaded checkpoint dated 2026-10-09. These are algebraic results, not experiments. No referenced implementation was available or executed.

## Decoder and scope

Write N=KM, e_L(z)=exp(2πiz/L), and use the unitary DFT. To avoid the checkpoint's overloaded c_r notation, call the slope s_r and the sketch y_r:

σ_{r,t}=e_M(a t²+s_r t),  y_r=Σ_{t=0}^{M−1}σ_{r,t}x_{rM+t}.

The natural adjoint/CountSketch decoder is

Xhat_m=N^(−1/2) Σ_r e_K(−mr) y_r H_r(m),
H_r(m)=Σ_u conjugate(σ_{r,u}) e_N(−mu).

It specializes to the checkpoint's factored decoder when all slopes are equal. All results below concern this decoder with one sketch. They do not rule out another decoder, nonlinear recovery, or a separately analyzed repetition/aggregation scheme.

For x≡1, ||x||₁/√N=√N. Its true transform is √N at zero and zero elsewhere. Thus |Xhat_m|/√N at a nonzero bin is precisely the error normalized by the checkpoint's desired scale.

## 1. Prime-modulus identity: slopes must be an ε-biased set

Let M be an odd prime and a≠0 mod M. Define S(s)=Σ_t e_M(a t²+st). Completing the square gives

S(s)=S(0)e_M(−s²/(4a)),  |S(0)|²=M.

At the alias bins m=qK, the block Fourier phase is one and H_r(qK)=conjugate(S(s_r+q)). Therefore

Xhat_{qK}/√N=e_M(q²/(4a)) · K^(−1) Σ_r e_M(q s_r/(2a)).

At q=0 this equals one exactly. At nonzero q it is spurious output. Consequently, flat-input success is equivalent to the slope multiset having every nontrivial Fourier bias at most ε. Merely decorrelating a fixed output bin does not establish this simultaneous property.

### Affine slopes fail exactly

Set s_r=b+dr. If d≠0, choose q=2a d^(−1) mod M, which is nonzero. Then

|Xhat_{qK}|/√N = |Σ_{r=0}^{K−1} e_M(r)|/K
= sin(πK/M)/(K sin(π/M)),  for 1≤K<M.

This is at least 2/π for K≤M/2 and tends to one as K/M tends to zero. If d=0, every nonzero alias has normalized magnitude one. Thus every nondegenerate affine seed fails any ε<2/π in the stated range, even though the offending bin can depend on that seed.

This prime-modulus result is not itself a theorem for power-of-two M. A separate dyadic result follows.

## 2. Power-of-two resonance

Let M=2^L≥4, a odd, d odd, s_r=b+dr, and K even with 2≤K<M. For this quadratic Gauss sum,

|S(s)|² = 2M when s is even, and 0 when s is odd.

The zero for odd s follows by pairing t with t+M/2. The even-s magnitude follows by shifting to S(0) and evaluating its squared magnitude. For any integer h, shifting the summation variable gives the exact identity

S(s+2ah)=e_M(−ah²−sh) S(s).

Choose h=d^(−1) mod M and q=2ah mod M. This q is nonzero. The alias decoder then has

Xhat_{qK}/√N = (2/K)e_M(ah²+bh) Σ_{0≤r<K: b+dr even} e_M(r).

Since d is odd and K is even, the active blocks are one parity class, exactly K/2 terms spaced by two. Therefore

|Xhat_{qK}|/√N = 2 sin(πK/M)/(K sin(2π/M)).

It is at least 2/π for K≤M/2 and tends to one as K/M tends to zero. This is an exact obstruction in the power-of-two setting for odd a and odd affine step d, independent of b.

Another dyadic failure: if a is odd, d is even, and b is odd, all slopes are odd, so y_r=S(s_r)=0 for flat input. The entire decoded vector vanishes, giving normalized DC error exactly one.

These statements do not classify every even-d/even-b dyadic case.

## 3. Fixed-degree polynomial slopes: prime-modulus obstruction

In the odd-prime setting above, let s_r=α₀+Σ_{j=1}^h α_j r^j with fixed h≥1. Define B_j=ceil(12h K^j). If

M > Π_{j=1}^h B_j,

there is a nonzero q for which the normalized error at alias qK is at least √3/2.

Proof: consider the M points indexed by v=0,...,M−1 in the h-dimensional unit torus, with coordinates the fractional parts of v α_j (2a)^(−1)/M. Partition coordinate j into B_j intervals. Since there are fewer boxes than points, two distinct points share a box. Their difference gives a nonzero residue q, and signed representatives θ_j of q α_j (2a)^(−1)/M modulo one satisfy |θ_j|<1/B_j. For every 0≤r<K,

|Σ_j θ_j r^j| ≤ Σ_j K^j/B_j ≤ 1/12.

After removing the constant phase, all terms of the slope Fourier sum lie within π/6 of phase zero. Its normalized magnitude is at least cos(π/6)=√3/2. Apply the identity in Section 1.

In particular, any fixed polynomial degree fails asymptotically when K is polylogarithmic in N and M=N/K is prime. The inequality supplies the finite-size qualification; this is not an asserted theorem for dyadic polynomial slopes.

## 4. Why favorable variance does not save affine slopes

For odd prime M, choose a,b,d independently and uniformly from F_M, including a=0. With s_r=b+dr the decoder is unbiased for each fixed x and m. If K≤M, its exact per-bin variance is

E|Xhat_m−X_m|² = (M−1)||x||₂²/N.

More generally, grouping blocks by their residue j modulo M gives

E|Xhat_m−X_m|² = (M−1)/N · Σ_{j=0}^{M−1} Σ_t |Σ_{r≡j (mod M)} x_{rM+t}e_K(−mr)|².

Derivation: expand the error using ordered off-diagonal pairs (t,u), t≠u. Averaging over b forces t−u=t'−u' mod M. Averaging over a forces t²−u²=t'²−u'² mod M. Since M is odd prime and the difference is nonzero, these imply t=t' and u=u'. Averaging over d then forces r=r' mod M. The remaining sum over u≠t contributes M−1.

The exact formula requires uniform a including zero. It should not be quoted unchanged for a fixed nonzero a or a sampled only from nonzero values. The a=0 event has probability 1/M and creates degenerate local Fourier selectors: y_r is a single local Fourier coefficient. For flat input and d≠0 with K≤M, all sketches vanish unless the unique root b+dr=0 occurs among the K sampled block indices; this root is present with probability K/M over b. This rare event should not be ignored in any high-moment argument.

For arbitrary composite M with independent uniform a,b,d, unbiasedness still holds, but the second moment retains precisely those pair pairs satisfying all three congruences:

(t−u)−(t'−u') ≡ 0 (mod M),
(t²−u²)−(t'²−u'²) ≡ 0 (mod M),
r(t−u)−r'(t'−u') ≡ 0 (mod M).

One cannot cancel 2(t−u) or t−u unless they are units. For example, with dyadic M and odd t−u, the quadratic condition permits (t',u')=(t+M/2,u+M/2) as well as (t,u), interpreted modulo M. Even differences allow further collisions. If a is fixed instead of uniform, the second congruence is not imposed; its associated phase remains in the covariance sum.

Independent uniform slopes for each block make distinct-block error covariance vanish for every M, because each off-diagonal term has zero mean. This alone does not give full entrywise randomness or eliminate within-block covariance.

## 5. What this establishes, and the next useful target

- The reported affine/polynomial idea needs an all-frequency bias test, not only fixed-frequency variance or random-input experiments.
- For the standard adjoint decoder, single affine sketches have explicit flat-input resonances in both prime and important dyadic regimes.
- In the prime case, fixed-degree polynomial slopes also have a finite exact obstruction when M is sufficiently large relative to K.
- Any replacement slope family must at least pass the ε-biased-set condition for flat input, before analyzing arbitrary local patterns and all-input concentration.
- Proving fast evaluation for such a family remains separate from proving concentration. These calculations do not supply a fast universal replacement decoder.

Finally, the relative-RMS rank barrier and the desired maximum-bin bound are different goals. The proposed maximum error scale is ε||x||₁/√N; for flat input this is ε√N, whereas ||x||₂=√N. A low-rank decoder's relative ℓ₂ obstruction alone cannot exclude this coarse ℓ∞ goal. The explicit alias calculations above address the actual ℓ∞ target directly.
