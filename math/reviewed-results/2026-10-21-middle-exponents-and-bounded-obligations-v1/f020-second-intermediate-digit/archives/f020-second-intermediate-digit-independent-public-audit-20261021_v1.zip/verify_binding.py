"""Fresh independent read-only archive validator; executes no archive content."""
import hashlib, io, json, pathlib, stat, struct, zipfile

def need(ok, why):
    if not ok:
        raise ValueError(why)

def unique_pairs(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'duplicate JSON key')
        out[key] = value
    return out

def parse_json(raw):
    return json.loads(raw.decode('utf-8'), object_pairs_hook=unique_pairs)

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def identity_is(raw, expected):
    got = identity(raw)
    return all(got[k] == expected[k] for k in ('bytes', 'sha256'))

def safe_path(name):
    return (isinstance(name, str) and name and not name.startswith('/') and '\\' not in name
            and ':' not in name and '\x00' not in name and all(c not in ('', '.', '..') for c in name.split('/')))

def inspect(raw, trusted_zip=None, trusted_manifest=None, suffixes=('.json', '.md')):
    if trusted_zip is not None:
        need(identity_is(raw, trusted_zip), 'trusted ZIP identity')
    need(len(raw) >= 22 and raw[-22:-18] == b'PK\x05\x06', 'exact terminal uncommented EOCD')
    e = struct.unpack('<4s4H2LH', raw[-22:])
    need(e[1] == e[2] == e[7] == 0 and e[3] == e[4], 'single disk EOCD')
    need(e[5] + e[6] == len(raw)-22, 'exact central-directory extent')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        need(len(infos) == e[4] and len(set(names)) == len(names), 'unique ZIP members')
        need(names == sorted(names), 'sorted ZIP members')
        need(z.comment == b'', 'archive comment')
        need(infos and infos[0].header_offset == 0, 'no prefixed bytes')
        data = {}
        times = set()
        for i in infos:
            need(safe_path(i.filename), 'safe member name')
            need(pathlib.PurePosixPath(i.filename).suffix in suffixes, 'documentary extension')
            need(not i.is_dir() and stat.S_ISREG(i.external_attr >> 16), 'regular file only')
            need((i.external_attr >> 16) == 0o100644, 'nonexecutable canonical mode')
            need(i.create_system == 3 and i.internal_attr == 0, 'canonical file attributes')
            need(i.compress_type == zipfile.ZIP_STORED and i.flag_bits == 0, 'stored unencrypted plain record')
            need(not i.comment and not i.extra, 'no member metadata payload')
            times.add(i.date_time)
            b = z.read(i)
            need(len(b) == i.file_size == i.compress_size, 'member length')
            b.decode('utf-8')
            if i.filename.endswith('.json'):
                parse_json(b)
            data[i.filename] = b
        need(len(times) == 1, 'uniform frozen timestamps')
        rebuilt = io.BytesIO()
        with zipfile.ZipFile(rebuilt, 'w', compression=zipfile.ZIP_STORED) as zz:
            for i in infos:
                zz.writestr(i, data[i.filename])
        need(rebuilt.getvalue() == raw, 'canonical record reconstruction')
    need('MANIFEST.json' in data and 'SEAL.json' in data, 'active inventory files')
    if trusted_manifest is not None:
        need(identity_is(data['MANIFEST.json'], trusted_manifest), 'trusted manifest identity')
    manifest = parse_json(data['MANIFEST.json'])
    entries = manifest['files']
    if isinstance(entries, list):
        need(len({i['path'] for i in entries}) == len(entries), 'unique manifest members')
        entries = {i['path']: i for i in entries}
    need(isinstance(entries, dict), 'manifest mapping')
    need(set(entries) == set(data)-{'MANIFEST.json', 'SEAL.json'}, 'exact active inventory')
    for name, meta in entries.items():
        need(safe_path(name), 'safe manifest name')
        need(identity_is(data[name], meta), 'manifest member identity')
    seal = parse_json(data['SEAL.json'])
    need(seal['manifest_sha256'] == identity(data['MANIFEST.json'])['sha256'], 'seal manifest hash')
    for field in ('total_files', 'expected_total_files', 'archive_file_count', 'total_file_count'):
        if field in seal:
            need(seal[field] == len(data), 'seal file count')
    if 'payload_file_count' in seal:
        need(seal['payload_file_count'] == len(entries), 'seal payload count')
    return data, {'archive': identity(raw), 'manifest': identity(data['MANIFEST.json']),
                  'total_files': len(data), 'manifest_entries': len(entries), 'timestamp': list(next(iter(times))),
                  'canonical_archive': True, 'status': 'PASS'}


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Read-only exact-byte verification of the detached audit and bound documentary main archive.")
    parser.add_argument("main_zip", type=pathlib.Path)
    parser.add_argument("--audit-manifest-sha256", required=True)
    args = parser.parse_args()
    pin = args.audit_manifest_sha256
    need(len(pin) == 64 and all(c in "0123456789abcdef" for c in pin), "external audit hash format")
    root = pathlib.Path(__file__).resolve().parent
    mb = (root / "MANIFEST.json").read_bytes()
    need(identity(mb)["sha256"] == pin, "external trusted audit manifest hash")
    manifest = parse_json(mb)
    entries = manifest["files"]
    need(isinstance(entries, dict) and all(safe_path(n) for n in entries), "safe audit inventory")
    expected = set(entries) | {"MANIFEST.json", "SEAL.json"}
    actual = set()
    for path in root.rglob("*"):
        need(not path.is_symlink(), "audit symlink")
        need(path.is_file(), "unexpected audit directory")
        actual.add(path.relative_to(root).as_posix())
    need(actual == expected, "exact audit inventory")
    for name, meta in entries.items():
        need(identity_is((root / name).read_bytes(), meta), "audit member bytes")
    seal = parse_json((root / "SEAL.json").read_bytes())
    need(seal["manifest_sha256"] == pin and seal["payload_file_count"] == len(entries)
         and seal["total_file_count"] == len(expected), "audit seal")
    binding = parse_json((root / "MAIN_BINDING.json").read_bytes())
    _, result = inspect(args.main_zip.read_bytes(), binding["archive"], binding["manifest"])
    print(json.dumps({"status": "PASS", "audit_manifest_sha256": pin,
                      "main_archive": result["archive"], "main_manifest": result["manifest"],
                      "main_files": result["total_files"], "supplied_programs_executed": False},
                     indent=2, sort_keys=True))

if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as exc:
        import sys
        print("REJECTED: " + str(exc), file=sys.stderr)
        raise SystemExit(1)
