# Uniform residual criterion for adjacent single-leading-digit degrees

Author candidate, 21 October 2026 UTC. Original F020 normalization. This is not a self-acceptance or a claim about arbitrary degrees.

## 1. Statement

Let p be an odd prime, c a positive even integer with 2 <= c < p, r >= 2, s > r, N=p^r, and q a characteristic-zero primitive p^s-th root of unity. Use exactly

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_j(z)=sum_a [j choose a]_q z^a.

Choose an algebraic p-adic embedding, put t=q-1, normalize v(t)=1, and write

    e=v(p)=(p-1)p^(s-1), B=r(p-1)p^(r-1)/2,
    h=floor(r/2), beta=p^h, L=N/beta,
    rho=beta/2                         if r is even,
    rho=p^(h-1)(2p-1)/2                if r is odd,
    K=cN/2+cB, E=(c-1)N/2+cB, D=(c+1)N/2+cB-p,
    n=cN+1.

Define integer polynomials and an explicit integer obstruction

    M_j(Z)=j! sum_(k=0)^floor(j/2) Z^(j-2k)/[2^k k! (j-2k)!],
    R_c(U)=sum_(k=0)^(c/2) c! U^(c/2-k)/[2^k k! (c-2k)!],
    A_c=R_c(-1)=M_c(i), where i^2=-1.

Thus R_c(Z^2)=M_c(Z). This is a fixed integer calculation in c, independent of p,r,s and of the unknown characteristic-zero roots.

THEOREM. If

    r >= 3, OR [r=2 and A_c is nonzero modulo p],              (C)

then both original H_n and P_n are squarefree, and the original algebraic-square Christoffel-Darboux kernel is nonzero at every P_n root. The following exact ordinary-derivative valuations hold:

    v(P_n'(0))=K,
    v(P_n'(xi))=x+min(D,N+E-2x), x=v(xi), for xi != 0.         (1)

The ordinary H_n root derivatives have the same valuations at the corresponding roots. No derivative in the residue field is substituted for the original ordinary derivative.

Root geometry does NOT require criterion (C). Put

    x_a=i(q^(a/2)-q^(-a/2)), 0<=a<beta,

with the square roots congruent to 1. For F=P_n/X, each closed disk v(X-x_a)>=rho contains exactly cL roots, all on its boundary, counted with multiplicity. These exhaust all cN roots of F. The remaining P_n root is its simple exact zero. For nonzero roots, x=rho in the central disk, while x=p^ord_p(a) in every other disk. The corresponding H disks are v(z+q^a)>=rho.

If r=2 and p divides A_c, the criterion has a precise genuine obstruction, not a verdict of nonsimplicity: exactly 2p central F roots counted with multiplicity have residual Y^2=-1 under X=mu Y, mu^2=t^p. At every such root,

    v(F') > D,                                                     (2)

allowing infinity if the root is multiple. All other nonzero roots satisfy (1). No simplicity or kernel conclusion is asserted here for those 2p exceptional roots. The c=2 central cancellation is retained, not silently excluded or declared solved by this argument.

Consequences include all even c<p for every r>=3, and the full families c=4 and c=6 for all r>=2. For c=8 the r=2 criterion fails exactly at p=11; for c=10 exactly at p=19; for c=12 exactly at p=311; for c=16 exactly at p=17 and p=29. These are exact factorizations of the obstruction, not finite parameter censuses.

The scope excludes arbitrary base-p digit strings, odd c, arbitrary n, global F020/F023 closure, FFT/cost claims, odd-composite orders, historical novelty, and a proof of nonsimplicity at any exceptional pair. The previously accepted c=2 and c=4 results are context, not new results credited here.

## 2. Original identities, denominators, and coefficientwise valuations

Write

    a_j=1-q^j, w_m=product_(j=1)^m a_j,
    Q_m=product_(j=1)^m (1-q^(2j)),
    N_m(z)=product_(j=0)^(m-1)(z+q^j),
    W(m)=sum_(j=1)^m p^ord_p(j).

Since cN+1 < pN <= p^s, every denominator appearing below is nonzero. Whenever a factor Q_a occurs, 2a<=cN; all derivative factors a_j also have j<=cN. For these indices v(a_j)=p^ord_p(j), and Q_m has valuation W(m). The factorials 1,...,c and 2 are residue-field units. There is no assumption that p=c+1 is prime: p is required to be prime at the outset, and that boundary is used only when it is prime.

The exact identities, before any reduction, are

    H_b=sum_(k=b mod 2) w_b N_k/[w_k Q_((b-k)/2)],                  (3)
    H_b'=sum_(k=b mod 2,k>=1) sum_(0<=m<k)
        w_b z^(k-m-1) N_m/[Q_((b-k)/2) w_m a_(k-m)].               (4)

One derivation works over Q(q): for the formal series J(x)=sum x^j/w_j, the relations J(qx)=(1-x)J(x), J(x)J(-x)=sum x^(2u)/Q_u, and J(zx)/J(-x)=sum N_k(z)x^k/w_k give (3). The identity

    partial_z log[J(zx)/J(-x)]=sum_(j>=1) z^(j-1)x^j/a_j

gives (4) by ordinary differentiation. All specializations are legal by the preceding denominator checks.

On a disk z=-q^a+lambda Y, v(lambda)=rho, use the coefficientwise Gauss weight. Set

    T(m)=sum_(j=1)^m min(p^ord_p(j),rho), R(m)=W(m)-T(m).

For completeness, the elementary cap needed throughout is proved here, not imported from an unreviewed adjacent family. The floor formulas are

    W(m)=m+sum_(b>=1)(p^b-p^(b-1)) floor(m/p^b),
    T(m)=m+sum_(b=1)^(h-1)(p^b-p^(b-1)) floor(m/p^b)
                   +(rho-p^(h-1)) floor(m/p^h).

Both W and R are linear in the base-p digits of m. For a<h, R(p^a)=0<W(p^a)/2. For h<=a<=r, direct substitution gives

    R(p^a)=W(p^a)/2-(r-a)(p-1)p^(a-1)/2.

Since 0<=m<=cN<p^(r+1), digitwise summation proves

    R(m)<=W(m)/2, equality exactly when m=jN.                     (5)

Also W is superadditive,

    W(N)=N+2B, W(jN)=jW(N), W((N-1)/2)=B.

Each coefficientwise factor of N_m has weight min(rho,p^ord_p(j-a)), with rho at j=a. Every string of m consecutive indices contains at least floor(m/p^b) members of each necessary divisibility level. Thus N_m has weight at least T(m). In a full N-block exactly L factors have indices congruent to a modulo beta; those factors have initial term lambda Y, and the others have nonzero constant initials. Choose omega^2=w_N. Then

    N_N/omega -> Zbar=alpha_a Y^L, alpha_a != 0.                  (6)

The disks for distinct a modulo beta are disjoint: their centers have mutual distance of valuation at most p^(h-1)<rho.

The block-unit formulas, coefficientwise where polynomials occur, are

    w_(jN)/w_N^j -> j!,
    Q_(uN)/(w_N^u) -> 2^u u!,
    Q_(uN+A)/(Q_A w_N^u) -> 2^u u!       (0<=A<N),
    N_(jN)/omega^j -> Zbar^j,                                  (7)

for the index ranges used below, all below p^s and all block multipliers below p. For the first formula, in block lN+i with i<N the factor ratio to i has residue 1; the endpoint i=N has ratio l+1. For the second, divide Q_(uN) by w_(uN), yielding product(1+q^i) with residue 2^(uN)=2^u. For the shifted formula, every ratio (1-q^(2uN+2i))/(1-q^(2i)), 1<=i<=A, has residue 1 because the added exponent has higher valuation. For N-block shifts, the changed factor differs by a term of valuation N>rho, proving the final formula without dividing by a polynomial at its zeros.

## 3. Reproved leading-digit residuals and ordinary derivative

For b=cN, the term k in (3) has weight at least

    W(cN)-[R(k)+W((cN-k)/2)] >= K.

By (5) equality requires k=jN. Parity gives j=c-2u, and each such index attains equality because there are no carries. Substitution of (7) proves

    H_(cN)/omega^c -> M_c(Zbar).                                (8)

For (4), put d=k-m and a0=(cN-k)/2. Its subtracted bracket is at most

    W(a0)+R(m)+p^ord_p(d)
       <= W(cN-d)/2+p^ord_p(d)
       = K-N/2+[p^ord_p(d)-W(d-1)/2].                           (9)

The reflection in the equality is exact: ord_p(cN-j)=ord_p(j) for 1<=j<cN, including j=lN since 1<=l<c<p. At a fixed b=ord_p(d), the final bracket has its unique maximum at d=p^b, with value

    g_b=p^b-b(p-1)p^(b-1)/2, g_0=1.

Here g_1>g_0, and for b>=1

    g_(b+1)-g_b=p^(b-1)(p-1)[p-b(p-1)]/2.

Thus the unique global maximum is g_2=p at d=p^2; the permitted interval includes p^2. Equality in (9) forces and is attained precisely by

    m=lN, k=lN+p^2, l=c-1,c-3,...,1,
    a0=uN+A0, u=(c-1-l)/2, A0=(N-p^2)/2.

The digits of A0 are (p-1)/2 in positions 2,...,r-1 and zero below; no carry is introduced. Put

    C1=w_N/[Q_A0 a_(p^2)].

Since W(A0)=B-p(p-1), its value is v(C1)=N+B-p. Each equality term divided by C1 omega^(c-1) has residue c! Zbar^l/[l! 2^u u!], as z^(p^2-1) reduces to 1. Consequently the ORIGINAL ordinary derivative has coefficientwise residual

    H_(cN)'/[C1 omega^(c-1)] -> c M_(c-1)(Zbar),
    v(C1 omega^(c-1))=D.                                      (10)

The integer recurrences

    M_j=Z M_(j-1)+(j-1)M_(j-2), M_j'=j M_(j-1)                 (11)

show that M_c and M_(c-1) are coprime modulo p: a common root propagates backwards to M_0=1, since all multipliers j-1 are units. More precisely, with the usual monic resultant convention,

    Res(M_c,M_(c-1))=product_(j=1)^(c-1) j^j,                  (12)

which follows inductively from (11) and the root-product definition. In particular no exceptional prime p>c can arise from this neighboring Hermite pair. Equations (8)-(10) have been proved coefficientwise, including away from the polynomial roots; their meaning is not differentiation of the inseparable polynomial M_c(alpha Y^L).

## 4. The odd neighbor and its full ordinary-derivative bound

Let b=cN-1, A=(N-1)/2. Then W(b)=cW(N)-N=2E. In (3), with a=(b-k)/2,

    W(b)-[W(a)+R(k)] >= E.

Equality requires exactly k=lN for l=1,3,...,c-1. Write u=(c-1-l)/2; then a=uN+A and W(a)=uW(N)+B. Set the actual scalar

    Cminus=omega^(c+1)/[a_(cN) Q_A], v(Cminus)=E.

Equations (7) show that the complete residual is

    H_(cN-1)/Cminus -> c M_(c-1)(Zbar).                         (13)

There is also a uniform coefficientwise bound weight(H_(cN-1)')>=E. Here are all terms, including the borderline possibilities. In (4) put j=k-m, a=(b-k)/2. Reflection gives W(b-j)=W(b)-W(j) for 0<=j<=b, by ord_p(cN-u)=ord_p(u). Hence

    W(a)+R(m)+p^ord_p(j)
       <= E+[p^ord_p(j)-W(j)/2].                              (14)

At fixed d=ord_p(j) the last bracket is maximal at j=p^d and equals

    [p^d-d(p-1)p^(d-1)]/2.

Its global maximum is 1/2, attained only at j=1 or j=p. For d>=2 it is negative; increasing j at a fixed d strictly decreases it. If j=1 or p, parity makes m even. If m is not a multiple of N, (5) is strict. Otherwise m=lN with l even and 0<=l<=c-2. Then

    2a=(c-l)N-1-j,
    floor(2a/N)=c-l-1 > 2 floor(a/N)=c-l-2.

Thus 2W(a)<W(2a) already at the N-level floor term. In either case (14) is strictly below E+1/2. All quantities lie in (1/2)Z, so the bracket is at most E. This proves the bound for every derivative term, not merely the residual pivots.

## 5. Transfer, quotient disks, and exact root at zero

The exact coordinate identity and its ordinary derivative are

    H_b(v0^2)=v0^b P_b(v0+v0^(-1)),
    H_b'=v0^(b-2)[(b/2)P_b+(v0-v0^(-1))P_b'/2].                 (15)

Near v0=i, the maps z=v0^2 and X=v0+v0^(-1) have unit derivatives. They give an analytic isometry between the stated H and P disks, preserving Gauss lower bounds. With M=P_(cN-1), Section 4 and (15) give

    weight(M)>=E, weight(M')>=E.                              (16)

The term proportional to P_(cN) in (15) has weight at least re+K>D, since re>N/2-p. Thus (10) transfers to the ordinary P_(cN) derivative also away from roots, with its actual unit coordinate factor and no omitted prefactor contribution.

Both M and P_n are odd by the original recurrence. The polynomials G=M/X and F=P_n/X satisfy exactly

    F=P_(cN)-a_(cN)G.                                        (17)

On the central disk, multiplication by X adds rho to Gauss weight. On a noncentral disk X is an analytic unit after scaling by its constant valuation x=p^ord_p(a)<rho. Consequently in every disk

    weight(a_(cN)G)>=N+E-rho=K+N/2-rho>K.                     (18)

Here rho<N/2 for all stated r,p. Therefore F has the same root residual as P_(cN), namely a unit times M_c(alpha_a Y^L). Its constant term is a unit because M_c(0)=c!/[2^(c/2)(c/2)!] and c<p; its degree is cL. All higher coefficients have strictly positive normalized weight.

The closed-disk Newton polygon count gives precisely cL roots, all with nonzero residual Y, in each disk; it counts multiplicity and does not use simple-root Hensel lifting on a repeated residual. The beta disjoint counts sum to cN=degree F and thus exhaust the roots without requiring an imported cover lemma. In the central disk the exact constant term has value K, so F(0) is nonzero and P_n'(0)=F(0) has value K. The exact zero is simple regardless of the criterion.

At any F root xi, the residual equation is M_c(Zbar)=0. By (11), M_(c-1)(Zbar) is nonzero. Equations (10),(13),(15) therefore yield the exact values

    v(M(xi))=E, v(P_(cN)'(xi))=D.                            (19)

They are asserted on this residual root locus, not at arbitrary boundary points.

## 6. All unequal-valuation cases

At a nonzero F root xi, write x=v(xi)>0. Ordinary differentiation of (17) gives

    F'=P_(cN)'-a_(cN)M'/X+a_(cN)M/X^2.                       (20)

By (16),(19), the last term has exact value N+E-2x, and the middle term has value at least N+E-x, strictly larger than the last. The first term has exact value D=N+E-p. If 2x differs from p, the first and last have unequal valuations, so

    v(F')=min(D,N+E-2x).                                    (21)

Every noncentral x is an integral power of the odd prime p, so 2x cannot equal p. In the central disk x=rho equals p/2 exactly when r=2; for every r>=3 it is larger. This proves the entire r>=3 family for every even c<p without any extra residual criterion, and all noncentral roots for r=2.

## 7. The central r=2 tie, with actual units for arbitrary c

Now N=p^2, B=N-p, rho=p/2. Choose mu^2=t^p and write X=mu Y. Let epsilon=(-1)^((p-1)/2). For indices below p^s, the edge unit is

    a_j/t^(p^ord_p(j)) -> -j/p^ord_p(j) modulo p.

Multiplying the residue blocks gives

    w_N/t^(N+2B) -> -1,
    Q_A/t^B -> -1, A=(N-1)/2,
    a_(cN)/t^N -> -c,
    N_N(z)/(t^B mu^p) -> -i^p Y^p.                          (22)

For w_N there are p full nonmultiple-of-p blocks, contributing (-1)^p=-1; the p-divisible block contributes 1. For Q_A, write A=ap+a, a=(p-1)/2. The product of j/p^ord_p(j) equals (-1)^a(a!)^2=-1 by Wilson, and the extra (-2)^A factor is 1 modulo p. For N_N, the p indices divisible by p contribute (z+1)^p, while the others contribute -t^B; use the exact identity z+1=v0 X and v0bar=i. These give all signs in (22) without fitting a control case.

Write the residue of omega/(t^B mu^p) as eta, so eta^2=-1, and put delta=-i^p/eta. Then delta^2=1 and Zbar=delta Y^p. Since c is even, i^(-cN) eta^c=1 (N=p^2 congruent to 1 modulo 4), and M_c(delta Y^p)=M_c(Y^p). Thus (8),(18) give the actual root residual

    F(mu Y)/t^K -> M_c(Y^p)=R_c(Y^2)^p.                      (23)

For the neighbor, (13) and (22) give a scalar with residue

    i^(1-cN) eta^(c+1) delta = -i^(p+1)=epsilon.

Therefore, for every even c<p, not just c=4,

    M(mu Y)/[t^(cB) mu^((c-1)p)] -> epsilon M_(c-1)(Y^p).     (24)

The equality of the two Hermite factors in (10),(13) lets us compare their actual scalar normalizations, without dividing at zeros. Their ratio is exactly

    [C1 omega^(c-1)]/Cminus
      =a_(cN) Q_A/[Q_A0 a_(p^2)].                            (25)

At r=2, A0=0, and (22) makes its initial -c t^B. Equation (15) multiplies the derivative-to-neighbor scalar ratio by 2v0^2/(v0^2-1), with residue 1. The prefactor error is higher by Section 5. Consequently

    P_(cN)'(mu Y)/[t^((c+1)B) mu^((c-1)p)]
         -> -c epsilon M_(c-1)(Y^p).                        (26)

The normalizing weight is E+B=D. In (20) the middle term has weight strictly greater than D on the central boundary, while the last term contributes -c epsilon Y^(-2)M_(c-1)(Y^p), because N-B=p and mu^2=t^p. Hence the ACTUAL ordinary quotient derivative has boundary residual

    F'(mu Y)/[t^((c+1)B) mu^((c-1)p)]
         -> -c epsilon (Y^2+1) M_(c-1)(Y^p)/Y^2.             (27)

This expression is a polynomial: M_(c-1) is odd and its smallest exponent after substitution is p>=3. It also holds coefficientwise on the closed disk. Indeed the polynomial G=M/X has weight at least E-rho; (16) ensures M'/X has boundary weight above D after multiplying by a_(cN). A polynomial's Gauss weight is its boundary Gauss weight, so the Laurent calculation identifies the polynomial initial without hiding a negative power or a low-degree term. Equivalently one can differentiate G in characteristic zero: each leading exponent lp-1 reduces to -1, whereas (16) places every possible M' contribution above D. All derivative integer factors are retained before reduction.

At a root of (23), Y is nonzero and M_(c-1)(Y^p) is nonzero by (11). The only possible cancellation factor in (27) is therefore Y^2+1. The exact criterion is

    gcd(R_c(U),U+1)=1 over F_p
       iff A_c=R_c(-1) is nonzero modulo p.                 (28)

With the usual resultant convention,

    Res(R_c,U+1)=(-1)^(c/2) A_c.                             (29)

It is an explicit integer, unrelated to an unknown ordinary derivative at a lifted root. This is why the criterion is not tautological.

If (28) holds, (27) is nonzero at every central F root and v(F')=D. If it fails, R_c has a simple root at U=-1: M_c is separable by (11), its constant term is nonzero, and p is odd. Thus (23) has precisely the two residual roots Y^2=-1, each of multiplicity p. Newton polygon counting supplies exactly 2p lifted roots counted with multiplicity, and (27) vanishes at each, proving (2). All other residual roots give v(F')=D. These assertions do not assume those exceptional lifted roots are simple.

## 8. Exact obstruction arithmetic and meaningful subfamilies

Let a_m=A_(2m). Elimination of the odd Hermite polynomial from (11), or direct coefficient comparison, gives the integer recurrence

    a_0=1, a_1=0,
    a_m=(2m-2)[2a_(m-1)-(2m-3)a_(m-2)], m>=2.                (30)

Thus the criterion is effectively computable without constructing any high-degree original polynomial or taking any cyclotomic derivative. Fixed digits give the following exact results:

    A_2=0,
    A_4=-2,
    A_6=-16,
    A_8=-132=-2^2*3*11,
    A_10=-1216=-2^6*19,
    A_12=-12440=-2^3*5*311,
    A_16=-1601264=-2^4*7*17*29^2.

Because p>c, c=4 and c=6 have no exceptional allowed prime; c=8,10,12,16 have exactly the exceptional allowed primes listed in Section 1. In particular c=16,p=17 is a genuine prime-boundary obstruction. The nonprime numbers c+1=9 or 15 are never tested as if they were primes. For c=2, (23)=(Y^2+1)^p and (27) is a nonzero scalar times Y^(p-2)(Y^2+1), so the central cancellation occurs at every central residual root. This preserves the established negative control; the deeper c=2 completion lies outside this criterion.

There is also an infinite arithmetic subfamily for which the integer obstruction is provably nonzero: for k>=1,

    ord_2(a_(2k))=k,
    ord_2(a_(2k+1))>=k+3, with ord_2(0)=infinity.             (31)

Proof by induction: a_1=0 and a_2=-2 start it. In the even step, the bracket 2a_(2k-1)-(4k-3)a_(2k-2) has exact 2-adic value k-1 because the first term has strictly greater value; the outside factor 4k-2 adds 1. In the odd step the two bracket terms have values at least k+1, and the outside factor 4k has value at least 2, giving at least k+3. This proves (31), including the initial k=1 odd step. Hence A_c is nonzero for every positive c divisible by 4. For each such fixed c the central criterion excludes only the finite, explicitly determined prime divisors p>c of A_c. No claim that every other even-index obstruction is nonzero is needed or made. In any case all digits remain covered unconditionally when r>=3.

## 9. Original H/P simplicity and square-kernel gate

At a nonzero F root, P_n'=X F'; hence (21) and (27) give (1). At zero, Section 5 already proved the exact derivative K. Under criterion (C), every original P_n root derivative is therefore nonzero.

Modulo the maximal ideal P_n=X^n and H_n=(1+z)^n; thus P roots are not +/-2, and H roots are nonzero. On the branch near i, both coordinate derivatives in (15) are units. At a root the term proportional to P_n vanishes exactly, transferring multiplicities and ordinary derivative valuations to H_n. This proves its squarefreeness under the same criterion.

Every original recurrence edge a_j, 1<=j<n, is nonzero. A common root of P_n and P_(n-1) would propagate backwards through the original recurrence to P_0=1, impossible. The identity follows by differentiating the original recurrence: the Wronskian difference at level j equals P_j^2 plus a_j times the previous Wronskian; division by w_j and telescoping gives the ordinary Christoffel-Darboux identity. At a P_n root xi it is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
       =P_n'(xi) P_(n-1)(xi)/w_(n-1).

All factors on the right are nonzero under (C). This is the original algebraic-square kernel, not an absolute-value-square kernel. No positivity, real-rootedness, interlacing or Fourier inference is used. Injectivity of the chosen algebraic p-adic embedding and Galois conjugacy transfer nonvanishing to every characteristic-zero primitive embedding.

## 10. Verification status, controls, and dependency gate

The proof above is self-contained from the original recurrence and displayed exact identities. In particular Sections 2-3 reprove the cap, block units, and ordinary derivative residual needed from the earlier single-leading-digit work. No mathematical claim depends on the c=4 candidate or on its later acceptance. The copied accepted single-leading-digit report and its public archive are bound as normalization/provenance comparisons, not as a substitute for a proof step.

check_controls.py performs separate finite falsification checks: all neighboring Newton/derivative terms in bounded cases, exact low-degree resultants and obstruction factorization, rational-q original H/P/Newton/CD identities, and actual mixed-characteristic cyclotomic recurrence coefficients. The latter uses Z/p^h[q]/Phi_(p^s), with h chosen so h*e is strictly above every tested threshold. It keeps the entire q-degree basis and truncates X only above every potentially contributing weighted degree. After the exact Pascal substitution q=1+t, coefficient weights j+e*ord_p(coefficient) are distinct modulo e, so their minimum and its unit are exact below h*e. The leading unit p/t^e=-1 is retained. Ordinary derivative integer factors are multiplied before valuation; coefficient divisibility by p is never discarded prematurely. This includes the c=2 negative control and the actual exceptional (c,p)=(8,11) recurrence, not only a formal residual census.

Controls do not prove the unlimited family. The candidate requires a separate reviewer binding its exact frozen manifest and checking both the uniform proof and an independent cold replay. Every prior source remains unchanged; no external write is part of this candidate.
