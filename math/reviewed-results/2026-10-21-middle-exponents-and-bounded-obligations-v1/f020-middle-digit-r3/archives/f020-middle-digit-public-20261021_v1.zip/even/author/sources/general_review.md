# Independent review: even leading-digit adjacent criterion

## Verdict and exact binding

**ACCEPTED WITHIN THE EXACT STATED SCOPE.** No essential repair was supplied by this reviewer. The author wrote and froze the proof; the reviewer independently reconstructed its mathematical argument, checked its actual frozen bytes, and completed separate original-recurrence controls and capped cold replays. No author file or external repository was changed.

The accepted author candidate is `f020-uniform-adjacent-criterion-candidate-20261021_v1`:

- Author `MANIFEST.json` SHA-256: `e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7`.
- Author `REPORT.md` SHA-256: `639b35b0b603fccc44a57c1f5321fc7efc5c9007510b0cd12d714eefc0d5820c` (22,805 bytes).
- Exact inventory: 13 manifest-bound files, plus manifest and seal; no unlisted files or symlinks.
- Mathematical dependencies: none beyond the original definitions and the standard elementary formal-series, valuation, and Newton-polygon facts explicitly used in the proof. The needed leading-digit lemmas are actually reproved, not imported from c=4.

The fixed accepted comparison archive has SHA-256 `c86929554da6cba650c0eb13ede9384e1515cfd220522983e0031e39331aa5fe`; all 453 entries in its manifest and the candidate's copied report/acceptance bytes were checked. Those archive bytes equal the copy in the preceding accepted c=4 package. The supplied earlier anchors were independently checked too: the c=4 candidate manifest `24ed212df93a491daf4ac7dddd880b36e44520242f84c78c12bb858ef22fb40d`, its review manifest `9ac7622b6dc17f61af62a3699efa655a2ea302ce11bcf691ac7cf4ab99b40dac`, and the central-family archive `667b37740cd2229082899e726a6efdb7e2be8b2e5d177eed5d3869bbcb79ec4e`.

## Accepted theorem, not a broader closure claim

Assume p is an odd prime, c is even with 2 <= c < p, r >= 2, s > r, N=p^r, q is primitive of order p^s, and n=cN+1. Use the original H/P polynomials, ordinary characteristic-zero derivatives, and algebraic-square Christoffel-Darboux kernel. Write B=r(p-1)p^(r-1)/2 and

- K=cN/2+cB;
- E=(c-1)N/2+cB;
- D=(c+1)N/2+cB-p.

With the author's explicit integer A_c=R_c(-1)=M_c(i), both H_n and P_n are squarefree and the original kernel is nonzero at every P_n root whenever r>=3, or r=2 and p does not divide A_c. The exact derivative values are K at zero and x+min(D,N+E-2x) at a nonzero root with x=v(X). The corresponding H derivative valuations agree.

The disk geometry and simple exact zero do not need the criterion. F=P_n/X has cL roots on each of the beta closed-disk boundaries specified in the candidate, counting multiplicity. Their total is cN. Noncentral roots have x=p^ord_p(a); central roots have x=rho.

At r=2 and p|A_c, exactly 2p central F roots, counted with multiplicity, lie above Y^2=-1 and have v(F')>D, with infinity allowed. All other nonzero roots retain the stated derivative formula. This is a proved failure of the leading derivative test, **not a proof of nonsquarefreeness**. The criterion is sufficient for squarefreeness, not asserted necessary. The separately accepted deeper c=2 result is not contradicted.

No acceptance extends to odd c, c>=p, r=1, s<=r, general base-p strings, arbitrary n, odd-composite orders, global F020/F023 closure, FFT or cost-model consequences, or historical novelty. The c=2 and c=4 results are not counted as new here. The new unconditional c=6 family is a genuine consequence of the stated criterion and A_6=-16.

## Uniform mathematical audit

### 1. Indices, weights, and the cap

The strict inequality cN+1<pN<=p^s uses c<=p-1 and N>1. It covers every recurrence edge, every a_(k-m), and the Q factors, whose exponents satisfy 2a<=cN. No denominator vanishes. The edge valuation is p^ord_p(j), and e=v(p)=(p-1)p^(s-1). Prime-boundary c=p-1 is included; composite values of c+1 are never treated as primes.

The displayed floor formulas for W and T yield digitwise linearity of W and R=W-T. Substitution at p-powers gives the stated deficit from W/2 at every digit below r, with equality only at the r-th digit. Since c<p, there is no higher digit. Thus R(m)<=W(m)/2 has exactly the equality set m=jN on the full needed interval. This is a uniform digit proof, not an inference from finite tests.

For a translated rho-disk, residue-class counts give the coefficientwise lower bound T(m) for N_m. In an N-block exactly L factors contribute the scaled variable and the remaining factors contribute nonzero constants. Hence N_N/omega has initial alpha Y^L with alpha nonzero. The shifted-block arguments keep actual unit residues and do not divide by a polynomial at a zero.

### 2. Leading polynomial and its ordinary derivative

The Newton and derivative formulas are exact over Q(q), with legal specialization afterward. Their formal-series derivation differentiates before residue reduction. In particular it is not differentiating M_c(alpha Y^L) in characteristic p.

For H_(cN), the only Newton equality indices are k=jN with j=c,c-2,...,0. The actual w and Q block units sum to M_c. In the ordinary derivative, the score at fixed ord_p(d) is largest at d=p^b, and its consecutive differences show the unique global maximum at d=p^2. Equality also requires m=lN, with exactly the odd l from 1 through c-1; the no-carry check for A0=(N-p^2)/2 is valid, including A0=0. Summing all equality terms produces c M_(c-1), not a selected pivot term.

The Hermite recursion gives a uniform backwards-propagation proof of coprimality for p>c. The resultant formula is correctly signed and equals product j^j for 1<=j<c. Since c is a unit, the formal derivative relation also gives separability of M_c. This disposes of all possible consecutive-Hermite residue collisions without a prime census.

### 3. The odd neighbor, including every derivative term

For b=cN-1, the Newton equality indices are precisely k=lN, l odd, 1<=l<=c-1. With the actual scalar Cminus, their sum is c M_(c-1), and its weight is E.

The full ordinary-derivative bound follows from exact reflection W(b-j)=W(b)-W(j), the cap, and superadditivity. The only apparent excess scores are j=1,p, both with excess 1/2. If m is not a multiple of N, the cap is strict. Otherwise parity makes m=lN with l even, and floor(2a/N)=c-l-1 exceeds 2 floor(a/N)=c-l-2. The positive N-level contribution makes superadditivity strict. Since all bounds are half-integral, the subtracted bracket is at most E. This checks the p=3,c=2 and prime-boundary cases as well as larger c. No omitted ordinary derivative term can compete below E.

### 4. Analytic transfer and complete root count

The H/P coordinate identity and its ordinary derivative have the correct factor (b/2)P_b. Both coordinate maps are local isometries near i because p is odd. For b=cN, the prefactor error has weight at least re+K>D; the strict comparison re>N/2-p follows already from s>r. Thus the leading ordinary P derivative can be used away from roots, as the proof needs.

Oddness makes G=P_(cN-1)/X and F=P_(cN+1)/X actual polynomials. On the central disk division by X lowers weight by rho. On noncentral disks X has constant valuation below rho, so the same weaker bound remains valid. Therefore a_(cN)G has weight at least K+N/2-rho>K. The quotient and leading polynomial have the same residual.

For even c<p, M_c(0) is a unit. The translated F residual has degree cL and nonzero constant, and all higher coefficients have positive normalized weight. The closed-disk Newton polygon therefore counts exactly cL roots, all on the boundary, before simplicity is known. The beta disjoint disk counts exhaust degree cN, so no extra imported all-root cover is needed. At the central constant coefficient, F(0) has exact value K. The zero of P_n is consequently simple without dividing by X at zero.

The exact neighbor and base derivative values E and D are claimed only at the F residual root locus, where Hermite coprimality guarantees them. The proof does not incorrectly assert these values at every arbitrary boundary point.

### 5. Separation for r>=3 and noncentral roots

The three derivative terms have respective values D, at least N+E-x, and exactly N+E-2x. The middle term is strictly above the last. If the first is the smaller term, the middle is also above it. Thus unequal first/last values suffice. Their only possible tie is 2x=p. Noncentral x is an integral power of an odd prime, so no tie occurs. Centrally rho=p/2 exactly when r=2; for r>=3, rho>p/2. This proves the unconditional r>=3 claim for every allowed even c.

### 6. The actual general-c tie calculation

The r=2 phase calculation was independently reconstructed. With mu^2=t^p, B=p^2-p and epsilon=(-1)^((p-1)/2), the actual block initials are w_N -> -1, Q_A -> -1, a_(cN) -> -c, and N_N -> -i^p Y^p under the displayed scalings. Wilson's identity gives the Q_A sign; the factor (-2)^A is 1 because A=(p^2-1)/2 is divisible by p-1.

Writing eta for the normalized omega unit and delta=-i^p/eta gives eta^2=-1 and delta^2=1. Evenness removes the arbitrary square-root sign in the F residual. The actual P-neighbor scalar reduces to epsilon, independently of c. These give F/t^K -> M_c(Y^p) and the neighbor initial epsilon M_(c-1)(Y^p).

The scalar ratio is the actual ratio C1 omega^(c-1)/Cminus, not a guessed continuation of c=4. At r=2 it has initial -c t^B; the H/P conversion ratio 2v0^2/(v0^2-1) has residue 1. The base ordinary derivative therefore contributes -c epsilon M_(c-1)(Y^p). The quotient correction contributes the same scalar times Y^(-2)M_(c-1)(Y^p). Their sum has exactly the factor Y^2+1.

The expression is polynomial since the minimum substituted exponent is p>=3. A direct coefficient check on G=M/X confirms that a leading exponent lp-1 contributes -1 modulo p under ordinary differentiation; all higher-weight coefficients remain higher. Equivalently the already proved M' bound excludes a missing contribution. Thus the closed-disk residual is legitimate, not merely a formal Laurent evaluation.

### 7. Criterion, exceptions, and arithmetic nontriviality

At a root of M_c(Y^p), neither Y nor M_(c-1)(Y^p) vanishes. The only possible leading cancellation is Y^2+1=0, exactly equivalent to R_c(-1)=0 modulo p. The stated resultant sign is Res(R_c,U+1)=(-1)^(c/2)A_c.

When A_c vanishes modulo p, R_c is still separable and has a simple root at -1. Therefore its two Y square roots each acquire multiplicity p in R_c(Y^2)^p. This explains the count **2p lifted roots**, while the gcd of the displayed root and derivative residual polynomials has **degree 2**, not 2p. The distinction is respected in the proof and controls.

The obstruction recurrence and listed exact factorizations are correct. They give all allowed exceptions for c=8,10,12,16, including (16,17). The two-adic induction establishes ord_2(A_(4k))=k and the stated lower bound on the interleaved indices. This is a uniform proof of an infinite nonzero-obstruction subfamily; no finite factorization census substitutes for it. For c=2, A_2=0 identically, so the all-prime cancellation negative control is retained.

### 8. Original normalization and kernel gate

At a nonzero F root, P_n'=X F'. At zero the exact value was already determined. H/P multiplicities and derivative values transfer through unit coordinate derivatives; the prefactor term vanishes exactly at a root. There is no ramified coordinate exception at +/-2.

Consecutive P polynomials have no common root because all recurrence edges are nonzero and backwards propagation would reach P_0=1. Differentiating the unchanged recurrence and telescoping gives the displayed diagonal Christoffel-Darboux identity. Its nonzero right side yields the original algebraic-square kernel gate. No absolute-value-square, positivity, interlacing, Fourier, or cost inference is made.

## Independent controls and replay evidence

The finite controls are falsification and transcription evidence; the uniform argument above establishes the unlimited theorem.

The separately written `independent_controls.py` imports neither candidate nor prior-review code. Its exact field computation uses the original P recurrence in a parity-compressed full cyclic group algebra, then reduces to the canonical cyclotomic basis at the end. This differs from the author's X-truncated, stepwise cyclotomic implementation. Ordinary derivative integer multipliers are retained. The q=1+t conversion keeps p-divisibility and the leading unit p/t^e=-1. Its precision is strictly above every inspected threshold, and the int64 accumulation bound is checked.

Completed independent tests include:

- 40 weight/geometry parameter rows and 1,839,452 complete Newton/ordinary-derivative term pairs.
- 384 prime/digit Hermite tests; exact resultant checks through c=20; obstruction recurrence and two-adic checks through c=300.
- Explicit exceptional controls (8,11), (10,19), (12,311), (14,719), (16,17), (16,29), together with c=2 cancellation and c=4,c=6 passing cases. Large-prime checks use squarefree R and Frobenius rather than constructing unnecessarily huge Y polynomials.
- Exact rational-q Newton, ordinary derivative, H/P, and original algebraic-square CD identities through degree 10 at q=2/7.
- Nine actual cyclotomic recurrence cases: (p,c,r,s)=(3,2,2,3), (5,2,2,3), (5,4,2,3), (5,4,2,4), (7,6,2,3), (11,8,2,3), (3,2,3,4), (3,2,4,5), (5,4,3,4).

The exceptional c=8,p=11 computation is above ramification: K=1364 and D=1413.5 while e=1210. It therefore tests the mixed-characteristic issue, not merely a characteristic-p model. The actual F derivative residual has the predicted degree-2 common factor. The p=3 and p=5 c=2 cases preserve cancellation; the r=3 and r=4 tests have no such tie.

The author's frozen cold replay passed byte-for-byte in 21.321 seconds under 180 CPU seconds, 240 wall seconds, 1 GiB address space, 64 MiB output, and one numerical thread. The independently written suite cold-replayed in 16.442 seconds under 120 CPU seconds, 180 wall seconds, 2 GiB address space, 32 MiB output, and one numerical thread. Its result JSON was exactly equal after removing timing-only fields. The independent script SHA-256 is `f9061c75ee541f5a1beab44c42a5e780dac7fc49ef35921d9f5b341d6720e3ae`; normalized semantic result SHA-256 is `eff916c821610f60e3dbdde482bcc40a0b23a04e8235c9db0274797b868cb4f0`.

Six disposable-copy integrity mutations were rejected: proof edit, missing bound file, unlisted file, seal mismatch, fully rehashed replacement under a changed manifest, and symlink replacement. Additional algebraic gates reject copying the c=4 scalar into arbitrary c, the wrong tie sign, an omitted tie factor, residue-field differentiation, removal of the c=2 negative control, denial of prime-boundary exceptions, and inadequate mod-p precision.

## Final conclusion

All mathematical, normalization, source, inventory, cold-replay, and scoped negative-control gates passed. This exact frozen candidate is accepted for the theorem and cancellation statement above. Exceptional leading cancellation remains an open lifting question in this argument, not a counterexample. The candidate and all previously accepted sources were unchanged by the review.
