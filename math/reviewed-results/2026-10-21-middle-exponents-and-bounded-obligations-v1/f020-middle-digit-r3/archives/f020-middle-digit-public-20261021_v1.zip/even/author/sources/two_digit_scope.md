# F020/F023: the complete first-two-digit residual range

20 October 2026 UTC. Frozen author proof candidate for independent review. No external mutation, owner closure, priority change, cost claim, or historical-originality claim.

## Theorem and exact scope

Let p be any odd prime, s>=1, and q any primitive p^s-th root of unity in characteristic zero. Define the actual polynomials

    P_0(X;q)=1, P_1(X;q)=X,
    P_(n+1)(X;q)=X P_n(X;q)-(1-q^n)P_(n-1)(X;q),
    H_n(z;q)=sum_(j=0)^n [n choose j]_q z^j,

where the brackets are Gaussian binomial coefficients. Then

    0<=b<min(p²,p^s)
    implies Disc_X P_b != 0 and Disc_z H_b != 0.          (T)

Both are ordinary discriminants in the displayed polynomial variables. At every root xi of P_b,

    sum_(j=0)^(b-1) P_j(xi;q)^2 / product_(a=1)^j(1-q^a) != 0. (K)

The squares in (K) are algebraic squares, not absolute-value squares; empty products equal 1. At b=0 there are no roots and (K) is vacuous. Disc(1)=Disc(monic linear)=1.

This settles the entire ordinary static guard at every odd prime-square root order d=p², not merely another fixed number of p-blocks. At higher powers it settles all first-two-base-p-digit residual degrees. The new uniform argument treats every k,r with b=kp+r, 0<=k,r<p, at p>=5; the k=0/s=1 and p=3/b<9 cases already lie in accepted ranges. No p>=5 local valuation formula is asserted at p=3. The previously accepted p=3 degrees 9,10,11 below the root order, complete d=9/d=25 certificates, fixed-residual families, all-odd fixed-node and overlap guards, signed coefficients, nonzero denominators, and independent local/all-A hypotheses remain valid and unchanged.

For p>=5, s>=2, b=kp+r, eta=k mod 2, epsilon=r mod 2, and v(q-1)=1, the proof also gives the exact ordinary X-discriminant valuation

    v(Disc_X P_(kp+r))
      = kp[kp-(k+1)/2] + kp r + r(r-1)/2
        + epsilon (p-1)(k+eta/2).                       (D)

At k=0 this reads r(r-1)/2; at k=3 it is exactly the independently accepted fourth-block formula. No equality with the ordinary H-discriminant valuation is claimed.

The proof is one arbitrary-k path-matching argument with uniform error bounds, not an induction that assumes previous root simplicity and not a finite-prime extrapolation. In particular the ordinary derivative is reduced separately before specialization; the formal derivative of a Frobenius residue would be zero and is not substituted for it.

## Accepted inputs and source binding

The accepted fourth-block report, independent review and verdict are retained in sources/; the report hash is 1001aeb410010dbff16873200a516320d5fec48760bca40f2b6ccb177698336d. The retained accepted p-block and 3p reports give the elementary p-block coefficient theorem, rederived below. The original accepted scope and uniform node-guard texts are also retained. SOURCE_BINDINGS.json gives their exact byte lengths and SHA-256 hashes. These are fresh checks of retained source bytes, not a claimed new remote retrieval. No historical proof checker is imported or executed.

The classical Gaussian identity, monic Hermite recurrence, path-continuant expansion, Gauss valuation multiplicativity, simple-root Hensel lemma, discriminant product formula and Christoffel-Darboux identity are used as standard tools. The candidate is the stated uniform combination and its actual-family estimates, not a claim that those tools are new. Historical priority remains unverified.

## Valuation setup and notation

Let p>=5, q primitive p^s with s>=2, t=q-1, v(t)=1, e=v(p)=p^(s-1)(p-1), u_j=1-q^j. Let 1<=k<p, 0<=r<p, n=kp+r. Define h=(p-1)/2, c=(-1)^((p+1)/2), d=(p-2)!!, f=2^h h!, so df=-1 mod p. Choose rho^(2p)=t^(2p-1), alpha=v(rho)=(2p-1)/(2p), and tau=rho^p/t^(p-1), so tau²=t. Put delta=(p²-1)/(2p), eta=k mod 2, epsilon=r mod 2, r=2m+epsilon. All reduction statements below mean coefficientwise integrality followed by residue reduction, not simply a formal mod-p computation of a target whose valuation may approach e.

Write He_j(Z) for the monic probabilists' Hermite recurrence He_0=1, He_1=Z, He_(j+1)=Z He_j-j He_(j-1). For j<p these are squarefree: He_j'=j He_(j-1), and consecutive polynomials are coprime by downward recurrence. Put C_j=He_j(0) if j even and C_j=He_j'(0) if j odd. Thus C_(2a)=(-1)^a(2a-1)!! and C_(2a+1)=(-1)^a(2a+1)!!, all units for j<p. In particular C_k=k C_(k-1) when k is odd.

## 1. Local pieces

For completeness, the p-block coefficient estimate follows directly from the actual Gaussian coefficients. Over F_p[[T]], q=1+T, for 0<j<p,

    [p choose j]_q = ((1-q^p)/(1-q^j))[p-1 choose j-1]_q
                  = (-1)^(j-1) T^(p-1)/j + O(T^p).

Thus H_p(z;1+T) is 1+z^p modulo T^(p-1). The exact identity H_p(v²;q)=v^p P_p(v+v^(-1);q) and Frobenius imply P_p(X;1+T)=X^p modulo (p,T^(p-1)); injectivity of X->v+v^(-1) follows by its largest Laurent exponent. Differentiating the Gaussian expansion at z=-1 gives H_p'(-1;1+T)=-T^(p-1)+O(T^p) modulo p. Differentiating the exact normalization at v²=-1 gives P_p'(0;q)=(-1)^h H_p'(-1;q). Hence the linear coefficient has residue c after division by t^(p-1). Every possible p-multiple has valuation at least e>=p(p-1)>p-1. This proves the following coefficientwise assertion in the actual mixed-characteristic field, not only in a formal series ring.

The accepted p-block coefficient theorem states P_p=X^p+lambda X+E, where lambda/t^(p-1)->c and every coefficient of E has valuation >=p-1; E is odd with exponents 3,...,p-2. Every shifted p-block A_i on vertices ip+1,...,(i+1)p has A_i-P_p coefficientwise valuation >=p because each changed edge u_(ip+j)-u_j=-q^j(q^(ip)-1) has valuation p, for 1<=i<p. The difference is odd of degree <=p-2. Therefore:

 A_i(rho Y)/rho^p -> Y^p,
 A_i'(rho Y)/t^(p-1) -> c,
 A_i(tY)/t^p -> S(Y)=Y^p+cY.

The ordinary derivative statement is derived before reduction: the leading derivative pX^(p-1) has weight e+(p-1)alpha>p-1. It is not the derivative of Y^p.

Let L_i and R_i be A_i with last or first vertex removed. Their weights at any beta>1/2 are h and residual constants d and f. Each coefficient of X^(2j) has valuation >=h-j, so their derivatives at rho have weight >=h-1+alpha. Let M_i have both endpoints removed. It has p-2 odd vertices; its weight at beta>1/2 is >=h-1+beta, and its derivative weight is >=h-1. No leading coefficient of M_i needs to be a unit.

## 2. Arbitrarily many whole blocks

Let G_k=P_(kp). Expand path matchings by the subset E of the k-1 joining edges p,2p,...,(k-1)p. Let j=|E| and a be the number of full blocks incident to two selected joining edges, equivalently the number of adjacent pairs in E. Exactly b=2j-2a blocks have one endpoint removed and c0=k-2j+a have none. The exact summand is product of (-u_(ip)) over E times the corresponding A,L,R,M factors. No subset is omitted.

At rho scale the summand weight is >=kp alpha+a delta. If a=0, its residual after division by rho^(kp) is product_((i in E))(-i) Y^(p(k-2j)). These are exactly path matchings for He_k(Y^p). Thus

 G_k(rho Y)/rho^(kp) -> He_k(Y^p).                    (G-alpha)

Define N_k=t^(p-1)rho^((k-1)p)=rho^(kp)/tau, of weight D_k=kp alpha-1/2=kp-(k+1)/2. Differentiate each exact subset summand:

- derivative hits an A: weight >=kp alpha+a delta-1/2;
- derivative hits an L or R: weight >=kp alpha+a delta-1+alpha;
- derivative hits an M: weight >=kp alpha+a delta-alpha.

Relative to D_k, all a>=1 contributions have positive gap: respectively a delta, a delta+alpha-1/2, and a delta-alpha+1/2>=h. When a=0, endpoint derivatives have gap alpha-1/2>0. Only the derivative hitting an intact A survives, with its c residue. Hence

 G_k'(rho Y)/N_k -> c He_k'(Y^p).                    (G-prime)

The prime on He_k here denotes its derivative in Z, evaluated at Z=Y^p. It does not denote d/dY of He_k(Y^p).

At t scale a subset weight is >=kp-j+a(h+1). Set M_k=kp-floor(k/2). If a=0 the minimum is attained at j=floor(k/2). If a>=1, the number of runs j-a is <=floor(k/2), so its excess over M_k is >=ah>0. The disjoint maximal matchings give

 G_k(tY)/t^M_k -> C_k S(Y)^eta.                     (G-t)

## 3. The one-vertex-short polynomial

Let V_k=P_(kp-1). It consists of k-1 complete blocks followed by the last p-1-vertex L block. Partition by E as before. Let z=1 if the final joining edge (k-1)p is selected and 0 otherwise; let a count doubly incident full blocks among the first k-1. The first k-1 blocks have 2j-z-2a single-endpoint deletions and k-1-2j+z+a intact blocks. The final block is L if z=0 and M if z=1.

Set L_k=h+(k-1)p alpha. At rho scale each summand has weight >=L_k+(a+z)delta. Only a=z=0 survives, giving

 V_k(rho Y)/(t^h rho^((k-1)p)) -> d He_(k-1)(Y^p).  (V-alpha)

The denominator is meaningful even when L_k is half-integral. This also gives the coefficientwise derivative bound weight(V_k'(rho Y))>=L_k-alpha.

At t scale the weight is >=h+(k-1)p-j+(a+z)(h+1). Set J_k=h+(k-1)p-floor((k-1)/2)=L_k+(1-eta)/2. The number of runs not touching the final edge is j-a-z<=floor((k-1)/2); all a+z>0 terms have gap >=(a+z)h. Hence

 V_k(tY)/t^J_k -> d C_(k-1) S(Y)^(1-eta).           (V-t)

For odd k the V-t residue is a unit constant and remains so at every beta>=1 after the same normalization.

## 4. Tail pieces, alpha root counts, and ordinary derivatives

For r>=1 let A be the r-vertex tail after kp and B its first vertex deleted. Exact identity F=P_n=A G_k-u_(kp) B V_k. All internal tail edges have valuation 1 and residues -j after division by t. Set a_r=(2m-1)!! for even r and (2m+1)!! for odd r. For every beta>1/2,

 A(t^beta Y)/(t^m(t^beta)^epsilon) -> a_r Y^epsilon.

For even r, B has weight >=m-1+beta and B' >=m-1. For odd r, B/t^m -> b_r=2^m m!, and (XA'-A) has weight >=m-1+3beta when r>=3 (identically zero for r=1).

At rho scale the joining perturbation has gap delta for even r, and (p-1)^2/(2p) for odd r, over t^m rho^(kp+epsilon). Thus F has residual a_r Y^epsilon He_k(Y^p) in that normalization.

At outer scale tau the monic normalized polynomial has residual Y^(kp) h_r(Y), where h_(j+1)=Yh_j+jh_(j-1). Its r-epsilon nonzero residual roots are simple. They lift to r-epsilon distinct roots of valuation 1/2, with derivative valuation (n-1)/2. Let O be their monic Galois-stable factor of degree 2m. Elementary symmetric bounds give O(rho Y)/t^m -> a_r. In F=O I, Gauss valuation multiplicativity therefore makes I(rho Y)/rho^(kp+epsilon) integral and monic, with residual Y^epsilon He_k(Y^p). Thus exactly p(k-eta) target roots, counted with multiplicity, have valuation alpha; the remaining eta p+epsilon have valuation >alpha. This is not a simple-root Hensel claim for a Frobenius residue.

For even r>=2 use the exact root-aware identity

    R=A F'-A'F
     =A²G_k'+u_(kp)(A' B V_k-A B' V_k-A B V_k').

The even tail has A' weight >=m-1+alpha. Thus the first joining term before its u factor has weight >=2m-2+2alpha+L_k, and the other two have weight >=2m-1+L_k. Since 2alpha>1, every joining derivative perturbation has weight >=p+2m-1+L_k, exceeding 2m+D_k by h. The main term is A²G_k'. Thus

 R(rho Y)/(t^(2m)N_k) -> c a_r² He_k'(Y^p).

At an alpha root y, He_k(y^p)=0 and He_k'(y^p)!=0, so F' is nonzero and has valuation m+D_k. At r=0 use G-prime directly.

For odd r use the exact identity

    R=XF'-F
     =(XA'-A)G_k+X A G_k'
       -u_(kp)(X B' V_k+X B V_k'-B V_k).

Multiplying a derivative by X cannot decrease a coefficientwise scaled valuation. Its main term X A G_k' has normalization t^m rho² N_k and residual c a_r Y² He_k'(Y^p). The term (XA'-A)G has gap alpha-1/2; the entire joining term has gap h+1-2alpha=(p-3)/2+1/p>0. At an alpha root R=XF', so F' is nonzero with valuation m+D_k+alpha.

## 5. The remaining roots, all k and r parities

If k even and r even, none remain.

If k even and r odd, G-t is C_k and V-t is proportional to S. F(tY)/t^(m+M_k+1) -> a_r C_k Y; the joining gap is h. Its simple residual zero lifts to exact X=0, with derivative valuation m+M_k=m+D_k+1/2.

If k odd and r even, F(tY)/t^(m+M_k) -> a_r C_k S(Y), with joining gap h (or no joining term at r=0). Its p simple roots lift: p-1 have valuation 1 and one is exact 0, all with derivative valuation m+D_k.

If k odd and r odd, F(tY)/t^(m+M_k+1) -> a_r C_k Y S(Y). The joining gap is h-1=(p-3)/2>0. Its p-1 nonzero simple roots lift with valuation 1 and derivative valuation m+D_k+1. The remaining double zero is not Hensel-lifted here.

For this last case choose sigma²=t^((p+1)/2), gamma=v(sigma)=(p+1)/4>1, and W_k=p+L_k. The G-t coefficient bound proves that at beta>1 G_k is dominated by its linear coefficient C_k c t^(M_k-1)X. V_k stays the constant d C_(k-1)t^L_k. Since W_k-D_k=(p+1)/2=2gamma,

 F(sigma Y)/t^(m+W_k)
   -> C_k c a_r Y² + k d C_(k-1)b_r
    = k C_(k-1)(c a_r Y²+d b_r).

This quadratic has two distinct nonzero roots in odd characteristic, since every displayed factor is a unit. They lift to two distinct roots of valuation gamma and derivative valuation m+D_k+gamma. The group counts now exhaust n in every parity case.

## 6. Ordinary discriminant, original Gaussian polynomial, and scope

The sum of the ordinary derivative valuations is

 v(Disc_X P_(kp+r))
 = kp[kp-(k+1)/2] + kp r + r(r-1)/2
   + epsilon (p-1)(k+eta/2).

For k=0 the accepted b<p Hermite proof gives r(r-1)/2 and the same displayed expression. For k=3 this specializes to the accepted fourth-block formula exactly. No claim is made that Disc_z H has the same valuation.

Actual normalization H_n(v²;q)=v^n P_n(v+v^(-1);q), H_n(0)=1, and P_n(±2) units transfer squarefreeness through the two unramified maps. All original denominators product_(j=1)^a(1-q^j), a<n, are nonzero under n<p^s. Consecutive P are coprime by recurrence propagation. The ordinary-square diagonal CD identity therefore gives nonzero kernel P_n'(xi)P_(n-1)(xi)/w_(n-1) at each root, with algebraic, not absolute-value, squares.

The resulting theorem is 0<=b<min(p²,p^s) for every odd prime p. The proof above handles p>=5 and s>=2; s=1 is the accepted b<p range, and p=3/b<9 is already within accepted coverage. Existing p=3 degrees 9,10,11 below root order and all other independently accepted named cases remain accepted beyond this theorem's displayed range. No k=p statement is inferred: He_p(Z)=Z^p is inseparable in residue characteristic p, and derivative He_p' vanishes. No odd-composite blanket result, all-A owner closure, OPEN58 paired-support resolution, OPEN53 endpoint resolution, cost or novelty claim follows.


## 7. The next boundary and preserved original obligations

The arbitrary-subset alpha and derivative expansions still identify the method boundary at k=p when b=p² is below the root order (s>=3). In residue characteristic p,

    He_p(Z)=Z^p,
    He_p(Y^p)=Y^(p²),
    He_p'(Z)=0.

The normalized ordinary derivative residual therefore vanishes and the nonzero alpha-cluster mechanism is no longer available. This is a precise failure of the present separation argument, not evidence that the characteristic-zero polynomial has a repeated root. Every separately accepted case beyond the displayed two-digit range remains accepted; no already certified p=3 case is reopened.

The unresolved ordinary-squarefreeness gate remains outside all accepted ranges, including later residual degrees at higher prime-power orders and remaining odd-composite orders. Existing local/all-A formulas may only be composed where all independent hypotheses hold. This packet changes neither those formulas nor their signs or normalization. OPEN58 four-channel characteristic-two paired support and OPEN53 endpoints remain independent and open. Actual-degree reversal, both inverse-orbit types, exact lifted order, unit-denominator, all-m certificate and actual-family counterexample requirements are unchanged. No even-order, positive-characteristic, conditioning, FFT-count, runtime, or worldwide novelty conclusion follows. F020 remains open at priority 58, with F023 its alias.

## 8. Fresh exact controls and reproducibility

check_exact.py is newly written standard-library code. For each tested prime it reconstructs every P_b, 0<=b<p², using the original recurrence in the exact integer ring Z[q]/Phi_(p²)(q). Multiplication by q^j is a cyclic shift modulo q^(p²)-1 followed by the exact monic Phi reduction. It then substitutes q=1+t into the degree<e representative, e=phi(p²). For a nonzero coefficient polynomial sum a_j t^j of degree<e, the candidate values e v_p(a_j)+j are distinct modulo e. Its smallest value is therefore the exact actual-field valuation, with leading unit (a_j/p^v_p(a_j))(-1)^v_p(a_j), since p/t^e reduces to -1. No F_p truncation is used to ignore mixed-characteristic terms near the top of the range.

The checker verifies all outer, target alpha, whole-block ordinary-derivative, t-scale, short-block, and central residuals in their stated ranges; checks every joining-subset bound for the tested k; and independently sums the four root-group derivative ledgers to (D). It does not numerically solve roots and does not use old research code. The exact finite tests check transcription only. The unlimited p,s,k,r assertion is the coefficientwise proof in Sections 1-6, whose strict gaps h, alpha-1/2 and (p-3)/2+1/p do not degrade as k grows.

The completed run tests p=5,7,11,13,17 and passes 287,945 assertions. EXACT_CHECKS.json and check_exact.log retain every tested degree, exact valuations and control counts. verify_sources.py rechecks every retained source hash. RUN_LOG.md records the fresh commands and evidence separation; MANIFEST.json freezes the completed candidate packet. Independent acceptance must bind the final report and manifest, and is not assumed by this author report.
