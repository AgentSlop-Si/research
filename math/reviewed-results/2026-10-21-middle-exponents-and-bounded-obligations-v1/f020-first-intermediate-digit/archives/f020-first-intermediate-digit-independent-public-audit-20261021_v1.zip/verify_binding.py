"""Independent stdlib archive inventory checker; no archive program is executed."""
import hashlib,io,json,posixpath,stat,zipfile

def sha(data): return hashlib.sha256(data).hexdigest()
def require(ok,why):
    if not ok: raise ValueError(why)
def unique_object(pairs):
    d={}
    for k,v in pairs:
        require(k not in d,'duplicate JSON key')
        d[k]=v
    return d
def parse(data): return json.loads(data,object_pairs_hook=unique_object)
def safe_name(name):
    require(isinstance(name,str) and bool(name),'empty member name')
    require('\\' not in name and '\x00' not in name,'ambiguous archive name')
    require(not name.startswith('/') and posixpath.normpath(name)==name,'unsafe archive name')
    require(all(s not in ('','..','.') for s in name.split('/')),'unsafe archive path')
    require(':' not in name.split('/')[0],'drive archive path')
    return name

def read_zip(data):
    files={};names=set()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        require(not z.comment,'unexpected archive comment')
        infos=z.infolist()
        all_names=[i.filename for i in infos]
        if 'MANIFEST.json' in all_names: root=''
        else:
            roots=[n[:-len('/MANIFEST.json')] for n in all_names if n.endswith('/MANIFEST.json') and n.count('/')==1]
            require(len(roots)==1,'missing or ambiguous archive root');root=roots[0]
        for info in infos:
            require(not info.is_dir(),'directory entries are not accepted in frozen inventory')
            safe_name(info.filename)
            require(info.filename not in names,'duplicate ZIP member');names.add(info.filename)
            require(not info.flag_bits&1,'encrypted ZIP member')
            mode=info.external_attr>>16
            require(stat.S_IFMT(mode) in (0,stat.S_IFREG),'nonregular ZIP member')
            if root:
                prefix,sep,member=info.filename.partition('/')
                require(bool(sep) and prefix==root,'multiple archive roots')
            else: member=info.filename
            content=z.read(info)
            require(len(content)==info.file_size,'ZIP member size mismatch')
            files[member]=content
    require(bool(files),'empty ZIP')
    return root,files

def validate_inventory(files,pin):
    require('MANIFEST.json' in files and 'SEAL.json' in files,'missing active manifest or seal')
    require(sha(files['MANIFEST.json'])==pin,'active manifest pin mismatch')
    manifest=parse(files['MANIFEST.json']);seal=parse(files['SEAL.json'])
    require(seal['manifest_sha256']==pin,'seal does not bind active manifest')
    if 'total_file_count' in seal: require(seal['total_file_count']==len(files),'seal total count mismatch')
    if 'payload_file_count' in seal: require(seal['payload_file_count']==len(files)-2,'seal payload count mismatch')
    inventory=manifest['files']
    if isinstance(inventory,list):
        entries={}
        for row in inventory:
            name=row['path'];require(name not in entries,'duplicate inventory path');entries[name]=row
    else:
        require(isinstance(inventory,dict),'invalid inventory type');entries=inventory
    require(set(files)==set(entries)|{'MANIFEST.json','SEAL.json'},'complete inventory mismatch')
    require(not ({'MANIFEST.json','SEAL.json'}&set(entries)),'circular active inventory')
    for name,row in entries.items():
        safe_name(name)
        require(isinstance(row['bytes'],int) and row['bytes']>=0,'invalid declared byte length')
        require(len(files[name])==row['bytes'],'member byte count mismatch: '+name)
        require(sha(files[name])==row['sha256'],'member hash mismatch: '+name)
    return {'listed_members':len(entries),'all_members':len(files),'manifest_sha256':pin}

def check_archive(data,pin,archive_sha=None,archive_bytes=None):
    if archive_sha is not None:require(sha(data)==archive_sha,'ZIP SHA-256 mismatch')
    if archive_bytes is not None:require(len(data)==archive_bytes,'ZIP byte count mismatch')
    root,files=read_zip(data)
    result=validate_inventory(files,pin)
    result.update({'archive_root':root,'archive_bytes':len(data),'archive_sha256':sha(data)})
    return result,files


def main():
    import argparse
    from pathlib import Path
    parser=argparse.ArgumentParser(description='Verify this detached audit and its exact accepted main archive; execute no supplied archive code.')
    parser.add_argument('main_zip')
    parser.add_argument('--audit-manifest-sha256',required=True,help='Audit manifest digest from a separately trusted delivery record.')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    local={}
    for path in root.rglob('*'):
        require(not path.is_symlink(),'symlink in detached audit')
        if path.is_file():local[path.relative_to(root).as_posix()]=path.read_bytes()
    audit=validate_inventory(local,args.audit_manifest_sha256)
    binding=parse(local['MAIN_BINDING.json'])
    archive=binding['archive']
    result,files=check_archive(Path(args.main_zip).read_bytes(),binding['active_manifest']['sha256'],archive['sha256'],archive['bytes'])
    require(len(files['MANIFEST.json'])==binding['active_manifest']['bytes'],'main manifest byte count differs')
    require(len(files['SEAL.json'])==binding['active_seal']['bytes'] and sha(files['SEAL.json'])==binding['active_seal']['sha256'],'main seal differs')
    require(len(files)==binding['main_total_file_count'],'main total inventory differs')
    print(json.dumps({'status':'PASS','detached_audit':audit,'accepted_main':result},sort_keys=True,indent=2))
if __name__=='__main__': main()
