# Independent review: projective row-consistency graph gate

10 October 2026 UTC. Verdict: accepted as a polynomial-size necessary gate for a selected two-Green row-direction subsystem. The algebraic-closure decision, base-field distinction, finite-domain handling, singular-boundary continuation and extraction ledger are correctly scoped. A pass does not supply column directions, supported-entry scales, legal Green weights or a Fourier factorization.

## Exact reduction

For fixed branch support patterns, Q0 B Q1=Q0+Q1 gives homogeneous off-support equations. Eliminating each shared nonzero column pair yields bilinear row-direction equations u_k^T L_e u_i=0. Their coefficients are degree-two polynomials in eight target entries. The formula is division-free and keeps zero weights and singular target subblocks. Independently expanding it gives det(L_e)=det(M_i)det(M_k), agreeing with the constructor.

If L_e has rank two, J L_e with J=[[0,1],[-1,0]] carries u_i to u_k projectively and is invertible. Rank one gives exactly a disjunction of two projective kernel lines; rank zero imposes nothing. Treating rank-one transitions as invertible maps, or treating their determinant as an automatic rejection, would be invalid. The report avoids both errors.

A spanning forest of all invertible edges represents each direction as T_i z_C, with one projective variable per connected component. Substitution of every internal edge yields a homogeneous binary quadratic q_e(z_C), including identically zero polynomials. A return map R=[[a,b],[c,d]] gives c x^2+(d-a)xy-b y^2. Infinity is the ordinary point (0,1), tested by the y^2 coefficient; there is no affine-coordinate division.

A component's intersection domain is all P1, an at-most-two-point set, or empty over an algebraic closure. If empty, take one nonzero quadratic and one further equation excluding each of its at most two distinct projective roots. This proves an at-most-three-quadratic rejection certificate. Repeated roots need no extra multiplicity condition because existence asks for a point. The bound is tight: xy, x(x-y), y(x-y) have pairwise common projective roots but no common root of all three. Our exact controls verify this in characteristics two, three, five and seven. Consequently pairwise common-eigenline or commutator checks alone are incomplete; the joint quadratic test is needed.

## Component domains and 2-SAT

Every intercomponent edge has rank at most one, hence gives a positive equality clause (z_C=alpha) OR (z_D=beta), with distinguished points computed over the base field. Deduplicate equal projective lines including infinity. Equality flags for different points of one component must be at most one true. Points outside the component's common-root domain are forbidden. If a restricted domain is exhausted by named permitted points, it has at most two distinct points, so its at-least-one clause is a valid unit or two-literal clause.

If a restricted domain has an unnamed allowed point, an all-false equality assignment is realized by that point. For an unrestricted component over a finite field, all projective points might be named. The report correctly repairs an all-false assignment by choosing any point and turning at most one flag true. This cannot break positive edge clauses or within-component at-most-one clauses, since the component previously had no true flag. There are no negative domain restrictions in an unrestricted component. Thus no large at-least-one clause is needed.

A slightly broader equivalent implementation can omit the finite restricted-domain at-least-one clauses too, then repair any all-false component by choosing an allowed point. Provided the only negative clauses are at-most-one and forbidding genuinely disallowed points, the same monotonicity argument works. Our independent implementation checks both versions against exhaustive direction assignments; this observation does not weaken the report's stricter valid encoding.

The 2-SAT proof establishes exact existence for the selected projective subsystem over the specified domain. It must not be confused with a complete two-Green representation decision, because elimination of the original column variables discards compatibility information and the supported-entry equations remain unsolved.

## Algebraic closure, roots and complexity

For a restricted component, compute the gcd of nonzero q_e(1,t) and handle infinity separately. A nonconstant gcd has an algebraic-closure root; this does not imply a base-field root. Named permitted finite lines exhaust the closure domain exactly when that gcd divides the square of their linear-factor product, with infinity checked separately. Degree at most two makes the multiplicity-two exponent sufficient. No quadratic-root extraction is required for a rejection-only closure decision. Our controls include repeated roots in characteristic two, constant chart polynomials with an infinity root, an empty domain, and t^2-7 over F241, which has two closure roots and no base-field roots.

A base-field acceptance/witness requires a separate certified degree-two root test and, when needed, extension representation or root construction. Those costs are explicitly outside the unqualified constant field-operation count. The report correctly avoids dividing by two or assuming a quadratic formula works in characteristic two.

For M selected equations, extraction reads O(M) target entries after O(N) support/inverse-permutation preparation. All triples can be O(N^3); there is no hidden O(N) all-equations gate. Rank tests, guarded two-by-two inversions, forest propagation and constant-degree gcd computations use O(N+M) field/graph work. Naive exact point deduplication and pairwise at-most-one clauses cost O(M^2). Thus the conservative bound S_B+O(N+M E_B+M^2), plus field-root/representation costs, is justified. This is a verification bound in the field-operation/graph model, not a bit bound or Fourier-application bound. For a random-access chirp target, root-power tables and the Gauss/chirp recurrence can support the claimed O(N) setup and O(1) entry access in the stated arithmetic/indexing model.

## Singular endpoint masks

The full gate's endpoint-boundary extension is stronger than merely retaining nonzero homography guards. Perturb zero endpoint scales by a formal epsilon while retaining legal Green denominators and fixed endpoint permutations. For epsilon nonzero the branch inverses exist and satisfy all cleared bilinear equations. Normalize each nonzero rational row pair independently by its minimum epsilon valuation so both entries are regular and at least one has nonzero constant term. Separate homogeneity in each row preserves every equation. Specialization gives nonzero projective row directions solving the target subsystem, even when an invertible transition drops rank in the limit.

This proves necessity for singular endpoint masks without assuming any target transition determinant remains nonzero. It does not extend to singular Green denominators, which are not legal resolvents, or to changing the fixed endpoint permutations. The argument is exact algebraic specialization, not a numerical limit claim.

## Independent evidence and replay

The newly authored standard-library solver agrees with exhaustive P1 assignments in 432 bounded finite-field graph controls across fields of size two, three and five. These include rank-two forests, multiple equations, singular transitions, zero constraints, empty domains and projective infinity. Both finite-domain clause conventions are tested. Seven explicit gcd/domain profiles check the closure/base-field distinction and multiplicities; four fields verify the tight three-quadratic example.

The general routine accepts the N3 extracted graph, which is vacuous at those supports; the previously sealed full-entry construction supplies the actual positive certificate. It rejects the N5 target directly from independently extracted target entries. The supplied N5 Bezout identity using q1=(113,40,220), q2=(207,140,92) and multipliers (169+215t),(108+146t) is independently verified to equal one modulo241; both quadratics also reject infinity. Eight genuine two-Green target controls, including four zero-edge cases and three singular-endpoint cases, pass the general gate.

The source report snapshot, exact deterministic results, fresh verifier, isolated replay and checksums are included. No constructor or uploaded program was executed or imported. Earlier seals are unchanged.
