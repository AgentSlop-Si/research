# ALG-009: remove the linear-specialized-gcd restriction

Candidate for independent review, 23 October 2026. No external publication or
Sheet update was performed by the author.

The new theorem and paid executor recover every admissible input with the
original nonzero padded resultant, using at most three raw-coordinate ratios
per subgroup shift, at most 45 shifts and at most 135 complete certificate
attempts. The linear-gcd hypothesis is removed. A verified N=16 witness is
rejected by every old linear-gcd candidate and accepted by the new gate; its
explicit original-input Green lift is included.

This is selector-level coverage only. Both strict-selector witnesses are already accepted
by the earlier Phase19 ratio branch of the full hybrid. Raw-ratio recovery
at a proposed shift is also an existing project ingredient. See PROOF.md
Section 8 for the explicit predecessor comparison; no net-hybrid coverage
or speed improvement is established.

Read PROOF.md, OPERATION_LEDGER.md, and SCIENTIFIC_RESULT.json first. The
primary strict witness is STRICT_EXTENSION_WITNESS_N16.json. The smaller
N=8 witness is supplementary. Historical sources are text evidence only.

New executable files:

- paid_executor.py: capped, metered exact raw-r executor, with an optional
  explicitly O(N^2) direct fallback and no extra roots.
- exact_controls.py: separately authored small polynomial/reference controls
  and initial N=8 witness search; never imports historical programs.
- run_executor_controls.py: 88 new-executor controls, including N=16 strict
  witness, noncoprime nonresonance, a paid single pole, zero-resultant cases,
  generic rejected inputs, unchanged-eight-probe adversary, and exact
  original-input Green lifts. All 1,632 output coordinates match the direct
  reference. Three invalid-root rejections are checked separately.

Run from this directory: python run_executor_controls.py

This executes only the newly authored files. It does not validate or rerun
the historical detector, Green engine, hybrid, fallback, or benchmark.
Reference and dense input-generation work is excluded from fast-path meters,
not hidden in the claimed executable runtime. See CONTROL_RUN_HISTORY.json
for the corrected control-setup failure before the final passing run.

Remaining: zero-resultant coverage; historical source execution and literal
ledger; the early-hybrid small-length guard; external theorem matching and
priority. Keep ALG-009 TO RESEARCH at priority 42. No discovery-count, novelty,
whole-owner closure, bit/float stability, or FFT speed claim is made.
