# Hero #1 — Phase 20: certified blind binomial / two-defect Fourier reconstruction

**Date:** October 10, 2026  
**Status:** New project-specific exact finite-field algorithm with explicit algebraic nondegeneracy hypotheses and a correct FFT fallback. The general exact `o(N log N)` FFT problem is **not solved**. No worldwide priority or numerical-stability claim.

## 1. Operators and field model

Fix a prime field `F_p`, `p>55`, `char(F_p)` not dividing `N`, and a supplied primitive `N`th root `omega`. Let

- `(S r)_j = r_(j-1 mod N)`;
- `(F_N r)_k = sum_j r_j omega^(kj)` (unnormalized);
- `D = diag(1,omega,...,omega^(N-1))`.

The project preserves the previously verified noncommuting Green identity

`L=7I+2S+D`, `P=7I+S+2D^(-1)`, `LF_N=F_NP`.

We assume the specific Green matrices are invertible (checked in the implementation). Given `x`, the residual `r=Px` and recovery `y=L^(-1)F_Nr` cost `O(N)` field arithmetic after `O(N)` setup. All input data are arbitrary until a certificate accepts a structured branch.

## 2. Main theorem: blind recovery of a binomial with two impulse defects

**Theorem (Hankel-resultant gate).** Let `N>=8`. Suppose there exist **unknown** `1<=delta<N`, `alpha !=0` and a defect vector `h` with at most two nonzero coordinates such that

`h=(I-alpha S^delta)r`.

Define eight directly computed Fourier samples `R_k=(F_Nr)_k`, `k=0,...,7`. Write `w=omega^delta` and

`Y_k(alpha,w)=R_k(1-alpha*w^k)`.

For `u=0,1`, define two polynomials in `alpha` and `w`:

`P_u(alpha,w)=det( Y_(u+i+j)(alpha,w) )_(0<=i,j<=2)`.

Treating both polynomials as cubics in `alpha` (allowing leading coefficients to be zero at special `w`), form their six-by-six Sylvester determinant

`T(w)=Res_alpha(P_0,P_1)`.

Then:

1. **Necessary condition:** `T(omega^delta)=0` at every valid true shift. This holds even if the binomial is resonant.
2. **Fixed degree bound:** `deg_w T <= 45`, independently of `N`. In the non-identically-zero case there are at most 45 candidate shifts among all `N` roots of unity.
3. **Constructive sufficiency with a nondegeneracy hypothesis:** If `T` is nonzero and the polynomial gcd `gcd_alpha(P_0(alpha,omega^delta),P_1(alpha,omega^delta))` has degree one, recover `alpha` by the sole linear root; checking all `N` entries of `(I-alpha S^delta)r` certifies a valid at-most-two-defect relation. A different earlier candidate is also safe if its full certificate passes.
4. **Exact output:** from the certified two impulses, compute `F_Nh` as at most two geometric streams. For any nonresonant frequency `k`, set

   `R_k=(F_Nh)_k / (1-alpha*omega^(k*delta))`.

   If the denominator has one zero and `gcd(delta,N)=1`, compute that `R_k` by a single `O(N)` direct Fourier dot product. The current fast branch declines to handle a larger resonant set; fallback is exact.
5. **Complexity:** with a supplied primitive root and the stated finite-field arithmetic model, the discovery and exact transform take `O(N)` field operations for the certified, nondegenerate input family. On arbitrary inputs the selector is **always correct** but has `O(N log N)` worst-case field arithmetic via a fully charged Bluestein fallback.

**Proof of (1):** The diagonalization `F_NS^delta=D^delta F_N` gives `Y_k=(F_Nh)_k`. Since `h` has at most two nonzero coordinates, `Y_k=c_1 lambda_1^k+c_2 lambda_2^k`, with `lambda_i` among the `N`th roots. Every 3x3 Hankel matrix of this sequence has rank at most two; hence both determinants vanish at the true `(alpha,w)`, forcing the resultant to vanish.

**Proof of (2):** In a 3x3 determinant term, its three selected Fourier indices `u+i+sigma(i)` sum to `3u+6`. Expanding `Y_k=R_k-alpha R_k w^k` shows `deg_alpha P_u<=3` and `deg_w P_u<=3u+6`, namely 6 and 9. The 6x6 Sylvester determinant is homogeneous of degree three in the coefficients of each cubic, so every determinant term has degree at most `3*6+3*9=45` in `w`. A nonzero polynomial of degree at most 45 has at most 45 roots in a field. `omega^delta` are distinct because `omega` is primitive.

**Proof of (3-5):** Obtain `R_0..R_7` in 8 direct `O(N)` dot products. The complete polynomial `T` is recovered exactly by evaluations at 46 distinct field elements `w=0,...,45` and Newton interpolation, taking an `N`-independent number of operations (requires `p>45`). The code independently checks three further evaluation points. Evaluate the polynomial at all `omega^delta` with a charged polynomial-of-fixed-degree/sparse-input Fourier evaluator (`O(N)` because its input has at most 46 terms), or by 46 direct phase streams. Each candidate root has a constant-degree polynomial gcd in `alpha`; its linear factor gives `alpha`. At most 45 roots require potentially complete `O(N)` defect scans. Full exact support verification rules out *all* false acceptances, even on adversarial inputs. A two-sparse `F_Nh` and one full spectral division take `O(N)` operations; a single resonant frequency uses one `O(N)` direct dot. If any stage fails or there is no certified candidate, the ordinary exact FFT fallback returns the correct `F_Nr`, followed by the `O(N)` Green solve. QED.

**Nondegeneracy is real:** The true `alpha` is always *a* common root, but it need not be the unique root of the two determinants. If the gcd is higher-degree or `T` vanishes identically, this fast gate makes **no completeness claim** and correctly falls back. The small-field audit has 56 such correct fallback instances among 2,240 structured cases.

## 3. Exact per-input algebraic simplification

After reconstructing `T`, the implementation divides out only its exactly checked factors `w` and `w-1`. These cannot vanish for trial nontrivial shift roots `w=omega^delta`, `1<=delta<N`. In all tested generic samples, `T` had degree 32 and factored as `w^13 (w-1)^9 U(w)`, with `U` a palindromic polynomial of degree 10. This is an **observed pattern**, *not* a universally established theorem. The implemented result does **not** depend on it: division is performed only when verified on that exact input, and the correctness/complexity theorem uses the conservative degree-45 bound.

## 4. Eight Fourier samples and a sparse-rational uniqueness lemma

**Lemma.** Suppose `H_1/Q_1` and `H_2/Q_2` each have numerator support at most `K` and denominator support at most `s`, with all sampled denominators nonzero. If `N>=2Ks` and the two rational functions agree at `2Ks` consecutive powers `omega^k`, then they agree at *all* `N`th roots where both are defined.

**Proof.** `H_1 Q_2-H_2 Q_1` has at most `2Ks` monomials after collision cancellation. Its evaluations at `2Ks` consecutive powers vanish. Combine terms having the same exponent modulo `N`; the resulting expression is a sum of at most `2Ks` exponentials `c_j (omega^(a_j))^k` with distinct nonzero nodes. Its first `t<=2Ks` values form a Vandermonde system with nonzero determinant. Thus all coefficients vanish and the cross-product is zero throughout the root subgroup. QED.

For binomial denominators (`s=2`) and two-term numerators (`K=2`), eight probes therefore *uniquely identify an existing sparse-rational function*. They are **not**, by themselves, a sound acceptance certificate for arbitrary `r`: a dense arbitrary vector can match a valid rational function at eight samples and differ later. The implementation always performs the complete time-domain defect check. `test_unmodified_eight_probes_adversary` constructs an explicit perturbation preserving the first eight samples, verifies rejection, and checks the fallback against the independent DFT.

## 5. Strict limitations

- **Not a general FFT improvement.** For fixed `delta` and defect support positions, nonresonant residuals have only three continuous parameters (`alpha` and two impulse amplitudes) over the complex numbers; a finite union of such families is measure-zero in `C^N` for `N>3`. Adaptively searching these families does not establish worst-case sub-`N log N` complexity.
- **No bit/float theorem.** Arithmetic counts use unit-cost field operations including inverses. The chosen field and primitive roots are given; their bit construction, finite-word memory and numerical conditioning are not established. Resultant-root detection, small polynomial gcds and spectral divisions can be extremely ill-conditioned over floating point near resonance. See `PRECISION.md`.
- **No unsupported uniqueness claim.** The algorithm discovers some valid annihilator, not necessarily a unique physical graph factorization. A resonance is explicitly repaired or declined, never divided through zero.
- **Prior art.** Hankel rank/Prony, Sylvester resultants, sparse rational interpolation, sparse Fourier evaluation and Bluestein all predate this project; this is their specialized project implementation and charged integration, not a priority claim for the foundational techniques.

## 6. Reproduction

- `resultant_gate.py`: exact polynomial interpolation, Sylvester determinant, subgroup root evaluation, complete support test and Green recovery.
- `blind_sparse_rational.py`: independent direct shift-loop recovery (no resultant interpolation), useful as a cross-check.
- `hybrid_phase20.py`: previous Phase19 project detectors with one shared eight-probe bank and the new Phase20 fall-through gate.
- `test_phase20.py`: 9 focused exact tests including the Phase19 resonant counterexample and unchanged-eight-probe attack.
- `exact_basis_audit.py`: 53,778 Fourier outputs compared with independent direct DFT across 807 two-defect inputs.
- `exhaustive_small_gate.py`: 2,240 fixed-parameter GF(97)^8 inputs, 17,920 direct-DFT output checks; 56 correct fallbacks.
- `benchmark_phase20.py`: N=4096 exact field-operation ledger with baseline and hybrid comparison.
- Exact earlier Phase19 work is included as an unchanged ZIP.
