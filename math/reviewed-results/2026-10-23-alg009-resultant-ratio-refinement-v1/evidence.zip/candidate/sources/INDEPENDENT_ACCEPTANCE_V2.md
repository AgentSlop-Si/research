# ALG-009 fixed-root-grid comparison: independent acceptance of version 2

21 October 2026 UTC

## Verdict

ACCEPT version 2 as a bounded mathematical primary-source comparison, invalid-adapter analysis, and conditional charged-wrapper statement. Both substantive qualifications required by the version-1 addendum are now present. No further textual repair is required for this bounded acceptance.

This verdict is bound to the comparison report SHA-256 521efc5a7291d062862246ed16d5e4448e75a13ac32e810b10e9665051bfbedf, source provenance SHA-256 999c7421d011c8eeee46fdf59fa27254636a6f900193566efa5305459b83de94, and scalar witness SHA-256 5648e336fd7ac18819d39b38c160d16db5c185b1563ad803102d616745bd46d8. The complete six-member author archive is independently verified at SHA-256 af682b6dc6f331273dd77aa028efac37543dec955d006e42d804cd67b42d638b (15,275 bytes). Its CRC, manifest payloads and privacy checks pass. Exact byte counts and package bindings appear in REVIEW_BINDING.json. The copies under comparison/ are byte-identical to those reviewed files.

Accepted here does not mean that a complete external recovery theorem or cost-preserving reduction has been found. The owner remains open. Source execution, a literal complete operation ledger, the early-hybrid size safeguard, valid full-engine domains and broader historical attribution are separate unfinished obligations.

## Verified corrections

1. The adapter now distinguishes universal output soundness from pre-fallback complexity and promised-family fast recovery. It explicitly observes that a procedure returning no proposals satisfies the budgets while always falling back.
2. A fast-recovery reduction now requires a proved candidate-coverage guarantee on every promised input: an admissible proposal must pass all guards and the complete raw certificate within the same aggregate budgets. Any probabilistic success guarantee must be stated and proved within those capped budgets. Fallback keeps output correctness independent of fast-path success.
3. The m,c,B budgets are aggregate per input, not per attempt. They include setup, randomization, parameter recovery, every black-box query, failed attempts and restarts. Uncapped or merely expected retry costs cannot replace the all-path bound.
4. The 2020 comparison now includes actual-degree knowledge and the extra 2(D+1) evaluations needed when only an upper bound D is supplied, together with query-formation and univariate-interpolation setup.
5. The current one-or-two-defect and at-most-one-pole admission is explicitly preserved. The report still does not claim either named paper satisfies the full relation-interface and coverage contract.

These changes remove the ambiguity identified in version 1 without changing the accepted algebraic target or enlarging the source implementation's accepted family.

## Substantive findings retained

The reviewed comparison's precise mechanism-level overlap with Kaltofen–Nehring Section 6 and its qualified full-theorem nonmatch remain supported. The source uses a total-sparsity 2τ² probe count; the shared mechanism is not a verbatim eight-probe theorem. Its reconstruction assumptions, chosen modulus structure and unproved Sp2 guarantee cannot be transferred for free. [Primary source](https://kaltofen.math.ncsu.edu/bibliography/11/KaNe11.pdf)

The van der Hoeven–Lecerf comparison retains the correct coprime rational-oracle interface, Monte Carlo/field-size assumptions, Theorem 2 formula, off-grid transformations and degree-dependent cost boundary. The Section 3.3 setup qualification is now carried explicitly. [Primary source](https://www.texmacs.org/joris/sparserat/sparserat.pdf)

The coefficient identity Q A−H=(z^N−1)C is correct and rules out substituting off-grid evaluations of the raw coefficient polynomial for the unknown rational oracle. The pole-kernel argument is correct: H,Q do not determine raw-input Fourier coordinates at zeros of Q, and removable continuation alone cannot supply them. Eight probes prove conditional subgroup identity between actual sparse models, not formal rational equality, arbitrary raw-data acceptance, factor uniqueness or pole coordinates.

The pre-fallback field-operation bound O(N+mN+B+cN+ZN) remains valid for the explicitly stated direct adapter. Every direct probe, proposal admission/certificate, sparse output construction and pole repair is charged, and the entire admissible fallback is added on decline. Bounded m,c,Z and B=O(N) give linear pre-fallback work; family recovery additionally needs the now-explicit coverage guarantee. The abstract degree-45 schedule is not the literal implementation ledger.

## Review method and evidence boundary

The reviewer inspected the complete original comparison, original theorem, historical audit, accepted static repair review and corrected source as text, independently opened both author-hosted primary papers, and authored independent algebra checks during the version-1 review. The reviewer then inspected the exact version-2 diff, read the complete revised report/provenance and rechecked all pinned identities. The sources' unchanged portions inherit that already completed review, not an invented new source-execution run.

The independent controls recorded in this packet passed 8,264 coefficient-level wrap identities and 8,264 exact pole-count cases, the archived GF97 scalar witness, kernel-coordinate variations and a raw-data adversary preserving eight probes. These are the same previously completed independent checks, carried byte-for-byte; they were not relabelled a second fresh run. They do not recompute resultants or gcds, establish model-example gate nondegeneracy or validate supplied code.

No supplied detector, decoder, benchmark, fallback, hybrid, test suite or other research module was imported, compiled or executed in either review. The corrected gate remains statically pinned to SHA-256 09ef37694af956394b82f55bf366e121849cbaf7f4d89caff5527aad9a142ef4. No external write was made.

Original external PDF bytes were not recovered or hashed. Primary text was inspected through PDF extraction; screenshot retrieval failed in the prior review. No external paper is redistributed.

## Lineage and disposition

Version 1 and its qualified addendum are preserved unchanged. The addendum archive SHA-256 remains 7e5b4c4b1f49cdcde40bf002b03ea00557ddc13f076dc80279b1ee4e7baeed06. Its warning about version-1 recovery wording remains valid for those exact old bytes. The present acceptance applies only to version 2 and does not retroactively turn the unmodified version 1 into an unqualified accepted report.

The version-2 provenance's review-pending sentence is preserved historical author metadata. This separate pinned review supplies its actual acceptance state.

The outcome is completed bounded comparison/review progress. It is not whole-owner closure, implementation-execution acceptance, exact operation-total certification, historical-novelty clearance, a bit/float theorem, a hardware-speed result or an unrestricted FFT improvement.
