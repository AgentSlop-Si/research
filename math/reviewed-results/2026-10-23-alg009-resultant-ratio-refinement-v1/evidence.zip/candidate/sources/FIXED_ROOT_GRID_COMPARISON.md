# Fixed root grid sparse rational comparison for ALG009

21 October 2026 UTC. Version 2. The original version is preserved unchanged.

## Finding

There is precise prior overlap for the sparse cross-product and Vandermonde uniqueness argument. This pass does not establish a prior theorem that supplies the complete ALG-009 raw-input recognizer at the same cost. Two named primary sources have specific interface, hypothesis, and cost mismatches. The analysis below also proves why two tempting adapters are invalid: evaluating the raw coefficient polynomial off the root grid, and filling resonant Fourier values by rational cancellation.

The separate execution validation and literal implementation operation ledger remain open. No supplied research program was executed or imported. The original conditional correctness result is not reopened, and no historical-novelty conclusion follows.

## Exact mathematical target

Work in a field F containing a supplied element omega of exact order N, with N invertible in F. The implemented interpolation domain additionally requires prime F = GF(p), p > 55, and N >= 8. For raw r in F^N, set

R_k = sum from j=0 to N-1 of r_j omega^(kj),

h_j = r_j - alpha r_(j-delta mod N),

H(z) = sum h_j z^j, and Q(z) = 1 - alpha z^delta.

The model has unknown 1 <= delta < N, alpha != 0, and at most two nonzero h_j. The current source accepts one or two defects, not zero. Its conditional discovery branch additionally requires a nonzero padded resultant T(w), degree at most 45, and a linear specialized gcd at a valid candidate. The complete raw defect scan is mandatory. Gate decline is not a proof that all two-defect descriptions are absent.

The target is a full finite vector R, not an abstract rational expression. At each nonpole, R_k = H(omega^k)/Q(omega^k). At a pole both H and Q vanish, and this equation imposes no value on R_k. For g = gcd(N,delta), the pole count is g if alpha^(N/g) = 1 and zero otherwise. The admitted repair budget is at most one pole. Green preprocessing and recovery are an additional O(N) wrapper only in their separately valid domain.

## Named primary source comparisons

### Kaltofen and Nehring 2011

[Supersparse Black Box Rational Function Interpolation](https://kaltofen.math.ncsu.edu/bibliography/11/KaNe11.pdf), ISSAC 2011, pp. 177–185, Sections 2, 4, 6 and 7.3.

Section 6 tests sparse cross-products on consecutive powers of a primitive root; exponent residues are combined and a full-rank Vandermonde matrix establishes the modular identity. This is the precise overlap with the eight-probe lemma, not a general Prony slogan. Recovery uses a modular-evaluation black box for a rational function over Q, a selected subgroup/prime lifting scheme, and assumptions Sp1 and Sp2. Sp2, preservation of sparsest images, is explicitly not proved to hold with high probability. Section 2.1 treats undefined values with denominator equations. Section 7.3 records a certification drawback.

ALG-009 instead supplies finite Fourier values from one given field and one fixed root grid, including finite values at hidden denominator zeros. Its nonzero resultant and linear gcd do not imply Sp1 or Sp2. Its grid is not guaranteed to admit the source's chosen subgroup ladder. The common identity argument does not transfer the recovery guarantee, raw-data certification, or paid pole values. Outcome: exact uniqueness-mechanism overlap; qualified nonmatch for the complete theorem and cost-preserving reduction.

### Van der Hoeven and Lecerf 2020

[On sparse interpolation of rational functions and gcds](https://www.texmacs.org/joris/sparserat/sparserat.pdf), inspected preliminary version dated 11 November 2020, Introduction, Section 2.2, Theorem 2 and Remark 3.

Theorem 2 assumes a coprime rational black box and a sufficiently large field. Its Monte Carlo field-operation bound is

(L + 4n + O-tilde(log^2 d))(d+2) E_F(n+1,d,s) + S_F(n+1,d,s) + O(ns log d),

Here d=d_A+d_B, s=s_A+s_B, L is black-box evaluation cost, and E_F,S_F are polynomial-interpolation evaluation and arithmetic costs. The construction uses random shifts/projective coordinates and dilations, discarding bad sequences. Section 3.3 assumes known actual degrees; from an upper bound D it first uses 2(D+1) evaluations to identify them with high probability. Query formation and univariate interpolation also belong to setup. Remark 3 retains degree-sized overhead.

ALG-009 lacks this off-grid oracle and probabilistic field-size guarantee. Its sparse pair need not be coprime; cancellation can change sparsity. Moreover d can scale with N despite four terms. Outcome: qualified nonmatch at the measurement, representation, genericity and charged-cost interfaces.

## The root grid is not a rational black box

This section gives an independent algebraic derivation rather than an additional claim attributed to either paper.

Let A_r(z) = sum from j=0 to N-1 of r_j z^j. Cyclic shifting gives the polynomial identity

Q(z) A_r(z) - H(z) = (z^N - 1) C(z),

where C(z) = -alpha sum from j=N-delta to N-1 of r_j z^(j+delta-N).

Thus Q A_r equals H in the quotient ring F[z]/(z^N-1), not generally in F[z]. Off-grid evaluation of A_r is available by Horner evaluation, but it is generally the wrong rational function. Randomly dilating or shifting the query points cannot be justified by the Fourier promise alone.

A concrete nondegenerate archived witness makes the failure explicit. Take N=8, F=GF(97), omega=64, delta=2, alpha=64, and

r=(1,50,64,96,22,33,50,75).

Its accepted historical audit records h=(2,3,0,0,0,0,0,0), nonzero resultant witness T(2)=95 and specialized gcd a+33. Here

(1-64z^2) A_r(z) - (2+3z) = (z^8-1)(1+50z).

At the nonzero off-grid point z=2, A_r(2)=7 but H(2)/Q(2)=8/36=11 in GF(97). The difference after multiplying by Q is 50, exactly the wrap term. These scalar values were freshly checked without importing or executing any supplied research module. The archived resultant and gcd claims are attributed historical evidence, not rerun computations.

Consequently a reduction that simply passes A_r to an unrestricted sparse-rational interpolator is false, even on this recorded nondegenerate zero-pole instance. This disproves that adapter, not the existence of every possible reduction.

## Pole values are independent data

Fourier diagonalization gives F h = diag(Q(omega^k)) F r. Since the Fourier matrix is invertible, the kernel of I-alpha S^delta has dimension equal to the pole count Z. For each pole k, adding a scalar multiple of the inverse Fourier character j -> N^(-1) omega^(-kj) to r leaves h unchanged and changes only R_k.

It follows that H and Q, even known exactly, do not determine the pole coordinates of the required vector. Cancelling common factors and taking a removable continuation supplies a value of a rational function, not the missing input-dependent Fourier datum.

For example, let delta=1, alpha=1, and r=e_0+t(1,...,1). Then h=e_0-e_1 for every t. The rational quotient (1-z)/(1-z) is identically 1 after cancellation, but R_0=1+Nt and R_k=1 for k!=0. This is a transparent model-level example, not a claim of nondegeneracy for the resultant gate.

Likewise (1-z^m)/(1-z)=1+...+z^(m-1) shows that cancelling a common factor of a two-term numerator and binomial denominator can make the reduced numerator have m terms. This is a representation obstruction, not a claimed new accepted fast-family example. More generally, any resonant certificate has a common zero of H and Q on the grid. A reduction must preserve the original sparse relation and separately recover the lost kernel data, or explicitly pay for a different representation and its pole repair.

## What eight probes establish and what they do not

Suppose two actual sparse pairs (H_1,Q_1) and (H_2,Q_2) have numerator support at most K and denominator support at most s. Their cross-product has at most 2Ks terms before reduction modulo z^N-1. Combine terms with equal exponent residues. If its evaluations vanish at 2Ks consecutive powers of omega and N >= 2Ks, the resulting t <= 2Ks distinct nonzero nodes form an invertible t-by-t Vandermonde system. All reduced coefficients vanish. The cross-product is therefore zero on the full grid.

For K=s=2, eight samples suffice for this conditional identity argument. Equality of ratios at those samples implies vanishing of the cross-product only when both sampled denominators are nonzero. The conclusion is equality on grid points where both ratios are defined. It is not formal rational-function equality, uniqueness of factor descriptions, or identification of pole coordinates. The Hankel necessary equations themselves remain valid at poles because they multiply, rather than divide, by Q.

Nor do the probes certify arbitrary raw data. For N>8 choose an unsampled frequency ell with Q(omega^ell)!=0. Add a nonzero inverse character at ell to r. The eight measured values are unchanged, whereas the proposed defect changes by a nonzero multiple of that character at every coordinate. Starting from a two-defect h, at least N-2 coordinates of the new defect are nonzero. Thus the proposed relation fails and the proposed output is wrong at ell. This establishes failure of the proposed candidate; it does not by itself assert that no alternative sparse description exists.

## Root admission and a valid reduction contract

The gate scans w=omega^delta for 1<=delta<N. It neither assumes that every algebraic root of T is admissible nor obtains delta by a free discrete logarithm. A replacement returning algebraic nodes must establish their membership in the supplied subgroup and recover their exponent indices. A scan of the existing N-root table costs O(N) for a fixed number of nodes and supplies both; field-extension and generic root-finding costs are not automatically free. The full raw scan obtains defect positions directly and avoids a separate Prony node-to-exponent problem.

A sound proposal-and-verification adapter is as follows. Assume an interpolation procedure works on the fixed-grid relation Q(omega^k) phi(k)=H(omega^k), allowing arbitrary finite values of phi at zeros of Q. Assume that the entire candidate procedure proposes at most c(N) binomial parameters using at most m(N) calls to phi(k)=R_k and B(N) other charged field operations. These are aggregate per-input budgets, not per-attempt budgets: m,c,B include all setup, randomization, parameter recovery, failed attempts and restarts, with every black-box query included in m and every other field operation included in B. Cap all execution paths within these budgets. Reject invalid parameters and certify each surviving proposal from every raw coordinate, retaining the source's one-or-two-defect and at-most-one-pole admission. For an accepted proposal, evaluate its certified sparse H and Q on the grid, divide at all nonpoles, and compute every admitted pole coordinate by a direct Fourier sum. Otherwise use an admissible exact fallback.

With one shared root table, its pre-fallback cost is

O(N + m(N)N + B(N) + c(N)N + ZN),

including sample formation, root admission, certificates, sparse evaluation, divisions and repairs. Integer indexing/gcd work is separately charged in the O(log N)-bit word model. Thus bounded m,c,Z and B=O(N) prove linear pre-fallback work and, with an admissible exact fallback, universal output correctness. They do not prove fast recovery of any promised family: a procedure returning no proposals satisfies these budgets but always falls back.

For a cost-preserving fast-recovery reduction on a stated family, additionally prove candidate coverage: on every input in that family, the procedure produces within those aggregate budgets at least one proposal that passes every admission condition and the full raw certificate. If coverage is probabilistic, specify and prove the claimed success probability within the same capped budgets; it is the fast-recovery probability, not an output-correctness probability. Failures remain correct through the separately charged fallback. Expected or uncapped retry costs cannot silently replace these all-path budgets. Only with this coverage guarantee does the wrapper transfer promised-family recovery and its stated success guarantee. Neither compared paper has been shown to satisfy this complete contract here.

If a proposed theorem needs m growing as log N or N, this direct adapter does not preserve the linear field bound; a better batched-probe reduction would need its own proof. This is a bound for the specified adapter, not a lower bound against all adapters.

## Complete asymptotic schedule and its boundary

For the abstract degree-45 gate, the following disjoint stages suffice. Their bounds charge performed work on both success and failure paths.

1. Build the N-root table: N-1 field products. Include O(N) admissible Green preprocessing when used. Field/root discovery is not part of the supplied-root model.
2. Form eight direct Fourier samples: at most 8N products and 8(N-1) additions, with charged reads and indexing. No spectral oracle is free.
3. Construct the two cubics, evaluate the padded resultant at 46 distinct interpolation points, interpolate, and perform any fixed additional checks: a constant amount C_alg of field work, including inverses, signs, and scaling. The bound is constant in N, not zero.
4. Evaluate T at N-1 nontrivial subgroup nodes by Horner's rule: at most 45(N-1) products and the same number of additions. This schedule uses only the existing N-root table. Literal alternative backends must pay their own setup and additional roots.
5. For each of at most 45 roots, form the specialized cubics, compute their gcd, normalize, extract alpha, and apply the remaining filters. Charge each constant-degree operation. Each resonance test uses O(log N) field products if done by powering, plus the integer gcd. Each attempted full defect scan costs at most N products and N subtractions, with all equality tests, including unsuccessful and partially abandoned scans.
6. For one certified pair, evaluate up to two geometric streams, construct every denominator, test zeros, and perform each nonzero-denominator inversion and product: O(N) field work. Seed streams from the supplied root table. Recover each of Z<=1 poles by at most N products and N-1 additions. Include O(N) admissible Green recovery when used.
7. On decline, add the entire exact fallback cost to all prior work. The historical Bluestein implementation additionally needs compatible 2N-th and convolution roots and its valid constructor domain. Its O(N log N) fallback bound is conditional on those resources, not implied by the N-th root alone.

This is an exhaustive stage-level asymptotic upper schedule, not an exact scalar count of the literal nine-module implementation. Freshly rebuilt backend roots, pruned negations, signed scaling, gcd normalization, exponentiation, factor-test sums, folded collisions, all attempts and all fallback intervals remain obligations for that separate ledger. No repaired benchmark total, running time, bit complexity, floating-point stability or general FFT improvement is claimed.

## Evidence and disposition

The exact original theorem was read from the preserved Phase20 archive: 9,788 bytes, SHA-256 b49a3863273c2c80cb211e71711d0575cd3ac96bac32f4ac293f48a77b0f7ec9. The historical independent audit was read in full: 17,292 bytes, SHA-256 4e6b45aeab8f22872d9cb6ea37cb74b2c06b55492ac53c8fa1991ac7d60678e9. The accepted static repair review is bound by 11,161 bytes, SHA-256 37e52c3a66f85aa6b6bb67fb404789d88a36444938f6becf0d0f6a57dc8d6e92. The corrected gate's verified SHA-256 remains 09ef37694af956394b82f55bf366e121849cbaf7f4d89caff5527aad9a142ef4.

The external papers were inspected through web-tool PDF text extraction. Original PDF byte streams were not recovered or hashed; no PDF hash or exact-download provenance is claimed. The HTML version of the 2020 source renders formulas as images, so the theorem formula was checked in the PDF extraction. A screenshot request was unavailable. No external paper is redistributed with this note.

The named-source outcomes and the two invalid-adapter proofs are bounded progress. An exact prior recovery theorem satisfying the fixed-grid relation contract and candidate-coverage promise, or a complete alternative cost-preserving reduction to one, has not been established in this pass. Version 2 addresses the independent version-1 addendum by separating universal soundness, pre-fallback cost and promised-family coverage, and by adding degree-discovery and aggregate setup/restart charges. The version-1 report and its qualified addendum remain unchanged; a separate hash-bound review determines acceptance of this version. No historical-priority claim follows. Keep implementation execution, literal accounting, the early hybrid length safeguard, and broader attribution open.
