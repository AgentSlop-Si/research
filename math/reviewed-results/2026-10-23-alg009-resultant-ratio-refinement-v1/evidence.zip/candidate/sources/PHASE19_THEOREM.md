# Hero #1 — Phase 19: exact blind graph and sparse-circular-inverse Fourier recovery

**Date:** 2026-10-10  
**Status:** exact finite-field algebra, independently checked executable implementations. **Not an unrestricted `o(N log N)` FFT, not a bit-complexity result, and not a floating-point stability theorem.**

## 0. Field and operator convention

Let E be a field of characteristic not dividing N, with a supplied primitive N-th root `omega`. Define the **unnormalized** DFT by

    (F_N r)[k] = sum_{j=0}^{N-1} r[j] omega^(k j).

For cyclic shift `(S r)[j]=r[(j-1) mod N]`, the exact intertwining law is `F_N S = D F_N`, with `D[k,k]=omega^k`. All vector expressions, support tests and divisions below are exact field operations. Zero tests are not noisy floating-point thresholds.

We preserve the inherited Green system:

    L = 7I + 2S + D,    P = 7I + S + 2D^(-1),
    L F_N = F_N P.

For any x, compute r=Px in O(N), compute `F_N r` by a certified route, and solve `Ly=F_N r` in O(N). Precomputed cyclic solver coefficients and N root powers are supplied/shared and cost O(N) field operations to establish once the root is given. The finite-field engine checks all needed inverses.

## 1. Theorem A: deterministic unknown one-defect shift discovery

**Theorem.** Suppose `N>=3`, `r[j] != 0` for every j, and for an *unknown* `delta` coprime with N and *unknown* `alpha != 0`,

    h = (I - alpha*S^delta) r

has **exactly one** nonzero entry. Then the delay delta, some valid alpha and the complete exact Fourier vector `F_N r` can all be obtained in O(N) field arithmetic, without a preselected delay catalog. If no such certificate is found on arbitrary input, the engine computes the ordinary exact FFT instead.

**Proof.** Put `u=delta^(-1) mod N` with `1<=u<N`, and choose the unique defect location j0. The cyclic difference equation implies

    r[j0 + t delta] = c alpha^t,    t=0,...,N-1,

with c nonzero. Because h has one nonzero entry, `alpha^N != 1`: if alpha^N=1, consistency around the entire cycle would make its single forcing impulse vanish. Write `t(j)=u(j-j0) mod N`. The ordinary adjacent ratios are

    rho_j = r[j]/r[j-1] = alpha^u                  if t(j-1)<N-u,
                              alpha^(u-N)          otherwise.

Exactly u of the N positions wrap modulo N, so the **two distinct** ratio values have multiplicities `{u,N-u}`. We discover and count these values by one scan using projective pairs `(r[j],r[j-1])`, never requiring N field inversions. Either count is u or N-u; these give at most two candidate `delta` values by modular inversion in `Z/NZ`. At the true delta, each projective edge ratio `r[j]/r[j-delta]` equals alpha except at exactly one location. Consequently, three distinct sample edges possess a strict majority equal to alpha. The full O(N) defect scan certifies the candidate. Finally, the only forcing entry h creates one geometric Fourier stream in O(N), and the denominator `1-alpha*omega^(k delta)` is never zero (else alpha^N=1). One batch inverse and the O(N) Green solve recover every coefficient exactly. QED.

A zero-defect, *coprime-shift* eigenvector also has constant ordinary adjacent ratio and is handled by candidate delta=1 with one resonant frequency repaired directly in O(N). **This does not cover noncoprime zero-defect cycles:** e.g. over GF(17), `r=(1,1,-1,-1)` is annihilated by `I+S^2`, but has no coprime-shift annihilator with <=1 defect. Phase19 safely falls back on this input.

**Verification:** hidden delays never present in Phase18's fixed bank; exhaustive oracle agreement on all `17^4` vectors (with coprime shifts and nowhere-zero model), and exact Fourier full-family basis comparisons.

## 2. Theorem B: bounded multi-defect recovery under ratio-class separation

Let the same unknown `delta` be coprime to N, `alpha!=0`, and `K=||h||_0>=1` be bounded. Along the delta-cycle, between successive defect positions `r` is a geometric progression. Therefore there are at most K geometric runs,

    r[j] = c_{sigma(t(j))} * alpha^(t(j)),

where `sigma(t)` is one of at most K segment labels. Taking an ordinary adjacent ratio gives

    rho_j = alpha^(u-N w_j) * c_{sigma(t(j))}/c_{sigma(t(j-1))},
    w_j in {0,1},       sum_j w_j = u.

Thus **at most `2K^2` distinct ratio values** can occur. Suppose the **wrap-separation condition** holds: a numerical ratio class never contains both `w=0` and `w=1` indices. Under this explicit (not universal) condition, u equals the sum of the occurrence counts of some subset of the at most `2K^2` classes. Enumerate the at most `2^(2K^2)` subsets, invert candidate u mod N, find the candidate alpha from a deterministic `2K+1`-edge majority, and fully verify every proposed graph relation. The true candidate is found, and no invalid candidate can be accepted.

**Cost:** `O(N (K^2+K*2^(2K^2))+2^(2K^2)*polylog(N))` arithmetic/word-level model operations for fixed K, plus the O(KN) sparse Fourier forcing and O(N) Green work. **For fixed K this is O(N)**; the constant is bad as K grows, and the hypothesis is essential. For K=2 there are at most eight ratio classes and at most 256 subsets. The code uses a *deduplicated subset-sum set* and early rejection of invalid full scans.

**Sharp exception:** at N=128, delta=63, alpha=omega^9 (so alpha^N=1), set `r[(t delta) mod N] = alpha^t*(3 if t<17 else 5)`. The graph defect has K=2 but wrap and nonwrap classes collide. The bounded-ratio detector fails; the exact generic fallback succeeds. This counterexample prevents a false all-K completeness claim.

## 3. Theorem C (strongest result): fully blind s-sparse circular-inverse recovery

**Theorem.** Suppose `s<=N/2`, and there exists a polynomial with *unknown* support and coefficients

    C(z) = sum_{ell=1}^{t} c_ell z^(a_ell),   1<=t<=s,

having distinct exponents `a_ell mod N`, nonzero coefficients, and satisfying

    C(S) r = e_0,     e_0=(1,0,...,0).

Then one can discover C, independently verify the identity, and compute all N exact Fourier coefficients of r in

    O(N*s + s^3)

field arithmetic, given omega and the associated N powers. No coefficient, exponent, source impulse position, or factorization of C is supplied.

**Proof (completeness).** From Fourier diagonalization,

    C(omega^k) * R_k = 1,    R_k=(F_N r)[k],

so every R_k is nonzero, and

    b_k=R_k^(-1)=sum_{ell=1}^t c_ell (omega^(a_ell))^k.

Compute only k=0,...,2s-1 using ordinary O(N)-cost Fourier dot products (`O(sN)` total), then batch-invert their nonzero values. The sequence b is a sum of t distinct, nonzero exponentials. Its length-2s prefix determines its unique minimal linear recurrence of order t (standard Prony/Berlekamp–Massey: a t-by-t Hankel minor is a Vandermonde-diagonal-Vandermonde product with nonzero determinant). Recover that recurrence in O(s^2). Its monic characteristic polynomial has the distinct roots `omega^(a_ell)`. Evaluate it at every one of the N roots of unity, at cost O(sN), obtaining the exact unknown exponents without a discrete-log oracle or general finite-field factoring. Solve the t-by-t Vandermonde coefficient system by charged O(s^3) Gaussian elimination. The recovered sparse polynomial is exactly C by uniqueness of the recurrence and interpolation.

**Proof (soundness on arbitrary input).** Independently check every coordinate of `C(S)r=e0`, by t cyclic taps per coordinate (`O(sN)`). Only an exact match is accepted. If successful, output

    R_k = 1 / C(omega^k),    k=0,...,N-1,

by t geometric streams and one batch inversion (`O(sN)`). The certificate makes every denominator nonzero. If any stage fails, use the ordinary exact FFT. The full-input selector is therefore always exact, with O(sN) discovery toll plus O(N log N) FFT fallback when it does not compress. QED.

**Important subtlety:** BM from 2s samples alone is not a correctness proof. Phase19 also tests full root-subgroup membership, interpolates amplitudes, and checks *all N convolution identity coordinates*. A deliberately corrupted signal with the **same first eight Fourier samples** as a valid 4-tap example is rejected at the final certificate (not accidentally accepted).

### 3.1 Fully unknown graph union, one impulse

Suppose for a *completely unknown* collection of m cyclic long-distance graph filters,

    Q(S) = product_{i=1}^m (I-alpha_i*S^(delta_i)),
    Q(S) r = c e_j,     c!=0,

and Q is invertible. Then

    C(S) = c^(-1) S^(-j) Q(S)

satisfies `C(S)r=e0`, and its expanded polynomial has at most `2^m` nonzero taps. Hence all unknown shifts, multipliers, source location and scale are **unnecessary** to recover the Fourier transform: with m fixed, use Theorem C at s=2^m for O(N) field arithmetic. **We recover the combined sparse inverse, not necessarily a unique factorization of Q.**

For m=2 this solves Phase18's *known-filter* one-impulse union subfamily **without supplying either factor**. For m=3, the tested example collapses to six distinct taps from eight possible monomials and is also recovered exactly. Nothing in the theorem covers arbitrary K>1 defect vectors h, where `C=Q/h` may be dense.

### 3.2 Generic-input limitation

For a fixed inverse support set J of size t, invertible polynomials C supported on J are parametrized by t field/complex coefficients. The map `C -> C(S)^(-1)e0` is rational, so over the complex numbers its image has dimension <=t. At fixed N the finite union over all supports of size <=s has algebraic dimension at most s. The invertible Green change of coordinates `r=Px` does not alter it. Thus for s<N the structured fast family is measure zero in C^N. **This is not a lower bound against general FFT algorithms.**

## 4. Scope of all-input fallback and arithmetic charging

The exact hybrid tests the graph-ratio route (Theorems A/B), next the sparse-inverse route (Theorem C), and finally full Bluestein. The selector always produces the correct DFT in fields meeting the root and invertibility requirements. On generic inputs, the asymptotic field arithmetic is O(N log N), not `o(N log N)`. Initialization, root generation and Green coefficient setup are O(N) assuming a supplied primitive N-th root; the cost of finding a suitable field, primitive root, big integers, address operations, and finite precision is not hidden inside an O(N) bit-complexity claim.

A standard complex floating-point implementation does not inherit the exact zero comparisons or this exact finite-field guarantee. In particular, Vandermonde systems for roots `1` and `exp(2*pi*i/N)` have condition number `cot(pi/(2N))=Theta(N)` (for their 2x2 first-power matrix), and multi-root clusters are worse. We make **no floating-point stability claim**.

## 5. Independent audit and provenance

- `test_phase19.py`: unknown shifts K=1, bounded K=2, noncoprime / resonant exceptions, semi-blind unions, generic fallbacks.
- `test_inverse.py`: two and three completely unknown graph factors; independently generated generic sparse inverse; adversarial unchanged-prefix mutation; zero-frequency, interpolation and fallback tests.
- `test_hybrid.py`: combined full engine and adversarial mutations.
- `exhaustive_gate.py`: exact GF(17)^4 brute-force coprime-shift oracle on all 83,521 vectors.
- `exhaustive_inverse_gate.py`: independent GF(17)^4 direct-spectral inverse and support classification, again all 83,521 vectors.
- `exact_basis_audit.py`, `exact_inverse_basis_audit.py`: direct DFT of structured inputs across independent finite fields and all source positions. These are **tests of individual nonlinear adaptive invocations**; testing a basis is not mistaken for a proof of linearity of the adaptive decision logic.
- `benchmark_phase19.py`, `benchmark_inverse.py`, `benchmark_hybrid.py`: charged field-operation proxies versus equal-field, common-setup Bluestein, separately reporting non-field work.
- The complete immutable Phase18 archive is included.

**Prior art, not claimed as novel:** Fourier diagonalization of cyclic shifts, finite-rate-of-innovation/Prony spectral estimation, Berlekamp–Massey, sparse polynomial interpolation, cyclic convolution inversion, rational generating functions, Bluestein and Green operator identities. The new contribution *within this project* is their specific auditable combination into a certified, factor-blind sparse-inverse/graph-union selector and independently checked counterexamples. No global scientific priority is claimed.
