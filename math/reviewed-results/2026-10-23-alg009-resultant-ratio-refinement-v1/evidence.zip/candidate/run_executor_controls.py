"""Run only programs newly authored for this candidate, not historical code."""
from pathlib import Path
import json, random
from math import gcd
from paid_executor import core
from exact_controls import dft, from_defect, first_probes, resultant_value, raw_defect, gate, old_linear_gate_decision

HERE=Path(__file__).resolve().parent
results=[]

def control(name,r,p,w,promised=False):
    result=core(r,p,w,with_fallback=True)
    reference=dft(r,p,w)
    assert result['output']==reference
    assert len(result.get('attempts',[]))<=135
    algebra=sum(v for k,v in result['counts']['fixed_algebra'].items() if k!='zero_test')
    assert algebra<=500000
    if promised:
        assert result['status']=='accepted', (name,result['status'])
    if result['status']=='accepted':
        h=raw_defect(r,result['delta'],result['alpha'],p)
        assert 1<=len(h)<=2 and len(result['poles'])<=1
    results.append({'name':name,'p':p,'N':len(r),'omega':w,'r':r,
                    'result':result,'full_reference':reference})
    return result

control('quadratic-gcd-strict-extension',[65,9,49,62,28,77,42,67],97,64,True)
control('quadratic-gcd-strict-extension-N16',[80,4,42,70,52,22,69,18,30,50,51,85,77,96,63,8],97,8,True)
control('archived-noncoprime-nonresonance',[1,50,64,96,22,33,50,75],97,64,True)
control('one-pole-paid-repair',[3,3,1,1,1,1,1,1],97,64,True)
control('zero-vector-no-zero-defect-admission',[0]*8,97,64)
control('sparse-rank-one-zero-resultant',[1]+[0]*7,97,64)
control('sparse-rank-two-zero-resultant',[2,3]+[0]*6,97,64)
control('short-period-zero-resultant',[1,2]*4,97,64)
control('literal-multipole-example',[3,7,3,7,5,7,5,7],97,64)

rng=random.Random(230923)
generated=0
for n in (8,16,24,32):
    w=pow(5,96//n,97)
    for trial in range(12):
        d=rng.randrange(1,n); a=rng.randrange(1,97)
        if pow(a,n//gcd(n,d),97)==1:
            continue
        i,j=rng.sample(range(n),2)
        h={i:rng.randrange(1,97),j:rng.randrange(1,97)}
        r=from_defect(n,d,a,h,97)
        assert r is not None and raw_defect(r,d,a,97)==h
        R=first_probes(r,97,w)
        nonzero=any(resultant_value(R,x,97) for x in range(46))
        control(f'generated-{n}-{trial}',r,97,w,nonzero)
        generated+=1
    for trial in range(8):
        r=[rng.randrange(97) for _ in range(n)]
        control(f'arbitrary-{n}-{trial}',r,97,w)

# This exact perturbation preserves all eight charged measurements.
n,p,w=16,97,8
r=from_defect(n,1,34,{0:2,2:3},p)
mutation=[(r[j]+pow(w,-8*j,p))%p for j in range(n)]
assert first_probes(r,p,w)==first_probes(mutation,p,w)
assert len(raw_defect(mutation,1,34,p))>2
control('same-eight-probes-original',r,p,w)
control('same-eight-probes-mutant',mutation,p,w)

badroots=[]
for root in (1,22,2):
    try:
        core([1]*8,97,root)
    except ValueError as e:
        badroots.append({'omega':root,'reason':str(e)})
    else:
        raise AssertionError('bad root was accepted')

def solve(A,b,p):
    n=len(b); C=[row[:]+[b[i]] for i,row in enumerate(A)]
    for k in range(n):
        q=next(i for i in range(k,n) if C[i][k]%p)
        C[q],C[k]=C[k],C[q]
        inv=pow(C[k][k]%p,-1,p)
        C[k]=[x*inv%p for x in C[k]]
        for i in range(n):
            if i!=k:
                s=C[i][k]%p
                C[i]=[(x-s*y)%p for x,y in zip(C[i],C[k])]
    return [row[-1] for row in C]

# Independent full-x composition witness in the literal L=7I+2S+D,
# P=7I+S+2D^{-1} model. Dense solve is test-only, never fast-path work.
n,p,w=8,97,64
ld=[(7+pow(w,j,p))%p for j in range(n)]
pd=[(7+2*pow(w,-j,p))%p for j in range(n)]
assert all(ld) and all(pd)
L=[[(ld[i] if j==i else 0)+2*(j==(i-1)%n) for j in range(n)] for i in range(n)]
P=[[(pd[i] if j==i else 0)+(j==(i-1)%n) for j in range(n)] for i in range(n)]
r=[65,9,49,62,28,77,42,67]
x=solve(P,r,p)
recovered=solve(L,results[0]['result']['output'],p)
assert recovered==dft(x,p,w)
factors=[]
for diag,s in ((ld,2),(pd,1)):
    product=1
    for z in diag: product=product*(-s)*pow(z,-1,p)%p
    factors.append((1-product)%p)
assert all(factors)
green={'p':p,'N':n,'omega':w,'L_diagonal':ld,'P_diagonal':pd,
       'constructor_factors_L_P':factors,'x':x,'r':r,'output':recovered}

n,p,w=16,97,8
r=[80,4,42,70,52,22,69,18,30,50,51,85,77,96,63,8]
result=gate(r,p,w)
assert result['status']=='accepted' and result['output']==dft(r,p,w)
old=old_linear_gate_decision(r,p,w)
assert [z['delta'] for z in old]==[1,15] and not any(z['admissible'] for z in old)
(HERE/'STRICT_EXTENSION_WITNESS_N16.json').write_text(json.dumps({
    'p':p,'N':n,'omega':w,'r':r,'delta':1,'alpha':34,'h':{0:2,2:3},
    'old_selector':old,'new_gate':result},indent=2)+'\n')
ld=[(7+pow(w,j,p))%p for j in range(n)]
pd=[(7+2*pow(w,-j,p))%p for j in range(n)]
assert all(ld) and all(pd)
L=[[(ld[i] if j==i else 0)+2*(j==(i-1)%n) for j in range(n)] for i in range(n)]
P=[[(pd[i] if j==i else 0)+(j==(i-1)%n) for j in range(n)] for i in range(n)]
x=solve(P,r,p)
recovered=solve(L,result['output'],p)
assert recovered==dft(x,p,w)
factors=[]
for diag,s in ((ld,2),(pd,1)):
    product=1
    for z in diag: product=product*(-s)*pow(z,-1,p)%p
    factors.append((1-product)%p)
assert all(factors)
green16={'p':p,'N':n,'omega':w,'L_diagonal':ld,'P_diagonal':pd,
         'constructor_factors_L_P':factors,'x':x,'r':r,'output':recovered}

summary={'controls':len(results),'generated_cases':generated,
         'accepted':sum(z['result']['status']=='accepted' for z in results),
         'fallback':sum(z['result']['fallback'] for z in results),
         'output_coordinates_verified':sum(len(z['full_reference']) for z in results),
         'max_attempts':max(len(z['result'].get('attempts',[])) for z in results),
         'max_fixed_algebra_operations':max(sum(v for k,v in z['result']['counts']['fixed_algebra'].items()
                                               if k!='zero_test') for z in results),
         'root_rejections':badroots,'green_composition_N8':green,'green_composition_N16':green16,
         'historical_programs_executed':False,
         'reference_and_input_generation_cost':'Separate control work, not fast-path runtime.'}
(HERE/'EXECUTOR_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
(HERE/'CONTROL_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
