"""New, standalone exact controls. No historical program is imported or run."""
from itertools import permutations, combinations
from math import gcd
from pathlib import Path
import json

def trim(a):
    a = a[:]
    while a and a[-1] == 0:
        a.pop()
    return a

def pmul(a, b, p):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] = (out[i+j] + x*y) % p
    return trim(out)

def padd(a, b, p):
    out = [0] * max(len(a), len(b))
    for i in range(len(out)):
        out[i] = ((a[i] if i < len(a) else 0) + (b[i] if i < len(b) else 0)) % p
    return trim(out)

def peval(a, x, p):
    y = 0
    for c in a[::-1]:
        y = (y*x+c) % p
    return y

def pgcd(a, b, p):
    a, b = trim(a), trim(b)
    while b:
        r = a[:]
        while len(r) >= len(b):
            c = r[-1]*pow(b[-1], -1, p) % p
            off = len(r)-len(b)
            for j, x in enumerate(b):
                r[off+j] = (r[off+j]-c*x) % p
            r = trim(r)
        a, b = b, r
    return [x*pow(a[-1], -1, p) % p for x in a] if a else []

PERMS = [(t, (-1)**sum(t[i]>t[j] for i in range(3) for j in range(i+1,3)))
         for t in permutations(range(3))]

def hankel_cubic(R, w, base, p):
    out = []
    for perm, sign in PERMS:
        term = [sign % p]
        for row, col in enumerate(perm):
            k = base+row+col
            term = pmul(term, [R[k], -R[k]*pow(w,k,p) % p], p)
        out = padd(out, term, p)
    return out

def det(M, p):
    A = [row[:] for row in M]
    answer = 1
    for k in range(len(A)):
        pivot = next((i for i in range(k,len(A)) if A[i][k]), None)
        if pivot is None:
            return 0
        if pivot != k:
            A[k], A[pivot] = A[pivot], A[k]
            answer = -answer % p
        q = A[k][k]
        answer = answer*q % p
        qi = pow(q,-1,p)
        for i in range(k+1,len(A)):
            scale = A[i][k]*qi % p
            for j in range(k,len(A)):
                A[i][j] = (A[i][j]-scale*A[k][j]) % p
    return answer

def resultant_value(R,w,p):
    rows = []
    for start in (0,1):
        c = hankel_cubic(R,w,start,p)
        c = (c+[0]*(4-len(c)))[::-1]
        for offset in range(3):
            rows.append([0]*offset+c+[0]*(2-offset))
    return det(rows,p)

def interpolate_46(values,p):
    # Deliberately use direct Lagrange, not historical Newton interpolation.
    out = []
    for i, value in enumerate(values):
        basis, denom = [1], 1
        for j in range(46):
            if i != j:
                basis = pmul(basis, [-j % p,1],p)
                denom = denom*(i-j) % p
        scale = value*pow(denom,-1,p) % p
        out = padd(out,[scale*x % p for x in basis],p)
    return out

def dft(r,p,w):
    n = len(r)
    return [sum(r[j]*pow(w,(k*j)%n,p) for j in range(n)) % p for k in range(n)]

def first_probes(r,p,w):
    n = len(r)
    return [sum(r[j]*pow(w,(k*j)%n,p) for j in range(n)) % p for k in range(8)]

def raw_defect(r,d,a,p):
    n = len(r)
    return {j:v for j in range(n) if (v:=(r[j]-a*r[(j-d)%n])%p)}

def pole_indices(n,d,a,p,w):
    return [k for k in range(n) if (1-a*pow(w,(k*d)%n,p))%p == 0]

def candidate_certificate(r,d,a,p,w):
    if not (1 <= d < len(r)) or a == 0:
        return None
    h = raw_defect(r,d,a,p)
    if not 1 <= len(h) <= 2:
        return None
    poles = pole_indices(len(r),d,a,p,w)
    if len(poles) > 1:
        return None
    return h,poles

def reconstruct(r,d,a,h,poles,p,w):
    n = len(r)
    out = []
    for k in range(n):
        if k in poles:
            out.append(sum(r[j]*pow(w,(j*k)%n,p) for j in range(n)) % p)
        else:
            numerator = sum(v*pow(w,(j*k)%n,p) for j,v in h.items()) % p
            denominator = (1-a*pow(w,(d*k)%n,p)) % p
            out.append(numerator*pow(denominator,-1,p) % p)
    return out

def gate(r,p,w, full_interpolation=True):
    n = len(r)
    assert n >= 8 and p > 55
    table = [pow(w,i,p) for i in range(n)]
    assert pow(w,n,p) == 1 and len(set(table)) == n
    R = first_probes(r,p,w)
    vals = [resultant_value(R,x,p) for x in range(46)]
    if not any(vals):
        return {'status':'decline-zero-resultant'}
    coeff = interpolate_46(vals,p) if full_interpolation else None
    if coeff is not None:
        assert len(coeff) <= 46
        for x in range(46,49):
            assert peval(coeff,x,p) == resultant_value(R,x,p)
    roots = [d for d in range(1,n) if (peval(coeff,table[d],p) if coeff is not None
              else resultant_value(R,table[d],p)) == 0]
    assert len(roots) <= 45
    anchors = [i for i,x in enumerate(r) if x][:3]
    assert len(anchors) == 3
    attempts = []
    for d in roots:
        for i in anchors:
            a = r[(i+d)%n]*pow(r[i],-1,p) % p
            cert = candidate_certificate(r,d,a,p,w)
            attempts.append([d,i,a,bool(cert)])
            if cert:
                h,poles = cert
                out = reconstruct(r,d,a,h,poles,p,w)
                assert out == dft(r,p,w)
                return {'status':'accepted','delta':d,'alpha':a,'h':h,'poles':poles,
                        'output':out,'root_shifts':roots,'anchors':anchors,
                        'attempts':attempts,'resultant_coefficients':coeff,
                        'resultant_witness':next([x,v] for x,v in enumerate(vals) if v)}
    return {'status':'decline-no-certificate','root_shifts':roots,'attempts':attempts,
            'resultant_coefficients':coeff}

def old_linear_gate_decision(r,p,w):
    # A mathematical old-selector comparator, not an execution of old code.
    n = len(r)
    R = first_probes(r,p,w)
    records = []
    for d in range(1,n):
        q = pow(w,d,p)
        if resultant_value(R,q,p):
            continue
        g = pgcd(hankel_cubic(R,q,0,p),hankel_cubic(R,q,1,p),p)
        a = -g[0] % p if len(g)==2 else None
        cert = candidate_certificate(r,d,a,p,w) if a is not None else None
        records.append({'delta':d,'gcd':g,'candidate_alpha':a,'admissible':bool(cert)})
    return records

def from_defect(n,d,a,h,p):
    # Exact cyclic recurrence solve, independently using a dense augmented system.
    A = [[int(i==j)-a*int(j==(i-d)%n) for j in range(n)]+[h.get(i,0)]
         for i in range(n)]
    row = 0
    for col in range(n):
        piv = next((i for i in range(row,n) if A[i][col]%p),None)
        if piv is None:
            continue
        A[row],A[piv] = A[piv],A[row]
        inv = pow(A[row][col]%p,-1,p)
        A[row] = [x*inv%p for x in A[row]]
        for i in range(n):
            if i!=row:
                q = A[i][col]%p
                A[i] = [(x-q*y)%p for x,y in zip(A[i],A[row])]
        row += 1
    if any(not any(A[i][:-1]) and A[i][-1] for i in range(row,n)):
        return None
    r = [0]*n
    for i in range(row):
        lead = next(j for j in range(n) if A[i][j])
        r[lead] = A[i][-1]
    return r

def main():
    p,n,w = 97,8,64
    witness = None
    checked = 0
    for d in range(1,n):
        for a in range(1,p):
            if len(pole_indices(n,d,a,p,w)) > 1:
                continue
            for i,j in combinations(range(n),2):
                h = {i:2,j:3}
                r = from_defect(n,d,a,h,p)
                if r is None:
                    continue
                checked += 1
                R = first_probes(r,p,w)
                # Only a witness value is needed to prove T is nonzero in search.
                witness_value = resultant_value(R,2,p)
                if not witness_value:
                    continue
                old = old_linear_gate_decision(r,p,w)
                if not any(e['admissible'] for e in old):
                    result = gate(r,p,w)
                    assert result['status']=='accepted'
                    witness = {'p':p,'N':n,'omega':w,'r':r,'generating_delta':d,
                               'generating_alpha':a,'generating_h':h,'old_selector':old,
                               'new_gate':result,'searched_inputs':checked}
                    break
            if witness:
                break
        if witness:
            break
    print(json.dumps(witness,indent=2))
    Path(__file__).with_name('STRICT_EXTENSION_WITNESS.json').write_text(json.dumps(witness,indent=2)+'\n')

if __name__ == '__main__':
    main()
