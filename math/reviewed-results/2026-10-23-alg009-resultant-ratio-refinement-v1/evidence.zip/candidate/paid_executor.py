"""New exact prime-field executor for the nonzero-resultant family.

No historical code imports. All finite-field arithmetic in the executor passes
through Meter. Field/root discovery and primality certification are not inputs
to this supplied-prime-field/supplied-root theorem. Python/bit-operation counts
and reference-test costs are not represented as field operations.
"""
from itertools import permutations

class Meter:
    def __init__(self,p):
        self.p=p
        self.stage='setup'
        self.counts={}
    def tick(self,key):
        d=self.counts.setdefault(self.stage,{})
        d[key]=d.get(key,0)+1
    def add(self,a,b):
        self.tick('add'); return (a+b)%self.p
    def sub(self,a,b):
        self.tick('sub'); return (a-b)%self.p
    def mul(self,a,b):
        self.tick('mul'); return a*b%self.p
    def neg(self,a):
        self.tick('neg'); return -a%self.p
    def inv(self,a):
        assert not self.zero(a)
        self.tick('inv'); return pow(a,-1,self.p)
    def zero(self,a):
        self.tick('zero_test'); return a==0

def trim(a,F):
    while a and F.zero(a[-1]): a.pop()
    return a

def product(a,b,F):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            out[i+j]=F.add(out[i+j],F.mul(x,y))
    return trim(out,F)

def evaluate(a,x,F):
    v=0
    for c in reversed(a): v=F.add(F.mul(v,x),c)
    return v

PERMS=[(q,sum(q[i]>q[j] for i in range(3) for j in range(i+1,3))%2)
       for q in permutations(range(3))]

def cubic(R,powers,base,F):
    result=[0]*4
    minus_one=F.neg(1)
    for q,odd in PERMS:
        term=[minus_one if odd else 1]
        for i,j in enumerate(q):
            k=base+i+j
            term=product(term,[R[k],F.neg(F.mul(R[k],powers[k]))],F)
        for j,x in enumerate(term): result[j]=F.add(result[j],x)
    return result

def determinant(A,F):
    A=[row[:] for row in A]
    value=1
    for k in range(6):
        pivot=next((j for j in range(k,6) if not F.zero(A[j][k])),None)
        if pivot is None: return 0
        if pivot!=k:
            A[pivot],A[k]=A[k],A[pivot]
            value=F.neg(value)
        value=F.mul(value,A[k][k])
        qi=F.inv(A[k][k])
        for j in range(k+1,6):
            scale=F.mul(A[j][k],qi)
            for t in range(k,6): A[j][t]=F.sub(A[j][t],F.mul(scale,A[k][t]))
    return value

def resultant(R,w,F):
    powers=[1]
    for _ in range(5): powers.append(F.mul(powers[-1],w))
    matrix=[]
    for base in (0,1):
        c=list(reversed(cubic(R,powers,base,F)))
        for shift in range(3): matrix.append([0]*shift+c+[0]*(2-shift))
    return determinant(matrix,F)

def interpolate(values,F):
    out=[0]*46
    for i in range(46):
        basis=[1]; denom=1
        for j in range(46):
            if i!=j:
                basis=product(basis,[F.neg(j),1],F)
                denom=F.mul(denom,F.sub(i,j))
        scale=F.mul(values[i],F.inv(denom))
        for j,c in enumerate(basis): out[j]=F.add(out[j],F.mul(scale,c))
    return trim(out,F)

def direct_frequency(r,node,F):
    value=0; power=1
    for x in r:
        value=F.add(value,F.mul(x,power))
        power=F.mul(power,node)
    return value

def core(r,p,omega,with_fallback=False):
    """Return a certified output or decline; direct fallback is optional.

    Preconditions: p is a supplied certified prime >55, N=len(r)>=8,
    each r_j and omega is canonically encoded in 0,...,p-1.
    Root exact order is checked using the paid table. Only prime-field
    arithmetic is provided by this concrete executor.
    """
    n=len(r)
    if n<8 or p<=55 or any(not isinstance(x,int) or not 0<=x<p for x in [omega]+r):
        raise ValueError('outside the supplied prime-field domain')
    F=Meter(p)
    table=[1]
    for j in range(1,n):
        table.append(F.mul(table[-1],omega))
        if F.zero(F.sub(table[-1],1)):
            raise ValueError('omega has order smaller than N')
    if not F.zero(F.sub(F.mul(table[-1],omega),1)):
        raise ValueError('omega does not have order N')
    F.stage='probes'
    R=[direct_frequency(r,table[k],F) for k in range(8)]
    F.stage='fixed_algebra'
    values=[resultant(R,x,F) for x in range(46)]
    coeff=interpolate(values,F)
    base={'N':n,'p':p,'omega':omega,'counts':F.counts,'fallback':False}

    def decline(reason):
        answer={**base,'status':reason}
        if with_fallback:
            F.stage='fallback'
            answer.update(status='fallback-output',decline_reason=reason,fallback=True,
                          output=[direct_frequency(r,z,F) for z in table])
        return answer

    if not coeff: return decline('zero-resultant')
    F.stage='root_scan'
    shifts=[d for d in range(1,n) if F.zero(evaluate(coeff,table[d],F))]
    assert len(shifts)<=45
    F.stage='anchors'
    anchors=[]
    for i,x in enumerate(r):
        if not F.zero(x):
            anchors.append(i)
            if len(anchors)==3: break
    assert len(anchors)==3  # The proof derives this from T != 0.
    inverse=[F.inv(r[i]) for i in anchors]
    attempts=[]
    for d in shifts:
        for i,ri in zip(anchors,inverse):
            F.stage='candidate_certificates'
            alpha=F.mul(r[(i+d)%n],ri)
            attempt={'delta':d,'anchor':i,'alpha':alpha}
            attempts.append(attempt)
            if F.zero(alpha):
                attempt['reject']='zero-alpha'; continue
            defects=[]
            for j in range(n):
                v=F.sub(r[j],F.mul(alpha,r[(j-d)%n]))
                if not F.zero(v):
                    defects.append((j,v))
                    if len(defects)>2: break
            if not 1<=len(defects)<=2:
                attempt['reject']='defect-count'; continue
            # Count actual grid poles, with no powering/gcd/root oracle.
            poles=[]; denominators=[]; power=1
            for k in range(n):
                q=F.sub(1,F.mul(alpha,power))
                denominators.append(q)
                if F.zero(q): poles.append(k)
                power=F.mul(power,table[d])
            if len(poles)>1:
                attempt['reject']='multiple-poles'; continue
            F.stage='output'
            streams=[1]*len(defects)
            out=[]
            for k,q in enumerate(denominators):
                value=0
                for t,(pos,amplitude) in enumerate(defects):
                    value=F.add(value,F.mul(amplitude,streams[t]))
                    streams[t]=F.mul(streams[t],table[pos])
                if F.zero(q):
                    value=direct_frequency(r,table[k],F)
                else:
                    value=F.mul(value,F.inv(q))
                out.append(value)
            attempt['accepted']=True
            return {**base,'status':'accepted','delta':d,'alpha':alpha,
                    'defects':defects,'poles':poles,'output':out,'shifts':shifts,
                    'anchors':anchors,'attempts':attempts,
                    'resultant_coefficients':coeff}
    answer=decline('no-admissible-certificate')
    answer.update(shifts=shifts,anchors=anchors,attempts=attempts)
    return answer
