"""Independent controls. Reads data-only witness; no supplied program imports."""
import hashlib
import itertools
import json
import sys
from collections import Counter
from math import prod
from pathlib import Path

HERE=Path(__file__).resolve().parent
SOURCE=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/'alg009_three_ratio_gate_20261023_v1'
W=json.loads((SOURCE/'STRICT_EXTENSION_WITNESS.json').read_text())

def trim(a,p):
    a=[x%p for x in a]
    while a and a[-1]==0: a.pop()
    return a

def add(a,b,p):
    c=[0]*max(len(a),len(b))
    for i,x in enumerate(a): c[i]+=x
    for i,x in enumerate(b): c[i]+=x
    return trim(c,p)

def mul(a,b,p):
    c=[0]*max(0,len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return trim(c,p)

def rem(a,b,p):
    a=trim(a,p)
    while len(a)>=len(b) and a:
        j=len(a)-len(b); c=a[-1]*pow(b[-1],-1,p)%p
        for i,x in enumerate(b): a[j+i]=(a[j+i]-c*x)%p
        a=trim(a,p)
    return a

def gcd(a,b,p):
    while b: a,b=b,rem(a,b,p)
    return [(x*pow(a[-1],-1,p))%p for x in a] if a else []

def det_permutation(a,p):
    n=len(a); ans=0
    for s in itertools.permutations(range(n)):
        term=(-1)**sum(s[i]>s[j] for i in range(n) for j in range(i+1,n))
        for i,j in enumerate(s): term=term*a[i][j]%p
        ans=(ans+term)%p
    return ans

def interpolate(xs,ys,p):
    ans=[]
    for j,x in enumerate(xs):
        basis=[1]; den=1
        for k,y in enumerate(xs):
            if j!=k:
                basis=mul(basis,[-y,1],p); den=den*(x-y)%p
        ans=add(ans,[b*ys[j]*pow(den,-1,p)%p for b in basis],p)
    return ans

def hankel_cubic(R,w,base,p):
    # Interpolate in alpha from four fresh numerical Hankel determinants.
    vals=[]
    for alpha in range(4):
        y=[R[k]*(1-alpha*pow(w,k,p))%p for k in range(6)]
        vals.append(det_permutation([[y[base+i+j] for j in range(3)] for i in range(3)],p))
    return interpolate(list(range(4)),vals,p)

def padded_resultant(R,w,p):
    A=hankel_cubic(R,w,0,p); B=hankel_cubic(R,w,1,p)
    a=list(reversed(A+[0]*(4-len(A))))
    b=list(reversed(B+[0]*(4-len(B))))
    rows=[]
    for c in (a,b):
        for t in range(3): rows.append([0]*t+c+[0]*(2-t))
    return det_permutation(rows,p)

def dft(r,w,p):
    return [sum(x*pow(w,k*j,p) for j,x in enumerate(r))%p for k in range(len(r))]

def defect(r,d,a,p):
    return [(r[j]-a*r[(j-d)%len(r)])%p for j in range(len(r))]

def evalpoly(a,x,p):
    y=0
    for c in reversed(a): y=(y*x+c)%p
    return y

def solve_matrix(A,b,p):
    M=[[x%p for x in row]+[v%p] for row,v in zip(A,b)]
    for j in range(len(M)):
        k=next(k for k in range(j,len(M)) if M[k][j])
        M[j],M[k]=M[k],M[j]
        inverse=pow(M[j][j],-1,p)
        M[j]=[x*inverse%p for x in M[j]]
        for k in range(len(M)):
            if k!=j:
                scale=M[k][j]
                M[k]=[(x-scale*y)%p for x,y in zip(M[k],M[j])]
    return [row[-1] for row in M]

def main():
    p=W['p']; n=W['N']; w=W['omega']; r=W['r']
    roots=[pow(w,d,p) for d in range(n)]
    assert len(set(roots))==n and pow(w,n,p)==1
    R=dft(r,w,p); assert R==[11,51,26,43,66,40,75,14]
    assert R==W['new_gate']['output']
    h=defect(r,1,27,p)
    assert h==[2,0,0,0,3,0,0,0]
    assert [k for k in range(n) if (1-27*pow(w,k,p))%p==0]==[]
    ts=[padded_resultant(R,roots[d],p) for d in range(1,n)]
    assert [d for d in range(1,n) if ts[d-1]==0]==[1,7]
    gs={d:gcd(hankel_cubic(R,roots[d],0,p),hankel_cubic(R,roots[d],1,p),p) for d in (1,7)}
    assert gs=={1:[60,57,1],7:[76,64,1]}
    assert padded_resultant(R,2,p)==78
    # All 46 degree-bounding evaluations independently bind recorded T.
    for x in range(46):
        assert padded_resultant(R,x,p)==evalpoly(W['new_gate']['resultant_coefficients'],x,p)
    # Full output reconstruction through the certified sparse relation.
    out=[sum(h[j]*pow(w,j*k,p) for j in range(n))*pow((1-27*pow(w,k,p))%p,-1,p)%p for k in range(n)]
    assert out==R
    ratios=[r[(i+1)%n]*pow(r[i],-1,p)%p for i in [0,1,2]]
    assert 27 in ratios
    # Supplied-root original-input lift, without running any Green source.
    ldiag=[(7+roots[j])%p for j in range(n)]
    pdiag=[(7+2*roots[-j%n])%p for j in range(n)]
    L=[[(int(i==j)*ldiag[i]+2*int(j==(i-1)%n))%p for j in range(n)] for i in range(n)]
    P=[[(int(i==j)*pdiag[i]+int(j==(i-1)%n))%p for j in range(n)] for i in range(n)]
    assert all(ldiag+pdiag)
    detL=det_permutation(L,p); detP=det_permutation(P,p)
    assert detL!=0 and detP!=0
    green_x=solve_matrix(P,r,p)
    assert green_x==[23,45,13,2,44,13,31,52]
    assert [sum(P[i][j]*green_x[j] for j in range(n))%p for i in range(n)]==r
    y=solve_matrix(L,R,p)
    assert y==dft(green_x,w,p)==[29,4,14,36,96,35,32,35]
    # Independently discovered strict witness where eight probes are not all N outputs.
    N16=16; omega16=8; alpha16=34
    r16=[80,4,42,70,52,22,69,18,30,50,51,85,77,96,63,8]
    roots16=[pow(omega16,j,p) for j in range(N16)]
    assert len(set(roots16))==N16 and pow(omega16,N16,p)==1
    full16=dft(r16,omega16,p); probes16=full16[:8]
    assert full16==[41,0,22,23,10,94,75,18,14,0,67,75,18,40,51,53]
    h16=defect(r16,1,alpha16,p)
    assert h16==[2,0,3]+[0]*13
    assert all((1-alpha16*z)%p for z in roots16)
    assert padded_resultant(probes16,2,p)==46
    W16=json.loads((SOURCE/'STRICT_EXTENSION_WITNESS_N16.json').read_text())
    assert W16['r']==r16 and W16['new_gate']['output']==full16
    for point in range(46):
        assert padded_resultant(probes16,point,p)==evalpoly(W16['new_gate']['resultant_coefficients'],point,p)
    candidates16=[d for d in range(1,N16) if padded_resultant(probes16,roots16[d],p)==0]
    assert candidates16==[1,15]
    gcds16={d:gcd(hankel_cubic(probes16,roots16[d],0,p),hankel_cubic(probes16,roots16[d],1,p),p) for d in candidates16}
    assert gcds16=={1:[77,75,1],15:[63,69,1]}
    ratios16=[r16[(i+1)%N16]*pow(r16[i],-1,p)%p for i in [0,1,2]]
    assert alpha16 in ratios16
    reconstruct16=[sum(h16[j]*pow(omega16,j*k,p) for j in range(N16))*pow((1-alpha16*roots16[k])%p,-1,p)%p for k in range(N16)]
    assert reconstruct16==full16
    ld16=[(7+z)%p for z in roots16]; pd16=[(7+2*roots16[-j%N16])%p for j in range(N16)]
    L16=[[(int(i==j)*ld16[i]+2*int(j==(i-1)%N16))%p for j in range(N16)] for i in range(N16)]
    P16=[[(int(i==j)*pd16[i]+int(j==(i-1)%N16))%p for j in range(N16)] for i in range(N16)]
    assert all(ld16+pd16)
    detL16=(prod(ld16)-pow(2,N16,p))%p
    detP16=(prod(pd16)-1)%p
    assert detL16==detP16==71
    x16=solve_matrix(P16,r16,p); y16=solve_matrix(L16,full16,p)
    assert x16==[19,18,6,6,4,12,34,88,66,12,33,35,75,56,64,6]
    assert y16==dft(x16,omega16,p)==[49,84,28,19,86,60,86,94,68,39,7,60,65,74,0,67]
    adjacent8=[r[j]*pow(r[(j-1)%n],-1,p)%p for j in range(n)]
    adjacent16=[r16[j]*pow(r16[(j-1)%N16],-1,p)%p for j in range(N16)]
    assert sorted(Counter(adjacent8).values())==[1,1,6]
    assert sorted(Counter(adjacent16).values())==[1,1,14]
    assert adjacent8[:5].count(27)>=3 and adjacent16[:5].count(34)>=3

    # Exhaustive small-field raw lemma, including periodic shifts and alpha=0.
    vectors=descriptions=anchor_sets=0
    zero_ratios=periodic_shifts=0
    from math import gcd as igcd
    for N in range(3,8):
        for raw in itertools.product(range(3),repeat=N):
            nonzero=[i for i,x in enumerate(raw) if x]
            if len(nonzero)<3: continue
            vectors+=1
            for delta in range(1,N):
                for a in range(3):
                    hh=defect(raw,delta,a,3)
                    if sum(bool(x) for x in hh)>2: continue
                    descriptions+=1
                    periodic_shifts+=igcd(N,delta)>1
                    for ids in itertools.combinations(nonzero,3):
                        anchor_sets+=1
                        proposed=[raw[(i+delta)%N]*pow(raw[i],-1,3)%3 for i in ids]
                        assert a in proposed
                        zero_ratios+=0 in proposed
                        assert sum(x!=a for x in proposed)<=2
                        assert all((proposed[k]!=a)==(hh[(i+delta)%N]!=0) for k,i in enumerate(ids))
    # Sparse-input common-alpha-zero mechanism, checked on independent samples.
    sparse_controls=0
    for support in itertools.chain([()],itertools.combinations(range(n),1),itertools.combinations(range(n),2)):
        rr=[0]*n
        for j in support: rr[j]=(j+2)%p
        RR=dft(rr,w,p)
        for x in [0,1,2,3,8,35,64,96]:
            A=hankel_cubic(RR,x,0,p); B=hankel_cubic(RR,x,1,p)
            assert (not A or A[0]==0) and (not B or B[0]==0)
            assert padded_resultant(RR,x,p)==0
            sparse_controls+=1
    result={
      'verdict':'PASS', 'source_program_execution':False,
      'witness_sha256':hashlib.sha256((SOURCE/'STRICT_EXTENSION_WITNESS.json').read_bytes()).hexdigest(),
      'N16_witness_sha256':hashlib.sha256((SOURCE/'STRICT_EXTENSION_WITNESS_N16.json').read_bytes()).hexdigest(),
      'strict_extension':{'dft':R,'root_shifts':[1,7],'padded_resultant_at_2':78,'specialized_gcds':gs,'ratios':ratios,'resultant_transcription_points':46},
      'original_input_green_lift':{'x':green_x,'P_diagonal':pdiag,'L_diagonal':ldiag,'det_P':detP,'det_L':detL,'full_output':y,'supplied_root':w,'historical_constructor_executed':False},
      'independently_discovered_N16_strict_extension':{'N':N16,'p':p,'omega':omega16,'alpha':alpha16,'delta':1,'r':r16,'defects':h16,'resultant_at_2':46,'candidate_shifts':candidates16,'specialized_gcds':gcds16,'ratios':ratios16,'raw_DFT':full16,'Green_input':x16,'Green_output':y16,'P_diagonal':pd16,'L_diagonal':ld16,'det_P':detP16,'det_L':detL16,'all_constructor_diagonals_nonzero':True,'historical_program_execution':False},
      'predecessor_ratio_route_scope':{'N8_adjacent_counts':sorted(Counter(adjacent8).values()),'N16_adjacent_counts':sorted(Counter(adjacent16).values()),'both_witnesses_are_already_covered_by_Phase19_ratio_branch':True,'full_hybrid_strict_extension_claimed':False,'historical_program_execution':False},
      'exhaustive_ratio_controls':{'field':3,'lengths':[3,4,5,6,7],'raw_vectors_with_3_nonzeros':vectors,'qualifying_descriptions':descriptions,'anchor_sets':anchor_sets,'sets_containing_zero_ratio':zero_ratios,'noncoprime_descriptions':periodic_shifts},
      'sparse_input_padded_zero_controls':sparse_controls,
      'limitations':'Finite controls verify transcription and edge examples; universal coverage rests on the algebraic proof.'
    }
    (HERE/'INDEPENDENT_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
