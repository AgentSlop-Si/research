# Hero #1 — Phase20 research gate

## Main unsolved problem: fully blind sparse rational forcing with K>=2

Phase19's strongest theorem automatically recovers r from a sparse circulant inverse C satisfying `C(S)r=e0`. A general union with K>1 arbitrary defects only guarantees `Q(S)r=h` where Q and h are both sparse but entirely unknown. In frequency, `R_k = H(omega^k)/Q(omega^k)`, and reciprocal spectral probes are no longer sums of a few exponentials.

**Gate A — sparse rational interpolation without guessed supports.** Find an exact O(N log log N) (ideally O(N)) method for discovering unknown sparse numerator H and sparse denominator Q from O(s+K) directly calculated spectral probes, complete with source/destination support recovery *without discrete-log oracle*, and a full O(N(s+K)) time-domain certificate. Need distinguish non-identifiability from actual computational barriers; handle gcd(H,Q), common roots, and scalar/shift gauges.

**Gate B — defeat cross-wrap collisions without N delay scans.** Extend the K>=2 unknown single-shift theorem to resonant root families, perhaps using several adjacent-ratio string windows, modular mechanical words or graph-cycle invariants. Preserve the explicit GF counterexample in `NEGATIVE_GATE.md` and require exact full-vector check.

**Gate C — global scope, not cherry-picked inputs.** Sparse C parameter dimension<=s shows the newly solved family is not generic. Any purported arbitrary-input speedup must explain how genuinely N-dimensional fresh data are represented and evaluated with o(N log N) total arithmetic, including selection/routing/precomputation. Do not use CrocSwap conditional exponents or an FFT hidden inside forcing.

**Gate D — numeric and bit model.** Develop certified complex recovery with adaptive precision or avoid ill-conditioned Prony entirely; prove forward-error bounds. Specify root supply, modular field size, bit operations and workspace. Current exact field results do not transfer automatically to floating-point FFT.

**Gate E — adversarial acceptance.** Keep the unchanged-first-eight-probes mutation test; require independent full-basis tests and a separate noisy/near-resonant stress gate. A promising short-sample pattern without a full convolution certificate must be rejected.

## Acceptance checklist before claiming an unrestricted breakthrough

Exact all-input identity; input-independent or correctly charged adaptive algorithm; all arithmetic/data accesses and setup counted; worst-case `o(N log N)` for a clearly defined model; independent adversarial tests; relevant prior-art comparison; mathematically established precision/bit bounds if claimed.
