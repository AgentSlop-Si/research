# Odd higher-middle boundary resolution by amplitude-sensitive elimination

23 October 2026 UTC. Author candidate for independent review. This is a uniform partial theorem, not full F020 closure. No external publication and no supplied research program was executed.

## 1. Claim and the actual delta

Let p be an odd prime, c=2a+1 with 1<=c<p, k>=2, r>=k+2, s>r, M=p^k, N=p^r, and n=2N+cM. Let q be any characteristic-zero primitive p^s-th root. Use the actual recurrence

P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),

and w_j=product_(u=1)^j(1-q^u). Derivatives are ordinary characteristic-zero derivatives; the kernel uses algebraic squares.

NEW CLAIM: Every P_n root on the boundary of any of the old r-scale disks is simple, with a nonzero original algebraic-square kernel. There are at least 2N such roots, counted with multiplicity before simplicity, for every parameter choice above. The theorem includes both coincident and disjoint short-tail/core residual classes. It does not assume that the short odd tail is a unit.

Combined with the inherited (c-1)M simple k-boundary roots and the inherited simple exact zero, at most M-1 nonzero roots remain unresolved by this combination. Those remaining roots are in strict k-interiors but not on old r-boundaries. No exact allocation among deeper r-interiors and the region outside old r-disks is asserted.

The full accepted first-residual criterion, other fixed certificates, and the accepted high-order deflation filter remain inherited. To define that filter explicitly, for j=(n-1)/2 set l_d=floor(j/d), e_d=((d+1)/2)l_d+floor(l_d/2), kappa_j=j+3floor(j^2/4)+2floor(j/4), and

C_j=j(j+1)(2j+1)/3-ceil(j/2)-kappa_j-sum_(odd 3<=d<=j) phi(d)e_d.

Here phi is Euler's totient. The accepted strict sufficient condition is phi(p^s)>C_j; C_j is a deflated degree bound. Its exact source and acceptance are pinned in sources/SOURCE_FRONTIER.json.

 The research delta is only the not-previously-certified roots under phi(p^s)<=C_((n-1)/2), after subtracting all other accepted certificates. Although this theorem is stated uniformly for all s>r, cases already fully certified gain no new coverage credit. In the n=513 source example the two tail boundary roots were already certified; they are not new here. The theorem newly controls its remaining 486 r-boundary roots, leaving its other 24 roots open.

## 2. Source inputs and notation

Put t=q-1, v(t)=1, e=v(p)=(p-1)p^(s-1), V(j)=p^ord_p(j), W(j)=sum_(u=1)^j V(u), and

A=W(M), K=W(N), B_k=k(p-1)p^(k-1)/2,
u=(cM-1)/2=aM+(M-1)/2,
G=W(u)=aA+B_k.

Then cA=2G+M and W(cM-1)=2G. All recurrence indices are below p^s because n<[2+(p-1)/p^2]N<pN<=p^s.

Let beta=p^floor(r/2), L=N/beta, and rho=beta/2 for even r, or rho=(2p-1)p^(floor(r/2)-1)/2 for odd r. The old disks are D_b={v(X-x_b)>=rho}, 0<=b<beta, with x_b=i(q^(b/2)-q^(-b/2)). Their centers and their disjointness are the accepted original core geometry. Each lies strictly inside its corresponding k-disk.

Write C=P_(2N), B=P_(2N-1), b0=1-q^(2N), and E=K-N/2. The accepted full-disk core bounds are

C: >=K; C': >=K+N/2-p; B: >=E; B': >=E.

The exact initial C polynomial is a nonzero multiple of Z^2+1, with Z=gamma_b Y^L and gamma_b nonzero. The exact initial B polynomial is a nonzero multiple of Z. Consequently B has value E at EVERY nonzero boundary residue, not just at old C roots. This distinction is essential.

These core statements are taken from the accepted leading-core source as retained and used in Sections 2 and 10 of the accepted all-even report. The actual bound source and its acceptance bindings are pinned in SOURCE_PINS.json. The original higher-middle report/review supply the lower-root/zero accounting. The finite connection identities and the strict deep cap below are credited to the accepted c=2/all-even architecture, not claimed as new identities.

## 3. Full-disk odd-tail estimates

Define the genuine shifted continuants f_j^L,g_j^L by f_0=1,f_1=X,g_0=0,g_1=1 and h_(j+1)=Xh_j-(1-q^(L+j))h_(j-1). Set m=cM, f=f_m^(2N), g=g_m^(2N). The needed new odd-tail statement is

weight(f)>=G+M,
weight(f')=G+M-p, with nonzero constant initial,
weight(g)=G, with nonzero constant initial,
weight(g')>=G-(p-1).                                      (3.1)

All statements are coefficientwise on every full old r-disk. In particular they apply at every point in the disk and not merely at a root of an auxiliary polynomial.

### 3.1 Short ordinary polynomials

For j<pM set h_j=W(j)-W(floor(j/2)). On old r-disks, the strict deep cap is

R(j)=W(j)-sum_(u=1)^j min(V(u),rho)<=W(floor(j/2)),

with equality only at j=0,1. Here the apparent equality at j=1 is R(1)=W(0)=0. For completeness, W and S=W/2-R are digit-linear. At the digit basis p^d, S(p^d)=W(p^d)/2 if d<floor(r/2), and S(p^d)=(r-d)(p-1)p^(d-1)/2 otherwise. For j>=2 with top digit d>=floor(r/2), r>=k+2 and d<=k give S(j)>p^d/2, whereas W(j)-2W(floor(j/2))<=p^d. The remaining d<floor(r/2) case has R(j)=0<W(floor(j/2)). This proves the strict cap uniformly, including p=3.

Insert this cap into the original Newton formulas (before specialization and before reduction):

H_j=sum_(ell=j mod2) w_j N_ell/[w_ell Q_((j-ell)/2)],
H_j'=sum_(h,d;d>=1;h+d<=j;j-h-d even) w_j z^(d-1)N_h/[w_h Q_((j-h-d)/2)(1-q^d)],

where Q_b=product_(v=1)^b(1-q^(2v)) and N_h=product_(v=0)^(h-1)(z+q^v). The interval cap applies in every disk and in both q and q^-1 orientations. The exact inequalities

V(2v+1)-W(v)<=p, equality only at v=(p^2-1)/2;
V(2v+1)-W(v+1)<=p-1;
V(v)-W(v)<=0

give weight(P_j)>=h_j, weight(P_j')>=h_j-p for odd j, and >=h_j-(p-1) for even j. Even P_j has nonzero constant initial equal to its value at zero. These are the same finite-score statements proved in the accepted all-even report, Section 4; no new q-derivative is introduced.

For m=cM odd, h_m=G+M. The lower k digits of u=(m-1)/2 are all (p-1)/2. With H=(p^2-1)/2, W(u)=W(u-H)+W(H) and W(H)=p^2-p. In the original derivative formula the unique least term is h=0,d=p^2. Strictness of the deep cap excludes h>0; the score inequality excludes every other d. Its nonzero scalar initial is

P_m' ~ (-1)^u w_m/[(1-q^(p^2))Q_(u-H)]

of value G+M-p. The H/P ordinary chain rule adds only a term with weight >=G+M and unit coordinate factors, so the P derivative has that same exact constant initial. This argument applies also to m=M and p=3.

### 3.2 The unshifted first-deleted tail

Use the exact finite identity, with L=0,

g_m^0=w_m sum_(ell=1)^m (-1)^(ell-1)q^(ell(ell-1)/2) P_(m-ell)(q)P_(ell-1)(q^-1)/[w_(m-ell)w_(ell-1)(1-q^ell)].

For odd ell the two polynomial indices are even. Their floor indices sum to u, so their term weight is at least

cA-G-V(ell)=G+M-V(ell)>=G.

Equality requires ell=bM with b odd. Both even polynomial initials there are constants. All other odd ell have a positive gap. For even ell the two polynomial indices are odd; their floor indices sum to u-1, with W(u-1)=G-1. Their term weight is therefore at least G+M+1-V(ell)>=G+1.

Thus the entire weight-G initial is a constant. It is nonzero: exactly g_m^0(0)=(-1)^u Q_u, which has value G. Derivatives of odd-ell products lose at most p-1, and derivatives of even-ell products lose at most p. Consequently weight((g_m^0)')>=G-(p-1). This proves all four unshifted assertions without guessing or omitting any internal M-block endpoint.

### 3.3 The actual outer shift

Let eta=product_(j=1)^m(1-q^(2N+j))/w_m. Each shifted edge has the same V-value and leading unit as its unshifted edge, and v(eta-1)>=N-M.

The exact associated connection for f is

f_m^L=C_m^L sum_(d=0)^m [(1-q^L)/(1-q^(L+d))] (-1)^d q^(d(d+1)/2) P_(m-d)(q)P_d(q^-1)/[w_(m-d)w_d],

with d=0 ratio interpreted as 1. For odd m, the two floor indices sum to u for either parity of d. Every d>0 correction therefore has weight >=G+N, and its ordinary derivative has weight >=G+N-p. Hence f_m^(2N)=eta P_m+Delta_f with precisely these bounds.

In the g identity subtracting eta*g_m^0 replaces (1-q^ell)^-1 by

(1-q^(2N+ell))^-1-(1-q^ell)^-1,

of exact value N-2V(ell). The same odd/even floor-index calculation gives weight(Delta_g)>=G+N-M and weight(Delta_g')>=G+N-M-p. Since N-M>1, neither error can alter (3.1). These are relative mixed-characteristic bounds, not a claim that a total tail weight is below e. No replacement of the actual shifted tail by an unproved approximation is made.

## 4. Counts before simplicity

Let F_b be the exact Gauss weight of f on D_b. From (3.1), F_b>=G+M. For any polynomial on a radius-rho disk, ordinary differentiation satisfies weight(f')>=weight(f)-rho, because every integer multiplier has nonnegative valuation. Therefore

F_b<=G+M-p+rho<G+N/2.

The strict inequality follows from M<=N/p^2 and rho<N/p: 1/p^2+1/p<=4/9<1/2.

The exact original transfer is P_n=fC-b0gB. The first product has exact weight F_b+K. The second has weight at least N+G+E=G+K+N/2, strictly larger. Thus the original root initial polynomial is the PRODUCT f_initial*(Z^2+1), up to nonzero units.

No coprimality of those two residual factors is assumed. Even if they share residual roots, the product degree/order gives at least 2L boundary roots in that disk, with multiplicities counted. Across beta disjoint disks there are at least 2N such roots. The inequality does not assert exactly 2N; extra tail roots may lie on those boundaries, as the accepted n=513 example demonstrates.

## 5. Denominator-free derivative comparison and the amplitude parameter

Take any P_n root xi on any old r-boundary. Its normalized disk coordinate is nonzero, so B(xi) has exact value E. Also g(xi) has exact value G. The root identity fC=b0gB therefore makes BOTH f(xi) and C(xi) nonzero. Define the finite actual amplitudes

 delta=v(f(xi))-G>=M,
 gamma=v(C(xi))-K>=0.

The exact root identity gives delta+gamma=N/2. This records the actual lifting amplitude, not just a vanishing residue. In particular a common tail/core residual class is not discarded or treated as a characteristic-zero collision.

Differentiate the ORIGINAL transfer before reduction:

P_n'=f'C+fC'-b0g'B-b0gB'.

The first term has exact value

D_n=G+M-p+K+gamma.

Relative to that exact value, the other three terms have the following uniform lower gaps:

fC': 2delta-M >= M;
b0g'B: delta-M+1 >= 1;
b0gB': delta-M+p >= p.

These follow directly from (3.1), the full core bounds and delta+gamma=N/2. Thus f'C is uniquely least, so P_n'(xi) is nonzero with EXACT value D_n. This is an amplitude-sensitive next correction: the root equation is used to value C at the NEW root, rather than making the false substitution C=0 or dividing by a possibly vanishing tail residual.

## 6. Actual neighbor, original kernel, and H transfer

The positively oriented continuant identity is

f_m^(2N) P_(n-1)-f_(m-1)^(2N) P_n=b0 product_(j=1)^(m-1)(1-q^(2N+j)) B.

At xi its second term is exactly zero. The product has value W(m-1)=2G. Hence the ORIGINAL immediate neighbor has exact value

E_n=N+2G+E-(G+delta)=K+G+gamma.

Since W(n-1)=2K+2G, the original Christoffel-Darboux formula gives

v(sum_(j<n)P_j(xi)^2/w_j)=D_n+E_n-W(n-1)=M-p+2gamma.

This is finite. No positivity, Hermitian square, or replacement neighbor is used.

All roots reduce to X=0 and are not +/-2, while H_n(0)=1. The actual coordinate identity H_n(v0^2)=v0^n P_n(v0+v0^-1), with its characteristic-zero ordinary derivative and unit factors near v0=i, transfers multiplicity and the displayed derivative values to H_n. Algebraic p-adic embedding and injectivity give the conclusion for every characteristic-zero primitive phase.

## 7. Remaining obstruction and limits

The first new strict argument stops exactly when the core neighbor's boundary initial is zero, or when the root is outside the old r-disk cover. The former occurs at Y=0, not on any old r-boundary. There one cannot set v(B)=E and delta+gamma=N/2; the discarded excess v(B)-E can erase the displayed positive gaps. Outside old disks the imported core bounds are unavailable. A full theorem therefore still requires a root-location and amplitude lemma for the at most M-1 remaining nonzero strict k-interior roots, retaining the actual tail/core/neighbor values.

No remaining root is declared repeated. No residual zero is a characteristic-zero collision. No tiny parameter slice is substituted for the uniform family. No all-A obligation, owner closure, novelty claim, algorithmic speedup, FFT advantage or numerical stability conclusion follows.

## 8. Cost and reproducibility boundary

The mathematical proof uses finite exact identities and uniform inequalities; it does not require constructing the degree-n polynomial, factoring any residual, or enumerating roots. Its theorem is a nonvanishing statement, not a numerical algorithm. The amplitude gamma is defined at the actual root and is not claimed to be cheaply computable.

A direct exact implementation of the certificate inputs can compute V,W and tail score tables through m=cM in O(m log_p m) elementary integer operations, or O(m) after a valuation sieve, with O(m) stored values. Enumerating the full first-derivative minimum pairs by the accepted least-d rule is O(m log_p m). Constructing all recurrence polynomials naively over a coefficient field is O(n^2) field operations and O(n) live coefficients, and this count excludes the coefficient field's bit complexity, cyclotomic representation, precision and algebraic-root handling. Nothing here improves those costs or supplies a uniform bit bound for evaluating gamma.

Fresh controls and exact source pins accompany this report. The normal and optimized outputs are byte-identical: 1,100,754 explicit checks across 69 valuation fixtures and two legal auxiliary finite-phase identity fixtures. Controls test transcription and finite identities, not the all-parameter proof. No historical scientific code is imported or executed.
