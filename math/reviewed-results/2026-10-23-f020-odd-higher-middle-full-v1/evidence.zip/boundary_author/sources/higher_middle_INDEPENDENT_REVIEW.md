# Independent review: higher middle positions, exact partial theorem

Date: 21 October 2026 UTC.

## Verdict and consumption boundary

ACCEPT the uniform partial theorem and exact first-residual criterion/obstructions in the frozen candidate the original candidate identified by the hashes below.

- Candidate MANIFEST.json SHA-256: `7d1176ebd17f037b23bec99f8dfa99d8c657eadd21d8b00339ebef961e1d40f7`.
- Candidate REPORT.md SHA-256: `77e5786ff256f73a487eebb0a562be9e1f6fda68e60c941c01d97bc10ba082c3`.
- Essential mathematical repair required: NO.
- Full-family squarefreeness or full-family kernel nonvanishing established: NO.
- This acceptance is for these exact bytes and this exact partial scope. It does not transfer to modified or publicly transformed packages.

The scope is every odd prime p, 1 <= c < p, 2 <= k <= r-2, s > r, n = 2p^r + c p^k, and every primitive characteristic-zero q of order p^s. The original recurrence, ordinary derivatives, original immediate neighbor, and algebraic-square kernel are retained.

The accepted conclusions are the complete k-scale root-count ledger, simplicity and exact original derivative/neighbor/kernel values for all (c-(c mod 2))p^k lower-boundary roots, the simple exact zero and its data for odd c, the nonzero constant and complete high-root location ledger for even c, and the stated arithmetic first-residual criterion. The reported obstruction and nested examples are exact leading-order facts, not counterexamples in characteristic zero.

This review does not accept full simplicity of the 2p^r even-c high roots or the general 2p^r+p^k-1 odd-c nonzero interior roots. In the explicit n=513 example, the additional two simple roots reduce the latter unresolved count from 512 to 510. No whole-owner F020/F023 closure, historical novelty, FFT/cost/stability gain, publication, or repository action follows.

## Method and independence

The review inspected the entire uniform argument, reconstructed the arithmetic inequalities and equality cases, and used newly authored controls. No candidate or supplied scientific program was executed or imported. Reading program bytes for SHA-256 inventory checks is not execution. The sole scientific import in this review is a reviewer-written module imported by another reviewer-written control.

The three paired normal/-O evidence sets are byte-identical. They contain 2,783,609 explicit checks: 2,765,511 arithmetic/residual/source checks, 17,761 additional geometry/gcd/all-order checks, and 337 exact-identity and normalization-negative checks. These are falsification and transcription controls. Universal acceptance rests on the uniform proof analysis below, not on the finite grid.

## 1. Legal specialization and the original identities

The strict degree gate is valid at the largest allowed c and k:

n <= [2 + (p-1)/p^2]p^r < p^(r+1) <= p^s.

In particular, every edge and factorial used in a finite coefficient identity is nonzero. With t=q-1 and v(t)=1, the leading term of 1-q^j is -(j/p^ord_p(j)) t^(p^ord_p(j)), for the relevant nonzero differences. This follows from the binomial expansion at q=1 and v(p)=(p-1)p^(s-1). It is expressed relative to the actual chosen q-1, so the residue calculations do not acquire an untracked phase factor.

The generating-series relations used in Section 2 yield the original Newton sum and its ordinary derivative. They are formal rational identities before specialization. In particular, differentiating log J(zu) produces z^(d-1)/(1-q^d), not a q-integer multiple or an inseparable residue derivative. The sign z^(d-1) reduces to (-1)^(d-1) on the stated disks.

The Gaussian map H_b(v^2)=v^b P_b(v+v^-1) agrees with the given P recurrence. Its differentiated identity has the ordinary chain-rule factor (v-v^-1)/2. Near v=i this is a unit because p is odd. At a root the additional bP_b/2 summand is exactly zero. The original immediate neighbor also transfers by a unit. Thus the reported valuations are for the original objects, not a replacement normalization.

The monic three-term recurrence gives the diagonal identity

sum_(j<n) P_j(X)^2/w_j = [P_n'(X)P_(n-1)(X)-P_n(X)P_(n-1)'(X)]/w_(n-1).

At a root this is exactly the kernel formula used in the candidate. The recurrence also proves consecutive coprimality by backward propagation through nonzero edges. It does not by itself prove P_n squarefree.

Independent exact controls compare polynomial coefficients at rational q=2,-2,3/2, through degree 14. Additional controls use legal auxiliary prime-power phases at degrees 171,180,513,540,1275,1300. Neither auxiliary finite characteristic nor those sample degrees substitute for the characteristic-zero theorem. Negative controls reject q-derivative, shifted-neighbor, and absolute-square replacements.

## 2. The cap and mixed-block inequality

Write M=p^k, h=floor(k/2), and R=W-T at the proposed radius. The floor-sum formulas make W and R additive in base-p digits. Evaluating at each digit basis p^b gives the strict R(j)<W(j)/2 for 0<j<M and equality at M. Both choices of k parity give the displayed basis formula; no step replaces the prime p by a composite M.

Splitting an interval at multiples of M gives

W(uM+v)=u(W(M)-M)+M W(u)+W(v),
R(uM+v)=u(R(M)-M)+M W(u)+R(v).

For a reflected partial terminal block, its endpoint contributes M V(Q-B)-rho; the remaining proper offsets have the valuations of 1 through b_0-1. This proves the candidate's exact equation (3.3), including the case where the endpoint has valuation strictly larger than M.

For d=lM+v and a=uM+w, write v+2w=epsilon_0 M+b_0. In (3.4), the only quotient inequalities needed are

W(Q)-W(Q-B) >= W(B) >= W(l)+2W(u)+epsilon_0,

where B=l+2u+epsilon_0 and epsilon_0<=2<p. Substituting the two block formulas gives precisely the proposed lower bound, with no missing quotient or carry term. This remains valid for arbitrarily large r and k.

The local reflection inequality deserves particular care at p=3. For nonzero v and t=v+2w not divisible by M, set J=ceil(t/M) and j=JM-t. Then J<=3, and

W(JM-v)=J W(M)-M-W(v-1).

When J=p=3 this identity is still true: W(pM) is NOT pW(M), but W(pM)-V(pM)=pW(M)-M. The extra carry and endpoint valuation cancel in this difference. Thus the proof does not silently use a false carry-free W(pM) formula. Combined with R(j)<W(j)/2, it gives the required strict local bound. When t is a multiple of M, the exact reflection formula for W(2w) gives the weak version, with equality precisely when doubling w has no carry. The d=0 case is strict for every w>0.

This establishes the uniform inequality and the relevant equality mechanisms, including the p=3 endpoint, all k parities, and the top digit c=p-1.

## 3. Equality positions, ordinary derivative, and Hermite units

For the root score, equality forces w=0 and W(u)=u, hence u<p. The remaining quotient interval must contain no multiple of p. Since Q mod p=c, this is equivalent to 2u<=c. These are exactly j=2N+(c-2u)M.

For the derivative, the maximized local denominator benefit is

V(v)-W(v-1)/2.

At fixed p-adic order it is uniquely largest at v=p^b. The resulting g_b has its unique global maximum p at b=2. This fact includes p=3. The divisible-M and nondivisible-M cases cannot be combined by replacing p with M:

- If v>0, equality requires k>=3, l=0, v=p^2, and v+2w=M. The no-carry condition holds at w=(M-p^2)/2.
- If v=0, equation (3.5) is sharp only for k=2 and l=1; equality further requires w=0. Again d=p^2.

The quotient interval then has length 2u+1 and must avoid multiples of p. Therefore all and only the pairs in (4.4) attain equality. This proves the ordinary-derivative weight D=K+M/2-p, not a spurious K+M/2-M value.

The neighbor argument is the d=1 root-score comparison without subtracting V(1). Its equality position is w=(M-1)/2 and it uses W(n-1)=W(n)-M. The exact neighbor weight is E=K-M/2.

For a shifted k-disk, the count of multiples of each relevant p-power in an interval of length j gives T_a(j)>=T(j). Every equality index is a multiple of M and attains the bound at every allowed center. The complete blocks have L boundary factors and a nonzero constant product from the other factors.

The block unit ratios follow by separating proper offsets from the endpoint of each M-block. Proper offsets keep their initial units under the shift; endpoint hM contributes the factor h relative to the first block. Thus w-block ratios give j!, Q-block ratios give 2^u u!, including the partial offset (M-p^2)/2. All factorials remain units because the relevant counts are below p, including c=p-1.

Consequently the root residue is a nonzero multiple of Y^(2N/beta) M_c(gamma Y^L), while the ordinary derivative and original neighbor residues are nonzero multiples of Y^(2N/beta) M_(c-1)(gamma Y^L). The ordinary derivative is obtained before reduction; the root residue is not differentiated. Coprimality of consecutive M_j follows recursively since 1,...,c-1 are units, and M_c'=c M_(c-1). This proves the needed nonvanishing on the nonzero Hermite root locus.

Independent controls reproduce the complete score equality sets in 60 parameter fixtures and the actual three residual polynomials, up to the stated nonzero scalar, in 118 k-disks. Direct full-d sums and the omitted-d reduction agree in all 18 independently tested smaller disks.

## 4. Root counts, boundary simplicity, and exact kernels

The k-disks are disjoint because their different centers have distance valuation at most p^(h-1)<rho. The exact initial polynomial has degree n/beta and order (2N+(c mod 2)M)/beta at Y=0. Polynomial Newton/Weierstrass counting gives the closed, strict-interior, and boundary counts with multiplicity. Summing closed-disk counts gives n, so no original root is omitted.

At a boundary root, Y is nonzero and the consecutive Hermite residual is nonzero. Therefore the ordinary derivative and original neighbor have exactly D and E. This proves actual characteristic-zero simplicity even though the reduced root polynomial is generally inseparable. No simple-root Hensel argument for a Frobenius-composed residual is used.

The CD valuation simplifies to

D+E-W(n-1)=M-p-2N(r-k)(p-1)/p.

Its possible negativity is not a defect. Nonvanishing is the relevant conclusion. At unresolved roots consecutive coprimality still makes the neighbor nonzero, but does not fix its valuation or settle the derivative.

## 5. Exact zero and even-c high locations

For even c the exact Newton evaluation at -1 is w_n/Q_(n/2). Its valuation is W(N)+cW(M)/2, so P_n(0) is not zero.

For odd c the derivative at -1 contains precisely the odd-d, m=0 terms. At each fixed order of d, the denominator score strictly decreases when d increases, because W((n-d)/2) strictly decreases. Thus the smallest eligible d=p^b is the only contender for that order. The digit formulas for these contenders are exactly C+g_b for b<=k and C-(N-M)+g_b for k<b<=r. The unique maximum is at b=2. The unique leading term cannot cancel.

This proves the exact zero is simple, with the displayed D_0 and E_0, and D_0+E_0-W(n-1)=M-p. The direct even-neighbor product agrees. The all-order score formulas were additionally checked independently for 15,810 parameter/order choices, without treating that grid as proof.

For even c at r-scale, R_r(j)<=W(j)/2 below n, with equality precisely at multiples of N. Parity removes j=N; only j=0 and 2N remain. The carry-free halves attain the bound. The block unit calculation gives the genuine two-term M_2 residue, not merely its support. It has degree 2L_r and nonzero constant, so every r-disk has 2L_r boundary roots and no strict-interior roots.

There are exactly 2N such roots, matching the k-scale interior ledger. Each r-disk lies strictly in its appropriate k-disk: both its radius and the inter-center valuation exceed rho_k. This proves location and counting, NOT simplicity. I independently checked the two-term coefficient ratio and nested containment in 378 high disks, covering both r parities and multiple k positions.

No corresponding uniform flattening of odd-c interior geometry is accepted or needed.

## 6. Exact phase-independent residual criterion and cancellation

The units in (8.1)-(8.2) are correct. In N_j, q^i-q^a contributes (i-a)/V(i-a), whereas w and Q contribute negative units. For the ordinary derivative, both (-1)^(d-1) and the denominator unit -d/V(d) must remain; the proposed formula retains both.

At fixed m and ord_p(d), parity makes the least allowed d either p^j or 2p^j. Every larger eligible d at that order has strictly smaller W((n-m-d)/2), hence strictly larger term valuation. It cannot be among the minima. This justifies the optimization without changing the exact residual.

A nonzero sum of the minimal coefficient initials is the exact initial polynomial. A zero sum is only a strict lower bound. The candidate handles identically-zero root/derivative/neighbor residuals correctly and makes no count or equality from a zero polynomial. For a nonzero root residual, its degree and zero order give the disk counts; evaluation of the separate derivative and neighbor residuals gives equalities precisely on their nonvanishing loci. Gcd detects the failed first test, not actual repeated characteristic-zero roots.

The data depend only on integer valuations and prime-field units relative to t=q-1. Subject to the stated legal index/radius hypotheses, no chosen s or characteristic-zero phase enters the arithmetic test.

I recomputed all 28 all-center obstruction rows from scratch, matching every weight, minimal-index set, and polynomial. Independently computed gcd degrees also match. In particular:

- n=171 and n=180: the ordinary derivative and neighbor first residues vanish on the entire old high-root boundary locus, at all nine centers.
- n=513: the central disk has 56 boundary roots and one strict-interior root. The two roots with Y^2=1 have nonzero derivative and neighbor residues, with kernel valuation 24; the other 54 central boundary roots are on the unresolved leading obstruction. The remaining eight old disks have 54 roots each. Thus the old disks contain 489 roots and 24 roots remain outside them but inside the k-cover.
- p=5,r=4,k=2,c=2: the four minimal derivative pairs (0,2),(0,10),(1250,2),(1250,10) cancel identically at formal weight 2714. This is strict lower-bound information, not an equality.

These failures do not imply characteristic-zero multiplicity. They precisely explain why the first-residual argument cannot settle the full family.

## 7. Scope and inherited-credit audit

The candidate's selected source snapshots are byte-identical to the cited originals. I checked all 35 candidate payloads, the exact candidate inventory, 16 source snapshots, four original manifest pins, and 168 payload pins in those four source inventories.

The prior all-r accepting review covers k=1, n=2p^r+cp. Its manifest is `2b565308b16423106b40a397d39208ceba85638eeea39573b873c7b5cbc17b24`; its accepted candidate manifest is `4b111627d15ef5c485d5c290ea3f0f045d87d405c12f8bcd3156795d24a3d5e4`.

The two-digit-window accepting review covers n=2p^r+t with 0<=t<p^2. Its manifest is `b4e795ea7d9dfd445bbd054e6f1d24fcec61a4374a3fc4d26684139ce3641311`; its accepted assembly manifest is `aefea5c4cd53eca9d1b4760bc1c567e15b8c0ddbc6b5f04275c8dc51c11ba51e`.

Those scopes do not include the present c p^k>=p^2 offsets. No k=1, c=0, or already accepted low-window result receives new credit here. No unproved shifted-tail or odd-leading theorem is silently imported. The uniform proof is self-contained for the accepted partial conclusions. This source audit is not a new proof of the inherited theorems and makes no historical priority claim.

## Final disposition

The exact partial theorem, its root-count accounting, and its first-residual obstruction criterion are accepted without essential repair. The unresolved high/interior problem is genuine and remains explicitly open. The paired reviewer evidence corroborates the proof, and the original normalization is preserved throughout.
