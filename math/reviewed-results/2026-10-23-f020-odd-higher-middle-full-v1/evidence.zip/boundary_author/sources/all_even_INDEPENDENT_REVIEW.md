# Independent review: even middle coefficients beyond two

22 October 2026 UTC.

## Verdict and exact consumption boundary

ACCEPT the new uniform family in the exact frozen candidate `source://author`.

- Candidate MANIFEST.json SHA-256: `651da609bc5b0494d7841d6605ff1c0f1a63a85fa94babcd8d5193a707618fd3`.
- Candidate REPORT.md SHA-256: `67f8beb9f3971909f0f2332c4b58a55d7d1673763c29ae947533a9f6de4f4a71`.
- Essential mathematical repair supplied by this reviewer: none.
- Essential gap identified within the exact claimed family: none.
- This acceptance binds those bytes, not a later edit or a transformed package.

The scope is: every odd prime p, every even integer c=2a with 2<c<p, every integer k>=2, r>=k+2, s>r, n=2p^r+c p^k, and every characteristic-zero primitive p^s-th phase q. With M=p^k, N=p^r, A=W(M), K=W(N), and v(q-1)=1, every one of the 2N high roots is simple and has

    v(P_n') = K+N/2+aA-p,
    v(P_(n-1)) = K+N/2+aA-M,
    v(sum_(j<n) P_j^2/w_j) = N-p.

Here P is the ORIGINAL recurrence, the derivatives are original ordinary characteristic-zero derivatives, P_(n-1) is the actual immediate neighbor, and the kernel is the ORIGINAL algebraic-square kernel. There is no conjugation or replacement normalization.

The accepted higher-middle partial theorem supplies the other cM simple lower-boundary roots and their stated values. The disjoint counts total n, the even constant is nonzero with value K+aA, and P_n and H_n are squarefree throughout this exact family. Ordinary H root-derivative values equal the P values.

The genuinely new eliminated unit is

    Lambda_a = 4^a / binom(2a,a) in F_p,

not a+1 and not a copied constant 2. The complete tail initial is tau_a=1-Lambda_a, which can be zero. In particular (p,c)=(5,4) gives tail initial 0 and eliminated initial 1. Acceptance does NOT include an assertion that the tail derivative always has exact value -p.

The c=2 result is credited inheritance, not new work. The new p=3 range is empty. Whole F020/F023, odd c, c>=p, k<2, r<k+2, s<=r, arbitrary degrees or orders, FFT superiority, complexity/stability consequences, historical priority, and publication remain outside this acceptance.

## Independence, evidence, and source preservation

I read the complete new proof and the actual inherited leading-core and higher-middle reports and accepting reviews, together with the c=2 proof/review and the credited ternary finite-connection argument. I reconstructed the mathematical steps below rather than treating producer check counts as proof. No supplied scientific program, including any copied candidate or predecessor program, was executed or imported. Source programs and cache files were handled only as inert bytes for hashing and preservation. All mathematical controls in this review were newly written.

The fresh arithmetic and rational identity controls use exact integers, fractions, and modular products. The direct recurrence controls propagate the original ordinary X derivatives before substitution, which is independent of the producer's z-derivative/conversion implementation. Full F_p[u,Y] disk controls are distinguished from F_p[u] point controls. Every formal diagnostic uses an explicitly checked precision strictly below its actual mixed-characteristic ramification threshold. The finite controls are falsification/transcription evidence, not the all-parameter proof.

The new candidate's complete inventory is exact and all its pinned bytes are unchanged. All manifest-pinned payloads in the eight cited source inventories are intact, and the documentary snapshots equal their actual source files. There is one precisely limited directory-membership caveat: the credited ternary author's directory also contains two unlisted files:

- `__pycache__/explore_tail.cpython-312.opt-1.pyc`
- `__pycache__/explore_tail.cpython-312.pyc`

Each is 6,639 bytes with SHA-256 `037e7266f68c79ed7a614aa32eff623204863cac0b1d0a6b17719912fd07c5ea`. They were observed separately, preserved, and never executed or imported. No inference is made about when or why they appeared. That older directory is NOT described as a clean exact inventory. Its manifest-pinned proof and accepting review remain unchanged; this caveat does not create a mathematical gap in the inherited theorem or the independently rederived finite identities. SOURCES_BEFORE.json and SOURCES_AFTER_OPTIMIZED.json separately record pinned payloads, actual membership, inert extras, and matching whole-directory digests.

No frozen source was edited, no external state was changed, no file was uploaded, no repository action occurred, and no subdelegation was used. The candidate is preserved again in `candidate_snapshot/` as inert documentary evidence.

## 1. Legal indices and exact inherited scope

The degree satisfies

    n <= [2+(p-1)/p^2]N < pN <= p^s.

Every relevant positive recurrence edge, factorial exponent, shifted denominator, and finite coefficient specialization is therefore legal. The signed differences used for inverse parameters also have nonzero absolute index below p^s. In the actual mixed-characteristic field, with the actual t=q-1,

    v(1-q^j)=V(j),
    (1-q^j)/t^V(j) -> -j/V(j),
    e=v(p)=(p-1)p^(s-1).

The unit formula concerns individual legal factors; it does not require the weight of a product to be below e. That distinction is essential when k is unbounded.

The higher-middle author manifest `7d1176ebd17f037b23bec99f8dfa99d8c657eadd21d8b00339ebef961e1d40f7` is bound by accepting review manifest `11abe81e31c14ea6642d19e7d1896273431eaa1e925c93cbdacd6fc30a236af2`. Its hypotheses are all odd primes, 1<=c<p, k>=2, r>=k+2, s>r, so the specialization here is legal. For even c it gives exactly cM simple lower-boundary roots, with J=(N/M+a)A and values

    D_low=J+M/2-p,
    E_low=J-M/2,
    kernel_low=M-p-2N(r-k)(p-1)/p.

It also supplies the complete 2N-root high cover, initially with multiplicity, strict nesting and disjointness, and the nonzero even constant. It explicitly did NOT prove high-root simplicity. The new proof discharges that exact missing obligation.

The leading-core author manifest `e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7` is accepted by review manifest `a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7`. Its Sections 2–5 prove coefficientwise full-disk statements for C=P_(2N), B=P_(2N-1), E=K-N/2:

    weight(C)>=K, weight(B)>=E,
    weight(C')>=K+N/2-p, weight(B')>=E.

The relevant residuals of C, B, C' are nonzero scalar multiples of Z^2+1, Z, Z. These are not restricted to exact C roots. Its later adjacent-degree criterion is not imported. The required original derivative and neighbor scalars are actually present in the source.

The c=2 author/review manifests are respectively `c1599e66cdec763f9c66e0d7e7491eff3765f4aa64392a4379388087b5e2e26d` and `a072aecd19addec60eddd9bd1e5358211362d3ce779f6ec5c47128be9500905b`. They receive credit for the earlier mechanism, not authority for unproved general-c units. The new proof rederives the c-dependent parts.

## 2. Strict deep cap through every j<pM

Put h=floor(r/2), use the stated even/odd r-radius rho, and set T(j)=sum min(V(u),rho), R=W-T, S=W/2-R. The exact floor formulas imply additivity in the base-p digits. At a digit p^d,

    S(p^d)=W(p^d)/2, d<h;
    S(p^d)=(r-d)(p-1)p^(d-1)/2, h<=d<=k.

The second formula includes the additional term in the odd-r radius. Replacing an odd radius by the even one would not justify it.

For j=2u+epsilon with epsilon in {0,1}, the floor difference at each p-power is 0 or 1. Thus

    W(j)-2W(u)<=p^d,

where d is the highest base-p position of j. If j>=2 and d<h, R(j)=0<W(u). Otherwise j<pM implies d<=k. All digit contributions to S are positive, so

    S(j)>=(r-d)(p-1)p^(d-1)/2
        >=(p-1)p^(d-1)>p^d/2.

The last strict inequality uses p>2. Combining the inequalities gives R(j)<W(floor(j/2)) for every 2<=j<pM. At j=0 and 1 equality is immediate. This is a uniform proof of the enlarged range, including the endpoint c=p-1, both r parities, h>k, and arbitrarily large k.

For a shifted disk, the Gauss weight of each N_j factor is the capped valuation of its signed index offset, with the cap used at offset zero. Any interval of j consecutive indices has at least floor(j/p^b) members of each relevant residue class. Summing the positive divisibility-level contributions gives weight(N_j)>=T(j) at every center. Reverse orientation gives the same inequality for q^-1 on the same X-disks. It is not enough to check only the central disk; the proof and fresh controls do not do so.

The positive floor coefficients also show W superadditive. Equality is precisely carry-free base-p addition: every actual carry produces a positive strict contribution at its level.

## 3. Original short-polynomial bounds and all required odd pivots

The displayed Newton and derivative identities follow over Q(q) from J(qu)=(1-u)J(u), J(u)J(-u), and J(zu)/J(-u). The logarithmic derivative contributes z^(d-1)/(1-q^d). This is ordinary differentiation before finite coefficient extraction and specialization, not differentiation of an inseparable residual.

For h_j=W(j)-W(floor(j/2)), the cap and superadditivity give the original polynomial bound h_j. If j is even, only the Newton term ell=0 can attain equality, so the normalized initial is the actual nonzero constant at X=0. This proves f=P_(2aM) has exact value aA throughout every old disk and a normalized analytic inverse.

To audit all ordinary derivative terms, fix b=ord_p(2u+1). Strict increase of W makes V(2u+1)-W(u) uniquely largest in that order at u=(p^b-1)/2. The values are 1 for b=0 and

    g_b=[p-b(p-1)/2]p^(b-1), b>=1.

Here g_1=(p+1)/2<p=g_2, while g_(b+1)-g_b is negative for every b>=2. Thus the unique global maximum is p, at H=(p^2-1)/2. Subtracting V(u+1)>=1 gives the even-index bound p-1; V(u)<=W(u) handles the even-d parity. Combining these with the cap in all four m,d parity combinations proves the claimed ordinary derivative bounds h_j-p for odd j and h_j-(p-1) for even j.

The H/P ordinary chain rule has the extra jP_j/2 term. Its weight is at least h_j, so it cannot interfere with these lower derivative weights. The coordinate multipliers are units because p is odd.

The required expanded endpoint list is exactly

    j=dM, d odd, 1<=d<=2a-1;
    j=dM-1, d even, 2<=d<=2a.

For j=2u+1, the low k digits of u are respectively all (p-1)/2 or all p-1. Subtracting H, which has digits (p-1)/2 in its first two places, introduces no borrow. Hence W(u)=W(u-H)+W(H), W(H)=p^2-p, including k=2. The score equality requires d=p^2, and the strict cap for even m excludes every m>0. Therefore the only least-weight original derivative term is (m,d)=(0,p^2), yielding

    P_j'(X;q) ~ (-1)^u w_j/[(1-q^(p^2))Q_(u-H)].

Its initial is a constant on the entire disk. It is not merely its value at an old root or one center. For q^-1, rewrite each edge 1-q^-b=-q^-b(1-q^b). The complete sign exponent becomes j-1+H, which is even. Thus its rewritten derivative scalar has sign +1 up to a q power of residue 1. This independently checks the inverse-parameter sign on both prime congruence classes.

## 4. Exact finite associated connection

Starting with the associated recurrence in z, its generating series satisfies

    b S_b(qu)=(1-u)(1-zu)S_b(u)-(1-b).

Writing S_b=H T_b and using H(qu)=(1-u)(1-zu)H(u) gives the coefficient ratio (1-b)/(1-bq^d). The inverse-series coefficient is

    (-1)^d q^(d(d+1)/2) H_d(z;q^-1)/w_d(q).

This proves the f connection as a finite rational identity after setting b=q^L and converting coordinates. The removable d=0 ratio is exactly 1; at L=0 the d>0 ratios are zero. Applying that formula to g_m^L=f_(m-1)^(L+1) and cancelling scalar factors gives the stated g connection and its precise reciprocal edge 1/(1-q^(L+ell)). Every denominator is legal. No infinite analytic product is specialized at a root of unity.

Fresh whole-polynomial rational checks compare these connections and their actual ordinary derivatives with independently generated original continuants. The check also keeps the exact transfer, positive immediate-neighbor determinant, and denominator-cleared off-root elimination identity. Finite rational fixtures corroborate the algebraic identities but are not their universal proof.

## 5. Every internal endpoint and its equality cases

In the unshifted g connection the two floor indices sum to aM-1. Since W(aM-1)=aA-M, the ell summand has weight at least

    aA+M-V(ell)>=aA.

For ell<=2aM<pM, the only possible equality indices are ell=bM, 1<=b<=2a. All of them attain equality. For b=2h+1, the low-digit halves are both d_0=(M-1)/2, whose sum M-1 has no carry; the top digits sum to a-1<p. For b=2h, the two terms are (a-h)M and hM-1, also carry-free. Every other ell has V(ell)<=M/p, hence a strict gap at least M-M/p.

Each product has one odd and one even polynomial. Differentiating the odd one can lose p; differentiating the even one can lose at most p-1. Exactly 2a differentiated summands can therefore contribute at aA-p:

- ell=(2h+1)M, 0<=h<a, differentiating P_((2a-2h-1)M)(q);
- ell=2hM, 1<=h<=a, differentiating P_(2hM-1)(q^-1).

The f'/f correction in (g/f)' has weight at least -(p-1), so it cannot contribute at -p. Dropping internal endpoints or replacing the tail by a shifted length-2M tail would discard contributions of the SAME leading weight. The fresh raw-factor controls construct each term before its simplification and retain all endpoints.

## 6. Raw factor units, actual denominators, and the new sum

Put b=(p-1)/2, H=(p^2-1)/2=bp+b, and U(v)=product_(j<=v) j/V(j) in F_p. Pairing the two halves of Wilson's product gives (b!)^2=(-1)^(b+1). Separating multiples of p gives U(H)=(-1)^b(b!)^2=-1. Similarly U(p^2-1)=1. H is divisible by 4 and by p-1, so the normalized odd and even products in 1,...,p^2-1 both equal -1.

For either endpoint form of u, the numerator of

    J_u=Q_u/[(1-q^(p^2))Q_(u-H)]

has proper offsets strictly below p^2<=M. Its actual signed edge units are +j/V(j), or +2j/V(j), respectively. Its weight is p^2-p and its unit is -1. The denominator has weight p^2 and unit -1. Hence J_u has value -p and normalized unit +1 at EVERY internal endpoint, not only the last one.

For v<p and d<M in the relevant ranges, removing complete M-blocks leaves all proper-offset units unchanged, while the successive endpoints contribute their block numbers. Thus

    Q_(vM+d)/(Q_M^v Q_d) -> v!,
    W(vM+d)=vA+W(d).

The half-block quotient is equally important. Removing p-multiples recursively gives U(M)=(-1)^k and U(d_0)^2=(-1)^(k(b+1)). As d_0 has parity kb, the exact unit is

    Q_M/[Q_(d_0)^2(1-q^M)] -> 2(-1)^d_0.

Substitute the original even constants, the unique ordinary odd derivative scalar, the sign from the g connection, and the sign of the actual f(0). The resulting contributions are

    A_h=-2a(-1)^h binom(a-1,h)/(2h+1), 0<=h<a;
    B_h=(-1)^(h+1)binom(a,h), 1<=h<=a.

The odd denominator is at most 2a-1<p. The factorial factors also involve only integers less than p. No exceptional allowed prime is lost through division. The independent raw calculation does not use these formulas to construct the factors: it multiplies the signed q and q^-1 edge units and the original pivot denominators first, and only then compares the results.

The even sum is 1. For the odd sum,

    I_a=sum_(h=0)^(a-1) (-1)^h binom(a-1,h)/(2h+1)
       =(2a-2)!!/(2a-1)!!,
    2a I_a=4^a/binom(2a,a).

The finite rational identity follows, for example, by coefficient integration of (1-x^2)^(a-1) and the recurrence (2a-1)I_a=2(a-1)I_(a-1), I_1=1. This is an identity in Q before reducing mod p. Every relevant denominator is a p-unit since 2a<p. Therefore

    t^p R_0' -> 1-4^a/binom(2a,a)=tau_a.

The rational sum is independently verified exactly through a=300; the proof, not that cutoff, gives all a.

For c=4 the ordered terms are -4, 2, 4/3, -1. At p=5 they reduce to 1,2,3,4 and sum to 0. The theorem correctly interprets this as a STRICTLY higher tail derivative weight, while Lambda_2=8/3 reduces to 1. At c=p-1, Lambda_a=(-1)^a: the tail vanishes for p=1 mod 4 and equals 2 for p=3 mod 4. In both cases elimination stays nonzero. Additional zeros, such as (11,6), are retained. A guessed a+1 does not reproduce the units.

## 7. Actual outer shift and differentiated relative errors

Set L=2N, m=2aM<N. For every 1<=j<=m, V(L+j)=V(j), and the shifted/unshifted edge quotient differs from 1 by a term of exact value N-V(j)>=N-M. Therefore eta_L is a unit and eta_L-1 has value at least N-M.

In the f connection, every d>0 coefficient gains N-V(d). For even d the two floor indices sum to aM; for odd d they sum to aM-1. The proven short-polynomial bounds and superadditivity give Delta_f weight at least aA+N-M. Differentiating the ORIGINAL finite polynomial products gives Delta_f' weight at least aA+N-M-p.

In the g connection, the difference of reciprocal edges has numerator q^ell(q^L-1), so its exact value is N-2V(ell). The two floor indices sum to aM-1, giving Delta_g weight at least aA+N-M and Delta_g' weight at least aA+N-M-p. These derivative bounds are not inferred by differentiating an unspecified small error.

The exact numerator of R_L-R_0 is Delta_g f-g Delta_f. Its weight is at least 2aA+N-M and its original derivative weight is at least 2aA+N-M-p. The denominator f_m^L f has value 2aA; its logarithmic derivative has weight at least -(p-1). Quotient differentiation proves

    weight(R_L-R_0)>=N-M,
    weight(R_L'-R_0')>=N-M-p>0.

The f denominator remains a normalized analytic unit. Thus the actual outer shift preserves the leading tail initial, even when it vanishes. Internal M-block shifts were NOT discarded through this argument; they were evaluated exactly in the preceding section.

No inequality 2A<N, 2A<e, 2aA<N, or 2aA<e is needed. Such absolute bounds fail for unbounded k at r=k+2. The fresh negative controls explicitly reject the obsolete 2A bounds. The proof uses exact mixed-characteristic factors and relative errors; the separately limited F_p diagnostics do not substitute for it.

## 8. Core unit on the full relevant locus, not at old roots only

The actual inherited H-derivative/neighbor scalar quotient is b_0=1-q^(2N) times

    Q_((N-1)/2)/[(1-q^(p^2))Q_((N-p^2)/2)].

The same proper-offset product calculation gives value -p and unit +1. The original H/P conversion multiplies the derivative/neighbor ratio by 2z/(z-1), whose residue is 1. Its extra ordinary-chain contribution is proportional to N C; after division by b_0B it has weight at least re-N/2>0.

Consequently t^p C'/(b_0B) has initial 1 wherever the core residual Z^2+1=0. On that locus Z is nonzero, B has exact value E, and B'/B has weight at least 0. The proof does not set C=0. Nor does it claim B has an analytic inverse on a disk containing Z=0; the quotient is used on the relevant nonzero residual locus. This is exactly the full-disk information needed at the new roots.

Fresh point controls generate C, its actual original immediate neighbor B, and both ordinary X derivatives directly from the recurrence. They verify the core ratio unit for two phase exponents with a precision strictly below a suitable mixed-characteristic ramification bound. They do not pretend that those points are exact high roots.

## 9. Exact root elimination, actual neighbor, and unchanged CD

The unchanged recurrence gives

    P_n=f_m^L C-b_0g_m^L B.

The correction has weight at least N+aA+E, greater than K+aA by N/2. Thus its high roots lie on the core residual locus, with f_m^L and B nonzero. Counts come from the inherited high cover, or from the same degree-2L_r residual with nonzero constant on each old disk, counting multiplicity before simplicity.

Differentiate the original identity, then use the EXACT root equation to remove f_m^L' times the vanishing root factor. At a high root,

    P_n'=b_0 f_m^L B [C'/(b_0B)-R_L'-R_L B'/B].

After multiplying the bracket by t^p its signed initial is

    1-tau_a-0=Lambda_a.

Since 2a<p, Lambda_a is nonzero. This gives the exact ordinary derivative value K+N/2+aA-p and hence characteristic-zero simplicity. Residual substitution alone would not remove the root-multiple term; the fresh rational checks retain and test the full denominator-cleared identity even off the root.

The positively oriented continuant determinant is

    f_m^L P_(n-1)-f_(m-1)^L P_n
      =b_0 product_(j=1)^(m-1)(1-q^(L+j)) B.

Its sign can be checked already at length one or two and propagated by the recurrence. At a root the second term vanishes exactly. The product has value W(m-1)=2aA-M, giving the actual original neighbor value K+N/2+aA-M. Replacing it by g_m^L or a deleted tail is not permitted.

Differentiating the original recurrence and telescoping gives the full algebraic-square identity

    sum_(j<n)P_j(X)^2/w_j
      =[P_n'P_(n-1)-P_n P_(n-1)']/w_(n-1).

Since W(n-1)=2K+2aA-M, its value at a high root is N-p. No positivity, real orthogonality, interlacing, conjugation, or Fourier argument appears. The rational controls compare all coefficients of the off-root CD identity and reject a wrong neighbor and a modulus-square replacement.

## 10. Shifted-disk geometry, degree exhaustion, and every primitive phase

Distinct r-centers have distance valuation at most p^(floor(r/2)-1)<rho_r, so the disks are disjoint. Match an r-center to its residue modulo beta_k. The inter-center difference has valuation at least beta_k>rho_k, and rho_r>rho_k; hence the entire r-disk lies strictly inside the matched k-disk. The lower roots are on k-boundaries, so the two groups are disjoint.

The counts 2N+cM=n exhaust degree. The exact even constant has value W(n)-W(n/2)=K+aA, excluding zero. Consecutive P polynomials have no common root by backward propagation through nonzero recurrence edges to P_0=1.

These are disks around shifted centers. In a noncentral disk the valuation of X itself can be the smaller valuation of the center. No conclusion that every root has v(X)=rho_r is used or accepted.

Modulo the maximal ideal P_n=X^n and H_n=(1+z)^n. Thus P roots have positive valuation and are not +/-2; H_n(0)=1. Choosing the near-i branch, z=v_0^2 and X=v_0+v_0^-1 are analytic isometries because p is odd. At a root the extra P_n term in the ordinary chain rule is exactly zero. Multiplicities and ordinary derivative values therefore transfer, and the n roots exhaust H_n too.

Every unit calculation is relative to the actual chosen t=q-1 and uses the actual signed factor rule. It therefore applies to every primitive phase and every s>r, not a selected complex or formal phase. The cyclotomic field embeds in an algebraic p-adic closure, and the embedding extends to the splitting field. Injectivity transfers the established characteristic-zero nonvanishing back to the original objects. Finite formal reductions are not the justification for this transfer.

## 11. Independent controls and limits

All scientific failure gates use explicit exceptions, not Python assert. Normal and optimized outputs must agree byte-for-byte before sealing. The result JSONs contain exact coverage and fixture details.

- Arithmetic: 8,600,048 gates; 549 raw signed-factor rows for every allowed new even coefficient at odd primes through 101, with k=3 added through p=11; all 2a endpoint units retained. There are 21 cancellation rows, 30 complete strict-cap grids through pM-1, 80 translated/orientation score fixtures, seven complete associated-endpoint score scans, rational central-binomial sums through a=300, and 54 large-parameter rows reaching k=1000. Every legal m,d ordinary derivative term is enumerated in the selected score fixtures, rather than checking only anticipated pivots.
- Rational identities: 859 gates at q=5/3,-4/3,2/5. Original Newton/ordinary-derivative and Laurent H/P identities through degree 18; both associated connections and derivatives through length 12 with shifts 0,2,7,11; original transfer, positive immediate-neighbor determinant, exact off-root elimination, and algebraic-square CD through degree 21. All polynomial coefficients are compared.
- Formal recurrences: 162 gates across 15 fixtures, comprising six full-disk tail polynomials, five tail points, two actual-shift comparisons, and two original-core/neighbor points. Direct original X recurrence and its ordinary-X derivative jets, with separately labeled full-disk polynomial and point fixtures, actual L=2N comparisons, and direct original-core/neighbor comparisons. FORMAL_NORMAL.json gives the completed fixture list, exact bounds, initial vectors, and cancellation behavior, including p=13,c=12 at a noncentral center. A null observed order means no nonzero coefficient within the stated finite precision, not an assertion that the characteristic-zero derivative is identically zero. Each output threshold is strictly below its checked mixed-characteristic e; int64 accumulation bounds are checked before arithmetic. These are not arbitrary-k proofs or numerical high-root approximations.
- Sources: nine inventories including the candidate, 330 manifest-pinned payloads, 39 exact documentary snapshots, four actual review-to-author acceptance links, and the separately identified inert cache extras. The paired before/after audit establishes source preservation without executing source programs.
- Integrity: six in-memory mutations are rejected: changed proof, missing bound file, unlisted file, seal mismatch, symlink replacement, and fully rehashed replacement under a changed manifest. The external candidate manifest pin is essential to reject the last mutation.

Adversarial mathematical controls reject the guessed a+1 unit, discarded internal endpoints, false universal exact tail derivative -p, illegal denominator extension beyond 2a<p, replacing the p^2 pivot by M, both obsolete absolute cutoffs, confusing a shifted disk radius with v(X), the excluded p=2 cancellation, q-derivatives, a wrong immediate neighbor, associated-g substitution, omitted exact root-multiple elimination, modulus squares, residual-only differentiation, and inadequate mixed-characteristic precision.

Finite coverage does not establish universal quantifiers. Sections 1–10 above audit the uniform proof. The controls only challenge arithmetic, signs, equality cases, branch coverage, implementation, and frozen-byte integrity.

## Final disposition

The new even 2<c<p completion is accepted without an essential repair. The finite tail sum and root-eliminated central-binomial unit are genuinely new relative to c=2, and the canceled-tail branches are correctly included. The inherited theorem supplies exactly the lower roots and geometry it actually proved. All source pins remain intact; the separately observed older cache extras are explicitly disclosed rather than misrepresented. Every excluded parameter regime and whole F020/F023/FFT question remains open.
