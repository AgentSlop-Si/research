# Higher middle positions: uniform boundary theorem and exact residual obstruction

21 October 2026 UTC. Author candidate, not an accepting review. The full squarefreeness question for the stated family is NOT settled by this packet. What is proved is a uniform lower-layer theorem, exact zero/neighbor/kernel data, complete coarse root counts, an even-digit high-root cover, and a phase-independent arithmetic obstruction certificate identifying precisely why a first-residual argument cannot finish the remaining roots.

## 1. Scope, original objects, and outcome

Let p be an odd prime, 1 <= c < p, 2 <= k <= r-2, s > r, N=p^r, M=p^k, and n=2N+cM. Let q be any characteristic-zero primitive p^s-th root. Keep the ORIGINAL definitions

    P_0=1, P_1=X,
    P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_b(z)=sum_j [b choose j]_q z^j,
    w_b=product_(j=1)^b(1-q^j), w_0=1.

All derivatives below are ordinary characteristic-zero derivatives. The kernel is the algebraic-square kernel, never an absolute-square kernel.

In an algebraic p-adic embedding put t=q-1, v(t)=1, e=v(p)=(p-1)p^(s-1), and

    V(j)=p^ord_p(j) for j!=0,
    W(j)=sum_(i=1)^j V(i), W(0)=0,
    B_l=l(p-1)p^(l-1)/2, W(p^l)=p^l+2B_l,
    beta_l=p^floor(l/2), L_l=p^l/beta_l,
    rho_l=beta_l/2                         if l is even,
    rho_l=p^(floor(l/2)-1)(2p-1)/2          if l is odd,
    x_a=i(q^(a/2)-q^(-a/2)), i^2=-1.

Square roots q^(a/2) are near 1. Let epsilon=c mod 2, beta=beta_k, L=M/beta, rho=rho_k, and

    K=(N/M+c/2) W(M),
    D=K+M/2-p,
    E=K-M/2,
    K_high=W(N)+c W(M)/2.

### The uniform theorem actually proved

1. The beta disjoint k-scale disks v(X-x_a)>=rho, 0<=a<beta, exhaust all n original roots, counted with multiplicity. Each contains n/beta roots.
2. In each such disk exactly (c-epsilon)L roots are on its boundary. All these boundary roots are simple, with the EXACT original values

       v(P_n')=D, v(P_(n-1))=E,
       v(sum_(j=0)^(n-1) P_j^2/w_j)
         = M-p-2N(r-k)(p-1)/p.

   The corresponding ordinary H derivative has value D. Thus exactly (c-epsilon)M roots are completely resolved, uniformly in every parameter and phase.
3. Each k-disk has exactly (2N+epsilon M)/beta strict-interior roots. If c is even, all 2N interior roots lie on the boundaries of the beta_r disjoint r-scale disks, 2L_r per disk. There is no exact zero, and v(P_n(0))=K_high.
4. If c is odd, there is one exact simple zero. Its exact data are

       D_0=v(P_n'(0))=W(N)+(c+1)M/2+cB_k-p,
       E_0=v(P_(n-1)(0))=W(N)+(c-1)M/2+cB_k,
       v(kernel at 0)=M-p.

   The corresponding H root is exactly -1 and is simple; H_n(0)=1. The general theorem leaves the other 2N+M-1 interior roots to the residual/deeper analysis; the explicit criterion below can resolve additional individual subclasses.
5. A finite, explicit, prime-field residual criterion, given in Section 8, computes the first original root/ordinary-derivative/neighbor residuals on ANY of the stated k-, intermediate-, or r-scale disks. It depends only on p,r,k,c and the chosen center/radius, not on q or s. It gives exact root counts, exact derivative/neighbor values on the nonvanishing residual locus, and a precise unresolved residue locus when cancellation occurs.

The general remaining full-theorem obligation is 2N high roots for even c, and 2N+M-1 interior roots for odd c, before any additional individual subclass is resolved by the criterion. This is not silently downgraded to a finite test family. Sections 9-10 give exact failures of the FIRST residual test, not characteristic-zero counterexamples: at the smallest new case p=3,r=4,k=2, the leading ordinary derivative and neighbor residues vanish on every high-root residual, for both c=1 and c=2. A further nested calculation is genuinely required.

### Credit and exclusions

The accepted all-r source the inherited k=1 candidate, manifest 4b111627d15ef5c485d5c290ea3f0f045d87d405c12f8bcd3156795d24a3d5e4, proves ONLY k=1, n=2p^r+cp, r>=3. Its independent review explicitly accepts that scope. The accepted two-digit-window assembly and its accepting review cover t<p^2 in n=2p^r+t, not this family with c p^k>=p^2. Their original source identities, public archive identities and inherited scopes are pinned in ../provenance/DEPENDENCIES.json. The dependency archives are not duplicated here. The inspected earlier general leading-digit report supplies contextual identities but is not used as an authority for an unproved odd-leading or shifted-tail estimate. The mathematical arguments below are reconstructed from the original identities.

All k=1, c=0, and lower-window cases receive no new credit. The new work is the uniform theorem and obstruction above, not a claim to have solved its unresolved interior. No composite p^k is substituted for a prime. No shifted-tail estimate, odd-leading-zero-tail result, historical novelty, whole-owner F020/F023 closure, FFT/cost/stability claim, publication, repository write, or table change is asserted. No supplied scientific program was executed or imported. Only newly written controls were run.

## 2. Exact identities and legal specialization

The degree is legal because

    n <= [2+(p-1)/p^2]N < pN <= p^s.

This is strict also at p=3,c=p-1,k=r-2,s=r+1. Consequently every recurrence edge, factorial, and denominator below is nonzero. For 0<|j|<p^s,

    v(1-q^j)=V(j),
    (1-q^j)/t^V(j) reduces to -j/V(j) modulo p.

Put Q_a=product_(u=1)^a(1-q^(2u)) and N_j(z)=product_(u=0)^(j-1)(z+q^u). Then v(Q_a)=W(a). The ORIGINAL Newton and ordinary derivative identities are

    H_b(z)=sum_(j congruent b mod 2) w_b N_j(z)/(w_j Q_((b-j)/2)),             (2.1)

    H_b'(z)=sum_(m,d>=0; d>=1; m+d<=b; b-m-d even)
       w_b z^(d-1) N_m(z)/(w_m Q_((b-m-d)/2) (1-q^d)).                     (2.2)

For a self-contained derivation, set J(u)=sum_(j>=0)u^j/w_j. Its exact formal relations J(qu)=(1-u)J(u), J(u)J(-u)=sum u^(2a)/Q_a, and J(zu)/J(-u)=sum N_j(z)u^j/w_j yield (2.1). Ordinary differentiation before specialization gives

    partial_z log[J(zu)/J(-u)]=sum_(d>=1) z^(d-1)u^d/(1-q^d),

and hence (2.2). The finite coefficient identities are rational identities in q and specialize legally here. These are not q-derivatives or derivatives of inseparable residual polynomials.

The exact H/P coordinate identity is

    H_b(v_0^2)=v_0^b P_b(v_0+v_0^(-1)),
    H_b'=v_0^(b-2)[(b/2)P_b+(v_0-v_0^(-1))P_b'/2].                      (2.3)

Near v_0=i the two coordinates are analytic isometries, because p is odd and both derivatives are units. Thus the z-disks v(z+q^a)>=rho correspond to the X-disks above. At a root the P_b term in (2.3) vanishes exactly, so ordinary root-derivative valuations transfer without any assumption about equality of normalized units. Neighbor values also transfer by a unit.

## 3. A cap and a block-interval inequality

For the k-scale radius define

    T(j)=sum_(u=1)^j min(V(u),rho), R(j)=W(j)-T(j).

Write h=floor(k/2). The exact floor expressions are

    W(j)=j+sum_(b>=1)(p^b-p^(b-1)) floor(j/p^b),
    T(j)=j+sum_(b=1)^(h-1)(p^b-p^(b-1)) floor(j/p^b)
                 +(rho-p^(h-1)) floor(j/p^h).

Both W and R are linear in base-p digits. For 0<j<M,

    R(j)<W(j)/2, and R(M)=W(M)/2.                                  (3.1)

Indeed R(p^b)=0<W(p^b)/2 when b<h; for h<=b<=k,

    R(p^b)=W(p^b)/2-(k-b)(p-1)p^(b-1)/2.

Digitwise summation proves (3.1). W is superadditive, with equality exactly when addition has no base-p carry, by its positive floor coefficients. The following exact decomposition is crucial and retains every valuation layer:

    W(uM+v)=u(W(M)-M)+M W(u)+W(v),
    R(uM+v)=u(R(M)-M)+M W(u)+R(v), 0<=v<M.                         (3.2)

Let Q=n/M=2p^(r-k)+c and F(b)=R(n)-R(n-b), 0<=b<=n. For b=BM+b_0,

    F(BM)=B(R(M)-M)+M[W(Q)-W(Q-B)],
    F(BM+b_0)=F(BM)+M V(Q-B)-rho+R(b_0-1), 0<b_0<M.               (3.3)

The latter follows by reflecting the last partial M-block; its endpoint has value M V(Q-B), while all preceding proper-offset values are those of 1,...,b_0-1.

Define a small periodic lower function for 0<=t<3M. If t=epsilon_0 M+b_0, set

    F_0(t)=epsilon_0 R(M)                                      if b_0=0,
    F_0(t)=epsilon_0 R(M)+M-rho+R(b_0-1)                       if b_0>0.

Now let a=uM+w, d=lM+v, 0<=w,v<M, and t=v+2w. Whenever d+2a<=n, (3.2)-(3.3) and W superadditivity give

    F(d+2a)-W(a)
      >= l R(M)+M[W(l)-l]+M[W(u)-u]+F_0(t)-W(w).              (3.4)

To check every coefficient: put t=epsilon_0 M+b_0, so the full quotient is B=l+2u+epsilon_0. Use

    W(Q)-W(Q-B)>=W(B)>=W(l)+2W(u)+epsilon_0,

where epsilon_0<=2<p, and, if b_0>0, V(Q-B)>=1. Substituting yields (3.4) exactly. This is a lower bound, not a cancellation-free equality claim.

The following consequences resolve the equality cases needed later.

(a) F_0(2w)-W(w)>=0, with equality only at w=0. For w>0 put J=ceil(2w/M) in {1,2} and j=JM-2w in (0,M). Reflection gives F_0(2w)=J R(M)-R(j). Since R(j)<W(j)/2 and W(j)+2W(w)<=W(JM)=J W(M), the inequality is strict.

(b) For 0<v<M, put t=v+2w. If t is not a multiple of M, put J=ceil(t/M)<=3<=p and j=JM-t in (0,M). Then

    F_0(t)=J R(M)-R(j),
    W(j)+2W(w)<=W(JM-v)=J W(M)-M-W(v-1).

Consequently F_0(t)-W(w)>M/2+W(v-1)/2. If t is a multiple of M the same inequality holds weakly, with equality requiring no carry in doubling w.

(c) Put g_b=p^b-B_b, with g_0=1. At fixed ord_p(v)=b the quantity V(v)-W(v-1)/2 is uniquely maximal at v=p^b, where it equals g_b. The unique global maximum is g_2=p. In fact g_1>g_0 and

    g_(b+1)-g_b=p^(b-1)(p-1)[p-b(p-1)]/2,

positive at b=1 and negative for all b>=2. This includes p=3. In the truncated range b<k, the maximum is p for k>=3, but only (p+1)/2 for k=2.

(d) For l>=1,

    l R(M)+M[W(l)-l]-M V(l)>=R(M)-M>=M/2-p.                  (3.5)

At fixed V(l)=p^b the first expression increases strictly with l, since R(M)-M>0 for k>=2. Its least value at l=p^b is p^b[R(M)-M]+2M B_b, minimized uniquely at l=1. The last inequality is equivalent to B_k>=M-p; equality occurs precisely at k=2, and it is strict for k>=3.

## 4. Exact k-scale root, derivative, and neighbor residuals

On a disk z=-q^a+lambda Y, 0<=a<beta, v(lambda)=rho, every product N_j has coefficientwise weight at least T(j). Each full M-block has exactly L factors of weight rho and its other factors have constant initial terms. With omega^2=w_M,

    N_M/omega reduces to Z=gamma_a Y^L, gamma_a!=0.

The shift by any multiple of M changes q^u by a term of value at least M>rho, so this holds blockwise without dividing by polynomials at their zeros. In particular N_(2N) has weight 2T(N) and initial a nonzero scalar times Y^(2N/beta).

Define the integer modified Hermite polynomial

    M_c(Z)=c! sum_(u=0)^floor(c/2) Z^(c-2u)/(2^u u! (c-2u)!).

It obeys M_j=Z M_(j-1)+(j-1)M_(j-2) and M_j'=j M_(j-1). Since c<p, consecutive M_c and M_(c-1) are coprime over F_p. M_c has c distinct roots; exactly epsilon of them are zero.

### Root score

The term j=n-2a in (2.1) has weight at least W(n)-R(j)-W(a). By (3.4) with d=0 and Section 3(a),

    R(j)+W(a)<=R(n),

with equality only if a=uM, u<p, and the quotient interval of length 2u ending at Q contains no multiple of p. Since Q mod p=c, this means exactly 0<=2u<=c. Thus the equality indices are

    j=2N+(c-2u)M, 0<=u<=floor(c/2).                         (4.1)

They all attain the product lower bound. Elementary block units are

    w_(2N+jM)/(w_(2N) w_M^j) -> j!,
    Q_(uM)/w_M^u -> 2^u u!,
    N_(2N+jM)/(N_(2N) omega^j) -> Z^j,

in these ranges, because no quotient crosses p in its last c blocks. Therefore the exact initial polynomial at weight

    W(n)-R(n)=K

is a nonzero scalar times

    Y^(2N/beta) M_c(gamma_a Y^L).                           (4.2)

These ratios specify initial polynomials coefficientwise, not pointwise division by N_(2N) at its zeros.

### Ordinary derivative score

For a term of (2.2), m+d+2a=n. Its weight is at least W(n)-R(m)-W(a)-V(d). Equations (3.4)-(3.5) and Section 3(b)-(c) prove

    R(m)+W(a)+V(d)<=R(n)-M/2+p.                            (4.3)

The equality classification is explicit. If d=lM+v with v>0, equality forces l=0, v=p^2, v+2w=M, and k>=3. Hence w=(M-p^2)/2. If v=0, equality forces k=2, l=1, w=0, again d=p^2. In both cases equality further requires the quotient interval of length 2u+1 to contain no multiple of p. The complete equality set is consequently

    d=p^2,
    a=uM+(M-p^2)/2,
    m=2N+(c-1-2u)M,
    0<=u<=floor((c-1)/2).                                 (4.4)

Every inequality is sharp there. Put A_0=(M-p^2)/2. The additional block identity

    Q_(uM+A_0)/(Q_A_0 w_M^u) -> 2^u u!

holds since A_0<M and all shifts have larger valuation than its proper offsets. Substitution into (2.2), including z^(p^2-1)->1, proves that the ORIGINAL ordinary derivative at weight D=K+M/2-p has initial

    nonzero scalar * Y^(2N/beta) M_(c-1)(gamma_a Y^L).        (4.5)

The root polynomial (4.2) was not differentiated after reduction. In particular (4.5) can be nonzero although the residue-field derivative of (4.2) is zero.

### Neighbor score

For b=n-1, use j+2a+1=n in (2.1). The proof of Section 3(b) with d=1, without subtracting V(1), gives

    R(j)+W(a)<=R(n)-M/2,

with equality exactly at

    a=uM+(M-1)/2,
    j=2N+(c-1-2u)M,
    0<=u<=floor((c-1)/2).

Since W(n-1)=W(n)-M, the exact weight is E=K-M/2, and the initial polynomial is

    nonzero scalar * Y^(2N/beta) M_(c-1)(gamma_a Y^L).        (4.6)

This is the actual ORIGINAL neighbor H_(n-1), not a shifted first-deleted or last-deleted tail.

## 5. Exhaustive coarse ledger and boundary simplicity

The disks are disjoint: different centers have mutual distance V(a-b)<=p^(floor(k/2)-1)<rho. The reduction (4.2) has degree n/beta and smallest exponent (2N+epsilon M)/beta. Newton/Weierstrass counting therefore gives n/beta roots in each closed disk, exactly (c-epsilon)L on its boundary and (2N+epsilon M)/beta in its strict interior. Counts include multiplicity; they do NOT use simple-root Hensel lifting on a Frobenius-composed residual. Summing over beta disks exhausts the degree n.

At each boundary root the variable Y is nonzero and M_c(gamma_a Y^L)=0. The Hermite coprimality makes M_(c-1) nonzero there, so (4.5)-(4.6) yield exact D and E. This proves all boundary roots simple, transfers their ordinary derivatives and neighbor values to P, and establishes the boundary row of the ledger.

Consecutive original P polynomials are coprime: a common zero propagates backwards through nonzero edges to P_0=1. The exact CD identity at a P_n root xi is

    sum_(j=0)^(n-1) P_j(xi)^2/w_j
        =P_n'(xi) P_(n-1)(xi)/w_(n-1).                       (5.1)

Using W(n-1)=W(n)-M gives its boundary valuation

    D+E-W(n-1)=M-p-2N(r-k)(p-1)/p.

This can be negative; nonvanishing, not positivity, is the issue. Even at unresolved roots the neighbor is nonzero by recurrence, but its exact valuation is NOT supplied unless the residual test proves it.

## 6. Exact zero/-1, with its unique p² pivot

For even c, n is even. At z=-1 every N_j with j>0 vanishes, so

    H_n(-1)=w_n/Q_(n/2),
    v(P_n(0))=W(n)-W(n/2)=W(N)+cW(M)/2=K_high.

There is no zero root.

For odd c, P_n is odd, hence zero is an exact root and H_n(-1)=0. At z=-1, (2.2) leaves only m=0, with odd d. Therefore

    H_n'(-1)=w_n sum_(d odd,1<=d<=n) 1/[(1-q^d) Q_((n-d)/2)].              (6.1)

At fixed ord_p(d)=b, the denominator score V(d)+W((n-d)/2) is uniquely maximal at the smallest permitted d=p^b. Put

    C=W(N)+(c-1)W(M)/2+B_k.

For b<=k the score is C+g_b. For k<b<=r it is C-(N-M)+g_b. These follow directly from the base-p digits of (n-p^b)/2; no estimate of a shifted tail is involved. Since k>=2 and g_b has its unique maximum p at b=2, (6.1) has the unique least-valuation term d=p^2. It cannot cancel. Thus

    v(P_n'(0))=W(n)-C-p=W(N)+(c+1)M/2+cB_k-p.

The original even neighbor gives directly

    v(P_(n-1)(0))=W(n-1)-W((n-1)/2)
                  =W(N)+(c-1)M/2+cB_k.

Substitution into (5.1) yields the exact kernel value M-p. This resolves the exact zero and H root -1 for EVERY odd c, including c=1,p=3 and both k/r parities. It does not resolve the other inner roots.

## 7. Even c: a complete high-root location ledger, not a simplicity claim

For even c use the r-scale cap R_r(j)<=W(j)/2, whose equality indices below n are multiples of N. Since n<3N and j has even parity, only j=0 and j=2N qualify. The carry-free halves n/2=N+cM/2 and (n-2N)/2=cM/2 attain equality. Hence on every r-disk the root weight is K_high and the residual is a nonzero scalar times

    M_2(gamma_a Y^L_r)=gamma_a^2 Y^(2L_r)+1.                  (7.1)

The shifted Q ratio required here has shift N and offset cM/2<N, so its proper factors retain their leading units. It gives the actual two-term ratio of M_2, not merely its support.

There are exactly 2L_r boundary roots per r-disk and no strict-interior root there. These total 2N and exhaust the k-scale interior roots from Section 5. Since r>=k+2, rho_r>rho_k and beta_k>rho_k, every r-disk is strictly inside its appropriate k-disk. Thus the high and lower boundary groups are disjoint. No derivative valuation or simplicity is inferred from the inseparable residual (7.1).

For odd c no analogous uniform high/shifted-inner allocation is asserted. Already the exact example in Section 10 shows additional tail roots on an old high boundary. The general interior obligation is 2N+M-1 after removing the simple exact zero; the displayed nested example additionally resolves two of those roots.

## 8. A phase-independent exact residual criterion

This criterion is a finite arithmetic calculation in integers and F_p, not a gcd of the unknown characteristic-zero polynomial with its unknown derivative. It uses no original polynomial coefficient expansion, no cyclotomic root approximations, and no chosen s. It is applicable at any half-integral radius rho_* strictly between consecutive p powers, and any integer center a with the relevant indices below p^s. The k- and r-radii above satisfy this.

Take lambda=t^rho_* in an algebraic extension, z=-q^a+lambda Y. For 0<=j<=b define

    T_a(j)=sum_(i=0)^(j-1) min(V(i-a),rho_*), V(0)=infinity,
    h_a(j)=number of i in [0,j) with V(i-a)>rho_*,
    U_a(j)=product_(i in [0,j), V(i-a)<rho_*) (i-a)/V(i-a) mod p,
    U_w(j)=product_(i=1)^j [-i/V(i)] mod p,
    U_Q(j)=product_(i=1)^j [-2i/V(i)] mod p.

Empty products are 1. Every displayed factor is a unit. Exact half-integrality excludes ties V(i-a)=rho_*. The coefficientwise initial of N_j is U_a(j)Y^h_a(j) at weight T_a(j).

For b in {n,n-1}, set

    L_b(j)=W(b)+T_a(j)-W(j)-W((b-j)/2), j congruent b mod 2,
    lambda_b=min_j L_b(j),
    R_b(Y)=sum_(j attaining lambda_b)
       U_w(b) U_a(j) Y^h_a(j) / [U_w(j) U_Q((b-j)/2)].        (8.1)

For the ORIGINAL ordinary derivative, set

    L'_n(m,d)=W(n)+T_a(m)-W(m)-W((n-m-d)/2)-V(d),
    lambda_D=min_(m,d) L'_n(m,d),
    D_n(Y)=sum_(m,d attaining lambda_D)
       U_w(n) (-1)^(d-1) U_a(m) Y^h_a(m)
       /[U_w(m) U_Q((n-m-d)/2) (-d/V(d))].                  (8.2)

All sums and minima are exact. They are over m>=0,d>=1,m+d<=n and n-m-d even. For each m, it suffices to test d=p^j when n-m is odd, and d=2p^j when n-m is even. At each fixed p-adic order these are the least allowed d; increasing d strictly decreases the denominator's W score, so no omitted d can be minimal. This reduces the derivative calculation to O(n log_p n) candidate pairs, without changing the mathematical criterion.

If R_n is nonzero, it is the exact initial polynomial of H_n, with weight lambda_n. Its degree is the number of roots in the disk and its order at Y=0 is the number in the strict interior. For each nonzero residual root y of R_n:

- If D_n(y)!=0, every lifted root above y is simple with v(H_n')=lambda_D.
- If R_(n-1)(y)!=0, its original neighbor has exact value lambda_(n-1).
- If both are nonzero, (2.3) and (5.1) give the exact original P derivative, neighbor, and kernel valuation lambda_D+lambda_(n-1)-W(n-1).
- If D_n(y)=0, the exact derivative value is STRICTLY GREATER than lambda_D, possibly infinity. This is an obstruction to this leading-residual proof, not a proof of multiplicity.
- If R_(n-1)(y)=0, its value is strictly greater than lambda_(n-1), but is finite at every original P_n root by consecutive coprimality.

If a displayed residual is identically zero, the respective weight is only a strict lower bound, and no root count or equality is claimed from that zero polynomial. The program records this explicitly.

Equivalently, on the nonzero root locus the failed first-derivative test is the support of

    gcd(R_n(Y)/Y^ord_0(R_n), D_n(Y)) in F_p[Y].               (8.3)

A nonconstant gcd is a fully explicit arithmetic obstruction independent of s and the characteristic-zero phase. It is not itself a characteristic-zero counterexample. Equations (8.1)-(8.2) follow immediately by inserting the proven factor units into (2.1)-(2.2); they remain valid when residual sums cancel. No differentiation after reduction is used.

This criterion is deliberately limited to the first stated residual on each chosen disk. It does not claim that a nonempty obstruction locus is resolved by a finite-field test or that arbitrary deeper refinements have been performed. The unresolved counts in Section 1 remain open in this packet.

## 9. Exact smallest-position obstruction: p=3,r=4,k=2

Here N=81,M=9,beta_k=3,rho_k=3/2,beta_r=9,rho_r=9/2. The following coefficients are in F_3, with lambda=t^(9/2), and are exact evaluations of (8.1)-(8.2). They hold for EVERY s>=5 and EVERY characteristic-zero primitive phase.

For c=1,n=171, there are no k-boundary roots and all 171 roots are strict-interior. The exact zero is simple with derivative value 309, neighbor value 303, kernel value 6. At r-center a=0:

    root weight 627/2, R_n=2Y+Y^19=Y(Y^18+2),
    derivative weight 309, D_n=2+Y^18,
    neighbor weight 303, R_(n-1)=1+2Y^18.

The root minima are j=9,171. The derivative minima are (m,d)=(0,9),(162,9). Thus 18 boundary roots lie above Y^18+2=0; their original ordinary derivative has value >309 and neighbor >303. There is one strict-interior root, the already proved simple zero.

At r-center a=1:

    root weight 312, R_n=2+Y^18,
    derivative weight 309, D_n=2+Y^18,
    neighbor weight 303, R_(n-1)=1+2Y^18.

All 18 roots in that disk are boundary roots and both leading values vanish on their residue class. The full all-nine-center exact table is OBSTRUCTION_LEDGER.json; its counts give 162 high boundary roots plus the exact zero in old disks, leaving precisely 8 other strict k-interior roots outside the old r-disks. Their finer locations and simplicity are not supplied.

For c=2,n=180, exactly 18 k-boundary roots are simple. Their derivative, neighbor, and kernel values are 423/2, 411/2, and -210. The remaining 162 roots lie on the nine r-disk boundaries, 18 per disk; zero is absent. At r-center a=0:

    root weight 318, R_n=1+2Y^18,
    derivative weight 651/2, D_n=Y+2Y^19=Y R_n,
    neighbor weight 639/2, R_(n-1)=Y+2Y^19=Y R_n.

At a=1:

    root weight 318, R_n=1+2Y^18,
    derivative weight 324, D_n=1+2Y^18,
    neighbor weight 318, R_(n-1)=1+2Y^18.

Again the obstruction is the full high-root residual, not a negligible exception. The all-center table confirms the same locus for every high disk. No nonsimplicity follows: the actual derivative and neighbor are higher-order values at these roots.

These examples do not establish or refute the missing uniform high-root theorem. They certify exactly which proposed first-residual inference fails.

## 10. Nested-layer negative controls

The case p=3,r=5,k=3,c=1,n=513 prevents flattening the odd interior into the k=1 ledger. On the central r-disk, rho_r=15/2,

    root weight 2223/2,
    R_n=2Y+Y^3+2Y^55+Y^57=Y(Y^2-1)(1+Y^54),
    derivative weight 1104, D_n=2(1+Y^54).

There are 56 boundary roots and one strict-interior root in this disk: 54 high roots on 1+Y^54=0 and TWO additional simple boundary roots on Y^2=1. The derivative residue is nonzero at the latter two roots, so their derivative value is exactly 1104. Their neighbor residue is 1+Y^54 at weight 1080, nonzero on Y^2=1, so the exact neighbor value is 1080 and the original kernel value is 24. The exact zero is the sole strict-interior root and has derivative value 1104. The other eight old r-disks contain 54 roots each. Thus the old r-disks contain 489 roots; the other 24 roots remain outside them but inside the k-scale cover. In this particular example, the simple zero and the two additional simple boundary roots leave 486 high roots plus 24 other inner roots, exactly 510 unresolved roots, rather than the general pre-criterion count 512. This shows concretely why neither the k=1 count p-1 nor a single enlarged fixed radius can be transplanted.

A separate zero-residual negative control is p=5,r=4,k=2,c=2 at central r-radius 25/2. The formal minimum derivative score is 2714, but its initial polynomial is identically zero: its four minimal pairs (0,2),(0,10),(1250,2),(1250,10) cancel. The criterion therefore records v(H_n')>2714 coefficientwise, not an equality or a derivative polynomial obtained by discarding the cancellation.

## 11. Evidence, limits, and next mathematical step

The self-contained arithmetic inequalities prove the uniform assertions for every odd prime, every allowed c,k,r,s, both k/r parities, c=p-1, and p=3. Fresh controls independently enumerate the exact scores and equality sets in a bounded grid, evaluate all residues from the original Newton/ordinary-derivative formulas, test exact H/P/Newton/derivative/CD identities at legal auxiliary finite phases, and test normalization and cancellation negatives. They are falsification/transcription controls, not the uniform proof and not a bridge from good finite reduction to characteristic-zero simplicity.

The root/derivative/neighbor ledger is deliberately exhaustive about unresolved entries. Even c: (cM) resolved boundary roots plus 2N unresolved high roots, no zero. Odd c: (c-1)M resolved boundary roots, one resolved exact zero, and a general remaining obligation of 2N+M-1 interior roots, reduced by the two additional certified roots in the displayed n=513 case. No root is omitted by counting; no unknown ordinary derivative or neighbor valuation is invented.

A completion needs higher mixed-characteristic control on the obstruction locus, or an exact characteristic-zero identity that cancels the root-multiple part before estimating the derivative. Reusing the k=1 fixed-tail/eta estimates is not justified. In particular, replacing p by p^k in those estimates would lose the p^2 ordinary-derivative pivot and the nested interior counts exhibited here. This packet requests independent review of the new partial theorem and exact obstruction only, not acceptance of full squarefreeness.

Final author controls: normal and optimized outputs are byte-identical. The mathematical/control run contains 896,785 explicit checks, including 64,638 exact rational parameter ledgers, 571,448 exhaustive score indices, 150 complete k-scale disk residual calculations in 30 degree fixtures, and eight invalid-inference negatives. The separate original-identity run passes 3,726 exact checks in 81 legal auxiliary finite-phase/coordinate fixtures. The source audit passes 210 byte/acceptance checks across four complete original inventories and 16 selected documentary snapshots. These numbers are control coverage, not universal theorem evidence.
