# Even middle coefficients beyond two: central-binomial noncancellation

22 October 2026 UTC. AUTHOR CANDIDATE for separate independent review. This packet does not accept itself.

## 1. New theorem and exact boundary

Let p be an odd prime, c=2a with 2<c<p, k>=2, r>=k+2, s>r, M=p^k, N=p^r, and n=2N+2aM. Let q be ANY characteristic-zero primitive p^s-th root. Use the original definitions

    P_0=1, P_1=X, P_(j+1)=X P_j-(1-q^j)P_(j-1),
    H_j(z)=sum_b [j choose b]_q z^b,
    w_j=product_(b=1)^j(1-q^b), w_0=1.

All derivatives are original ordinary characteristic-zero derivatives. The kernel is the original algebraic-square sum, not a Hermitian or absolute-square sum. In an algebraic p-adic embedding put t=q-1, v(t)=1, and

    V(j)=p^ord_p(j) (j!=0), W(j)=sum_(b=1)^j V(b), W(0)=0,
    A=W(M)=[p+k(p-1)]p^(k-1), K=W(N)=[p+r(p-1)]p^(r-1).

NEW CLAIM: all 2N high roots are simple, and at each of them

    D_high = v(P_n') = K+N/2+aA-p,
    E_high = v(P_(n-1)) = K+N/2+aA-M,
    v(sum_(j<n)P_j^2/w_j) = N-p.                         (1)

The decisive NEW unit is not a+1. Define in F_p

    Lambda_a = 4^a / binom(2a,a),
    tau_a = 1-Lambda_a.

Both numerator and denominator of Lambda_a are nonzero because 2a<p. The core derivative ratio has initial 1. The complete short-tail ratio derivative has initial tau_a at weight -p, ALLOWING tau_a=0; the eliminated initial is exactly Lambda_a, always nonzero. In particular c=4 gives Lambda_2=8/3 and tau_2=-5/3. At p=5 the tail initial vanishes, yet the eliminated initial is 1. One must NOT claim an exact tail derivative value -p at every prime.

INHERITED, NOT NEW: put J=(N/M+a)A. The accepted higher-middle theorem already proves simplicity of the other 2aM lower-boundary roots, with

    D_low=J+M/2-p, E_low=J-M/2,
    kernel_low=M-p-2N(r-k)(p-1)/p.                        (2)

It also gives the complete 2N high-root cover, disjointness, and nonzero constant v(P_n(0))=K+aA. Combining (1) and (2) exhausts n, proves both P_n and H_n squarefree, and proves original kernel nonvanishing at every root. Corresponding ordinary H root-derivative values equal the P values.

This is genuinely new for every even c with 2<c<p, including the first new c=4 family for every p>=5 and the endpoint c=p-1. The formulas incidentally specialize to the already accepted c=2 theorem, but that family receives no new credit. The empty new p=3 range is not presented as progress. Whole F020/F023, odd c, c>=p, k<2, r<k+2, s<=r, general degrees/orders, FFT superiority, cost/stability, historical novelty and publication remain outside the claim.

## 2. Inherited mathematical inputs and legal specialization

The exact frozen author/review records are in SOURCE_PINS.json. The accepted all-odd-prime c=2 report/review are the starting mechanism, not an authority for general c. Its author MANIFEST is c1599e66cdec763f9c66e0d7e7491eff3765f4aa64392a4379388087b5e2e26d; accepting review MANIFEST is a072aecd19addec60eddd9bd1e5358211362d3ce779f6ec5c47128be9500905b. We rederive the general tail and all c-dependent units below.

The higher-middle author MANIFEST 7d1176ebd17f037b23bec99f8dfa99d8c657eadd21d8b00339ebef961e1d40f7 is accepted by review MANIFEST 11abe81e31c14ea6642d19e7d1896273431eaa1e925c93cbdacd6fc30a236af2, at source://higher_review. Its exact accepted scope includes the present p,c,k,r,s; only (2), the location/count ledger and constant are inherited. It explicitly leaves the even high roots unresolved.

Put C=P_(2N), B=P_(2N-1), b_0=1-q^(2N), E=K-N/2. The leading-core author MANIFEST e19104be98018ea10de85dd648b3b2634664150ea24994300e28ac56fe889ec7 and accepting review MANIFEST a7990e625de81f3797ac13bbad7d7c817eb65aee195e5690f84de6ca7540c3c7 supply coefficientwise estimates on FULL old r-disks:

    weight(C)>=K, weight(B)>=E,
    weight(C')>=K+N/2-p, weight(B')>=E.                  (3)

The root initial is a nonzero multiple of Z^2+1, and the neighbor and derivative relevant initials are nonzero multiples of Z. Here h=floor(r/2), beta=p^h, L_r=N/beta,

    rho=beta/2 (r even), rho=(2p-1)p^(h-1)/2 (r odd),
    z=-q^b+lambda Y, v(lambda)=rho, 0<=b<beta,
    Z=gamma_b Y^L_r, gamma_b!=0.

The coordinate identities are z=v_0^2 and X=v_0+v_0^-1 on the near-i branch, i^2=-1. They are analytic isometries because p is odd. The associated X-center is i(q^(b/2)-q^(-b/2)). These full-disk results, not merely old C-root results, are used at the new roots. The leading-core source's later adjacent-degree theorem is not imported.

Every index is legal: n <= [2+(p-1)/p^2]N < pN <= p^s. In the actual mixed-characteristic field

    v(1-q^j)=V(j), (1-q^j)/t^V(j) -> -j/V(j),
    e=v(p)=(p-1)p^(s-1)>=(p-1)N.                         (4)

This holds for the relevant nonzero signed proper indices, including q^-1 factors. The proof never assumes its total polynomial weights lie below e. No supplied scientific program was run or imported; all controls in this packet are newly authored.

## 3. The enlarged strict deep cap: every j<pM

Set T(j)=sum_(u=1)^j min(V(u),rho) and R(j)=W(j)-T(j). On EVERY old r-disk, N_j(z)=product_(u=0)^(j-1)(z+q^u) has coefficientwise weight at least T(j): each interval of j indices contains at least floor(j/p^b) members of the relevant residue class at level b. A zero offset has capped value rho. The same interval argument in reverse orientation applies to q^-1 on the same X-disks.

The strengthened range actually used is

    R(j)<=W(floor(j/2)), 0<=j<pM,
    equality exactly at j=0,1.                           (5)

Proof. The exact floor formulas are

    W(j)=j+sum_(b>=1)(p^b-p^(b-1))floor(j/p^b),
    T(j)=j+sum_(b=1)^(h-1)(p^b-p^(b-1))floor(j/p^b)
                  +(rho-p^(h-1))floor(j/p^h).

They make W,R, and S=W/2-R linear in base-p digits. At a digit basis

    S(p^d)=W(p^d)/2                 if d<h,
    S(p^d)=(r-d)(p-1)p^(d-1)/2     if h<=d<=k.            (6)

All are positive. If j=2u+epsilon, epsilon=0 or 1, and d is its highest digit, then

    W(j)-2W(u)=epsilon+(p-1)sum_(b=1)^d p^(b-1)
                         [floor(j/p^b)-2floor(u/p^b)]
               <=p^d,                                   (7)

since each bracket is 0 or 1. The NEW range j<pM still gives d<=k. If j>=2 and d<h, R(j)=0<W(u). Otherwise (6) and r>=k+2 imply

    S(j)>=(r-d)(p-1)p^(d-1)/2
         >=(p-1)p^(d-1)>p^d/2.

Together with (7) this proves strictness. The endpoints 0,1 are immediate. This treats both r parities and h>k, without a finite parameter cutoff. W is superadditive, with equality exactly for carry-free addition, directly from the positive floor coefficients.

## 4. Original short polynomials and every needed odd pivot

For 0<=j<pM put h_j=W(j)-W(floor(j/2)). On each old disk, for Q=q or q^-1,

    weight(P_j(X;Q))>=h_j,
    weight(P_j'(X;Q))>=h_j-p         (j odd),
    weight(P_j'(X;Q))>=h_j-(p-1)     (j even).            (8)

For even j its normalized initial is the nonzero constant equal to its exact value at X=0. In particular f=P_(2aM) has value aA everywhere and a normalized analytic inverse.

For completeness, use only the exact original finite identities, with Q_u=product_(b=1)^u(1-q^(2b)),

    H_j=sum_(ell congruent j mod2) w_j N_ell/[w_ell Q_((j-ell)/2)],
    H_j'=sum_(m>=0,d>=1,m+d<=j,j-m-d even)
           w_j z^(d-1)N_m/[w_m Q_((j-m-d)/2)(1-q^d)].      (9)

They follow before specialization from J(qu)=(1-u)J(u) for J(u)=sum u^j/w_j, J(u)J(-u)=sum u^(2j)/Q_j, and J(zu)/J(-u)=sum N_j(z)u^j/w_j. Ordinary differentiation gives the logarithmic factor sum_(d>=1) z^(d-1)u^d/(1-q^d). Only finite coefficients are specialized.

Let H=(p^2-1)/2. The exact denominator-score inequalities are

    V(2u+1)-W(u)<=p, equality ONLY u=H,
    V(2u+1)-W(u+1)<=p-1,
    V(u)-W(u)<=0 (u>=1).                                 (10)

At fixed b=ord_p(2u+1), the smallest u is (p^b-1)/2 and uniquely maximizes the first score. Its values are g_0=1 and g_b=[p-b(p-1)/2]p^(b-1). Now g_1=(p+1)/2<p=g_2 and g_(b+1)-g_b=(p-1)p^(b-1)[p-b(p-1)]/2<0 for b>=2. The second inequality subtracts V(u+1)>=1; the third is immediate.

For odd j=2B+1, odd d=2u+1/even m=2v give a subtracted score at most W(B-u)+V(2u+1)<=W(B)+p. Even d=2u/odd m=2v+1 give at most W(B-u)+V(u)<=W(B). For even j=2B, odd d/odd m give at most W(B-u-1)+V(2u+1)<=W(B)+p-1; even d/even m give at most W(B). These are (8) for H. The root bound follows from (5), with equality for even j only at ell=0. The exact ordinary chain rule

    H_j(v_0^2)=v_0^jP_j(X),
    H_j'=v_0^(j-2)[(j/2)P_j+(v_0-v_0^-1)P_j'/2]          (11)

transfers (8), since its extra P term has weight at least h_j.

The NEW list of odd indices is

    j=dM with d odd, 1<=d<=2a-1,
    j=dM-1 with d even, 2<=d<=2a.                         (12)

Write j=2u+1. For the first list u=((d-1)/2)M+(M-1)/2; for the second u=(d/2)M-1. Their lower k digits are respectively all (p-1)/2 or all p-1. Therefore u>=H and W(u)=W(u-H)+W(H), with W(H)=p^2-p, including k=2. Strictness of (5) for even m forces m=0, and (10) forces d=p^2 in (9). Thus the single least-weight original derivative term has the exact scalar initial

    P_j'(X;q) ~ (-1)^u w_j/[(1-q^(p^2))Q_(u-H)],
    v(initial)=h_j-p.                                   (13)

The initial is constant on the complete disk. The same formula with actual inverse-parameter factors holds for q^-1. Replacing each 1-q^-b by -q^-b(1-q^b) makes (13) for q^-1 have sign +1, up to a q power: the total sign exponent is j-1+H, which is even. We used H even. This is an actual sign calculation, not a copied c=2 assertion.

## 5. Exact associated connection; no short internal shift is discarded

For any legal shift L define

    f_0^L=1, f_1^L=X, g_0^L=0, g_1^L=1,
    u_(j+1)^L=Xu_j^L-(1-q^(L+j))u_(j-1)^L,
    C_m^L=product_(j=1)^m(1-q^(L+j)).

The exact finite rational identities are

    f_m^L=C_m^L sum_(d=0)^m [(1-q^L)/(1-q^(L+d))]
       (-1)^d q^(d(d+1)/2) P_(m-d)(X;q)P_d(X;q^-1)
       /[w_(m-d)w_d],                                    (14)

    g_m^L=C_m^L sum_(ell=1)^m (-1)^(ell-1)q^(ell(ell-1)/2)
       P_(m-ell)(X;q)P_(ell-1)(X;q^-1)
       /[w_(m-ell)w_(ell-1)(1-q^(L+ell))].                (15)

At d=0 the ratio is the removable value 1; at L=0,d>0 it is zero. To derive these, transform f to F_(j+1)^(b)=(1+z)F_j^(b)-z(1-bq^j)F_(j-1)^(b). For S_b=sum F_j^(b)u^j/product_(h=1)^j(1-bq^h), recurrence gives

    b S_b(qu)=(1-u)(1-zu)S_b(u)-(1-b).

The unshifted series H(u) obeys H(qu)=(1-u)(1-zu)H(u). Writing S_b=H T_b, its d-th coefficient is (1-b)/(1-bq^d) times the d-th coefficient of 1/H(qu). The latter equals (-1)^d q^(d(d+1)/2)H_d(z;q^-1)/w_d(q), by the inverse q-binomial series determined by J(qu)=(1-u)J(u). Setting b=q^L and applying (11) gives (14); g_m^L=f_(m-1)^(L+1) gives (15) after cancellation. No infinite analytic product at a root of unity is used.

The accepted c=2 and earlier ternary works receive credit for this finite connection/elimination architecture. Here m=2aM, and ALL 2a internal M-block endpoints in (15) are retained. Replacing the tail by a shifted length-2M approximation would lose terms of the SAME weight and is not permitted.

## 6. General unshifted tail: all 2a surviving terms

Set m=2aM, f=f_m^0=P_m, g=g_m^0, R_0=g/f. The ell-th term in (15), including w_m, has weight at least

    B_ell=2aA-W(floor((m-ell)/2))
                 -W(floor((ell-1)/2))-V(ell).

The floor indices sum to aM-1, of W-value aA-M. Since ell<=2aM<pM,

    B_ell>=aA+M-V(ell)>=aA.                              (16)

Equality can occur only at ell=bM, 1<=b<=2a. Each of these attains equality in the floor sum. If b=2h+1, the floor indices are (a-h-1)M+d_0 and hM+d_0, d_0=(M-1)/2; doubling the low digits d_0 has no carry and the top sum is a-1<p. If b=2h, the floor indices are (a-h)M and hM-1, again carry-free. Every other ell has gap at least M-M/p. Consequently weight(g)>=aA and weight(R_0)>=0.

Each product in (15) contains one odd and one even polynomial. By (8), differentiating the even one loses at most p-1, while differentiating the odd one loses at most p. Thus precisely the following terms can contribute to weight aA-p in g':

    ell=(2h+1)M, 0<=h<a: differentiate P_((2a-2h-1)M)(q),
    ell=2hM, 1<=h<=a: differentiate P_(2hM-1)(q^-1).      (17)

They all have the unique pivot (13). The other factor has its exact even constant initial. The term R_0 f'/f has weight at least -(p-1), so it cannot affect weight -p in R_0'. The sum of the actual scalar units in (17), not a guess from c=2, is required.

## 7. Raw factor products and the 2a exact units

Write O_u=product_(j=1)^u(1-q^(2j-1)). Exactly,

    P_(2u)(0;q)=(-1)^u O_u,
    P_(2u)(0;q^-1)=q^(-u^2)O_u,
    w_(2u)=Q_u O_u.                                     (18)

Let U(v)=product_(j=1)^v j/V(j) in F_p. Put b=(p-1)/2 and H=(p^2-1)/2=bp+b. Wilson's pairing gives (b!)^2=(-1)^(b+1), so U(H)=(-1)^b(b!)^2=-1. Also U(p^2-1)=1; H is divisible by both 4 and p-1, so 2^H=(-2)^H=1. Hence the normalized product of either the odd or the even members of 1,...,p^2-1 is -1; their W-weight is p^2-p.

For u in either list underlying (12), set

    J_u=Q_u/[(1-q^(p^2))Q_(u-H)].

If u=vM+d_0, its numerator exponents are (2v+1)M-j for odd j=1,3,...,p^2-2. If u=vM-1, they are 2vM-2j for j=1,...,H. Every proper offset is <p^2<=M. Formula (4) gives the same normalized units +j/V(j), or +2j/V(j), respectively. In both cases the numerator has value p^2-p and unit -1. The denominator has value p^2 and unit -1. Therefore

    v(J_u)=-p, t^p J_u ->1.                              (19)

This proves the pivot ratio for every internal endpoint, not merely the last one.

For 0<=v<p and 0<=d<M in the range used,

    Q_(vM+d)/(Q_M^v Q_d) ->v!,
    W(vM+d)=vA+W(d).                                    (20)

All proper offsets retain their units under a multiple-of-M shift; each block endpoint contributes its block number. These identities control internal shifts exactly through their factorial factors.

We also need

    Q_M/[Q_(d_0)^2(1-q^M)] ->2(-1)^d_0.                  (21)

Here all weights cancel, since 2W(d_0)=A-M. To verify the unit without selecting a prime, removing p-multiples gives U(M)=(-1)^k and U(d_0)^2=(-1)^(k(b+1)). The unit of Q_M is -2(-1)^k, that of Q_(d_0)^2 is (-1)^(k(b+1)), and that of 1-q^M is -1. Finally d_0 has parity kb, proving (21).

For ell=(2h+1)M put u=(a-h-1)M+d_0, v=hM+d_0. Substituting (13),(18) into (15), dividing by f(0)=(-1)^a O_(aM), and retaining the q^-1 sign, gives the scalar initial

    (-1)^(a+u) [Q_(aM)/(Q_u Q_v(1-q^((2h+1)M)))] J_u.

By (20)-(21), the bracket's unit is

    2(-1)^d_0 a! /[(a-h-1)!h!(2h+1)].

Since a+u+d_0 has parity h+1, the complete normalized contribution at weight -p is

    A_h = -2a (-1)^h binom(a-1,h)/(2h+1), 0<=h<a.        (22)

For ell=2hM put u=hM-1 and v=(a-h)M. The sign from (15), (18), the inverse odd derivative and division by f(0) is (-1)^(h+1). The scalar becomes

    (-1)^(h+1) [Q_(aM)/(Q_v Q_u(1-q^(2hM)))] J_u.

As Q_u(1-q^(2hM))=Q_(hM), (20) gives its complete unit

    B_h = (-1)^(h+1) binom(a,h), 1<=h<=a.                (23)

All 2a denominators 2h+1 are nonzero in F_p because 2a<p. Thus no exceptional prime was removed by illegal division.

## 8. Central-binomial summation and exact cancellation handling

The even-index sum is sum_(h=1)^a B_h=1. For the odd-index sum set

    I_a=sum_(h=0)^(a-1) (-1)^h binom(a-1,h)/(2h+1).

As an identity over Q, I_a is the integral from 0 to 1 of (1-x^2)^(a-1). Integration of d[x(1-x^2)^(a-1)] gives I_a=2(a-1)I_(a-1)/(2a-1), with I_1=1. Equivalently this identity follows by finite coefficient sums, so no analytic fact is needed in the p-adic argument. Hence

    I_a=(2a-2)!!/(2a-1)!!,
    2a I_a=4^a/binom(2a,a)=Lambda_a.                     (24)

Every denominator occurring before reduction is a product of positive odd integers <p. Therefore reducing the rational identity modulo p is legal. Equations (22)-(24) prove coefficientwise on every full old r-disk

    v(f)=aA, weight(R_0)>=0, weight(R_0')>=-p,
    t^p R_0' ->tau_a=1-Lambda_a.                        (25)

If tau_a=0, (25) means a strict inequality for the derivative, not an exact -p valuation. Examples include (p,c)=(5,4),(11,6),(13,12). No such cancellation obstructs the theorem, because the later eliminated unit is Lambda_a, not tau_a. c=4 gives ordered endpoint units -4,2,4/3,-1; their sum is -5/3. At p=5 the four units are 1,2,3,4 and sum to 0. At the endpoint c=p-1, Fermat and binom(p-1,a)=(-1)^a give Lambda_a=(-1)^a; thus the tail initial is 0 for p congruent to 1 mod 4 and 2 for p congruent to 3 mod 4, while elimination is always a unit. The c=2 formula -2+1=-1 is a consistency check only. Neither copying its eliminated unit 2 nor guessing a+1 is correct in general.

## 9. The actual outer shift and valid relative derivative bounds

Now L=2N and m=2aM<N. Set eta_L=C_m^L/w_m and

    f_m^L=eta_L f+Delta_f, g_m^L=eta_L g+Delta_g.

For 1<=j<=m<pM<N, V(L+j)=V(j), and each shifted/unshifted edge quotient differs from 1 by a term of value N-V(j)>=N-M. Thus eta_L is a scalar unit and v(eta_L-1)>=N-M.

In (14), each d>0 extra ratio has exact value N-V(d). Its two floor indices sum to aM for even d and aM-1 for odd d. By (8) and superadditivity,

    weight(Delta_f)>=aA+N-M,
    weight(Delta_f')>=aA+N-M-p.                          (26)

The latter differentiates the ORIGINAL finite products in (14); it is not a derivative estimate inferred from an unstructured small remainder. In (15), subtracting eta_L times the unshifted identity replaces the reciprocal by

    1/(1-q^(L+ell))-1/(1-q^ell),

whose exact value is N-2V(ell). Its floor sum aM-1 therefore yields

    weight(Delta_g)>=2aA+N-2V(ell)-(aA-M)>=aA+N-M,
    weight(Delta_g')>=aA+N-M-p.                          (27)

Differentiation again precedes estimation. Since N>=p^2M, f_m^L retains its value aA and normalized analytic inverse, and its derivative has weight at least aA-(p-1).

For R_L=g_m^L/f_m^L the exact numerator of R_L-R_0 is Delta_g f-g Delta_f. Its weight is at least 2aA+N-M and its ordinary derivative weight at least 2aA+N-M-p. The denominator f_m^L f has value 2aA and logarithmic derivative weight at least -(p-1). Quotient differentiation proves

    weight(R_L-R_0)>=N-M,
    weight(R_L'-R_0')>=N-M-p>0.                          (28)

Thus (25) holds for the actual shifted ratio too. These are RELATIVE bounds in the actual mixed-characteristic field. No assertion 2aA<N or 2aA<e appears; both fail for unbounded k with r=k+2. Internal short-tail shifts were not treated by (28); they were retained exactly in Sections 6-8.

## 10. Core unit on the full residue-root locus

The accepted leading-core derivative/neighbor scalar ratio is b_0 times

    Q_((N-1)/2)/[(1-q^(p^2))Q_((N-p^2)/2)].

Its numerator exponents are N-j for odd j=1,3,...,p^2-2. The factor product calculation in Section 7 gives weight -p and unit 1. The original H/P conversion ratio is 2z/(z-1), of residue 1. The extra chain-rule term proportional to N C, after division by b_0B, has weight at least re-N/2>0. Consequently, on the FULL core residue-root locus Z^2+1=0,

    v(B)=E, weight(B'/B)>=0,
    t^p C'/(b_0B) ->1.                                  (29)

No old-root substitution C=0 is made. This is why the inherited full-disk estimates suffice for the new roots.

## 11. Exact elimination, immediate neighbor and unchanged CD

The ORIGINAL recurrence transfer gives identically

    P_n=f_m^L C-b_0g_m^L B.                              (30)

The first term has weight K+aA and residual a nonzero multiple of Z^2+1. By (25),(28), the correction has weight at least N+aA+E, higher by N/2. Hence each high root lies on the locus of (29), and both f_m^L and B are nonzero. The inherited count, or the same residual degree 2L_r and nonzero constant on each of beta disks, counts exactly 2N such roots before simplicity.

Ordinarily differentiate (30), then use the EXACT root equation to eliminate the root-multiple term. At every high root xi,

    P_n'=b_0 f_m^L B
         [C'/(b_0B)-R_L'-R_L B'/B].                     (31)

After multiplying the bracket by t^p, its signed initial is

    1-tau_a-0=Lambda_a=4^a/binom(2a,a) !=0.              (32)

This remains valid when tau_a=0. It proves the exact derivative value N+aA+E-p=K+N/2+aA-p, hence simplicity by the original characteristic-zero derivative, not by differentiating an inseparable residual.

The positively oriented continuant determinant gives the exact original-neighbor identity

    f_m^L P_(n-1)-f_(m-1)^L P_n
       =b_0 product_(j=1)^(m-1)(1-q^(L+j)) B.             (33)

At the root the second term vanishes exactly. The scalar product has value W(m-1)=2aA-M, so the actual immediate neighbor has value N+(2aA-M)+E-aA=K+N/2+aA-M. It is not g_m^L or a substituted tail neighbor.

Finally differentiating the original recurrence and telescoping gives the unchanged identity

    sum_(j<n)P_j(X)^2/w_j
      =[P_n'P_(n-1)-P_n P_(n-1)']/w_(n-1).               (34)

At a root, W(n-1)=2K+2aA-M, so (1) gives the exact kernel value N-p. This proves nonvanishing, without conjugation, positivity, interlacing or real orthogonality.

## 12. Exhaustive accounting, H and every primitive phase

The accepted lower theorem supplies exactly 2aM simple roots and (2). Distinct r-disks are disjoint. Every r-disk is strictly within its matching k-disk because rho_r>rho_k, while center differences for representatives congruent modulo beta_k have valuation at least beta_k>rho_k. The lower roots lie on the k-boundaries, so the two groups are disjoint. Their counts 2N+2aM=n exhaust the degree. The exact even constant has value W(n)-W(n/2)=K+aA, excluding zero.

Modulo the maximal ideal P_n=X^n and H_n=(1+z)^n, so P roots have positive value and are not +/-2, while H_n(0)=1. On the branch near i, z=v_0^2 and X=v_0+v_0^-1 are analytic isometries. The extra P term in (11) vanishes exactly at a root. Multiplicity and ordinary derivative valuations transfer, and the n roots exhaust H_n. Consecutive P polynomials also have no common root by backward propagation through the nonzero recurrence edges to P_0=1.

All units used the actual chosen t=q-1 and the actual signed factor rule (4). The derivation therefore works for every primitive phase and every s>r, not one selected complex root or finite-field phase. A characteristic-zero cyclotomic field embeds into an algebraic p-adic closure and that embedding extends to the splitting field. Injectivity transfers the established nonvanishing to the original characteristic-zero objects. Finite formal tests are not used to infer this transfer.

## 13. Evidence boundary, credit, and independent-review request

Sections 3-12 are the all-parameter proof. Newly authored normal/-O tests independently compute raw factor-unit products, the 2a endpoint contributions, finite score/equality grids, central-binomial identities, exact rational recurrence/connection/neighbor/CD identities, and finite original recurrence/ordinary-derivative formal controls. Source bytes are frozen and checked, never executed or imported. Every failure gate uses an explicit exception and remains active under Python -O. Exact coverage/results and limitations are in RUN_LOG.md and the JSON outputs.

The inherited lower-boundary theorem and location cover belong to the accepted higher-middle result; full-disk core statements belong to the accepted leading-core source; finite connections, relative-error architecture and exact root elimination are credited to accepted c=2/ternary work. The genuinely new contribution is the enlarged j<pM strict cap, the complete list of general-c derivative endpoints, exact internal-block factorial factors, and the central-binomial eliminated unit. No historical priority claim is made.

Review particularly (12)'s expanded pivots, all signs in (22)-(23), reduction of the rational sum in (24), the vanishing tail at (p,c)=(5,4), the distinction between a lower bound and equality in (25), retention of every internal shift, relative ordinary-derivative errors, core statements off old roots, original neighbor/CD normalization and all-phase root exhaustion. Requested acceptance is only the new uniform 2<c<p even family stated in Section 1. Whole F020/F023 and FFT superiority remain open.
