#!/usr/bin/env python3
"""Fresh exact arithmetic/identity controls, not a proof or a historical replay."""
import json
from fractions import Fraction
from hashlib import sha256
from pathlib import Path

checks=0

def check(ok,why):
    global checks
    checks+=1
    if not ok: raise RuntimeError(why)

def valuation(j,p):
    if j<=0: raise ValueError('positive integer required')
    a=1
    while j%p==0: a*=p;j//=p
    return a

def tails_fixture(p,k,r,c):
    M=p**k;N=p**r;m=c*M;a=(c-1)//2
    rho=Fraction(p**(r//2),2) if r%2==0 else Fraction((2*p-1)*p**(r//2-1),2)
    vs=[0]+[valuation(j,p) for j in range(1,m+1)]
    W=[0];T=[Fraction(0)];Uw=[1];U=[1]
    for j in range(1,m+1):
        W.append(W[-1]+vs[j]);T.append(T[-1]+min(vs[j],rho))
        U.append(U[-1]*(j//vs[j])%p);Uw.append(Uw[-1]*(-j//vs[j])%p)
    A=W[M];G=W[(m-1)//2]
    check(G==a*A+k*(p-1)*p**(k-1)//2,'G digits')
    check(m<p*M and m<N,'legal tail range')
    check(W[m]==2*G+M and W[m-1]==2*G,'weights')
    for j in range(m+1):
        check(W[j]-T[j]<=W[j//2],'cap inequality')
        check((W[j]-T[j]==W[j//2])==(j in (0,1)),'cap equality')
    valmin=None;pairs=[]
    for h in range(m):
        d=1 if (m-h)%2 else 2
        while d<=m-h:
            z=W[m]+T[h]-W[h]-W[(m-h-d)//2]-valuation(d,p)
            if valmin is None or z<valmin: valmin=z;pairs=[(h,d)]
            elif z==valmin:pairs.append((h,d))
            d*=p
    check(valmin==G+M-p,'odd derivative weight')
    check(pairs==[(0,p*p)],'unique ordinary p-squared pivot')
    odd_endpoints=[];gunit=0
    def even_initial(deg,inverse=False):
        v=1
        for j in range(1,deg,2):v=v*(j//valuation(j,p))%p
        if inverse and (deg//2)%2:v=-v
        return v%p
    for ell in range(1,m+1):
        lo=(m-ell)//2;hi=(ell-1)//2
        base=W[m]-W[lo]-W[hi]-vs[ell]
        check(base >= G+(ell%2==0),'g lower score')
        loss=p-1 if ell%2 else p
        check(base-loss>=G-(p-1),'g derivative score')
        shift=W[m]+N-2*vs[ell]-W[lo]-W[hi]
        check(shift>=G+N-M,'shifted g bound')
        check(shift-loss>=G+N-M-p,'shifted g derivative bound')
        if base==G:
            check(ell%M==0 and (ell//M)%2==1,'minimal g endpoint parity')
            odd_endpoints.append(ell)
            denominator=Uw[m-ell]*Uw[ell-1]*(-ell//vs[ell])%p
            unit=Uw[m]*even_initial(m-ell)*even_initial(ell-1,True)*pow(denominator,-1,p)%p
            gunit=(gunit+unit)%p
    check(odd_endpoints==list(range(M,m+1,2*M)),'all minimal endpoints retained')
    exact_gunit=pow(2,(m-1)//2,p)*U[(m-1)//2]%p
    check(gunit==exact_gunit and gunit!=0,'raw normalized g unit sum')
    for d in range(1,m+1):
        score=W[m]+N-vs[d]-W[(m-d)//2]-W[d//2]
        check(score>=G+N,'shifted f bound')
        check(score-p>=G+N-p,'shifted f derivative bound')
    check(M-p+rho<Fraction(N,2),'strict root-count dominance')
    # Endpoint delta=M is the worst strict gap for every comparison.
    for delta in [Fraction(M),Fraction(M)+Fraction(1,2),Fraction(N,2)]:
        gamma=Fraction(N,2)-delta
        check(gamma>=0,'admissible amplitude')
        gaps=[2*delta-M,delta-M+1,delta-M+p]
        check(all(g>0 for g in gaps),'strict derivative gaps')
        check((G+M-p+gamma)+(G+gamma)-2*G==M-p+2*gamma,'kernel cancellation')
    return dict(p=p,k=k,r=r,c=c,m=m,rho=str(rho),G=G,derivative_min=str(valmin),minimal_pairs=pairs,minimal_g_endpoints=odd_endpoints,g_unit=gunit)

# Polynomial arithmetic over a legal auxiliary finite field. These are identity
# controls only; no inference of all-phase characteristic-zero simplicity.
def trim(a):
    while len(a)>1 and a[-1]==0:a.pop()
    return a

def add(a,b,l):
    z=[0]*max(len(a),len(b))
    for i,x in enumerate(a):z[i]=(z[i]+x)%l
    for i,x in enumerate(b):z[i]=(z[i]+x)%l
    return trim(z)

def scale(a,c,l):return trim([x*c%l for x in a])
def mul(a,b,l):
    z=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):z[i+j]=(z[i+j]+x*y)%l
    return trim(z)

def derivative(a,l):return trim([i*a[i]%l for i in range(1,len(a))] or [0])
def polys(n,q,l,offset=0):
    out=[[1],[0,1]]
    for j in range(1,n):out.append(add([0]+out[-1],scale(out[-2],pow(q,offset+j,l)-1,l),l))
    return out[:n+1]

def identities(p,r,k,c,s,l,q):
    N=p**r;M=p**k;m=c*M;n=2*N+m
    check(pow(q,p**s,l)==1 and pow(q,p**(s-1),l)!=1,'legal auxiliary phase')
    check(n<p**s,'legal auxiliary degree')
    P=polys(n,q,l);f=polys(m,q,l,2*N);g=[[0],[1]]
    for j in range(1,m):g.append(add([0]+g[-1],scale(g[-2],pow(q,2*N+j,l)-1,l),l))
    b0=(1-pow(q,2*N,l))%l;C=P[2*N];B=P[2*N-1]
    transfer=add(mul(f[m],C,l),scale(mul(g[m],B,l),-b0,l),l)
    check(transfer==P[n],'original tail transfer')
    dtransfer=add(add(mul(derivative(f[m],l),C,l),mul(f[m],derivative(C,l),l),l),scale(add(mul(derivative(g[m],l),B,l),mul(g[m],derivative(B,l),l),l),-b0,l),l)
    check(dtransfer==derivative(P[n],l),'ordinary derivative transfer')
    lhs=add(mul(f[m],P[n-1],l),scale(mul(f[m-1],P[n],l),-1,l),l)
    scalar=b0
    for j in range(1,m):scalar=scalar*(1-pow(q,2*N+j,l))%l
    check(lhs==scale(B,scalar,l),'positively oriented actual neighbor')
    check(add(mul(f[m],P[n-1],l),mul(f[m-1],P[n],l),l)!=scale(B,scalar,l),'wrong neighbor sign negative control')
    # Exact finite associated connection, with independently formed unshifted q and q^-1 polynomials.
    A=polys(m,q,l);Ai=polys(m,pow(q,-1,l),l);w=[1]
    for j in range(1,m+1):w.append(w[-1]*(1-pow(q,j,l))%l)
    cm=1
    for j in range(1,m+1):cm=cm*(1-pow(q,2*N+j,l))%l
    sf=[0];sg=[0]
    for d in range(m+1):
        ratio=1 if d==0 else b0*pow((1-pow(q,2*N+d,l))%l,-1,l)%l
        coef=ratio*pow(-1,d)*pow(q,d*(d+1)//2,l)*pow(w[m-d]*w[d]%l,-1,l)%l
        sf=add(sf,scale(mul(A[m-d],Ai[d],l),coef,l),l)
    for ell in range(1,m+1):
        coef=pow(-1,ell-1)*pow(q,ell*(ell-1)//2,l)*pow(w[m-ell]*w[ell-1]*(1-pow(q,2*N+ell,l))%l,-1,l)%l
        sg=add(sg,scale(mul(A[m-ell],Ai[ell-1],l),coef,l),l)
    check(scale(sf,cm,l)==f[m],'finite f connection')
    check(scale(sg,cm,l)==g[m],'finite g connection')
    return dict(p=p,r=r,k=k,c=c,s=s,field=l,q=q,n=n)

rows=[]
for p in [3,5,7,11]:
    for k in [2,3]:
        for r in [k+2,k+3,k+4]:
            for c in range(1,p,2):rows.append(tails_fixture(p,k,r,c))
# Larger exponent cases check the relative-error architecture without requiring total weights <e.
for p,k,r,c in [(3,8,10,1),(5,5,7,3),(3,4,6,1)]:rows.append(tails_fixture(p,k,r,c))
identity_rows=[]
# q=4 has order 243 modulo 487 (since 487 prime and 2 primitive).
for q in [4,16,64]:
    if pow(q,243,487)==1 and pow(q,81,487)!=1:identity_rows.append(identities(3,4,2,1,5,487,q))
check(len(identity_rows)>0,'nonempty legal identity controls')
result={'status':'PASS','checks':checks,'valuation_fixtures':rows,'finite_identity_fixtures':identity_rows,'scientific_scope':'Falsification/transcription controls only. No historical program executed, no characteristic-zero proof inferred from finite reduction.'}
print(json.dumps(result,sort_keys=True,indent=2))
