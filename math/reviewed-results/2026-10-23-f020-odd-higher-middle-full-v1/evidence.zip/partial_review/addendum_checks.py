"""Independent controls for the closed-disk addendum; imports only reviewer code."""
from fresh_checks import polys,mul,add,scale,check,count,F
from math import prod
import json
for q in [F(2,3),F(3,5),F(5,8)]:
 for L in [2,5,10]:
  P=polys(q,L+12);fs=polys(q,12,L);gs=polys(q,12,L,True)
  for m in range(1,13):
   scalar=prod((1-q**(L+j) for j in range(1,m)),start=F(1))
   left=add(mul(gs[m],P[L+m-1]),scale(mul(gs[m-1],P[L+m]),-1))
   right=scale(P[L],scalar)
   check(left,right,'g oriented original neighbor identity')
   wr=add(mul(gs[m],fs[m-1]),scale(mul(gs[m-1],fs[m]),-1))
   check(wr,[scalar],'g oriented positive determinant')
   check(left!=scale(right,-1),True,'negative determinant sign rejected')
for p in [3,5,7,11]:
 for k in [2,3,5]:
  M=p**k
  for r in [k+2,k+3]:
   N=p**r
   for c in range(1,p,2):
    A=(p+k*(p-1))*p**(k-1);K=(p+r*(p-1))*p**(r-1);G=(c*A-M)//2
    check(min(F(N,2),F(N,2)-M+1,F(N,2)-M+p)>0,True,'division free strict interior gaps')
    for eps in [F(0),F(1,2),F(M),F(N)]:
     delta=F(N,2)+eps;gamma=0
     gaps=[2*delta-M-eps,delta-M+1,delta-eps-M+p]
     check(gaps,[N-M+eps,F(N,2)-M+1+eps,F(N,2)-M+p],'neighbor excess gaps')
     check(min(gaps)>0,True,'neighbor excess positive')
    D=K+G+M-p;En=K+G
    check(D+En-(2*K+2*G),M-p,'strict interior kernel')
print(json.dumps({'passed':True,'reviewer_own_code_only':True,'checks':count,'total':sum(count.values()),'not_a_uniform_proof_by_sampling':True},indent=2))
