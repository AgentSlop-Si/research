# Independent mathematical review: F020 odd higher-middle closed disks

23 October 2026. ACCEPT the frozen boundary theorem and its separately frozen closed-disk extension, exactly within the scope below. This review does not close F020 or F023 and does not approve any external publication operation.

## 1. Accepted scope and remaining obligation

Let p be an odd prime, c an odd integer with 1<=c<p, k>=2, r>=k+2, s>r, M=p^k, N=p^r and n=2N+cM. For every characteristic-zero primitive p^s-th root q, retain the original recurrence P_(j+1)=X P_j-(1-q^j)P_(j-1), ordinary characteristic-zero derivatives, and the algebraic-square Christoffel-Darboux kernel.

Every root in every CLOSED old r-scale disk is simple. With the source notation K=W(N), G=W((cM-1)/2), C=P_(2N), and gamma=v(C(xi))-K, the exact values at such a root are

    v(P_n') = K+G+M-p+gamma,
    v(P_(n-1)) = K+G+gamma,
    v(sum_(j<n) P_j^2/w_j) = M-p+2gamma.

Here C(xi) is nonzero and gamma is finite and nonnegative. In each strict old-disk interior gamma=0. Ordinary H_n root multiplicities and derivative values transfer by the original unit coordinate identity.

There are at least 2N boundary roots across these disks, counted with multiplicity before proving simplicity. The exact zero is also in the central strict interior and was already accepted. Together with the disjoint inherited (c-1)M simple k-boundary roots, at most M-1 nonzero roots remain unresolved. The extension proves that all these remaining roots lie outside the union of the closed old r-disks but inside the inherited strict k-interiors. It does not assert that there are exactly M-1, or give their finer locations or multiplicities.

The boundary packet is accepted as its own unchanged mathematical theorem. The closed-disk packet is a separate strengthening: its interior argument supersedes the narrower packet's prospective interior obstruction, rather than pretending that obstruction was already resolved in the earlier text.

## 2. Source comparison and real delta

The accepted higher-middle source supplies the (c-1)M lower boundary roots, simple zero, disjoint k-cover and residual criterion. For odd c it explicitly leaves 2N+M-1 nonzero interior roots before additional successful residual tests. Its n=171 example leaves the 162 old r-boundary roots unresolved, with eight other nonzero roots outside those old disks. Its n=513 example has 488 old r-boundary roots, two already certified, and 24 other roots outside the old disks. Thus the new theorem really settles the previously unresolved 486 boundary roots of that example; the two known tail roots and the exact zero are not re-credited.

The all-even report and its accepted source chain supply finite connection identities, the strict-cap/ordinary-derivative architecture and the leading core bounds. They do not already cover the odd tail used here. The key new mechanism is the odd-tail amplitude elimination, not another assertion of residual squarefreeness.

The accepted high-order deflation criterion also remains inherited. The repaired boundary report explicitly defines its exact degree bound C_j and condition phi(p^s)>C_j; this is not a Catalan number. New coverage credit is restricted to previously uncertified roots after that filter and all other accepted certificates are subtracted. No exhaustive count of new roots across all parameter tuples or global novelty claim is accepted.

The reviewer checked the cited full-disk core report sections 3-5, not just a root-locus summary. The C initial is proportional to Z^2+1, B=P_(2N-1) has initial proportional to Z, and the B' bound is coefficientwise on the full disks. Thus B has exact value E=K-N/2 at every nonzero boundary residue, while C has exact value K at zero disk residue. The source's later restriction of certain equalities to its own root locus does not erase these earlier coefficientwise identities.

## 3. Independent proof verification

### Odd-tail estimates

Write m=cM, u=(m-1)/2 and G=W(u). The carry-free digit formulas give cW(M)=2G+M and W(m-1)=2G. All recurrence factors used are nonzero because n<p^s.

For j<pM, the strict deep-cap proof extends exactly as stated: the top base-p digit index is at most k, so the positive digit contribution to S=W/2-R is greater than p^d/2 when the cap is active. The floor difference W(j)-2W(floor(j/2)) is at most p^d. The uncapped case is strict for j>=2. Thus equality in R(j)<=W(floor(j/2)) occurs only at 0 and 1.

Applying this to the original finite Newton and ordinary-derivative identities gives the inherited parity-sensitive derivative bounds. For odd m=cM, the lower k digits of u are (p-1)/2, so subtracting (p^2-1)/2 is carry-free. The unique least ordinary-derivative term is (Newton index, derivative index)=(0,p^2). Its actual nonzero constant initial gives the exact full-disk f' weight G+M-p; no residual polynomial is differentiated.

For the first-deleted unshifted odd tail g_m^0, odd ell in the finite connection has two even factors and weight at least G+M-V(ell)>=G. Every weight-G initial is constant. Even ell has two odd factors and an extra +1, giving weight at least G+1. The exact identity g_m^0(0)=(-1)^u Q_u has value G, so the weight-G constant cannot cancel. Ordinary differentiation loses at most p-1 in the first case and p in the second, proving g' >=G-(p-1).

The actual shift 2N is not discarded: each relative edge error has value at least N-M. The finite associated identities give Delta_f >=G+N and Delta_g >=G+N-M, with their original derivatives losing at most p. These errors are strictly above the claimed leading values, since N>=p^2 M. This proves f>=G+M, exact constant f' at G+M-p, exact constant g at G, and g'>=G-(p-1) on every full old disk. No inequality comparing the total tail weight with v(p) is assumed.

### Counts and boundary roots

Let F_b be f's exact Gauss weight. Ordinary differentiation of a radius-rho disk expansion satisfies weight(f')>=F_b-rho, because integer derivative multipliers have nonnegative valuation. Hence F_b<=G+M-p+rho<G+N/2. The last strict bound follows from M<=N/p^2 and rho<N/p.

In the exact transfer P_n=fC-b0gB, the first product therefore dominates in Gauss weight. Its initial polynomial is f_initial times a nonzero scalar multiple of Z^2+1. No coprimality is needed: degree minus order counts nonzero residual roots with multiplicity, so this product contributes at least 2L boundary roots per disk, at least 2N in total. This remains valid if the two initial factors share roots or are inseparable after reduction.

At a boundary root, B and g are nonzero of exact values E and G. The exact root equation implies f and C are nonzero. With delta=v(f)-G>=M and gamma=v(C)-K>=0 it gives delta+gamma=N/2. The term f'C in the ORIGINAL derivative has exact value K+G+M-p+gamma. The other terms have lower gaps 2delta-M, delta-M+1 and delta-M+p, all strictly positive. Thus there is no leading cancellation. In particular a shared residual tail/core class is not being declared a characteristic-zero multiple root.

### Strict interiors and the original neighbor

In a strict old-disk interior C has exact value K. Therefore f'C has exact value K+G+M-p, and the full-disk estimates put the other derivative terms above it by at least N/2, N/2-M+1 and N/2-M+p. This argument requires no root division and also covers f=B=0.

The complementary exact determinant has positive orientation:

    g_m P_(n-1)-g_(m-1)P_n
      = product_(j=1)^(m-1)(1-q^(2N+j)) C.

At m=1 its continuant determinant is 1; recurrence multiplies it by successive original edges. On all these disks g is nonzero of exact value G. At a P_n root, C cannot vanish because transfer would force the consecutive original pair C,B to share a root. Dividing only by this proved nonzero g gives v(P_(n-1))=K+G+gamma, including the f=B=0 case. The source w_(n-1) value is 2K+2G, so the ordinary algebraic-square CD identity gives M-p+2gamma. This is the actual immediate neighbor, not a shifted or Hermitian substitute.

The unit H/P coordinate factors and the injective characteristic-zero p-adic embedding are valid under the inherited odd-prime hypotheses. The proof does not lift a finite-field collision or rootlessness claim.

## 4. Fresh independent controls

fresh_checks.py was written by the reviewer from the stated definitions. It imports no author or historical scientific code. Exact Fraction polynomial arithmetic checks the associated f and g connections, the original transfer, oriented original-neighbor determinant, Newton expansion, ORIGINAL ordinary derivative expansion and the algebraic-square CD identity at two rational q fixtures and several lengths/shifts.

The program separately enumerates all original derivative-score pairs in 28 bounded valuation fixtures, rather than testing only proposed pivot pairs. It checks the unique p^2 pivot, every deep-cap input, all odd/even g endpoint bounds, shifted f/g relative errors, product-residual dominance and derivative/neighbor/kernel ledgers. There are 41,824 explicit checks. Ordinary and Python -O runs produce byte-identical result JSON; checks use explicit exceptions rather than assert. These are transcription/falsification controls, not the all-parameter proof.

addendum_checks.py imports only the reviewer's own polynomial routines. It independently verifies the complementary g determinant and positive orientation at 108 rational fixtures, rejects the opposite sign, and checks the strict-interior and neighbor-excess gap algebra. All 984 checks pass. A boundary-control negative shows that deleting the necessary delta>=M premise can destroy dominance. No author control output is relabeled as independent reviewer evidence.

## 5. Limits, frozen pins and disposition

No numerical root solver, unknown-root factorization, Hermitian positivity, q derivative, new phase restriction, arbitrary subclass, hidden localization or unpriced speedup is used. The parameter gamma is a mathematical valuation at an actual root; this review does not claim an efficient algorithm for computing it. The author's field-operation, storage, coefficient-encoding and bit-cost caveats are preserved.

Accepted boundary report: f44e9c7259df3aa618748a6d495e7685ca62d0902f1b3dfa02e509cd9e80ae0d.
Accepted boundary manifest: fcc0c66566ebf24cbf65275514ef7a47520ec64d5196ce50a2afbac1d99a3797.
Accepted closed-disk report: bbacc5c2b3f15e780047481e9b2c2a784bf6c436a5f5800e6fff5acaab6e290e.
Accepted closed-disk manifest: 04c1ed31e62a1a8077fbe7ec623720a95cb3f95929af8eb6b830c5acb2854442.

Both author manifests and the selected source-copy hashes have been checked. BINDINGS.json preserves their exact inventories. The source review is deliberately limited to the inputs used by this proof, not a re-audit of the entire historical program or publication state. The original pre-clarity boundary packet is not the accepted release; the final repair only defines the inherited deflation threshold.

Verdict: accept these two bounded mathematical claims. Keep the parent owners open, retain all earlier certificates and subtract their coverage, and leave the at most M-1 outside-old-disk roots as the next genuine unresolved obligation. No external writes were performed by this reviewer.
