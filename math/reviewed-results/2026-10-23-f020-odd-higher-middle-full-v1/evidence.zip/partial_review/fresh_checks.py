"""Fresh independent exact finite identities and finite falsification controls.
No author or historical program imports. Uniform theorem is reviewed separately.
"""
from fractions import Fraction as F
from math import prod
from pathlib import Path
import json,hashlib
count={}
def check(a,b,label):
 count[label]=count.get(label,0)+1
 if a!=b:raise RuntimeError((label,a,b))
def trim(a):
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def add(a,b):
 c=[F(0)]*max(len(a),len(b))
 for j,x in enumerate(a):c[j]+=x
 for j,x in enumerate(b):c[j]+=x
 return trim(c)
def scale(a,c):return trim([x*c for x in a])
def mul(a,b):
 c=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def diff(a):return trim([F(i)*a[i] for i in range(1,len(a))] or [F(0)])
def polys(q,length,shift=0,g=False,H=False):
 a=[[F(0)] if g else [F(1)],[F(1)] if g else ([F(1),F(1)] if H else [F(0),F(1)])]
 for j in range(1,length):
  t=scale(a[-2],-(1-q**(shift+j)))
  if H:t=[F(0)]+t
  a.append(add(mul(a[-1],[F(1),F(1)] if H else [F(0),F(1)]),t))
 return a[:length+1]
def identities():
 for q in [F(2,3),F(3,5)]:
  limit=12;P=polys(q,40);Pi=polys(1/q,limit);w=[F(1)]
  for j in range(1,41):w.append(w[-1]*(1-q**j))
  for L in [0,4,10]:
   fs=polys(q,limit,L);gs=polys(q,limit,L,g=True);C=[F(1)]
   for j in range(1,limit+1):C.append(C[-1]*(1-q**(L+j)))
   for m in range(1,limit+1):
    f=[F(0)];g=[F(0)]
    for d in range(m+1):
     ratio=F(1) if d==0 else (1-q**L)/(1-q**(L+d))
     c=C[m]*ratio*(-1)**d*q**(d*(d+1)//2)/(w[m-d]*w[d])
     f=add(f,scale(mul(P[m-d],Pi[d]),c))
    for ell in range(1,m+1):
     c=C[m]*(-1)**(ell-1)*q**(ell*(ell-1)//2)/(w[m-ell]*w[ell-1]*(1-q**(L+ell)))
     g=add(g,scale(mul(P[m-ell],Pi[ell-1]),c))
    check(f,fs[m],'associated f');check(g,gs[m],'associated g')
    if m%2:
     d=(m-1)//2;exact=(-1)**d*prod((1-q**(2*j) for j in range(1,d+1)),start=F(1))
     if L==0:check(gs[m][0],exact,'odd g constant')
    if L:
     x=add(mul(fs[m],P[L]),scale(mul(gs[m],P[L-1]),-(1-q**L)))
     check(x,P[L+m],'original transfer')
     left=add(mul(fs[m],P[L+m-1]),scale(mul(fs[m-1],P[L+m]),-1))
     right=scale(P[L-1],(1-q**L)*C[m-1]);check(left,right,'original neighbor determinant')
  HH=polys(q,limit,H=True); NN=[[F(1)]];Q=[F(1)]
  for j in range(1,limit+1):
   NN.append(mul(NN[-1],[q**(j-1),F(1)]));Q.append(Q[-1]*(1-q**(2*j)))
  for n in range(1,limit+1):
   new=[F(0)];der=[F(0)]
   for ell in range(n%2,n+1,2):new=add(new,scale(NN[ell],w[n]/(w[ell]*Q[(n-ell)//2])))
   for h in range(n):
    for d in range(1,n-h+1):
     if (n-h-d)%2:continue
     v=[F(0)]*(d-1)+NN[h]
     der=add(der,scale(v,w[n]/(w[h]*Q[(n-h-d)//2]*(1-q**d))))
   check(new,HH[n],'Newton identity');check(der,diff(HH[n]),'ordinary derivative identity')
   cd=[F(0)]
   for j in range(n):cd=add(cd,scale(mul(P[j],P[j]),w[n-1]/w[j]))
   wr=add(mul(diff(P[n]),P[n-1]),scale(mul(P[n],diff(P[n-1])),-1))
   check(cd,wr,'ordinary algebraic-square CD')
def val(j,p):
 v=1
 while j%p==0:j//=p;v*=p
 return v

def valuation_checks():
 fixtures=[]
 for p,k in [(3,2),(3,3),(5,2),(5,3),(7,2),(11,2)]:
  M=p**k
  for c in range(1,p,2):
   m=c*M;u=(m-1)//2
   for r in [k+2,k+3]:
    N=p**r;rho=F(p**(r//2),2) if r%2==0 else F((2*p-1)*p**(r//2-1),2)
    vs=[0]+[val(j,p) for j in range(1,m+1)];W=[0];T=[F(0)]
    for j in range(1,m+1):W.append(W[-1]+vs[j]);T.append(T[-1]+min(vs[j],rho))
    R=[F(w)-t for w,t in zip(W,T)];A=W[M];G=W[u]
    check(2*G+M,c*A,'odd digit ledger');check(W[m-1],2*G,'tail neighbor ledger')
    for j in range(m+1):check(R[j]<=W[j//2] and ((R[j]==W[j//2])==(j in (0,1))),True,'strict deep cap')
    # Enumerate all original derivative terms, not just author-selected candidates.
    best=None;args=[]
    for h in range(m):
     for d in range(1+(m-h-1)%2,m-h+1,2):
      s=W[m]-R[h]-W[(m-h-d)//2]-vs[d]
      if best is None or s<best:best=s;args=[(h,d)]
      elif s==best:args.append((h,d))
    check(best,G+M-p,'odd derivative exact weight');check(args,[(0,p*p)],'unique ordinary p2 pivot')
    # Independently test raw finite-connection weights for g and its derivative.
    equal=[]
    for ell in range(1,m+1):
     f1=(m-ell)//2;f2=(ell-1)//2
     score=W[m]-W[f1]-W[f2]-vs[ell]
     check(score>=G+(ell%2==0),True,'g endpoint weight')
     if score==G:equal.append(ell);check(ell%2==1 and ell%M==0,True,'constant g initial support')
     loss=p-1 if ell%2 else p
     check(score-loss>=G-(p-1),True,'g derivative bound')
     check(score+N-vs[ell]>=G+N-M,True,'shifted g relative error')
     if ell<m+1:
      # Shifted f correction d=ell; floor sum is u.
      scoref=W[m]-W[(m-ell)//2]-W[ell//2]+N-vs[ell]
      check(scoref>=G+N,True,'shifted f relative error')
    check(G+M-p+rho<G+F(N,2),True,'strict product residual dominance')
    # Entire allowed amplitude interval, tested at half-integral endpoints and a middle point.
    for delta in [F(M),F(N,4)+F(M,2),F(N,2)]:
     gamma=F(N,2)-delta
     check(min(2*delta-M,delta-M+1,delta-M+p)>0,True,'all derivative gaps positive')
     K=(p+r*(p-1))*p**(r-1);E=K-F(N,2)
     D=G+M-p+K+gamma;En=N+2*G+E-(G+delta)
     check(En,K+G+gamma,'actual immediate neighbor valuation')
     check(D+En-(2*K+2*G),M-p+2*gamma,'original kernel valuation')
    fixtures.append({'p':p,'k':k,'r':r,'c':c,'m':m,'derivative_pivot':args[0],'g_leading_endpoints':equal})
 return fixtures
if __name__=='__main__':
 identities();f=valuation_checks()
 # Consequential negative controls at the symbolic gap boundary.
 check(2*F(0)-9<0,True,'negative: removed delta bound breaks dominance')
 check((F(81,2)-10)+10==F(81,2),True,'amplitude relation fixture')
 out={'passed':True,'independent_fresh_program':True,'author_programs_executed':False,'checks':count,'total_checks':sum(count.values()),'valuation_fixtures':f,'proof_not_inferred_from_finite_grid':True}
 print(json.dumps(out,indent=2))
