# Odd higher-middle closed-disk extension

23 October 2026 UTC. Separate author candidate; the earlier boundary packet is unchanged. This strengthens location coverage, not whole-family closure.

## Claim and dependency

Retain exactly the original odd-c family and all notation, exclusions, ordinary derivatives, source bounds, and cost assumptions of the frozen boundary report at SHA-256 f44e9c7259df3aa618748a6d495e7685ca62d0902f1b3dfa02e509cd9e80ae0d, whose manifest is fcc0c66566ebf24cbf65275514ef7a47520ec64d5196ce50a2afbac1d99a3797.

Every root of P_n in ANY CLOSED old r-disk is simple, not only its boundary roots. At each such root xi, write gamma=v(C(xi))-K. Then C(xi) is nonzero, gamma is finite and nonnegative, and the exact values are

v(P_n'(xi))=K+G+M-p+gamma,
v(P_(n-1)(xi))=K+G+gamma,
v(original algebraic-square kernel at xi)=M-p+2gamma.

On the strict interior gamma=0. The boundary values coincide with the frozen theorem. Simplicity transfers to the original H_n through the already pinned unit ordinary coordinate identity.

The at most M-1 potentially unresolved nonzero roots now all lie OUTSIDE the union of the closed old r-disks, but inside the inherited strict k-disk interiors. The inherited lower-boundary roots, exact zero, successful residual loci and high-order deflation remain excluded from new coverage credit. No exact number of newly covered strict-interior roots is claimed, and the exact zero earns no new credit.

## 1. Why neighbor excess is not a new collision inside the disks

The full core initials are C_initial proportional to Z^2+1 and B_initial proportional to Z. Therefore they never vanish simultaneously in the residue field. At a point of a closed old disk:

- At nonzero disk residue Y, B has exact E=K-N/2. This is the frozen boundary case.
- At disk residue Y=0, C has exact K, since Z=0 and Z^2+1=1.

Thus a vanished B residual automatically gives a nonvanishing C residual. This is the source-named core/neighbor residual separation needed to repair the overly broad prospective obstruction in the boundary packet. It is not an assumption of characteristic-zero root separation.

If f and B are nonzero at a root, put delta=v(f)-G and epsilon=v(B)-E, as well as gamma=v(C)-K. The actual root equation gives

delta+gamma=N/2+epsilon.

The three lower derivative gaps over the exact f'C term are respectively

2delta-M-epsilon,
delta-M+1,
delta-epsilon-M+p.

These are the requested excess-sensitive formulas. An arbitrary nonnegative epsilon would not suffice for the boundary argument. But within these disks, either epsilon=0 (boundary case), or gamma=0 and delta=N/2+epsilon (strict interior). In the latter case the gaps become at least

N-M+epsilon,
N/2-M+1+epsilon,
N/2-M+p,

all strictly positive because M<=N/p^2. This comparison is not used when f=B=0, where delta and epsilon would be infinite; that legitimate case is covered without division next.

## 2. Direct strict-interior comparison, including f=B=0

At every strict-interior point, C has exact value K. The proven full-disk odd-tail derivative has the constant nonzero initial at G+M-p. Thus f'C has exact value D0=K+G+M-p, whether or not f or B vanishes.

The full-disk estimates alone give the following lower gaps for the other terms of

P_n'=f'C+fC'-b0g'B-b0gB':

fC': at least N/2;
b0g'B: at least N/2-M+1;
b0gB': at least N/2-M+p.

All are strictly positive. Hence every P_n root in a strict old-disk interior is simple with derivative value D0. The argument includes the already accepted exact zero but does not re-credit it. It requires no unknown root count and no inverse of f, B, or a vanishing residual.

## 3. The g-oriented exact determinant supplies the actual neighbor

The original continuants obey the positively oriented identity

g_m^(2N) P_(n-1)-g_(m-1)^(2N) P_n
  = product_(j=1)^(m-1)(1-q^(2N+j)) C.

It follows directly by inserting P_n=f_m C-b0g_m B and the analogous formula for P_(n-1), then using

g_m f_(m-1)-g_(m-1)f_m=product_(j=1)^(m-1)(1-q^(2N+j)).

The sign is fixed already at m=1, when the determinant is 1, and recurrence multiplies it by the next nonzero edge.

At a P_n root, g is a nonzero analytic unit of exact value G and the scalar product has value W(m-1)=2G. Consequently C cannot be zero: the exact transfer would then also give B=0, contradicting consecutive coprimality of C and B. Thus

v(P_(n-1))=2G+v(C)-G=K+G+gamma

at EVERY root in the closed disks, even if f=B=0. This is the actual immediate neighbor, not a shifted or first-deleted substitute. Combining with the original derivative and W(n-1)=2K+2G gives the asserted kernel M-p+2gamma.

## 4. Exhaustion boundary and costs

The frozen result counted at least 2N boundary roots before simplicity. The exact zero lies in the central strict interior, so the old closed disks contain at least 2N+1 certified roots in total. Together with the disjoint inherited (c-1)M k-boundary roots, at most M-1 roots remain. This is an upper bound, not a claim that exactly M-1 always remain.

The remaining problem is a uniform root-aware estimate outside the old r-disk union. The core bounds imported here are not asserted there. In particular no general displaced-tail radius, no count beyond the stated upper bound, and no uniform lower bound for the required perturbation derivative outside that union is invented.

This extension needs no new polynomial expansion, residual factorization, or numerical root approximation. It adds a constant number of symbolic valuation comparisons and one exact continuant determinant to the inherited finite certificate. Computing gamma at an actual algebraic root remains an unpriced operation; no bit complexity, FFT, or speedup claim follows. The frozen packet's arithmetic/cyclotomic cost caveats remain unchanged.
