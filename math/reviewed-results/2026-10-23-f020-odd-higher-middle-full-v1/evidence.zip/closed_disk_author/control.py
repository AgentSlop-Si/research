#!/usr/bin/env python3
import json
from fractions import Fraction
checks=0

def ck(ok,why):
 global checks
 checks+=1
 if not ok:raise RuntimeError(why)

fixtures=[]
for p in [3,5,7,11,13,17,19]:
 for k in range(2,10):
  for r in range(k+2,k+7):
   M=p**k;N=p**r
   for eps in [Fraction(0),Fraction(1,2),Fraction(1),Fraction(M),Fraction(N)]:
    delta=Fraction(N,2)+eps
    gaps=[2*delta-M-eps,delta-M+1,delta-eps-M+p]
    ck(gaps==[N-M+eps,Fraction(N,2)-M+1+eps,Fraction(N,2)-M+p],'excess-gap substitution')
    ck(min(gaps)>0,'strict excess gaps')
   ck(min(Fraction(N,2),Fraction(N,2)-M+1,Fraction(N,2)-M+p)>0,'direct strict-interior gaps')
   fixtures.append([p,k,r])
# Exact integer continuants with heterogeneous nonzero edges; no root or division needed.
def add(a,b):
 z=[0]*max(len(a),len(b))
 for i,x in enumerate(a):z[i]+=x
 for i,x in enumerate(b):z[i]+=x
 while len(z)>1 and z[-1]==0:z.pop()
 return z

def mul(a,b):
 z=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):z[i+j]+=x*y
 while len(z)>1 and z[-1]==0:z.pop()
 return z

def sc(a,k):return [k*x for x in a]
for seed in range(1,9):
 f=[[1],[0,1]];g=[[0],[1]];prod=1
 for m in range(1,15):
  det=add(mul(g[m],f[m-1]),sc(mul(g[m-1],f[m]),-1))
  ck(det==[prod],'positive g-oriented determinant')
  edge=(seed+2*m)*(1 if m%2 else -1)
  f.append(add([0]+f[m],sc(f[m-1],-edge)))
  g.append(add([0]+g[m],sc(g[m-1],-edge)))
  prod*=edge
print(json.dumps({'status':'PASS','checks':checks,'valuation_fixtures':len(fixtures),'exact_continuant_fixtures':112,'limits':'Finite transcription controls, not the uniform proof. No inherited code imported or run.'},sort_keys=True,indent=2))
