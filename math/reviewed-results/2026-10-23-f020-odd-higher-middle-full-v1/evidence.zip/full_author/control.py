#!/usr/bin/env python3
"""Fresh outside-cover and k-tail valuation controls; not universal proof."""
import json
from fractions import Fraction
checks=0

def ck(ok,why):
 global checks
 checks+=1
 if not ok:raise RuntimeError(why)

def V(j,p):
 if j==0:return None
 j=abs(j);v=1
 while j%p==0:j//=p;v*=p
 return v

def rho(p,k):return Fraction(p**(k//2),2) if k%2==0 else Fraction((2*p-1)*p**(k//2-1),2)

def WT(p,n,cap):
 W=[0];T=[Fraction(0)]
 for j in range(1,n+1):W.append(W[-1]+V(j,p));T.append(T[-1]+min(V(j,p),cap))
 return W,T

def short(p,k,r,c):
 M=p**k;N=p**r;m=c*M;sig=rho(p,k);rr=rho(p,r)
 W,T=WT(p,m,sig);G=W[(m-1)//2];A=W[M]
 for j in range(m+1):
  ck(W[j]-T[j]<=Fraction(W[j],2),'k half-W cap')
  ck((W[j]-T[j]==Fraction(W[j],2))==(j%M==0),'k cap equality')
 # Ordinary derivative minimum pairs on full k disks, plus unique constant-index pivot.
 low=None;pairs=[]
 for h in range(m):
  d=1 if (m-h)%2 else 2
  while d<=m-h:
   v=W[m]+T[h]-W[h]-W[(m-h-d)//2]-V(d,p)
   if low is None or v<low:low=v;pairs=[(h,d)]
   elif v==low:pairs.append((h,d))
   d*=p
 ck(low==G+M-p,'k ordinary derivative weight')
 ck(pairs==[(h*M,p*p) for h in range(0,c,2)],'all k derivative minima')
 ck([x for x in pairs if x[0]==0]==[(0,p*p)],'unique Y-zero derivative pivot')
 endpoints=[]
 for ell in range(1,m+1):
  ck(W[m-ell]+W[ell-1]==2*G,'endpoint reflection')
  base=W[m]-Fraction(W[m-ell]+W[ell-1],2)-V(ell,p)
  ck(base>=G,'coarse g bound')
  if base==G:
   endpoints.append(ell)
   ck(ell%M==0,'g endpoint necessity')
   if ell%2:
    ck(W[m-ell]==2*W[(m-ell)//2],'first even constant exact')
    ck(W[ell-1]==2*W[(ell-1)//2],'second even constant exact')
   else:ck((m-ell)%2 and (ell-1)%2,'even endpoint vanishes at zero')
  shift=W[m]+N-2*V(ell,p)-Fraction(W[m-ell]+W[ell-1],2)
  ck(shift>=G+N-M,'coarse shifted g bound')
 ck(endpoints==list(range(M,m+1,M)),'all coarse g endpoints')
 for d in range(1,m+1):
  sf=W[m]+N-V(d,p)-Fraction(W[m-d]+W[d],2)
  ck(sf>=G+N-Fraction(M,2),'coarse shifted f bound')
 ck(G+N-Fraction(M,2)-sig>G+M-p,'f derivative shift strictly higher')
 ck(M+rr<Fraction(N,2),'master derivative gap')
 return dict(p=p,k=k,r=r,c=c,m=m,derivative_min=str(low),minimal_pairs=pairs)

def outside(p,k,r):
 N=p**r;M=p**k;rr=rho(p,r);sig=rho(p,k);W,T=WT(p,2*N,rr);K=W[N];E=K-Fraction(N,2)
 R=[Fraction(w)-t for w,t in zip(W,T)]
 ck(R[2*N-1]==K-N+rr,'core endpoint R')
 for h in range(N):
  j=2*N-1-2*h
  ck(R[j]+R[2*h]==R[2*N-1],'R reflection')
  ck(R[j]+W[h]<=E,'core neighbor numerator bound')
  ck(W[h]-R[2*h]<=Fraction(N,2)-rr,'ratio common bound')
  ck(W[2*N-1]-W[j]==W[2*h],'W reflection')
 # Full capping at all chosen centers, including ties tau=p^d and fractional tau.
 taus={sig+Fraction(1,4),(sig+rr)/2,rr-Fraction(1,4)}
 power=1
 while power<rr:
  if power>sig:taus.add(Fraction(power))
  power*=p
 centers=range(p**(r//2))
 for tau in sorted(taus):
  ck(sig<tau<rr,'outside tau scope')
  L0=-Fraction(N,2)+rr-tau
  for a in centers:
   ps=[Fraction(0)]
   for j in range(2*N):
    cap=tau if j==a else min(tau,V(j-a,p));ps.append(ps[-1]+cap)
   for h in range(N):
    j=2*N-1-2*h;tail=ps[2*N]-ps[j]
    ck(tail<=tau+T[2*h],'arbitrary aligned interval cap')
    value=W[2*h]-W[h]-tail
    ck(value>=L0,'every original neighbor term ratio')
   # Independent direct check that all nonmonic C Newton terms are strictly higher.
   for h in range(1,N+1):
    j=2*N-2*h;gap=W[2*N]-W[j]-W[h]-(ps[2*N]-ps[j])
    ck(gap>0,'outside original core leading product dominance')
  gaps=[Fraction(N,2)-M+p+rr-2*tau,Fraction(N,2)-M+p+rr-tau-sig,Fraction(N,2)-M+p-tau]
  ck(min(gaps)>0,'all final outside derivative gaps')
 return dict(p=p,k=k,r=r,centers=len(centers),taus=[str(x) for x in sorted(taus)])

shorts=[]
for p in [3,5,7,11]:
 for k in [2,3]:
  for r in [k+2,k+3]:
   for c in range(1,p,2):shorts.append(short(p,k,r,c))
outs=[outside(*x) for x in [(3,2,4),(3,2,5),(3,3,5),(5,2,4),(5,2,5),(7,2,4)]]
# Generic split cap for intervals not positioned at the global maximizer.
for p in [3,5,7]:
 for r in [4,5,6]:
  rr=rho(p,r);_,T=WT(p,301,rr)
  for left in range(0,151):
   for right in range(0,151):ck(T[left]+T[right]<=T[left+right],'cap superadditive split')
print(json.dumps({'status':'PASS','checks':checks,'short_tail_fixtures':shorts,'outside_fixtures':outs,'normalization':'Original ordinary derivative scores, original core and immediate neighbor Newton terms. No characteristic-zero conclusion inferred from controls.','program_boundary':'Fresh authored data-only arithmetic controls. No supplied historical code imported or executed.'},sort_keys=True,indent=2))
