"""Independent bounded falsification checks, not an enumeration proof.
No author/historical scientific code is imported or executed.
"""
from fractions import Fraction as F
from collections import Counter
from itertools import product
import json
checks=Counter()
def ck(test,name):
 checks[name]+=1
 if not test: raise RuntimeError(name)
def V(j,p):
 if not j: return None
 j=abs(j);a=1
 while j%p==0: j//=p;a*=p
 return a
def W(j,p):
 z=j;d=p
 while d<=j: z+=(d-d//p)*(j//d);d*=p
 return z
def radius(p,l):
 return F(p**(l//2),2) if l%2==0 else F((2*p-1)*p**(l//2-1),2)
def T(j,p,rho):
 z=F(j);d=p
 while d<=j and d//p<rho:
  z+=(min(d,rho)-min(d//p,rho))*(j//d);d*=p
 return z
def R(j,p,rho):return W(j,p)-T(j,p,rho)
fixtures=[]
for p,k,r in [(3,2,4),(3,3,5),(5,2,4),(5,3,5),(7,2,4)]:
 M=p**k;N=p**r;sig=radius(p,k);rho=radius(p,r);K=W(N,p)
 ck(sig<rho<N/p,'nested radius strict bounds')
 for j in range(p*M):
  ck(R(j,p,sig)<=F(W(j,p),2),'large k disk half-W cap')
  ck((R(j,p,sig)==F(W(j,p),2))==(j%M==0),'large k disk equality set')
 for c in range(1,p,2):
  m=c*M;G=W((m-1)//2,p);Df=G+M-p
  ck(W(m,p)==2*G+M and W(m-1,p)==2*G,'odd tail ledger')
  for ell in range(1,m+1):
   ck(W(m-ell,p)+W(ell-1,p)==2*G,'all g endpoints reflection')
   score=G+M-V(ell,p)
   ck(score>=G and ((score==G)==(ell%M==0)),'full k g equality endpoints')
   ck(score+N-V(ell,p)>=G+N-M,'full k shifted g error')
   if ell%M==0:
    b=ell//M
    if b%2:
     for j in [m-ell,ell-1]: ck(W(j//2,p)==F(W(j,p),2),'odd g endpoint constant attains half-W')
    else: ck((m-ell)%2==1 and (ell-1)%2==1,'even g endpoint constants vanish')
   ck(W(m,p)-F(W(m-ell,p)+W(ell,p),2)+N-V(ell,p)>=G+N-F(M,2),'full k shifted f error')
  e=(p-1)*p**r # minimum s=r+1
  ck(k*e+G+F(M,2)>Df,'off-root P derivative correction strictly higher')
  ck(G+N-F(M,2)-sig>Df,'full k f derivative error strictly higher')
  ck(G+N-M>G,'full k g error strictly higher')
 fixtures.append([p,k,r])
 # Every core numerator Newton index, with the independently defined cap.
 E=K-F(N,2)
 for h in range(N):
  j=2*N-1-2*h
  ck(W(2*N-1,p)-W(j,p)==W(2*h,p),'core numerator endpoint reflection')
  ck(R(j,p,rho)+W(h,p)<=E,'core half-W score')
  ck(R(j,p,rho)+R(2*h,p,rho)==K-N+rho,'core capped reflection')
  ck(W(h,p)-R(2*h,p,rho)<=F(N,2)-rho,'core ratio uniform bound')
 # Exhaustive interval-split test on a bounded block; floors also independently sum.
 lim=min(2*N,90)
 for h1 in range(lim):
  for h2 in [0,1,2,3,7,lim-1]:
   ck(T(h1,p,rho)+T(h2,p,rho)<=T(h1+h2,p,rho),'arbitrary split cap superadditivity')
 for j in range(lim):ck(T(j,p,rho)==sum(min(V(d,p),rho) for d in range(1,j+1)),'floor cap equals direct sum')
 # Synthetic actual ultrametric distance profile; includes tied centers and exact p powers.
 taus={sig+(rho-sig)/3,sig+(rho-sig)*2/3,rho-F(1,4)}
 d=p
 while d<rho:
  if d>sig:taus.add(F(d))
  d*=p
 for tau in sorted(taus):
  ck(sig<tau<rho,'outside tau legal')
  for a in [0,1,p-1,p,p+1,2*N-1]:
   dist=[tau if b==a else min(tau,V(b-a,p)) for b in range(2*N)]
   ck(max(dist)==tau,'closest center including ties')
   if tau.denominator==1 and V(int(tau),p)==tau:
    ck(sum(x==tau for x in dist)>1,'exact p-power tied centers included')
   for lo in [0,1,p-1,p,2*N//3]:
    prefix=[F(0)]
    for x in dist[lo:]:prefix.append(prefix[-1]+x)
    for length in range(1,len(prefix),2):
     ck(prefix[length]<=tau+T(length-1,p,rho),'actual odd interval distance cap')
   gaps=[F(N,2)-M+p+rho-2*tau,F(N,2)-M+p+rho-tau-sig,F(N,2)-M+p-tau]
   ck(min(gaps)>0,'all outside ordinary derivative gaps positive')
   L0=-F(N,2)+rho-tau
   ck(L0-rho==-F(N,2)-tau and L0-tau>L0-rho,'ratio derivative product comparison')
# Large k/r, not small-array extrapolation: sparse digit extremals and strict margins.
for p in [3,5,11,101]:
 for k in [2,7,20]:
  M=p**k
  for r in [k+2,k+3,2*k+1]:
   N=p**r;sig=radius(p,k);rho=radius(p,r)
   ck(M+rho<F(N,2),'all-parameter margin extremal controls')
   for c in [1,p-2]:
    m=c*M;G=W((m-1)//2,p)
    for j in sorted({0,1,M-1,M,M+1,m-1,m,p*M-1}):
     ck(R(j,p,sig)<=F(W(j,p),2),'large exponent half-W')
    ck(k*(p-1)*p**r>F(M,2)-p,'large exponent off-root derivative transfer')
    ck(N-F(3*M,2)-sig+p>0,'large exponent shifted derivative margin')
# Exact ordinary chain rule before root evaluation, in Laurent polynomials.
def add(a,b):
 d=dict(a)
 for k,v in b.items():d[k]=d.get(k,F(0))+v
 return {k:v for k,v in d.items() if v}
def scale(a,c):return {k:v*c for k,v in a.items() if v*c}
def mul(a,b):
 d={}
 for j,x in a.items():
  for k,y in b.items():d[j+k]=d.get(j+k,F(0))+x*y
 return {k:v for k,v in d.items() if v}
def deriv(a):return {k-1:k*v for k,v in a.items() if k}
def subst(a,x):
 d={};power={0:F(1)}
 for j in range(max(a,default=0)+1):
  d=add(d,scale(power,a.get(j,F(0))));power=mul(power,x)
 return d
for q in [F(2,3),F(4,7)]:
 P=[{0:F(1)},{1:F(1)}];H=[{0:F(1)},{0:F(1),1:F(1)}]
 for j in range(1,11):
  P.append(add(mul({1:F(1)},P[-1]),scale(P[-2],-(1-q**j))))
  H.append(add(mul({0:F(1),1:F(1)},H[-1]),scale(mul({1:F(1)},H[-2]),-(1-q**j))))
 for m in [1,3,5,9,11]:
  ps=subst(P[m],{1:F(1),-1:F(1)})
  pd=subst(deriv(P[m]),{1:F(1),-1:F(1)})
  hs=subst(deriv(H[m]),{2:F(1)})
  core=scale(mul({1:F(1),-1:F(-1)},pd),F(1,2))
  rhs=mul({m-2:F(1)},add(scale(ps,F(m,2)),core))
  ck(hs==rhs,'exact off-root ordinary derivative chain rule')
  ck(hs!=mul({m-2:F(1)},core),'negative discarded off-root prefactor term detected')
# Consequential scope mutations are falsified, not silently admitted.
ck(F(3**2,1)+radius(3,2)>F(3**2,2),'negative removed scale separation can break margin')
ck((F(9,2)-9+3-F(9,2))<0,'negative unbounded tau can destroy derivative gap')
print(json.dumps({'passed':True,'fixtures':fixtures,'checks':dict(sorted(checks.items())),'total':sum(checks.values()),'author_code_executed':False,'uniform_proof_by_sampling':False},indent=2))
