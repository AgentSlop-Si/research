"""Fresh original-envelope/operator checks; no author/historical code imports."""
from collections import Counter
import json
checks=Counter()
def ck(t,s):
 checks[s]+=1
 if not t:raise RuntimeError(s)
class Field:
 def __init__(self,p,poly=None):self.p=p;self.poly=poly;self.size=p if poly is None else 1<<(poly.bit_length()-1)
 def add(self,a,b):return (a+b)%self.p if self.poly is None else a^b
 def neg(self,a):return (-a)%self.p if self.poly is None else a
 def sub(self,a,b):return self.add(a,self.neg(b))
 def mul(self,a,b):
  if self.poly is None:return a*b%self.p
  r=0
  while b:
   if b&1:r^=a
   b>>=1;a<<=1
   if a&self.size:a^=self.poly
  return r
 def pw(self,a,n):
  if n<0:return self.pw(self.pw(a,self.size-2),-n)
  y=1
  while n:
   if n&1:y=self.mul(y,a)
   a=self.mul(a,a);n>>=1
  return y
 def div(self,a,b):
  ck(b!=0,'nonzero denominator')
  return self.mul(a,self.pw(b,-1))
 def integer(self,n):return n%self.p
 def poladd(self,a,b):
  return self.trim([self.add(a[j] if j<len(a) else 0,b[j] if j<len(b) else 0) for j in range(max(len(a),len(b)))])
 def scale(self,a,c):return self.trim([self.mul(x,c) for x in a])
 def trim(self,a):
  while len(a)>1 and a[-1]==0:a.pop()
  return a
 def polmul(self,a,b):
  out=[0]*(len(a)+len(b)-1)
  for i,x in enumerate(a):
   for j,y in enumerate(b):out[i+j]=self.add(out[i+j],self.mul(x,y))
  return self.trim(out)
 def ev(self,a,x):
  y=0
  for c in a[::-1]:y=self.add(self.mul(y,x),c)
  return y
 def rank(self,rows):
  a=[r[:] for r in rows];nr=len(a);nc=len(a[0]);pos=0
  for col in range(nc):
   pivot=next((j for j in range(pos,nr) if a[j][col]),None)
   if pivot is None:continue
   a[pos],a[pivot]=a[pivot],a[pos]
   inv=self.pw(a[pos][col],-1);a[pos]=[self.mul(x,inv) for x in a[pos]]
   for j in range(pos+1,nr):
    f=a[j][col]
    if f:
     for h in range(col,nc):a[j][h]=self.sub(a[j][h],self.mul(f,a[pos][h]))
   pos+=1
   if pos==nr:break
  return pos
fixtures=[]
for N,d,F in [(23,4,Field(47)),(35,6,Field(71)),(47,8,Field(283)),(63,10,Field(2,0b1000011))]:
 ck(N>=6*d-2 and d>=4 and N%2,'new legal range')
 ck(all(F.mul(x,F.pw(x,-1))==1 for x in range(1,F.size)),'finite field inverse validation')
 q=next(a for a in range(2,F.size) if F.pw(a,N)==1 and all(F.pw(a,j)!=1 for j in range(1,N)))
 h=pow(4,-1,N);e=pow(2,-1,N);rho=F.pw(q,e);qh=F.pw(q,h);m=N-d
 D=[1]
 for j in range(2,d):D=F.polmul(D,[1,F.neg(F.pw(q,j))])
 ck(len(D)==d-1 and D[0]!=0 and D[-1]!=0,'original D endpoints')
 ck(all(F.ev(D,F.pw(q,k)) for k in range(m+1)),'all original envelope guards')
 def C(k):return F.pw(q,h*k*k)
 def Lseq(vals,x,start):
  return [F.sub(F.mul(F.sub(1,F.pw(q,k+2)),vals[j+1]),F.mul(F.mul(x,F.sub(1,F.pw(q,k+d))),vals[j])) for j,k in enumerate(range(start,start+len(vals)-1))]
 def Mseq(vals):
  for r in range(d):vals=[F.sub(vals[j+1],F.mul(F.pw(q,r),vals[j])) for j in range(len(vals)-1)]
  return vals
 def chirpL(P,x):
  rotated=[F.mul(v,F.pw(rho,j)) for j,v in enumerate(P)]
  first=F.scale(F.polmul([0,1,0,F.neg(F.pw(q,2))],rotated),qh)
  second=F.scale(F.polmul([1,0,F.neg(F.pw(q,d))],P),F.neg(x))
  return F.poladd(first,second)
 def chirpM(P):
  for r in range(d):
   rotated=[0]+[F.mul(qh,F.mul(v,F.pw(rho,j))) for j,v in enumerate(P)]
   P=F.poladd(rotated,F.scale(P,F.neg(F.pw(q,r))))
  return P
 for x in [1,q,F.pw(q,3),F.size-1]:
  target=[F.mul(F.pw(x,k),F.ev(D,F.pw(q,k))) for k in range(1,m+1)]
  ck(all(v==0 for v in Lseq(target,x,1)),'fixed-root first-order annihilation')
  for degree in [0,1,3*d-7]:
   P=[(5*j+3)%(F.size-1)+1 for j in range(degree+1)];R=[(7*j+2)%(F.size-1)+1 for j in range(d-1)]
   first=chirpL(P,x);trans=chirpM(first)
   ck(len(first)==len(P)+3,'first-order chirp exact degree plus three')
   ck(first[-1]==F.neg(F.mul(F.pw(q,h+2),F.mul(F.pw(rho,degree),P[-1]))),'first-order unique leading coefficient')
   ck(len(trans)==len(P)+3+d,'constant chirp injectivity exact degree')
   seq=[F.add(F.mul(C(k),F.ev(P,F.pw(rho,k))),F.ev(R,F.pw(q,k))) for k in range(1,m+1)]
   applied=Mseq(Lseq(seq,x,1))
   expected=[F.mul(C(k),F.ev(trans,F.pw(rho,k))) for k in range(1,m-d)]
   ck(applied==expected,'full operator on actual envelope sequence')
  ck(N-2*d-1>4*d-4 and 4*d-4<N,'strict degree versus distinct point count')
 derivative=[F.mul(F.integer(k),F.ev(D,F.pw(q,k))) for k in range(1,m+1)]
 transformed=Lseq(derivative,1,1)
 J=F.polmul([1,F.neg(F.pw(q,d))],D)
 ck(transformed==[F.ev(J,F.pw(q,k)) for k in range(1,m)],'ordinary derivative target first-order image')
 ck(all(v==0 for v in Mseq(transformed)),'ordinary derivative image killed in all characteristics')
 # Original envelope, not a restricted surrogate. Test joint endpoint independence.
 E=[]
 for a in range(3*d-6):E.append([F.div(F.mul(C(k),F.pw(rho,k*a)),F.ev(D,F.pw(q,k))) for k in range(m+1)])
 for a in range(d-1):E.append([F.div(F.pw(q,k*a),F.ev(D,F.pw(q,k))) for k in range(m+1)])
 rank=F.rank(E);delta=[[int(k==j) for k in range(m+1)] for j in [0,1,m]]
 ck(F.rank(E+delta)==rank+3,'joint original endpoint functional independence')
 base=E+[delta[0]];rb=F.rank(base)
 ck(F.rank(base+[[F.integer(k) for k in range(m+1)]])==rb+1,'ordinary derivative functional excluded')
 ck(F.rank(base+[[1]*(m+1)])==rb,'forced root one retained')
 for x in [q,F.pw(q,2),F.size-1]:
  if x==1:continue
  ck(F.rank(base+[[F.pw(x,k) for k in range(m+1)]])==rb+1,'sample non-one fixed root excluded')
 ck(N-2*d-1>4*d-8,'sparse endpoint zero-count margin')
 ck(m>=2*d-2 and 2*m-2>N-1 and (N-1)//2<=m,'all inherited propagation and axis dimensions')
 ck(N-5*d+8>=d+6,'corrected envelope dimension lower bound')
 guard=d*(d+1)+2*m-1
 ck(2*guard<(F.size**2),'quadratic coefficient field guard bound')
 # Direct original Gaussian-row identity throughout every legal recurrence window.
 def gauss(ep,de,a,b):
  rr=(ep*a)%N;ll=(de*b)%N
  if rr+ll>=N:return 0
  z=F.pw(q,ep*de);val=1
  for j in range(1,ll+1):val=F.mul(val,F.div(F.sub(1,F.pw(z,rr+j)),F.sub(1,F.pw(z,j))))
  return val
 for a in range(1,d-1):
  for b in range(1,d-a):
   tb=F.div(1,gauss(-1,1,N-b,b));qb=1
   for l in range(1,b+1):qb=F.mul(qb,F.sub(1,F.pw(q,l)))
   bb=F.mul(tb,F.mul(F.pw(F.neg(1),b),F.pw(q,b*(b+1)//2)))
   for j in range(m+1):
    z=F.pw(q,j);dv=F.ev(D,z);den=1;rv=1
    for l in range(1,b+1):
     den=F.mul(den,F.sub(1,F.mul(F.pw(q,a+l),z)))
     rv=F.mul(rv,F.sub(1,F.mul(F.pw(q,a-l),z)))
    fv=F.div(dv,den)
    target=F.pw(q,h*(a+j+b)**2)
    vb=F.div(F.sub(target,F.mul(tb,gauss(-1,1,a+j,b))),gauss(1,1,a+j,b))
    left=F.mul(dv,vb)
    chirp=F.mul(F.mul(qb,F.pw(q,h*(a+b)**2)),F.mul(C(j),F.mul(F.pw(rho,(a+b)*j),fv)))
    right=F.sub(chirp,F.mul(bb,F.mul(rv,fv)))
    ck(left==right,'every original whole-left Gaussian row identity')
 # Explicit singular positions are retained, rather than used for propagation.
 longtarget=[F.mul(F.pw(q,k),F.ev(D,F.pw(q,k))) for k in range(N+2)]
 ck(all(v==0 for v in Lseq(longtarget,q,0)),'first-order identity through zero coefficients')
 ck(F.sub(1,F.pw(q,(N-2)+2))==0 and F.sub(1,F.pw(q,(N-d)+d))==0,'variable propagation pivots really can vanish')
 damaged=[F.sub(F.mul(F.sub(1,F.pw(q,k+1)),longtarget[k+1]),F.mul(F.mul(q,F.sub(1,F.pw(q,k+d))),longtarget[k])) for k in range(N+1)]
 ck(any(damaged),'negative changed first-order coefficient detected')
 ck((6*d-3)-2*d-1==4*d-4,'negative missing strict zero-count margin detected')
 fixtures.append({'N':N,'d':d,'characteristic':F.p,'field_size':F.size,'q':q,'old_threshold':8*d-10,'new_threshold':6*d-2,'bank_bound':2*m+2,'envelope_rank':rank,'distinct_zero_count':N-2*d-1,'max_transformed_degree':4*d-4})
print(json.dumps({'passed':True,'fixtures':fixtures,'checks':dict(checks),'total':sum(checks.values()),'author_code_executed':False,'finite_checks_not_a_uniform_proof':True},indent=2))
