#!/usr/bin/env python3
"""Fresh controls for the first-order support lemma; no historical imports."""
import json, math, random, hashlib
from pathlib import Path

class Field:
    def __init__(self,p,mod=0):
        self.p=p; self.mod=mod; self.Q=(1<<(mod.bit_length()-1)) if mod else p
    def add(self,a,b): return a^b if self.mod else (a+b)%self.p
    def neg(self,a): return a if self.mod else (-a)%self.p
    def sub(self,a,b): return self.add(a,self.neg(b))
    def mul(self,a,b):
        if not self.mod:return a*b%self.p
        r=0
        while b:
            if b&1:r^=a
            b>>=1;a<<=1
            if a&self.Q:a^=self.mod
        return r
    def pow(self,a,n):
        if n<0:return self.pow(self.inv(a),-n)
        r=1
        while n:
            if n&1:r=self.mul(r,a)
            a=self.mul(a,a);n>>=1
        return r
    def inv(self,a):
        assert a
        r=self.pow(a,self.Q-2);assert self.mul(a,r)==1
        return r
    def integer(self,a):return (a%2) if self.mod else a%self.p

def trim(a):
    a=a[:]
    while len(a)>1 and not a[-1]:a.pop()
    return a

def add(a,b,F):
    r=[0]*max(len(a),len(b))
    for i,x in enumerate(a):r[i]=F.add(r[i],x)
    for i,x in enumerate(b):r[i]=F.add(r[i],x)
    return trim(r)

def scale(a,c,F):return trim([F.mul(x,c) for x in a])
def mul(a,b,F):
    r=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):r[i+j]=F.add(r[i+j],F.mul(x,y))
    return trim(r)
def rem(a,b,F):
    a=trim(a);b=trim(b); inv=F.inv(b[-1])
    while len(a)>=len(b) and a!=[0]:
        c=F.mul(a[-1],inv);off=len(a)-len(b)
        for j,v in enumerate(b):a[off+j]=F.sub(a[off+j],F.mul(c,v))
        a=trim(a)
    return a

def gcd(a,b,F):
    while b!=[0]:a,b=b,rem(a,b,F)
    return scale(a,F.inv(a[-1]),F)

def ev(a,x,F):
    y=0
    for c in a[::-1]:y=F.add(F.mul(y,x),c)
    return y

def pder(a,F):return trim([F.mul(F.integer(i),a[i]) for i in range(1,len(a))] or [0])

def rref(a,F):
    a=[r[:] for r in a];piv=[];i=0
    if not a:return a,piv
    for j in range(len(a[0])):
        pivot=next((r for r in range(i,len(a)) if a[r][j]),None)
        if pivot is None:continue
        a[i],a[pivot]=a[pivot],a[i];fac=F.inv(a[i][j]);a[i]=[F.mul(x,fac) for x in a[i]]
        for r in range(len(a)):
            if r!=i and a[r][j]:
                fac=a[r][j];a[r]=[F.sub(x,F.mul(fac,y)) for x,y in zip(a[r],a[i])]
        piv.append(j);i+=1
        if i==len(a):break
    return a,piv

def nullspace(A,F):
    rr,piv=rref(A,F);n=len(A[0]);bs=[]
    for j in range(n):
        if j in piv:continue
        a=[0]*n;a[j]=1
        for i,k in enumerate(piv):a[k]=F.neg(rr[i][j])
        bs.append(a)
    return bs

def lincomb(bs,cs,F):
    a=[0]*len(bs[0])
    for b,c in zip(bs,cs):
        for i,x in enumerate(b):a[i]=F.add(a[i],F.mul(c,x))
    return a

def dot(a,b,F):
    r=0
    for x,y in zip(a,b):r=F.add(r,F.mul(x,y))
    return r

def primitive(N,F):
    for q in range(2,F.Q):
        powers=[F.pow(q,j) for j in range(N)]
        if len(set(powers))==N and F.pow(q,N)==1:return q
    raise AssertionError('no primitive root')

def axis(g,N,F):
    m=len(g)-1; ps=[];p=[1]
    for j in range(N):
        ps.append(p+[0]*(m-len(p)));p=rem([0]+p,g,F)
    return [ps[a]+[1]+ps[(-a)%N] for a in range(N)]

def case(N,d,F):
    m=N-d;q=primitive(N,F);rho=F.pow(q,pow(2,-1,N));h=pow(4,-1,N)
    C=lambda k:F.pow(q,h*k*k%N)
    D=[1]
    for j in range(2,d):D=mul(D,[1,F.neg(F.pow(q,j))],F)
    ds=[ev(D,F.pow(q,k),F) for k in range(m+1)];assert all(ds)
    E=[]
    for r in range(3*d-6):E.append([F.mul(F.mul(C(k),F.pow(rho,r*k)),F.inv(ds[k])) for k in range(m+1)])
    for r in range(d-1):E.append([F.mul(F.pow(q,r*k),F.inv(ds[k])) for k in range(m+1)])
    U=nullspace(E,F);erank=len(E)-sum(all(not x for x in r) for r in rref(E,F)[0]);assert len(U)==m+1-erank
    assert all(ev(g,1,F)==0 for g in U)
    ug=[0]
    for g in U:ug=gcd(ug,trim(g),F)
    assert ug==[F.neg(1),1],ug
    endpoints=[[g[0],g[1],g[m]] for g in U]; assert len(rref(endpoints,F)[1])==3
    U0=nullspace(E+[[1]+[0]*m],F);ug0=[0]
    for g in U0:ug0=gcd(ug0,trim(g),F)
    assert ug0==[0,F.neg(1),1],ug0
    # Direct original whole-left Gaussian row identity, including support zeros.
    def G(eps,delta,a,b):
        r=eps*a%N;l=delta*b%N
        if r+l>=N:return 0
        base=F.pow(q,eps*delta);v=1
        for z in range(1,l+1):v=F.mul(v,F.mul(F.sub(1,F.pow(base,r+z)),F.inv(F.sub(1,F.pow(base,z)))))
        return v
    def target(a,b):return F.pow(q,h*(a+b)**2%N)
    A=[]
    for b in range(1,d-1):
        T=F.inv(G(-1,1,N-b,b))
        for a in range(1,d-b):
            row=[]
            for k in range(m+1):
                v=F.mul(F.sub(target(a+k,b),F.mul(T,G(-1,1,a+k,b))),F.inv(G(1,1,a+k,b)))
                row.append(v)
            assert all(dot(row,g,F)==0 for g in U)
            A.append(row)
    rng=random.Random(14159+N+d)
    # Fresh variable-operator identity and leading-coefficient checks, even where coefficients vanish.
    operator_checks=0;singular_positions=[]
    for x in [1,q,F.add(1,q)]:
        if not x:continue
        P=[rng.randrange(F.Q) for _ in range(3*d-6)];P[-1]=1
        R=[rng.randrange(F.Q) for _ in range(d-1)]
        Pr=[F.mul(a,F.pow(rho,j)) for j,a in enumerate(P)]
        phi=add(scale(mul([0,1,0,F.neg(F.pow(q,2))],Pr,F),F.pow(q,h),F),scale(mul([1,0,F.neg(F.pow(q,d))],P,F),F.neg(x),F),F)
        assert len(phi)-1==len(P)+2
        assert phi[-1]==F.neg(F.mul(F.pow(q,(h+2)%N),F.pow(rho,len(P)-1)))
        Rq=[F.mul(a,F.pow(q,j)) for j,a in enumerate(R)]
        Rout=add(mul([1,F.neg(F.pow(q,2))],Rq,F),scale(mul([1,F.neg(F.pow(q,d))],R,F),F.neg(x),F),F)
        assert len(Rout)-1<=d-1
        for k in range(N):
            z=F.pow(q,k);a=F.sub(1,F.mul(F.pow(q,2),z));b=F.sub(1,F.mul(F.pow(q,d),z))
            if not a or not b:singular_positions.append(k)
            L=lambda fun:F.sub(F.mul(a,fun(k+1)),F.mul(F.mul(x,b),fun(k)))
            assert L(lambda j:F.mul(F.pow(x,j),ev(D,F.pow(q,j),F)))==0
            assert L(lambda j:F.mul(C(j),ev(P,F.pow(rho,j),F)))==F.mul(C(k),ev(phi,F.pow(rho,k),F))
            assert L(lambda j:ev(R,F.pow(q,j),F))==ev(Rout,z,F)
            if x==1:
                assert L(lambda j:F.mul(F.integer(j),ev(D,F.pow(q,j),F)))==F.mul(b,ev(D,z,F))
            operator_checks+=1
        # Apply the ordinary annihilator and check exact degree rises at every step.
        pp=phi
        for r in range(d):
            shifted=[0]+[F.mul(F.mul(c,F.pow(rho,j)),F.pow(q,h)) for j,c in enumerate(pp)]
            pp=add(shifted,scale(pp,F.neg(F.pow(q,r)),F),F)
        assert len(pp)-1==4*d-4
    # Legal coefficient polynomial, exact recurrence and axis guards.
    for attempt in range(1,500):
        g=lincomb(U,[rng.randrange(F.Q) for _ in U],F)
        if not g[-1]:continue
        g=scale(g,F.inv(g[-1]),F)
        if not g[0] or gcd(g,pder(g,F),F)!=[1]:continue
        X=axis(g,N,F);arank=len(rref(X,F)[1])
        if arank==N:break
    else:raise AssertionError('no guarded g')
    assert all(dot(row,g,F)==0 for row in A)
    assert N>=6*d-2
    return {'N':N,'d':d,'m':m,'field':{'p':F.p,'binary_modulus':F.mod,'Q':F.Q},'q':q,'new_B':2*m+2,'prior_B':2*N-2*((N+10)//8)+2,'outside_old_range':N<8*d-10,'envelope_rank':erank,'dim_U':len(U),'gcd_U':ug,'gcd_U0':ug0,'endpoint_rank':3,'actual_recurrence_rows':len(A),'axis_rank':arank,'g':g,'attempts':attempt,'operator_identity_checks':operator_checks,'tested_vanishing_variable_coefficient_positions':sorted(set(singular_positions)),'post_operator_degree':4*d-4,'known_distinct_zero_count':N-2*d-1,'all_pass':True}

def main():
    # Prime choices have N | p-1. Binary moduli are validated by inversion for every nonzero element.
    specs=[(23,4,47,0),(29,5,59,0),(35,6,71,0),(41,7,83,0),(47,8,283,0),(53,9,107,0),(59,10,709,0),(63,10,2,0b1000011),(95,16,191,0),(127,21,2,0b10000011)]
    results=[]
    for N,d,p,mod in specs:
        F=Field(p,mod)
        if mod:
            for a in range(1,F.Q):assert F.mul(a,F.inv(a))==1
        results.append(case(N,d,F));print('PASS',N,d,flush=True)
    out={'description':'Fresh exact finite-field checks. No actual splitting fields or literal bank arrays were instantiated. General bank reconstruction is proved, not inferred from these controls.','cases':results,'all_pass':True}
    dest=Path(__file__).parent/'EXACT_CONTROLS.json';dest.write_text(json.dumps(out,indent=2)+'\n');print(dest)
if __name__=='__main__':main()
