"""Reviewer-authored exact controls. No candidate scientific code is imported."""
import hashlib,itertools,json,pathlib
ROOT=pathlib.Path('compatibility_author')
counts={}
def check(b,k):
    counts[k]=counts.get(k,0)+1
    if not b: raise RuntimeError(k)
def zero_sum(exponents,p,q):
    # Rational cyclotomic tensor basis: last power equals minus preceding ones.
    A=[[0]*q for _ in range(p)]
    for e in exponents: A[e%p][e%q]+=1
    corner=A[p-1][q-1]
    return all(A[i][j]-A[i][q-1]-A[p-1][j]+corner==0 for i in range(p-1) for j in range(q-1))
def prime(x): return x>=2 and all(x%d for d in range(2,int(x**.5)+1))
def divisor_mask(p,q,d):
    N=p*q;m=N//d
    return [set(range(r//d,N,m)) for r in range(N)]
def transpose(rows,N):
    cols=[set() for _ in range(N)]
    for r,S in enumerate(rows):
        for c in S: cols[c].add(r)
    return cols
def gram(rows,labels,p,q,degree,expected):
    # Entire original-index rectangular/square row Gram, not an incidence proxy.
    failures=[]
    for i,S in enumerate(rows):
        check(len(S)==degree,'diagonal_degree')
        for j in range(i):
            ok=zero_sum(((labels[i]-labels[j])*c for c in S&rows[j]),p,q)
            counts['original_offdiagonal_gram']=counts.get('original_offdiagonal_gram',0)+1
            if not ok: failures.append([labels[i],labels[j]])
    check((not failures)==expected,'gram_expected')
    return failures[:1]
# Frozen bytes and immutable Git-blob bindings, not a recursive archive audit.
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
for item in manifest['files']:
    data=(ROOT/item['path']).read_bytes()
    check(len(data)==item['size'] and hashlib.sha256(data).hexdigest()==item['sha256'],'author_manifest')
for item in json.loads((ROOT/'SOURCE_BINDINGS.json').read_text()):
    data=(ROOT/item['local']).read_bytes()
    check(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_blob_sha'],'source_git_blob')
# Full original CRT phase identity in several prime ratios including new p>=7.
for p,q in [(3,5),(5,7),(7,11),(7,31)]:
    N=p*q;ep=q*pow(q,-1,p);eq=p*pow(p,-1,q)
    for r in range(N):
        for c in range(N):
            check((r*c-ep*(r%p)*(c%p)-eq*(r%q)*(c%q))%N==0,'crt_phase')
    check((ep+1)%p!=1,'wrong_crt_rejected')
# Exhaust all binary overlap masks at pq=15, independently test cancellation shape.
p,q=3,5
for mask in range(1<<(p*q)):
    E=[e for e in range(p*q) if mask>>e&1]
    fiber=all(len({(mask>>e)&1 for e in range(p*q) if e%q==v})==1 for v in range(q))
    line=all(len({(mask>>e)&1 for e in range(p*q) if e%p==u})==1 for u in range(p))
    check(zero_sum(E,p,q)==(fiber or line),'binary_cancellation')
records=[]
for p,q in [(3,5),(5,7),(7,11),(7,31)]:
    N=p*q
    for d in [1,p,q,N]:
        rows=divisor_mask(p,q,d)
        for sides in [rows,transpose(rows,N)]: gram(sides,list(range(N)),p,q,d,True)
        records.append({'p':p,'q':q,'degree':d,'both_grams':'pass'})
# Exact regular masks are not automatically orthogonal: original-index circulants.
p,q=7,31;N=p*q
for d in [8,32,37,62,93]:
    rows=[{(r+k)%N for k in range(d)} for r in range(N)]
    bad=[gram(sides,list(range(N)),p,q,d,False) for sides in [rows,transpose(rows,N)]]
    records.append({'p':p,'q':q,'degree':d,'negative_first_pairs':bad})
# Uniform threshold and capacity algebra, testing integer identities, not the theorem.
for p in [x for x in range(3,44,2) if prime(x)]:
    T=(p-1)*(p-2)
    for q in [x for x in range(p+1,2001) if prime(x) and x>T]:
        check(q>2*p-2,'threshold_implies_star_range')
        d=q+p-1
        check(d*d-p*(d+(p-2)*q)==q*q-T*q-(p-1)>0,'second_moment_obstruction')
        for h in range(1,p):
            for m in range(0,min(q,2*p)+1):
                excess=(p-1)*(q*h+(q-m)*(p-1))+m*d-p*q*(p-1)
                reduced=m*(q-T)+q*(p-1)*(h-1)
                check(excess==reduced,'capacity_identity')
                check((excess<=0)==(m==0 and h==1),'capacity_uniqueness')
# Build independent Fano rectangular countercontrol in actual cyclic indices.
p,q=11,23;N=p*q;ep=q*pow(q,-1,p);eq=p*pow(p,-1,q)
rows=[set() for _ in range(q)];slots=[]
for v in range(q):
    if v<5:
        for b in range(7):
            for u in [b,(b+1)%7,(b+3)%7]: rows[b].add((u*ep+v*eq)%N)
        base=7;available=range(8,11)
    else:
        for b in range(7): rows[b].add((v*eq)%N)
        base=1;available=range(2,11)
    for b in range(7,q): rows[b].add((base*ep+v*eq)%N)
    slots.extend((u*ep+v*eq)%N for u in available)
for j,c in enumerate(slots[:160]): rows[7+j%16].add(c)
labels=[(b*eq)%N for b in range(q)]
gram(rows,labels,p,q,33,True)
for b in range(q):
    neighbors=[c for c in range(q) if c!=b and rows[b]&rows[c]]
    check(len(neighbors)==(6 if b<7 else 15),'fano_components')
check(q>2*p-2 and q<=(p-1)*(p-2),'fano_scope')
# It is not a square two-sided witness; some rectangular columns have wrong norms.
check(len(rows)!=N and any(len(S)!=33 for S in transpose(rows,N)),'rectangular_not_full_mask')
result={'status':'PASS','checks':counts,'total_checks':sum(counts.values()),'mask_fixtures':records,'fano_scope':'23 by 253 row Gram only, not a square mask','author_code_executed':False}
print(json.dumps(result,sort_keys=True,indent=2))
