# Independent mathematical review: symbolic-prime binary Fourier masks

Date: 2026-10-23 UTC. Verdict: **ACCEPT at the exact scopes below.** No mathematical repair is required to the frozen packet.

## 1. Exact binding and accepted delta

Reviewed author directory: `semiprime_mask_compatibility_20261023_frozen_v1`.

- REPORT.md SHA-256: `1a51d0d0e7b3a5e418eee5b5660e5752ac14fc7b1da7e26a6e0d68a2c64b010d`.
- MANIFEST.json SHA-256: `e8d5d819224c7cc881b9961142e4b2b3463c5bb5a39469292a89c1334ba6924b`.
- All 25 declared members match their lengths and SHA-256 hashes. All eight selected inert source bodies match their declared immutable Git blob identifiers.

For odd primes p<q, N=pq, primitive complex zeta, and an arbitrary binary square R, set D[r,c]=R[r,c] zeta^(rc), in the actual original cyclic indices. The following are accepted:

1. Either scalar Gram identity forces d in {0,1,p,pq} union [q,q+p-1].
2. If q>2p-2, degrees q+t with 1<=t<=p-2 are excluded.
3. If q>(p-1)(p-2), the exact attainable degree set is {0,1,p,q,pq}.
4. In the original simultaneous inverse-row-sparsity model and under the last prime separation, Delta(pq,s)=sqrt(1-s/(pq)) holds exactly at s in {pq-1,pq-p,pq-q}, for 1<=s<=pq-1. Other budgets have a strict infimum gap, with no claimed numerical gap size.

New credit is restricted to p>=7 and excludes previously accepted scopes. The accepted p=3 and p=5 classifications are not weakened or republished as new results. M-SPARSE-DEFECT remains TO RESEARCH, priority 42. There is no complete close-prime classification, support-pattern classification, arithmetic speedup, or historical novelty clearance.

## 2. Source comparison and exact model

The selected predecessor is the accepted order-5q classification at commit `2af731c19cfa5409c358580e2ed07e7e5d7aae92`, `math/finalized/2026-10-19-fiveprime-degree-classification/THEOREM.md`, with its synthesis and separate acceptance. Its dense-range coverage, fiber packing, and q-multiple arguments have symbolic-p forms; its small incidence catalogue is specifically five-coordinate. The present proof replaces that catalogue by a second-moment and occupancy bound, rather than extrapolating it.

A Gram diagonal makes d an integer in [0,N]. For d>0 the square matrix is invertible, so either Gram identity implies both and all row and column degrees equal d. At d=0 no invertibility is invoked. The CRT idempotents e_p and e_q give the literal identity rc=e_p au+e_q bv modulo N. Thus the CRT proof neither selects new phases nor substitutes a rectangular model.

The inherited cancellation facts are used only at their correct scope. Same-a row overlaps have constant counts in the q fibers; same-b overlaps have constant counts in the p lines. For primitive differences, a binary overlap is a union of whole fibers or whole lines. One may verify the latter directly in the rational cyclotomic tensor basis: vanishing gives an array A_u+B_v; a binary array of this form cannot vary nontrivially in both coordinates, since its two independent ranges would have total width at least two. This remains classical cancellation, not a new priority claim.

For d<q, q same-group rows have disjoint supports, forcing d<=p. If 1<d<p, every nonempty overlap would have at least p entries, impossible; all rows would be disjoint, forcing d<=1. This is inherited low-range reasoning.

## 3. Dense-range proof

When p+q-1<d<pq, every supported column has a supporting partner row differing from a given row in both CRT coordinates. Primitive cancellation therefore places a full line or fiber through every supported entry. It follows, rather than being assumed, that each support is

    (A_r x Z_q) union (Z_p x B_r),
    d=ell_r q+(p-ell_r)f_r.

The maximal sets have ell_r<p and f_r<q. Within one row group, the B_r are disjoint: a common full fiber would make every fiber intersection have size p and force full supports.

For d=kq, 2<=k<=p-1, primality and 0<p-ell_r<q imply f_r=0 and ell_r=k. At a fixed second row coordinate, order-p balance makes the proper line sets pairwise disjoint. There cannot be p disjoint k-subsets of p points.

For q not dividing d, all B_r are nonempty. The q disjoint nonempty subsets of q fibers are singletons and form a permutation. Hence d=p+ell(q-1). Comparing the two special fibers with an ordinary fiber in a same-group pair forces its A sets equal. Column degrees then make every line belong to exactly ell groups. Those group A sets cannot all coincide, since 0<ell<p. Choose unequal A sets and rows differing in both their second coordinate and their special fiber. At most two choices are forbidden, so such a pair exists. The overlap has ell points in its two special fibers and a strictly smaller ordinary intersection. It is neither whole fibers nor whole lines. This closes every proper degree above p+q-1, including q-multiple endpoints.

## 4. Narrow-window and row-line quotient

At d=q+t<2q, a same-group overlap has either zero or one entry in each fiber. Every row has a fiber of weight at most one. A zero makes it isolated; a singleton makes its neighbors a clique. Consequently all connected components are cliques. Selecting one row per component shows there are at most p-1 components.

In one fiber of a nonsingleton clique, row restrictions intersect pairwise in exactly one point. If they share a point, it is unique and all other entries are private. Otherwise every row weight is at least two, and the incidence Gram is diag(w_i-1)+J, positive definite. Thus a nonstar component has at most p rows. Repeated restrictions cause no exception. Singleton components can be empty and are not assigned fictional baseline incidences.

Assume q>2p-2 and t<=p-2. A full p-fiber in one row would force every other component to be singleton, giving its component at least q-(p-2)>p rows. It would be a star in every fiber, but the row has only t private extras, fewer than the p-1 required for a full fiber. Thus no full fiber exists.

A row also lacking a full line has no primitive overlap. Each of its supported columns then has at least d-(p-1)>=q-p+2 incidences from its own group. This is greater than p and q/2. Such incidences belong to one large clique, whose only high-multiplicity columns are its q baselines. They cannot cover d>q row entries. Therefore every row has one full q-line and t extras.

Rows with different baseline lines have intersection at most 2t<q. Same-group balance, primitive cancellation, and same-b balance each force this intersection empty. In the last case each row uses at most 1+t<=p-1 lines, so some line intersection is zero. A nonempty baseline class consequently has exactly d rows by column regularity. Summing classes gives pq=h d with h<=p<q, which forces q|d, impossible in the open interval. No common-support or Cartesian ansatz was assumed.

## 5. Boundary d=q+p-1

Fix one group and let its clique sizes be n_i. Set S=sum n_i(n_i-1). In each fiber, column multiplicities x_u satisfy sum x_u^2=I+S. Cauchy and averaging over the fibers yield

    d^2 <= p(d+S).

If all components had size at most p-1, then S<=(p-2)q. Substitution gives q^2-(p-1)(p-2)q-(p-1)<=0. For integer q>(p-1)(p-2), its left side is at least q-(p-1)>0. Hence a component of size at least p exists.

The hypothesis also gives q>2p-2: for p>=5 this is immediate, and p=3 uses q>=5. A component larger than p is a star by the rank test. If a size-p component were nonstar in one fiber, it would occupy all p positions there; every other component would be singleton, forcing q<=2p-2. Therefore all large components are stars in every fiber.

Let h_L be the number of large components and m the number of rows in small components. Large components use exactly q h_L+(q-m)(p-1) column positions. Small components need at least m(q+p-1)/(p-1) further positions, since their multiplicities are at most p-1 and component supports are disjoint. The pq-position capacity gives

    m[q/(p-1)-(p-2)] <= q(1-h_L).

The positive left coefficient and h_L>=1 force m=0 and h_L=1. This is the actual new symbolic-p step, with no assumption that all small designs are near-pencils.

Each group is now one star clique per fiber and uses every nonbaseline position exactly once. If a column is baseline in h groups, its degree is hq+(p-h)=q+p-1, so h=1. Baseline sets across groups are disjoint. Take one row's extra column and the group for which it is a baseline. Every row of that group meets the chosen row; their overlaps have size at most 2(p-1)<q. The q-1 primitive partners therefore each require a full p-fiber. The chosen row has only p-1 extras and can contain at most one full fiber; privacy in the partner group permits at most one row to contain that whole fiber. This contradicts q-1>1. The boundary is excluded.

## 6. Attainment and inverse-row translation

For d dividing N, the original mask floor(r/d)=c mod(N/d) consists of disjoint d-by-d blocks. Their entries are zeta^((td+u)t)(zeta^(N/d))^(u ell), so both block Grams equal dI. This proves attainment at 1,p,q,N; the zero mask supplies zero. It does not classify all supports.

The exact inverse-row criterion is contained in the selected `sources/E_REVIEW.md`, SHA-256 `54511a4d4c1e343b5d3bbe3edb7d9a054d42a4200681bb17cf0bda6c11538253`, Git blob `8a23ab3f7eb388283ed6e7b7362a9fa5fc81e9c7`. I checked its Sections 1-4: equality rigidifies every inverse row, the spanning inverse rows force the error Gram to be scalar, and the complementary Fourier mask has degree d=N-s. Conversely, normality of F* C yields an invertible attained witness. Compactness applies because the floor is strictly below one for s>=1, making a near-minimizing sequence uniformly nonsingular. Thus absence of a mask gives a strict infimum gap, not merely absence of attainment. The claimed translation uses only 1<=s<=N-1 and excludes the singular endpoint s=0.

## 7. Independent exact controls and limits

`fresh_controls.py` was written for this review and does not import or execute any author or historical scientific script. It uses integers and the exact rational basis of Q(zeta_p,zeta_q), with no floating-point norm or root tolerance. Normal and optimized Python outputs are byte-identical. There are 4,305,569 recorded checks, including:

- all 25 manifest members and eight selected Git blob bindings;
- 54,468 original cyclic-index CRT phase equalities;
- exhaustive exact cancellation and shape comparison for all 32,768 binary masks at N=15;
- 16 positive divisor masks at (p,q)=(3,5),(5,7),(7,11),(7,31), checking both full original-index Grams;
- five deliberately regular but nonorthogonal original cyclic masks at N=217, of degrees 8,32,37,62,93, each rejected in both Gram orders;
- 451,109 actual off-diagonal Gram comparisons in total, plus 4,945 diagonal degree checks;
- exact threshold and occupancy identities for prime pairs in the recorded bounded grid, including the p=3 edge;
- an independently constructed Fano rectangular control at (p,q,d)=(11,23,33), with components 7 and 16 and exact row Gram. It is expressly not a square two-sided equality mask.

The Fano control establishes that the local one-clique conclusion cannot simply be extended to every q>2p-2. It neither proves nor refutes a full square boundary mask at those close ratios. The finite controls corroborate the proof and scope; they do not prove the universal prime quantifiers. Author controls are separately labeled and were not used as independent execution evidence.

No original unresolved owner was closed, no novelty status was promoted, and no GitHub, table, or other external state was changed by this review.
