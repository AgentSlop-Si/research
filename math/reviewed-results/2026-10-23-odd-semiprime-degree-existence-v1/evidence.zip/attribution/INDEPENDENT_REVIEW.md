# Independent bounded attribution review

23 October 2026 UTC. ACCEPT the hypothesis/domain comparison in REPORT.md, SHA-256 `e577d54624d17943a3e73da6e9c388cf20593a3db18f1232875124151152f59e`. The original three-member manifest `0ea1e3b987b1531fd5d12e90efd76700f2a463f5221c45854e3040478569f3cc` remains unchanged. This is not a new mathematical classification, exhaustive literature search, or historical novelty clearance.

The target quantifier is precise: a successful binary square mask EXISTS exactly at degrees 0,1,p,q,pq; necessity holds for every successful mask, not every mask of a listed degree. Arbitrary masks may have different row supports.

I independently checked the relevant primary theorem passages and the following deductions:

1. Bond–Glickfield–Herr Theorem 1 applies to Cartesian Fourier submatrices. At order pq, its divisor tests give n=p when 1<n<=p, n=q when p<n<=q, and n=pq when q<n<=pq. Thus the report correctly identifies the divisor-cardinality submatrix branch as known. Direct NSF PDF retrieval again failed; I checked the journal article's indexed full-text mirror, specifically Theorem 1 and its surrounding setup, not a complete PDF. The author's narrower retrieval description is not promoted to a complete read. [Journal article mirror](https://www.researchgate.net/publication/330062454_On_the_existence_of_complex_Hadamard_submatrices_of_the_Fourier_matrices), [DOI](https://doi.org/10.1515/dema-2019-0001).

2. Malikiosis–Kolountzakis Theorem 1.2 sends spectral subsets of Z_(p^n q) to translational tiles. At exponent one, tile cardinality divides pq. A square Hadamard submatrix gives a spectral pair with ONE fixed support, so the report's application is valid. An arbitrary masked Gram instead sums over pair-dependent intersections; no common-support reduction follows from that hypothesis. This is a missing proved reduction, not a claim that no future reduction can exist. [Primary paper, Theorem 1.2 and setup](https://arxiv.org/pdf/1612.01328).

3. Lam–Leung Theorem 3.3 and Corollary 3.4 provide the inherited nonnegative two-prime cycle structure. At pq, binary coefficients prohibit mixing intersecting cycles of the two orientations. The authors themselves attribute the antecedent structure to de Bruijn; the original de Bruijn body was not checked here. [Primary paper](https://arxiv.org/pdf/math/9511209).

4. Herr–Wiegand Theorem 2.6 retains Cartesian row/column selections and does not assert a conversion from arbitrary masks. Best–Kharaghani–Ramp allow arbitrary unit-modulus entries; their order-three and order-four weight-three blocks yield order 35 by 3+8*4. This distinguishes unrestricted weighing matrices from literal Fourier masks without asserting those example phases are 35th roots. [Herr–Wiegand](https://arxiv.org/pdf/1909.13145), [Best–Kharaghani–Ramp](https://arxiv.org/pdf/1209.4581).

5. Severini's support criterion does not prescribe Fourier entries. Egan–O Cathain–Svob Theorem 3.1 explicitly restricts order, primitive automorphism rank, and orbital coefficients. Neither inspected statement is an arbitrary fixed-Fourier-mask classification. [Severini, Lemma 1 and Theorem 1](https://arxiv.org/pdf/math/0205187), [Egan–O Cathain–Svob, Theorem 3.1](https://arxiv.org/pdf/2607.16069).

The bounded conclusion is therefore supported: classical cancellation and the common-support divisor list are not new credit; the inspected results do not themselves supply the full arbitrary-mask implication. No theorem repair, mathematical owner/status change, global nonimplication, or priority assertion follows. Author source/read ledgers remain frozen; no scientific or historical program was run for this attribution review.
