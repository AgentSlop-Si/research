#!/usr/bin/env python3
"""Fresh original-index exact controls, with no imports of earlier checkers."""
import json,math,pathlib,time
ROOT=pathlib.Path(__file__).resolve().parent
C={}
def ck(b,k):
    if not b:raise RuntimeError(k)
    C[k]=C.get(k,0)+1

def primes(bound):return [x for x in range(3,bound+1,2) if all(x%d for d in range(2,math.isqrt(x)+1))]
def original(p,q,a,b):return (a*q*pow(q,-1,p)+b*p*pow(p,-1,q))%(p*q)
def kernel(exponents,p,q):
    z=[[0]*q for _ in range(p)]
    for e in exponents:z[e%p][e%q]+=1
    corner=z[-1][-1]
    coeff=tuple(z[a][b]-z[a][-1]-z[-1][b]+corner for a in range(p-1) for b in range(q-1))
    return coeff

def support(p,q,kind,t):
    n=p*q;out=[]
    for r in range(n):
        a,b=r%p,r%q
        if kind=='divisor':s={c for c in range(n) if c%(n//t)==r//t}
        elif kind=='cross':s={c for c in range(n) if c%p==a or c%q==b}
        elif kind=='cross_permuted':s={c for c in range(n) if c%p==a or c%q==((a+1)*b+a)%q}
        elif kind=='split':
            base=a if b else (a+1)%p
            s={c for c in range(n) if c%p==base}
            s.update(original(p,q,(a+j)%p,b) for j in range(2,t+2))
        else:raise ValueError(kind)
        out.append(s)
    return out

def full_control(p,q,kind,t,positive):
    n=p*q;rr=support(p,q,kind,t);cc=[set() for _ in range(n)];d=len(rr[0])
    for r,s in enumerate(rr):
        for c in s:cc[c].add(r)
    ck(all(len(s)==d for s in rr+cc),'two_degree_counts')
    res={'p':p,'q':q,'kind':kind,'parameter':t,'degree':d,'gram_results':[]}
    for label,ss in [('DD*',rr),('D*D',cc)]:
        nonzero=0;witness=None
        for i in range(n):
            ck(len(ss[i])==d,'gram_diagonal')
            for j in range(i):
                exps=[((i-j)*x)%n for x in ss[i]&ss[j]]
                coeff=kernel(exps,p,q)
                C['gram_offdiagonal']=C.get('gram_offdiagonal',0)+2
                if any(coeff):
                    nonzero+=2
                    if witness is None:witness={'indices':[i,j],'exponents':exps,'nonzero_coefficient':next(([k,v] for k,v in enumerate(coeff) if v))}
        ck((nonzero==0)==positive,'expected_gram_outcome')
        res['gram_results'].append({'orientation':label,'nonzero_count':nonzero,'first_witness':witness})
    return res

def main():
    start=time.time();controls=[]
    ps=primes(100)
    for p in ps:
      for q in ps:
       if q<=p:continue
       ck(p+1<q+1,'deficient_column_contradiction')
       ck(q+p-1<2*q,'narrow_window_overlap_cap')
       gap=(p-1)*(q+p-1)-(q+p-2+(p-1)**2)
       ck(gap==(p-2)*(q-1) and gap>0,'cross_incidence_contradiction')
       ck(p-1>=2,'competing_supporters_overlap_contradiction')
       for t in range(1,p-1):ck(t+1<p and t<p-1,'interior_line_row_conditions')
    # Fully original-index square tests in previously unclassified close-prime ranges.
    for p,q in [(7,11),(7,13),(11,13)]:
        for d in [1,p,q,p*q]:controls.append(full_control(p,q,'divisor',d,True))
        for t in [1,p-2]:controls.append(full_control(p,q,'split',t,False))
        for kind in ['cross','cross_permuted']:controls.append(full_control(p,q,kind,0,False))
    # Literal original-index cross character sum, retaining center/difference phase.
    # Kernel coefficients agree with the claimed integer multiple of one monomial.
    for p,q in [(3,5),(5,7),(7,11),(7,13),(11,13),(11,23)]:
        n=p*q
        for a,b in [(0,0),(1,2),(p-1,q-1)]:
            row=original(p,q,a,b)
            X=[r for r in range(n) if r%p==a or r%q==b]
            ck(len(X)==p+q-1,'cross_support_size')
            for du in range(p):
             for dv in range(q):
              if not (du or dv):continue
              delta=original(p,q,du,dv)
              coefficient=q*int(dv==0)+p*int(du==0)-1
              got=kernel([(r*delta)%n for r in X],p,q)
              basis=kernel([(row*delta)%n],p,q)
              ck(got==tuple(coefficient*x for x in basis) and any(got),'original_cross_character_sum')
    result={'status':'PASS','counts':C,'controls':controls,'elapsed_seconds':round(time.time()-start,3),'limits':'Finite exact controls only; no square-mask census and no historical program executed.'}
    (ROOT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','counts':C,'full_square_controls':len(controls),'elapsed_seconds':result['elapsed_seconds']},sort_keys=True))
if __name__=='__main__':main()
