"""Independent exact controls of the new global compatibility steps only."""
import hashlib,json,pathlib,itertools
counts={}
def ck(ok,kind):
 counts[kind]=counts.get(kind,0)+1
 if not ok:raise RuntimeError(kind)
def zero(terms,p,q):
 # Exact rational cyclotomic basis, allowing signed integer multiplicities.
 A=[[0]*q for _ in range(p)]
 for e,w in terms:A[e%p][e%q]+=w
 return all(A[i][j]-A[-1][j]-A[i][-1]+A[-1][-1]==0 for i in range(p-1) for j in range(q-1))
def prime(n):return n>1 and all(n%d for d in range(2,int(n**.5)+1))
R=pathlib.Path('full_author')
for item in json.loads((R/'MANIFEST.json').read_text())['files']:
 b=(R/item['path']).read_bytes();ck(len(b)==item['size'] and hashlib.sha256(b).hexdigest()==item['sha256'],'manifest_member')
for item in json.loads((R/'SOURCE_BINDINGS.json').read_text()):
 b=(R/item['local']).read_bytes();ck(b==pathlib.Path(item['original']).read_bytes() and hashlib.sha256(b).hexdigest()==item['sha256'],'accepted_source_copy')
# Every center and column difference, not just differences with two nonzero coordinates.
for p,q in [(3,5),(5,7),(7,11),(7,13),(11,13)]:
 N=p*q;ep=q*pow(q,-1,p);eq=p*pow(p,-1,q)
 for r in range(N):
  X={x for x in range(N) if x%p==r%p or x%q==r%q}
  ck(len(X)==p+q-1,'coordinate_cross_size')
  for delta in range(1,N):
   k=p*(delta%p==0)+q*(delta%q==0)-1
   ck(k!=0,'cross_nonzero_coefficient')
   ck(zero([(x*delta,1) for x in X]+[(r*delta,-k)],p,q),'original_cross_character_formula')
# Exhaust cross-row intersection patterns for same-b and primitive partners.
for p,q in [(3,5),(5,7),(7,11)]:
 N=p*q;ep=q*pow(q,-1,p);eq=p*pow(p,-1,q)
 C=[c for c in range(N) if c%p==0 or c%q==0]
 T={c for c in C if c%p!=0};Fv={c for c in C if c%q==0}
 for mask in range(1<<len(C)):
  I={C[j] for j in range(len(C)) if mask>>j&1}
  line_counts=[sum(c%p==u for c in I) for u in range(p)]
  if len(set(line_counts))==1 and I&T:
   ck(T<=I,'same_b_meets_T_implies_all_T')
   ck(len(I&Fv)>=p-1,'same_b_fiber_intersection')
   # Primitive full-fiber supporter cannot coexist in the same group.
   ck(len(I&Fv)>1,'incompatible_supporter_types')
  if p==3 and zero([(c,1) for c in I],p,q) and I&T:
   ck(Fv<=I,'primitive_meets_T_requires_full_fiber')
 # Mutation: dropping an off-line point defeats positive equal line counts.
 for c in T:
  bad=T-{c}|{0}
  ck(len({sum(z%p==u for z in bad) for u in range(p)})>1,'missing_T_point_detected')
# Exact contradiction identities include the formerly exceptional p=3,q=5.
for p in [x for x in range(3,102,2) if prime(x)]:
 for q in [x for x in range(p+1,202) if prime(x)]:
  ck(p+1<q+1,'deficient_column_degree_contradiction')
  d=p+q-1;required=(p-1)*d;cap=q+p-2+(p-1)**2
  ck(required-cap==(p-2)*(q-1)>0,'sharpened_cross_capacity')
print(json.dumps({'status':'PASS','checks':counts,'total_checks':sum(counts.values()),'author_code_executed':False,'scope':'New propagation/cross-incidence controls. Full-square positive and negative controls are inherited from the independent compatibility review; no rectangular witness is treated as square.'},sort_keys=True,indent=2))
