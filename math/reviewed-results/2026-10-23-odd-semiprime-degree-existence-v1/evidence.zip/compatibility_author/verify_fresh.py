#!/usr/bin/env python3
"""Self-authored exact controls. Does not load or execute historical checkers."""
import json, math, hashlib, pathlib, itertools, time
ROOT=pathlib.Path(__file__).resolve().parent
counts={}
def check(x,tag):
    if not x: raise RuntimeError(tag)
    counts[tag]=counts.get(tag,0)+1

def prime(n): return n>=2 and all(n%a for a in range(2,math.isqrt(n)+1))
def crt(p,q,a,b): return (a*q*pow(q,-1,p)+b*p*pow(p,-1,q))%(p*q)

def rem(a,b):
    a=list(a)
    while len(a)>=len(b):
        c=a[-1]
        if c:
            off=len(a)-len(b)
            for j,v in enumerate(b):a[off+j]-=c*v
        a.pop()
    return tuple(a+[0]*(len(b)-1-len(a)))

def phi(p,q):
    # Phi_p(X^q) / Phi_p(X), independent univariate construction.
    a=[0]*((p-1)*q+1)
    for j in range(p):a[j*q]=1
    b=[1]*p; quo=[0]*(len(a)-len(b)+1)
    for k in range(len(quo)-1,-1,-1):
        c=a[k+len(b)-1];quo[k]=c
        for j,v in enumerate(b):a[k+j]-=c*v
    check(not any(a),'cyclotomic_exact_division')
    return quo

def zero_counts(cs,p,q):
    # zeta^e=alpha^(e mod p) beta^(e mod q), reduced in exact tensor basis.
    grid=[[0]*q for _ in range(p)]
    for e,c in enumerate(cs):
        if c:grid[e%p][e%q]+=c
    corner=grid[p-1][q-1]
    return all(grid[a][b]-grid[a][q-1]-grid[p-1][b]+corner==0 for a in range(p-1) for b in range(q-1))

def mask(p,q,kind,k):
    n=p*q
    if kind=='divisor':
        return [{c for c in range(n) if r//k==c%(n//k)} for r in range(n)]
    out=[]
    for r in range(n):
        a,b=r%p,r%q
        if kind=='endpoint':
            A={(a+j)%p for j in range(k)}
            out.append({c for c in range(n) if c%p in A})
        elif kind=='cross':
            A={(a+j)%p for j in range(k)}
            f=((a+1)*b+a)%q
            out.append({c for c in range(n) if c%p in A or c%q==f})
        elif kind=='split':
            base=a if b else (a+1)%p
            extras={crt(p,q,(a+j)%p,b) for j in range(2,k+2)}
            out.append({c for c in range(n) if c%p==base}|extras)
        else: raise ValueError(kind)
    return out

def gram_control(p,q,kind,k,expected):
    n=p*q; rows=mask(p,q,kind,k); d=len(rows[0]);cols=[set() for _ in range(n)]
    for r,cs in enumerate(rows):
        for c in cs:cols[c].add(r)
    check(all(len(x)==d for x in rows+cols),'regular_degrees')
    result={'p':p,'q':q,'kind':kind,'k':k,'d':d,'both_grams':[]}
    for orientation,families in [('rows',rows),('columns',cols)]:
        nz=0; witness=None
        for i in range(n):
            for j in range(i+1,n):
                counts0=[0]*n
                for x in families[i]&families[j]:counts0[((i-j)*x)%n]+=1
                z=zero_counts(counts0,p,q)
                counts['exact_gram_offdiagonals']=counts.get('exact_gram_offdiagonals',0)+2
                if not z:
                    nz+=2
                    if witness is None:witness={'i':i,'j':j,'root_counts':[[e,c] for e,c in enumerate(counts0) if c]}
        check((nz==0)==expected,'gram_expected_outcome')
        result['both_grams'].append({'orientation':orientation,'nonzero_offdiagonals':nz,'first_witness':witness})
    return result

def main():
    start=time.time();results=[]
    ps=[p for p in range(3,32,2) if prime(p)]
    qs=[q for q in range(5,212,2) if prime(q)]
    for p in ps:
      for q in qs:
       if q<=p:continue
       threshold=(p-1)*(p-2)
       if q>threshold:
        d=q+p-1
        check(q*q-threshold*q-(p-1)>0,'second_moment_excludes_small_only')
        check(q>2*p-2,'separated_implies_line_threshold')
        for h in range(1,p):
         for m in range(q):
          cap=(q-m)*(p-1)**2+m*(q+p-1)<=q*(p-h)*(p-1)
          check(cap==(m==0 and h==1),'capacity_reduction')
       if q>2*p-2:
        for t in range(1,p-1):
         check(q-p+2>p and 2*(q-p+2)>q and 2*t<q,'line_quotient_thresholds')
         for h in range(1,p+1):check(p*q!=h*(q+t),'line_quotient_obstruction')
       for k in range(2,p):
        for ell in range(k+1):
         num=(k-ell)*q;den=p-ell
         if num%den==0 and num//den<q:
          check(ell==k and num==0,'endpoint_row_geometry')
       # Dense non-q-multiples: disjoint nonempty packing forces f=1;
       # then degree fixes ell uniquely. Check all attainable singleton counts.
       for ell in range(1,p):
        d=p+ell*(q-1)
        if d>p+q-1:
         check(d%q!=0 and d<p*q,'dense_singleton_residual_degree')
       for a in range(p):
        for b in range(q):
         r=crt(p,q,a,b)
         c=crt(p,q,(a+1)%p,(b+2)%q)
         ep=q*pow(q,-1,p);eq=p*pow(p,-1,q)
         check((r*c-(a*((a+1)%p)*ep+b*((b+2)%q)*eq))%(p*q)==0,'original_crt_phase')
    for p,q in [(3,5),(5,7),(7,11),(7,31),(11,23)]:
       f=phi(p,q); n=p*q
       for e in range(n):
        # Both representations are converted independently to univariate residues.
        ep=q*pow(q,-1,p);eq=p*pow(p,-1,q)
        v=[0]*n;v[e]=1
        w=[0]*n;w[((e%p)*ep+(e%q)*eq)%n]=1
        check(rem(v,f)==rem(w,f),'tensor_univariate_monomials')
       for h in range(1,n):
        cs=[0]*n
        for c in range(n):cs[(h*c)%n]+=1
        check(zero_counts(cs,p,q) and not any(rem(cs,f)),'full_fourier_root_sums')
       # Independent root-sum agreement on structured nonzero controls.
       for h in range(1,min(n,31)):
        cs=[0]*n
        for c in range(n):
         if c%p in (0,1) or c%q==2:cs[(h*c)%n]+=1
        check(zero_counts(cs,p,q)==(not any(rem(cs,f))),'tensor_univariate_control_sums')
    # Full original-index Grams beyond both accepted p=3 and p=5 scopes.
    p,q=7,31
    for d in [1,p,q,p*q]:results.append(gram_control(p,q,'divisor',d,True))
    for t in range(1,p-1):results.append(gram_control(p,q,'split',t,False))
    for ell in [1,2,3,4,5,6]:results.append(gram_control(p,q,'cross',ell,False))
    for k in [2,3,4,5,6]:results.append(gram_control(p,q,'endpoint',k,False))
    payload={'status':'PASS','counts':counts,'controls':results,'elapsed_seconds':round(time.time()-start,3),'limits':'Fresh finite controls only; universal statements rely on REPORT.md symbolic proofs. No historical program executed.'}
    (ROOT/'RESULTS.json').write_text(json.dumps(payload,indent=2)+'\n')
    print(json.dumps({'status':'PASS','counts':counts,'full_square_controls':len(results),'elapsed_seconds':payload['elapsed_seconds']},sort_keys=True))
if __name__=='__main__':main()
