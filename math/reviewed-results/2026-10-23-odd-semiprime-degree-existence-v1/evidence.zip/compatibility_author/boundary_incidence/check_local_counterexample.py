#!/usr/bin/env python3
"""Exact rectangular row-Gram control; emphatically not a square mask."""
import json
from pathlib import Path
def check(value):
    if not value: raise RuntimeError("Exact rectangular control failed")
p, q, d = 11, 23, 33
N=p*q
A=list(range(7)); B=list(range(7,23))
S=[set() for _ in range(q)]
fano=[{i,(i+1)%7,(i+3)%7} for i in range(7)]
check(all(len(fano[i]&fano[j])==1 for i in range(7) for j in range(i)))
slots=[]
for v in range(q):
    if v<5:
        for b in A:
            S[b].update((u,v) for u in fano[b])
        for b in B:
            S[b].add((7,v))
        slots.extend((u,v) for u in [8,9,10])
    else:
        for b in A:
            S[b].add((0,v))
        for b in B:
            S[b].add((1,v))
        slots.extend((u,v) for u in range(2,11))
check(len(slots)==177)
for j,c in enumerate(slots[:160]):
    S[B[j%16]].add(c)
check(all(len(s)==d for s in S))
checks=0
for b in range(q):
    for c in range(q):
        overlap=S[b]&S[c]
        if b==c:
            check(len(overlap)==d)
        else:
            same=(b<7)==(c<7)
            counts=[sum(v==w for u,w in overlap) for v in range(q)]
            check(counts==[int(same)]*q)
        checks+=1
# Verify original-index phase exponents, not an altered CRT pairing.
ep=q*pow(q,-1,p); eq=p*pow(p,-1,q)
original_rows=[(b*eq)%N for b in range(q)]
original_cols=[[(u*ep+v*eq)%N for u,v in sorted(s)] for s in S]
phase_checks=0
for b in range(q):
    for c in range(q):
        if b==c: continue
        poly=[0]*q
        for u,v in S[b]&S[c]:
            rr=original_rows[b]-original_rows[c]
            cc=(u*ep+v*eq)%N
            exponent=(rr*cc)%N
            check(exponent==(((b-c)*v)%q)*eq%N)
            poly[((b-c)*v)%q]+=1
            phase_checks+=1
        # beta=zeta**eq has prime order q. A polynomial of degree <q
        # is zero at beta iff all q integer coefficients are equal.
        check(len(set(poly))==1)
out={"p":p,"q":q,"N":N,"d":d,"shape":[q,N],
     "component_row_labels":[A,B],"crt_supports":[[list(x) for x in sorted(s)] for s in S],
     "original_row_indices":original_rows,"original_column_supports":original_cols,
     "claim":"The original fixed-Fourier rectangular matrix has D D*=33 I_23. No full square mask and no column-Gram identity are claimed."}
Path(__file__).with_name('local_counterexample_p11_q23_d33.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({"status":"PASS","row_gram_entries":checks,"original_phase_overlap_terms":phase_checks,"row_degrees":[len(s) for s in S],"extra_capacity":len(slots),"extras_used":160,"component_sizes":[7,16]}))
