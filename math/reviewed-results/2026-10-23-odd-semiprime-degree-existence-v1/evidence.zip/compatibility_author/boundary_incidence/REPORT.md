# Boundary row-group incidence: exact obstruction and uniform sufficient bound

Date: 2026-10-23 UTC. Internal candidate research; no publication or repository change. Classical root-of-unity cancellation is assumed, not claimed as novel.

## Findings

1. The local assertion that a split row group is impossible at degree d=q+p−1 for every odd-prime pair q>2p−2 is false. An exact rectangular original-phase control exists at (p,q,d)=(11,23,33), with clique components of sizes 7 and 16.
2. A uniform sufficient local theorem does hold: for odd primes p<q with q>(p−1)(p−2), every row group at this boundary is a single clique. This sharpens the elementary sufficient cutoff q>(p−1)^2. It is a sufficient cutoff, not a claimed optimal one.
3. The rectangular control is not a square equality mask, does not satisfy or claim the square column-Gram condition, and does not disprove a global boundary exclusion at q>2p−2.

## 1. Exact counterexample at p=11, q=23, d=33

The columns are indexed by (u,v) in Z_11 × Z_23. The 23 rows have labels b=0,...,22 and all have fixed CRT first coordinate a=0. Split them into A={0,...,6} and B={7,...,22}.

Let the seven Fano lines be

    L_i = {i, i+1, i+3} modulo 7,   i=0,...,6.

Each has size three and every two distinct lines intersect exactly once.

For fibers v=0,...,4:
- A row i contains coordinates L_i.
- Every B row contains baseline coordinate 7.
- Coordinates 8,9,10 are available for private B extras.

For fibers v=5,...,22:
- Every A row contains coordinate 0.
- Every B row contains baseline coordinate 1.
- Coordinates 2,...,10 are available for private B extras.

List the available B-extra slots in increasing fiber order, and within a fiber in increasing coordinate order. There are 5·3+18·9=177 slots. Use the first 160. Assign slot number j, starting at j=0, to B row 7+(j mod 16). Thus every B row receives exactly ten private extras.

Each A row has degree 5·3+18=33. Each B row has degree 23+10=33. Two A rows meet exactly once in every fiber; so do two B rows; an A and B row are disjoint. The two components are distinct cliques, and 23>2·11−2.

For original fixed phases, set N=253, e_p=23 and e_q=231. Row b has original index r=b e_q modulo N; column (u,v) has original index c=u e_p+v e_q modulo N. With zeta a primitive N-th root and beta=zeta^e_q, the exact original phase is

    zeta^(rc) = beta^(bv).

Consequently an off-diagonal row Gram entry within a component is sum_v beta^((b−b')v)=0, and a cross-component entry is zero by disjointness. The rectangular 23-by-253 matrix therefore has D D*=33 I_23 exactly.

The explicit CRT and original-index supports are in local_counterexample_p11_q23_d33.json. The checker check_local_counterexample.py verifies all 529 row-Gram entries and 6,486 original-index phase overlap terms using integer equalities, without floating-point tolerance.

## 2. Setup for the sufficient theorem

Let one row group have q rows, each of degree d=q+p−1, across q fibers of p coordinates. Assume its overlap graph is a disjoint union of h clique components of sizes n_1,...,n_h. Distinct rows in one component meet once in every fiber; rows in different components are disjoint. These are the original-model consequences already established for q<d<2q.

Choosing one row from each component yields h disjoint supports of degree d>q in pq columns, hence h≤p−1.

For a component on n≥2 rows in one fiber, either all rows share a common point, or its incidence matrix W has

    W W^T = diag(w_i−1)+J.

In the no-common-point case every row has weight w_i≥2, so this matrix is positive definite and the component uses at least n coordinates. In the common-point case, all other coordinates are private, so it is a star and its incidence sum I and occupied-coordinate count k obey I=n+k−1.

## 3. Components of size at least p are stars when q>2p−2

A component with n>p cannot be nonstar by the rank bound. If n=p were nonstar in a fiber, it would occupy all p coordinates. Every other component would then be empty in that fiber; a nonsingleton component cannot be empty, because its row pairs must intersect once there. Thus all the other components would be singletons, and

    q ≤ p+(h−1) ≤ 2p−2,

a contradiction. Hence every component of size at least p is a star in every fiber.

## 4. Second moments force a component of size at least p

Assume all n_i≤p−1. In fiber v let m_(v,u) be the multiplicity of coordinate u and let I_v=sum_u m_(v,u). Exact pair intersections give

    sum_u m_(v,u)^2 = I_v + sum_i n_i(n_i−1).

Cauchy in each p-point fiber, followed by averaging and Jensen, gives

    d^2 ≤ p[d+sum_i n_i(n_i−1)]
        = p[sum_i n_i^2+p−1]
        ≤ p[(p−1)q+p−1].

Substituting d=q+p−1 yields

    q^2−(p−1)(p−2)q−(p−1) ≤ 0.

Put A=(p−1)(p−2). If the integer q>A, then q(q−A)≥q>p−1, contradicting this inequality. Thus q>A forces a component of size at least p.

## 5. Weighted occupancy eliminates every split

Let h_L≥1 be the number of components of size at least p, and let m be the total number of rows in the remaining components. The large components are stars by Section 3. A star component on n rows occupies, summed across all q fibers,

    q+n(p−1)

coordinates: there is one baseline in every fiber and n(p−1) private extra incidences. Thus the large components occupy q h_L+(q−m)(p−1) coordinates in total.

Every coordinate of a remaining component has multiplicity at most p−1. Its m rows have m(q+p−1) incidences, and hence those components occupy at least m(q+p−1)/(p−1) coordinates. Components have disjoint coordinate supports. Therefore

    q h_L+(q−m)(p−1)+m(q+p−1)/(p−1) ≤ pq,

or equivalently

    m[q/(p−1)−(p−2)] ≤ q(1−h_L).

When q>(p−1)(p−2), the coefficient of m is positive. Since h_L≥1, this forces m=0 and h_L=1. The row group is one clique.

For odd primes p<q, the same cutoff implies q>2p−2: this is immediate for p≥5, while p=3 forces q≥5. Thus the hypotheses used above are consistent without an additional prime-separation condition.

## 6. Scope and exact verification

The sufficient theorem is a local row-group theorem under the stated clique structure. It can be combined with a separate global saturation argument, but that argument is not repeated or claimed here. The p=11,q=23 construction establishes only the exact obstruction to extending the purely local single-clique conclusion all the way down to q>2p−2.

Run:

    python check_local_counterexample.py

Expected completed result: PASS; 529 rectangular row-Gram entries; 6,486 original-phase overlap terms; every row degree 33; two component sizes 7 and 16. It writes the explicit support JSON deterministically.

No unverified sharper-threshold exploration is part of this report.
