"""Certified bit-burst scalar backends with injected exact multiplication.

Binary splitting, dyadic bit bursts, outward intervals, and Newton division.
The default integer backend is RecursiveFermatMultiplier, not native mul.
These are components, not a complete sub-N-log-N multiplier. See FAST_SCALAR_PROOF.txt.
"""
from certified_exp import ExpCertificate
from certified_phase import PhaseCertificate, rotate_pair, rotate_intervals
from fermat_recursive import NullLedger, RecursiveFermatMultiplier


class FastArithmetic:
    def __init__(self, integer_multiply=None, ledger=None):
        self.integer_multiply = integer_multiply if integer_multiply is not None else RecursiveFermatMultiplier()
        self.ledger = ledger if ledger is not None else NullLedger()

    def mul(self, a, b):
        self.ledger["fast_scalar_integer_products"] += 1
        self.ledger["fast_scalar_max_product_bits"] = max(
            self.ledger["fast_scalar_max_product_bits"], abs(a).bit_length(), abs(b).bit_length())
        result = self.integer_multiply(abs(a), abs(b))
        return -result if (a < 0) != (b < 0) else result

    def divmod(self, a, b):
        """Exact Euclidean division, using shifts, products and one correction."""
        if type(a) is not int or type(b) is not int or b <= 0:
            raise ValueError("integer dividend and positive integer divisor required")
        self.ledger["fast_scalar_divisions"] += 1
        if a < 0:
            q, r = self.divmod(-a, b)
            return (-q-1, b-r) if r else (-q, 0)
        if a < b: return 0, a
        # u=b/2**t in [1/2,1); r/2**w is a lower bound for 1/u.
        t, w = b.bit_length(), a.bit_length()+4
        r = 1 << w
        shift = t+w
        for _ in range(w.bit_length()):
            product = self.mul(b, self.mul(r, r))
            rounded_up = -((-product) >> shift)
            r = (r << 1)-rounded_up
            self.ledger["fast_scalar_newton_steps"] += 1
        q = self.mul(a, r) >> shift
        remainder = a-self.mul(q, b)
        if remainder >= b:
            q, remainder = q+1, remainder-b
            self.ledger["fast_scalar_quotient_corrections"] += 1
        if not 0 <= remainder < b:
            raise ArithmeticError("Newton division certificate")
        return q, remainder

    def floor(self, a, b): return self.divmod(a, b)[0]
    def ceil(self, a, b): return -self.floor(-a, b)

    def cmul(self, z, v):
        a, b = z
        c, d = v
        return self.mul(a, c)-self.mul(b, d), self.mul(a, d)+self.mul(b, c)


def _binary_sum(start, stop, leaf, arithmetic, complex_values=False):
    """P/Q is a ratio product; T/Q is the corresponding prefix-product sum."""
    if stop-start == 1:
        arithmetic.ledger["fast_scalar_binary_leaves"] += 1
        return leaf(start)
    mid = (start+stop)//2
    p, q, t = _binary_sum(start, mid, leaf, arithmetic, complex_values)
    u, v, w = _binary_sum(mid, stop, leaf, arithmetic, complex_values)
    if complex_values:
        product = arithmetic.cmul(p, u)
        tail = arithmetic.cmul(p, w)
        total = tuple(arithmetic.mul(c, v)+d for c, d in zip(t, tail))
    else:
        product = arithmetic.mul(p, u)
        total = arithmetic.mul(t, v)+arithmetic.mul(p, w)
    denominator = arithmetic.mul(q, v)
    arithmetic.ledger["fast_scalar_binary_nodes"] += 1
    return product, denominator, total


def fast_pi_interval(bits, arithmetic=None):
    """Machin's identity; exact binary sums plus an alternating-tail bound."""
    if type(bits) is not int or bits < 4: raise ValueError("at least four bits required")
    arithmetic = arithmetic if arithmetic is not None else FastArithmetic()
    def atan(d):
        rate = 2*(d.bit_length()-1)
        terms = (bits+8+rate-1)//rate
        def leaf(j):
            if not j: return 1, d, 1
            p = -(2*j-1)
            q = (2*j+1)*(d*d)  # d is the fixed constant 5 or 239.
            return p, q, p
        _, q, t = _binary_sum(0, terms, leaf, arithmetic)
        low, rem = arithmetic.divmod(t << bits, q)
        high = low+bool(rem)
        # The first omitted term is <2**(-bits-8), with sign (-1)**terms.
        if terms % 2: low -= 1
        else: high += 1
        arithmetic.ledger["fast_pi_terms"] += terms
        return low, high
    a, b = atan(5), atan(239)
    arithmetic.ledger["fast_pi_interval_calls"] += 1
    return (a[0] << 4)-(b[1] << 2), (a[1] << 4)-(b[0] << 2)


def _small_exp(a, qbits, bits, arithmetic, imaginary):
    """Enclose exp(a/2**qbits) or exp(i*a/2**qbits), |a/2**qbits|<=1/8."""
    scale = 1 << bits
    if not a:
        return ((scale, scale), (0, 0)) if imaginary else (scale, scale)
    decay = qbits-(abs(a)-1).bit_length()
    if decay < 3: raise ValueError("small exponential argument exceeds 1/8")
    terms = (bits+4+decay-1)//decay
    def leaf(j):
        if not j:
            return ((1, 0), 1, (1, 0)) if imaginary else (1, 1, 1)
        p = (0, a) if imaginary else a
        return p, j << qbits, p
    _, denominator, total = _binary_sum(0, terms, leaf, arithmetic, imaginary)
    def interval(n):
        lo, rem = arithmetic.divmod(n << bits, denominator)
        return lo-1, lo+bool(rem)+1
    arithmetic.ledger["fast_exp_series_terms"] += terms
    return tuple(interval(t) for t in total) if imaginary else interval(total)


def _interval_product(x, y, bits, arithmetic):
    products = [arithmetic.mul(a, b) for a in x for b in y]
    return min(products) >> bits, -((-max(products)) >> bits)


def _complex_interval_product(z, v, bits, arithmetic):
    a, b = z
    c, d = v
    ac = _interval_product(a, c, bits, arithmetic)
    bd = _interval_product(b, d, bits, arithmetic)
    ad = _interval_product(a, d, bits, arithmetic)
    bc = _interval_product(b, c, bits, arithmetic)
    return ((ac[0]-bd[1], ac[1]-bd[0]), (ad[0]+bc[0], ad[1]+bc[1]))


def bit_burst_exp(value, bits, arithmetic=None, *, imaginary=False):
    """Enclose an exponential at an exact dyadic argument of magnitude <=1/8."""
    if (type(value) is not int or type(bits) is not int or bits < 4
            or abs(value) << 3 > 1 << bits):
        raise ValueError("dyadic argument must have bits>=4 and magnitude <=1/8")
    arithmetic = arithmetic if arithmetic is not None else FastArithmetic()
    scale = 1 << bits
    result = ((scale, scale), (0, 0)) if imaginary else (scale, scale)
    magnitude, sign = abs(value), -1 if value < 0 else 1
    previous, qbits = 0, min(4, bits)
    while True:
        prefix = magnitude >> (bits-qbits)
        chunk = prefix-previous
        if chunk:
            factor = _small_exp(sign*chunk, qbits, bits, arithmetic, imaginary)
            if imaginary: result = _complex_interval_product(result, factor, bits, arithmetic)
            else: result = _interval_product(result, factor, bits, arithmetic)
        arithmetic.ledger["fast_exp_burst_stages"] += 1
        if qbits == bits: return result
        next_bits = min(2*qbits, bits)
        previous = prefix << (next_bits-qbits)
        qbits = next_bits


class _ScalarContext:
    def __init__(self, ledger=None, *, integer_multiply=None):
        self.ledger = ledger if ledger is not None else NullLedger()
        self.arithmetic = FastArithmetic(integer_multiply, self.ledger)
        self.pi_cache = None  # One precision only; no unbounded multi-precision cache.

    def _pi(self, bits):
        if self.pi_cache is None or self.pi_cache[0] != bits:
            self.pi_cache = bits, fast_pi_interval(bits, self.arithmetic)
        return self.pi_cache[1]


class FastCertifiedExp(_ScalarContext):
    """Fast Gaussian exponential interface.

    Positive arguments require the explicit disk margin 5*numerator <=
    shift*denominator, satisfied by every Gaussian diagonal in this project.
    All nonpositive arguments are accepted. General disk-valued positive
    arguments outside that margin are not part of this class's contract.
    """
    def _point(self, value, bits):
        return bit_burst_exp(value, bits, self.arithmetic)

    def grid(self, numerator, denominator, p, *, shift=0):
        if (any(type(v) is not int for v in (numerator, denominator, p, shift))
                or denominator <= 0 or p < 2 or shift < 0):
            raise ValueError("invalid exponential arguments")
        a = self.arithmetic
        self.ledger["fast_certified_exp_calls"] += 1
        if numerator > 0 and a.mul(5, numerator) > a.mul(shift, denominator):
            raise ValueError("positive exponential needs the declared Gaussian disk margin")
        if numerator == 0:
            bits = max(p, shift)
            exact = 1 << (bits-shift)
            return ExpCertificate((1 << p) >> shift, p, exact, exact, bits, "exact power of two")
        if numerator < 0 and -numerator >= a.mul(p, denominator):
            self.ledger["fast_exp_underflow_bounds"] += 1
            return ExpCertificate(0, p, 0, 1, p, "analytic underflow bound")
        size = p+shift+max(abs(numerator).bit_length(), denominator.bit_length())+32
        bits = p+4*shift+8*size.bit_length()+64
        lo_pi, hi_pi = self._pi(bits)
        if numerator < 0: lo_pi, hi_pi = hi_pi, lo_pi
        low = a.floor(a.mul(lo_pi, numerator), denominator)
        high = a.ceil(a.mul(hi_pi, numerator), denominator)
        scale = 1 << bits
        squarings = max(0, (8*max(abs(low), abs(high))-1).bit_length()-bits)
        low, high = low >> squarings, -((-high) >> squarings)
        while 8*max(abs(low), abs(high)) > scale:
            low, high = low >> 1, -((-high) >> 1)
            squarings += 1
        lower = self._point(low, bits)[0]
        upper = self._point(high, bits)[1]
        for _ in range(squarings):
            if lower < 0: raise ArithmeticError("exponential enclosure lost positivity")
            lower = a.mul(lower, lower) >> bits
            upper = -((-a.mul(upper, upper)) >> bits)
            self.ledger["fast_exp_interval_squarings"] += 1
        lower >>= shift
        upper = -((-upper) >> shift)
        if numerator < 0: upper = min(upper, scale)  # Analytic exp(x)<=1 for x<0.
        value = lower >> (bits-p)
        scaled = value << (bits-p)
        if not (0 <= scaled <= lower <= upper <= scale and upper-scaled < 2 << (bits-p)):
            raise ArithmeticError("fixed-precision exponential certificate failed")
        self.ledger["fast_exp_peak_interval_bits"] = max(self.ledger["fast_exp_peak_interval_bits"], bits)
        return ExpCertificate(value, p, lower, upper, bits, "binary splitting and dyadic bit burst")


class FastCertifiedPhase(_ScalarContext):
    def grid(self, numerator, denominator, p):
        if (any(type(v) is not int for v in (numerator, denominator, p))
                or denominator < 1 or p < 2):
            raise ValueError("integer phase numerator, positive denominator, p>=2 required")
        a = self.arithmetic
        self.ledger["fast_certified_phase_calls"] += 1
        remainder = a.divmod(numerator, denominator)[1]
        quadrant, remainder = a.divmod(remainder << 2, denominator)
        if not remainder:
            value = rotate_pair((1 << p, 0), quadrant)
            return PhaseCertificate(value, (value[0], value[0]), (value[1], value[1]), p, p)
        size = p+max(abs(numerator).bit_length(), denominator.bit_length())+32
        bits = p+8*size.bit_length()+64
        pi_low, pi_high = self._pi(bits)
        low = a.floor(a.mul(pi_low, remainder), denominator << 1)
        high = a.ceil(a.mul(pi_high, remainder), denominator << 1)
        # Divide the point by 16, then restore by four complex squarings.
        # The argument displacement to the actual angle is bounded below.
        point = low >> 4
        z = bit_burst_exp(point, bits, a, imaginary=True)
        for _ in range(4): z = _complex_interval_product(z, z, bits, a)
        displacement = high-(point << 4)
        scale = 1 << bits
        real, imag = [(max(0, lo-displacement), min(scale, hi+displacement)) for lo, hi in z]
        inward = real[0] >> (bits-p), imag[0] >> (bits-p)
        value = rotate_pair(inward, quadrant)
        real, imag = rotate_intervals(real, imag, quadrant)
        unit_shift = bits-p
        errors = [max(abs(lo-(v << unit_shift)), abs(hi-(v << unit_shift)))
                  for v, (lo, hi) in zip(value, (real, imag))]
        if (not all(lo <= hi for lo, hi in (real, imag))
                or sum(a.mul(v, v) for v in value) > 1 << (2*p)
                or sum(a.mul(e, e) for e in errors) >= 1 << (2*unit_shift+2)):
            raise ArithmeticError("fixed-precision phase certificate failed")
        self.ledger["fast_phase_peak_interval_bits"] = max(self.ledger["fast_phase_peak_interval_bits"], bits)
        return PhaseCertificate(value, real, imag, p, bits)
