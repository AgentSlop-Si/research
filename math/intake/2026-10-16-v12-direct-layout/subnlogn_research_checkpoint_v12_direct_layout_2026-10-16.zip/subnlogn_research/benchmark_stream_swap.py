"""Reproducible stream-interchange component benchmark, not a speed claim."""
from collections import Counter
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import random
import sys
from bit_frames import BitNetwork
from stream_moves import swap_digits
from swap_recursion import CompiledBitCircuit, binary_chunk_swap
from test_stream_swap import SwapControl, swap_oracle

SOURCES=("benchmark_stream_swap.py","stream_moves.py","bit_frames.py","swap_recursion.py",
         "test_stream_swap.py","motifs.py")


def main():
    root=Path(__file__).resolve().parent
    def hashes(): return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in SOURCES}
    initial_hashes=hashes()
    gc.disable()
    report=dict(scope="Sequential movement components; toy recursion has NO rank saving; no integer multiplication speedup or full h=100 execution",
                python=sys.version,platform=platform.platform(),gc_disabled=True,
                ledger_scope="Payload transfers and local parking, excluding Python descriptor arithmetic and a complete finite-tape counter audit",
                timed_scope="Each call includes shape work, padding, movement and cleanup; fixed circuit compilation, input generation and output comparison are outside the per-call timer",
                cases=[])
    start=perf_counter_ns()
    small=CompiledBitCircuit(BitNetwork(3))
    report["actual_h3_factor_compilation"]=dict(duration_ns=perf_counter_ns()-start,wires=small.wires,
        ambient=small.m,rank_sum=small.rank_sum,unique_plans=len(small.plans),prime=small.prime,
        has_rank_saving=small.rank_sum<small.wires*small.m)
    start=perf_counter_ns()
    control=CompiledBitCircuit(SwapControl())
    report["control"]=dict(m=control.m,wires=control.wires,rank_sum=control.rank_sum,prime=control.prime,
                           compilation_ns=perf_counter_ns()-start)
    for bits in (2,3,5,6):
        rng=random.Random(77791+bits)
        prefix,gap,suffix,width=1,2,1,8
        values=[rng.randrange(1<<width) for _ in range(prefix*(1<<(2*bits))*gap*suffix)]
        expected=swap_oracle(values,prefix,1<<bits,gap,suffix)
        samples={"recursive_control":[],"individual_binary_digits":[]}
        ledgers={}
        order=[name for name in samples for _ in range(3)]
        rng.shuffle(order)
        for name in order:
            ledger=Counter()
            start=perf_counter_ns()
            if name=="recursive_control":
                got=binary_chunk_swap(values,bits,control,ledger,prefix=prefix,gap=gap,suffix=suffix,width=width)
            else:
                got=values
                for i in range(bits):
                    got=swap_digits(got,prefix*(1<<i),2,(1<<(bits-i-1))*gap*(1<<i),
                                    (1<<(bits-i-1))*suffix,ledger,width)
            elapsed=perf_counter_ns()-start
            if got!=expected: raise AssertionError("stream interchange mismatch")
            samples[name].append(elapsed)
            ledgers[name]=dict(ledger)
        report["cases"].append(dict(chunk_bits=bits,records=len(values),record_width=width,
            samples_ns=samples,median_ns={key:median(data) for key,data in samples.items()},ledgers=ledgers))
        print(json.dumps({"chunk_bits":bits,"medians_ms":{key:median(data)/1e6 for key,data in samples.items()}}),flush=True)
    final_hashes=hashes()
    if initial_hashes!=final_hashes: raise RuntimeError("sources changed while benchmarking")
    report["source_sha256"]=initial_hashes
    report["sources_unchanged_during_benchmark"]=True
    report["checked_permutations"]=24
    (root/"stream_swap_benchmarks.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")


if __name__=="__main__": main()
