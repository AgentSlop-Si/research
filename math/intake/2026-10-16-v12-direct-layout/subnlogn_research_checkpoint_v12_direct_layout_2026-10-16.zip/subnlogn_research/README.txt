SUB-N-LOG-N MULTIPLICATION RESEARCH — CURRENT CHECKPOINT
2026-10-15

Goal: an implemented, verified algorithm for arbitrary N-bit integer inputs
whose fully charged asymptotic bit cost is o(N log N).

Status: ACTIVE; NOT ACHIEVED.
This folder is runnable research progress, not a completed faster multiplier.
The original archive's optimized multiplier remains intact in the workspace.

What is executable now
----------------------
motifs.py:
  Both eight-operation scalar motifs, arbitrary scratch restoration, full
  three-stage scalar bank exchange on small examples, rational lower-triangular
  factorization, rank-counted modular shears, binary phase-frame kernels, and
  exact symbolic rank budgets for the published h=100 networks.

packed_bits.py:
  Eight packed rotations, exact exceptional-address detection and correction,
  stable radix sorting of only exceptional records, and payload reinsertion.
  Address semantics run in ordinary Python; packed_stream.py now supplies the
  separate sequential movement integration. A full fixed-tape proof is absent.

stream_moves.py, bit_frames.py and swap_recursion.py:
  Sequential payload split/merge, ordered rational affine operations, cyclic
  row distribution, the rational XOR-network compiler, and rank-counted chunk
  interchange recursion. Width decomposition, high-digit row supply, numerical
  binary/radix padding, zero-row checks and inactive-role parking are executable.
  These components never scatter payloads to computed destination addresses.
  The compiler checks endpoint identities, scalar routing and total rank.
  The actual h=100 descriptor exists, but its complete factor table has NOT
  been compiled or executed. Tests use separate no-saving controls for complete
  swaps, plus the actual small networks for circuit/frame/factor checks.
  Payload transfers are counted; Python descriptor/counter arithmetic is not
  a verified fixed-tape bit-cost implementation.

packed_stream.py:
  Eight controlled rotations use the recursive chunk-swap interface, bringing
  the target after its controls and restoring physical chunk order. Exceptional
  records alone are sorted by destination rank and reinserted sequentially.
  A fixed signed Gaussian-record codec connects this to the basis_move interface.
  The named L and inverse-L layout schedules use sequential single-bit moves
  and recursive chunk swaps as well. Both movement interfaces are injectable
  into synthetic convolution, and into the reference integer adapter.
  Tests distinguish real K>=6 single-field rectangles, real multi-field repair
  orbits, generic full rotation rectangles, and separate all-exceptional controls.
  No complete real K>=6, f>=2 rectangle (at least 2^36 records) has been run.
  K<6 numerical tests use the explicitly counted sequential two-bit fallback.
  Both the basis codec and external layout codec accept a declared fixed
  component width; their older adaptive modes remain available as controls.

guarded_layer.py:
  A separate common-format numerical executor. Guard widths are selected from
  the declared precision, axis count and fixed network, before reading values.
  All levels retain one binary point and one signed component width. Every
  halving is checked exact and every arithmetic result is range-checked.
  A compiled dependency program gives practical bounds for finite controls;
  the actual h=100 polynomial descriptor is also available without executing
  that enormous network. Inactive numeric streams are parked at the same
  format, and both record- and bit-volume ratios are checked.
  This closes the layer's adaptive-width gap, not the full time/reduction proof.

guard_certificate.py and GUARD_PROOF.txt:
  Exact dependency budgets, the h=100 guard polynomial and scoped cutoff
  arithmetic. The guard-only cutoff is not a full algorithm crossover.

certified_exp.py, gaussian_resampling.py and gaussian_tensor.py:
  Certified integer-only exponential enclosures, finite Gaussian windows,
  ordered coordinate selection, bounded Neumann correction and scaled diagonal
  compression. Padded tensors expose and restore axes through sequential chunk
  swaps and fixed-width codecs, including unequal neighboring binary widths.
  Tests use independent high-precision period sums and dense linear algebra;
  production does not use dense inverses, a floating-point exp, or a Fourier
  oracle. The current integer Taylor backend has NO fast scalar bit-cost proof.
  GAUSSIAN_PROOF.txt records interval correctness, numerical invariants and gaps.

certified_phase.py and resampled_transform.py:
  Disk-valued complex phases with integer interval certificates; coefficient
  twists turn synthetic negacyclic convolution into complex cyclic convolution.
  Chirps retain the target frequency permutation. Gaussian expansion, chirp,
  compression and exact scaling now execute source transforms without any
  Fourier oracle. Finite error bounds are checked before execution.

crt_layout.py and multiply_resampled.py:
  Sequential triangular CRT rotations, padded axis reversal, exact coefficient
  recovery, inverse CRT and radix carries. The full numerical reduction now
  returns exact products with explicitly supplied finite parameters. Its
  automatic asymptotic parameter selector and fully charged fast backends are
  still missing. RESAMPLED_PROOF.txt documents the correctness certificate.

fermat_recursive.py and fermat_certificate.py:
  Exact recursive Fermat-ring integer products, sequential DIF/DIT transforms,
  shared operand/result stacks, signed carries and fixed-threshold schoolbook
  leaves. No growing native coefficient product is used by this backend.
  FERMAT_PROOF.txt derives O(N log N log log N) for the specified bit-stream
  algorithm and explains conditional absorption of its extra logarithm in the
  larger reduction. This backend is NOT itself below N log N. It is optional:
  multiply_resampled still defaults to native integer products as a control.
  Tests and the new benchmark explicitly inject RecursiveFermatMultiplier.
  Global diagnostic counters are disabled by default; audited runs are separate.

fast_scalar.py and fast_scalar_transform.py:
  Exact Newton division, binary-split Machin pi, dyadic bit-burst exponential
  and complex phase routines with outward integer certificates. Scalar classes
  default to the recursive Fermat backend and disable global audits. Positive
  exponentials require an explicit disk margin satisfied by every Gaussian
  diagonal. FAST_SCALAR_PROOF.txt derives a conservative O(P log^6 P) component
  bound, conditional on the integer stream implementation, and fixed guards.
  The transform_factory hook connects these routines to the finite reduction.
  Its new full-product test uses an explicitly labeled native-integer control;
  separate scalar tests execute the recursive integer backend. Gaussian weight
  products, norm checks and other descriptor arithmetic remain to be integrated
  and charged. The original Taylor functions remain the default control.

fast_gaussian.py and fast_resampled.py:
  The separate multiply_fast_finite profile routes Gaussian weights, coordinate
  divisions, disk/norm checks, chirp numerators, phase products and packed-ring
  products through one supplied integer backend. Its default is recursive
  Fermat, with global audit counters disabled. Strict windows and beta residues
  advance incrementally. Three sequential parameter-only weight tapes preserve
  every rounding point while reusing weights across Neumann steps and lines.
  A constant 256-entry linear-search cache has an explicit O(p) lookup cost.
  Final power-of-two scaling and carries use shifts/masks. Ordinary polynomial
  descriptor setup remains separately charged. FAST_GAUSSIAN_ARITHMETIC.txt
  records the line-cost argument, cache-storage schedule and remaining tape
  obligations. Parameters are still explicit; the default phase layer is not
  the rank-saving asymptotic branch. This profile is not the completed goal.

phase_layers.py:
  Exact Gaussian-integer phase wrappers implementing H0 = b S C S. The C tensor
  interface exposes the point where recursive batching must replace the current
  explicit per-axis backend. There is no intermediate numerical rounding.

network_frames.py:
  Lazy gate and role compiler for the actual complex network, common tensor
  projectors, constructive orthonormal residual bases, and exact frame changes.
  Residual directions are represented by three h-bit factors. A full h=4
  spectral control verifies all roles; it has no rank saving. One actual h=100
  edge with 999,900 directions is fully streamed in the component benchmark.

recursive_edges.py and recursive_network.py:
  Coordinate changes, one recursive child per residual vector, inverse-kernel
  corrections, cyclic row distribution, dyadic gate alignment, endpoint phases,
  signed role restoration, row supply/padding and base-m axis partitioning.
  Multiple levels are tested with explicitly separate small control networks.
  Bulk address movement defaults to the explicit reference implementation;
  packed_stream.py is the new injectable sequential alternative. The complete
  h=100 execution and its fixed-tape cost are not verified.
  make_network_layer connects this engine to the synthetic convolution. Tests
  exercise recursive calls through a small control and the explicitly recorded
  small-width branch of the actual h=100 network.

synthetic.py:
  Signed polynomial packing and centered extraction; four recorded integer
  products per ring product; normalized negacyclic products; grouped synthetic
  transform rounds; named-slot layout; retained frequency order; normalized
  convolution with one rounding per round; an exact integer integration adapter.
  The adapter exercises these interfaces with zero-padded matrix convolution.
  It does not implement the final Gaussian-resampling reduction of the paper.

cost_certificate.py:
  Exact rational checks of the original seven cost margins and a larger feasible
  kappa, conditional on the cited mathematical and tape-algorithm lemmas.
  This arithmetic certificate is not a proof about the present implementation.

Reproduce with Python 3.10+ and the standard library
---------------------------------------------------
From this folder:

    python run_validation.py
    python cost_certificate.py
    python benchmark_synthetic.py
    python benchmark_network.py
    python benchmark_stream_swap.py
    python benchmark_packed_stream.py
    python guard_certificate.py
    python benchmark_guarded_layer.py
    python benchmark_gaussian.py
    python benchmark_resampled.py
    python fermat_certificate.py
    python benchmark_fermat_recursive.py
    python benchmark_fast_scalar.py
    python benchmark_fast_arithmetic.py

To remeasure the supplied baseline, pass its extracted folder:

    python benchmark_baseline.py --baseline-dir PATH_TO_ORIGINAL_TRIAL

Example of the integration adapter:

    from synthetic import multiply_reference
    product, diagnostics = multiply_reference(123456789, 987654321)
    assert product == 121932631112635269

The name multiply_reference is intentional. It has no sub-N-log-N guarantee.
Do not replace its missing backends by an assumed constant-time oracle.

Example of a certified scalar with the recursive integer backend:

    from fast_scalar import FastCertifiedExp
    certificate = FastCertifiedExp().grid(-1, 3, 128)
    assert certificate.verify_grid_error()

The result is a lower dyadic approximation to exp(-pi/3), within two 128-bit
grid units. Its correctness does not establish the full multiplier's bound.

Current evidence
----------------
validation.json: all 137 test methods pass. Coverage includes 98,304 exhaustive
guard addresses, 6,561 exhaustive modular shears, 150 defining synthetic
transform comparisons, 149 exact integer integration cases, and 106 negative
controls. Different counters count different units; adding them together is
not a meaningful count of independent proofs.

Network coverage includes 56 edge classes, 7,552 full framed-network role
comparisons, 352 packed basis changes, five multilevel recursion cases and six
row-padding/axis-partition cases. The test runner hashes code before importing
tests and after completion, and rejects a result if source changed during testing.

network_benchmarks.json separately records the h=100 residual stream and
small-control recursive timings. These are component measurements only.

New movement coverage includes 26 rational affine maps, four rank-factored
stream shears, four multilevel swap cases, seven arbitrary-width cases, and
four numerically padded binary cases. Tests check exact child count and V/W
child volume, multiple high-digit joins, nonbinary width decompositions, and
arbitrary scratch values. The complete h=3 rational factor table compiles.
Sparse-frame controls cover all 331 roles at h=3 and h=4 with arbitrary-role
basis payloads, and all 12,500 output roles at h=5 with three nonzero inputs.
The h=5 check exercises side wires but is not an exhaustive input-basis test.

stream_swap_benchmarks.json records 24 checked permutations and both recursive
control and individual-digit timings. These small controls have NO rank saving
and are slower than individual digit moves. Symbol ledgers exclude a complete
descriptor/counter audit, so they must not be presented as a Turing-time proof.

The new movement integration checks 48 controlled rotations across all six
chunk orders, one rotation containing recursive swaps, three full K=6/f=1
rectangles, six real guarded repair orbits with nonbinary spectators, and six
distinct all-exceptional whole-pipeline controls. Gaussian records round-trip
exactly, including signed 150-bit components. Five streamed layout/inverse
roundtrips match the independent permutation oracle.

A non-coordinate phase-network convolution executes both movement backends
with zero reference layout or basis-permutation calls and matches the independent
reference exactly. These tests use no-saving controls and do NOT prove the
large-input bound. Four integer adapter calls also accept the backends; because
that adapter has one record axis, they do not exercise large-D phase recursion.
packed_stream_benchmarks.json separates these branches and records seven
checked component/integration outputs, including fixed record encoding costs.

Common-format coverage includes four multi-level recursive cases, +/-1/2
scalar gates, inverse children, six Walsh-layer comparisons, identical formats
on zero/small/extreme inputs, one streamed guarded convolution, and four
precision-aware integer adapter cases. The guarded convolution uses no adaptive
basis or layout codec. The actual h=100 small-width branch and its large-width
guard descriptor are distinguished; the large network is not executed.
guard_certificate.json saves 20 finite guard cases and two exact, scoped
guard-cutoff checks. guarded_layer_benchmarks.json records nine checked outputs.

Gaussian coverage adds five certified pi intervals, 42 exponential enclosures,
15 independent analytic line-map comparisons, 25 boundary/zero map cases,
two retained-permutation identities, six adjacent-axis roundtrips and four
analytic tensor comparisons in both axis orders. Gaussian window endpoints,
multi-period input scans and fixed Neumann iteration counts are checked.
Those older identity tests use an oracle for the middle Fourier transform.
The separate resampled tests below exercise the implemented production path.
gaussian_benchmarks.json records 18 checked cold component outputs; exponential
setup, all arithmetic, validation, codec and axis movement are timed.

The complete-reduction tests add 193 certified complex phases, 48 phase-product
norm checks, five CRT layout roundtrips, one exact CRT convolution isomorphism,
eight cyclic twist comparisons, three chirp/Fourier comparisons, four source
transform/Fourier comparisons and 13 exact resampled integer products.
Production uses no Fourier oracle or dense inverse. Twelve product cases use
guarded phase layers and streamed layouts; one substitutes a schoolbook integer
backend and checks its call count. They exercise the actual h=100 small-width
phase branch, not its huge rank-saving recursion. Swap controls have no saving.
resampled_benchmarks.json records 18 complete numerical-reduction products
through 128 bits with cold setup, CRT, Gaussian/chirp/twist work, coefficient
recovery and carries included. These explicit finite parameters and timings
are not evidence of a sub-N-log-N implementation.

Recursive Fermat coverage adds 9,640 modular shifts, six defining Fourier sums,
1,493 exhaustive small residue products, 70 recursive modular products and 40
ordinary products through 4,096 bits. Three audit-mode comparisons verify that
disabling global diagnostics preserves answers. A further complete resampled
product injects this backend for every ring, phase and final scaling product;
the separate Gaussian/phase interval routines retain their existing arithmetic.
The recurrence certificate checks 5,077 sample plan nodes, while three tests
check conditional polylogarithmic slack. The all-size argument is stated in
FERMAT_PROOF.txt; finite samples are not its proof.
fermat_recursive_benchmarks.json records 21 checked timed products: three per
size through 262,144 bits and three complete 32-bit resampled products. Six
separate untimed audited calls check the identical answers and stream counters.
All timed backend calls disable global diagnostics. Neither these timings nor
the conditional logarithmic-slack certificate prove the full goal.

The fast scalar tests independently check exact quotients, rational binary sums,
pi enclosures, exponential/phase enclosures and the Gaussian positive-argument
margin. Default recursive scalar calls are compared with separately injected
native arithmetic. The whole-reduction control exercises both new scalar
classes and checks that neither old rounded Taylor loop was called.
Coverage includes 12,040 exhaustive signed quotient pairs, 288 large boundary
pairs, four recursive-backend quotient cases, 32 exact rational series sums,
12 dyadic real enclosures, seven pi intervals, 45 exponential enclosures and
63 complex phase enclosures. Four separate scalar cases use recursive integer
products; 98 alpha cases check the positive Gaussian margin.
fast_scalar_benchmarks.json separates cold recursive scalar timings from native
integer controls, includes pi/setup costs, and records untimed audited checks.
It checks 28 timed scalar outputs, 14 untimed audited outputs and one timed
complete integer product.
Its full-product timing is explicitly a native-arithmetic control, not a fully
recursive execution or evidence of the complete requested asymptotic bound.

The full-arithmetic profile adds direct-formula geometry checks, all six
Gaussian line maps against separate reference loops, cached/uncached operand
checks, forced constant-cache eviction and both tensor axis orders. Explicit
zero-weight controls isolate periodic head movement. Packed products, synthetic
convolutions and chirps match the existing arithmetic controls. A default
recursive-backend product covers the whole numerical path at explicit one-axis
parameters; separate two-axis products use native-integer controls.
Counts include four geometry cases, 18 line-map comparisons, four tensor-map
comparisons, ten head-movement controls, four packed-ring products, two synthetic
convolutions and four cyclic/chirp comparisons. The suite also checks eviction
past the 256-entry cache bound and one recursive-backend diagonal map.
fast_arithmetic_benchmarks.json includes all cold weight construction and keeps
the recursive numerical path separate from native arithmetic controls. The
one-axis case does not exercise the huge phase network; guarded two-axis controls
use only the actual h=100 small-width branch and a no-saving swap circuit.
This Python profile is slow at these precisions: a single 32-bit fully recursive
run can take several minutes. The names of the fast interfaces are not claims
of a measured practical speedup.
The current cold recursive run took 415.640 seconds. Native-integer controls
took median 0.549 seconds (one axis) and 3.821 seconds (two guarded/streamed
axes). The recursive case is one timed run; each native control has three.
All seven timed products and two separate audited controls matched exactly.

synthetic_benchmarks.json: all 45 reference benchmark products pass through
65,536 bits; 15 cold calls per size, five independently generated full-width
pairs, three repetitions, randomly interleaved with native Python calls.
All setup, conversion, arithmetic, rounding and reconstruction are timed.

N bits        Reference synthetic ms        Native Python ms
4,096                    44.1920                   0.0151
16,384                  215.0638                   0.1396
65,536                  440.7039                   1.3682

These are machine-specific medians and describe the reference integration
implementation. They neither establish nor suggest the desired bit bound.
baseline_benchmarks.json separately records the original enhanced.py controls
through 262,144 bits. No parameter search is hidden in the timed calls.

PROOF_STATUS.txt records the mathematical distinctions and remaining work.
source_manifest.json pins the preprint sources and their hashes.
It also identifies the author-hosted Harvey--van der Hoeven manuscript used
for the Gaussian numerical algorithms; that PDF is not bundled in this ZIP.
SOURCE_LICENSE.txt and NOTICE.txt record source attribution.
