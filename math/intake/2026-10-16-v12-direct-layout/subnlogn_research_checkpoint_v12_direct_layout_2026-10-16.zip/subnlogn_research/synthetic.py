"""Executable synthetic ring transforms, signed packing and convolution.

Implements the numerical interfaces of section 06 of the pinned preprint.
Gaussian coefficients are integer pairs on the grid 2**(-p). The current
layer and address backends are explicit finite reference implementations;
their cost is NOT the preprint's fast recursive tape cost. Native integer
multiplications are recorded, never charged as unit-cost bit operations.
"""
from collections import Counter
from dataclasses import dataclass
from math import isqrt, prod
from operator import mul


def trunc_shift(x, shift):
    if shift < 0: raise ValueError("negative shift")
    return x >> shift if x >= 0 else -((-x) >> shift)


def monomial(poly, exponent):
    """Multiply by y**exponent modulo y**r+1 as two signed pieces."""
    r = len(poly)
    if not r: raise ValueError("empty polynomial")
    turns, offset = divmod(exponent, r)
    sign = -1 if turns % 2 else 1
    if not offset:
        return [(sign*a, sign*b) for a, b in poly]
    return [(-sign*a, -sign*b) for a, b in poly[-offset:]] + [
        (sign*a, sign*b) for a, b in poly[:-offset]]


def _blocks_to_bytes(digits, width):
    """Whole-block writes with at most seven carry bits between iterations."""
    out = bytearray()
    buf = used = 0
    for digit in digits:
        buf |= digit << used
        used += width
        whole = used//8
        if whole:
            bits = whole*8
            out.extend((buf & ((1 << bits)-1)).to_bytes(whole, "little"))
            buf >>= bits
            used -= bits
    if used: out.append(buf)
    return out


def pack_signed(coefficients, width):
    """Signed evaluation at 2**width using one constant-size carry per block."""
    if width < 2 or not coefficients: raise ValueError("invalid width or empty input")
    base, half = 1 << width, 1 << (width-1)
    carry, digits = 0, []
    for value in coefficients:
        if not isinstance(value, int) or not -half < value < half:
            raise ValueError("coefficient violates strict signed separation")
        carry, digit = divmod(value+carry, base)
        if carry not in (-1, 0): raise AssertionError("packing carry")
        digits.append(digit)
    value = int.from_bytes(_blocks_to_bytes(digits, width), "little")
    return value if carry == 0 else value-(1 << (width*len(digits)))


def unpack_centered(value, count, width):
    """Recover centered coefficients by scanning fixed blocks of a signed integer.

    The caller must prove true coefficients have magnitude strictly below half
    the radix. The final sign-extension check detects insufficient output size.
    """
    if count < 1 or width < 2: raise ValueError("invalid extraction shape")
    bits, mask, half = count*width, (1 << width)-1, 1 << (width-1)
    if not -(1 << (bits-1)) <= value < (1 << (bits-1)):
        raise ValueError("signed evaluation does not fit")
    raw = memoryview(value.to_bytes((bits+7)//8, "little", signed=True))
    carry, result = 0, []
    for j in range(count):
        byte, offset = divmod(j*width, 8)
        block = int.from_bytes(raw[byte:byte+(offset+width+7)//8], "little")
        residue = ((block >> offset) & mask)+carry
        digit = ((residue+half) & mask)-half
        carry = (residue-digit) >> width
        if carry not in (0, 1): raise AssertionError("extraction carry")
        result.append(digit)
    if carry != int(value < 0): raise ValueError("unconsumed sign extension")
    return result


def _shape(records, r, p, require_disk=False):
    if p < 2 or r < 2 or r & (r-1) or r >= 1 << p:
        raise ValueError("require p >= 2, power-of-two 2 <= r < 2**p")
    bound = 1 << (2*p)
    for poly in records:
        if len(poly) != r: raise ValueError("polynomial length mismatch")
        for z in poly:
            if len(z) != 2 or any(not isinstance(v, int) for v in z):
                raise ValueError("integer Gaussian numerators required")
            if require_disk and z[0]*z[0]+z[1]*z[1] > bound:
                raise ValueError("coefficient outside unit disk")


def ring_product_numerators(f, g, p, *, integer_multiply=mul, ledger=None):
    """Exact numerator pairs of fg in Z[i][y]/(y**r+1).

    The four signed evaluation products are each on at most 4pr bits.
    The returned coefficients have scale 2**(-2p), not 2**(-p).
    """
    r = len(f)
    _shape((f, g), r, p, require_disk=True)
    ledger = ledger if ledger is not None else Counter()
    width = 4*p
    a, b = [z[0] for z in f], [z[1] for z in f]
    c, e = [z[0] for z in g], [z[1] for z in g]
    aa, bb, cc, ee = [pack_signed(v, width) for v in (a, b, c, e)]
    products = []
    for left, right in ((aa, cc), (bb, ee), (aa, ee), (bb, cc)):
        bits = max(abs(left).bit_length(), abs(right).bit_length())
        ledger["integer_multiplications"] += 1
        ledger["integer_multiply_operand_bits_sum"] += abs(left).bit_length()+abs(right).bit_length()
        ledger["integer_multiply_max_bits"] = max(ledger["integer_multiply_max_bits"], bits)
        result = integer_multiply(abs(left), abs(right))
        if (left < 0) != (right < 0): result = -result
        products.append(unpack_centered(result, 2*r, width))
    ac, be, ae, bc = products
    ledger["packing_input_blocks"] += 4*r
    ledger["extraction_output_blocks"] += 8*r
    return [(ac[j]-ac[j+r]-be[j]+be[j+r], ae[j]-ae[j+r]+bc[j]-bc[j+r]) for j in range(r)]


def normalized_ring_product(f, g, p, *, integer_multiply=mul, ledger=None):
    raw = ring_product_numerators(f, g, p, integer_multiply=integer_multiply, ledger=ledger)
    shift = p+len(f).bit_length()-1
    return [(trunc_shift(a, shift), trunc_shift(b, shift)) for a, b in raw]


def _power_log(n):
    if not isinstance(n, int) or n < 1 or n & (n-1):
        raise ValueError("axis lengths must be powers of two")
    return n.bit_length()-1


@dataclass(frozen=True)
class Layout:
    """Named bit slots and the actual prefix-move/chunk-exchange schedule L."""
    axes: tuple
    r: int
    chunk_bits: int = 1

    def __post_init__(self):
        ell = _power_log(self.r)
        if ell < 1 or not self.axes or self.chunk_bits < 1:
            raise ValueError("nonempty axes, r >= 2, and positive chunk width required")
        if any(t not in (self.r//2, self.r) for t in self.axes):
            raise ValueError("axes must have lengths r/2 or r")
        if self.chunk_bits > max(1, ell-1): raise ValueError("chunk width exceeds common axis width")

    @property
    def size(self): return prod(self.axes)
    @property
    def original_slots(self):
        return tuple((i, h) for i, t in enumerate(self.axes) for h in range(_power_log(t)-1, -1, -1))

    def schedule(self):
        ell, k = _power_log(self.r), self.chunk_bits
        b = (ell-1) % k
        slots = list(self.original_slots)
        prefix = [(i, ell-1) for i, t in enumerate(self.axes) if t == self.r]
        prefix += [(i, h) for h in range(b-1, -1, -1) for i in range(len(self.axes))]
        moves = []
        for destination, slot in enumerate(prefix):
            source = slots.index(slot)
            if source != destination:
                moves.append(("bit_move", source, destination, 1))
                slots.insert(destination, slots.pop(source))
        prefix_len, q = len(prefix), (ell-1)//k
        chunks = [(i, j) for i in range(len(self.axes)) for j in range(q)]
        target = [(i, j) for j in range(q) for i in range(len(self.axes))]
        for destination, chunk in enumerate(target):
            source = chunks.index(chunk)
            if source == destination: continue
            a, z = prefix_len+destination*k, prefix_len+source*k
            moves.append(("chunk_swap", a, z, k))
            slots[a:a+k], slots[z:z+k] = slots[z:z+k], slots[a:a+k]
            chunks[destination], chunks[source] = chunks[source], chunks[destination]
        return tuple(slots), tuple(moves)

    def frequency_at(self, physical_index):
        """Natural frequency coordinates at a stored LB address."""
        slots, _ = self.schedule()
        frequency = [0]*len(self.axes)
        for position, (axis, h) in enumerate(slots):
            bit = (physical_index >> (len(slots)-1-position)) & 1
            frequency[axis] |= bit << (_power_log(self.axes[axis])-1-h)
        return tuple(frequency)


def permute_slots(records, source_slots, target_slots, ledger):
    """Explicit reference address permutation. Full bit/address work is logged."""
    if set(source_slots) != set(target_slots) or len(source_slots) != len(target_slots):
        raise ValueError("slot sets differ")
    n = len(source_slots)
    if len(records) != 1 << n: raise ValueError("incomplete address range")
    if source_slots == target_slots: return [list(poly) for poly in records]
    bit_map = [n-1-source_slots.index(slot) for slot in target_slots]
    out = [None]*len(records)
    for old, record in enumerate(records):
        new = 0
        for bit in bit_map: new = (new << 1) | ((old >> bit) & 1)
        out[new] = list(record)
    ledger["reference_permutation_records"] += len(records)
    ledger["reference_address_bit_actions"] += n*len(records)
    return out


def direct_layer(records, selected_bits, ledger):
    """Exact unnormalized Walsh factors; caller divides once after all axes.

    This is the current correctness backend, with ordinary per-axis work.
    A fast recursive layer must satisfy the same contract before substitution.
    """
    n = len(records)
    if len(set(selected_bits)) != len(selected_bits): raise ValueError("duplicate selected bit")
    if any(b < 0 or (1 << b) >= n for b in selected_bits): raise ValueError("selected bit outside address")
    out = [list(poly) for poly in records]
    for bit in selected_bits:
        stride = 1 << bit
        for start in range(0, n, 2*stride):
            for j in range(stride):
                low, high = start+j, start+j+stride
                a, b = out[low], out[high]
                out[low] = [(ar+br, ai+bi) for (ar, ai), (br, bi) in zip(a, b)]
                out[high] = [(ar-br, ai-bi) for (ar, ai), (br, bi) in zip(a, b)]
                ledger["scalar_component_additions"] += 4*len(a)
                ledger["polynomial_butterflies"] += 1
    ledger["layer_calls"] += 1
    return out


def transform(records, layout, p, *, opposite=False, layer=direct_layer, layout_move=None, ledger=None):
    """Grid approximation to LB F^- or F^+ B^-1 L^-1, both normalized.

    Each simultaneous round truncates once after all participating factors.
    The default random-access address backend and direct layer are reference
    implementations. Injecting other backends does not itself prove a
    sub-N-log-N bound; their arithmetic and movement costs must be established.
    """
    ledger = ledger if ledger is not None else Counter()
    _shape(records, layout.r, p)
    if len(records) != layout.size: raise ValueError("record count mismatch")
    slots, moves = layout.schedule()
    position = {slot: len(slots)-1-i for i, slot in enumerate(slots)}
    data = ([list(poly) for poly in records] if opposite else
            permute_slots(records, layout.original_slots, slots, ledger) if layout_move is None else
            layout_move(records,layout,False,ledger))
    ledger["scheduled_bit_moves"] += sum(op[0] == "bit_move" for op in moves)
    ledger["scheduled_chunk_swaps"] += sum(op[0] == "chunk_swap" for op in moves)
    ell = _power_log(layout.r)
    rounds = range(ell) if opposite else range(ell-1, -1, -1)
    for h in rounds:
        participants = [i for i, t in enumerate(layout.axes) if _power_log(t) > h]
        if not participants: continue
        selected = [position[i, h] for i in participants]

        def phases(array):
            out = []
            step = (2*layout.r) >> (h+1)
            for address, record in enumerate(array):
                exponent = 0
                for i in participants:
                    if (address >> position[i, h]) & 1:
                        low = sum(((address >> position[i, j]) & 1) << j for j in range(h))
                        exponent += step*low
                out.append(monomial(record, exponent if opposite else -exponent))
            ledger["monomial_record_actions"] += len(array)
            return out

        if opposite: data = phases(data)
        data = layer(data, selected, ledger)
        shift = len(participants)
        data = [[(trunc_shift(a, shift), trunc_shift(b, shift)) for a, b in poly] for poly in data]
        ledger["rounded_components"] += 2*layout.size*layout.r
        if not opposite: data = phases(data)
    if opposite:
        data = (permute_slots(data,slots,layout.original_slots,ledger) if layout_move is None else
                layout_move(data,layout,True,ledger))
    return data


def normalized_convolution(f, g, layout, p, *, integer_multiply=mul, layer=direct_layer, layout_move=None, ledger=None):
    """Approximate f*g/(r*M) on cyclic record axes and a negacyclic suffix.

    In coefficient units, absolute error is < sqrt(2)*M*(3*ell+1)*2**(-p).
    Its numerator error is therefore < sqrt(2)*M*(3*ell+1).
    Inputs must lie in the unit disk. Final output need not unless an operand
    margin also covers that error; do not silently clamp the final result.
    """
    ledger = ledger if ledger is not None else Counter()
    _shape(f, layout.r, p, require_disk=True)
    _shape(g, layout.r, p, require_disk=True)
    a = transform(f, layout, p, layer=layer, layout_move=layout_move, ledger=ledger)
    b = transform(g, layout, p, layer=layer, layout_move=layout_move, ledger=ledger)
    pointwise = [normalized_ring_product(x, y, p, integer_multiply=integer_multiply, ledger=ledger)
                 for x, y in zip(a, b)]
    result = transform(pointwise, layout, p, opposite=True, layer=layer, layout_move=layout_move, ledger=ledger)
    return [[(re*layout.size, im*layout.size) for re, im in poly] for poly in result]


def status():
    return {"numerical_interfaces": "synthetic transform and normalized ring convolution implemented",
            "layer_backend": "explicit per-axis reference", "address_backend": "explicit permutation reference",
            "integer_multiply_backend": "injected callable; default Python multiplication",
            "sub_n_log_n_proved_for_implementation": False}


def multiply_reference(x, y, *, digit_bits=None, integer_multiply=mul, layer=direct_layer, layout_move=None,
                       layer_factory=None, layout_move_factory=None):
    """End-to-end exact integer adapter exercising the synthetic interfaces.

    This test adapter uses a zero-padded matrix, without Gaussian resampling.
    Its precision is derived from the proved synthetic-convolution error bound.
    It is NOT the preprint's final reduction or a sub-N-log-N algorithm.
    Every call, including zero inputs, goes through the synthetic transform.
    """
    if not isinstance(x, int) or not isinstance(y, int) or x < 0 or y < 0:
        raise ValueError("nonnegative integer operands required")
    n = max(1, x.bit_length(), y.bit_length())
    m = max(2, n.bit_length()) if digit_bits is None else digit_bits
    if not isinstance(m, int) or m < 1: raise ValueError("positive integer digit width required")
    length = (n+m-1)//m
    side = isqrt(length)
    if side*side < length: side += 1
    r = 1 << (2*side-1).bit_length()
    t = r//2 if r >= 4 and r*r//8 >= length else r
    columns, rows = r//2, t//2
    layout = Layout((t,), r, max(1, (_power_log(r)-1)//2))
    total = t*r
    scale_bits = m+2
    ell = _power_log(r)
    # Numerator error < sqrt(2)*t*(3ell+1). Recovered coefficient error
    # is that times total*2**(2*scale_bits-p), strictly below sqrt(2)/8.
    p = max(ell+1, 2*scale_bits+_power_log(total)+_power_log(t)+(3*ell+1).bit_length()+3)
    if layer_factory is not None:
        if layer is not direct_layer: raise ValueError("supply either layer or precision-aware layer_factory")
        layer=layer_factory(p)
    if layout_move_factory is not None:
        if layout_move is not None: raise ValueError("supply either layout_move or precision-aware layout_move_factory")
        layout_move=layout_move_factory(p)
    ledger = Counter()

    def encode(value):
        raw = memoryview(value.to_bytes((n+7)//8, "little"))
        records = [[(0, 0)]*r for _ in range(t)]
        mask = (1 << m)-1
        for j in range(length):
            byte, offset = divmod(j*m, 8)
            digit = (int.from_bytes(raw[byte:byte+(offset+m+7)//8], "little") >> offset) & mask
            row, col = divmod(j, columns)
            records[row][col] = (digit << (p-scale_bits), 0)
        ledger["input_digit_reads"] += length
        return records

    f, g = encode(x), encode(y)
    approximate = normalized_convolution(f,g,layout,p,integer_multiply=integer_multiply,
                                        layer=layer,layout_move=layout_move,ledger=ledger)
    recovery_shift = p-2*scale_bits-_power_log(total)
    half = 1 << (recovery_shift-1)
    folded = [0]*(2*rows*columns+2*columns)
    rounded_max_error_bound_squared = 2*t*t*(3*ell+1)**2
    for row, polynomial in enumerate(approximate):
        for col, (real, imaginary) in enumerate(polynomial):
            coefficient = (real+half) >> recovery_shift
            imaginary_coefficient = (imaginary+half) >> recovery_shift
            if coefficient < 0 or imaginary_coefficient != 0:
                raise ArithmeticError("coefficient recovery failed")
            if row >= 2*rows-1 or col >= 2*columns-1:
                if coefficient != 0: raise ArithmeticError("nonzero padded coefficient")
            folded[row*columns+col] += coefficient
    digits, carry, mask = [], 0, (1 << m)-1
    for coefficient in folded:
        value = coefficient+carry
        digits.append(value & mask)
        carry = value >> m
    while carry:
        digits.append(carry & mask)
        carry >>= m
    result = int.from_bytes(_blocks_to_bytes(digits, m), "little")
    backend_status=status()
    if layer is not direct_layer: backend_status["layer_backend"]="injected layer; no speed bound implied"
    if layout_move is not None: backend_status["address_backend"]="injected layout mover; no speed bound implied"
    info = dict(input_bits=n, digit_bits=m, digit_count=length, transform_shape=(t, r), precision_bits=p,
                coefficient_recovery_shift=recovery_shift,
                coefficient_error_squared_bound=f"{rounded_max_error_bound_squared}/2**{2*recovery_shift}",
                ledger=dict(ledger), implementation_status=backend_status,
                reduction="zero-padded matrix integration adapter, not final Gaussian-resampling reduction")
    return result, info
