"""Recursive Fermat backend timings and a complete-reduction integration check."""
from collections import Counter
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import random
import sys

SOURCES = ("benchmark_fermat_recursive.py","fermat_recursive.py","stream_moves.py","synthetic.py",
           "multiply_resampled.py","resampled_transform.py","certified_phase.py","certified_exp.py",
           "crt_layout.py","gaussian_resampling.py","gaussian_tensor.py","guarded_layer.py",
           "packed_stream.py","packed_bits.py","swap_recursion.py","bit_frames.py","motifs.py",
           "network_frames.py","recursive_edges.py","recursive_network.py","phase_layers.py",
           "test_stream_swap.py")


def main():
    root = Path(__file__).resolve().parent
    def hashes(): return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in SOURCES}
    before = hashes()
    from fermat_recursive import RecursiveFermatMultiplier
    from guarded_layer import make_guarded_network_layer
    from multiply_resampled import multiply_resampled
    from network_frames import ComplexNetwork
    from packed_stream import make_stream_layout_move
    from swap_recursion import CompiledBitCircuit
    from test_stream_swap import SwapControl
    report = dict(python=sys.version,platform=platform.platform(),
        scope="Recursive short-product backend; not a below-N-log-N multiplier by itself",
        method="Three cold calls per size, global backend audit counters disabled inside timer; separate untimed audited call must return the identical product; all operand setup/conversion/FFT/recursion/carries inside each call",
        leaf_bits=1024,sizes=[])
    rng = random.Random(233691)
    was_enabled = gc.isenabled()
    gc.disable()
    try:
        for bits in (256,1024,4096,16384,65536,262144):
            a,b = [rng.getrandbits(bits) | (1 << (bits-1)) for _ in range(2)]
            samples,native = [],[]
            for _ in range(3):
                started = perf_counter_ns()
                value = RecursiveFermatMultiplier(1024)(a,b)
                samples.append(perf_counter_ns()-started)
                started = perf_counter_ns()
                expected = a*b
                native.append(perf_counter_ns()-started)
                if value!=expected: raise AssertionError("backend product")
            ledger = Counter()
            if RecursiveFermatMultiplier(1024,ledger=ledger)(a,b)!=expected:
                raise AssertionError("audit mode changed result")
            report["sizes"].append(dict(input_bits=bits,samples_ns=samples,median_ns=median(samples),
                native_samples_ns=native,native_median_ns=median(native),audit_ledger=dict(ledger)))
            print(json.dumps({"bits":bits,"median_ms":median(samples)/1e6,
                              "audited_depth":ledger["fermat_max_depth"]}),flush=True)
        integration = []
        a,b = 0xdeadbeef,0xfedcba98
        for _ in range(3):
            started = perf_counter_ns()
            circuit = CompiledBitCircuit(SwapControl())
            layer = make_guarded_network_layer(ComplexNetwork(100),192,swap_circuit=circuit)
            movement = make_stream_layout_move(circuit,component_bytes=25)
            value,diagnostics = multiply_resampled(a,b,sources=(3,5),targets=(4,8),p=192,
                alpha=6,digit_bits=4,circuit=circuit,layer=layer,layout_move=movement,
                integer_multiply=RecursiveFermatMultiplier(1024))
            integration.append(perf_counter_ns()-started)
            if value!=a*b: raise AssertionError("full resampled integration")
        report["resampled_integration"] = dict(samples_ns=integration,median_ns=median(integration),
            diagnostics=diagnostics,scope="Explicit finite parameters; actual h100 small-width phase branch and separate no-saving swap control")
        print(json.dumps({"resampled_integration_ms":median(integration)/1e6}),flush=True)
    finally:
        if was_enabled: gc.enable()
    if hashes()!=before: raise RuntimeError("sources changed during benchmark")
    report.update(source_sha256=before,sources_unchanged_during_benchmark=True,
                  checked_timed_products=21,checked_untimed_audit_products=6)
    (root/"fermat_recursive_benchmarks.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")


if __name__ == "__main__": main()
