"""Independent exact oracles and adversarial controls for the research primitives."""
from collections import Counter
from dataclasses import replace
from fractions import Fraction as Q
from itertools import combinations, product
import random
import unittest

from motifs import (Budget, Gaussian as G, I_POWERS, Motif, identity, lower_factorization,
                    matmul, phase_frame, shear_by_rank, translation_kernel)
from cost_certificate import certificate, improved_parameters, original_parameters

COUNTS = Counter()


def walsh(values):
    """Defining dense Walsh matrix; independent of translation kernels."""
    return [sum((value*(-1 if (x & y).bit_count() % 2 else 1)
                 for y, value in enumerate(values)), G()) for x in range(len(values))]


def defining_frame(values, basis, inverse=False):
    spectrum = walsh(values)
    for x in range(len(values)):
        projection = 0
        for v in basis:
            if (x & v).bit_count() % 2: projection ^= v
        phase = (-1 if inverse else 1)*projection.bit_count()
        spectrum[x] *= I_POWERS[phase % 4]
    return [z*Q(1, len(values)) for z in walsh(spectrum)]


def rank(matrix):
    """Ordinary row echelon oracle, unlike the ordered two-sided factorization."""
    a = [[Q(x) for x in row] for row in matrix]
    row = 0
    for col in range(len(a)):
        p = next((i for i in range(row, len(a)) if a[i][col]), None)
        if p is None: continue
        a[row], a[p] = a[p], a[row]
        scale = a[row][col]
        a[row] = [x/scale for x in a[row]]
        for i in range(row+1, len(a)):
            scale = a[i][col]
            a[i] = [x-scale*y for x, y in zip(a[i], a[row])]
        row += 1
    return row


def orthonormal_basis(m, rng):
    basis = [1 << i for i in range(m)]
    for _ in range(20):
        u = rng.randrange(1 << m)
        if u.bit_count() % 2: continue
        basis = [v ^ (u if (v & u).bit_count() % 2 else 0) for v in basis]
    return basis


class ScalarTests(unittest.TestCase):
    def test_all_input_basis_vectors_and_arbitrary_scratch(self):
        for h in (3, 4, 5, 6):
            for kind in ("bit", "complex"):
                motif = Motif(h, kind)
                total = 2*motif.v+len(motif.edges)+motif.center_count
                for column in range(total):
                    vector = [0 if kind == "bit" else Q(0)]*total
                    vector[column] = 1 if kind == "bit" else Q(1)
                    x = vector[:motif.v]
                    y = vector[motif.v:2*motif.v]
                    side = vector[2*motif.v:-motif.center_count]
                    center = vector[-motif.center_count:]
                    saved = [list(z) for z in (x, y, side, center)]
                    motif.apply(x, y, side, center)
                    expected_y = [a ^ b if kind == "bit" else a+b for a, b in zip(saved[0], saved[1])]
                    self.assertEqual([x, y, side, center], [saved[0], expected_y, saved[2], saved[3]])
                    motif.apply(x, y, side, center, inverse=True)
                    self.assertEqual([x, y, side, center], saved)
                    COUNTS["scalar_basis_forward_inverse"] += 1

    def test_random_gaussian_and_bit_scratch(self):
        rng = random.Random(713006)
        for h in (7, 8, 10):
            for kind in ("bit", "complex"):
                motif = Motif(h, kind)
                def value():
                    return (rng.getrandbits(128) if kind == "bit" else
                            G(Q(rng.randrange(-100, 101), 8), Q(rng.randrange(-100, 101), 16)))
                for _ in range(3):
                    x, y = [[value() for _ in range(motif.v)] for _ in range(2)]
                    side = [value() for _ in motif.edges]
                    center = [value() for _ in range(motif.center_count)]
                    saved = [list(z) for z in (x, y, side, center)]
                    motif.apply(x, y, side, center)
                    expected = [a ^ b if kind == "bit" else a+b for a, b in zip(saved[0], saved[1])]
                    self.assertEqual([x, y, side, center], [saved[0], expected, saved[2], saved[3]])
                    COUNTS["random_invocations"] += 1

    def test_full_tensor_exchange(self):
        rng = random.Random(1183)
        for h in (4, 5):
            for kind in ("bit", "complex"):
                motif = Motif(h, kind)
                def value(): return rng.getrandbits(31) if kind == "bit" else Q(rng.randrange(-30, 31), 4)
                x, y = [[value() for _ in range(motif.v**3)] for _ in range(2)]
                saved = list(x), list(y)
                def scratch(axis, fixed, sizes):
                    return tuple([value() for _ in range(size)] for size in sizes)
                calls = motif.exchange(x, y, scratch)
                self.assertEqual(x, saved[1] if kind == "bit" else [-v for v in saved[1]])
                self.assertEqual(y, saved[0])
                self.assertEqual(calls, 3*motif.v**2)
                COUNTS["full_exchange_invocations"] += calls

    def test_symbolic_intersection_identity(self):
        # Covers h=100 through the five distinct (intersection, equality) types;
        # scratch restoration is linear cancellation for every input value.
        for kind in ("bit", "complex"):
            for intersection, same in ((0, False), (1, False), (2, False), (3, True)):
                central = intersection % 2 if kind == "bit" else Q(intersection-1, 2)
                side = int(intersection == 1) if kind == "bit" else (-central if intersection % 2 == 0 else 0)
                net = central ^ side if kind == "bit" else central+side
                self.assertEqual(net, int(same))
                COUNTS["symbolic_intersection_types"] += 1

    def test_bad_schedule_detected(self):
        motif = Motif(5, "complex")
        x, y = [Q(0)]*motif.v, [Q(0)]*motif.v
        side, center = [Q(1)]*len(motif.edges), [Q(1)]*motif.center_count
        motif.schedule = motif.schedule[2:]  # Missing old-scratch cancellation.
        motif.apply(x, y, side, center)
        self.assertNotEqual(y, [Q(0)]*motif.v)
        COUNTS["negative_controls"] += 1


class PhaseTests(unittest.TestCase):
    def test_defining_frames_and_residuals(self):
        rng = random.Random(5166)
        for m in range(1, 7):
            for _ in range(3):
                basis = orthonormal_basis(m, rng)
                values = [G(Q(rng.randrange(-8, 9), 8), Q(rng.randrange(-8, 9), 4)) for _ in range(1 << m)]
                for k in range(m+1):
                    frame = phase_frame(values, basis[:k])
                    self.assertEqual(frame, defining_frame(values, basis[:k]))
                    self.assertEqual(phase_frame(frame, basis[:k], inverse=True), values)
                    for j in range(k+1):
                        residual = phase_frame(phase_frame(values, basis[:j], inverse=True), basis[:k])
                        self.assertEqual(residual, defining_frame(values, basis[j:k]))
                        COUNTS["nested_phase_residuals"] += 1
                    COUNTS["defining_phase_and_inverse"] += 1

    def test_endpoint_correction(self):
        # u has odd norm. Complete it to an orthonormal basis by exhaustive
        # search in the small test space, independent of the kernel routines.
        for m, u in ((4, 7), (5, 7), (6, 31)):
            basis = [u]
            def extend(current):
                if len(current) == m: return current
                for v in range(1, 1 << m):
                    if v.bit_count() % 2 and all((v & w).bit_count() % 2 == 0 for w in current):
                        found = extend(current+[v])
                        if found: return found
                return None
            basis = extend(basis)
            self.assertIsNotNone(basis)
            values = [G(Q(x-3, 4), Q((x*x) % 7, 8)) for x in range(1 << m)]
            z_input = [v*(-1 if (x & u).bit_count() % 2 else 1) for x, v in enumerate(values)]
            routed = defining_frame(defining_frame(z_input, [u], inverse=True), basis[1:])
            corrected = [v*I_POWERS[u.bit_count() % 4]*(-1 if (x & u).bit_count() % 2 else 1)
                         for x, v in enumerate(routed)]
            expected = defining_frame(values, [1 << j for j in range(m)])
            self.assertEqual(corrected, expected)
            COUNTS["endpoint_corrections"] += 1

    def test_weight_three_sign_is_not_optional(self):
        values = [G(int(x == 0)) for x in range(8)]
        self.assertNotEqual(translation_kernel(values, 7), defining_frame(values, [7]))
        self.assertEqual(translation_kernel(values, 7, inverse=True), defining_frame(values, [7]))
        COUNTS["negative_controls"] += 1


class ShearTests(unittest.TestCase):
    def assert_factor(self, matrix):
        e1, p, e2 = factors = lower_factorization(matrix)
        n = len(matrix)
        self.assertEqual(matmul(matmul(e1, p), e2), matrix)
        for e in (e1, e2):
            self.assertTrue(all(e[i][i] for i in range(n)))
            self.assertTrue(all(e[i][j] == 0 for i in range(n) for j in range(i+1, n)))
        self.assertTrue(all(x in (0, 1) for row in p for x in row))
        self.assertTrue(all(sum(row) <= 1 for row in p))
        self.assertTrue(all(sum(col) <= 1 for col in zip(*p)))
        r = rank(matrix)
        self.assertEqual(sum(sum(row) for row in p), r)
        COUNTS["rational_factorizations"] += 1
        return factors, r

    def test_exhaustive_two_by_two(self):
        for entries in product((-1, 0, 1), repeat=4):
            a = [list(entries[:2]), list(entries[2:])]
            factors, rank_a = self.assert_factor(a)
            for fields in product(range(3), repeat=4):
                h, d = fields[:2], fields[2:]
                hh, dd, count = shear_by_rank(h, d, factors, 5)
                self.assertEqual(hh, [(h[i]+sum(a[i][j]*d[j] for j in range(2))) % 5 for i in range(2)])
                self.assertEqual(dd, list(d))
                self.assertEqual(count, rank_a)
                COUNTS["exhaustive_modular_shears"] += 1

    def test_random_rational_and_composite_moduli(self):
        rng = random.Random(14452)
        for n in range(1, 8):
            for trial in range(12):
                a = [[Q(rng.randrange(-5, 6), rng.choice((1, 2, 3, 7))) for _ in range(n)] for _ in range(n)]
                if trial % 3 == 0: a[-1] = [Q(0)]*n
                factors, rank_a = self.assert_factor(a)
                # Pick a small prime avoiding ALL factor denominators and diagonals.
                for prime in (101, 103, 107, 109, 113, 127, 131):
                    if all(x.denominator % prime for e in factors for row in e for x in row) and all(
                            e[i][i].numerator % prime for e in (factors[0], factors[2]) for i in range(n)):
                        break
                else: self.fail("no test prime")
                for mod in (prime, prime**2, prime**3):
                    h, d = [[rng.randrange(mod) for _ in range(n)] for _ in range(2)]
                    hh, dd, count = shear_by_rank(h, d, factors, mod)
                    expected = [(h[i]+sum(v.numerator*pow(v.denominator, -1, mod)*d[j]
                                         for j, v in enumerate(a[i]))) % mod for i in range(n)]
                    self.assertEqual((hh, dd, count), (expected, d, rank_a))
                    COUNTS["rational_prime_power_shears"] += 1

    def test_nonunit_denominator_rejected(self):
        with self.assertRaises(ValueError): shear_by_rank([1], [1], lower_factorization([[Q(1, 2)]]), 4)
        COUNTS["negative_controls"] += 1


class BudgetTests(unittest.TestCase):
    def test_exact_published_constants(self):
        expected = {"bit": (177176569091445000000, 177176569088785861287000000, Q(339, 22587335000000)),
                    "complex": (1873807244643542670000, 1873807244636671267308000000, Q(73, 19906842167500))}
        for kind, values in expected.items():
            b = Budget(100, kind)
            self.assertEqual((b.wires, b.ranks, b.deficit), values)
            self.assertEqual(b.edge_count_certificate()["ranks"], b.ranks)
            COUNTS["published_rank_budgets"] += 1
        for h in range(7, 151):
            for kind in ("bit", "complex"):
                if h == 9 and kind == "bit": continue
                b = Budget(h, kind)
                self.assertEqual(b.edge_count_certificate()["ranks"], b.ranks)
                COUNTS["parameterized_edge_sums"] += 1

    def test_cost_parameters(self):
        old, new = original_parameters(), improved_parameters()
        self.assertTrue(all(old.check().values()))
        self.assertTrue(all(new.check().values()))
        self.assertEqual(min(old.margins()), Q(1, 2**181))
        self.assertEqual(min(new.margins()), 2*new.kappa)
        self.assertGreater(new.kappa/old.kappa, 2**59)
        with self.assertRaises(ValueError): replace(new, kappa=new.kappa*2).check()
        with self.assertRaises(ValueError): replace(new, c=Q(1)).check()
        certificate()
        COUNTS["exact_cost_inequalities"] += len(old.check())+len(new.check())
        COUNTS["negative_controls"] += 2


if __name__ == "__main__":
    unittest.main()
