from collections import Counter
from itertools import combinations
import random
import unittest
from phase_layers import explicit_c_numerators, phase_layer
from synthetic import Layout, direct_layer, normalized_convolution, transform

COUNTS = Counter()


def defining_walsh(records, bits):
    mask = sum(1 << b for b in bits)
    result = []
    for address in range(len(records)):
        row = []
        for coefficient in range(len(records[0])):
            real = imag = 0
            for source in range(len(records)):
                if source & ~mask != address & ~mask: continue
                sign = -1 if (address & source & mask).bit_count() % 2 else 1
                a, b = records[source][coefficient]
                real += sign*a
                imag += sign*b
            row.append((real, imag))
        result.append(row)
    return result


class PhaseLayerTests(unittest.TestCase):
    def test_all_selected_bit_subsets(self):
        rng = random.Random(30119)
        for width in range(1, 7):
            for d in range(width+1):
                for bits in combinations(range(width), d):
                    records = [[(rng.randrange(-500, 501), rng.randrange(-500, 501)) for _ in range(2)]
                               for _ in range(1 << width)]
                    ledger = Counter()
                    actual = phase_layer(records, bits, ledger)
                    self.assertEqual(actual, defining_walsh(records, bits))
                    self.assertEqual(actual, direct_layer(records, bits, Counter()))
                    self.assertEqual(ledger["phase_common_exact_fraction_bits"], d)
                    COUNTS["phase_layer_bit_subsets"] += 1

    def test_synthetic_integration(self):
        rng = random.Random(30122)
        for axes in ((4,4), (4,8), (8,4), (4,4,4)):
            layout, p = Layout(axes, 8, 2), 12
            f, g = [[[(rng.randrange(-300,301),rng.randrange(-300,301)) for _ in range(8)]
                     for _ in range(layout.size)] for _ in range(2)]
            for opposite in (False, True):
                self.assertEqual(transform(f,layout,p,opposite=opposite,layer=phase_layer),
                                 transform(f,layout,p,opposite=opposite))
                COUNTS["phase_synthetic_transforms"] += 1
            self.assertEqual(normalized_convolution(f,g,layout,p,layer=phase_layer),
                             normalized_convolution(f,g,layout,p))
            COUNTS["phase_synthetic_convolutions"] += 1

    def test_bad_backend_normalization_detected(self):
        def faulty(records, bits, ledger):
            result = explicit_c_numerators(records,bits,ledger)
            a,b=result[0][0]
            result[0][0]=(a+1,b)
            return result
        with self.assertRaises(ArithmeticError):
            phase_layer([[(1,0)],[(0,0)]], [0], Counter(), c_backend=faulty)
        COUNTS["negative_controls"] += 1


if __name__ == "__main__": unittest.main()
