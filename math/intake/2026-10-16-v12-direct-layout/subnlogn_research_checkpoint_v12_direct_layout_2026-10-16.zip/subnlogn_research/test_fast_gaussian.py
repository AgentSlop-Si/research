"""Cross-check fast arithmetic maps against independent reference loops."""
from collections import Counter
from operator import mul
import random
import unittest

from fast_gaussian import FastGaussianLine, FastGaussianTensor, ResidueTape
from fast_resampled import (FastCyclicConvolver, FastArithmeticSourceTransform,
                            fast_ring_product, fast_convolution, multiply_fast_finite, check_norm)
from fast_scalar import FastArithmetic, FastCertifiedExp, FastCertifiedPhase
from fermat_recursive import NullLedger
from gaussian_resampling import GaussianLine, GaussianParameters
from gaussian_tensor import GaussianTensor
from resampled_transform import CyclicConvolver
from synthetic import Layout, normalized_convolution, normalized_ring_product, direct_layer
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl

COUNTS = Counter()


class MemoExp:
    """Unbounded memo is ONLY a test oracle, never the production cache."""
    def __init__(self):
        self.engine = FastCertifiedExp(integer_multiply=mul)
        self.cache = {}
    def grid(self, n, d, p, *, shift=0):
        key = n, d, p, shift
        if key not in self.cache: self.cache[key] = self.engine.grid(n, d, p, shift=shift)
        return self.cache[key]


def reference_line(parameters):
    line = GaussianLine(parameters)
    line.exponential = MemoExp()
    return line


class FastGaussianTests(unittest.TestCase):
    def test_incremental_geometry(self):
        for s, t, p, alpha in ((3, 4, 101, 5), (5, 8, 128, 5), (17, 32, 128, 4), (3, 8, 101, 3)):
            a = GaussianParameters(s, t, p, alpha)
            line = FastGaussianLine(a, integer_multiply=mul)
            radius = a.expansion_radius
            expected = [((s*k-radius*t)//t+1, -(-(s*k+radius*t)//t), s*k % t) for k in range(t)]
            self.assertEqual(list(line._expansion_rows()), expected)
            self.assertEqual([beta for _, beta in line._betas()], [a.beta_numerator(j) for j in range(s)])
            values = [(j, -j) for j in range(t)]
            self.assertEqual(line.select(values), [values[j] for j in a.selected_coordinates()])
            COUNTS["fast_gaussian_geometry_cases"] += 1

    def test_all_maps_and_weight_reuse(self):
        rng = random.Random(61629)
        for s, t, p, alpha in ((3, 4, 101, 5), (5, 8, 128, 5), (3, 8, 101, 3)):
            a, ledger = GaussianParameters(s, t, p, alpha), Counter()
            line = FastGaussianLine(a, ledger=ledger, integer_multiply=mul)
            reference = reference_line(a)
            for name in ("expand", "correction", "neumann", "diagonal", "select", "compress"):
                count = t if name in ("select", "compress") else s
                values = [(rng.randrange(-(1 << (p-3)), 1 << (p-3)),
                           rng.randrange(-(1 << (p-3)), 1 << (p-3))) for _ in range(count)]
                self.assertEqual(getattr(line, name)(values), getattr(reference, name)(values))
                calls = ledger["fast_certified_exp_calls"]
                zeros = [(0, 0)]*count
                self.assertEqual(getattr(line, name)(zeros), [(0, 0)]*(t if name == "expand" else s))
                self.assertEqual(ledger["fast_certified_exp_calls"], calls)
                COUNTS["fast_gaussian_map_comparisons"] += 1
            self.assertEqual(ledger["gaussian_weight_tapes_built"], 3)
            self.assertLessEqual(len(line.exp_cache), line.CACHE_CAPACITY)
            self.assertGreater(ledger["gaussian_fixed_cache_hits"], 0)
            self.assertEqual(ledger.get("exp_taylor_terms", 0), 0)

    def test_bounded_cache_eviction(self):
        # More than 256 distinct underflow arguments: cheap exact certificates.
        line = FastGaussianLine(GaussianParameters(3, 4, 101, 5), ledger=Counter(), integer_multiply=mul)
        for j in range(300): self.assertEqual(line._exponential_value(-101-j, 1), 0)
        self.assertEqual(len(line.exp_cache), 256)
        calls = line.ledger["fast_certified_exp_calls"]
        self.assertEqual(line._exponential_value(-101, 1), 0)
        self.assertEqual(line.ledger["fast_certified_exp_calls"], calls+1)
        COUNTS["fast_gaussian_cache_evictions"] += 45

    def test_tensor_maps_and_axis_orders(self):
        p, alpha = 128, 5
        circuit = CompiledBitCircuit(SwapControl())
        tensor = FastGaussianTensor((3, 5), (4, 8), p, alpha, circuit, integer_multiply=mul)
        reference = GaussianTensor((3, 5), (4, 8), p, alpha, circuit)
        for line in reference.lines: line.exponential = MemoExp()
        values = [((j-7) << (p-7), (3-j) << (p-8)) for j in range(15)]
        for order in ((0, 1), (1, 0)):
            for inverse in (False, True):
                data = ([(i << (p-8), -i << (p-9)) for i in range(32)] if inverse else tensor.embed(values))
                self.assertEqual(tensor.apply(data, inverse=inverse, axis_order=order),
                                 reference.apply(data, inverse=inverse, axis_order=order))
                COUNTS["fast_gaussian_tensor_comparisons"] += 1
        self.assertEqual(dict(tensor.ledger), {})

    def test_head_movement_and_recursive_weights(self):
        ledger = Counter()
        tape = ResidueTape(list(range(7)), 13, ledger)
        self.assertEqual([tape.read(i) for i in (0, 6, 0, 3, 2)], [0, 6, 0, 3, 2])
        self.assertEqual(ledger["gaussian_head_move_bits"], (0+5+7+2+2)*13)
        # Only the diagonal here; the separate complete product uses all maps.
        a = GaussianParameters(3, 4, 101, 5)
        fast, control = FastGaussianLine(a), FastGaussianLine(a, integer_multiply=mul)
        values = [(1 << 98, 0), (0, -(1 << 98)), (1 << 97, 1 << 97)]
        self.assertEqual(fast.diagonal(values), control.diagonal(values))
        self.assertEqual(dict(fast.ledger), {})
        COUNTS["fast_gaussian_recursive_diagonal_cases"] += 1

    def test_periodic_head_bound_controls(self):
        for s, t, p, alpha in ((3, 4, 101, 5), (17, 32, 128, 4),
                                (113, 128, 101, 6), (127, 256, 101, 4), (257, 512, 101, 4)):
            a, ledger = GaussianParameters(s, t, p, alpha), Counter()
            line = FastGaussianLine(a, ledger=ledger, integer_multiply=mul)
            # Movement-only controls: explicit zero weight tapes avoid scalar
            # setup; complete numerical maps are tested separately above.
            line.weight_tapes["A"] = [0]*sum(stop-start for start, stop, _ in line._expansion_rows())
            line.weight_tapes["E"] = [0]*(2*s*a.correction_radius)
            for name, size, radius in (("expand", t, a.expansion_radius),
                                        ("correction", s, a.correction_radius)):
                ledger["gaussian_head_move_bits"] = ledger["gaussian_read_bits"] = 0
                getattr(line, name)([(0, 0)]*s)
                moved = ledger["gaussian_head_move_bits"]+ledger["gaussian_read_bits"]
                self.assertLessEqual(moved, 128*size*(radius+1)*2*a.component_bits)
                COUNTS["fast_gaussian_head_bound_controls"] += 1


class FastReductionTests(unittest.TestCase):
    def test_ring_convolution_and_norm_checks(self):
        rng = random.Random(44192)
        p, arithmetic, ledger = 32, FastArithmetic(mul), Counter()
        for r in (2, 4, 8, 16):
            f, g = [[(rng.randrange(-(1 << 27), 1 << 27), rng.randrange(-(1 << 27), 1 << 27))
                     for _ in range(r)] for _ in range(2)]
            self.assertEqual(fast_ring_product(f, g, p, arithmetic, ledger), normalized_ring_product(f, g, p))
            COUNTS["fast_ring_product_comparisons"] += 1
        for axes, r in (((4,), 4), ((2, 4), 4)):
            layout = Layout(axes, r)
            f, g = [[[(rng.randrange(1 << 25), -rng.randrange(1 << 25)) for _ in range(r)]
                     for _ in range(layout.size)] for _ in range(2)]
            self.assertEqual(fast_convolution(f, g, layout, p, arithmetic, ledger, direct_layer, None),
                             normalized_convolution(f, g, layout, p))
            COUNTS["fast_synthetic_convolution_comparisons"] += 1
        self.assertFalse(check_norm([(1 << p, 0)], p, arithmetic, 7, 10, reject=False))

    def test_cyclic_and_chirp_exact_reference(self):
        p = 96
        for sources, targets in (((3,), (4,)), ((3, 5), (4, 8))):
            fast = FastCyclicConvolver(targets, p, integer_multiply=mul)
            reference = CyclicConvolver(targets, p)
            reference.phase = FastCertifiedPhase(integer_multiply=mul)
            values = [((j % 7-3) << (p-6), (j % 5-2) << (p-6)) for j in range(fast.T)]
            self.assertEqual(fast.convolve(values, values), reference.convolve(values, values))
            self.assertEqual(fast.chirp(values, sources), reference.chirp(values, sources))
            COUNTS["fast_cyclic_and_chirp_comparisons"] += 2

    def test_complete_native_control_products(self):
        for x, y in ((0, 0xffffffff), (0xdeadbeef, 0xfedcba98)):
            ledger = Counter()
            value, diagnostics = multiply_fast_finite(x, y, sources=(3, 5), targets=(4, 8),
                p=192, alpha=6, digit_bits=4, circuit=CompiledBitCircuit(SwapControl()),
                integer_multiply=mul, ledger=ledger)
            self.assertEqual(value, x*y)
            self.assertTrue(diagnostics["implementation_status"]["global_audit_enabled"])
            self.assertEqual(ledger["gaussian_weight_tapes_built"], 6)
            self.assertEqual(ledger.get("exp_taylor_terms", 0), 0)
            COUNTS["resampled_fast_arithmetic_control_products"] += 1

    def test_complete_recursive_product(self):
        # No native integer backend is injected: all growing numerical products
        # use the recursive backend, including weight construction and norms.
        x, y = 0xdeadbeef, 0xfedcba98
        value, diagnostics = multiply_fast_finite(x, y, sources=(3,), targets=(4,),
            p=128, alpha=5, digit_bits=16, circuit=CompiledBitCircuit(SwapControl()))
        self.assertEqual(value, x*y)
        self.assertEqual(diagnostics["ledger"], {})
        self.assertEqual(diagnostics["implementation_status"]["integer_backend"], "RecursiveFermatMultiplier")
        self.assertFalse(diagnostics["implementation_status"]["sub_n_log_n_proved_for_implementation"])
        COUNTS["resampled_full_recursive_arithmetic_products"] += 1

    def test_invalid_inputs(self):
        arithmetic = FastArithmetic(mul)
        line = FastGaussianLine(GaussianParameters(3, 4, 101, 5), integer_multiply=mul)
        invalid = [lambda: line.expand([(0, 0)]), lambda: line._weights("bad"),
                   lambda: line.diagonal([(1 << 102, 0)]*3),
                   lambda: ResidueTape([1], 1, Counter()).read(1),
                   lambda: check_norm([(1 << 33, 0)], 32, arithmetic),
                   lambda: check_norm([(1,)], 32, arithmetic),
                   lambda: FastCyclicConvolver((4,), 32, integer_multiply=mul).chirp([(0, 0)]*4, ())]
        for call in invalid:
            with self.assertRaises(ValueError): call()
            COUNTS["negative_controls"] += 1


if __name__ == "__main__": unittest.main()
