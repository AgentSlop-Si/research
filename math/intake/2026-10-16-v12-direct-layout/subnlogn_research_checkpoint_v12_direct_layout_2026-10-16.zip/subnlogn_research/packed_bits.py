"""Executable address semantics of section 05's packed selected-bit addition.

Eight controlled rotations, followed by deterministic exceptional-address
repair, implement simultaneous XOR while restoring the third chunk.
This implements the address maps, NOT their asymptotically fast tape schedule.
"""
from dataclasses import dataclass
from fractions import Fraction


@dataclass(frozen=True)
class PackedBits:
    k: int
    fields: int
    offset: int = 0

    def __post_init__(self):
        if self.k < 6 or self.fields < 1 or not 0 <= self.offset < self.k:
            raise ValueError("require K >= 6, f >= 1, 0 <= rho < K")

    @property
    def width(self): return self.k*self.fields
    @property
    def mask(self): return (1 << self.width)-1
    @property
    def selected(self): return sum(1 << (self.offset+i*self.k) for i in range(self.fields-1))
    @property
    def top(self): return 1 << (self.offset+(self.fields-1)*self.k)
    @property
    def bad_fraction_bound(self): return min(Fraction(1), Fraction(80*(self.fields-1), 1 << self.k))
    @property
    def exact_bad_fraction(self):
        return 1-(1-Fraction(20, 1 << (self.k-1)))**(2*(self.fields-1))

    def validate(self, address):
        if len(address) != 3 or any(not 0 <= value <= self.mask for value in address):
            raise ValueError("address outside complete chunk range")

    def bad(self, address):
        self.validate(address)
        _, y, z = address
        guard_mask = (1 << (self.k-1))-1
        return any(not 10 <= ((chunk >> (self.offset+i*self.k+1)) & guard_mask) <= guard_mask-10
                   for chunk in (y, z) for i in range(self.fields-1))

    def rotations(self, address, inverse=False):
        self.validate(address)
        x, y, z = address
        # target, other-control parity, direction, in chronological order.
        schedule = (("y", 0, -1), ("z", 0, -1), ("y", 0, 1), ("z", 0, 1),
                    ("z", 1, 1), ("y", 1, 1), ("z", 1, -1), ("y", 1, -1))
        if inverse: schedule = tuple((target, parity, -sign) for target, parity, sign in reversed(schedule))
        selected, mask = self.selected, self.mask
        for target, parity, sign in schedule:
            other = z if target == "y" else y
            amount = x & (other if parity else ~other) & selected
            if target == "y": y = (y+sign*amount) & mask
            else: z = (z+sign*amount) & mask
        return x, y, z

    def ideal(self, address, include_top=True):
        self.validate(address)
        x, y, z = address
        return x, y ^ (x & (self.selected | (self.top if include_top else 0))), z

    def repair_destination(self, current_address):
        """Destination under T0 S0^-1. Only exceptional records need moving."""
        if not self.bad(current_address): return tuple(current_address)
        original = self.rotations(current_address, inverse=True)
        return self.ideal(original, include_top=False)

    def apply(self, address):
        x, y, z = self.repair_destination(self.rotations(address))
        return x, y ^ (x & self.top), z


def stable_radix_records(records, key_bits):
    """Sort (nonnegative destination rank, payload) pairs by stable bit passes."""
    out = list(records)
    if key_bits < 0 or any(key < 0 or key.bit_length() > key_bits for key, _ in out):
        raise ValueError("key outside fixed rank width")
    for bit in range(key_bits):
        zero, one = [], []
        for record in out:
            (one if (record[0] >> bit) & 1 else zero).append(record)
        out = zero+one
    return out


def repair_sparse_stream(records, spec):
    """Test/execution adapter for a finite sorted address stream.

    Accepts complete rectangles or any finite subset invariant under the repair
    permutation. Extracts only exceptional records, radix-sorts their destination
    ranks, and reinserts into holes. No sort of the full stream is performed.
    This list-backed adapter is not a fixed-tape complexity implementation.
    """
    def rank(a): return (a[0] << (2*spec.width)) | (a[1] << spec.width) | a[2]
    records = list(records)
    ranks = [rank(a) for a, _ in records]
    if any(a >= b for a, b in zip(ranks, ranks[1:])):
        raise ValueError("stream must have distinct addresses in ascending rank order")
    exceptional, hole_ranks = [], []
    for address, payload in records:
        spec.validate(address)
        if spec.bad(address):
            exceptional.append((rank(spec.repair_destination(address)), payload))
            hole_ranks.append(rank(address))
    sorted_bank = stable_radix_records(exceptional, 3*spec.width)
    if [key for key, _ in sorted_bank] != hole_ranks:
        raise ValueError("address set not invariant under exceptional repair")
    it = iter(sorted_bank)
    out = [(address, next(it)[1] if spec.bad(address) else payload) for address, payload in records]
    return out, {"records": len(records), "exceptional_records": len(exceptional),
                 "radix_passes": 3*spec.width if exceptional else 0}
