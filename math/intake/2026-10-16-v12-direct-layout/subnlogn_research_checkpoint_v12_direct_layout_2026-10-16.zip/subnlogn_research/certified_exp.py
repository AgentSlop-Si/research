"""Certified exp(pi*a/b)/2**shift on a dyadic grid, using integers only.

This auditable scalar backend uses outward-rounded Taylor intervals and a
Machin pi interval. It is NOT the fast scalar backend in the asymptotic paper.
No float, Decimal, transcendental library, or guessed guard accuracy is used.
"""
from collections import Counter
from dataclasses import dataclass


def ceil_div(a, b):
    return -(-a//b)


def pi_interval(bits, ledger=None):
    """Integer endpoints with denominator 2**bits, enclosing pi strictly."""
    if bits < 4:
        raise ValueError("at least four interval bits required")
    ledger = ledger if ledger is not None else Counter()
    scale = 1 << bits

    def atan(d):
        low = high = j = 0
        power = d
        while True:
            denominator = (2*j+1)*power
            if denominator > scale:
                # The alternating remainder has the next term's sign and
                # magnitude strictly below one interval unit.
                if j % 2: low -= 1
                else: high += 1
                return low, high
            floor = scale//denominator
            ceil = ceil_div(scale, denominator)
            if j % 2:
                low -= ceil
                high -= floor
            else:
                low += floor
                high += ceil
            ledger["pi_series_terms"] += 1
            power *= d*d
            j += 1

    a, b = atan(5), atan(239)
    ledger["pi_interval_calls"] += 1
    return 16*a[0]-4*b[1], 16*a[1]-4*b[0]


@dataclass(frozen=True)
class ExpCertificate:
    value: int
    p: int
    lower: int
    upper: int
    interval_bits: int
    method: str

    def verify_grid_error(self):
        """Check the arithmetic certificate, not the transcendental lemma."""
        scale = 1 << (self.interval_bits-self.p)
        return (0 <= self.value <= (1 << self.p)
                and 0 <= self.lower <= self.upper
                and self.value*scale <= self.lower
                and self.upper-self.value*scale < 2*scale)


class CertifiedExp:
    """Explicit per-context pi cache; parameter/setup work is recorded."""
    def __init__(self, ledger=None):
        self.ledger = ledger if ledger is not None else Counter()
        self.pi_cache = {}

    def _positive_exp(self, low, high, bits):
        scale = 1 << bits
        squarings = 0
        while 8*high > scale << squarings:
            squarings += 1
        low //= 1 << squarings
        high = ceil_div(high, 1 << squarings)
        # Range reduction can enlarge the upper endpoint by one grid unit.
        # high/scale <= 1/4 (bits>=4), so a geometric tail bound suffices.
        if 4*high > scale:
            raise AssertionError("Taylor range reduction")
        term_low = term_high = total_low = total_high = scale
        j = 0
        while True:
            j += 1
            term_low = term_low*low//(scale*j)
            term_high = ceil_div(term_high*high, scale*j)
            total_low += term_low
            total_high += term_high
            self.ledger["exp_taylor_terms"] += 1
            if term_high <= 1:
                # All uncomputed terms total less than one interval unit,
                # because subsequent term ratios are <=1/4.
                total_high += 1
                break
        for _ in range(squarings):
            total_low = total_low*total_low//scale
            total_high = ceil_div(total_high*total_high, scale)
            self.ledger["exp_interval_squarings"] += 1
        return total_low, total_high

    def grid(self, numerator, denominator, p, *, shift=0):
        """Return a nonnegative disk coefficient and a <2-grid-unit enclosure.

        Requires the real target exp(pi*numerator/denominator)/2**shift
        to lie in [0,1]. Invalid targets are rejected, not clipped.
        """
        if (any(type(v) is not int for v in (numerator, denominator, p, shift))
                or denominator <= 0 or p < 2 or shift < 0):
            raise ValueError("invalid exponential arguments")
        self.ledger["certified_exp_calls"] += 1
        if numerator == 0:
            bits = max(p, shift)
            exact = 1 << (bits-shift)
            result = ExpCertificate((1 << p) >> shift, p, exact, exact,
                                    bits, "exact power of two")
        elif numerator < 0 and -numerator >= p*denominator:
            # pi>1 and e>2 imply exp(-pi*p)<2**(-p).
            result = ExpCertificate(0, p, 0, 1, p, "analytic underflow bound")
            self.ledger["exp_underflow_bounds"] += 1
        else:
            bits = p+shift+(abs(numerator)+denominator).bit_length()+16
            while True:
                if bits not in self.pi_cache:
                    self.pi_cache[bits] = pi_interval(bits, self.ledger)
                lo_pi, hi_pi = self.pi_cache[bits]
                magnitude = abs(numerator)
                low = lo_pi*magnitude//denominator
                high = ceil_div(hi_pi*magnitude, denominator)
                low, high = self._positive_exp(low, high, bits)
                scale = 1 << bits
                if numerator < 0:
                    low, high = scale*scale//high, ceil_div(scale*scale, low)
                low //= 1 << shift
                high = ceil_div(high, 1 << shift)
                if low > scale:
                    raise ValueError("exponential target exceeds the unit interval")
                value = low >> (bits-p)
                result = ExpCertificate(value, p, low, high, bits,
                                        "outward integer Taylor interval")
                self.ledger["exp_peak_interval_bits"] = max(
                    self.ledger["exp_peak_interval_bits"], bits)
                if high <= scale and result.verify_grid_error():
                    break
                bits *= 2
                self.ledger["exp_interval_refinements"] += 1
        if not result.verify_grid_error():
            raise AssertionError("exponential grid certificate")
        return result
