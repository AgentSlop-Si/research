"""Fast-arithmetic Gaussian maps with sequential parameter-only weight tapes.

Native arithmetic is confined to parameter/line setup and small descriptors.
Every growing per-coefficient product uses FastArithmetic. Default diagnostics
are disabled. This component does not complete the entire fast multiplication proof.
"""
from itertools import product
from math import prod

from fast_scalar import FastArithmetic, FastCertifiedExp
from fermat_recursive import NullLedger
from gaussian_resampling import GaussianLine
from gaussian_tensor import GaussianTensor
from stream_moves import Reader, emit
from synthetic import trunc_shift


def disk_check(z, p, arithmetic):
    if (not isinstance(z, (tuple, list)) or len(z) != 2
            or any(type(v) is not int for v in z)
            or arithmetic.mul(z[0], z[0])+arithmetic.mul(z[1], z[1]) > 1 << (2*p)):
        raise ValueError("disk-grid Gaussian pair required")


class ResidueTape:
    """Move the logical head before each read; no native modular division."""
    def __init__(self, values, width, ledger):
        self.values, self.width, self.ledger = values, width, ledger
        self.head = 0

    def read(self, residue):
        if not 0 <= residue < len(self.values): raise ValueError("canonical tape residue required")
        while self.head != residue:
            self.head += 1 if self.head < residue else -1
            self.ledger["gaussian_head_move_bits"] += self.width
        value = self.values[self.head]
        self.head += 1
        self.ledger["gaussian_read_bits"] += self.width
        return value


class FastGaussianLine(GaussianLine):
    CACHE_CAPACITY = 256  # Absolute constant; linear search, not assumed O(1) hashing.

    def __init__(self, parameters, *, ledger=None, integer_multiply=None):
        self.parameters = parameters
        self.ledger = ledger if ledger is not None else NullLedger()
        self.arithmetic = FastArithmetic(integer_multiply, self.ledger)
        self.exponential = FastCertifiedExp(self.ledger,
            integer_multiply=self.arithmetic.integer_multiply)
        a, op = parameters, self.arithmetic
        # Polynomial-time setup is performed once per line context, not per term.
        self.alpha2 = a.alpha*a.alpha
        self.s2 = op.mul(a.s, a.s)
        self.expansion_denominator = op.mul(self.alpha2, op.mul(a.t, a.t))
        self.expansion_radius = a.expansion_radius
        self.correction_radius = a.correction_radius
        self.selector_quotient, self.residue_step = op.divmod(a.t, a.s)
        self.expansion_beta = op.floor(1 << a.p, 2*a.alpha)
        self.weight_tapes = {}
        self.exp_cache = []

    def _check(self, values, size):
        if len(values) != size: raise ValueError("Gaussian line length mismatch")
        for z in values: disk_check(z, self.parameters.p, self.arithmetic)
        self.ledger["gaussian_disk_checks"] += size

    def _multiply_real(self, x, z):
        self.ledger["gaussian_scalar_integer_products"] += 2
        return tuple(trunc_shift(self.arithmetic.mul(x, v), self.parameters.p) for v in z)

    def _exponential_value(self, numerator, denominator, shift=0):
        key = (numerator, denominator, shift)
        for stored_key, value in self.exp_cache:
            self.ledger["gaussian_fixed_cache_comparisons"] += 1
            if key == stored_key:
                self.ledger["gaussian_fixed_cache_hits"] += 1
                return value
        value = self.exponential.grid(numerator, denominator, self.parameters.p, shift=shift).value
        if len(self.exp_cache) == self.CACHE_CAPACITY: self.exp_cache.pop(0)
        self.exp_cache.append((key, value))
        return value

    def _expansion_rows(self):
        a, radius = self.parameters, self.expansion_radius
        quotient = remainder = 0
        for _ in range(a.t):
            # floor(s*k/t)-radius < j < ceil(s*k/t)+radius, both strict ends.
            yield quotient-radius+1, quotient+radius+bool(remainder), remainder
            remainder += a.s
            if remainder >= a.t:
                remainder -= a.t
                quotient += 1

    def _betas(self):
        residue, a = 0, self.parameters
        for _ in range(a.s):
            yield residue, residue-a.s if 2*residue >= a.s else residue
            residue += self.residue_step
            if residue >= a.s: residue -= a.s

    def _weights(self, kind):
        """Three append-only p+2-bit tapes, independent of numerical operands."""
        if kind in self.weight_tapes: return self.weight_tapes[kind]
        a, op, values = self.parameters, self.arithmetic, []
        def append(value):
            if not 0 <= value <= 1 << a.p: raise ArithmeticError("Gaussian weight format")
            emit(values, value, self.ledger, a.component_bits)
        if kind == "A":
            edge = op.mul(1-self.expansion_radius, a.t)
            for start, stop, remainder in self._expansion_rows():
                difference = edge-remainder
                for _ in range(start, stop):
                    x = self._exponential_value(-op.mul(difference, difference), self.expansion_denominator)
                    append(trunc_shift(op.mul(self.expansion_beta, x), a.p))
                    difference += a.t
        elif kind == "E":
            radius = self.correction_radius
            edge = -op.mul(radius, a.t)
            for residue, beta in self._betas():
                other_residue = op.divmod(residue+edge, a.s)[1]
                difference = edge+beta
                for h in range(-radius, radius+1):
                    if h:
                        other = other_residue-a.s if 2*other_residue >= a.s else other_residue
                        numerator = op.mul(self.alpha2,
                            op.mul(difference, difference)-op.mul(other, other))
                        if numerator <= 0: raise ArithmeticError("off-diagonal Gaussian exponent")
                        append(self._exponential_value(-numerator, self.s2))
                    difference += a.t
                    other_residue += self.residue_step
                    if other_residue >= a.s: other_residue -= a.s
        elif kind == "D":
            for _, beta in self._betas():
                append(self._exponential_value(op.mul(self.alpha2, op.mul(beta, beta)),
                                                self.s2, a.gamma-2))
        else: raise ValueError("unknown Gaussian weight tape")
        self.weight_tapes[kind] = values
        self.ledger["gaussian_weight_tapes_built"] += 1
        self.ledger["gaussian_weight_records"] += len(values)
        return values

    def expand(self, values):
        a, op = self.parameters, self.arithmetic
        self._check(values, a.s)
        weights = Reader(self._weights("A"), self.ledger, a.component_bits)
        tape = ResidueTape(values, 2*a.component_bits, self.ledger)
        out = []
        for start, stop, _ in self._expansion_rows():
            residue = op.divmod(start, a.s)[1]
            total = (0, 0)
            for _ in range(start, stop):
                total = self._sum(total, self._multiply_real(weights.take(), tape.read(residue)))
                residue += 1
                if residue == a.s: residue = 0
                self.ledger["gaussian_expansion_terms"] += 1
            out.append(total)
        weights.finish()
        self.ledger["gaussian_A_calls"] += 1
        return self._output(out, a.t)

    def correction(self, values):
        a, op, radius = self.parameters, self.arithmetic, self.correction_radius
        self._check(values, a.s)
        weights = Reader(self._weights("E"), self.ledger, a.component_bits)
        tape = ResidueTape(values, 2*a.component_bits, self.ledger)
        out = []
        for j in range(a.s):
            residue = op.divmod(j-radius, a.s)[1]
            total = (0, 0)
            for h in range(-radius, radius+1):
                if h:
                    total = self._sum(total, self._multiply_real(weights.take(), tape.read(residue)))
                    self.ledger["gaussian_correction_terms"] += 1
                residue += 1
                if residue == a.s: residue = 0
            out.append(total)
        weights.finish()
        self.ledger["gaussian_E_calls"] += 1
        return self._output(out, a.s)

    def diagonal(self, values):
        a = self.parameters
        self._check(values, a.s)
        weights = Reader(self._weights("D"), self.ledger, a.component_bits)
        out = [self._multiply_real(weights.take(), z) for z in values]
        weights.finish()
        self.ledger["gaussian_D_calls"] += 1
        return self._output(out, a.s)

    def select(self, values):
        a = self.parameters
        self._check(values, a.t)
        quotient = remainder = 0
        target, selected, out = 0, 0, []
        for k, value in enumerate(values):
            self.ledger["gaussian_selection_read_bits"] += 2*a.component_bits
            if selected < a.s and k == target:
                out.append(value)
                selected += 1
                quotient += self.selector_quotient
                remainder += self.residue_step
                if remainder >= a.s:
                    quotient += 1
                    remainder -= a.s
                target = quotient+(2*remainder >= a.s)
        if selected != a.s: raise ArithmeticError("ordered selector failed")
        self.ledger["gaussian_C_calls"] += 1
        return self._output(out, a.s)


class FastGaussianTensor(GaussianTensor):
    def __init__(self, sources, targets, p, alpha, circuit, *, ledger=None, integer_multiply=None):
        ledger = ledger if ledger is not None else NullLedger()
        super().__init__(sources, targets, p, alpha, circuit, ledger=ledger)
        self.arithmetic = FastArithmetic(integer_multiply, ledger)
        self.lines = tuple(FastGaussianLine(a, ledger=ledger,
            integer_multiply=self.arithmetic.integer_multiply) for a in self.parameters)

    def _check_box(self, values, valid):
        if len(values) != prod(self.targets): raise ValueError("incomplete padded box")
        for coordinates, z in zip(product(*(range(t) for t in self.targets)), values):
            disk_check(z, self.p, self.arithmetic)
            if any(j >= n for j, n in zip(coordinates, valid)) and tuple(z) != (0, 0):
                raise ValueError("nonzero invalid padding")
