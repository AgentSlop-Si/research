# v11 attribution and limits

The inherited NOTICE.txt and SOURCE_LICENSE.txt apply to their original
material and are retained byte-for-byte. No claim of author endorsement is made.

New local work: packed_gaussian_v11.py; explicit injection hooks in
fast_resampled.py; exact tighter-log certificate; scoped parameter-ceiling proof;
independent tests; regression and timing harnesses; audit and reproducibility
records. Gauss/Karatsuba three-product multiplication and Kronecker substitution
are standard identities and are not claimed as novel. No novelty or priority
claim is made for the narrower packing bound or parameter choice.

The OpenAI September 2026 network and analytic framework remains the mathematical
source already adopted by the supplied checkpoints. The CrocSwap community
result is a comparison only: no implementation or construction from that
repository was adopted by v11. The inherited archival notices contain historical
claims that are separated from fresh checks in AUDIT_V11.md.

Local work was generated and checked with AI assistance in this conversation.
Exact finite tests and rational inequalities are not complete formal verification
of a multiplication theorem. No new general-DFT bound is claimed.
