# Audit and enhancement: checkpoint v11

**Date:** 15 October 2026  
**Decision:** No independently established, end-to-end sub-N-log-N multiplier in the supplied implementation. There is a conditional exponent certificate and a substantial collection of verified finite components. This audit strengthens the certificate and adds exact opt-in packing kernels, without changing that overall status.

## 1. What “beat N log N” means here

In these ten archives, **N is the bit length of each integer**, not a matrix side length, the number of coefficients, or an arbitrary complex DFT length. The requested output is the complete exact product of arbitrary inputs. Setup, base conversion, coefficient precision, recursive products, movement, temporary storage restoration, reconstruction and output must be charged in the same bit model.

For a fixed positive kappa, the expression

    N (log N)^(1-kappa)

really is little-o of N log N, because their ratio is (log N)^(-kappa), which tends to zero. The disputed step is not this elementary limit. It is whether a complete specified algorithm satisfies this bound, with its required operations implemented or justified uniformly and all costs included.

A mathematical algorithm does not need a practical implementation to be a valid theorem. Conversely, an implementation passing many tests is not a proof of its asymptotic complexity. The gap here is the audited transfer from local identities and parameter inequalities to one all-size machine, not simply the absence of an astronomical benchmark.

The original Mersenne/base-matrix trial is described in the inherited audit as retaining Theta(N) stored bits over Theta(log N) transform stages. That gives Theta(N log N) work for that schedule. Its original source is not included among these ten checkpoints, so that description is an inherited result, not a fresh rerun of the original trial. No new arbitrary-input sub-N-log-N DFT is established here.

## 2. What was inspected and rerun

All ten uploaded ZIPs were enumerated, hashed and safely extracted. Their version deltas were compared; v10 is cumulative and contains 80 files. The detailed input hashes and per-file differences are retained in `input_manifest.json` and `version_deltas.json`.

| Version | Files | Added | Changed | Removed |
|---|---:|---:|---:|---:|
| v1 | 21 | 21 | 0 | 0 |
| v2 | 29 | 8 | 5 | 0 |
| v3 | 35 | 6 | 5 | 0 |
| v4 | 39 | 4 | 10 | 0 |
| v5 | 46 | 7 | 9 | 0 |
| v6 | 53 | 7 | 6 | 0 |
| v7 | 61 | 8 | 6 | 0 |
| v8 | 68 | 7 | 6 | 0 |
| v9 | 74 | 6 | 11 | 0 |
| v10 | 80 | 6 | 13 | 0 |

The earliest checkpoints contain exact motifs, rank budgets, signed packing and synthetic controls. Later versions add finite network compilation, recursive controls, sequential movement, common precision guards, Gaussian resampling, the CRT/chirp/recovery reduction, recursive Fermat arithmetic, and certified fast scalar routines. This is real implementation progress, not ten separately completed asymptotic proofs.

### Fresh validation evidence

| Evidence | Result | Scope |
|---|---|---|
| Original v10 full test suite | 137 methods passed | Original, unchanged v10 sources; includes one full finite recursive-arithmetic product |
| New v11 suite | 8 methods passed | 21,177 exact kernel comparisons, normalization and integration checks |
| v11 default-hook regression | 10 methods passed | Inherited Gaussian tests except the costly full recursive product |
| Timed benchmark calls | 198 exact answers checked | Kernel timings and explicit native full-reduction controls |

The original v10 suite took 539.321 seconds in this run. That is suite duration, not a product-time benchmark. Its recorded source hashes remained unchanged. The new suite separately records 6,561 distinct exhaustive input pairs, 192 adversarial pairs, 300 random pairs, six recursive-backend pairs, 900 normalized comparisons, 300 v10 reference comparisons, 12 chirp/cyclic and three synthetic integration comparisons, seven rejection controls, and four complete native control products. Counts overlap by design; they must not be added as though every category contained new independent inputs.

The 21,177 kernel comparisons are 7,059 comparisons for each of three variants. Recursive-backend cases include genuine internal Fermat recursion and use an independent schoolbook coefficient oracle. Full v11 default-recursive multiplication was **not** rerun; the full recursive case was rerun on original v10. Complete v11 control products explicitly used native integer arithmetic and small no-saving control circuits. This distinction is retained rather than hidden.

Evidence files: `validation_v10_rerun.json`, `validation_v11.json`, `regression_v11.json`, and `evidence/`. The inherited `validation.json` is historical v10 evidence, not a new v11 run.

## 3. Enhancement A: exact, narrower three-product packing

Write the Gaussian polynomials as f=A+iB and g=C+iD. The v10 kernel packs four real polynomials and makes four large products, AC, BD, AD and BC, using signed lanes of width 4p.

The new `three` kernel computes

    U = AC
    V = BD
    W = (A+B)(C+D)
    fg = (U-V) + i(W-U-V).

These are the standard Gauss/Karatsuba identities, not a newly discovered algebraic multiplication formula. The contribution is safe integration with this checkpoint's signed representation, input norm checks, injected backend, coefficient bounds, negacyclic folding and exact truncation.

For r=2^ell and the inherited coefficient disk bound, the new lane width is

    w = 2p + ell + 3.

Each input coefficient has magnitude at most Q=2^p. An AC or BD coefficient is bounded by rQ^2. By Cauchy-Schwarz, each coefficient of (A+B)(C+D) is bounded by 2rQ^2. Since the signed radix R=2^w has R/2=4rQ^2, every decoded coefficient is strictly inside the centered interval. This covers negative, extremal and adversarial inputs, not only cancellation-friendly data.

After exact ordinary coefficient extraction, the kernel subtracts coefficient j+r from j, then applies exactly the old signed truncation. Therefore its finite output is bit-for-bit identical to the old normalized ring product. Numerical error bounds are not replaced with informal “close enough” checks.

At p=128 and r=32, the lane width falls from 512 to 264 bits. The large-product count falls from four to three. The summed upper operand-bit budget is 38.671875% of the old budget; that percentage is **not** a runtime guarantee.

### Two controls prevent misleading product-count claims

`four_narrow` retains four products at the new width. It isolates the gain from a smaller radix. The `one` variant packs

    F(X)=A(X^3)+X B(X^3),   G(X)=C(X^3)+X D(X^3)

so that one product has separate coefficient classes for AC, AD+BC, and BD. Its operands can have 3rw bits, instead of rw for the three-product variant. One product is not automatically cheaper than three smaller ones. This is standard Kronecker substitution, not a priority claim.

For an explicitly sequential block implementation, let M(t) denote the actual supplied integer multiplier's cost, and retain C_norm=O(r M(O(p))) for the input checks. The component accounting is

    old:   C_norm + 4 M(4pr) + O(pr)
    three: C_norm + 3 M(rw)  + O(rw)
    one:   C_norm +   M(3rw) + O(rw).

Packing, decoding, signed sums, reconstruction and formatting are included in these component expressions. They are not a proof of the whole Python interpreter's fixed-tape cost. No free giant-word multiplication is introduced.

See `PACKING_PROOF_V11.md` for the proof and `packed_gaussian_v11.py` for the implementation. The only edited inherited file is `fast_resampled.py`, adding backward-compatible explicit injection hooks. Its default kernel remains unchanged. The patch is retained in `evidence/v10_to_v11_hooks.patch`.

## 4. What the timings actually show

These are local Python 3.13.5 measurements, not complexity estimates. Each kernel shape used three independently generated full-width signed input pairs. Variants were interleaved in randomized order, with nine native samples or three recursive-backend samples per variant. Timers included arithmetic-context creation, norm checks, packing, backend products, extraction and rounding. Independent expected answers were calculated outside the timer; global diagnostic counters were disabled during timings. Raw samples and separate operand-size audits are retained.

| Backend | p | r | v10 median, ms | Three median, ms | Three speedup | One speedup |
|---|---:|---:|---:|---:|---:|---:|
| native | 32 | 8 | 0.0972 | 0.0914 | 1.063x | 1.066x |
| native | 128 | 32 | 0.7367 | 0.4396 | 1.676x | 1.443x |
| native | 256 | 128 | 14.8002 | 5.3280 | 2.778x | 2.134x |
| native | 512 | 256 | 94.7040 | 27.8086 | 3.406x | 1.984x |
| recursive | 32 | 8 | 6.5512 | 5.2034 | 1.259x | 0.963x |
| recursive | 64 | 8 | 26.1330 | 5.3186 | 4.913x | 0.936x |
| recursive | 128 | 32 | 831.1556 | 652.4088 | 1.274x | 1.907x |

The sharp recursive gain at p=64,r=8 crosses the backend's fixed schoolbook threshold: audited packed operands fall from about 1,855 bits to about 1,001 bits, below the 1,024-bit leaf threshold. It must not be extrapolated as a uniform 4.91x speedup. At p=128,r=32, the one-product alternative wins over the three-product kernel for this particular recursive backend; with the native backend, the three-product kernel wins. Keep both choices explicit.

### Complete finite reduction, native controls

Every row below multiplies the same nonzero 32-bit operands. Each variant had three cold calls, including circuit construction and the complete Gaussian/CRT/recovery profile. These use native integer arithmetic deliberately; they do not benchmark a new sub-N-log-N multiplier.

| Control shape | v10, ms | Three, ms | One, ms | Three speedup |
|---|---:|---:|---:|---:|
| one_axis | 319.845 | 315.832 | 320.897 | 1.0127x |
| two_axes | 2816.194 | 2801.073 | 2818.780 | 1.0054x |

The measured whole-profile changes are only about 0.5–1.3%, with overlapping individual timing ranges. This is insufficient to establish a reliable full-product improvement. The defensible claim is an exact optimized component with measured component gains, **not** a 3x or 5x faster whole multiplier. Source: `packing_benchmarks_v11.json`.

## 5. Enhancement B: a 3.0338x stronger conditional exponent certificate

The v10 h=100 network calculation used the valid but loose bound ln(100^3)<20. Replace 20 with the rational

    L = 13815511/1000000 = 13.815511.

The program verifies the exact rational inequality

    sum_{j=0}^{99} L^j/j! > 1000000.

Since the omitted terms are positive, ln(1000000)<L follows without a rounded logarithm. Keeping the same exact rank deficits, set a=eta_bit/L and use the unchanged parameter family. Its exponent saving simplifies to

    kappa = a^3(1-2a)/4.

All 17 named checks, including the seven cost margins, pass with exact fractions. The results are

    v10: kappa approximately 1.0564626242044788e-37
    v11: kappa approximately 3.205112405573184e-37
    ratio: approximately 3.033815235997249.

This strengthens a feasible-parameter certificate under the same source assumptions. It is not a 3.03x runtime speedup and not an independent multiplication theorem. The v11 packing optimization and this inequality refinement are separate improvements; their gains must not be multiplied together as performance factors.

The necessary cutoff remains extraordinary: with b=ceil(log2 N), d=floor(b^epsilon), and K=floor(d^c), even K>=2 requires log2(b)>=1/(epsilon*c), approximately 1.6947e24 for the new parameters. This is necessary, not sufficient. It explains why small exact experiments cannot demonstrate the asymptotic saving.

See `parameter_certificate_v11.py`, `parameter_certificate_v11.json`, and `PARAMETER_CEILING_V11.md`.

## 6. A useful stop rule for ineffective parameter tuning

Fix the existing bit exponent tau=1-a, beta=1/2, and retain the current cost constraints. Then

    tau(1+2c)<lambda<1        implies c<a/[2(1-a)]
    epsilon(2-tau)<1-tau     implies epsilon<a/(1+a)
    2kappa<=epsilon*c*a      implies kappa<a^3/[4(1-a^2)].

The old feasible choice already achieves the fraction (1-2a)(1-a^2) of this restricted ceiling. Its remaining relative room is about 1.50084e-12. Retuning epsilon and c without changing these bottlenecks cannot yield a material improvement. Tightening the logarithm changes a, so it is not in conflict with this ceiling.

This is a ceiling for one specific parameter family and set of cost constraints. It is not a lower bound for integer multiplication, not a universal network optimum, and not a reason to abandon the broader research.

## 7. Comparison and attribution, pinned to 15 October 2026

The peer-reviewed Harvey–van der Hoeven paper (Annals, 2021) gives O(N log N). It is a reliable published historical baseline, but must not be described as the latest source in October 2026.

The supplied construction borrows the networks, Gaussian/synthetic-transform reduction and assembly from OpenAI's September 23, 2026 preprint, pinned here at `1581d4cbdd69a0faf34b2089614fe2a814316a6a`. Its introduction states a fixed-multitape theorem with kappa=2^-182. The primary source was read, but this audit does not independently verify its entire proof. The archived per-file source manifest is retained; its historical remote hashes were not all re-fetched in this audit.

For a stronger conditional comparison, the CrocSwap/integer-mult-bounds README at commit `b4560d9e7216f72b73c5aa940ac099c05e33ccf9` (15 October 2026, 16:31:36 UTC) reports a selected, maintainer-reviewed witness from Rohan Arun's PR #1094:

    kappa = 836330098538459 / 500000000000000000
          = 0.001672660197076918.

This is vastly larger than our new 3.2051e-37. It is also explicitly conditional on all-size/compiler, common-label/mutable-source realization, hosting, precision/tape, recovery and analytic interfaces. It is not a complete formalized multiplication theorem or a practical runtime benchmark. We have verified what the source reports, not independently replayed and proved its full construction.

Consequently the checkpoint does **not** beat the strongest comparable conditional exponent found in this audit. No exhaustive worldwide priority search or “world record” claim is made. No community-repository algorithm was imported and relabeled as our enhancement. The core asymptotic route was already borrowed in the user's uploads; the local v11 work consists of exact parameter refinement, packing integration, proofs and reproducible tests.

Primary references and exact revision metadata are recorded in `external_baselines_v11.json`. The inherited `NOTICE.txt` and `SOURCE_LICENSE.txt` remain unchanged.

## 8. What still blocks the full claim

The blockers are concrete. A uniform specification and proof must cover automatic all-size parameter/prime/cutoff choices; the actual rank-saving address and numerical layer implementations; bounded coefficient formats and guard growth; all packing and recursive arithmetic; and finite-alphabet descriptor, counter, parking, cache and head-movement costs through exact output.

The current recursive Fermat backend has its own documented O(N log N log log N) component recurrence. Using that backend for smaller operands is not automatically fatal to a faster outer reduction: it may be absorbed by slack in a correct full recurrence. But those costs still need to be assembled for the implemented algorithm. A component recurrence is not the final claimed bound.

The tests exercise actual small h=100 branches and small, explicitly separate no-saving control circuits, not the enormous full rank-saving recursion. Running the full h=100 construction is not logically necessary if a rigorous uniform proof covers it. Neither that proof transfer nor a complete fully charged execution audit is supplied by passing finite tests alone.

For progress on the user's base/matrix route, the useful target is now a **genuinely cheaper representation conversion or batched address/layer operation**, with a charged recurrence. In this inherited assembly, the axis-layout cost is a named bottleneck. Merely reshaping a length-N object into a square matrix, increasing the base, retuning c/epsilon, or reducing the number of large arithmetic calls without paying their sizes does not resolve it. No improved layout theorem is asserted here.

## 9. Release status

**Established in this release:** fresh finite validation; exact replacement-kernel identities and bounds; measured packing-component improvements; a larger conditional exponent certificate; and a scoped tuning ceiling.

**Not established:** a new standalone sub-N-log-N multiplication theorem, a faster arbitrary-input DFT, an asymptotic bound for the full Python implementation, a reliable whole-profile practical speedup, or superiority over the stronger current conditional comparison.

The release preserves the original v10 defaults and exposes v11 kernels explicitly. Start with `README_V11.md`; the package includes source, proofs, test logs, benchmark samples and provenance.
