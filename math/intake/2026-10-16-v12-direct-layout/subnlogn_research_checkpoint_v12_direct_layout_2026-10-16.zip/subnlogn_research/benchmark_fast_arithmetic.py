"""Full finite products with fast Gaussian arithmetic; cold setup is timed."""
from collections import Counter
from operator import mul
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import sys

SOURCES = ("benchmark_fast_arithmetic.py", "fast_gaussian.py", "fast_resampled.py",
    "fast_scalar.py", "fermat_recursive.py", "multiply_resampled.py", "resampled_transform.py",
    "certified_exp.py", "certified_phase.py", "gaussian_resampling.py", "gaussian_tensor.py",
    "crt_layout.py", "synthetic.py", "guarded_layer.py", "packed_stream.py", "swap_recursion.py",
    "stream_moves.py", "network_frames.py", "recursive_network.py", "recursive_edges.py",
    "phase_layers.py", "packed_bits.py", "bit_frames.py", "motifs.py", "test_stream_swap.py")


def main():
    root = Path(__file__).resolve().parent
    def hashes(): return {n: hashlib.sha256((root/n).read_bytes()).hexdigest() for n in SOURCES}
    before = hashes()
    from fast_resampled import multiply_fast_finite
    from guarded_layer import make_guarded_network_layer
    from network_frames import ComplexNetwork
    from packed_stream import make_stream_layout_move
    from swap_recursion import CompiledBitCircuit
    from test_stream_swap import SwapControl
    x, y = 0xdeadbeef, 0xfedcba98
    expected = x*y
    profiles = [("recursive_fermat_one_axis", (3,), (4,), 128, 5, 16, 1, None),
                ("native_control_one_axis", (3,), (4,), 128, 5, 16, 3, mul),
                ("native_control_guarded_two_axes", (3, 5), (4, 8), 192, 6, 4, 3, mul)]
    report = dict(python=sys.version, platform=platform.platform(), cases=[],
        method="Cold contexts/circuits, all weight construction, fixed-cache scans, Gaussian/chirp/ring arithmetic, exact recovery and carries inside timers; global audits disabled; correctness checked outside",
        scope="One completely recursive numerical-arithmetic product and separate native-integer controls, all at explicit finite parameters; not the completed sub-N-log-N algorithm")
    was_enabled = gc.isenabled()
    gc.disable()
    try:
        for name, sources, targets, p, alpha, digit_bits, repetitions, backend in profiles:
            samples = []
            for _ in range(repetitions):
                started = perf_counter_ns()
                circuit = CompiledBitCircuit(SwapControl())
                layer = make_guarded_network_layer(ComplexNetwork(100), p, swap_circuit=circuit)
                movement = make_stream_layout_move(circuit, component_bytes=(p+9)//8)
                value, diagnostics = multiply_fast_finite(x, y, sources=sources, targets=targets,
                    p=p, alpha=alpha, digit_bits=digit_bits, circuit=circuit, layer=layer,
                    layout_move=movement, integer_multiply=backend)
                samples.append(perf_counter_ns()-started)
                if value != expected or diagnostics["ledger"]:
                    raise AssertionError("full product or disabled global audit")
            report["cases"].append(dict(profile=name, samples_ns=samples, median_ns=median(samples),
                repetitions=repetitions, diagnostics=diagnostics))
            print(json.dumps(dict(profile=name, median_ms=median(samples)/1e6)), flush=True)
        audited = []
        for name, sources, targets, p, alpha, digit_bits, _, _ in profiles[1:]:
            ledger = Counter()
            circuit = CompiledBitCircuit(SwapControl())
            layer = make_guarded_network_layer(ComplexNetwork(100), p, swap_circuit=circuit)
            movement = make_stream_layout_move(circuit, component_bytes=(p+9)//8)
            value, diagnostics = multiply_fast_finite(x, y, sources=sources, targets=targets,
                p=p, alpha=alpha, digit_bits=digit_bits, circuit=circuit, layer=layer,
                layout_move=movement, integer_multiply=mul, ledger=ledger)
            if value != expected: raise AssertionError("audited arithmetic control")
            audited.append(dict(profile=name, diagnostics=diagnostics))
        report["untimed_native_audit_controls"] = audited
    finally:
        if was_enabled: gc.enable()
    if hashes() != before: raise RuntimeError("sources changed during benchmark")
    report.update(source_sha256=before, sources_unchanged_during_benchmark=True,
                  checked_timed_products=7, checked_untimed_audit_products=2)
    (root/"fast_arithmetic_benchmarks.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__": main()
