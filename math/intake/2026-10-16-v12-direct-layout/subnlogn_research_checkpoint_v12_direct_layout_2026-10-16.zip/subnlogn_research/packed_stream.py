"""Packed selected-bit row additions on complete sequential record streams.

Chunk movement uses swap_recursion's binary interface; only exceptional records
are radix-sorted. All three logical chunk orders and arbitrary spectator ranges
are supported. A supplied compiled circuit determines the swap recurrence; toy
circuits do NOT gain the actual h=100 rank saving. Descriptor arithmetic and
the complete fixed-tape cost audit remain outside the payload-transfer ledger.
"""
from dataclasses import dataclass
from math import prod
from packed_bits import PackedBits, stable_radix_records
from stream_moves import Reader, charge, copy_records, emit, move_digit, rotate_later, shape_check, validate_payload
from swap_recursion import binary_chunk_swap


@dataclass(frozen=True)
class Rectangle:
    chunk_bits: int
    spectators: tuple = (1,1,1,1)
    names: tuple = ("x","y","z")

    def __post_init__(self):
        if not isinstance(self.chunk_bits,int) or self.chunk_bits<1: raise ValueError("positive chunk width")
        if len(self.spectators)!=4 or any(not isinstance(n,int) or n<1 for n in self.spectators):
            raise ValueError("four positive spectator ranges required")
        if sorted(self.names)!=["x","y","z"]: raise ValueError("chunk names must be a permutation of x,y,z")

    @property
    def shape(self):
        a,b,c,d=self.spectators
        q=1<<self.chunk_bits
        return (a,q,b,q,c,q,d)

    @property
    def volume(self): return prod(self.shape)

    @property
    def strides(self): return {name:prod(self.shape[2*i+2:]) for i,name in enumerate(self.names)}

    def address(self,rank):
        if not 0<=rank<self.volume: raise ValueError("record rank outside rectangle")
        q=1<<self.chunk_bits
        strides=self.strides
        return tuple(rank//strides[name]%q for name in ("x","y","z"))

    def repair_rank(self,rank,spec):
        old=self.address(rank)
        new=spec.repair_destination(old)
        strides=self.strides
        return rank+sum((b-a)*strides[name] for name,a,b in zip(("x","y","z"),old,new))


def xor_bit_pair(records,prefix,gap,suffix,control_first,ledger,width):
    """A fixed two-bit permutation using four sequential banks."""
    shape_check(records,(prefix,2,gap,2,suffix),width)
    banks=[[] for _ in range(4)]
    reader=Reader(records,ledger,width)
    for _ in range(prefix):
        for a in range(2):
            for _ in range(gap):
                for b in range(2): copy_records(reader,banks[2*a+b],suffix,ledger,width)
    reader.finish()
    readers=[Reader(bank,ledger,width) for bank in banks]
    out=[]
    for _ in range(prefix):
        for a in range(2):
            for _ in range(gap):
                for b in range(2):
                    original=(a,b^a) if control_first else (a^b,b)
                    copy_records(readers[2*original[0]+original[1]],out,suffix,ledger,width)
    for reader in readers: reader.finish()
    ledger["elementary_selected_bit_additions"]+=1
    return out


def xor_address_bits(records,source_bit,target_bit,ledger,width):
    """Integer bit-position adapter; arbitrary complete preceding rows allowed."""
    if min(source_bit,target_bit)<0 or source_bit==target_bit: raise ValueError("distinct nonnegative bits required")
    high,low=max(source_bit,target_bit),min(source_bit,target_bit)
    if len(records)%(1<<(high+1)): raise ValueError("incomplete bit-pair rectangle")
    return xor_bit_pair(records,len(records)//(1<<(high+1)),1<<(high-low-1),1<<low,
                        source_bit==high,ledger,width)


def rotate_named_chunk(records,rectangle,target,selected_mask,parity,sign,circuit,ledger,width=1):
    """One controlled whole-chunk rotation, restoring physical name order.

    The offset is sign * (x & (other if parity else ~other) & selected_mask).
    Target is y or z; its two controls are brought before it by at most one
    chunk swap, which is undone after the sequential rotation.
    """
    shape=rectangle.shape
    shape_check(records,shape,width)
    if target not in ("y","z") or parity not in (0,1) or sign not in (-1,1):
        raise ValueError("invalid controlled rotation")
    if selected_mask<0 or selected_mask.bit_length()>rectangle.chunk_bits: raise ValueError("mask outside chunk")
    names=list(rectangle.names)
    old=names.index(target)
    out=records
    if old!=2:
        first,last=2*old+1,5
        p,g,b=prod(shape[:first]),prod(shape[first+1:last]),prod(shape[last+1:])
        out=binary_chunk_swap(out,rectangle.chunk_bits,circuit,ledger,prefix=p,gap=g,suffix=b,width=width)
        names[old],names[2]=names[2],names[old]
        ledger["packed_rotation_chunk_swaps"]+=1
    x_position=2*names.index("x")+1
    other="z" if target=="y" else "y"
    other_position=2*names.index(other)+1
    if max(x_position,other_position)>=5: raise AssertionError("rotation target must follow controls")
    def offset(controls):
        value=controls[other_position]
        return sign*(controls[x_position] & (value if parity else ~value) & selected_mask)
    out=rotate_later(out,shape,5,offset,ledger,width)
    if old!=2:
        out=binary_chunk_swap(out,rectangle.chunk_bits,circuit,ledger,prefix=p,gap=g,suffix=b,width=width)
        ledger["packed_rotation_chunk_swaps"]+=1
    ledger["packed_whole_chunk_rotations"]+=1
    return out


def repair_indexed_stream(factory,rectangle,spec,ledger,width=1):
    """Extract/sort/reinsert only bad records from a repeatable ordered stream.

    factory yields (implicit record rank, payload); for a full rectangle it is
    simply enumerate(records). Closed sparse orbits are accepted for independent
    finite tests, but never substituted for complete rectangles by the backend.
    No destination rank is used for random-access payload writes.
    """
    if rectangle.chunk_bits!=spec.width: raise ValueError("inconsistent packed width")
    exceptional=[]
    previous=-1
    count=0
    for rank,value in factory():
        if rank<=previous: raise ValueError("stream ranks must be strictly increasing")
        address=rectangle.address(rank)
        previous=rank
        if spec.bad(address): exceptional.append((rectangle.repair_rank(rank,spec),value))
        count+=1
    key_bits=(rectangle.volume-1).bit_length()
    if exceptional:
        bank=stable_radix_records(exceptional,key_bits)
        ledger["exceptional_radix_passes"]+=key_bits
        # Field-work accounting, not a machine-step trace. Keys must be charged
        # as well as payload; the full rectangle is NOT passed to the sort.
        ledger["exceptional_sort_field_bits"]+=2*len(bank)*key_bits*(width+key_bits)
    else: bank=[]
    it=iter(bank)
    out=[]
    last=-1
    for rank,value in factory():
        if rank<=last: raise ValueError("second scan is not ordered")
        last=rank
        if spec.bad(rectangle.address(rank)):
            item=next(it,None)
            if item is None or item[0]!=rank: raise ValueError("exceptional set is not invariant under repair")
            value=item[1]
        emit(out,value,ledger,width)
    if len(out)!=count or next(it,None) is not None: raise ValueError("inconsistent repeated stream")
    ledger["exceptional_records_sorted"]+=len(bank)
    ledger["packed_repair_scanned_records"]+=2*count
    charge(ledger,"packed_repair_read_symbols",2*count,width)
    ledger["packed_repair_max_key_bits"]=max(ledger["packed_repair_max_key_bits"],key_bits)
    return out


def packed_selected_add(records,rectangle,spec,circuit,ledger,width=1):
    """Execute all selected XORs, preserving the arbitrary third chunk."""
    if not isinstance(spec,PackedBits) or rectangle.chunk_bits!=spec.width:
        raise ValueError("require a valid K>=6 packed descriptor of matching width")
    shape_check(records,rectangle.shape,width)
    validate_payload(records,width)
    return _execute_packed_selected_add(records,rectangle,spec,circuit,ledger,width)


def _execute_packed_selected_add(records,rectangle,spec,circuit,ledger,width):
    """Shared execution body; tests also use an explicit all-exceptional control.

    Production callers must pass through packed_selected_add's real K>=6
    validation. The control is not a substitute for a full guarded rectangle.
    """
    out=records
    if spec.fields>1:
        schedule=(("y",0,-1),("z",0,-1),("y",0,1),("z",0,1),
                  ("z",1,1),("y",1,1),("z",1,-1),("y",1,-1))
        for target,parity,sign in schedule:
            out=rotate_named_chunk(out,rectangle,target,spec.selected,parity,sign,circuit,ledger,width)
        out=repair_indexed_stream(lambda:enumerate(out),rectangle,spec,ledger,width)
    # Split x and y at their highest selected bits. Spectator fields need not
    # be powers of two, so this descriptor is built from mixed-radix lengths.
    shape=rectangle.shape
    i,j=sorted((2*rectangle.names.index("x")+1,2*rectangle.names.index("y")+1))
    bit=spec.offset+(spec.fields-1)*spec.k
    high,low=1<<(spec.width-bit-1),1<<bit
    p=prod(shape[:i])*high
    g=low*prod(shape[i+1:j])*high
    b=low*prod(shape[j+1:])
    out=xor_bit_pair(out,p,g,b,rectangle.names[(i-1)//2]=="x",ledger,width)
    ledger["packed_selected_row_additions"]+=1
    return out


@dataclass(frozen=True)
class GaussianRecordCodec:
    coefficients: int
    component_bytes: int

    def __post_init__(self):
        if self.coefficients<1 or self.component_bytes<1: raise ValueError("positive fixed record shape required")

    @property
    def width(self): return 16*self.coefficients*self.component_bytes

    @classmethod
    def choose(cls,records):
        if not records or not records[0]: raise ValueError("nonempty polynomial records required")
        r=len(records[0])
        maximum=0
        for poly in records:
            if len(poly)!=r: raise ValueError("unequal polynomial lengths")
            for pair in poly:
                if len(pair)!=2 or any(not isinstance(x,int) for x in pair): raise ValueError("integer Gaussian pairs required")
                maximum=max(maximum,*(abs(x).bit_length()+1 for x in pair))
        return cls(r,max(1,(maximum+7)//8))

    def encode(self,records,ledger):
        out=[]
        for poly in records:
            if len(poly)!=self.coefficients: raise ValueError("coefficient count changed")
            raw=b"".join(x.to_bytes(self.component_bytes,"little",signed=True) for pair in poly for x in pair)
            if len(raw)*8!=self.width: raise ValueError("not a Gaussian record")
            out.append(int.from_bytes(raw,"little"))
        charge(ledger,"gaussian_record_encode_bits",len(out),self.width)
        ledger["gaussian_record_max_width"]=max(ledger["gaussian_record_max_width"],self.width)
        return out

    def decode(self,records,ledger):
        out=[]
        step=self.component_bytes
        for value in records:
            raw=value.to_bytes(self.width//8,"little")
            parts=[int.from_bytes(raw[i:i+step],"little",signed=True) for i in range(0,len(raw),step)]
            out.append(list(zip(parts[::2],parts[1::2])))
        charge(ledger,"gaussian_record_decode_bits",len(out),self.width)
        return out


def make_packed_basis_move(circuit,*,component_bytes=None):
    """Provide the recursive_edges basis_move interface for Gaussian records.

    Complete equally spaced slots are required for K>=6. Small K uses explicit
    sequential two-bit operations, recorded as a separate fallback. The codec
    makes record bit widths explicit. component_bytes supplies a data-independent
    common format, as used by guarded_layer; omitted, widths remain adaptive.
    """
    if component_bytes is not None and (not isinstance(component_bytes,int) or component_bytes<1):
        raise ValueError("positive fixed component byte width required")
    def move(records,slots,operations,ledger):
        slots=tuple(tuple(row) for row in slots)
        operations=tuple(operations)
        if not slots or not slots[0] or any(len(row)!=len(slots[0]) for row in slots):
            raise ValueError("nonempty equally sized slots required")
        bits=[bit for row in slots for bit in row]
        if len(set(bits))!=len(bits) or min(bits)<0 or len(records)%(1<<(max(bits)+1)):
            raise ValueError("incomplete or overlapping selected-bit slots")
        if any(not 0<=a<len(slots) or not 0<=b<len(slots) or a==b for a,b in operations):
            raise ValueError("invalid binary row operation")
        if not operations: return [list(poly) for poly in records]
        f=len(slots[0])
        starts=sorted(min(row) for row in slots)
        if f>1:
            signed_step=slots[0][1]-slots[0][0]
            k=abs(signed_step)
            if not k or any(b-a!=signed_step for row in slots for a,b in zip(row,row[1:])):
                raise ValueError("inconsistent selected-bit column order")
        else:
            k=min((b-a for a,b in zip(starts,starts[1:])),default=1)
        if component_bytes is None:
            codec=GaussianRecordCodec.choose(records)
            ledger["adaptive_basis_codec_calls"]+=1
        else:
            codec=GaussianRecordCodec(len(records[0]),component_bytes)
            ledger["fixed_basis_codec_calls"]+=1
            ledger["fixed_basis_max_component_bytes"]=max(ledger["fixed_basis_max_component_bytes"],component_bytes)
        out=codec.encode(records,ledger)
        if k<6:
            for target,source in operations:
                for sb,tb in zip(slots[source],slots[target]):
                    out=xor_address_bits(out,sb,tb,ledger,codec.width)
                ledger["small_k_sequential_row_additions"]+=1
        else:
            if len(slots)<3: raise ValueError("packed row addition requires a third helper slot")
            length=k*f
            if any(b-a!=length for a,b in zip(starts,starts[1:])):
                raise ValueError("packed slots must be consecutive and nonoverlapping")
            rho=starts[0]%k
            bases=[min(row)-rho for row in slots]
            if len(records)%(1<<(max(bases)+length)): raise ValueError("incomplete packed chunk ranges")
            spec=PackedBits(k,f,rho)
            for target,source in operations:
                helper=next(i for i in range(len(slots)) if i not in (source,target))
                physical=sorted(((bases[source],"x"),(bases[target],"y"),(bases[helper],"z")),reverse=True)
                (a,_),(b,_),(c,_)=physical
                spectators=(len(out)//(1<<(a+length)),1<<(a-b-length),1<<(b-c-length),1<<c)
                rect=Rectangle(length,spectators,tuple(name for _,name in physical))
                out=packed_selected_add(out,rect,spec,circuit,ledger,codec.width)
        ledger["stream_basis_change_calls"]+=1
        return codec.decode(out,ledger)
    return move


def make_stream_layout_move(circuit,*,component_bytes=None):
    """Execute synthetic.Layout's named bit/chunk schedule, and its inverse.

    This removes the reference destination scatter from L and L^-1. It does
    not change the precision, arithmetic or phase-loop complexity of transforms.
    A supplied component_bytes fixes the external record format before payloads
    are inspected; omitting it retains the adaptive reference codec.
    """
    if component_bytes is not None and (not isinstance(component_bytes,int) or component_bytes<1):
        raise ValueError("positive fixed layout component width required")
    def move(records,layout,opposite,ledger):
        slots,moves=layout.schedule()
        n=len(slots)
        if len(records)!=1<<n: raise ValueError("incomplete layout address range")
        if opposite:
            moves=tuple((kind,b,a,width) if kind=="bit_move" else (kind,a,b,width)
                        for kind,a,b,width in reversed(moves))
        ledger["stream_layout_calls"]+=1
        if not moves: return [list(poly) for poly in records]
        if component_bytes is None:
            codec=GaussianRecordCodec.choose(records)
            ledger["adaptive_layout_codec_calls"]+=1
        else:
            codec=GaussianRecordCodec(len(records[0]),component_bytes)
            ledger["fixed_layout_codec_calls"]+=1
        out=codec.encode(records,ledger)
        for kind,a,b,length in moves:
            if kind=="bit_move":
                if a<b:
                    shape=(1<<a,2,1<<(b-a),1<<(n-b-1))
                    out,_=move_digit(out,shape,1,2,ledger,codec.width)
                else:
                    shape=(1<<b,1<<(a-b),2,1<<(n-a-1))
                    out,_=move_digit(out,shape,2,1,ledger,codec.width)
                ledger["stream_layout_bit_moves"]+=1
            elif kind=="chunk_swap":
                a,b=min(a,b),max(a,b)
                if a+length>b or b+length>n: raise ValueError("overlapping layout chunks")
                out=binary_chunk_swap(out,length,circuit,ledger,prefix=1<<a,
                                      gap=1<<(b-a-length),suffix=1<<(n-b-length),width=codec.width)
                ledger["stream_layout_chunk_swaps"]+=1
            else: raise ValueError("unknown layout operation")
        return codec.decode(out,ledger)
    return move
