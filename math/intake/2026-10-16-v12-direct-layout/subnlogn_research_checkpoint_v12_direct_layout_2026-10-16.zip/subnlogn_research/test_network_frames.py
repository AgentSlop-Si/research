"""Network compiler checks independent of the existing scalar motif executor."""
from collections import Counter
from fractions import Fraction as Q
from itertools import product
import random
import unittest
from motifs import Budget, Gaussian as G, I_POWERS
from network_frames import (ComplexNetwork, apply_row_operations, basis_row_operations,
                            complete_basis, dot, independent_basis, label, matrix_vector,
                            orthonormal_basis, TensorDirection, complement_tensor_factors)

COUNTS=Counter()


def dense_projector(space):
    h,m=space.h,space.ambient
    coordinates=[(i//(h*h),(i//h)%h,i%h) for i in range(m)]
    columns=[]
    for source in range(m):
        column=0
        for target in range(m):
            parity=0
            for term in space.terms:
                product_entry=1
                for axis,factor in enumerate(term):
                    a,b=coordinates[target][axis],coordinates[source][axis]
                    product_entry &= int(a==b) if factor is None else ((factor>>a)&(factor>>b)&1)
                parity ^= product_entry
            column |= parity<<target
        columns.append(column)
    return columns


def initial_value(role):
    # A stable arithmetic encoding of all role components, with nonzero scratch.
    values=[]
    def flatten(x):
        if isinstance(x,tuple):
            for y in x: flatten(y)
        elif isinstance(x,str): values.extend(ord(c) for c in x)
        else: values.append(x)
    flatten(role)
    code=1
    for value in values: code=(code*137+value+1)%100003
    return G(Q(code%31-15,8),Q(code%23-11,16))


class BinaryLinearAlgebraTests(unittest.TestCase):
    def test_compact_tensor_bases(self):
        for h in (4,7):
            lines=(7,11)
            basis=[TensorDirection(h,b) for b in complement_tensor_factors(h,lines)]
            self.assertEqual(len(basis),h*h-1)
            tensors=[b.materialize() for b in basis]
            center=TensorDirection(h,lines).materialize()
            for i,b in enumerate(basis):
                self.assertEqual(b.weight,tensors[i].bit_count())
                self.assertEqual(dot(tensors[i],center),0)
                for j,c in enumerate(basis):
                    self.assertEqual(b.dot(c),int(i==j))
                    self.assertEqual(b.dot(c),dot(tensors[i],tensors[j]))
                COUNTS["compact_tensor_directions"]+=1
    def test_units_and_alternating_plane_absorption(self):
        # <e0> orthogonal to a hyperbolic plane supported on the other 3 bits.
        basis=orthonormal_basis((1,0b0110,0b1100))
        self.assertEqual(len(basis),3)
        self.assertTrue(all(dot(u,v)==int(i==j) for i,u in enumerate(basis) for j,v in enumerate(basis)))
        self.assertEqual(len(independent_basis([1,6,12,*basis])),3)
        with self.assertRaises(ValueError): orthonormal_basis((6,12))
        with self.assertRaises(ValueError): orthonormal_basis((1,6))
        COUNTS["binary_alternating_plane_controls"]+=3

    def test_basis_extension_and_elementary_schedule(self):
        rng=random.Random(7614)
        for m in range(3,13):
            for _ in range(8):
                directions=independent_basis(rng.randrange(1,1<<m) for _ in range(m//2))
                columns=complete_basis(directions,m)
                forward,inverse=basis_row_operations(columns)
                self.assertLessEqual(len(forward),m*(m-1)+3*m)
                self.assertEqual(columns[:len(directions)],tuple(directions))
                for x in [0,(1<<m)-1,*[rng.randrange(1<<m) for _ in range(10)]]:
                    expected=matrix_vector(columns,x)
                    self.assertEqual(apply_row_operations(x,forward),expected)
                    self.assertEqual(apply_row_operations(expected,inverse),x)
                    COUNTS["binary_basis_address_checks"]+=1


class NetworkCompilerTests(unittest.TestCase):
    def test_neighbor_generation_and_fixed_constants(self):
        for h in (4,5,7,10):
            network=ComplexNetwork(h)
            for i,mask in enumerate(network.masks):
                expected={j for j,other in enumerate(network.masks) if i!=j and (mask&other).bit_count()%2==0}
                neighbors=list(network.neighboring(i))
                self.assertEqual(len(neighbors),len(set(neighbors)))
                self.assertEqual(set(neighbors),expected)
                self.assertEqual(len(neighbors),network.neighbors)
                COUNTS["compiled_neighbor_lists"]+=1
        network=ComplexNetwork(100)
        budget=Budget(100,"complex")
        self.assertEqual((network.wires,network.rank_sum,network.m),(budget.wires,budget.ranks,budget.m))
        self.assertLess(network.rank_sum,network.wires*network.m)
        # Sample actual h=100 gate descriptors without materializing the network.
        first=next(network.invocation(0,(0,0)))
        self.assertEqual(len(first.roles),1+budget.neighbors)
        self.assertEqual(first.label.dimension,0)
        self.assertEqual(first.label.terms,frozenset())
        COUNTS["fixed_network_descriptor_checks"]+=3

    def test_compiled_rank_count_and_residual_bases(self):
        network=ComplexNetwork(4)
        sums=Counter()
        cases={}
        roles=set()
        for role,tail,head,gate in network.compiled_edges():
            roles.add(role)
            change=head.dimension-tail.dimension
            sums["absolute"]+=abs(change)
            sums["signed"]+=change
            sums["loss"]+=max(0,-change)
            key=(role[0],gate.stage if gate else -1,gate.time if gate else -1,tail.dimension,head.dimension)
            cases.setdefault(key,(role,tail,head,gate))
            if change<0:
                self.assertEqual(role[0],"C")
                self.assertEqual(gate.time,4)
                self.assertEqual(change,-network.h)
        self.assertEqual(len(roles),network.wires)
        self.assertEqual(sums["absolute"],network.rank_sum)
        self.assertEqual(sums["signed"],network.wires*network.m-2*network.bank_size)
        self.assertEqual(sums["loss"],3*network.v**2*(network.h+1)*network.h)
        rng=random.Random(8614)
        for role,tail,head,gate in cases.values():
            residual=tail.residual(head)
            basis=residual.basis()
            compact=list(network.residual_directions(role,gate))
            constructive=tuple(direction.materialize() for direction,_ in compact)
            self.assertEqual(len(constructive),len(basis))
            self.assertTrue(all(dot(u,v)==int(i==j) for i,u in enumerate(constructive) for j,v in enumerate(constructive)))
            self.assertEqual(len(basis),abs(head.dimension-tail.dimension))
            small,large=(tail,head) if tail.dimension<=head.dimension else (head,tail)
            for x in [*[1<<i for i in range(network.m)],*[rng.getrandbits(network.m) for _ in range(4)]]:
                self.assertEqual(large.project(small.project(x)),small.project(x))
                self.assertEqual(small.project(large.project(x)),small.project(x))
                self.assertEqual(residual.project(x),sum_projection(basis,x))
                self.assertEqual(residual.project(x),sum_projection(constructive,x))
                COUNTS["compiled_nested_projection_checks"]+=1
            # A residual kernel gets sign -1 iff its odd basis weight is 3 mod4;
            # a decreasing edge reverses the sign. Check this phase polynomial.
            for _ in range(8):
                x=rng.getrandbits(network.m)
                sign=1 if head.dimension>=tail.dimension else -1
                expected=sum(sign*v.bit_count()*dot(v,x) for v in basis)%4
                self.assertEqual((head.phase(x)-tail.phase(x))%4,expected)
                compiled=sum((-1 if inverse else 1)*dot(v,x) for v,(_,inverse) in zip(constructive,compact))%4
                self.assertEqual(compiled,expected)
                COUNTS["compiled_residual_phase_checks"]+=1
        COUNTS["compiled_edge_classes"]+=len(cases)

    def test_projectors_against_dense_tensor_definition(self):
        network=ComplexNetwork(4)
        rng=random.Random(7633)
        for stage,time in product(range(3),range(8)):
            space=network.gate_label(stage,(1,2),time,3)
            dense=dense_projector(space)
            self.assertEqual(len(independent_basis(dense)),space.dimension)
            self.assertTrue(all(((dense[i]>>j)&1)==((dense[j]>>i)&1) for i in range(64) for j in range(64)))
            for x in (0,(1<<64)-1,*[rng.getrandbits(64) for _ in range(5)]):
                self.assertEqual(space.project(x),matrix_vector(dense,x))
                self.assertEqual(space.project(space.project(x)),space.project(x))
                COUNTS["dense_tensor_projector_checks"]+=1

    def test_full_network_at_walsh_frequencies(self):
        network=ComplexNetwork(4)
        rng=random.Random(9811)
        for frequency in (0,1,3,(1<<64)-1,*[rng.getrandbits(64) for _ in range(4)]):
            actual,info=network.run_spectral(frequency,initial_value)
            self.assertEqual(info["wires"],network.wires)
            self.assertEqual(info["edge_ranks"],network.rank_sum)
            for output,value in actual.items():
                source=("Y",*output[1:]) if output[0]=="X" else (("X",*output[1:]) if output[0]=="Y" else output)
                sign=-1 if output[0]=="X" else 1
                phase=(network.sink_label(output).phase(frequency)-network.source_label(source).phase(frequency))%4
                self.assertEqual(value,initial_value(source)*I_POWERS[phase]*sign)
                COUNTS["full_framed_network_role_checks"]+=1

    def test_small_network_has_no_claimed_saving(self):
        network=ComplexNetwork(4)
        self.assertGreater(network.rank_sum,network.wires*network.m)
        with self.assertRaises(ValueError): ComplexNetwork(100).run_spectral(0,initial_value)
        with self.assertRaises(ValueError): ComplexNetwork(6)
        COUNTS["negative_controls"]+=3


def sum_projection(basis,vector):
    out=0
    for v in basis:
        if dot(v,vector): out ^= v
    return out


if __name__=="__main__": unittest.main()
