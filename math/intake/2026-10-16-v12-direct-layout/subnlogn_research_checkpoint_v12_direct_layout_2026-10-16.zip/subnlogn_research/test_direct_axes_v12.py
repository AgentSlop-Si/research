"""Independent scatter oracles are test-only, never used in the algorithms."""
from collections import Counter
from itertools import product, combinations
from math import prod
from operator import mul
import random
import unittest
from direct_axes_v12 import swap_axes, reverse_axes, DirectCRTLayout, DirectFastGaussianTensor
from direct_pipeline_v12 import multiply_direct_finite
from crt_layout import CRTLayout
from fast_gaussian import FastGaussianTensor
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl, scatter
from parameter_certificate_v12 import certificate

COUNTS = Counter()


class DirectAxesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.circuit = CompiledBitCircuit(SwapControl())

    def test_all_small_shapes(self):
        for d in range(2,6):
            for shape in product((2,4), repeat=d):
                values=list(range(prod(shape)))
                width=len(values).bit_length()
                for i,j in combinations(range(d),2):
                    ledger=Counter()
                    actual,new=swap_axes(values,shape,i,j,self.circuit,ledger,width)
                    def mapping(x):
                        y=list(x); y[i],y[j]=y[j],y[i]; return y
                    self.assertEqual(actual,scatter(values,shape,mapping,new))
                    restored,sh=swap_axes(actual,new,j,i,self.circuit,ledger,width)
                    self.assertEqual((restored,sh),(values,shape))
                    self.assertEqual(ledger['v12_direct_axis_swaps'],2)
                    self.assertEqual(ledger['v12_excess_bit_moves'],2*int(shape[i]!=shape[j]))
                    COUNTS['exact_pair_swaps']+=1
                    COUNTS['pair_roundtrips']+=1
                ledger=Counter()
                actual,new=reverse_axes(values,shape,self.circuit,ledger,width)
                self.assertEqual(actual,scatter(values,shape,lambda x:x[::-1],shape[::-1]))
                self.assertEqual(new,shape[::-1])
                self.assertEqual(ledger['v12_direct_axis_swaps'],d//2)
                COUNTS['exact_reversals']+=1

    def test_larger_chunks_and_rejections(self):
        for shape,i,j in [((8,2,8),0,2),((4,2,8),0,2),((8,2,4),0,2),
                          ((16,2,16),0,2),((8,4,2,16),0,3)]:
            values=list(range(prod(shape)))
            ledger=Counter()
            out,new=swap_axes(values,shape,i,j,self.circuit,ledger,len(values).bit_length())
            def mapping(x):
                y=list(x); y[i],y[j]=y[j],y[i]; return y
            self.assertEqual(out,scatter(values,shape,mapping,new))
            COUNTS['larger_chunk_swaps']+=1
            COUNTS['toy_internal_nodes_executed']+=ledger['swap_internal_nodes']
        for shape,i,j in [((2,8),0,1),((3,4),0,1),((2,2),-1,1),((2,2),0,2)]:
            with self.assertRaises(ValueError):
                swap_axes(list(range(prod(shape))),shape,i,j,self.circuit,Counter(),8)
            COUNTS['rejection_controls']+=1
        data=[1,2,3,4]
        self.assertEqual(swap_axes(data,(2,2),0,0,self.circuit,Counter(),8),(data,(2,2)))

    def test_crt_against_definition(self):
        rng=random.Random(121016)
        configurations=[((3,),(4,)),((3,5),(4,8)),((3,5,7),(4,8,8)),
                        ((7,3,5),(8,4,8)),((3,5,7,11),(8,8,8,16))]
        for sources,targets in configurations:
            old=CRTLayout(sources,targets,self.circuit,ledger=Counter())
            new=DirectCRTLayout(sources,targets,self.circuit,ledger=Counter())
            values=[rng.getrandbits(17) for _ in range(prod(sources))]
            actual=new.forward(values,17)
            expected=[0]*prod(targets)
            for k,value in enumerate(values):
                rank=0
                for s,t,mu in zip(sources,targets,new.mu):
                    rank=rank*t+(mu*k)%s
                expected[rank]=value
            self.assertEqual(actual,expected)
            self.assertEqual(actual,old.forward(values,17))
            self.assertEqual(new.inverse(actual,17),values)
            self.assertEqual(new.ledger['v12_direct_axis_swaps'],2*(len(sources)//2))
            COUNTS['crt_definition_comparisons']+=1
            COUNTS['crt_roundtrips']+=1

    def test_gaussian_maps_preserve_operation_order(self):
        for sources,targets in [((3,3,3),(4,4,4)),((3,5,3),(4,8,4))]:
            p,alpha=192,5
            old=FastGaussianTensor(sources,targets,p,alpha,self.circuit,
                                   integer_multiply=mul,ledger=Counter())
            new=DirectFastGaussianTensor(sources,targets,p,alpha,self.circuit,
                                         integer_multiply=mul,ledger=Counter())
            for inverse in (False,True):
                size=prod(targets if inverse else sources)
                values=[((j%7-3)<<(p-6),(j%5-2)<<(p-7)) for j in range(size)]
                data=values if inverse else old.embed(values)
                for order in ((0,1,2),(2,0,1),(1,2,0)):
                    before_old=old.ledger['gaussian_adjacent_axis_swaps']
                    before_new=new.ledger['v12_direct_axis_swaps']
                    self.assertEqual(old.apply(data,inverse=inverse,axis_order=order),
                                     new.apply(data,inverse=inverse,axis_order=order))
                    self.assertEqual(old.ledger['gaussian_adjacent_axis_swaps']-before_old,6)
                    self.assertEqual(new.ledger['v12_direct_axis_swaps']-before_new,4)
                    COUNTS['bit_exact_gaussian_tensor_comparisons']+=1

    def test_parameter_certificate(self):
        result=certificate()
        self.assertTrue(all(result['checks'].values()))
        self.assertGreater(result['new_kappa'],result['old_kappa'])
        COUNTS['exact_rational_checks']+=len(result['checks'])

    def test_full_native_controls(self):
        configs=[dict(sources=(3,),targets=(4,),p=128,alpha=5,digit_bits=16),
                 dict(sources=(3,5),targets=(4,8),p=192,alpha=6,digit_bits=4),
                 dict(sources=(3,5,7),targets=(4,8,8),p=448,alpha=8,digit_bits=4)]
        for config in configs:
            ledger=Counter()
            x,y=0xdeadbeef,0xfedcba98
            actual,diagnostics=multiply_direct_finite(x,y,circuit=self.circuit,
                                      integer_multiply=mul,ledger=ledger,**config)
            self.assertEqual(actual,x*y)
            d=len(config['sources'])
            self.assertEqual(ledger['v12_direct_axis_swaps'],12*(d-1)+3*(d//2))
            self.assertFalse(diagnostics['implementation_status']['sub_n_log_n_proved_for_implementation'])
            COUNTS['complete_native_products']+=1
            print('full native control',d,'axes: PASS',flush=True)


if __name__=='__main__':
    unittest.main(verbosity=2)
