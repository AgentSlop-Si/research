# v12 — direct tensor-axis scheduling

**16 October 2026.** Removes redundant neighboring-axis interchanges from the
CRT layout and Gaussian tensor exposure/restoration. Existing v11 numerical
kernels, arithmetic defaults, notices and licenses are retained.

## Result

* CRT reversal: d(d-1)/2 axis exchanges -> floor(d/2).
* Gaussian expansion or compression: d(d-1) exchanges -> 2(d-1).
* Conditional layout bound: O(V d^2(1+ell^tau)) -> O(V d(1+ell^tau)).
* Conditional exponent: 3.205112405573184e-37 -> 7.375908518826216e-27.

The last comparison is NOT a runtime factor. The full all-size multiplier and
arbitrary complex DFT claims remain unestablished by this implementation.
The underlying nonadjacent swap primitive is explicitly inherited from section
04 of the pinned OpenAI preprint. The new work uses it in a shorter schedule.
No independent-priority or global-optimality claim is made.

Read `DIRECT_LAYOUT_PROOF_V12.md` for the local proof and conditional transfer,
and `AUDIT_V12.md` for validation and measured scope.

## Reproduce

Use Python 3.11 or later from this directory. New modules use the standard
library and the inherited local modules. Native control tests deliberately use
`operator.mul`; their runtimes are not sub-N-log-N benchmarks.

```bash
python parameter_certificate_v12.py
python run_v12_validation.py --group core
python run_v12_validation.py --group gaussian
python run_v12_validation.py --group full
python run_v12_regression.py
python benchmark_direct_axes_v12.py
```

The three-axis full native control is substantially more expensive than the
layout-only tests. A recorded first combined shell invocation hit its execution
time limit after the one- and two-axis controls passed; a fresh uninterrupted
full-group run then passed all three. Both logs are retained. No interrupted
run is counted as a completed full validation.

## Use the opt-in full finite path

```python
from operator import mul
from direct_pipeline_v12 import multiply_direct_finite
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl

# Explicit small, NO-RANK-SAVING circuit and native integer control.
circuit = CompiledBitCircuit(SwapControl())
value, diagnostics = multiply_direct_finite(
    0xDEADBEEF, 0xFEDCBA98,
    sources=(3, 5), targets=(4, 8),
    p=192, alpha=6, digit_bits=4,
    circuit=circuit, integer_multiply=mul,
)
assert value == 0xDEADBEEF * 0xFEDCBA98
```

Omitting `integer_multiply` selects the inherited recursive Fermat backend, not
a free constant-time big-integer primitive. The new full-profile tests select
native arithmetic explicitly; full recursive-backend v12 was not replayed.

## File guide

`direct_axes_v12.py` contains the sequential schedules; `direct_pipeline_v12.py`
combines them with v11 packing; `parameter_certificate_v12.py` checks the revised
cost constraints with exact fractions. `test_direct_axes_v12.py` uses independent
scatter and CRT definitions only as test oracles. `direct_layout_benchmarks_v12.json`
contains all 50 raw timing samples and separate operation ledgers.

The only inherited code edits are backward-compatible factory hooks in
`multiply_resampled.py` and `fast_resampled.py`. Defaults stay unchanged; patches
are under `evidence/`. Earlier v10/v11 reports, manifests and benchmark files
remain historical records, not fresh v12 validations. `SHA256SUMS_V12.json` is
the current release manifest; the retained v11 manifest describes v11's old bytes.
