"""Exact executable finite primitives from the September 2026 preprint.

This module is a research building block, NOT a sub-n-log-n multiplier.
It does not claim that Python's random-access execution has the tape bounds.
Source: openai/math, pinned in source_manifest.json, sections 03 and 04.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import combinations, product
from math import comb


@dataclass(frozen=True)
class Budget:
    h: int
    kind: str

    def __post_init__(self):
        if self.kind not in ("bit", "complex"):
            raise ValueError("kind must be bit or complex")
        if self.h < 7 or (self.kind == "bit" and self.h == 9):
            raise ValueError("labels require h >= 7; rational form is singular at 9")

    @property
    def v(self): return comb(self.h, 3)
    @property
    def n(self): return self.v**3  # Number of bank roles, NOT input bit length.
    @property
    def m(self): return self.h**3
    @property
    def invocations(self): return 3*self.v**2
    @property
    def neighbors(self):
        return (3*comb(self.h-3, 2) if self.kind == "bit"
                else comb(self.h-3, 3)+3*(self.h-3))
    @property
    def centers(self): return self.h+(self.kind == "complex")
    @property
    def wires(self):
        return 2*self.n+self.invocations*(self.v*self.neighbors+self.centers)
    @property
    def loss(self): return self.invocations*self.centers*self.h
    @property
    def ranks(self):
        return self.wires*self.m-2*self.n+2*self.loss+(self.n if self.kind == "bit" else 0)
    @property
    def deficit(self): return Q(self.wires*self.m-self.ranks, self.wires*self.m)

    def edge_count_certificate(self):
        """Sum each wire's edges directly, independently of telescoping formula.

        Dimensions are the residual table in section 03. Multiplicities
        include ordered side pairs and the sink edges on all scratch roles.
        """
        positive = negative = 0
        rows = []
        for j in (1, 2, 3):
            a, future = self.h**(j-1), self.h**(3-j)
            count_inv = self.v**2
            data_gain = 2*self.n*a*(self.h-1)
            center_gain = count_inv*self.centers*((a-1)*self.h+2*self.h+a*self.h*(future-1))
            center_loss = count_inv*self.centers*self.h
            side_gain = count_inv*self.v*self.neighbors*(
                (a-1)+((a-1)*(self.h-1)+1)+(self.h-2)+1+a*self.h*(future-1))
            positive += data_gain+center_gain+side_gain
            negative += center_loss
            rows.append(dict(stage=j, data_gain=data_gain, center_gain=center_gain,
                             center_loss=center_loss, side_gain=side_gain))
        source_rank = self.n if self.kind == "bit" else 0
        return dict(stages=rows, signed=positive-negative, absolute=positive+negative,
                    source_rank=source_rank, ranks=positive+negative+source_rank)


class Motif:
    """Materialize one scalar invocation for finite tests or small instances.

    F2 values are bit-packed vectors (XOR). Complex-network scalars may be
    Fraction or Gaussian; exact half-scaled additions work for either.
    The explicit pair count is O(binomial(h,3)^2); no fast claim is made.
    """
    schedule = (("side", -1), ("scatter", -1), ("copy", 1), ("gather", 1),
                ("scatter", 1), ("side", 1), ("gather", -1), ("copy", -1))

    def __init__(self, h, kind, *, pair_limit=2_000_000):
        if h < 3 or kind not in ("bit", "complex"):
            raise ValueError("invalid motif")
        v = comb(h, 3)
        if v*v > pair_limit:
            raise ValueError("explicit motif exceeds pair_limit; use Budget for exact symbolic counts")
        self.h, self.kind = h, kind
        self.triples = list(combinations(range(h), 3))
        self.v = len(self.triples)
        masks = [sum(1 << i for i in t) for t in self.triples]
        self.edges = []
        for s, ms in enumerate(masks):
            for t, mt in enumerate(masks):
                k = (ms & mt).bit_count()
                if (k == 1 if kind == "bit" else s != t and k % 2 == 0):
                    self.edges.append((s, t, Q(1) if kind == "bit" else Q(1-k, 2)))
        self.center_count = h+(kind == "complex")

    def apply(self, x, y, side, center, inverse=False):
        """Mutate target and scratch by all eight operations, with arbitrary scratch."""
        if len(x) != self.v or len(y) != self.v:
            raise ValueError("bank length mismatch")
        if len(side) != len(self.edges) or len(center) != self.center_count:
            raise ValueError("scratch length mismatch")
        schedule = ([(op, -sign) for op, sign in reversed(self.schedule)]
                    if inverse else self.schedule)
        bit = self.kind == "bit"

        def add(array, index, value, sign, coefficient=Q(1)):
            if bit:
                array[index] ^= value
            else:
                array[index] += value*(sign*coefficient)

        for op, sign in schedule:
            if op == "copy":
                for k, (_, t, _) in enumerate(self.edges):
                    add(side, k, x[t], sign)
            elif op == "side":
                for k, (s, _, coefficient) in enumerate(self.edges):
                    add(y, s, side[k], sign, coefficient)
            elif op == "gather":
                for t, triple in enumerate(self.triples):
                    for i in triple:
                        add(center, i, x[t], sign)
                    if not bit:
                        add(center, self.h, x[t], sign)
            else:
                for s, triple in enumerate(self.triples):
                    for i in triple:
                        add(y, s, center[i], sign, Q(1) if bit else Q(1, 2))
                    if not bit:
                        add(y, s, center[self.h], -sign, Q(1, 2))

    def exchange(self, x, y, scratch_factory):
        """Execute all v^2 invocations at each of the three tensor stages.

        scratch_factory(stage, fixed_indices, lengths) supplies arbitrary
        scratch; every scratch entry is checked for exact restoration.
        """
        if len(x) != self.v**3 or len(y) != self.v**3:
            raise ValueError("tensor bank length mismatch")
        calls = 0
        for axis in range(3):
            others = [i for i in range(3) if i != axis]
            for fixed in product(range(self.v), repeat=2):
                ids = []
                for t in range(self.v):
                    coord = [0]*3
                    coord[axis] = t
                    for i, value in zip(others, fixed): coord[i] = value
                    ids.append((coord[0]*self.v+coord[1])*self.v+coord[2])
                side, center = scratch_factory(axis, fixed, (len(self.edges), self.center_count))
                saved = (list(side), list(center))
                source, target = (y, x) if axis == 1 else (x, y)
                xx, yy = [source[i] for i in ids], [target[i] for i in ids]
                self.apply(xx, yy, side, center, inverse=axis == 1)
                if (side, center) != saved:
                    raise AssertionError("scratch was not restored")
                for i, value in zip(ids, yy): target[i] = value
                calls += 1
        return calls


@dataclass(frozen=True)
class Gaussian:
    """Exact Q(i) value. Callers use dyadic components for phase tests."""
    real: Q = Q(0)
    imag: Q = Q(0)

    def __post_init__(self):
        object.__setattr__(self, "real", Q(self.real))
        object.__setattr__(self, "imag", Q(self.imag))

    @staticmethod
    def coerce(x): return x if isinstance(x, Gaussian) else Gaussian(x)
    def __add__(self, other):
        o = self.coerce(other)
        return Gaussian(self.real+o.real, self.imag+o.imag)
    __radd__ = __add__
    def __neg__(self): return Gaussian(-self.real, -self.imag)
    def __sub__(self, other): return self+-self.coerce(other)
    def __rsub__(self, other): return self.coerce(other)+-self
    def __mul__(self, other):
        o = self.coerce(other)
        return Gaussian(self.real*o.real-self.imag*o.imag,
                        self.real*o.imag+self.imag*o.real)
    __rmul__ = __mul__
    def conjugate(self): return Gaussian(self.real, -self.imag)


I_POWERS = (Gaussian(1), Gaussian(0, 1), Gaussian(-1), Gaussian(0, -1))


def translation_kernel(values, vector, inverse=False):
    """Apply (1+i)/2 I + (1-i)/2 X_vector, or its inverse."""
    n = len(values)
    if n < 2 or n & (n-1) or not 0 < vector < n:
        raise ValueError("complete binary address range and nonzero vector required")
    a, b = Gaussian(Q(1, 2), Q(1, 2)), Gaussian(Q(1, 2), Q(-1, 2))
    if inverse: a, b = a.conjugate(), b.conjugate()
    return [a*values[x]+b*values[x ^ vector] for x in range(n)]


def phase_frame(values, basis, inverse=False):
    """Apply the frame of an orthonormal binary basis via translation kernels."""
    basis = tuple(basis)
    for i, v in enumerate(basis):
        if v <= 0 or v >= len(values) or v.bit_count() % 2 != 1:
            raise ValueError("basis vector must be in range and have norm one")
        if any((v & u).bit_count() % 2 for u in basis[:i]):
            raise ValueError("basis is not orthogonal")
    out = list(values)
    for v in basis:
        out = translation_kernel(out, v, inverse ^ (v.bit_count() % 4 == 3))
    return out


def identity(n): return [[Q(int(i == j)) for j in range(n)] for i in range(n)]


def matmul(a, b):
    return [[sum((x*y for x, y in zip(row, col)), Q(0)) for col in zip(*b)] for row in a]


def inverse_lower(a):
    n = len(a)
    out = [[Q(0)]*n for _ in range(n)]
    for j in range(n):
        for i in range(j, n):
            out[i][j] = (int(i == j)-sum(a[i][k]*out[k][j] for k in range(i)))/a[i][i]
    return out


def lower_factorization(matrix):
    """Return E1, Pi, E2 with A=E1 Pi E2, both E factors invertible lower triangular.

    Executes the elimination in section 04, retaining rational exactness.
    It is preprocessing for a fixed matrix, not a fast growing-matrix routine.
    """
    n = len(matrix)
    if any(len(row) != n for row in matrix): raise ValueError("square matrix required")
    a = [[Q(x) for x in row] for row in matrix]
    left, right = identity(n), identity(n)
    rows, cols = list(range(n)), list(range(n))
    while True:
        pivot = next(((i, max(j for j in cols if a[i][j]))
                      for i in rows if any(a[i][j] for j in cols)), None)
        if pivot is None: break
        i, j = pivot
        for c in cols:
            if c >= j or not a[i][c]: continue
            scale = a[i][c]/a[i][j]
            for r in range(n):
                a[r][c] -= scale*a[r][j]
                right[r][c] -= scale*right[r][j]
        scale = a[i][j]
        a[i] = [x/scale for x in a[i]]
        left[i] = [x/scale for x in left[i]]
        for r in rows:
            if r <= i or not a[r][j]: continue
            scale = a[r][j]
            a[r] = [x-scale*y for x, y in zip(a[r], a[i])]
            left[r] = [x-scale*y for x, y in zip(left[r], left[i])]
        rows.remove(i)
        cols.remove(j)
    return inverse_lower(left), a, inverse_lower(right)


def shear_by_rank(h, d, factors, modulus):
    """Execute a rational shear using one pair interchange per pivot.

    The operation trace counts interchanges, not Python time or bit work.
    All denominators and required diagonal elements must be units modulo q.
    """
    e1, pivots, e2 = factors
    n = len(e1)
    if modulus < 2 or len(h) != n or len(d) != n:
        raise ValueError("invalid modulus or field lengths")

    def apply(a, x):
        return [sum((v.numerator*pow(v.denominator, -1, modulus)*y
                     for v, y in zip(row, x)), 0) % modulus for row in a]

    hh, dd = apply(inverse_lower(e1), h), apply(e2, d)
    count = 0
    for i, row in enumerate(pivots):
        for j, value in enumerate(row):
            if not value: continue
            if value != 1: raise ValueError("invalid partial permutation factor")
            dd[j] = (dd[j]+hh[i]) % modulus
            hh[i], dd[j] = dd[j], hh[i]
            dd[j] = (hh[i]-dd[j]) % modulus
            count += 1
    return apply(e1, hh), apply(inverse_lower(e2), dd), count
