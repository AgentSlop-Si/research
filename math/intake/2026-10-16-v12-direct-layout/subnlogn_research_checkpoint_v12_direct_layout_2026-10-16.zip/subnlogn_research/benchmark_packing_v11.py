"""Cold, interleaved finite benchmarks; not asymptotic evidence.

Run when other audit processes are idle. Timers include arithmetic context
creation, norm checks, packing, every backend product, extraction and rounding.
Operands and independent schoolbook answers are generated outside the timer.
No global audit ledger is maintained during timed calls. Audits run separately.
"""
import hashlib,json,platform,random,statistics,time
from collections import Counter
from operator import mul
from pathlib import Path

from fast_resampled import fast_ring_product, multiply_fast_finite
from fast_scalar import FastArithmetic
from fermat_recursive import NullLedger,RecursiveFermatMultiplier
from packed_gaussian_v11 import normalized_packed_product, multiply_packed_finite,packing_width
from synthetic import trunc_shift
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl
from test_packing_v11 import schoolbook

MODES=('v10_four_wide','four_narrow','three','one')


def evaluate(f,g,p,mode,backend_name,audit=False):
    backend=mul if backend_name=='native' else RecursiveFermatMultiplier()
    ledger=Counter() if audit else NullLedger()
    arithmetic=FastArithmetic(backend)
    if mode=='v10_four_wide': value=fast_ring_product(f,g,p,arithmetic,ledger)
    else: value=normalized_packed_product(f,g,p,arithmetic,ledger,mode=mode)
    return value,dict(ledger)


def main():
    rng=random.Random(150102026)
    configs={'native':[(32,8),(128,32),(256,128),(512,256)],
             'recursive':[(32,8),(64,8),(128,32)]}
    rows=[];checked=0
    for backend_name,shapes in configs.items():
        for p,r in shapes:
            cases=[]
            for _ in range(3):
                f,g=[[(rng.randrange(-(1<<(p-1)),1<<(p-1)),
                       rng.randrange(-(1<<(p-1)),1<<(p-1))) for _ in range(r)] for _ in range(2)]
                shift=p+r.bit_length()-1
                expected=[(trunc_shift(a,shift),trunc_shift(b,shift)) for a,b in schoolbook(f,g)]
                cases.append((f,g,expected))
            repeats=3 if backend_name=='native' else 1
            jobs=[(mode,i) for _ in range(repeats) for i in range(3) for mode in MODES]
            rng.shuffle(jobs);samples={mode:[] for mode in MODES}
            for mode,i in jobs:
                f,g,expected=cases[i]
                start=time.perf_counter_ns()
                actual,_=evaluate(f,g,p,mode,backend_name)
                elapsed=time.perf_counter_ns()-start
                assert actual==expected,(backend_name,p,r,mode)
                samples[mode].append(elapsed);checked+=1
            medians={mode:statistics.median(values) for mode,values in samples.items()}
            audits={mode:evaluate(cases[0][0],cases[0][1],p,mode,backend_name,True)[1] for mode in MODES}
            rows.append(dict(backend=backend_name,p=p,r=r,old_lane_width=4*p,new_lane_width=packing_width(p,r),
                samples_ns=samples,median_ns=medians,
                speedup_vs_v10={mode:medians['v10_four_wide']/v for mode,v in medians.items()},audits=audits))
            print(backend_name,p,r,{k:round(v,3) for k,v in rows[-1]['speedup_vs_v10'].items()},flush=True)
    full=[]
    # Full native controls include cold Gaussian setup and circuit construction.
    # Recursive full-profile timing is not repeated here and is not implied.
    for shape in ('one_axis','two_axes'):
        modes=('v10_four_wide','three','one');samples={mode:[] for mode in modes}
        jobs=[mode for _ in range(3) for mode in modes];rng.shuffle(jobs)
        for mode in jobs:
            start=time.perf_counter_ns()
            circuit=CompiledBitCircuit(SwapControl())
            params=(dict(sources=(3,),targets=(4,),p=128,alpha=5,digit_bits=16)
                    if shape=='one_axis' else dict(sources=(3,5),targets=(4,8),p=192,alpha=6,digit_bits=4))
            if mode=='v10_four_wide':
                value,diag=multiply_fast_finite(0xdeadbeef,0xfedcba98,integer_multiply=mul,circuit=circuit,**params)
            else:
                value,diag=multiply_packed_finite(0xdeadbeef,0xfedcba98,packing=mode,integer_multiply=mul,circuit=circuit,**params)
            elapsed=time.perf_counter_ns()-start
            assert value==0xdeadbeef*0xfedcba98
            samples[mode].append(elapsed);checked+=1
        medians={mode:statistics.median(v) for mode,v in samples.items()}
        full.append(dict(shape=shape,backend='native control',samples_ns=samples,median_ns=medians,
                         speedup_vs_v10={mode:medians['v10_four_wide']/v for mode,v in medians.items()}))
        print('full',shape,full[-1]['speedup_vs_v10'],flush=True)
    report=dict(date='2026-10-15',python=platform.python_version(),platform=platform.platform(),
        scope='Finite packing component benchmarks and full native controls; not a sub-n-log-n result',
        method='Three independent full-width signed input pairs per kernel shape; randomized interleaving; '
               '9 timed calls/mode/native shape, 3 calls/mode/recursive shape; all cold setup and norm checks included; '
               'full native profile uses 3 cold calls/mode/shape, same 32-bit operands; comparisons outside timer',
        checked_timed_calls=checked,kernel_rows=rows,full_native_controls=full)
    root=Path(__file__).resolve().parent
    report['source_sha256']={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
                            ('packed_gaussian_v11.py','fast_resampled.py','benchmark_packing_v11.py')}
    (root/'packing_benchmarks_v11.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
