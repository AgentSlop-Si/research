from collections import Counter
from itertools import product
import random
import unittest
from packed_bits import PackedBits, repair_sparse_stream, stable_radix_records

COUNTS = Counter()


class PackedTests(unittest.TestCase):
    def test_scalar_eight_steps_exhaustively(self):
        # Independent direct integer schedule, including negative values.
        for c, u, w in product((0, 1), range(-12, 13), range(-12, 13)):
            a, b = u, w
            a -= c*(b % 2 == 0)
            b -= c*(a % 2 == 0)
            a += c*(b % 2 == 0)
            b += c*(a % 2 == 0)
            b += c*(a % 2 == 1)
            a += c*(b % 2 == 1)
            b -= c*(a % 2 == 1)
            a -= c*(b % 2 == 1)
            self.assertEqual((a, b), (u+c*(1-2*(u % 2)), w))
            COUNTS["scalar_eight_rotation_cases"] += 1

    def test_exhaustive_guard_segments(self):
        for offset in range(6):
            spec = PackedBits(6, 2, offset)
            low = (1 << offset)-1
            for u, w, control in product(range(64), range(64), range(4)):
                x = ((control & 1) << offset) | ((control >> 1) << (offset+6))
                address = (x, (u << offset) | low, w << offset)
                shifted = spec.rotations(address)
                self.assertEqual(spec.rotations(shifted, inverse=True), address)
                self.assertEqual(spec.bad(address), spec.bad(shifted))
                self.assertEqual(spec.apply(address), spec.ideal(address))
                if not spec.bad(address): self.assertEqual(shifted, spec.ideal(address, include_top=False))
                COUNTS["exhaustive_guard_addresses"] += 1

    def test_multiple_segments_and_boundaries(self):
        rng = random.Random(19011)
        for k in (6, 7, 9, 16):
            for f in (1, 2, 3, 7, 21):
                for offset in (0, k//2, k-1):
                    spec = PackedBits(k, f, offset)
                    self.assertLessEqual(spec.exact_bad_fraction, spec.bad_fraction_bound)
                    cases = list(product((0, spec.mask), repeat=3))
                    cases += [tuple(rng.getrandbits(spec.width) for _ in range(3)) for _ in range(80)]
                    for address in cases:
                        shifted = spec.rotations(address)
                        self.assertEqual(spec.rotations(shifted, inverse=True), address)
                        self.assertEqual(spec.bad(address), spec.bad(shifted))
                        self.assertEqual(spec.apply(address), spec.ideal(address))
                        COUNTS["multisegment_addresses"] += 1

    def test_repair_and_payload_reinsertion(self):
        spec = PackedBits(6, 3)
        # Close a deterministic seed set under the repair permutation. This
        # reaches actual spill/borrow cases without allocating a 2^54 rectangle.
        seeds = [(65, 0, 0), (65, 0, 63), (4161, spec.mask, spec.mask), (65, 22, 25), (1, 63, 64)]
        addresses = set()
        for start in seeds:
            address = start
            for _ in range(10000):
                if address in addresses: break
                addresses.add(address)
                address = spec.repair_destination(address)
            else: self.fail("orbit unexpectedly large")
        records = [(a, (i, bytes((i % 256, (i*7) % 256)))) for i, a in enumerate(sorted(addresses))]
        repaired, info = repair_sparse_stream(records, spec)
        expected = {spec.repair_destination(a): payload for a, payload in records}
        self.assertEqual(dict(repaired), expected)
        self.assertEqual(len(repaired), len(records))
        self.assertGreater(info["exceptional_records"], 0)
        self.assertTrue(any(spec.repair_destination(a) != a for a, _ in records))
        COUNTS["repaired_payload_records"] += len(records)

    def test_radix_sort_stability(self):
        records = [(key, i) for i, key in enumerate((3, 1, 7, 3, 0, 7, 1, 1))]
        self.assertEqual(stable_radix_records(records, 3), sorted(records, key=lambda t: t[0]))

    def test_missing_repair_fails(self):
        spec = PackedBits(6, 3)
        witness = (65, 0, 0)
        self.assertEqual(spec.rotations(witness), (65, 262017, 262080))
        self.assertEqual(spec.ideal(witness, include_top=False), (65, 65, 0))
        self.assertEqual(spec.apply(witness), spec.ideal(witness))
        with self.assertRaises(ValueError): PackedBits(5, 2)
        COUNTS["negative_controls"] += 2


if __name__ == "__main__": unittest.main()
