"""Run meaningful exact tests and save their counts with source hashes."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import platform
import sys
import time
import unittest

TEST_MODULES=("test_primitives","test_packed_bits","test_synthetic","test_phase_layers",
              "test_network_frames","test_recursive_edges","test_recursive_network","test_stream_swap",
              "test_packed_stream","test_guarded_layer","test_gaussian_resampling","test_resampled",
              "test_fermat_recursive","test_fast_scalar","test_fast_gaussian")
SOURCE_FILES=("motifs.py","cost_certificate.py","packed_bits.py","synthetic.py","phase_layers.py",
              "network_frames.py","recursive_edges.py","recursive_network.py",
              "stream_moves.py","bit_frames.py","swap_recursion.py","packed_stream.py",
              "guarded_layer.py","guard_certificate.py","certified_exp.py",
              "gaussian_resampling.py","gaussian_tensor.py","certified_phase.py",
              "resampled_transform.py","crt_layout.py","multiply_resampled.py",
              "fermat_recursive.py","fermat_certificate.py","fast_scalar.py",
              "fast_scalar_transform.py","fast_gaussian.py","fast_resampled.py","run_validation.py",
              *(name+".py" for name in TEST_MODULES))


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=root/"validation.json")
    args = parser.parse_args()
    def hashes(): return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in SOURCE_FILES}
    before_hashes=hashes()
    modules=[importlib.import_module(name) for name in TEST_MODULES]
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module) for module in modules)
    started = time.perf_counter()
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    after_hashes=hashes()
    unchanged=before_hashes==after_hashes
    from collections import Counter
    counts=sum((module.COUNTS for module in modules),Counter())
    success=result.wasSuccessful() and unchanged
    report = {"status": "passed" if success else "failed",
              "test_methods": result.testsRun,
              "counts": dict(counts),
              "duration_seconds": time.perf_counter()-started,
              "python": sys.version, "platform": platform.platform(),
              "source_sha256": before_hashes, "sources_unchanged_during_tests":unchanged,
              "scope": "Exact finite primitives and inequalities; no complete sub-N-log-N multiplier"}
    args.output.write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
