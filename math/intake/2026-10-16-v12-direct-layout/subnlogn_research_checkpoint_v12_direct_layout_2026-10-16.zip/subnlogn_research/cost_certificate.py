"""Exact rational certificates for the preprint's finite rank and cost margins.

These certify arithmetic inequalities, conditional on the remaining analytic
and tape implementation lemmas. They are not a proof of an implemented full
multiplier. Floating point is used only for optional human-readable display.
"""
from dataclasses import dataclass, asdict
from fractions import Fraction as Q
from motifs import Budget


@dataclass(frozen=True)
class Parameters:
    tau: Q
    sigma: Q
    beta: Q
    delta: Q
    lam: Q
    lam_prime: Q
    c: Q
    epsilon: Q
    kappa: Q
    guard_power: int = 20

    def margins(self):
        e, c, t, lp = self.epsilon, self.c, self.tau, self.lam_prime
        return (1-e*(1+c), e*c*(1-t), e*(1-lp), 1-t-e*(2-t),
                Q(1, 4)-self.delta-Q(3, 2)*e, 1-self.delta-e, e)

    def check(self):
        bit, comp = Budget(100, "bit"), Budget(100, "complex")
        t, s, b, l, lp, c, e = self.tau, self.sigma, self.beta, self.lam, self.lam_prime, self.c, self.epsilon
        # m < 2^20 and ln 2 < 1 imply ln m < 20. Consequently
        # 20(1-tau) <= eta implies m^tau > m(1-eta), with strictness
        # from exp(-x)>1-x. This avoids rounded logarithmic comparisons.
        checks = {
            "bit_rank_recurrence": 0 < t < 1 and 20*(1-t) <= bit.deficit,
            "complex_rank_recurrence": 0 < s < 1 and 20*(1-s) <= comp.deficit,
            "recursion_cutoff": b == Q(1, 2),
            "internal_layer": max(t, s) < l < 1,
            "movement_overhead": t*(1+c/b) < l,
            "leaf_and_grouping": max(l, s+b*(1-s)) < lp < 1,
            "positive_parameters": c > 0 and e > 0 and self.delta > 0 and self.kappa > 0,
            "dimension_bound": e < Q(1, 12),
            "guard_width": e*self.guard_power < 1,
            "axis_layout": e*(2-t) < 1-t,
            "gaussian_maps": Q(3, 4)+self.delta+Q(3, 2)*e < 1,
            "prefix_moves": e*(1+c) < 1,
            "scalar_products": e+self.delta < 1,
            "all_seven_margins": min(self.margins()) >= 2*self.kappa,
        }
        if not all(checks.values()):
            raise ValueError({k: v for k, v in checks.items() if not v})
        return checks

    def certificate(self):
        checks = self.check()
        return dict(parameters=asdict(self), checks=checks, margins=self.margins(),
                    necessary_log2_b_for_K_at_least_2=1/(self.epsilon*self.c),
                    scope="Conditional exact inequality certificate; full multiplier remains unimplemented")


def original_parameters():
    return Parameters(1-Q(1, 2**50), 1-Q(1, 2**50), Q(1, 2), Q(1, 16),
                      1-Q(1, 2**52), 1-Q(1, 2**54), Q(1, 2**56), Q(1, 2**75), Q(1, 2**182))


def improved_parameters():
    """One exact feasible choice, keeping the paper's h=100 networks unchanged.

    No claim of optimality or novelty. The bottleneck remains the layout term.
    This is a parameter improvement conditional on the cited lemmas, not a
    measured speedup and not a substitute for the missing implementation.
    """
    a, b = Budget(100, "bit").deficit/20, Budget(100, "complex").deficit/20
    c = a*(1-2*a)/(2*(1-a))
    e = a*(1-a*a)/(1+a)
    k = e*c*a/2
    return Parameters(1-a, 1-b, Q(1, 2), Q(1, 16), 1-a*a, 1-a*a/2, c, e, k)


def certificate():
    networks = {}
    for kind in ("bit", "complex"):
        budget = Budget(100, kind)
        edges = budget.edge_count_certificate()
        if edges["ranks"] != budget.ranks: raise AssertionError("rank sum mismatch")
        if edges["signed"] != budget.wires*budget.m-2*budget.n: raise AssertionError("telescoping mismatch")
        networks[kind] = {key: getattr(budget, key) for key in
                          ("h", "v", "n", "m", "invocations", "neighbors", "centers", "wires", "loss", "ranks", "deficit")}
        networks[kind]["edge_count_certificate"] = edges
    old, new = original_parameters(), improved_parameters()
    return dict(networks=networks, original=old.certificate(), improved=new.certificate(),
                kappa_ratio=new.kappa/old.kappa,
                status="Research progress only: full end-to-end goal is not achieved")


def json_default(value):
    if isinstance(value, Q): return {"numerator": value.numerator, "denominator": value.denominator}
    raise TypeError(type(value).__name__)


if __name__ == "__main__":
    import argparse
    import json
    from pathlib import Path
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("certificate.json"))
    args = parser.parse_args()
    result = certificate()
    args.output.write_text(json.dumps(result, indent=2, default=json_default)+"\n", encoding="utf-8")
    print(json.dumps({"status": "exact inequalities passed", "full_multiplier_implemented": False,
                      "improved_kappa_display_only": float(improved_parameters().kappa),
                      "kappa_ratio_display_only": float(result["kappa_ratio"])}))
