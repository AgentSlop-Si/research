# v11: exact, narrower packing for Gaussian polynomial products

**Date:** 15 October 2026. **Claim:** identical finite outputs with different
packing and multiplication counts. **Not claimed:** a new sub-N-log-N theorem,
a faster arbitrary-input DFT, or novelty of Gauss/Karatsuba or Kronecker identities.

## Contract and notation

Let `r = 2^ell`, `p >= 2`, and `2 <= r < 2^p`. Inputs are Gaussian-integer
numerator polynomials `f=A+iB`, `g=C+iD`, each of degree below `r`. For every
input coefficient, `a_j^2+b_j^2 <= 2^(2p)` and likewise for `c_j,d_j`.
The existing injected arithmetic backend checks these inequalities.

Choose a **value-independent** lane width

    w = 2p + ell + 3,    radix R = 2^w.

This replaces the old `w_old=4p`. Since `ell <= p-1`, `w <= 3p+2 <= 4p`.
No input-dependent cancellation, sparsity, lucky carries, free giant-word
operation, or growing lookup table is assumed.

## Three-product mode

Evaluate the four real polynomials at `R` using the inherited signed,
carry-aware block codec. Compute

    U = A(R) C(R),
    V = B(R) D(R),
    W = (A(R)+B(R)) (C(R)+D(R)).

Centered decoding gives the ordinary integer coefficients of `AC`, `BD`,
and `(A+B)(C+D)` respectively. Reconstruct

    Re(fg) = AC - BD,
    Im(fg) = (A+B)(C+D) - AC - BD.

The two packed sums are evaluated as long integer additions, not as free
scalar operations. There are still four input packing streams, but only
three product-decoding streams instead of four.

### Separation proof, including worst-case coefficients

Put `Q=2^p`. Every ordinary product coefficient is a sum of at most `r`
terms. Thus coefficients of `AC` and `BD` have magnitude at most `r Q^2`.
Cauchy-Schwarz gives `|a_j+b_j| <= sqrt(2) Q` and similarly for `c_j+d_j`.
Every coefficient of `(A+B)(C+D)` therefore has magnitude at most `2r Q^2`.
But

    R/2 = 2^(2p+ell+2) = 4r Q^2.

Every decoded coefficient is strictly inside `(-R/2,R/2)`, including negative
and extremal inputs. Signed packing also accepts each input coefficient and
each coefficient of the two summed polynomials, since their magnitudes are
at most `sqrt(2)Q < R/2`.

The inherited centered decoder recovers all coefficients uniquely. Each
operand fits in at most `r*w` magnitude bits. Decoding `2r` coefficients per
product leaves an explicit zero top coefficient and verifies sign extension.

For `j=0,...,r-1`, subtract ordinary coefficient `j+r` from coefficient `j`
to reduce modulo `y^r+1`. Only then apply the original signed truncation by
`p+ell` bits. Consequently the normalized integer-pair output is **bit-for-bit
identical** to v10, not merely within the same error tolerance. The synthetic,
chirp and Gaussian reduction therefore retain all existing numerical bounds.
This does not certify any missing asymptotic implementation interface.

## One-product three-lane mode

Use an independent variable `X` and encode

    F(X)=A(X^3)+X B(X^3),  G(X)=C(X^3)+X D(X^3).

Then

    F(X)G(X)=AC(X^3)+X(AD+BC)(X^3)+X^2 BD(X^3).

The residue classes of powers modulo three are disjoint. Evaluate at `R`,
perform one integer product, and decode `6r` centered lanes. Reconstruct the
real part from lanes 0 minus 2, and the imaginary part from lane 1. Each
coefficient is bounded by `2rQ^2`, so the same strict separation proof applies.
The operands now have at most `3rw` bits. The product count falls from four to
one, but the individual operands can be longer. This variant is an explicitly
benchmarked alternative, **not** a claim that one product must be fastest.

`four_narrow` is a control retaining four products at the shorter width. It
separates the benefit of the smaller base from the benefit of product fusion.

## Fully stated component costs

Write `M(t)` for the actual bit cost of the supplied integer backend at `t`
bits, and retain the norm-check cost `C_norm(r,p)=O(r M(O(p)))`.
For a sequential block implementation, with all packing, decoding, additions
and folding charged, the respective upper bounds are

    v10:   C_norm(r,p) + 4 M(4pr) + O(pr),
    three: C_norm(r,p) + 3 M(rw)  + O(rw),
    one:   C_norm(r,p) +   M(3rw) + O(rw).

These are component accounting statements, not complete fixed-tape bounds
for the Python program. Coefficient additions use O(w) bits. The input codec,
centered extraction and output formatting each require a constant number of
passes over O(rw) bits. Parameter calculation is charged separately as small
integer setup. Diagnostic global counters are disabled in ordinary execution;
finite audited tests count actual operand sizes and codec volumes.

At `p=128,r=32`, `ell=5`, the lane shrinks from 512 to 264 bits. The upper
budget for the sum of the three-product operands is 38.671875% of the old
four-product budget. This is **not** a guaranteed 2.59x runtime speedup:
backend thresholds, extra additions, norm checks and the surrounding transforms
still cost time. The asymptotic exponent is unchanged.

## Integration, provenance and limits

The only edited inherited source is `fast_resampled.py`, which adds explicit
kernel injection hooks while retaining v10 defaults. `multiply_packed_finite`
is the opt-in complete finite-reduction entrypoint. Its default integer backend
is still `RecursiveFermatMultiplier`, not a hidden native whole-input product.
Native arithmetic is only selected explicitly through `operator.mul` in controls.

The algebraic identities are standard. The work here is their safe integration
with this checkpoint's exact signed codecs, backend injection, normalization,
coefficient bounds, adversarial tests, and operation accounting. No priority or
publication claim is made. Reducing large kernel products does not remove the
rank-network, numerical parameter, tape implementation or output obligations.
