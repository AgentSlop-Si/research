"""Measure the new network machinery, with explicit limits on what is tested."""
from collections import Counter
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import random
import sys
from network_frames import ComplexNetwork, Gate
from phase_layers import explicit_c_numerators
from recursive_network import recursive_c_numerators
from test_recursive_network import SmallControlNetwork


def main():
    gc.disable()
    root=Path(__file__).resolve().parent
    report=dict(scope="Component benchmark; small control has NO rank saving; no full h=100 execution or integer speedup claimed",
                python=sys.version,platform=platform.platform(),gc_disabled=True,recursive_controls=[])
    network=ComplexNetwork(100)
    space=network.gate_label(2,(0,1),1)
    gate=Gate(2,(0,1),1,space,(),())
    role=("C",2,(0,1),0)
    count=inverse=maximum_factor_bits=0
    start=perf_counter_ns()
    for direction,negative in network.residual_directions(role,gate):
        count+=1
        inverse+=negative
        maximum_factor_bits=max(maximum_factor_bits,sum(v.bit_length() for v in direction.factors))
        if direction.dot(direction)!=1: raise AssertionError("non-unit direction")
    duration=perf_counter_ns()-start
    if count!=999900 or count!=space.dimension: raise AssertionError("fixed residual count")
    report["fixed_h100_streamed_residual"]=dict(directions=count,inverse_kernels=inverse,
        maximum_factor_bits=maximum_factor_bits,duration_ns=duration,
        method="Stream every compact direction of one actual largest h=100 edge; no dense ambient matrix")
    print(json.dumps({"h100_directions":count,"seconds":duration/1e9}),flush=True)
    for depth in (1,2,3):
        control=SmallControlNetwork()
        e=2**depth
        rows=2**depth
        suffix=1<<(e+1)
        rng=random.Random(78337+depth)
        values=[[(rng.randrange(-100,101),rng.randrange(-100,101))] for _ in range(rows*suffix)]
        bits=tuple(range(1,e+1))
        expected=explicit_c_numerators(values,bits,Counter())
        samples=[]
        details=None
        for _ in range(5):
            ledger=Counter()
            start=perf_counter_ns()
            got=recursive_c_numerators(values,bits,ledger,network=control,rows=rows,suffix_records=suffix)
            samples.append(perf_counter_ns()-start)
            if got!=expected: raise AssertionError("recursive output mismatch")
            details=dict(ledger)
        report["recursive_controls"].append(dict(depth=depth,selected_axes=e,rows=rows,records=len(values),
            median_ns=median(samples),samples_ns=samples,ledger=details))
        print(json.dumps({"depth":depth,"median_ms":median(samples)/1e6}),flush=True)
    report["source_sha256"]={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
        ("network_frames.py","recursive_edges.py","recursive_network.py","phase_layers.py","packed_bits.py",
         "test_recursive_network.py","benchmark_network.py")}
    (root/"network_benchmarks.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")


if __name__=="__main__": main()
