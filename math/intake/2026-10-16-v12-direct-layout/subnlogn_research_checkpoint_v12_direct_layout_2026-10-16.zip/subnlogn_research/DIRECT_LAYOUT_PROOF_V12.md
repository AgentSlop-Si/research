# v12: removing a redundant tensor-axis layout factor

**Date:** 16 October 2026. **Status:** proved local scheduling improvement and
exact finite implementation; conditional transfer to the inherited asymptotic
cost table. Not an independently verified complete multiplication theorem.
No worldwide novelty or priority claim is made.

## What is borrowed, and what changes

The pinned OpenAI source already supplies equal-width chunk swaps with arbitrary
prefix, gap and suffix, and explicitly gives the one-extra-bit construction for
nonadjacent unequal-width chunks. Those are inherited primitives, NOT new v12
mathematics. See section 04, particularly its final paragraph.

Sections 07 and 08 nevertheless use neighboring-axis schedules with O(d^2)
interchanges for Gaussian exposure/restoration and CRT axis reversal. The v10/
v11 Python schedules do the same. The v12 change is to use those already
available nonadjacent swaps directly, reducing the number of interchanges to
O(d), while preserving the same logical axis-processing order and arithmetic.

The shared primitive is not a free random-access transpose. Every call is made
to `binary_chunk_swap`; the unequal-width correction calls `move_digit` with
radix two. Existing padding, unpadding, row operations, and diagnostic charges
remain inside these routines.

## 1. Inherited swap contract

Assume the section-04 chunk routine swaps two disjoint, contiguous u-bit address
fields in a complete Cartesian record stream of V bits in O(V u^tau) time,
0 < tau < 1. All other fields are preserved. The constant is independent of
prefix, gap and suffix lengths. A single address-bit move costs O(V), with a
fixed number of sequential tapes. These are inherited cost assumptions; finite
tests do not independently prove the full rank-saving routine.

For two fields of bit widths a,b with |a-b|<=1 and intervening fields M:

* a=b: swap the two equal-width fields, retaining M.
* a=b+1: e X M Y -> e Y M X -> Y M e X.
* b=a+1: X M e Y -> e X M Y -> e Y M X.

This is exactly the source's inherited nonadjacent construction. Each case uses
one equal-width swap and at most one single-bit move. In particular the gap M
is not moved across the final pair and its fields do not reverse. The cost is
O(V(1+max(a,b)^tau)). `swap_axes` implements these cases, explicitly charging
the existing routines and preserving the record width.

## 2. CRT reversal

For fields A_0,...,A_(d-1), exchange A_i with A_(d-1-i),
0<=i<floor(d/2). Each pair is disjoint, and every other position is a spectator.
The final order is A_(d-1),...,A_0. There are exactly floor(d/2) swaps.

For the inherited t_i in {2^ell,2^(ell-1)}, every pair meets the neighboring-bit-
width requirement. Therefore reversal costs

    O(V d (1+ell^tau)),

not O(V d^2 (1+ell^tau)). The padding, controlled CRT rotations, inverse
rotations, and zero-padding checks are unchanged. The d controlled rotations
cost O(dV), absorbed above. Per-prefix offset setup has the same inherited
O(d T poly(p)/r)=o(Tp) bound.

This argument covers arbitrary record values. It does not depend on repeated,
sparse, special, or cached numerical inputs.

## 3. Gaussian exposure and restoration

Keep the numerical axes in exactly the same requested order as before. For the
next axis i, exchange physical field i with the final field. Update the shape
and physical-to-logical descriptor. Apply the SAME one-dimensional routine,
with the SAME logical source/target lengths and validity rules. Then swap the
two fields back before processing the next axis.

For fixed values of all other logical coordinates, the final contiguous line
contains exactly the original axis-i samples, in their original order. The
order of different independent lines can change, but not the arithmetic within
a line. Thus this is conjugation of a linewise map by an exact permutation.
It does not assume that rounded numerical axis operations commute: their
logical order is unchanged. Validity and zero-padding conditions are evaluated
using the updated descriptor.

All axes except the final axis need two swaps. Therefore one complete tensor
expansion or compression needs exactly 2(d-1) swaps, instead of d(d-1).
The sequential line scans and codecs remain O(dV), within the new layout bound.
Exact record permutations introduce no numerical error, so the inherited line
norm, grid, truncation, and recovery error estimates do not change.

## 4. Uniform descriptors and memory movement

No new family of tapes or heads depends on d. Reuse the same swap workspace and
line workspace. On completion, the inherited swap contract restores its
workspace. Shape and logical-axis descriptors have O(d ell)=O(p) bits. Preparing
and updating them a polynomial number of times is polynomial in p and is o(V)
in the inherited assembly. Preparing validity data once per line remains
O(d T poly(p)/r)=o(V), since r exceeds every fixed power of p.

This is a compositional argument conditional on the original complete primitive
contracts. The executable Python diagnostics do not themselves certify all
finite-alphabet control operations, and the tested small circuit is not the
rank-saving h=100 circuit.

## 5. Changed assembly row

Use V=Tp=Theta(N), p=Theta(log N), d=Theta(p^epsilon), and
ell=Theta(p^(1-epsilon)). Only the CRT/axis layout row changes:

    old: O(V d^2 (1+ell^tau))
           = O(V p^(tau+epsilon(2-tau)))
    new: O(V d   (1+ell^tau))
           = O(V p^(tau+epsilon(1-tau))).

Since ell>=1, the linear-in-d part is absorbed by d ell^tau. The new fourth
margin below exponent one is

    g4_new = (1-tau)(1-epsilon),

replacing

    g4_old = 1-tau-epsilon(2-tau).

The other six cost rows and the internal layer/movement conditions are retained,
not dropped. In particular the synthetic-transform layout row
p K^(tau-1) still exists. This scheduling change does NOT remove all movement
costs or establish O(N) multiplication.

## 6. An exact feasible conditional parameter choice

Let L=13815511/1000000 be the certified upper bound on ln(100^3), and let

    a = eta_bit/L, b = eta_complex/L,
    tau = 1-a, sigma = 1-b,
    beta = 1/2, delta = 1/16,
    lambda = 1-a^2, lambda' = 1-a^2/2,
    c = a(1-2a)/(2(1-a)), epsilon = 1/40,
    kappa = epsilon*c*a/2
          = a^2(1-2a)/(160(1-a)).

The exact rank deficits eta are unchanged from the h=100 networks. The same
positive rational exponential partial-sum certificate establishes L. The
program checks all layer, guard, Gaussian, dimensional, scalar and layout
conditions and verifies all seven margins >=2*kappa with exact fractions.
It also verifies that this parameter choice FAILS the old layout constraint;
the gain depends on the proved schedule replacement, not optimistic tuning.

Numerically, for display only:

    a             = 1.086344955809837e-12
    kappa_v11     = 3.205112405573184e-37
    kappa_v12     = 7.375908518826216e-27
    ratio         = 23012948020.171387 approximately.

The exact ratio is 1/[40a(1-a)]. Along this parameter family, the saving changes
from order a^3 to order a^2. This is not a 23-billion-fold runtime speedup.
Both exponents remain extremely small.

The necessary condition K=floor(d^c)>=2 becomes

    log2(ceil(log2 N)) >= 1/(epsilon*c)
                        ~= 7.364143366454844e13.

This is only a necessary asymptotic threshold, not a sufficient crossover or a
feasible input size. No practical victory follows from these exponent figures.

## 7. Conditional theorem and its boundary

Assume the complete inherited rank-recursion, layout, layer, numerical precision,
Gaussian resampling, arithmetic, uniform setup and tape-cleanup contracts, with
the retained parameter hypotheses and cost table. Replace both quadratic axis
schedules by the direct schedules above. Then the revised table has every
normalized cost bounded by p^(1-2*kappa), before remaining fixed polylog(p)
factors. Such factors fit within the positive kappa slack for sufficiently
large p. The derived bound is consequently

    O(N (log N)^(1-kappa)), kappa as above.

This is a conditional transfer theorem. It is not a fresh independent proof of
every imported contract, not a proof of this whole Python program's tape time,
and not an algorithmic result for arbitrary complex DFT inputs. N is integer
input BIT LENGTH, not the number of DFT coefficients. The only new proof here
is the schedule replacement and its cost-table consequence. The nonadjacent
swap primitive and the asymptotic framework remain credited to their sources.

## Primary source locations

Pinned repository: `openai/math`, revision
`1581d4cbdd69a0faf34b2089614fe2a814316a6a`.
Base path: `preprints/Integer-multiplication-below-n-log-n-September-23-2026/build/sections/`.

* `04-swap.tex`, final paragraph: arbitrary gap and unequal-width nonadjacent swaps.
* `07-resampling.tex`, tensor map proof: neighboring exposure/restoration O(d^2).
* `08-assembly.tex`, CRT layout and complete time bound: O(d^2) schedules and fourth cost margin.
* Uploaded `parameter_certificate_v11.py`: unchanged rank constants and exact log certificate.

The source files were inspected via the GitHub connector in this turn. Their
hash manifest in the inherited checkpoint remains historical; this release does
not claim to have re-downloaded and rehashed every original source.
