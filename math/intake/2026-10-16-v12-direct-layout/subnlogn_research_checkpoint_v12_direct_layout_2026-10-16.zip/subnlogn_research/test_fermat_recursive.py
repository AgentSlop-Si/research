"""Independent native products/DFTs are oracles, never backend operations."""
from collections import Counter
import random
import unittest

from fermat_recursive import FermatPlan,FermatRing,RecursiveFermatMultiplier,streamed_fft
from multiply_resampled import multiply_resampled
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl

COUNTS = Counter()


class FermatPrimitiveTests(unittest.TestCase):
    def test_recurrence_and_slack_certificate(self):
        from fermat_certificate import certificate,slack_certificate
        from cost_certificate import improved_parameters
        from fractions import Fraction
        result = certificate()
        self.assertGreater(result["sample_plan_nodes"],1000)
        for parameters in (result["original"],result["improved"]):
            self.assertGreaterEqual(Fraction(parameters["additional_margin"]),0)
            self.assertGreater(int(parameters["sufficient_log2_precision"]),16)
        self.assertGreater(int(slack_certificate(improved_parameters(),3)["sufficient_log2_precision"]),
                           int(result["improved"]["sufficient_log2_precision"]))
        COUNTS["recursive_fermat_recurrence_sample_nodes"] += result["sample_plan_nodes"]
        COUNTS["recursive_fermat_slack_certificates"] += 3

    def test_all_small_modular_shifts(self):
        for n in (1,2,3,4,5,8):
            ring = FermatRing(n,Counter())
            for value in range(ring.q):
                for shift in range(-2*n,2*n+1):
                    expected = value*pow(2,shift,ring.q) % ring.q
                    self.assertEqual(ring.shift(value,shift),expected)
                    COUNTS["recursive_fermat_shift_checks"] += 1

    def test_streamed_transform_defining_sum(self):
        rng = random.Random(901)
        for n,L in ((4,4),(8,8),(12,8),(24,16),(36,8),(80,32)):
            ring = FermatRing(n,Counter())
            values = [rng.randrange(ring.q) for _ in range(L)]
            values[0] = ring.q-1
            root = pow(2,2*n//L,ring.q)
            expected = [sum(v*pow(root,j*k,ring.q) for j,v in enumerate(values)) % ring.q
                        for k in range(L)]
            def reverse(j):
                out = 0
                for _ in range(L.bit_length()-1): out,j = (out << 1)|(j&1),j>>1
                return out
            actual = streamed_fft(values,ring)
            self.assertEqual(actual,[expected[reverse(j)] for j in range(L)])
            restored = streamed_fft(actual,ring,inverse=True)
            restored = [ring.shift(v,-(L.bit_length()-1)) for v in restored]
            self.assertEqual(restored,values)
            COUNTS["recursive_fermat_defining_transforms"] += 1

    def test_plan_descent_and_capacity(self):
        for log_n in range(5,301):
            n = 1 << log_n
            while n>16:
                plan = FermatPlan.make(n)
                self.assertEqual(plan.length*plan.digit_bits,n)
                self.assertEqual(plan.child_exponent % plan.length,0)
                self.assertGreaterEqual(plan.child_exponent,2*plan.digit_bits+plan.log_length+2)
                self.assertLess(plan.child_exponent,n)
                self.assertLessEqual(plan.length*plan.child_exponent,(3 if n>=32 else 4)*n)
                if plan.child_exponent>16:
                    child = FermatPlan.make(plan.child_exponent)
                    self.assertLessEqual(child.length,plan.length)
                n = plan.child_exponent
                COUNTS["recursive_fermat_plan_nodes"] += 1


class FermatProductTests(unittest.TestCase):
    def test_default_disables_growing_global_audit_state(self):
        for bits in (16,1024,4096):
            a,b = (1 << bits)-7,(1 << (bits-1))+3
            normal = RecursiveFermatMultiplier(128)
            audited = RecursiveFermatMultiplier(128,ledger=Counter())
            self.assertEqual(normal(a,b),audited(a,b))
            self.assertEqual(normal.ledger,{})
            self.assertEqual((normal.operand_bits,normal.result_bits),(0,0))
            self.assertGreater(audited.ledger["fermat_integer_calls"],0)
            COUNTS["recursive_fermat_audit_mode_comparisons"] += 1

    def test_exhaustive_small_residues(self):
        multiplier = RecursiveFermatMultiplier(16)
        for n in range(1,6):
            q = (1 << n)+1
            for a in range(q):
                for b in range(q):
                    self.assertEqual(multiplier.modular(a,b,n),a*b % q)
                    COUNTS["recursive_fermat_exhaustive_residues"] += 1

    def test_recursive_modular_products_and_stacks(self):
        rng = random.Random(6431)
        for n in (20,24,32,36,64,68,128,256,512,1024):
            q = (1 << n)+1
            cases = [(0,q-1),(q-1,q-1),(q-2,q-2),(q//2,q//2)]
            cases += [(rng.randrange(q),rng.randrange(q)) for _ in range(3)]
            for a,b in cases:
                ledger = Counter()
                multiplier = RecursiveFermatMultiplier(16,ledger=ledger)
                self.assertEqual(multiplier.modular(a,b,n),a*b % q)
                self.assertEqual((multiplier.operands,multiplier.results),([],[]))
                self.assertEqual(ledger["fermat_operand_push_bits"],ledger["fermat_operand_pop_bits"])
                self.assertEqual(ledger["fermat_result_push_bits"],ledger["fermat_result_pop_bits"])
                self.assertLessEqual(ledger["fermat_max_leaf_exponent"],16)
                self.assertLessEqual(ledger["fermat_peak_operand_stack_bits"],40*n)
                self.assertLessEqual(ledger["fermat_peak_result_stack_bits"],40*n)
                if a<q-1 and b<q-1:
                    self.assertGreater(ledger["fermat_internal_nodes"],0)
                COUNTS["recursive_fermat_modular_products"] += 1

    def test_ordinary_products(self):
        rng = random.Random(2384)
        for bits in (1,7,16,63,128,257,512,1024,2048,4096):
            for a,b in ((0,(1 << bits)-1),(1,(1 << bits)-1),
                        ((1 << bits)-1,(1 << bits)-1),(rng.getrandbits(bits),rng.getrandbits(bits))):
                multiplier = RecursiveFermatMultiplier(128,ledger=Counter())
                self.assertEqual(multiplier(a,b),a*b)
                self.assertLessEqual(multiplier.ledger["fermat_max_leaf_exponent"],128)
                COUNTS["recursive_fermat_integer_products"] += 1

    def test_resampled_reduction_with_recursive_backend(self):
        from guarded_layer import make_guarded_network_layer
        from network_frames import ComplexNetwork
        from packed_stream import make_stream_layout_move
        multiplier = RecursiveFermatMultiplier(1024,ledger=Counter())
        a,b = 0xdeadbeef,0xfedcba98
        circuit = CompiledBitCircuit(SwapControl())
        layer = make_guarded_network_layer(ComplexNetwork(100),192,swap_circuit=circuit)
        movement = make_stream_layout_move(circuit,component_bytes=25)
        value,diagnostics = multiply_resampled(a,b,sources=(3,5),targets=(4,8),
            p=192,alpha=6,digit_bits=4,circuit=circuit,layer=layer,layout_move=movement,
            integer_multiply=multiplier)
        self.assertEqual(value,a*b)
        ledger = diagnostics["ledger"]
        self.assertEqual(multiplier.ledger["fermat_integer_calls"],
                         ledger["integer_multiplications"]+ledger["scalar_integer_multiplications"])
        self.assertGreater(multiplier.ledger["fermat_internal_nodes"],0)
        self.assertGreater(multiplier.ledger["fermat_max_depth"],1)
        self.assertEqual(ledger.get("reference_permutation_records",0),0)
        self.assertEqual(ledger.get("adaptive_layout_codec_calls",0),0)
        COUNTS["resampled_recursive_backend_products"] += 1

    def test_invalid_inputs_and_reuse_after_error(self):
        multiplier = RecursiveFermatMultiplier(16)
        for action in (lambda: RecursiveFermatMultiplier(15),
                       lambda: RecursiveFermatMultiplier(4097),
                       lambda: FermatPlan.make(19),
                       lambda: multiplier(-1,5),
                       lambda: multiplier.modular(0,1,0),
                       lambda: multiplier.modular(1 << 25,1,24),
                       lambda: streamed_fft([0]*3,FermatRing(12,Counter())),
                       lambda: multiplier.modular(2,3,19)):
            with self.assertRaises(ValueError): action()
            self.assertEqual(multiplier(5,7),35)
            self.assertFalse(multiplier.active)
            self.assertEqual((multiplier.operands,multiplier.results),([],[]))
            COUNTS["negative_controls"] += 1


if __name__ == "__main__": unittest.main(verbosity=2)
