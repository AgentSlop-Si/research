"""Executable Gaussian/chirp/twist source transforms; no Fourier oracle.

All scalar values are integer pairs at precision p. Backends are injectable;
the default explicit layer and native integer products have no sub-N-log-N
guarantee. Finite error bounds do not use eventual large-input inequalities.
"""
from collections import Counter
from itertools import product
from math import prod
from operator import mul

from certified_phase import CertifiedPhase
from gaussian_tensor import GaussianTensor
from synthetic import (Layout,direct_layer,normalized_convolution,
                       normalized_ring_product,trunc_shift)


def check_norm(values,p,numerator=1,denominator=1):
    if denominator <= 0 or numerator < 0: raise ValueError("invalid norm bound")
    for z in values:
        if (not isinstance(z,(tuple,list)) or len(z)!=2
                or any(type(v) is not int for v in z)
                or (z[0]*z[0]+z[1]*z[1])*denominator**2 > numerator**2*(1 << (2*p))):
            raise ValueError("coefficient exceeds the declared disk norm")


def integer_product(a,b,ledger,integer_multiply=mul):
    value = integer_multiply(abs(a),abs(b))
    ledger["scalar_integer_multiplications"] += 1
    ledger["scalar_integer_operand_bits_sum"] += abs(a).bit_length()+abs(b).bit_length()
    ledger["scalar_integer_max_bits"] = max(ledger["scalar_integer_max_bits"],
                                            abs(a).bit_length(),abs(b).bit_length())
    return -value if (a<0)!=(b<0) else value


def grid_product(z,w,p,ledger,integer_multiply=mul):
    products = [integer_product(a,b,ledger,integer_multiply)
                for a,b in ((z[0],w[0]),(z[1],w[1]),(z[0],w[1]),(z[1],w[0]))]
    a,b,c,d = products
    ledger["scalar_truncated_components"] += 2
    return trunc_shift(a-b,p),trunc_shift(c+d,p)


class CyclicConvolver:
    def __init__(self,targets,p,*,chunk_bits=1,layer=direct_layer,layout_move=None,
                 integer_multiply=mul,ledger=None):
        self.targets = tuple(targets)
        if (not self.targets or type(p) is not int or p<2
                or any(type(t) is not int or t<2 or t & (t-1) for t in self.targets)):
            raise ValueError("positive power-of-two tensor and precision required")
        self.r = self.targets[-1]
        if any(t not in (self.r//2,self.r) for t in self.targets) or self.r >= 1 << p:
            raise ValueError("last axis must be largest, with neighboring binary widths")
        self.T,self.M,self.p = prod(self.targets),prod(self.targets[:-1]),p
        self.ledger = ledger if ledger is not None else Counter()
        self.phase = CertifiedPhase(self.ledger)
        self.layer,self.layout_move,self.integer_multiply = layer,layout_move,integer_multiply
        self.layout = Layout(self.targets[:-1],self.r,chunk_bits) if len(self.targets)>1 else None
        ell = self.r.bit_length()-1
        self.ring_error = 2*self.M*(3*ell+1)
        self.error = self.ring_error+12
        self.chirp_error = self.error+10
        if 1000*self.ring_error >= 1 << p:
            raise ValueError("precision does not provide the ring output disk margin")

    def _product(self,z,w): return grid_product(z,w,self.p,self.ledger,self.integer_multiply)

    def _twist(self,values,opposite):
        out = []
        for address,z in enumerate(values):
            k = address % self.r
            phase = self.phase.grid(-k if opposite else k,2*self.r,self.p).value
            out.append(self._product(phase,z))
        self.ledger["coefficient_twist_calls"] += 1
        return out

    def convolve(self,f,g):
        if len(f)!=self.T or len(g)!=self.T: raise ValueError("cyclic tensor size mismatch")
        check_norm(f,self.p)
        check_norm(g,self.p)
        smaller = any(all((x*x+y*y)*100 <= 49*(1 << (2*self.p)) for x,y in v) for v in (f,g))
        if not smaller: raise ValueError("one cyclic operand must have norm <=0.7")
        f,g = self._twist(f,False),self._twist(g,False)
        # The coefficient suffix is already contiguous; grouping changes no
        # address order and introduces no synthetic coefficient permutation.
        f = [f[j:j+self.r] for j in range(0,self.T,self.r)]
        g = [g[j:j+self.r] for j in range(0,self.T,self.r)]
        if self.layout is None:
            h = [normalized_ring_product(f[0],g[0],self.p,
                    integer_multiply=self.integer_multiply,ledger=self.ledger)]
        else:
            h = normalized_convolution(f,g,self.layout,self.p,layer=self.layer,
                layout_move=self.layout_move,integer_multiply=self.integer_multiply,ledger=self.ledger)
        h = [z for row in h for z in row]
        check_norm(h,self.p,701,1000)
        out = self._twist(h,True)
        check_norm(out,self.p,701,1000)
        self.ledger["normalized_complex_convolution_calls"] += 1
        return out

    def chirp(self,values,sources):
        sources = tuple(sources)
        if len(values)!=self.T or len(sources)!=len(self.targets) or any(type(s) is not int or s<1 for s in sources):
            raise ValueError("chirp source descriptor or tensor size")
        check_norm(values,self.p,3,5)
        phases = []
        for coordinates in product(*(range(t) for t in self.targets)):
            numerator = -sum(s*j*j*(self.r//t) for s,j,t in zip(sources,coordinates,self.targets))
            phases.append(self.phase.grid(numerator % (2*self.r),2*self.r,self.p).value)
            self.ledger["chirp_coordinate_terms"] += len(sources)
        conjugates = [(a,-b) for a,b in phases]
        operand = [self._product(a,z) for a,z in zip(conjugates,values)]
        middle = self.convolve(phases,operand)
        out = [self._product(a,z) for a,z in zip(conjugates,middle)]
        check_norm(out,self.p,701,1000)
        self.ledger["permuted_chirp_calls"] += 1
        return out


class SourceTransform:
    def __init__(self,sources,targets,p,alpha,circuit,*,chunk_bits=1,layer=direct_layer,
                 layout_move=None,integer_multiply=mul,ledger=None):
        self.ledger = ledger if ledger is not None else Counter()
        self.gaussian = GaussianTensor(sources,targets,p,alpha,circuit,ledger=self.ledger)
        self.convolver = CyclicConvolver(targets,p,chunk_bits=chunk_bits,layer=layer,
            layout_move=layout_move,integer_multiply=integer_multiply,ledger=self.ledger)
        self.sources,self.targets,self.p = tuple(sources),tuple(targets),p
        self.gamma = self.gaussian.gamma
        self.error = (1 << self.gamma)*(2*len(self.sources)*p*p+self.convolver.chirp_error)
        if 1000*self.error >= 1 << p:
            raise ValueError("precision does not provide the source-transform disk margin")

    def apply(self,padded,*,opposite=False):
        check_norm(padded,self.p,1,2)
        data = [(a,-b) for a,b in padded] if opposite else padded
        expanded = self.gaussian.apply(data)
        middle = self.convolver.chirp(expanded,self.sources)
        compressed = self.gaussian.apply(middle,inverse=True)
        scaled = [(a << self.gamma,b << self.gamma) for a,b in compressed]
        self.ledger["source_exact_scale_components"] += 2*len(scaled)
        check_norm(scaled,self.p,501,1000)
        self.gaussian._check_box(scaled,self.sources)
        self.ledger["source_opposite_calls" if opposite else "source_forward_calls"] += 1
        return [(a,-b) for a,b in scaled] if opposite else scaled
