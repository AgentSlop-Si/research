"""Tighter exact h=100 certificate and scoped parameter-ceiling audit.

No network, analytic lemma, or full-machine theorem is certified here.
The only changed rank estimate is ln(10**6)<13.815511, proved with a
positive Taylor partial sum for exp. The old source assumptions remain.
"""
from fractions import Fraction as Q
from dataclasses import asdict
import json
from pathlib import Path
from cost_certificate import Parameters, improved_parameters, json_default
from motifs import Budget

L = Q(13815511, 1000000)


def exp_lower(x, terms=100):
    if x <= 0: raise ValueError('positive x required')
    total = term = Q(1)
    for k in range(1, terms):
        term *= x/k
        total += term
    return total


def parameters():
    a, b = (Budget(100, kind).deficit/L for kind in ('bit', 'complex'))
    return Parameters(1-a, 1-b, Q(1, 2), Q(1, 16),
                      1-a*a, 1-a*a/2,
                      a*(1-2*a)/(2*(1-a)), a*(1-a), a**3*(1-2*a)/4)


def independent_checks(v):
    a = 1-v.tau
    checks = {
        'certified_log_upper': exp_lower(L)>100**3,
        'bit_rank': 0<v.tau<1 and L*(1-v.tau)<=Budget(100,'bit').deficit,
        'complex_rank': 0<v.sigma<1 and L*(1-v.sigma)<=Budget(100,'complex').deficit,
        'fixed_beta': v.beta==Q(1,2),
        'internal_layer': max(v.tau,v.sigma)<v.lam<1,
        'movement_overhead': v.tau*(1+v.c/v.beta)<v.lam,
        'leaf_and_grouping': max(v.lam,v.sigma+v.beta*(1-v.sigma))<v.lam_prime<1,
        'positive': min(v.c,v.epsilon,v.delta,v.kappa)>0,
        'dimension': v.epsilon<Q(1,12),
        'guard': v.epsilon*v.guard_power<1,
        'axis_layout': v.epsilon*(2-v.tau)<1-v.tau,
        'gaussian': Q(3,4)+v.delta+Q(3,2)*v.epsilon<1,
        'prefix': v.epsilon*(1+v.c)<1,
        'scalar': v.epsilon+v.delta<1,
        'all_seven_margins': min(v.margins())>=2*v.kappa,
        'simple_kappa_identity': v.kappa==a**3*(1-2*a)/4,
        'below_scoped_ceiling': v.kappa<a**3/(4*(1-a*a)),
    }
    if not all(checks.values()): raise AssertionError(checks)
    return checks


def certificate():
    old, new = improved_parameters(), parameters()
    old.check()
    checks = independent_checks(new)
    a0 = 1-old.tau
    ceiling = a0**3/(4*(1-a0*a0))
    return {
        'status':'exact rational inequalities passed; conditional candidate only',
        'scope':'unchanged h=100 networks, beta=1/2, seven v10 cost margins',
        'log_upper':L,
        'log_upper_proof':'sum_{j=0}^{99} L^j/j! > 1000000; all omitted terms positive',
        'old_kappa':old.kappa,
        'new_parameters':asdict(new),
        'new_checks':checks,
        'new_margins':new.margins(),
        'new_kappa':new.kappa,
        'ratio_new_over_old':new.kappa/old.kappa,
        'old_fixed_tau_ceiling':ceiling,
        'old_fraction_of_scoped_ceiling':old.kappa/ceiling,
        'old_remaining_relative_room':ceiling/old.kappa-1,
        'necessary_log2_b_for_K_at_least_2':1/(new.epsilon*new.c),
        'ceiling_proof':[
            'tau*(1+2c)<lambda<1 implies c<a/(2*(1-a))',
            'epsilon*(1+a)<a implies epsilon<a/(1+a)',
            '2*kappa<=epsilon*c*a implies kappa<a^3/(4*(1-a^2))',
            'This is NOT a lower bound on multiplication and NOT a ceiling for other networks or cost models.'
        ],
        'full_multiplier_implemented':False,
        'new_arbitrary_DFT_algorithm':False,
    }


if __name__=='__main__':
    result=certificate()
    Path(__file__).with_name('parameter_certificate_v11.json').write_text(
        json.dumps(result,indent=2,default=json_default)+'\n')
    print(json.dumps({'kappa_v10':float(result['old_kappa']),
                      'kappa_v11':float(result['new_kappa']),
                      'ratio':float(result['ratio_new_over_old']),
                      'old_relative_room':float(result['old_remaining_relative_room']),
                      'necessary_log2_b':float(result['necessary_log2_b_for_K_at_least_2'])},indent=2))
