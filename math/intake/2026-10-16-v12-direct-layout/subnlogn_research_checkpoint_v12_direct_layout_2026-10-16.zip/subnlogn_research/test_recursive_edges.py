from collections import Counter
from itertools import product
import random
import unittest
from motifs import Gaussian as G, translation_kernel
from network_frames import (ComplexNetwork, Gate, apply_row_operations, basis_row_operations,
                            complete_basis, dot, independent_basis, orthonormal_basis)
from phase_layers import explicit_c_numerators
from recursive_edges import apply_residual_numerators, packed_basis_address

COUNTS=Counter()


class RecursiveEdgeTests(unittest.TestCase):
    def test_basis_move_with_packed_repair(self):
        rng=random.Random(78122)
        for m in (3,4,6,9):
            columns=complete_basis(independent_basis(rng.randrange(1,1<<m) for _ in range(m-1)),m)
            forward,inverse=basis_row_operations(columns)
            for k,f,rho in ((6,1,0),(6,3,0),(7,4,6),(9,7,4)):
                selected=sum(1<<(rho+j*k) for j in range(f))
                for values in [[0]*m,[(1<<(k*f))-1]*m,*[[rng.getrandbits(k*f) for _ in range(m)] for _ in range(20)]]:
                    got=packed_basis_address(values,forward,k,f,rho)
                    expected=list(values)
                    for column in range(f):
                        bit=rho+column*k
                        vector=sum(((v>>bit)&1)<<row for row,v in enumerate(values))
                        result=apply_row_operations(vector,forward)
                        for row in range(m):
                            expected[row]=(expected[row]&~(1<<bit))|(((result>>row)&1)<<bit)
                    self.assertEqual(got,expected)
                    self.assertEqual(packed_basis_address(got,inverse,k,f,rho),values)
                    self.assertTrue(all((x&~selected)==(y&~selected) for x,y in zip(values,got)))
                    COUNTS["packed_basis_changes"]+=1

    def test_residual_children_against_directional_kernel(self):
        rng=random.Random(76115)
        for m in (3,4):
            for f in (1,2):
                # One spectator bit is deliberately interspersed between slots.
                positions=[i for i in range(m*f+1) if i!=1]
                slots=tuple(tuple(positions[row*f:row*f+f]) for row in range(m))
                size=1<<(m*f+1)
                for rank in range(1,m+1):
                    basis=[1<<i for i in range(m)]
                    for _ in range(8):
                        u=rng.randrange(1<<m)
                        if u.bit_count()%2==0:
                            basis=[v^(u if dot(u,v) else 0) for v in basis]
                    directions=basis[:rank]
                    flags=[bool(i%2) for i in range(rank)]
                    records=[[(rng.randrange(-9,10),rng.randrange(-9,10))] for _ in range(size)]
                    ledger=Counter()
                    calls=[]
                    def child(values,bits,ledger):
                        calls.append(tuple(bits))
                        return explicit_c_numerators(values,bits,ledger)
                    got,extra=apply_residual_numerators(records,directions,flags,slots,ledger,child=child)
                    exact=[G(*poly[0]) for poly in records]
                    for direction,inverse in zip(directions,flags):
                        for column in range(f):
                            address_direction=sum(1<<slots[row][column] for row in range(m) if (direction>>row)&1)
                            exact=translation_kernel(exact,address_direction,inverse=inverse)
                    self.assertEqual([G(*poly[0]) for poly in got],[value*(1<<extra) for value in exact])
                    self.assertEqual(extra,rank*f)
                    self.assertEqual(len(calls),rank)
                    self.assertTrue(all(len(bits)==f for bits in calls))
                    COUNTS["recursive_residual_executions"]+=1

    def test_constructive_fixed_network_basis_prefix(self):
        from itertools import islice
        network=ComplexNetwork(100)
        # Largest central-source residual: (h**2-1)*h = 999900 directions.
        # Prefix inspection verifies actual h=100 descriptors with compact
        # 300-bit tensor factors, without materializing a million-square matrix.
        role=("C",2,(0,1),0)
        space=network.gate_label(2,(0,1),1)
        gate=Gate(2,(0,1),1,space,(),())
        directions=list(islice(network.residual_directions(role,gate),150))
        self.assertEqual(space.dimension,999900)
        self.assertEqual(len(directions),150)
        for i,(direction,negative) in enumerate(directions):
            self.assertLessEqual(sum(v.bit_length() for v in direction.factors),300)
            self.assertEqual(negative,direction.weight%4==3)
            for j,(other,_) in enumerate(directions): self.assertEqual(direction.dot(other),int(i==j))
        COUNTS["fixed_network_compact_basis_prefix"]+=len(directions)


if __name__=="__main__": unittest.main()
