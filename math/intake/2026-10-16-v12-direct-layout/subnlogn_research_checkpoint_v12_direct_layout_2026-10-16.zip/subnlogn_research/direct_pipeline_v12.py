"""Opt-in v12 layout integration. Existing v11 defaults are unchanged."""
from functools import partial
from operator import mul
from direct_axes_v12 import DirectCRTLayout, DirectFastGaussianTensor
from fast_resampled import FastArithmeticSourceTransform
from multiply_resampled import multiply_resampled
from packed_gaussian_v11 import normalized_packed_product
from fermat_recursive import NullLedger, RecursiveFermatMultiplier


def multiply_direct_finite(x, y, *, packing='three', integer_multiply=None,
                           ledger=None, **parameters):
    if packing not in ('three', 'one', 'four_narrow'):
        raise ValueError('unknown packing variant')
    backend = integer_multiply if integer_multiply is not None else RecursiveFermatMultiplier()
    ledger = ledger if ledger is not None else NullLedger()
    factory = partial(FastArithmeticSourceTransform,
                      gaussian_factory=DirectFastGaussianTensor,
                      ring_product=partial(normalized_packed_product, mode=packing))
    value, diagnostics = multiply_resampled(x, y, integer_multiply=backend,
        transform_factory=factory, crt_factory=DirectCRTLayout, ledger=ledger,
        **parameters)
    diagnostics['implementation_status'].update(
        layout='v12 nonadjacent swaps; v11 packing, explicit finite parameters',
        integer_backend='explicit native control' if backend is mul else type(backend).__name__,
        sub_n_log_n_proved_for_implementation=False)
    return value, diagnostics
