"""Component/integration timings with explicit test-network and branch scope."""
from collections import Counter
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import random
import sys

SOURCES=("benchmark_packed_stream.py","packed_stream.py","packed_bits.py","stream_moves.py",
         "swap_recursion.py","bit_frames.py","motifs.py","phase_layers.py","network_frames.py",
         "recursive_edges.py","recursive_network.py","synthetic.py",
         "test_packed_stream.py","test_stream_swap.py","test_recursive_network.py")


def main():
    root=Path(__file__).resolve().parent
    def hashes(): return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in SOURCES}
    before=hashes()
    from packed_stream import make_packed_basis_move, make_stream_layout_move, Rectangle, rotate_named_chunk
    from recursive_edges import explicit_basis_move
    from recursive_network import make_network_layer
    from swap_recursion import CompiledBitCircuit
    from synthetic import Layout, normalized_convolution
    from test_packed_stream import TwoRoleRotatedControl
    from test_stream_swap import SwapControl, scatter
    gc.disable()
    report=dict(python=sys.version,platform=platform.platform(),gc_disabled=True,
        scope="Component and integration benchmarks; separate no-saving controls; not a sub-N-log-N multiplier",
        timed_scope="Per-call width selection, record coding, padding, movement, numerical work and reconstruction included; fixed circuit compilation, inputs, oracle and comparison outside timer",
        limits=["No full h=100 network execution", "No full K>=6 f>=2 packed rectangle",
                "Symbol ledgers are not a complete fixed-tape time trace"],cases=[])
    started=perf_counter_ns()
    swap_circuit=CompiledBitCircuit(SwapControl())
    report["swap_control"]=dict(m=swap_circuit.m,wires=swap_circuit.wires,s=swap_circuit.rank_sum,
                                 compilation_ns=perf_counter_ns()-started,has_rank_saving=False)
    mover=make_packed_basis_move(swap_circuit)
    layout_move=make_stream_layout_move(swap_circuit)

    def measure(name,execute,expected,count,details):
        samples=[]
        final_ledger=None
        for _ in range(count):
            ledger=Counter()
            started=perf_counter_ns()
            actual=execute(ledger)
            samples.append(perf_counter_ns()-started)
            if actual!=expected: raise AssertionError(name+" disagrees with independent oracle")
            final_ledger=dict(ledger)
        report["cases"].append(dict(name=name,repetitions=count,samples_ns=samples,median_ns=median(samples),
                                    ledger=final_ledger,**details))
        print(json.dumps({"case":name,"repetitions":count,"median_ms":median(samples)/1e6}),flush=True)

    records=[[(i%131-65,37-i%73)] for i in range(1<<18)]
    slots=((12,),(6,),(0,))
    operations=((1,0),)
    expected=explicit_basis_move(records,slots,operations,Counter())
    measure("real_K6_f1_gaussian_basis",lambda ledger:mover(records,slots,operations,ledger),expected,3,
            dict(records=len(records),K=6,f=1,branch="top-bit permutation only; no packed rotations"))

    rect=Rectangle(5)
    values=list(range(rect.volume))
    expected=scatter(values,rect.shape,lambda x:(x[0],x[1],x[2],(x[3]-(x[1]&~x[5]&21))%32,x[4],x[5],x[6]))
    measure("rotation_with_recursive_swaps",lambda ledger:rotate_named_chunk(values,rect,"y",21,0,-1,swap_circuit,ledger,16),
            expected,1,dict(records=len(values),chunk_bits=5,branch="full rotation using recursive no-saving chunk circuit"))

    rng=random.Random(482334)
    layout=Layout((4,)*6,4)
    operands=[[[(rng.randrange(-15,16),rng.randrange(-15,16)) for _ in range(4)]
                for _ in range(layout.size)] for _ in range(2)]
    expected=normalized_convolution(*operands,layout,10)
    layer=make_network_layer(TwoRoleRotatedControl(),basis_move=mover)
    measure("whole_stream_convolution",lambda ledger:normalized_convolution(*operands,layout,10,layer=layer,
                layout_move=layout_move,ledger=ledger),expected,3,
            dict(records=layout.size,coefficients=4,precision_bits=10,phase_control=dict(m=4,wires=2,s=8,has_rank_saving=False),
                 branch="non-coordinate recursive phase network; K=1 sequential fallback; streamed L and inverse L"))
    if before!=hashes(): raise RuntimeError("source changed during benchmark")
    report["source_sha256"]=before
    report["sources_unchanged_during_benchmark"]=True
    report["checked_outputs"]=7
    (root/"packed_stream_benchmarks.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")


if __name__=="__main__": main()
