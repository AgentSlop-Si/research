"""Common-format execution benchmarks with declared input-independent guards."""
from collections import Counter
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import random
import sys

SOURCES=("benchmark_guarded_layer.py","guarded_layer.py","packed_stream.py","packed_bits.py","stream_moves.py",
         "swap_recursion.py","bit_frames.py","motifs.py","phase_layers.py","network_frames.py",
         "recursive_edges.py","recursive_network.py","synthetic.py","test_guarded_layer.py",
         "test_packed_stream.py","test_stream_swap.py","test_recursive_network.py")


def main():
    root=Path(__file__).resolve().parent
    def hashes(): return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in SOURCES}
    before=hashes()
    from guarded_layer import make_guarded_network_layer
    from network_frames import ComplexNetwork
    from packed_stream import make_stream_layout_move
    from swap_recursion import CompiledBitCircuit
    from synthetic import Layout, direct_layer, normalized_convolution
    from test_packed_stream import TwoRoleRotatedControl
    from test_stream_swap import SwapControl
    gc.disable()
    circuit=CompiledBitCircuit(SwapControl())
    report=dict(python=sys.version,platform=platform.platform(),gc_disabled=True,
        scope="Common-format component checks, not a sub-N-log-N multiplier; controls have no rank saving",
        timing="Guard planning, format import, exact execution, fixed codec and export inside each timer; fixed network construction and oracle outside",
        cases=[])
    def measure(name,execute,expected,repeats,scope):
        samples=[]
        final=None
        for _ in range(repeats):
            ledger=Counter()
            start=perf_counter_ns()
            got=execute(ledger)
            samples.append(perf_counter_ns()-start)
            if got!=expected: raise AssertionError(name+" mismatch")
            if ledger["adaptive_basis_codec_calls"] or ledger["adaptive_layout_codec_calls"]:
                raise AssertionError("value-dependent width selected")
            if ledger["fixed_max_observed_signed_bits"]>ledger["guarded_peak_component_bits"]:
                raise AssertionError("guard bound exceeded")
            final=dict(ledger)
        report["cases"].append(dict(name=name,scope=scope,samples_ns=samples,median_ns=median(samples),ledger=final))
        print(json.dumps({"case":name,"median_ms":median(samples)/1e6,
                          "declared_component_bits":final["guarded_peak_component_bits"],
                          "observed_signed_bits":final["fixed_max_observed_signed_bits"]}),flush=True)
    rng=random.Random(955312)
    for name,network,d in (("noncoordinate_control",TwoRoleRotatedControl(),6),
                           ("actual_h100_small_width",ComplexNetwork(100),8)):
        p=16
        values=[[(rng.randrange(-500,501),rng.randrange(-500,501)) for _ in range(2)] for _ in range(1<<d)]
        bits=tuple(range(d))
        expected=direct_layer(values,bits,Counter())
        def execute(ledger):
            backend=make_guarded_network_layer(network,p,swap_circuit=circuit)
            return backend(values,bits,ledger)
        measure(name,execute,expected,3,"recursive no-saving control" if d==6 else "actual h100 individual-kernel branch only")
    layout=Layout((4,)*6,4)
    p=10
    values=[[[(rng.randrange(-15,16),rng.randrange(-15,16)) for _ in range(4)]
                for _ in range(layout.size)] for _ in range(2)]
    expected=normalized_convolution(*values,layout,p)
    def execute_convolution(ledger):
        backend=make_guarded_network_layer(TwoRoleRotatedControl(),p,swap_circuit=circuit)
        movement=make_stream_layout_move(circuit,component_bytes=(p+9)//8)
        return normalized_convolution(*values,layout,p,layer=backend,layout_move=movement,ledger=ledger)
    measure("common_format_stream_convolution",execute_convolution,expected,3,
            "no-saving phase/swap controls, exact half-scaled arithmetic, fixed codecs, numerical role parking; K=1 movement")
    if hashes()!=before: raise RuntimeError("sources changed during benchmark")
    report["source_sha256"]=before
    report["sources_unchanged_during_benchmark"]=True
    report["checked_outputs"]=9
    (root/"guarded_layer_benchmarks.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")


if __name__=="__main__": main()
