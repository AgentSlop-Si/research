"""Opt-in, exactly certified packing improvements to the v10 finite profile.

Three-product mode uses the classical Gauss/Karatsuba identity and shorter
signed lanes. One-product mode uses ordinary Kronecker substitution with
three residue-class lanes. Neither identity is claimed as novel. Neither
mode establishes a sub-n-log-n integer multiplier or a faster arbitrary DFT.
All growing products use the supplied FastArithmetic backend. Norm checks,
packing, decoding, reconstruction and final truncation are retained.
"""
from __future__ import annotations
from functools import partial
from typing import Literal, Sequence

from fast_resampled import check_norm, FastArithmeticSourceTransform
from fast_scalar import FastArithmetic
from fermat_recursive import NullLedger, RecursiveFermatMultiplier
from multiply_resampled import multiply_resampled
from synthetic import _shape, pack_signed, unpack_centered, trunc_shift

Pair = tuple[int, int]
Mode = Literal['three', 'one', 'four_narrow']


def packing_width(p: int, r: int) -> int:
    """Declared-data-independent width: 2p + log2(r) + 3 bits."""
    if type(p) is not int or type(r) is not int or p < 2 or r < 2 or r & (r-1) or r >= 1 << p:
        raise ValueError('require integer p>=2 and power-of-two 2<=r<2**p')
    return 2*p + r.bit_length()-1 + 3


def packed_numerators(f: Sequence[Pair], g: Sequence[Pair], p: int,
                      arithmetic: FastArithmetic, ledger=None,
                      *, mode: Mode = 'three') -> list[Pair]:
    """Exact coefficients of f*g modulo y**r+1, with unrounded integer numerators.

    Input pairs obey a*a+b*b <= 2**(2*p), checked using the injected backend.
    Three mode: 3 products on at most r*w bits; one mode: 1 product on at
    most 3*r*w bits. Four_narrow is a diagnostic control isolating lane width.
    """
    if mode not in ('three', 'one', 'four_narrow'):
        raise ValueError('mode must be three, one, or four_narrow')
    r = len(f)
    width = packing_width(p, r)
    _shape((f, g), r, p, require_disk=False)
    check_norm(f, p, arithmetic)
    check_norm(g, p, arithmetic)
    ledger = ledger if ledger is not None else NullLedger()
    ledger['packed_digit_width_max'] = max(ledger['packed_digit_width_max'], width)

    def product(left: int, right: int, count: int) -> list[int]:
        ledger['integer_multiplications'] += 1
        ledger['integer_multiply_operand_bits_sum'] += abs(left).bit_length()+abs(right).bit_length()
        ledger['integer_multiply_max_bits'] = max(ledger['integer_multiply_max_bits'],
                                                 abs(left).bit_length(), abs(right).bit_length())
        values = unpack_centered(arithmetic.mul(left, right), count, width)
        ledger['extraction_output_blocks'] += count
        ledger['v11_extraction_bits'] += count*width
        return values

    if mode == 'one':
        # F(X)=A(X**3)+X*B(X**3); residue classes 0,1,2 keep AC,AD+BC,BD separate.
        left = pack_signed([v for a, b in f for v in (a, b, 0)], width)
        right = pack_signed([v for c, d in g for v in (c, d, 0)], width)
        lanes = product(left, right, 6*r)
        real = [lanes[3*k]-lanes[3*k+2] for k in range(2*r)]
        imag = [lanes[3*k+1] for k in range(2*r)]
        ledger['packing_input_blocks'] += 6*r
        ledger['v11_packing_bits'] += 6*r*width
    else:
        a, b, c, d = [pack_signed([z[k] for z in row], width)
                      for row, k in ((f, 0), (f, 1), (g, 0), (g, 1))]
        ac = product(a, c, 2*r)
        bd = product(b, d, 2*r)
        real = [x-y for x, y in zip(ac, bd)]
        if mode == 'three':
            cross = product(a+b, c+d, 2*r)
            imag = [z-x-y for x, y, z in zip(ac, bd, cross)]
            # Each long addition reads two operands and writes one result.
            ledger['v11_packed_sum_bit_transfers_upper'] += 6*r*width
        else:
            ad = product(a, d, 2*r)
            bc = product(b, c, 2*r)
            imag = [x+y for x, y in zip(ad, bc)]
        ledger['packing_input_blocks'] += 4*r
        ledger['v11_packing_bits'] += 4*r*width
    ledger['v11_'+mode+'_calls'] += 1
    ledger['v11_coefficient_reconstruction_steps'] += 2*r
    return [(real[j]-real[j+r], imag[j]-imag[j+r]) for j in range(r)]


def normalized_packed_product(f: Sequence[Pair], g: Sequence[Pair], p: int,
                              arithmetic: FastArithmetic, ledger=None,
                              *, mode: Mode = 'three') -> list[Pair]:
    """Exactly the old normalized/truncated ring product, not a new rounding rule."""
    numerators = packed_numerators(f, g, p, arithmetic, ledger, mode=mode)
    shift = p + len(f).bit_length()-1
    return [(trunc_shift(a, shift), trunc_shift(b, shift)) for a, b in numerators]


def multiply_packed_finite(x: int, y: int, *, packing: Mode = 'three',
                            integer_multiply=None, ledger=None, **parameters):
    """Full explicit-parameter CRT/Gaussian reduction with an opt-in ring kernel.

    Default integer arithmetic remains the recursive Fermat backend. Passing
    operator.mul deliberately selects a native-Python control. Parameters and
    circuit/layer obligations are the same as v10; no asymptotic selector exists.
    """
    if packing not in ('three', 'one', 'four_narrow'):
        raise ValueError('unsupported packing mode')
    backend = integer_multiply if integer_multiply is not None else RecursiveFermatMultiplier()
    ledger = ledger if ledger is not None else NullLedger()
    kernel = partial(normalized_packed_product, mode=packing)
    factory = partial(FastArithmeticSourceTransform, ring_product=kernel)
    result, diagnostics = multiply_resampled(x, y, integer_multiply=backend,
        transform_factory=factory, ledger=ledger, **parameters)
    diagnostics['implementation_status'].update(
        arithmetic_profile='v10 full arithmetic with v11 opt-in signed packing',
        packed_kernel=packing,
        sub_n_log_n_proved_for_implementation=False,
        remaining='automatic asymptotic parameters, huge-network execution and complete fixed-tape audit')
    return result, diagnostics
