"""Integer interval roots of unity, inside the disk with error <2 grid units.

Correctness backend only: the present Taylor evaluator does not establish the
quasi-linear scalar cost needed by the full asymptotic multiplication claim.
"""
from collections import Counter
from dataclasses import dataclass
from certified_exp import ceil_div, pi_interval


@dataclass(frozen=True)
class PhaseCertificate:
    value: tuple
    real_interval: tuple
    imag_interval: tuple
    p: int
    interval_bits: int

    def verify_grid_error(self):
        unit = 1 << (self.interval_bits-self.p)
        errors = [max(abs(low-v*unit),abs(high-v*unit))
                  for v,(low,high) in zip(self.value,(self.real_interval,self.imag_interval))]
        return (all(low <= high for low,high in (self.real_interval,self.imag_interval))
                and sum(v*v for v in self.value) <= 1 << (2*self.p)
                and sum(e*e for e in errors) < 4*unit*unit)


def rotate_pair(pair, quadrant):
    a,b = pair
    return ((a,b),(-b,a),(-a,-b),(b,-a))[quadrant % 4]


def rotate_intervals(real,imag,quadrant):
    negate = lambda x: (-x[1],-x[0])
    return ((real,imag),(negate(imag),real),(negate(real),negate(imag)),
            (imag,negate(real)))[quadrant % 4]


class CertifiedPhase:
    def __init__(self,ledger=None):
        self.ledger = ledger if ledger is not None else Counter()
        self.pi_cache = {}

    def _series(self,low,high,bits,sine):
        scale = 1 << bits
        square = (low*low//scale,ceil_div(high*high,scale))
        if square[1] >= 3*scale: raise AssertionError("first-quadrant range")
        term = (low,high) if sine else (scale,scale)
        total = term
        j = 0
        while True:
            j += 1
            divisor = (2*j)*(2*j+1) if sine else (2*j-1)*(2*j)
            term = (term[0]*square[0]//(scale*divisor),
                    ceil_div(term[1]*square[1],scale*divisor))
            if j % 2: total = total[0]-term[1],total[1]-term[0]
            else: total = total[0]+term[0],total[1]+term[1]
            self.ledger["phase_taylor_terms"] += 1
            if term[1] <= 1:
                # From j>=1 onward the alternating terms decrease. The next
                # term is <one interval unit and bounds the remaining tail.
                if j % 2: total = total[0],total[1]+1
                else: total = total[0]-1,total[1]
                return max(0,total[0]),min(scale,total[1])

    def grid(self,numerator,denominator,p):
        if (any(type(v) is not int for v in (numerator,denominator,p))
                or denominator < 1 or p < 2):
            raise ValueError("integer phase numerator, positive denominator, p>=2 required")
        self.ledger["certified_phase_calls"] += 1
        quadrant,remainder = divmod(4*(numerator % denominator),denominator)
        if remainder == 0:
            value = rotate_pair((1 << p,0),quadrant)
            return PhaseCertificate(value,(value[0],value[0]),(value[1],value[1]),p,p)
        bits = p+24
        while True:
            if bits not in self.pi_cache:
                self.pi_cache[bits] = pi_interval(bits,self.ledger)
            pi_low,pi_high = self.pi_cache[bits]
            low = pi_low*remainder//(2*denominator)
            high = ceil_div(pi_high*remainder,2*denominator)
            real = self._series(low,high,bits,False)
            imag = self._series(low,high,bits,True)
            # Each nonnegative component is rounded inward independently.
            # Therefore its magnitude cannot exceed the true component;
            # the pair is in the unit disk, without radial clipping.
            inward = (real[0] >> (bits-p),imag[0] >> (bits-p))
            value = rotate_pair(inward,quadrant)
            real,imag = rotate_intervals(real,imag,quadrant)
            result = PhaseCertificate(value,real,imag,p,bits)
            self.ledger["phase_peak_interval_bits"] = max(self.ledger["phase_peak_interval_bits"],bits)
            if result.verify_grid_error(): return result
            bits *= 2
            self.ledger["phase_interval_refinements"] += 1
