import argparse, hashlib, json, time, unittest
from pathlib import Path
import test_direct_axes_v12 as tests

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--group',choices=['core','gaussian','full','all'],default='all')
    args=parser.parse_args()
    names=unittest.defaultTestLoader.getTestCaseNames(tests.DirectAxesTests)
    selected=[]
    for name in names:
        group='full' if name=='test_full_native_controls' else 'gaussian' if name=='test_gaussian_maps_preserve_operation_order' else 'core'
        if args.group in ('all',group): selected.append(tests.DirectAxesTests(name))
    start=time.perf_counter()
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
    evidence=dict(status='passed' if result.wasSuccessful() else 'failed',group=args.group,
        test_methods=result.testsRun,elapsed_seconds=time.perf_counter()-start,
        counts=dict(tests.COUNTS),
        scope='Explicit finite tests; native integer controls; small no-saving swap circuit. No full asymptotic-network execution.',
        sources_sha256={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in
            ['direct_axes_v12.py','direct_pipeline_v12.py','parameter_certificate_v12.py',
             'multiply_resampled.py','fast_resampled.py','test_direct_axes_v12.py']})
    Path('validation_v12_'+args.group+'.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(json.dumps(evidence['counts'],indent=2))
    raise SystemExit(not result.wasSuccessful())
