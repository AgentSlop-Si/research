"""Independent exact coefficient oracle, negative controls and finite integration."""
from collections import Counter
from itertools import product
from math import isqrt
from operator import mul
import random
import unittest

from fast_resampled import FastCyclicConvolver, fast_convolution, fast_ring_product
from fast_scalar import FastArithmetic
from fermat_recursive import RecursiveFermatMultiplier
from packed_gaussian_v11 import (packing_width, packed_numerators,
                                 normalized_packed_product, multiply_packed_finite)
from parameter_certificate_v11 import certificate
from synthetic import Layout, direct_layer, trunc_shift
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl

COUNTS=Counter()
MODES=('three','one','four_narrow')


def schoolbook(f,g):
    r=len(f)
    real=[0]*r; imag=[0]*r
    for j,(a,b) in enumerate(f):
        for k,(c,d) in enumerate(g):
            index=(j+k)%r
            sign=1 if j+k<r else -1
            real[index]+=sign*(a*c-b*d)
            imag[index]+=sign*(a*d+b*c)
    return list(zip(real,imag))


class PackingV11Tests(unittest.TestCase):
    def compare(self,f,g,p,arithmetic=None,modes=MODES):
        arithmetic=arithmetic if arithmetic is not None else FastArithmetic(mul)
        expected=schoolbook(f,g)
        for mode in modes:
            ledger=Counter()
            self.assertEqual(packed_numerators(f,g,p,arithmetic,ledger,mode=mode),expected)
            self.assertEqual(ledger['integer_multiplications'], {'three':3,'one':1,'four_narrow':4}[mode])
            self.assertLessEqual(ledger['integer_multiply_max_bits'],
                packing_width(p,len(f))*len(f)*(3 if mode=='one' else 1))
            COUNTS['exact_kernel_comparisons']+=1
            COUNTS[mode+'_exact_comparisons']+=1

    def test_exhaustive_small_signed(self):
        pairs=list(product((-1,0,1),repeat=2))
        arrays=list(product(pairs,repeat=2))
        for f in arrays:
            for g in arrays:
                self.compare(f,g,2)
        COUNTS['distinct_exhaustive_input_pairs']+=len(arrays)**2

    def test_adversarial_extremes(self):
        for p in (2,3,5,8,16,32,64,128):
            for ell in range(1,min(p,6)):
                r=1<<ell; full=1<<p; diagonal=isqrt((full*full)//2)
                cases=[[(full,0)]*r,[(0,-full)]*r,[(diagonal,-diagonal)]*r,
                       [((-1)**j*full,0) for j in range(r)],
                       [(0,0)]*r,[(full-1,1)]+[(0,0)]*(r-1)]
                for f,g in zip(cases,cases[1:]+cases[:1]): self.compare(f,g,p)
                COUNTS['adversarial_input_pairs']+=len(cases)

    def test_randomized_coefficients_and_rounding(self):
        rng=random.Random(20261015)
        for _ in range(300):
            p=rng.choice((4,8,12,16,31,64,96,128,257))
            r=1<<rng.randrange(1,min(p,7))
            f,g=[[(rng.randrange(-(1<<(p-1)),1<<(p-1)),
                   rng.randrange(-(1<<(p-1)),1<<(p-1))) for _ in range(r)] for _ in range(2)]
            self.compare(f,g,p)
            shift=p+r.bit_length()-1
            want=[(trunc_shift(a,shift),trunc_shift(b,shift)) for a,b in schoolbook(f,g)]
            for mode in MODES:
                self.assertEqual(normalized_packed_product(f,g,p,FastArithmetic(mul),mode=mode),want)
                COUNTS['normalized_kernel_comparisons']+=1
            self.assertEqual(want,fast_ring_product(f,g,p,FastArithmetic(mul),Counter()))
            COUNTS['v10_reference_comparisons']+=1
        COUNTS['random_input_pairs']+=300

    def test_recursive_backend(self):
        rng=random.Random(123004)
        for p,r in ((8,2),(16,4),(32,8),(64,8),(96,16),(128,32)):
            f,g=[[(rng.randrange(-(1<<(p-1)),1<<(p-1)),
                   rng.randrange(-(1<<(p-1)),1<<(p-1))) for _ in range(r)] for _ in range(2)]
            stats=Counter()
            backend=RecursiveFermatMultiplier(ledger=stats)
            self.compare(f,g,p,FastArithmetic(backend))
            if p>=64: self.assertGreater(stats.get('fermat_internal_nodes',0),0)
            COUNTS['recursive_backend_input_pairs']+=1

    def test_convolution_and_chirp_integration(self):
        from functools import partial
        p=48
        layout=Layout((2,4),4)
        rng=random.Random(5121)
        f,g=[[[((rng.randrange(50)-25)<<(p-10),(rng.randrange(50)-25)<<(p-10))
                for _ in range(4)] for _ in range(layout.size)] for _ in range(2)]
        expected=fast_convolution(f,g,layout,p,FastArithmetic(mul),Counter(),direct_layer,None)
        for mode in MODES:
            kernel=partial(normalized_packed_product,mode=mode)
            actual=fast_convolution(f,g,layout,p,FastArithmetic(mul),Counter(),direct_layer,None,
                                    ring_product=kernel)
            self.assertEqual(actual,expected)
            for targets,sources in (((4,),(3,)),((4,8),(3,5))):
                base=FastCyclicConvolver(targets,p,integer_multiply=mul)
                new=FastCyclicConvolver(targets,p,integer_multiply=mul,ring_product=kernel)
                x=[((j%7-3)<<(p-6),(j%5-2)<<(p-6)) for j in range(base.T)]
                self.assertEqual(new.convolve(x,x),base.convolve(x,x))
                self.assertEqual(new.chirp(x,sources),base.chirp(x,sources))
                COUNTS['cyclic_chirp_integration_comparisons']+=2
            COUNTS['synthetic_integration_comparisons']+=1

    def test_complete_finite_native_controls(self):
        circuit=CompiledBitCircuit(SwapControl())
        for mode in ('three','one'):
            for x,y in ((0,0xffffffff),(0xdeadbeef,0xfedcba98)):
                ledger=Counter()
                value,diag=multiply_packed_finite(x,y,packing=mode,integer_multiply=mul,ledger=ledger,
                    sources=(3,5),targets=(4,8),p=192,alpha=6,digit_bits=4,circuit=circuit)
                self.assertEqual(value,x*y)
                self.assertGreater(ledger['v11_'+mode+'_calls'],0)
                self.assertFalse(diag['implementation_status']['sub_n_log_n_proved_for_implementation'])
                COUNTS['complete_native_control_products']+=1

    def test_invalid_contracts(self):
        arithmetic=FastArithmetic(mul); good=[(0,0)]*2
        bad=[lambda:packing_width(1,2),lambda:packing_width(4,3),
             lambda:packing_width(2,4),
             lambda:packed_numerators(good,good,4,arithmetic,mode='bad'),
             lambda:packed_numerators(good,good[:1],4,arithmetic),
             lambda:packed_numerators([(16,16)]*2,good,4,arithmetic),
             lambda:packed_numerators([(True,0)]*2,good,4,arithmetic)]
        for call in bad:
            with self.assertRaises(ValueError):call()
        COUNTS['negative_controls']+=len(bad)

    def test_exact_parameter_certificate(self):
        result=certificate()
        self.assertGreater(result['new_kappa'],result['old_kappa'])
        self.assertLess(result['old_remaining_relative_room'],1/10**10)
        COUNTS['exact_parameter_certificates']+=1


if __name__=='__main__':unittest.main()
