"""Triangular CRT coefficient layout via ordered rotations and axis swaps.

Moves payload at ordinary index k to coordinates (mu_i*k mod s_i).
This push convention differs from Fourier dilation's pull convention.
"""
from collections import Counter
from itertools import product
from math import gcd,prod

from gaussian_tensor import adjacent_axes
from stream_moves import Reader,copy_records,emit,validate_payload


class CRTLayout:
    def __init__(self,sources,targets,circuit,*,ledger=None):
        self.sources,self.targets = tuple(sources),tuple(targets)
        if (not self.sources or len(self.sources)!=len(self.targets)
                or any(type(s) is not int or s<2 for s in self.sources)
                or any(type(t) is not int or t<2 or t & (t-1) for t in self.targets)
                or any(s>t for s,t in zip(self.sources,self.targets))
                or any(t not in (max(self.targets)//2,max(self.targets)) for t in self.targets)):
            raise ValueError("invalid CRT padded shape")
        self.prefix,self.mu = [],[]
        prefix = 1
        for s in self.sources:
            if gcd(prefix,s)!=1: raise ValueError("source lengths must be pairwise coprime")
            self.prefix.append(prefix)
            self.mu.append(pow(prefix,-1,s))
            prefix *= s
        self.S,self.T,self.circuit = prefix,prod(self.targets),circuit
        self.ledger = ledger if ledger is not None else Counter()

    def _reverse_axes(self,values,shape,width):
        names = list(range(len(shape)))
        target = list(reversed(names))
        for i,name in enumerate(target):
            position = names.index(name)
            while position>i:
                values,shape = adjacent_axes(values,shape,position-1,self.circuit,self.ledger,width)
                names[position-1],names[position] = names[position],names[position-1]
                position -= 1
        return values,shape

    def _padding_check(self,values):
        for address,value in zip(product(*(range(t) for t in self.targets)),values):
            if any(j>=s for j,s in zip(address,self.sources)) and value!=0:
                raise ValueError("CRT padding must be zero")

    def _rotate(self,values,axis,inverse,width):
        valid,full = self.sources[axis],self.targets[axis]
        suffix = prod(self.targets[axis+1:])
        banks = [[],[],[]]
        reader = Reader(values,self.ledger,width)
        def offset(controls):
            self.ledger["crt_offset_preparations"] += 1
            if any(j>=s for j,s in zip(controls,self.sources)):
                return 0
            amount = self.mu[axis]*sum(j*p for j,p in zip(controls,self.prefix)) % valid
            return (-amount if inverse else amount) % valid
        for controls in product(*(range(t) for t in self.targets[:axis])):
            amount = offset(controls)
            copy_records(reader,banks[0],(valid-amount)*suffix,self.ledger,width)
            copy_records(reader,banks[1],amount*suffix,self.ledger,width)
            copy_records(reader,banks[2],(full-valid)*suffix,self.ledger,width)
        reader.finish()
        readers = [Reader(bank,self.ledger,width) for bank in banks]
        out = []
        for controls in product(*(range(t) for t in self.targets[:axis])):
            amount = offset(controls)
            copy_records(readers[1],out,amount*suffix,self.ledger,width)
            copy_records(readers[0],out,(valid-amount)*suffix,self.ledger,width)
            copy_records(readers[2],out,(full-valid)*suffix,self.ledger,width)
        for reader in readers: reader.finish()
        self.ledger["crt_valid_interval_rotations"] += 1
        return out

    def forward(self,values,width):
        if len(values)!=self.S: raise ValueError("ordinary CRT coefficient count")
        validate_payload(values,width)
        reader = Reader(values,self.ledger,width)
        out = []
        reverse_targets,reverse_sources = self.targets[::-1],self.sources[::-1]
        for address in product(*(range(t) for t in reverse_targets)):
            value = reader.take() if all(j<s for j,s in zip(address,reverse_sources)) else 0
            emit(out,value,self.ledger,width)
        reader.finish()
        out,shape = self._reverse_axes(out,reverse_targets,width)
        if shape!=self.targets: raise AssertionError("CRT forward axis order")
        for axis in reversed(range(len(self.sources))):
            out = self._rotate(out,axis,False,width)
        self._padding_check(out)
        self.ledger["crt_forward_calls"] += 1
        return out

    def inverse(self,values,width):
        if len(values)!=self.T: raise ValueError("padded CRT coefficient count")
        validate_payload(values,width)
        self._padding_check(values)
        out = values
        for axis in range(len(self.sources)):
            out = self._rotate(out,axis,True,width)
        self._padding_check(out)
        out,shape = self._reverse_axes(out,self.targets,width)
        if shape!=self.targets[::-1]: raise AssertionError("CRT inverse axis order")
        reader = Reader(out,self.ledger,width)
        result = []
        for address in product(*(range(t) for t in shape)):
            value = reader.take()
            if all(j<s for j,s in zip(address,self.sources[::-1])):
                emit(result,value,self.ledger,width)
            elif value!=0: raise AssertionError("inverse CRT did not restore padding")
        reader.finish()
        self.ledger["crt_inverse_calls"] += 1
        return result
