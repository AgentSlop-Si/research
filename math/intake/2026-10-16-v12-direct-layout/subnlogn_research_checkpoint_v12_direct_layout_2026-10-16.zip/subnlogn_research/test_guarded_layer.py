"""Independent arithmetic/oracle tests for common-width phase execution."""
from collections import Counter
from fractions import Fraction as Q
import random
import unittest
from guarded_layer import (FixedFormat, GuardPlanner, PublishedGuard, fixed_c_tensor,
                           fixed_recursive_c, make_guarded_network_layer)
from network_frames import ComplexNetwork, Gate
from packed_stream import make_packed_basis_move, make_stream_layout_move
from phase_layers import explicit_c_numerators
from recursive_edges import explicit_basis_move
from synthetic import Layout, direct_layer, multiply_reference, normalized_convolution
from swap_recursion import CompiledBitCircuit
from test_packed_stream import TwoRoleRotatedControl, RotatedControlNetwork
from test_recursive_network import SmallControlNetwork, CoordinateSpace
from test_stream_swap import SwapControl

COUNTS=Counter()


class HalfControlNetwork(SmallControlNetwork):
    """Independent no-saving circuit with +/-1/2 updates and restored routing."""
    def gates(self):
        for time,(mask,target,source,sign) in enumerate(((1,"Y","X",1),(3,"X","Y",-1),(3,"Y","X",1))):
            yield Gate(0,(),time,CoordinateSpace(mask),("X","Y"),((target,source,Q(sign,2)),)*2)


class GuardTests(unittest.TestCase):
    def test_saved_guard_certificate_and_cutoff(self):
        from guard_certificate import certificate
        result=certificate()
        self.assertEqual(len(result["finite_cases"]),20)
        c0=int(result["published_h100"]["C0"])
        for item in result["guard_cutoffs"].values():
            gap=Q(item["exponent_gap"])
            q=item["sufficient_log2_precision"]
            self.assertGreaterEqual(q*gap,c0.bit_length())
            self.assertGreater(gap,0)
            COUNTS["guard_cutoff_certificates"]+=1

    def test_published_exact_guard_integers(self):
        pub=PublishedGuard.h100()
        self.assertEqual((pub.m,pub.wires,pub.rank_sum),
                         (1000000,1873807244643542670000,1873807244636671267308000000))
        self.assertLess(pub.m**10,pub.branching)
        self.assertLess(pub.branching,pub.m**11)
        self.assertEqual(pub.exponent,20)
        for d in (1,2,100,1000000,10**30):
            self.assertTrue(pub.verify_margins(d))
            self.assertEqual(pub.guard_bits(d),128*pub.m*pub.branching**2*d**20)
            COUNTS["published_guard_integer_margins"]+=1
        planner=GuardPlanner(ComplexNetwork(100))
        small=planner.certificate(8)
        self.assertEqual(small.core_depth,64)
        self.assertEqual(small.guard_bits,80)
        self.assertIsNone(planner.program)
        large=planner.certificate(1000200)
        self.assertEqual(large.method,"published h100 polynomial")
        self.assertEqual(large.guard_bits,pub.guard_bits(1000200))
        self.assertIsNone(planner.program)
        COUNTS["h100_guard_descriptors"]+=2

    def test_fixed_arithmetic_and_exact_divisions(self):
        ledger=Counter()
        fmt=FixedFormat(8,32,ledger)
        records=[[(-37,123),(256,-256)]]
        data=fmt.import_records(records)
        u,v=data[0]
        self.assertEqual(fmt.add(u,v),tuple((a+b)<<32 for a,b in zip(records[0][0],records[0][1])))
        self.assertEqual(fmt.half(fmt.add(u,v)),tuple((a+b)<<31 for a,b in zip(records[0][0],records[0][1])))
        self.assertEqual(fmt.rotate(u,1),(-u[1],u[0]))
        self.assertEqual(fmt.rotate(u,-1),(u[1],-u[0]))
        self.assertEqual(fmt.storage_bits%8,0)
        self.assertLessEqual(ledger["fixed_max_observed_signed_bits"],fmt.component_bits)
        COUNTS["fixed_format_arithmetic_cases"]+=5

    def test_common_format_leaf_kernels(self):
        rng=random.Random(71118)
        for n,bits in ((16,(0,2)),(32,(4,1,0)),(48,(3,1))):
            values=[[(rng.randrange(-128,129),rng.randrange(-128,129)) for _ in range(2)] for _ in range(n)]
            fmt=FixedFormat(8,40,Counter())
            actual=fixed_c_tensor(fmt.import_records(values),bits,fmt)
            numerators=explicit_c_numerators(values,bits,Counter())
            expected=[[tuple(x<<(40-len(bits)) for x in z) for z in poly] for poly in numerators]
            self.assertEqual(actual,expected)
            COUNTS["common_format_C_tensor_cases"]+=1

    def test_multilevel_common_format_recursion(self):
        rng=random.Random(71119)
        circuit=CompiledBitCircuit(SwapControl())
        for network,axes,rows in ((SmallControlNetwork(),8,8),(SmallControlNetwork(True),4,4),
                                  (HalfControlNetwork(),4,4),(RotatedControlNetwork(),8,3)):
            n=rows*(1<<axes)
            values=[[(rng.randrange(-16,17),rng.randrange(-16,17))] for _ in range(n)]
            planner=GuardPlanner(network)
            delta=planner.node_depth(axes,network.m)+1
            ledger=Counter()
            fmt=FixedFormat(5,delta,ledger)
            mover=make_packed_basis_move(circuit,component_bytes=fmt.component_bytes)
            got=fixed_recursive_c(fmt.import_records(values),tuple(reversed(range(axes))),fmt,
                network=network,rows=rows,suffix=1<<axes,prefixes=1,basis_move=mover,leaf_axes=network.m)
            expected=explicit_c_numerators(values,tuple(range(axes)),Counter())
            expected=[[tuple(x<<(delta-axes) for x in z) for z in poly] for poly in expected]
            self.assertEqual(got,expected)
            self.assertGreater(ledger["fixed_network_internal_nodes"],0)
            self.assertEqual(ledger["fixed_child_record_volume_sum"]*network.wires,
                             ledger["fixed_parent_record_volume_sum"]*network.rank_sum)
            self.assertEqual(ledger["fixed_child_bit_volume_sum"]*network.wires,
                             ledger["fixed_parent_bit_volume_sum"]*network.rank_sum)
            self.assertEqual(ledger["fixed_child_calls"],ledger["fixed_parking_calls"])
            self.assertEqual(ledger["adaptive_basis_codec_calls"],0)
            self.assertLessEqual(ledger["fixed_max_observed_signed_bits"],fmt.component_bits)
            COUNTS["common_format_recursive_networks"]+=1

    def test_guarded_layers_against_walsh_oracle(self):
        rng=random.Random(71120)
        circuit=CompiledBitCircuit(SwapControl())
        for network,d,k,rho in ((SmallControlNetwork(),8,1,0),(SmallControlNetwork(True),9,1,0),
                               (HalfControlNetwork(),8,1,0),(RotatedControlNetwork(),8,1,0),
                               (TwoRoleRotatedControl(),6,2,1),(ComplexNetwork(100),6,1,0)):
            records=[[(rng.randrange(-256,257),rng.randrange(-256,257))] for _ in range(1<<(d*k))]
            bits=tuple(rho+i*k for i in range(d))
            ledger=Counter()
            backend=make_guarded_network_layer(network,8,swap_circuit=circuit)
            self.assertEqual(backend(records,bits,ledger),direct_layer(records,bits,Counter()))
            certificate=backend.guard_planner.certificate(d)
            self.assertEqual(ledger["guarded_peak_guard_bits"],certificate.guard_bits)
            self.assertEqual(ledger["adaptive_basis_codec_calls"],0)
            self.assertLessEqual(ledger["fixed_max_observed_signed_bits"],ledger["guarded_peak_component_bits"])
            if isinstance(network,ComplexNetwork): self.assertEqual(ledger["fixed_network_internal_nodes"],0)
            COUNTS["guarded_Walsh_layers"]+=1

    def test_value_independent_width_and_fixed_codec(self):
        circuit=CompiledBitCircuit(SwapControl())
        network=TwoRoleRotatedControl()
        backend=make_guarded_network_layer(network,7,swap_circuit=circuit)
        width_results=[]
        for z in ((0,0),(1,-1),(128,-128)):
            values=[[z] for _ in range(64)]
            ledger=Counter()
            got=backend(values,tuple(range(6)),ledger)
            self.assertEqual(got,direct_layer(values,tuple(range(6)),Counter()))
            width_results.append((ledger["guarded_peak_component_bits"],ledger["fixed_basis_max_component_bytes"]))
            self.assertGreater(ledger["fixed_basis_codec_calls"],0)
            self.assertEqual(ledger["adaptive_basis_codec_calls"],0)
        self.assertEqual(len(set(width_results)),1)
        self.assertEqual(width_results[0][1],(width_results[0][0]+7)//8)
        COUNTS["data_independent_width_controls"]+=3

    def test_guarded_streamed_convolution(self):
        rng=random.Random(71121)
        circuit=CompiledBitCircuit(SwapControl())
        layout=Layout((4,)*6,4)
        operands=[[[(rng.randrange(-15,16),rng.randrange(-15,16)) for _ in range(4)]
                    for _ in range(layout.size)] for _ in range(2)]
        expected=normalized_convolution(*operands,layout,10)
        ledger=Counter()
        backend=make_guarded_network_layer(TwoRoleRotatedControl(),10,swap_circuit=circuit)
        got=normalized_convolution(*operands,layout,10,layer=backend,
                                    layout_move=make_stream_layout_move(circuit,component_bytes=2),ledger=ledger)
        self.assertEqual(got,expected)
        self.assertGreater(ledger["fixed_network_internal_nodes"],0)
        self.assertGreater(ledger["fixed_basis_codec_calls"],0)
        self.assertEqual(ledger["adaptive_basis_codec_calls"],0)
        self.assertEqual(ledger["adaptive_layout_codec_calls"],0)
        self.assertGreater(ledger["fixed_layout_codec_calls"],0)
        self.assertEqual(ledger["reference_permutation_records"],0)
        self.assertEqual(ledger["explicit_basis_record_moves"],0)
        COUNTS["guarded_stream_convolutions"]+=1

    def test_precision_factory_integer_adapter(self):
        rng=random.Random(71122)
        circuit=CompiledBitCircuit(SwapControl())
        net=TwoRoleRotatedControl()
        factory=lambda p:make_guarded_network_layer(net,p,swap_circuit=circuit)
        for x,y in ((0,0),(1,1),(rng.getrandbits(63),rng.getrandbits(63)),
                    (rng.getrandbits(511),rng.getrandbits(511))):
            result,details=multiply_reference(x,y,layer_factory=factory,
                layout_move_factory=lambda p:make_stream_layout_move(circuit,component_bytes=(p+9)//8))
            self.assertEqual(result,x*y)
            self.assertGreater(details["ledger"]["guarded_layer_calls"],0)
            self.assertEqual(details["ledger"].get("fixed_network_internal_nodes",0),0)
            self.assertFalse(details["implementation_status"]["sub_n_log_n_proved_for_implementation"])
            COUNTS["guarded_integer_integrations"]+=1

    def test_reject_underallocation_overflow_and_invalid_inputs(self):
        fmt=FixedFormat(2,0,Counter())
        with self.assertRaises(ArithmeticError): fmt.half((-3,1))
        with self.assertRaises(OverflowError): fmt.check(1<<(fmt.component_bits-1))
        with self.assertRaises(OverflowError): fmt.rotate((-(1<<(fmt.component_bits-1)),0),2)
        with self.assertRaises(ValueError): fmt.import_records([[(5,0)]])
        backend=make_guarded_network_layer(SmallControlNetwork(),2,guard_bits=0)
        with self.assertRaises(ValueError): backend([[(1,0)]]*4,(0,1),Counter())
        with self.assertRaises(ValueError): make_packed_basis_move(CompiledBitCircuit(SwapControl()),component_bytes=0)
        with self.assertRaises(ValueError): multiply_reference(2,3,layer=lambda a,b,c:a,layer_factory=lambda p:None)
        with self.assertRaises(ValueError): multiply_reference(2,3,layout_move=lambda a,b,c,d:a,layout_move_factory=lambda p:None)
        class WrongRank(SmallControlNetwork):
            @property
            def rank_sum(self): return 1
        with self.assertRaises(ValueError): GuardPlanner(WrongRank()).compile()
        COUNTS["negative_controls"]+=9


if __name__=="__main__": unittest.main()
