"""Finite layout-only measurements; no FFT or multiplier speed claim."""
from collections import Counter
from math import prod
from pathlib import Path
from time import perf_counter_ns
import json, platform, random, statistics
from gaussian_tensor import adjacent_axes
from direct_axes_v12 import reverse_axes
from fermat_recursive import NullLedger
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl, scatter


def old_reverse(records,shape,circuit,ledger,width):
    names=list(range(len(shape)))
    for i,name in enumerate(reversed(range(len(shape)))):
        position=names.index(name)
        while position>i:
            records,shape=adjacent_axes(records,shape,position-1,circuit,ledger,width)
            names[position-1],names[position]=names[position],names[position-1]
            position-=1
    return records,shape


def main():
    rng=random.Random(1210162026)
    circuit=CompiledBitCircuit(SwapControl())
    rows=[]
    shapes=[(2,)*d for d in (4,6,8,10)]+[(2,4)*3]
    for shape in shapes:
        vals=[rng.getrandbits(32) for _ in range(prod(shape))]
        expected=scatter(vals,shape,lambda x:x[::-1],shape[::-1])
        functions={'v11_neighboring':old_reverse,'v12_direct':reverse_axes}
        jobs=[name for _ in range(5) for name in functions]
        rng.shuffle(jobs)
        samples={name:[] for name in functions}
        for name in jobs:
            start=perf_counter_ns()
            out,new=functions[name](vals,shape,circuit,NullLedger(),32)
            samples[name].append(perf_counter_ns()-start)
            assert out==expected and new==shape[::-1]
        audits={}
        for name,fn in functions.items():
            ledger=Counter()
            out,new=fn(vals,shape,circuit,ledger,32)
            assert out==expected
            audits[name]=dict(ledger)
        medians={name:statistics.median(v) for name,v in samples.items()}
        row=dict(shape=shape,d=len(shape),records=len(vals),samples_ns=samples,
            median_ns=medians,ratio_v11_over_v12=medians['v11_neighboring']/medians['v12_direct'],
            old_axis_calls=len(shape)*(len(shape)-1)//2,new_axis_calls=len(shape)//2,
            ledgers=audits)
        rows.append(row)
        print('shape',shape,'speed ratio',round(row['ratio_v11_over_v12'],3),flush=True)
    result=dict(date='2026-10-16',scope='Layout-only finite timings, no whole-multiplier or FFT benchmark',
        method='5 randomized interleaved trials per variant per shape; compiled toy circuit shared and untimed; '
               'input generation and independent oracle untimed; all movement/padding/copying in timed routines; '
               'global ledger disabled while timing; ledger audits separate; no other research process running',
        python=platform.python_version(),platform=platform.platform(),
        checked_timed_calls=50,rows=rows)
    Path('direct_layout_benchmarks_v12.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
