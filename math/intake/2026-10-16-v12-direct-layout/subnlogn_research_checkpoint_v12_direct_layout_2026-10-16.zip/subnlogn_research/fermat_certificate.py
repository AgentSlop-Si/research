"""Exact sample checks and conditional logarithmic-slack arithmetic.

The all-size recurrence proof is in FERMAT_PROOF.txt. Sample checks alone do
not prove it, and neither result establishes the full multiplier's time bound.
"""
from pathlib import Path
import hashlib
import json
from cost_certificate import original_parameters,improved_parameters
from fermat_recursive import FermatPlan

SOURCES = ("fermat_certificate.py","fermat_recursive.py","cost_certificate.py","motifs.py",
           "stream_moves.py","synthetic.py","test_fermat_recursive.py")


def ceil_fraction(value): return -(-value.numerator//value.denominator)


def slack_certificate(parameters,degree=1):
    if type(degree) is not int or degree<1: raise ValueError("positive fixed polylog degree")
    parameters.check()
    kappa = parameters.kappa
    log_precision_cutoff = max(16,ceil_fraction(degree/kappa)**2)
    # For t>=16, log2(t)<=sqrt(t). Thus t**degree<=2**(kappa*t)
    # whenever sqrt(t)>=degree/kappa. Here t=log2(p).
    if kappa*kappa*log_precision_cutoff < degree*degree:
        raise AssertionError("polylog absorption cutoff")
    margin = parameters.epsilon-2*kappa
    if margin<0: raise AssertionError("short-product exponent lacks slack")
    return dict(polylog_degree=degree,
        sufficient_log2_precision=str(log_precision_cutoff),
        packed_margin_after_one_kappa=str(parameters.epsilon-kappa),
        required_margin=str(kappa),additional_margin=str(margin),
        scope="Conditional on the existing size/interface lemmas and recursive backend bit-cost proof; not a runtime crossover")


def certificate():
    nodes = 0
    samples = []
    for root_log in range(5,301):
        n,depth = 1 << root_log,0
        while n>16:
            plan = FermatPlan.make(n)
            m,L = plan.child_exponent,plan.length
            u = n.bit_length()-1
            if u>=16:
                if (L*m-2*n)*u*u > 2*n: raise AssertionError("guard/padding excess")
                if m*m > 81*u*u*n: raise AssertionError("child size")
            if u>=64:
                if m**4 > n**3: raise AssertionError("logarithmic contraction")
                h = (u-1).bit_length()
                ell_n,ell_m = (n-1).bit_length(),(m-1).bit_length()
                if L*m*ell_m*u > n*ell_n*(u+6*h):
                    raise AssertionError("normalized recurrence coefficient")
            if m>16 and FermatPlan.make(m).length>L:
                raise AssertionError("binary divisibility inheritance")
            n,depth = m,depth+1
            nodes += 1
        if root_log in (5,16,32,64,128,256,300):
            samples.append(dict(root_log2_exponent=root_log,depth_to_16=depth,leaf_exponent=n))
    root = Path(__file__).resolve().parent
    return dict(status="sample inequalities and exact conditional slack passed",
        sample_plan_nodes=nodes,sample_chains=samples,
        source_sha256={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in SOURCES},
        original=slack_certificate(original_parameters()),
        improved=slack_certificate(improved_parameters()),
        scope="The samples do not prove an all-size recurrence or the complete sub-N-log-N goal")


if __name__ == "__main__":
    result = certificate()
    Path(__file__).with_suffix(".json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:result[k] for k in ("status","sample_plan_nodes","sample_chains")},indent=2))
