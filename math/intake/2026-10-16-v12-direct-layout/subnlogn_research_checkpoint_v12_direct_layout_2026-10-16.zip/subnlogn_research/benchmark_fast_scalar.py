"""Cold scalar timings: recursive backend and explicit native arithmetic control."""
from collections import Counter
from dataclasses import asdict
from operator import mul
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import sys

SOURCES = ("benchmark_fast_scalar.py", "fast_scalar.py", "fast_scalar_transform.py",
    "fermat_recursive.py", "certified_exp.py", "certified_phase.py", "multiply_resampled.py",
    "resampled_transform.py", "gaussian_resampling.py", "gaussian_tensor.py", "crt_layout.py",
    "synthetic.py", "guarded_layer.py", "packed_stream.py", "swap_recursion.py", "stream_moves.py",
    "network_frames.py", "recursive_network.py", "recursive_edges.py", "phase_layers.py",
    "packed_bits.py", "bit_frames.py", "motifs.py", "test_stream_swap.py")


def main():
    root = Path(__file__).resolve().parent
    def hashes(): return {n: hashlib.sha256((root/n).read_bytes()).hexdigest() for n in SOURCES}
    before = hashes()
    from fast_scalar import FastCertifiedExp, FastCertifiedPhase
    from fast_scalar_transform import FastScalarSourceTransform
    from fermat_recursive import RecursiveFermatMultiplier
    from guarded_layer import make_guarded_network_layer
    from multiply_resampled import multiply_resampled
    from network_frames import ComplexNetwork
    from packed_stream import make_stream_layout_move
    from swap_recursion import CompiledBitCircuit
    from test_stream_swap import SwapControl
    report = dict(python=sys.version, platform=platform.platform(), cases=[],
        method="Two cold scalar calls per case, including pi/setup and all arithmetic; global scalar/backend audits disabled inside timer; one separate untimed scalar-audit call per case",
        scope="Scalar component measurements plus one complete explicit-parameter native-arithmetic control; not a full sub-N-log-N implementation")
    was_enabled = gc.isenabled()
    gc.disable()
    try:
        for backend_name in ("recursive_fermat", "native_integer_control"):
            for p in ((32, 128, 512) if backend_name == "recursive_fermat" else (32, 128, 512, 1024)):
                for name, cls in (("exponential", FastCertifiedExp), ("phase", FastCertifiedPhase)):
                    samples = []
                    args = (-1, 3, p) if name == "exponential" else (1, 7, p)
                    control = cls(integer_multiply=mul).grid(*args)
                    for _ in range(2):
                        started = perf_counter_ns()
                        backend = RecursiveFermatMultiplier() if backend_name == "recursive_fermat" else mul
                        result = cls(integer_multiply=backend).grid(*args)
                        samples.append(perf_counter_ns()-started)
                        if result != control or not result.verify_grid_error():
                            raise AssertionError("scalar backend/certificate mismatch")
                    ledger = Counter()
                    backend = RecursiveFermatMultiplier() if backend_name == "recursive_fermat" else mul
                    audited = cls(ledger, integer_multiply=backend).grid(*args)
                    if audited != result: raise AssertionError("scalar audit changed the answer")
                    report["cases"].append(dict(name=name, precision=p, backend=backend_name,
                        samples_ns=samples, median_ns=median(samples),
                        certificate=asdict(result), untimed_scalar_ledger=dict(ledger)))
                    print(json.dumps(dict(name=name, p=p, backend=backend_name,
                                          median_ms=median(samples)/1e6)), flush=True)
        started = perf_counter_ns()
        circuit = CompiledBitCircuit(SwapControl())
        layer = make_guarded_network_layer(ComplexNetwork(100), 192, swap_circuit=circuit)
        movement = make_stream_layout_move(circuit, component_bytes=25)
        x, y = 0xdeadbeef, 0xfedcba98
        value, diagnostics = multiply_resampled(x, y, sources=(3, 5), targets=(4, 8),
            p=192, alpha=6, digit_bits=4, circuit=circuit, layer=layer, layout_move=movement,
            integer_multiply=mul, transform_factory=FastScalarSourceTransform)
        elapsed = perf_counter_ns()-started
        if value != x*y: raise AssertionError("complete scalar-control reduction")
        report["integration"] = dict(elapsed_ns=elapsed, repetitions=1,
            integer_backend="explicit native arithmetic control", diagnostics=diagnostics,
            scope="Complete guarded/streamed finite reduction with bit-burst scalar functions; NOT a fully recursive arithmetic execution")
        print(json.dumps({"integration_native_control_ms": elapsed/1e6}), flush=True)
    finally:
        if was_enabled: gc.enable()
    if hashes() != before: raise RuntimeError("sources changed during benchmark")
    report.update(source_sha256=before, sources_unchanged_during_benchmark=True,
        checked_timed_scalar_outputs=28, checked_untimed_audited_scalar_outputs=14,
        checked_timed_integration_products=1)
    (root/"fast_scalar_benchmarks.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__": main()
