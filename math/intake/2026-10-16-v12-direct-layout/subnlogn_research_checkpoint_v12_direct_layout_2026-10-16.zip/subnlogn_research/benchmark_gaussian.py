"""Cold Gaussian-map component timings, checked against independent analytics."""
from collections import Counter
from decimal import Decimal, localcontext
from math import prod
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import random
import sys

SOURCES = ("benchmark_gaussian.py","certified_exp.py","gaussian_resampling.py",
           "gaussian_tensor.py","test_gaussian_resampling.py","packed_stream.py",
           "packed_bits.py","stream_moves.py","swap_recursion.py","bit_frames.py",
           "motifs.py","synthetic.py","test_stream_swap.py")


def main():
    root = Path(__file__).resolve().parent
    def hashes(): return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in SOURCES}
    before = hashes()
    from gaussian_resampling import GaussianParameters, GaussianLine
    from gaussian_tensor import GaussianTensor
    from swap_recursion import CompiledBitCircuit
    from test_stream_swap import SwapControl
    from test_gaussian_resampling import analytic_matrices, matvec, solve, tensor_matrix
    report = dict(python=sys.version, platform=platform.platform(),
                  scope="Certified Gaussian numerical components; no fast scalar or full multiplication bound",
                  timing="Cold per-call parameter validation, pi intervals, exponentials, arithmetic, checks, codecs and movement included; oracle and fixed control-circuit compiler excluded",
                  cases=[])
    was_enabled = gc.isenabled()
    gc.disable()
    try:
        with localcontext() as ctx:
            ctx.prec = 100
            rng = random.Random(19253)
            def measure(name, operation, expected, p, bound):
                samples = []
                max_error = Decimal(0)
                for _ in range(3):
                    ledger = Counter()
                    started = perf_counter_ns()
                    actual = operation(ledger)
                    samples.append(perf_counter_ns()-started)
                    if len(actual) != len(expected): raise AssertionError("output shape")
                    for z,w in zip(actual,expected):
                        error2 = sum((Decimal(x)-y*(1 << p))**2 for x,y in zip(z,w))
                        if error2 >= Decimal(bound)**2: raise AssertionError(name+" error bound")
                        max_error = max(max_error,error2.sqrt())
                    final_ledger = dict(ledger)
                report["cases"].append(dict(name=name,precision_bits=p,samples_ns=samples,
                    median_ns=median(samples),maximum_grid_error=str(max_error),
                    grid_error_bound=str(bound),ledger=final_ledger))
                print(json.dumps({"case":name,"median_ms":median(samples)/1e6,
                                  "maximum_grid_error":str(max_error)}),flush=True)

            for s,t,alpha in ((3,4,5),(15,16,7)):
                p = 128
                parameters = GaussianParameters(s,t,p,alpha)
                scale = 1 << p
                S,N,D,indices = analytic_matrices(parameters)
                u = [(rng.randrange(-scale//3,scale//3),rng.randrange(-scale//3,scale//3))
                     for _ in range(s)]
                v = [(rng.randrange(-scale//3,scale//3),rng.randrange(-scale//3,scale//3))
                     for _ in range(t)]
                expected_A = [tuple(x/2 for x in z) for z in matvec(S,
                              [tuple(Decimal(x)/scale for x in z) for z in u])]
                expected_B = solve(N,[tuple(Decimal(x)/(2*scale) for x in v[j]) for j in indices])
                expected_B = [tuple(x*d/(1 << (parameters.gamma-2)) for x in z)
                              for d,z in zip(D,expected_B)]
                def expansion(ledger):
                    return GaussianLine(GaussianParameters(s,t,p,alpha),ledger=ledger).expand(u)
                def compression(ledger):
                    return GaussianLine(GaussianParameters(s,t,p,alpha),ledger=ledger).compress(v)
                measure(f"line_{s}_{t}_A",expansion,expected_A,p,16*p)
                measure(f"line_{s}_{t}_B0",compression,expected_B,p,p*p)

            circuit = CompiledBitCircuit(SwapControl())
            sources,targets,p,alpha = (3,5),(4,8),128,5
            matrices = []
            for s,t in zip(sources,targets):
                parameters = GaussianParameters(s,t,p,alpha)
                S,N,D,indices = analytic_matrices(parameters)
                A = [[v/2 for v in row] for row in S]
                inv = solve(N,[[Decimal(i==j) for j in range(s)] for i in range(s)])
                B = [[Decimal(0) for _ in range(t)] for _ in range(s)]
                for i in range(s):
                    for j,k in enumerate(indices):
                        B[i][k] = D[i]*inv[i][j]/(1 << (parameters.gamma-1))
                matrices.append((A,B))
            for inverse in (False,True):
                shape = targets if inverse else sources
                values = [(rng.randrange(-scale//3,scale//3),rng.randrange(-scale//3,scale//3))
                          for _ in range(prod(shape))]
                expected = [tuple(Decimal(x)/scale for x in z) for z in values]
                for axis in range(2):
                    expected,shape = tensor_matrix(expected,shape,axis,matrices[axis][inverse])
                def execute(ledger):
                    tensor = GaussianTensor(sources,targets,p,alpha,circuit,ledger=ledger)
                    data = values if inverse else tensor.embed(values)
                    out = tensor.apply(data,inverse=inverse)
                    return tensor.extract(out) if inverse else out
                measure("tensor_B0" if inverse else "tensor_A",execute,expected,p,2*p*p)
    finally:
        if was_enabled: gc.enable()
    if hashes() != before: raise RuntimeError("source changed during benchmark")
    report.update(source_sha256=before,sources_unchanged_during_benchmark=True,checked_outputs=18)
    (root/"gaussian_benchmarks.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")


if __name__ == "__main__": main()
