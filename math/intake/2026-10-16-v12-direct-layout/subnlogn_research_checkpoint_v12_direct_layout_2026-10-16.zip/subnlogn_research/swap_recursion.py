"""Rank-counted address interchange with sequential payload movement.

This implements section 04's power-width recursion, including rational lower
triangular changes, cyclic role rows, arbitrary scratch, and signed source
frames. It does not infer speed from the control networks used in small tests.
Payload transfers/parking are counted, but descriptor/counter arithmetic and
fixed-machine compilation still need a complete bit-cost audit.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from math import gcd, isqrt, prod
from motifs import identity, inverse_lower, lower_factorization
from stream_moves import (Reader, affine_later, charge, copy_records, emit,
                          merge_rows, move_digit, shape_check, split_rows, swap_digits, xor_stream)


@dataclass(frozen=True)
class ChunkLayout:
    prime: int
    digits: int
    prefix: int = 1
    rows: int = 1
    before: int = 1
    gap: int = 1
    suffix: int = 1

    def __post_init__(self):
        if any(not isinstance(x,int) or x<1 for x in (self.digits,self.prefix,self.rows,self.before,self.gap,self.suffix)):
            raise ValueError("positive integer shape required")
        if self.prime<3 or self.prime%2==0 or any(self.prime%d==0 for d in range(3,isqrt(self.prime)+1,2)):
            raise ValueError("an odd prime radix is required")

    @property
    def chunk_range(self): return self.prime**self.digits
    @property
    def row_size(self): return self.before*self.chunk_range**2*self.gap*self.suffix
    @property
    def volume(self): return self.prefix*self.rows*self.row_size

    def divide_rows(self, roles):
        if self.rows%roles: raise ValueError("row supply is not divisible by role count")
        return ChunkLayout(self.prime,self.digits,self.prefix,self.rows//roles,self.before,self.gap,self.suffix)

    def fields(self, m):
        if self.digits%m: raise ValueError("power width must split into equal fields")
        q=self.prime**(self.digits//m)
        return (self.prefix,self.rows,self.before,*([q]*m),self.gap,*([q]*m),self.suffix)

    def child(self,m,i,j):
        if self.digits%m or not 0<=i<m or not 0<=j<m: raise ValueError("invalid pivot chunk")
        b=self.digits//m
        q=self.prime**b
        return ChunkLayout(self.prime,b,self.prefix,self.rows,self.before*q**i,
                           q**(m-i-1)*self.gap*q**j,q**(m-j-1)*self.suffix)


class ShearPlan:
    """Finite rational table, compiled independently of input chunk width."""
    def __init__(self,matrix):
        if not matrix: raise ValueError("nonempty matrix required")
        e1,pivots,e2=lower_factorization(matrix)
        self.m=len(matrix)
        self.before=(inverse_lower(e1),e2)
        self.after=(e1,inverse_lower(e2))
        self.pivots=tuple((i,j) for i,row in enumerate(pivots) for j,value in enumerate(row) if value)
        self.rank=len(self.pivots)
        self.unit_conditions=[]
        for factor in (*self.before,*self.after):
            for i,row in enumerate(factor):
                for value in row: self.unit_conditions.append(value.denominator)
                self.unit_conditions.append(row[i].numerator)

    def accepts_prime(self,prime): return all(gcd(c,prime)==1 for c in self.unit_conditions)

    def execute(self,records,layout,child,ledger,width=1):
        m=self.m
        if not self.accepts_prime(layout.prime): raise ValueError("prime divides a compiled unit or denominator")
        shape=layout.fields(m)
        shape_check(records,shape,width)
        starts=(3,m+4)

        def triangular(data,factor,start):
            # Descending target order retains the original earlier controls.
            for i in reversed(range(m)):
                data=affine_later(data,shape,start+i,factor[i][i],
                                  tuple((start+j,factor[i][j]) for j in range(i)),ledger,width)
            return data

        out=records
        for start,factor in zip(starts,self.before): out=triangular(out,factor,start)
        for i,j in self.pivots:
            h,d=starts[0]+i,starts[1]+j
            out=affine_later(out,shape,d,1,((h,1),),ledger,width)
            child_layout=layout.child(m,i,j)
            if child_layout.volume!=layout.volume: raise AssertionError("pivot lost spectator volume")
            out=child(out,child_layout)
            out=affine_later(out,shape,d,-1,((h,1),),ledger,width)
            ledger["matrix_shear_child_calls"] += 1
        for start,factor in zip(starts,self.after): out=triangular(out,factor,start)
        ledger["rational_stream_shears"] += 1
        return out


class CompiledBitCircuit:
    """Compile one finite circuit and its entire rational factor table.

    Building this for the h=100 circuit is a huge finite computation, not a
    completed precomputation in this checkpoint. Small controls are separate.
    """
    def __init__(self,network):
        self.m,self.wires=network.m,network.wires
        if self.m<2 or self.wires<2: raise ValueError("recursion requires m,W>=2")
        self.roles=tuple(network.roles())
        if len(self.roles)!=self.wires or len(set(self.roles))!=self.wires: raise ValueError("role inventory")
        indices={role:i for i,role in enumerate(self.roles)}
        self.routing=tuple(indices[network.routed_output(role)] for role in self.roles)
        if sorted(self.routing)!=list(range(self.wires)): raise ValueError("routing must be a permutation")
        endpoints=set()
        for role in self.roles:
            endpoints.add((network.source_frame(role),network.sink_frame(network.routed_output(role))))
        for source,sink in endpoints:
            if network.edge_matrix(source,sink)!=identity(self.m):
                raise ValueError("endpoint frame difference is not identity")
        scalars=[1<<i for i in range(self.wires)]
        previous={role:network.source_frame(role) for role in self.roles}
        self.program=[]
        self.plans={}

        def edge(role,head):
            tail=previous[role]
            key=(tail,head)
            if key not in self.plans:
                self.plans[key]=ShearPlan(network.edge_matrix(tail,head))
                if self.plans[key].m!=self.m: raise ValueError("edge dimension mismatch")
            plan=self.plans[key]
            previous[role]=head
            self.program.append(("edge",indices[role],plan))

        for gate in network.gates():
            if len(set(gate.roles))!=len(gate.roles): raise ValueError("duplicate role at gate")
            if any(a not in gate.roles or b not in gate.roles for a,b in gate.updates):
                raise ValueError("gate update outside common frame")
            if {a for a,_ in gate.updates}&{b for _,b in gate.updates}:
                raise ValueError("this compiler requires disjoint gate controls and targets")
            for role in gate.roles: edge(role,gate.frame)
            for target,source in gate.updates:
                self.program.append(("xor",indices[target],indices[source]))
                scalars[indices[target]] ^= scalars[indices[source]]
        for role in self.roles: edge(role,network.sink_frame(role))
        if any(scalars[self.routing[i]]!=1<<i for i in range(self.wires)):
            raise ValueError("scalar circuit does not implement declared role routing")
        self.rank_sum=sum(value.rank for op,_,value in self.program if op=="edge")
        if self.rank_sum!=network.rank_sum: raise ValueError("compiled rank sum differs from declared rank sum")
        prime=3
        while not all(plan.accepts_prime(prime) for plan in self.plans.values()):
            prime+=2
            while any(prime%d==0 for d in range(3,isqrt(prime)+1,2)): prime+=2
        self.prime=prime


def _park_others(banks,active,ledger,width):
    """Append inactive streams, then clear their reusable role slots."""
    stack=[]
    lengths=[]
    for i,bank in enumerate(banks):
        if i==active: continue
        lengths.append((i,len(bank)))
        reader=Reader(bank,ledger,width)
        copy_records(reader,stack,len(bank),ledger,width)
        reader.finish()
        charge(ledger,"parking_erase_symbols",len(bank),width)
        banks[i]=[]
    ledger["parking_push_calls"] += 1
    ledger["parking_records"] += len(stack)
    return stack,lengths


def _restore_others(banks,stack,lengths,ledger,width):
    for i,length in reversed(lengths):
        reverse=[]
        for _ in range(length):
            emit(reverse,stack.pop(),ledger,width)
            charge(ledger,"stack_pop_symbols",1,width)
        bank=[]
        while reverse:
            emit(bank,reverse.pop(),ledger,width)
            charge(ledger,"stack_pop_symbols",1,width)
        banks[i]=bank
    if stack: raise AssertionError("parking boundary not restored")


def recursive_swap(records,layout,circuit,ledger,width=1):
    """Swap two prime-radix chunks of width m^k, with W^k supplied rows."""
    if len(records)!=layout.volume: raise ValueError("incomplete layout")
    e,k=layout.digits,0
    while e>1 and e%circuit.m==0: e//=circuit.m; k+=1
    if e!=1: raise ValueError("digit width must be a power of m")
    if layout.rows%circuit.wires**k: raise ValueError("insufficient row divisibility")
    if layout.prime!=circuit.prime: raise ValueError("layout radix differs from fixed compiled prime")
    if k==0:
        ledger["swap_leaf_calls"] += 1
        return swap_digits(records,layout.prefix*layout.rows*layout.before,layout.prime,layout.gap,layout.suffix,ledger,width)
    ledger["swap_internal_nodes"] += 1
    ledger["swap_parent_record_volume_sum"] += layout.volume
    shape=layout.fields(circuit.m)
    out=records
    for i in range(circuit.m):
        out=affine_later(out,shape,circuit.m+4+i,1,((3+i,-1),),ledger,width)
    banks=split_rows(out,layout.prefix,layout.rows,layout.row_size,circuit.wires,ledger,width)
    child_layout=layout.divide_rows(circuit.wires)
    direct_children=0

    for operation,target,value in circuit.program:
        if operation=="xor":
            banks[target]=xor_stream(banks[target],banks[value],ledger,width)
        elif value.rank:
            def child(data,child_shape):
                nonlocal direct_children
                if child_shape.volume*circuit.wires!=layout.volume:
                    raise AssertionError("incorrect child logical volume")
                stack,lengths=_park_others(banks,target,ledger,width)
                banks[target]=[]
                data=recursive_swap(data,child_shape,circuit,ledger,width)
                _restore_others(banks,stack,lengths,ledger,width)
                direct_children+=1
                ledger["swap_child_record_volume_sum"] += child_shape.volume
                return data
            banks[target]=value.execute(banks[target],child_layout,child,ledger,width)
    if direct_children!=circuit.rank_sum: raise AssertionError("child count must equal total rational rank")
    out=merge_rows(banks,layout.prefix,layout.rows,layout.row_size,circuit.routing,ledger,width)
    for i in range(circuit.m):
        out=affine_later(out,shape,circuit.m+4+i,-1,((3+i,1),),ledger,width)
    return out


def _resize_rows(records,prefix,old,new,suffix,ledger,width):
    """Append/remove zero rows separately for every preceding prefix."""
    shape_check(records,(prefix,old,suffix),width)
    reader=Reader(records,ledger,width)
    out=[]
    for _ in range(prefix):
        copy_records(reader,out,min(old,new)*suffix,ledger,width)
        if new>old:
            for _ in range((new-old)*suffix): emit(out,0,ledger,width)
        else:
            for _ in range((old-new)*suffix):
                if reader.take()!=0: raise ArithmeticError("padded row was not restored")
    reader.finish()
    ledger["row_padding_records"] += prefix*abs(new-old)*suffix
    return out


def arbitrary_q_swap(records,digits,circuit,ledger,*,prefix=1,gap=1,suffix=1,width=1):
    """Supply rows from high digits, pad, and use base-m width decomposition."""
    q,m,w=circuit.prime,circuit.m,circuit.wires
    shape_check(records,(prefix,q**digits,gap,q**digits,suffix),width)
    if digits<1: raise ValueError("positive digit width required")
    k,power=0,1
    while power<digits: k+=1; power*=m
    required=w**k
    rho,r=0,1
    while r<required: rho+=1; r*=q*q
    if rho==0 or rho>=digits:
        out=records
        for i in range(digits):
            out=swap_digits(out,prefix*q**i,q,q**(digits-i-1)*gap*q**i,q**(digits-i-1)*suffix,ledger,width)
        ledger["bounded_width_swap_fallbacks"] += 1
        return out
    low=digits-rho
    out=records
    for i in range(rho):
        out=swap_digits(out,prefix*q**i,q,q**(digits-i-1)*gap*q**i,q**(digits-i-1)*suffix,ledger,width)
    shape=(prefix,q**rho,q**low,gap,*([q]*rho),q**low,suffix)
    for i in range(rho): out,shape=move_digit(out,shape,4+i,2+i,ledger,width)
    padded=required*((r+required-1)//required)
    if not r<=padded<2*r: raise AssertionError("row padding must be below factor two")
    row_size=q**(2*low)*gap*suffix
    out=_resize_rows(out,prefix,r,padded,row_size,ledger,width)
    pieces=[]
    remaining=low
    for exponent in reversed(range(k+1)):
        piece=m**exponent
        count,remaining=divmod(remaining,piece)
        pieces.extend([piece]*count)
    offset=0
    for piece in pieces:
        layout=ChunkLayout(q,piece,prefix,padded,q**offset,
                           q**(low-offset-piece)*gap*q**offset,q**(low-offset-piece)*suffix)
        out=recursive_swap(out,layout,circuit,ledger,width)
        offset+=piece
    if offset!=low: raise AssertionError("width decomposition")
    out=_resize_rows(out,prefix,padded,r,row_size,ledger,width)
    for _ in range(rho): out,shape=move_digit(out,shape,2,rho+3,ledger,width)
    ledger["arbitrary_q_chunk_swaps"] += 1
    ledger["width_decomposition_pieces"] += len(pieces)
    return out


def _resize_chunks(records,prefix,old,new,gap,suffix,ledger,width):
    shape_check(records,(prefix,old,gap,old,suffix),width)
    reader=Reader(records,ledger,width)
    out=[]
    if new>=old:
        for _ in range(prefix):
            for h in range(new):
                for _ in range(gap):
                    for d in range(new):
                        for _ in range(suffix): emit(out,reader.take() if h<old and d<old else 0,ledger,width)
    else:
        for _ in range(prefix):
            for h in range(old):
                for _ in range(gap):
                    for d in range(old):
                        for _ in range(suffix):
                            value=reader.take()
                            if h<new and d<new: emit(out,value,ledger,width)
                            elif value: raise ArithmeticError("invalid coordinate was not restored to zero")
    reader.finish()
    ledger["chunk_padding_records"] += prefix*abs(new*new-old*old)*gap*suffix
    return out


def binary_chunk_swap(records,bits,circuit,ledger,*,prefix=1,gap=1,suffix=1,width=1):
    """The section 04 binary interface; numerical padding needs no radix conversion."""
    if bits<1: raise ValueError("positive binary chunk width required")
    old=1<<bits
    q,e=circuit.prime,1
    new=q
    while new<old: e+=1; new*=q
    out=_resize_chunks(records,prefix,old,new,gap,suffix,ledger,width)
    out=arbitrary_q_swap(out,e,circuit,ledger,prefix=prefix,gap=gap,suffix=suffix,width=width)
    out=_resize_chunks(out,prefix,new,old,gap,suffix,ledger,width)
    ledger["binary_chunk_swaps"] += 1
    return out
