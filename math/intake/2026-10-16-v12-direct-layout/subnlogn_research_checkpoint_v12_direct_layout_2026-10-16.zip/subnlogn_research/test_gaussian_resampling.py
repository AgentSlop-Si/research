"""Independent high-precision analytic checks; Decimal is oracle-only."""
from collections import Counter
from decimal import Decimal, localcontext
from math import gcd
from itertools import product
from math import prod
import random
import unittest

from certified_exp import CertifiedExp, pi_interval
from gaussian_resampling import GaussianLine, GaussianParameters, PeriodicTape
from gaussian_tensor import GaussianTensor, adjacent_axes
from swap_recursion import CompiledBitCircuit
from test_stream_swap import SwapControl, scatter

COUNTS = Counter()


def decimal_pi():
    # Gauss--Legendre: deliberately different from production's Machin series.
    a, b, t, power = Decimal(1), Decimal(1)/Decimal(2).sqrt(), Decimal(1)/4, 1
    for _ in range(12):
        next_a = (a+b)/2
        b = (a*b).sqrt()
        t -= power*(a-next_a)**2
        a, power = next_a, power*2
    return (a+b)**2/(4*t)


def matvec(matrix, values):
    return [tuple(sum((w*z[c] for w, z in zip(row, values)), Decimal(0))
                  for c in (0, 1)) for row in matrix]


def solve(matrix, values):
    # Dense pivoted elimination belongs ONLY to this independent test oracle.
    n = len(matrix)
    rows = [list(row)+list(z) for row, z in zip(matrix, values)]
    for j in range(n):
        pivot = max(range(j, n), key=lambda i: abs(rows[i][j]))
        rows[j], rows[pivot] = rows[pivot], rows[j]
        c = rows[j][j]
        rows[j] = [v/c for v in rows[j]]
        for i in range(n):
            if i == j: continue
            c = rows[i][j]
            rows[i] = [x-c*y for x, y in zip(rows[i], rows[j])]
    return [tuple(row[n:]) for row in rows]


def analytic_matrices(a):
    """Longer period sums for S,T, then form N=C T D directly (not E formula)."""
    pi = decimal_pi()
    s, t, alpha = a.s, a.t, Decimal(a.alpha)
    # Extra Gaussian tails are far below the Decimal oracle's test tolerance.
    radius = (a.p+40)*a.alpha
    S = [[Decimal(0) for _ in range(s)] for _ in range(t)]
    T = [[Decimal(0) for _ in range(s)] for _ in range(t)]
    for k in range(t):
        center = Decimal(s*k)/t
        for j in range(int(center)-radius, int(center)+radius+1):
            S[k][j % s] += (-(pi/alpha**2)*(Decimal(j)-center)**2).exp()/alpha
        # T has a much narrower window. Still independent of correction_radius.
        for j in range(-a.p, s+a.p):
            T[k][j % s] += (-pi*alpha**2*(Decimal(t*j)/s-k)**2).exp()
    indices = [(2*t*j+s)//(2*s) for j in range(s)]
    D = [(pi*alpha**2*(Decimal(t*j)/s-indices[j])**2).exp()
         for j in range(s)]
    N = [[T[k][j]*D[j] for j in range(s)] for k in indices]
    return S, N, D, indices


def decimal_phase(n, d):
    n %= d
    if 2*n > d: n -= d
    x = 2*decimal_pi()*n/d
    sine = sine_term = x
    cosine = cosine_term = Decimal(1)
    for k in range(1, 200):
        sine_term *= -x*x/((2*k)*(2*k+1))
        cosine_term *= -x*x/((2*k-1)*(2*k))
        previous = (sine,cosine)
        sine += sine_term
        cosine += cosine_term
        if previous == (sine,cosine): return cosine,sine
    raise AssertionError("oracle trigonometric series did not converge")


def decimal_fourier(values, multiplier):
    n = len(values)
    out = []
    for k in range(n):
        real = imag = Decimal(0)
        for j,(a,b) in enumerate(values):
            c,d = decimal_phase(-multiplier*j*k,n)
            real += a*c-b*d
            imag += a*d+b*c
        out.append((real/n,imag/n))
    return out


def tensor_matrix(values, shape, axis, matrix):
    """Independent dense address-gather oracle; never used in production."""
    new_shape = list(shape)
    new_shape[axis] = len(matrix)
    out = []
    for destination in product(*(range(n) for n in new_shape)):
        row = matrix[destination[axis]]
        total = [Decimal(0),Decimal(0)]
        for j,weight in enumerate(row):
            source = list(destination)
            source[axis] = j
            rank = 0
            for coordinate,n in zip(source,shape): rank = rank*n+coordinate
            for c in (0,1): total[c] += weight*values[rank][c]
        out.append(tuple(total))
    return out,tuple(new_shape)


class CertifiedExpTests(unittest.TestCase):
    def test_pi_enclosures(self):
        with localcontext() as ctx:
            ctx.prec = 260
            pi = decimal_pi()
            for bits in (16, 64, 128, 257, 512):
                low, high = pi_interval(bits)
                self.assertLess(Decimal(low)/(1 << bits), pi)
                self.assertGreater(Decimal(high)/(1 << bits), pi)
                COUNTS["certified_pi_enclosures"] += 1

    def test_exponential_enclosures(self):
        rng = random.Random(6518)
        with localcontext() as ctx:
            ctx.prec = 250
            pi = decimal_pi()
            cases = [(0, 1, 128, 0), (0, 1, 128, 150),
                     (-128, 1, 128, 0), (-127, 1, 128, 0),
                     (25, 9, 128, 48), (1, 4, 128, 2)]
            cases += [(-rng.randrange(1, 400), rng.randrange(1, 80), p, 0)
                      for p in (101, 128, 256) for _ in range(12)]
            exp = CertifiedExp()
            for n, d, p, shift in cases:
                result = exp.grid(n, d, p, shift=shift)
                exact = (pi*n/d).exp()/(1 << shift)
                self.assertTrue(result.verify_grid_error())
                self.assertLessEqual(Decimal(result.lower)/(1 << result.interval_bits), exact)
                self.assertGreaterEqual(Decimal(result.upper)/(1 << result.interval_bits), exact)
                self.assertLess(abs(Decimal(result.value)-exact*(1 << p)), 2)
                COUNTS["certified_exponential_enclosures"] += 1

    def test_invalid_scalar_inputs(self):
        exp = CertifiedExp()
        for args, kwargs in [((1, 1, 128), {}), ((1, 0, 128), {}),
                             ((0, 1, 1), {}), ((0, 1, 128), {"shift":-1})]:
            with self.assertRaises(ValueError): exp.grid(*args, **kwargs)
            COUNTS["negative_controls"] += 1


class GaussianLineTests(unittest.TestCase):
    def test_parameters_and_selector(self):
        for s in range(2, 16):
            for t in range(s+1, 33):
                if gcd(s, t) != 1: continue
                a = GaussianParameters(s, t, 128, 8)
                indices = list(a.selected_coordinates())
                self.assertEqual(indices, [(2*t*j+s)//(2*s) for j in range(s)])
                self.assertEqual(indices, sorted(set(indices)))
                self.assertEqual(indices[0], 0)
                self.assertLess(indices[-1], t)
                for j in range(-s, 2*s):
                    q = (2*t*j+s)//(2*s)
                    self.assertEqual(a.beta_numerator(j), t*j-s*q)
                self.assertLessEqual(a.iterations, a.alpha*a.alpha+1)
                self.assertGreaterEqual(4*a.alpha*a.alpha*a.correction_radius**2, a.p)
                COUNTS["gaussian_parameter_selector_cases"] += 1

    def test_periodic_head_accounting(self):
        ledger = Counter()
        tape = PeriodicTape([(j, -j) for j in range(3)], 20, ledger)
        indices = list(range(-10, 11))+[4, -8, 0]
        head = moves = 0
        for j in indices:
            moves += abs(head-j % 3)
            head = j % 3+1
            self.assertEqual(tape.read(j), (j % 3, -(j % 3)))
        self.assertEqual(ledger["gaussian_head_move_bits"], moves*20)
        self.assertEqual(ledger["gaussian_read_bits"], len(indices)*20)
        COUNTS["gaussian_periodic_head_reads"] += len(indices)

    def test_line_maps_against_analytic_matrices(self):
        rng = random.Random(39106)
        # Includes many-period expansion windows, different nonzero E weights,
        # and fixed Neumann loops continuing even after grid iterates vanish.
        for a in (GaussianParameters(3, 4, 128, 5),
                  GaussianParameters(5, 8, 128, 4),
                  GaussianParameters(15, 16, 128, 7)):
            with self.subTest(parameters=a), localcontext() as ctx:
                ctx.prec = 100
                scale = 1 << a.p
                values = [(rng.randrange(-scale//2, scale//2),
                           rng.randrange(-scale//2, scale//2)) for _ in range(a.s)]
                target = [(rng.randrange(-scale//2, scale//2),
                           rng.randrange(-scale//2, scale//2)) for _ in range(a.t)]
                u = [tuple(Decimal(v)/scale for v in z) for z in values]
                v = [tuple(Decimal(x)/scale for x in z) for z in target]
                S, N, D, selected = analytic_matrices(a)
                expected_A = [tuple(v/2 for v in z) for z in matvec(S, u)]
                expected_E = [tuple(x-y for x,y in zip(z,w)) for z,w in zip(matvec(N,u),u)]
                expected_J = solve(N, [tuple(x/2 for x in z) for z in u])
                expected_D = [tuple(x*d/(1 << (a.gamma-2)) for x in z) for d,z in zip(D,u)]
                expected_B = solve(N, [tuple(x/2 for x in v[j]) for j in selected])
                expected_B = [tuple(x*d/(1 << (a.gamma-2)) for x in z) for d,z in zip(D,expected_B)]
                engine = GaussianLine(a)
                outputs = [(engine.expand(values), expected_A, 16*a.p),
                           (engine.correction(values), expected_E, Decimal(a.p)/3),
                           (engine.neumann(values), expected_J, Decimal(3*a.p*a.p)/4),
                           (engine.diagonal(values), expected_D, 4),
                           (engine.compress(target), expected_B, a.p*a.p)]
                for actual, expected, bound in outputs:
                    for z, w in zip(actual, expected):
                        error2 = sum((Decimal(x)-y*scale)**2 for x,y in zip(z,w))
                        self.assertLess(error2, Decimal(bound)**2)
                        self.assertLessEqual(sum(x*x for x in z), scale*scale)
                    COUNTS["gaussian_analytic_map_comparisons"] += 1
                self.assertEqual(engine.ledger["gaussian_E_calls"], 2*a.iterations-1)
                self.assertEqual(engine.ledger["gaussian_neumann_terms"], 2*a.iterations)
                self.assertGreater(engine.ledger["gaussian_head_move_bits"], 0)
                self.assertLessEqual(engine.ledger["gaussian_peak_accumulator_bits"],
                                     a.p+(2*a.expansion_radius+a.iterations+1).bit_length()+2)

    def test_zero_extreme_inputs(self):
        a = GaussianParameters(3, 4, 128, 5)
        scale = 1 << a.p
        for z in ((0,0), (scale,0), (-scale,0), (0,scale), (0,-scale)):
            engine = GaussianLine(a)
            for operation, length in ((engine.expand,a.s), (engine.correction,a.s),
                                      (engine.neumann,a.s), (engine.diagonal,a.s),
                                      (engine.compress,a.t)):
                result = operation([z]*length)
                self.assertTrue(all(x*x+y*y <= scale*scale for x,y in result))
                if z == (0,0): self.assertTrue(all(v == (0,0) for v in result))
                COUNTS["gaussian_boundary_map_cases"] += 1

    def test_retained_permutation_transform_identity(self):
        # The middle Fourier map is an independent oracle here, not a hidden
        # replacement for the still-unimplemented production chirp stage.
        for a in (GaussianParameters(3,4,128,5), GaussianParameters(5,8,128,4)):
            with localcontext() as ctx:
                ctx.prec = 100
                scale = 1 << a.p
                source = [(scale//(5+j), -scale//(9+j)) for j in range(a.s)]
                engine = GaussianLine(a)
                expanded = engine.expand(source)
                middle = decimal_fourier([tuple(Decimal(x)/scale for x in z)
                                          for z in expanded],-a.s)
                grid = [tuple(int(x*scale) for x in z) for z in middle]
                actual = [tuple(v << a.gamma for v in z) for z in engine.compress(grid)]
                expected = decimal_fourier([tuple(Decimal(x)/scale for x in z)
                                            for z in source],a.t)
                bound = (1 << a.gamma)*(2*a.p*a.p+2)
                for z,w in zip(actual,expected):
                    self.assertLess(sum((Decimal(x)-y*scale)**2 for x,y in zip(z,w)),
                                    Decimal(bound)**2)
                self.assertGreater(engine.ledger["gaussian_E_calls"],0)
                COUNTS["gaussian_retained_permutation_identities"] += 1

    def test_invalid_parameters_and_payloads(self):
        for args in ((3,4,100,5), (4,4,128,5), (4,6,128,5),
                     (3,4,128,1), (3,4,128,12), (3,4,128,4),
                     (2,2**128,128,5), (3.0,4,128,5)):
            with self.assertRaises(ValueError): GaussianParameters(*args)
            COUNTS["negative_controls"] += 1
        engine = GaussianLine(GaussianParameters(3,4,128,5))
        for values in ([(0,0)], [(1 << 128, 1)]*3, [(0.5,0)]*3):
            with self.assertRaises(ValueError): engine.expand(values)
            COUNTS["negative_controls"] += 1


class GaussianTensorTests(unittest.TestCase):
    def test_adjacent_axis_streams(self):
        circuit = CompiledBitCircuit(SwapControl())
        for shape,axis in (((4,4),0),((4,8),0),((8,4),0),
                           ((2,4,8,2),1),((2,8,4,2),1),((16,16),0)):
            values = list(range(prod(shape)))
            ledger = Counter()
            actual,new_shape = adjacent_axes(values,shape,axis,circuit,ledger,
                                              len(values).bit_length())
            def mapping(c):
                c = list(c)
                c[axis],c[axis+1] = c[axis+1],c[axis]
                return c
            self.assertEqual(actual,scatter(values,shape,mapping,new_shape))
            restored,original_shape = adjacent_axes(actual,new_shape,axis,circuit,
                                                   ledger,len(values).bit_length())
            self.assertEqual((restored,original_shape),(values,shape))
            self.assertEqual(ledger["gaussian_adjacent_axis_swaps"],2)
            self.assertEqual(ledger["gaussian_excess_bit_moves"],2*int(shape[axis]!=shape[axis+1]))
            COUNTS["gaussian_adjacent_axis_roundtrips"] += 1

    def test_tensor_maps_against_dense_analytic_maps(self):
        circuit = CompiledBitCircuit(SwapControl())
        with localcontext() as ctx:
            ctx.prec = 100
            sources,targets,p,alpha = (3,5),(4,8),128,5
            scale = 1 << p
            matrices = []
            for s,t in zip(sources,targets):
                a = GaussianParameters(s,t,p,alpha)
                S,N,D,selected = analytic_matrices(a)
                A = [[v/2 for v in row] for row in S]
                identity = [[Decimal(i==j) for j in range(s)] for i in range(s)]
                inv = solve(N,identity)
                B = [[Decimal(0) for _ in range(t)] for _ in range(s)]
                for i in range(s):
                    for j,k in enumerate(selected):
                        B[i][k] = D[i]*inv[i][j]/(1 << (a.gamma-1))
                matrices.append((A,B))
            rng = random.Random(18052)
            for inverse in (False,True):
                shape = targets if inverse else sources
                values = [(rng.randrange(-scale//3,scale//3),
                           rng.randrange(-scale//3,scale//3)) for _ in range(prod(shape))]
                expected = [tuple(Decimal(x)/scale for x in z) for z in values]
                exact_shape = shape
                for axis in range(2):
                    expected,exact_shape = tensor_matrix(expected,exact_shape,axis,
                                                         matrices[axis][inverse])
                for order in ((0,1),(1,0)):
                    tensor = GaussianTensor(sources,targets,p,alpha,circuit)
                    data = values if inverse else tensor.embed(values)
                    actual = tensor.apply(data,inverse=inverse,axis_order=order)
                    if inverse: actual = tensor.extract(actual)
                    for z,w in zip(actual,expected):
                        self.assertLess(sum((Decimal(x)-y*scale)**2 for x,y in zip(z,w)),
                                        Decimal(2*p*p)**2)
                    self.assertEqual(tensor.ledger["gaussian_fixed_tensor_codec_calls"],2)
                    self.assertEqual(tensor.ledger["gaussian_adjacent_axis_swaps"],2)
                    self.assertGreater(tensor.ledger["gaussian_tensor_skipped_lines"],0)
                    self.assertEqual(tensor.ledger["adaptive_basis_codec_calls"],0)
                    self.assertEqual(tensor.ledger["reference_permutation_records"],0)
                    COUNTS["gaussian_tensor_analytic_comparisons"] += 1

    def test_padding_and_order_rejections(self):
        circuit = CompiledBitCircuit(SwapControl())
        tensor = GaussianTensor((3,5),(4,8),128,5,circuit)
        zeros = tensor.embed([(0,0)]*15)
        self.assertEqual(tensor.extract(zeros),[(0,0)]*15)
        malformed = list(zeros)
        malformed[7] = (1,0)
        for action in (lambda: tensor.apply(malformed),
                       lambda: tensor.extract(malformed),
                       lambda: tensor.apply(zeros,axis_order=(0,0)),
                       lambda: tensor.embed([(0,0)]),
                       lambda: GaussianTensor((3,5),(4,16),128,5,circuit),
                       lambda: adjacent_axes(list(range(32)),(2,16),0,circuit,Counter(),8)):
            with self.assertRaises(ValueError): action()
            COUNTS["negative_controls"] += 1
if __name__ == "__main__": unittest.main(verbosity=2)
