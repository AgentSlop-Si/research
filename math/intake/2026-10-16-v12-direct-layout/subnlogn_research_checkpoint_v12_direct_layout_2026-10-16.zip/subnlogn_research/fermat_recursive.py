"""Recursive exact multiplication modulo 2**n+1, with streamed DIF/DIT FFTs.

No native product of growing coefficient integers is used. Leaves perform a
fixed-threshold schoolbook bit loop. This is a SHORT-PRODUCT backend for the
larger reduction, not itself a below-N-log-N multiplier. See FERMAT_PROOF.txt
for the arithmetic recurrence and the boundary of the tape-cost audit.
"""
from collections import Counter
from dataclasses import dataclass

from stream_moves import Reader,copy_records,emit
from synthetic import _blocks_to_bytes


class NullLedger(dict):
    """Discard optional global audit counters in the algorithmic execution."""
    def __missing__(self,key): return 0
    def __setitem__(self,key,value): pass


@dataclass(frozen=True)
class FermatPlan:
    exponent: int
    log_length: int
    length: int
    digit_bits: int
    child_exponent: int

    @classmethod
    def make(cls,n):
        if type(n) is not int or n<=16:
            raise ValueError("recursive exponent must exceed 16")
        log_n = n.bit_length()-1
        k = max(2,log_n//2-log_n.bit_length())
        length = 1 << k
        if n % length:
            raise ValueError("exponent lacks the required binary divisibility")
        width = n//length
        child = ((2*width+k+2+length-1)//length)*length
        if not child<n: raise ValueError("recursive exponent does not decrease")
        return cls(n,k,length,width,child)


class FermatRing:
    def __init__(self,n,ledger):
        if type(n) is not int or n<1: raise ValueError("positive ring exponent required")
        self.n,self.q,self.mask,self.ledger = n,(1 << n)+1,(1 << n)-1,ledger
        ledger["fermat_modulus_setup_bits"] += 2*(n+1)

    def check(self,x):
        if type(x) is not int or not 0<=x<self.q:
            raise ValueError("canonical Fermat residue required")

    def shift(self,x,exponent):
        """Canonical x*2**exponent, including the exceptional residue 2**n."""
        exponent %= 2*self.n
        negate = exponent>=self.n
        if negate: exponent -= self.n
        if exponent:
            x = ((x << exponent) & self.mask)-(x >> (self.n-exponent))
            if x<0: x += self.q
        if negate and x: x = self.q-x
        self.ledger["fermat_shift_calls"] += 1
        self.ledger["fermat_linear_arithmetic_bit_units"] += 8*(self.n+1)
        return x

    def butterfly(self,u,v):
        a,b = u+v,u-v
        if a>=self.q: a -= self.q
        if b<0: b += self.q
        self.ledger["fermat_butterflies"] += 1
        self.ledger["fermat_linear_arithmetic_bit_units"] += 6*(self.n+1)
        return a,b


def streamed_fft(values,ring,*,inverse=False):
    """Forward DIF / inverse DIT, retaining bit-reversed frequency order.

    Every stage splits sequentially, performs paired arithmetic, and merges
    sequentially. It never accesses a payload at a computed scatter address.
    """
    length = len(values)
    if length<1 or length & (length-1) or (2*ring.n)%length:
        raise ValueError("FFT length must be a power of two dividing 2n")
    for value in values: ring.check(value)
    ledger,width = ring.ledger,ring.n+1
    data = list(values)
    stage = 2 if inverse else length
    while stage<=length if inverse else stage>=2:
        half = stage//2
        source = Reader(data,ledger,width)
        first,second = [],[]
        for _ in range(length//stage):
            copy_records(source,first,half,ledger,width)
            copy_records(source,second,half,ledger,width)
        source.finish()
        left,right = Reader(first,ledger,width),Reader(second,ledger,width)
        sums,differences = [],[]
        step = 2*ring.n//stage
        for _ in range(length//stage):
            for j in range(half):
                u,v = left.take(),right.take()
                if inverse and j: v = ring.shift(v,-j*step)
                a,b = ring.butterfly(u,v)
                if not inverse and j: b = ring.shift(b,j*step)
                emit(sums,a,ledger,width)
                emit(differences,b,ledger,width)
        left.finish(); right.finish()
        sums,differences = Reader(sums,ledger,width),Reader(differences,ledger,width)
        data = []
        for _ in range(length//stage):
            copy_records(sums,data,half,ledger,width)
            copy_records(differences,data,half,ledger,width)
        sums.finish(); differences.finish()
        ledger["fermat_fft_stages"] += 1
        stage = stage*2 if inverse else stage//2
    ledger["fermat_fft_calls"] += 1
    return data


def split_digits(value,width,count):
    raw = memoryview(value.to_bytes((width*count+7)//8,"little"))
    mask = (1 << width)-1
    out = []
    for j in range(count):
        byte,offset = divmod(j*width,8)
        out.append((int.from_bytes(raw[byte:byte+(offset+width+7)//8],"little") >> offset)&mask)
    return out


class RecursiveFermatMultiplier:
    """Callable nonnegative integer backend; mutable stacks must be idle on entry.

    leaf_bits is bounded by an absolute constant and fixed for this instance.
    Passing a ledger enables optional global audit counters and frame checks;
    the default disables them to avoid charging growing diagnostic integers
    as if they were constant-cost machine counters.
    Stacks are shared at every recursion depth. Only the current top is touched;
    parent operand pairs are pushed once, not recopied before every child.
    """
    def __init__(self,leaf_bits=1024,*,ledger=None):
        if type(leaf_bits) is not int or not 16<=leaf_bits<=4096:
            raise ValueError("fixed leaf threshold must be in [16,4096]")
        self.leaf_bits = leaf_bits
        self.audit = ledger is not None
        self.ledger = ledger if self.audit else NullLedger()
        self.operands,self.results = [],[]
        self.operand_bits = self.result_bits = 0
        self.active = False

    def _peaks(self):
        if not self.audit: return
        self.ledger["fermat_peak_operand_stack_bits"] = max(
            self.ledger["fermat_peak_operand_stack_bits"],self.operand_bits)
        self.ledger["fermat_peak_result_stack_bits"] = max(
            self.ledger["fermat_peak_result_stack_bits"],self.result_bits)

    def _push_operands(self,a,b,n):
        self.operands.append((a,b,n))
        bits = 2*(n+1)
        if self.audit: self.operand_bits += bits
        self.ledger["fermat_operand_push_bits"] += bits
        self._peaks()

    def _pop_operands(self,n):
        a,b,width = self.operands.pop()
        if width!=n: raise AssertionError("operand stack frame width")
        bits = 2*(n+1)
        if self.audit: self.operand_bits -= bits
        self.ledger["fermat_operand_pop_bits"] += bits
        return a,b

    def _push_result(self,value,n):
        self.results.append((value,n))
        if self.audit: self.result_bits += n+1
        self.ledger["fermat_result_push_bits"] += n+1
        self._peaks()

    def _pop_result(self,n):
        value,width = self.results.pop()
        if width!=n: raise AssertionError("result stack frame width")
        if self.audit: self.result_bits -= n+1
        self.ledger["fermat_result_pop_bits"] += n+1
        return value

    def _schoolbook(self,a,b,n):
        # No native coefficient multiplication, even at a leaf. This fixed-n
        # loop keeps leading-zero and zero inputs within the same leaf schedule.
        result = 0
        for _ in range(n):
            if b & 1: result += a
            a <<= 1
            b >>= 1
        self.ledger["fermat_leaf_calls"] += 1
        self.ledger["fermat_leaf_bit_iterations"] += n
        self.ledger["fermat_leaf_bit_work_upper"] += 8*n*n
        self.ledger["fermat_max_leaf_exponent"] = max(self.ledger["fermat_max_leaf_exponent"],n)
        return result

    def _mod_product(self,a,b,n,depth):
        ring = FermatRing(n,self.ledger)
        ring.check(a); ring.check(b)
        self.ledger["fermat_modular_calls"] += 1
        self.ledger["fermat_max_depth"] = max(self.ledger["fermat_max_depth"],depth)
        # 2**n is the canonical representative of -1; it does not fit in the
        # n-bit digit array. Handle it exactly, without a coefficient product.
        if a==ring.q-1 or b==ring.q-1:
            other = b if a==ring.q-1 else a
            self.ledger["fermat_minus_one_shortcuts"] += 1
            self.ledger["fermat_linear_arithmetic_bit_units"] += 2*(n+1)
            return ring.q-other if other else 0
        if n<=self.leaf_bits:
            result = self._schoolbook(a,b,n)
            residue = (result & ring.mask)-(result >> n)
            return residue+ring.q if residue<0 else residue
        plan = FermatPlan.make(n)
        L,m,bits = plan.length,plan.child_exponent,plan.digit_bits
        self.ledger["fermat_internal_nodes"] += 1
        self.ledger["fermat_parent_exponent_sum"] += n
        self.ledger["fermat_child_exponent_sum"] += L*m
        self.ledger["fermat_input_digit_bits"] += 2*n
        child_ring = FermatRing(m,self.ledger)
        twist_step = m//L
        first = [child_ring.shift(v,j*twist_step) for j,v in enumerate(split_digits(a,bits,L))]
        second = [child_ring.shift(v,j*twist_step) for j,v in enumerate(split_digits(b,bits,L))]
        first = streamed_fft(first,child_ring)
        second = streamed_fft(second,child_ring)
        input_base = len(self.operands) if self.audit else None
        output_base = len(self.results) if self.audit else None
        for left,right in zip(reversed(first),reversed(second)):
            self._push_operands(left,right,m)
        # Growing payloads are parked once. Ancestor descriptors retain only
        # the small integer plan; large moduli and transform arrays are dropped.
        a=b=left=right=0
        first=second=child_ring=ring=None
        for _ in range(L):
            left,right = self._pop_operands(m)
            value = self._mod_product(left,right,m,depth+1 if self.audit else 0)
            self._push_result(value,m)
            self.ledger["fermat_recursive_children"] += 1
        if self.audit and len(self.operands)!=input_base: raise AssertionError("operand frame not restored")
        pointwise = [self._pop_result(m) for _ in range(L)]
        pointwise.reverse()
        self.ledger["fermat_result_reversal_bits"] += L*(m+1)
        if self.audit and len(self.results)!=output_base: raise AssertionError("result frame not restored")
        child_ring = FermatRing(m,self.ledger)
        raw = streamed_fft(pointwise,child_ring,inverse=True)
        carry,digits = 0,[]
        mask = (1 << bits)-1
        coefficient_bound = ((1 << (2*bits))-(1 << (bits+1))+1) << plan.log_length
        for j,value in enumerate(raw):
            value = child_ring.shift(value,-plan.log_length-j*twist_step)
            coefficient = value if value<=child_ring.q//2 else value-child_ring.q
            if abs(coefficient)>coefficient_bound: raise ArithmeticError("negacyclic coefficient capacity")
            total = coefficient+carry
            digits.append(total & mask)
            carry = total >> bits
            self.ledger["fermat_reconstruction_records"] += 1
        low = int.from_bytes(_blocks_to_bytes(digits,bits),"little")
        q = (1 << n)+1
        if not -q<carry<q: raise ArithmeticError("terminal signed carry bound")
        result = low-carry
        if result<0: result += q
        if result>=q: result -= q
        if not 0<=result<q: raise ArithmeticError("reconstructed Fermat residue")
        self.ledger["fermat_reconstruction_bit_units"] += 8*(n+L*(m+1))
        return result

    def modular(self,a,b,exponent):
        if self.active or self.operands or self.results:
            raise RuntimeError("recursive multiplier is already active")
        if type(exponent) is not int or exponent<1: raise ValueError("positive exponent required")
        self.active = True
        try:
            result = self._mod_product(a,b,exponent,0)
            if self.operands or self.results or self.operand_bits or self.result_bits:
                raise AssertionError("top-level stacks not empty")
            return result
        finally:
            self.active = False
            # Exception cleanup never leaks a partially consumed frame into
            # a later multiplication. Normal completion already emptied them.
            self.operands.clear(); self.results.clear()
            self.operand_bits=self.result_bits=0

    def __call__(self,a,b):
        if any(type(v) is not int or v<0 for v in (a,b)):
            raise ValueError("nonnegative integers required")
        n = max(1,a.bit_length(),b.bit_length())
        exponent = 1 << (2*n-1).bit_length()
        self.ledger["fermat_integer_calls"] += 1
        self.ledger["fermat_integer_input_bits"] += 2*n
        self.ledger["fermat_max_root_exponent"] = max(self.ledger["fermat_max_root_exponent"],exponent)
        result = self.modular(a,b,exponent)
        if result.bit_length()>2*n: raise ArithmeticError("ordinary product overflow")
        return result
