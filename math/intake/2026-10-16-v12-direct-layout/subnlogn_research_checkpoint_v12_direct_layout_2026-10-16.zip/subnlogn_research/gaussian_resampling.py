"""Ordered Gaussian A, E, J', D', C and B0 line maps on fixed p-bit grids.

Formulas and truncation schedule: Harvey--van der Hoeven (2021), author-hosted
45-page manuscript, Lemmas 4.8--4.12; retained permutations: pinned preprint
section 07. These routines do not execute P_s or P_t, or any Fourier transform.
The scalar exponential backend has certified accuracy, NOT the required fast
bit-cost proof. This module alone is not a sub-N-log-N multiplication algorithm.
"""
from collections import Counter
from dataclasses import dataclass
from math import gcd, isqrt

from certified_exp import CertifiedExp, ceil_div
from synthetic import trunc_shift


def ceil_sqrt(n):
    v = isqrt(n)
    return v+(v*v != n)


@dataclass(frozen=True)
class GaussianParameters:
    s: int
    t: int
    p: int
    alpha: int

    def __post_init__(self):
        if (any(type(v) is not int for v in (self.s, self.t, self.p, self.alpha))
                or self.p <= 100 or not 2 <= self.s < self.t < 1 << self.p
                or gcd(self.s, self.t) != 1 or self.alpha < 2
                or self.alpha*self.alpha >= self.p
                or (self.t-self.s)*self.alpha**4 <= self.p*self.s):
            raise ValueError("Gaussian resampling hypotheses are not satisfied")

    @property
    def expansion_radius(self): return ceil_sqrt(self.p)*self.alpha
    @property
    def correction_radius(self):
        # Least m with 4*alpha**2*m**2 >= p, without floating-point sqrt.
        return ceil_sqrt(ceil_div(self.p, 4*self.alpha*self.alpha))
    @property
    def iterations(self):
        return ceil_div(self.p*self.s, self.alpha*self.alpha*(self.t-self.s))
    @property
    def gamma(self): return 2*self.alpha*self.alpha
    @property
    def component_bits(self): return self.p+2

    def beta_numerator(self, j):
        """s*beta_j; periodic also for negative and out-of-period j."""
        residue = self.t*j % self.s
        return residue-self.s if 2*residue >= self.s else residue

    def selected_coordinates(self):
        """Ordered nearest integers using only quotient/remainder increments."""
        h, rho = divmod(self.t, self.s)
        f = e = 0
        for _ in range(self.s):
            yield f+(2*e >= self.s)
            carry = int(e+rho >= self.s)
            e, f = e+rho-carry*self.s, f+h+carry


class PeriodicTape:
    """Logical two-way record head; no uncharged computed-index payload read.

    Integer counters and Python storage are not a finite-tape simulation.
    Head positions move one record at a time, with all distances recorded.
    """
    def __init__(self, values, width, ledger):
        self.values, self.width, self.ledger = values, width, ledger
        self.head = 0

    def read(self, periodic_index):
        target = periodic_index % len(self.values)
        while self.head != target:
            self.head += 1 if self.head < target else -1
            self.ledger["gaussian_head_move_bits"] += self.width
        value = self.values[self.head]
        self.head += 1
        self.ledger["gaussian_read_bits"] += self.width
        return value


class GaussianLine:
    """Each completed numerical boundary uses the same p+2 signed bits."""
    def __init__(self, parameters, *, ledger=None):
        self.parameters = parameters
        self.ledger = ledger if ledger is not None else Counter()
        self.exponential = CertifiedExp(self.ledger)

    def _check(self, values, size):
        if len(values) != size:
            raise ValueError("Gaussian line length mismatch")
        bound = 1 << (2*self.parameters.p)
        for z in values:
            if (not isinstance(z, (tuple, list)) or len(z) != 2
                    or any(type(v) is not int for v in z)
                    or z[0]*z[0]+z[1]*z[1] > bound):
                raise ValueError("Gaussian line must consist of disk-grid pairs")
        self.ledger["gaussian_disk_checks"] += size

    def _output(self, values, size):
        self._check(values, size)
        self.ledger["gaussian_write_bits"] += size*2*self.parameters.component_bits
        return values

    def _multiply_real(self, x, z):
        self.ledger["gaussian_scalar_integer_products"] += 2
        p = self.parameters.p
        return trunc_shift(x*z[0], p), trunc_shift(x*z[1], p)

    def _sum(self, total, term):
        out = total[0]+term[0], total[1]+term[1]
        self.ledger["gaussian_accumulator_additions"] += 2
        peak = max(abs(v).bit_length()+1 for v in out)
        self.ledger["gaussian_peak_accumulator_bits"] = max(
            self.ledger["gaussian_peak_accumulator_bits"], peak)
        return out

    def expand(self, values):
        """A=S/2; includes every periodic integer in the strict Gaussian window."""
        a = self.parameters
        self._check(values, a.s)
        tape = PeriodicTape(values, 2*a.component_bits, self.ledger)
        beta = (1 << a.p)//(2*a.alpha)
        radius = a.expansion_radius
        out = []
        for k in range(a.t):
            # Strict inequalities, including when s*k/t is an integer.
            start = (a.s*k-radius*a.t)//a.t+1
            stop = ceil_div(a.s*k+radius*a.t, a.t)
            total = (0, 0)
            for j in range(start, stop):
                numerator = -(a.t*j-a.s*k)**2
                denominator = a.alpha*a.alpha*a.t*a.t
                x = self.exponential.grid(numerator, denominator, a.p).value
                weight = trunc_shift(beta*x, a.p)
                self.ledger["gaussian_scalar_integer_products"] += 1
                total = self._sum(total, self._multiply_real(weight, tape.read(j)))
                self.ledger["gaussian_expansion_terms"] += 1
            out.append(total)
        self.ledger["gaussian_A_calls"] += 1
        return self._output(out, a.t)

    def correction(self, values):
        """E=C T D-I; the omitted term is h=0, not every h divisible by s."""
        a = self.parameters
        self._check(values, a.s)
        tape = PeriodicTape(values, 2*a.component_bits, self.ledger)
        out = []
        for j in range(a.s):
            beta = a.beta_numerator(j)
            total = (0, 0)
            for h in range(-a.correction_radius, a.correction_radius+1):
                if h == 0: continue
                other = a.beta_numerator(j+h)
                numerator = a.alpha*a.alpha*((a.t*h+beta)**2-other*other)
                if numerator <= 0: raise AssertionError("off-diagonal Gaussian exponent")
                weight = self.exponential.grid(-numerator, a.s*a.s, a.p).value
                total = self._sum(total, self._multiply_real(weight, tape.read(j+h)))
                self.ledger["gaussian_correction_terms"] += 1
            out.append(total)
        self.ledger["gaussian_E_calls"] += 1
        return self._output(out, a.s)

    def neumann(self, values):
        """J'=N**(-1)/2, with a fixed parameter-derived iteration count."""
        a = self.parameters
        self._check(values, a.s)
        current = [(trunc_shift(x, 1), trunc_shift(y, 1)) for x, y in values]
        result = list(current)
        for j in range(1, a.iterations):
            current = self.correction(current)
            sign = -1 if j % 2 else 1
            result = [self._sum(z, (sign*w[0], sign*w[1]))
                      for z, w in zip(result, current)]
        self.ledger["gaussian_neumann_terms"] += a.iterations
        self.ledger["gaussian_J_calls"] += 1
        return self._output(result, a.s)

    def diagonal(self, values):
        """D'=2**(-(2*alpha**2-2))*D, with a disk-valued exponential."""
        a = self.parameters
        self._check(values, a.s)
        out = []
        for j, z in enumerate(values):
            beta = a.beta_numerator(j)
            weight = self.exponential.grid(a.alpha*a.alpha*beta*beta,
                a.s*a.s, a.p, shift=a.gamma-2).value
            out.append(self._multiply_real(weight, z))
        self.ledger["gaussian_D_calls"] += 1
        return self._output(out, a.s)

    def select(self, values):
        """C: one forward scan, with no sorting or Fourier dilation."""
        a = self.parameters
        self._check(values, a.t)
        wanted = iter(a.selected_coordinates())
        next_index = next(wanted, None)
        out = []
        for k, value in enumerate(values):
            self.ledger["gaussian_selection_read_bits"] += 2*a.component_bits
            if k == next_index:
                out.append(value)
                next_index = next(wanted, None)
        if next_index is not None or len(out) != a.s:
            raise AssertionError("ordered selector failed")
        self.ledger["gaussian_C_calls"] += 1
        return self._output(out, a.s)

    def compress(self, values):
        """B0=D' J' C, retaining both Fourier permutations in the identity."""
        out = self.diagonal(self.neumann(self.select(values)))
        self.ledger["gaussian_B0_calls"] += 1
        return out
