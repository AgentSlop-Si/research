"""Exact products through CRT -> Gaussian/chirp transforms -> CRT -> carries.

This is the final reduction's executable arithmetic path, with explicit finite
parameters and injected backends. It is NOT the complete asymptotically fast
algorithm: automatic large-input parameters, fast scalar/integer backends and
the complete fixed-tape cost proof are still missing.
"""
from collections import Counter
from operator import mul

from crt_layout import CRTLayout
from packed_stream import GaussianRecordCodec
from resampled_transform import SourceTransform,grid_product,integer_product
from synthetic import _blocks_to_bytes,direct_layer


def nearest_integer(numerator,p):
    value = (abs(numerator)+(1 << (p-1))) >> p
    return -value if numerator<0 else value


def radix_digits(value,width,count):
    raw = memoryview(value.to_bytes((count*width+7)//8,"little"))
    mask = (1 << width)-1
    out = []
    for j in range(count):
        byte,offset = divmod(j*width,8)
        out.append((int.from_bytes(raw[byte:byte+(offset+width+7)//8],"little") >> offset) & mask)
    return out


def multiply_resampled(x,y,*,sources,targets,p,alpha,digit_bits,circuit,
                       chunk_bits=1,layer=direct_layer,layout_move=None,
                       integer_multiply=mul,transform_factory=SourceTransform,ledger=None,
                       crt_factory=CRTLayout):
    if any(type(v) is not int or v<0 for v in (x,y)):
        raise ValueError("nonnegative integer inputs required")
    if type(digit_bits) is not int or digit_bits<1 or p<digit_bits+2:
        raise ValueError("positive digit width and sufficient input precision required")
    ledger = ledger if ledger is not None else Counter()
    crt = crt_factory(sources,targets,circuit,ledger=ledger)
    transform = transform_factory(sources,targets,p,alpha,circuit,chunk_bits=chunk_bits,
        layer=layer,layout_move=layout_move,integer_multiply=integer_multiply,ledger=ledger)
    n = max(1,x.bit_length(),y.bit_length())
    count = (n+digit_bits-1)//digit_bits
    if 2*count-2 >= crt.S: raise ValueError("source convolution would wrap nonzero coefficients")
    recovery_scale = crt.S*crt.S*(1 << (2*digit_bits+4))
    error_numerator = recovery_scale*(3*transform.error+2)
    if 2*error_numerator >= 1 << p:
        raise ValueError("finite parameter certificate does not ensure unique coefficient recovery")
    codec = GaussianRecordCodec(1,(p+2+7)//8)

    def prepare(value):
        digits = radix_digits(value,digit_bits,count)
        records = [[(digit << (p-digit_bits-2),0)] for digit in digits]
        records += [[(0,0)] for _ in range(crt.S-count)]
        encoded = codec.encode(records,ledger)
        padded = crt.forward(encoded,codec.width)
        ledger["resampled_input_digit_reads"] += count
        return [row[0] for row in codec.decode(padded,ledger)]

    left,right = transform.apply(prepare(x)),transform.apply(prepare(y))
    pointwise = [grid_product(z,w,p,ledger,integer_multiply) for z,w in zip(left,right)]
    opposite = transform.apply(pointwise,opposite=True)
    # Keep the two S scalings explicit; they undo separate normalizations.
    def scale_S(values):
        return [tuple(integer_product(v,crt.S,ledger,integer_multiply) for v in z) for z in values]
    scaled_once = scale_S(opposite)
    scaled_twice = [tuple(v << (2*digit_bits+4) for v in z) for z in scale_S(scaled_once)]
    ledger["resampled_exact_S_scalings"] += 4*crt.T
    bound = count*((1 << digit_bits)-1)**2
    coefficients = []
    for real,imag in scaled_twice:
        value = nearest_integer(real,p)
        if nearest_integer(imag,p)!=0 or not 0<=value<=bound:
            raise ArithmeticError("coefficient recovery violates the certified integer range")
        coefficients.append(value)
    ordered = crt.inverse(coefficients,max(1,bound.bit_length()+1))
    if any(ordered[2*count-1:]): raise ArithmeticError("nonzero coefficient above product degree")
    carry,output_digits = 0,[]
    base = 1 << digit_bits
    carry_limit = count*(base-1)
    for coefficient in ordered:
        total = coefficient+carry
        carry,digit = total >> digit_bits,total & (base-1)
        if carry>carry_limit: raise ArithmeticError("radix carry bound")
        output_digits.append(digit)
        ledger["resampled_carry_steps"] += 1
    while carry:
        carry,digit = carry >> digit_bits,carry & (base-1)
        output_digits.append(digit)
        ledger["resampled_carry_steps"] += 1
    result = int.from_bytes(_blocks_to_bytes(output_digits,digit_bits),"little")
    if result.bit_length()>2*n: raise ArithmeticError("product output exceeds 2n bits")
    return result,dict(input_bits=n,digit_bits=digit_bits,digit_count=count,
        sources=list(sources),targets=list(targets),precision_bits=p,alpha=alpha,
        gamma=transform.gamma,source_error_units=str(transform.error),
        recovery_error_numerator=str(error_numerator),recovery_error_denominator_bits=p,
        ledger=dict(ledger),
        implementation_status={"reduction":"CRT/Gaussian/chirp/twist/source transforms/carries executed",
            "parameter_selection":"explicit finite parameters, not the asymptotic automatic selector",
            "scalar_backend":getattr(transform,"scalar_backend_description",
                "certified integer Taylor intervals, fast bound not established"),
            "integer_backend":"injected callable; default native Python multiplication",
            "sub_n_log_n_proved_for_implementation":False})
