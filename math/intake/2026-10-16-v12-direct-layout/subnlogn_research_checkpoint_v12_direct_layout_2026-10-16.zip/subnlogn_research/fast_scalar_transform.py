"""Connect fast scalar functions to the existing finite numerical reduction.

Only exponential/phase evaluation is changed. Gaussian weight arithmetic,
parameter construction and general checks still have their existing backends.
Consequently this adapter does not establish an end-to-end fast bit bound.
"""
from fast_scalar import FastCertifiedExp, FastCertifiedPhase
from resampled_transform import SourceTransform


class FastScalarSourceTransform(SourceTransform):
    scalar_backend_description = (
        "bit-burst exponential/phase with supplied integer backend; "
        "other Gaussian arithmetic and full bit-cost audit remain unchanged")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        backend = self.convolver.integer_multiply
        self.convolver.phase = FastCertifiedPhase(self.ledger, integer_multiply=backend)
        for line in self.gaussian.lines:
            line.exponential = FastCertifiedExp(self.ledger, integer_multiply=backend)
