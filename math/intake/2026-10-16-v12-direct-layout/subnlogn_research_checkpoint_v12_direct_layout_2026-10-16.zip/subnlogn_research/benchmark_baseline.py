"""Cold full-product baseline, with frozen parameter rules and checked outputs.

This benchmarks the supplied enhanced.py and native Python. None of these
implementations is represented as the requested sub-N-log-N algorithm.
"""
import argparse
from collections import defaultdict
import gc
import hashlib
import importlib.util
import json
from math import isqrt
from pathlib import Path
import platform
import random
from statistics import median
import sys
from time import perf_counter_ns


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-dir", type=Path, required=True)
    parser.add_argument("--sizes", type=int, nargs="+", default=[4096, 16384, 65536, 262144])
    parser.add_argument("--pairs", type=int, default=7)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("baseline_benchmarks.json"))
    args = parser.parse_args()
    if args.pairs < 1 or args.repeats < 1 or any(n < 2 for n in args.sizes):
        parser.error("positive pairs/repeats and bit lengths >= 2 required")
    root = args.baseline_dir.resolve()
    sys.path.insert(0, str(root))
    spec = importlib.util.spec_from_file_location("baseline_enhanced", root/"enhanced.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    gc.disable()
    result = {"python": sys.version, "platform": platform.platform(), "gc_disabled": True,
              "method": "Cold setup and conversion included; frozen m rules; randomly interleaved calls; correctness outside timed interval",
              "status": "baseline only; goal not achieved", "sizes": [],
              "source_sha256": {name: hashlib.sha256((root/name).read_bytes()).hexdigest()
                                for name in ("enhanced.py", "optimized.py", "verify.py")}}
    for n in args.sizes:
        rng = random.Random(87123+n)
        pairs = [((1 << (n-1)) | rng.getrandbits(n-1), (1 << (n-1)) | rng.getrandbits(n-1)) for _ in range(args.pairs)]
        expected = [x*y for x, y in pairs]
        configs = [("mersenne_matrix", max(2, round(3*isqrt(n)/16)*16), "matrix_ntt", 1),
                   ("binary_vector", max(2, round(4*isqrt(n)/16)*16), "vector_ntt", 0),
                   ("native_python", None, None, None)]
        jobs = [(i, c) for _ in range(args.repeats) for i in range(args.pairs) for c in range(len(configs))]
        rng.shuffle(jobs)
        durations, phases, info = defaultdict(list), defaultdict(lambda: defaultdict(list)), {}
        for i, c in jobs:
            x, y = pairs[i]
            name, m, kind, delta = configs[c]
            start = perf_counter_ns()
            if m is None:
                actual = x*y
                details = None
            else:
                actual, details = module.multiply(x, y, (1 << m)-delta, kind=kind)
            durations[name].append(perf_counter_ns()-start)
            if actual != expected[i]: raise AssertionError((n, name, i))
            if details:
                info[name] = {k: details[k] for k in ("layout", "q_bits", "counts", "digits")}
                for phase, value in details["timings_ns"].items(): phases[name][phase].append(value)
        rows = []
        for name, m, kind, delta in configs:
            samples = durations[name]
            rows.append(dict(name=name, m=m, kind=kind, median_ns=median(samples), min_ns=min(samples),
                             max_ns=max(samples), samples_ns=samples, samples=len(samples),
                             phase_medians_ns={k: median(v) for k, v in phases[name].items()},
                             details=info.get(name)))
        result["sizes"].append(dict(input_bits=n, configurations=rows))
        args.output.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
        print(json.dumps({"bits": n, "median_ms": {r["name"]: r["median_ns"]/1e6 for r in rows}}), flush=True)


if __name__ == "__main__": main()
