# v11: tighter conditional exponent and a scoped tuning ceiling

This note concerns only the existing h=100 networks, beta=1/2, and the seven
cost margins in the pinned preprint/v10 certificate. It is not a lower bound
on integer multiplication, a global network optimum, or a completed algorithm.

## A certified improvement with unchanged networks

The old certificate replaced `ln(m)` by 20 for `m=100^3=10^6`. Let

    L = 13815511 / 1000000 = 13.815511.

The exact rational program verifies

    sum_{j=0}^{99} L^j / j! > 10^6.

All omitted exponential terms are positive, hence `exp(L)>10^6` and
`ln(10^6)<L`. No floating-point logarithm is used in the proof.
For either network let `eta` be its exact relative rank deficit. Choose
`1-tau=eta_bit/L` and `1-sigma=eta_complex/L`. If `a=1-tau`, then

    m^tau = m exp(-a ln m) > m exp(-a L)
          = m exp(-eta_bit) > m(1-eta_bit).

Thus the same strict rank-recursion inequality is certified more tightly.
Choose the remaining parameters exactly as in the v10 family:

    beta = 1/2, delta = 1/16,
    lambda = 1-a^2, lambda' = 1-a^2/2,
    c = a(1-2a)/(2(1-a)), epsilon = a(1-a),
    kappa = a^3(1-2a)/4.

All layer, dimension, guard, layout, Gaussian and scalar conditions and all
seven `margin >= 2*kappa` inequalities are checked using exact fractions.
The previous epsilon expression simplifies to `a(1-a)` identically.

    kappa_v10 = 1.0564626242044788e-37 approximately,
    kappa_v11 = 3.205112405573184e-37 approximately,
    ratio      = 3.033815235997249 approximately.

The exact rational values are in `parameter_certificate_v11.json`. This is
an improvement of a **conditional feasible-parameter certificate**, not a
runtime factor or transfer of a theorem to the runnable implementation.
All borrowed network and analytic assumptions remain borrowed.

For any fixed positive kappa, `N(log N)^(1-kappa)/(N log N)=(log N)^(-kappa)`
tends to zero. The unresolved issue is not this limit; it is proving that one
complete specified algorithm actually has the proposed bound.

## Why further c/epsilon tuning cannot change the story

Fix `a=1-tau`, `beta=1/2`, and retain the v10 conditions. From

    tau(1+2c) < lambda < 1

we obtain `c < a/(2(1-a))`. From the axis-layout condition

    epsilon(2-tau) < 1-tau

we obtain `epsilon < a/(1+a)`. Finally the second cost margin requires

    2*kappa <= epsilon*c*a.

Combining gives the universal ceiling **for this restricted parameter family**

    kappa < a^3 / (4(1-a^2)).

The existing v10 choice attains the fraction `(1-2a)(1-a^2)` of this ceiling.
The relative room above it is only about `1.5008410686813471e-12`.
Thus adjusting c and epsilon while leaving these bottlenecks intact cannot
produce a material exponent improvement. The tighter logarithm changes `a`,
which is why it legitimately yields the approximately threefold increase.

A larger advance requires changing a structural cost inequality or the actual
rank budget, while paying the cost of the replacement. Smaller dimensions,
finite benchmarks and more optimistic constant choices do not supply that step.

## Cutoff remains enormous

With `b=ceil(log2 N)`, `d=floor(b^epsilon)` and `K=floor(d^c)`, having `K>=2`
necessarily requires

    log2 b >= 1/(epsilon*c) approximately 1.6947064850531526e24.

This is necessary only, not a sufficient global algorithm crossover. Other
cutoffs can be larger. It prevents interpreting the improved kappa as a
practical runtime improvement at feasible input sizes.
