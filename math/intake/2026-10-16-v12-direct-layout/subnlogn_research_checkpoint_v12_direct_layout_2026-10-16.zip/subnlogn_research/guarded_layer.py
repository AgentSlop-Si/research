"""Data-independent guard budgets and common-format exact phase execution.

Small fixed networks use a compiled arithmetic dependency bound. The actual
h=100 network also has the source section 05 polynomial guard certificate;
computing its descriptor does not allocate or execute that enormous network.
No measured coefficient values are used to select the guarded width.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from math import isqrt
from network_frames import ComplexNetwork, basis_row_operations, complete_basis, dot
from motifs import Budget
from packed_stream import make_packed_basis_move
from recursive_edges import explicit_basis_move
from recursive_network import ceiling_log
from stream_moves import merge_rows, split_rows
from swap_recursion import _park_others, _restore_others


@dataclass(frozen=True)
class GuardCertificate:
    axes: int
    guard_bits: int
    core_depth: int
    row_axes: int
    leaf_axes: int
    pieces: tuple
    method: str


@dataclass(frozen=True)
class PublishedGuard:
    """Exact integers in the source's fixed h=100 guard calculation."""
    m: int
    wires: int
    rank_sum: int

    @classmethod
    def h100(cls):
        b=Budget(100,"complex")
        return cls(b.m,b.wires,b.ranks)

    @property
    def overhead(self): return 64*(self.wires+self.m+1)**3
    @property
    def branching(self): return self.rank_sum+self.overhead
    @property
    def exponent(self): return max(20,ceiling_log(self.branching,self.m)+3)
    @property
    def coefficient(self): return 128*self.m*self.branching**2
    def guard_bits(self,d):
        if not isinstance(d,int) or d<1: raise ValueError("positive axis bound required")
        return self.coefficient*d**self.exponent

    def verify_margins(self,d):
        nu=ceiling_log(self.branching,self.m)
        arithmetic=26*self.m*self.branching**2*d**(nu+2)
        # The extra unit covers componentwise input bounds (modulus <= sqrt2),
        # without doing a size-dependent multiplication to test a disk norm.
        return (self.rank_sum<self.wires*self.m and
                24*self.wires**3+6*self.rank_sum+6*self.wires+4<self.overhead and
                arithmetic+1<self.guard_bits(d))


def layer_partition(network,axes):
    if axes<1 or network.m<2 or network.wires<2: raise ValueError("invalid layer or network")
    q0=(network.wires-1).bit_length()*ceiling_log(2*axes,network.m)
    leaf=max(network.m,isqrt(axes-1)+1)
    if axes<=q0: return axes,leaf,()
    remaining=axes-q0
    powers=[]
    value=1
    while value<=remaining: powers.append(value); value*=network.m
    pieces=[]
    for value in reversed(powers):
        count,remaining=divmod(remaining,value)
        pieces.extend([value]*count)
    return q0,leaf,tuple(pieces)


class GuardPlanner:
    """Compile a fixed dependency program once; its bounds use no payloads."""
    def __init__(self,network,*,maximum_compiled_wires=100000):
        self.network=network
        self.maximum_compiled_wires=maximum_compiled_wires
        self.program=None
        self.depth_cache={}

    def compile(self):
        if self.program is not None: return
        net=self.network
        if net.wires>self.maximum_compiled_wires:
            raise ValueError("finite dependency compiler limit; use the published h=100 certificate")
        roles=tuple(net.roles())
        if len(roles)!=net.wires or len(set(roles))!=net.wires: raise ValueError("role inventory")
        index={role:i for i,role in enumerate(roles)}
        previous={role:net.source_label(role) for role in roles}
        program=[]
        ranks=0
        def change(role,head):
            nonlocal ranks
            rank=abs(head.dimension-previous[role].dimension)
            if rank<0 or rank>net.m: raise ValueError("invalid residual dimension")
            program.append(("edge",index[role],rank))
            ranks+=rank
            previous[role]=head
        for gate in net.gates():
            if len(set(gate.roles))!=len(gate.roles): raise ValueError("duplicate gate incidence")
            if {a for a,_,_ in gate.updates}&{b for _,b,_ in gate.updates}:
                raise ValueError("overlapping gate controls and targets")
            for role in gate.roles: change(role,gate.label)
            for target,source,coefficient in gate.updates:
                coefficient=Q(coefficient)
                if coefficient not in (Q(1),Q(-1),Q(1,2),Q(-1,2)):
                    raise ValueError("guard compiler supports the source's fixed scalar coefficients")
                if target not in gate.roles or source not in gate.roles: raise ValueError("gate lacks common frame")
                program.append(("add",index[target],index[source],coefficient.denominator==2))
        for role in roles: change(role,net.sink_label(role))
        if ranks!=net.rank_sum: raise ValueError("guard program rank sum mismatch")
        self.program=tuple(program)

    def node_depth(self,axes,leaf_axes):
        key=(axes,leaf_axes)
        if key in self.depth_cache: return self.depth_cache[key]
        if axes<leaf_axes: return 8*axes
        if axes%self.network.m: raise ValueError("nonleaf axes must split equally")
        self.compile()
        child=self.node_depth(axes//self.network.m,leaf_axes)
        # A sign plus a fourth-root phase costs at most three elementary steps.
        depths=[3]*self.network.wires
        for instruction in self.program:
            kind,target,*args=instruction
            if kind=="edge": depths[target]+=args[0]*(child+6)
            else:
                source,half=args
                depths[target]=max(depths[target],depths[source]+int(half))+1
        result=max(depths)+3
        self.depth_cache[key]=result
        return result

    def certificate(self,axes):
        q0,leaf,pieces=layer_partition(self.network,axes)
        needs_network=any(piece>=leaf for piece in pieces)
        if needs_network and self.network.wires>self.maximum_compiled_wires:
            net=self.network
            pub=PublishedGuard.h100()
            if not isinstance(net,ComplexNetwork) or net.h!=100 or (net.m,net.wires,net.rank_sum)!=(pub.m,pub.wires,pub.rank_sum):
                raise ValueError("large network has no verified published guard descriptor")
            if not pub.verify_margins(axes): raise ArithmeticError("published guard inequalities failed")
            return GuardCertificate(axes,pub.guard_bits(axes),-1,q0,leaf,pieces,"published h100 polynomial")
        core=8*q0+sum(self.node_depth(piece,leaf) for piece in pieces)
        # Two outer S phases (at most 3 each), the scalar phase (at most 2),
        # an optional (z-iz)/2 (3), floor(D/2) halving units, and one unit
        # for the componentwise-input/modulus bound. All are data independent.
        delta=core+12+axes//2
        method="compiled dependency paths" if needs_network else "individual kernels with outer phases"
        return GuardCertificate(axes,delta,core,q0,leaf,pieces,method)


@dataclass
class FixedFormat:
    precision_bits: int
    guard_bits: int
    ledger: object

    def __post_init__(self):
        if not isinstance(self.precision_bits,int) or self.precision_bits<1 or not isinstance(self.guard_bits,int) or self.guard_bits<0:
            raise ValueError("invalid fixed format")

    @property
    def fractional_bits(self): return self.precision_bits+self.guard_bits
    @property
    def component_bits(self): return self.precision_bits+2*self.guard_bits+3
    @property
    def component_bytes(self): return (self.component_bits+7)//8
    @property
    def storage_bits(self): return 8*self.component_bytes

    def check(self,value):
        if not isinstance(value,int) or not -(1<<(self.component_bits-1))<=value<1<<(self.component_bits-1):
            raise OverflowError("fixed guard format overflow")
        signed_bits=(value if value>=0 else ~value).bit_length()+1
        self.ledger["fixed_max_observed_signed_bits"]=max(self.ledger["fixed_max_observed_signed_bits"],signed_bits)
        return value

    def work(self,kind,components=1):
        self.ledger[kind]+=components
        self.ledger["fixed_arithmetic_bit_units"]+=components*self.storage_bits

    def add(self,u,v,sign=1):
        if sign not in (-1,1): raise ValueError("addition sign must be +1 or -1")
        out=tuple(self.check(a+sign*b) for a,b in zip(u,v))
        self.work("fixed_component_additions",2)
        return out

    def rotate(self,z,power):
        a,b=z
        power%=4
        result=((a,b),(-b,a),(-a,-b),(b,-a))[power]
        for x in result: self.check(x)
        self.work("fixed_component_phases",2)
        return result

    def half(self,z,bits=1):
        if bits<0: raise ValueError("nonnegative exact division required")
        if bits==0: return z
        mask=(1<<bits)-1
        if any(x&mask for x in z): raise ArithmeticError("guard fractional zeros exhausted; no rounding is allowed")
        out=tuple(self.check(x>>bits) for x in z)
        self.work("fixed_exact_divisions",2)
        return out

    def import_records(self,records):
        if not records or not records[0]: raise ValueError("nonempty polynomial records required")
        r=len(records[0])
        limit=1<<self.precision_bits
        out=[]
        for poly in records:
            if len(poly)!=r: raise ValueError("unequal polynomial lengths")
            target=[]
            for z in poly:
                if len(z)!=2 or any(not isinstance(x,int) or abs(x)>limit for x in z):
                    raise ValueError("component outside declared input precision bound")
                target.append(tuple(self.check(x<<self.guard_bits) for x in z))
            out.append(target)
        self.ledger["fixed_import_component_bits"]+=len(out)*2*r*self.storage_bits
        return out

    def export_walsh(self,records,axes):
        shift=self.guard_bits-axes
        if shift<0: raise ArithmeticError("guard budget below exact output scale")
        out=[]
        for poly in records:
            target=[]
            for z in poly: target.append(self.half(z,shift))
            out.append(target)
        self.ledger["fixed_exact_exports"]+=len(out)
        return out


def fixed_phases(records,mask,power,fmt):
    out=[]
    for address,poly in enumerate(records):
        turn=power+(2 if (address&mask).bit_count()%2 else 0)
        out.append([fmt.rotate(z,turn) for z in poly])
    return out


def fixed_c_tensor(records,selected_bits,fmt):
    """True C kernels at one unchanged binary point; no numerator rescaling."""
    out=records
    for bit in selected_bits:
        if bit<0 or len(out)%(1<<(bit+1)): raise ValueError("incomplete kernel bit range")
        banks=[[],[]]
        for address,poly in enumerate(out): banks[(address>>bit)&1].append(poly)
        updated=[[],[]]
        for lower,upper in zip(*banks):
            lo,hi=[],[]
            for u,v in zip(lower,upper):
                total=fmt.add(u,v)
                difference=fmt.rotate(fmt.add(u,v,-1),1)
                lo.append(fmt.half(fmt.add(total,difference)))
                hi.append(fmt.half(fmt.add(total,difference,-1)))
            updated[0].append(lo); updated[1].append(hi)
        streams=tuple(iter(bank) for bank in updated)
        out=[next(streams[(address>>bit)&1]) for address in range(len(out))]
        fmt.ledger["fixed_C_pairs"]+=len(out)//2
        fmt.ledger["fixed_kernel_movement_bits"]+=4*len(out)*2*len(out[0])*fmt.storage_bits
    return out


def fixed_recursive_c(records,bits,fmt,*,network,rows,suffix,prefixes,basis_move,leaf_axes):
    """Same role-volume recursion, with one common format on every level."""
    bits=tuple(bits)
    e=len(bits)
    if len(records)!=prefixes*rows*suffix or rows<1 or prefixes<1 or suffix<1 or suffix&(suffix-1):
        raise ValueError("incomplete row/suffix shape")
    if len(set(bits))!=e or any(b<0 or (1<<b)>=suffix for b in bits): raise ValueError("invalid selected bits")
    if e<leaf_axes:
        fmt.ledger["fixed_network_leaf_calls"]+=1
        return fixed_c_tensor(records,bits,fmt)
    if e%network.m or rows%network.wires: raise ValueError("network width or row divisibility")
    f=e//network.m
    slots=tuple(bits[i*f:(i+1)*f] for i in range(network.m))
    roles=tuple(network.roles())
    if len(roles)!=network.wires or len(set(roles))!=len(roles): raise ValueError("role inventory")
    index={role:i for i,role in enumerate(roles)}
    record_width=2*len(records[0])*fmt.storage_bits
    arrays=split_rows(records,prefixes,rows,suffix,network.wires,fmt.ledger,record_width)
    streams=dict(zip(roles,arrays))
    del arrays
    previous={role:network.source_label(role) for role in roles}
    for role in roles: streams[role]=fixed_phases(streams[role],*network.pre_phase(role,slots),fmt)
    own_children=0
    fmt.ledger["fixed_network_internal_nodes"]+=1
    fmt.ledger["fixed_parent_record_volume_sum"]+=len(records)
    fmt.ledger["fixed_parent_bit_volume_sum"]+=len(records)*record_width
    def change(role,head,gate):
        nonlocal own_children
        factors=tuple(network.edge_factors(role,previous[role],head,gate))
        if len(factors)!=abs(head.dimension-previous[role].dimension): raise ValueError("edge rank mismatch")
        if factors:
            directions,negative=zip(*factors)
            if any(dot(u,v)!=int(i==j) for i,u in enumerate(directions) for j,v in enumerate(directions)):
                raise ValueError("non-orthonormal residual directions")
            columns=complete_basis(directions,network.m)
            forward,inverse=basis_row_operations(columns)
            data=basis_move(streams[role],slots,inverse,fmt.ledger)
            for row,backwards in enumerate(negative):
                selected=slots[row]
                mask=sum(1<<b for b in selected)
                if backwards: data=fixed_phases(data,mask,0,fmt)
                if len(data)*network.wires!=len(records): raise AssertionError("child logical volume is not V/W")
                banks=[streams[r] for r in roles]
                stack,lengths=_park_others(banks,index[role],fmt.ledger,record_width)
                banks[index[role]]=[]
                for r in roles: streams[r]=[]
                data=fixed_recursive_c(data,selected,fmt,network=network,rows=rows//network.wires,
                    suffix=suffix,prefixes=prefixes,basis_move=basis_move,leaf_axes=leaf_axes)
                _restore_others(banks,stack,lengths,fmt.ledger,record_width)
                for r,i in index.items():
                    if r!=role: streams[r]=banks[i]
                del banks,stack,lengths
                if backwards: data=fixed_phases(data,mask,-f,fmt)
                own_children+=1
                fmt.ledger["fixed_child_calls"]+=1
                fmt.ledger["fixed_parking_calls"]+=1
                fmt.ledger["fixed_child_record_volume_sum"]+=len(data)
                fmt.ledger["fixed_child_bit_volume_sum"]+=len(data)*record_width
            streams[role]=basis_move(data,slots,forward,fmt.ledger)
        previous[role]=head
    for gate in network.gates():
        if len(set(gate.roles))!=len(gate.roles): raise ValueError("duplicate gate role")
        if {a for a,_,_ in gate.updates}&{b for _,b,_ in gate.updates}: raise ValueError("overlapping gate operands")
        for role in gate.roles: change(role,gate.label,gate)
        for target,source,coefficient in gate.updates:
            c=Q(coefficient)
            if c not in (Q(1),Q(-1),Q(1,2),Q(-1,2)): raise ValueError("unsupported scalar coefficient")
            if target not in gate.roles or source not in gate.roles: raise ValueError("gate frame mismatch")
            out=[]
            for left,right in zip(streams[target],streams[source]):
                out.append([fmt.add(u,fmt.half(v) if c.denominator==2 else v,c.numerator) for u,v in zip(left,right)])
            streams[target]=out
    for role in roles:
        change(role,network.sink_label(role),None)
        streams[role]=fixed_phases(streams[role],*network.post_phase(role,slots),fmt)
    if own_children!=network.rank_sum: raise AssertionError("fixed recursive child count differs from s")
    routing=[index[network.routed_output(role)] for role in roles]
    return merge_rows([streams[role] for role in roles],prefixes,rows,suffix,routing,fmt.ledger,record_width)


def fixed_batched_c(records,axes,k,rho,fmt,certificate,network,basis_move,prefixes,suffix):
    if k<1 or not 0<=rho<k or suffix<1 or suffix&(suffix-1): raise ValueError("invalid fixed layer layout")
    if len(records)!=prefixes*(1<<(axes*k))*suffix: raise ValueError("incomplete fixed layer range")
    suffix_bits=suffix.bit_length()-1
    selected=tuple(suffix_bits+rho+(axes-1-i)*k for i in range(axes))
    q0=certificate.row_axes
    data=fixed_c_tensor(records,selected[:q0],fmt)
    if q0==axes:
        fmt.ledger["fixed_row_preprocessing_only_layers"]+=1
        return data
    remaining=axes-q0
    rows=1<<(q0*k)
    child_suffix=(1<<(remaining*k))*suffix
    divisor=network.wires**ceiling_log(axes,network.m)
    padded_rows=divisor*((rows+divisor-1)//divisor)
    if not rows<=padded_rows<2*rows: raise AssertionError("fixed row padding factor")
    zero=[(0,0)]*len(records[0])
    padded=[]
    for prefix in range(prefixes):
        start=prefix*rows*child_suffix
        padded.extend(data[start:start+rows*child_suffix])
        padded.extend([list(zero) for _ in range((padded_rows-rows)*child_suffix)])
    fmt.ledger["fixed_layer_padding_records"]+=(padded_rows-rows)*prefixes*child_suffix
    begin=q0
    for piece in certificate.pieces:
        padded=fixed_recursive_c(padded,selected[begin:begin+piece],fmt,network=network,rows=padded_rows,
            suffix=child_suffix,prefixes=prefixes,basis_move=basis_move,leaf_axes=certificate.leaf_axes)
        begin+=piece
    if begin!=axes: raise AssertionError("fixed width partition")
    out=[]
    for prefix in range(prefixes):
        start=prefix*padded_rows*child_suffix
        out.extend(padded[start:start+rows*child_suffix])
        if any(a or b for poly in padded[start+rows*child_suffix:start+padded_rows*child_suffix] for a,b in poly):
            raise ArithmeticError("fixed padded rows were not restored")
    return out


def make_guarded_network_layer(network,precision_bits,*,swap_circuit=None,guard_bits=None):
    """Return an exact unnormalized Walsh backend using one proved format.

    Inputs are Gaussian integers on the declared 2^-p grid with each component
    bounded by 2^p. This includes all disk inputs without an expensive norm
    test. The caller performs the one final rounding after the complete layer.
    An explicit basis fallback is used only if no swap circuit is supplied.
    """
    if not isinstance(precision_bits,int) or precision_bits<1: raise ValueError("positive declared precision required")
    planner=GuardPlanner(network)
    def layer(records,bits,ledger):
        selected=tuple(sorted(bits,reverse=True))
        if not selected: return [list(poly) for poly in records]
        if len(set(selected))!=len(selected) or min(selected)<0: raise ValueError("invalid selected bits")
        d=len(selected)
        k=selected[0]-selected[1] if d>1 else 1
        if k<1 or any(a-b!=k for a,b in zip(selected,selected[1:])): raise ValueError("nonuniform axis chunks")
        rho=selected[-1]%k
        suffix=1<<(selected[-1]-rho)
        block=(1<<(d*k))*suffix
        if not records or len(records)%block: raise ValueError("incomplete guarded layer")
        certificate=planner.certificate(d)
        delta=certificate.guard_bits if guard_bits is None else guard_bits
        if delta<certificate.guard_bits: raise ValueError("supplied guard width is below the certified bound")
        fmt=FixedFormat(precision_bits,delta,ledger)
        basis_move=(explicit_basis_move if swap_circuit is None else
                    make_packed_basis_move(swap_circuit,component_bytes=fmt.component_bytes))
        data=fmt.import_records(records)
        mask=sum(1<<b for b in selected)
        # S_D is i to the sum of selected address bits, not parity alone.
        def s_phase(array):
            return [[fmt.rotate(z,(address&mask).bit_count()) for z in poly] for address,poly in enumerate(array)]
        data=s_phase(data)
        data=fixed_batched_c(data,d,k,rho,fmt,certificate,network,basis_move,len(records)//block,suffix)
        data=s_phase(data)
        out=[]
        t=d//2
        for poly in data:
            target=[]
            for z in poly:
                value=fmt.rotate(z,-t)
                if d%2: value=fmt.half(fmt.add(value,fmt.rotate(value,1),-1))
                target.append(fmt.half(value,t))
            out.append(target)
        ledger["guarded_layer_calls"]+=1
        ledger["guarded_peak_guard_bits"]=max(ledger["guarded_peak_guard_bits"],delta)
        ledger["guarded_peak_component_bits"]=max(ledger["guarded_peak_component_bits"],fmt.component_bits)
        ledger["guarded_peak_storage_bits"]=max(ledger["guarded_peak_storage_bits"],fmt.storage_bits)
        ledger["guarded_value_dependent_width_choices"]+=0
        return fmt.export_walsh(out,d)
    layer.guard_planner=planner
    return layer
