"""Cold benchmarks of the new integration adapter, not an asymptotic claim."""
from collections import defaultdict
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import argparse
import gc
import hashlib
import json
import platform
import random
import sys
from synthetic import multiply_reference


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", nargs="+", type=int, default=[4096, 16384, 65536])
    parser.add_argument("--pairs", type=int, default=5)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("synthetic_benchmarks.json"))
    args = parser.parse_args()
    if min(args.sizes) < 2 or args.pairs < 1 or args.repeats < 1: parser.error("positive parameters required")
    gc.disable()
    root = Path(__file__).resolve().parent
    report = dict(status="Reference integration only; no sub-N-log-N claim",
                  method="Cold setup, encoding, transforms, packing, rounding, carries and output included; checked outside timed region",
                  python=sys.version, platform=platform.platform(), gc_disabled=True,
                  source_sha256={name: hashlib.sha256((root/name).read_bytes()).hexdigest()
                                 for name in ("synthetic.py", "benchmark_synthetic.py")}, sizes=[])
    for n in args.sizes:
        rng = random.Random(83214+n)
        pairs = [tuple((1 << (n-1)) | rng.getrandbits(n-1) for _ in range(2)) for _ in range(args.pairs)]
        expected = [x*y for x,y in pairs]
        jobs = [(kind,i) for _ in range(args.repeats) for kind in ("synthetic_reference","native_python")
                for i in range(args.pairs)]
        rng.shuffle(jobs)
        samples, details = defaultdict(list), None
        for kind,i in jobs:
            x,y=pairs[i]
            start=perf_counter_ns()
            if kind == "synthetic_reference": actual,details=multiply_reference(x,y)
            else: actual=x*y
            samples[kind].append(perf_counter_ns()-start)
            if actual != expected[i]: raise AssertionError((n,kind,i))
        row=dict(input_bits=n, configurations={kind: dict(median_ns=median(values),min_ns=min(values),max_ns=max(values),
                 samples_ns=values,samples=len(values)) for kind,values in samples.items()},reference_details=details)
        report["sizes"].append(row)
        args.output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
        print(json.dumps({"bits":n,"median_ms":{k:v["median_ns"]/1e6 for k,v in row["configurations"].items()}}),flush=True)


if __name__ == "__main__": main()
