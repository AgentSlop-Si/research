"""Execute a compiled phase residual as basis changes and recursive C calls.

This module supplies the edge contract for the full network executor. The
default basis-movement backend is explicit. packed_stream supplies a sequential
alternative; its full fixed-tape cost audit remains incomplete.
recursive_network.py supplies the role-volume recursion. One child call occurs per
residual basis vector, even for an inverse kernel.
"""
from network_frames import basis_row_operations, complete_basis, dot
from phase_layers import explicit_c_numerators, rotate_i
from packed_bits import PackedBits


def packed_basis_address(slot_values, row_operations, k, fields, offset=0):
    """Execute columnwise basis changes using the actual eight-rotation repair.

    Each slot is an f*K-bit chunk; a row addition uses a third, arbitrary slot
    for temporary address bits. Nonselected bits and the helper are restored.
    This acts on an address; it is not the bulk-stream movement algorithm.
    """
    if len(slot_values)<3: raise ValueError("a third helper slot is required")
    spec=PackedBits(k,fields,offset)
    values=list(slot_values)
    if any(v<0 or v>spec.mask for v in values): raise ValueError("slot value outside width")
    for target,source in row_operations:
        if not 0<=target<len(values) or not 0<=source<len(values) or target==source:
            raise ValueError("invalid row addition")
        helper=next(i for i in range(len(values)) if i not in (target,source))
        x,y,z=spec.apply((values[source],values[target],values[helper]))
        values[source],values[target],values[helper]=x,y,z
    return values


def explicit_basis_move(records, slots, operations, ledger):
    """Move record at address x to its columnwise transformed address."""
    out=list(records)
    for target,source in operations:
        moved=[None]*len(out)
        for address,record in enumerate(out):
            destination=address
            for tb,sb in zip(slots[target],slots[source]):
                destination ^= ((address>>sb)&1)<<tb
            moved[destination]=record
        out=moved
        ledger["explicit_basis_record_moves"]+=len(out)
    return out


def apply_residual_numerators(records, directions, inverse_flags, slots, ledger,
                              *, child=explicit_c_numerators, basis_move=explicit_basis_move):
    """Apply all residual kernels to all columns at one common dyadic scale.

    slots[row][column] is an address bit. If there are f columns and rank a,
    return (numerators, extra_fraction_bits=a*f). Each child returns 2**f times
    C**tensor(f), including through the inverse wrapper -i Z C Z. No rounding
    occurs and no child is charged a unit-time bit cost.
    """
    directions,flags=tuple(directions),tuple(inverse_flags)
    slots=tuple(tuple(row) for row in slots)
    n=len(records)
    if n<1: raise ValueError("nonempty record address range required")
    if len(directions)!=len(flags) or not slots or not slots[0]: raise ValueError("invalid edge shape")
    f=len(slots[0])
    if any(len(row)!=f for row in slots): raise ValueError("unequal column counts")
    bits=[bit for row in slots for bit in row]
    if len(bits)!=len(set(bits)) or any(b<0 or (1<<b)>=n for b in bits): raise ValueError("invalid selected bits")
    if n%(1<<(max(bits)+1)): raise ValueError("incomplete selected-bit Cartesian range")
    if any(dot(u,v)!=int(i==j) for i,u in enumerate(directions) for j,v in enumerate(directions)):
        raise ValueError("residual directions must be orthonormal")
    columns=complete_basis(directions,len(slots))
    forward,inverse=basis_row_operations(columns)
    data=basis_move(records,slots,inverse,ledger)
    for row,negative in enumerate(flags):
        selected=slots[row]
        mask=sum(1<<bit for bit in selected)

        def z_phase(array):
            return [[(-a,-b) if (address&mask).bit_count()%2 else (a,b) for a,b in poly]
                    for address,poly in enumerate(array)]

        if negative: data=z_phase(data)
        data=child(data,selected,ledger)
        if negative:
            data=z_phase(data)
            data=[[rotate_i(z,-f) for z in poly] for poly in data]
        ledger["edge_child_calls"]+=1
        ledger["edge_child_selected_bits_total"]+=f
    data=basis_move(data,slots,forward,ledger)
    return data,len(directions)*f
