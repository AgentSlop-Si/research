"""Padded tensor Gaussian maps with sequential axis exposure and fixed codecs.

No payload scatter or sorting is used. Adjacent power-of-two axes are exchanged
by the existing chunk-swap interface plus one elementary bit move for unequal
widths. This preserves the large-algorithm interface, but does not establish
its complete tape-time bound or the scalar exponential cost bound.
"""
from collections import Counter
from itertools import product
from math import prod

from gaussian_resampling import GaussianLine, GaussianParameters
from packed_stream import GaussianRecordCodec
from stream_moves import Reader, emit, move_digit
from swap_recursion import binary_chunk_swap


def adjacent_axes(records, shape, index, circuit, ledger, width):
    """Swap complete adjacent binary axes whose bit widths differ by <=1."""
    shape = tuple(shape)
    if (not 0 <= index < len(shape)-1 or len(records) != prod(shape)
            or any(type(v) is not int or v < 2 or v & (v-1) for v in shape)):
        raise ValueError("invalid binary axis shape")
    bits = [v.bit_length()-1 for v in shape]
    a, b = bits[index:index+2]
    if abs(a-b) > 1:
        raise ValueError("adjacent axes must have equal or neighboring bit widths")
    prefix, suffix = prod(shape[:index]), prod(shape[index+2:])
    offset = sum(bits[:index])
    out = records
    if a < b:
        # x,e,y -> e,x,y -> e,y,x.
        out, _ = move_digit(out, (2,)*sum(bits), offset+a, offset, ledger, width)
        ledger["gaussian_excess_bit_moves"] += 1
    out = binary_chunk_swap(out, min(a,b), circuit, ledger,
                            prefix=prefix*(2 if a != b else 1),
                            suffix=suffix, width=width)
    if a > b:
        # e,x,y -> e,y,x -> y,e,x.
        out, _ = move_digit(out, (2,)*sum(bits), offset, offset+b, ledger, width)
        ledger["gaussian_excess_bit_moves"] += 1
    new_shape = list(shape)
    new_shape[index:index+2] = [shape[index+1], shape[index]]
    ledger["gaussian_adjacent_axis_swaps"] += 1
    return out, tuple(new_shape)


class GaussianTensor:
    def __init__(self, sources, targets, p, alpha, circuit, *, ledger=None):
        self.sources, self.targets = tuple(sources), tuple(targets)
        if (not self.sources or len(self.sources) != len(self.targets)
                or any(type(t) is not int or t < 2 or t & (t-1) for t in self.targets)
                or any(t not in (max(self.targets)//2, max(self.targets)) for t in self.targets)):
            raise ValueError("nonempty source/target pairs and adjacent binary widths required")
        self.ledger = ledger if ledger is not None else Counter()
        self.parameters = tuple(GaussianParameters(s,t,p,alpha)
                                for s,t in zip(self.sources,self.targets))
        self.lines = tuple(GaussianLine(a,ledger=self.ledger) for a in self.parameters)
        self.p, self.alpha, self.circuit = p, alpha, circuit
        self.codec = GaussianRecordCodec(1,(p+2+7)//8)

    @property
    def gamma(self): return 2*len(self.sources)*self.alpha*self.alpha

    def _check_box(self, values, valid):
        if len(values) != prod(self.targets): raise ValueError("incomplete padded box")
        bound = 1 << (2*self.p)
        for coordinates, z in zip(product(*(range(t) for t in self.targets)),values):
            if (not isinstance(z,(tuple,list)) or len(z) != 2
                    or any(type(v) is not int for v in z)
                    or z[0]*z[0]+z[1]*z[1] > bound):
                raise ValueError("padded box must contain disk-grid pairs")
            if any(j >= n for j,n in zip(coordinates,valid)) and tuple(z) != (0,0):
                raise ValueError("nonzero invalid padding")

    def embed(self, values):
        if len(values) != prod(self.sources): raise ValueError("source tensor size")
        reader = Reader(values,self.ledger,self.codec.width)
        out = []
        for coordinates in product(*(range(t) for t in self.targets)):
            value = reader.take() if all(j<s for j,s in zip(coordinates,self.sources)) else (0,0)
            emit(out,value,self.ledger,self.codec.width)
        reader.finish()
        self._check_box(out,self.sources)
        return out

    def extract(self, values):
        self._check_box(values,self.sources)
        reader = Reader(values,self.ledger,self.codec.width)
        out = []
        for coordinates in product(*(range(t) for t in self.targets)):
            value = reader.take()
            if all(j<s for j,s in zip(coordinates,self.sources)):
                emit(out,value,self.ledger,self.codec.width)
        reader.finish()
        return out

    def apply(self, values, *, inverse=False, axis_order=None):
        """Expand A or compress B0, retaining the full target-size padded box.

        'inverse' selects compression, NOT a mathematical inverse of A.
        No factor 2**gamma is applied here; that belongs to the source transform.
        """
        count = len(self.sources)
        order = tuple(range(count)) if axis_order is None else tuple(axis_order)
        if sorted(order) != list(range(count)):
            raise ValueError("axis order is not a permutation")
        valid = list(self.targets if inverse else self.sources)
        self._check_box(values,valid)
        out = list(values)
        for axis in order:
            physical = list(range(count))
            shape = self.targets
            encoded = self.codec.encode([[z] for z in out],self.ledger)
            self.ledger["gaussian_fixed_tensor_codec_calls"] += 1
            path = []
            for position in range(axis,count-1):
                encoded,shape = adjacent_axes(encoded,shape,position,self.circuit,
                                               self.ledger,self.codec.width)
                physical[position],physical[position+1] = physical[position+1],physical[position]
                path.append(position)
            exposed = [row[0] for row in self.codec.decode(encoded,self.ledger)]
            reader = Reader(exposed,self.ledger,self.codec.width)
            transformed = []
            for prefix in product(*(range(n) for n in shape[:-1])):
                line = [reader.take() for _ in range(shape[-1])]
                is_valid = all(j < valid[i] for j,i in zip(prefix,physical[:-1]))
                if not is_valid:
                    if any(z != (0,0) for z in line): raise AssertionError("invalid line not zero")
                    result = [(0,0)]*len(line)
                    self.ledger["gaussian_tensor_skipped_lines"] += 1
                elif inverse:
                    result = self.lines[axis].compress(line)
                    result += [(0,0)]*(self.targets[axis]-self.sources[axis])
                else:
                    if any(z != (0,0) for z in line[self.sources[axis]:]):
                        raise AssertionError("source line padding not zero")
                    result = self.lines[axis].expand(line[:self.sources[axis]])
                if is_valid: self.ledger["gaussian_tensor_processed_lines"] += 1
                for z in result: emit(transformed,z,self.ledger,self.codec.width)
            reader.finish()
            encoded = self.codec.encode([[z] for z in transformed],self.ledger)
            for position in reversed(path):
                encoded,shape = adjacent_axes(encoded,shape,position,self.circuit,
                                               self.ledger,self.codec.width)
                physical[position],physical[position+1] = physical[position+1],physical[position]
            if shape != self.targets or physical != list(range(count)):
                raise AssertionError("axis restoration failed")
            out = [row[0] for row in self.codec.decode(encoded,self.ledger)]
            valid[axis] = self.sources[axis] if inverse else self.targets[axis]
            self._check_box(out,valid)
        self.ledger["gaussian_tensor_B0_calls" if inverse else "gaussian_tensor_A_calls"] += 1
        return out
