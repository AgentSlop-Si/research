# v11 audited research checkpoint

**Status:** exact finite improvements and conditional inequality certificate;
**not** a complete verified sub-N-log-N multiplier or a new faster general DFT.

Start with [AUDIT_V11.md](AUDIT_V11.md). It gives the verdict, exact scope,
benchmarks, current dated comparison, and remaining proof obligations.
`README.txt` and `PROOF_STATUS.txt` are retained historical v10 documents.

## Reproduce

Use Python 3.10+ (tested with 3.13.5) and `mpmath` for the inherited numerical
comparison tests. The new kernel and its exact certificate use the standard
library; inherited tests use mpmath as an independent reference.

```sh
python parameter_certificate_v11.py
python run_v11_validation.py
python run_v11_regression.py
python benchmark_packing_v11.py
# Optional: all inherited tests, including a costly full recursive control.
python run_validation.py --output inherited_rerun.json
```

Do not run timing benchmarks concurrently with validation jobs. Test suites
and scalar/recursive controls can be expensive; this is reference research code,
not a production big-integer library. The timing script validates every answer.
The `inherited_rerun.json` filename avoids overwriting historical evidence.

## Exact kernel example

```python
from packed_gaussian_v11 import normalized_packed_product
from fast_scalar import FastArithmetic
from fermat_recursive import RecursiveFermatMultiplier

# Each (real, imaginary) numerator obeys real**2+imaginary**2 <= 2**(2*p).
p = 8
f = [(20, -10), (30, 5)]
g = [(-7, 4), (12, -9)]
arithmetic = FastArithmetic(RecursiveFermatMultiplier())
answer = normalized_packed_product(f, g, p, arithmetic, mode='three')
print(answer)  # Normalized and truncated ring coefficients, not the raw product.
```

`mode='one'` selects the three-lane, one-large-product alternative;
`mode='four_narrow'` isolates the benefit of narrower lanes. Product count
alone does not predict runtime. All modes preserve the old normalization.

The opt-in full finite entrypoint is `multiply_packed_finite`, taking the same
explicit geometric/precision/circuit parameters as v10. Its default integer
backend is recursive Fermat. Passing `operator.mul` deliberately selects a
native-integer control, not a sub-N-log-N proof. See the complete native
controls in `test_packing_v11.py` for reproducible parameter sets.

## Evidence and provenance

- `validation_v10_rerun.json`: 137 methods, original unmodified v10.
- `validation_v11.json`: 8 new methods; 21,177 exact kernel comparisons.
- `regression_v11.json`: 10 inherited methods on the modified hooks.
- `packing_benchmarks_v11.json`: 198 checked timed calls and raw samples.
- `PACKING_PROOF_V11.md`: coefficient, packing and exact-output proofs.
- `PARAMETER_CEILING_V11.md`: conditional exponent improvement and tuning ceiling.
- `input_manifest.json`, `version_deltas.json`: all ten input archives.
- `external_baselines_v11.json`: dated public source comparison and limitations.
- `evidence/v10_to_v11_hooks.patch`: only edit to inherited code.

The original notice and license are retained. `NOTICE_V11.md` distinguishes
borrowed mathematics from local modifications. Source hashes are recorded in
`SHA256SUMS_V11.json` for release integrity, not as a proof certificate.
