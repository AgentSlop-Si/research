from collections import Counter
from dataclasses import dataclass
from fractions import Fraction as Q
import random
import unittest
from network_frames import Gate
from phase_layers import explicit_c_numerators
from recursive_network import (DyadicStream, add_stream, recursive_c_numerators, rescale_exact,
                               batched_c_numerators, make_network_layer)

COUNTS=Counter()


@dataclass(frozen=True)
class CoordinateSpace:
    mask:int
    @property
    def dimension(self): return self.mask.bit_count()


class SmallControlNetwork:
    """A separately specified m=2, W=2 control with NO rank saving.

    It executes the same generic recursive engine as ComplexNetwork. Optional
    decreasing edges test inverse children. It is never presented as the
    source's h=100 network or as a sub-N-log-N construction.
    """
    m=wires=2
    def __init__(self,decreasing=False): self.decreasing=decreasing
    @property
    def rank_sum(self): return 8 if self.decreasing else 4
    def roles(self): return iter(("X","Y"))
    def source_label(self,role): return CoordinateSpace(0)
    def sink_label(self,role): return CoordinateSpace(3)
    def pre_phase(self,role,slots): return 0,0
    def post_phase(self,role,slots): return (0,2) if role=="X" else (0,0)
    def routed_output(self,source): return "Y" if source=="X" else "X"
    def gates(self):
        masks=(3,1,3) if self.decreasing else (1,3,3)
        for time,(mask,update) in enumerate(zip(masks,(("Y","X",Q(1)),("X","Y",Q(-1)),("Y","X",Q(1))))):
            yield Gate(0,(),time,CoordinateSpace(mask),("X","Y"),(update,))
    def edge_factors(self,role,tail,head,gate):
        difference=tail.mask^head.mask
        for i in range(2):
            if (difference>>i)&1: yield 1<<i,bool((tail.mask>>i)&1)


class PaddedControlNetwork(SmallControlNetwork):
    """m=4, W=3, with a scratch role and nonbinary row divisibility."""
    m,wires=4,3
    @property
    def rank_sum(self): return 12
    def roles(self): return iter(("X","Y","A"))
    def sink_label(self,role): return CoordinateSpace(15)
    def routed_output(self,source): return "A" if source=="A" else super().routed_output(source)
    def gates(self):
        for time,update in enumerate((("Y","X",Q(1)),("X","Y",Q(-1)),("Y","X",Q(1)))):
            yield Gate(0,(),time,CoordinateSpace(0),("X","Y"),(update,))
    def edge_factors(self,role,tail,head,gate):
        difference=tail.mask^head.mask
        for i in range(4):
            if (difference>>i)&1: yield 1<<i,bool((tail.mask>>i)&1)


class RecursiveNetworkTests(unittest.TestCase):
    def test_recursive_engine_inside_synthetic_convolution(self):
        from synthetic import Layout, normalized_convolution
        from network_frames import ComplexNetwork
        rng=random.Random(8872)
        layout=Layout((2,)*8,2)
        values=[[[(rng.randrange(-30,31),rng.randrange(-30,31)) for _ in range(2)]
                 for _ in range(layout.size)] for _ in range(2)]
        expected=normalized_convolution(*values,layout,12)
        ledger=Counter()
        actual=normalized_convolution(*values,layout,12,layer=make_network_layer(PaddedControlNetwork()),ledger=ledger)
        self.assertEqual(actual,expected)
        self.assertGreater(ledger["network_internal_nodes"],0)
        self.assertEqual(ledger["integrated_network_layer_calls"],3)
        real_ledger=Counter()
        actual=normalized_convolution(*values,layout,12,layer=make_network_layer(ComplexNetwork(100)),ledger=real_ledger)
        self.assertEqual(actual,expected)
        self.assertEqual(real_ledger["network_internal_nodes"],0)
        self.assertEqual(real_ledger["row_preprocessing_only_layers"],3)
        COUNTS["recursive_synthetic_convolutions"]+=1
        COUNTS["fixed_network_small_width_convolutions"]+=1

    def test_arbitrary_axis_partition_and_row_padding(self):
        rng=random.Random(8899)
        for net,d,k,rho,suffix,prefixes in ((SmallControlNetwork(),8,1,0,1,2),
                (SmallControlNetwork(),9,1,0,2,1),(SmallControlNetwork(),12,1,0,1,1),
                (PaddedControlNetwork(),8,1,0,2,2),(PaddedControlNetwork(),9,1,0,1,1),
                (PaddedControlNetwork(),6,2,1,1,1)):
            values=[[(rng.randrange(-10,11),rng.randrange(-10,11))] for _ in range(prefixes*(1<<(d*k))*suffix)]
            ledger=Counter()
            actual=batched_c_numerators(values,d,k,rho,ledger,network=net,prefixes=prefixes,suffix_records=suffix)
            selected=tuple(suffix.bit_length()-1+rho+i*k for i in range(d))
            self.assertEqual(actual,explicit_c_numerators(values,selected,Counter()))
            if isinstance(net,PaddedControlNetwork) and d==8:
                self.assertGreater(ledger["layer_padding_records"],0)
                self.assertGreater(ledger["network_internal_nodes"],0)
            COUNTS["batched_row_padding_layers"]+=1

    def test_multilevel_recursion_and_volume(self):
        rng=random.Random(8832)
        for decreasing,depth in ((False,1),(False,2),(False,3),(True,1),(True,2)):
            net=SmallControlNetwork(decreasing)
            e=2**depth
            rows=2**depth
            suffix=1<<(e+1)
            # Leave one low spectator bit, and use two outer prefixes.
            records=[[(rng.randrange(-5,6),rng.randrange(-5,6))] for _ in range(2*rows*suffix)]
            bits=tuple(range(1,e+1))
            ledger=Counter()
            got=recursive_c_numerators(records,bits,ledger,network=net,rows=rows,suffix_records=suffix,prefixes=2)
            expected=explicit_c_numerators(records,bits,Counter())
            self.assertEqual(got,expected)
            internal=sum(net.rank_sum**j for j in range(depth))
            leaves=net.rank_sum**depth
            self.assertEqual(ledger["network_internal_nodes"],internal)
            self.assertEqual(ledger["network_leaf_calls"],leaves)
            self.assertEqual(ledger["edge_child_calls"],internal*net.rank_sum)
            self.assertEqual(ledger["network_child_record_volume_sum"]*net.wires,
                             ledger["network_parent_record_volume_sum"]*net.rank_sum)
            COUNTS["multilevel_recursive_networks"]+=1
            COUNTS["recursive_network_internal_nodes"]+=internal
            COUNTS["recursive_network_leaf_calls"]+=leaves

    def test_dyadic_gate_alignment(self):
        target=DyadicStream([[(3,-5)]],2)
        source=DyadicStream([[(-7,9)]],4)
        ledger=Counter()
        add_stream(target,source,Q(-3,2),ledger)
        self.assertEqual(target.fractional_bits,5)
        self.assertEqual(target.records,[[(45,-67)]])
        with self.assertRaises(ArithmeticError): rescale_exact(target,4)
        with self.assertRaises(ValueError): add_stream(target,source,Q(1,3),ledger)
        COUNTS["dyadic_gate_controls"]+=3

    def test_incomplete_rows_rejected(self):
        net=SmallControlNetwork()
        with self.assertRaises(ValueError):
            recursive_c_numerators([[(0,0)]]*4,(0,1),Counter(),network=net,rows=1,suffix_records=4)
        with self.assertRaises(ValueError):
            recursive_c_numerators([[(0,0)]]*16,(0,1,2),Counter(),network=net,rows=2,suffix_records=8)
        COUNTS["negative_controls"]+=2


if __name__=="__main__": unittest.main()
