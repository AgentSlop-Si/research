"""Finite full-arithmetic profile; automatic asymptotic parameters still absent.

Gaussian/scalar, chirp, twist, disk-check and packed-ring products are routed
through one explicit integer backend. The default is recursive Fermat and
default global audit counters are disabled. This is not a full tape-time proof.
"""
from itertools import product
from operator import mul

from fast_gaussian import FastGaussianTensor
from fast_scalar import FastArithmetic, FastCertifiedPhase
from fermat_recursive import NullLedger, RecursiveFermatMultiplier
from multiply_resampled import multiply_resampled
from resampled_transform import CyclicConvolver, SourceTransform
from synthetic import (_shape, pack_signed, unpack_centered, trunc_shift,
                       transform, direct_layer)


def check_norm(values, p, arithmetic, numerator=1, denominator=1, *, reject=True):
    if denominator <= 0 or numerator < 0: raise ValueError("invalid norm bound")
    bound = arithmetic.mul(numerator, numerator) << (2*p)
    multiplier = arithmetic.mul(denominator, denominator)
    inside = True
    for z in values:
        if (not isinstance(z, (tuple, list)) or len(z) != 2
                or any(type(v) is not int for v in z)):
            raise ValueError("integer Gaussian pair required")
        norm = arithmetic.mul(z[0], z[0])+arithmetic.mul(z[1], z[1])
        if arithmetic.mul(norm, multiplier) > bound: inside = False
    if reject and not inside: raise ValueError("coefficient exceeds declared norm")
    return inside


def fast_ring_product(f, g, p, arithmetic, ledger):
    """Same four-product packing, with injected disk checks and exact recovery."""
    r = len(f)
    _shape((f, g), r, p, require_disk=False)
    check_norm(f, p, arithmetic)
    check_norm(g, p, arithmetic)
    width = 4*p
    a, b, c, e = [pack_signed([z[component] for z in row], width)
                   for row, component in ((f, 0), (f, 1), (g, 0), (g, 1))]
    products = []
    for left, right in ((a, c), (b, e), (a, e), (b, c)):
        ledger["integer_multiplications"] += 1
        ledger["integer_multiply_operand_bits_sum"] += abs(left).bit_length()+abs(right).bit_length()
        ledger["integer_multiply_max_bits"] = max(ledger["integer_multiply_max_bits"],
                                                  abs(left).bit_length(), abs(right).bit_length())
        products.append(unpack_centered(arithmetic.mul(left, right), 2*r, width))
    ac, be, ae, bc = products
    shift = p+r.bit_length()-1
    ledger["packing_input_blocks"] += 4*r
    ledger["extraction_output_blocks"] += 8*r
    return [(trunc_shift(ac[j]-ac[j+r]-be[j]+be[j+r], shift),
             trunc_shift(ae[j]-ae[j+r]+bc[j]-bc[j+r], shift)) for j in range(r)]


def fast_convolution(f, g, layout, p, arithmetic, ledger, layer, layout_move,
                     *, ring_product=fast_ring_product):
    _shape(f, layout.r, p)
    _shape(g, layout.r, p)
    check_norm((z for row in f for z in row), p, arithmetic)
    check_norm((z for row in g for z in row), p, arithmetic)
    a = transform(f, layout, p, layer=layer, layout_move=layout_move, ledger=ledger)
    b = transform(g, layout, p, layer=layer, layout_move=layout_move, ledger=ledger)
    pointwise = [ring_product(x, y, p, arithmetic, ledger) for x, y in zip(a, b)]
    out = transform(pointwise, layout, p, opposite=True,
                    layer=layer, layout_move=layout_move, ledger=ledger)
    shift = layout.size.bit_length()-1
    if 1 << shift != layout.size: raise AssertionError("binary record count required")
    return [[(a << shift, b << shift) for a, b in row] for row in out]


class FastCyclicConvolver(CyclicConvolver):
    def __init__(self, targets, p, *, integer_multiply=None, ledger=None,
                 ring_product=fast_ring_product, **kwargs):
        ledger = ledger if ledger is not None else NullLedger()
        backend = integer_multiply if integer_multiply is not None else RecursiveFermatMultiplier()
        super().__init__(targets, p, integer_multiply=backend, ledger=ledger, **kwargs)
        self.arithmetic = FastArithmetic(backend, ledger)
        self.ring_product = ring_product
        self.phase = FastCertifiedPhase(ledger, integer_multiply=backend)

    def _twist(self, values, opposite):
        out, k = [], 0
        for z in values:
            phase = self.phase.grid(-k if opposite else k, 2*self.r, self.p).value
            out.append(self._product(phase, z))
            k += 1
            if k == self.r: k = 0
        self.ledger["coefficient_twist_calls"] += 1
        return out

    def convolve(self, f, g):
        if len(f) != self.T or len(g) != self.T: raise ValueError("cyclic tensor size mismatch")
        check_norm(f, self.p, self.arithmetic)
        check_norm(g, self.p, self.arithmetic)
        if not any(check_norm(v, self.p, self.arithmetic, 7, 10, reject=False) for v in (f, g)):
            raise ValueError("one cyclic operand must have norm <=0.7")
        f, g = self._twist(f, False), self._twist(g, False)
        f = [f[j:j+self.r] for j in range(0, self.T, self.r)]
        g = [g[j:j+self.r] for j in range(0, self.T, self.r)]
        if self.layout is None:
            h = [self.ring_product(f[0], g[0], self.p, self.arithmetic, self.ledger)]
        else:
            h = fast_convolution(f, g, self.layout, self.p, self.arithmetic,
                                 self.ledger, self.layer, self.layout_move, ring_product=self.ring_product)
        h = [z for row in h for z in row]
        check_norm(h, self.p, self.arithmetic, 701, 1000)
        out = self._twist(h, True)
        check_norm(out, self.p, self.arithmetic, 701, 1000)
        self.ledger["normalized_complex_convolution_calls"] += 1
        return out

    def chirp(self, values, sources):
        sources = tuple(sources)
        if (len(values) != self.T or len(sources) != len(self.targets)
                or any(type(s) is not int or s < 1 for s in sources)):
            raise ValueError("chirp source descriptor or tensor size")
        check_norm(values, self.p, self.arithmetic, 3, 5)
        phases, mask = [], 2*self.r-1
        for coordinates in product(*(range(t) for t in self.targets)):
            total = 0
            for s, j, t in zip(sources, coordinates, self.targets):
                term = self.arithmetic.mul(s, self.arithmetic.mul(j, j))
                total += term if t == self.r else term << 1
            phases.append(self.phase.grid((-total) & mask, 2*self.r, self.p).value)
            self.ledger["chirp_coordinate_terms"] += len(sources)
        conjugates = [(a, -b) for a, b in phases]
        operand = [self._product(a, z) for a, z in zip(conjugates, values)]
        middle = self.convolve(phases, operand)
        out = [self._product(a, z) for a, z in zip(conjugates, middle)]
        check_norm(out, self.p, self.arithmetic, 701, 1000)
        self.ledger["permuted_chirp_calls"] += 1
        return out


class FastArithmeticSourceTransform(SourceTransform):
    scalar_backend_description = "bit-burst scalar functions and fast Gaussian/chirp/norm arithmetic"

    def __init__(self, sources, targets, p, alpha, circuit, *, chunk_bits=1,
                 layer=direct_layer, layout_move=None, integer_multiply=None, ledger=None,
                 ring_product=fast_ring_product, gaussian_factory=FastGaussianTensor):
        self.ledger = ledger if ledger is not None else NullLedger()
        backend = integer_multiply if integer_multiply is not None else RecursiveFermatMultiplier()
        self.arithmetic = FastArithmetic(backend, self.ledger)
        self.gaussian = gaussian_factory(sources, targets, p, alpha, circuit,
            ledger=self.ledger, integer_multiply=backend)
        self.convolver = FastCyclicConvolver(targets, p, chunk_bits=chunk_bits, layer=layer,
            layout_move=layout_move, integer_multiply=backend, ledger=self.ledger,
            ring_product=ring_product)
        self.sources, self.targets, self.p = tuple(sources), tuple(targets), p
        self.gamma = self.gaussian.gamma
        self.error = (1 << self.gamma)*(2*len(self.sources)*p*p+self.convolver.chirp_error)
        if 1000*self.error >= 1 << p: raise ValueError("insufficient source-transform disk margin")

    def apply(self, padded, *, opposite=False):
        check_norm(padded, self.p, self.arithmetic, 1, 2)
        data = [(a, -b) for a, b in padded] if opposite else padded
        expanded = self.gaussian.apply(data)
        middle = self.convolver.chirp(expanded, self.sources)
        compressed = self.gaussian.apply(middle, inverse=True)
        scaled = [(a << self.gamma, b << self.gamma) for a, b in compressed]
        self.ledger["source_exact_scale_components"] += 2*len(scaled)
        check_norm(scaled, self.p, self.arithmetic, 501, 1000)
        self.gaussian._check_box(scaled, self.sources)
        self.ledger["source_opposite_calls" if opposite else "source_forward_calls"] += 1
        return [(a, -b) for a, b in scaled] if opposite else scaled


def multiply_fast_finite(x, y, *, integer_multiply=None, ledger=None, **parameters):
    backend = integer_multiply if integer_multiply is not None else RecursiveFermatMultiplier()
    diagnostics_ledger = ledger if ledger is not None else NullLedger()
    value, diagnostics = multiply_resampled(x, y, integer_multiply=backend,
        transform_factory=FastArithmeticSourceTransform, ledger=diagnostics_ledger, **parameters)
    diagnostics["implementation_status"].update(
        integer_backend="explicit native control" if backend is mul else type(backend).__name__,
        arithmetic_profile="Gaussian/scalar/chirp/norm/ring products routed through supplied backend",
        global_audit_enabled=not isinstance(diagnostics_ledger, NullLedger),
        remaining="automatic asymptotic parameters, actual-network obligations and full fixed-tape audit")
    return value, diagnostics
