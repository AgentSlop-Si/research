"""Direct (possibly nonadjacent) swaps of neighboring-width binary axes.

Payload access uses the existing sequential movement interfaces. No address
scatter/gather or Python sorting is used. The inherited binary-chunk primitive
and its conditional asymptotic guarantee are not re-proved by this module.
"""
from itertools import product
from math import prod

from crt_layout import CRTLayout
from gaussian_tensor import GaussianTensor
from fast_gaussian import FastGaussianTensor
from stream_moves import Reader, emit, move_digit
from swap_recursion import binary_chunk_swap


def swap_axes(records, shape, first, second, circuit, ledger, width=1):
    """Swap fields i,j while leaving every intermediate field unchanged.

    The two fields must have equal bit widths or differ by one. One binary
    chunk interchange and at most one single-bit move suffice. Other axes
    may have arbitrary positive binary widths.
    """
    shape = tuple(shape)
    if (not shape or any(type(v) is not int or v < 2 or v & (v-1) for v in shape)
            or len(records) != prod(shape) or type(width) is not int or width < 1
            or type(first) is not int or type(second) is not int
            or not 0 <= first < len(shape) or not 0 <= second < len(shape)):
        raise ValueError('invalid binary axis-swap request')
    if first == second:
        return records, shape
    i, j = sorted((first, second))
    bits = [v.bit_length()-1 for v in shape]
    a, b = bits[i], bits[j]
    if abs(a-b) > 1:
        raise ValueError('swapped axes must have neighboring bit widths')
    prefix = prod(shape[:i])
    gap = prod(shape[i+1:j])
    suffix = prod(shape[j+1:])
    offset, middle = sum(bits[:i]), sum(bits[i+1:j])
    out = records
    if a < b:
        # X M eY -> e X M Y, exposing two equal-width fields.
        out, _ = move_digit(out, (2,)*sum(bits), offset+a+middle,
                            offset, ledger, width)
        ledger['v12_excess_bit_moves'] += 1
    out = binary_chunk_swap(out, min(a,b), circuit, ledger,
                            prefix=prefix*(2 if a != b else 1),
                            gap=gap, suffix=suffix, width=width)
    if a > b:
        # e X M Y -> e Y M X -> Y M eX.
        out, _ = move_digit(out, (2,)*sum(bits), offset,
                            offset+b+middle, ledger, width)
        ledger['v12_excess_bit_moves'] += 1
    changed = list(shape)
    changed[i], changed[j] = changed[j], changed[i]
    ledger['v12_direct_axis_swaps'] += 1
    return out, tuple(changed)


def reverse_axes(records, shape, circuit, ledger, width=1):
    """Reverse d neighboring-width axes with floor(d/2) direct swaps."""
    out, shape = records, tuple(shape)
    for i in range(len(shape)//2):
        out, shape = swap_axes(out, shape, i, len(shape)-1-i,
                               circuit, ledger, width)
    ledger['v12_axis_reversals'] += 1
    return out, shape


class DirectCRTLayout(CRTLayout):
    def _reverse_axes(self, values, shape, width):
        return reverse_axes(values, shape, self.circuit, self.ledger, width)


class DirectAxisMixin:
    """Expose one axis by exchanging it with the final axis, then restore.

    Maintains the requested original axis order, so each line executes exactly
    the same fixed-point operations as the inherited implementation. Does not
    reorder numerical axis operations or rely on floating-point commutativity.
    """
    def apply(self, values, *, inverse=False, axis_order=None):
        count = len(self.sources)
        order = tuple(range(count)) if axis_order is None else tuple(axis_order)
        if sorted(order) != list(range(count)):
            raise ValueError('axis order is not a permutation')
        valid = list(self.targets if inverse else self.sources)
        self._check_box(values, valid)
        out = list(values)
        for axis in order:
            physical = list(range(count))
            shape = self.targets
            encoded = self.codec.encode([[z] for z in out], self.ledger)
            self.ledger['gaussian_fixed_tensor_codec_calls'] += 1
            if axis != count-1:
                encoded, shape = swap_axes(encoded, shape, axis, count-1,
                    self.circuit, self.ledger, self.codec.width)
                physical[axis], physical[-1] = physical[-1], physical[axis]
            exposed = [row[0] for row in self.codec.decode(encoded, self.ledger)]
            reader = Reader(exposed, self.ledger, self.codec.width)
            transformed = []
            for prefix in product(*(range(n) for n in shape[:-1])):
                line = [reader.take() for _ in range(shape[-1])]
                is_valid = all(j < valid[i] for j, i in zip(prefix, physical[:-1]))
                if not is_valid:
                    if any(z != (0,0) for z in line):
                        raise AssertionError('invalid line not zero')
                    result = [(0,0)]*len(line)
                    self.ledger['gaussian_tensor_skipped_lines'] += 1
                elif inverse:
                    result = self.lines[axis].compress(line)
                    result += [(0,0)]*(self.targets[axis]-self.sources[axis])
                else:
                    if any(z != (0,0) for z in line[self.sources[axis]:]):
                        raise AssertionError('source line padding not zero')
                    result = self.lines[axis].expand(line[:self.sources[axis]])
                if is_valid:
                    self.ledger['gaussian_tensor_processed_lines'] += 1
                for z in result:
                    emit(transformed, z, self.ledger, self.codec.width)
            reader.finish()
            encoded = self.codec.encode([[z] for z in transformed], self.ledger)
            if axis != count-1:
                encoded, shape = swap_axes(encoded, shape, axis, count-1,
                    self.circuit, self.ledger, self.codec.width)
                physical[axis], physical[-1] = physical[-1], physical[axis]
            if shape != self.targets or physical != list(range(count)):
                raise AssertionError('axis restoration failed')
            out = [row[0] for row in self.codec.decode(encoded, self.ledger)]
            valid[axis] = self.sources[axis] if inverse else self.targets[axis]
            self._check_box(out, valid)
        self.ledger['gaussian_tensor_B0_calls' if inverse else 'gaussian_tensor_A_calls'] += 1
        return out


class DirectGaussianTensor(DirectAxisMixin, GaussianTensor):
    pass


class DirectFastGaussianTensor(DirectAxisMixin, FastGaussianTensor):
    pass
