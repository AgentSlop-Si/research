"""Recheck the default hooks without repeating the costly full recursive case."""
import hashlib
import json
from pathlib import Path
import time
import unittest
import test_fast_gaussian

if __name__ == '__main__':
    def flatten(suite):
        for item in suite:
            if isinstance(item, unittest.TestSuite):
                yield from flatten(item)
            else:
                yield item
    tests = [t for t in flatten(unittest.defaultTestLoader.loadTestsFromModule(test_fast_gaussian))
             if not t.id().endswith('.test_complete_recursive_product')]
    start = time.perf_counter()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(tests))
    output = {'status': 'passed' if result.wasSuccessful() else 'failed',
              'test_methods': result.testsRun, 'duration_seconds': time.perf_counter()-start,
              'included': [t.id() for t in tests],
              'excluded': 'test_complete_recursive_product: tested separately on original v10',
              'source_sha256': {n: hashlib.sha256(Path(n).read_bytes()).hexdigest()
                                for n in ['fast_resampled.py','test_fast_gaussian.py']},
              'scope': 'Backward-compatible defaults on v11; not a full v11 rerun of all inherited tests'}
    Path('regression_v11.json').write_text(json.dumps(output, indent=2)+'\n')
    raise SystemExit(not result.wasSuccessful())
