# v12 attribution and scope

All inherited NOTICE.txt and SOURCE_LICENSE.txt terms are retained.
The original preprint and earlier checkpoint authors retain credit for the
rank-saving networks, gap-permitting nonadjacent bit-field swaps, fixed-tape
layout contracts, Gaussian/synthetic reduction, arithmetic and recovery lemmas.

The final paragraph of the pinned source's 04-swap.tex explicitly describes the
same unequal-width nonadjacent swap used here. It is not a new v12 primitive.
The local modification exploits that contract in shorter CRT reversal and
Gaussian axis-exposure schedules, proves the resulting layout bound, derives
an exact conditional parameter certificate and supplies opt-in implementation,
validation and finite layout benchmarks.

No independent audit of all inherited lemmas, peer review, worldwide novelty
search, arbitrary-DFT improvement, full-code asymptotic proof, or whole-product
runtime superiority is claimed. The conditional exponent is NOT a practical
speedup measurement.
