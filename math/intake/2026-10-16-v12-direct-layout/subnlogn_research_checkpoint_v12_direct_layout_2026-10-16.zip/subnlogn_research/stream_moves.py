"""Sequential stream algorithms from source section 02.

Payloads are fixed-width nonnegative bit records. Movement uses append-only
output streams, forward readers, or explicit local stacks, never destination
address scatter. The ledger counts payload-symbol transfers and head returns.
Python loop/descriptor arithmetic is NOT included in those counts; this is a
streaming implementation, not yet a complete finite-alphabet tape simulator.
The number of temporary streams depends only on fixed radix/coefficients.
"""
from fractions import Fraction
from itertools import product
from math import gcd, prod


def charge(ledger, name, records, width):
    ledger[name] += records*width


class Reader:
    """Only sequential payload access is exposed to the movement algorithms."""
    def __init__(self, values, ledger, width):
        self.values, self.position = values, 0
        self.ledger, self.width = ledger, width
        # Conservative positioning bound: a prior writer can end at the right
        # boundary. This is a symbol-distance bound, not a Turing-step trace.
        charge(ledger,"stream_reposition_bound_symbols",len(values),width)

    def take(self):
        if self.position == len(self.values): raise ValueError("stream exhausted")
        value = self.values[self.position]
        self.position += 1
        charge(self.ledger, "stream_read_symbols", 1, self.width)
        return value

    def finish(self):
        if self.position != len(self.values): raise ValueError("stream not exhausted")
        charge(self.ledger, "stream_head_return_symbols", self.position, self.width)


def emit(out, value, ledger, width):
    out.append(value)
    charge(ledger, "stream_write_symbols", 1, width)


def copy_records(reader, out, count, ledger, width):
    for _ in range(count): emit(out, reader.take(), ledger, width)


def shape_check(records, shape, width):
    if not isinstance(width,int) or width < 1 or any(not isinstance(n, int) or n < 1 for n in shape):
        raise ValueError("positive record width and shape required")
    if len(records) != prod(shape): raise ValueError("incomplete Cartesian stream")


def validate_payload(records, width):
    if width < 1 or any(not isinstance(x, int) or x < 0 or x.bit_length() > width for x in records):
        raise ValueError("payload outside fixed record width")


def swap_digits(records, prefix, radix, gap, suffix, ledger, width=1):
    """[P,q,G,q,B] -> [P,q,G,q,B], by q^2 stable streams."""
    shape_check(records, (prefix,radix,gap,radix,suffix), width)
    banks = [[] for _ in range(radix*radix)]
    source = Reader(records,ledger,width)
    for _ in range(prefix):
        for a in range(radix):
            for _ in range(gap):
                for b in range(radix):
                    copy_records(source,banks[a*radix+b],suffix,ledger,width)
    source.finish()
    readers = [Reader(bank,ledger,width) for bank in banks]
    out=[]
    for _ in range(prefix):
        for a in range(radix):
            for _ in range(gap):
                for b in range(radix):
                    copy_records(readers[b*radix+a],out,suffix,ledger,width)
    for reader in readers: reader.finish()
    ledger["single_digit_swaps"] += 1
    return out


def move_digit(records, shape, source_index, target_index, ledger, width=1):
    """Move one fixed-radix field, preserving all other field order."""
    shape=tuple(shape)
    shape_check(records,shape,width)
    if not 0 <= source_index < len(shape) or not 0 <= target_index < len(shape):
        raise ValueError("invalid digit position")
    q=shape[source_index]
    new_shape=list(shape)
    new_shape.insert(target_index,new_shape.pop(source_index))
    input_prefix,input_suffix=prod(shape[:source_index]),prod(shape[source_index+1:])
    output_prefix,output_suffix=prod(new_shape[:target_index]),prod(new_shape[target_index+1:])
    banks=[[] for _ in range(q)]
    reader=Reader(records,ledger,width)
    for _ in range(input_prefix):
        for digit in range(q):
            copy_records(reader,banks[digit],input_suffix,ledger,width)
    reader.finish()
    readers=[Reader(bank,ledger,width) for bank in banks]
    out=[]
    for _ in range(output_prefix):
        for digit in range(q):
            copy_records(readers[digit],out,output_suffix,ledger,width)
    for reader in readers: reader.finish()
    ledger["single_digit_moves"] += 1
    return out,tuple(new_shape)


def rotate_later(records, shape, target, offset, ledger, width=1):
    """Target += offset(earlier field values), using two sequential banks.

    offset is evaluated once per complete target fiber, never per payload bit.
    Its cost must be bounded separately by the caller. No later control allowed.
    """
    shape=tuple(shape)
    shape_check(records,shape,width)
    if not 0 <= target < len(shape): raise ValueError("invalid target")
    q,b=shape[target],prod(shape[target+1:])
    banks=[[],[]]
    reader=Reader(records,ledger,width)
    for controls in product(*(range(n) for n in shape[:target])):
        amount=offset(controls)%q
        ledger["offset_preparations"] += 1
        copy_records(reader,banks[0],(q-amount)*b,ledger,width)
        copy_records(reader,banks[1],amount*b,ledger,width)
    reader.finish()
    readers=[Reader(bank,ledger,width) for bank in banks]
    out=[]
    for controls in product(*(range(n) for n in shape[:target])):
        amount=offset(controls)%q
        ledger["offset_preparations"] += 1
        copy_records(readers[1],out,amount*b,ledger,width)
        copy_records(readers[0],out,(q-amount)*b,ledger,width)
    for reader in readers: reader.finish()
    ledger["ordered_rotations"] += 1
    return out


def scale_positive(records, shape, target, coefficient, inverse, ledger, width=1):
    """Fixed positive integer unit via its coefficient monotone pieces."""
    shape=tuple(shape)
    shape_check(records,shape,width)
    if not 0<=target<len(shape): raise ValueError("invalid target")
    q,b=shape[target],prod(shape[target+1:])
    c=coefficient
    if c < 1 or gcd(c,q)!=1: raise ValueError("coefficient must be a positive unit")
    if c==1: return records
    inverse_q=pow(q,-1,c)
    bank_of_output=lambda y: (-y*inverse_q)%c
    bank_of_input=lambda y: c*y//q
    split,merge=(bank_of_output,bank_of_input) if inverse else (bank_of_input,bank_of_output)
    banks=[[] for _ in range(c)]
    reader=Reader(records,ledger,width)
    for _ in range(prod(shape[:target])):
        for y in range(q): copy_records(reader,banks[split(y)],b,ledger,width)
    reader.finish()
    readers=[Reader(bank,ledger,width) for bank in banks]
    out=[]
    for _ in range(prod(shape[:target])):
        for y in range(q): copy_records(readers[merge(y)],out,b,ledger,width)
    for reader in readers: reader.finish()
    ledger["fixed_integer_scalings"] += 1
    return out


def negate_field(records, shape, target, ledger, width=1):
    """Keep coordinate zero; reverse nonzero blocks and restore block order."""
    shape=tuple(shape)
    shape_check(records,shape,width)
    if not 0<=target<len(shape): raise ValueError("invalid target")
    q,b=shape[target],prod(shape[target+1:])
    reader=Reader(records,ledger,width)
    out=[]
    for _ in range(prod(shape[:target])):
        copy_records(reader,out,b,ledger,width)
        stack=[]
        copy_records(reader,stack,(q-1)*b,ledger,width)
        for _ in range(q-1):
            block=[]
            for _ in range(b):
                emit(block,stack.pop(),ledger,width)
                charge(ledger,"stack_pop_symbols",1,width)
            while block:
                emit(out,block.pop(),ledger,width)
                charge(ledger,"stack_pop_symbols",1,width)
    reader.finish()
    ledger["field_negations"] += 1
    return out


def affine_later(records, shape, target, scale, controls, ledger, width=1):
    """y <- scale*y + sum(c_i*x_i) with strictly earlier controls.

    Coefficients are fixed rational values, not their growing modular residues.
    This distinction keeps the number of monotone streams fixed as q^b grows.
    """
    shape=tuple(shape)
    shape_check(records,shape,width)
    if not 0 <= target < len(shape): raise ValueError("invalid target")
    controls=tuple((i,Fraction(c)) for i,c in controls if c)
    if any(not 0 <= i < target for i,_ in controls): raise ValueError("control must precede target")
    scale=Fraction(scale)
    q=shape[target]
    if gcd(scale.numerator,q)!=1 or gcd(scale.denominator,q)!=1:
        raise ValueError("scale is not a unit")
    reduced=[]
    for i,c in controls:
        if gcd(c.denominator,q)!=1: raise ValueError("control denominator is not a unit")
        reduced.append((i,c.numerator*pow(c.denominator,-1,q)%q))
    out=scale_positive(records,shape,target,abs(scale.numerator),False,ledger,width)
    out=scale_positive(out,shape,target,scale.denominator,True,ledger,width)
    if scale < 0: out=negate_field(out,shape,target,ledger,width)
    if reduced:
        out=rotate_later(out,shape,target,lambda x: sum(c*x[i] for i,c in reduced),ledger,width)
    ledger["ordered_affine_calls"] += 1
    return out


def split_rows(records, prefix, rows, suffix, roles, ledger, width=1):
    shape_check(records,(prefix,rows,suffix),width)
    if roles < 2 or rows%roles: raise ValueError("incomplete cyclic role rows")
    banks=[[] for _ in range(roles)]
    reader=Reader(records,ledger,width)
    for _ in range(prefix):
        for row in range(rows): copy_records(reader,banks[row%roles],suffix,ledger,width)
    reader.finish()
    ledger["cyclic_row_splits"] += 1
    return banks


def merge_rows(banks, prefix, rows, suffix, routing, ledger, width=1):
    roles=len(banks)
    if sorted(routing)!=list(range(roles)) or rows%roles: raise ValueError("invalid role routing")
    for bank in banks: shape_check(bank,(prefix,rows//roles,suffix),width)
    readers=[Reader(bank,ledger,width) for bank in banks]
    out=[]
    for _ in range(prefix):
        for row in range(rows): copy_records(readers[routing[row%roles]],out,suffix,ledger,width)
    for reader in readers: reader.finish()
    ledger["cyclic_row_merges"] += 1
    return out


def xor_stream(target, source, ledger, width=1):
    if len(target)!=len(source): raise ValueError("unaligned gate inputs")
    a,b=Reader(target,ledger,width),Reader(source,ledger,width)
    out=[]
    for _ in range(len(target)): emit(out,a.take()^b.take(),ledger,width)
    a.finish(); b.finish()
    charge(ledger,"pointwise_xor_bits",len(out),width)
    return out
