"""Exact conditional cost certificate after the direct-axis layout replacement.

All inherited rank, layer, analytic and fixed-tape assumptions remain. The new
local scheduling proof replaces only the fourth row of the assembly cost table.
It does not certify the entire imported paper or the whole Python algorithm.
"""
from dataclasses import asdict
from fractions import Fraction as Q
import json
from pathlib import Path
from cost_certificate import Parameters, json_default
from motifs import Budget
from parameter_certificate_v11 import L, exp_lower, parameters as v11_parameters


def parameters():
    a, b = (Budget(100,kind).deficit/L for kind in ('bit','complex'))
    epsilon = Q(1,40)
    c = a*(1-2*a)/(2*(1-a))
    return Parameters(1-a, 1-b, Q(1,2), Q(1,16), 1-a*a, 1-a*a/2,
                      c, epsilon, epsilon*c*a/2)


def margins(v):
    result = list(v.margins())
    # New CRT/Gaussian axis layouts: d(1+ell^tau), not d^2(1+ell^tau).
    result[3] = (1-v.tau)*(1-v.epsilon)
    return tuple(result)


def certificate():
    v, old = parameters(), v11_parameters()
    a=1-v.tau
    checks = {
        'log_upper': exp_lower(L)>100**3,
        'bit_rank': 0<v.tau<1 and L*(1-v.tau)<=Budget(100,'bit').deficit,
        'complex_rank': 0<v.sigma<1 and L*(1-v.sigma)<=Budget(100,'complex').deficit,
        'fixed_beta': v.beta==Q(1,2),
        'internal_layer': max(v.tau,v.sigma)<v.lam<1,
        'movement_overhead': v.tau*(1+v.c/v.beta)<v.lam,
        'leaf_and_grouping': max(v.lam,v.sigma+v.beta*(1-v.sigma))<v.lam_prime<1,
        'positive': min(v.c,v.epsilon,v.delta,v.kappa)>0,
        'dimension': v.epsilon<Q(1,12),
        'guard': v.epsilon*v.guard_power<1,
        'new_axis_layout': v.tau+v.epsilon*(1-v.tau)<1,
        'gaussian_maps': Q(3,4)+v.delta+Q(3,2)*v.epsilon<1,
        'prefix': v.epsilon*(1+v.c)<1,
        'scalar': v.epsilon+v.delta<1,
        'new_seven_margins': min(margins(v))>=2*v.kappa,
        'quadratic_identity': v.kappa==a*a*(1-2*a)/(160*(1-a)),
        'not_feasible_under_old_layout': v.epsilon*(2-v.tau)>1-v.tau,
    }
    if not all(checks.values()):
        raise AssertionError({k:val for k,val in checks.items() if not val})
    return dict(date='2026-10-16',status='CONDITIONAL: direct-axis schedule plus inherited interfaces',
        parameters=asdict(v),checks=checks,margins=margins(v),a=a,
        old_kappa=old.kappa,new_kappa=v.kappa,ratio=v.kappa/old.kappa,
        old_necessary_log2_b=1/(old.epsilon*old.c),
        new_necessary_log2_b=1/(v.epsilon*v.c),
        new_layout_normalized_cost='O(d*(1+ell**tau))',
        old_layout_normalized_cost='O(d**2*(1+ell**tau))',
        unchanged_other_cost_rows=True,full_machine_proof=False,novelty_verified=False,
        note='The older Parameters.check/margins intentionally implement the OLD contract. Use this module for the revised contract.')


if __name__=='__main__':
    result=certificate()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2,default=json_default)+'\n')
    print(json.dumps({k:float(result[k]) for k in ('a','old_kappa','new_kappa','ratio','new_necessary_log2_b')},indent=2))
