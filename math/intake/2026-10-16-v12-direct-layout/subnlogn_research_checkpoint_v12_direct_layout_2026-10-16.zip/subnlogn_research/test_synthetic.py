"""Defining-sum oracles for the integrated synthetic transform and ring product."""
from collections import Counter
from fractions import Fraction as Q
from itertools import product
from math import prod
import random
import unittest
from motifs import Gaussian as G
from synthetic import (Layout, monomial, multiply_reference, normalized_convolution,
                       normalized_ring_product, pack_signed, ring_product_numerators,
                       transform, trunc_shift, unpack_centered)

COUNTS = Counter()


def coordinates(index, axes):
    out = []
    for size in reversed(axes):
        index, value = divmod(index, size)
        out.append(value)
    return tuple(reversed(out))


def direct_transform(records, layout, opposite=False):
    # Defining multidimensional character sums with independent wrap arithmetic.
    r, count = layout.r, layout.size
    original = records
    if opposite:
        original = [None]*count
        for stored, record in enumerate(records):
            natural = 0
            for k, t in zip(layout.frequency_at(stored), layout.axes): natural = natural*t+k
            original[natural] = record
    outputs = []
    for out in range(count):
        freq = coordinates(out, layout.axes) if opposite else layout.frequency_at(out)
        polynomial = [G() for _ in range(r)]
        for index, record in enumerate(original):
            coord = coordinates(index, layout.axes)
            exponent = sum((2*r//t)*a*b for t, a, b in zip(layout.axes, freq, coord))
            if not opposite: exponent = -exponent
            for j, z in enumerate(record):
                q, dest = divmod(j+exponent, r)
                polynomial[dest] += G(*z)*(-1 if q % 2 else 1)*Q(1, count)
        outputs.append(polynomial)
    return outputs


def schoolbook_ring(f, g):
    r = len(f)
    out = [G() for _ in range(r)]
    for i, a in enumerate(f):
        for j, b in enumerate(g):
            sign = 1 if i+j < r else -1
            out[(i+j) % r] += G(*a)*G(*b)*sign
    return [(int(z.real), int(z.imag)) for z in out]


def direct_convolution(f, g, axes):
    r, size = len(f[0]), len(f)
    out = [[G() for _ in range(r)] for _ in range(size)]
    for i, a in enumerate(f):
        ic = coordinates(i, axes)
        for j, b in enumerate(g):
            jc = coordinates(j, axes)
            dest = 0
            for u, v, t in zip(ic, jc, axes): dest = dest*t+(u+v) % t
            for index, z in enumerate(schoolbook_ring(a, b)): out[dest][index] += G(*z)
    return out


def small_integer_multiply(a, b):
    """Independent schoolbook bit oracle; used to verify injected calls."""
    out = 0
    while b:
        if b & 1: out += a
        a <<= 1
        b >>= 1
    return out


class PackingTests(unittest.TestCase):
    def test_signed_pack_and_centered_recovery(self):
        for width in (3, 4, 7, 8, 9, 17, 32):
            half = 1 << (width-1)
            choices = (-half+1, -2, -1, 0, 1, half-1)
            for coefficients in product(choices, repeat=3):
                expected = sum(c*(1 << (width*j)) for j, c in enumerate(coefficients))
                packed = pack_signed(coefficients, width)
                self.assertEqual(packed, expected)
                self.assertEqual(unpack_centered(packed, 4, width), list(coefficients)+[0])
                COUNTS["signed_packing_cases"] += 1
        self.assertEqual(unpack_centered(-1, 4, 8), [-1, 0, 0, 0])
        with self.assertRaises(ValueError): pack_signed([128], 8)
        with self.assertRaises(ValueError): unpack_centered(1 << 20, 2, 8)

    def test_signed_ring_products(self):
        rng = random.Random(83112)
        for p in (4, 7, 16, 33):
            for r in (2, 4, 8):
                limit = 1 << p
                cases = []
                for value in ((limit, 0), (-limit, 0), (0, limit), (0, -limit)):
                    cases.append(([value]*r, [value]*r))
                for _ in range(8):
                    cases.append(tuple([(rng.randrange(-limit//2, limit//2+1), rng.randrange(-limit//2, limit//2+1))
                                        for _ in range(r)] for _ in range(2)))
                for f, g in cases:
                    ledger = Counter()
                    got = ring_product_numerators(f, g, p, integer_multiply=small_integer_multiply, ledger=ledger)
                    self.assertEqual(got, schoolbook_ring(f, g))
                    self.assertEqual(ledger["integer_multiplications"], 4)
                    self.assertLessEqual(ledger["integer_multiply_max_bits"], 4*p*r)
                    normalized = normalized_ring_product(f, g, p)
                    denom = (1 << p)*r
                    self.assertEqual(normalized, [(int(Q(a, denom)), int(Q(b, denom))) for a, b in got])
                    self.assertTrue(all(a*a+b*b <= limit*limit for a, b in normalized))
                    COUNTS["signed_ring_products"] += 1

    def test_negative_rounding_and_wrap(self):
        self.assertEqual(trunc_shift(-3, 1), -1)
        self.assertNotEqual(trunc_shift(-3, 1), -3 >> 1)
        f = [(0, 0), (16, 0)]
        self.assertEqual(ring_product_numerators(f, f, 4), [(-256, 0), (0, 0)])
        COUNTS["negative_controls"] += 2


class TransformTests(unittest.TestCase):
    def assert_error(self, actual, exact, squared_bound):
        for out, expected in zip(actual, exact):
            for z, w in zip(out, expected):
                delta = G(*z)-w
                self.assertLess(delta.real**2+delta.imag**2, squared_bound)

    def test_all_signed_monomials(self):
        for r in (2, 4, 8, 16):
            poly = [(i-3, 2*i+1) for i in range(r)]
            for exponent in range(-4*r, 4*r+1):
                expected = [(0, 0)]*r
                for i, (a, b) in enumerate(poly):
                    q, j = divmod(i+exponent, r)
                    sign = -1 if q % 2 else 1
                    expected[j] = (sign*a, sign*b)
                self.assertEqual(monomial(poly, exponent), expected)
                COUNTS["synthetic_monomial_actions"] += 1

    def test_layout_schedule(self):
        # This is the named-slot illustration in the source, independently fixed.
        layout = Layout((64, 32), 64, 2)
        slots, moves = layout.schedule()
        expected = ((0,5),(0,0),(1,0),(0,4),(0,3),(1,4),(1,3),(0,2),(0,1),(1,2),(1,1))
        self.assertEqual(slots, expected)
        self.assertTrue(any(op[0] == "chunk_swap" for op in moves))
        for r in (2, 4, 8, 16, 32):
            for axes in ((r,), (r//2,), (r, r//2), (r//2, r, r//2)):
                for k in range(1, max(1, r.bit_length()-2)+1):
                    l = Layout(axes, r, k)
                    slots, ops = l.schedule()
                    self.assertEqual(set(slots), set(l.original_slots))
                    self.assertEqual(len(slots), sum(t.bit_length()-1 for t in axes))
                    self.assertLessEqual(sum(op[0] == "bit_move" for op in ops), len(axes)*k)
                    self.assertLessEqual(sum(op[0] == "chunk_swap" for op in ops), len(axes)*(r.bit_length()-2)//k)
                    COUNTS["layout_schedules"] += 1

    def test_defining_transform_and_inverse(self):
        rng = random.Random(83118)
        for r, axes in ((2,(2,)), (4,(2,4)), (4,(2,2,2)), (8,(4,8)), (8,(8,4))):
            p = 18
            for k in range(1, max(1, r.bit_length()-2)+1):
                layout = Layout(axes, r, k)
                size = layout.size
                inputs = [[[(rng.randrange(-50, 51), rng.randrange(-50, 51)) for _ in range(r)] for _ in range(size)]]
                # Every impulse address at small shapes covers signs and frequencies.
                if size <= 8:
                    for index in range(size*r):
                        f = [[(0, 0)]*r for _ in range(size)]
                        f[index//r][index % r] = (1 << 12, 0)
                        inputs.append(f)
                for f in inputs:
                    exact = direct_transform(f, layout)
                    got = transform(f, layout, p)
                    self.assert_error(got, exact, 2*(r.bit_length()-1)**2)
                    exact_back = direct_transform(got, layout, opposite=True)
                    back = transform(got, layout, p, opposite=True)
                    self.assert_error(back, exact_back, 2*(r.bit_length()-1)**2)
                    COUNTS["defining_synthetic_transforms"] += 2
                # At integral grids divisible by M**2 no round loses information.
                f = [[(rng.randrange(-4, 5)*size*size, 0) for _ in range(r)] for _ in range(size)]
                got = transform(f, layout, p)
                back = transform(got, layout, p, opposite=True)
                self.assertEqual([[(a*size,b*size) for a,b in poly] for poly in back], f)
                COUNTS["exact_normalized_roundtrips"] += 1

    def test_convolution_error_and_operation_accounting(self):
        rng = random.Random(14001)
        for r, axes in ((2,(2,)), (4,(2,4)), (4,(4,2)), (8,(4,))):
            layout = Layout(axes, r)
            for p in (7, 13):
                for trial in range(3):
                    max_num = (1 << p)//4
                    f, g = [[[(rng.randrange(-max_num, max_num+1), rng.randrange(-max_num, max_num+1))
                              for _ in range(r)] for _ in range(layout.size)] for _ in range(2)]
                    ledger = Counter()
                    got = normalized_convolution(f, g, layout, p, ledger=ledger)
                    raw = direct_convolution(f, g, axes)
                    exact = [[z*Q(1, (1 << p)*layout.size*r) for z in poly] for poly in raw]
                    bound_squared = 2*layout.size**2*(3*(r.bit_length()-1)+1)**2
                    self.assert_error(got, exact, bound_squared)
                    self.assertEqual(ledger["integer_multiplications"], 4*layout.size)
                    self.assertEqual(ledger["polynomial_butterflies"], 3*layout.size*(layout.size.bit_length()-1)//2)
                    COUNTS["synthetic_convolutions"] += 1

    def test_too_small_precision_is_rejected(self):
        with self.assertRaises(ValueError): transform([[(0,0)]*8]*4, Layout((4,),8), 3)
        with self.assertRaises(ValueError): normalized_ring_product([(17,0)]*2, [(0,0)]*2, 4)
        COUNTS["negative_controls"] += 2


class IntegrationTests(unittest.TestCase):
    def test_exact_integer_integration(self):
        rng = random.Random(5911)
        for bits in (0, 1, 2, 7, 31, 64, 127, 256, 1024, 4096):
            for m in (2, 7, 16, None):
                for trial in range(3):
                    x, y = (((1 << bits)-1, (1 << bits)-1) if trial == 0 else
                            (rng.getrandbits(bits), rng.getrandbits(bits)))
                    got, info = multiply_reference(x, y, digit_bits=m)
                    self.assertEqual(got, x*y)
                    self.assertFalse(info["implementation_status"]["sub_n_log_n_proved_for_implementation"])
                    COUNTS["synthetic_integer_products"] += 1
        for x, y in ((0, 1 << 512), (1, (1 << 512)-1), ((1 << 37)-1, (1 << 213)+17)):
            got, _ = multiply_reference(x, y, integer_multiply=small_integer_multiply)
            self.assertEqual(got, x*y)
            COUNTS["synthetic_integer_products_injected_schoolbook"] += 1


if __name__ == "__main__": unittest.main()
