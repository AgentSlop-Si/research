"""Independent address-scatter oracles are used ONLY in these tests."""
from collections import Counter
from fractions import Fraction as Q
from itertools import product
from math import prod
import random
import unittest
from bit_frames import BitGate, BitNetwork, frame
from motifs import Budget, identity, matmul
from stream_moves import (affine_later, merge_rows, move_digit, negate_field,
                          split_rows, swap_digits, validate_payload)
from swap_recursion import (ChunkLayout, CompiledBitCircuit, ShearPlan, arbitrary_q_swap,
                            binary_chunk_swap, recursive_swap, _resize_rows)

COUNTS=Counter()


def scatter(values,shape,mapping,new_shape=None):
    new_shape=shape if new_shape is None else new_shape
    out=[None]*len(values)
    for coordinates,value in zip(product(*(range(n) for n in shape)),values):
        destination=mapping(coordinates)
        rank=0
        for d,n in zip(destination,new_shape): rank=rank*n+d
        if out[rank] is not None: raise AssertionError("oracle is not injective")
        out[rank]=value
    return out


def swap_oracle(values,p,a,g,b):
    return scatter(values,(p,a,g,a,b),lambda x:(x[0],x[3],x[2],x[1],x[4]))


class SwapControl:
    """Independent m=2 W=2/3 test circuit, explicitly WITHOUT rank saving."""
    m=2
    def __init__(self,scratch=False,negative_source=False,*,m=2,wires=None):
        self.m=m
        self.wires=(3 if scratch else 2) if wires is None else wires
        self.negative=negative_source
        self.rank_sum=self.m*self.wires+(3 if negative_source else 0)
    def roles(self): return iter(range(self.wires))
    def source_frame(self,role): return (Q(-1),*([Q(0)]*(self.m-1))) if self.negative and role==0 else (Q(0),)*self.m
    def sink_frame(self,role): return (Q(0),*([Q(1)]*(self.m-1))) if self.negative and role==1 else (Q(1),)*self.m
    def routed_output(self,role): return 1-role if role<2 else role
    def gates(self):
        frames=((Q(1),*([Q(0)]*(self.m-1))),(Q(1),)*self.m,
                (Q(0),*([Q(1)]*(self.m-1)))) if self.negative else ((Q(0),)*self.m,)*3
        for time,(f,update) in enumerate(zip(frames,((1,0),(0,1),(1,0)))):
            yield BitGate(0,(),time,f,(0,1),(update,))
    def edge_matrix(self,tail,head): return [[head[i]-tail[i] if i==j else Q(0) for j in range(self.m)] for i in range(self.m)]


class SequentialMovementTests(unittest.TestCase):
    def test_digit_split_move_and_swap(self):
        for q in (3,5,7):
            for p,g,b in ((1,1,1),(2,3,2)):
                values=list(range(p*q*g*q*b))
                got=swap_digits(values,p,q,g,b,Counter(),len(values).bit_length())
                self.assertEqual(got,swap_oracle(values,p,q,g,b))
                COUNTS["stream_digit_swaps"]+=1
            shape=(2,q,3,2)
            values=list(range(prod(shape)))
            for source,target in ((1,3),(1,0),(3,1),(2,2)):
                ledger=Counter()
                got,new_shape=move_digit(values,shape,source,target,ledger,len(values).bit_length())
                def mapping(x):
                    x=list(x); x.insert(target,x.pop(source)); return x
                self.assertEqual(got,scatter(values,shape,mapping,new_shape))
                self.assertEqual(ledger["stream_read_symbols"],2*len(values)*len(values).bit_length())
                COUNTS["stream_digit_moves"]+=1

    def test_affine_fibers_all_units_and_spectators(self):
        for modulus in (3,5,9,25):
            shape=(2,modulus,2,modulus,3)
            values=list(range(prod(shape)))
            for scale in (Q(1),Q(-1),Q(2),Q(-2),Q(1,2),Q(-5,2),Q(7,4)):
                from math import gcd
                if gcd(scale.numerator*scale.denominator,modulus)!=1: continue
                controls=((1,Q(-2,1)),(2,Q(1,2)))
                got=affine_later(values,shape,3,scale,controls,Counter(),len(values).bit_length())
                reduced=lambda c: c.numerator*pow(c.denominator,-1,modulus)%modulus
                def mapping(x):
                    y=list(x)
                    y[3]=(reduced(scale)*x[3]+sum(reduced(c)*x[i] for i,c in controls))%modulus
                    return y
                self.assertEqual(got,scatter(values,shape,mapping))
                COUNTS["stream_rational_affine_maps"]+=1

    def test_cyclic_rows_and_nonzero_scratch(self):
        for w in (2,3,5):
            p,r,b=2,3*w,7
            values=list(range(p*r*b))
            ledger=Counter()
            banks=split_rows(values,p,r,b,w,ledger,12)
            self.assertTrue(all(len(bank)*w==len(values) for bank in banks))
            routed=list(reversed(banks))
            self.assertEqual(merge_rows(routed,p,r,b,list(reversed(range(w))),ledger,12),values)
            COUNTS["stream_row_roundtrips"]+=1

    def test_stream_matrix_shears(self):
        rng=random.Random(172903)
        matrices=([[0,0],[0,0]],[[1,2],[2,4]],[[1,2],[3,5]],[[0,Q(2,3)],[Q(-1,2),Q(1,4)]])
        for matrix in matrices:
            plan=ShearPlan(matrix)
            prime=next(q for q in (3,5,7,11) if plan.accepts_prime(q))
            layout=ChunkLayout(prime,2,2,1,1,2,2)
            shape=layout.fields(2)
            values=[rng.randrange(1<<12) for _ in range(layout.volume)]
            ledger=Counter()
            calls=[]
            def child(data,s):
                calls.append(s)
                return swap_digits(data,s.prefix*s.rows*s.before,s.prime,s.gap,s.suffix,ledger,12)
            got=plan.execute(values,layout,child,ledger,12)
            def mapping(x):
                y=list(x)
                for i in range(2):
                    y[3+i]=(x[3+i]+sum(Q(c).numerator*pow(Q(c).denominator,-1,prime)*x[6+j] for j,c in enumerate(matrix[i])))%prime
                return y
            self.assertEqual(got,scatter(values,shape,mapping))
            self.assertEqual(len(calls),plan.rank)
            self.assertTrue(all(s.volume==layout.volume for s in calls))
            COUNTS["stream_rank_factored_shears"]+=1

    def test_multilevel_swap_recursion(self):
        rng=random.Random(173016)
        for scratch,negative,depth in ((False,False,1),(False,False,2),(False,True,1),(True,False,1)):
            circuit=CompiledBitCircuit(SwapControl(scratch,negative))
            layout=ChunkLayout(circuit.prime,2**depth,1,circuit.wires**depth,1,2 if depth==1 else 1,2)
            values=[rng.randrange(256) for _ in range(layout.volume)]
            ledger=Counter()
            got=recursive_swap(values,layout,circuit,ledger,8)
            expected=swap_oracle(values,layout.prefix*layout.rows*layout.before,layout.chunk_range,layout.gap,layout.suffix)
            self.assertEqual(got,expected)
            internal=sum(circuit.rank_sum**i for i in range(depth))
            self.assertEqual(ledger["swap_internal_nodes"],internal)
            self.assertEqual(ledger["swap_leaf_calls"],circuit.rank_sum**depth)
            self.assertEqual(ledger["matrix_shear_child_calls"],circuit.rank_sum*internal)
            self.assertEqual(ledger["swap_child_record_volume_sum"]*circuit.wires,
                             ledger["swap_parent_record_volume_sum"]*circuit.rank_sum)
            self.assertEqual(ledger["parking_push_calls"],circuit.rank_sum*internal)
            COUNTS["multilevel_stream_swaps"]+=1

    def test_arbitrary_width_and_binary_padding(self):
        rng=random.Random(19823)
        configurations=((2,2,1),(2,2,3),(2,2,4),(2,3,3),(2,4,3),(2,4,4),(3,2,5))
        for m,w,digits in configurations:
            circuit=CompiledBitCircuit(SwapControl(m=m,wires=w))
            n=circuit.prime**digits
            p,g,b=(2,2,1) if digits<4 else (1,1,1)
            values=[rng.randrange(64) for _ in range(p*n*g*n*b)]
            ledger=Counter()
            got=arbitrary_q_swap(values,digits,circuit,ledger,prefix=p,gap=g,suffix=b,width=6)
            self.assertEqual(got,swap_oracle(values,p,n,g,b))
            if w!=3 and digits>=3: self.assertGreater(ledger["row_padding_records"],0)
            if digits>=3 and (w,digits)!=(4,3): self.assertGreater(ledger["swap_internal_nodes"],0)
            if w==4: self.assertEqual(ledger["single_digit_moves"],4)  # rho=2, join and separate.
            COUNTS["arbitrary_width_stream_swaps"]+=1
        circuit=CompiledBitCircuit(SwapControl())
        for bits in (1,2,3,5):
            p,g,b=2,3,2
            values=[rng.randrange(256) for _ in range(p*(1<<(2*bits))*g*b)]
            ledger=Counter()
            got=binary_chunk_swap(values,bits,circuit,ledger,prefix=p,gap=g,suffix=b,width=8)
            self.assertEqual(got,swap_oracle(values,p,1<<bits,g,b))
            if bits==5: self.assertGreater(ledger["swap_internal_nodes"],0)
            COUNTS["binary_padded_stream_swaps"]+=1

    def test_invalid_contracts(self):
        with self.assertRaises(ValueError): affine_later([0]*9,(3,3),0,1,((1,1),),Counter())
        with self.assertRaises(ValueError): affine_later([0]*9,(3,3),1,Q(1,3),(),Counter())
        with self.assertRaises(ValueError): split_rows([0]*9,1,3,3,2,Counter())
        with self.assertRaises(ValueError): validate_payload([0,4],2)
        with self.assertRaises(ArithmeticError): _resize_rows([0,0,1],1,3,2,1,Counter(),1)
        circuit=CompiledBitCircuit(SwapControl())
        with self.assertRaises(ValueError): recursive_swap([0]*81,ChunkLayout(3,2),circuit,Counter())
        with self.assertRaises(ValueError): ChunkLayout(9,1)
        class WrongEndpoint(SwapControl):
            def sink_frame(self,role): return (Q(0),Q(0))
        class WrongRouting(SwapControl):
            def routed_output(self,role): return role
        class WrongRank(SwapControl):
            def __init__(self): super().__init__(); self.rank_sum=3
        for bad in (WrongEndpoint(),WrongRouting(),WrongRank()):
            with self.assertRaises(ValueError): CompiledBitCircuit(bad)
        COUNTS["negative_controls"]+=10


class RationalBitFrameTests(unittest.TestCase):
    def test_fixed_h100_descriptor(self):
        net=BitNetwork()
        expected=Budget(100,"bit")
        self.assertEqual((net.m,net.wires,net.rank_sum),(expected.m,expected.wires,expected.ranks))
        neighbors=list(net.neighboring(0))
        self.assertEqual(len(set(neighbors)),13968)
        self.assertTrue(all((net.masks[0]&net.masks[i]).bit_count()==1 for i in neighbors))
        role=("X",0,1,2)
        endpoint=net.sink_frame(net.routed_output(role)).difference(net.source_frame(role))
        self.assertEqual(endpoint,frame(100,((1,(None,None,None)),)))
        self.assertEqual(endpoint.entry(123456,123456),1)
        self.assertEqual(endpoint.entry(123456,123457),0)
        self.assertLess(net.rank_sum,net.wires*net.m)
        COUNTS["fixed_bit_network_checks"]+=4

    def test_rational_projection_and_negative_source(self):
        net=BitNetwork(3)
        role=("X",0,0,0)
        source=net.source_frame(role)
        head=net.gate_frame(0,(0,0),2,0)
        self.assertEqual(source.trace,-1)
        self.assertEqual(head.trace,1)
        # The first edge is 2 P, of rank ONE, not trace two or rank zero.
        first=head.difference(source)
        self.assertEqual(ShearPlan(first.dense()).rank,1)
        p=head.dense()
        self.assertEqual(matmul(p,p),p)
        rng=random.Random(391)
        for _ in range(3):
            d=[rng.randrange(5) for _ in range(net.m)]
            actual=head.apply_mod(d,5)
            expected=[sum(c.numerator*pow(c.denominator,-1,5)*v for c,v in zip(row,d))%5 for row in p]
            self.assertEqual(actual,expected)
            COUNTS["rational_tensor_contractions"]+=1
        COUNTS["negative_source_rank_checks"]+=1

    def test_actual_small_network_factor_table(self):
        network=BitNetwork(3)
        circuit=CompiledBitCircuit(network)
        self.assertEqual(circuit.rank_sum,network.rank_sum)
        self.assertEqual(circuit.wires,11)
        self.assertTrue(all(plan.accepts_prime(circuit.prime) for plan in circuit.plans.values()))
        self.assertNotEqual(circuit.prime,3)
        self.assertGreaterEqual(circuit.rank_sum,circuit.wires*circuit.m)
        COUNTS["complete_small_bit_factor_tables"]+=1

    def test_complete_framed_bit_network_sparse_fibers(self):
        rng=random.Random(392)
        for h in (3,4):
            net=BitNetwork(h)
            roles=tuple(net.roles())
            self.assertEqual(len(roles),net.wires)
            d=[rng.randrange(5) for _ in range(net.m)]
            addresses={role:tuple(rng.randrange(5) for _ in range(net.m)) for role in roles}
            initial={role:{addresses[role]:1<<i} for i,role in enumerate(roles)}
            result=net.run_sparse(initial,d,5)
            for i,role in enumerate(roles):
                destination=tuple((a+b)%5 for a,b in zip(addresses[role],d))
                self.assertEqual(result[role],{destination:1<<i})
                COUNTS["framed_bit_network_role_checks"]+=1
            self.assertGreaterEqual(net.rank_sum,net.wires*net.m)  # NO small-network gain claimed.

    def test_rational_neighbor_projection(self):
        net=BitNetwork(5)
        tx,ty=net.masks[0],net.masks[next(net.neighboring(0))]
        self.assertEqual((tx&ty).bit_count(),1)
        # Check rational orthogonality of the two line projectors on F, not a
        # binary dot product, which would incorrectly say they overlap.
        p=lambda t:[[Q(((t>>i)&1)*(3*((t>>j)&1)-1),6) for j in range(5)] for i in range(5)]
        self.assertEqual(matmul(p(tx),p(ty)),[[Q(0)]*5 for _ in range(5)])
        COUNTS["rational_neighbor_projection_checks"]+=1

    def test_full_side_wire_network_sparse_fiber(self):
        net=BitNetwork(5)
        roles=tuple(net.roles())
        rng=random.Random(394)
        chosen=[roles[0],next(role for role in roles if role[0]=="A"),next(role for role in roles if role[0]=="C")]
        initial={role:{} for role in roles}
        d=[rng.randrange(5) for _ in range(net.m)]
        for i,role in enumerate(chosen):
            address=tuple(rng.randrange(5) for _ in range(net.m))
            initial[role][address]=1<<i
        got=net.run_sparse(initial,d,5)
        for role in roles:
            expected={tuple((a+b)%5 for a,b in zip(h,d)):v for h,v in initial[role].items()}
            self.assertEqual(got[role],expected)
        COUNTS["sparse_h5_bit_role_checks"]+=len(roles)


if __name__=="__main__": unittest.main()
