"""Analytic Fourier, integer cyclic and address-scatter oracles are TEST ONLY."""
from collections import Counter
from decimal import Decimal,localcontext
from itertools import product
from math import prod
import random
import unittest

from certified_phase import CertifiedPhase
from crt_layout import CRTLayout
from guarded_layer import make_guarded_network_layer
from multiply_resampled import multiply_resampled
from network_frames import ComplexNetwork
from packed_stream import make_stream_layout_move
from resampled_transform import CyclicConvolver,SourceTransform,grid_product
from swap_recursion import CompiledBitCircuit
from test_gaussian_resampling import decimal_phase
from test_stream_swap import SwapControl

COUNTS = Counter()


def rank(coordinates,shape):
    out = 0
    for coordinate,n in zip(coordinates,shape): out = out*n+coordinate
    return out


def direct_cyclic(f,g,shape):
    coordinates = list(product(*(range(t) for t in shape)))
    out = [[0,0] for _ in f]
    for a,x in zip(coordinates,f):
        for b,y in zip(coordinates,g):
            i = rank([(j+k)%t for j,k,t in zip(a,b,shape)],shape)
            out[i][0] += x[0]*y[0]-x[1]*y[1]
            out[i][1] += x[0]*y[1]+x[1]*y[0]
    return out


def direct_fourier(values,shape,multipliers,opposite=False):
    total = prod(shape)
    coordinates = list(product(*(range(t) for t in shape)))
    phases = [decimal_phase(j,total) for j in range(total)]
    out = []
    sign = 1 if opposite else -1
    for destination in coordinates:
        a = b = Decimal(0)
        for source,z in zip(coordinates,values):
            numerator = sign*sum(c*j*k*(total//t) for c,j,k,t in
                                 zip(multipliers,source,destination,shape))
            u,v = phases[numerator % total]
            a += z[0]*u-z[1]*v
            b += z[0]*v+z[1]*u
        out.append((a/total,b/total))
    return out


class PhaseTests(unittest.TestCase):
    def test_certified_disk_phases(self):
        rng = random.Random(1472)
        with localcontext() as ctx:
            ctx.prec = 160
            engine = CertifiedPhase()
            cases = [(n,d,p) for p in (2,101,128,256) for d in (1,4,7,16)
                     for n in range(-2,d+2)]
            cases += [(rng.randrange(-(1 << 120),1 << 120),
                       rng.randrange(1,1 << 119),128) for _ in range(15)]
            cases += [(j,1 << 100,128) for j in ((1 << 98)-1,(1 << 98)+1)]
            for n,d,p in cases:
                result = engine.grid(n,d,p)
                expected = decimal_phase(n,d)
                self.assertTrue(result.verify_grid_error())
                for exact,(lo,hi) in zip(expected,(result.real_interval,result.imag_interval)):
                    # Decimal's final analytic rounding can differ at an exact
                    # quadrant endpoint by <1e-150. The certificate is exact.
                    tolerance = Decimal("1e-145")
                    self.assertLessEqual(Decimal(lo)/(1 << result.interval_bits)-tolerance,exact)
                    self.assertGreaterEqual(Decimal(hi)/(1 << result.interval_bits)+tolerance,exact)
                self.assertLess(sum((Decimal(v)-x*(1 << p))**2 for v,x in zip(result.value,expected)),4)
                COUNTS["certified_complex_phases"] += 1

    def test_phase_product_contract(self):
        engine = CertifiedPhase()
        p,scale = 128,1 << 128
        for n in range(12):
            phase = engine.grid(n,12,p).value
            for z in ((scale,0),(0,-scale),(scale//3,-scale//4),(0,0)):
                got = grid_product(phase,z,p,Counter())
                self.assertLessEqual(sum(v*v for v in got),sum(v*v for v in z))
                COUNTS["phase_product_norm_checks"] += 1


class CRTTests(unittest.TestCase):
    def test_triangular_layout_and_inverse(self):
        circuit = CompiledBitCircuit(SwapControl())
        for sources,targets in (((3,),(4,)),((3,5),(4,8)),((5,7),(8,8)),
                                ((3,5,7),(8,8,8)),((7,5,3),(8,8,4))):
            crt = CRTLayout(sources,targets,circuit)
            values = list(range(1,crt.S+1))
            expected = [0]*crt.T
            for k,value in enumerate(values):
                expected[rank([mu*k%s for mu,s in zip(crt.mu,sources)],targets)] = value
            got = crt.forward(values,(crt.S+1).bit_length())
            self.assertEqual(got,expected)
            self.assertEqual(crt.inverse(got,(crt.S+1).bit_length()),values)
            self.assertEqual(crt.ledger["crt_valid_interval_rotations"],2*len(sources))
            COUNTS["triangular_crt_roundtrips"] += 1

    def test_crt_convolution_isomorphism(self):
        crt = CRTLayout((3,5),(4,8),CompiledBitCircuit(SwapControl()))
        f,g = list(range(15)),list(reversed(range(15)))
        padded = [crt.forward(v,8) for v in (f,g)]
        compact = [[(v,0) for c,v in zip(product(range(4),range(8)),a)
                    if c[0]<3 and c[1]<5] for a in padded]
        result = direct_cyclic(*compact,(3,5))
        cursor = iter(z[0] for z in result)
        box = [next(cursor) if i<3 and j<5 else 0 for i,j in product(range(4),range(8))]
        got = crt.inverse(box,16)
        expected = [sum(f[j]*g[(k-j)%15] for j in range(15)) for k in range(15)]
        self.assertEqual(got,expected)
        COUNTS["crt_cyclic_isomorphisms"] += 1


class TransformTests(unittest.TestCase):
    def test_complex_convolution_and_wrap(self):
        rng = random.Random(10056)
        p,scale = 128,1 << 128
        for targets in ((4,),(4,4),(4,8),(4,4,8)):
            engine = CyclicConvolver(targets,p)
            arrays = [[(rng.randrange(-scale//3,scale//3),rng.randrange(-scale//3,scale//3))
                       for _ in range(prod(targets))] for _ in range(2)]
            for f,g in (arrays,([((scale,0) if j==prod(targets)-1 else (0,0))
                                for j in range(prod(targets))],arrays[1])):
                actual = engine.convolve(f,g)
                raw = direct_cyclic(f,g,targets)
                denominator = prod(targets)*scale
                for z,w in zip(actual,raw):
                    self.assertLess(sum((x*denominator-y)**2 for x,y in zip(z,w)),
                                    (engine.error*denominator)**2)
                COUNTS["twisted_cyclic_convolutions"] += 1

    def test_chirp_matches_permuted_fourier(self):
        with localcontext() as ctx:
            ctx.prec = 110
            p,scale = 128,1 << 128
            for sources,targets in (((3,),(4,)),((3,5),(4,8)),((3,3,5),(4,4,8))):
                values = [(scale//(4+j%5),-scale//(9+j%7)) for j in range(prod(targets))]
                engine = CyclicConvolver(targets,p)
                actual = engine.chirp(values,sources)
                expected = direct_fourier([tuple(Decimal(v)/scale for v in z) for z in values],
                                          targets,[-s for s in sources])
                for z,w in zip(actual,expected):
                    self.assertLess(sum((Decimal(v)-x*scale)**2 for v,x in zip(z,w)),
                                    Decimal(engine.chirp_error)**2)
                self.assertEqual(engine.ledger["normalized_complex_convolution_calls"],1)
                COUNTS["production_chirp_fourier_comparisons"] += 1

    def test_source_transform_no_fourier_oracle_backend(self):
        circuit = CompiledBitCircuit(SwapControl())
        with localcontext() as ctx:
            ctx.prec = 110
            for sources,targets,p,alpha in (((3,),(4,),128,5),((3,5),(4,8),192,6)):
                scale = 1 << p
                layer = make_guarded_network_layer(ComplexNetwork(100),p,swap_circuit=circuit)
                movement = make_stream_layout_move(circuit,component_bytes=(p+9)//8)
                engine = SourceTransform(sources,targets,p,alpha,circuit,layer=layer,layout_move=movement)
                values = [(scale//(5+j%5),-scale//(11+j%7)) for j in range(prod(sources))]
                box = engine.gaussian.embed(values)
                for opposite in (False,True):
                    actual = engine.gaussian.extract(engine.apply(box,opposite=opposite))
                    expected = direct_fourier([tuple(Decimal(v)/scale for v in z) for z in values],
                                              sources,targets,opposite)
                    for z,w in zip(actual,expected):
                        self.assertLess(sum((Decimal(v)-x*scale)**2 for v,x in zip(z,w)),
                                        Decimal(engine.error)**2)
                    COUNTS["production_source_transform_comparisons"] += 1
                self.assertEqual(engine.ledger["reference_permutation_records"],0)
                self.assertEqual(engine.ledger["adaptive_layout_codec_calls"],0)
                if len(targets)>1:
                    self.assertGreater(engine.ledger["guarded_layer_calls"],0)
                    self.assertGreater(engine.ledger["stream_layout_calls"],0)


class IntegerReductionTests(unittest.TestCase):
    def test_injected_schoolbook_backend(self):
        from test_synthetic import small_integer_multiply
        calls = []
        def backend(a,b):
            self.assertGreaterEqual(a,0)
            self.assertGreaterEqual(b,0)
            calls.append((a.bit_length(),b.bit_length()))
            return small_integer_multiply(a,b)
        got,diagnostics = multiply_resampled(0xdeadbeef,0x8badf00d,
            sources=(3,5),targets=(4,8),p=192,alpha=6,digit_bits=4,
            circuit=CompiledBitCircuit(SwapControl()),integer_multiply=backend)
        self.assertEqual(got,0xdeadbeef*0x8badf00d)
        ledger = diagnostics["ledger"]
        self.assertEqual(len(calls),ledger["scalar_integer_multiplications"]+ledger["integer_multiplications"])
        self.assertGreater(ledger["integer_multiplications"],0)
        COUNTS["resampled_injected_schoolbook_products"] += 1

    def test_complete_resampled_integer_products(self):
        circuit = CompiledBitCircuit(SwapControl())
        rng = random.Random(17233)
        for bits,p,b,alpha in ((32,192,4,6),(64,192,8,6),(128,256,16,6)):
            layer = make_guarded_network_layer(ComplexNetwork(100),p,swap_circuit=circuit)
            movement = make_stream_layout_move(circuit,component_bytes=(p+9)//8)
            pairs = [(0,(1 << bits)-1),(1,(1 << bits)-1),((1 << bits)-1,(1 << bits)-1),
                     (rng.getrandbits(bits),rng.getrandbits(bits))]
            for x,y in pairs:
                product_value,diagnostics = multiply_resampled(x,y,sources=(3,5),targets=(4,8),
                    p=p,alpha=alpha,digit_bits=b,circuit=circuit,layer=layer,layout_move=movement)
                self.assertEqual(product_value,x*y)
                self.assertEqual(diagnostics["ledger"]["source_forward_calls"],2)
                self.assertEqual(diagnostics["ledger"]["source_opposite_calls"],1)
                self.assertEqual(diagnostics["ledger"]["crt_forward_calls"],2)
                self.assertEqual(diagnostics["ledger"]["crt_inverse_calls"],1)
                self.assertEqual(diagnostics["ledger"].get("reference_permutation_records",0),0)
                self.assertEqual(diagnostics["ledger"].get("adaptive_layout_codec_calls",0),0)
                self.assertFalse(diagnostics["implementation_status"]["sub_n_log_n_proved_for_implementation"])
                COUNTS["resampled_integer_products"] += 1

    def test_invalid_contracts(self):
        circuit = CompiledBitCircuit(SwapControl())
        for action in (lambda: CertifiedPhase().grid(1,0,128),
                       lambda: CertifiedPhase().grid(1,4,1),
                       lambda: CRTLayout((3,3),(4,4),circuit),
                       lambda: CRTLayout((3,5),(4,16),circuit),
                       lambda: CyclicConvolver((8,4),128),
                       lambda: CyclicConvolver((4,4),8),
                       lambda: SourceTransform((3,5),(4,8),128,7,circuit),
                       lambda: CyclicConvolver((4,),128).convolve([(1 << 128,0)]*4,[(1 << 128,0)]*4),
                       lambda: CyclicConvolver((4,),128).chirp([(1 << 128,0)]*4,(3,)),
                       lambda: multiply_resampled(1 << 33,1,sources=(3,5),targets=(4,8),
                           p=192,alpha=6,digit_bits=4,circuit=circuit),
                       lambda: multiply_resampled(1,1,sources=(3,5),targets=(4,8),
                           p=192,alpha=6,digit_bits=16,circuit=circuit)):
            with self.assertRaises(ValueError): action()
            COUNTS["negative_controls"] += 1
        crt = CRTLayout((3,5),(4,8),circuit)
        malformed = [0]*32
        malformed[7] = 1
        with self.assertRaises(ValueError): crt.inverse(malformed,8)
        COUNTS["negative_controls"] += 1


if __name__ == "__main__": unittest.main(verbosity=2)
