"""Rational frame compiler for the actual source's XOR network.

The scalar ring is F2, but the address matrices are over Q with form I-J/9.
In particular, rational subtraction must NOT be replaced by XOR. The negative
X source frame is included; without it, the endpoint shear contract is false.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import combinations, product
from math import comb


@dataclass(frozen=True)
class RationalFrame:
    h: int
    terms: tuple  # (rational coefficient, three tensor factors); None = identity

    @property
    def ambient(self): return self.h**3

    @property
    def trace(self):
        return sum((c*self.h**sum(t is None for t in factors) for c,factors in self.terms),Q(0))

    def entry(self, row, column):
        if not 0 <= row < self.ambient or not 0 <= column < self.ambient: raise ValueError("matrix index")
        a=(row//self.h**2,row//self.h%self.h,row%self.h)
        b=(column//self.h**2,column//self.h%self.h,column%self.h)
        out=Q(0)
        for coefficient,factors in self.terms:
            for x,y,line in zip(a,b,factors):
                # P_t = t (t^T (I-J/9))/2, since t has three ones.
                coefficient *= int(x==y) if line is None else Q(((line>>x)&1)*(3*((line>>y)&1)-1),6)
            out += coefficient
        return out

    def dense(self, maximum_dimension=4096):
        if self.ambient > maximum_dimension: raise ValueError("dense fixed-table compilation limit")
        return [[self.entry(i,j) for j in range(self.ambient)] for i in range(self.ambient)]

    def difference(self, other):
        if self.h != other.h: raise ValueError("different ambient forms")
        return frame(self.h,(*self.terms,*((-c,t) for c,t in other.terms)))

    def apply_mod(self, vector, modulus):
        """Tensor contraction without forming an ambient-square matrix."""
        if len(vector)!=self.ambient: raise ValueError("vector dimension")
        h=self.h
        inv6=pow(6,-1,modulus)
        out=[0]*len(vector)
        for coefficient,factors in self.terms:
            values=list(vector)
            for axis,line in enumerate(factors):
                if line is None: continue
                stride=h**(2-axis)
                projected=[0]*len(vector)
                for base in range(0,len(vector),h*stride):
                    for offset in range(stride):
                        total=sum((3*((line>>j)&1)-1)*values[base+j*stride+offset] for j in range(h))*inv6%modulus
                        for j in range(h):
                            if (line>>j)&1: projected[base+j*stride+offset]=total
                values=projected
            c=coefficient.numerator*pow(coefficient.denominator,-1,modulus)%modulus
            out=[(a+c*b)%modulus for a,b in zip(out,values)]
        return out


def frame(h, terms=()):
    combined={}
    for coefficient,factors in terms:
        factors=tuple(factors)
        if len(factors)!=3: raise ValueError("three tensor factors required")
        if any(t is not None and (t<0 or t.bit_length()>h or t.bit_count()!=3) for t in factors):
            raise ValueError("factor must be a triple indicator")
        combined[factors]=combined.get(factors,Q(0))+Q(coefficient)
    # Canonical key avoids comparing None and int directly.
    ordered=sorted(combined,key=lambda t:tuple(-1 if x is None else x for x in t))
    return RationalFrame(h,tuple((combined[t],t) for t in ordered if combined[t]))


@dataclass(frozen=True)
class BitGate:
    stage: int
    fixed: tuple
    time: int
    frame: object
    roles: tuple
    updates: tuple  # (target, source), bitwise XOR


class BitNetwork:
    """h=100 is the rank-saving network; small h are only test controls."""
    def __init__(self,h=100):
        if h<3 or h==9: raise ValueError("require h>=3, h!=9")
        self.h,self.m,self.v=h,h**3,comb(h,3)
        self.triples=tuple(combinations(range(h),3))
        self.masks=tuple(sum(1<<i for i in triple) for triple in self.triples)
        self._indices={triple:i for i,triple in enumerate(self.triples)}

    @property
    def bank_size(self): return self.v**3
    @property
    def neighbors(self): return 3*comb(self.h-3,2) if self.h>=5 else 0
    @property
    def wires(self): return 2*self.bank_size+3*self.v**2*(self.v*self.neighbors+self.h)
    @property
    def rank_sum(self): return self.wires*self.m-self.bank_size+6*self.v**2*self.h**2

    def neighboring(self,index):
        triple=self.triples[index]
        outside=tuple(i for i in range(self.h) if i not in triple)
        for point in triple:
            for pair in combinations(outside,2): yield self._indices[tuple(sorted((point,*pair)))]

    def data_role(self,bank,stage,fixed,varying):
        coordinates=list(fixed)
        coordinates.insert(stage,varying)
        return (bank,*coordinates)

    def source_frame(self,role):
        return frame(self.h,((-1,tuple(self.masks[t] for t in role[1:])),)) if role[0]=="X" else frame(self.h)

    def sink_frame(self,role):
        terms=[(1,(None,None,None))]
        if role[0]=="Y": terms.append((-1,tuple(self.masks[t] for t in role[1:])))
        return frame(self.h,terms)

    def gate_frame(self,stage,fixed,time,varying=None):
        coords=list(fixed)
        coords.insert(stage,varying)
        full=tuple(None if i<=stage else self.masks[coords[i]] for i in range(3))
        prefix=tuple(None if i==stage else self.masks[coords[i]] for i in range(3))
        if time in (1,4): return frame(self.h,((1,full),(-1,prefix)))
        if time in (3,6,7): return frame(self.h,((1,full),))
        if varying is None: raise ValueError("side gate requires a triple")
        line_full=tuple(self.masks[varying] if i==stage else full[i] for i in range(3))
        line_prefix=tuple(self.masks[varying] if i==stage else prefix[i] for i in range(3))
        if time==0: return frame(self.h,((1,line_full),(-1,line_prefix)))
        if time==2: return frame(self.h,((1,full),(-1,prefix),(1,line_prefix)))
        if time==5: return frame(self.h,((1,full),(-1,line_prefix)))
        raise ValueError("gate time")

    def invocation(self,stage,fixed):
        if stage not in (0,1,2) or len(fixed)!=2 or any(not 0<=i<self.v for i in fixed):
            raise ValueError("invalid invocation")
        actions=(("copy","Y"),("gather","Y"),("side","X"),("scatter","X"),
                 ("gather","Y"),("copy","Y"),("scatter","X"),("side","X")) if stage==1 else (
                 ("side","Y"),("scatter","Y"),("copy","X"),("gather","X"),
                 ("scatter","Y"),("side","Y"),("gather","X"),("copy","X"))
        centers=tuple(("C",stage,fixed,i) for i in range(self.h))
        for time,(operation,bank) in enumerate(actions):
            if operation in ("copy","side"):
                for i in range(self.v):
                    role=self.data_role(bank,stage,fixed,i)
                    sides,updates=[],[]
                    for neighbor in self.neighboring(i):
                        ys,xt=(i,neighbor) if bank=="Y" else (neighbor,i)
                        side=("A",stage,fixed,ys,xt)
                        sides.append(side)
                        updates.append((side,role) if operation=="copy" else (role,side))
                    yield BitGate(stage,fixed,time,self.gate_frame(stage,fixed,time,i),(role,*sides),tuple(updates))
            else:
                data=tuple(self.data_role(bank,stage,fixed,i) for i in range(self.v))
                updates=[]
                for i,role in enumerate(data):
                    for coordinate in self.triples[i]:
                        updates.append((centers[coordinate],role) if operation=="gather" else (role,centers[coordinate]))
                yield BitGate(stage,fixed,time,self.gate_frame(stage,fixed,time),(*data,*centers),tuple(updates))

    def gates(self):
        for stage in range(3):
            for fixed in product(range(self.v),repeat=2): yield from self.invocation(stage,fixed)

    def roles(self):
        for bank in ("X","Y"):
            for coords in product(range(self.v),repeat=3): yield (bank,*coords)
        for stage in range(3):
            for fixed in product(range(self.v),repeat=2):
                for ys in range(self.v):
                    for xt in self.neighboring(ys): yield ("A",stage,fixed,ys,xt)
                for i in range(self.h): yield ("C",stage,fixed,i)

    @staticmethod
    def routed_output(role):
        return (("Y" if role[0]=="X" else "X"),*role[1:]) if role[0] in ("X","Y") else role

    def edge_matrix(self,tail,head): return head.difference(tail).dense(maximum_dimension=self.m)

    def run_sparse(self,initial,d,modulus,maximum_wires=20000):
        """Execute all edges/gates on sparse arrays for one fixed D fiber.

        initial maps roles to {H tuple: bit record}; XOR cancellation is exact.
        This validates the framed circuit but is not the fast movement backend.
        """
        if self.wires>maximum_wires: raise ValueError("sparse verifier wire limit")
        roles=tuple(self.roles())
        if set(initial)!=set(roles): raise ValueError("all roles, including scratch, are required")
        values={role:dict(initial[role]) for role in roles}
        previous={role:self.source_frame(role) for role in roles}
        images={}
        def image(space):
            if space not in images: images[space]=space.apply_mod(d,modulus)
            return images[space]
        def edge(role,head):
            delta=[(b-a)%modulus for a,b in zip(image(previous[role]),image(head))]
            values[role]={tuple((a+b)%modulus for a,b in zip(h,delta)):value for h,value in values[role].items()}
            previous[role]=head
        for gate in self.gates():
            for role in gate.roles: edge(role,gate.frame)
            for target,source in gate.updates:
                for address,value in values[source].items():
                    values[target][address]=values[target].get(address,0)^value
                    if not values[target][address]: del values[target][address]
        for role in roles: edge(role,self.sink_frame(role))
        return {role:values[self.routed_output(role)] for role in roles}
