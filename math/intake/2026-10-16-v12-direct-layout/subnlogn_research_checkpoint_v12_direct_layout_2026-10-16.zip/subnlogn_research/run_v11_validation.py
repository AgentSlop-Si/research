"""Run new independent tests; use run_validation.py for the inherited suite."""
import hashlib,json,platform,time,unittest
from pathlib import Path
import test_packing_v11

root=Path(__file__).resolve().parent
sources=['packed_gaussian_v11.py','parameter_certificate_v11.py','fast_resampled.py','test_packing_v11.py']
before={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sources}
started=time.perf_counter()
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(test_packing_v11))
after={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sources}
report=dict(status='passed' if result.wasSuccessful() and before==after else 'failed',
            test_methods=result.testsRun,counts=dict(test_packing_v11.COUNTS),
            duration_seconds=time.perf_counter()-started,source_sha256=before,
            sources_unchanged=before==after,python=platform.python_version(),
            scope='Exact finite coefficients and native full-reduction controls; no sub-n-log-n proof')
(root/'validation_v11.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
