"""Finite-parameter end-to-end reduction benchmarks, not asymptotic evidence."""
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import gc
import hashlib
import json
import platform
import random
import sys

SOURCES = ("benchmark_resampled.py","multiply_resampled.py","resampled_transform.py",
           "certified_phase.py","certified_exp.py","crt_layout.py","gaussian_resampling.py",
           "gaussian_tensor.py","guarded_layer.py","packed_stream.py","packed_bits.py",
           "stream_moves.py","swap_recursion.py","bit_frames.py","motifs.py","synthetic.py",
           "network_frames.py","recursive_edges.py","recursive_network.py","phase_layers.py",
           "test_stream_swap.py")


def main():
    root = Path(__file__).resolve().parent
    def hashes(): return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in SOURCES}
    before = hashes()
    from guarded_layer import make_guarded_network_layer
    from multiply_resampled import multiply_resampled
    from network_frames import ComplexNetwork
    from packed_stream import make_stream_layout_move
    from swap_recursion import CompiledBitCircuit
    from test_stream_swap import SwapControl
    report = dict(python=sys.version,platform=platform.platform(),
        scope="Complete numerical reduction with explicit finite parameters; not the full asymptotically fast multiplier",
        method="Two full-width pairs per size, three repetitions each; cold circuit/guard setup, interval caches, CRT, transforms, rounding and carries inside each timer; correctness outside",
        network_scope="Actual h100 phase descriptor, small-width kernel branch only; complete swap operations use a separate no-saving circuit",
        sizes=[])
    rng = random.Random(55071)
    was_enabled = gc.isenabled()
    gc.disable()
    try:
        for bits,p,digit_bits in ((32,192,4),(64,192,8),(128,256,16)):
            pairs = [(rng.getrandbits(bits) | (1 << (bits-1)),
                      rng.getrandbits(bits) | (1 << (bits-1))) for _ in range(2)]
            jobs = [pair for pair in pairs for _ in range(3)]
            rng.shuffle(jobs)
            samples,native_samples = [],[]
            for x,y in jobs:
                started = perf_counter_ns()
                circuit = CompiledBitCircuit(SwapControl())
                layer = make_guarded_network_layer(ComplexNetwork(100),p,swap_circuit=circuit)
                movement = make_stream_layout_move(circuit,component_bytes=(p+9)//8)
                value,diagnostics = multiply_resampled(x,y,sources=(3,5),targets=(4,8),p=p,
                    alpha=6,digit_bits=digit_bits,circuit=circuit,layer=layer,layout_move=movement)
                samples.append(perf_counter_ns()-started)
                started = perf_counter_ns()
                expected = x*y
                native_samples.append(perf_counter_ns()-started)
                if value!=expected: raise AssertionError("resampled product differs from exact integer product")
                if diagnostics["ledger"].get("reference_permutation_records",0):
                    raise AssertionError("unexpected reference permutation")
                if diagnostics["ledger"].get("adaptive_layout_codec_calls",0):
                    raise AssertionError("unexpected adaptive layout codec")
            report["sizes"].append(dict(input_bits=bits,samples_ns=samples,median_ns=median(samples),
                native_samples_ns=native_samples,native_median_ns=median(native_samples),
                checked_products=len(jobs),diagnostics=diagnostics))
            print(json.dumps({"bits":bits,"median_ms":median(samples)/1e6,
                              "checked_products":len(jobs)}),flush=True)
    finally:
        if was_enabled: gc.enable()
    if hashes()!=before: raise RuntimeError("sources changed during benchmark")
    report.update(source_sha256=before,sources_unchanged_during_benchmark=True,checked_outputs=18)
    (root/"resampled_benchmarks.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")


if __name__ == "__main__": main()
