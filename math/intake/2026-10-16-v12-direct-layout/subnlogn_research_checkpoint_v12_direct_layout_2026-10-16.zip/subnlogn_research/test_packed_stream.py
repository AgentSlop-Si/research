"""Compositional checks for packed streaming and the numerical interface.

A complete f>=2, K>=6 rectangle has at least 2^36 records and is not allocated.
Its rotation primitive is tested on full smaller rectangles; the real guarded
repair is tested on closed orbits. These scopes are explicitly distinguished.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import permutations, product
from math import prod
import random
import unittest
from network_frames import Gate
from packed_bits import PackedBits
from packed_stream import (Rectangle, GaussianRecordCodec, make_packed_basis_move,
                           packed_selected_add, repair_indexed_stream, rotate_named_chunk,
                           xor_address_bits, xor_bit_pair, _execute_packed_selected_add, make_stream_layout_move)
from phase_layers import explicit_c_numerators
from recursive_edges import explicit_basis_move
from recursive_network import make_network_layer, recursive_c_numerators
from synthetic import Layout, normalized_convolution, multiply_reference, permute_slots
from swap_recursion import CompiledBitCircuit
from test_recursive_network import PaddedControlNetwork, CoordinateSpace
from test_stream_swap import SwapControl, scatter

COUNTS=Counter()


class RotatedControlNetwork(PaddedControlNetwork):
    """m=4, W=3 NO-saving control with non-coordinate orthonormal residuals."""
    basis=(0b0111,0b1011,0b1101,0b1110)
    def gates(self):
        for time,(mask,update) in enumerate(zip((1,3,15),(("Y","X",Q(1)),("X","Y",Q(-1)),("Y","X",Q(1))))):
            yield Gate(0,(),time,CoordinateSpace(mask),("X","Y"),(update,))
    def edge_factors(self,role,tail,head,gate):
        for i,direction in enumerate(self.basis):
            if ((tail.mask^head.mask)>>i)&1:
                yield direction,bool((tail.mask>>i)&1) ^ (direction.bit_count()%4==3)


class TinyAllExceptionalControl:
    """Deliberately NOT PackedBits: a small composition control with no good set.

    This exercises all eight rotations, nontrivial repair and the top-bit map
    on a complete rectangle. It has no sparse-exception or fast-time claim.
    """
    k,fields,offset,width,selected=1,3,0,3,3
    @staticmethod
    def bad(address): return True
    @staticmethod
    def rotations(address,inverse=False):
        x,y,z=address
        schedule=(("y",0,-1),("z",0,-1),("y",0,1),("z",0,1),
                  ("z",1,1),("y",1,1),("z",1,-1),("y",1,-1))
        if inverse: schedule=tuple((target,parity,-sign) for target,parity,sign in reversed(schedule))
        for target,parity,sign in schedule:
            other=z if target=="y" else y
            amount=sum(1<<j for j in range(2) if (x>>j)&1 and ((other>>j)&1)==parity)
            if target=="y": y=(y+sign*amount)%8
            else: z=(z+sign*amount)%8
        return x,y,z
    def repair_destination(self,address):
        x,y,z=self.rotations(address,True)
        return x,y^(x&3),z


class TwoRoleRotatedControl(RotatedControlNetwork):
    wires=2
    @property
    def rank_sum(self): return 8
    def roles(self): return iter(("X","Y"))


def logical_to_rank(rect,logical,spectators=(0,0,0,0)):
    coords=[spectators[0]]
    for i,name in enumerate(rect.names): coords.extend((logical["xyz".index(name)],spectators[i+1]))
    rank=0
    for n,x in zip(rect.shape,coords): rank=rank*n+x
    return rank


class PackedStreamTests(unittest.TestCase):
    def test_two_bit_maps_and_nonbinary_spectators(self):
        for control_first in (False,True):
            shape=(3,2,5,2,2)
            data=list(range(prod(shape)))
            def mapping(x):
                out=list(x)
                if control_first: out[3]^=out[1]
                else: out[1]^=out[3]
                return out
            got=xor_bit_pair(data,3,5,2,control_first,Counter(),8)
            self.assertEqual(got,scatter(data,shape,mapping))
            COUNTS["sequential_bit_pair_maps"]+=1
        for source,target in ((0,3),(3,0),(1,4),(4,1)):
            data=list(range(3*32))
            expected=[None]*len(data)
            for address,value in enumerate(data): expected[address^(((address>>source)&1)<<target)]=value
            self.assertEqual(xor_address_bits(data,source,target,Counter(),8),expected)
            COUNTS["sequential_bit_pair_maps"]+=1

    def test_all_chunk_orders_controlled_rotations(self):
        circuit=CompiledBitCircuit(SwapControl())
        for names in permutations(("x","y","z")):
            rect=Rectangle(2,(2,2,1,2),names)
            values=list(range(rect.volume))
            for target,parity,sign in product(("y","z"),(0,1),(-1,1)):
                ledger=Counter()
                got=rotate_named_chunk(values,rect,target,3,parity,sign,circuit,ledger,12)
                def mapping(x):
                    out=list(x)
                    positions={name:1+2*i for i,name in enumerate(names)}
                    other="z" if target=="y" else "y"
                    control=x[positions[other]]
                    offset=x[positions["x"]] & (control if parity else ~control) & 3
                    out[positions[target]]=(out[positions[target]]+sign*offset)%4
                    return out
                self.assertEqual(got,scatter(values,rect.shape,mapping))
                self.assertEqual(ledger["packed_rotation_chunk_swaps"],0 if names[-1]==target else 2)
                self.assertEqual(ledger["packed_whole_chunk_rotations"],1)
                COUNTS["packed_stream_controlled_rotations"]+=1

    def test_rotation_with_recursive_chunk_swaps(self):
        circuit=CompiledBitCircuit(SwapControl())
        rect=Rectangle(5)
        values=list(range(rect.volume))
        ledger=Counter()
        got=rotate_named_chunk(values,rect,"y",0b10101,0,-1,circuit,ledger,16)
        def mapping(x):
            y=(x[3]-(x[1]&~x[5]&0b10101))%32
            return (x[0],x[1],x[2],y,x[4],x[5],x[6])
        self.assertEqual(got,scatter(values,rect.shape,mapping))
        self.assertGreater(ledger["swap_internal_nodes"],0)
        self.assertGreater(ledger["matrix_shear_child_calls"],0)
        COUNTS["recursive_chunk_rotation_integrations"]+=1

    def test_actual_K6_single_field_complete_rectangles(self):
        circuit=CompiledBitCircuit(SwapControl())
        for names,offset in ((('x','y','z'),0),(('y','z','x'),3),(('z','x','y'),5)):
            rect=Rectangle(6,names=names)
            spec=PackedBits(6,1,offset)
            values=list(range(rect.volume))
            ledger=Counter()
            got=packed_selected_add(values,rect,spec,circuit,ledger,18)
            def mapping(x):
                out=list(x)
                xp,yp=1+2*names.index("x"),1+2*names.index("y")
                out[yp]^=x[xp]&(1<<offset)
                return out
            self.assertEqual(got,scatter(values,rect.shape,mapping))
            self.assertEqual(ledger["packed_whole_chunk_rotations"],0)
            self.assertEqual(ledger["exceptional_records_sorted"],0)
            COUNTS["full_K6_single_field_rectangles"]+=1

    def test_real_guarded_repair_in_all_mixed_radix_orders(self):
        spec=PackedBits(6,3)
        addresses=set()
        for seed in ((65,0,0),(65,22,25)):
            address=seed
            for _ in range(20000):
                if address in addresses: break
                addresses.add(address)
                address=spec.repair_destination(address)
            else: self.fail("repair orbit did not close")
        good=(65,(20<<1)+(20<<7),(21<<1)+(21<<7))
        self.assertFalse(spec.bad(good))
        addresses.add(good)
        for names in permutations(("x","y","z")):
            rect=Rectangle(spec.width,(2,3,2,3),names)
            spectators=(1,2,1,2)
            ranked=sorted((logical_to_rank(rect,a,spectators),i+1) for i,a in enumerate(sorted(addresses)))
            by_rank=dict(ranked)
            expected={}
            for a in sorted(addresses):
                source=logical_to_rank(rect,a,spectators)
                restored=spec.rotations(a,inverse=True) if spec.bad(a) else a
                dest=spec.ideal(restored,include_top=False) if spec.bad(a) else a
                expected[logical_to_rank(rect,dest,spectators)]=by_rank[source]
            ledger=Counter()
            out=repair_indexed_stream(lambda:iter(ranked),rect,spec,ledger,16)
            self.assertEqual(out,[v for _,v in sorted(expected.items())])
            self.assertLess(ledger["exceptional_records_sorted"],len(ranked))
            self.assertGreater(ledger["exceptional_records_sorted"],0)
            self.assertEqual(ledger["exceptional_radix_passes"],(rect.volume-1).bit_length())
            COUNTS["mixed_radix_repair_orbits"]+=1

    def test_entire_pipeline_on_distinct_all_exceptional_control(self):
        spec=TinyAllExceptionalControl()
        self.assertTrue(any(spec.repair_destination(a)!=a for a in product(range(8),repeat=3)))
        circuit=CompiledBitCircuit(SwapControl())
        for names in permutations(("x","y","z")):
            rect=Rectangle(3,(1,2,1,2),names)
            values=list(range(rect.volume))
            ledger=Counter()
            got=_execute_packed_selected_add(values,rect,spec,circuit,ledger,12)
            def mapping(x):
                out=list(x)
                xp,yp=1+2*names.index("x"),1+2*names.index("y")
                out[yp]^=out[xp]
                return out
            self.assertEqual(got,scatter(values,rect.shape,mapping))
            self.assertEqual(ledger["packed_whole_chunk_rotations"],8)
            self.assertEqual(ledger["exceptional_records_sorted"],rect.volume)
            self.assertEqual(ledger["elementary_selected_bit_additions"],1)
            # The production entry point must never accept the tiny control.
            with self.assertRaises(ValueError): packed_selected_add(values,rect,spec,circuit,Counter(),12)
            COUNTS["all_exceptional_pipeline_controls"]+=1
            COUNTS["negative_controls"]+=1

    def test_codec_exact_signed_roundtrip(self):
        records=[[(-1,0),(127,-128),(128,-129)],
                 [(1<<137,-(1<<149)),(3,-5),(-(1<<140)-1,(1<<140)+1)]]
        codec=GaussianRecordCodec.choose(records)
        ledger=Counter()
        encoded=codec.encode(records,ledger)
        self.assertEqual(codec.decode(encoded,ledger),records)
        self.assertTrue(all(0<=x<1<<codec.width for x in encoded))
        self.assertEqual(ledger["gaussian_record_encode_bits"],len(records)*codec.width)
        self.assertEqual(ledger["gaussian_record_decode_bits"],len(records)*codec.width)
        COUNTS["signed_gaussian_record_roundtrips"]+=len(records)

    def test_basis_backend_with_gaussian_records(self):
        circuit=CompiledBitCircuit(SwapControl())
        mover=make_packed_basis_move(circuit)
        rng=random.Random(771192)
        for slots,size in ((((11,8,5),(10,7,4),(9,6,3)),1<<12),
                           (((7,6),(5,4),(3,2),(1,0)),5*256)):
            records=[[(rng.randrange(-1000,1001),rng.randrange(-1000,1001))] for _ in range(size)]
            operations=((1,0),(0,2),(2,1),(0,1))
            ledger=Counter()
            got=mover(records,slots,operations,ledger)
            self.assertEqual(got,explicit_basis_move(records,slots,operations,Counter()))
            self.assertGreater(ledger["small_k_sequential_row_additions"],0)
            self.assertEqual(ledger["explicit_basis_record_moves"],0)
            COUNTS["gaussian_stream_basis_changes"]+=1

    def test_packed_gaussian_basis_backend(self):
        circuit=CompiledBitCircuit(SwapControl())
        mover=make_packed_basis_move(circuit)
        slots=((12,),(6,),(0,))
        records=[[(i%131-65,37-i%73)] for i in range(1<<18)]
        operations=((1,0),)
        ledger=Counter()
        got=mover(records,slots,operations,ledger)
        self.assertEqual(got,explicit_basis_move(records,slots,operations,Counter()))
        self.assertEqual(ledger["packed_selected_row_additions"],1)
        self.assertEqual(ledger["small_k_sequential_row_additions"],0)
        COUNTS["packed_gaussian_basis_changes"]+=1

    def test_noncoordinate_recursion_and_synthetic_integration(self):
        mover=make_packed_basis_move(CompiledBitCircuit(SwapControl()))
        net=RotatedControlNetwork()
        rng=random.Random(553812)
        records=[[(rng.randrange(-16,17),rng.randrange(-16,17))] for _ in range(2*3*256)]
        bits=tuple(reversed(range(8)))
        ledger=Counter()
        got=recursive_c_numerators(records,bits,ledger,network=net,rows=3,suffix_records=256,
                                    prefixes=2,basis_move=mover)
        self.assertEqual(got,explicit_c_numerators(records,bits,Counter()))
        self.assertGreater(ledger["stream_basis_change_calls"],0)
        self.assertEqual(ledger["explicit_basis_record_moves"],0)
        COUNTS["noncoordinate_stream_phase_networks"]+=1
        layout=Layout((2,)*8,2)
        operands=[[[(rng.randrange(-30,31),rng.randrange(-30,31)) for _ in range(2)]
                    for _ in range(layout.size)] for _ in range(2)]
        expected=normalized_convolution(*operands,layout,12)
        ledger=Counter()
        got=normalized_convolution(*operands,layout,12,layer=make_network_layer(net,basis_move=mover),ledger=ledger)
        self.assertEqual(got,expected)
        self.assertEqual(ledger["integrated_network_layer_calls"],3)
        self.assertGreater(ledger["stream_basis_change_calls"],0)
        self.assertEqual(ledger["explicit_basis_record_moves"],0)
        COUNTS["stream_movement_synthetic_convolutions"]+=1

    def test_streamed_layout_schedules_and_inverse(self):
        move=make_stream_layout_move(CompiledBitCircuit(SwapControl()))
        rng=random.Random(82411)
        for axes,r,k in (((2,4,2),4,1),((8,4),8,1),((16,8),16,2),((32,16),32,3),((64,32),64,2)):
            layout=Layout(axes,r,k)
            records=[[(rng.randrange(-500,501),rng.randrange(-500,501))] for _ in range(layout.size)]
            slots,_=layout.schedule()
            expected=permute_slots(records,layout.original_slots,slots,Counter())
            ledger=Counter()
            forward=move(records,layout,False,ledger)
            self.assertEqual(forward,expected)
            self.assertEqual(move(forward,layout,True,ledger),records)
            self.assertEqual(ledger["reference_permutation_records"],0)
            COUNTS["streamed_layout_roundtrips"]+=1

    def test_whole_stream_stack_convolution_and_integer_adapter(self):
        circuit=CompiledBitCircuit(SwapControl())
        basis_move=make_packed_basis_move(circuit)
        layout_move=make_stream_layout_move(circuit)
        layer=make_network_layer(TwoRoleRotatedControl(),basis_move=basis_move)
        rng=random.Random(482334)
        layout=Layout((4,)*6,4)
        operands=[[[(rng.randrange(-15,16),rng.randrange(-15,16)) for _ in range(4)]
                    for _ in range(layout.size)] for _ in range(2)]
        expected=normalized_convolution(*operands,layout,10)
        ledger=Counter()
        got=normalized_convolution(*operands,layout,10,layer=layer,layout_move=layout_move,ledger=ledger)
        self.assertEqual(got,expected)
        self.assertGreater(ledger["stream_basis_change_calls"],0)
        self.assertGreater(ledger["stream_layout_bit_moves"]+ledger["stream_layout_chunk_swaps"],0)
        self.assertEqual(ledger["stream_layout_calls"],3)
        self.assertEqual(ledger["reference_permutation_records"],0)
        self.assertEqual(ledger["explicit_basis_record_moves"],0)
        COUNTS["complete_stream_backend_convolutions"]+=1
        for n in (1,63,257,1024):
            x,y=rng.getrandbits(n),rng.getrandbits(n)
            product_value,details=multiply_reference(x,y,layer=layer,layout_move=layout_move)
            self.assertEqual(product_value,x*y)
            self.assertEqual(details["ledger"].get("reference_permutation_records",0),0)
            self.assertFalse(details["implementation_status"]["sub_n_log_n_proved_for_implementation"])
            # This adapter has only one record axis; do not pretend it tests
            # the large-D recursive branch of the final multiplication theorem.
            self.assertEqual(details["ledger"].get("network_internal_nodes",0),0)
            COUNTS["integer_stream_backend_integrations"]+=1

    def test_invalid_packed_contracts(self):
        circuit=CompiledBitCircuit(SwapControl())
        with self.assertRaises(ValueError): Rectangle(2,names=("x","x","z"))
        with self.assertRaises(ValueError): packed_selected_add([0]*64,Rectangle(2),PackedBits(6,1),circuit,Counter())
        with self.assertRaises(ValueError): xor_address_bits([0]*15,0,3,Counter(),1)
        with self.assertRaises(ValueError): GaussianRecordCodec.choose([[(0,0)],[(0,0),(0,0)]])
        with self.assertRaises(ValueError): make_packed_basis_move(circuit)([[(0,0)]]*16,((0,),(0,)),((1,0),),Counter())
        spec=PackedBits(6,3)
        rect=Rectangle(spec.width)
        rank=logical_to_rank(rect,(65,0,0))
        with self.assertRaises(ValueError): repair_indexed_stream(lambda:iter(((rank,1),)),rect,spec,Counter(),1)
        COUNTS["negative_controls"]+=6


if __name__=="__main__": unittest.main()
