"""Constructive binary labels and gate/edge compiler for the complex network.

The complete h=100 network is generated lazily; its fixed size is enormous.
Small h networks exercise the same gate/label rules but do not have a rank
saving. Spectral execution is a verification backend, not the desired fast
address-domain recursive execution.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import combinations, product
from math import comb
from functools import lru_cache
from motifs import Gaussian, I_POWERS


def dot(a, b): return (a & b).bit_count() & 1


def independent_basis(vectors):
    pivots, out = {}, []
    for vector in vectors:
        reduced = vector
        while reduced:
            bit = reduced.bit_length()-1
            if bit not in pivots:
                pivots[bit] = reduced
                out.append(vector)
                break
            reduced ^= pivots[bit]
    return out


def orthonormal_basis(vectors):
    """Construct a binary orthonormal basis, absorbing alternating planes.

    A purely alternating or degenerate space is rejected. The preprint proves
    the actual nonzero residuals are nondegenerate and nonalternating for h=100.
    """
    remaining = independent_basis(vectors)
    units = []
    while remaining:
        index = next((i for i, v in enumerate(remaining) if dot(v, v)), None)
        if index is None: break
        unit = remaining.pop(index)
        units.append(unit)
        remaining = [v ^ (unit if dot(v, unit) else 0) for v in remaining]
    if remaining and not units:
        raise ValueError("purely alternating space has no orthonormal basis")
    while remaining:
        a = remaining.pop(0)
        index = next((i for i, v in enumerate(remaining) if dot(a, v)), None)
        if index is None: raise ValueError("degenerate residual")
        b = remaining.pop(index)
        remaining = [v ^ (a if dot(v, b) else 0) ^ (b if dot(v, a) else 0) for v in remaining]
        w = units.pop()
        units.extend((w ^ a, w ^ b, w ^ a ^ b))
    if any(dot(u, v) != int(i == j) for i, u in enumerate(units) for j, v in enumerate(units)):
        raise ValueError("residual was not nondegenerate symmetric")
    return tuple(units)


def complete_basis(vectors, dimension):
    if dimension < 1 or any(v <= 0 or v.bit_length() > dimension for v in vectors):
        raise ValueError("basis outside ambient space")
    result = independent_basis(vectors)
    if len(result) != len(vectors): raise ValueError("dependent prescribed columns")
    return tuple(independent_basis(result+[1 << i for i in range(dimension)]))


def matrix_vector(columns, vector):
    if vector < 0 or vector.bit_length() > len(columns): raise ValueError("vector outside matrix domain")
    out = 0
    while vector:
        low = vector & -vector
        out ^= columns[low.bit_length()-1]
        vector ^= low
    return out


def basis_row_operations(columns):
    """Return elementary row-addition schedules for M and M^-1.

    Columns encode M; each pair (target, source) means row[target] ^= row[source].
    A swap uses three row additions. No floating point or pivot oracle is used.
    """
    m = len(columns)
    if any(c < 0 or c.bit_length() > m for c in columns): raise ValueError("matrix shape")
    rows = [sum(((c >> i) & 1) << j for j, c in enumerate(columns)) for i in range(m)]
    inverse = []

    def add(target, source):
        rows[target] ^= rows[source]
        inverse.append((target, source))

    for col in range(m):
        pivot = next((i for i in range(col, m) if (rows[i] >> col) & 1), None)
        if pivot is None: raise ValueError("singular basis matrix")
        if pivot != col:
            add(col, pivot)
            add(pivot, col)
            add(col, pivot)
        for row in range(m):
            if row != col and (rows[row] >> col) & 1: add(row, col)
    if rows != [1 << i for i in range(m)]: raise AssertionError("elimination failed")
    return tuple(reversed(inverse)), tuple(inverse)


def apply_row_operations(vector, operations):
    for target, source in operations:
        vector ^= ((vector >> source) & 1) << target
    return vector


@dataclass(frozen=True)
class TensorDirection:
    """Compact orthonormal direction; at most three h-bit factors are stored."""
    h: int
    factors: tuple

    @property
    def weight(self):
        result=1
        for factor in self.factors: result*=factor.bit_count()
        return result

    def dot(self, other):
        if self.h!=other.h or len(self.factors)!=len(other.factors): raise ValueError("tensor shapes differ")
        return int(all(dot(a,b) for a,b in zip(self.factors,other.factors)))

    def materialize(self):
        value=1
        for factor in self.factors:
            out=0
            while value:
                low=value&-value
                out |= factor << ((low.bit_length()-1)*self.h)
                value ^= low
            value=out
        return value


@lru_cache(maxsize=1024)
def orthogonal_line_complement(h, lines):
    """A small h-dimensional basis, not an h**3-dimensional matrix."""
    if any(v<=0 or v.bit_length()>h or not dot(v,v) for v in lines): raise ValueError("norm-one lines required")
    if any(dot(a,b) for i,a in enumerate(lines) for b in lines[:i]): raise ValueError("lines are not orthogonal")
    vectors=[]
    for i in range(h):
        v=1<<i
        for line in lines:
            if (line>>i)&1: v ^= line
        vectors.append(v)
    basis=orthonormal_basis(vectors)
    if len(basis)!=h-len(lines): raise AssertionError("complement dimension")
    return basis


def full_tensor_factors(h, count):
    yield from product(tuple(1<<i for i in range(h)),repeat=count)


def complement_tensor_factors(h, lines):
    """Orthogonal complement of a tensor of norm-one lines, as pure tensors.

    Decompose at the first factor orthogonal to its prescribed line. Later
    factors range over the full standard basis. Different branches are orthogonal.
    """
    for split,line in enumerate(lines):
        for perpendicular in orthogonal_line_complement(h,(line,)):
            for rest in full_tensor_factors(h,len(lines)-split-1):
                yield (*lines[:split],perpendicular,*rest)


@dataclass(frozen=True)
class Label:
    """XOR sum of tensor projectors: None is identity; int is a norm-one line.

    A factor mask has h coordinates. The three tensor axes use index
    (i*h+j)*h+k, so the final factor occupies the contiguous coefficient bits.
    dimension is checked against actual projected columns when a residual basis
    is materialized; it is not inferred from trace in characteristic two.
    """
    h: int
    terms: frozenset
    dimension: int

    def __post_init__(self):
        if self.h < 1 or not 0 <= self.dimension <= self.h**3: raise ValueError("invalid label dimension")
        for term in self.terms:
            if len(term) != 3: raise ValueError("three tensor factors required")
            if any(v is not None and (v <= 0 or v.bit_length() > self.h or not dot(v,v)) for v in term):
                raise ValueError("line projector requires a norm-one vector")

    @property
    def ambient(self): return self.h**3

    def project(self, vector):
        if vector < 0 or vector.bit_length() > self.ambient: raise ValueError("ambient vector too large")
        result = 0
        for term in self.terms:
            value = vector
            for axis, mask in enumerate(term):
                if mask is None: continue
                stride = self.h**(2-axis)
                indices = [i for i in range(self.h) if (mask >> i) & 1]
                projected = 0
                for outer in range(self.h**axis):
                    start = outer*self.h*stride
                    for inner in range(stride):
                        fiber = sum(1 << (start+i*stride+inner) for i in indices)
                        if dot(value, fiber): projected ^= fiber
                value = projected
            result ^= value
        return result

    def phase(self, frequency): return self.project(frequency).bit_count() % 4

    def residual(self, other):
        if self.h != other.h: raise ValueError("ambient spaces differ")
        # Valid for comparable nondegenerate spaces; callers/tests must check
        # comparability. XOR of the nested projectors is their residual.
        return Label(self.h, self.terms ^ other.terms, abs(self.dimension-other.dimension))

    def basis(self, *, max_dimension=4096):
        if self.ambient > max_dimension:
            raise ValueError("explicit basis exceeds max_dimension; raise explicitly for fixed-network compilation")
        candidates = [self.project(1 << i) for i in range(self.ambient)]
        basis = orthonormal_basis(candidates)
        if len(basis) != self.dimension: raise ValueError("claimed dimension does not match projector rank")
        if any(self.project(v) != v for v in basis): raise ValueError("not a projector")
        return basis


def label(h, dimension, *terms):
    unique = set()
    for term in terms:
        term = tuple(term)
        if term in unique: unique.remove(term)
        else: unique.add(term)
    return Label(h, frozenset(unique), dimension)


@dataclass(frozen=True)
class Gate:
    stage: int
    fixed: tuple
    time: int
    label: Label
    roles: tuple
    updates: tuple  # (destination role, source role, exact scalar coefficient)


class ComplexNetwork:
    """Lazy compiler for the actual three-stage network and shared gate frames.

    h=100 gives the source network. h=4 is a small executable structural control
    with NO rank saving. Neither parameter is silently substituted for the other.
    """
    def __init__(self, h=100):
        if h < 4 or h==6:
            raise ValueError("require h=4, h=5, or h>=7; h=6 has alternating two-line residuals")
        self.h, self.m, self.v = h, h**3, comb(h,3)
        self.triples = tuple(combinations(range(h),3))
        self.masks = tuple(sum(1 << i for i in t) for t in self.triples)

    @property
    def bank_size(self): return self.v**3
    @property
    def neighbors(self): return (comb(self.h-3,3) if self.h >= 6 else 0)+3*(self.h-3)
    @property
    def wires(self): return 2*self.bank_size+3*self.v**2*(self.v*self.neighbors+self.h+1)
    @property
    def rank_sum(self):
        return self.wires*self.m-2*self.bank_size+2*3*self.v**2*(self.h+1)*self.h

    def neighboring(self, index):
        """Generate neighbors from combinations, without a v-by-v adjacency table."""
        triple = self.triples[index]
        outside = tuple(i for i in range(self.h) if i not in triple)
        # The reverse index is intentionally not a growing per-input table:
        # this network is a fixed finite construction. Build lazily per instance.
        if not hasattr(self, "_triple_index"):
            self._triple_index = {t:i for i,t in enumerate(self.triples)}
        for t in combinations(outside,3): yield self._triple_index[t]
        for pair in combinations(triple,2):
            for i in outside: yield self._triple_index[tuple(sorted((*pair,i)))]

    def data_role(self, bank, stage, fixed, varying):
        address = list(fixed)
        address.insert(stage,varying)
        return (bank, *address)

    def source_label(self, role):
        if role[0] == "X":
            return label(self.h,1,tuple(self.masks[t] for t in role[1:]))
        return label(self.h,0)

    def sink_label(self, role):
        if role[0] == "Y":
            return label(self.h,self.m-1,(None,None,None),tuple(self.masks[t] for t in role[1:]))
        return label(self.h,self.m,(None,None,None))

    def gate_label(self, stage, fixed, time, varying=None):
        coords = list(fixed)
        coords.insert(stage,varying)
        full = tuple(None if i <= stage else self.masks[coords[i]] for i in range(3))
        prefix = tuple(self.masks[coords[i]] if i != stage else None for i in range(3))
        a = self.h**stage
        if time in (1,4): return label(self.h,(a-1)*self.h,full,prefix)
        if time in (3,6,7): return label(self.h,a*self.h,full)
        if varying is None: raise ValueError("side gate requires varying triple")
        line_full = tuple(self.masks[varying] if i == stage else full[i] for i in range(3))
        line_prefix = tuple(self.masks[varying] if i == stage else prefix[i] for i in range(3))
        if time == 0: return label(self.h,a-1,line_full,line_prefix)
        if time == 2: return label(self.h,(a-1)*self.h+1,full,prefix,line_prefix)
        if time == 5: return label(self.h,a*self.h-1,full,line_prefix)
        raise ValueError("invalid gate time")

    def invocation(self, stage, fixed):
        if stage not in (0,1,2) or len(fixed) != 2 or any(not 0 <= i < self.v for i in fixed):
            raise ValueError("invalid invocation")
        # Logical inverse at stage 1 (the middle tensor factor), but gate frames
        # follow physical X/Y wires in the same order as the other stages.
        if stage == 1:
            actions = (("copy","Y",1),("gather","Y",1),("side","X",-1),("scatter","X",-1),
                       ("gather","Y",-1),("copy","Y",-1),("scatter","X",1),("side","X",1))
        else:
            actions = (("side","Y",-1),("scatter","Y",-1),("copy","X",1),("gather","X",1),
                       ("scatter","Y",1),("side","Y",1),("gather","X",-1),("copy","X",-1))
        centers = tuple(("C",stage,fixed,i) for i in range(self.h+1))
        for time,(operation,bank,sign) in enumerate(actions):
            if operation in ("side","copy"):
                for i in range(self.v):
                    data = self.data_role(bank,stage,fixed,i)
                    side,updates = [],[]
                    for neighbor in self.neighboring(i):
                        ys,xt = (i,neighbor) if bank == "Y" else (neighbor,i)
                        role = ("A",stage,fixed,ys,xt)
                        side.append(role)
                        coefficient = Q(1-(self.masks[i]&self.masks[neighbor]).bit_count(),2)
                        updates.append((role,data,Q(sign)) if operation == "copy" else (data,role,sign*coefficient))
                    yield Gate(stage,fixed,time,self.gate_label(stage,fixed,time,i),(data,*side),tuple(updates))
            else:
                data = tuple(self.data_role(bank,stage,fixed,i) for i in range(self.v))
                updates=[]
                for i,role in enumerate(data):
                    for coordinate in self.triples[i]:
                        updates.append((centers[coordinate],role,Q(sign)) if operation == "gather" else
                                       (role,centers[coordinate],Q(sign,2)))
                    updates.append((centers[-1],role,Q(sign)) if operation == "gather" else
                                   (role,centers[-1],Q(-sign,2)))
                yield Gate(stage,fixed,time,self.gate_label(stage,fixed,time),(*data,*centers),tuple(updates))

    def gates(self):
        for stage in range(3):
            for fixed in product(range(self.v),repeat=2):
                yield from self.invocation(stage,fixed)

    def roles(self):
        """Fixed role order used by cyclic row distribution, including scratch."""
        for bank in ("X","Y"):
            for coordinates in product(range(self.v),repeat=3): yield (bank,*coordinates)
        for stage in range(3):
            for fixed in product(range(self.v),repeat=2):
                for ys in range(self.v):
                    for xt in self.neighboring(ys): yield ("A",stage,fixed,ys,xt)
                for i in range(self.h+1): yield ("C",stage,fixed,i)

    def edge_factors(self, role, tail, head, gate):
        """Actual directional factors for the generic recursive executor."""
        for direction,inverse in self.residual_directions(role,gate):
            yield direction.materialize(),inverse

    def pre_phase(self, role, slots):
        if role[0]!="X": return 0,0
        u=TensorDirection(self.h,tuple(self.masks[t] for t in role[1:])).materialize()
        mask=0
        for i,bits in enumerate(slots):
            if (u>>i)&1:
                for bit in bits: mask |= 1<<bit
        return mask,0

    def post_phase(self, role, slots):
        if role[0]=="Y":
            mask,_=self.pre_phase(("X",*role[1:]),slots)
            return mask,27*len(slots[0])
        # Undo the minus sign on the physical X output once per role.
        return (0,2) if role[0]=="X" else (0,0)

    @staticmethod
    def routed_output(source_role):
        if source_role[0]=="X": return ("Y",*source_role[1:])
        if source_role[0]=="Y": return ("X",*source_role[1:])
        return source_role

    def compiled_edges(self):
        """Yield (role, tail, head, gate) events; gate=None marks sink edges.

        This iterator retains the last label on each visited role. Its finite
        memory may be huge for h=100, so it is currently a verification compiler,
        not the final fixed-table streaming executor.
        """
        previous={}
        for gate in self.gates():
            for role in gate.roles:
                tail=previous.get(role,self.source_label(role))
                yield role,tail,gate.label,gate
                previous[role]=gate.label
        for role,tail in previous.items():
            yield role,tail,self.sink_label(role),None

    def residual_directions(self, role, gate):
        """Yield (compact direction, inverse_C) for one actual network edge.

        Uses the constructive residual decompositions in the source's edge
        table. No ambient dense projector or matrix is constructed. For a
        scratch sink edge, gate=None; data sink edges have zero residual.
        The sum of all yielded lengths is rank_sum, including decreasing edges.
        """
        kind=role[0]
        if gate is None:
            if kind in ("X","Y"): return
            stage,fixed=role[1],role[2]
            time=None
        else:
            stage,fixed,time=gate.stage,gate.fixed,gate.time
        earlier=tuple(self.masks[i] for i in fixed[:stage])
        later=tuple(self.masks[i] for i in fixed[stage:])
        # A block is prefix subspace (full/line/complement), middle basis, and
        # future subspace (line/complement). Each list is orthonormal.
        full=tuple(1<<i for i in range(self.h))
        blocks=[]
        decreasing=False
        if time is None:
            blocks=[("full",full,"complement")]
        elif kind=="X":
            t=self.masks[role[stage+1]]
            if time==2: blocks=[("complement",orthogonal_line_complement(self.h,(t,)),"line")]
            elif time==3: blocks=[("line",orthogonal_line_complement(self.h,(t,)),"line")]
            elif time not in (6,7): raise ValueError("unexpected X edge")
        elif kind=="Y":
            t=self.masks[role[stage+1]]
            if time==1: blocks=[("complement",orthogonal_line_complement(self.h,(t,)),"line")]
            elif time==5: blocks=[("line",orthogonal_line_complement(self.h,(t,)),"line")]
            elif time not in (0,4): raise ValueError("unexpected Y edge")
        elif kind=="C":
            if time==1: blocks=[("complement",full,"line")]
            elif time in (3,4,6): blocks=[("line",full,"line")]
            else: raise ValueError("unexpected central edge")
            decreasing=time==4
        elif kind=="A":
            ty,tx=self.masks[role[3]],self.masks[role[4]]
            if time==0: blocks=[("complement",(ty,),"line")]
            elif time==2:
                blocks=[("complement",orthogonal_line_complement(self.h,(ty,)),"line"),("line",(tx,),"line")]
            elif time==5: blocks=[("line",orthogonal_line_complement(self.h,(tx,ty)),"line")]
            elif time==7: blocks=[("line",(ty,),"line")]
            else: raise ValueError("unexpected side edge")
        else: raise ValueError("unknown role")

        def factors(space,lines):
            if space=="line": yield lines
            elif space=="full": yield from full_tensor_factors(self.h,len(lines))
            else: yield from complement_tensor_factors(self.h,lines)

        for prefix,middle,future in blocks:
            for before in factors(prefix,earlier):
                for center in middle:
                    for after in factors(future,later):
                        direction=TensorDirection(self.h,(*before,center,*after))
                        # The phase sign includes both weight modulo four and
                        # the orientation of the edge, not just its rank.
                        yield direction, decreasing ^ (direction.weight%4==3)

    def run_spectral(self, frequency, initial, *, maximum_wires=100_000):
        """Execute every gate and edge at one Walsh frequency, with exact scalars.

        No endpoint/source correction is hidden here. The raw result should
        equal the signed bank permutation times its endpoint frame ratio.
        Testing this frequency diagonalization does NOT execute the address
        permutations, recursive volume splits or the fast layer algorithm.
        """
        if self.wires > maximum_wires: raise ValueError("spectral execution exceeds maximum_wires")
        if frequency < 0 or frequency.bit_length() > self.m: raise ValueError("frequency outside ambient space")
        values,previous,phases={},{},{}
        rank_count=edge_count=gate_count=0

        def phase(space):
            if space not in phases: phases[space]=space.phase(frequency)
            return phases[space]

        def change(role,head):
            nonlocal rank_count,edge_count
            tail=previous.get(role,self.source_label(role))
            value=values.get(role)
            if value is None: value=Gaussian.coerce(initial(role))
            values[role]=value*I_POWERS[(phase(head)-phase(tail))%4]
            previous[role]=head
            rank_count+=abs(head.dimension-tail.dimension)
            edge_count+=1

        for gate in self.gates():
            for role in gate.roles: change(role,gate.label)
            # All target updates are shears with disjoint control/target sets.
            for target,source,coefficient in gate.updates:
                values[target]+=values[source]*coefficient
            gate_count+=1
        for role in tuple(previous): change(role,self.sink_label(role))
        return values,dict(wires=len(values),edge_ranks=rank_count,edges=edge_count,gates=gate_count,
                           unique_frames=len(phases),backend="spectral verifier, not recursive layer")
