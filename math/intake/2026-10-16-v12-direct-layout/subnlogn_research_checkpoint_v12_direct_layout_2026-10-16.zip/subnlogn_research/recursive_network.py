"""Exact role-stream recursion for a finite phase network.

This implements cyclic row splitting, common frames at gates, one recursive
C call per edge direction, dyadic gate arithmetic, endpoint corrections and
role reassembly. The default address moves are explicit Python permutations;
packed_stream supplies an optional sequential, rank-recursive movement backend.
Neither backend currently has a complete verified fixed-tape bit-cost bound.
The actual h=100 network is accepted but is far beyond runnable finite tests.
Passing toy-network tests is not a verification of its full asymptotic path.
"""
from dataclasses import dataclass
from fractions import Fraction
from math import isqrt
from phase_layers import explicit_c_numerators, rotate_i, phase_layer
from recursive_edges import apply_residual_numerators, explicit_basis_move


@dataclass
class DyadicStream:
    records: list
    fractional_bits: int=0


def add_stream(target, source, coefficient, ledger):
    coefficient=Fraction(coefficient)
    denominator=coefficient.denominator
    if denominator&(denominator-1): raise ValueError("gate coefficient must be dyadic")
    k=denominator.bit_length()-1
    extra=max(target.fractional_bits,source.fractional_bits+k)
    target_shift=extra-target.fractional_bits
    source_shift=extra-source.fractional_bits-k
    numerator=coefficient.numerator
    if len(target.records)!=len(source.records): raise ValueError("unaligned role streams")
    out=[]
    for a,b in zip(target.records,source.records):
        if len(a)!=len(b): raise ValueError("record width mismatch")
        out.append([((ar<<target_shift)+numerator*(br<<source_shift),
                     (ai<<target_shift)+numerator*(bi<<source_shift))
                    for (ar,ai),(br,bi) in zip(a,b)])
    target.records,target.fractional_bits=out,extra
    ledger["network_gate_record_additions"]+=len(out)
    ledger["network_max_fractional_bits"]=max(ledger["network_max_fractional_bits"],extra)


def phase_stream(stream, sign_mask, phase):
    stream.records=[[rotate_i((-a,-b) if (address&sign_mask).bit_count()%2 else (a,b),phase)
                     for a,b in poly] for address,poly in enumerate(stream.records)]


def rescale_exact(stream, desired_bits):
    difference=stream.fractional_bits-desired_bits
    if difference<=0:
        return [[(a<<(-difference),b<<(-difference)) for a,b in poly] for poly in stream.records]
    mask=(1<<difference)-1
    if any((a&mask) or (b&mask) for poly in stream.records for a,b in poly):
        raise ArithmeticError("completed network is not on its required exact grid")
    return [[(a>>difference,b>>difference) for a,b in poly] for poly in stream.records]


def split_roles(records, rows, suffix_records, roles, prefixes, ledger):
    width=len(roles)
    if rows%width or len(records)!=prefixes*rows*suffix_records:
        raise ValueError("role split requires complete rows divisible by W")
    streams={role:[] for role in roles}
    for prefix in range(prefixes):
        for row in range(rows):
            start=(prefix*rows+row)*suffix_records
            streams[roles[row%width]].extend(records[start:start+suffix_records])
    ledger["network_split_record_copies"]+=len(records)
    return {role:DyadicStream(value) for role,value in streams.items()}


def recursive_c_numerators(records, selected_bits, ledger, *, network, rows,
                            suffix_records, prefixes=1, basis_move=explicit_basis_move, leaf_axes=None):
    """Return 2**e C**tensor(e) via the full role-network recursion.

    Selected bits lie in the common complete suffix, below the row field.
    For nonleaf calls e is divisible by m and rows is divisible by W at each
    recursion depth. batched_c_numerators supplies the arbitrary-width row
    preprocessing wrapper. The supplied network is fixed, not input advice.
    """
    selected_bits=tuple(selected_bits)
    e=len(selected_bits)
    if prefixes<1 or rows<1 or suffix_records<1 or suffix_records&(suffix_records-1):
        raise ValueError("invalid row/suffix shape")
    if len(records)!=prefixes*rows*suffix_records: raise ValueError("incomplete Cartesian stream")
    if len(set(selected_bits))!=e or any(b<0 or (1<<b)>=suffix_records for b in selected_bits):
        raise ValueError("selected bits must lie below the row field")
    if network.m<2: raise ValueError("recursion requires m >= 2")
    leaf_axes=network.m if leaf_axes is None else max(network.m,leaf_axes)
    if e<leaf_axes:
        ledger["network_leaf_calls"]+=1
        return explicit_c_numerators(records,selected_bits,ledger)
    if e%network.m: raise ValueError("active width must be divisible by m")
    if rows%network.wires: raise ValueError("insufficient rows for this recursive level")
    f=e//network.m
    slots=tuple(selected_bits[row*f:(row+1)*f] for row in range(network.m))
    roles=tuple(network.roles())
    if len(roles)!=network.wires or len(set(roles))!=len(roles): raise ValueError("incorrect role inventory")
    role_index={role:i for i,role in enumerate(roles)}
    streams=split_roles(records,rows,suffix_records,roles,prefixes,ledger)
    previous={role:network.source_label(role) for role in roles}
    ledger["network_internal_nodes"]+=1
    ledger["network_parent_record_volume_sum"]+=len(records)
    own_child_calls=0
    for role,stream in streams.items(): phase_stream(stream,*network.pre_phase(role,slots))

    def child(values,bits,child_ledger):
        nonlocal own_child_calls
        if len(values)*network.wires!=len(records): raise AssertionError("child stream volume is not V/W")
        own_child_calls+=1
        child_ledger["network_child_record_volume_sum"]+=len(values)
        return recursive_c_numerators(values,bits,child_ledger,network=network,rows=rows//network.wires,
                                      suffix_records=suffix_records,prefixes=prefixes,basis_move=basis_move,
                                      leaf_axes=leaf_axes)

    def change(role,head,gate):
        factors=tuple(network.edge_factors(role,previous[role],head,gate))
        expected_rank=abs(head.dimension-previous[role].dimension)
        if len(factors)!=expected_rank: raise ValueError("edge factor count differs from nested-label rank")
        if factors:
            directions,negative=zip(*factors)
            stream=streams[role]
            stream.records,extra=apply_residual_numerators(stream.records,directions,negative,slots,ledger,
                                                          child=child,basis_move=basis_move)
            stream.fractional_bits+=extra
            ledger["network_max_fractional_bits"]=max(ledger["network_max_fractional_bits"],stream.fractional_bits)
        previous[role]=head

    for gate in network.gates():
        if len(set(gate.roles))!=len(gate.roles): raise ValueError("duplicate gate incidence")
        if {target for target,_,_ in gate.updates}&{source for _,source,_ in gate.updates}:
            raise ValueError("gate updates must be simultaneous shears with disjoint controls")
        for role in gate.roles: change(role,gate.label,gate)
        for target,source,coefficient in gate.updates:
            if target not in gate.roles or source not in gate.roles: raise ValueError("update lacks common gate frame")
            add_stream(streams[target],streams[source],coefficient,ledger)
    for role in roles:
        change(role,network.sink_label(role),None)
        phase_stream(streams[role],*network.post_phase(role,slots))
    if own_child_calls!=network.rank_sum: raise AssertionError("recursive child count disagrees with network rank budget")
    normalized={role:rescale_exact(stream,e) for role,stream in streams.items()}
    out=[]
    child_rows=rows//network.wires
    for prefix in range(prefixes):
        for row in range(rows):
            source=roles[row%network.wires]
            routed=network.routed_output(source)
            if routed not in role_index: raise ValueError("routing outside role inventory")
            start=(prefix*child_rows+row//network.wires)*suffix_records
            out.extend(normalized[routed][start:start+suffix_records])
    ledger["network_merge_record_copies"]+=len(out)
    return out


def ceiling_log(value, base):
    if value<1 or base<2: raise ValueError("invalid integer logarithm")
    result,power=0,1
    while power<value:
        power*=base
        result+=1
    return result


def batched_c_numerators(records, axes, chunk_bits, offset, ledger, *, network,
                          prefixes=1, suffix_records=1, basis_move=explicit_basis_move):
    """Arbitrary-width C layer with row supply, padding and base-m partition.

    Layout is [prefixes] x [2**K]**D x [suffix_records]. The suffix length must
    be a power of two, as in the synthetic-transform application. Selected
    bits share the supplied offset. This wrapper follows the paper's row
    preprocessing and stops each recursion below sqrt(D), but still calls the
    explicit movement backend unless a verified replacement is supplied.
    """
    if axes<1 or chunk_bits<1 or not 0<=offset<chunk_bits or prefixes<1:
        raise ValueError("invalid layer descriptor")
    if suffix_records<1 or suffix_records&(suffix_records-1): raise ValueError("power-of-two suffix required")
    address_records=(1<<(axes*chunk_bits))*suffix_records
    if len(records)!=prefixes*address_records: raise ValueError("incomplete layer Cartesian product")
    suffix_bits=suffix_records.bit_length()-1
    selected=tuple(suffix_bits+offset+(axes-1-i)*chunk_bits for i in range(axes))
    q0=(network.wires-1).bit_length()*ceiling_log(2*axes,network.m)
    if axes<=q0:
        ledger["row_preprocessing_only_layers"]+=1
        return explicit_c_numerators(records,selected,ledger)
    data=explicit_c_numerators(records,selected[:q0],ledger)
    remaining=axes-q0
    rows=1<<(q0*chunk_bits)
    child_suffix=(1<<(remaining*chunk_bits))*suffix_records
    k0=ceiling_log(axes,network.m)
    divisor=network.wires**k0
    padded_rows=((rows+divisor-1)//divisor)*divisor
    if rows<divisor or padded_rows>=2*rows: raise AssertionError("row-supply bound")
    record_width=len(records[0])
    padded=[]
    for prefix in range(prefixes):
        start=prefix*rows*child_suffix
        padded.extend(data[start:start+rows*child_suffix])
        padded.extend([[(0,0)]*record_width for _ in range((padded_rows-rows)*child_suffix)])
    ledger["layer_padding_records"]+=(padded_rows-rows)*prefixes*child_suffix
    ledger["layer_reserved_row_axes"]+=q0
    # Consecutive active pieces in decreasing powers of m. Their selected bits
    # remain below the common row field, and all other bits stay as spectators.
    powers=[]
    power=1
    while power<=remaining:
        powers.append(power)
        power*=network.m
    active=selected[q0:]
    begin=0
    unassigned=remaining
    leaf_axes=isqrt(axes-1)+1
    for power in reversed(powers):
        count,unassigned=divmod(unassigned,power)
        for _ in range(count):
            bits=active[begin:begin+power]
            padded=recursive_c_numerators(padded,bits,ledger,network=network,rows=padded_rows,
                suffix_records=child_suffix,prefixes=prefixes,basis_move=basis_move,leaf_axes=leaf_axes)
            begin+=power
            ledger["layer_base_m_pieces"]+=1
    if begin!=remaining or unassigned: raise AssertionError("incomplete active-axis partition")
    out=[]
    for prefix in range(prefixes):
        start=prefix*padded_rows*child_suffix
        out.extend(padded[start:start+rows*child_suffix])
        padding=padded[start+rows*child_suffix:start+padded_rows*child_suffix]
        if any(a or b for poly in padding for a,b in poly): raise ArithmeticError("padded rows were not restored to zero")
    ledger["layer_unpadded_records"]+=len(out)
    return out


def make_network_layer(network, *, basis_move=explicit_basis_move):
    """Connect the recursive C engine to synthetic.transform's layer interface.

    Common-offset rounds are complete equal-width chunk groups. Prefix rounds
    use consecutive single bits. Irregular selections are rejected. Attainable
    h=100 sizes use the source's small-width branch, not its large-input regime.
    """
    def backend(records,bits,ledger):
        bits=tuple(sorted(bits,reverse=True))
        if not bits: return [list(poly) for poly in records]
        if len(set(bits))!=len(bits): raise ValueError("duplicate selected bits")
        k=bits[0]-bits[1] if len(bits)>1 else 1
        if k<1 or any(a-b!=k for a,b in zip(bits,bits[1:])):
            raise ValueError("selected bits do not form a common-offset chunk group")
        offset=bits[-1]%k
        suffix=1<<(bits[-1]-offset)
        block=(1<<(len(bits)*k))*suffix
        if len(records)%block: raise ValueError("selected chunks exceed complete address shape")
        ledger["integrated_network_layer_calls"]+=1
        return batched_c_numerators(records,len(bits),k,offset,ledger,network=network,
                                   prefixes=len(records)//block,suffix_records=suffix,basis_move=basis_move)

    def layer(records,bits,ledger):
        return phase_layer(records,bits,ledger,c_backend=backend)
    return layer
