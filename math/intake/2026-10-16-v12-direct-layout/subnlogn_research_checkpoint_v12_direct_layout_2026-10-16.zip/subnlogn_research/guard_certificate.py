"""Save exact data-independent guard descriptors; not a full time proof."""
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path
import hashlib
import json
from guarded_layer import GuardPlanner, PublishedGuard
from network_frames import ComplexNetwork
from cost_certificate import improved_parameters, original_parameters
from test_guarded_layer import HalfControlNetwork
from test_packed_stream import TwoRoleRotatedControl, RotatedControlNetwork
from test_recursive_network import SmallControlNetwork


def certificate():
    pub=PublishedGuard.h100()
    if not all(pub.verify_margins(d) for d in (1,100,1000000)): raise AssertionError("published guard margin")
    bands={}
    for name,parameters in (("source",original_parameters()),("conditional_improved",improved_parameters())):
        gap=1-parameters.epsilon*pub.exponent
        if gap<=0: raise AssertionError("guard is not o(p)")
        # C0 < 2^c, q*(1-epsilon*C1)>=c implies C0*p^(epsilon*C1)<p
        # for every p>=2^q. This is ONLY the guard cutoff, with b_d=1.
        c=pub.coefficient.bit_length()
        bound=Fraction(c)/gap
        q=(bound.numerator+bound.denominator-1)//bound.denominator
        if q*gap<c: raise AssertionError("inexact cutoff rounding")
        bands[name]=dict(epsilon=str(parameters.epsilon),exponent_gap=str(gap),
                         sufficient_log2_precision=q,dimension_band="1 <= D <= p^epsilon; upper constant b_d=1",
                         scope="Guard-width cutoff only, NOT a simultaneous algorithm or packed-movement cutoff",
                         byte_aligned_component_bound="storage_bits <= 3*p+10 <= 13*p")
    cases=[]
    for name,network in (("two_role_rotated_control",TwoRoleRotatedControl()),
                         ("three_role_rotated_control",RotatedControlNetwork()),
                         ("half_scalar_control",HalfControlNetwork()),
                         ("decreasing_control",SmallControlNetwork(True)),
                         ("actual_h100",ComplexNetwork(100))):
        planner=GuardPlanner(network)
        for axes in (1,6,8,9):
            item=asdict(planner.certificate(axes))
            cases.append(dict(network=name,has_rank_saving=network.rank_sum<network.wires*network.m,**item))
    return dict(status="Exact guard descriptors; no complete sub-N-log-N multiplication proof",
        published_h100={name:str(value) for name,value in dict(m=pub.m,W=pub.wires,s=pub.rank_sum,E=pub.overhead,
            B=pub.branching,C0=pub.coefficient,C1=pub.exponent).items()},
        guard_cutoffs=bands,finite_cases=cases,
        invariants=["One binary point and one component width per completed layer",
                    "Budget chosen from precision, axes and fixed network before reading payload values",
                    "Every halving exact; all intermediate signed components range-checked",
                    "One final truncation in the synthetic caller; no rounding in recursive children",
                    "Same record width at parent and child; child logical bit volume V/W"],
        remaining=["Full h100 arithmetic execution not run", "Fixed-tape address/descriptor cost audit incomplete",
                   "Final Gaussian resampling integer reduction missing", "Python is not a finite-tape simulator"])


if __name__=="__main__":
    root=Path(__file__).resolve().parent
    result=certificate()
    result["source_sha256"]={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
        ("guarded_layer.py","guard_certificate.py","cost_certificate.py","network_frames.py","motifs.py",
         "test_guarded_layer.py","test_packed_stream.py","test_recursive_network.py")}
    (root/"guard_certificate.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"status":"exact guard certificate saved","cases":len(result["finite_cases"]),
                      "guard_only_log2_precision_cutoffs":{k:v["sufficient_log2_precision"] for k,v in result["guard_cutoffs"].items()}}))
