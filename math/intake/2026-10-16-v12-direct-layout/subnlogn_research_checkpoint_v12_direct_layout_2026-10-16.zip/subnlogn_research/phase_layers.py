"""Exact phase wrappers for replacing synthetic butterflies by C layers.

The wrapper supplies the preprint's H0 = b S C S identity without floating
point or intermediate truncation. The default C tensor backend is explicit,
so this alone does not implement the faster recursive network.
"""


def rotate_i(z, power):
    a, b = z
    power %= 4
    return ((a, b), (-b, a), (-a, -b), (b, -a))[power]


def explicit_c_numerators(records, selected_bits, ledger):
    """Return numerators of C**tensor(D), at D extra fractional bits.

    For each pair, 2C(u,v) = (u+v+i(u-v), u+v-i(u-v)). No division
    or truncation occurs inside this routine.
    """
    out = [list(poly) for poly in records]
    for bit in selected_bits:
        stride = 1 << bit
        for start in range(0, len(out), 2*stride):
            for j in range(stride):
                lower, upper = start+j, start+j+stride
                lo, hi = [], []
                for (a, b), (c, d) in zip(out[lower], out[upper]):
                    total_re, total_im = a+c, b+d
                    diff_re, diff_im = a-c, b-d
                    lo.append((total_re-diff_im, total_im+diff_re))
                    hi.append((total_re+diff_im, total_im-diff_re))
                out[lower], out[upper] = lo, hi
                ledger["phase_scalar_component_additions"] += 8*len(lo)
                ledger["explicit_C_pairs"] += 1
    return out


def phase_layer(records, selected_bits, ledger, *, c_backend=explicit_c_numerators):
    """Drop-in unnormalized Walsh layer for synthetic.transform.

    c_backend must return 2**D times C**tensor(D) on the supplied records.
    It must be exact for arbitrary Gaussian integer numerators. The returned
    layer equals 2**D H0**tensor(D), so the caller truncates once after the
    full layer. No per-axis or intermediate rounding is allowed.
    """
    n = len(records)
    selected_bits = tuple(selected_bits)
    if n < 1 or n & (n-1): raise ValueError("complete binary address range required")
    if len(set(selected_bits)) != len(selected_bits): raise ValueError("duplicate bit")
    if any(bit < 0 or (1 << bit) >= n for bit in selected_bits): raise ValueError("bit outside address")
    if any(len(poly) != len(records[0]) for poly in records): raise ValueError("inconsistent record widths")
    selected_mask = sum(1 << bit for bit in selected_bits)
    d = len(selected_bits)

    def phases(array):
        return [[rotate_i(z, (address & selected_mask).bit_count()) for z in poly]
                for address, poly in enumerate(array)]

    data = c_backend(phases(records), selected_bits, ledger)
    if len(data) != n or any(len(poly) != len(records[0]) for poly in data):
        raise ValueError("C backend returned wrong shape")
    data = phases(data)
    # (1-i)**D = (-2i)**floor(D/2) * (1-i)**(D mod 2).
    # We need (1-i)**D / 2**D times the backend's integer numerators.
    shift, turn = d-d//2, -(d//2)
    mask = (1 << shift)-1
    out = []
    for poly in data:
        target = []
        for z in poly:
            a, b = rotate_i(z, turn)
            if d % 2: a, b = a+b, b-a
            if (a & mask) or (b & mask):
                raise ArithmeticError("C backend lost exactness or normalization")
            target.append((a >> shift, b >> shift))
        out.append(target)
    ledger["phase_layer_calls"] += 1
    ledger["phase_endpoint_records"] += 2*n
    ledger["phase_common_exact_fraction_bits"] = max(ledger["phase_common_exact_fraction_bits"], d)
    return out
