# v12 audit: a shorter tensor-axis schedule

**Date:** 16 October 2026.

## Decision

A concrete structural improvement is established for the checkpoint's layout
schedule. The local schedule uses O(d) instead of O(d^2) axis exchanges. With the
inherited gap-independent chunk-swap cost, the layout cost loses a factor d.
A revised exact parameter certificate gives a larger conditional exponent.
This does not independently certify the whole imported framework or prove the
complete Python implementation sub-N-log-N.

## Precisely what changed

The original source already allowed nonadjacent bit-field swaps. Its tensor
resampling and CRT schedules, like the checkpoint, nevertheless used neighboring
swaps. The new code performs one direct pair exchange for each mirrored CRT axis
pair, and two direct exchanges to expose and restore each nonfinal Gaussian
axis. Actual padding and sequential movement remain charged in the old routines.

The logical arithmetic order within each numerical line and between logical
axes is unchanged. Thus the change preserves exact fixed-point outputs, not
merely approximate values. The independent coordinate-map proof is in
DIRECT_LAYOUT_PROOF_V12.md. The source primitive itself is credited to the
pinned OpenAI preprint, not claimed as a v12 invention.

For V=Theta(N), d=Theta(p^epsilon), ell=Theta(p^(1-epsilon)), p=Theta(log N):

    old layout = O(V p^(tau + epsilon(2-tau)))
    new layout = O(V p^(tau + epsilon(1-tau))).

The fourth cost margin becomes (1-tau)(1-epsilon). Other six assembly margins
and internal layer conditions are retained. Using epsilon=1/40 and the same
h=100 networks gives

    kappa_v11 = 3.205112405573184e-37
    kappa_v12 = 7.375908518826216e-27
    ratio     = 23012948020.171387 approximately.

The ratio describes the exponent saving only. The exact rational certificate
also verifies that the new parameters FAIL the old fourth constraint, so the
gain is tied to the replacement schedule rather than unnoticed parameter tuning.

The necessary asymptotic condition K>=2 still requires approximately
log2(ceil(log2 N)) >= 7.364143366454844e13. This is not a feasible input size or
a practical crossover. There is no claim of linear-time multiplication.

## Fresh validation

All six new test methods passed in separate core, Gaussian, and full groups.
The evidence separates repeated roundtrips from distinct input configurations:

| Evidence | Fresh result |
|---|---:|
| Small-shape axis swaps against independent address oracle | 444 passed |
| Roundtrips for those same pairs | 444 passed |
| Larger-chunk swaps, including toy internal recursion | 5 passed |
| Axis reversals against independent oracle | 60 passed |
| CRT cases against defining modular map | 5 passed |
| CRT roundtrips for those same cases | 5 passed |
| Bit-exact Gaussian tensor comparisons, both directions and varied axis orders | 12 passed |
| Complete finite native products at 1, 2, and 3 axes | 3 passed |
| Exact rational certificate conditions | 17 passed |
| Default-hook regression test methods | 10 passed |
| Checked finite layout timing calls | 50 passed |

The full native group completed in 79.499 seconds. That
is suite runtime, not a multiplication speedup claim. One earlier combined
shell call timed out before the third full control finished; the later full
group ran afresh to completion. The interrupted run is not counted as a pass.
Full v12 recursive-Fermat multiplication was not rerun. The tested finite
circuit is an explicitly no-saving control, not the huge h=100 network.
Earlier v10/v11 counts remain historical and are not added to these counts.

## Finite layout-only measurements

The same complete coordinate reversal was timed using five interleaved trials
per variant for each shape. All payload copying, padding and actual swap calls
were inside the timing; shared small-circuit compilation and the independent
oracle were outside. Diagnostics were disabled while timing and collected in
separate runs. There were no other research computations during these timings.

| Axes | Records | Old axis calls | New axis calls | Median layout speedup |
|---:|---:|---:|---:|---:|
| 4 | 16 | 6 | 2 | 2.68x |
| 6 | 64 | 15 | 3 | 4.71x |
| 8 | 256 | 28 | 4 | 4.65x |
| 10 | 1024 | 45 | 5 | 9.64x |
| 6 | 512 | 15 | 3 | 10.19x |

The final row uses mixed axis lengths (2,4,2,4,2,4); the preceding rows use
all length-two axes. The unequal-width layout also avoids extra bit moves.
These measurements use Python and a small no-saving control circuit. They are
not measurements of a sub-N-log-N algorithm, FFT performance, or the entire
integer multiplication pipeline. No whole-product speedup was measured here.
All raw samples and operation ledgers are in direct_layout_benchmarks_v12.json.

## Changed files and current status

New source modules are direct_axes_v12.py, direct_pipeline_v12.py and
parameter_certificate_v12.py, with tests, runners and benchmark code. Only
multiply_resampled.py and fast_resampled.py have inherited-code edits: optional
factory injection hooks, leaving default behavior unchanged. The ten default
regression methods passed after those edits. Existing v11 packing is retained.

The proved local result plus conditional certificate is worth retaining. The
complete all-size selector, compiled rank-saving circuit contract, numerical
and storage bounds, and full fixed-tape composition remain inherited obligations
rather than newly independently certified facts. No current world-record or
independent arbitrary-complex-DFT claim is made. The new work is a shorter
schedule within the supplied integer-multiplication research.
