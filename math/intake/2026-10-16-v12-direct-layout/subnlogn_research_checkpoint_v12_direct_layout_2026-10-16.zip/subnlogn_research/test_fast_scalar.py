"""Independent exact-rational and high-precision checks for fast scalar paths."""
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
from operator import mul
import random
import unittest

from fast_scalar import (FastArithmetic, FastCertifiedExp, FastCertifiedPhase,
                         bit_burst_exp, fast_pi_interval, _small_exp)
from test_gaussian_resampling import decimal_pi, decimal_phase

COUNTS = Counter()


class FastDivisionTests(unittest.TestCase):
    def test_exhaustive_signed_quotients(self):
        ledger = Counter()
        arithmetic = FastArithmetic(mul, ledger)
        for b in range(1, 41):
            for a in range(-150, 151):
                self.assertEqual(arithmetic.divmod(a, b), divmod(a, b))
                COUNTS["fast_division_exhaustive_pairs"] += 1
        self.assertGreater(ledger["fast_scalar_quotient_corrections"], 0)

    def test_large_boundary_quotients(self):
        rng = random.Random(813908)
        arithmetic = FastArithmetic(mul)
        for bits in (4, 16, 64, 256, 1024, 4096):
            for _ in range(8):
                b = rng.getrandbits(bits) | 1 << (bits-1)
                q = rng.getrandbits(bits)
                for r in (0, 1, b-1):
                    a = b*q+r
                    for sign in (-1, 1):
                        self.assertEqual(arithmetic.divmod(sign*a, b), divmod(sign*a, b))
                        COUNTS["fast_division_large_pairs"] += 1

    def test_recursive_integer_division(self):
        arithmetic = FastArithmetic()
        for bits in (16, 64, 256, 1024):
            a, b = (1 << (2*bits))-17, (1 << bits)-3
            self.assertEqual(arithmetic.divmod(a, b), divmod(a, b))
            COUNTS["fast_division_recursive_backend_pairs"] += 1


class FastScalarTests(unittest.TestCase):
    def test_pi_binary_splitting_intervals(self):
        with localcontext() as ctx:
            ctx.prec = 1450
            pi = decimal_pi()
            for bits in (4, 16, 64, 257, 512, 2048, 4096):
                low, high = fast_pi_interval(bits, FastArithmetic(mul))
                self.assertLess(Decimal(low)/(1 << bits), pi)
                self.assertGreater(Decimal(high)/(1 << bits), pi)
                self.assertLessEqual(high-low, 40)
                COUNTS["fast_pi_enclosures"] += 1

    def test_exact_small_series_and_bit_bursts(self):
        with localcontext() as ctx:
            ctx.prec = 230
            for bits in (16, 65, 192, 512):
                for numerator, qbits in ((-1, 3), (1, 3), (7, 9), (-17, 10)):
                    for imaginary in (False, True):
                        interval = _small_exp(numerator, qbits, bits, FastArithmetic(mul), imaginary)
                        decay = qbits-(abs(numerator)-1).bit_length()
                        terms = (bits+4+decay-1)//decay
                        term, total = (Fraction(1), Fraction(0)), (Fraction(1), Fraction(0))
                        x = Fraction(numerator, 1 << qbits)
                        for j in range(1, terms):
                            term = ((-term[1]*x/j, term[0]*x/j) if imaginary
                                    else (term[0]*x/j, Fraction(0)))
                            total = tuple(a+b for a, b in zip(total, term))
                        intervals = interval if imaginary else (interval,)
                        for exact, (lo, hi) in zip(total, intervals):
                            self.assertLess(Fraction(lo, 1 << bits), exact)
                            self.assertGreater(Fraction(hi, 1 << bits), exact)
                        COUNTS["fast_binary_series_exact_sums"] += 1
                for value in (0, (1 << (bits-3))-1, -(1 << (bits-4))+1):
                    lo, hi = bit_burst_exp(value, bits, FastArithmetic(mul))
                    expected = (Decimal(value)/(1 << bits)).exp()
                    self.assertLessEqual(Decimal(lo)/(1 << bits), expected)
                    self.assertGreaterEqual(Decimal(hi)/(1 << bits), expected)
                    COUNTS["fast_bit_burst_real_enclosures"] += 1

    def test_exponential_certificates(self):
        rng = random.Random(7133)
        cases = [(n, d, p, s) for p in (2, 32, 101, 256, 512)
                 for n, d, s in ((0, 1, 0), (0, 7, 31), (-1, 3, 0),
                                (-p, 1, 0), (-p+1, 1, 0), (1, 5, 1), (3, 7, 3))]
        cases += [(-rng.randrange(1, 1 << 200), 1 << 201, 128, 0) for _ in range(8)]
        cases += [(-1, 1 << 600, 128, 0), (1, 5, 128, 300)]
        with localcontext() as ctx:
            ctx.prec = 550
            pi = decimal_pi()
            engine = FastCertifiedExp(integer_multiply=mul)
            for n, d, p, shift in cases:
                result = engine.grid(n, d, p, shift=shift)
                exact = (pi*Decimal(n)/d).exp()/(1 << shift)
                tolerance = Decimal("1e-520")
                self.assertTrue(result.verify_grid_error())
                self.assertLessEqual(Decimal(result.lower)/(1 << result.interval_bits)-tolerance, exact)
                self.assertGreaterEqual(Decimal(result.upper)/(1 << result.interval_bits)+tolerance, exact)
                self.assertLess(abs(Decimal(result.value)-exact*(1 << p)), 2)
                COUNTS["fast_exponential_enclosures"] += 1

    def test_phase_certificates(self):
        cases = [(n, d, p) for p in (2, 101, 256) for d in (1, 4, 7, 17)
                 for n in (-1, 0, 1, d//2, d-1)]
        cases += [(n, 1 << 400, 256) for n in (1, (1 << 398)-1, (1 << 398)+1)]
        with localcontext() as ctx:
            ctx.prec = 230
            engine = FastCertifiedPhase(integer_multiply=mul)
            for n, d, p in cases:
                result = engine.grid(n, d, p)
                exact = decimal_phase(n, d)
                self.assertTrue(result.verify_grid_error())
                for v, (lo, hi) in zip(exact, (result.real_interval, result.imag_interval)):
                    tolerance = Decimal("1e-210")
                    self.assertLessEqual(Decimal(lo)/(1 << result.interval_bits)-tolerance, v)
                    self.assertGreaterEqual(Decimal(hi)/(1 << result.interval_bits)+tolerance, v)
                self.assertLess(sum((Decimal(v)-x*(1 << p))**2 for v, x in zip(result.value, exact)), 4)
                COUNTS["fast_complex_phase_enclosures"] += 1

    def test_default_recursive_scalar_backends(self):
        ledger = Counter()
        fast_exp, control_exp = FastCertifiedExp(ledger), FastCertifiedExp(integer_multiply=mul)
        fast_phase, control_phase = FastCertifiedPhase(ledger), FastCertifiedPhase(integer_multiply=mul)
        for n, d, p, shift in ((-1, 3, 48, 0), (1, 5, 64, 1)):
            self.assertEqual(fast_exp.grid(n, d, p, shift=shift), control_exp.grid(n, d, p, shift=shift))
            COUNTS["fast_exp_recursive_backend_cases"] += 1
        for n, d, p in ((1, 7, 48), (-37, 101, 128)):
            self.assertEqual(fast_phase.grid(n, d, p), control_phase.grid(n, d, p))
            COUNTS["fast_phase_recursive_backend_cases"] += 1
        self.assertGreater(ledger["fast_scalar_max_product_bits"], 1024)

    def test_gaussian_diagonal_contract(self):
        # Analytic beta bound: |beta|<=1/2, shift=2*alpha**2-2.
        for alpha in range(2, 100):
            self.assertLessEqual(5*alpha*alpha, 4*(2*alpha*alpha-2))
            COUNTS["fast_gaussian_positive_margin_checks"] += 1

    def test_complete_fast_scalar_reduction(self):
        from fast_scalar_transform import FastScalarSourceTransform
        from guarded_layer import make_guarded_network_layer
        from multiply_resampled import multiply_resampled
        from network_frames import ComplexNetwork
        from packed_stream import make_stream_layout_move
        from swap_recursion import CompiledBitCircuit
        from test_stream_swap import SwapControl
        circuit = CompiledBitCircuit(SwapControl())
        layer = make_guarded_network_layer(ComplexNetwork(100), 192, swap_circuit=circuit)
        movement = make_stream_layout_move(circuit, component_bytes=25)
        x, y = 0xdeadbeef, 0xfedcba98
        # Native integer products are an explicit arithmetic control here.
        # The four separate scalar tests above run the recursive backend.
        result, diagnostics = multiply_resampled(x, y, sources=(3, 5), targets=(4, 8),
            p=192, alpha=6, digit_bits=4, circuit=circuit, layer=layer,
            layout_move=movement, integer_multiply=mul,
            transform_factory=FastScalarSourceTransform)
        self.assertEqual(result, x*y)
        ledger = diagnostics["ledger"]
        self.assertGreater(ledger["fast_certified_exp_calls"], 0)
        self.assertGreater(ledger["fast_certified_phase_calls"], 0)
        self.assertEqual(ledger.get("exp_taylor_terms", 0), 0)
        self.assertEqual(ledger.get("phase_taylor_terms", 0), 0)
        self.assertFalse(diagnostics["implementation_status"]["sub_n_log_n_proved_for_implementation"])
        COUNTS["resampled_fast_scalar_control_products"] += 1

    def test_invalid_contracts(self):
        arithmetic = FastArithmetic(mul)
        functions = [lambda: arithmetic.divmod(2, 0), lambda: arithmetic.divmod(2, -1),
                     lambda: arithmetic.divmod(1.5, 2), lambda: fast_pi_interval(3),
                     lambda: bit_burst_exp(3, 4), lambda: bit_burst_exp(0, 3),
                     lambda: FastCertifiedExp().grid(1, 1, 32),
                     lambda: FastCertifiedExp().grid(1, 0, 32),
                     lambda: FastCertifiedPhase().grid(1, 0, 32),
                     lambda: FastCertifiedPhase().grid(1, 3, 1)]
        for function in functions:
            with self.assertRaises(ValueError): function()
            COUNTS["negative_controls"] += 1


if __name__ == "__main__": unittest.main()
