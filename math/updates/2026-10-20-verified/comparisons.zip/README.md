# Two bounded comparison evidence updates

20 October 2026. Read SCOPE.json, then each COMPARISON.md and INDEPENDENT_REVIEW.md.

## What is finished, and what is not

- ALG-061: independently accepted as a scoped evidence update. The inspected Gaussian-moment and Toeplitz/Prony clauses supply classical ingredients with qualified interface/cost nonmatches. Derin 1987 and the complete Applebaum et al. 2009 journal algorithm remain FULLTEXT-GAP.
- M-REPEATED-BITREV: separately reviewed bounded mechanism/interface comparison. The GIRS, nullity and displacement mechanisms are credited; endpoint freedom and the direction of cost bounds remain restricted. Fresh final-body verification of Delvaux–Van Barel 2008 remains an access gap.
- Neither result is a completed full-text comparison of every named source, a worldwide novelty finding, a new theorem acceptance, an unrestricted runtime claim, or closure of the overall research task. Priorities remain 34 and 42 at the recorded read. No table status, priority or global count was changed by these comparisons or this packaging.

The author reports and source manifests preserve their historical pre-review wording. The separately sealed reviews and SCOPE.json record the review outcome. A past acceptance of a theorem is not a new acceptance by this comparison.

## Evidence, identities and exclusions

The original fetched accepted audit/algebra exports are preserved byte-for-byte in the audits directories. They were already sanitized repository exports; an archive-path/source-identity hash is not necessarily the hash of those exported bytes. The distinctions and unresolved original-byte gaps are retained.

The inherited DELVAUX_FINAL_COMPARISON.md is also byte-preserved. Its opening claim of a final-paper read belongs to that earlier comparison and its other named results. It is not a fresh primary-body read for this package and does not close the present DV2008 access gap.

SOURCE_BINDINGS.json binds every copied source and public rendition. PROJECTIONS.json lists only locator and role-label substitutions. Reviewed source hashes continue to identify the pre-projection sources, not the changed public renditions. Private native table locations and executor-local paths are not distributed. The reports retain stable IDs, recorded action/stop clauses, guards and the independent read outcomes.

Primary sources are attributed by links and exact inspected locators; no primary-paper fulltexts are redistributed. Raw workbook/tool captures, original research archives, historical programs and historical theorem-replay datasets are excluded. Historical audit references to their own replay packets do not mean those packets are included here. This ZIP supports reading the complete audit exports and replaying package-integrity and finite comparison controls only, not reproducing all historical theorem audits or source retrievals.

The SOURCE_MANIFEST.json files are byte-preserved historical inventories of the author inputs, including excluded captures. They are not the public ZIP inventory. The root MANIFEST.json and SHA256SUMS are the exact public inventory.

## Offline verification

Use Python 3.10 or newer, standard library only:

    python3 -I -B verify_package.py
    python3 -I -B verify_package.py --self-test

Run from the extracted directory or pass that directory as the sole positional argument. The first command checks exact inventory, path safety, strict metadata types, hashes, byte-preserved source bindings and scope guards. It runs only the new finite comparative checker in a temporary directory and compares its result using type-strict JSON equality. It neither imports historical research code nor makes network requests. The self-test challenges type confusion, metadata promotion, modified data, extra/missing files and symbolic links on disposable copies.

SHA256SUMS covers every payload file and MANIFEST.json, excluding only SHA256SUMS itself. MANIFEST.json covers every payload file, excluding itself and SHA256SUMS. The verifier pins the expected metadata bytes and payload hashes separately. These are integrity checks, not a digital signature: authenticate the ZIP SHA-256 through the separately supplied receipt. A malicious party replacing the entire ZIP and all checks is outside these checks' trust boundary.
