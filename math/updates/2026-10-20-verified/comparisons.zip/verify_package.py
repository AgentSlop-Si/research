#!/usr/bin/env python3
"""Offline, bounded package integrity and finite comparative-control replay."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile

PAYLOAD_PINS = {'ALG061/COMPARISON.md': {'bytes': 15517, 'sha256': 'a74e8aba005249d12c398450d3b1eca5603d8511aaac360ce5e638c8b7c89180'}, 'ALG061/FRESH_SOURCE_HASHES.json': {'bytes': 1675, 'sha256': '674edabbd19ecc1bce2b966e6326d7c5938fb3705c267a3d6ae09ca77008dcb4'}, 'ALG061/INDEPENDENT_REVIEW.md': {'bytes': 6828, 'sha256': '426239d59862a2ba5014cb2ef04ebd61f791bac1711875b5e90e8b7c37abb91b'}, 'ALG061/SOURCE_MANIFEST.json': {'bytes': 1027, 'sha256': '3cff59a91d0fceee1bb257bcc71445841d10e8de33313e054e5298da472b4efe'}, 'ALG061/audits/PHASE21_AUDIT.md': {'bytes': 15988, 'sha256': 'c39f51b938c1e90c504400bd3269e9b976ebaa46fee4a9dfae1657c9a425bb76'}, 'ALG061/audits/PHASE22_AUDIT.md': {'bytes': 14555, 'sha256': 'd372ddeb4dbd5033dfb44fea8d76c8ac4745a8e80b90a58c066c8fc3463b7543'}, 'ALG061/audits/PHASE23_AUDIT.md': {'bytes': 12397, 'sha256': 'c1f3e69837f82b0a214ab6b02ee64ba363faa2c8ef6f4a28c7cc914c0d3c1f70'}, 'ALG061/audits/PROOF_ALGEBRA.md': {'bytes': 5261, 'sha256': 'f7aef958bb7f1d226391c3873609c6b1c577003e166f3b30234dc0f6a95c6d1d'}, 'M-REPEATED-BITREV/COMPARISON.md': {'bytes': 14936, 'sha256': '76c544047effdcd050dfc3318428a41ba8feccf9e2614080537ced76be0a738b'}, 'M-REPEATED-BITREV/CONTROL_RESULTS.json': {'bytes': 556, 'sha256': '5a3eefe8bb3f4edfcac5729248d231283114b826e1876bbf113289f11479d27d'}, 'M-REPEATED-BITREV/FRESH_SOURCE_HASHES.json': {'bytes': 3257, 'sha256': 'ba744c242bc03f05db1b1a0a05090d0f44439721e8c73503cfc6830b7534b9ae'}, 'M-REPEATED-BITREV/INDEPENDENT_REVIEW.md': {'bytes': 8653, 'sha256': 'f7b894fb1788596112c2e6b1027e07a9194138ee4dd1d6e469c838f02c4c4fa9'}, 'M-REPEATED-BITREV/PRIMARY_SOURCE_LOCATORS.json': {'bytes': 4543, 'sha256': 'fd1c0e68a9735abee458e58c2a629ae44a26f8e33e8b036a7b3dff6e20bf6c81'}, 'M-REPEATED-BITREV/SOURCE_MANIFEST.json': {'bytes': 2061, 'sha256': '35838a785e6fd7a5a7a2d4303429dbe6701264a2f420b1e20eb210afe55012d4'}, 'M-REPEATED-BITREV/audits/ACCEPTED_AUDIT.md': {'bytes': 8810, 'sha256': '718fd42163cd7ff83fa5cf4860e416bd3c12f4dac86728cb5bfb6aab743d88d0'}, 'M-REPEATED-BITREV/check_comparison_controls.py': {'bytes': 3124, 'sha256': '39c534a1b398636ead2b8fd24a9d4a1a9421c9aa763ab99bc69ec55b110c9fb1'}, 'M-REPEATED-BITREV/inherited/DELVAUX_FINAL_COMPARISON.md': {'bytes': 26112, 'sha256': '596cbc312fdb89224470905dcb8e188e86b050e7cdac6a9e84e17a3556883817'}, 'PROJECTIONS.json': {'bytes': 4518, 'sha256': 'e41ce4eca8d321fa42ad15713ffb60614eb1c4effff8e5062e922d3fba312b7e'}, 'README.md': {'bytes': 4326, 'sha256': '8829cc1a82c79740da99b2f93be66656ecf9bd75a0e7f68c8944cf8f55b1d305'}, 'SCOPE.json': {'bytes': 1814, 'sha256': 'f84a6827370cf135efe98919b9a5c018718005407851fd0dbfed4cd3794914b2'}, 'SOURCE_BINDINGS.json': {'bytes': 6683, 'sha256': 'af39820bfc3fe4a1c4596506a18228fcbfa76379d5799bc3a12e71c1877f370e'}}
EXPECTED_SCOPE = {'schema_version': 1, 'package_id': 'selected-comparisons-2026-10-20', 'purpose': 'Bounded comparison evidence update, not complete full-text comparison or research-task closure.', 'status_priority_or_counts_changed': False, 'new_theorem_acceptance': False, 'worldwide_novelty_claim': False, 'historical_research_programs_executed': False, 'primary_paper_fulltexts_included': False, 'historical_theorem_replay_included': False, 'comparisons': [{'stable_id': 'ALG-061', 'priority_at_read': 34, 'independent_disposition': 'PASS_SCOPED_EVIDENCE_UPDATE_WITH_FULLTEXT_GAPS', 'reviewed_source_sha256': '220d529dab5dacf82ebf7fbf047eb03f0d483efcb4bfcbd0359645fcf3475cd8', 'source_manifest_sha256': '3cff59a91d0fceee1bb257bcc71445841d10e8de33313e054e5298da472b4efe', 'independent_review_source_sha256': '0e79101bbf045f93b29a20f49d5765a6bb5c8d7250dc4bcb9c627900388b7b60', 'fulltext_gaps': ['Derin 1987', 'Complete Applebaum et al. 2009 journal algorithm'], 'complete_fulltext_comparison': False, 'overall_research_task_closed': False}, {'stable_id': 'M-REPEATED-BITREV', 'priority_at_read': 42, 'independent_disposition': 'PASS_SCOPED_EVIDENCE_UPDATE_WITH_RETAINED_ACCESS_GAP', 'reviewed_source_sha256': '6cb0466f5ed2033a04fcf7e54a438172ca11b1db211c1848d12ff78a85396936', 'source_manifest_sha256': '35838a785e6fd7a5a7a2d4303429dbe6701264a2f420b1e20eb210afe55012d4', 'independent_review_source_sha256': 'c2f5a7d6eef1d2f4f008f8a87c75a04bfc585d5dfb3d43af00d1114b206d6977', 'fulltext_gaps': ['Fresh final-body verification of Delvaux–Van Barel 2008'], 'complete_fulltext_comparison': False, 'overall_research_task_closed': False}]}
META = {"MANIFEST.json", "SHA256SUMS"}
HEX = re.compile(r"[0-9a-f]{64}")

class VerificationError(Exception):
    pass

def require(condition, reason):
    if not condition:
        raise VerificationError(reason)

def same(actual, expected):
    if type(actual) is not type(expected):
        return False
    if type(actual) is dict:
        return actual.keys() == expected.keys() and all(same(actual[k], expected[k]) for k in actual)
    if type(actual) is list:
        return len(actual) == len(expected) and all(same(a, b) for a, b in zip(actual, expected))
    return actual == expected

def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, "Duplicate JSON key.")
        result[key] = value
    return result

def invalid_constant(value):
    raise VerificationError("Non-finite JSON constant.")

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=pairs,
                          parse_constant=invalid_constant)
    except (UnicodeError, ValueError, OSError) as e:
        raise VerificationError("Invalid JSON input: " + path.name) from e

def keys(obj, expected):
    require(type(obj) is dict and set(obj) == set(expected), "Unexpected metadata keys.")

def integer(value):
    require(type(value) is int and value >= 0, "Expected nonnegative integer, not boolean/float/string.")

def digest(value):
    require(type(value) is str and HEX.fullmatch(value) is not None, "Expected lowercase SHA-256.")

def safe_path(value):
    require(type(value) is str and value != "", "Expected nonempty path.")
    p = PurePosixPath(value)
    require(not p.is_absolute() and "\\" not in value and "\x00" not in value and
            all(part not in {"", ".", ".."} for part in value.split("/")) and
            str(p) == value, "Unsafe inventory path.")

def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inspect_tree(root, expected_files):
    require(root.is_dir() and not root.is_symlink(), "Expected an ordinary extracted directory.")
    actual = set()
    dirs = set()
    for p in root.rglob("*"):
        mode = p.lstat().st_mode
        rel = p.relative_to(root).as_posix()
        require(not stat.S_ISLNK(mode), "Symbolic links are not permitted.")
        if stat.S_ISDIR(mode):
            dirs.add(rel)
        else:
            require(stat.S_ISREG(mode), "Only regular files and directories are permitted.")
            safe_path(rel)
            actual.add(rel)
    require(actual == expected_files, "Exact file inventory mismatch.")
    needed_dirs = set()
    for name in expected_files:
        for parent in PurePosixPath(name).parents:
            if str(parent) != ".":
                needed_dirs.add(str(parent))
    require(dirs == needed_dirs, "Unexpected or missing directory.")

def validate_scope(root):
    scope = read_json(root / "SCOPE.json")
    require(same(scope, EXPECTED_SCOPE), "Scope metadata changed or has noncanonical types.")

def validate_bindings(root):
    bindings = read_json(root / "SOURCE_BINDINGS.json")
    keys(bindings, {"schema_version", "note", "files"})
    require(type(bindings["schema_version"]) is int and bindings["schema_version"] == 1,
            "Invalid binding schema version.")
    require(type(bindings["note"]) is str and type(bindings["files"]) is list, "Invalid binding metadata.")
    seen = set()
    for item in bindings["files"]:
        keys(item, {"path", "source_name", "source_bytes", "source_sha256",
                    "public_bytes", "public_sha256", "byte_preserved"})
        safe_path(item["path"])
        require(item["path"] in PAYLOAD_PINS and item["path"] not in seen, "Unexpected source binding.")
        seen.add(item["path"])
        require(type(item["source_name"]) is str and "/" not in item["source_name"],
                "Expected a source basename, not a private locator.")
        integer(item["source_bytes"])
        integer(item["public_bytes"])
        digest(item["source_sha256"])
        digest(item["public_sha256"])
        require(type(item["byte_preserved"]) is bool, "byte_preserved must be boolean.")
        p = root / item["path"]
        require(p.stat().st_size == item["public_bytes"] and hash_file(p) == item["public_sha256"],
                "Public/source binding mismatch.")
        if item["byte_preserved"]:
            require(item["source_bytes"] == item["public_bytes"] and
                    item["source_sha256"] == item["public_sha256"], "Byte-preservation claim failed.")
    projection = read_json(root / "PROJECTIONS.json")
    keys(projection, {"schema_version", "policy", "projections", "excluded"})
    require(type(projection["schema_version"]) is int and projection["schema_version"] == 1,
            "Invalid projection schema.")
    require(type(projection["policy"]) is str and type(projection["projections"]) is list and
            type(projection["excluded"]) is list and
            all(type(x) is str for x in projection["excluded"]), "Invalid projection metadata types.")
    changed = set()
    for item in projection["projections"]:
        keys(item, {"path", "source_sha256", "public_sha256", "changes"})
        safe_path(item["path"])
        digest(item["source_sha256"])
        digest(item["public_sha256"])
        require(item["path"] in seen and item["path"] not in changed, "Unexpected projection target.")
        changed.add(item["path"])
        require(type(item["changes"]) is list and len(item["changes"]) > 0, "Missing change description.")
        for change in item["changes"]:
            keys(change, {"kind", "occurrences", "description"})
            require(type(change["kind"]) is str and change["kind"] in {"locator", "role"},
                    "Only declared locator/role projections are permitted.")
            integer(change["occurrences"])
            require(change["occurrences"] > 0 and type(change["description"]) is str,
                    "Invalid change count/description.")
    require(changed == {x["path"] for x in bindings["files"] if not x["byte_preserved"]},
            "Projection coverage mismatch.")

def verify(root, replay=True):
    expected_files = set(PAYLOAD_PINS) | META | {"verify_package.py"}
    inspect_tree(root, expected_files)
    validate_scope(root)
    validate_bindings(root)
    manifest = read_json(root / "MANIFEST.json")
    keys(manifest, {"schema_version", "package_id", "inventory_excludes", "files"})
    require(type(manifest["schema_version"]) is int and manifest["schema_version"] == 1,
            "Invalid manifest schema version.")
    require(manifest["package_id"] == "selected-comparisons-2026-10-20" and
            type(manifest["package_id"]) is str, "Wrong package identity.")
    require(same(manifest["inventory_excludes"], ["MANIFEST.json", "SHA256SUMS"]),
            "Inventory exclusion mismatch.")
    require(type(manifest["files"]) is list, "Manifest files must be an array.")
    listed = []
    for item in manifest["files"]:
        keys(item, {"path", "bytes", "sha256"})
        safe_path(item["path"])
        integer(item["bytes"])
        digest(item["sha256"])
        listed.append(item["path"])
        require(item["path"] in expected_files - META, "Unexpected manifest target.")
        p = root / item["path"]
        require(p.stat().st_size == item["bytes"] and hash_file(p) == item["sha256"],
                "Payload size or hash mismatch.")
    require(listed == sorted(expected_files - META), "Manifest order or exact membership mismatch.")
    for name, pin in PAYLOAD_PINS.items():
        p = root / name
        require(p.stat().st_size == pin["bytes"] and hash_file(p) == pin["sha256"],
                "Pinned payload changed, even if its manifest was rehashed.")
    sums = "".join(f"{hash_file(root / name)}  {name}\n" for name in sorted(expected_files - {"SHA256SUMS"}))
    require((root / "SHA256SUMS").read_text(encoding="utf-8") == sums, "SHA256SUMS mismatch.")
    for p in root.rglob("*.json"):
        read_json(p)  # Reject duplicate keys and non-finite values in all bundled JSON.
    if replay:
        expected = read_json(root / "M-REPEATED-BITREV/CONTROL_RESULTS.json")
        with tempfile.TemporaryDirectory(prefix="comparison-controls-") as tmp:
            temp = Path(tmp)
            source = root / "M-REPEATED-BITREV/check_comparison_controls.py"
            shutil.copyfile(source, temp / source.name)
            run = subprocess.run([sys.executable, "-I", "-B", source.name], cwd=temp,
                                 capture_output=True, text=True, timeout=30)
            require(run.returncode == 0, "Finite comparison-control program did not pass.")
            actual = read_json(temp / "CONTROL_RESULTS.json")
            require(same(actual, expected), "Finite controls differ in value or JSON type.")
            require({x.name for x in temp.iterdir()} == {source.name, "CONTROL_RESULTS.json"},
                    "Unexpected comparative-control output.")
    return {"result": "PASS", "inventory_files": len(expected_files),
            "scope_and_metadata": "type-strict", "finite_comparison_controls": "PASS" if replay else "not run",
            "historical_theorem_replay": "not included or claimed", "network_access": "none"}

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def alter_json(path, fn):
    obj = read_json(path)
    fn(obj)
    write_json(path, obj)

def self_test(root):
    results = []
    cases = [
        ("scope false changed to integer zero", lambda r: alter_json(r/"SCOPE.json",
            lambda o: o.__setitem__("worldwide_novelty_claim", 0))),
        ("scope false changed to string", lambda r: alter_json(r/"SCOPE.json",
            lambda o: o.__setitem__("status_priority_or_counts_changed", "false"))),
        ("scope false changed to null", lambda r: alter_json(r/"SCOPE.json",
            lambda o: o.__setitem__("new_theorem_acceptance", None))),
        ("scope promotion", lambda r: alter_json(r/"SCOPE.json",
            lambda o: o["comparisons"][0].__setitem__("complete_fulltext_comparison", True))),
        ("priority integer changed to float", lambda r: alter_json(r/"SCOPE.json",
            lambda o: o["comparisons"][0].__setitem__("priority_at_read", 34.0))),
        ("manifest bytes changed to boolean", lambda r: alter_json(r/"MANIFEST.json",
            lambda o: o["files"][0].__setitem__("bytes", True))),
        ("manifest unknown key", lambda r: alter_json(r/"MANIFEST.json",
            lambda o: o.__setitem__("unexpected", False))),
        ("source binding false changed to integer", lambda r: alter_json(r/"SOURCE_BINDINGS.json",
            lambda o: o["files"][0].__setitem__("byte_preserved", 0))),
        ("projection count changed to boolean", lambda r: alter_json(r/"PROJECTIONS.json",
            lambda o: o["projections"][0]["changes"][0].__setitem__("occurrences", True))),
        ("extra file", lambda r: (r/"unexpected.txt").write_text("unexpected")),
        ("extra empty directory", lambda r: (r/"unexpected_directory").mkdir()),
        ("missing file", lambda r: (r/"ALG061/COMPARISON.md").unlink()),
        ("modified payload", lambda r: (r/"ALG061/COMPARISON.md").write_bytes(
            (r/"ALG061/COMPARISON.md").read_bytes() + b"\nchanged\n")),
        ("duplicate JSON key", lambda r: (r/"SCOPE.json").write_text(
            (r/"SCOPE.json").read_text().replace('"schema_version": 1,', '"schema_version": 1, "schema_version": 1,', 1))),
        ("nonfinite JSON value", lambda r: (r/"SCOPE.json").write_text(
            (r/"SCOPE.json").read_text().replace('"schema_version": 1,', '"schema_version": NaN,', 1))),
        ("path traversal", lambda r: alter_json(r/"MANIFEST.json",
            lambda o: o["files"][0].__setitem__("path", "../outside"))),
        ("checksum changed", lambda r: (r/"SHA256SUMS").write_text("0" * 64 + "  README.md\n")),
    ]
    def replace_symlink(r):
        p = r / "ALG061/COMPARISON.md"
        p.unlink()
        p.symlink_to("../README.md")
    cases.append(("symbolic link", replace_symlink))
    def rehash_scope(r):
        p = r / "SCOPE.json"
        alter_json(p, lambda o: o.__setitem__("worldwide_novelty_claim", True))
        def update(o):
            entry = next(x for x in o["files"] if x["path"] == "SCOPE.json")
            entry["bytes"], entry["sha256"] = p.stat().st_size, hash_file(p)
        alter_json(r / "MANIFEST.json", update)
    cases.append(("scope promotion with updated manifest", rehash_scope))
    def rehash_report(r):
        p = r / "ALG061/COMPARISON.md"
        p.write_bytes(p.read_bytes() + b"\nchanged\n")
        def update(o):
            entry = next(x for x in o["files"] if x["path"] == "ALG061/COMPARISON.md")
            entry["bytes"], entry["sha256"] = p.stat().st_size, hash_file(p)
        alter_json(r / "MANIFEST.json", update)
        def update_binding(o):
            entry = next(x for x in o["files"] if x["path"] == "ALG061/COMPARISON.md")
            entry["public_bytes"], entry["public_sha256"] = p.stat().st_size, hash_file(p)
        alter_json(r / "SOURCE_BINDINGS.json", update_binding)
    cases.append(("changed report with rehashed manifest and binding", rehash_report))
    for name, mutate in cases:
        with tempfile.TemporaryDirectory(prefix="comparison-tamper-") as tmp:
            copied = Path(tmp) / "package"
            shutil.copytree(root, copied)
            mutate(copied)
            try:
                verify(copied, replay=False)
            except VerificationError:
                results.append({"control": name, "result": "REJECTED_AS_EXPECTED"})
            else:
                raise VerificationError("Tamper self-test unexpectedly accepted: " + name)
    require(not same(True, 1) and not same(False, 0) and not same(1, 1.0),
            "Type-strict comparison control failed.")
    results.append({"control": "boolean/integer/float equality collision", "result": "REJECTED_AS_EXPECTED"})
    return results

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", nargs="?", type=Path, default=Path(__file__).absolute().parent)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    try:
        report = verify(args.directory)
        if args.self_test:
            report["tamper_controls"] = self_test(args.directory)
            report["tamper_controls_passed"] = len(report["tamper_controls"])
        print(json.dumps(report, indent=2))
    except (VerificationError, OSError, subprocess.SubprocessError) as e:
        print(json.dumps({"result": "FAIL", "reason": str(e)}))
        return 1
    return 0

if __name__ == "__main__":
    sys.exit(main())
