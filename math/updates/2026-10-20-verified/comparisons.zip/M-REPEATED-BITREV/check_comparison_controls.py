"""New, bounded comparative controls; never imports or executes source programs."""
import json
from pathlib import Path

P = 17

def mul(a, b):
    return [[sum(x*y for x,y in zip(row,col)) % P
             for col in zip(*b)] for row in a]

def sub(a, b):
    return [[(x-y) % P for x,y in zip(r,s)] for r,s in zip(a,b)]

def add(a, b):
    return [[(x+y) % P for x,y in zip(r,s)] for r,s in zip(a,b)]

def rank(a):
    a=[r[:] for r in a]
    if not a: return 0
    row=0
    for c in range(len(a[0])):
        pivot=next((i for i in range(row,len(a)) if a[i][c]),None)
        if pivot is None: continue
        a[row],a[pivot]=a[pivot],a[row]
        inv=pow(a[row][c],-1,P)
        a[row]=[(v*inv)%P for v in a[row]]
        for i in range(len(a)):
            if i != row:
                q=a[i][c]
                a[i]=[(v-q*w)%P for v,w in zip(a[i],a[row])]
        row+=1
        if row==len(a): break
    return row

def block(a,rows,cols): return [[a[i][j] for j in cols] for i in rows]
def ident(n): return [[int(i==j) for j in range(n)] for i in range(n)]
def projector(n,x): return [[int(i==j and i in x) for j in range(n)] for i in range(n)]
def perm(mapping): return [[int(i==mapping[j]) for j in range(len(mapping))] for i in range(len(mapping))]

results={}
n=8
omega=2
assert pow(omega,n,P)==1 and pow(omega,n//2,P)!=1
f=[[pow(omega,i*j,P) for j in range(n)] for i in range(n)]
x=[0,1,4,5]; y=[2,3,6,7]; even=list(range(0,n,2))
e=projector(n,x); ec=sub(ident(n),e)
results["even_even_half_rank"]={"N":n,"field":P,"rank":rank(block(f,even,even)),"expected":n//4}
assert results["even_even_half_rank"]["rank"]==n//4
mapping=list(range(n)); mapping[0],mapping[2]=mapping[2],mapping[0]
mix=perm(mapping)
results["one_pair_mixing_cross_rank"]=rank(block(mix,x,y))
assert results["one_pair_mixing_cross_rank"]==1
swap=perm([i^2 for i in range(n)])
results["complete_swap_fixed_projector_displacement_rank"]=rank(sub(mul(e,swap),mul(swap,e)))
results["complete_swap_transported_displacement_rank"]=rank(sub(mul(ec,swap),mul(swap,e)))
assert results["complete_swap_fixed_projector_displacement_rank"]==n
assert results["complete_swap_transported_displacement_rank"]==0
results["identity_nonzero_but_projector_displacement_zero"]=rank(sub(mul(e,ident(n)),mul(ident(n),e)))==0
assert results["identity_nonzero_but_projector_displacement_zero"]
a=[[(3*i+7*j+i*j+1)%P for j in range(n)] for i in range(n)]
b=[[(2*i+5*j+3*i*j+4)%P for j in range(n)] for i in range(n)]
lhs=sub(mul(ec,mul(a,b)),mul(mul(a,b),e))
rhs=add(mul(sub(mul(ec,a),mul(a,e)),b),mul(a,sub(mul(e,b),mul(b,e))))
results["compatible_displacement_product_identity"]=lhs==rhs
assert results["compatible_displacement_product_identity"]
results["basic_support_product_does_not_exclude_half_half"]={str(n): (n//2)**2>=n for n in [4,8,128]}
assert all(results["basic_support_product_does_not_exclude_half_half"].values())
results["scope"]="Finite comparative countercontrols only; no theorem replay or uniform-proof claim."
Path(__file__).with_name("CONTROL_RESULTS.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results,indent=2))
