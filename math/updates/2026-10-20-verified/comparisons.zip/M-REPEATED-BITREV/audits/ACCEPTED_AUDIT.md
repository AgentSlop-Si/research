# Repeated bit-reversal quasiseparable depth: independent audit

Date: 2026-10-09 UTC. Uploaded code was read statically and never executed or imported.

## Verdict

Accept the all-length central-partition theorem. For N=2^k, k≥2, arbitrary two-sided quasiseparable stages of orders r_i, and interstage permutations that preserve or swap the specified central-bit groups,

    N/2 ≤ d_N sum_i r_i,
    d_N = 2^((k+1)/2)−1 when k is odd,
    d_N = 2^(k/2) when k is even.

Hence the total quasiseparable order is Ω(√N), and four rank-one stages are impossible at every dyadic N≥128. At N=128 the required rank is 64 and the four-stage capacity is 60. At N=256 they are 128 and 64.

This is a distinct model and proof from the previously reviewed paired-Green L-bound. Keep the results separate. It is a stage-width/depth obstruction for a restricted shuffle class, not an unrestricted Fourier arithmetic-circuit lower bound, faster FFT, or publication-priority claim.

## Source and provenance

Library `[private-id]`; source archive `fft_four_stage_central_bit_no_go_2026-10-10.zip`; 687,917 bytes; SHA-256 `0d0b58a05ebd8ab57d4b51deaa6dfefaa2f08a2c2511de2f0053f7bf4011e8cb`.

All 25 source manifest entries verify. Its nested `prior_checkpoint_full.zip` has SHA-256 `9d3e4fce68dfe0e8ae89fcd8bcc7408325586f97472dd3497d554315542b5bea`, exactly the previously reviewed three-stage source. No predecessor code was executed. The source date remains publisher metadata rather than a verified execution timestamp.

## 1. Crossing-rank lemma and stage propagation

For any binary partition X,Y of the naturally ordered indices, let d count adjacent changes of membership. Split X into its maximal consecutive row runs I. Columns of Y lie wholly to the left or right of each I. Each nonempty left piece is a submatrix of a lower off-diagonal cut block, and each right piece lies in an upper off-diagonal cut block. A two-sided quasiseparable order-r matrix therefore contributes at most r per such piece. The number of pieces is exactly d, because each X/Y boundary borders exactly one X run. Thus both cross blocks have rank at most dr.

Track one input group through the net preserve/swap parity of the interstage permutations. Multiplication by a new stage expresses the unexpected-group block as its previous unexpected-group contribution plus one crossing contribution. Their ranks are bounded by the previous rank and dr_i, respectively. This proves the cumulative bound d sum_i r_i by induction, including whole-group swapping permutations and arbitrary within-group orderings.

There is no division by stage parameters, generic-nonzero assumption, conditioning assumption, or invertible-stage chart. Zero transition coefficients are harmless. A factorization of an invertible target would itself force square stages to be invertible, but the rank inequality is valid even for arbitrary singular products.

## 2. All four central Fourier blocks really are invertible

For odd k=2m+1, set L=2^m, N=2L², and separate indices by middle bit. Write row and column indices as

    i=2Lz+uL+a, j=2Lw+vL+b,
    0≤z,w,a,b<L, u,v∈{0,1}.

Modulo N the Fourier exponent decomposes into `2L(zb+aw)+(uL+a)(vL+b)`. Fourier transforms in the z and w coordinates isolate b and a. After row/column reordering this leaves a diagonal matrix with nonzero monomial entries. Each of the four choices of fixed u,v is therefore invertible. The membership string has 2L−1 boundaries.

For even k=2m, set q=2^(m−1), N=4q², and separate the two middle bits into agreeing values {0,3} and disagreeing values {1,2}. Write

    i=4qz+uq+a, j=4qw+vq+b.

The same outer-coordinate Fourier reductions give q² independent 2-by-2 blocks. Their determinant is a nonzero monomial times `1−eta^(Δu Δv)`, where eta=omega^(q²) is a primitive fourth root and both differences are odd. Every local determinant is nonzero. Thus every choice of row and column group gives a full-rank N/2 block. The membership pattern is repetitions of A B B A, with endpoint A runs merged, giving 2q boundaries.

This elementary argument proves the complex all-length claim directly. It also works over splitting fields of characteristic not dividing N. Finite-field experiments are corroboration rather than a substitute for this proof.

Bit reversal preserves both central partitions. More generally the stage argument allows any permutation that preserves the groups or swaps the complete groups. Since all four Fourier blocks are invertible, either net swap parity gives the required rank N/2.

## 3. Thresholds and scope

The rank-one depth lower bounds at N=32,64,128,256,512,1024,2048 are respectively 3,4,5,8,9,16,17. Therefore four rank-one stages are excluded from N=128 onward; four rank-two stages are excluded from N=512 onward. N=64 at rank-one depth four merely meets this necessary budget. It is not a construction or an existence result.

Permutations that mix the groups internally evade this proof. Our exact negative control swaps just one index between A and B: even with no cross-stage channel order, the permutation has a nonzero cross block. Whole-group preservation/swapping is therefore an essential hypothesis, not a cosmetic coordinate convention.

Do not convert this depth/order lower bound into an arithmetic lower bound by multiplying it by an O(Nr) upper bound for a scan evaluator. A literal implementation that evaluates every channel at every coordinate can spend Θ(N sum r_i), but a rank theorem alone does not prove that every evaluator must pay that many scalar gates. The source itself disclaims unrestricted arithmetic lower bounds; this logical distinction must remain explicit.

## 4. Independently verified finite wire certificates

Our newly authored checker reads the four saved JSON witnesses as inert data. It independently reconstructs graph successors on demand, checks that every removed edge is one valid scalar-node capacity edge, rejects duplicate cut entries, computes reachability after deletion, and recomputes the Fourier determinant residues. It calls no uploaded verifier, optimizer, or graph package.

All four certificates pass:

- N128, repeated bit reversal: 60 removed scalar wires, 64 selected outputs unreachable, Fourier rank 64.
- N256, repeated bit reversal: 64 wires, 128 unreachable outputs, Fourier rank 128.
- N256, middle rotate(bitrev): 112 wires, Fourier rank 128.
- N256, middle XOR-mix(bitrev): 124 wires, Fourier rank 128.

The latter two are finite-size obstructions for the explicitly represented two-directional scalar-scan network. They do not extend the central-partition all-length theorem to arbitrary mixing shuffles. The graph allows arbitrary scalar edge weights and zero coefficients, so no favorable numerical generator choice can bypass its cuts.

The independently recomputed A-by-B determinants are 3504 modulo 12289 and 4096 modulo 65537 at N128; 696 and 4096 at N256. The selected Fourier block is already proved invertible over complex numbers above, so no claim about lifting arbitrary finite-field infeasibility is needed.

## 5. Independent controls, reproducibility, and remaining limits

The independent checker additionally verifies:

- Partition sizes, transition counts, bit-reversal invariance, and thresholds through N8192.
- All four Fourier block determinants in two fields at seven lengths N4 through N256: 56 nonzero determinant checks.
- 13,456 exact radix-decomposition entry identities and 1,364 nonzero even-case local determinants through N1024.
- 25 matrix-product controls with rank-zero, rank-one, and rank-two transition-generator stages, including zero transitions and random within-group preserving/swapping permutations, up to N128.
- The source's four finite cut witnesses and the mixing-permutation countercontrol.

The source's random dense stage generator tests only a semiseparable subclass with transition products fixed to one. That is sufficient as a sample control but not as a proof of every quasiseparable chart. Our broader zero-transition controls supplement it; the general theorem follows from cut ranks directly.

Several optional source discovery scripts refer to an absolute `` predecessor location. They are not portable as shipped merely by installing SciPy/NetworkX. Its core symbolic proof and saved-certificate data do not depend on those tools. Our replay requires only the independent checker and its four relative JSON data files, and uses Python's standard library. Uploaded scripts remain inert.

Floating MILP output concerning alternative N64 partitions is exploratory and was not rerun. It is not a formal certificate of the absence of all possible cuts, and cannot prove that a four-stage Fourier factorization exists. No exhaustive literature-priority review or faster FFT claim is made.
