# Hero1 Phase23: independent short-probe audit

## Decision

**Accept the reduction from 4s to 2s+2 Fourier probes, the shared streaming prefix, and the joint adjacent-pencil compiler.** The exact resultant is unchanged because the two Hankel windows never used the omitted samples. The source correctly stops relying on its previous 4s-sample uniqueness argument: after a failed cyclic certificate it continues checking the remaining bounded candidates.

The change gives genuine local field-operation savings and can expand fast-family coverage. We independently exhibit an N=32 structured residual rejected by the old sixteen-probe gate because Fourier coefficient 11 is zero, but certified by the new ten-probe route. Complete input verification remains necessary.

The whole source's “fully charged” totals and all-input executable domain still inherit qualifications from Phase22. This is not a generic-input FFT improvement, a floating-point result or a novelty claim.

## Provenance and exact lineage

Archive: `fft_hero1_phase23_20261010.zip`, 9,949,421 bytes, Library `[private-id]`.

SHA-256:

    0df6af5743923a90e1b5da9219630c51c69b043aaaa126bbffa9d8d41bc5907c

All 58 members were materialized inertly; all 57 source-manifest entries match. The embedded Phase22 archive is byte-identical to the reviewed predecessor, SHA-256 `e1af07f82b4872ba952f1ab4bae8f4c0da29504d3a51420e17707bb66e001c92`. Of 43 common filenames, 32 are unchanged. Among carried-over Python files, only the packaging label and `compressed_resultant.py` change. The latter now accepts a callback for the resultant evaluator; its old default remains intact.

The two new algorithm modules are `short_probe_fusion.py` and `joint_pencil.py`. They, the new tests/audit/benchmark, changed prose and saved results were read statically. No uploaded program was executed or imported. Our portable checker imports only two preserved auditor-authored mathematical checkers from the previous reviews.

## Exact mathematical change

Set R_k=(F_N r)_k, T_k=1/R_k, and s as the candidate denominator sparsity. For a candidate shift w=ω^δ and multiplier α, the two order-(s+1) Hankel pencils are

    P_b(α,w)=det[T_(b+i+j)(1−αw^(b+i+j))]_(i,j=0...s), b=0,1.

Their maximum index is 2s+1. Their union of dependencies is exactly T₀,...,T_(2s+1), so 2s+2 probes suffice. Phase21's universal resultant factorization was already a polynomial identity in these variables. Reducing the supplied array length does not change that theorem, its fixed-degree Sylvester convention, the bound 2b on the reduced polynomial U, or the trace representation U(w)=w^b V(w+w inverse), with b=sum_(j=1 to s) j².

For m=2s+2, the streaming prefix reads r_j and the prepared root ω^j once per input position and repeatedly multiplies its current term by ω^j. At frequency k that term is r_j ω^(jk), proving every output. The loop performs exactly N(m−1) field multiplications and Nm additions. This is (4s+3)N operations, versus the source's former 12sN probe loop. At s=4 the change is 48N to 19N.

At each resultant sample w, the joint compiler generates w⁰,...,w^(2s+1) once. For each α sample it forms one corrected sequence of length 2s+2, then assembles both overlapping Hankel matrices. These are entrywise identical to the old independently assembled matrices. The interpolated pencils and Sylvester determinant are therefore identical, including singular samples and degree drops.

This changes constants and dependencies, not the resultant's degree or the fixed-s arithmetic order.

## Certification, candidate search and coverage

After the unchanged trace sieve generates all nonidentity shift roots, a linear gamma gcd identifies a candidate α. Prony recovery uses the first 2s corrected samples and checks the available prefix. The source then checks that the recovered A has no zero at any Fourier root and verifies

    A(S)r=e₀−αe_δ

at every coordinate before accepting. Therefore R_k=(1−αω^(δk))/A(ω^k) at every k. With valid invertible outer Green operators obeying LF=FP, the final solve returns Fx.

A failed cyclic certificate may stop at its first bad coordinate, which is sufficient to reject that candidate. It is not a completed verification of all N entries. Every accepted certificate does inspect all N. The source now continues after a failure rather than using the old early-exit uniqueness claim. We do not assert that a counterexample to every possible shorter-prefix uniqueness theorem has been proved; the previous specific 4s proof no longer applies, and this conservative candidate loop is sound.

For nonzero U there are at most 2b candidate shifts. At fixed s, even a full O(sN) check for every candidate is O_s(N). Nonlinear gamma gcds, vanished probes, zero resultants, failed sparse recovery and singular A spectra may still decline valid structured inputs. Generic inputs retain ordinary FFT fallback and positive discovery overhead.

The new source length gate is N≥2s+2 instead of N≥4s, with the same 1≤s≤8 and p>4b+20 restrictions. This broadens the algebraic residual route, although whole-executable Green and FFT domain requirements remain separate.

### Explicit expanded-coverage control

Over GF(3329), take N=32, primitive ω=2532, and

    A(z)=1+771z+106z³+1474z⁷,
    R_k=(1−1062ω^k)/A(ω^k),
    r=F_N^(−1)R.

Every denominator value is nonzero. The first ten R_k are nonzero, but R₁₁=0. Our independent Phase22 gate declines at its sixteen-probe check; the new gate finds two shift candidates, accepts one full cyclic certificate and reproduces all 32 values. This is a real coverage gain from removing an unnecessary nonzero-probe requirement, not a repair of all degeneracies.

Adding η_j=ω^(−10j) preserves exactly the first ten probes while changing the full spectrum. In our control both plausible candidate certificates fail and no output is accepted. This demonstrates why the full certificate remains essential even on a prefix indistinguishable from an accepted model.

## Independently derived local savings

For one resultant sample, joint compilation saves 2s root-power multiplications and 6s(s+2) corrected-sequence operations:

    saving = 6s²+14s.

Both determinant matrices, elimination paths and polynomial interpolations have the same values as before, so this local comparison does not assume generic nonsingularity. At s=4, each sample saves 152 operations. The compressed compiler takes 31 core samples plus three witnesses, saving 34*152=5,168 operations.

When both methods reach the same constant-trace-gcd rejection branch, the first batch reciprocal changes from sixteen to ten entries, saving another 18 multiplications. Along with the probe reduction, this gives

    Phase22 minus Phase23 = 29N+5,186.

For the recorded successful four-tap branch, the new routine also avoids the old duplicate sixteen-element reciprocal batch (49 operations), six corrected sequence values (24 operations), and six four-term Prony fit checks (72 operations). The extra 145 gives

    Phase22 minus Phase23 = 29N+5,331.

These conditions match the source's six structured and six generic benchmark records. `BENCHMARK_DIFFERENCE_CHECKS.json` verifies every numerical difference against the independently derived formulas. They are not universal costs for arbitrary branch patterns, merged supports, zero probes or additional rejected candidates.

This validates the local reduction, not every absolute grand total. The saved N=32,768 totals 2,962,215→2,006,612 are consistent with the successful-branch formula. Any percentage against the separate FFT baseline still uses the inherited warm proxy model and its residual ledger limitations.

## Inherited limitations and proposed guard discipline

- Phase22 had removed the active compressed route's erroneous fresh sparse-root-table omission by deleting its U-evaluation call. Phase23 keeps that improvement. The old helper remains present for legacy callers; its defect should not be reattached to the new active path.
- Gamma-gcd monic normalization products, determinant swap negations, some sample-denominator subtractions and optional factor-output arithmetic remain omitted by inherited counters. The shared root table and Green matrices are preinitialized and excluded from the published comparators. Prefix memory counters also omit some root-table accesses; these are not complete cold or machine-instruction ledgers.
- `trace_subgroup.py` is byte-unchanged. Phase23 now says “polylog p” rather than the previous specific O(log p) root-extraction term, which accommodates an ordinary Tonelli–Shanks descent with supplied setup. But the actual function still scans deterministically for a nonresidue rather than accepting one. That search needs its own bound or supplied verified nonresidue. The complete half-subgroup scan is an already available O_s(N) alternative for every positive trace gcd.
- The legacy Phase20 noncoprime-resonance guard remains unchanged, but the new short-probe path does not call it. The correct pole condition remains α^(N/gcd(N,δ))=1.
- The cyclic Green solver still attempts to invert every diagonal entry and therefore fails on some invertible matrices. Our inherited GF(1201), N=8 control reproduces the invertible P,L determinants 945 with a zero L diagonal. The mathematical Green identity remains true there. This is a domain/implementation limitation, not a defect in short-probe algebra.
- Exact Bluestein fallback requires compatible 2Nth and convolution-NTT roots, not merely an Nth root. Thus an unqualified executable “every input in every such field” statement is too broad without the valid outer-engine/fallback domain.
- Full-certificate soundness does not mean arbitrary internal exceptions, malformed field setup or compiler bugs are automatically caught and redirected. The implementation still has assertions and setup exceptions. Its mathematical exactness theorem presumes the specified algebra and valid execution domain.
- No floating-point stability or linear bit-time claim is established. Statements that this branch has not constructed a generic sub-N-log-N FFT must not be read as a worldwide claim excluding different established computation models.

## Independent controls and portable replay

Only our three included auditor files were executed. The inherited files are our independent math, not uploaded source. The new checker uses direct Fourier sums, independently assembled pencils/resultants, exact sparse recovery and explicit cyclic identities.

Passed controls:

- 34 streamed-prefix cases over dyadic and nondyadic lengths, with exact formula counts and direct Fourier agreement.
- 96 joint-resultant comparisons for s=1,...,8 over GF(12289) and GF(65537), including w=0,1,−1 and other nodes. Appending arbitrary unused suffix samples changes nothing.
- Fourteen fresh structured residuals: twelve complete certificates and two retained support-collision declines, with all accepted full spectra checked.
- Twelve previously authored probe-preserving adversaries plus the new strict ten-probe adversary; no false acceptance. The latter explicitly records two failed candidates, confirming continued search rather than the old early exit.
- The explicit R₁₁=0 coverage gain above, and accepted residual controls at N=10 and N=12 with s=4. These are mathematical residual tests, not claims to certify every outer engine at those lengths.
- Nine generic controls, the zero-vector/zero-probe guards, the inherited invertible zero-diagonal Green example and all twelve saved local benchmark differences.

The published 58 tests, 75 compiler comparisons and 35,206 DFT-coordinate checks remain source-reported evidence, distinct from these new counts. `PORTABILITY.json` records an actual relocated byte-identical replay. `REPLAY.md` gives the command.

## Final boundary

Accepted: exact dependency reduction, shared field arithmetic, unchanged resultant, sound continued candidate certification, conditional fixed-s linear structured recovery and the demonstrated extra nonzero-prefix coverage. Qualified: residual cold-cost omissions, root/nonresidue supply, Green/fallback domains and finite precision. No general FFT improvement or historical priority is established; the elementary overlap-sharing and summation principles are not claimed as new foundational methods.
