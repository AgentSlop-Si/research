# Hero1 Phase22: independent trace-sieve audit

## Decision

**Accept the exact trace/Dickson subgroup-root sieve and complete candidate enumeration, conditional on the inherited Phase21 gates and valid field/Green setup.** The sieve replaces the N-point evaluation of the reciprocal resultant by arithmetic modulo a polynomial of degree at most b=s(s+1)(2s+1)/6. It proves absence of every admissible shift when its gcd is constant; a nonconstant gcd supplies candidates, not a complete sparse-rational certificate.

**The active Phase22 path really removes Phase21's specific fresh sparse-root-table undercharge.** That cost was tied to the now-replaced `sparse_group_eval(U)` call. It is not correct to carry that particular omission forward into the new compressed-path total. The legacy helper itself is unchanged and remains defective for legacy callers.

**Qualify the stated linear-trace root-extraction complexity.** The source's Tonelli–Shanks routine searches for a quadratic nonresidue internally rather than accepting the supplied setup invoked by the theorem. With a supplied nonresidue, the straightforward routine has a conservative O(log p + ν₂(p−1)²) field-multiplication bound, not uniformly O(log p). These issues do not invalidate the sieve or output certificate. The complete half-subgroup scan already provided by the source can enumerate even a linear gcd in O_b(N), avoiding square roots and discrete logarithms altogether.

This remains a conditional structured-input algorithm with an ordinary FFT fallback. No generic-input FFT improvement or historical priority is established.

## Provenance and predecessor comparison

Archive: `fft_hero1_phase22_20261010.zip`, 9,854,573 bytes, Library `[private-id]`.

SHA-256:

    e1af07f82b4872ba952f1ab4bae8f4c0da29504d3a51420e17707bb66e001c92

All 49 members were materialized as inert bytes, and all 48 source-manifest entries match. The nested `PRIOR_PHASE21_COMPLETE.zip` is byte-identical to the reviewed Phase21 archive, SHA-256 `59b93d506fd4d545e9932ae98c4f290c1ae68b90878a82e344ecffb616d5780a`. There are 39 same-named files across the two top-level archives; 29 are unchanged. Among carried-over Python files, only `compressed_resultant.py` changes. The new trace implementation, tests, audit and benchmark were read in full; changed prose and saved results were inspected. The static diff is summarized in `LINEAGE_CHECKS.json`.

No uploaded source or test was executed or imported. Our checker imports only `independent_phase21_math.py`, a byte-preserved copy of our own previously authored Phase21 checker. Both auditor files are included in portable replay. Publisher execution receipts remain source claims rather than our execution results.

## Exact theorem and field guards

Let p be an odd prime, N divide p−1, and ω be a supplied primitive Nth root. Phase21 gives a nonzero polynomial V such that

    U(w) = w^b V(w+w^(−1)).

Remove every factor t−2 from V, producing V*. This is necessary because t=2 corresponds only to w=1 in odd characteristic, and the identity shift is forbidden. Nonzero constant V* correctly means no admissible shift.

Define Dickson polynomials by D₀=2, D₁=t and D_(n+1)=tD_n−D_(n−1). Then

    D_N(w+w^(−1))−2 = (w^N−1)² / w^N.

Consequently D_N−2 has roots exactly the traces of Nth roots. The identity trace 2 is simple; when N is even the trace −2 is also simple; every other inverse-pair trace has multiplicity two. Its complete monic factorization has total degree N. Since all Nth roots are in the base field, every trace and both quadratic preimages are also in the base field.

Thus

    there is δ in {1,...,N−1} with U(ω^δ)=0
      iff degree gcd(V*, D_N−2) > 0.

No probabilistic step or heuristic is present in this equivalence. The statement is about resultant roots. A resultant root may still fail the gamma-gcd, Prony, denominator or full cyclic certificate gates; nonconstant trace gcd alone never licenses output acceptance.

The guard N | p−1 matters. For example, over GF(5), N=3 and V=t+1 give a nonconstant trace gcd, but the field has no nonidentity third roots. The uploaded helper's comments about possible extension-field candidates are relevant outside its theorem's field assumptions; they are unnecessary under those assumptions. Primality, Nth-root existence and primitivity are assumed setup, not established by the small helper's `p`-odd check.

## Quotient recurrence and candidate completeness

The identities

    D_(2m)=D_m²−2,
    D_(2m+1)=D_m D_(m+1)−t,
    D_(2m+2)=D_(m+1)²−2

follow by substituting t=w+w inverse. They are polynomial identities, so reducing after each operation modulo V* preserves the desired remainder. A binary index walk needs at most three quotient-polynomial products per bit; dyadic N needs one squaring per doubling. No degree-N polynomial is constructed by the source algorithm. Ordinary dense arithmetic gives O(b² log N) field work plus O(b²) polynomial gcd work, with b interpreted as a bound on degree V.

Write G=gcd(V*,D_N−2):

- Constant G certifies no admissible shift.
- For linear G, its unique trace t determines w from w²−tw+1=0. The two roots are inverse partners; they can coincide at w=−1. Filtering w=1, checking w^N=1, and a correct BSGS discrete-log recovery enumerate every admissible shift. The source actually performs these checks and pays group multiplications for its table and giant steps.
- For higher degree G, evaluating at δ=1 through floor(N/2) and adding the inverse partner N−δ visits every admissible trace exactly once, except that the even-N midpoint is correctly a singleton. This is complete even when G has repeated roots. It costs O(N degree G) arithmetic and uses the engine's existing root table.

The same half-scan is valid for degree-one G. It is a simple deterministic substitute if a bounded root-extraction setup is unavailable. No free finite-field polynomial factorization or free discrete logarithm is needed for the linear-in-N candidate route.

## Integration with the inherited certificate

The source preserves the first 4s reciprocal probes, the compressed-resultant identity, two Hankel-pencil gamma gcds, sparse coefficient recovery, all-N denominator nonvanishing check, and complete cyclic identity

    A(S)r = e₀ − γ e_δ.

Only after that identity holds at every coordinate may it return

    R_k = (1−γ ω^(δk)) / A(ω^k).

For fixed s, these input-dependent and full-output stages remain O_s(N); eliminating the resultant scan does not eliminate the initial O(sN) probes, sparse-denominator evaluation, certificate, output writes or final Green solve. The candidate list still has at most 2b shifts.

The same fast-family exclusions remain: first probes must be nonzero, resultant must not vanish identically, an appropriate gamma gcd must be linear, recovered A must have at most s taps and no subgroup zero, and the interpolation field must be large enough. The implemented compressed path additionally enforces 1≤s≤8, N≥4s and p>4b+20. Fixed-support rational families have dimension at most s+1 after normalization; density of their time-domain vectors does not make them generic inputs.

## Cost corrections and implementation qualifications

### The active-path root-table omission is gone

The exact source diff replaces `sparse_group_eval(U,engine,co)` by the trace sieve and candidate enumeration. The subsequent denominator spectrum is computed by `sparse_direct_fourier`, which reuses the engine powers and charges its arithmetic. The legacy `sparse_group_eval` function and unused import remain, but neither is called by the active Phase22 compressed path. Accordingly the N−1 fresh-table omission and discarded pruned-FFT negations attached to that call no longer belong to this path.

Other inherited omissions remain, such as normalization multiplications in the gamma `poly_gcd`, determinant row-swap negations, compressed-sample denominator subtractions, and portions of optional factor-output construction. The new trace gcd's own monic normalization does charge its multiplications. Comparators also share preinitialized roots and Green solvers, so the published table is a warm field-operation proxy, not a complete cold ledger. Some other inherited counters overestimate formulas; simply adding a few omissions does not produce a certified exact grand total.

The reported N=32,768 proxy is 2,962,215 versus Phase21's 3,213,392 and the shared-setup baseline's 5,440,325. Those are source-reported figures, not independently certified savings. The improvement in the algebraic root-search step is valid independently of those percentages.

### Root extraction needs a corrected bound or a different route

For p−1=2^h q, q odd, the ordinary Tonelli–Shanks descent performs at most h decreasing-order rounds, each with O(h) squarings. With a supplied nonresidue, a safe field-multiplication bound is O(log p+h²). The source's stated O(log p) term is therefore not a general bound for this implementation. This is consistent with the established analysis in [Schlage-Puchta's paper](https://arxiv.org/abs/1105.1456).

Moreover `modular_sqrt(a,p,co)` has no nonresidue argument. It tests z=2,3,... until finding a nonresidue, charging each modular exponentiation. If z₀ is the first successful integer, this adds O(z₀ log p) multiplications. Actual finite runs count the work, but the deterministic scan has no supplied polylogarithmic bound in this package. The theorem's supplied-nonresidue setup does not match the API. A supplied verified primitive field generator could provide a nonresidue, but the current function does not use it.

A repaired accelerated-branch bound is

    O_s(N + b² log N + sqrt N + log p + h² + nonresidue-search cost),

plus BSGS memory and lookup/index costs. With supplied nonresidue and log p=O(log N), the logarithmic-square term is still dominated by N; however that conclusion must not silently cover the current search loop. Alternatively, selecting the already-implemented half-scan for every positive G gives O_s(N+b² log N) arithmetic, conditional only on the field/root table setup already needed by the engine. BSGS's O(sqrt N) word storage is real; deterministic sorted lookup costs additional comparisons rather than free hashing.

### Earlier safety/domain defects remain separate

The old Phase20 resonance predicate in `resultant_gate.py` is byte-unchanged. Its correction remains: with g=gcd(N,δ), poles occur exactly when α^(N/g)=1; the old α^N test can falsely reject noncoprime nonresonant cases. The new Phase22 compressed route does not use this predicate, so it is neither newly broken by it nor a repair to the legacy API.

The original zero-diagonal limitation in the cyclic Green solver is also unchanged. Our independent GF(1201), N=8 control has primitive generator 29, ω=1194, invertible P and L with determinants 945, but L has a zero diagonal entry that the uploaded solver attempts to invert. The mathematical Green identity still holds. This defeats an unqualified claim that the executable supports every invertible Green instance. The control has the necessary 16th roots, so it is independent of the separate Bluestein root-supply issue.

An exact fallback also needs its compatible 2Nth root and convolution-NTT roots, not merely a primitive Nth root. Thus whole-executable all-input correctness requires valid Green and fallback domains. These inherited limitations do not refute the new trace-polynomial theorem. No floating-point conditioning or bit-complexity improvement is established.

## Independent controls

Only the two included auditor-authored Python files were executed. The quotient-ring test uses 2×2 polynomial transfer-matrix powering, independent of the source's Dickson binary-pair implementation. Quadratic root recovery is checked using exhaustive field roots as an oracle, followed by a separately authored BSGS routine; that intentionally slow oracle is not claimed as the accelerated algorithm.

Passed:

- All 7,450 nonzero degree-at-most-two polynomials over GF(7), N=3; GF(13), N=6; and GF(17), N=4. Exact sieve acceptance and full shift sets agree with direct subgroup evaluation. This includes the source's 4,912-polynomial GF(17) domain without executing its test.
- 390 additional randomized trace-polynomial cases across every divisor of p−1 for p=17,31,97,193. Full Dickson construction and independent quotient-matrix powering agree in all 390 cases.
- Complete Dickson trace factorization for 39 field/length pairs, with correct simple ±2 traces and double inverse-pair traces.
- 1,157 linear-trace quadratic/BSGS recoveries and 204 individual BSGS index checks, including odd order, full subgroups and N=1.
- Sixteen identity-multiplicity/negative-one controls; the explicit extension-field counterexample documents the root-supply guard.
- The trace route integrated into our own Phase21 recovery checker preserves exactly the old resultant-scan candidate sets on fourteen fresh structured cases. Twelve certify the complete spectrum; two support-collision cases remain valid declines with degree-two trace gcds.
- Twelve perturbations preserve every short input probe but fail the full cyclic certificate. Nine generic controls decline; zero-vector and inherited zero-probe controls remain guarded.
- The invertible zero-diagonal Green counterexample is reproduced using independently constructed dense matrices, not the uploaded solver.

`PORTABILITY.json` records an actual relocated replay with only the two independent auditor files. Results match byte-for-byte. The publisher's 51 tests and 15,492 DFT-coordinate checks remain distinct saved source claims.

## Literature and acceptance boundary

Dickson traces are established mathematics; [Bluher's paper](https://arxiv.org/pdf/1707.06877) explicitly gives the recurrence and w+w inverse characterization. Ordinary modular-root and BSGS machinery also predates this package. This audit accepts the application of these tools to the already-proved Phase21 representation; it makes no historical novelty claim.

Final boundary: exact sieve and complete enumeration accepted; full certificate remains mandatory; the specific Phase21 root-table omission is removed from the active route; accelerated root-extraction setup/bounds and residual ledger/domain limitations are qualified. A clean fixed-s linear candidate route exists through the half-scan, while the arbitrary-input complete transform still falls back to O(N log N).
