# Exact algebraic proof — self-reciprocal Hankel resultant

Let `s>=1`, `m=s+1`, `T_0,...,T_(2s+1)` be algebraically independent, and set

`H_e=(T_(e+i+j))_(0<=i,j<=s)`, `D_w=diag(1,w,...,w^s)`,

`P_e(a,w)=det(H_e-a*w^e D_w H_e D_w)`, for `e=0,1`.

Set `Res_s(w)=Res_a(P_0,P_1)` using the degree-m homogeneous Sylvester convention; the actual leading coefficients may drop under specialization without invalidating the polynomial identity. The variables `w,a` commute, and the following proof works in a characteristic-zero rational function field before specializing the resulting integral polynomial identity to finite fields.

## 1. Exact reciprocal identity

At `w^-1`, `a` fixed, the entry `(i,j)` is

`T_(e+i+j)(1-a*w^(-e-i-j))`.

Using `1-a*w^(-k) = -a*w^(-k)(1-a^-1*w^k)`, determinant row and column scalings give

`P_e(a,w^-1)=(-a)^m w^(-E_e) P_e(a^-1,w)`, `E_e=m*e+m(m-1)`.

Write `rev_a(P)=a^m P(1/a)`. For degree-m polynomials, reversing both resultant arguments changes their resultant by `(-1)^(m*m)`. Moreover scaling both P0 and P1 by `(-1)^m*w^(-E_e)` multiplies the resultant by the mth power of each scaling. Therefore

`Res_s(w^-1)=(-1)^(m*m) w^(-m(E_0+E_1)) Res_s(w)`.

Since `m(E_0+E_1)=m^2(2m-1)`, the claimed grade-D reciprocal identity follows.

## 2. The universal `(w-1)^(m^2)` factor

Put `w=1+epsilon`, `a=1+epsilon*t`. For each k, `1-(1+epsilon*t)(1+epsilon)^k` is divisible by `epsilon` in `Z[t,epsilon]`. Hence

`P_e(1+epsilon*t,1+epsilon)=epsilon^m * Q_e(t,epsilon)`

with polynomial `Q_e`. A common affine change of polynomial argument satisfies

`Res_t(P_0(1+epsilon*t),P_1(1+epsilon*t))=epsilon^(m*m) Res_a(P_0,P_1)`.

Scaling each m-degree polynomial by `epsilon^m` instead gives

`Res_t(...)=epsilon^(2m*m) Res_t(Q_0,Q_1)`.

Cancel `epsilon^(m*m)` in the integral domain to obtain

`Res_s(1+epsilon)=epsilon^(m*m)*Res_t(Q_0,Q_1)`.

Thus `(w-1)^(m^2)` divides `Res_s(w)` as an exact polynomial identity.

## 3. Universal w-adic valuation at 0

Work in the generic field `K=Q(T_0,...,T_(2s+1))`. Every `H_e` and its relevant leading minors are invertible over K for generic Hankel data (e.g. generic sums of distinct exponential sequences give nonsingular Hankel minors).

Factor the determinant as

`P_e(a,w)=det(H_e) det(I - a w^e H_e^-1 D_w H_e D_w)`.

The coefficient of `a^j` is a sum of principal j-minors of the indicated matrix. The Cauchy–Binet expansion of a principal minor with row/column set I contains

`w^(e*j+sum(I)+sum(J)) det((H_e^-1)_(I,J)) det((H_e)_(J,I))`

for `|I|=|J|=j`. The minimal weight is attained uniquely at `I=J={0,...,j-1}`, yielding

`ord_w [a^j]P_e = j(j-1) + e*j`.

The associated Newton polygon has consecutive slopes

`e, e+2, ..., e+2s`, with each segment of horizontal length one. Over the algebraic closure of `K((w))`, its m roots in `a` therefore have distinct valuations

`-e, -(e+2), ..., -(e+2s)`.

For P0 these are `-2i`; for P1 they are `-(2j+1)`, `0<=i,j<=s`. Because the two sets have distinct parities, no cancellation is possible in any root difference. The valuations are exactly

`ord_w(alpha_i-beta_j)=-max(2i,2j+1)`.

The leading coefficients of P0 and P1 have valuations `m(m-1)` and `m^2`. The root product formula for their resultant gives

`ord_w Res_s = m^2(2m-1) - sum_(i,j=0)^s max(2i,2j+1)`.

Calculate the sum:

`sum_(i,j) max(2i,2j+1) = 4 sum_(j=0)^s j^2 + 3 sum_(j=0)^s j + (s+1)`.

Substitution of the square and triangular sums yields

`ord_w Res_s = s(s+1)(4s+5)/6 =: v_s`.

In particular, the coefficients of `w^0,...,w^(v_s-1)` vanish identically as polynomials in the T variables. Although generic leading order may rise under specializations, **the divisibility by w^v remains a universal polynomial identity**. This is not merely a numerical small-size observation.

## 4. Palindromic quotient and sample count

Write `Res_s(w)=w^v_s (w-1)^(m^2) U_s(w)`. The reciprocal identity implies

`w^(D_s-2v_s-m^2) U_s(w^-1)=U_s(w)`.

A direct simplification gives

`D_s-2v_s-m^2 = 2 s(s+1)(2s+1)/6 = 2b_s`.

Therefore U is palindromic of grade 2b. Multiply by w^-b to obtain a symmetric Laurent polynomial in `w,w^-1`. The invariant Laurent ring is `K[w+w^-1]`, so for a polynomial `V_s` of degree at most b,

`U_s(w)=w^b V_s(w+w^-1)`.

It follows that `b+1` field evaluations at distinct reciprocal-quotient nodes suffice to reconstruct the full polynomial U. Three additional evaluations in the implementation are numerical/exact code witnesses, not assumptions in the theorem.

For s=4: `m=5`, `D=225`, `v=70`, `(w-1)` multiplicity 25, `b=30`, `deg U<=60`; 31 determinant evaluations suffice. For s=2: `D=45`, `v=13`, `(w-1)` multiplicity 9, `b=5`, `deg U<=10`; six evaluations suffice.

## 5. Independent finite-field diagnostics

`test_compressed_phase21.py` reconstructs the full uncompressed resultant with its conservative D+1 samples for s=1,...,6, verifies the exact coefficient reciprocity `coeff[j]=(-1)^(m*m) coeff[D-j]`, all predicted universal factors, equality of full and compressed U, and independent evaluations away from interpolation nodes.

Finite experiments corroborate the polynomial proof; they are not substituted for it. For degenerate data that make the resultant identically zero, no uniqueness or fast recovery is claimed.
