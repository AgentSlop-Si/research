"""Independent symbolic/endpoint checks only. No inherited executable or root census."""
from pathlib import Path
import hashlib,json
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).with_name('REPLAY_CHECK_RESULTS.json')
q=s.symbols('q',nonzero=True)
a1=2/q/(1-q);a2=2/q**3/(1-q)**2
assert s.factor(a1*a1-2*a2+4/q**3/(1-q))==0
# Distinguishing phase control: flipping the sign must not simplify to zero.
assert s.factor(a1*a1-2*a2-4/q**3/(1-q))!=0
N=4;I=s.I;S=s.zeros(N)
for j in range(N-1):S[j+1,j]=1
S[0,N-1]=-1
assert S**N==-s.eye(N)
C=s.zeros(N)
for k in range(N):C+=I**(k*(k-1)//2)*(S**k)
EL=s.diag(*[I**(-j*(j-1)//2) for j in range(N)])
ER=s.diag(*[I**(-j*(j+1)//2) for j in range(N)])
F=s.Matrix(N,N,lambda j,k:I**(-j*k)/2)
assert s.simplify(EL*C*ER/2-F)==s.zeros(N)
# Verify the signed-wrap branch formula symbolically in a and arbitrary x.
a=s.symbols('a');x=s.Matrix(s.symbols('x0:4'))
b=sum(a**(N-1-k)*x[k] for k in range(1,N))
y=[(x[0]-a*b)/(1+a**N)]
for k in range(1,N):y.append(a*y[-1]+x[k])
res=(s.eye(N)-a*S)*s.Matrix(y)-x
assert all(s.factor(v)==0 for v in res)
ybad=list(y);ybad[0]=(x[0]+a*b)/(1+a**N)
assert any(s.factor(v)!=0 for v in (s.eye(N)-a*S)*s.Matrix(ybad)-x)
# Rouché slack uses only m>=2, M2>=m, r<=1.
# The asserted d0*r/4 lower margin is below the uniform bound.
assert s.Rational(1,2)-s.Rational(1,128)-s.Rational(1,32)>s.Rational(1,4)
# Total coefficient/modulus disturbance <= (m+3)/(1024 M2)*d0*r.
# This is <= (1+3/2)/1024 for all m>=2.
assert s.Rational(5,2048)<s.Rational(1,16)
import subprocess,sys
subprocess.run([sys.executable,str(ROOT/'verify.py'),'--integrity-only'],check=True,capture_output=True,text=True)
manifest=json.loads((ROOT/'provenance/AUTHOR_ORIGINAL_MANIFEST.json').read_text())
result={'status':'PASS','candidate_manifest_sha256':hashlib.sha256((ROOT/'provenance/AUTHOR_ORIGINAL_MANIFEST.json').read_bytes()).hexdigest(),'candidate_proof_sha256':hashlib.sha256((ROOT/'result/PROOF.md').read_bytes()).hexdigest(),'original_manifest_entries_accounted':len(manifest['files']), 'public_inventory_verified':True,'checks':['symbolic Newton identity and wrong-sign negative control','exact N=4 signed shift, endpoint phases and normalized negative-sign Fourier identity','symbolic signed-wrap rational branch for arbitrary a and x; wrong-sign control','uniform m>=2 Rouché slack and outward-enclosure budget'],'not_run':['author checker','inherited checker','root census','exhaustive root grid','production executor'],'mandatory_specification_repairs':[], 'replay_note':'Public binding replay against accepted v2; original first-freeze receipt is retained separately.'}
OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
