# Executed evidence

The final check_candidate.py run passed 24 exact cyclotomic coefficient/Newton-sign cases (h=2 through 24 and h=32), 12 exact parameter-guard cases (N=4,6,8,10 with p=1,3,19), the excluded h=1 negative control, two exact N=4 full-tolerance Rouché disks, and two negative certificate examples. The proposed centers are numerical, but all acceptance comparisons are rational and the degree-two coverage is exact.

An initial exploratory guard list extended through N=96 and was interrupted before producing a result because directly constructing enormous rational powers was unnecessary for these finite controls. It is not a failed proof, a passing test, or a performance result. The retained checker narrows the explicit rational guard sweep; the symbolic asymptotic exponents are proved in PROOF.md.

No inherited research executable, exhaustive root grid, or production root engine was run. No exact arithmetic claim is inferred solely from numerical root proposals.
