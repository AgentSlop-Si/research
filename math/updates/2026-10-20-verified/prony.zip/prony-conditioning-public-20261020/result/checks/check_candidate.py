#!/usr/bin/env python3
"""Finite controls only. Does not execute the exhaustive grid or prove all-h claims."""
from pathlib import Path
from fractions import Fraction as F
import json, sys, hashlib
import sympy as sp
import mpmath as mp
ROOT=Path(__file__).resolve().parents[1]
q=sp.Symbol('q')

def rem(expr, modulus):
    return sp.rem(sp.Poly(sp.expand(expr),q,domain=sp.QQ),modulus).as_expr()

algebra=[]
for h in list(range(2,25))+[32]:
    phi=sp.Poly(sp.cyclotomic_poly(2*h,q),q,domain=sp.QQ)
    # Independently form only top three coefficients of the ORIGINAL product.
    sum1=sum(q**k for k in range(h))
    sum2=sum(q**(2*k) for k in range(h))
    r1=-sum1
    r2=sp.expand((sum1**2-sum2)/2)
    a1=rem(q**(h-1)*r1,phi)
    a2=rem(q**(2*h-3)*r2,phi)
    tests={
      'first_coefficient':rem(a1*q*(1-q)-2,phi)==0,
      'second_coefficient':rem(a2*q**3*(1-q)**2-2,phi)==0,
      'negative_newton_sign':rem((a1*a1-2*a2)*q**3*(1-q)+4,phi)==0,
      'positive_sign_mutation_rejected':rem((a1*a1-2*a2)*q**3*(1-q)-4,phi)!=0,
      'sum_q_squared_zero':rem(sum2,phi)==0,
    }
    assert all(tests.values()),(h,tests)
    algebra.append({'h':h,'N':2*h,**tests})
# h=1 excluded negative control: true P_1=z-1 has p2=1, not 2.
assert 1!=2

# Exact positive rational parameters, all displayed inequalities are checked.
def params(N,p):
    m=N//2;R=F(2)**(N+1);delta=(2*R)**(-N*m*(m-1))
    eta=(2*R**N)**(-N*m);rho=eta*(2*R)**(-(N-1))
    KV=m*(2*R/delta)**(m-1);W=m*KV;G=2*W*R**N;HV=m*m*(2*R)**(m-1)
    eps=F(2)**(-p);vg=eps*rho/(16*m);vb=vg/(8*(2*R)**N);uc=vb/(8*m*KV)
    e=min(F(1),rho/2,eps*rho*rho/(16*m*G),1/(4*KV*HV),vb/(8*KV*HV*W),vg/(4*W*N*(2*R)**(N-1)))
    def floorpow(x):
        k=x.numerator.bit_length()-x.denominator.bit_length()
        v=F(2)**k
        if v>x:v/=2
        return v
    e=floorpow(e);M2=1<<(m-1).bit_length();A=(4*R)**m;d0=delta**(m-1)
    r=floorpow(min(e,delta/8,d0/(16*M2*A)))
    s=d0*r/(64*M2*A)
    theta=d0*r/(1024*M2*A);zeta=d0*r/(1024*M2)
    assert e<=rho/2 and KV*HV*e<=F(1,4)
    assert 2*KV*(m*uc+HV*e*W)<=vb/2
    assert 2*(2*R)**N*vb+W*N*(2*R)**(N-1)*e<=vg/2
    assert m*(2*vg/rho+2*G*e/rho**2)<=eps/4
    assert m*A*s<=d0/2
    assert A*s+A*r*r < d0*r/4
    assert 2*theta*A+(m+1)*zeta<d0*r/16
    assert 4*r<delta
    return locals()

parameter_checks=[]
for N in [4,6,8,10]:
    for p in [1,3,19]:
        a=params(N,p)
        parameter_checks.append({'N':N,'p':p,'all_guard_inequalities':True,
          'root_tolerance_denominator_bits':a['e'].denominator.bit_length(),
          'disk_radius_denominator_bits':a['r'].denominator.bit_length(),
          'grid_step_denominator_bits':a['s'].denominator.bit_length(),
          'scope_note':'parameter arithmetic only; does not assert squarefreeness for this N'})

# N=4: q=i exactly; P_2(z)=z^2+(1-i)z-1.
# mpmath only proposes centers. Every acceptance predicate below is exact rational.
def C(a=0,b=0):return (F(a),F(b))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,t):return (a[0]*t,a[1]*t)
def power(a,n):
    r=C(1)
    for _ in range(n):r=mul(r,a)
    return r

def U(a):return abs(a[0])+abs(a[1])
def L(a):return max(abs(a[0]),abs(a[1]))
def abs2(a):return a[0]**2+a[1]**2

a=params(4,3);r=a['r'];s=a['s'];rho=a['rho'];delta=a['delta'];eta=a['eta']
prec=s.denominator.bit_length()+80;mp.mp.prec=prec
b=mp.mpc(1,-1)
roots=[(-b+mp.sqrt(b*b+4))/2,(-b-mp.sqrt(b*b+4))/2]
centers=[]
for x in roots:
    centers.append(C(F(int(mp.nint(x.real/s.numerator*s.denominator)))*s,F(int(mp.nint(x.imag/s.numerator*s.denominator)))*s))
certificates=[]
for w in centers:
    a0=add(add(mul(w,w),mul(C(1,-1),w)),C(-1));a1=add(scale(w,2),C(1,-1));a2=C(1)
    lhs=U(a0)+U(a2)*r*r;rhs=L(a1)*r
    assert lhs<rhs
    assert L(w)>r # every point in disk nonzero
    assert L(add(C(1),power(w,4)))>=eta # conservative exact center denominator
    certificates.append({'center_real':str(w[0]),'center_imag':str(w[1]),'radius':str(r),
       'rouche_lhs':str(lhs),'rouche_rhs':str(rhs),'strict_rouche':True,
       'nonzero_disk':True,'center_legal_denominator_lower_bound_at_least_eta':True})
assert abs2(sub(centers[0],centers[1]))>(2*r)**2
# Wrong-root and repeated-root negative controls for same rational RD test.
assert not (F(1)+r*r < 0*r) # z^2-1 around w=0
assert not (r*r < 0*r) # z^2 around repeated root w=0

results={
 'status':'finite controls passed; not independent review',
 'python':sys.version.split()[0], 'sympy':sp.__version__, 'mpmath':mp.__version__,
 'exact_cyclotomic_cases':algebra,
 'h1_exclusion_control':True,
 'parameter_guard_cases':parameter_checks,
 'N4_full_tolerance_exact_certificates':certificates,
 'N4_disjoint_complete_degree_two_coverage':True,
 'negative_root_certificate_controls':2,
 'limits':['No exhaustive grid was run','No all-h squarefreeness claim','Proposal arithmetic is not a certificate','No performance benchmark','No universal lower bound']
}
(ROOT/'evidence'/'CONTROL_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'exact_cyclotomic_cases':len(algebra),'guard_cases':len(parameter_checks),'N4_exact_disks':len(certificates),'all_pass':True}))
