# Original Prony conditioning and paid application contract

Scoped accepted research release, 20 October 2026.

Read result/PROOF.md, result/COST_LEDGER.md and review/SEALED_INDEPENDENT_REVIEW.md together. SCOPE.json is the release boundary. The author proof and the fresh sealed verdict retain exactly the independently bound bytes. The proof's original candidate-era wording is historical; the later sealed verdict supplies acceptance.

The result proves exponential conditioning of the raw monomial moment matrix in the canonical embedding for every integer h>=2, with infinity for repeated roots. It supplies an explicitly paid exponential cold-preparation route and a full O(N^2) rational independent-bank application for the original family when 16 does not divide N. Neither a bit lower bound, exclusion of scaling or preconditioning, all-even squarefreeness, production implementation nor faster Fourier computation follows.

## Files and provenance

- result/: unchanged accepted v2 manuscript, cost ledger, finite author controls and saved evidence.
- review/: sealed independent mathematical verdict, repair binding and first-freeze evidence. FIRST_FREEZE_CHECK_RESULTS.json deliberately refers to v1; V2_BINDING_PUBLIC.json and the sealed verdict identify the repaired accepted version.
- sources/: original model, recurrence, legality and ordinary-squarefreeness proofs and scoped acceptances. The explicit degree-two boundary is covered by the twice-odd lemma.
- historical/large-t/: separate earlier family proof and reviews. The Oct19 polynomial-preparation result is retained from its historical review. Its complete proof and controls are not supplied here, it is not freshly reaccepted or replayed, and its bound is not transferred to the original family.
- inherited_controls/: available prior finite controls and saved receipts, retained inert. Their historical executions are not new executions by this release.
- provenance/: original manifests plus a strict original-to-export route ledger with sizes, hashes, exclusions, and hashed line-change segments. Original manifests are historical membership records, not inventories of this export. SHA-256 binds bytes; it is not a signature or identity attestation.

Only machine locators and neutral role labels are projected, alongside the clearly labeled public adaptation of the review checker. The optional reciprocal-root sharpening is absent. Historical routing-only metadata and superseded review-request instructions are excluded. Mathematical attribution is retained.

## Reproduce

Use Python 3.11 or later with the packages in requirements.txt. Integrity/privacy/inventory checking uses only the standard library:

    python verify.py --integrity-only

Run current author and separately authored reviewer mathematical controls in isolated temporary copies, with output validation and negative controls:

    python verify.py --controls

Test integrity rejection, JSON type confusion, changed claims, missing or extra files, duplicate keys and unsafe routes:

    python verify.py --tamper-tests

The verifier does not use the network or machine-specific paths and never modifies this release. Controls are finite evidence; they do not execute the full exhaustive grid, prove the uniform theorem by enumeration, or establish performance. A successful replay is not a new independent mathematical review.
