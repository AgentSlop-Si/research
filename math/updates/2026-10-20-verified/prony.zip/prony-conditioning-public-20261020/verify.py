#!/usr/bin/env python3
"""Offline public-package verifier. Never imports or executes inherited controls."""
from pathlib import Path, PurePosixPath
import argparse, copy, hashlib, json, re, shutil, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parent
SHA=re.compile(r'[0-9a-f]{64}\Z')
PINNED={
 'provenance/AUTHOR_ORIGINAL_MANIFEST.json':'ed384801908daf6020da067c0f6d7ca65bb71e022b100191778c876649c6ae12',
 'provenance/REVIEW_ORIGINAL_MANIFEST.json':'24071fa727bc71f5566823ad57e995c2acb730af4fd89d9f408a4bf711519a20',
 'result/PROOF.md':'e9f61348c4e91ebb63bd9040ea877d075f61602499075fcc3611e18e789a2c44',
 'review/SEALED_INDEPENDENT_REVIEW.md':'1d47a0e586407d801388b3320b9e0be1d476833a4b93323f4d992e6067219379'}
def require(v,msg):
 if not v:raise ValueError(msg)
def keys(v,expected,label):
 require(type(v)is dict and set(v)==set(expected),label+' fields')
def integer(v,label):require(type(v)is int and v>=0,label+' integer')
def digest(v,label):require(type(v)is str and SHA.fullmatch(v) is not None,label+' digest')
def route(v,label):
 require(type(v)is str and v and '\\' not in v and '\x00' not in v,label+' path type')
 p=PurePosixPath(v)
 require(not p.is_absolute() and str(p)==v and all(x not in ('','.','..') for x in p.parts),label+' safe path')
def hashbytes(b):return hashlib.sha256(b).hexdigest()
def object_pairs(pairs):
 d={}
 for k,v in pairs:
  require(k not in d,'duplicate JSON key '+k);d[k]=v
 return d
def readjson(p):return json.loads(p.read_text('utf-8'),object_pairs_hook=object_pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def strict_equal(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return set(a)==set(b) and all(strict_equal(a[k],b[k]) for k in a)
 if type(a)is list:return len(a)==len(b) and all(strict_equal(x,y) for x,y in zip(a,b))
 return a==b
def privacy(root):
 patterns=[r'/'+x+r'/' for x in ('workspace','home','tmp')]+['lib'+'file_', 'dream'+'_notes', 'agent'+'_notes', 'thread'+'_id', 'approval'+'_request', 'cloud'+'_browser_handoff']
 hits=[]
 for p in root.rglob('*'):
  if p.is_file():
   data=p.read_text('utf-8')
   for pat in patterns:
    if re.search(pat,data):hits.append((str(p.relative_to(root)),pat))
 require(not hits,'privacy marker detected: '+str(hits))
def integrity(root=ROOT):
 require(sys.flags.optimize==0,'assertion-enabled Python required for scientific controls')
 mf=readjson(root/'MANIFEST.json')
 keys(mf,('schema_version','status','inventory_policy','files'),'manifest')
 require(type(mf['schema_version'])is int and mf['schema_version']==1,'manifest schema')
 require(mf['status']=='PUBLIC_SCOPED_RELEASE','manifest status')
 require(mf['inventory_policy']=='all regular files except MANIFEST.json; no symlinks; no unlisted files','inventory policy')
 require(type(mf['files'])is list,'manifest files list')
 paths=[]
 for e in mf['files']:
  keys(e,('path','bytes','sha256'),'manifest entry');route(e['path'],'entry');integer(e['bytes'],'size');digest(e['sha256'],'entry')
  require(e['path']!='MANIFEST.json','self entry');paths.append(e['path'])
  p=root/e['path'];require(p.is_file() and not p.is_symlink(),'missing or symlink member '+e['path'])
  raw=p.read_bytes();require(len(raw)==e['bytes'] and hashbytes(raw)==e['sha256'],'member mismatch '+e['path'])
 require(paths==sorted(set(paths)),'duplicate or unsorted inventory')
 actual=[]
 for p in root.rglob('*'):
  require(not p.is_symlink(),'symlink')
  if p.is_file() and str(p.relative_to(root))!='MANIFEST.json':actual.append(str(p.relative_to(root)))
 require(sorted(actual)==paths,'extra or omitted file')
 for rel,h in PINNED.items():require(hashbytes((root/rel).read_bytes())==h,'accepted anchor '+rel)
 for p in root.rglob('*.json'):readjson(p)
 s=readjson(root/'SCOPE.json')
 expected_keys=('schema_version','status','canonical_embedding','conditioning_domain','matrix','conditioning_bound','construction_domain','cold_preparation','application','error','original_proof_sha256','original_author_manifest_sha256','original_review_sha256','original_review_manifest_sha256','inherent_bit_lower_bound','preconditioner_exclusion','faster_fft','all_even_squarefreeness','full_grid_executed','production_executor','reciprocal_sharpening_included','broader_owner_closed','historical_large_t_newly_accepted')
 keys(s,expected_keys,'scope');require(type(s['schema_version'])is int and s['schema_version']==1,'scope schema');require(s['status']=='SCOPED_ACCEPT','scope acceptance')
 for k in expected_keys[14:]:require(type(s[k])is bool and s[k] is False,'overclaim or boolean type '+k)
 require(s['canonical_embedding']=='q=exp(pi i/h)' and s['conditioning_domain']=='integer h>=2, N=2h','canonical domain')
 require(s['construction_domain']=='even N>=4 with N%16!=0; elsewhere conditional on separately certified ordinary squarefreeness','construction scope')
 require(s['matrix']=='V[k,l]=alpha_l^k, 0<=k<h; raw unscaled monomial basis','matrix scope')
 require(s['conditioning_bound']=='kappa_2(V)> (4/pi)^((h-1)/2)/sqrt(h), or infinity for repeated roots','conditioning statement')
 require(s['error']=='relative output error <2^-p for nonzero b-bit dyadic input; zero input handled separately','accuracy statement')
 require(s['cold_preparation']=='2^[O(p+N^5)] bit operations; polynomial workspace','setup scope')
 require(s['application']=='O(N^2) rational operations; O(N^6(p+b+N^5)^2) conservative bit operations','application scope')
 for k,p in [('original_proof_sha256','result/PROOF.md'),('original_author_manifest_sha256','provenance/AUTHOR_ORIGINAL_MANIFEST.json'),('original_review_sha256','review/SEALED_INDEPENDENT_REVIEW.md'),('original_review_manifest_sha256','provenance/REVIEW_ORIGINAL_MANIFEST.json')]:require(s[k]==PINNED[p],'scope anchor')
 ledger=readjson(root/'provenance/EXPORT_ROUTES.json');keys(ledger,('schema_version','policy','routes'),'export ledger')
 require(type(ledger['schema_version'])is int and ledger['schema_version']==1 and type(ledger['policy'])is str and type(ledger['routes'])is list,'ledger schema')
 seen=set();destinations=set();originals={}
 for e in ledger['routes']:
  keys(e,('source_set','original_route','original_bytes','original_sha256','export_route','export_bytes','export_sha256','mode','reason','changes'),'route record')
  route(e['original_route'],'original');integer(e['original_bytes'],'original size');digest(e['original_sha256'],'original')
  require(e['original_route'] not in seen,'duplicate original route');seen.add(e['original_route']);originals[e['original_route']]=e
  require(e['source_set']==e['original_route'].split('/',1)[0] and type(e['reason'])is str and e['reason'],'source set/reason')
  require(type(e['changes'])is list,'projection list')
  if e['mode']=='excluded':
   require(e['export_route'] is None and e['export_bytes'] is None and e['export_sha256'] is None and e['changes']==[],'excluded route');continue
  require(e['mode'] in ('verbatim','public_projection'),'export mode');route(e['export_route'],'export');integer(e['export_bytes'],'export size');digest(e['export_sha256'],'export')
  require(e['export_route'] not in destinations,'duplicate export route');destinations.add(e['export_route'])
  raw=(root/e['export_route']).read_bytes();require(len(raw)==e['export_bytes'] and hashbytes(raw)==e['export_sha256'],'export binding')
  if e['mode']=='verbatim':require(e['original_bytes']==e['export_bytes'] and e['original_sha256']==e['export_sha256'] and e['changes']==[],'verbatim identity')
  else:
   require(e['original_sha256']!=e['export_sha256'] and e['changes'],'projection difference')
   lines=raw.decode().splitlines(keepends=True)
   for d in e['changes']:
    keys(d,('operation','original_lines','export_lines','original_segment_sha256','export_segment_sha256'),'change')
    require(d['operation'] in ('insert','delete','replace'),'change operation')
    for key in ('original_lines','export_lines'):
     require(type(d[key])is list and len(d[key])==2 and all(type(v)is int for v in d[key]) and d[key][0]>=1 and d[key][1]>=d[key][0]-1,'line range')
    digest(d['original_segment_sha256'],'original segment');digest(d['export_segment_sha256'],'export segment')
    lo,hi=d['export_lines'];require(hashbytes(''.join(lines[lo-1:hi]).encode())==d['export_segment_sha256'],'projection segment')
 for prefix,mfpath in [('author_v2','provenance/AUTHOR_ORIGINAL_MANIFEST.json'),('fresh_review','provenance/REVIEW_ORIGINAL_MANIFEST.json')]:
  om=readjson(root/mfpath)
  for e in om['files']:
   route(e['path'],'frozen route');integer(e['bytes'],'frozen bytes');digest(e['sha256'],'frozen digest')
   r=originals.get(prefix+'/'+e['path']);require(r is not None,'unaccounted frozen member');require(r['original_bytes']==e['bytes'] and r['original_sha256']==e['sha256'],'original manifest binding')
 binding=readjson(root/'review/V2_BINDING_PUBLIC.json')
 require(binding['status']=='SCOPED_ACCEPT' and binding['candidate_proof_sha256']==PINNED['result/PROOF.md'] and binding['candidate_manifest_sha256']==PINNED['provenance/AUTHOR_ORIGINAL_MANIFEST.json'],'v2 acceptance binding')
 require(type(binding['manifest_entries_verified'])is int and binding['manifest_entries_verified']==20 and binding['outstanding_mandatory_repairs']==[],'v2 repairs')
 privacy(root)
 return {'status':'PASS','inventory_files':len(paths)+1,'source_routes':len(ledger['routes']),'frozen_author_members_accounted':20,'frozen_review_members_accounted':5,'privacy':'PASS','strict_types':'PASS','pinned_accepted_anchors':len(PINNED)}
def controls():
 integrity()
 outputs={}
 with tempfile.TemporaryDirectory(prefix='prony-public-replay-') as tmp:
  dst=Path(tmp)/'packet';shutil.copytree(ROOT,dst)
  # Run the public reviewer first, before any script creates a new receipt.
  proc=subprocess.run([sys.executable,str(dst/'checks/independent_checks_public.py')],capture_output=True,text=True,timeout=180)
  require(proc.returncode==0,'reviewer control failed: '+proc.stderr)
  r=readjson(dst/'checks/REPLAY_CHECK_RESULTS.json')
  require(r['status']=='PASS' and type(r['original_manifest_entries_accounted'])is int and r['original_manifest_entries_accounted']==20 and r['public_inventory_verified'] is True,'review controls result')
  require(r['candidate_proof_sha256']==PINNED['result/PROOF.md'] and r['candidate_manifest_sha256']==PINNED['provenance/AUTHOR_ORIGINAL_MANIFEST.json'],'review controls anchors')
  require(r['mandatory_specification_repairs']==[] and len(r['checks'])==4,'review checks scope')
  outputs['reviewer_math_controls']={'status':'PASS','groups':len(r['checks']),'v2_binding':'PASS'}
  proc=subprocess.run([sys.executable,str(dst/'result/checks/check_candidate.py')],capture_output=True,text=True,timeout=180)
  require(proc.returncode==0,'author control failed: '+proc.stderr)
  got=readjson(dst/'result/evidence/CONTROL_RESULTS.json');saved=readjson(ROOT/'result/evidence/CONTROL_RESULTS.json')
  versions={k:got.pop(k) for k in ('python','sympy','mpmath')}
  for k in ('python','sympy','mpmath'):saved.pop(k)
  require(strict_equal(got,saved),'replayed scientific controls differ from frozen receipt (strict types)')
  outputs['author_finite_controls']={'status':'PASS','cyclotomic_cases':len(got['exact_cyclotomic_cases']),'guard_cases':len(got['parameter_guard_cases']),'exact_N4_disks':len(got['N4_full_tolerance_exact_certificates']),'negative_certificate_cases':got['negative_root_certificate_controls'],'versions':versions,'strict_receipt_match':True}
 integrity()
 return {'status':'PASS','outputs':outputs,'inherited_controls_run':False,'exhaustive_grid_run':False,'production_executor_run':False,'package_unchanged':True}
def rewrite_manifest(root):
 mf=readjson(root/'MANIFEST.json')
 for e in mf['files']:
  p=root/e['path']
  if p.is_file():raw=p.read_bytes();e['bytes']=len(raw);e['sha256']=hashbytes(raw)
 (root/'MANIFEST.json').write_text(json.dumps(mf,indent=2)+'\n')
def tamper():
 tests=[]
 def case(name,action):
  with tempfile.TemporaryDirectory(prefix='prony-public-negative-') as tmp:
   dst=Path(tmp)/'packet';shutil.copytree(ROOT,dst);action(dst)
   try:integrity(dst)
   except (ValueError,OSError,KeyError,TypeError,json.JSONDecodeError):tests.append({'name':name,'rejected':True});return
   raise ValueError('tamper accepted: '+name)
 def change_manifest(root,key,value):
  d=readjson(root/'MANIFEST.json');d['files'][0][key]=value;(root/'MANIFEST.json').write_text(json.dumps(d))
 def change_scope(root,key,value):
  d=readjson(root/'SCOPE.json');d[key]=value;(root/'SCOPE.json').write_text(json.dumps(d));rewrite_manifest(root)
 def duplicate(root):
  p=root/'SCOPE.json';p.write_text(p.read_text().replace('"schema_version": 1,','"schema_version": 1, "schema_version": 1,',1));rewrite_manifest(root)
 def leak(root):
  (root/'README.md').write_text((root/'README.md').read_text()+'\n/'+ 'workspace'+'/not-public\n');rewrite_manifest(root)
 case('changed proof byte',lambda r:(r/'result/PROOF.md').write_bytes((r/'result/PROOF.md').read_bytes()+b' '))
 case('missing source',lambda r:(r/'sources/SCOPED_THEOREMS.md').unlink())
 case('unlisted file',lambda r:(r/'EXTRA.txt').write_text('extra'))
 case('nested unlisted manifest',lambda r:((r/'nested').mkdir(),(r/'nested/MANIFEST.json').write_text('{}')))
 case('boolean masquerades as byte count',lambda r:change_manifest(r,'bytes',True))
 case('string masquerades as byte count',lambda r:change_manifest(r,'bytes','1'))
 case('negative byte count',lambda r:change_manifest(r,'bytes',-1))
 case('upper-case hash',lambda r:change_manifest(r,'sha256','A'*64))
 case('absolute member route',lambda r:change_manifest(r,'path','/escape'))
 case('unsafe relative route',lambda r:change_manifest(r,'path','../escape'))
 case('duplicate JSON keys after rehash',duplicate)
 case('boolean schema version after rehash',lambda r:change_scope(r,'schema_version',True))
 case('bit lower bound asserted after rehash',lambda r:change_scope(r,'inherent_bit_lower_bound',True))
 case('changed conditioning statement after rehash',lambda r:change_scope(r,'conditioning_bound','polynomial'))
 case('zero masquerades as false after rehash',lambda r:change_scope(r,'faster_fft',0))
 case('widened all-even claim after rehash',lambda r:change_scope(r,'all_even_squarefreeness',True))
 case('wrong setup complexity after rehash',lambda r:change_scope(r,'cold_preparation','polynomial'))
 case('private machine locator after rehash',leak)
 def anchor(root):
  p=root/'result/PROOF.md';p.write_bytes(p.read_bytes()+b' ');rewrite_manifest(root)
 case('modified accepted anchor after rehash',anchor)
 def symlink(root):
  p=root/'README.md';p.unlink();p.symlink_to('ATTRIBUTION.md')
 case('symlink substitution',symlink)
 integrity()
 return {'status':'PASS','negative_cases':len(tests),'cases':tests,'package_unchanged':True}
def main():
 p=argparse.ArgumentParser();p.add_argument('--integrity-only',action='store_true');p.add_argument('--controls',action='store_true');p.add_argument('--tamper-tests',action='store_true');a=p.parse_args()
 result={'integrity':integrity()}
 if a.controls:result['controls']=controls()
 if a.tamper_tests:result['tamper_tests']=tamper()
 print(json.dumps(result,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as exc:print('FAIL: '+str(exc),file=sys.stderr);sys.exit(1)
