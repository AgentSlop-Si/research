#!/usr/bin/env python3
"""Fresh independent controls; symbolic identities and finite diagnostic scope only."""
import json, hashlib, math
from fractions import Fraction
from pathlib import Path
import sympy as sp

OUT=Path(__file__).resolve().parent
Q=sp.Symbol('q'); X=sp.Symbol('x')

class Ring:
    def __init__(self,N):
        p=sp.Poly(sp.cyclotomic_poly(N,Q),Q)
        self.N=N; self.phi=[int(p.nth(i)) for i in range(p.degree()+1)]; self.d=p.degree()
        self.zero=(0,)*self.d; self.one=(1,)+(0,)*(self.d-1)
        self.powers=[self.one]
        for _ in range(1,N): self.powers.append(self.reduce((0,)+self.powers[-1]))
    def reduce(self,a):
        a=list(a)+[0]*max(0,self.d-len(a))
        for k in range(len(a)-1,self.d-1,-1):
            c=a[k]
            if c:
                for j in range(self.d): a[k-self.d+j]-=c*self.phi[j]
        return tuple(a[:self.d])
    def add(self,a,b): return tuple(x+y for x,y in zip(a,b))
    def neg(self,a): return tuple(-x for x in a)
    def mul(self,a,b):
        r=[0]*(2*self.d-1)
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b): r[i+j]+=x*y
        return self.reduce(r)
    def power(self,e): return self.powers[e%self.N]
    def gaussian(self,h):
        c=[self.one]
        for n in range(1,h+1):
            old=c;c=[]
            for j in range(n+1):
                a=old[j] if j<len(old) else self.zero
                b=self.mul(self.power(n-j),old[j-1]) if j else self.zero
                c.append(self.add(a,b))
        return c

symbolic=[]
for h in range(2,33):
    r=Ring(2*h); C=r.gaussian(h)
    R=[r.one]
    for k in range(h):
        new=[r.zero]*(len(R)+1)
        for j,a in enumerate(R):
            new[j]=r.add(new[j],r.neg(r.mul(a,r.power(k))))
            new[j+1]=r.add(new[j+1],a)
        R=new
    P=[r.mul(a,r.power(h*(h-1)//2-j*(j-1)//2)) for j,a in enumerate(R)]
    assert all(P[j]==r.neg(r.mul(C[j],r.power(j))) for j in range(h+1))
    assert P[-1]==r.one and P[0]==r.neg(r.one)
    assert C==C[::-1]
    for j in range(h+2):
        lhs=r.mul(C[j],r.power(j)) if j<=h else r.zero
        rhs=C[j] if j<=h else r.zero
        if j:
            rhs=r.add(rhs,r.neg(C[j-1]));rhs=r.add(rhs,r.neg(r.mul(C[j-1],r.power(1-j))))
        assert lhs==rhs,(h,j,'full q-difference')
    row={'h':h,'N':2*h,'cyclotomic_degree':r.d,'normalization':True,'reciprocity':True,'full_q_difference_through_degree_h_plus_1':True}
    if h%2:
        assert all(all(a%2==0 for a in C[j]) for j in range(1,h))
        phi=sp.Poly(sp.cyclotomic_poly(2*h,Q),Q,modulus=2)
        order_controls=[]
        for d in sp.divisors(h):
            if d<h:
                gd=sp.gcd(phi,sp.Poly(Q**d-1,Q,modulus=2)).degree()
                assert gd==0
                order_controls.append({'proper_divisor':int(d),'gcd_degree':int(gd)})
        hb=sp.Poly(1+X**h,X,modulus=2)
        assert sp.gcd(hb,hb.diff()).degree()==0
        row.update(mod_2_reduction='1+x^h',mod_2_ordinary_derivative_gcd_degree=0,exact_residue_order_controls=order_controls)
    symbolic.append(row)


def trim(a):
    while len(a)>1 and a[-1]==0:a.pop()
    return a

def prem(a,b,p):
    a=trim(list(a)); b=trim(list(b)); inv=pow(b[-1],-1,p)
    while len(a)>=len(b) and a!=[0]:
        k=len(a)-len(b);c=a[-1]*inv%p
        for i,v in enumerate(b):a[i+k]=(a[i+k]-c*v)%p
        trim(a)
    return a

def pgcd(a,b,p):
    a=trim(list(a));b=trim(list(b))
    while b!=[0]:a,b=b,prem(a,b,p)
    return [(v*pow(a[-1],-1,p))%p for v in a]

finite=[]
for h in list(range(2,129))+[191,192,255,256,511,512]:
    N=2*h;k=max(1,100000//N)
    while not sp.isprime(k*N+1):k+=1
    p=k*N+1;g=int(sp.primitive_root(p));q=pow(g,(p-1)//N,p)
    assert pow(q,h,p)==p-1
    assert all(pow(q,N//int(r),p)!=1 for r in sp.factorint(N))
    C=[1]
    for n in range(1,h+1):
        old=C;C=[((old[j] if j<len(old) else 0)+(pow(q,n-j,p)*old[j-1] if j else 0))%p for j in range(n+1)]
    D=[j*C[j]%p for j in range(1,h+1)]
    F=[1]+[0]*(N-1)+[1]
    forbidden=pgcd(C,F,p);derivative=pgcd(C,D,p)
    assert len(forbidden)==1
    # This finite squarefreeness control is not used as an all-h theorem.
    finite.append({'h':h,'N':N,'p':p,'q_image':q,'forbidden_gcd_degree':len(forbidden)-1,'ordinary_derivative_gcd_degree':len(derivative)-1})

valuation=[]
for m in range(1,64,2):
    h=2*m
    def vf(r):
        if r%m:return Fraction(0)
        t=r//m
        assert t in (1,2)
        return Fraction(1,2) if t==1 else Fraction(1)
    v=[Fraction(0)]
    for j in range(1,h):
        v.append(sum((vf(r) for r in range(h-j+1,h+1)),Fraction(0))-sum((vf(r) for r in range(1,j+1)),Fraction(0)))
    v.append(Fraction(0))
    assert all(v[j]==(Fraction(1,2) if j==m else Fraction(1)) for j in range(1,h))
    def v2(j):
        n=0
        while j%2==0:n+=1;j//=2
        return n
    deriv=[Fraction(v2(j))+v[j] for j in range(1,h+1)]
    minimum=min(deriv); minimizers=[j for j in range(1,h+1) if deriv[j-1]==minimum]
    assert minimum==Fraction(1,2) and minimizers==[m]
    valuation.append({'m':m,'h':h,'N':2*h,'central_coefficient_valuation':'1/2','other_interior_valuation':'1','derivative_unique_minimum_index':m,'derivative_minimum_valuation':'1/2'})

k,t,theta=sp.symbols('k t theta', real=True)
f=lambda j: j*t/2+j*j*theta/4
assert sp.expand(f(k+1)-f(k) - ((t+k*theta)/2+theta/4))==0
assert sp.expand(t+k*theta+f(k-1)-f(k) - ((t+k*theta)/2+theta/4))==0
arc_count=0
for h in range(2,65):
    for a in range(h):
        tpi=Fraction(2*a+1,2*h); L=2*h-(2*a+1)
        assert 0<tpi<1 and L%2==1 and 1<=L<2*h
        assert tpi+Fraction(L,h)==2-tpi
        assert all(0<tpi+Fraction(j,h)<2 for j in range(L+1))
        arc_count+=1
result={'exact_gauge_exponent_identities':True,'exact_reciprocal_arc_cases':arc_count,'symbolic_cyclotomic_controls':symbolic,'finite_prime_diagnostics':finite,'h_twice_odd_valuation_controls':valuation,'limitations':['Finite prime squarefreeness results do not establish uniform all-even squarefreeness.','The h=2m valuation controls check the counting algebra, not the independent proof that root valuations are zero.','No supplied executable was run.']}
p=OUT/'control_results.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'symbolic_h_range':[2,32],'symbolic_cases':len(symbolic),'finite_diagnostic_cases':len(finite),'finite_squarefree_failures':[r for r in finite if r['ordinary_derivative_gcd_degree']],'twice_odd_valuation_cases':len(valuation),'output':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
