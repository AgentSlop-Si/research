# Ordinary squarefreeness when h is four times an odd integer

Frozen candidate, 20 October 2026. This addendum is separate from the frozen core theorem. It requires fresh adversarial review and does not claim all-even optimality.

## Statement

Let m>=1 be odd, h=4m, and q be any primitive root of order 2h=8m in characteristic zero. Then the Rogers–Szegő polynomial

H_h(x;q)=sum_{j=0}^h C_j x^j,  C_j=[h choose j]_q,

is squarefree for the ordinary derivative. Thus P_h(z)=-H_h(qz;q) is squarefree for N=8m, and the separate all-even legality theorem implies Q_min=h for every N congruent to 8 modulo 16 in the original common-T model.

This proof is a new contribution of the core author. It builds on the audit partner's separately attributed h=2m valuation method but adds a distinct residue-class cancellation. It is not part of that partner's independent core audit.

## 1. Valuations and residues of the coefficients

Choose a prime above 2 in K=Q(q), extend its valuation to an algebraic closure, and normalize v(2)=4. Write bars for residues. Then qbar has exact order m: modulo 2 the identity Phi_{8m}(X)=Phi_{2m}(X^4) becomes Phi_m(X)^4, and the factors of X^m-1 are pairwise coprime because m is odd.

For 0<r<h,

v(1-q^r)=0 if m does not divide r,
v(1-q^m)=v(1-q^{3m})=1,
v(1-q^{2m})=2.

These are the standard primitive eighth-root and fourth-root valuations, which also follow from (1-i)^2=-2i and (1-zeta_8)(1+zeta_8)=1-i, with equal valuations of 1-zeta_8 and 1+zeta_8. In particular pi=1-q^m has valuation 1.

The Gaussian product can be rewritten exactly as

C_j = 2/(1-q^j) product_{r=1}^{j-1} [(1+q^{-r})/(1-q^r)],  0<j<h.       (1)

Every quotient in (1) is a unit. If m does not divide r, numerator and denominator are units directly. If m divides r, q^r has order 4 or 8, and the numerator and denominator have equal positive valuations. Consequently

v(C_j)=4 when m does not divide j,
v(C_m)=v(C_{3m})=3,
v(C_{2m})=2.                                                        (2)

For m not dividing j, division by 2 leaves an integral unit, whose residue is

bar(C_j/2)=qbar^{-j(j-1)/2}/(1-qbar^j).                              (3)

Indeed each quotient in (1) reduces to qbar^{-r}. This is immediate when m does not divide r. When m divides r, its residue is 1=qbar^{-r}: writing a=q^r, the difference between (1+a^{-1})/(1-a) and -a^{-1} is 2a^{-1}/(1-a), of positive valuation, because v(1-a) is 1 or 2, strictly less than v(2)=4. Summing the exponents gives (3).

The right side of (3) is periodic in j modulo m. For the exponent, the change under j -> j+m is m[j+(m-1)/2], a multiple of m because m is odd. The denominator is also periodic.

## 2. Valuation of a root near its residue class

Let alpha be any root of H_h. Since H_h is monic with constant coefficient 1 and integral coefficients, v(alpha)=0: a negative valuation makes its leading term uniquely smallest, and a positive valuation makes its constant term uniquely smallest.

All interior C_j have positive valuation by (2), so H_h reduces to 1+x^{4m}=(1+x^m)^4. Therefore alphabar^m=1. Set

t=alpha^m,  y=t+1,  w=v(y)>0.

By Gaussian symmetry C_{3m}=C_m. The root equation is

0=1+t^4+C_m(t+t^3)+C_{2m}t^2+E,

where E is the sum of terms with indices not divisible by m, hence v(E)>=4. The middle term C_{2m}t^2 has valuation 2, whereas C_m(t+t^3) has valuation at least 3. Thus

v(1+t^4)=2.                                                        (4)

Expanding t=y-1 gives

1+t^4=y^4-4y^3+6y^2-4y+2.

The displayed term valuations are 4w, 8+3w, 4+2w, 8+w, and 4. If w>=1 they are all at least 4, contradicting (4). If 0<w<1, the first term is uniquely smallest, so (4) implies 4w=2. Hence

v(t+1)=1/2.                                                       (5)

## 3. The ordinary derivative cannot vanish

Evaluate alpha H_h'(alpha), where the prime is the ordinary derivative. The j=m and j=3m terms combine to

A=m C_m t(1+3t^2).

Because t=y-1,

1+3t^2=4-6y+3y^2.

Using (5), these three terms have valuations 8, 9/2, and 1, respectively. Thus v(1+3t^2)=1 and

v(A)=4.                                                          (6)

The remaining positive multiples of m contribute 2m C_{2m}t^2 and 4m t^4, of valuations 6 and 8.

It remains to show that the nonmultiple contribution

S=sum_{1<=j<4m, m not dividing j} j C_j alpha^j

has valuation strictly greater than 4. Divide by 2 and use (3). In the residue field,

bar(S/2)=sum_{m not dividing j} bar(j) qbar^{-j(j-1)/2} alphabar^j/(1-qbar^j).

For each residue r=1,...,m-1 modulo m, the four indices are r, r+m, r+2m, r+3m. The factor other than bar(j) is the same at all four, by the periodicity after (3) and alphabar^m=1. Exactly two of the four indices are odd, because m is odd. Their total in characteristic 2 is zero. Hence bar(S/2)=0, so

v(S)>4.                                                          (7)

For m=1, the sum is empty and (7) is interpreted as v(0)=+infinity.

Equations (6)-(7) make A the unique lowest-valuation contribution to alpha H_h'(alpha). It cannot cancel, so H_h'(alpha)!=0. Every root is simple. The scalar and argument change to P_h preserves squarefreeness. QED.

## 4. Scope and charged costs

The underlying polynomial, moments, node restrictions, and reconstruction are exactly those of SCOPED_THEOREMS.md Sections 1 and 4. Combined with its all-even forbidden-node theorem and the audit partner's separate h=2m lemma, these results establish Q_min=h for all even N not divisible by 16. The residual all-even gate is ordinary squarefreeness when 8 divides h (equivalently 16 divides N), except at any separately accepted finite instances.

No result about 8|h is proved by this addendum. In particular, the residue cancellation here is not asserted to iterate indefinitely. Existing preparation, application, conditioning, and complexity charges are unchanged.
