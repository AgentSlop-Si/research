#!/usr/bin/env python3
"""Independent controls for a uniform proof; finite cases are diagnostics only."""
import hashlib, json
from fractions import Fraction
from pathlib import Path
import sympy as s
OUT=Path(__file__).resolve().parent
q,x,a,y,j,m=s.symbols('q x a y j m')
checks={}
assert s.cancel((1+a**-1)/(1-a)+a**-1-2*a**-1/(1-a))==0
checks['mixed_characteristic_ratio_difference']=True
assert s.expand(((j+m)*(j+m-1)-j*(j-1))/2-m*(j+(m-1)/2))==0
checks['exact_periodicity_exponent_difference']=True
assert s.expand(1+(y-1)**4-(y**4-4*y**3+6*y**2-4*y+2))==0
assert s.expand(1+3*(y-1)**2-(4-6*y+3*y**2))==0
checks['root_and_ordinary_derivative_expansions']=True
assert s.expand((1-a)**2-(1+a*a-2*a))==0
assert s.expand((1+a)**2-(1+a*a+2*a))==0
checks['eighth_root_valuation_auxiliary_identities']=True


def coeffs(n, order):
    modulus=s.Poly(s.cyclotomic_poly(order,q),q,domain=s.ZZ)
    zero=s.Poly(0,q,domain=s.ZZ)
    one=s.Poly(1,q,domain=s.ZZ)
    powers=[one]
    for k in range(1,n+1):
        powers.append((powers[-1]*s.Poly(q,q,domain=s.ZZ)).rem(modulus))
    row=[one]
    for k in range(1,n+1):
        row=[((row[r] if r<k else zero)+(powers[k-r]*row[r-1] if r else zero)).rem(modulus) for r in range(k+1)]
    return modulus,row


def mod2(p, modulus):
    return s.Poly(p,q,modulus=2).rem(modulus)


def norm_v(p, modulus):
    z=abs(int(s.resultant(p.as_expr(),modulus.as_expr(),q)))
    assert z
    n=0
    while z%2==0:
        z//=2;n+=1
    return Fraction(4*n,modulus.degree())

finite=[]
for odd in [1,3,5,9,15]:
    h=4*odd; order=8*odd
    modulus,C=coeffs(h,order)
    residual=s.Poly(s.cyclotomic_poly(odd,q),q,modulus=2)
    assert s.Poly(modulus.as_expr(),q,modulus=2)==residual**4
    assert C==C[::-1]
    residues={}
    sums=[s.Poly(0,q,modulus=2) for r in range(odd)]
    verified=0
    for r in range(1,h):
        if r%odd==0:continue
        assert all(int(v)%2==0 for v in C[r].all_coeffs())
        half=s.Poly(C[r].as_expr()/2,q,domain=s.ZZ)
        actual=mod2(half.as_expr(),residual)
        e=(-r*(r-1)//2)%odd
        expected=(s.Poly(q**e,q,modulus=2)*s.invert(s.Poly(1-q**(r%odd),q,modulus=2),residual)).rem(residual)
        assert actual==expected
        residues[r]=actual
        sums[r%odd]=(sums[r%odd]+(r%2)*actual).rem(residual)
        verified+=1
    assert all(v.is_zero for v in sums)
    for r in range(1,odd):
        assert len({str(residues[r+k*odd].as_expr()) for k in range(4)})==1
        # Deliberately omit two classes: the remaining two do NOT cancel.
        assert not ((r%2)*residues[r]+((r+odd)%2)*residues[r+odd]).rem(residual).is_zero
    norms=[]
    if odd<=5:
        for r in range(1,h):
            expected=Fraction(4) if r%odd else Fraction(2 if r==2*odd else 3)
            actual=norm_v(C[r],modulus)
            assert actual==expected,(odd,r,actual,expected)
            norms.append({'j':r,'four_times_2_adic_norm_average':str(actual)})
    finite.append({'m':odd,'h':h,'N':order,'cyclotomic_degree':modulus.degree(),'coefficient_residue_checks':verified,'four_class_log_derivative_cancellation':True,'two_class_negative_control':odd>1,'norm_controls':norms})

# If m=2 is improperly admitted, q has order 16 and C_1 has valuation 7/2,
# not 4 under the candidate's v(2)=4 normalization. Its residue order is 1,
# not m=2. This is an exact countercontrol against that proof extension.
modulus,C=coeffs(8,16)
assert norm_v(C[1],modulus)==Fraction(7,2)
assert s.Poly(modulus.as_expr(),q,modulus=2)==s.Poly((q+1)**8,q,modulus=2)
checks['even_m_countercontrol']={'m':2,'h':8,'N':16,'C_1_valuation':'7/2','incorrect_odd_m_formula_would_give':'4','q_residue_order':1}

p=OUT.parent/'proof'/'FOUR_TIMES_ODD_SQUAREFREE_ADDENDUM.md'
hashvalue=hashlib.sha256(p.read_bytes()).hexdigest()
assert hashvalue=='899e7c94a7389f48a51f140fe3a3127900cb4838511f1c8d8087141b882d65bc'
result={'candidate_sha256':hashvalue,'universal_symbolic_controls':checks,'finite_exact_diagnostics':finite,'scope_warning':'The finite diagnostics are not an extrapolative proof; the audit accepts the explicit all-odd-m valuation argument.'}
(OUT/'CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','candidate_sha256':hashvalue,'odd_m_cases':[r['m'] for r in finite],'residue_checks':sum(r['coefficient_residue_checks'] for r in finite),'norm_checks':sum(len(r['norm_controls']) for r in finite),'even_m_countercontrol':checks['even_m_countercontrol']},indent=2))
