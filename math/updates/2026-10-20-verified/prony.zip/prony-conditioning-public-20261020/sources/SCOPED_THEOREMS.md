# Uniform legality and the odd-half-size exact Prony theorem

20 October 2026. Frozen candidate for fresh adversarial review, not an all-even optimality claim.

## Scope and conclusions

Let N=2h>=4, let q be any primitive Nth root in characteristic zero, and let c_j=q^{j(j-1)/2}. For the fixed common-generator model with T^N=-I, admissible nodes are distinct, nonzero, and satisfy alpha^N != -1; all weights must be nonzero and all N moments must match.

Write

R_h(z)=product_{k=0}^{h-1}(z-q^k)=sum_j r_j z^j,
P_h(z)=sum_{j=0}^h (c_h/c_j)r_j z^j,
H_h(x;q)=sum_{j=0}^h C_j x^j,  C_j=[h choose j]_q.

This packet proves:

1. For every h>=2 and every primitive q of order 2h, gcd(P_h,z^{2h}+1)=1.
2. For every odd h>=3 and every such q, gcd(P_h,P_h')=1, where the prime is the ordinary formal derivative.
3. Consequently the original minimum admissible common-T pole count is exactly h for every N=2h with h odd (equivalently N=2 mod 4, N>=6).

For even h, ordinary squarefreeness is NOT proved here. The accepted general bound h<=Q_min<=h+1 remains in force. There is no complexity, conditioning, general-circuit, publication-priority, or faster-FFT claim.

## 1. Exact normalization and recurrence

The finite product expansion gives

r_j=(-1)^{h-j}q^{(h-j)(h-j-1)/2} C_j.

Therefore

(c_h/c_j)r_j=(-1)^{h-j}q^{h(h-1)-j(h-1)}C_j.

Since q^h=-1, (-1)^h q^{h(h-1)}=-1 and -q^{-(h-1)}=q. Hence

P_h(z)=-H_h(qz;q).

In particular P_h is monic (its leading coefficient is -q^h=1), and P_h(0)=-1. Gaussian symmetry C_j=C_{h-j} gives the polynomial reciprocity identity

H_h(x;q)=x^h H_h(x^{-1};q).

For 1<=j<=h the Gaussian product formula yields

(1-q^j) C_j=(1-q^{h-j+1}) C_{j-1}=(1+q^{1-j}) C_{j-1}.

Comparing coefficients, including degrees 0 and h+1, gives

H_h(qx;q)=(1-x)H_h(x;q)-x H_h(q^{-1}x;q).                 (1)

Equation (1) is an exact polynomial finite-difference identity. It is not a statement about ordinary derivatives, and no simplicity conclusion is extracted from a q-derivative.

## 2. Uniform exclusion of every forbidden node

First take the principal embedding q=exp(i theta), theta=pi/h. Suppose H_h(x;q)=0 and x^{2h}=-1. Reciprocity supplies H_h(x^{-1};q)=0. Neither x nor x^{-1} is 1 or -1. By replacing x with x^{-1} if necessary, write

x=exp(it),  0<t<pi,  t=(2k+1)pi/(2h).

Let L=2h-(2k+1). Then L is a positive odd integer smaller than 2h and

x q^L=x^{-1},
0<t+j theta<2pi  for 0<=j<=L.

Set H_j=H_h(xq^j;q) and

u_j=exp[-i(jt/2+j^2 theta/4)] H_j.

The endpoints satisfy u_0=u_L=0. For 1<=j<=L-1, substitute the gauge into (1). The two neighboring terms have the same phase exp[i(t+j theta)/2+i theta/4], and so

u_{j+1}+u_{j-1}=lambda sin((t+j theta)/2) u_j,
lambda=-2i exp(-i theta/4).                              (2)

The imaginary part of lambda is -2cos(theta/4), which is nonzero. Every displayed sine is strictly positive.

If L>=3, multiply (2) by conjugate(u_j) and sum over the interior indices. Its left side is

2 Re sum_{j=1}^{L-2} conjugate(u_j)u_{j+1},

which is real. Taking imaginary parts therefore shows

sum_{j=1}^{L-1} sin((t+j theta)/2)|u_j|^2=0.

Thus all interior u_j vanish. If L=1, the two endpoints were already consecutive zeros. In either case H_j and H_{j+1} vanish for some adjacent indices. Equation (1), and xq^j!=0, propagate the zero in both directions around the q-orbit. This would give 2h distinct roots of a nonzero degree-h polynomial, impossible. Therefore

gcd(H_h(x;q),x^{2h}+1)=1

at the principal embedding. The change x=qz preserves the forbidden equation because q^{2h}=1, giving the corresponding assertion for P_h.

For another primitive q, choose a cyclotomic Galois automorphism mapping the principal root to q. The coefficients of H_h and P_h lie in the cyclotomic field, and the forbidden polynomial has rational coefficients. Applying that automorphism to a Bezout identity (or to the nonzero resultant) preserves coprimality. This proves the statement for every primitive q, and hence over every characteristic-zero field containing such q.

## 3. Ordinary squarefreeness when h is odd

Assume h is odd. Then K=Q(q)=Q(zeta_h), and Phi_{2h}(X)=Phi_h(-X). Choose any prime of its integer ring above 2 and reduce q to qbar in its residue field.

The reduction qbar has exact order h. Indeed modulo 2 the polynomial Phi_{2h} equals Phi_h, while X^h-1 is squarefree because h is odd. Its integral cyclotomic factorization reduces to pairwise coprime factors, so a root of the reduced Phi_h cannot be a root of X^d-1 for any proper divisor d of h.

For 0<j<h, the Gaussian product

C_j=product_{r=0}^{j-1}(1-q^{h-r}) / product_{r=1}^{j}(1-q^r)

has a zero numerator factor 1-qbar^h and no zero denominator factor on reduction. Hence C_j reduces to zero, while C_0=C_h=1. Thus

H_h(x;q) mod p = 1+x^h.

Its ordinary derivative in characteristic 2 is x^{h-1}, since h is odd. These two polynomials are coprime. Consequently the ordinary resultant Res(H_h,H_h') is nonzero in characteristic zero. Equivalently H_h is squarefree. This argument uses monicity, so no degree-drop issue occurs for H_h; the derivative retains degree h-1 because h is odd.

The scalar and nonzero argument change P_h(z)=-H_h(qz;q) preserve squarefreeness.

## 4. Full original-model realization and nonzero weights

The accepted Hankel determinant formula is

Delta_h=det[c_{r+s}]_{0<=r,s<h}
=q^{h(h-1)(h-2)/2} product_{d=1}^{h-1}(q^d-1)^{h-d} !=0.

The defining P_h satisfies, for 0<=s<h,

sum_{j=0}^h [z^j]P_h(z) c_{s+j}=c_h c_s R_h(q^s)=0.

For odd h, let alpha_1,...,alpha_h be its roots. The preceding theorems show that they are distinct, nonzero, and avoid alpha^{2h}=-1. Solve the invertible h-node Vandermonde system

c_j=sum_{ell=1}^h beta_ell alpha_ell^j,  0<=j<h.

Both sides obey the monic P_h recurrence, so induction gives all required moments 0<=j<2h. None of the beta_ell can vanish: otherwise the same moments would have a representation by at most h-1 nodes, making the h-by-h Hankel matrix rank at most h-1, contrary to Delta_h!=0.

For the original fixed T, define gamma_ell=beta_ell(1+alpha_ell^{2h}). These weights are nonzero and each inverse exists. Then

sum_{j=0}^{2h-1} c_j T^j
=sum_{ell=1}^h gamma_ell (I-alpha_ell T)^{-1},

by the finite geometric identity for T^{2h}=-I. The matching lower bound is the same Hankel-rank argument, so Q_min=h in precisely the announced odd-h scope. No change of generator or of moment list is made.

## 5. Independent odd-h legality cross-check and attribution

The initial research contributor supplied the initial observation that an unramified 2-adic splitting field would exclude forbidden roots for odd h. The author converted this into the following valuation proof, and the algebra auditor separately checked it before this packet was frozen.

Normalize an extension of a prime-above-2 valuation by v(2)=1. For odd h, all 1-q^r with 1<=r<h are units. Thus each interior C_j has v(C_j)>=1. If x^{2h}=-1, then x^h=+i or -i, so

(1+x^h)^2=+2i or -2i,
v(1+x^h)=1/2.

Every interior term C_j x^j has valuation at least 1, since x is a root of unity. The endpoint sum 1+x^h has uniquely smaller valuation and cannot cancel them. This independently proves the forbidden-node statement for odd h. It is superseded in scope by Section 2, but its contributed origin is retained honestly.

The Section 2 Dirichlet-gauge argument and Section 3 reduction argument were developed by the author; the algebra auditor independently checked their algebra. That audit is not the fresh post-freeze adversarial review requested for acceptance. No other proof contribution is silently incorporated.

## 6. Source binding and limitations

Original model and half-pole lower bound: sources/PHASE21_THEOREM.md Sections 0-3A.
Accepted all-even h<=Q_min<=h+1 theorem and determinant: sources/P02_ACCEPTED.md Section B.
Definition and recurrence construction: sources/ORIGINAL_PENCIL_EXTENSION.md Sections 1-5 and 7.
Latest scope boundary: historical/large-t/HISTORICAL_PREPARATION_REVIEW.md Section 8.

All new arguments above are explicit. No real-q orthogonality theorem is imported at nonreal q. Prior finite dyadic certificates are not reused as uniform evidence, and no broader optimality conclusion is drawn.
