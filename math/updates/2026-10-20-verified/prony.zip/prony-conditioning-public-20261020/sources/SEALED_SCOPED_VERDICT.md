# Sealed adversarial verdict: even-cycle Prony subfamilies

20 October 2026. Fresh source-bound mathematical review. This verdict accepts the scope below and does not close the all-even ordinary-squarefreeness question.

## 1. Verdict and exact accepted scope

**PASS, at the stated scope.** For N=2h>=4, q primitive of order N in characteristic zero, and the original moments c_j=q^{j(j-1)/2}, the reviewed arguments establish:

1. The original monic recurrence polynomial P_h(z)=-H_h(qz;q) satisfies gcd(P_h,z^N+1)=1 for every even N.
2. P_h is ordinary squarefree when h is odd, and separately when h=2m with m odd.
3. Hence the original minimum admissible common-generator pole count is Q_min=N/2 for every even N>=4 with 8 not dividing N. The representation has distinct nonzero nodes, nonzero moment weights, nonzero resolvent weights, and matches every one of the N original moments.
4. For 8 dividing N, the accepted bound remains N/2<=Q_min<=N/2+1. Uniform ordinary squarefreeness remains open in this reviewed packet. Uniform forbidden-node avoidance is no longer the missing condition.

Roots and weights may be taken in an algebraic closure, as in the accepted construction. No claim of roots in the original coefficient field is added. The matrix interpretation is the original cyclic Weyl generator, whose N powers are linearly independent; the equivalent moment formulation explicitly requires all N moments. No arbitrary-generator or unrestricted-circuit lower bound is asserted.

## 2. Frozen objects reviewed

The initial theorem was read only after the reviewer independently reconstructed the q-difference, reciprocal-arc, and odd-h reduction arguments from the original definitions.

- Candidate author: `proof/SCOPED_THEOREMS.md`
- SHA256: `525a566612ebf6c96f15077b2824c7f06a582d1f5f52e0c28a92f68f5c3ab2b0`
- Essential later contribution by the first algebra reviewer: `proof/HALF_ODD_SQUAREFREE_LEMMA.md`
- SHA256: `68d2c51071d7d9d7af3a1abd38fecbe95720f6e8b801160664bd9cf8499b9799`

The second frozen object was separately reviewed. Its h=2m valuation mechanism was also independently reconstructed before its text was read. This verdict does not treat that contributor's own checks as independent acceptance of their contribution.

Original source hashes:

- PHASE21_THEOREM.md: `e03f5f77ecae1791d7c1e093ba728ea642152647bb3043f9bbf55884e7232e6e`
- P02_ACCEPTED.md: `f6412a2cb78457a2fddd62a6e688095cb82528b4457ad1454dbbe069179937d6`
- ORIGINAL_PENCIL_EXTENSION.md: `d6f5ac8d0cbd7f48cf928139dd60d275c79ad7b566d3c772795bb91d0d3a4861`

These three original files are under `sources/`.

## 3. Adversarial proof checks

### 3.1 Normalization and the full q-difference identity

The defining product and chirp coefficient twist give

P_h(z)=(-1)^h q^{h(h-1)} H_h(-q^{-(h-1)}z;q)=-H_h(qz;q).

Here q^h=-1 makes the scalar exactly -1, not merely an unspecified unit. Therefore P_h is monic and P_h(0)=-1. This is precisely the old recurrence, not a renamed replacement.

For C_j=[h choose j]_q,

(1-q^j)C_j=(1+q^{1-j})C_{j-1}.

This yields the full polynomial identity

H_h(qx)=(1-x)H_h(x)-xH_h(q^{-1}x).

The top x^{h+1} term also vanishes: its coefficient is -(1+q^{-h})=0. The endpoints are not silently dropped. Symmetry C_j=C_{h-j} gives H_h(x)=x^h H_h(x^{-1}). Neither identity is a theorem about ordinary derivatives.

### 3.2 Forbidden roots, arc selection, and positive weights

Only a putative forbidden root is assumed to have complex modulus one. The proof does not assume that all polynomial roots lie on the unit circle.

At the principal embedding q=exp(i phi), phi=pi/h, reciprocity turns a forbidden zero x into a zero x^{-1}. Neither endpoint can be 1 or -1. Select the endpoint x=exp(it) with 0<t<pi; then t=(2k+1)pi/(2h). The increasing-q arc from t to 2pi-t has odd length L=2h-(2k+1), with 1<=L<2h. All its angles are strictly between 0 and 2pi, and its endpoints are distinct.

For y_j=H_h(xq^j), use

y_j=exp(i[jt/2+j^2 phi/4])u_j.

Both neighboring terms in the difference equation acquire the same phase. The interior equation is

u_{j+1}+u_{j-1}=lambda sin((t+j phi)/2)u_j,

where lambda=-2i exp(-i phi/4). Its imaginary part is nonzero, while every displayed sine is strictly positive. With Dirichlet endpoints, the path-adjacency quadratic form is real. Its imaginary part forces every interior u_j to vanish. This is equivalently a real symmetric generalized eigenproblem with a positive diagonal weight matrix.

When L=1, the endpoints themselves are adjacent zeros. In every case there are adjacent zeros. The original recurrence propagates these through the entire q-orbit because xq^j is nonzero, producing 2h distinct roots of a nonzero degree-h polynomial. This is impossible. The L=1 case and nonzero-vector issue are therefore handled without an unproved spectral assumption.

Positivity is invoked only at the principal embedding. Cyclotomic Galois conjugation of a Bezout identity or nonzero resultant extends the conclusion to every primitive q. The argument does not assert positive sine weights for arbitrary primitive embeddings.

Finally x=qz preserves x^{2h}=-1 iff z^{2h}=-1, so legality transfers to the exact original nodes.

### 3.3 Odd h: ordinary squarefreeness and characteristic-zero transfer

For odd h, reduction at a prime above 2 sends q to an element of exact order h. The point requiring justification is exact order, not merely the assertion that 2 is unramified. It follows because Phi_{2h} reduces to Phi_h and the factorization of the separable polynomial X^h-1 has pairwise coprime cyclotomic factors modulo 2.

Every interior Gaussian coefficient reduces to zero: its numerator contains 1-q^h and its denominator contains only units. Thus H_h reduces to 1+x^h. Its ordinary derivative reduces to x^{h-1}, and their gcd is 1. Monicity and the nonvanishing top derivative coefficient at odd h make the resultant transfer to characteristic zero sound, with no degree-drop shortcut. Scaling the variable by q preserves ordinary squarefreeness.

### 3.4 h=2m, m odd: independently reviewed later lemma

At a prime above 2, normalize v(2)=1. Reduction of Phi_{4m} is Phi_m^2, so q reduces to exact order m. Consequently, for 1<=d<=2m:

- v(1-q^d)=0 if m does not divide d;
- v(1-q^m)=1/2;
- v(1-q^{2m})=1.

Counting the product formula gives v(C_m)=1/2, while every other interior C_j has valuation 1. Both endpoint coefficients are 1. Every root alpha of H_h has valuation zero: a positive root valuation makes the constant term uniquely minimal, and a negative root valuation makes the monic top term uniquely minimal.

In the ordinary derivative, the term m C_m alpha^{m-1} has valuation 1/2. Every other derivative term has valuation at least 1, including the top term 2m alpha^{2m-1}. Thus the derivative cannot vanish at any root. Equivalently, H_h'/C_m reduces to x^{m-1}, which is nonzero at every residue-unit root. This does not misuse a derivative whose reduction has lower degree; the proof is a local evaluation argument, not a faulty degree-preserving discriminant claim.

The boundary m=1 is included: H_2' has its constant coefficient of uniquely minimal valuation. No assumption m>=3 is hidden. The proof applies to every primitive q. It supplies exactly N=4 mod 8, and no 4|h extension is inferred.

### 3.5 Original representation and nonzero weights

The original h-by-h Hankel determinant is nonzero. The defining P_h is the unique monic degree-h recurrence matching the original 2h moments. Once P_h is squarefree, its h roots are nonzero because P_h(0)=-1 and legal by the uniform theorem.

An invertible Vandermonde system fixes the first h moment weights. The monic recurrence then matches every remaining moment through 2h-1. If any weight vanished, the same h-by-h Hankel matrix would have rank at most h-1, a contradiction. Multiplication by 1+alpha^{2h} preserves nonzero resolvent weights because every node is legal.

The accepted lower bound and accepted h+1 construction therefore combine legitimately with these scoped theorems. The reasoning does not replace distinct ordinary poles by repeated/confluent poles, discard any target moment, or remove a cost from the computational model.

## 4. Independent exact controls

The fresh script `independent_controls.py` was authored for this review; no supplied executable was run.

- 31 exact cyclotomic-ring cases, h=2,...,32: original product-to-P normalization, monicity, constant coefficient, reciprocity, and the complete q-difference through degree h+1.
- Every odd h in that range: exact mod-2 coefficient reduction to 1+x^h, coprimality with the ordinary derivative, and exact-order checks against every proper divisor of h.
- Two symbolic gauge-exponent identities, with unrestricted symbolic index and angle parameters.
- 2,079 exact rational-angle reciprocal-arc cases for h=2,...,64: odd length, distinct endpoints, endpoint equality, and the strictly positive-sine interval.
- 32 twice-odd valuation-count cases, m=1,3,...,63: exact rational valuations and a unique minimum derivative term at j=m.
- 133 independent finite-prime diagnostics: h=2,...,128 and h in {191,192,255,256,511,512}; the forbidden gcd and ordinary-derivative gcd are both constant in every diagnostic. These finite results are explicitly not an all-h squarefreeness proof.

All controls passed. Full finite lists and parameters are in `control_results.json`. The exact theoretical arguments, not the finite diagnostics, support the uniform scope.

## 5. Attribution and release limits

The candidate text retains the initial research contributor's earlier odd-h ramification lead, rather than presenting it as the candidate author's unaided discovery. The all-even reciprocal-arc argument supersedes that lead in scope. The h=2m, m odd squarefreeness result is a separate essential contribution by the first algebra reviewer and must remain attributed as such in any combined release. This review independently validates its proof; it does not transfer authorship.

No publication-priority claim was checked. No all-even squarefreeness proof, fast pole preparation, conditioning bound, subquadratic application, faster FFT, or unrestricted DFT lower bound is accepted. No external service or repository was written during this review. The two frozen proofs were not modified.
