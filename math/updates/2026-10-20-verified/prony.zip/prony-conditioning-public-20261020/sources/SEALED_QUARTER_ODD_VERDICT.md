# Fresh independent verdict: four-times-odd Prony squarefreeness

Date: 20 October 2026. Verdict: **PASS at the precise scope below.**

## 1. Frozen object and accepted statement

Reviewed object:

- `proof/FOUR_TIMES_ODD_SQUAREFREE_ADDENDUM.md`
- SHA256: `899e7c94a7389f48a51f140fe3a3127900cb4838511f1c8d8087141b882d65bc`

The object was first supplied under the core packet's proof directory, then moved without a byte change to the separate path above. Both reads had the same hash. The review is bound to those bytes, not to later edits.

For every odd positive integer m, h=4m, and every characteristic-zero primitive 8m-th root q, the ordinary polynomial H_h(x;q)=sum_j [h choose j]_q x^j is squarefree. Thus the exact original recurrence P_h(z)=-H_h(qz;q) is ordinary squarefree for N=8m, equivalently N congruent to 8 modulo 16.

Combining this new theorem with the separately accepted uniform forbidden-node theorem and the earlier ordinary-squarefreeness results for odd h and h twice odd gives Q_min=N/2 for every even N>=4 not divisible by 16, in the original common-generator moment model. The all-even result is NOT closed: for 16|N this audit leaves the uniform bound N/2<=Q_min<=N/2+1, except for separately accepted individual cases.

The proof is a uniform mixed-characteristic valuation argument, not an extrapolation of finite checks. It uses the ordinary derivative and does not require a theorem about zeros inside a complex disk.

## 2. Independent reconstruction and substantive checks

The reviewer reconstructed the coefficient valuations, root valuation, and four-residue cancellation from the task description before reading the frozen addendum. The addendum's complete proof matches that reconstruction. No proof correction or new essential step was supplied to the author by this reviewer.

### 2.1 Residue order and valuation normalization

Fix a prime above 2 and extend its valuation to an algebraic closure, with v(2)=4. Because m is odd, reduction of Phi_(8m)(X)=Phi_(2m)(X^4) is Phi_m(X)^4. The cyclotomic factors of X^m-1 are pairwise coprime in characteristic 2. Consequently qbar has exact order m, including m=1.

Put zeta=q^m, a primitive eighth root. Then v(1-zeta)=v(1-zeta^3)=1 and v(1-zeta^2)=2. These are actual characteristic-zero valuations. To avoid assuming equality of valuations merely from residue equality, write a for either primitive eighth root. Since a^2 is a primitive fourth root, v(1+a^2)=2. The identities (1-a)^2=1+a^2-2a and (1+a)^2=1+a^2+2a have right-hand summands of unequal valuations 2 and 4, proving v(1-a)=v(1+a)=1. For a primitive fourth root, (1-a)^2=-2a proves valuation 2. Thus pi=1-q^m really has valuation 1 under the stated normalization.

If m does not divide r, qbar^r is not 1, so 1-q^r and 1+q^(-r) are both units. This exact-order point is essential for composite m as well as prime m.

### 2.2 Every coefficient valuation and its unit residue

For 0<j<h, the exact Gaussian product identity is

C_j = 2/(1-q^j) product_(r=1)^(j-1) ((1+q^(-r))/(1-q^r)).

No denominator vanishes because its exponent is strictly between 0 and the order 8m. Every factor in the product is a unit. At a multiple r of m, the possible nontrivial orders are 4 and 8 and the numerator and denominator valuations agree. Therefore

- v(C_m)=v(C_(3m))=3;
- v(C_(2m))=2;
- v(C_j)=4 at every other interior index;
- C_0=C_h=1.

For a=q^r the exact identity

(1+a^(-1))/(1-a) - (-a^(-1)) = 2a^(-1)/(1-a)

establishes the residue of the quotient even when both numerator and denominator are nonunits. Its right side has strictly positive valuation, since the denominator has valuation 0, 1, or 2. Thus every quotient reduces to qbar^(-r), because minus equals plus in the residue field. In particular, for m not dividing j,

bar(C_j/2)=qbar^(-j(j-1)/2)/(1-qbar^j),

and this is a nonzero residue. The exponent changes by m[j+(m-1)/2] on replacing j by j+m, an integer multiple of m precisely under the odd-m hypothesis. This proves the required periodicity without dividing by 2 inside a characteristic-2 field.

### 2.3 Root valuation in the actual algebraic closure

Every root alpha is a unit. If v(alpha)>0 the constant term of H_h(alpha) is uniquely minimal; if v(alpha)<0 the monic highest-degree term is uniquely minimal. Neither is possible. All interior coefficients have positive valuation, so alphabar^m=1 follows from Hbar=1+x^(4m)=(1+x^m)^4.

Set t=alpha^m and y=t+1. Gaussian symmetry gives C_(3m)=C_m. The root equation becomes

0 = 1+t^4+C_m(t+t^3)+C_(2m)t^2+E,

with v(E)>=4. Since t is a unit, the C_(2m) term has exact valuation 2; the paired C_m term has valuation at least 3. Hence v(1+t^4)=2, with no cancellation ambiguity at its minimum.

Now y has positive valuation, and

1+t^4=y^4-4y^3+6y^2-4y+2.

If w=v(y)>=1, every displayed term has valuation at least 4, impossible. This also rules out y=0. If 0<w<1, the valuations are 4w, 8+3w, 4+2w, 8+w, and 4; 4w is uniquely minimal. Therefore w=1/2. This is an assertion about a root in an extension of the mixed-characteristic valued field, not merely about a root of a residual polynomial.

### 2.4 Ordinary derivative and the only cancellation that matters

In alpha H_h'(alpha), the j=m and j=3m contributions are exactly

A=m C_m t(1+3t^2).

Here m is a valuation unit and t is a valuation unit. With t=y-1,

1+3t^2=4-6y+3y^2.

The three term valuations are 8, 9/2, and 1. Thus the last term is uniquely minimal, and v(A)=3+1=4, with a nonzero leading unit. The remaining positive multiples of m have valuations 6 and 8. These coefficients are the ordinary integer differentiation factors j; no q-derivative is substituted.

For the sum S of all nonmultiple derivative terms, each C_j/2 is integral and the root is a unit. In its residue, group j=r,r+m,r+2m,r+3m for each 1<=r<m. Both bar(C_j/2) and alphabar^j are constant across this group. Exactly two ordinary differentiation factors j are odd and two are even, so their sum is zero in characteristic 2. Thus bar(S/2)=0 and v(S)>4.

This is essential: individual nonmultiple terms can have valuation exactly 4, so merely comparing them individually would not prove the theorem. The four-class cancellation, established at the unit residue level, is sufficient to raise the valuation of their whole sum. It leaves A as the unique minimum among the grouped contributions. Therefore H_h'(alpha) is nonzero at every root. When m=1 the nonmultiple sum is empty, and the proof still holds.

No leading-degree argument for a reduced derivative is being used. Indeed Hbar itself is inseparable; the characteristic-zero evaluation argument is what proves ordinary squarefreeness.

## 3. Negative controls and excluded extensions

Oddness of m is not cosmetic. For the improperly admitted case m=2, h=8, q primitive of order 16, and v(2)=4, qbar has order 1, not m=2. Moreover C_1=2/(1-q) has valuation 7/2, not the asserted nonmultiple value 4. An exact cyclotomic norm check confirms this. Thus the coefficient and residue proof cannot be carried over by merely allowing even m.

Likewise, two residue classes r and r+m would not suffice for the derivative cancellation: their odd differentiation factors sum to one, not zero. The independent controls explicitly test this failure while checking the four-class cancellation.

This audit does not rule out a different proof for 8|h. It rules out treating the present proof as if it already covered that case. No assertion of complex-disk zero simplicity, root location, conditioning, root-preparation speed, faster application, or a faster FFT has been imported.

## 4. Original-model binding and dependency boundary

The exact normalization P_h(z)=-H_h(qz;q) is the one checked in the accepted core packet, not a new recurrence. Nonzero scaling and nonzero variable change preserve the ordinary derivative gcd. The original source files remain:

- PHASE21_THEOREM.md: SHA256 e03f5f77ecae1791d7c1e093ba728ea642152647bb3043f9bbf55884e7232e6e.
- P02_ACCEPTED.md: SHA256 f6412a2cb78457a2fddd62a6e688095cb82528b4457ad1454dbbe069179937d6.
- ORIGINAL_PENCIL_EXTENSION.md: SHA256 d6f5ac8d0cbd7f48cf928139dd60d275c79ad7b566d3c772795bb91d0d3a4861.

These are in `sources/`. Their hashes were rechecked. The original recurrence definition and full-moment reconstruction were reread in ORIGINAL_PENCIL_EXTENSION.md.

For the combined Q_min conclusion this audit relies on the already accepted legality and reconstruction arguments in `sources/SEALED_SCOPED_VERDICT.md`. In particular, ordinary squarefreeness here is combined with, not substituted for, forbidden-node avoidance. The Vandermonde reconstruction and nonsingular Hankel determinant provide all original N moments and nonzero weights, while the legality factor preserves nonzero resolvent weights. No confluent pole or changed generator is admitted.

## 5. Reproducible exact diagnostics and provenance

The reviewer independently authored `exact_controls.py`; no candidate executable was run. `CONTROL_RESULTS.json` records:

- Exact symbolic identities for the mixed-characteristic ratio difference, exponent-periodicity difference, root expansion, derivative expansion, and eighth-root valuation auxiliary identities.
- Exact cyclotomic-ring coefficient checks at m=1,3,5,9,15, including composite odd m.
- 112 exact unit-residue checks and exact four-class ordinary-derivative cancellation checks modulo Phi_m in characteristic 2.
- 33 exact cyclotomic norm controls for all interior coefficients at m=1,3,5.
- A two-class cancellation negative control and the even-m=2 countercontrol described above.

All completed controls pass. They test calculations and edge cases but do not replace the uniform proof. One initial script run reached its final source-hash read after the author had relocated the unchanged candidate and therefore reported FileNotFoundError. The script path was updated to the verified new location and the complete script rerun; this was an artifact-location race, not a mathematical failure.

The addendum's proof contribution belongs to its author and builds on the previously attributed h=2m valuation method. This reviewer supplied no essential proof repair, changed no candidate bytes, added no further contributors, and performed no external write. The supplemental valuation justification and negative controls above are audit exposition, not a silently incorporated new theorem contribution.
