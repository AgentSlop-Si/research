# Phase 21: Exact Weyl–Green chirps and the common-order barrier

**Date:** 2026-10-09  
**Status:** Theorems proved algebraically for every even transform size `N>=4`; finite-field tests are supplemental. No new `o(N log N)` FFT is claimed.

## 0. Definitions and exact model

Let `omega = exp(-2*pi*i/N)` and `Fhat[j,k]=omega^(jk)/sqrt(N)`. Indices are 0 to `N-1`. The cyclic forward shift is `Z e_k=e_(k+1 mod N)` and `D=diag(omega^j)`. Define

```
T = D^(-1) Z,     U=Z D,     Q=diag(omega^(j^2)).
```

Each of `T` and `U` is a unitary monomial matrix and, for even `N`,

```
T^N = U^N = -I.
```

A **weighted cyclic Green inverse** is `G_w=(I-S_w)^(-1)` with `(S_w x)[j]=w_j x[j-1]` (cyclic indices), for arbitrary complex edge weights with `prod_j w_j !=1`. It costs `O(N)` field operations and memory accesses to apply: solve the first-order recurrence, close the cycle with one scalar division, then back-substitute. `G_alpha=(I-alpha*T)^(-1)` and `K_beta=(I-beta*U)^(-1)` are special cases.

All exact complexity statements concern algebraic arithmetic on the current input. Numerical precision, root preparation and real machine costs are *not* free; bounds for this restricted architecture are not DFT lower bounds in the unrestricted model.

## 1. A dense flat Green kernel is possible in linear work

**Proposition 1 (explicit inverse).** For even `N` and `1+alpha^N != 0`,

```
G_alpha = (I-alpha*T)^(-1)
        = [sum_(m=0)^(N-1) alpha^m T^m] / (1+alpha^N).
```

**Proof.** Multiply the numerator by `I-alpha*T`; the product telescopes to `I-alpha^N*T^N=(1+alpha^N)I`.

Every `T^m` is a different weighted cyclic permutation, so the `N` summands occupy disjoint cyclic diagonals and every entry of `G_alpha` is nonzero when `alpha!=0`. For `|alpha|=1` all entries have modulus `1/|1+alpha^N|`. In particular, when `alpha=1`, every entry has modulus `1/2`.

**Conditioning warning.** The eigenvalues of unitary `T` are the `N` roots of `z^N=-1`. Consequently,

```
kappa_2((I-T)^(-1)) = cot(pi/(2*N)) ~ (2/pi)*N.
```

This is a flat, dense, linear-work transform but not a unitary Fourier transform. For any two distinct columns of `G_alpha`, their row-by-row ratio takes exactly two distinct values, so a single such Green solve is not monomial-equivalent to `Fhat` when `N>=4` (compare the pair of Fourier columns indexed by consecutive frequencies, which has `N` distinct row ratios). This two-value observation assumes nonzero `alpha` and a valid inverse.

## 2. Constructive identity: the DFT is a chirp polynomial in a Weyl shift

**Theorem 2 (exact chirp identity).** Put

```
c_m = omega^(-m*(m-1)/2),   m=0,...,N-1.
P(T) = sum_(m=0)^(N-1) c_m*T^m.
Q[j,j] = omega^(j*j).
```

Then for every even `N`,

```
                   Fhat = N^(-1/2) Q P(T).
```

**Proof.** Given any row `j` and column `k`, exactly one power `m=(j-k mod N)` contributes to `P(T)[j,k]`. Its phase is

```
T^m[j,k] = omega^(-m*k-m*(m+1)/2).
```

Hence `Q[j,j] c_m T^m[j,k]` equals

```
omega^(j*j-m*(m-1)/2-m*k-m*(m+1)/2)
= omega^(j*j-m*(j))
= omega^(j*k),
```

because `m=j-k mod N`. This is precisely the normalized DFT entry. **No algorithmic speedup follows:** direct application of `P(T)` uses `Theta(N^2)` operations; conventional FFT applies the same matrix in `O(N log N)`.

This is a twisted-shift form of the classical chirp/convolution identities associated with Bluestein. Our project-specific use is to analyze Green-resolvent compression of the chirp polynomial, not to claim discovery of the chirp identity itself.

## 3. Exact Hankel rank lower bound even with arbitrary outer diagonals

**Theorem 3 (common Weyl pole budget).** For every even `N>=4`, suppose

```
Fhat = L [sum_(ell=1)^q a_ell (I-alpha_ell*T)^(-1)] R
```

where `L,R` are arbitrary invertible diagonal complex matrices, the scalar weights and poles are arbitrary and each inverse exists. Then

```
                       q >= N/2.
```

**Proof, step A — coefficients.** By Proposition 1, the central bracket is `C(T)=sum_(m=0)^(N-1) c_m T^m` with

```
c_m = sum_ell (a_ell/(1+alpha_ell^N))*alpha_ell^m.
```

Since the Fourier matrix has no zero entries, every `c_m` is nonzero.

**Step B — phase curvature forces a chirp.** For each `m=1,...,N-2`, examine rows `(m,m+1)` and columns `(0,1)`. The cross-ratio of `C(T)` on this minor is

```
      C[m,0]*C[m+1,1] / (C[m,1]*C[m+1,0])
                    = c_m^2/(c_(m-1)*c_(m+1)).
```

Left and right diagonal scalings cancel from every cross-ratio. For `Fhat`, the same ratio equals `omega`, so

```
c_m^2 = omega*c_(m-1)*c_(m+1).
```

Solving this second-order multiplicative recurrence gives

```
      c_m = c_0*rho^m*omega^(-m*(m-1)/2)
```

for some nonzero `c_0,rho`.

**Step C — the chirp Hankel matrix has maximal rank.** Let `h=N/2` and `H[r,s]=c_(r+s)` for `0<=r,s<h`. Since `2h-2<N`, all entries are among the known coefficients. Factor

```
H[r,s] = [c_0*rho^r*omega^(-r*(r-1)/2)]
         * omega^(-r*s)
         * [rho^s*omega^(-s*(s-1)/2)].
```

The middle matrix `(omega^(-r*s))` is Vandermonde on `h` **distinct** nodes `1,omega^-1,...,omega^(-(h-1))`, so `rank(H)=h`.

**Step D — each Green pole contributes rank at most one.** The first coefficient expression gives

```
H[r,s] = sum_ell (a_ell/(1+alpha_ell^N))*alpha_ell^r*alpha_ell^s,
```

so `rank(H)<=q`. Hence `q>=h=N/2`.

This is an **exact representation-size theorem**, not a runtime lower bound for algorithms that share intermediate calculations among resolvents. It covers arbitrary outer diagonal *scalings*, but not arbitrary outer permutations or arbitrary per-term diagonal gauges.

The rank-of-exponential-sums argument belongs to the classical Prony/Hankel toolbox. The theorem is its specialized application to this Weyl Green family.

## 3A. Matching pole count: exact finite-size algebraic construction

The lower bound `q>=N/2` is **attainable for the power-of-two lengths whose algebraic nondegeneracy we certified**. This is a positive **representation** result, not a fast algorithm.

Let `h=N/2`, let `c_m=omega^(-m*(m-1)/2)` as above, and form the explicit degree-h polynomial

```
R_h(z) = prod_(k=0)^(h-1)(z-omega^(-k)) = sum_(j=0)^h r_j z^j,
A_h(z) = sum_(j=0)^h a_j z^j,
a_j = (c_h / c_j) * r_j.
```

The polynomial `A_h` is **monic**, with coefficients in the cyclotomic integer ring `Z[omega]`, and has nonzero constant coefficient. For `s=0,...,h-1`, use `c_(s+j)=c_s*c_j*omega^(-s*j)` to obtain

```
sum_(j=0)^h a_j*c_(s+j)
  = c_h*c_s * R_h(omega^(-s)) = 0.
```

Thus `A_h` is an explicit order-h recurrence polynomial for all N given chirp coefficients. If it has h distinct roots `alpha_1,...,alpha_h` with `alpha_l^N != -1`, then the Vandermonde system for the first h moments uniquely determines coefficients `beta_l` such that

```
 c_m = sum_(l=1)^h beta_l*(alpha_l)^m,    0 <= m < N.
```

Both sequences obey the same recurrence and agree initially, so the equality holds throughout. Setting `a_l=beta_l*(1+alpha_l^N)` gives an exact **h-term resolvent identity**

```
Fhat = (Q/sqrt(N)) * sum_(l=1)^h a_l*(I-alpha_l*T)^(-1).
```

**Rigorous computer-assisted certificates for a finite sequence of lengths.** Using `p=998244353` and mapping the cyclotomic integer `omega` to a primitive Nth root modulo p, the standalone verifier `prony_squarefree_certificate` computed

```
gcd(A_h, A_h')       = 1 mod p,
gcd(A_h, z^N+1)      = 1 mod p
```

for each `N=4,8,16,...,8192`. Because the coefficients of the monic polynomial `A_h` are cyclotomic algebraic integers and this reduction is a ring homomorphism, nonzero resultants modulo p **exclude zero resultants in characteristic zero**. Thus those finite-size A_h polynomials have distinct complex roots and none is forbidden by `alpha^N=-1`. This proves exact h-pole representations **for each checked size**, without numerically approximating those roots.

What remains **unproved** is that `A_h` is squarefree and avoids `z^N+1` for *every* even N. The certificate is finite in scope, despite testing sizes up to 8192. Computing the pole roots, residues, and summing `h=N/2` independent O(N) solves is still costly, potentially severely ill-conditioned, and does not yield `o(N log N)` runtime.

## 4. A stronger theorem: all same-order weighted cyclic Green circuits

**Theorem 4 (common-order product/sum barrier).** Fix even `N`. Consider **any** product

```
M = D_t S_t D_(t-1) S_(t-1) ... D_1 S_1 D_0,
S_j = sum_(ell=1)^(q_j) a_(j,ell) (I - S_(w,j,ell))^(-1),
```

where all `S_w` are cyclic *forward* weighted shifts in the same coordinate order; the edge weights are completely arbitrary, each denominator is invertible, and all `D_i` are arbitrary diagonal matrices. Some `D_i` may be singular; the inequality remains valid. Let `Q=sum_j q_j` be the total counted Green inverses. Then:

```
rank(M[0:N/2, N/2:N]) <= Q.
```

In particular, if `M=Fhat`, then

```
                          Q >= N/2.
```

The statement permits noncommuting Green terms, arbitrarily ill-conditioned denominators, and an arbitrary number of layers. **Intermediate coordinate permutations or reversed/nonidentical path orderings are excluded.** They can defeat the fixed-cut rank bound.

**Proof.** The inverse of `I-S_w` is `sum_(m=0)^(N-1) S_w^m/(1-prod w_j)`. When `j<N/2<=k`, the unique cyclic path contributing to entry `(j,k)` wraps past 0, so the entry factors as

```
G_w[j,k] = [prod_(r=0)^j w_r]
           * [prod_(r=k+1)^(N-1) w_r] / (1-prod_r w_r).
```

Thus its upper-right half block is an outer product, rank at most one, even if weights vanish. Summing `q_j` inverses gives upper-right rank at most `q_j`.

For the half-partition `R={0,...,N/2-1}`, `C={N/2,...,N-1}`, the block identity

```
(AB)[R,C] = A[R,R]*B[R,C] + A[R,C]*B[C,C]
```

shows `rank((AB)[R,C]) <= rank(A[R,C])+rank(B[R,C])`. Intermediate diagonals contribute zero cross-block rank. Therefore `rank(M[R,C])<=Q`.

Finally, `Fhat[R,C]` is an `N/2 x N/2` Vandermonde matrix: its rows are powers 0 through `N/2-1` evaluated at `N/2` distinct values `omega^k`. Hence its rank is exactly `N/2`. QED.

This is a more general, simpler obstruction than Theorem 3, but Theorem 3 separately identifies the **quadratic Fourier phase sequence** and its Prony complexity in the common-generator family.

**Theorem 5 (spectral approximation floor).** In Theorem 4, assume `Q<N/4` and let `m=N/2`. Then

```
||M-Fhat||_2 >= sqrt[(N/4-Q)/(N/2-Q)].
```

**Proof.** The Fourier half block `C=Fhat[R,C]` has `||C||_F^2=N/4` and `||C||_2<=1`, since it is a compression of a unitary matrix. If its singular values are `s_1>=...>=s_m`, the first `Q` contribute at most `Q` to their squared sum, so

```
(m-Q)*s_(Q+1)^2 >= sum_(j=Q+1)^m s_j^2 >= N/4-Q.
```

Any rank-at-most-Q approximation to `C` has spectral error at least `s_(Q+1)` (Eckart–Young), and the norm of an ambient error dominates that of its submatrix. QED.

For `Q=o(N)`, the error floor tends to at least `1/sqrt(2)`. **This is restricted to common-order cyclic Green circuits.**

## 5. Noncommutativity can create full commutator rank in linear work

**Theorem 6 (Weyl commutator escape, but not yet Fourier).** With `T=D^-1 Z` and `U=ZD`,

```
T*U = omega^(-2) Z^2,     U*T=Z^2,
[T,U] = (omega^(-2)-1) Z^2.
```

The right side is invertible for `N>2`. For every nonzero `beta` such that `K_beta=(I-beta U)^(-1)` exists,

```
[T,K_beta] = beta*K_beta*[T,U]*K_beta.
```

Therefore the commutator has rank **N**, although `K_beta` has an `O(N)` apply and inverse. This shows full displacement/commutator rank relative to `T` does **not** imply a computationally hard transform.

However, `G_alpha(T)` and `K_beta(U)` use the same forward cyclic **coordinate order**. Thus any fixed-depth sum/product of a small number of them is still ruled out by Theorem 4. Numerical or modular tests of a sample mixed sum also fail both full Fourier Weyl identities.

**Key lesson for Phase 22:** The next escape architecture needs *both* noncommutativity and **different effective coordinate orders**, not merely flat-magnitude Green kernels, commutator rank, or a complex phase parameter.

## 6. Exactly what has and has not been established

Established:

- Exact dense flat Green matrices with O(N) application, and their N-dependent conditioning.
- An exact chirp-polynomial Fourier representation, independently checked over a finite field.
- `q>=N/2` pole budget for common Weyl resolvent sums even with outer diagonals; exact matching-size representations certified for powers of two up to N=8192, but no uniform proof.
- `sum q_j>=N/2` for arbitrary products of same-order cyclic weighted Green sums with arbitrary diagonal intermediate gauges, including noncommuting terms, and a spectral approximation floor.
- Exact full-rank Weyl commutator with an O(N)-work Green solve, demonstrating why high rank alone cannot certify Fourier coherence.

Not established:

- An `o(N log N)` DFT, numerical FFT improvement, or integer multiplication improvement.
- A lower bound on the operation count of algorithms sharing computations across `N/2` Green terms.
- Impossibility for independently permuted/nonidentically ordered Green products, the surviving Phase 20 branch.
- A construction satisfying both Fourier Weyl intertwining equations using O(1) independently ordered Green sums.

## 7. Prior art and attribution

- Quadratic chirp and convolution Fourier identities: Bluestein (1968), Rabiner–Schafer–Rader (1969); AMD rocFFT Bluestein notes: https://rocm.docs.amd.com/projects/rocFFT/en/docs-5.7.1/design/bluestein.html
- Rank factorization of exponential-sum Hankel matrices: classical Prony method, see https://link.springer.com/article/10.1007/s00365-020-09501-6
- Green inverse low-rank off-diagonal blocks: classical one-dimensional Green matrices and quasiseparable matrices, previously used in our Phases 11 and 17.
- Nonunitary FFT lower-bound context: Nir Ailon, *An n log n Lower Bound for Fourier Transform Computation in the Well Conditioned Model* (2014), https://arxiv.org/abs/1403.1307 . Its computation model differs.
- OpenAI 2026 exact complex-register DFT bound: https://github.com/openai/math/blob/main/lean/docs/130.md . Our construction **does not improve** this bound.

The above exact theorems are project-specific deductions from established algebraic ingredients; they have not undergone independent peer review. Finite-field testing supports the implementation but does not prove a complex identity or a universal algorithmic speedup.
