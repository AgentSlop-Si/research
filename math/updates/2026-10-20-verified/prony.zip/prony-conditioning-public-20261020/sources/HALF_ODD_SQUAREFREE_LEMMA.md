# Ordinary squarefreeness when h is twice an odd integer

Frozen candidate, 20 October 2026. This lemma is an essential contribution by the independent audit partner, not an independently reviewed part of that partner's audit. A fresh reviewer must assess it before acceptance.

## Statement

Let m be a positive odd integer, h=2m, and q be any primitive 2h-th root of unity in characteristic zero. Define the ordinary Rogers–Szegő polynomial

H_h(x;q) = sum_{j=0}^h C_j x^j,
C_j = [h choose j]_q = product_{d=h-j+1}^h (1-q^d) / product_{d=1}^j (1-q^d).

The empty products give C_0=C_h=1. Then gcd(H_h, dH_h/dx)=1. The derivative is the ordinary derivative, not a q-derivative.

Consequently, for the original canonical chirp moments c_j=q^{j(j-1)/2}, the monic recurrence polynomial P_h(z)=-H_h(qz;q) is squarefree whenever N=2h is congruent to 4 modulo 8. This statement alone does not prove the forbidden-node gcd; that requires the separate legality theorem.

## Proof

Let K=Q(q), choose a prime of its ring of integers above 2, and extend its valuation to an algebraic closure. Normalize v(2)=1. Write a bar for residue reduction. Since m is odd, the reduction qbar has exact order m. Indeed, the characteristic-zero cyclotomic identity Phi_{4m}(X)=Phi_{2m}(X^2) reduces modulo 2 to Phi_m(X)^2. The polynomial X^m-1 is squarefree in characteristic 2, so its cyclotomic factors have disjoint roots and every root of Phi_m has exact order m. This includes m=1, where qbar=1.

For 1<=d<=2m, it follows that

- v(1-q^d)=0 if m does not divide d;
- v(1-q^m)=1/2, since q^m is a primitive fourth root and (1-q^m)^2=-2q^m;
- v(1-q^{2m})=1, since q^{2m}=-1.

All denominator factors defining C_j are nonzero. Counting the two possible positive-valuation factors in numerator and denominator gives

v(C_m)=1/2,
v(C_j)=1 for every interior j with 1<=j<=2m-1 and j!=m.

In detail, for j<m the numerator contains d=2m but not d=m, while the denominator contains neither. For j=m, the numerator contains d=2m but not d=m, and the denominator contains d=m. For m<j<2m, the numerator contains both, while the denominator contains only d=m.

Set G(x)=H_h'(x)/C_m, a polynomial over K. Its coefficient of x^{m-1} is the odd integer m, hence has valuation zero. Every other coefficient has strictly positive valuation: for interior j!=m it has valuation v(j)+1-1/2>=1/2, and the leading derivative coefficient h/C_m has valuation v(2m)-1/2=1/2. Thus all coefficients of G are integral at the chosen prime and

Gbar(x)=x^{m-1}.

Every root alpha of H_h has v(alpha)=0. If v(alpha)<0, its monic degree-h term has uniquely least valuation. If v(alpha)>0, the constant term 1 has uniquely least valuation. Either case contradicts H_h(alpha)=0, because all coefficients of H_h are integral and its constant and leading coefficients are 1.

For such a root alpha, the term m alpha^{m-1} in G(alpha) has valuation zero and all other terms have positive valuation. Therefore G(alpha)!=0, hence H_h'(alpha)!=0. Every root is simple. Scaling x=qz and multiplying by -1 preserve ordinary squarefreeness. QED.

## Scope and original-source binding

The original recurrence is defined in PHASE21_THEOREM.md §3A and ORIGINAL_PENCIL_EXTENSION.md §§1,7 as

R_h(z)=product_{k=0}^{h-1}(z-q^k),
P_h(z)=sum_j (c_h/c_j)[z^j]R_h(z) z^j.

The finite q-binomial expansion gives P_h(z)=(-1)^h q^{h(h-1)} H_h(-q^{-(h-1)}z;q). As q^h=-1, the scalar is -1 and the argument is qz, yielding P_h(z)=-H_h(qz;q). Thus the lemma concerns the exact original recurrence, not a redefined polynomial.

This is a uniform subfamily theorem, not an extrapolation from finite reductions. It does not prove squarefreeness for 4|h, give an algorithmic speedup, or improve the already accepted h+1-pole upper bound by itself.
