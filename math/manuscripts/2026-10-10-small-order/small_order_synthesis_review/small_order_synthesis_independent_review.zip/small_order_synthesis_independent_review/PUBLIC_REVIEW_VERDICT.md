# Independent review of the small order synthesis manuscript

Reviewed 10 October 2026. Verdict: the complete mathematical argument is accepted within its stated grammar and field scopes. There are no mathematical correction blockers. Two editorial clarifications are listed below for the final typesetting pass. This verdict binds the exact manuscript bytes identified in `ACCEPTANCE_RECEIPT.json`; subsequent changes require a bounded recheck.

## Accepted mathematical scope

The exact complex signed-Weyl phase-weighted bank minima are four at order three, five at order five, and eight at order seven. A bank has exactly the definition in Section 1, including the four allowed orientations, one parameter pair for the whole phase average, arbitrary phase weights, and a nonzero scalar inverse guard. Enlarging the grammar would require a different theorem.

The order-three argument holds in every field of characteristic different from three containing a primitive cube root. The order-five minimum holds over every characteristic-zero field containing its primitive root. The order-seven obstruction holds over every characteristic-zero extension containing a primitive seventh root; its eight-bank realization is over the splitting field of the stated separable cubic over Q(q), and therefore over C. An order-seven realization wholly over Q(q) is not established.

The retained general lower and upper bounds, four-bank classification, and order-nine lower bound are consistent with the displayed arguments. No exact minimum at orders at least nine, Fourier runtime speedup, arithmetic lower bound, or historical priority is accepted or inferred.

## Full proof review

This was a review of the complete assembled proof, not merely a check that acceptance receipts exist. Every section of the 623-line TeX source was read. The following logical points were checked separately from numerical or certificate evidence.

- The commutation sign is D A = q^(epsilon delta) A D. The Gaussian expansion uses the matching coefficient convention and gives precisely the stated triangular support.
- The finite geometric inverse is legal for every specified branch. The Fourier trace coefficient, square completion, nonvanishing Gauss factor, and inverse-character raw-weight conversion have the correct signs and normalization. The factor 1/N occurs exactly once in the original bank definition.
- All four orientations have exclusive nonzero Fourier coefficients. Support coverage is not mistaken for coefficient compatibility. The lower-bound relaxation to arbitrary sector amplitudes contains the actual beta = 0 stratum without claiming it is itself realizable.
- The order-three construction independently assigns its character row, four exclusive entries, and two remaining axis entries. Its denominators remain nonzero in the stated positive-characteristic scope, including characteristic two.
- The order-five lower argument forces nonzero nodes, covers both diagonal and nondiagonal row-compatible types over arbitrary extension fields, rules out mixed types, and excludes every remaining pairing. Its Bezout step does not divide by the linear coefficient; the third- and fourth-sector support cannot repair the obstructed axis entries.
- The five-bank order-five recipe specifies all 25 amplitudes. The three displayed matrices are the original Weyl coefficient systems, their determinants are nonzero, and sector assignments do not interfere.
- The order-seven lower argument isolates rows independently of the number of opposite-delta banks. Its recurrence identities do not divide by a node difference, discriminant, or Hankel determinant. Repeated/zero forward nodes, zero amplitudes, and D = 0 remain included. Only the singleton node is divided by, after its nonzero endpoint proves legality.
- Transposition and simultaneous reflection act with the stated sign and phase reindexings and preserve the target. Legal zero-bank padding closes the smaller multiplicities, so both delta signs require at least four banks.
- The modular order-seven proof is valid good reduction: the row denominators and leading coefficient are units in the stated local ring; the quotient is finite free; the reduced multiplication determinant is nonzero; hence the characteristic-zero multiplication map is invertible. This is not inference from an empty finite-field point search.
- The order-seven cubic has nonzero constant term and discriminant. Its roots are nonzero and distinct, and all inverse guards are legal. Edge compatibility, nonzero interior minors, reflection, Lagrange recovery of individual amplitudes, and one-to-one sector indexing supply a complete construction.
- The cubic quotient is used as a separable algebra, without presuming irreducibility. Its trace sums the three root evaluations. Thus the literal quotient-algebra matrix controls imply all individual resolvent identities after passage to the splitting field.
- The general Hankel bound, Fourier Vandermonde factorization, triangle-wise interpolation upper bound, and order-nine paired-root recurrence obstruction have no missing genericity assumption. The general interpolation formula takes zero at unassigned local coordinates.

## Fresh exact reproduction

`fresh_review_control.py` was written independently for this review using SymPy only as an arithmetic library. No uploaded, author, or predecessor research program was read as code, parsed, imported, compiled, or executed. Archived program files were read only as opaque bytes to verify their hashes. Inert JSON certificates were compared with newly reconstructed algebra.

The successful recorded run contains 403 assertion checks, including:

- all 69 source byte hashes, all 22 draft ZIP members, the manuscript manifest, and every copied certificate's provenance;
- every original order-three and order-five branch inverse, both inverse products, and the complete 3-by-3 and 5-by-5 target matrices;
- the order-five forced amplitudes, isolated row equations, third-sector outer entries, axis equation, mixed-type polynomial identity, elimination residues, three determinant identities, all 25 frozen amplitudes, and all raw weights;
- independently derived order-seven moment polynomials, every saved necessary polynomial, the full rational Bezout identity, the complete short modular Bezout identity, the original denominator reductions, the multiplication determinant 19, and symbolic two-atom recurrence identities including degenerate cases;
- the order-seven cubic/discriminant, compatibility identities, all three displayed minors, all seven row systems and ranks, every saved transformed amplitude and sector polynomial;
- 28 literal cubic/singleton phase calculations representing all 56 original order-seven resolvents, both inverse products, and all 49 final Fourier entries;
- the retained order-nine recurrence, uniqueness matrix, elimination polynomial, and nonzero residue.

Exact arithmetic in Q[q]/Phi_N verifies algebraic identities, rather than approximate checks at a floating-point root. These characteristic-zero controls extend to the other primitive-root embeddings. The all-field order-three assertion and the exhaustive nonexistence assertions are accepted from their proofs, not from extrapolating a finite test set. This review is not a formal proof-assistant verification.

## Typesetting and attribution

All 15 pages were independently rasterized and visually inspected. No clipped equations, overlapping text, missing glyphs, or broken cross-references were found. The final TeX log has no overfull boxes or undefined citations/references. Long literal filenames sometimes wrap across lines, but remain present and legible.

The cited primary passages were checked directly: [Holtz, Mehrmann and Schneider, Theorems 1–2](https://people.math.wisc.edu/hans/hms_sub.pdf), [Schlosser, Proposition 1](https://arxiv.org/pdf/1106.2112), [Gross, Section II](https://arxiv.org/pdf/quant-ph/0602001), [Ouvry, Wagner and Wu, Section 2.2](https://arxiv.org/pdf/1606.03273), [Potts and Tasche, Section 2](https://www-user.tu-chemnitz.de/~potts/paper/prony.pdf), and [Peter and Plonka, Theorem 2.1](https://num.math.uni-goettingen.de/plonka/pdfs/Operator_Prony_revised2.pdf). They support the classical ingredients attributed to them. The magnetic branch identification is a specialization, not attribution of the bank-minimization result. The archived bounded prior-art comparison is accurately characterized. This review is not a new exhaustive priority search.

## Two editorial clarifications for the author

1. Section 1 initially defines the setting for a characteristic-zero field, although Theorem 1.2 and Proposition 3.2 explicitly extend order three to positive characteristic. For a fully uniform definition, start with a field whose characteristic does not divide N, then restrict the later characteristic-zero results as already stated. This clarifies scope and does not expand any theorem.
2. In Definition 1.1, replace the potentially ambiguous assertion that repeated parameters never improve a minimum with the explicit statement that banks with identical signs and identical parameter pairs combine by adding their phase weights, and zero banks can be removed. Different orientations may legitimately share the same parameter pair.

These are presentational clarifications, not defects in the accepted lower or upper proofs. The author should make only these bounded edits, refresh typesetting and metadata, and submit the changed hashes for final verification. Frozen underlying research sources must remain untouched.

No remote writes were made during this review.
