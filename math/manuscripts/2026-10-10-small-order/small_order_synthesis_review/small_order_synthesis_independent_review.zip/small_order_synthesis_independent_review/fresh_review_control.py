"""Fresh manuscript review control. No archived program is read or imported.

Only inert JSON certificate data are used for comparisons. Mathematical
formulas are transcribed from the manuscript and independently evaluated.
"""
import hashlib
import json
from pathlib import Path
from fractions import Fraction
from sympy import QQ, CRootOf, cyclotomic_poly, symbols
from sympy.polys.rings import ring
from sympy.polys.fields import field as rational_field

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'small_order_synthesis_manuscript'
OUT = Path(__file__).resolve().parent
results = {}
checks = 0

def check(ok, label):
    global checks
    if not ok:
        raise AssertionError(label)
    checks += 1

def field(n):
    X = symbols('X')
    k = QQ.algebraic_field(CRootOf(cyclotomic_poly(n, X), 0))
    return k, k.unit

def ser(a, d):
    v = list(reversed(a.to_list()))
    return [str(x) for x in v] + ['0']*(d-len(v))

def val(v, q):
    return sum((q**i * QQ(c) for i,c in enumerate(v)), q*0)

def gb(n, ell, q):
    r = q**0
    for i in range(1, ell+1):
        r *= (1-q**(n-ell+i))/(1-q**i)
    return r

def blank(n, m, zero): return [[zero for _ in range(m)] for _ in range(n)]
def eye(n, one): return [[one if i==j else one*0 for j in range(n)] for i in range(n)]
def madd(A,B): return [[a+b for a,b in zip(x,y)] for x,y in zip(A,B)]
def scale(A,s): return [[s*a for a in row] for row in A]
def mmul(A,B):
    z=A[0][0]*0
    return [[sum((a*b for a,b in zip(row,col)),z) for col in zip(*B)] for row in A]

def solve(A,b=None):
    a=[list(row)+([] if b is None else [b[i]]) for i,row in enumerate(A)]
    n=len(a); m=len(A[0]); piv=[]; det=A[0][0]**0
    for c in range(m):
        r=len(piv)
        if r==n: break
        p=next((p for p in range(r,n) if a[p][c]),None)
        if p is None: continue
        if p!=r: a[p],a[r]=a[r],a[p]; det=-det
        v=a[r][c]; det*=v; a[r]=[u/v for u in a[r]]
        for i in range(n):
            if i!=r and a[i][c]:
                v=a[i][c]; a[i]=[u-v*w for u,w in zip(a[i],a[r])]
        piv.append(c)
    if len(piv)!=n or m!=n: det=None
    return ([a[i][-1] for i in range(n)] if b is not None and len(piv)==m else None),det,piv

def matvec(A,v): return [sum((a*b for a,b in zip(row,v)),v[0]*0) for row in A]

def coefficient(n,q,eps,delta,alpha,a,b):
    r=(eps*a)%n; ell=(delta*b)%n
    return q*0 if r+ell>n-1 else alpha**r*gb(r+ell,ell,q**(eps*delta))

def f(n,q,a,b): return q**((pow(4,-1,n)*(a+b)**2)%n)

def literal_banks(n,q,banks):
    """Direct literal inverses by Gauss-Jordan, without Weyl expansion."""
    one=q**0; zero=q*0; I=eye(n,one); total=blank(n,n,zero)
    C=sum((q**((-j*j)%n) for j in range(n)),zero)/n
    inverse_count=0
    for eps,delta,alpha,h in banks:
        guard=-alpha**n
        check(bool(guard),'literal nonzero guard')
        for j in range(n):
            w=C*guard*sum((h[l]*q**((-eps*delta*j*l)%n) for l in range(n)),zero)
            B=eye(n,one)
            for t in range(n):
                B[(t+eps)%n][t]-=alpha
                B[t][t]-=q**((eps*delta*j+delta*t)%n)
            cols=[solve(B,[one if r==c else zero for r in range(n)])[0] for c in range(n)]
            inv=[list(row) for row in zip(*cols)]
            check(mmul(B,inv)==I and mmul(inv,B)==I,'literal inverse products')
            total=madd(total,scale(inv,w/n)); inverse_count+=1
    check(total==[[q**((-a*b)%n) for b in range(n)] for a in range(n)],'literal Fourier equality')
    return inverse_count

def provenance():
    source=json.loads((DOC/'SOURCE_REGISTER.json').read_text())['sources']
    for s in source:
        b=(ROOT/s['path']).read_bytes()
        check(len(b)==s['bytes'] and hashlib.sha256(b).hexdigest()==s['sha256'],'source hash '+s['path'])
    for name,s in json.loads((DOC/'MANUSCRIPT_MANIFEST.json').read_text())['files'].items():
        b=(DOC/name).read_bytes()
        check(len(b)==s['bytes'] and hashlib.sha256(b).hexdigest()==s['sha256'],'manuscript manifest '+name)
    for name,s in json.loads((DOC/'certificate_data/COPY_PROVENANCE.json').read_text()).items():
        b=(DOC/'certificate_data'/name).read_bytes()
        check(b==(ROOT/s['original_path']).read_bytes() and hashlib.sha256(b).hexdigest()==s['sha256'],'copy '+name)
    import zipfile
    with zipfile.ZipFile(DOC/'small_order_synthesis_draft.zip') as z:
        for n in z.namelist():
            check(z.read(n)==(ROOT/n).read_bytes(),'zip byte equality '+n)
    results['provenance']={'source_hashes_verified':len(source),'archive_members_match':len(z.namelist())}

def n3():
    K,q=field(3); zero=K.zero
    specs=[(1,1,K.one),(1,-1,q),(-1,1,q),(-1,-1,K.one)]
    h=[[zero]*3 for _ in specs]
    for i,k in enumerate((0,1,-1)):
        h[i][0]=sum((f(3,q,a,0)*q**((-k*a)%3) for a in range(3)),zero)/3
    for i,(e,d,alpha) in enumerate(specs):
        h[i][1]=f(3,q,e,d)/(alpha*(1+q**(e*d)))
    for d in (1,-1):
        ix=lambda e,dd: next(i for i,(ee,ddd,_) in enumerate(specs) if (e,dd)==(ee,ddd))
        h[ix(1,-d)][2]=f(3,q,0,d)-h[ix(1,d)][1]-h[ix(-1,d)][1]
    for a in range(3):
        for b in range(3):
            check(sum((h[i][(d*b)%3]*coefficient(3,q,e,d,alpha,a,b) for i,(e,d,alpha) in enumerate(specs)),zero)==f(3,q,a,b),'N3 Weyl coefficient')
    results['N3']={'literal_inverses':literal_banks(3,q,[(*s,hh) for s,hh in zip(specs,h)]),'all_entries':True}
    print('N3 complete',flush=True)

def n5():
    K,q=field(5); zero=K.zero; one=K.one
    c=q+q**4; d=1+q**4; H=q/(1+q)
    check(c*(c+1)==one and H==1+q+q**3,'N5 constants')
    s=-one/c; p=one/c**2-q**2/c
    check(s==q**3+q**2 and p==1-q-2*q**2-2*q**3,'N5 pair invariants')
    check(s*s-4*p==-3+4*q+7*q**2+7*q**3,'N5 discriminant')
    a=2*c-q
    check(c*(a*(-q*q/c)-2*one/c-2*d)==-2-2*q+2*q**2-q**3,'N5 distinct diagonal residue')
    R,t=ring('t',K); B=c*t*t-t-q*q; D=a*t*t-4*t-2*d
    l1=2*q**3+2*q**2-q+2; l0=q**3+2*q**2+2*q
    L=l1*t+l0
    check(c*D-a*B==L,'N5 diagonal elimination linear')
    check(l1*l1*B-(c*l1*t-c*l0-l1)*L==R(1+4*q-11*q**2+6*q**3),'N5 diagonal Bezout')
    check(q*q*(s*s-2*p)-s*p-2*d*p-q*p*p==-5-5*q+5*q**3,'N5 nondiagonal residue 1')
    check(q*q*(s*s-2*p)-s*p-d*(s*s-2*p)-q*p*p==-9-19*q-17*q**2-5*q**3,'N5 nondiagonal residue 2')
    # Derive the lower equations directly, with arbitrary nonzero nodes.
    FF,xx,yy,uu,vv=rational_field('x,y,u,v',K)
    ns=[(1,1,xx),(-1,1,yy),(-1,-1,uu),(1,-1,vv)]
    for e,dd,node in ns:
        for ell,hforced in [(1,H/node),(2,q*q/node**2)]:
            check(hforced*coefficient(5,q,e,dd,node,(e*ell)%5,(dd*ell)%5)==FF(f(5,q,e*ell,dd*ell)),'N5 exclusive forced amplitude')
    for aa,necessary in [(2,xx-c*yy**2+q*q),(3,yy-c*xx**2+q*q)]:
        res=H/xx*coefficient(5,q,1,1,xx,aa,1)+H/yy*coefficient(5,q,-1,1,yy,aa,1)-f(5,q,aa,1)
        quotient=res/necessary
        check(bool(quotient) and all(not any(mon) for mon in quotient.numer) and all(not any(mon) for mon in quotient.denom),'N5 isolated row iff displayed condition')
    hthirdpm=-(1+d/xx)/vv;hthirdmm=-(1+d/yy)/uu
    for aa in (1,4):
        res=q*q/xx**2*coefficient(5,q,1,1,xx,aa,2)+q*q/yy**2*coefficient(5,q,-1,1,yy,aa,2)+hthirdpm*coefficient(5,q,1,-1,vv,aa,2)+hthirdmm*coefficient(5,q,-1,-1,uu,aa,2)-f(5,q,aa,2)
        check(not res,'N5 third sector forced outer entries')
    axis=q*q/xx**2+q*q/yy**2+hthirdpm+hthirdmm-q
    displayedaxis=q*q*(xx**-2+yy**-2)-uu**-1-vv**-1-d*((xx*vv)**-1+(yy*uu)**-1)-q
    check(axis==displayedaxis,'N5 axis residual')
    Rxy,X,Y=ring('X,Y',K)
    numerator=q*q*(X*X+Y*Y)+X*Y*(X+Y)-2*c*X*X*Y*Y+(X+Y)*(X-Y)**2
    # A direct polynomial combination, no nondegeneracy cancellation beyond xy.
    relation1=c*X*X-Y-q*q;relation2=c*Y*Y-X-q*q
    check(numerator==-(Y*Y)*relation1-(X*X)*relation2,'N5 mixed type identity')
    x=one; z=-2-3*q-3*q*q-q**3; y=q; u=v=1+q
    M=c*y*y-q*q; N=(y+q*q)/c
    check(N==(x+z)*M-x*z and c*u*u-u-q*q==zero,'N5 recurrence compatibility')
    specs=[(1,1,x),(1,1,z),(-1,1,y),(1,-1,v),(-1,-1,u)]
    h=[[zero]*5 for _ in specs]
    h[0][1]=H*(z-M)/(x*(z-x));h[1][1]=H*(M-x)/(z*(z-x));h[2][1]=H/y
    h[3][1]=H/v;h[4][1]=H/u
    h[3][4]=f(5,q,0,1)-sum((h[i][1] for i in (0,1,2)),zero)
    h[0][4]=f(5,q,0,4)-H/v-H/u
    G=1+q+q*q;P=1+q**4+q**3
    displayed={0:[[one]*5,[x,z,y**4,v,u**4],[x*x,z*z,y**3,v*v,u**3],[x**3,z**3,y*y,v**3,u*u],[x**4,z**4,y,v**4,u]],
       2:[[one]*5,[G*x,G*z,zero,-q*v,zero],[q*q*x*x,q*q*z*z,zero,zero,zero],[zero,zero,q**3*y*y,zero,zero],[zero,zero,P*y,zero,-q**4*u]],
       3:[[one]*5,[-q**4*x,-q**4*z,zero,P*v,zero],[zero,zero,zero,q**3*v*v,zero],[zero,zero,zero,zero,q*q*u*u],[zero,zero,-q*y,zero,G*u]]}
    expected={0:-1093-5351*q-6894*q*q-3592*q**3,2:31+21*q-17*q*q-30*q**3,3:6+19*q+21*q*q+9*q**3}
    for b in (0,2,3):
        mat=[[coefficient(5,q,e,d,alpha,a,b) for e,d,alpha in specs] for a in range(5)]
        check(mat==displayed[b],'N5 displayed original coefficient matrix')
        sol,det,_=solve(mat,[f(5,q,a,b) for a in range(5)])
        check(det==expected[b] and bool(det),'N5 determinant')
        for i,(_,d,_) in enumerate(specs):h[i][(d*b)%5]=sol[i]
    wdata=json.loads((DOC/'certificate_data/N5_WITNESS.json').read_text())
    C=sum((q**((-j*j)%5) for j in range(5)),zero)/5
    for i,(e,d,alpha) in enumerate(specs):
        wd=wdata['banks'][i]
        check([val(v,q) for v in wd['normalized_h']]==h[i],'N5 witness amplitude agrees')
        check(val(wd['Delta'],q)==-alpha**5,'N5 witness guard agrees')
        for j in range(5):check(val(wd['raw_weights'][j],q)==C*(-alpha**5)*sum((h[i][l]*q**((-e*d*j*l)%5) for l in range(5)),zero),'N5 raw weight agrees')
    for aa in range(5):
        for b in range(5):check(sum((h[i][(d*b)%5]*coefficient(5,q,e,d,alpha,aa,b) for i,(e,d,alpha) in enumerate(specs)),zero)==f(5,q,aa,b),'N5 all coefficients')
    results['N5']={'lower_residues_verified':True,'upper_matches_frozen_witness':True,'literal_inverses':literal_banks(5,q,[(*s,hh) for s,hh in zip(specs,h)])}
    print('N5 complete',flush=True)

def n7lower():
    K,q=field(7); R,Y=ring('Y',K); H=q/(1+q)
    m=[R.one]+[R(f(7,q,a,1)/(H*sum((q**i for i in range(a+1)),K.zero)))-R(sum((q**(-i) for i in range(8-a)),K.zero)/sum((q**i for i in range(a+1)),K.zero))*Y**(6-a) for a in range(2,6)]
    explicit=[R.one,-1-q-q**4-q**5-(q*q+q**5)*Y**4,1+q+q**3+q**4-(1+q**3+q**4)*Y**3,-q*q-(1+q*q+q**3+q**4+q**5)*Y**2,-q*q-q**3-(q*q+q**3+q**4+q**5)*Y]
    check(m==explicit,'N7 derived moment expansions')
    n2=R(q**4/gb(4,2,q)); n3=(q-Y**2*gb(6,2,q**-1)/gb(4,2,q**-1))/gb(5,2,q); n4=(q*q-Y*gb(5,2,q**-1)/gb(4,2,q**-1))/gb(6,2,q)
    check(n2==R(2+q+q**3+2*q**4) and n3==-1-q**3+(-3-2*q+q*q-2*q**3-3*q**4)*Y**2 and n4==q**5-(1+q+q**3+q**4)*Y,'N7 derived second row expansions')
    D=m[2]-m[1]**2;Sn=m[3]-m[1]*m[2];Pn=m[1]*m[3]-m[2]**2
    RR=D*m[4]-Sn*m[3]+Pn*m[2]; E=D*n4-Sn*n3+Pn*n2
    cert=json.loads((DOC/'certificate_data/N7_EXACT_ROW_CERTIFICATE.json').read_text())
    fromvec=lambda vv:sum((R(val(v,q))*Y**i for i,v in enumerate(vv)),R.zero)
    for name,poly in [('D',D),('Sn',Sn),('Pn',Pn),('R',RR),('F',E),('n2',n2),('n3',n3),('n4',n4)]:check(fromvec(cert[name])==poly,'N7 exact source polynomial '+name)
    check(fromvec(cert['exact_bezout']['U'])*RR+fromvec(cert['exact_bezout']['V'])*E==R.one,'N7 exact rational Bezout')
    mod=lambda a:sum((int(QQ(c).numerator)*pow(int(QQ(c).denominator),-1,29)*pow(7,i,29) for i,c in enumerate(ser(a,6))))%29
    rr=[mod(RR.get((i,),K.zero)) for i in range(10)]; ee=[mod(E.get((i,),K.zero)) for i in range(10)]
    check(rr==[23,26,9,23,13,0,11,16,10,8] and ee==[28,5,17,4,2,15,24,10,28,3],'N7 modular polynomial transcription')
    U=[21,24,2,5,25,23,15,2,18];V=[18,28,0,22,8,2,16,25,10]
    product=[0]*18
    for aa,bb in [(U,rr),(V,ee)]:
        for i,a in enumerate(aa):
            for j,b in enumerate(bb):product[i+j]=(product[i+j]+a*b)%29
    check(product==[1]+[0]*17,'N7 short modular Bezout')
    check([mod(a) for a in [H,gb(4,2,q),gb(5,2,q),gb(6,2,q),gb(4,2,q**-1)]]==[19,8,9,23,18],'N7 listed good reduction values')
    check(all(mod(sum((q**i for i in range(a+1)),K.zero)) for a in range(2,6)),'N7 all original first row denominators survive')
    # Compute the claimed multiplication determinant independently over F29.
    def pred(v):
        v=list(v)
        for i in range(len(v)-1,8,-1):
            mult=v[i]*pow(rr[9],-1,29)%29
            for j in range(10):v[i-9+j]=(v[i-9+j]-mult*rr[j])%29
        return v[:9]+[0]*max(0,9-len(v))
    cols=[pred([0]*i+ee) for i in range(9)]
    A=[list(row) for row in zip(*cols)];det=1
    for i in range(9):
        pivot=next(j for j in range(i,9) if A[j][i])
        if pivot!=i:A[pivot],A[i]=A[i],A[pivot];det=-det
        det=det*A[i][i]%29; iv=pow(A[i][i],-1,29)
        for j in range(i+1,9):
            factor=A[j][i]*iv%29
            A[j]=[(a-factor*b)%29 for a,b in zip(A[j],A[i])]
    check(det==19,'N7 reduced multiplication determinant')
    RA,aa,xx,zz=ring('A,x,z',K)
    mm=[aa*xx**j+(1-aa)*zz**j for j in range(5)]
    DD=mm[2]-mm[1]**2;SS=mm[3]-mm[1]*mm[2];PP=mm[1]*mm[3]-mm[2]**2
    check(SS==(xx+zz)*DD and PP==xx*zz*DD and not (DD*mm[4]-SS*mm[3]+PP*mm[2]),'N7 recurrence identities including degenerate atoms')
    results['N7_lower']={'source_polynomials_match':True,'exact_rational_bezout':True,'short_modular_bezout':True,'good_reduction_denominators':True,'modular_multiplication_determinant':det,'degeneracy_free_recurrence_identities':True}
    print('N7 lower complete',flush=True)

def n7upper():
    K,q=field(7); zero=K.zero;one=K.one
    s2=(-8+35*q+25*q*q+28*q**3+q**4-17*q**5)/29
    s3=(-3-5*q-16*q*q-4*q**3+4*q**4+19*q**5)/29
    disc=-4*s2**3-27*s3*s3
    check(disc==(665859+635064*q+863499*q*q+425987*q**3+275146*q**4-15036*q**5)/24389 and bool(disc) and bool(s3),'N7 cubic discriminant and nonzero roots')
    H=q/(1+q); m=[one,-1-q-q*q-q**4-2*q**5,q,-1-2*q*q-q**3-q**4-q**5,-2*q*q-2*q**3-q**4-q**5]
    D=m[2]-m[1]**2
    check(D==1+4*q-q*q+3*q**4 and s2==(m[1]*m[3]-m[4])/D and s3==m[3]+s2*m[1],'N7 cubic compatibility')
    p=[[one,zero,zero],[zero,one,zero],[zero,zero,one]]
    for r in range(3,8):p.append([-s2*a+s3*b for a,b in zip(p[r-2],p[r-3])])
    def matrix(b):
        mat=[]
        for a in range(7):
            gs=[coefficient(7,q,e,d,one,a,b) for e,d in [(1,1),(-1,1),(1,-1),(-1,-1)]]
            mat.append([gs[0]*u for u in p[a]]+[gs[1],gs[2]]+[gs[3]*u for u in p[(-a)%7]])
        return mat
    cols={0:[0,1,2,3,5,6,7],2:[0,1,2,3,4,5,6],3:[0,1,2,3,4,6,7]}
    dets={0:-(370501134818472+889546502909192*q+1166936870814012*q*q+994193630954024*q**3+501377982443436*q**4+58844381586428*q**5)/500246412961,2:(726-4387*q-12368*q*q-16345*q**3-13989*q**4-6744*q**5)/841,3:1+3*q+5*q*q+5*q**3+3*q**4+q**5}
    z={}
    for b in (0,2,3):
        A=matrix(b);sol,det,_=solve([[row[i] for i in cols[b]] for row in A],[f(7,q,a,b) for a in range(7)])
        check(det==dets[b] and bool(det),'N7 determinant '+str(b))
        z[b]=[zero]*8
        for i,v in zip(cols[b],sol):z[b][i]=v
    J=lambda v:v[5:8]+[v[4],v[3]]+v[:3]
    z[4]=J(z[3]);z[5]=J(z[2]);K0=H*(m[2]+s2)/s3
    z[1]=[K0,H,H*m[1],H,q*q-K0-H,zero,zero,zero];z[6]=J(z[1])
    witness=json.loads((DOC/'certificate_data/N7_EXACT_WITNESS.json').read_text())
    ranks=[]
    for b in range(7):
        A=matrix(b)
        check(matvec(A,z[b])==[f(7,q,a,b) for a in range(7)],'N7 solved row '+str(b))
        ranks.append(len(solve(A)[2]))
        check([val(v,q) for v in witness['row_results'][str(b)]['transformed_amplitudes']]==z[b],'N7 frozen transformed amplitude '+str(b))
    check(ranks==[7,5,7,7,7,7,5],'N7 ranks')
    R,t=ring('t',K);g=t**3+s2*t-s3;gp=3*t*t+s2
    def rem(a):return R(a).rem(g)
    def inv(a):
        a=rem(a); mat=[]
        columns=[rem(a*t**i) for i in range(3)]
        for j in range(3):mat.append([c.get((j,),zero) for c in columns])
        sol,det,_=solve(mat,[one,zero,zero]);check(bool(det),'N7 cubic inverse is unit')
        v=sum((R(c)*t**i for i,c in enumerate(sol)),R.zero);check(rem(a*v)==R.one,'N7 cubic inverse product');return v
    gpi=inv(gp);guard=-rem(t**7);guardi=inv(guard)
    sectors=[[R.zero for _ in range(7)] for _ in range(4)]
    for b in range(7):
        for group,offset,d in [(0,0,1),(3,5,-1)]:
            k0,k1,k2=z[b][offset:offset+3]
            sectors[group][(d*b)%7]=rem((k2+t*k1+(t*t+s2)*k0)*gpi)
        sectors[1][b]=R(z[b][3]);sectors[2][(-b)%7]=R(z[b][4])
    for group in range(4):
        for ell in range(7):
            data=witness['sector_polynomials_group_order_pp_mp_pm_mm'][group][ell]
            stated=sum((R(val(v,q))*t**i for i,v in enumerate(data)),R.zero)
            check(stated==sectors[group][ell],'N7 frozen sector polynomial')
    # Literal branch matrices over the cubic algebra. Polynomial reduction after
    # every multiplication keeps the separable quotient algebra exact.
    def emul(A,B):
        return [[rem(sum((a*b for a,b in zip(row,col)),R.zero)) for col in zip(*B)] for row in A]
    I=eye(7,R.one);total=blank(7,7,zero); C=sum((q**((-j*j)%7) for j in range(7)),zero)/7
    trace=lambda v:3*v.get((0,),zero)-2*s2*v.get((2,),zero)
    for group,(e,d) in enumerate([(1,1),(-1,1),(1,-1),(-1,-1)]):
        alpha=t if group in (0,3) else R.one
        guard=-rem(alpha**7);guardinv=guardi if group in (0,3) else -R.one
        for j in range(7):
            X=blank(7,7,R.zero)
            for col in range(7):
                X[(col+e)%7][col]+=alpha
                X[col][col]+=q**((e*d*j+d*col)%7)
            power=I;series=I
            for k in range(1,7):power=emul(power,X);series=madd(series,power)
            seventh=emul(power,X)
            check(seventh==scale(I,rem(alpha**7+1)),'N7 original X7')
            inverse=[[rem(v*guardinv) for v in row] for row in series];B=madd(I,scale(X,-R.one))
            check(emul(B,inverse)==I and emul(inverse,B)==I,'N7 both literal inverse products')
            w=rem(C*guard*sum((sectors[group][ell]*q**((-e*d*j*ell)%7) for ell in range(7)),R.zero))
            for a in range(7):
                for b in range(7):
                    v=rem(w*inverse[a][b])/7
                    total[a][b]+=trace(v) if group in (0,3) else v.get((0,),zero)
    check(total==[[q**((-a*b)%7) for b in range(7)] for a in range(7)],'N7 original trace Fourier equality')
    results['N7_upper']={'cubic_and_minors':True,'row_ranks':ranks,'all_frozen_transformed_amplitudes_and_sector_polynomials_match':True,'literal_algebra_phase_checks':28,'represented_original_inverses':56,'original_Fourier_entries':49}
    print('N7 upper complete',flush=True)

def n9():
    K,q=field(9)
    p3=-q**5+q**3-q*q-q+1;p2=-q**4+2*q*q-1;p1=q**4-q*q+q+1;p0=q*q
    check(p1==q*p3 and p3*(q*q+1)==K.one,'N9 pair elimination')
    E=(1+q)**2*(p2-1-q*q)-q*p3*p3
    check(E==q**5-q**4+2*q*q-2*q-3,'N9 elimination polynomial')
    check(E*(2*q**5-q**4+3*q*q-3*q+2)==3*K.one,'N9 inverse residue')
    ps=[p0,p1,p2,p3,K.one]
    for a in range(1,5):check(sum((ps[i]*f(9,q,a+i,1) for i in range(5)),K.zero)==K.zero,'N9 recurrence')
    A=[[f(9,q,a+i,1) for i in range(4)] for a in range(1,5)]
    check(bool(solve(A)[1]),'N9 recurrences determine coefficients uniquely')
    results['N9_retained_lower_bound']={'recurrence_and_nonzero_elimination':True}

if __name__=='__main__':
    provenance();n3();n5();n7lower();n7upper();n9()
    results['checks']=checks
    results['source_research_programs_read_parsed_imported_or_executed']=False
    results['fresh_control_only']=True
    (OUT/'FRESH_CONTROL_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2),flush=True)
