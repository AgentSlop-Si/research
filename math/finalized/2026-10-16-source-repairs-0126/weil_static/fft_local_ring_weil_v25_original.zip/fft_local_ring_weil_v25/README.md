# fft_local_ring_weil_v25

Exact finite-field certificates for the p-adic valuation hierarchy of one-dimensional Weil operators over `Z/p^k Z`.

## Run

```bash
python run_all.py
```

The suite verifies the Gauss kernel, support hierarchy, root-order invariant, `SL_2` valuation counts, subgroup obstruction, operation ledger, independent implementation, predecessor hash, manifest and ZIP-independent source integrity.

## Scope

This is a scoped exact theorem and negative gate. It does **not** construct a faster exact FFT.
