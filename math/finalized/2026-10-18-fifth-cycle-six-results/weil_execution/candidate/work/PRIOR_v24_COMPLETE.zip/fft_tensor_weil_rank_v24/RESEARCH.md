# Tensor Weil rank hierarchy and the cyclic prime-power FFT gate — v24

**Checkpoint:** 10 October 2026  
**Primary target:** exact full-output DFT of arbitrary fresh input in fully charged sequential `o(N log N)` arithmetic.  
**Status:** the higher-dimensional finite-field symplectic/tensor route is classified at the operator level. It yields a genuine hierarchy of partial tensor Fourier cores, but it does **not** contain the cyclic length-`p^n` DFT when `n>1`. **No faster cyclic FFT is constructed.**

## 1. Starting point

v23 closed every finite word in the one-dimensional Weil representation of `SL_2(F_p)`: after multiplying the underlying `2 x 2` symplectic matrices, the operator is either a chirp/permutation monomial or one complete `p`-point DFT surrounded by monomial work.

The proposed escape was to increase the symplectic dimension. In `Sp(2n,F_p)`, the representation space has dimension

\[
N=p^n,
\]

and partial Fourier transforms on only some tensor coordinates become possible. This checkpoint asks two separate questions:

1. Does higher dimension create a genuinely new hierarchy of exact operators?
2. Can that hierarchy contain the **cyclic** DFT of length `p^n`, rather than the additive-group/tensor DFT on `F_p^n`?

The answer is:

* **yes** to the first question: the hierarchy is indexed by an integer rank `r=0,...,n`;
* **no** to the second: a root-order cross-ratio invariant separates the cyclic and tensor transforms exactly.

---

## 2. Higher-dimensional setup

Let

\[
V=\mathbb F_p^n
\]

for an odd prime `p`, and write a symplectic matrix as

\[
S=
\begin{pmatrix}
A&B\\
C&D
\end{pmatrix}
\in Sp(2n,\mathbb F_p).
\]

Use the lower Siegel parabolic

\[
P_-=
\left\{
\begin{pmatrix}
A&0\\
C&A^{-T}
\end{pmatrix}
:
A\in GL_n(\mathbb F_p),\ A^TC\text{ symmetric}
\right\}.
\]

In the position model of the finite Weil representation on functions `V -> K`:

* the `GL_n` block is a coordinate permutation;
* the symmetric lower block is a diagonal quadratic chirp;
* therefore every `P_-` operator is monomial in the position basis, up to a nonzero projective scalar.

For `r=0,...,n`, let `w_r` swap the first `r` position coordinates with their momentum coordinates and leave the other `n-r` coordinates fixed. Its Weil operator is exactly

\[
\mathcal F_p^{\otimes r}\otimes I_{p^{n-r}},
\]

a partial tensor Fourier transform.

---

## 3. Main structural theorem: the rank hierarchy

The Siegel-parabolic double cosets are indexed by the rank of the upper-right symplectic block:

\[
\boxed{
S\in P_- w_r P_-
\quad\Longleftrightarrow\quad
r=\operatorname{rank}_{\mathbb F_p}B.
}
\tag{3.1}
\]

Consequently, projectively,

\[
\boxed{
\rho(S)=M_1
\left(\mathcal F_p^{\otimes r}\otimes I_{p^{n-r}}\right)
M_2,
}
\tag{3.2}
\]

where `M_1,M_2` are chirp/permutation monomial operators.

### Theorem 3.1 — exact support law

Every row and every column of `rho(S)` has exactly

\[
\boxed{p^r}
\]

nonzero entries, where `r=rank(B)`.

**Proof.** The canonical partial Fourier core has `p^r` nonzero entries in each row and column: the untransformed coordinates are fixed by Kronecker deltas, while all `p^r` combinations of the transformed coordinates occur. Left/right monomial factors preserve zero patterns and row/column support counts. QED.

This yields `n+1` exact operator classes:

| rank `r` | zero pattern | canonical core |
|---:|---:|---|
| `0` | one nonzero per row/column | chirp/permutation only |
| `1` | `p` nonzeros per row/column | one-coordinate `p`-DFT |
| `r` | `p^r` nonzeros per row/column | `r`-coordinate tensor DFT |
| `n` | dense | full `F_p^{\otimes n}` |

Unlike the one-dimensional v23 dichotomy, higher-dimensional Weil geometry really does have intermediate partial-Fourier classes.

---

## 4. Exact fusion of arbitrary metaplectic words

Let `S_1,...,S_t` be any finite word in `Sp(2n,F_p)`. Multiply the symplectic matrices first:

\[
S=S_t\cdots S_1.
\]

The entire projective operator word then collapses to the single normal form (3.2), with

\[
r=\operatorname{rank}B(S).
\]

So arbitrary depth does not generate an operator outside the rank hierarchy. The complete word contains, after exact fusion, at most one partial tensor Fourier core.

### Rank-budget inequality

For two block matrices `S,T`,

\[
B(ST)=A(S)B(T)+B(S)D(T).
\]

Therefore

\[
\boxed{
\operatorname{rank}B(ST)
\le
\operatorname{rank}B(S)+\operatorname{rank}B(T).
}
\tag{4.1}
\]

Inductively, if a factorization reaches the full tensor Fourier Weyl element `w_n`, then

\[
\boxed{
\sum_{j=1}^t \operatorname{rank}B(S_j)\ge n.
}
\tag{4.2}
\]

This is a structural rank budget, not an unrestricted arithmetic lower bound.

### Canonical tensor FFT attains the budget

The `n` one-coordinate Weyl swaps commute, and

\[
w_n=w_{\{1\}}w_{\{2\}}\cdots w_{\{n\}}.
\]

In the Weil representation this is

\[
\mathcal F_p^{\otimes n}
=
\prod_{j=1}^n
\left(I\otimes\cdots\otimes \mathcal F_p\otimes\cdots\otimes I\right).
\]

A direct dense `p x p` implementation uses

\[
r\,pN
\]

scalar multiply-add terms for a rank-`r` partial transform, and

\[
n\,pN=\Theta_p(N\log_p N)
\]

for the full tensor transform. The operation ledger in this package records those explicit counts.

This is the ordinary radix-`p` tensor FFT. The rank budget explains why merely splitting a tensor Fourier core among lower-rank metaplectic stages reproduces the standard coordinate-by-coordinate transform rather than a new exponent.

**Important boundary.** Equation (4.2) does not prove that an unrestricted joint arithmetic DAG must pay `Omega(Nn)`. It only classifies the metaplectic stages and the literal partial-transform schedule. A different non-metaplectic joint evaluator remains logically outside the theorem.

---

## 5. Main obstruction: cyclic `F_{p^n}` is not a tensor Weil operator

Let

\[
q=p^n,
\qquad n>1,
\]

and let the cyclic Fourier matrix be

\[
C_q[i,j]=\zeta_q^{ij},
\]

where `zeta_q` is a primitive `q`th root.

For a dense matrix with nonzero entries, define the cross ratio

\[
\Lambda_{i,k;j,l}(H)
=
\frac{H_{ij}H_{kl}}{H_{il}H_{kj}}.
\]

This quantity is invariant under:

* arbitrary row and column permutations;
* arbitrary nonzero row and column diagonal scalings.

It is the elementary `2 x 2` ratio underlying the Haagerup invariant for complex Hadamard matrices.

### Tensor/Weil cross ratios

For the standard tensor Fourier matrix

\[
T[x,y]=\omega_p^{x\cdot y},
\]

we have

\[
\Lambda(T)
=
\omega_p^{(x-x')\cdot(y-y')},
\]

so every cross ratio is a `p`th root of unity.

Every dense higher-dimensional Weil operator has `r=n` and is monomially equivalent to `T` by (3.2). Therefore all its cross ratios lie in

\[
\mu_p.
\]

### Cyclic witness

For the cyclic matrix, choose rows `0,1` and columns `0,1`:

\[
\Lambda_{0,1;0,1}(C_q)=\zeta_q,
\]

which has order `q=p^n`, not order dividing `p`.

Hence:

\[
\boxed{
C_{p^n}
\text{ is not monomially equivalent to any }
Sp(2n,\mathbb F_p)
\text{ Weil operator when }n>1.
}
\tag{5.1}
\]

If `rank(B)<n`, the Weil operator already has zeros and cannot equal the dense cyclic Fourier matrix. If `rank(B)=n`, the cross-ratio exponent gives the contradiction.

This closes the direct higher-dimensional finite-field embedding of the cyclic prime-power DFT.

---

## 6. The extension-field trap

One might relabel the `p^n` coordinates by elements of the extension field `F_{p^n}` and use the additive Fourier kernel

\[
\psi(\operatorname{Tr}(xy)).
\]

This does not recover the cyclic Fourier matrix.

Choose any basis of `F_{p^n}` over `F_p`. The trace pairing has the form

\[
\operatorname{Tr}(xy)=x^TM y
\]

for an invertible `n x n` matrix `M` over `F_p`. Therefore

\[
\psi(\operatorname{Tr}(xy))
=
\omega_p^{x^TMy}.
\]

The column relabeling `y -> My` converts this exactly into

\[
\omega_p^{x\cdot y},
\]

the tensor Fourier matrix.

So:

\[
\boxed{
\text{the additive DFT on }F_{p^n}
\text{ is }F_p^{\otimes n}
\text{ up to a linear coordinate permutation, not }F_{p^n}^{\rm cyclic}.
}
\tag{6.1}
\]

The exact executable certificate verifies this for arbitrary invertible bilinear forms over `F_3^2`, `F_3^3`, and `F_5^2`.

---

## 7. Fully charged interpretation

The structural theorem does **not** by itself make an arbitrary supplied symplectic operator cheap end to end.

* Applying a prepared monomial chirp/permutation table costs `O(N)` scalar moves/multiplies.
* Constructing a general coordinate permutation `x -> A x` from an arbitrary dense `n x n` matrix can cost `O(n^2N)` base-field work if no structure or table is supplied.
* Constructing all quadratic chirp phases also requires charged preparation.
* The package's explicit operation ledger isolates the partial-Fourier core and does not hide arbitrary stage synthesis.

Thus v24 is an operator classification and an exact obstruction—not a new implementation speed claim.

---

## 8. Exact verification

The package uses finite coefficient fields containing the required roots of unity. Projective normalization factors do not affect zero patterns or cross ratios.

### Exhaustive `Sp(4,F_3)` certificate

A seven-generator breadth-first enumeration produces all

\[
|Sp(4,3)|=51,840
\]

elements. Their upper-right block ranks are:

| `rank(B)` | count |
|---:|---:|
| 0 | 1,296 |
| 1 | 15,552 |
| 2 | 34,992 |

The total and distribution are independently reproduced by a second implementation.

### Random word support certificates

Exact operator products were tested over finite fields for:

* `p=3,n=2`, dimension `9`;
* `p=3,n=3`, dimension `27`;
* `p=5,n=2`, dimension `25`.

For every tested word, every row and column had exactly

\[
p^{\operatorname{rank}B}
\]

nonzero entries.

### Exact cross-ratio certificates

The cyclic witnesses had exact multiplicative orders:

| `p` | `n` | dimension | cyclic witness order |
|---:|---:|---:|---:|
| 3 | 2 | 9 | 9 |
| 3 | 3 | 27 | 27 |
| 5 | 2 | 25 | 25 |

Every sampled tensor and dense-Weil cross ratio had `p`th power equal to one.

### Test status

\[
\boxed{10/10\text{ automated test groups pass}.}
\]

The predecessor v23 archive is embedded and hash-checked. The final manifest and ZIP CRC are checked in the cold run.

---

## 9. Prior-art and claim boundary

The following ingredients are classical:

* the finite Weil representation on functions on `F_p^n`;
* the appearance of the DFT inside `Sp(2n,F_p)`;
* Siegel-parabolic double cosets indexed by the rank of one off-diagonal block;
* cross-ratio/Haagerup invariants under monomial equivalence of complex Hadamard matrices;
* tensor/radix-`p` Fourier factorization.

The project-specific contribution is the combined computational gate:

1. turn the parabolic rank into an exact row/column-support and partial-Fourier hierarchy;
2. derive the additive stage-rank budget;
3. use the cross-ratio exponent to rule out the cyclic `p^n` DFT and the extension-field relabeling loophole;
4. provide exact finite-field certificates and a charged operation ledger.

This is **not** a literature-wide novelty proof and no priority claim is made.

---

## 10. Honest conclusion and next gate

We still do **not** have an exact `o(N log N)` cyclic FFT.

What v24 proves is:

\[
\boxed{
\text{higher-dimensional finite-field metaplectic geometry yields only partial tensor Fourier cores.}
}
\]

It does create intermediate ranks `1,...,n-1`, but those ranks reproduce the ordinary tensor FFT hierarchy.

And:

\[
\boxed{
\text{the cyclic length-}p^n\text{ DFT cannot be embedded into that hierarchy for }n>1.
}
\]

The next exact symplectic target is therefore no longer `Sp(2n,F_p)`. It is the finite-ring Weil representation over

\[
\mathbb Z/p^k\mathbb Z,
\]

where `p^k`th roots—and hence the cyclic prime-power character table—are native. The precise next question is:

> Classify the finite-ring symplectic cells by the `p`-adic valuation of the off-diagonal block, determine whether the corresponding Weil operators are partial cyclic FFTs on residue classes, and audit whether any nonunit cell admits a joint evaluator below the ordinary radix-`p` cost.

A second surviving route is a non-Weil high-treewidth exact stage with a genuinely non-Krylov linear-time solver.
