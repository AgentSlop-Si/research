# FFT tensor-Weil rank hierarchy v24

This package continues the exact FFT research after v23.

## Main result

For `S=[[A,B],[C,D]] in Sp(2n,F_p)`, the finite Weil operator is projectively equivalent to a partial tensor Fourier transform on exactly `rank(B)` coordinates, surrounded by chirp/permutation monomial operators. It therefore has exactly `p^rank(B)` nonzeros per row and column.

The cyclic length-`p^n` DFT is not monomially equivalent to any such operator for `n>1`: its cross-ratio set contains a primitive `p^n`th root, while dense tensor-Weil cross ratios are only `p`th roots.

## Reproduce

```bash
python run_all.py
```

The run performs:

- 10 automated test groups;
- exhaustive generation of all 51,840 elements of `Sp(4,3)`;
- exact random-word support checks;
- exact cross-ratio order checks;
- an independent verifier;
- manifest verification.

## Files

- `RESEARCH.md` — theorem, proofs, scope and next gate.
- `CHAIN_CHECKPOINT_2026-10-10_v24.md` — compact recovery checkpoint.
- `tensor_weil.py` — exact finite-field implementation.
- `group_audit.py` — exhaustive `Sp(4,3)` and support audit.
- `cross_ratio_gate.py` — cyclic-vs-tensor invariant certificate.
- `independent_verifier.py` — independent implementation.
- `test_checkpoint.py` — automated tests.
- `OPERATION_LEDGER.csv` — explicit partial-transform work counts.
- `PRIOR_v23_COMPLETE.zip` — exact predecessor archive.

## Claim boundary

No exact sub-`N log N` cyclic FFT is constructed. The package classifies a higher-dimensional metaplectic route and rules out a cyclic prime-power embedding into the finite-field tensor Weil representation.
