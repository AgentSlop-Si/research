# Reproduction

Requirements: Python 3.11+; no third-party Python packages.

```bash
python run_all.py
```

The exhaustive `Sp(4,3)` audit is the longest step and normally completes in seconds.

To verify the archive after extraction:

```bash
sha256sum -c MANIFEST.sha256
```
