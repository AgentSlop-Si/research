# Gaussian global optimizer: complete N=3, d=2 proper-complex classification

Accepted public research packet, 20 October 2026. The separate fresh source-bound review has accepted the frozen completion without corrections.

## Exact theorem and scope

For every finite a>0, q_j≥0, ∑q_j=1, u_j=√q_j, let Z∼CN(0,I−uu*) on its complex two-plane in C³, with intrinsic density π⁻²exp(−‖z‖²). Define F_a(q)=Pr(max_j |Z_j|≤√a). This is the original centered N=3, complex-rank d=2 proper-complex model, not a real Gaussian substitute.

The exact global maximum is max(B(a),S(a)), where B(a)=(1−e^(−a))(1−e^(−2a)) and S(a)=F_a(1/3,1/3,1/3). There is exactly one transverse crossing a_* with 1/2<a_*<2. Modulo coordinate permutations and phases, the maximizing normal weights are:

- (0,1/2,1/2) for 0<a<a_*;
- (1/3,1/3,1/3) for a>a_*;
- exactly those two types at a=a_*.

The original threshold is r=√a, so 1/√2<r_*<√2. No decimal approximation or closed-form value of a_* is claimed.

On the reduced branch f_a(c)=F_a(c,(1−c)/2,(1−c)/2), 0≤c≤1/3, put t=√(c/(1−c)), Φ_a(t)=f_a(t²/(1+t²)), and Φ_a′=2(P−N), with positive P,N as defined in the proof. The new theorem is (log(N/P))″>0 for every a>0 and 0<t<1/√2. It implies exactly one interior stationary point, a nondegenerate strict minimum, and strict endpoint domination at every interior point, including the endpoint tie. The accepted structural equality classification and endpoint crossing then give the full optimizer above.

No claim is made for general N, other ranks, a real-Gaussian analogue, strictness at a=0 or infinity, or a faster FFT algorithm. Earlier centering results are background, not reproved here; the probability objective in this packet is explicitly centered.

## What this release supersedes

The full accepted scalar completion supersedes the previously open scalar uniqueness, endpoint dominance, and all-radius optimizer gap in the included 20 October 2026 scalar/structural packets. Their old README exclusions, open labels, source-candidate status, and original release JSON remain unchanged as dated history. They describe the earlier state of knowledge, not this release's current theorem. Only root RELEASE.json and the new fresh review state the current completion disposition. Unrelated earlier questions are not automatically resolved.

## Reading order

1. candidate/PROOF.md: complete analytic argument and exact equality classification. Its historical pre-review status is retained, but its Sections 1–9 are unchanged and now accepted.
2. reviews/fresh/REVIEW.md and VERDICT.json: separate fresh source-bound acceptance. INDEPENDENT_RECONSTRUCTION.md is the pre-candidate review reconstruction, retained as historical evidence rather than a second acceptance.
3. DEPENDENCIES.md and dependencies/scalar: the complete prior accepted scalar, endpoint, structural, and stationary proof chain.
4. COLLABORATION.md: contribution roles and the independent-review boundary.
5. PROVENANCE.md, SOURCE_BINDINGS.json, and provenance/: disclosed public projections, original identities, and source-preservation evidence.

## Cold offline replay

Recorded environment: Python 3.12.14 and SymPy 1.14.0. With SymPy already installed (the version is pinned in requirements.txt), verification needs no network, private source directory, numeric quadrature, or optimizer search.

From a freshly extracted copy run:

    python verify_package.py --replay --negative-controls --require-accepted

To authenticate against a separately trusted release digest also pass:

    --expected-manifest-sha256 THE_TRUSTED_MANIFEST_HASH

The verifier checks the complete file set, original/public identities, fixed analytic-core seals, fresh acceptance, exact scope and dependency seals. It reruns 67 completion-author and 63 fresh-review mathematical controls, plus all 225 mathematical controls of the nested prior packets: 355 in total. All generated outputs must match the sealed bytes. Execution occurs in temporary copies and leaves the extracted packet unchanged.

The author's original 85 checks include 18 historical original-source checks; the fresh review's 143 include 80 such checks. Those 98 checks remain preserved as historical pass/fail evidence but are not misrepresented as portable mathematical replay against unavailable originals. Current public integrity checks replace their byte-verification role. See controls/author/PORTABLE_CONTROLS.md and reviews/fresh/PORTABLE_CONTROLS.md. The nested packet has its own equally explicit historical-versus-replay distinction.

Negative controls exercise tampered, missing and extra members, wrong source identities, nonindependent or pending acceptance, resealed scope changes, projection/core drift, dependency drift, malformed manifests and external-digest mismatch. They test packaging defenses, not theorem truth.

## Evidence limits

The universal theorem rests on the analytic proofs, not the finite control count. Symbolic controls verify algebraic consistency and exact certificates; hashes establish byte integrity relative to a trusted digest, not correctness, historical authorship, or priority. An unsigned archive and verifier can both be replaced, so obtain a trusted manifest/archive digest separately when authenticity matters. Numerical exploration is not used as proof. Approximate values appearing in an unchanged historical endpoint source are explicitly non-certified diagnostics.
