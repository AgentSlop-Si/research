#!/usr/bin/env python3
"""Exact symbolic consistency controls. No floating quadrature or optimizer search."""
from pathlib import Path
import json
import sympy as S

checks=[]
def check(name, cond, detail=''):
    ok=bool(cond)
    checks.append({'name':name,'pass':ok,'detail':detail})
    if not ok: raise AssertionError(name)
def zero(name, expr):
    check(name,S.simplify(expr)==0,str(S.simplify(expr)))

c,t,x,u,v,a=S.symbols('c t x u v a',positive=True)
r2=S.sqrt(2)
V=S.Matrix([[S.sqrt(1-c),0],[-S.sqrt(c)/r2,1/r2],[-S.sqrt(c)/r2,-1/r2]])
n=S.Matrix([S.sqrt(c),S.sqrt((1-c)/2),S.sqrt((1-c)/2)])
G=S.simplify(V.T*V)
for i in range(2):
    for j in range(2):zero(f'frame_gram_{i}{j}',G[i,j]-int(i==j))
# Verify normal identity with a square-root-safe substitution c=z^2/(1+z^2).
Vs=S.Matrix([[1/S.sqrt(1+t*t),0],[-t/S.sqrt(2*(1+t*t)),1/r2],[-t/S.sqrt(2*(1+t*t)),-1/r2]])
ns=S.Matrix([t/S.sqrt(1+t*t),1/S.sqrt(2*(1+t*t)),1/S.sqrt(2*(1+t*t))])
for j,e in enumerate(ns.T*Vs):zero(f'frame_normal_{j}',e)
zero('normal_unit',(ns.T*ns)[0]-1)
ct=t*t/(1+t*t)
zero('parameter_inverse',ct/(1-ct)-t*t)
zero('parameter_derivative',S.diff(ct,t)-2*t/(1+t*t)**2)
zero('physical_endpoint',ct.subs(t,1/r2)-S.Rational(1,3))
zero('A_conversion',a/(1-ct)-a*(1+t*t))
zero('upper_lens_argument',ct*a*(1+t*t)-a*t*t)
arg=t*S.sqrt(x)/S.sqrt(1+t*t)
zero('argument_derivative',S.diff(arg,t)-S.sqrt(x)/(1+t*t)**S.Rational(3,2))
xu=(1+t*t)*u*u/(t*t)
zero('derivative_u_substitution',S.simplify(S.sqrt(xu)/(1+t*t)**S.Rational(3,2)*S.diff(xu,u))-2*u*u/t**3)
zero('derivative_exponent_u',xu-(1+t**-2)*u*u)
zero('derivative_v_substitution',(2/t**3)*(t*v)**2*t-2*v*v)
zero('derivative_exponent_v',(1+t**-2)*(t*v)**2-(1+t*t)*v*v)
zero('fixed_interval_jacobian',S.diff(a*(1+t*t)*v*v,v)-2*a*(1+t*t)*v)
zero('D0_gamma_substitution',2*(S.sqrt(x))**2/(2*S.sqrt(x))-S.sqrt(x))
zero('sqrt_integral',S.integrate(S.sqrt(x),(x,0,a))-S.Rational(2,3)*a**S.Rational(3,2))
# Constants in the holomorphic bound.
check('sqrt2_less_3_over2',S.Rational(3,2)**2>2)
zero('fixed_integral_exponent',(S.Rational(3,2)+S.Rational(5,4))**2-S.Rational(121,16))
zero('J_squared_radius',2+S.Rational(5,4)**2-S.Rational(57,16))
zero('second_exponent',S.Rational(57,16)+S.Rational(25,16)-S.Rational(82,16))
check('sqrt57_less8',57<8**2)
zero('second_coefficient_bound',S.Rational(5,16)*8-S.Rational(5,2))
check('second_exponent_below_fixed',S.Rational(82,16)<S.Rational(121,16))
zero('lens_coefficient_with_pi_lower3',S.Rational(4,3)*(2+S.Rational(5,2))-6)
zero('one_plus_t_squared',1+S.Rational(25,16)-S.Rational(41,16))
zero('Phi_coefficient',2*S.Rational(41,16)*S.Rational(1,2)*6-S.Rational(123,8))
zero('Phi_exponent',S.Rational(41,16)+S.Rational(121,16)-S.Rational(81,8))
check('Phi_coefficient_relaxation',S.Rational(123,8)<16)
check('Phi_exponent_relaxation',S.Rational(81,8)<11)
zero('Cauchy_coefficient',16/S.Rational(1,4)-64)
check('sqrt2_greater7_over5',S.Rational(7,5)**2<2)
check('D0_lower_constant',8*S.Rational(7,5)/(3*S.Rational(22,7))>1)
zero('log_ratio_exponent',11+3-14)
check('exp_3over4_lower2',1+S.Rational(3,4)+S.Rational(3,4)**2/2>2)
check('log64_upper5',6*S.Rational(3,4)<5)
zero('Jensen_rational_bound',4*(5+14*a)-(20+56*a))
check('physical_interval_within3over4',S.Rational(1,2)<S.Rational(3,4)**2)
# Exact shell obstruction.
s=S.Rational(7,4);q=[S.Rational(1,7),S.Rational(3,7),S.Rational(3,7)];p=[1-z for z in q]
zero('shell_normal_sum',sum(q)-1)
zero('shell_pair_threshold2',s*p[1]-1)
zero('shell_pair_threshold3',s*p[2]-1)
zero('shell_active_retained',1/(s*p[0])-S.Rational(2,3))
zero('shell_block_retained',1/s-S.Rational(4,7))
zero('shell_symmetric_retained',S.Rational(9,2)/s-2-S.Rational(4,7))
zero('shell_strict_gap',S.Rational(2,3)-S.Rational(4,7)-S.Rational(2,21))
check('shell_gap_positive',S.Rational(2,21)>0)
# The Hessian lemma is contributed and source-bound, not silently recreated here.
report={'method':'exact symbolic algebra and rational/algebraic inequalities','count':len(checks),'all_pass':all(z['pass'] for z in checks),'checks':checks,'not_proved_by_controls':['No interior local maximum','Unique scalar interior critical point','Global optimizer phase transition','Any floating numerical claim']}
out=Path(__file__).with_name('EXACT_CONTROLS.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'count':len(checks),'all_pass':report['all_pass']}))
