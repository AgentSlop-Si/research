# Gaussian scalar bounds and endpoint comparison

Portable accepted scoped research packet, 20 October 2026.

## Exact scope

Let a>0 be finite, q_j≥0, ∑q_j=1, u_j=√q_j, and Z∼CN(0,I−uu*) on its complex two-plane, with intrinsic density π⁻²exp(−‖z‖²). Put F_a(q)=Pr(max_j |Z_j|≤√a) and f_a(c)=F_a(c,(1−c)/2,(1−c)/2), 0≤c≤1/3. The included accepted structural theorem reduces the global maximum to this closed scalar interval.

This packet proves:

- An exact finite lens integral and regular derivative for f_a, using t=√(c/(1−c)).
- Holomorphic continuation for |t|<√2, and N(a)<20+56a derivative zeros with multiplicity in |t|≤3/4, covering the whole physical interval.
- An explicit negative √c cusp at the block endpoint. The symmetric endpoint has negative-definite full-simplex tangent Hessian. Both endpoints are strict local maxima for every finite a>0; at least one strict interior minimum exists.
- Exactly one transverse crossing of the endpoint values, with certified 1/2<a_*<2. Below it S(a)<B(a), and above it S(a)>B(a), where B(a)=(1−e^(−a))(1−e^(−2a)) and S(a)=f_a(1/3).
- An exact obstruction to a proof shortcut: at squared shell norm 7/4, q=(1/7,3/7,3/7) has directional fraction 2/3, versus 4/7 at both endpoints, a gap of 2/21.

Not established: exclusion or value control of additional interior maxima, uniqueness of the interior stationary point, global endpoint dominance, a global optimizer transition at a_*, or the full all-radius optimizer. The shell counterexample is not a counterexample to the integrated Gaussian endpoint conjecture.

## Reading order

1. RELEASE.json states the current accepted scope. Historical pending labels in source projections are not current release status.
2. candidate/PROOF.md gives the scalar proof; endpoint_contribution/PROOF.md gives the separate endpoint contribution.
3. reviews/fresh/REVIEW.md and VERDICT.json give the fresh, independent, source-bound acceptance.
4. DEPENDENCIES.md explains the included structural/C² proofs and the earlier background that is not used as a substitute for proof.
5. COLLABORATION.md and PROVENANCE.md distinguish contributions, independent acceptance, historical source hashes and public projected hashes.

## Cold replay

Recorded environment: Python 3.12.14, SymPy 1.14.0. Install the pinned symbolic dependency from requirements.txt if needed. Integrity, source/scope checks and negative controls use only Python's standard library; symbolic replay needs SymPy. The replay does not access the network or any original research directory.

From a freshly extracted copy, run:

    python verify_package.py --replay --negative-controls --require-accepted

For authenticity relative to a separately trusted release digest, add:

    --expected-manifest-sha256 THE_TRUSTED_MANIFEST_HASH

The root verifier checks every packaged file, source projections, analytic-core seals, review binding, scope exclusions and the nested dependency seal. It reruns 49 scalar-author, 47 endpoint-author and 57 independent mathematical controls and compares output bytes exactly. It also reruns all four control groups in the structural dependency. Every execution uses temporary copies, leaving the extracted packet unchanged.

The fresh original audit recorded 101 checks: 57 mathematical and 44 historical source-integrity checks. Its full original output is retained, but the 44 original-file checks are not falsely claimed to replay against public projections. Current public integrity checks replace their role, separately from mathematics. See reviews/fresh/PORTABLE_CONTROLS.md.

Negative controls exercise altered, missing and extra members, broken acceptance/source bindings, re-sealed overclaims, projection/core drift, dependency drift, invalid manifests and untrusted digest rejection. They test packaging defenses, not theorem truth.

## Evidence limits

Analytic proofs establish the universal claims; finite symbolic checks are supporting consistency evidence, not exhaustive optimizer searches. Hashes establish byte integrity relative to trusted digests, not correctness or authorship. A party replacing the entire unsigned archive and verifier can create new hashes, so obtain the archive or manifest digest separately when authenticity matters. No historical-priority claim is made. Floating exploration is omitted; any approximate digits retained in the unchanged endpoint proof are explicitly non-certified diagnostics.
