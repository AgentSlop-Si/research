# Public projection, source identity and preservation

This is a public projection, not an undisclosed rewrite of the mathematical sources. Private filesystem locations and internal coordination wording are omitted or replaced by semantic source labels and public relative locators. The mathematical statements, formulas, domains, proofs and exclusions are unchanged.

provenance/PROJECTIONS.json records every newly projected source's original digest/length, public digest/length and disclosed nonmathematical edit. Removed text is represented only by its hash; omitted private strings cannot be reconstructed from this packet. The scalar proof's Sections 1–9, endpoint proof's Sections 1–7 and fresh review's Sections 2–7 are verified byte-identical analytic cores. The embedded structural packet retains its existing projection records and its unchanged manifest.

provenance/original_manifests contains exact original scalar, endpoint and fresh manifests, identifying the historical source sets. These are not current public member lists: some original reports are represented only by their identities, and public projections have distinct hashes. The root MANIFEST.json, not an original manifest, seals the public members.

provenance/SOURCE_BINDINGS.json binds the mathematical dependencies to both historical and packaged public identities. Historical source files were checked before and after construction, including every member of the three frozen source sets, with preservation results in provenance/SOURCE_PRESERVATION.json. This local comparison is reported evidence; a recipient without the historical originals cannot independently reproduce the omitted-original comparison.

All new portable symbolic outputs preserve the corresponding original mathematical checks exactly. Historical original-file hashing is separately documented, not counted as fresh symbolic proof. The packet has no network requirement for verification and contains no exploratory scripts, private work logs or unpublished coordination transcripts.

The public hash chain is internally reproducible. Authenticity of the original identities still requires a trusted source for the supplied digest; hashes alone cannot establish historical provenance or mathematical validity.
