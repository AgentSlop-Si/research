#!/usr/bin/env python3
"""Offline public integrity, scoped acceptance, exact replay and negative controls."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent
SCALAR='502d0551a661fe9424775aa83c10858929c9ba9da4e966a2133b48a953789c32'
ENDPOINT='6fec6e5c708b6bddd3b5efdc74007d8cb9bf0cf2978aa89b2e0a137e06457d66'
FRESH='e85dc6ae11d0e563dd63d85ff21c7ca277c136fe03dc6f0b1dc523dcede7373b'
MANIFESTS={
 'scalar':'9aa32ed9e8ecf51f663e8185927c82cdee84e33687ba5b3daca1abc9eb986ca7',
 'endpoint':'b73f38b4e5de2d9b28d44187d5643eb10f7d3c3cf7cd373f832017a85edb3aa1',
 'fresh':'5eb4a979e5e91d348b594c360d6604447992f9c844e5cb9bda6e0c202c8cb6d9'}
STRUCTURAL='85008206156b6eed3c0585900efa450793617987b1e157da7ab4dc4694e2c839'
SCOPE='proper_complex_finite_positive_radius_scalar_lens_analytic_zero_bound_and_endpoint_comparison'
ACCEPTED=[
 'proper_complex_finite_lens_and_derivative',
 'holomorphic_continuation_abs_t_less_sqrt2',
 'derivative_zero_count_N_less_20_plus_56a_abs_t_le_3over4',
 'strict_negative_block_sqrt_c_cusp',
 'negative_definite_symmetric_tangent_hessian',
 'at_least_one_strict_interior_minimum_every_finite_a',
 'simple_symmetric_endpoint_derivative_zero',
 'unique_transverse_endpoint_value_crossing_half_less_a_star_less_two',
 'exact_shell_domination_counterexample_gap_2over21']
NOT_ESTABLISHED=['global_endpoint_domination','unique_interior_stationary_point','global_optimizer_transition_at_a_star','full_all_radius_optimizer']
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def need(condition,message):
    if not condition:raise ValueError(message)
def safe(root,name):
    need(isinstance(name,str),'Non-string member name.')
    r=PurePosixPath(name)
    need(bool(r.parts) and not r.is_absolute() and '..' not in r.parts and str(r)==name,'Unsafe member name.')
    p=root/name
    need(not p.is_symlink() and p.is_file(),'Missing or symbolic-link member: '+name)
    need(root in p.resolve().parents,'Member escapes packet.')
    return p
def check_manifest(root,expected=None):
    mbytes=(root/'MANIFEST.json').read_bytes();digest=sha(mbytes)
    if expected is not None:need(digest==expected,'Manifest differs from externally trusted digest.')
    seal=(root/'MANIFEST.sha256').read_text().split()
    need(seal==[digest,'MANIFEST.json'],'Manifest seal mismatch.')
    manifest=json.loads(mbytes)
    need(manifest.get('schema')=='gaussian-scalar-portable-v1','Manifest schema mismatch.')
    names=[]
    for entry in manifest['files']:
        name=entry['path'];need(name not in names,'Duplicate manifest member.')
        names.append(name);p=safe(root,name);b=p.read_bytes()
        need(len(b)==entry['bytes'] and sha(b)==entry['sha256'],'Member digest mismatch: '+name)
    actual=[]
    for p in root.rglob('*'):
        need(not p.is_symlink(),'Symbolic links are not allowed.')
        if p.is_file():actual.append(p.relative_to(root).as_posix())
    need(set(actual)==set(names)|{'MANIFEST.json','MANIFEST.sha256'},'Unlisted or missing package member.')
    # Hex encodes generic private-location/control markers, not secret values.
    forbidden=[bytes.fromhex(h) for h in [
        '2f776f726b73706163652f','2f686f6d652f6167656e742f','202f726f6f742f','602f726f6f742f',
        '636f6c6c61626f726174696f6e2e73656e645f6d657373616765',
        '636c6f75645f746872656164732e','636f6465783a2f2f746872656164732f',
        '7375626167656e74','636f6f7264696e6174696e6720706172656e74']]
    for name in names:
        data=(root/name).read_bytes()
        need(not any(mark in data for mark in forbidden),'Private path or coordination marker: '+name)
    return digest,len(names)
def verify(root,expected=None,replay=False,require_accepted=False):
    root=root.resolve();digest,members=check_manifest(root,expected)
    release=read(root/'RELEASE.json')
    need(release.get('schema')=='gaussian-scalar-release-v1','Release schema mismatch.')
    need(release.get('status')=='ACCEPTED_SCOPED_RESULTS','Fresh scoped acceptance is required.')
    need(release.get('scope')==SCOPE and release.get('accepted')==ACCEPTED and release.get('not_established')==NOT_ESTABLISHED,'Scope drift or optimizer overclaim.')
    for key in ['proper_complex_only','finite_positive_a_only','fresh_independent_acceptance','collaborative_endpoint_is_not_fresh_acceptance']:
        need(release.get(key) is True,'Missing contract/independence field: '+key)
    need(release.get('full_optimizer_closed') is False and release.get('corrections_required') is False,'Full optimizer overclaim or correction drift.')
    identities={'scalar_source_sha256':SCALAR,'endpoint_source_sha256':ENDPOINT,'fresh_review_source_sha256':FRESH,'scalar_manifest_source_sha256':MANIFESTS['scalar'],'endpoint_manifest_source_sha256':MANIFESTS['endpoint'],'fresh_manifest_source_sha256':MANIFESTS['fresh'],'structural_public_manifest_sha256':STRUCTURAL}
    for k,v in identities.items():need(release.get(k)==v,'Wrong source identity: '+k)
    originals={}
    for label,d in MANIFESTS.items():
        p=root/'provenance/original_manifests'/f'{label}.json'
        need(sha(p.read_bytes())==d,'Historical manifest identity mismatch: '+label)
        originals[label]=read(p)
    original_index={}
    for label,m in originals.items():
        for x in m['files']:original_index[label+'/'+x['path']]=x
    projections=read(root/'provenance/PROJECTIONS.json')
    need(projections.get('mathematics_unchanged') is True,'Mathematical projection drift.')
    records={}
    for x in projections['records']:
        name=x['public_path'];need(name not in records,'Duplicate projection.')
        records[name]=x;p=safe(root,name);b=p.read_bytes()
        need(sha(b)==x['public_sha256'] and len(b)==x['public_bytes'],'Projection binding mismatch: '+name)
        original=original_index.get(x['source_id'])
        need(original is not None,'Unbound projection source: '+name)
        need(original['sha256']==x['source_sha256'] and original['bytes']==x['source_bytes'],'Original projection identity mismatch: '+name)
        need(x['byte_identical']==(x['source_sha256']==x['public_sha256'] and x['source_bytes']==x['public_bytes']),'Incorrect byte-identity label: '+name)
        if 'unchanged_analytic_core' in x:
            core=x['unchanged_analytic_core'];s=b.decode()
            need(s.count(core['start_after'])==1 and s.count(core['end_before'])==1,'Ambiguous analytic-core markers.')
            cb=s.split(core['start_after'],1)[1].split(core['end_before'],1)[0].encode()
            need(sha(cb)==core['sha256'] and len(cb)==core['bytes'],'Analytic-core seal mismatch: '+name)
    for name,identity in [('candidate/PROOF.md',SCALAR),('endpoint_contribution/PROOF.md',ENDPOINT),('reviews/fresh/REVIEW.md',FRESH)]:
        need(records[name]['source_sha256']==identity and 'unchanged_analytic_core' in records[name],'Missing proof/review core or source binding.')
    fresh=read(root/'reviews/fresh/VERDICT.json')
    need(fresh.get('verdict')=='ACCEPT_SCOPED_RESULTS' and fresh.get('fresh_independent_review') is True,'Fresh review independence/acceptance missing.')
    need(fresh.get('corrections_required') is False,'Fresh review corrections drift.')
    need(fresh.get('accepted')==ACCEPTED and fresh.get('not_established')==NOT_ESTABLISHED,'Fresh review scope drift.')
    for k,v in [('scalar_proof_sha256',SCALAR),('endpoint_proof_sha256',ENDPOINT),('review_sha256',FRESH),('scalar_manifest_sha256',MANIFESTS['scalar']),('endpoint_manifest_sha256',MANIFESTS['endpoint'])]:
        need(fresh.get(k)==v,'Fresh review source binding mismatch: '+k)
    preservation=read(root/'provenance/SOURCE_PRESERVATION.json')
    need(preservation.get('all_unchanged') is True,'Source preservation not confirmed.')
    need(all(x.get('unchanged') is True for x in preservation['source_identities']),'Historical source modification reported.')
    bindings=read(root/'provenance/SOURCE_BINDINGS.json')
    need(bindings.get('mathematical_dependencies_included') is True,'Mathematical dependency omission.')
    required_roles=['accepted_all_radius_structural_theorem','fresh_structural_review','structural_acceptance_verdict','accepted_C2_stationary_structure','preserved_small_radius_gaps_localization','collaborative_frozen_endpoint_candidate','collaborative_original_manifest','endpoint_C2_regularity_proof','endpoint_C2_regularity_review','endpoint_accepted_structural_proof','endpoint_fresh_structural_acceptance']
    need([x['role'] for x in bindings['bindings']]==required_roles,'Missing, duplicate or reordered required source binding.')
    dep_proj=read(root/'dependencies/structural/provenance/PROJECTIONS.json')['records']
    dep_index={x['public_path']:x['source_sha256'] for x in dep_proj}
    for x in bindings['bindings']:
        if x['included']:
            p=safe(root,x['public_path'])
            need(sha(p.read_bytes())==x['public_sha256'],'Dependency public binding mismatch.')
            name=x['public_path']
            if name.startswith('dependencies/structural/'):
                sub=name.removeprefix('dependencies/structural/')
                historical=dep_index.get(sub)
                # The structural fresh verdict is itself a public disposition projection.
                if sub=='reviews/fresh/VERDICT.json':
                    historical='f1516513c7b6676613778e1dc7e537799ba5a4478684e9c2546f1c874244c39e'
                need(historical==x['original_sha256'],'Dependency historical binding mismatch.')
            elif name in records:
                need(records[name]['source_sha256']==x['original_sha256'],'Companion historical binding mismatch.')
            else:
                need(name=='provenance/original_manifests/endpoint.json' and x['original_sha256']==MANIFESTS['endpoint'],'Unknown source binding.')
        else:
            need(x['role']=='preserved_small_radius_gaps_localization' and x['public_path'] is None,'A required source was omitted.')
    need(sha((root/'dependencies/structural/MANIFEST.json').read_bytes())==STRUCTURAL,'Structural dependency manifest changed.')
    # Check the mathematical rows themselves, not just script exit codes or totals.
    author=read(root/'controls/author/EXACT_CONTROLS.json')
    endpoint=read(root/'endpoint_contribution/controls/EXACT_CONTROLS.json')
    endpoint_old=read(root/'endpoint_contribution/controls/HISTORICAL_CONTROLS.json')
    hist=read(root/'reviews/fresh/HISTORICAL_CONTROLS.json')
    independent=read(root/'reviews/fresh/INDEPENDENT_CONTROLS.json')
    excluded=('endpoint_bytes_','endpoint_sha_','source_sha_','scalar_bytes_','scalar_sha_','scalar_source_')
    math=[x for x in hist['checks'] if not x['check'].startswith(excluded) and x['check']!='unchanged_endpoint_proof']
    need(len(hist['checks'])==101 and len(math)==57 and independent['checks']==math,'Independent mathematical row drift.')
    need(len(author['checks'])==49 and all(x['pass'] for x in author['checks']),'Author controls failed.')
    need(len(endpoint['checks'])==47 and endpoint['checks']==endpoint_old['checks'] and all(x['pass'] for x in endpoint['checks']),'Endpoint mathematical row drift.')
    need(all(x['passed'] for x in hist['checks']) and all(x['passed'] for x in independent['checks']),'Historical or portable independent controls failed.')
    replay_spec=read(root/'REPLAY.json')
    need([(x['directory'],x['script'],x['output'],x['expected_checks']) for x in replay_spec['controls']]==[
        ('controls/author','exact_controls.py','EXACT_CONTROLS.json',49),
        ('endpoint_contribution/controls','exact_controls.py','EXACT_CONTROLS.json',47),
        ('reviews/fresh','independent_controls.py','INDEPENDENT_CONTROLS.json',57)],'Replay specification drift.')
    results=[]
    if replay:
        for item in replay_spec['controls']:
            with tempfile.TemporaryDirectory(prefix='scalar-control-') as td:
                work=Path(td);directory=item['directory'];script=item['script'];output=item['output']
                shutil.copy2(root/directory/script,work/script)
                env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONPATH',None)
                proc=subprocess.run([sys.executable,'-I',script],cwd=work,env=env,capture_output=True,text=True,timeout=240)
                need(proc.returncode==0,'Exact control failed: '+directory+'/'+script+'\n'+proc.stderr)
                need((work/output).read_bytes()==(root/directory/output).read_bytes(),'Exact replay output mismatch: '+directory+'/'+output)
                data=read(work/output)
                need(len(data['checks'])==item['expected_checks'],'Unexpected replay check count.')
                results.append({'script':directory+'/'+script,'exact_output_match':True,'mathematical_checks':item['expected_checks']})
    # The nested verifier is run on an isolated copy and checks its own complete member set.
    with tempfile.TemporaryDirectory(prefix='scalar-dependency-') as td:
        dep=Path(td)/'structural';shutil.copytree(root/'dependencies/structural',dep)
        cmd=[sys.executable,'-I','verify_package.py','--require-accepted','--expected-manifest-sha256',STRUCTURAL]
        if replay:cmd+=['--replay','--negative-controls']
        proc=subprocess.run(cmd,cwd=dep,capture_output=True,text=True,timeout=300)
        need(proc.returncode==0,'Structural dependency verification failed.\n'+proc.stdout+'\n'+proc.stderr)
        dependency=json.loads(proc.stdout)
        need(dependency.get('all_pass') is True,'Structural dependency did not pass.')
    stationary=read(root/'dependencies/structural/dependencies/stationary/INDEPENDENT_CHECKS.json')
    stationary_math=[v for k,v in stationary.items() if k!='all_exact_checks_pass' and isinstance(v,bool)]
    need(len(stationary_math)==20 and all(stationary_math),'Stationary mathematical controls drift.')
    return {'all_pass':True,'manifest_sha256':digest,'manifest_members':members,'archive_files':members+2,'release_status':release['status'],'full_optimizer_closed':False,'scalar_mathematical_checks':153,'structural_dependency_mathematical_checks':72,'combined_mathematical_checks':225,'historical_fresh_math_checks':57,'historical_fresh_integrity_checks_not_replayed':44,'replays':results,'structural_dependency':dependency}

def reseal(root):
    m=read(root/'MANIFEST.json')
    for e in m['files']:
        b=(root/e['path']).read_bytes();e.update(bytes=len(b),sha256=sha(b))
    b=(json.dumps(m,indent=2)+'\n').encode();(root/'MANIFEST.json').write_bytes(b)
    (root/'MANIFEST.sha256').write_text(sha(b)+'  MANIFEST.json\n')
def negative_controls(root):
    rows=[]
    def run(name,mutate,refresh=False,expected=None):
        with tempfile.TemporaryDirectory(prefix='scalar-negative-') as td:
            p=Path(td)/'packet';shutil.copytree(root,p)
            mutate(p)
            if refresh:reseal(p)
            try:verify(p,expected=expected)
            except (ValueError,KeyError,FileNotFoundError,json.JSONDecodeError,StopIteration) as exc:
                rows.append({'name':name,'rejected':True,'reason':str(exc)})
            else:raise ValueError('Negative control was accepted: '+name)
    def modify_json(p,name,key,value):
        j=read(p/name);j[key]=value;(p/name).write_text(json.dumps(j))
    def refresh_projection(p,name):
        j=read(p/'provenance/PROJECTIONS.json')
        r=next(x for x in j['records'] if x['public_path']==name)
        b=(p/name).read_bytes();r.update(public_bytes=len(b),public_sha256=sha(b))
        (p/'provenance/PROJECTIONS.json').write_text(json.dumps(j))
    def change_verdict(p,key,value):
        modify_json(p,'reviews/fresh/VERDICT.json',key,value)
        refresh_projection(p,'reviews/fresh/VERDICT.json')
    run('altered_scalar_proof',lambda p:(p/'candidate/PROOF.md').write_bytes((p/'candidate/PROOF.md').read_bytes()+b'\n'))
    run('missing_endpoint_proof',lambda p:(p/'endpoint_contribution/PROOF.md').unlink())
    run('unsealed_extra_file',lambda p:(p/'unexpected.txt').write_text('extra'))
    run('resealed_full_optimizer_overclaim',lambda p:modify_json(p,'RELEASE.json','full_optimizer_closed',True),True)
    run('resealed_scope_exclusion_removed',lambda p:modify_json(p,'RELEASE.json','not_established',[]),True)
    run('resealed_wrong_scalar_source',lambda p:modify_json(p,'RELEASE.json','scalar_source_sha256','0'*64),True)
    run('resealed_nonindependent_acceptance',lambda p:change_verdict(p,'fresh_independent_review',False),True)
    run('resealed_wrong_review_source',lambda p:change_verdict(p,'review_sha256','0'*64),True)
    run('externally_trusted_digest_mismatch',lambda p:None,expected='0'*64)
    run('resealed_projection_mismatch',lambda p:(p/'candidate/PROOF.md').write_bytes((p/'candidate/PROOF.md').read_bytes()+b'\n'),True)
    def core_drift(p):
        proof=p/'candidate/PROOF.md';proof.write_text(proof.read_text().replace('20+56a','20+55a'))
        j=read(p/'provenance/PROJECTIONS.json')
        r=next(x for x in j['records'] if x['public_path']=='candidate/PROOF.md')
        b=proof.read_bytes();r.update(public_bytes=len(b),public_sha256=sha(b))
        (p/'provenance/PROJECTIONS.json').write_text(json.dumps(j))
    run('resealed_math_core_drift_with_updated_projection',core_drift,True)
    run('resealed_dependency_manifest_drift',lambda p:(p/'dependencies/structural/MANIFEST.json').write_bytes((p/'dependencies/structural/MANIFEST.json').read_bytes()+b'\n'),True)
    run('resealed_required_source_binding_omission',lambda p:modify_json(p,'provenance/SOURCE_BINDINGS.json','bindings',[]),True)
    def row_drift(p):
        j=read(p/'reviews/fresh/INDEPENDENT_CONTROLS.json');j['checks'][0]['residual']='changed'
        (p/'reviews/fresh/INDEPENDENT_CONTROLS.json').write_text(json.dumps(j))
    run('resealed_independent_mathematical_row_drift',row_drift,True)
    def unsafe(p):
        j=read(p/'MANIFEST.json');j['files'][0]['path']='../outside.txt';(p/'MANIFEST.json').write_text(json.dumps(j))
        (p/'MANIFEST.sha256').write_text(sha((p/'MANIFEST.json').read_bytes())+'  MANIFEST.json\n')
    run('path_traversal_manifest',unsafe)
    def duplicate(p):
        j=read(p/'MANIFEST.json');j['files'].append(j['files'][0]);(p/'MANIFEST.json').write_text(json.dumps(j))
        (p/'MANIFEST.sha256').write_text(sha((p/'MANIFEST.json').read_bytes())+'  MANIFEST.json\n')
    run('duplicate_manifest_member',duplicate)
    return rows
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--replay',action='store_true')
    ap.add_argument('--negative-controls',action='store_true')
    ap.add_argument('--require-accepted',action='store_true')
    ap.add_argument('--expected-manifest-sha256')
    args=ap.parse_args()
    try:
        result=verify(ROOT,args.expected_manifest_sha256,args.replay,args.require_accepted)
        if args.negative_controls:result['negative_controls']=negative_controls(ROOT)
        print(json.dumps(result,indent=2))
    except Exception as e:
        print(json.dumps({'all_pass':False,'error':str(e)},indent=2));sys.exit(1)
