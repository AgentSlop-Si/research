# ALG-036: fresh adversarial acceptance of the scoped scalar packet

Date: 20 October 2026 UTC. Verdict: **ACCEPT the stated scalar, endpoint, and obstruction results at the exact frozen bytes below. The full scalar optimizer remains unresolved.**

I did not participate in either author's pre-freeze proof development. I received only frozen source identities and the dependency list, not proof assistance. I reconstructed the Gaussian measure, lens differentiation, continuation, zero bound, endpoint arguments, and shell obstruction, and wrote separate exact controls. No candidate or inherited source was edited. No historical-priority claim is made.

## 1. Frozen objects and exact disposition

Combined scalar source: identified by provenance/original_manifests/scalar.json; its public proof is candidate/PROOF.md.

- `candidate/PROOF.md`: SHA-256 `502d0551a661fe9424775aa83c10858929c9ba9da4e966a2133b48a953789c32`.
- `MANIFEST.json`: SHA-256 `9aa32ed9e8ecf51f663e8185927c82cdee84e33687ba5b3daca1abc9eb986ca7`.
- All 12 manifest entries match their recorded sizes and hashes. All seven explicit source bindings match.

Original endpoint source: identified by provenance/original_manifests/endpoint.json; its public proof is endpoint_contribution/PROOF.md.

- `PROOF.md`: SHA-256 `6fec6e5c708b6bddd3b5efdc74007d8cb9bf0cf2978aa89b2e0a137e06457d66`.
- `MANIFEST.json`: SHA-256 `b73f38b4e5de2d9b28d44187d5643eb10f7d3c3cf7cd373f832017a85edb3aa1`.
- All four original manifest entries and four source bindings match. The combined packet's endpoint proof is byte-identical to this object.

For every fixed finite a>0, I accept:

1. The actual proper-complex Gaussian scalar lens integral and its exact finite derivative.
2. Holomorphic continuation in t=sqrt(c/(1-c)) throughout |t|<sqrt(2), including zero and the whole physical interval.
3. Fewer than 20+56a complex derivative zeros, counted with multiplicity, in the closed disk |t|<=3/4.
4. The explicit strictly negative sqrt(c) block cusp.
5. The negative-definite full-simplex tangent Hessian at the symmetric normal.
6. At least one strict interior scalar minimum at each finite radius, and a simple derivative zero at the symmetric endpoint.
7. Exactly one transverse crossing of the two endpoint values, with 1/2<a_*<2 and the stated strict comparisons on either side.
8. The exact shell-wise endpoint-domination counterexample, with shell gap 2/21.

No mathematical correction to the frozen proofs is required. These results do not prove that the better endpoint globally dominates every intermediate c, that there is only one interior stationary point, or that a_* is the global optimizer transition. The structural reduction is an accepted dependency; its remaining one-variable optimization is not resolved here.

## 2. Primary Gaussian measure and finite derivative

With independent proper CN(0,1) variables X,Y, the proposed 3-by-2 frame has orthonormal columns, annihilates the stated normal, and has VV*=I-uu*. Therefore its intrinsic density is pi^(-2) exp(-|X|^2-|Y|^2), not a real-Gaussian density with different radial law.

For q=(c,(1-c)/2,(1-c)/2), the first constraint is |X|^2<=a/(1-c). Conditional on X, phase rotation converts the other two constraints to the intersection of radius-sqrt(2a) disks centered at +/-sqrt(c|X|^2). Since |X|^2 has density exp(-x), this proves the finite lens formula with its exact normalization.

In the first quadrant of the lens, the two disk inequalities reduce to

    0<=y<=sqrt(R^2-d^2),
    0<=z<=sqrt(R^2-y^2)-d.

The inner integral is zero at the moving outer endpoint. Its d derivative is minus the integrand at the inner upper endpoint, and completing the square gives precisely h_a in equation (2.3). On the physical scalar branch the shift never exceeds R/2, so the real differentiation stays away from lens collapse. Ordinary local domination justifies the differentiation.

I independently differentiated first in c. Multiplication by dc/dt=2t/(1+t^2)^2 gives the boundary contribution 2at exp(-a(1+t^2)) ell_a(sqrt(a)t). For the integral contribution, u=t sqrt(x/(1+t^2)) gives the factor -2/t^3. Substituting u=t v then cancels the apparent singularity exactly and gives equation (3.2).

A separate check differentiates the fixed-domain formula (3.1). The difference between that differentiated integrand and the proposed derivative integrates to the boundary flux

    2at [v^2 exp(-a(1+t^2)v^2) E_a(tv)] from v=0 to v=1.

Thus both routes give the same derivative, including all factors of 2, a, and 1+t^2.

## 3. Holomorphic continuation: branch and pole audit

The candidate's branch w(z)=sqrt(2-z^2) exists holomorphically on the simply connected disk |z|<sqrt(2), because its radicand has no zero there. Its prescribed value at zero fixes the branch. The integrand defining J_a is then holomorphic and locally uniformly dominated.

The first term in (5.2) is entire in d: x follows a fixed bounded real interval, and J_a(x) is continuous and bounded, including its zero limit at x=sqrt(2). The second term is an integral over a fixed s interval of holomorphic functions with local uniform bounds whenever |d|<sqrt(2). It is the analytic primitive subtracted from the fixed real integral. This proves that the continuation agrees with the physical lens for nonnegative d while remaining holomorphic throughout the stated disk.

As an independent construction, polar coordinates in the lens give, for real 0<=d<sqrt(2),

    E_a(d)=1-(2/pi) integral_0^(pi/2)
      exp(-a [sqrt(2-d^2 sin^2(theta))-d cos(theta)]^2) dtheta.

For each theta, choose the square root positive at d=0. Its possible zeros satisfy |d|>=sqrt(2), so this formula also defines a holomorphic function on the entire claimed disk by uniform domination on compact subdisks. It independently confirms the candidate's continuation and its branch choice.

There are no hidden poles at t=+/-i. The displayed rational c=t^2/(1+t^2) is only the physical reparametrization; the holomorphic continuation is defined by the fixed-domain formula (5.3), which has no denominator. In fact the latter has Phi_a(+/-i)=0. One must not attempt to substitute arbitrary complex c into an originally probabilistic definition instead of using this extension.

Similarly, the real moving-boundary formula for h_a need not be assigned naive complex square roots. Its required analytic continuation is minus the derivative of the lens extension just proved, with the appropriate sqrt(a) scaling. The real identity then extends by the identity theorem. Thus no nested-root ambiguity in the real Cartesian derivative undermines the holomorphic claim.

The negative-real continuation is not the even geometric lens ell_a(|d|). The packet explicitly makes the necessary distinction; otherwise analyticity would indeed contradict the block cusp.

## 4. Norm bounds, Cauchy estimate, and zero count

Every bound in the candidate's chain holds for arbitrary a>0, without a hidden small- or large-radius restriction.

On |d|<=5/4, the first fixed integral is at most 2 exp(121a/16): its length and the J bound multiply to 2, and sqrt(2)+5/4<11/4. For the second term,

    |J_a(ds)| <= (sqrt(57)/4) exp(57a/16),

and its other exponential contributes at most exp(25a/16). Its length factor is |d|<=5/4. Hence its whole bound is (5sqrt(57)/16) exp(82a/16), strictly less than (5/2) exp(121a/16). The factor 4a/pi, with pi>3, yields the asserted 6a exp(121a/16).

In (5.3), |1+t^2|<=41/16 and integral_0^1 v dv=1/2. The resulting prefactor is 123a^2/8 and the combined exponent is 81a/8. Both are strictly below the stated 16a^2 exp(11a) envelope. The entire closed disk of radius 5/4 lies strictly inside the continuation domain because 25/16<2.

For every |t|<=1, a circle of radius 1/4 about t is therefore legitimate for Cauchy's derivative estimate, giving |D_a(t)|<=64a^2 exp(11a). On the other hand, the exact negative value at zero and exp(-x)>=exp(-a) on [0,a] yield

    |D_a(0)| >= (8sqrt(2)/(3pi)) a^2 exp(-3a) > a^2 exp(-3a).

The coefficient is strictly greater than one, for example using sqrt(2)>7/5 and pi<22/7. In particular D_a is not identically zero.

The Jensen step is valid, including zeros on either displayed circle. An independent way to eliminate any boundary-log concern is to take just the finitely many zeros alpha_j in |t|<=3/4, with multiplicity, and form

    G(t)=D_a(t) product_j (1-conj(alpha_j)t)/(t-alpha_j).

Its apparent poles are removable, and on |t|=1 every added factor has modulus one. The maximum-modulus principle at t=0 gives

    |D_a(0)| product_j (1/|alpha_j|) <= max_|t|=1 |D_a(t)|.

There is no zero at zero. Taking logarithms proves exactly

    N(a) log(4/3) <= log(64)+14a.

Finiteness of the selected zeros follows independently from analyticity on a neighborhood of the closed disk and D_a(0) nonzero, not from the claimed bound. Since log(4/3)>1/4 and log(64)<5, the strict N(a)<20+56a follows. Multiplicity and the closed inner disk are both correctly covered. Finally 1/sqrt(2)<3/4, so the whole physical interval is included.

This is a count bound, not an algorithmic isolation of all roots, a simplicity theorem for all roots, or an optimizer certificate.

## 5. Block cusp, symmetric Hessian, and the forced minimum

At zero shift, ell_a(0)=1-exp(-2a) and -ell_a'(0)=4sqrt(2a) exp(-2a)/pi. Substitution in the regular derivative gives D_a(0)=-K(a), with exactly the positive K(a) in the packet. Analyticity gives a differentiable Taylor remainder in t, and t=sqrt(c)+O(c^(3/2)) gives both the cusp and the derivative asymptotic. This is pointwise in fixed finite a, not uniform in a.

For the symmetric Hessian, I checked the accepted C^2 extension and rotation-boundary identity at their source-bound bytes. Permutation symmetry makes the tangent Hessian a scalar lambda times the Euclidean form and makes the tangent gradient zero. Strict smoothing alone would only give a nonpositive curvature conclusion; the candidate correctly supplies a quantitative patch instead.

On rho in [r/3,r/2], cos(phi)<=-3/4, the two boundary arguments at symmetry have upper bound 11a/36, leaving the positive margin 7a/36 below the cutoff a/2. Compactness preserves a strict margin for sufficiently small epsilon>0. There h is the untruncated exponential, and the mean-value theorem bounds its difference below by a positive constant times

    (p-t)(a-rho^2), with a-rho^2>=3a/4 and p-t=3epsilon/s.

The radial interval, angular patch, Gaussian weight, and derivative conversion all have a strictly positive lower contribution for each fixed a. The rest of the boundary integrand is nonnegative by the accepted smallest-weight support argument, including the tied-minimum path used here. Therefore D_w F(q_0+epsilon v)>=C(a)epsilon. C^2 Taylor expansion gives the same quantity as -3lambda epsilon+o(epsilon), so lambda<0. No third derivative or unsupported strictness limit is used.

The scalar endpoint follows with no metric ambiguity. At t_0=1/sqrt(2),

    q'(t_0)=(4sqrt(2)/9)(1,-1/2,-1/2),
    Phi_a''(t_0)=lambda ||q'(t_0)||^2=16lambda/27<0.

Thus D_a(t_0)=0 is simple and D_a is positive immediately to its left, whereas it is negative immediately to the right of zero. A finite set of zeros must contain a negative-to-positive sign change between these two neighborhoods. The function is strictly decreasing before and increasing after that zero locally, hence this gives a strict interior local minimum even if its derivative-zero multiplicity exceeds one. It does not exclude additional maxima or minima.

## 6. Endpoint comparison and transversality

The independent radial measure is R exp(-R)dR for R=|X|^2+|Y|^2; its direction is independent and uniform in the unit sphere of C^2. Scaling R=a s gives

    F_a(q)=a^2 integral_0^3 s exp(-a s) g_q(s) ds.

The factor a^2 and shell weight s are essential and are correct. For the block frame, |X|^2/R is uniform on [0,1], giving the stated three pieces of g_B and the exact product B(a)=(1-exp(-a))(1-exp(-2a)).

For the symmetric frame the Hopf/Bloch image is uniform on S^2. The three coordinate fractions are (1+n dot r_j)/3 with mutual planar angles 2pi/3. For shells up to 2, the excluded caps are disjoint in precisely the range used in the proof, yielding g_S=1 up to 3/2 and g_S=9/(2s)-2 on [3/2,2].

For 2<=s<=3, k=3/s-1 lies in [0,1/2]. Projection of the spherical measure to the r_j plane has density 1/(2pi sqrt(1-|v|^2)); the two hemispheres are both included. The equilateral triangle has circumradius 2k and is contained in the disk. Scaling it from k=1/2 gives g_S<=4k^2 g_S(2)=k^2. The singular weight at the three outer vertices for k=1/2 is integrable; using the original spherical probability proves finiteness. Thus g_S<g_B=k for 2<=s<3.

Consequently Delta(s)=s(g_S-g_B) has exactly the claimed single sign change at tau=7/4, is positive on (1,tau), and is negative on (tau,3). The normalization

    M(a)=integral exp(a(tau-s)) Delta(s) ds

therefore has strictly positive derivative. The derivative and integral exchanges are over a bounded domain with a bounded Delta and uniform bounds on every compact a interval.

The direct disk-intersection volume gives M(0)=1-9sqrt(3)/(4pi)<0. The positive subinterval [5/4,3/2] contributes at least exp(a/4)/16, while the magnitude of the negative contribution is at most 95/32. Hence M tends to positive infinity. There is exactly one finite positive root. Differentiating S-B=a^2 exp(-tau a)M at that root gives a strictly positive derivative, so the crossing is transverse.

I independently integrated both bracket functions. The upper bound at a=1/2 factors as 2(x-1)^2(2x^2-2x-1), x=exp(1/4), and 1<x<4/3 makes it negative. The lower bound at a=2 is exp(2)(e-1)(e-2)-1, positive using e>8/3. Thus 1/2<a_*<2 is a genuine rational certificate, not numerical root finding.

The optional elementary shell antiderivative was separately differentiated in its integration variable and checked at its lower endpoint. The packet's floating crossing digits remain diagnostics, not a certified enclosure and not a basis of this verdict.

## 7. Exact shell obstruction and scope attacks

I independently obtained q=(1/7,3/7,3/7), shell s=7/4, before reading the scalar author's frozen counterexample. The row squared norms are (6/7,4/7,4/7). The last two constraints are automatic at this shell; the retained fraction of the first uniform coordinate fraction is 1/[(7/4)(6/7)]=2/3. Both endpoint fractions are 4/7, giving gap 2/21 exactly.

This defeats the pointwise shell inequality against the endpoint envelope. It neither proves that an interior Gaussian probability wins at any a nor refutes the unique endpoint-value crossing, because the Gaussian probability integrates all shells.

Additional attacks checked and excluded:

- Real-Gaussian radial normalization substituted for the complex measure.
- A missing moving-endpoint term or factor in the lens derivative.
- Treating the t^(-3) intermediate formula as singular at zero.
- Hidden rational poles at +/-i or branch points inside the continuation disk.
- Using a complex norm bound only for real parameters or only for some a range.
- Applying Cauchy on a contour outside the holomorphic domain.
- Applying Jensen with a zero at the origin or omitting boundary zeros/multiplicity.
- Inferring negative curvature from mere strict monotonicity.
- Confusing a locally maximizing endpoint with a globally maximizing endpoint.
- Treating the finite stationary-root bound as a root-sign or value comparison.
- Reporting the shell counterexample as a counterexample to the integrated conjecture.

No defect was found in the frozen scoped results. The unresolved operation is the genuine sign/root/value comparison for intermediate c in (0,1/3), not a software or permission blocker.

## 8. Controls and review boundary

The historical independent controls, preserved in HISTORICAL_CONTROLS.json, contain 101 passing checks (57 exact mathematical checks and 44 original-byte integrity checks). The portable independent_controls.py replays the same 57 mathematical checks; original-byte checks are historical evidence, not falsely rerun against projected files. The original checks cover: projector/isometry, radial normalization, block probability, shell algebra and integrals, rational bracket algebra, Hessian patch and tangent metric, independent shell counterexample, derivative integration by parts, continuation-bound arithmetic, and every declared frozen object/source hash. These are supplemental consistency and integrity checks, not a finite optimizer census. No floating quadrature or numerical optimization enters the acceptance.

The earlier authors' collaborative endpoint proof remains a contribution, not an independent acceptance of itself. This document is the separate fresh source-bound review. Candidate labels such as “awaiting review” are not silently rewritten; the accepted disposition is recorded here and in the accompanying verdict.
