#!/usr/bin/env python3
"""Fresh symbolic controls. No floating quadrature or optimizer sampling."""
from pathlib import Path
import sympy as S
import json, hashlib
OUT=Path(__file__).resolve().parent
rows=[]
def zero(name, expr):
    r=S.simplify(expr)
    rows.append({'check':name,'passed':r==0,'residual':str(r)})
    if r!=0: raise AssertionError((name,r))
def test(name, cond, detail=''):
    rows.append({'check':name,'passed':bool(cond),'detail':detail})
    if not cond: raise AssertionError(name)
c=S.symbols('c', positive=True)
v=S.Matrix([[S.sqrt(1-c),0],[-S.sqrt(c/2),1/S.sqrt(2)],[-S.sqrt(c/2),-1/S.sqrt(2)]])
u=S.Matrix([S.sqrt(c),S.sqrt((1-c)/2),S.sqrt((1-c)/2)])
for i in range(2):
 for j in range(2): zero(f'isometry_{i}{j}',(v.T*v-S.eye(2))[i,j])
for i in range(3):
 for j in range(3): zero(f'proper_complex_projector_{i}{j}',(v*v.T-(S.eye(3)-u*u.T))[i,j])
r,a=S.symbols('r a', positive=True)
zero('gamma_shape2_total_mass',S.integrate(r*S.exp(-r),(r,0,S.oo))-1)
t=S.symbols('t', positive=True)
gB=[1,1/t,3/t-1]
QB=sum(S.integrate(t*S.exp(-a*t)*g,(t,l,h)) for g,l,h in zip(gB,[0,1,2],[1,2,3]))
zero('block_shell_matches_exact_probability',a*a*QB-(1-S.exp(-a))*(1-S.exp(-2*a)))
zero('middle_shell_difference',t*((S.Rational(9,2)/t-2)-1/t)-(S.Rational(7,2)-2*t))
zero('one_shell_crossing',S.Rational(7,2)-2*S.Rational(7,4))
zero('block_zero_radius_volume',sum(S.integrate(t*g,(t,l,h)) for g,l,h in zip(gB,[0,1,2],[1,2,3]))-2)
disk_overlap=2*S.acos(r/2)-r*S.sqrt(4-r*r)/2
sym_volume=3/S.pi**2*S.integrate(2*S.pi*r*disk_overlap,(r,0,1))
zero('symmetric_volume_direct_disk_overlap',sym_volume-(3-9*S.sqrt(3)/(4*S.pi)))
I=S.integrate(S.exp(-a*t)*(t-1),(t,1,S.Rational(3,2)))+S.integrate(S.exp(-a*t)*(S.Rational(7,2)-2*t),(t,S.Rational(3,2),2))
J=S.integrate(S.exp(-a*t)*(3-t),(t,2,3))
x=S.symbols('x')
zero('half_bracket_integral_identity',S.expand(S.exp(S.Rational(3,2))*(I-J/2).subs(a,S.Rational(1,2)))-(4*S.exp(1)-12*S.exp(S.Rational(3,4))+10*S.exp(S.Rational(1,2))-2))
zero('half_bracket_factorization',4*x**4-12*x**3+10*x*x-2-2*(x-1)**2*(2*x*x-2*x-1))
zero('half_bracket_rational_bound',(2*x*x-2*x-1).subs(x,S.Rational(4,3))+S.Rational(1,9))
zero('two_bracket_integral_identity',4*S.exp(6)*(I-J).subs(a,2)-(S.exp(4)-3*S.exp(3)+2*S.exp(2)-1))
zero('two_bracket_factorization',x**4-3*x**3+2*x*x-1-(x*x*(x-1)*(x-2)-1))
zero('negative_mass_bound',S.integrate(t,(t,S.Rational(7,4),3))-S.Rational(95,32))
zero('positive_mass_bound',S.Rational(1,4)*(S.Rational(3,2)-S.Rational(5,4))-S.Rational(1,16))
zero('hessian_patch_maximum',(a+(S.sqrt(a)/3)**2)/2-S.Rational(3,4)*S.sqrt(a)*(S.sqrt(a)/3)-S.Rational(11,36)*a)
zero('hessian_patch_margin',a/2-S.Rational(11,36)*a-S.Rational(7,36)*a)
zero('tangent_hessian_dot',S.Matrix([-1,-1,2]).dot(S.Matrix([0,1,-1]))+3)
e=S.symbols('e',real=True)
cc=S.Rational(1,3)-e; ss=1-cc
zero('pair_gap_scale',(S.Rational(1,3)+2*e)/ss-cc/ss-3*e/ss)
# A separately derived shell counterexample, independent of whichever one the author freezes.
# For T<2, two exceedances cannot co-occur since their sum exceeds 1.
T=S.Rational(7,4); c0=S.Rational(1,7)
g0=1-(1-1/(T*(1-c0))) # Other two cap probabilities vanish exactly.
zero('independent_shell_fraction',g0-S.Rational(2,3))
zero('independent_shell_block',1/T-S.Rational(4,7))
zero('independent_shell_symmetric',S.Rational(9,2)/T-2-S.Rational(4,7))
zero('independent_shell_strict_gap',g0-S.Rational(4,7)-S.Rational(2,21))
zero('independent_shell_inactive_cap_threshold',T*(1+c0)/2-1)
# Original endpoint/source byte checks are historical, not mathematical controls.
# Independent derivative and holomorphic-bound arithmetic.
z,vv=S.symbols('z vv',real=True)
EE=S.Function('E')
expf=S.exp(-a*(1+z*z)*vv*vv)
base=2*a*(1+z*z)*vv*expf*EE(z*vv)
# Integration by parts transforms differentiated fixed-domain formula to (3.2).
raw=S.diff(base,z)
remaining=2*a*vv*vv*expf*S.diff(EE(z*vv),z)/vv
flux=2*a*z*S.diff(vv*vv*expf*EE(z*vv),vv)
zero('regular_derivative_integration_by_parts',raw-remaining-flux)
zero('rational_c_derivative',S.diff(z*z/(1+z*z),z)-2*z/(1+z*z)**2)
zero('parameter_exponent_cancellation',(1+z*z)*(z*vv)**2/z**2-(1+z*z)*vv**2)
zero('apparent_t_pole_cancels',2*(z*vv)**2*z/z**3-2*vv**2)
zero('analytic_phi_pole_factor_at_i',(1+z*z).subs(z,S.I))
for name,expr in [
 ('five_fourths_inside_domain',2-S.Rational(25,16)),
 ('sqrt2_below_three_halves',S.Rational(9,4)-2),
 ('sqrt57_below_eight',64-57),
 ('lens_exponent_dominance',S.Rational(121,16)-S.Rational(82,16)),
 ('phi_prefactor_below16',16-S.Rational(123,8)),
 ('phi_exponent_below11',11-S.Rational(81,8)),
 ('D0_coefficient_lower_than_actual',S.Rational(8)*S.Rational(7,5)/(3*S.Rational(22,7))-1),
 ('physical_interval_inside_jensen_inner',S.Rational(9,16)-S.Rational(1,2)),
 ('exp_three_quarters_truncation_above_two',1+S.Rational(3,4)+S.Rational(9,32)-2)]:
 test(name,expr>0,str(expr))
zero('lens_bound_constant',S.Rational(4,3)*(2+S.Rational(5,2))-6)
zero('phi_bound_prefactor',2*S.Rational(41,16)*S.Rational(1,2)*6-S.Rational(123,8))
zero('phi_bound_exponent',S.Rational(121,16)+S.Rational(41,16)-S.Rational(81,8))
zero('cauchy_bound',16/S.Rational(1,4)-64)
zero('jensen_slope',4*(11+3)-56)
zero('symmetric_scalar_hessian_metric',(4*S.sqrt(2)/9)**2*S.Rational(3,2)-S.Rational(16,27))
# Optional symmetric shell antiderivative, proved in its integration variable.
k,u0=S.symbols('k u0',positive=True)
rr=S.sqrt(1-k*k-k*k*u0*u0)
anti=S.atan(u0/rr)-k*S.atan(k*u0/rr)
zero('optional_shell_antiderivative',S.diff(anti,u0)-rr/(1+u0*u0))
zero('optional_shell_lower_endpoint',anti.subs(u0,0))
# Historical private-source checks are preserved in HISTORICAL_CONTROLS.json.
# Public source bindings and complete dependency integrity are checked by verify_package.py.
record={'status':'PASS','scope':'57 unchanged exact mathematical checks; historical byte checks are separate','count':len(rows),'checks':rows,'sympy_version':S.__version__}
(OUT/'INDEPENDENT_CONTROLS.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'PASS','count':len(rows)}))
