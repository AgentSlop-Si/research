# Historical versus portable controls

The original fresh audit accepted the frozen sources and recorded 101 passing checks. HISTORICAL_CONTROLS.json is an exact byte copy of that record. Of these checks, 57 are exact mathematical checks and 44 verify historical source bytes:

- 8 endpoint manifest-member size/hash checks.
- 4 endpoint dependency source checks.
- 24 combined scalar manifest-member size/hash checks.
- 7 combined scalar dependency source checks.
- 1 equality check of the duplicated endpoint proof.

The portable independent_controls.py retains every mathematical line from the original, deleting only original-source filesystem checks and changing output provenance fields. INDEPENDENT_CONTROLS.json records the resulting 57 checks, and the root verifier requires those check rows to match the mathematical subset of the historical record exactly. The 49 scalar-author checks and 47 endpoint-author checks are likewise unchanged. The endpoint portable output omits original path hashing; its historical source labels/hashes and mathematical rows are retained separately.

Current public integrity, source binding, scope, acceptance and analytic-core checks are performed by verify_package.py. They are not added to the mathematical check count. The structural dependency separately documents its own historical-versus-portable split.
