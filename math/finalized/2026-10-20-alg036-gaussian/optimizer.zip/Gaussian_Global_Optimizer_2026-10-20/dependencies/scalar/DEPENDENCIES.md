# Dependencies and preserved background

The complete accepted strict-largest-pair smoothing packet is included under dependencies/structural, byte for byte with manifest SHA-256 85008206156b6eed3c0585900efa450793617987b1e157da7ab4dc4694e2c839. It contains the structural proof, collaborative review, separate fresh acceptance, exact controls, and the earlier stationary report with its review and controls.

The scalar proof's lens, continuation, Jensen bound and shell obstruction are directly derived for the centered proper-complex model. The structural proof is needed to interpret the scalar interval as containing all global maximizers. The endpoint Hessian proof specifically uses the rotation-boundary identity in dependencies/structural/candidate/PROOF.md and the C² regularity in dependencies/structural/dependencies/stationary/REPORT.md. Their accepted reviews are included. The earlier exact conditional-lens counterexample is also retained to distinguish a false pointwise shortcut from true integrated smoothing.

Earlier small-radius optimality, effective gaps, centering of the larger problem, and large-radius localization are preserved background, not steps needed to prove these centered scalar statements. Their earlier effective report is identity-only in provenance/SOURCE_BINDINGS.json; no new certification or extension of those claims is asserted.

The stationary dependency includes references to NIST DLMF for Bessel differentiation/asymptotics, Prékopa for a separate log-concavity consequence, and Glover–Tkocz–Wyczesany for an unweighted comparison formula. Exact roles and public links are retained in the dependency. These citations are not used as an external optimizer theorem. The new finite lens/endpoint arguments use elementary integrations and standard analytic tools with their necessary hypotheses provided.

Historical statements in the stationary/structural documents that the scalar analysis or two-equal reduction was open are historical. The current scoped acceptance supersedes only the claims explicitly listed in RELEASE.json. The full optimizer remains unresolved.
