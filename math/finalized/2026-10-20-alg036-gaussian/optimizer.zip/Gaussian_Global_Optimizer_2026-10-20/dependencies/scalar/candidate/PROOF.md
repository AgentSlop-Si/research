# ALG-036: finite analytic scalar gate and exact remaining obstruction

Date: 20 October 2026 UTC. Historical source status: new scoped candidate, awaiting fresh adversarial review. Current accepted scope is recorded in RELEASE.json. This is not a complete all-radius optimizer theorem.

## 1. Contract, dependency and disposition

For the accepted proper-complex Gaussian model, write

    F_a(q)=Pr(max_j |Z_j| <= sqrt(a)),
    Z ~ CN(0,I-uu*), u_j=sqrt(q_j), sum_j q_j=1, a>0.

The accepted all-radius strict-largest-pair smoothing theorem reduces its global maximum exactly, modulo permutations and coordinate phases, to

    f_a(c)=F_a(c,(1-c)/2,(1-c)/2), 0<=c<=1/3.

The density on the complex two-plane remains pi^(-2)exp(-||z||^2); no real-Gaussian substitute is used. Centering, the exact boundary formula, the small-radius theorem, the leverage/gap bounds, and large-radius localization are unchanged.

**What is proved here.** We give a finite, nonoscillatory scalar integral and derivative. In the regular coordinate t=sqrt(c/(1-c)), its continuation is holomorphic on |t|<sqrt(2). For every a>0 its derivative has fewer than 20+56a complex zeros, counted with multiplicity, in |t|<=3/4, hence finitely many stationary points on the whole physical interval. The block endpoint has an explicit strictly negative cusp. Together with the separately contributed strict symmetric local-maximum theorem, this forces at least one strict interior minimum for every finite radius. We also give an exact counterexample to shell-wise endpoint domination.

**What is not proved.** No argument here excludes additional interior local maxima or proves that all intermediate c lie below the better endpoint. The full all-radius scalar optimizer and the original all-radius optimization therefore remain unresolved. A finite list of stationary candidates does not itself settle their signs or values. In particular, the separately proved unique crossing of the two endpoint values is not asserted to be the global phase transition.

## 2. Exact lens integral

Let X,Y be independent standard proper-complex Gaussians. A real isometric frame gives

    Z_1=sqrt(1-c)X,
    Z_2=(-sqrt(c)X+Y)/sqrt(2),
    Z_3=(-sqrt(c)X-Y)/sqrt(2).

Its Gram matrix is the identity and its normal is (sqrt(c),sqrt((1-c)/2),sqrt((1-c)/2)). Put R=sqrt(2a) and define, for 0<=d<R,

    ell_a(d)=(1/pi) integral_{|y+d|<=R, |y-d|<=R} exp(-|y|^2)dy.

Here d is real and nonnegative; dy is planar Lebesgue measure. Rotation invariance and |X|^2~Exp(1) give exactly

    f_a(c)=integral_0^{a/(1-c)} exp(-x) ell_a(sqrt(cx)) dx.             (2.1)

A finite Cartesian formula is

    ell_a(d)=(4/pi) integral_0^{sqrt(R^2-d^2)} exp(-y^2)
                    integral_0^{sqrt(R^2-y^2)-d} exp(-z^2) dz dy.     (2.2)

The inner integral vanishes at the moving outer endpoint. Differentiating in d therefore yields

    h_a(d):=-ell_a'(d)
      =(4/pi) exp(-2a-d^2)
         integral_0^{sqrt(2a-d^2)} exp(2d sqrt(2a-y^2))dy >0.          (2.3)

All formulas use actual bounded integrals. On the physical branch d<=sqrt(a/2)=R/2; in particular no lens-collapse singularity is encountered.

## 3. A regular exact derivative on the complete scalar interval

Set

    t=sqrt(c/(1-c)), 0<=t<=t_0=1/sqrt(2),
    c=t^2/(1+t^2), A=a(1+t^2), d=sqrt(a)t,
    Phi_a(t)=f_a(t^2/(1+t^2)).

Equation (2.1), first with x=A v^2, gives

    Phi_a(t)=2a(1+t^2) integral_0^1 v exp(-a(1+t^2)v^2)
                                    ell_a(sqrt(a)t v)dv.            (3.1)

For t>0 direct Leibniz differentiation of (2.1), followed by u=t sqrt(x/(1+t^2)), gives

    Phi_a'(t)=2at exp(-A)ell_a(d)
       -(2/t^3) integral_0^d u^2 exp(-(1+t^(-2))u^2)h_a(u)du.

The substitution u=t v removes the apparent singularity entirely:

    D_a(t):=Phi_a'(t)
      =2at exp(-a(1+t^2))ell_a(sqrt(a)t)
        -2 integral_0^{sqrt(a)} v^2 exp(-(1+t^2)v^2)h_a(tv)dv.        (3.2)

The right side extends continuously and analytically to t=0. It is also a genuine finite-integral root equation: all interior stationary points satisfy D_a(t)=0. No indicator derivative, numerical quadrature, or maximization oracle appears in (3.2).

## 4. Exact block cusp and its all-radius consequence

At d=0,

    ell_a(0)=1-exp(-2a),
    h_a(0)=4sqrt(2a)exp(-2a)/pi.

Using (3.2),

    D_a(0)=-K(a),
    K(a)=(4sqrt(2a)/pi)exp(-2a) integral_0^a sqrt(x)exp(-x)dx >0.     (4.1)

The analyticity proved below supplies the locally uniform expansion

    Phi_a(t)=B(a)-K(a)t+O_a(t^2),
    B(a)=(1-exp(-a))(1-exp(-2a)).

Since t=sqrt(c)+O(c^(3/2)),

    f_a(c)=B(a)-K(a)sqrt(c)+O_a(c),
    f_a'(c)=-K(a)/(2sqrt(c))+O_a(1).                                 (4.2)

Thus c=0 is a strict one-sided local maximum at every fixed finite a>0. No claim of uniformity in a is made. The cusp coefficient can become extremely small at large a, which explains why a coarse floating c mesh can falsely appear to show monotonicity away from zero.

## 5. Holomorphic continuation without a moving nonsmooth boundary

We prove more than real analyticity, both to justify endpoint expansions and to give a quantitative finite-root bound. Fix a>0. For complex z with |z|<sqrt(2), choose the holomorphic square-root branch w(z)=sqrt(2-z^2) with w(0)=sqrt(2), and put

    J_a(z)=w(z) integral_0^1 exp(-a w(z)^2 s^2)ds.

This is holomorphic in that disk. For real 0<=z<=sqrt(2), it equals integral_0^{sqrt(2-z^2)}exp(-a y^2)dy, with its continuous endpoint value.

A second Cartesian description of the lens, obtained by integrating its horizontal coordinate first, is

    E_a(d):=ell_a(sqrt(a)d)
      =(4a/pi) integral_d^{sqrt(2)} exp(-a(x-d)^2)J_a(x)dx,
                                                    0<=d<sqrt(2).  (5.1)

Indeed the lens may be described by 0<=z<=R-d and 0<=y<=sqrt(R^2-(z+d)^2) in its first quadrant. Rescaling by sqrt(a) gives (5.1).

To continue it analytically, split the right side into the fixed real integral and an analytic primitive:

    E_a(d)=(4a/pi)[
        integral_0^{sqrt(2)} exp(-a(x-d)^2)J_a(x)dx
        -d integral_0^1 exp(-a d^2(s-1)^2)J_a(ds)ds].                (5.2)

The first term is entire in d: its fixed real x interval is bounded and J_a(x) is bounded. The second term is holomorphic for |d|<sqrt(2), by uniform domination on compact subsets. Thus (5.2) is a holomorphic extension of the actual lens for nonnegative d. It is not claimed that its negative-real values equal the lens with absolute shift |d|; that would incorrectly remove the cusp.

Substituting (5.2) into (3.1) gives

    Phi_a(t)=2a(1+t^2) integral_0^1 v exp(-a(1+t^2)v^2)E_a(tv)dv,    (5.3)

holomorphic for |t|<sqrt(2). The continuation includes t=0 and t=t_0 in an open neighborhood. Its derivative D_a is holomorphic on the same disk.

## 6. An explicit all-radius finite stationary-root bound

This section gives a very coarse but rigorous bound, not a floating optimizer census.

For |d|<=5/4, the fixed real integral in (5.2) obeys

    |integral_0^{sqrt(2)} exp(-a(x-d)^2)J_a(x)dx|
      <=2 exp(121a/16).

Here J_a(x)<=sqrt(2), and |x-d|<=sqrt(2)+5/4<11/4. For the second term, |J_a(ds)| is bounded by

    sqrt(2+|d|^2) exp(a(2+|d|^2))
      <=(sqrt(57)/4)exp(57a/16).

Also |exp(-a d^2(s-1)^2)|<=exp(25a/16). Hence its whole absolute value is at most

    (5sqrt(57)/16)exp(82a/16)<(5/2)exp(121a/16).

Using pi>3, we conclude

    |E_a(d)|<6a exp(121a/16), |d|<=5/4.                            (6.1)

For |t|<=5/4, |1+t^2|<=41/16. Formula (5.3) therefore gives

    |Phi_a(t)|<(123/8)a^2 exp(81a/8)<16a^2 exp(11a).                (6.2)

At each point |t|<=1, apply Cauchy's derivative estimate on the circle of radius 1/4 centered at that point. It lies in |t|<=5/4, so

    |D_a(t)|<=64a^2 exp(11a), |t|<=1.                              (6.3)

On the other hand, (4.1) and exp(-x)>=exp(-a) for 0<=x<=a give

    |D_a(0)| >= (8sqrt(2)/(3pi))a^2 exp(-3a)>a^2 exp(-3a).         (6.4)

The strict last inequality follows, for example, from sqrt(2)>7/5 and pi<22/7.

Let N(a) be the number of complex zeros of D_a, with multiplicity, in |t|<=3/4. Jensen's formula applied at radius 1, with D_a(0) nonzero, implies

    N(a)log(4/3) <= log(64)+14a.

The inequality remains valid if zeros occur on one of the circles, by taking nearby radii or the usual limiting form of Jensen's formula. Since log(4/3)>1/4 and log(64)<5,

    N(a)<20+56a.                                                   (6.5)

For the latter elementary bound, exp(3/4)>1+3/4+(3/4)^2/2>2, so log(64)=6log(2)<9/2<5. The logarithmic lower bound follows by integrating 1/x>3/4 on 1<x<4/3.

The entire physical interval [0,1/sqrt(2)] lies in |t|<3/4. Therefore (6.5) bounds all its stationary points, counting their multiplicities. This is uniform for every a>0 and does not rely on searching a radius ladder. It does not show those roots are simple, ordered in a, or all minima; none of those conclusions follows from Jensen's formula.

## 7. Endpoint comparison and local stability: separately contributed results

The source-bound collaborative packet `endpoint_contribution/PROOF.md` proves:

1. Both c=0 and c=1/3 are strict local maxima for every finite a>0. The symmetric result is stronger: the tangent Hessian on the full simplex is negative definite. It follows quantitatively from the accepted rotation-boundary identity and C² regularity, not from an unjustified passage from strict monotonicity to strict curvature.
2. There is exactly one a_*>0 where S(a)=B(a), S(a)=f_a(1/3). It has a finite-integral definition, the certified bracket 1/2<a_*<2, and strict comparisons on both sides; the crossing is transverse. The proof uses a single sign change in the difference of the two endpoint radial-shell fractions. It does not compare intervening c.

Combining the local stability statement with Sections 3–6 gives a useful exact scalar shape consequence. D_a(t)<0 for t sufficiently near zero, whereas D_a(t)>0 for t just below t_0, because D_a(t_0)=0 and Phi_a''(t_0)<0. Since its zeros are finite, at least one interior zero changes sign from negative to positive. Such a zero is a strict local minimum, even if its multiplicity exceeds one. There is at least one interior minimum for every finite a. The endpoint derivative zero at t_0 is simple.

These facts are consistent with the conjecture that there is exactly one interior minimum and no other stationary point, but they do not prove it.

## 8. Exact diagnostic: shell-wise endpoint domination is false

This is a counterexample to a possible proof shortcut, not to the Gaussian endpoint-optimizer conjecture.

For a fixed squared norm s in a unit-polydisc section, write g_q(s) for the accepted directional shell fraction. Choose

    s=7/4,
    q=(1/7,3/7,3/7),
    p_j=1-q_j=(6/7,4/7,4/7).

For a uniform direction in C², the squared magnitude of a coordinate functional with squared norm p is uniform on [0,p]. At this shell the two latter constraints are automatic because s p_2=s p_3=1. Only the first constraint cuts a cap. Its retained fraction is

    g_q(7/4)=1/(s p_1)=2/3.

For the block endpoint the shell fraction is 1/s=4/7; for the symmetric endpoint it is 9/(2s)-2=4/7. Consequently

    g_q(7/4)-max(g_block(7/4),g_symmetric(7/4))=2/21>0.              (8.1)

The actual Gaussian probabilities integrate these shell fractions with the positive radial weight a² s exp(-a s). Inequality (8.1) neither proves an interior Gaussian winner nor invalidates the endpoint crossing theorem. It shows why shell-wise endpoint dominance cannot establish the missing integrated inequality.

## 9. Exact remaining gate

A sufficient stronger completion is the following genuine sign theorem for (3.2):

    for each a>0 there is exactly one t_m(a) in (0,1/sqrt(2))
    with D_a(t_m)=0, D_a(t)<0 for 0<t<t_m,
    and D_a(t)>0 for t_m<t<1/sqrt(2).

That would prove all interior stationary points are strict minima and complete the endpoint-only global classification using the unique a_* from the companion proof. A weaker sufficient completion is to show that any additional interior local maximum has value strictly below max(B(a),S(a)), with ties handled explicitly. Neither completion is supplied here.

The finite analytic root bound reduces each fixed-radius optimization to a finite candidate set, but this packet does not disguise that standard final comparison as an already-solved all-radius optimizer. The unfinished operation is an analytic sign/value comparison on the explicit finite integrals, not an access denial or a computational environment failure. No externally consequential action was attempted.

## 10. Controls and provenance

The exact controls check the isometric frame, parameter conversions, derivative substitutions and endpoint constants; they also check every rational/algebraic inequality used in the holomorphic bound and the exact shell counterexample. These are symbolic consistency controls, not a substitute for the analytic arguments.

The endpoint sign-change proof and strict symmetric Hessian proof were contributed by the endpoint author before the combined proof was frozen. They are credited in `COLLABORATION.md`. The scalar lens derivation and cusp were independently reconstructed by both authors. The explicit holomorphic continuation, Jensen zero bound, and shell-wise counterexample are contributions of the scalar author. A separate fresh review subsequently accepted these scoped results; see reviews/fresh/REVIEW.md and RELEASE.json. No historical-priority claim is made.

Exploratory floating computations are omitted from this public packet and are not used as proof of a root count, value comparison, or transition. The original model and accepted prior bounds remain unchanged.
