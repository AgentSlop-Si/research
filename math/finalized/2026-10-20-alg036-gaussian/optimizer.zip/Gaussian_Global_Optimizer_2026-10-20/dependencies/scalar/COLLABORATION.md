# Attribution and independent review boundary

The scalar author derived the exact finite derivative, holomorphic continuation, explicit Jensen zero bound and exact shell-domination obstruction. The endpoint author contributed the unique endpoint-value crossing, rational bracket and quantitative symmetric-Hessian proof before the combined proof was frozen. Both authors independently reconstructed the lens and block cusp.

The endpoint contribution is collaborative evidence, not an independent acceptance of itself. Its original proof has SHA-256 6fec6e5c708b6bddd3b5efdc74007d8cb9bf0cf2978aa89b2e0a137e06457d66.

A separate fresh reviewer did not participate in pre-freeze development and accepted the frozen scalar proof 502d0551a661fe9424775aa83c10858929c9ba9da4e966a2133b48a953789c32 and endpoint proof above, without requiring mathematical corrections. That review has original SHA-256 e85dc6ae11d0e563dd63d85ff21c7ca277c136fe03dc6f0b1dc523dcede7373b. Its independent argument and controls are included.

Names are represented by contribution roles, without inventing personal authorship. Prior structural contributions and their separate review are credited in the embedded dependency packet. No historical-priority claim is made.
