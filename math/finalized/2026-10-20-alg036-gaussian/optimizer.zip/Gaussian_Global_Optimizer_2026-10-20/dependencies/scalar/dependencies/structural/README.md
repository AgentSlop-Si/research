# Gaussian strict largest-pair smoothing

A portable research packet for the proper-complex rank-two Gaussian in C³, valid for every finite a>0.

## Exact theorem

Let q_j≥0, ∑q_j=1, u_j=√q_j, Z∼CN(0,I−uu*), and F_a(q)=Pr(max_j |Z_j|≤√a). The intrinsic plane density is π⁻²exp(−‖z‖²). If 0<q₁≤q₂<q₃, fixing q₁ and equalizing q₂,q₃ strictly increases F_a, with strictly positive derivative before equality. Every interior local or global maximum has its two largest weights equal, and no all-distinct interior stationary point exists.

Together with the separately proved boundary formula,

    max_{q∈Δ₂} F_a(q) = max_{0≤c≤1/3} F_a(c,(1−c)/2,(1−c)/2).

Every global maximizer is a permutation of a maximizing member of that family. This is the global two-equal structural reduction, not a classification of the maximizing c(a), transitions, or complete all-radius optimizer. a=0 and a=∞ are excluded from strictness.

## Read in this order

1. RELEASE.json for current scoped disposition and exact source identities. A pending fresh review is not an accepted release.
2. candidate/PROOF.md for the full analytic proof.
3. reviews/collaborative/REVIEW.md and COLLABORATION.md for technical contributions and their disclosed non-blind provenance.
4. reviews/fresh/REVIEW.md, when present, for the separate fresh adversarial audit. Only a fresh PASS on the exact source proof permits accepted release status.
5. DEPENDENCIES.md and dependencies/stationary/ for the normalization, finite face-minus-edge equations, boundary proof, earlier review, and rejected pointwise-lens shortcut.
6. PROVENANCE.md and provenance/ for original versus public byte identities, nonmathematical projections, and source preservation.

Historical status statements in the older stationary dependency are retained as historical text. The current theorem supersedes its former open two-equal gate; it does not claim to settle its separate off-shell root-count question or the full optimizer.

## Cold replay

Requirements: Python 3.12 and SymPy 1.14.0 were used for the recorded replay. Python's standard library alone checks integrity, scoped status, and tamper rejection. Exact symbolic controls require SymPy. No network, private source directory, or numerical optimizer is used.

After copying or extracting this directory anywhere, run:

    python verify_package.py --replay --negative-controls --require-accepted

To pin the packet to a digest obtained separately from the release source, also pass:

    --expected-manifest-sha256 THE_TRUSTED_MANIFEST_HASH

The verifier reads only packaged inputs, copies each source control into a temporary directory, and compares its generated JSON byte for byte with the sealed output. It does not overwrite this packet. It runs the 13 author controls, 8 collaborative checks, the stationary-dependency exact controls, and any separately listed fresh-review controls.

Negative controls reject a modified proof, missing proof, unlisted extra file, resealed optimizer overclaim, resealed wrong source identity, untrusted manifest digest, resealed projection mismatch, and missing or incorrectly bound fresh acceptance. These test the verifier's defenses, not mathematical truth. A determined party can replace an entire unsigned packet and its verifier; independently pinning the manifest digest is therefore necessary for authenticity.

## Evidence limits

The analytic proof establishes strictness and the universal radius range. Finite symbolic checks supplement it and are not exhaustive optimizer searches. Hashes establish byte integrity, not correctness. Exploratory floating-point work is intentionally excluded. The original source proof and public projection have different hashes because nonmathematical historical-status and provenance wording was projected; the analytic core in Sections 2–6 is byte-identical. All formulas, domains, and conclusions are unchanged.
