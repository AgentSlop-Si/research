# ALG-036: finite-radius stationary equations and a strict-triangle exclusion

Date: 2026-10-20. Historical source status: candidate for independent verification. The later structural theorem in this packet supersedes only the stated open structural gate; all mathematical content below is preserved.

## 1. Exact disposition and frozen contract

For every finite a=r²>0, set

    F_a(q) = Pr(max_j |Z_j| <= sqrt(a)),
    Z ~ CN(0, I-uu*), u_j=sqrt(q_j),
    q_j>=0, q_1+q_2+q_3=1.

The Gaussian is proper complex, with density pi^(-2)exp(-||z||²) on the complex plane u-perp. Coordinate phases and permutations have already been removed. The accepted centering theorem permits this centered problem. The accepted small-radius exact optimizer, explicit gap, effective computability theorem, and large-radius localization are preserved without alteration.

The requested all-radius assertion that every interior maximizer has two equal normal magnitudes is **not proved or disproved here**. No certified scalene counterexample has been found. The exact one-parameter reduction and full all-radius optimizer remain open.

This packet proves the following narrower, radius-uniform structural statements:

1. F has an exact homogeneous extension that is C² throughout the positive orthant. Absolutely convergent Fourier formulas give its gradient and Hessian, including at the normal-triangle tangency locus.
2. Interior stationarity has an equivalent formulation using positive finite-domain integrals: three explicitly defined face-minus-edge quantities must agree.
3. Every interior local maximizer satisfies

       q_1 q_2 + q_2 q_3 + q_3 q_1 > 1/4.

   Equivalently, sqrt(q_1), sqrt(q_2), sqrt(q_3) are the sides of a strict triangle. In particular every q_i<2/3. The equality locus is excluded, not silently omitted as nonsmooth.
4. On the simplex boundary, the unique maximizer modulo permutations is (1/2,1/2,0), with value (1-exp(-a))(1-exp(-2a)).

The remaining all-distinct strict-triangle gate is identified precisely in Sections 6–7. Numerical sampling, finite censuses, and arbitrary radius expansions are not used.

## 2. Homogeneous extension, exact Fourier formula, and regularity

Write S=q_1+q_2+q_3 and define, for q_i>0,

    H_a(q)=S^(-1) F_a(q/S).

Let f_a(z)=pi^(-1)exp(-|z|²)1_{|z|<=sqrt(a)} on C, regarded as an unnormalized density. Its radial characteristic function after scaling by sqrt(q) is

    phi_a(q,t)=integral_0^a exp(-s) J_0(t sqrt(qs)) ds.

The pushforward of the product density f_a(z_1)f_a(z_2)f_a(z_3) by z -> sum sqrt(q_i)z_i has value H_a(q)/pi at zero. Indeed the real two-dimensional coarea Jacobian of this linear map is S, and the Gaussian density on the kernel has normalization pi^(-2). Fourier inversion therefore gives

    H_a(q)= (1/2) integral_0^infinity
              t phi_a(q_1,t)phi_a(q_2,t)phi_a(q_3,t) dt.       (2.1)

This also fixes every normalization constant. The unweighted polydisc analogue is Glover–Tkocz–Wyczesany, Section 3.2, equation (7); (2.1) is derived here for the truncated Gaussian, not imported as a Gaussian optimizer theorem.

### 2.1 Absolute convergence through two q derivatives

For m=0,1,2, the Bessel derivative identity gives, with r=sqrt(a), k=t sqrt(q),

    partial_q^m phi_a(q,t)
      =2(-1)^m(t/2)^m q^(-m/2)
        integral_0^r rho^(m+1)exp(-rho²)J_m(k rho) d rho.       (2.2)

Using d/drho[rho^(m+1)J_(m+1)(k rho)]
=k rho^(m+1)J_m(k rho), integrate once by parts:

    integral_0^r rho^(m+1)exp(-rho²)J_m(k rho)d rho
      =r^(m+1)exp(-r²)J_(m+1)(kr)/k
       +(2/k)integral_0^r rho^(m+2)exp(-rho²)J_(m+1)(k rho)d rho.

The fixed-order estimate |J_n(x)|<=C_n x^(-1/2), x>0, follows from the standard large-positive-argument asymptotic and boundedness near zero. Thus, on every compact interval of positive q,

    partial_q^m phi_a(q,t)=O(t^(m-3/2)),  t>=1.             (2.3)

All derivatives are bounded on compact t intervals by the defining integral or power series. A product derivative of total order m<=2 in the integrand of (2.1) is O(t^(m-7/2)). Even the worst case m=2 has integrable decay t^(-3/2). Dominated differentiation proves H_a is C² on the entire positive orthant. No exceptional triangle or tangent locus is removed.

The Bessel identities and estimates used here are NIST DLMF 10.6.6 and 10.17.3; they are technical special-function inputs, not optimization results.

### 2.2 Exact first and second variations

Abbreviate phi_i=phi_a(q_i,t), phi_i'=partial_q phi_a(q_i,t), and phi_i''=partial_q² phi_a(q_i,t). Then

    H_i=(1/2)integral_0^infinity t phi_i' phi_j phi_k dt,
    H_ii=(1/2)integral_0^infinity t phi_i'' phi_j phi_k dt,
    H_ij=(1/2)integral_0^infinity t phi_i' phi_j' phi_k dt (i!=j).  (2.4)

These are ordinary absolutely convergent integrals, not merely formal differentiated oscillatory expressions. For a tangent vector v with sum v_i=0, the first and second constrained variations are sum v_i H_i and v^T(H_ij)v.

Since H_a(cq)=c^(-1)H_a(q), Euler's identity is

    sum_i q_i H_i=-H_a.

At an interior stationary point on S=1 the Lagrange multiplier is therefore fixed, not unknown:

    H_1=H_2=H_3=-F_a(q).                                (2.5)

At a local maximum, additionally

    v^T(H_ij)v<=0 whenever sum_i v_i=0.                  (2.6)

As a normalization control, at a=infinity phi(q,t)=exp(-qt²/4), so H=1/S, H_i=-1/S², H_ij=2/S³ and every tangent variation vanishes, as it must. This limiting control is not an optimizer argument at finite radius.

## 3. Finite positive-integral stationary equations

The Fourier representation is analytically rigorous but oscillatory. The following equivalent equations avoid improper integrals.

For x_i>=0 define

    Delta_q(x)=2 sum_(i<j) q_i q_j x_i x_j - sum_i q_i² x_i²,
    rho_2(q,x)=exp(-sum_i x_i) sqrt(max(Delta_q(x),0))
                  /(2 pi q_1 q_2 q_3).                 (3.1)

Here rho_2 is the density of the coordinatewise sum of squared magnitudes from two independent copies of CN(0,I-uu*) when sum q_i=1. Define

    K_q(b)=integral_[0,b_1]x[0,b_2]x[0,b_3] rho_2(q,x) dx.

At b=(a,a,a), put

    A_i=partial_(b_i) K_q(b),
    B_i=partial_(b_j) partial_(b_k) K_q(b), {i,j,k}={1,2,3}. (3.2)

Thus A_i is the integral of rho_2 over the two-dimensional face x_i=a, and B_i is its one-dimensional integral along the opposite edge x_j=x_k=a. Both are nonnegative and have finite integration ranges. Precisely,

    (partial_(q_i)-partial_(q_j)) H_a(q)
         =(A_i-B_i)-(A_j-B_j), sum q_i=1.                (3.3)

Consequently interior stationarity is equivalent to

    A_1-B_1=A_2-B_2=A_3-B_3.                           (3.4)

Nonnegativity of the individual A_i,B_i does not supply a sign for their differences.

### 3.1 Elementary derivation of rho_2

Choose a real 3-by-2 isometric frame V spanning u-perp. With p=q_2+q_3, one such frame has rows

    (sqrt(p),0),
    (-sqrt(q_1 q_2/p), sqrt(q_3/p)),
    (-sqrt(q_1 q_3/p),-sqrt(q_2/p)).

Let G be a 2-by-2 matrix of independent standard proper complex Gaussians and W=GG*. Write W=[[A,C+iD],[C-iD,B]]. Its density with respect to dA dB dC dD is

    pi^(-1)exp(-(A+B)) 1_{A>0,B>0,AB>C²+D²}.

For completeness, A has density A exp(-A). Conditional on the first Gaussian row, its inner product with the second row is CN(0,A), while the remaining orthogonal squared component is an independent unit exponential. Multiplying those three densities cancels the factor A and gives the displayed formula.

Let x_i=(VWV*)_ii. Then sum x_i=A+B and the real linear map (A,B,C)->(x_1,x_2,x_3) has absolute determinant 2 sqrt(q_1 q_2 q_3). Direct substitution gives

    Delta_q(x)=4q_1q_2q_3(AB-C²).

Integrating D over [-sqrt(AB-C²),sqrt(AB-C²)] gives exactly (3.1). This derivation does not assume independence of the three coordinate squared magnitudes.

### 3.2 Derivation of the tangent derivative identity

Let C_q(b) denote the one-copy CDF at unequal nonnegative thresholds b_i, extended by S^(-1) normalization as in Section 2 off the simplex. For s_i>0, its three-variable Laplace transform is

    L_b C_q(s)=1/(s_1 s_2 s_3 D_q(s)),
    D_q(s)=sum_i q_i (1+s_j)(1+s_k).                    (3.5)

This follows either by Gaussian integration on the plane or from det(I+P diag(s)); on S=1 the determinant is 1+sum_i(1-q_i)s_i+sum_i q_i s_j s_k. The homogeneous extension makes the denominator D_q valid also off S=1.

Convolution of two independent squared-magnitude vectors gives

    L_b K_q(s)=1/(s_1 s_2 s_3 D_q(s)²).

Since

    (partial_(q_i)-partial_(q_j))D_q
       =-(s_i-s_j)(1+s_k),

differentiating (3.5) yields the transform of

    (partial_(b_i)-partial_(b_j))(1+partial_(b_k))K_q(b).

There are no boundary terms: K_q vanishes when any b coordinate is zero, and the relevant tangential face derivatives do also. Equality of transforms gives the identity first distributionally; both sides have continuous representatives at positive equal thresholds. For the left side this follows from Section 2 (with the same argument for unequal fixed positive truncation radii); for the right side it follows from the continuous density (3.1) and bounded face/edge integrals. Evaluating at b=(a,a,a) proves (3.3).

An explicit useful edge expression is

    B_i=exp(-2a)/(2pi q_1q_2q_3)
        integral_0^a exp(-x)
        sqrt(max(4a²q_jq_k-(q_i x-a(q_j+q_k))²,0)) dx.   (3.6)

When sqrt(q_i) form a strict triangle, its nonzero integration interval is

    a(sqrt(q_j)-sqrt(q_k))²/q_i < x <= a;

the other quadratic root lies strictly above a.

## 4. All-radius exclusion of nontriangle and tangent normals

### Theorem

For every finite a>0, an interior local maximizer q of F_a satisfies

    e_2(q):=q_1q_2+q_2q_3+q_3q_1>1/4.                 (4.1)

### Proof

Suppose, after permuting coordinates, that sqrt(q_1)>=sqrt(q_2)+sqrt(q_3). On u-perp,

    sqrt(q_1)z_1=-sqrt(q_2)z_2-sqrt(q_3)z_3.

Therefore |z_2|,|z_3|<=sqrt(a) automatically imply |z_1|<=sqrt(a). The first constraint is redundant.

Put t=q_1 and c=q_2/(q_2+q_3), with 0<c<1. Along the simplex path

    q(t)=(t,(1-t)c,(1-t)(1-c)),

the two-coordinate covariance of (Z_2,Z_3) is

    I_2-(1-t)vv*, v=(sqrt(c),sqrt(1-c)),

with eigenvalues t and 1. Let w=(-sqrt(1-c),sqrt(c)), and K={z in C²:|z_1|,|z_2|<=sqrt(a)}. Define

    g(z)=pi^(-1) integral_C exp(-|y|²) 1_K(vz+wy) dy.

The function under the integral is log-concave in the four real variables (z,y). Prékopa's marginal theorem shows g is log-concave. It is radial in z because K is invariant under simultaneous complex rotations and the y Gaussian is radial. Hence g is nonincreasing in |z|. It is positive near zero and compactly supported: K is bounded, and the orthonormal decomposition z=v*xi, y=w*xi bounds |z| whenever xi is in K.

Write h(x)=g(sqrt(x)), x>=0. The probability of the two active constraints is

    P_c(t)=integral_0^infinity h(x) exp(-x/t) dx/t.

Differentiation under this bounded, compactly supported integral is legitimate. If X has the exponential distribution of mean t, then

    P_c'(t)=Cov(h(X),X)/t²<0.                          (4.2)

To verify the strict sign without invoking an unproved strict-equality version of Anderson's theorem, take independent X,Y with that law. Then

    2 Cov(h(X),X)=E[(h(X)-h(Y))(X-Y)].

The integrand is nonpositive because h is nonincreasing. It is strictly negative on a set of positive probability: h is positive on an initial interval and zero sufficiently far out. Thus (4.2) holds at every t>0.

In the strictly redundant region, F_a(q(t))=P_c(t), so decreasing t increases F_a. Such a point is not a local maximizer.

At sqrt(q_1)=sqrt(q_2)+sqrt(q_3), increasing t enters the redundant region. The full function t->F_a(q(t)) is C¹ by Section 2, including this tangency point. Its derivative there equals the right derivative P_c'(t)<0. Therefore decreasing t, now into the strict-triangle region, still increases F_a to first order. The tangency point is also not a local maximum. Strict monotonicity alone would not justify this step; the strict derivative (4.2) is essential.

For three positive lengths, the strict triangle inequalities are equivalent to positivity of their Heron product. With lengths sqrt(q_i) and sum q_i=1, that product is

    2 sum_(i<j)q_iq_j - sum_i q_i² =4e_2(q)-1.

This proves (4.1). Finally for a fixed coordinate t=q_i,

    e_2(q)<=t(1-t)+(1-t)²/4=(1+2t-3t²)/4.

The right side can exceed 1/4 only for t<2/3. Thus every coordinate at an interior local maximum is strictly less than 2/3. QED.

Prékopa, *On logarithmic concave measures and functions* (1973), Theorem 6, printed page 342, is the borrowed marginal-log-concavity input. The strict covariance derivative and its application here are proved above.

## 5. The complete boundary comparison

If q=(t,1-t,0), a unit direction in the first two coordinates is (sqrt(1-t),-sqrt(t)). The third coordinate is an independent standard proper complex Gaussian. Thus

    F_a(t,1-t,0)
       =(1-exp(-a))(1-exp(-a/max(t,1-t))).              (5.1)

For finite positive a this is maximized precisely at t=1/2. The vertices have value (1-exp(-a))² and are strictly worse. Consequently every global maximizer is either a permutation of the block normal (1/2,1/2,0) or lies in the strict-triangle interior (4.1).

This does not claim that the block wins against that interior for every radius. Indeed the already accepted large-radius localization precludes such a claim.

## 6. The precise all-distinct stationary obstruction

Set e_3(q)=q_1q_2q_3. In the ordered all-distinct interior chamber, (e_2,e_3) are local coordinates. In q_1=x,q_2=y,q_3=1-x-y coordinates, their Jacobian determinant is

    (q_1-q_2)(q_1-q_3)(q_2-q_3),

which is nonzero. Thus locally write F_a(q)=Psi_a(e_2,e_3). At S=1 the gradient differences of the homogeneous extension satisfy

    H_i-H_j=(q_j-q_i)(Psi_(e_2)+q_k Psi_(e_3)).         (6.1)

If all three q_i are distinct, stationarity is equivalent to

    Psi_(e_2)=Psi_(e_3)=0.                             (6.2)

At such a point the constrained Hessian is congruent to the Hessian of Psi in (e_2,e_3), because the terms involving first derivatives of Psi vanish. Hence a local maximum additionally requires that two-by-two Hessian to be negative semidefinite.

A proof of the requested two-equal property must rule out all-distinct global maxima in

    q_i>0, sum q_i=1, e_2>1/4,

not merely observe (6.2). A sufficient stronger result would exclude any simultaneous zero (6.2), or show a positive Hessian direction at every such zero. Neither is established here. A non-strict second-order test alone is not sufficient to establish a maximizer.

Symmetry by itself cannot close this gap. For example the symmetric polynomial

    G(q)=-(e_2(q)-31/100)²-(e_3(q)-3/100)²

has global maxima exactly at the six permutations of (1/2,3/10,1/5). They are all-distinct strict-triangle points, since e_2=31/100>1/4. This is a counterexample only to a proposed inference from symmetry and smoothness; it is **not** a counterexample for F_a.

## 7. An equivalent finite-integral root-count gate

The finite-integral equations make the missing step explicit without differentiating an oscillatory logarithm. Remove the common positive factor 1/(2pi q_1q_2q_3) from A_i-B_i and denote the result by T_i. It is symmetric in the two q coordinates other than q_i. For fixed e=e_2 and t=q_i, those two coordinates are

    b(t,e)=(1-t+sqrt(1+2t-3t²-4e))/2,
    c(t,e)=(1-t-sqrt(1+2t-3t²-4e))/2.

Consequently T_i=g_a(q_i;e_2), where the fully explicit function is

    g_a(t;e)= exp(-a) integral_0^a integral_0^a
                  exp(-(y+z)) sqrt(max(Delta_(t,b,c)(a,y,z),0)) dy dz
              -exp(-2a) integral_0^a
                  exp(-x) sqrt(max(Delta_(t,b,c)(x,a,a),0)) dx.  (7.1)

The definition is invariant under swapping b,c. For 1/4<e<1/3, the available t interval is

    (1-2sqrt(1-3e))/3 <= t <= (1+2sqrt(1-3e))/3.

The stationarity equation becomes

    g_a(q_1;e_2)=g_a(q_2;e_2)=g_a(q_3;e_2).            (7.2)

An at-most-two-horizontal-intersections theorem for this explicit function, or an appropriate Hessian exclusion for its three-intersection configurations, would complete the structural reduction. No such theorem is supplied. In particular, positivity of the integrands in the separate terms of (7.1) does not prove convexity, monotonicity, or an at-most-two-root property of their difference.

If the two-equal assertion is eventually proved, Sections 4–5 would reduce the global problem to the block endpoint and

    q=(x,x,1-2x), 1/6<x<1/2,

up to permutation. That reduction is conditional, not a result of this packet.

## 8. Sources, controls, and scope

Accepted local premises read without modification:

- Earlier effective-optimizer report (background source, not required for the elementary smoothing proof)
- Earlier effective-optimizer independent review (background source)

Primary sources directly opened:

- Glover, Tkocz, Wyczesany, *Stability of polydisc slicing*, Mathematika 69 (2023), 1165–1182, DOI 10.1112/mtk.12225. Section 3.2, equation (7), supplies the unweighted comparison formula only. https://eprints.whiterose.ac.uk/221836/1/Mathematika%20-%202023%20-%20Glover%20-%20Stability%20of%20polydisc%20slicing.pdf
- Prékopa, *On logarithmic concave measures and functions*, Acta Sci. Math. 34 (1973), 335–343, Theorem 6, printed page 342. https://rutcor.rutgers.edu/Prekopa/pdf/SCIENT2.pdf
- NIST DLMF, 10.6.6 and 10.17.3. https://dlmf.nist.gov/10.6.E6 and https://dlmf.nist.gov/10.17.E3

The fresh symbolic controls verify the frame Gram matrix, the exact Gram-coordinate Jacobian and Delta identity, determinant/Laplace algebra, invariant Jacobian, Heron identity, and the exact illustrative polynomial. They are algebraic controls, not an optimization census. No numerical global search was performed. No external mutation was performed. No historical-priority claim is made.

Final scope: exact finite-radius variational equations and a strict-triangle necessary condition are proved; the all-distinct strict-triangle exclusion, exact one-parameter optimizer reduction, and full all-radius classification remain unresolved.
