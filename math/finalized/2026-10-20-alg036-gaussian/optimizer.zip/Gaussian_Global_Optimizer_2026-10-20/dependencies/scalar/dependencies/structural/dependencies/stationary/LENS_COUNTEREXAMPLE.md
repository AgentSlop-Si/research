# A rigorously false conditional smoothing shortcut

Date: 2026-10-20. Status: independently derived diagnostic, not a counterexample to the ALG-036 optimizer conjecture.

## 1. What is disproved

For a standard proper complex Gaussian Y, define

    K(t,b,r) = {y in C:
       |sqrt(1-t)y-sqrt(t)b| <= r,
       |sqrt(t)y+sqrt(1-t)b| <= r},
    L(t,b,r)=Pr(Y in K(t,b,r)).

The proposed conditional shortcut was that L is nondecreasing in t toward 1/2 whenever 0<t<=1/2 and 0<=b<=r sqrt(t), with b,r held fixed. This assertion is false. An explicit counterexample is

    r=1/100, b=r/2, t=1/4,
    partial_t L(t,b,r) < -23/703125 < 0.

The bound is conservative. It is proved analytically below; no floating-point or quadrature decision enters.

This does NOT disprove smoothing after averaging over the independent truncated Gaussian coordinate that creates b, and does NOT supply an all-distinct maximizing normal for the original problem. It invalidates only a stronger pointwise conditional lemma.

## 2. Exact unweighted shape derivative

First scale r=1 and fix b=1/2. Put p=1-t. The two disks defining K have centers and radii

    c_1=b sqrt(t/p),     R_1=1/sqrt(p),
    c_2=-b sqrt(p/t),    R_2=1/sqrt(t),
    d=c_1-c_2=b/sqrt(tp).

At t=1/4 these become

    R_1=2/sqrt(3), R_2=2, d=2/sqrt(3).

The disks meet transversely. Their half-arc angles measured toward the other center are

    alpha_1=2pi/3, alpha_2=pi/6,

and the common chord halfheight is h=R_1 sin(alpha_1)=R_2 sin(alpha_2)=1. These follow from the elementary cosine law:

    cos(alpha_1)=(d²+R_1²-R_2²)/(2dR_1)=-1/2,
    cos(alpha_2)=(d²+R_2²-R_1²)/(2dR_2)=sqrt(3)/2.

Let A(t) be the ordinary area of the disk intersection. Differentiating its two circular-segment areas, or integrating the normal boundary velocity over each active arc, gives

    A'(t)=2R_1 R_1' alpha_1+2R_2 R_2' alpha_2-2h d'.

Here R_1'=4/(3sqrt(3)), R_2'=-4 and d'=-8/(3sqrt(3)) at t=1/4. Thus exactly

    A'(1/4)=(48sqrt(3)-40pi)/27 < -4/3.

The last strict inequality follows only from sqrt(3)<7/4 and pi>3.

## 3. Transfer to the actual Gaussian mass

For general r, set b=r/2. The lens is r times the preceding unit-scale lens, so

    partial_t L(1/4,r/2,r)
       =r²/pi integral_boundary(K(1/4,1/2,1))
          exp(-r²|y|²) v_n(y) ds(y),

where v_n is the outward normal velocity at fixed unit-scale b=1/2. There are no vertex terms: the two boundary arcs meet transversely, and the standard boundary-velocity formula applies piecewise. Their moving endpoints have zero length.

Every point of this lens obeys |y|²+b²<=2, obtained by adding the two squared coordinate constraints. Consequently |y|²<=7/4 on its boundary. Therefore

    |exp(-r²|y|²)-1| <= (7/4)r².

Bound the total absolute boundary flux by the entire two circles. On a circle with center c(t) and radius R(t), |v_n|<=|R'|+|c'|. At the specified parameters,

    c_1'=4/(3sqrt(3)), c_2'=4/sqrt(3).

It follows that

    integral_boundary |v_n| ds
      <=2pi R_1(|R_1'|+|c_1'|)
        +2pi R_2(|R_2'|+|c_2'|)
      =32pi/9+16pi(1+1/sqrt(3))
      <320pi/9.

Thus the weighted and unweighted derivatives differ by at most

    (560/9)r⁴.

Using A'<-4/3 and pi<4 gives

    partial_t L(1/4,r/2,r)
       < -r²/3+(560/9)r⁴.

At r=1/100 the last expression is the negative rational number -23/703125. This proves the claim. The condition b<=r sqrt(t) holds with equality at the starting point and continues to hold for every sufficiently small positive change of t. Hence the decrease already contradicts monotonicity on its proposed admissible domain. Continuity also gives nearby examples with strict b<r sqrt(t).

## 4. Relation to the actual normal-simplex problem

Holding the smallest normal weight q_1=c fixed, write s=1-c and t=q_2/s. After conditioning on a standard complex Gaussian X with |X|<=r/sqrt(s), the other two coordinate constraints have precisely the form above, with b=sqrt(c)|X| after removing its phase. If c<=q_2,q_3, then b<=r sqrt(t) for t<=1/2. This explains why the false lemma was tempting.

However the full probability averages L(t,b,r) against the allowed distribution of X. A negative derivative for individual b values does not determine the sign of that average. The two-largest-equal reduction, the weaker two-equal assertion, and the full all-radius optimizer remain unproved by this diagnostic.
