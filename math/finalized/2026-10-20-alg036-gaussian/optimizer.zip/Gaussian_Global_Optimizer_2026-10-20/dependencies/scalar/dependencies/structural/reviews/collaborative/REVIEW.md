# Independent review: all-radius two-largest-equal Gaussian maximizers

Date: 2026-10-20 UTC. Status: PASS on exact candidate bytes, with disclosed collaborative technical contributions. A separate fresh adversarial review is required for release acceptance.

## 1. Contract and current verdict

The problem is the proper complex rank-two Gaussian Z ~ CN(0,I-uu*) in C³, u_i=√q_i, q_i≥0 and ∑q_i=1, with F_a(q)=Pr(max_i |Z_i|≤√a), for every finite a>0. This is not a real Gaussian cube problem. The proposed theorem is stronger than the requested global two-equal gate: every interior local maximum has its two largest q coordinates equal.

I independently rederived the communicated rotation identity, the normalization, every sign, the strict positive boundary patch, and the zero-weight/finite-radius endpoints. I then read and checked the complete frozen candidate, including its actual cutoff passage and finite face-minus-edge conversion. No mathematical defect was found. The accepted byte binding and the limits of this collaborative review are stated in Section 8.

The proof does not classify which member of the two-equal family wins, compute transition radii, or resolve the full ALG-036 optimizer problem.

## 2. Independent coordinate and normalization derivation

Write q=(c,st,sp), where s=1−c, p=1−t, 0<c≤st≤sp. Then 0<t≤1/2. Use the actual plane coordinates x=z₂ and y=z₃, giving

    z₁=−√(s/c)(√t x+√p y).

The complex Gram determinant of this linear parametrization is det(I+(s/c)vv*)=1/c, for v=(√t,√p). The induced four-real-dimensional volume multiplier is this complex determinant, not its square root. Thus, with a=r², κ=s/c and d=ac/s,

    F_a(c,st,sp)=(π²c)⁻¹ J(θ),
    J(θ)=∫_{D_r×D_r} e^{−|x|²−|y|²} h(|sinθ x+cosθ y|²) dx dy,
    h(v)=e^{−κv} 1_{v≤d},  t=sin²θ.

The order assumption gives d≤at. All parameters c,a,κ,d stay fixed as θ varies; only the two larger weights are smoothed.

## 3. Independent rotation and boundary derivation

Identify x,y with real two-vectors. Let

    G=y·∇_x−x·∇_y.

It has zero divergence and annihilates |x|²+|y|². If V_θ=|sinθ x+cosθ y|², direct differentiation gives ∂_θ V_θ=−G V_θ. For a smooth h this implies

    J'(θ)=−∫_{∂(D_r×D_r)} e^{−|x|²−|y|²} h(V_θ) G·n dσ.

The two smooth faces are |x|=r and |y|=r. Their common corner has surface measure zero. Swap x and y on the second face. On the first face set ρ=|y| and u=cosφ=Re(y x̄)/(rρ). The resulting identity is

    J'(θ)=−∫_{|x|=r, |y|≤r} e^{−a−ρ²} ρu
                  [h(A+Ku)−h(B+Ku)] dσ(x)dy,
    A=ta+pρ², B=pa+tρ², K=2√(tp a)ρ.

No factor 2 is missing: the second face has been combined with the first through the bracket, not added again. The Gaussian prefactor and the overall normalizing 1/(π²c) are positive.

Since B−A=(p−t)(a−ρ²)≥0, h(A+Ku)≥h(B+Ku). If u≥0, A+Ku≥ta≥d, so the bracket vanishes away from the immaterial equality set. If u<0, the bracket is nonnegative while −ρu is positive. Therefore J'(θ)≥0.

## 4. The indicator is not silently differentiated

A valid approximation is h_ε(v)=e^{−κv} χ((d−v)/ε), where χ is a smooth nondecreasing function that is 0 on (−∞,0] and 1 on [1,∞). Then h_ε is nonnegative and nonincreasing on v≥0, and is supported below d. The support condition is essential: approximations supported up to d+ε would not preserve the pointwise sign argument as written.

For these approximants the preceding integration by parts is ordinary. Both the volume integrands and boundary-flux integrands have bounds independent of ε on their fixed compact domains. The level set V_θ=d has volume measure zero and face-surface measure zero: for each |x|=r on a face it is a circle, a point, or empty in the two-real-dimensional y plane, since cosθ>0; the analogous statement holds in the volume. Thus dominated convergence applies.

To avoid an invalid inference that pointwise convergence of derivatives alone implies differentiation of a limit, integrate the smooth identity between θ₀ and θ₁ first. Dominated convergence in the product of the angle interval and fixed boundary gives

    J(θ₁)−J(θ₀)=∫_{θ₀}^{θ₁} B(θ)dθ,

where B is the displayed limiting boundary flux. B is continuous in θ, again by dominated convergence and the zero-measure boundary level sets. Hence J'=B as an ordinary derivative. Alternatively the accepted C¹ regularity is consistent with the same integrated identity. This argument handles tangencies and the endpoint order equality c=st; it does not discard either as a nonsmooth case.

## 5. Strictness is a genuine positive-measure argument

For t<p, choose on the first face

    ρ₀=r√(t/p), u₀=−1.

Here 0<ρ₀<r, and

    A+Ku₀=0,
    B+Ku₀=a(p−t)²/p>0.

Because d>0, κ>0, and a is finite positive, h(0)=1 is strictly larger than h(v) at every v>0. A sufficiently small neighborhood of the chosen configuration has u<0, its first argument below d and sufficiently close to zero, its second argument bounded positively away from zero, and its bracket bounded positively away from zero. This remains true if the second argument at the central point equals d: no continuity across the jump is needed for the lower bound, since h(v)≤e^{−κv}.

That neighborhood has positive boundary measure. At u=−1 the polar angular coordinate has an endpoint if φ is reduced to [0,π], but every one-sided angular neighborhood still has positive measure; equivalently, use the full phase circle. The Gaussian weight is strictly positive everywhere at finite a. Therefore J'(θ)>0 whenever t<p. This works with c=st as well as c<st.

## 6. Local/global consequences and every boundary

Take any interior point and permute it into q₁≤q₂≤q₃. If q₂<q₃, the preceding tangent motion increases q₂ and decreases q₃ with q₁ fixed. It remains in the simplex and preserves q₁ as a smallest weight for sufficiently small positive motion. The derivative is strictly positive, so this point cannot be a local maximum. Therefore every interior local maximum, in particular every interior global maximum, has q₂=q₃.

The derivative need not be strictly positive at t=1/2: symmetry forces zero there. This is the target endpoint, not a gap. Integration of the positive derivative before the endpoint and continuity show that complete smoothing strictly improves any initial t<1/2 in the ordered regime.

For c=0 the parametrization above is unavailable and must not be used. The already accepted exact boundary formula is

    F_a(0,t,1−t)=(1−e^{−a})(1−e^{−a/max(t,1−t)}).

It is uniquely maximized, modulo permutation, at (0,1/2,1/2) for every finite a>0; vertices are strictly worse. Thus zero weights are fully covered by a separate formula.

At a=0 or a=∞ the claimed strictness would be false because the objective is constant. Both are expressly outside the finite-positive-radius contract. No limit argument silently asserts strictness at either endpoint. For every arbitrarily small positive a and every arbitrarily large finite a the strict patch still has positive Gaussian weight and κ>0.

Consequently the global value has the exact one-parameter reduction

    max_{q∈Δ₂} F_a(q)=max_{0≤c≤1/3} F_a(c,(1−c)/2,(1−c)/2).

Every global maximizer is a permutation of a maximizing member of this family. This is a structural theorem and a reduction, not the maximization of that one-variable function.

## 7. Independence, contributed details, and controls

The boundary-rotation/sign proof was communicated by the author before this review. I rederived it independently and did not alter the author's source file. I supplied the author the smooth-cutoff justification and the observation that c=st is included. These technical contributions are disclosed for an additional reader's scrutiny; they are not presented as separately pre-existing accepted lemmas. The main rotation/sign idea is the author's.

The local independent_checks.py and INDEPENDENT_CHECKS.json verify exact algebra for the Gram determinant, generator identity, Gaussian invariance, zero divergence, ordered arguments, and strict-patch values. All checks pass. These finite symbolic checks supplement, not replace, the analytic proof.

A preliminary floating-point sign scan was made while testing whether the proposed universal sign was plausible. It is segregated under exploratory/ and has no role in this proof or verdict. No numerical absence-of-counterexample argument is used. No external state was mutated.

## 8. Exact-byte review and disposition

Reviewed candidate:

    candidate/PROOF.md (source identity)
    SHA-256 c992118d24465076fae1e708725dfd77c82ac5d654c904f976bb7299531692a1

The full candidate/control manifest is

    original candidate manifest (source identity)
    SHA-256 eee4a1c75e357d112bbd30f2db32aae7e234fc642e3dcac0614bf0d605ab76ce

Every listed hash and byte length agrees. CANDIDATE_INTEGRITY.json records the check. Candidate Sections 4–5 contain the valid uniform positive patch and support-preserving smooth approximation described above, with no missing limit interchange. Section 6 has the correct derivative conversion:

    (A₂−B₂)−(A₃−B₃)=J'(θ)/(2π²cs√(tp))>0.

Thus it really settles the actual stationary-integral gate; it does not replace it by an unproved assertion about an auxiliary density. All-distinct stationary points are ruled out, and the necessary two-largest-equal statement holds even for interior local maxima.

I reran the author’s control script in a separate directory without editing any candidate files. Its 13-check output reproduces the sealed EXACT_CONTROLS.json byte for byte. My separate 8-check symbolic control also passes. The final exact-byte review is consistent with the declared global range c∈[0,1/3] and the preserved unresolved scalar optimization.

Disposition: PASS for the finite-positive-radius proper-complex strict largest-pair smoothing theorem, the interior local/global two-largest-equal consequence, the nonexistence of all-distinct stationary points, and the compact one-parameter global reduction. No scalene counterexample is supplied or required because the positive theorem is established. Do not extend this verdict to the all-radius maximizing parameter, phase transitions, the complete ALG-036 optimizer problem, or any external publication.

This is a collaborative verification, not a blind adversarial audit: the author sent the mechanism before freezing, and I discussed the cutoff justification. That provenance is explicit in both this review and the sealed COLLABORATION.md. The fresh adversarial review must make a separate decision; this collaborative report is not that separate acceptance.
