#!/usr/bin/env python3
"""Independent exact consistency controls, not numerical proof evidence."""
import hashlib
import json
from pathlib import Path
import sympy as S

HERE = Path(__file__).resolve().parent
checks = {}
def zero(name, expr):
    residual = S.simplify(expr)
    checks[name] = {'pass': residual == 0, 'residual': str(residual)}
# Historical source-byte checks are not rerun against public projections.
# The 31 exact algebra checks below are unchanged from the source audit.

# Reconstruct the plane from its graph, including full real volume and covariance.
alpha,beta = S.symbols('alpha beta', positive=True)
N = 1+alpha**2+beta**2
B = S.Matrix([[-alpha,-beta],[1,0],[0,1]])
G = B.T*B
M = S.Matrix([[-alpha,0,-beta,0],[0,-alpha,0,-beta],[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
zero('complex_gram', G.det()-N)
zero('real_gram_determinant', (M.T*M).det()-N**2)
u = S.Matrix([1,alpha,beta])/S.sqrt(N)
for i, x in enumerate(B*G.inv()*B.T-(S.eye(3)-u*u.T)):
    zero('projector_covariance_'+str(i), x)
zero('normal_is_unit', (u.T*u)[0]-1)
for i,x in enumerate(u.T*B):
    zero('graph_is_in_plane_'+str(i), x)

x1,x2,y1,y2,theta = S.symbols('x1 x2 y1 y2 theta', real=True)
coords=[x1,x2,y1,y2]
V=[y1,y2,-x1,-x2]
def generator(f): return sum(v*S.diff(f,x) for v,x in zip(V,coords))
Q = x1**2+x2**2+y1**2+y2**2
zero('generator_divergence', sum(S.diff(v,x) for v,x in zip(V,coords)))
zero('gaussian_radial_invariance', generator(Q))
X=(S.sin(theta)*x1+S.cos(theta)*y1)**2+(S.sin(theta)*x2+S.cos(theta)*y2)**2
zero('negative_rotation_sign', generator(X)+S.diff(X,theta))

r,rho,t,p,a,c,s,kappa = S.symbols('r rho t p a c s kappa', positive=True)
phi = S.symbols('phi', real=True)
A=t*r**2+p*rho**2
B2=p*r**2+t*rho**2
K=2*S.sqrt(t*p)*r*rho
Xface=(S.sqrt(t)*r+S.sqrt(p)*rho*S.cos(phi))**2+(S.sqrt(p)*rho*S.sin(phi))**2
Yface=(S.sqrt(p)*r+S.sqrt(t)*rho*S.cos(phi))**2+(S.sqrt(t)*rho*S.sin(phi))**2
zero('first_boundary_argument', Xface-A-K*S.cos(phi))
zero('swapped_boundary_argument', Yface-B2-K*S.cos(phi))
zero('boundary_order', B2-A-(p-t)*(r**2-rho**2))
zero('smallest_weight_support_equivalence', (a*t-a*c/s)-a*(s*t-c)/s)

rho0=r*S.sqrt(t/p)
D=r**2*(p-t)**2/p
zero('strict_center_first_argument', (A-K).subs(rho,rho0))
zero('strict_center_second_argument', (B2-K).subs(rho,rho0)-D)

# Independent Cartesian strict patch: z=-rho0+(xi+i eta).
xi,eta = S.symbols('xi eta',real=True)
Xpatch=(S.sqrt(t)*r+S.sqrt(p)*(-rho0+xi))**2+p*eta**2
Ypatch=(S.sqrt(p)*r+S.sqrt(t)*(-rho0+xi))**2+t*eta**2
zero('cartesian_patch_first_argument', Xpatch-p*(xi**2+eta**2))
zero('cartesian_patch_second_argument', Ypatch-((r*(p-t)/S.sqrt(p)+S.sqrt(t)*xi)**2+t*eta**2))
zero('strict_patch_squared_lower_radius', S.Rational(3,4)**2-S.Rational(9,16))
zero('strict_patch_squared_upper_radius', S.Rational(1,4)**2-S.Rational(1,16))

Jprime,delta,gap = S.symbols('Jprime delta gap',positive=True)
zero('path_chain_rule', S.diff(S.sin(theta)**2,theta)-2*S.sin(theta)*S.cos(theta))
zero('face_edge_conversion', (Jprime/(2*S.pi**2*c*S.sqrt(t*p)))/s-Jprime/(2*S.pi**2*c*s*S.sqrt(t*p)))
Jbound=S.pi**2*r*rho0*delta**2*S.exp(-2*a)*gap
zero('independent_strict_derivative_bound_constant', (Jbound/(2*S.pi**2*c*S.sqrt(t*p))).subs(r,S.sqrt(a))-a*delta**2*S.exp(-2*a)*gap/(2*c*p))

# Boundary formula: its two independent complex Gaussian modes have variances 1 and max(t,1-t).
q = S.symbols('q',positive=True)
boundary=(1-S.exp(-a))*(1-S.exp(-a/(1-q)))
zero('boundary_derivative_positive_factor', S.diff(boundary,q)-(1-S.exp(-a))*a*S.exp(-a/(1-q))/(1-q)**2)

result={'scope':'Exact independent algebra only. Historical source integrity is documented separately in PORTABLE_CONTROLS.md; analytic proof is in REVIEW.md.', 'all_pass':all(v['pass'] for v in checks.values()), 'check_count':len(checks), 'checks':checks}
(HERE/'INDEPENDENT_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_pass':result['all_pass'],'check_count':len(checks)},indent=2))
assert result['all_pass']
