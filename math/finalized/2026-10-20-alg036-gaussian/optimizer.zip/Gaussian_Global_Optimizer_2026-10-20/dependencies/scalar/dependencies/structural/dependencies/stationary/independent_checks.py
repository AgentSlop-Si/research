"""Fresh exact algebra controls; not a global optimizer or numerical certificate."""
import json
from pathlib import Path
import sympy as s

checks={}
def check(name, expr):
    value=s.simplify(expr)
    checks[name]=bool(value==0)
    if value!=0: raise AssertionError((name,value))
x,y=s.symbols('x y',real=True);z=1-x-y
q=[x,y,z]
e2=x*y+x*z+y*z;e3=x*y*z
check('invariant_jacobian',s.det(s.Matrix([[s.diff(e2,x),s.diff(e2,y)],[s.diff(e3,x),s.diff(e3,y)]]))-(x-y)*(x-z)*(y-z))
check('heron',2*(x*y+x*z+y*z)-(x*x+y*y+z*z)-(4*e2-1))
s1,s2,s3=s.symbols('s1 s2 s3');sv=[s1,s2,s3]
D=x*(1+s2)*(1+s3)+y*(1+s1)*(1+s3)+z*(1+s1)*(1+s2)
check('laplace_tangent_13',s.diff(D,x)+(s1-s3)*(1+s2))
check('laplace_tangent_23',s.diff(D,y)+(s2-s3)*(1+s1))
check('laplace_tangent_12',s.diff(D,x)-s.diff(D,y)+(s1-s2)*(1+s3))
check('symmetry_counterexample_e2',e2.subs({x:s.Rational(1,2),y:s.Rational(3,10)})-s.Rational(31,100))
check('symmetry_counterexample_e3',e3.subs({x:s.Rational(1,2),y:s.Rational(3,10)})-s.Rational(3,100))
A,B,C=s.symbols('A B C',real=True)
frames=[s.Matrix([[3/s.sqrt(13),12/(7*s.sqrt(13))],[-2/s.sqrt(13),18/(7*s.sqrt(13))],[0,-13/(7*s.sqrt(13))]]),s.Matrix([[1/s.sqrt(2),1/s.sqrt(6)],[-1/s.sqrt(2),1/s.sqrt(6)],[0,-2/s.sqrt(6)]])]
for m,V in enumerate(frames):
 check(f'frame_{m}_isometry',sum(v*v for v in V.T*V-s.eye(2)))
 P=V*V.T;qs=[s.simplify(1-P[i,i]) for i in range(3)]
 M=s.Matrix([[V[i,0]**2,V[i,1]**2,2*V[i,0]*V[i,1]] for i in range(3)])
 check(f'frame_{m}_jacobian_squared',s.det(M)**2-4*s.prod(qs))
 xx=M*s.Matrix([A,B,C])
 delta=2*sum(qs[i]*qs[j]*xx[i]*xx[j] for i in range(3) for j in range(i+1,3))-sum(qs[i]**2*xx[i]**2 for i in range(3))
 check(f'frame_{m}_delta',delta-4*s.prod(qs)*(A*B-C*C))
 check(f'frame_{m}_trace',sum(xx)-A-B)
 TT=s.diag(1+s1,1+s2,1+s3)
 check(f'frame_{m}_laplace',s.det(V.T*TT*V)-sum(qs[i]*s.prod([1+sv[j] for j in range(3) if j!=i]) for i in range(3)))
# Exact diagnostic lens derivative.
t,b=s.symbols('t b',positive=True);p=1-t
R1=1/s.sqrt(p);R2=1/s.sqrt(t);d=b/s.sqrt(t*p)
subs={t:s.Rational(1,4),b:s.Rational(1,2)}
alpha1=2*s.pi/3;alpha2=s.pi/6;h=1
area_deriv=(2*R1*s.diff(R1,t)*alpha1+2*R2*s.diff(R2,t)*alpha2-2*h*s.diff(d,t)).subs(subs)
check('lens_exact_area_derivative',area_deriv-(48*s.sqrt(3)-40*s.pi)/27)
check('lens_strict_upper_algebra',(48*s.Rational(7,4)-40*3)/27+s.Rational(4,3))
r=s.Rational(1,100)
upper=-r*r/3+s.Rational(560,9)*r**4
checks['lens_weighted_upper_strict_negative']=bool(upper<0)
checks['lens_radius']=str(r)
checks['lens_weighted_derivative_upper']=str(upper)
checks['all_exact_checks_pass']=all(v for v in checks.values() if isinstance(v,bool))
Path(__file__).with_name('INDEPENDENT_CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
