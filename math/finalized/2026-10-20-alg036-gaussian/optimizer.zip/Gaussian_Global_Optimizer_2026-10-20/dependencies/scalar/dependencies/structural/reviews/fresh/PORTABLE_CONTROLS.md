# Fresh audit controls: original versus portable

The original fresh audit performed 44 exact checks: 31 symbolic algebra checks and 13 source-byte checks (the original proof hash, original manifest hash, six manifest members, and five source-binding entries). Its historical output is retained in HISTORICAL_CONTROLS.json with nonmathematical public source-label aliases. All 44 original checks passed.

The public independent_controls.py retains the complete 31-check mathematical block byte for byte and removes only the source-specific integrity setup, which referred to private originals. Its output scope and count explicitly reflect that change. INDEPENDENT_CONTROLS.json is both the 31-entry projection of the historical output and the independently regenerated output of the portable script; those bytes match exactly.

The 13 historical checks cannot honestly be rerun against differently hashed public projections or omitted background originals. They are historical acceptance evidence, not claimed portable source-byte tests. The package verifier separately checks public member integrity, source-identity bindings, projection hashes, review separation, scope, and source-preservation attestations. It does not mislabel those tests as reruns of the 13 original checks.

The original fresh review, verdict, controls, output, and manifest have source identities in provenance/SOURCE_IDENTITIES.json. The portable script and outputs have their own public hashes in the release manifest and projection record. All mathematical checks, identities, formulas, and verdict scope remain unchanged.
