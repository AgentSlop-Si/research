# ALG-036: all-radius strict smoothing of the two largest normal weights

Date: 20 October 2026 UTC. Historical source status: candidate proof, awaiting independent review. Current release disposition is stated in RELEASE.json.

## 1. Result and exact scope

For every finite a>0, let

    F_a(q) = Pr(max_j |Z_j| <= sqrt(a)),
    Z ~ CN(0,I-uu*), u_j=sqrt(q_j), q_j>=0, sum_j q_j=1,

with the proper-complex Gaussian convention and intrinsic plane density pi^(-2) exp(-||z||²). This is exactly the previously accepted contract. No real-Gaussian substitution is made.

**Theorem (strict largest-pair smoothing).** If

    0 < q_1 <= q_2 < q_3,

then, keeping q_1 fixed and increasing q_2 toward q_3 with their sum fixed, F_a increases strictly. In particular,

    F_a(q_1,q_2,q_3)
      < F_a(q_1,(1-q_1)/2,(1-q_1)/2).

Moreover the derivative is strictly positive at every unequal point of that path, including an initial point with q_1=q_2.

Consequently every interior local maximizer, and hence every interior global maximizer, has its **two largest** coordinates equal. All-distinct stationary points are impossible, not merely excluded as global maxima. Together with the already accepted boundary result, the full global optimization reduces exactly to

    max_{0 <= c <= 1/3} F_a(c,(1-c)/2,(1-c)/2).

This settles the selected structural all-radius gate. It does not determine the maximizing c, its changes with a, or the complete all-radius optimizer. The existing centering, boundary and small-radius results are retained as dependencies, without re-audit or alteration.

The proof uses a finite rotation-boundary integral for the actual probability. It does **not** claim pointwise monotonicity of the conditional Gaussian lens, which is known to be false. Section 6 explicitly identifies the resulting sign of the accepted finite face-minus-edge derivative.

## 2. Exact finite integral on two coordinate disks

Write

    c=q_1, s=1-c, q_2=s t, q_3=s p,
    p=1-t, r=sqrt(a), t=sin²(theta), p=cos²(theta).

The sorted-weight assumption is

    0<c, c/s <= t < 1/2.

Use w=z_2 and z=z_3 as coordinates on u-perp. Then

    z_1=-sqrt(s/c)(sqrt(t) w+sqrt(p) z).

The complex Gram determinant of this parametrization is 1/c: it is the determinant of I_2+vv* with v=(sqrt(q_2/c),sqrt(q_3/c)). Therefore its four-real-dimensional volume Jacobian is also 1/c. Put

    R²=a c/s, kappa=s/c,
    h(v)=exp(-kappa v) 1_{v<=R²}, v>=0.

Then exactly

    F_a(c,s t,s p) = J(theta)/(pi² c),                  (2.1)

    J(theta)=integral_{|w|<=r, |z|<=r}
                exp(-|w|²-|z|²)
                h(|sin(theta) w+cos(theta) z|²) dw dz. (2.2)

Here dw,dz are planar Lebesgue measures. The essential cutoff condition supplied by choosing the smallest normal weight is

    R² <= a t.                                        (2.3)

Both the probability and the weight h in (2.2) are independent of theta except for the indicated rotation. In particular, c, s, R and kappa remain fixed during differentiation.

## 3. Rotation-boundary identity

First replace h by any smooth, bounded, nonnegative, nonincreasing function h_epsilon supported in [0,R²], and use J_epsilon for the corresponding integral. Such approximants to h are constructed in Section 5.

Treat w,z as vectors in R². Define the vector field

    V(w,z)=(z,-w),
    G=z dot grad_w - w dot grad_z.

Its divergence is zero, and G(exp(-|w|²-|z|²))=0. Also, for

    b_theta=sin(theta) w+cos(theta) z,

we have G b_theta=-partial_theta b_theta. Therefore

    partial_theta h_epsilon(|b_theta|²)
      =-G[h_epsilon(|b_theta|²)].

Apply the divergence theorem on the product of disks. Its corner, where both circle boundaries meet, has boundary measure zero. The two face contributions have opposite signs. Swap w and z in the second face to obtain

    J_epsilon'(theta)
      =- integral_{|w|=r, |z|<=r} exp(-a-|z|²)
           (w dot z)/r
           [h_epsilon(|sin(theta) w+cos(theta) z|²)
             -h_epsilon(|cos(theta) w+sin(theta) z|²)] dS_w dz.  (3.1)

Using simultaneous rotational invariance, write w=r, z=rho exp(i phi). Set

    A=t a+p rho²,
    B=p a+t rho²,
    K=2 sqrt(t p) r rho.

Since dS_w integrates to 2pi r and dz=rho d rho d phi, (3.1) becomes

    J_epsilon'(theta)
      =-2pi r integral_0^r exp(-a-rho²) rho²
           integral_0^{2pi} cos(phi)
             [h_epsilon(A+K cos(phi))
                -h_epsilon(B+K cos(phi))] d phi d rho.         (3.2)

All arguments of h_epsilon are nonnegative squared norms. Every integral is over a finite domain; there is no improper, oscillatory, or conditionally convergent expression here.

## 4. Sign and strictness

For 0<=rho<=r and t<=p,

    B-A=(p-t)(a-rho²)>=0.                              (4.1)

Since h_epsilon is nonincreasing, the bracket in (3.2) is nonnegative.

- If cos(phi)<=0, the product of that bracket with cos(phi) is nonpositive.
- If cos(phi)>0, then

      A+K cos(phi) >= A >= t a >= R²,
      B+K cos(phi) >= A+K cos(phi).

  Both terms vanish, because h_epsilon is supported in [0,R²].

Thus every integrand after the overall minus sign in (3.2) is nonnegative. This proves J_epsilon'(theta)>=0. Crucially, this sign applies **after integrating the conditioning variable** and moving the derivative to the disk boundary. It is not a sign for the conditional lens at a fixed conditioning value.

For strictness assume 0<t<p and R>0. At

    rho_0=r sqrt(t/p), phi_0=pi,

we have 0<rho_0<r, cos(phi_0)=-1, and

    A+K cos(phi_0)=0,
    B+K cos(phi_0)=a(p-t)²/p=:D>0.                    (4.2)

For the limiting h, its bracket there is strictly positive:

    h(0)-h(D)>0,

because h(0)=1 and either h(D)=0 or h(D)=exp(-kappa D)<1.

More explicitly, choose a small open neighborhood U of (rho_0,pi) within (0,r) x (0,2pi) on which

    cos(phi)<-1/2,
    A+K cos(phi) < min(R²/4,D/8),
    B+K cos(phi) > D/2.

By continuity this is possible. For the approximants below and all sufficiently small epsilon, their first value on U equals exp(-kappa(A+K cos(phi))), and their second value is at most exp(-kappa(B+K cos(phi))). The bracket is consequently at least

    exp(-kappa D/8)-exp(-kappa D/2)>0.

On a still smaller relatively compact neighborhood, rho is bounded away from zero. Formula (3.2) therefore has a strictly positive lower contribution independent of sufficiently small epsilon. Passing to the limit gives

    J'(theta)>0 whenever 0<t<1/2 and R²<=a t.          (4.3)

The derivative conversion is

    d t/d theta=2 sqrt(t p)>0,

so (4.3) is the desired strict derivative with respect to t.

## 5. Rigorous removal of the cutoff smoothing

Choose a smooth nondecreasing function chi on R with

    0<=chi<=1, chi(x)=0 for x<=0, chi(x)=1 for x>=1.

For epsilon>0 let

    h_epsilon(v)=exp(-kappa v) chi((R²-v)/epsilon), v>=0.

This is smooth, nonnegative and nonincreasing. It is zero for v>=R² and agrees with exp(-kappa v) for v<=R²-epsilon. It converges to h except at the single threshold R²; the chosen value at that threshold is irrelevant to the volume and boundary integrals.

The volume-level threshold |sin(theta)w+cos(theta)z|²=R² has four-dimensional Lebesgue measure zero, since this nonzero complex linear map can be completed to invertible real coordinates, and a circle has planar measure zero. Thus J_epsilon(theta)->J(theta) by dominated convergence.

For each fixed theta in (0,pi/4), the boundary threshold sets

    A+K cos(phi)=R², or B+K cos(phi)=R²

have two-dimensional (rho,phi) measure zero. For every rho>0, K>0, and each of these equations has at most two phi solutions. The rho=0 set also has measure zero. Formula (3.2) therefore converges by dominated convergence to the same expression with h. Denote that limiting right-hand side by Q(theta). It is continuous in theta in (0,pi/4): at any fixed theta the just-described threshold sets are null, so another dominated-convergence argument applies as theta varies.

For any compact theta interval inside (0,pi/4), all right-hand sides in (3.2) have one common integrable bound, since 0<=h_epsilon<=1 and the domain is bounded. Consequently, the identity

    J_epsilon(beta)-J_epsilon(alpha)
      =integral_alpha^beta J_epsilon'(theta) d theta

passes to

    J(beta)-J(alpha)=integral_alpha^beta Q(theta) d theta.

Continuity of Q proves that J is differentiable and J'=Q. This establishes the limiting boundary identity and justifies (4.3), with no differentiation of an indicator and no assumed third derivative.

The same volume-level dominated-convergence argument proves continuity at theta=pi/4. Strict positivity on the open path therefore gives the strict comparison with its equal-pair endpoint. For example, compare the initial point first with a strictly intermediate point, then use nondecrease and continuity up to the endpoint.

## 6. Relation to the accepted finite face-minus-edge equations

The accepted stationary-structure report defines a homogeneous extension H_a and nonnegative finite face and opposite-edge integrals A_i,B_i, with

    H_i-H_j=(A_i-B_i)-(A_j-B_j)

on sum q_i=1. Along the current path,

    d/dt F_a(c,s t,s(1-t))
      =s(H_2-H_3)
      =s[(A_2-B_2)-(A_3-B_3)].                       (6.1)

Equations (2.1), (4.3), and d t/d theta=2sqrt(t p) now give the exact sign

    (A_2-B_2)-(A_3-B_3)
      =J'(theta)/(2 pi² c s sqrt(t p)) > 0            (6.2)

whenever 0<q_1<=q_2<q_3. This is a sign theorem for the **actual finite face-minus-edge difference**, not for its two positive terms separately. It precludes their threefold equality at any all-distinct point. Thus the invariant simultaneous-zero/Hessian obstruction from the accepted report never occurs in an all-distinct chamber.

No at-most-two-horizontal-intersections theorem for the auxiliary g_a(t;e_2) is asserted or needed. That stronger off-shell root-count question remains separate from this proof.

## 7. Consequences and preserved scope

Permute any positive q into ascending order. If its two largest coordinates differ, the theorem supplies a strictly improving tangent direction and a strictly better equal-largest comparison point. Therefore no such point is stationary, locally maximizing, or globally maximizing.

If the two largest coordinates agree, write q=(c,(1-c)/2,(1-c)/2), with 0<c<=1/3. Together with the accepted unique boundary maximum (1/2,1/2,0) up to permutations, this yields the compact one-variable global reduction c in [0,1/3]. The maximum exists by continuity on the simplex, as in the accepted setup.

This proof does not compute that one-variable maximum, classify its parameter-dependent minimizers/maximizers, establish a unique transition, or change the broader ALG-036 optimizer problem's unresolved status. It makes no claim concerning historical priority. The already accepted small-radius theorem, centering, boundary result, effective bounds, and large-radius localization remain intact. No external mutation is performed.

## 8. Inputs, originality, and controls

The exact measure contract and accepted derivative identity are taken from the stationary-structure report, SHA-256 a96d0466385eb1e44ee4360d753c2bec666255ec567eabf4a3111402d350be21, and its independent review. The already accepted false conditional-lens diagnostic is expressly preserved.

The rotation-boundary proof in Sections 2–5 was derived in this research. Its use of the divergence theorem and dominated convergence is proved with the stated elementary hypotheses, rather than importing an optimizer theorem. An independent reviewer was sent the precise proposed identity and sign argument before this draft was frozen; independent review and any contributed correction are recorded separately.

controls/exact_controls.py checks, in exact symbolic algebra, the plane Jacobian, generator sign and Gaussian invariance, the two boundary squared-norm arguments and their order, the strict-point identities, and all derivative conversion constants. These controls are consistency checks supplementing the proof, not a finite optimizer census. Exploratory floating quadrature is segregated outside candidate/ and does not occur in any proof step or certificate claim.
