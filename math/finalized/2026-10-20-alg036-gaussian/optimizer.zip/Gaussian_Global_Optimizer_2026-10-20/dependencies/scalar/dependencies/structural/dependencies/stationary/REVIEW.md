# ALG-036 stationary-structure independent review

Date: 2026-10-20 UTC. Status: ACCEPTED AT THE SCOPED RESULTS; requested all-radius two-equal structural gate remains OPEN.

## 1. Scope and integrity

I read the accepted previous optimizer report and its independent verification before examining the new candidate. The existing small-radius theorem, effective gap algorithm, explicit moderate-radius gap, centering, and large-radius localization are premises, not results rerun in this review.

The new candidate reviewed is:

    dependencies/stationary/REPORT.md (source identity)

Its frozen SHA-256 is a96d0466385eb1e44ee4360d753c2bec666255ec567eabf4a3111402d350be21. No candidate file was edited by this reviewer.

The exact problem is the proper-complex rank-two Gaussian in C^3, projector I-uu*, q_i=|u_i|², sum q_i=1, and the event max |Z_i|<=sqrt(a) for arbitrary finite a>0. Real Gaussian cube results cannot replace this contract.

Accepted new results:

- A correctly normalized homogeneous C² extension throughout the positive orthant, with absolutely convergent Fourier gradient and Hessian formulas.
- Equivalent finite-domain face-minus-edge stationary equations using a two-copy complex Gram density.
- Exclusion of every interior local maximum with e_2(q)<=1/4, including the equality locus. Thus every interior maximum has strict triangle normal lengths and q_i<2/3.
- The unique simplex-boundary maximum, modulo permutations, is q=(1/2,1/2,0).
- Correct reduction of the remaining all-distinct stationarity condition to two invariant derivatives, with no false inference that symmetry settles it.

Not accepted as established: every interior maximizer has two equal q, an exact one-dimensional reduction, a complete list of stationary points, or the full finite-radius optimizer. The candidate expressly makes none of those claims.

## 2. Primary sources and their exact roles

I independently opened the following primary sources:

1. Prékopa, On logarithmic concave measures and functions, Acta Sci. Math. 34 (1973), 335–343, Theorem 6 on printed page 342. It supplies preservation of log-concavity under integration over the other variables. The candidate's fiber integrand is log-concave in four real variables and has bounded convex support in its indicator factor, so this application is valid. The strict derivative used later is proved separately, not attributed to an unspecified strict form of Anderson's inequality.
   https://rutcor.rutgers.edu/Prekopa/pdf/SCIENT2.pdf

2. NIST DLMF 10.6.6 and 10.17.3. The derivative identities and fixed-order positive-real-argument asymptotic support the stated Bessel differentiation and O(x^(-1/2)) bound. No optimization statement is drawn from these sources.
   https://dlmf.nist.gov/10.6.E6
   https://dlmf.nist.gov/10.17.E3

3. Glover, Tkocz and Wyczesany, Stability of polydisc slicing (2023), Section 3.2, equation (7), printed page 1169. I confirmed its unweighted section formula has prefactor 1/2 and factors 2J_1(a_j t)/(a_j t). It is only a comparison formula here. The weighted Gaussian formula is independently derived in the candidate, not borrowed as an optimizer theorem.
   https://eprints.whiterose.ac.uk/221836/1/Mathematika%20-%202023%20-%20Glover%20-%20Stability%20of%20polydisc%20slicing.pdf

No historical-priority claim is verified or made.

## 3. Fourier normalization and C² regularity: PASS

For S=sum q_i, the linear map z->sum sqrt(q_i)z_i from C^3 to C has two real singular values sqrt(S), hence real coarea Jacobian S. Pushing forward the product of three normalized Gaussian densities truncated to their disks therefore has density H_a(q)/pi at zero, where H_a(q)=S^(-1)F_a(q/S).

The two-dimensional inverse Fourier factor, radial integration, and this extra pi give exactly

    H_a(q)=(1/2) integral_0^infinity t product_i phi_a(q_i,t) dt.

I checked the q-derivative formula by the Bessel differential identity. One integration by parts in the radial variable gives the uniform compact-q bound partial_q^m phi=O(t^(m-3/2)) for m=0,1,2. The lower radial endpoint contributes zero. Products of total derivative order m have decay O(t^(m-7/2)) after including the radial t factor. At m=2 this is t^(-3/2), still integrable. Near t=0 the defining bounded-range integral supplies domination.

Thus the claimed first and second derivatives are ordinary absolutely convergent integrals, and continuity holds at all positive q, including the triangle-tangency locus. No unproved third derivative is needed. Homogeneity gives sum q_i H_i=-H; on sum q_i=1, a stationary point has all H_i=-F. The tangent Hessian condition is the usual necessary, not sufficient, maximum condition.

## 4. Nonoscillatory stationary equations: PASS

I independently derived the same joint Laplace denominator before reading the candidate's new Section 3:

    D_q(s)=sum_i q_i(1+s_j)(1+s_k).

The one-copy squared-modulus Laplace transform is D_q(s)^(-1), and the two-copy transform is D_q(s)^(-2). I also independently obtained the two-copy density

    rho_2(q,x)=exp(-sum x_i) sqrt(Delta_q(x))_+/(2pi q_1q_2q_3).

The normalization can be checked without quoting a multivariate-Wishart convention: the 2-by-2 Hermitian Gram matrix W has density pi^(-1)exp(-tr W) on W>0. For a real orthonormal frame of u-perp, the three x_i depend only on the two diagonal entries and Re W_12. That three-dimensional Jacobian has magnitude 2sqrt(q_1q_2q_3), and Delta=4q_1q_2q_3(det Re W). Integration over Im W_12 supplies exactly the square-root density above. The candidate's conditional Gaussian derivation of the Gram density is also correct.

Differentiating the Laplace denominator along q_i-q_j gives the multiplier (s_i-s_j)(1+s_k)/D². Inverting it against the integrated two-copy CDF yields

    (H_i-H_j)=(A_i-B_i)-(A_j-B_j).

I checked the sign and the opposite-edge indexing. Initial-threshold terms vanish because the integrated CDF and the required tangential face derivatives vanish when a remaining threshold is zero. The candidate appropriately starts with a distributional inversion and then uses continuous representatives at positive thresholds. The finite face and edge integrals are continuous because rho_2 is continuous, including Delta=0.

The stated edge support follows from the two roots a(sqrt(q_j)±sqrt(q_k))²/q_i. In the strict-triangle region the lower root is below a and the upper root above a. These formulas make stationarity computable in principle, but positivity of A_i and B_i gives no sign for their difference.

## 5. Strict-triangle exclusion, including tangency: PASS

If sqrt(q_1)>=sqrt(q_2)+sqrt(q_3), the first disk constraint is redundant by the complex triangle inequality. Along q(t)=(t,(1-t)c,(1-t)(1-c)), the covariance of the remaining coordinates has eigenvalues t and 1 with fixed eigenvectors.

The candidate integrates the variance-one component first. Its fiber mass g is log-concave by the verified marginal theorem and invariant under complex rotations, so g is radial and nonincreasing in radius. It is positive near zero and compactly supported. Consequently h(x)=g(sqrt(x)) is nonincreasing and genuinely nonconstant.

Differentiation of the remaining exponential integral gives P_c'(t)=Cov(h(X),X)/t², X exponential of mean t. The independent-copy covariance identity makes the sign strictly negative, since an initial positive interval and a terminal zero interval both have positive exponential probability. This closes an important gap that mere strict monotonicity would not close: a strictly monotone differentiable function can have a zero derivative at a specific point.

At the tangent normal, increasing t enters the redundant region. The full function is C¹ there by Section 2, so its derivative agrees with the strictly negative one-sided derivative. Decreasing t therefore raises F, even though the first disk becomes active. This excludes equality, not just the open nontriangle region.

Heron's product is 4e_2-1 under sum q_i=1. The resulting e_2>1/4 condition and the elementary bound e_2<=(1+2q_i-3q_i²)/4 correctly imply q_i<2/3. These are necessary conditions for interior local maxima, not a full optimizer classification.

## 6. Boundary and all-distinct invariant gate: PASS WITH OPEN MAIN GATE

On q=(t,1-t,0), one independent complex Gaussian contributes the third coordinate and another contributes the first two with squared magnitudes 1-t and t. The resulting formula

    F=(1-exp(-a))(1-exp(-a/max(t,1-t)))

is exact and uniquely maximized at t=1/2 for finite a>0.

On an all-distinct chamber the (e_2,e_3) Jacobian equals the stated nonzero Vandermonde product. The first-variation formula implies that all-distinct stationarity is equivalent to Psi_e2=Psi_e3=0. At such a point the constrained Hessian and invariant Hessian are congruent, with no extra first-derivative term. Neither condition excludes a maximum on its own. The explicit symmetric-polynomial counterexample in the candidate correctly shows why symmetry alone is inadequate; it is not presented as a Gaussian counterexample.

The finite-integral function g_a(t;e) and its stated t interval are correct. An at-most-two-horizontal-intersections theorem would be sufficient, but is not supplied. I therefore leave the requested all-radius two-equal structural gate OPEN, rather than relabeling a necessary stationarity equation as a solution.

## 7. Independent rejected-shortcut diagnostic

During the review I tested a stronger conditional-lens comparison suggested by a possible pair-smoothing proof. That lemma is false, and I converted the initial exploratory indication into an exact analytic counterexample. See LENS_COUNTEREXAMPLE.md.

For r=1/100, b=r/2 and t=1/4, the proper-complex Gaussian mass of

    {|sqrt(1-t)Y-sqrt(t)b|<=r,
     |sqrt(t)Y+sqrt(1-t)b|<=r}

has strictly negative derivative with respect to t at fixed b,r, despite b<=r sqrt(t). The proved rational upper bound is -23/703125. The proof author independently checked the diagnostic and did not include the false lemma in the candidate.

This invalidates only pointwise conditional smoothing. Averaging over the first truncated Gaussian variable can change the derivative sign. No counterexample to the original two-equal assertion or full optimizer has been produced.

## 8. Controls and final disposition

The fresh independent_checks.py verifies invariant and Laplace algebra, Gram Jacobians and Delta identities on two exact frames, and the exact lens derivative and rational negative bound. Its INDEPENDENT_CHECKS.json reports every exact check passing. These finite controls supplement the analytic review; they do not prove an exhaustive classification.

I performed exploratory non-certified quadrature and root searches while looking for a counterexample. Their scripts are segregated under exploratory/ and are not proof artifacts. In particular an unrestricted floating optimization can miss the boundary block even when it has a larger known exact value. No absence-of-counterexample claim is promoted to exhaustiveness, and no exploratory floating value is used in the accepted theorem or the exact diagnostic.

Candidate integrity was checked against its frozen manifest. No external mutation was performed. Final disposition: accept the narrower finite-radius variational and strict-triangle results; reject any broader reading as the requested all-radius two-equal theorem. ALG-036 remains open at that structural gate.
