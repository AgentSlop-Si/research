# Contract and dependency boundaries

## Original measure

For q in the closed simplex Δ₂, put u_j=√q_j and P=I−uu*. The random vector Z is the proper complex rank-two Gaussian CN(0,P) on the complex plane u⊥ in C³. Its density with respect to intrinsic four-real-dimensional Euclidean volume is π⁻² exp(−‖z‖²). For every finite a>0,

    F_a(q)=Pr(max_j |Z_j|≤√a).

The normalization, proper-complex convention, dimension, centered event, and finite-positive-radius domain are essential. No real Gaussian cube theorem is substituted. The preceding centering theorem is background for the original larger optimization problem; this packet proves a theorem about the explicitly centered objective above and does not reprove or extend centering.

## What is needed here

- The new elementary smoothing proof is candidate/PROOF.md, Sections 2–5. Its limiting argument proves the regularity it uses directly.
- The finite face-minus-edge interpretation in Section 6 uses the exact derivative identity from dependencies/stationary/REPORT.md, Sections 2–3. The complete argument and its prior independent review are included.
- Global boundary coverage uses the exact boundary formula and proof in the stationary report, Section 5. The global maximum exists by continuity on the compact simplex. The separate endpoint q₁=0 is not treated by the interior graph parametrization.
- The earlier stationary report contains additional C², strict-triangle, invariant, and root-count results. Its old statements that the two-equal gate was open are historical, superseded by the current theorem, not current release claims.
- Earlier small-radius optimality, effective bounds, centering, and large-radius localization are preserved background, not re-audited or used as substitutes for this proof. Those earlier packets are not included and are not required to check this centered structural theorem.

## External technical sources in the stationary dependency

The stationary report itself specifies the exact roles and equations: Prékopa's marginal log-concavity theorem is used only for its additional strict-triangle result; NIST DLMF 10.6.6 and 10.17.3 supply special-function identities for its Fourier regularity proof; Glover–Tkocz–Wyczesany supplies an unweighted comparison formula, not a Gaussian optimizer theorem. Their public source links are retained in that report. No external optimizer theorem or historical-priority assertion is required by the new smoothing argument.

## Rejected shortcut retained

The exact lens counterexample in dependencies/stationary/LENS_COUNTEREXAMPLE.md rejects pointwise conditional-lens smoothing only. It is not a counterexample to integrated largest-pair smoothing. Its rational negative bound and symbolic controls are included to prevent reuse of that invalid shortcut.
