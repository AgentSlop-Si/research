"""Exact algebra controls for the independently reviewed boundary-rotation proof.
No numerical optimization or numerical sign checks are used here.
"""
import json
from pathlib import Path
import sympy as S
c,s,t,p,a,rho,u=S.symbols('c s t p a rho u', positive=True)
# Plane parametrization z1=-sqrt(s/c)*(sqrt(t)*x+sqrt(p)*y).
v=S.Matrix([S.sqrt(t),S.sqrt(p)])
M=S.eye(2)+(s/c)*(v*v.T)
checks={}
checks['complex_gram_determinant'] = S.simplify(M.det().subs(p,1-t).subs(s,1-c)-1/c)==0
th=S.symbols('theta', real=True)
x1,x2,y1,y2=S.symbols('x1 x2 y1 y2', real=True)
V=(S.sin(th)*x1+S.cos(th)*y1)**2+(S.sin(th)*x2+S.cos(th)*y2)**2
def G(f):return y1*S.diff(f,x1)+y2*S.diff(f,x2)-x1*S.diff(f,y1)-x2*S.diff(f,y2)
checks['theta_generator_identity']=S.simplify(S.diff(V,th)+G(V))==0
norm=x1*x1+x2*x2+y1*y1+y2*y2
checks['gaussian_rotation_invariance']=S.expand(G(norm))==0
field=[y1,y2,-x1,-x2]
checks['generator_divergence_zero']=sum(S.diff(f,z) for f,z in zip(field,[x1,x2,y1,y2]))==0
A=t*a+p*rho**2
B=p*a+t*rho**2
K=2*S.sqrt(t*p*a)*rho
checks['ordered_arguments']=S.expand(B-A-(p-t)*(a-rho**2))==0
rho0=S.sqrt(a*t/p)
checks['strict_patch_first_argument_zero']=S.simplify((A-K).subs(rho,rho0))==0
checks['strict_patch_second_argument']=S.simplify((B-K).subs(rho,rho0)-a*(p-t)**2/p)==0
# Normal-dot factor at the strict patch (phi=pi): -rho0 < 0.
checks['strict_patch_inside_face']=S.simplify(a-rho0**2-a*(p-t)/p)==0
res={'all_pass':all(checks.values()),'checks':checks,'scope':'Exact symbolic identities only. Positivity and cutoff passage are analytic arguments in REVIEW.md.'}
out=Path(__file__).with_name('INDEPENDENT_CHECKS.json')
out.write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
assert all(checks.values())
