# ALG-036: fresh adversarial review of strict largest-pair smoothing

Date: 20 October 2026 UTC. Verdict: **ACCEPT the structural theorem at the exact frozen bytes identified below.**

This is a fresh audit by a reviewer who did not take part in the author's pre-freeze technical exchange or the contemporaneous collaborative confirmation. I read the candidate, reconstructed its probability and shape derivative directly, attacked its exceptional and limiting cases, and wrote separate algebraic controls. No candidate file was edited. No external mutation or publication was performed.

## 1. Frozen object and precise disposition

Reviewed candidate: `candidate/PROOF.md` in the `alg036_twoequal_gate_20261020` packet.

- Proof SHA-256: `c992118d24465076fae1e708725dfd77c82ac5d654c904f976bb7299531692a1`.
- Candidate `MANIFEST.json` SHA-256: `eee4a1c75e357d112bbd30f2db32aae7e234fc642e3dcac0614bf0d605ab76ce`.
- All six manifest file entries and all five source-binding entries matched their recorded bytes and hashes during this review.

For the proper-complex rank-two Gaussian in C^3,

    Z ~ CN(0, I-uu*), u_i=sqrt(q_i), sum q_i=1,
    F_a(q)=Pr(max_i |Z_i| <= sqrt(a)), 0<a<infinity,

I accept all of the following:

1. If 0<q_1<=q_2<q_3, fixing q_1 and moving q_2,q_3 strictly toward equality strictly increases F_a. The path derivative is strictly positive at every unequal point, including an initial q_1=q_2.
2. There are no all-distinct interior stationary points. Every interior local or global maximizer has its two largest normal weights equal.
3. With the accepted boundary result, the global maximum reduces exactly, up to permutations, to q=(c,(1-c)/2,(1-c)/2), 0<=c<=1/3.
4. The proof determines the sign of the actual accepted finite face-minus-edge difference, rather than the signs of its two terms separately.

No mathematical correction to the frozen proof is required. This acceptance does not identify the maximizing c, classify all stationary points on that branch, prove a unique radius transition, solve the full all-radius optimizer, or resolve the broader ALG-036 optimizer problem. There is no historical-priority judgment. The previously false pointwise conditional-lens lemma remains false.

## 2. Independent reconstruction of the Gaussian contract

Let alpha=sqrt(q_2/c), beta=sqrt(q_3/c), c=q_1>0. The graph map from C^2 into the plane is

    B(w,z)=(-alpha w-beta z,w,z).

Its complex metric is G=B*B and det G=1+alpha^2+beta^2=1/c. The corresponding real four-dimensional Gram determinant is (det G)^2, so the real volume Jacobian is det G=1/c, not 1/sqrt(c) or 1/c^2.

There is also a direct covariance check independent of a density convention: the graph-coordinate density det(G) pi^(-2) exp(-v*Gv) has covariance G^(-1), and

    B G^(-1) B* = I-uu*.

Thus the candidate's graph integral is the actual proper-complex Gaussian probability, not a real-Gaussian surrogate or a different normalization.

Writing q_2=s t, q_3=s p, s=1-c, p=1-t, and r=sqrt(a), the third disk condition is

    |sqrt(t) w+sqrt(p) z|^2 <= a c/s = R^2.

The Gaussian exponent splits as |w|^2+|z|^2+(s/c)|sqrt(t)w+sqrt(p)z|^2. Therefore F=J/(pi^2 c) with exactly the candidate's J and h. No theta-dependent Jacobian or weight has been omitted: c,s,kappa=s/c,R remain fixed along the path.

The hypothesis that c is the smallest normal weight is exactly what is needed:

    c<=q_2=s t  implies  R^2=a c/s<=a t.

It is an assumption on normal weights, not on coordinate variances.

## 3. Independent boundary derivative and sign

For smooth h_epsilon, use V=(z,-w) in four real coordinates. Its divergence vanishes, and it annihilates |w|^2+|z|^2. For b=sin(theta)w+cos(theta)z,

    V b = sin(theta)z-cos(theta)w = -partial_theta b.

Hence the derivative is minus the flux. The w-face has outward flux (w dot z)/r; the z-face has its negative. Exchanging w,z in the latter produces the subtraction, not an addition, of the two h-values. The product of disks is a bounded Lipschitz domain; its circle-circle corner has zero three-dimensional boundary measure. Thus its corner does not produce a missing term.

After rotating w to r, the identity can equivalently be written in Cartesian complex notation as

    J'(theta) = -2pi r integral_{|z|<=r} exp(-a-|z|^2) Re(z)
      [h(|sqrt(t)r+sqrt(p)z|^2)-h(|sqrt(p)r+sqrt(t)z|^2)] dz,

once the limiting argument below is justified. Converting z=rho exp(i phi) yields the candidate's prefactor -2pi r and rho^2 cos(phi). The face measure and both radial factors are correct.

For rho<=r, the second squared argument minus the first is

    (p-t)(a-rho^2)>=0.

The h-bracket is consequently nonnegative. If cos(phi)<=0, this has the desired sign after the leading minus sign. If cos(phi)>0, the first argument is at least t a, hence at least R^2, and the bracket vanishes for the supported smooth approximants. For the discontinuous limiting h, any threshold equality is a null set. There is no discarded positive-cosine contribution.

This pointwise sign is for the boundary integrand of the **full integrated probability**. It is not a sign assertion about a lens at a fixed value of the conditioning coordinate. The accepted conditional-lens counterexample is therefore not an obstruction to this proof.

## 4. Independent quantitative strict patch

The frozen proof's strictness argument is valid as written. As an additional adversarial control, I obtained the following explicit lower bound without relying on the wording of its continuity neighborhood.

For 0<t<p, define

    rho_0 = r sqrt(t/p),
    D = a(p-t)^2/p,
    delta = min{rho_0/2, (r-rho_0)/2, R/(2sqrt(p)),
                sqrt(D)/(4sqrt(p)), sqrt(D)/(4sqrt(t))}.

All five entries are strictly positive for every parameter in the theorem. In the Cartesian disk

    z=-rho_0+eta,  |eta|<delta,

the point remains inside |z|<r, and Re(z)<-rho_0/2. Its two boundary arguments X,Y obey

    X=p|eta|^2 <= min(R^2/4,D/16),
    Y=|sqrt(D)+sqrt(t)eta|^2 >= 9D/16.

Thus, writing kappa=s/c,

    h(X)-h(Y) >= exp(-kappa D/16)-exp(-9kappa D/16) =: g > 0.

This holds whether Y is inside, outside, or crossing the hard cutoff. For the approximants the same lower bound holds once epsilon<=3R^2/4. The Gaussian boundary weight is at least exp(-2a). The disk has area pi delta^2. Since the remaining boundary integrand is nonnegative, this gives

    J'(theta) >= pi^2 r rho_0 delta^2 exp(-2a) g > 0,

and therefore the actual probability satisfies

    dF_a(c,s t,s p)/dt
      >= [a delta^2/(2c p)] exp(-2a)
          [exp(-kappa D/16)-exp(-9kappa D/16)] > 0.

This is a positive bound at each finite admissible parameter, not a uniform lower bound as a approaches 0 or infinity, c approaches 0, or t approaches 1/2. None is needed. It independently verifies the candidate's strictness in all of those near-degenerate regimes, and at R^2=a t. The finite-positive-a and unequal-pair hypotheses are essential to this positivity argument.

## 5. Indicator approximation, differentiability, and endpoints

The candidate's h_epsilon is smooth on [0,infinity), nonnegative, nonincreasing, bounded by 1 there, and zero for v>=R^2. It has a smooth extension to a neighborhood of the relevant nonnegative arguments, so composition at b=0 presents no differentiability problem. Its derivative need not be uniformly bounded in epsilon; the proof never needs that.

For the volume integral, a nonzero complex linear map sends the threshold condition to a circle. Its inverse image has zero four-dimensional Lebesgue measure. The discrepancy at the cutoff therefore does not affect convergence of J_epsilon to J.

On a boundary face, for every rho>0 and theta in (0,pi/4), the coefficient K=2sqrt(tp)r rho is positive. Each threshold equation fixes at most two angular values. Fubini gives a null two-dimensional threshold set; rho=0 is also null. Consequently the boundary right-hand sides converge under a common, integrable finite-domain bound.

For theta approaching any fixed interior theta_0, the limiting h-values converge outside exactly those threshold sets at theta_0. Dominated convergence gives continuity of the limiting boundary expression Q(theta). It is not necessary to obtain uniform convergence of h_epsilon or to differentiate the hard indicator.

The common boundary bound also permits integration over any compact theta interval. Passing the smooth fundamental theorem of calculus to the limit yields

    J(beta)-J(alpha)=integral_alpha^beta Q(theta) dtheta.

As Q is continuous, J is differentiable and J'=Q. This justifies the derivative used in strictness, rather than merely proving weak monotonicity or an almost-everywhere statement.

The equality q_1=q_2 occurs at t=c/(1-c)>0. Provided q_2<q_3, this is still an interior theta in (0,pi/4), so differentiability has already been proved in a full neighborhood. The sign condition holds at equality and for the entire forward smoothing path. No endpoint-only derivative substitution is being made.

At theta=pi/4 the volume-level argument gives continuity, while strict positivity holds at every preceding unequal point. Comparing with an intermediate point and then taking the limit proves a strict comparison with the equal-pair endpoint. A positive derivative at the equal-pair endpoint itself is neither true nor claimed.

## 6. Stationary and global consequences

Since dt/dtheta=2sqrt(tp),

    dF/dt = J'(theta)/(2pi^2 c sqrt(tp)).

The accepted homogeneous extension has H_2-H_3 equal to the actual opposite face-minus-edge difference. Along q(t), dF/dt=s(H_2-H_3). The resulting denominator 2pi^2 c s sqrt(tp) in the frozen proof is correct and positive. The strict sign rules out stationarity, as well as local maximality, whenever the two largest coordinates differ.

No inference from mere permutation symmetry or from a numerical stationary-point census is needed. Symmetry is used only to reorder the coordinates and express the surviving branch.

For completeness, I independently checked that the global boundary dependency is compatible with the claimed reduction. At q=(0,t,1-t), two independent standard complex Gaussians give

    F_a=(1-exp(-a))(1-exp(-a/max(t,1-t))).

For finite a>0 this is uniquely maximized at t=1/2, up to permutations. That boundary maximizer is exactly the c=0 endpoint of the surviving branch.

Continuity on the closed simplex also follows directly by coupling Z(q)=(I-u(q)u(q)*)G with one standard complex Gaussian G in C^3. The event boundary has probability zero for a>0, including at vertices: each nondegenerate coordinate has a continuous law, and a degenerate coordinate is identically zero, not sqrt(a). Dominated convergence and compactness give attainment. Interior maximizers are on the stated branch; every boundary value is no larger than its c=0 endpoint. This proves the exact global reduction.

## 7. Counterexample attacks and preserved limitations

The attacks checked here were analytical, not an optimizer grid:

- A wrong square root in the complex-to-real Jacobian: excluded by the full real Gram determinant and projector covariance checks.
- A reversed rotation generator or missing second-face sign: excluded by independent flux derivation.
- A positive-cosine contribution at the cutoff-equality start: excluded by support and null-set arguments, including q_1=q_2.
- A strict patch collapsing for a small positive radius, small c, or almost equal pair: excluded by the explicit strictly positive delta above at every admissible point.
- A jump in the second h-value within the strict patch: harmless because the upper bound h(Y)<=exp(-kappa Y) works on both sides of the jump.
- Differentiating an indicator or silently exchanging nonuniform derivatives: avoided by the supported approximants, bounded flux identity, dominated convergence, and FTC.
- Reusing the disproved conditional-lens lemma: absent. Its counterexample is retained unchanged and concerns a different, stronger assertion.
- Extending strictness to a=0, a=infinity, or the already equal pair: not asserted. These limiting cases can have vanishing derivatives.
- Treating the graph formula as valid at c=0: not done; the boundary is handled separately.
- Claiming that arbitrary pairs smooth monotonically: not justified or asserted. The support inequality depends on fixing the smallest normal weight.

No counterexample or analytic defect was found in the frozen structural theorem. The controls supplement this proof audit; they are not themselves an exhaustive optimizer certificate. The complete one-parameter optimization remains unresolved by this packet.

## 8. Separate controls and integrity

The original `independent_controls.py` and `INDEPENDENT_CONTROLS.json` contain 44 exact algebraic or byte-integrity checks. For portable replay, PORTABLE_CONTROLS.md separates the 31 unchanged algebra checks from 13 historical source-integrity checks. They include the full real Gram determinant, graph covariance, generator and Gaussian invariance, both boundary arguments and their order, the smallest-weight cutoff equivalence, Cartesian strict-patch identities, derivative constants, and the exact boundary derivative. All passed. No floating quadrature, finite sampling, or approximate root finding enters this acceptance.

The candidate and its sources were read without modification. This fresh review is distinct from the earlier collaborative verification disclosed in the candidate's `COLLABORATION.md`. The frozen candidate's wording remains “awaiting independent review”; the acceptance record is this separate, source-bound verdict, not an unreported edit to that wording.
