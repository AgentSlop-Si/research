#!/usr/bin/env python3
"""Portable integrity, scoped-status, exact replay, and negative controls.
Hashes establish integrity relative to a trusted manifest, not analytic validity.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent
PROOF_SOURCE='c992118d24465076fae1e708725dfd77c82ac5d654c904f976bb7299531692a1'
SOURCE_MANIFEST='eee4a1c75e357d112bbd30f2db32aae7e234fc642e3dcac0614bf0d605ab76ce'
COLLAB_SOURCE='3f9ae2f45ee7bc0ea97e361ab22ada205029eebe03c2242cf3bfb6817c37167d'
SCOPE='proper_complex_finite_positive_radius_global_two_largest_equal_reduction'
NOT_PROVED=['maximizing_c_for_every_a','transition_radius_classification','complete_all_radius_optimizer','off_shell_horizontal_root_count']
def sha(b):return hashlib.sha256(b).hexdigest()
def fail(msg):raise ValueError(msg)
def read_json(p):return json.loads(p.read_text())
def reseal(root):
 m=read_json(root/'MANIFEST.json')
 for x in m['files']:
  p=root/x['path'];x.update(sha256=sha(p.read_bytes()),bytes=p.stat().st_size)
 (root/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
 (root/'MANIFEST.sha256').write_text(sha((root/'MANIFEST.json').read_bytes())+'  MANIFEST.json\n')
def verify(root,expected_manifest=None,replay=False,require_accepted=False):
 root=root.resolve();manifest=root/'MANIFEST.json'
 actual_sha=sha(manifest.read_bytes())
 if expected_manifest and actual_sha!=expected_manifest:fail('Manifest differs from externally trusted digest.')
 seal=(root/'MANIFEST.sha256').read_text().split()
 if len(seal)!=2 or seal[1]!='MANIFEST.json' or seal[0]!=actual_sha:fail('Manifest seal mismatch.')
 m=read_json(manifest)
 if m.get('schema')!='gaussian-structure-portable-v1':fail('Unexpected manifest schema.')
 names=[]
 for x in m['files']:
  rel=PurePosixPath(x['path'])
  if rel.is_absolute() or '..' in rel.parts or str(rel)!=x['path']:fail('Unsafe manifest member.')
  if x['path'] in names:fail('Duplicate manifest member.')
  names.append(x['path']);p=root/x['path']
  if p.is_symlink() or not p.is_file():fail('Missing or symbolic-link member: '+x['path'])
  if root not in p.resolve().parents:fail('Member escapes package.')
  b=p.read_bytes()
  if len(b)!=x['bytes'] or sha(b)!=x['sha256']:fail('Member digest mismatch: '+x['path'])
 actual=[]
 for p in root.rglob('*'):
  if p.is_symlink():fail('Symbolic links are not package members.')
  if p.is_file():actual.append(p.relative_to(root).as_posix())
 if set(actual)!=set(names)|{'MANIFEST.json','MANIFEST.sha256'}:fail('Unlisted or missing package member.')
 rel=read_json(root/'RELEASE.json')
 if rel.get('scope')!=SCOPE or rel.get('not_proved')!=NOT_PROVED:fail('Scope drift or overclaim.')
 if rel.get('candidate_source_sha256')!=PROOF_SOURCE or rel.get('candidate_manifest_source_sha256')!=SOURCE_MANIFEST:fail('Candidate identity mismatch.')
 if rel.get('finite_positive_a_only') is not True or rel.get('proper_complex_only') is not True:fail('Measure/radius contract drift.')
 if rel.get('full_optimizer_closed') is not False:fail('Full optimizer overclaim.')
 if rel.get('status') not in ('PENDING_FRESH_ADVERSARIAL_REVIEW','ACCEPTED_SCOPED_THEOREM'):fail('Unexpected release status.')
 if require_accepted and rel['status']!='ACCEPTED_SCOPED_THEOREM':fail('Fresh acceptance is still pending.')
 coll=read_json(root/'reviews/collaborative/VERDICT.json')
 if coll.get('review_source_sha256')!=COLLAB_SOURCE or coll.get('candidate_source_sha256')!=PROOF_SOURCE:fail('Collaborative binding mismatch.')
 if coll.get('collaboration_disclosed') is not True or coll.get('fresh_adversarial_acceptance_separate') is not True:fail('Collaborative attribution missing.')
 if rel['status']=='ACCEPTED_SCOPED_THEOREM':
  fresh=read_json(root/'reviews/fresh/VERDICT.json')
  if fresh.get('verdict')!='PASS' or fresh.get('candidate_source_sha256')!=PROOF_SOURCE or fresh.get('candidate_manifest_source_sha256')!=SOURCE_MANIFEST:fail('Fresh verdict does not accept exact source.')
  if fresh.get('review_kind')!='fresh_adversarial_audit':fail('Fresh independence label missing.')
  if fresh.get('review_source_sha256')!=rel.get('fresh_review_source_sha256'):fail('Fresh review identity mismatch.')
  if not (root/'reviews/fresh/REVIEW.md').is_file():fail('Missing fresh analytic review.')
 proj=read_json(root/'provenance/PROJECTIONS.json')
 if proj.get('mathematics_unchanged') is not True:fail('Unacknowledged mathematical alteration.')
 for x in proj['records']:
  p=root/x['public_path']
  if sha(p.read_bytes())!=x['public_sha256'] or p.stat().st_size!=x['public_bytes']:fail('Projection binding mismatch: '+x['public_path'])
 if next(x for x in proj['records'] if x['public_path']=='candidate/PROOF.md')['source_sha256']!=PROOF_SOURCE:fail('Proof projection source mismatch.')
 if read_json(root/'provenance/SOURCE_PRESERVATION.json').get('all_unchanged') is not True:fail('Source preservation not confirmed.')
 # Literal path/control markers are encoded to avoid inserting private markers in this public script.
 forbidden=[bytes.fromhex(h) for h in ('2f776f726b73706163652f','2f686f6d652f6167656e742f','2f726f6f742f','636f6c6c61626f726174696f6e2e73656e645f6d657373616765','636c6f75645f746872656164732e','636f6465783a2f2f746872656164732f')]
 for name in names:
  b=(root/name).read_bytes()
  if any(marker in b for marker in forbidden):fail('Private path or coordination marker in '+name)
 runs=[]
 if replay:
  controls=[('controls/author','exact_controls.py','EXACT_CONTROLS.json',13),('reviews/collaborative','independent_checks.py','INDEPENDENT_CHECKS.json',8),('dependencies/stationary','independent_checks.py','INDEPENDENT_CHECKS.json',None)]
  if (root/'reviews/fresh/REPLAY.json').is_file():
   for item in read_json(root/'reviews/fresh/REPLAY.json')['controls']:
    controls.append((item['directory'],item['script'],item['output'],item.get('expected_checks')))
  for directory,script,output,count in controls:
   with tempfile.TemporaryDirectory(prefix='gaussian-control-') as td:
    work=Path(td);shutil.copy2(root/directory/script,work/script)
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    proc=subprocess.run([sys.executable,script],cwd=work,env=env,text=True,capture_output=True)
    if proc.returncode:fail('Control failed: '+directory+'/'+script+'\n'+proc.stderr)
    if (work/output).read_bytes()!=(root/directory/output).read_bytes():fail('Exact replay differs: '+directory+'/'+output)
    data=read_json(work/output)
    if count is not None and len(data.get('checks',{}))!=count:fail('Unexpected control count.')
    runs.append({'script':directory+'/'+script,'exact_output_match':True,'check_count':count})
 return {'all_pass':True,'manifest_sha256':actual_sha,'members':len(names),'release_status':rel['status'],'scoped_theorem_only':True,'replays':runs}
def negative_controls(root):
 results=[]
 def run(name,mutate,refresh=False,expected=None):
  with tempfile.TemporaryDirectory(prefix='gaussian-negative-') as td:
   copy=Path(td)/'packet';shutil.copytree(root,copy)
   mutate(copy)
   if refresh:reseal(copy)
   try:verify(copy,expected_manifest=expected)
   except (ValueError,KeyError,FileNotFoundError,json.JSONDecodeError) as e:results.append({'name':name,'rejected':True,'reason':str(e)})
   else:fail('Negative control was accepted: '+name)
 run('altered_proof_byte',lambda p:(p/'candidate/PROOF.md').write_bytes((p/'candidate/PROOF.md').read_bytes()+b'\n'))
 run('missing_proof',lambda p:(p/'candidate/PROOF.md').unlink())
 run('extra_unsealed_member',lambda p:(p/'unexpected.txt').write_text('extra'))
 def overclaim(p):
  j=read_json(p/'RELEASE.json');j['full_optimizer_closed']=True;(p/'RELEASE.json').write_text(json.dumps(j))
 run('resealed_optimizer_overclaim',overclaim,True)
 def wrong_source(p):
  j=read_json(p/'RELEASE.json');j['candidate_source_sha256']='0'*64;(p/'RELEASE.json').write_text(json.dumps(j))
 run('resealed_wrong_source_identity',wrong_source,True)
 run('externally_pinned_manifest_mismatch',lambda p:None,expected='0'*64)
 def wrong_projection(p):
  f=p/'candidate/PROOF.md';f.write_bytes(f.read_bytes()+b'\n')
 run('resealed_projection_mismatch',wrong_projection,True)
 def wrong_fresh(p):
  path=p/'reviews/fresh/VERDICT.json'
  if path.exists():
   j=read_json(path);j['candidate_source_sha256']='0'*64;path.write_text(json.dumps(j))
  else:
   j=read_json(p/'RELEASE.json');j['status']='ACCEPTED_SCOPED_THEOREM';(p/'RELEASE.json').write_text(json.dumps(j))
 run('resealed_missing_or_wrong_fresh_acceptance',wrong_fresh,True)
 return results
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--replay',action='store_true');ap.add_argument('--negative-controls',action='store_true');ap.add_argument('--require-accepted',action='store_true');ap.add_argument('--expected-manifest-sha256');args=ap.parse_args()
 try:
  result=verify(ROOT,args.expected_manifest_sha256,args.replay,args.require_accepted)
  if args.negative_controls:result['negative_controls']=negative_controls(ROOT)
  print(json.dumps(result,indent=2))
 except Exception as e:
  print(json.dumps({'all_pass':False,'error':str(e)},indent=2));sys.exit(1)
