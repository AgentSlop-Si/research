#!/usr/bin/env python3
"""Exact algebraic controls. The analytic proof is candidate/PROOF.md."""
import json
from pathlib import Path
import sympy as S
checks={}
def check(name, expr):
    val=S.simplify(expr)
    checks[name]={'pass':val==0,'residual':str(val)}
c,s,q2,q3,a,r,rho,t,p,k,theta=S.symbols('c s q2 q3 a r rho t p k theta', positive=True, real=True)
v=S.Matrix([S.sqrt(q2/c),S.sqrt(q3/c)])
check('complex_Gram_determinant',((S.eye(2)+v*v.T).det()-1/c).subs(q3,1-c-q2))
x1,x2,y1,y2=S.symbols('x1 x2 y1 y2',real=True)
x=S.Matrix([x1,x2]);y=S.Matrix([y1,y2]);coords=[x1,x2,y1,y2];V=[y1,y2,-x1,-x2]
def G(f):return sum(V[i]*S.diff(f,coords[i]) for i in range(4))
check('generator_divergence',sum(S.diff(V[i],coords[i]) for i in range(4)))
check('generator_norm_invariance',G((x.T*x)[0]+(y.T*y)[0]))
b=S.sin(theta)*x+S.cos(theta)*y
for i in range(2):check('generator_rotation_sign_'+str(i),G(b[i])+S.diff(b[i],theta))
check('squared_norm_rotation_sign',G((b.T*b)[0])+S.diff((b.T*b)[0],theta))
phi=S.symbols('phi',real=True)
w=S.Matrix([r,0]);z=S.Matrix([rho*S.cos(phi),rho*S.sin(phi)])
A=t*a+p*rho**2;B=p*a+t*rho**2;K=2*S.sqrt(t*p)*r*rho
check('first_face_squared_norm',((S.sqrt(t)*w+S.sqrt(p)*z).dot(S.sqrt(t)*w+S.sqrt(p)*z)-(A+K*S.cos(phi))).subs(a,r**2))
check('swapped_face_squared_norm',((S.sqrt(p)*w+S.sqrt(t)*z).dot(S.sqrt(p)*w+S.sqrt(t)*z)-(B+K*S.cos(phi))).subs(a,r**2))
check('boundary_argument_order',(B-A)-(p-t)*(a-rho**2))
check('strict_point_first_argument',(A-K).subs({rho:r*S.sqrt(t/p),a:r**2}))
check('strict_point_second_argument',((B-K)-a*(p-t)**2/p).subs({rho:r*S.sqrt(t/p),a:r**2}))
check('theta_to_t_derivative',S.diff(S.sin(theta)**2,theta)-2*S.sin(theta)*S.cos(theta))
Jp=S.symbols('Jp',real=True)
dFdt=Jp/(S.pi**2*c)/(2*S.sqrt(t*p))
check('finite_face_difference_conversion',dFdt/s-Jp/(2*S.pi**2*c*s*S.sqrt(t*p)))
result={'arithmetic':'exact SymPy symbolic simplification; no floating optimizer evidence','all_pass':all(x['pass'] for x in checks.values()),'checks':checks}
out=Path(__file__).with_name('EXACT_CONTROLS.json');out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['all_pass']
