#!/usr/bin/env python3
"""Fresh symbolic checks. No floating computation supports acceptance."""
from pathlib import Path
import json, hashlib
import sympy as s

checks=[]
def check(name, expression, expected=0):
    residual=s.simplify(expression-expected)
    ok=residual==0
    checks.append({'name':name,'pass':bool(ok),'residual':str(residual)})
    if not ok:raise AssertionError((name,residual))

c=s.symbols('c',positive=True)
v=s.Matrix([[s.sqrt(1-c),0],[-s.sqrt(c/2),1/s.sqrt(2)],[-s.sqrt(c/2),-1/s.sqrt(2)]])
u=s.Matrix([s.sqrt(c),s.sqrt((1-c)/2),s.sqrt((1-c)/2)])
for i in range(2):
 for j in range(2):check(f'scalar_frame_orthonormal_{i}{j}',(v.T*v)[i,j],int(i==j))
# Square roots use 0<c<1 in these polynomial coordinate checks.
for i in range(3):
 for j in range(3):check(f'scalar_projector_{i}{j}',(v*v.T+u*u.T)[i,j],int(i==j))
vs=s.simplify(v.subs(c,s.Rational(1,3)))
rs=[s.Matrix([0,0,1]),s.Matrix([-s.sqrt(3)/2,0,-s.Rational(1,2)]),s.Matrix([s.sqrt(3)/2,0,-s.Rational(1,2)])]
for i in range(3):
 check(f'bloch_unit_vector_{i}',(rs[i].T*rs[i])[0],1)
 for j in range(i):check(f'bloch_pair_dot_{i}{j}',(rs[i].T*rs[j])[0],-s.Rational(1,2))
for j in range(3):check(f'bloch_vector_sum_{j}',sum(r[j] for r in rs))
x,y,z,w=s.symbols('x y z w',real=True)
X=x+s.I*y;Y=z+s.I*w
norm=x*x+y*y+z*z+w*w
nnum=s.Matrix([2*(x*z+y*w),2*(x*w-y*z),x*x+y*y-z*z-w*w])
check('bloch_sphere_norm',(nnum.T*nnum)[0],norm**2)
for i in range(3):
 zi=vs[i,0]*X+vs[i,1]*Y
 check(f'bloch_coordinate_identity_{i}',s.expand_complex(zi*s.conjugate(zi)),(norm+(rs[i].T*nnum)[0])/3)

t=s.symbols('t',positive=True)
k=s.symbols('k',positive=True)
check('middle_shell_formula',(3*(3/t-1)-1)/2,s.Rational(9,2)/t-2)
check('middle_shell_difference',t*(s.Rational(9,2)/t-2-1/t),s.Rational(7,2)-2*t)
check('shell_crossing',(s.Rational(7,2)-2*t).subs(t,s.Rational(7,4)))
check('symmetric_shell_continuity_3over2',(s.Rational(9,2)/t-2).subs(t,s.Rational(3,2)),1)
check('symmetric_shell_at_2',(s.Rational(9,2)/t-2).subs(t,2),s.Rational(1,4))
check('triangle_scaling_det',(2*k*s.eye(2)).det(),4*k*k)
check('triangle_shell_upper_bound',4*k*k*s.Rational(1,4),k*k)
check('block_volume',s.integrate(t,(t,0,1))+s.integrate(1,(t,1,2))+s.integrate(3-t,(t,2,3)),2)
r=s.symbols('r',nonnegative=True)
vol=s.integrate(2*s.pi*r*(2*s.acos(r/2)-r*s.sqrt(4-r*r)/2),(r,0,1))*3/s.pi**2
check('symmetric_section_volume',vol,3-9*s.sqrt(3)/(4*s.pi))
check('zero_radius_Q',vol-2,1-9*s.sqrt(3)/(4*s.pi))
check('negative_mass_crude_bound',s.integrate(t,(t,s.Rational(7,4),3)),s.Rational(95,32))
check('positive_interval_coefficient',(s.Rational(3,2)-s.Rational(5,4))*s.Rational(1,4),s.Rational(1,16))
psi=s.symbols('psi',real=True)
# Trigonometric substitution proof of the optional antiderivative.
check('optional_antiderivative',s.diff(s.atan(s.tan(psi)/k)-k*psi,psi),k*(1/(k*k+(1-k*k)*s.sin(psi)**2)-1))
aa=s.symbols('aa',positive=True)
front=lambda aa:s.integrate(s.exp(-aa*t)*(t-1),(t,1,s.Rational(3,2)))+s.integrate(s.exp(-aa*t)*(s.Rational(7,2)-2*t),(t,s.Rational(3,2),2))
tail=lambda aa:s.integrate(s.exp(-aa*t)*(3-t),(t,2,3))
check('half_radius_upper_bound',s.exp(s.Rational(3,2))*(front(s.Rational(1,2))-tail(s.Rational(1,2))/2),4*s.E-12*s.exp(s.Rational(3,4))+10*s.exp(s.Rational(1,2))-2)
xx=s.symbols('xx',real=True)
check('half_radius_polynomial_factor',4*xx**4-12*xx**3+10*xx**2-2,2*(xx-1)**2*(2*xx**2-2*xx-1))
check('half_radius_quadratic_bound',(2*xx**2-2*xx-1).subs(xx,s.Rational(4,3)),-s.Rational(1,9))
check('two_radius_lower_bound',4*s.exp(6)*(front(s.Integer(2))-tail(s.Integer(2))),s.E**2*(s.E-1)*(s.E-2)-1)
check('exponential_lower_product',s.Rational(64,9)*s.Rational(5,3)*s.Rational(2,3),s.Rational(640,81))
check('symmetric_patch_limit',(1+s.Rational(1,9))/2-s.Rational(1,4),s.Rational(11,36))
check('symmetric_tangent_pairing',(s.Matrix([-1,-1,2]).T*s.Matrix([0,1,-1]))[0],-3)
check('lens_cusp_integral',s.integrate(1,(r,0,s.sqrt(2*t))),s.sqrt(2*t))

# Source integrity is handled by the root public verifier.
# Historical bindings are preserved separately, without private locations.
bindings={}
out={'status':'PASS','exact_check_count':len(checks),'checks':checks,'source_bindings':bindings,'sympy_version':s.__version__,'no_floating_optimizer_certificate':True}
p=Path(__file__).with_name('EXACT_CONTROLS.json')
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','exact_check_count':len(checks)},indent=2))
