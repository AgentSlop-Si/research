# ALG-036: unique comparison transition between the two endpoint normals

Date: 20 October 2026 UTC. Historical source status: collaborative analytic contribution; fresh adversarial acceptance pending. Current accepted scope is recorded in RELEASE.json. This does not solve the intervening scalar optimization.

## 1. Contract and exact scope

Use the accepted proper-complex Gaussian contract

    F_a(q)=Pr(max_j |Z_j|<=sqrt(a)),
    Z~CN(0,I-uu*), u_j=sqrt(q_j), sum q_j=1, a>0.

Let B(a)=F_a(0,1/2,1/2) and S(a)=F_a(1/3,1/3,1/3). The accepted all-radius structural theorem reduces the global maximum to F_a(c,(1-c)/2,(1-c)/2), 0<=c<=1/3. We prove only the following endpoint comparison.

**Theorem.** There is exactly one finite a_* in (1/2,2) such that S(a_*)=B(a_*). Moreover

    S(a)<B(a) for 0<a<a_*,
    S(a)>B(a) for a>a_*.

The crossing is transverse: (S-B)'(a_*)>0. The common zero at a=0 is not included in this finite-positive-a assertion. Both probabilities tend to one as a tends to infinity; their difference does not vanish at another finite positive a.

The theorem is NOT a proof that either endpoint globally maximizes the scalar branch. It does not exclude intermediate c, identify their stationary points, or prove that a_* is the global-optimizer transition. Those are separate gates.

## 2. Exact radial-shell representation

Choose an isometric complex frame of u-perp and write Z=V(X,Y), where X,Y are independent standard proper-complex Gaussians. Then R=|X|²+|Y|² has density R exp(-R), and the unit direction is independent and uniform on the unit sphere in C². Define

    g_q(t)=Pr_direction(max_j |(V direction)_j|² <= 1/t), t>0.

Since sum_j |(V direction)_j|²=1, g_q(t)=0 for t>3. With r=a t, radial integration gives exactly

    F_a(q)/a² = integral_0^3 t exp(-a t) g_q(t) dt.       (2.1)

This normalization follows from the proper-complex Gamma(shape 2, scale 1) radial density, not a real-Gaussian replacement.

### 2.1 Block shell fraction

For q=(0,1/2,1/2), take Z=(X,Y/sqrt(2),-Y/sqrt(2)). Conditional on the total squared radius, x=|X|²/(|X|²+|Y|²) is uniform on [0,1]. The directional constraints are x<=1/t and 1-x<=2/t. Therefore

    g_B(t)=1,                0<t<=1;
           1/t,              1<t<=2;
           3/t-1,            2<t<=3;
           0,                t>3.                    (2.2)

In particular B(a)=(1-exp(-a))(1-exp(-2a)).

### 2.2 Symmetric shell fraction and the sphere model

For q=(1/3,1/3,1/3), choose

    Z_1=sqrt(2/3)X,
    Z_2=-X/sqrt(6)+Y/sqrt(2),
    Z_3=-X/sqrt(6)-Y/sqrt(2).

For a unit direction (X,Y), define

    n=(2 Re(conj(X)Y), 2 Im(conj(X)Y), |X|²-|Y|²).

Then n is uniform on S². Indeed |X|² is uniform on [0,1], so n_3 is uniform on [-1,1], and the relative phase is independent and uniform on [0,2pi). These are exactly uniform spherical coordinates. Put

    r_1=(0,0,1),
    r_2=(-sqrt(3)/2,0,-1/2),
    r_3=(sqrt(3)/2,0,-1/2).

The three squared coordinate fractions are (1+n dot r_j)/3. The vectors r_j are coplanar unit vectors with mutual angle 2pi/3 and sum zero. Consequently, with k=3/t-1,

    g_S(t)=Pr(n dot r_j<=k for all j).                (2.3)

For t<=3/2, k>=1, so g_S(t)=1. For 3/2<=t<=2, 1/2<=k<=1. The three excluded spherical caps n dot r_j>k are pairwise disjoint up to null boundaries: two such strict inequalities would give n dot(r_i+r_j)>2k>=1, but |r_i+r_j|=1. A cap has spherical probability (1-k)/2, hence

    g_S(t)=1,                     0<t<=3/2;
           9/(2t)-2,              3/2<=t<=2.          (2.4)

In particular g_S(2)=1/4.

For 2<=t<=3, 0<=k<=1/2. Project n onto the plane of the r_j. The projection v has density

    [2pi sqrt(1-|v|²)]^(-1), |v|<1.                 (2.5)

One obtains (2.5) directly by summing the surface-area Jacobians of the two graphs ±sqrt(1-|v|²). The event in (2.3) becomes the equilateral triangle

    T_k={v: v dot r_j<=k for all j}

in that plane. Its inradius is k and circumradius 2k. For k<=1/2 it is contained in the closed unit disk; a boundary point on the circle has zero probability. Also T_k=2k T_(1/2). Therefore

    g_S(t)=(1/(2pi)) integral_(T_k) (1-|v|²)^(-1/2) dv
          =(4k²/(2pi)) integral_(T_(1/2)) (1-4k²|w|²)^(-1/2) dw
          <=4k² g_S(2)=k².                           (2.6)

The comparison holds almost everywhere, and the right integral is finite. For 0<k<=1/2, k²<k. Since g_B(t)=k in this range, this proves

    g_S(t)<g_B(t), 2<=t<3.                          (2.7)

The equalities at t=3, or k=0, cause no issue.

## 3. The shell difference has one sign change

Set

    Delta(t)=t(g_S(t)-g_B(t)), tau=7/4.

Equations (2.2), (2.4), and (2.7) give:

- Delta(t)=0 for 0<t<=1.
- Delta(t)=t-1>0 for 1<t<=3/2.
- Delta(t)=7/2-2t for 3/2<=t<=2. Its only zero on this interval is tau=7/4.
- Delta(t)<0 for 2<t<3.

Thus Delta is strictly positive on (1,tau) and strictly negative on (tau,3). This conclusion is exact and uniform; it is not inferred from a finite grid.

## 4. Strict monotonicity after exponential normalization

By (2.1), define for all real a

    Q(a)=integral_0^3 exp(-a t) Delta(t) dt.

For a>0 this is (S(a)-B(a))/a². Its extension to a=0 and differentiation under the finite integral are immediate from boundedness. Let

    M(a)=exp(tau a)Q(a).

Then

    M'(a)=integral_0^3 (tau-t) exp(a(tau-t)) Delta(t) dt >0.  (4.1)

The strict sign follows because (tau-t)Delta(t)>0 throughout each of the nonempty intervals (1,tau) and (tau,3). This is the entire variation-diminishing step, proved directly rather than invoked as an external theorem.

At a=0 the block integral is 2. To compute the symmetric integral, set unit truncation radius and use z_1=-z_2-z_3. The intrinsic complex Jacobian is 3, so its normalized four-real-dimensional section volume is

    integral_0^3 t g_S(t)dt
      = (3/pi²) integral_(|w|<=1, |z|<=1, |w+z|<=1) dw dz
      = (3/pi²) integral_0^1 2pi r
          [2 arccos(r/2)-(r/2)sqrt(4-r²)] dr
      = 3 - 9sqrt(3)/(4pi).                            (4.2)

The middle expression uses the elementary area of intersection of two unit disks at distance r. The final elementary integral is also checked symbolically in the accompanying controls. Hence

    M(0)=Q(0)=1-9sqrt(3)/(4pi)<0.                      (4.3)

For example pi<22/7 and sqrt(3)>5/3 imply 4pi<88/7<15<9sqrt(3), certifying the strict inequality without a decimal approximation.

Finally M(a) tends to positive infinity as a tends to positive infinity. Here is an explicit bound. On [5/4,3/2], Delta(t)=t-1>=1/4 and tau-t>=1/4. The positive contribution is at least exp(a/4)/16. The magnitude of the negative contribution is at most

    integral_tau^3 t dt=95/32,

because |g_S-g_B|<=1 and exp(a(tau-t))<=1 there for a>=0. Therefore

    M(a)>=exp(a/4)/16 - 95/32.                        (4.4)

It follows from continuity, (4.1), (4.3), and (4.4) that M has exactly one zero a_*>0. Since the factors exp(tau a) and a² are positive for a>0, this proves the theorem's strict endpoint comparisons. At the zero,

    (S-B)'(a_*)=a_*² exp(-tau a_*) M'(a_*)>0,

so the crossing is transverse.

### 4.1 A certified rational bracket

The following coarse bracket requires no quadrature or decimal constants:

    1/2 < a_* < 2.                                    (4.5)

For 2<=t<=3, let k=3/t-1. By (2.6), 0<=g_S(t)<=k²<=k/2. Define

    I(a)=integral_1^(3/2) exp(-at)(t-1)dt
           + integral_(3/2)^2 exp(-at)(7/2-2t)dt,
    J(a)=integral_2^3 exp(-at)(3-t)dt.

Then

    I(a)-J(a)<=Q(a)<=I(a)-J(a)/2.                      (4.6)

At a=1/2, elementary integration, followed by x=exp(1/4), gives

    exp(3/2)[I(1/2)-J(1/2)/2]
      =4x^4-12x^3+10x²-2
      =2(x-1)²(2x²-2x-1)<0.

Indeed 1<x<4/3, because exp(1/4)=sum_n (1/4)^n/n! is strictly smaller than sum_n (1/4)^n=4/3. The quadratic is increasing for x>=1 and its value at 4/3 is -1/9. Thus Q(1/2)<0.

At a=2, elementary integration gives

    4 exp(6)[I(2)-J(2)]
      =exp(4)-3exp(3)+2exp(2)-1
      =e²(e-1)(e-2)-1>0.

Here e>1+1+1/2+1/6=8/3, and the product is greater than (64/9)(5/3)(2/3)=640/81>1. Hence Q(2)>0. Uniqueness proves (4.5).

## 5. An optional explicit shell formula

For 2<t<3 and k=3/t-1, polar integration over the triangle gives

    g_S(t)=1-(3/pi) integral_0^(pi/3) sqrt(1-k² sec²(phi)) d phi.

For 0<k<1/2, the integral is

    arctan(sqrt(3)/sqrt(1-4k²))
      - k arctan(sqrt(3) k/sqrt(1-4k²)).                (5.1)

The endpoint values are obtained by continuity. Formula (5.1) is not needed for the sign proof; it is a useful scalar evaluation formula. Exploratory non-certified quadrature gives

    a_* approximately 0.9526342063524,
    sqrt(a_*) approximately 0.9760298183726.

These decimals are diagnostics, not proof or a certified root enclosure. The theorem defines a_* exactly as the unique positive zero above.

## 6. Independent boundary-cusp control

This section records a separate corroboration of the scalar author's boundary calculation; it does not exclude interior maxima. Write s=1-c and use the isometric representation

    Z=(sqrt(s)X,(-sqrt(c)X+Y)/sqrt(2),(-sqrt(c)X-Y)/sqrt(2)).

For R=sqrt(2a), define the normalized Gaussian lens

    L_a(v)=Pr(|Y+sqrt(v)|<=R and |Y-sqrt(v)|<=R).

Then exactly

    F_a(c,s/2,s/2)=integral_0^(a/s) exp(-x)L_a(cx) dx.  (6.1)

In Cartesian coordinates and for 0<=v<R²,

    L_a(v)=(4/pi) integral_0^sqrt(R²-v) exp(-y²)
                 integral_0^(sqrt(R²-y²)-sqrt(v)) exp(-z²) dz dy.

Differentiating first in d=sqrt(v), the moving upper boundary contributes zero because the inner integral vanishes there. Thus

    d/dd L_a(d²)=-(4/pi) exp(-R²-d²)
        integral_0^sqrt(R²-d²) exp(2d sqrt(R²-y²))dy.    (6.2)

In particular the derivative at d=0 is -4R exp(-R²)/pi. The derivative is locally Lipschitz near zero, directly from (6.2), so

    L_a(v)=1-exp(-2a)-(4sqrt(2a)/pi)exp(-2a)sqrt(v)+O_a(v).

Substituting in (6.1), and noting a/s=a+O_a(c), gives

    F_a(c,s/2,s/2)=B(a)-K(a)sqrt(c)+O_a(c),
    K(a)=(4sqrt(2a)/pi)exp(-2a) integral_0^a sqrt(x)exp(-x)dx>0.  (6.3)

For every fixed finite a>0, c=0 is therefore a strict one-sided local maximum. Its derivative diverges negatively:

    partial_c F_a(c,s/2,s/2)= -K(a)/(2sqrt(c))+O_a(1).

The derivative expansion follows by differentiating the finite integral using (6.2), whose corresponding v derivative is -2R exp(-R²)/(pi sqrt(v))+O_a(1). No uniform claim in a is made. At large a this cusp can lie below any coarse numerical c mesh, so apparent scalar monotonicity from such a mesh is not a proof.

## 7. The symmetric normal is a strict local maximum at every finite radius

This additional endpoint statement uses the accepted C² regularity theorem and the accepted strict largest-pair boundary identity, source-bound in the controls. It is a quantitative consequence of that identity, not of strict monotonicity alone.

Let q_0=(1/3,1/3,1/3). Permutation invariance implies the Hessian of the symmetric homogeneous extension has equal diagonal entries and equal off-diagonal entries at q_0. Thus its restriction to the tangent plane sum v_i=0 has the form lambda times the Euclidean inner product, for some real lambda=lambda(a). The tangent first derivative vanishes by symmetry.

Put v=(-1,-1,2), w=(0,1,-1), and q_epsilon=q_0+epsilon v. For small epsilon>0, the first two normal weights are tied minima. Write

    c=1/3-epsilon, s=1-c,
    t=c/s, p=(1/3+2epsilon)/s,
    r=sqrt(a), kappa=s/c, R²=ac/s,
    A=t a+p rho², B=p a+t rho², K=2sqrt(tp)r rho.

The accepted boundary formula gives

    D_w F_a(q_epsilon)=J'(theta)/(2pi² c s sqrt(tp)),
    J'(theta)=-2pi r integral_0^r exp(-a-rho²)rho²
        integral_0^(2pi) cos(phi)[h(A+K cos(phi))-h(B+K cos(phi))]dphi drho,

where h(z)=exp(-kappa z)1_(z<=R²). Every contribution after the leading negative sign is nonnegative, by the accepted smallest-weight support argument.

Use the fixed positive-measure patch

    r/3<=rho<=r/2, cos(phi)<=-3/4.

At epsilon=0, both arguments X=A+K cos(phi) and Y=B+K cos(phi) are at most 11a/36, strictly below the limiting cutoff a/2. This bound follows because (a+rho²)/2-(3/4)r rho decreases on that radial interval and has value 11a/36 at rho=r/3. By uniform continuity on the compact patch, for all sufficiently small epsilon>0 both arguments remain strictly below R². Thus on that patch h is its untruncated exponential, and

    h(X)-h(Y)=kappa exp(-kappa xi)(Y-X)
             >= C_1(a)(p-t),
    Y-X=(p-t)(a-rho²)>=(3a/4)(p-t),

for an intermediate xi between X and Y and a fixed C_1(a)>0. All other factors in the patch integral are bounded below by strictly positive constants after including the leading negative sign. Since p-t=3epsilon/s, and the derivative prefactor tends to a finite positive number, it follows that

    D_w F_a(q_epsilon)>=C_2(a)epsilon

for a fixed C_2(a)>0 and all sufficiently small epsilon>0.

C² regularity and the scalar tangent Hessian give independently

    D_w F_a(q_0+epsilon v)
       =epsilon lambda(w dot v)+o(epsilon)
       =-3lambda epsilon+o(epsilon).

Dividing by epsilon and taking the limit proves -3lambda>=C_2(a)>0. Hence lambda<0. The constrained Hessian is negative definite, so q_0 is a strict local maximum in the full simplex for every fixed finite a>0. In particular it is a strict local maximum at the scalar endpoint c=1/3.

This result and the block cusp show that both scalar endpoints remain locally maximizing throughout the endpoint-value transition. They do not exclude additional interior local maxima or establish the global endpoint-only conjecture.

## 8. Integrity and unresolved gate

The endpoint transition theorem and the cusp statement are analytic proofs. Exact symbolic controls check normalizations, isometries, shell formulas, and elementary integrations; they do not replace the proofs. The exploratory floating evaluation is kept separate and has no role in either theorem.

The endpoint author contributed the shell-sign-change argument to the scalar author before the combined proof was frozen. This is a collaborative contribution, not an independent acceptance of itself. The separate fresh source-bound review is included at reviews/fresh/REVIEW.md.

The exact remaining gate is to prove, or disprove by certified counterexample, that every intermediate scalar point c in (0,1/3) is below max(B(a),S(a)) for every a>0. The endpoint crossing theorem alone does not imply this.
