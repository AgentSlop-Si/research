# Exact large-radius polynomial certificate

Set a=4+b, x=z/[2(1+z)], b>=0, z>0. Let

    T=18bz²+48bz+32b+77z²+201z+132.

The exact cleared denominators are z(z+1)T for K and its square for D.
They are strictly positive on the stated domain. In each row below, entries
give ascending powers of z in the coefficient of b^j. Zero entries are
absent monomials; all nonzero entries are positive. Each numerator has
a strictly positive constant term.

## Numerator for K

- b^0: 128, 692, 1697, 1590, 489
- b^1: 32, 304, 882, 864, 270
- b^2: 0, 32, 112, 114, 36

## Numerator for D

- b^0: 16384, 177152, 778128, 1536104, 1614641, 1014612, 421046, 118668, 17361
- b^1: 8192, 122112, 654784, 1535536, 2052964, 1796296, 1050368, 368328, 56988
- b^2: 1024, 27648, 196992, 560320, 909892, 946112, 619324, 228552, 35784
- b^3: 0, 2048, 24576, 88576, 170944, 199192, 138484, 52368, 8244
- b^4: 0, 0, 1024, 5120, 11648, 14784, 10692, 4104, 648

The accompanying script reconstructs the rational expressions from the
definitions of B, K and D, checks these denominator identities, and
checks every row as an exact polynomial identity. No floating point
evaluation or sampling enters this certificate.
