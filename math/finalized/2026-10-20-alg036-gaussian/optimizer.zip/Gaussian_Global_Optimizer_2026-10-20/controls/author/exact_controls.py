#!/usr/bin/env python3
"""Exact rational/symbolic controls, not numerical quadrature or a radius census."""
from pathlib import Path
import hashlib
import json
import sympy as S

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, condition, detail=""):
    ok = bool(condition)
    checks.append({"name": name, "pass": ok, "detail": str(detail)})
    if not ok:
        raise AssertionError(name)

def zero(name, expression):
    value = S.factor(expression)
    check(name, value == 0, value)

a, t, v, d, rho, x = S.symbols("a t v d rho x", positive=True)
A, B, C, y, z, b = S.symbols("A B C y z b", positive=True)
L = S.Function("L")
H = S.Function("H")
log_P = S.log(a) + S.log(t) - a*(1+t*t) + L(S.sqrt(a)*t)
zero("log_P_second_derivative",
     S.diff(log_P,t,2) - (-1/t**2-2*a+a*S.diff(L(d),d,2).subs(d,S.sqrt(a)*t)))
log_w = 2*S.log(v)-(1+t*t)*v*v+H(t*v)
zero("integral_score", S.diff(log_w,t)-(-2*t*v*v+v*S.diff(H(d),d).subs(d,t*v)))
zero("integral_score_derivative",
     S.diff(log_w,t,2)-(-2*v*v+v*v*S.diff(H(d),d,2).subs(d,t*v)))

base_log_h = -rho*rho-d*d+S.log(rho*rho-d*d)/2
zero("base_log_h_second_derivative",
     S.diff(base_log_h,d,2)+2+(rho*rho+d*d)/(rho*rho-d*d)**2)
G = y*S.sqrt(B+C*y*y)
zero("G_second_derivative",
     S.diff(G,y,2)-C*y*(3*B+2*C*y*y)/(B+C*y*y)**S.Rational(3,2))
zero("G_third_derivative",
     S.diff(G,y,3)-3*B*B*C/(B+C*y*y)**S.Rational(5,2))
zero("G_second_derivative_bound_square",
     4*C*(B+C*y*y)**3-C*C*y*y*(3*B+2*C*y*y)**2-C*B*B*(4*B+3*C*y*y))
zero("fixed_h_exponent_second_derivative",
     S.diff(2*d*S.sqrt(A+B*d*d),d,2)
     -2*B*d*(3*A+2*B*d*d)/(A+B*d*d)**S.Rational(3,2))
q = (rho*rho+d*d)/(rho*rho-d*d)**2
zero("h_curvature_penalty_monotonicity",
     S.diff(q,d)-2*d*(3*rho*rho+d*d)/(rho*rho-d*d)**3)
g = (2+x)/(2-x)**2
zero("g_derivative", S.diff(g,x)-(6+x)/(2-x)**3)
zero("scaled_curvature_penalty", q.subs({rho:S.sqrt(2*a),d:S.sqrt(a*x)})-g/a)
zero("g_half", g.subs(x,S.Rational(1,2))-S.Rational(10,9))
zero("g_four_ninths", g.subs(x,S.Rational(4,9))-S.Rational(99,98))

# Integration by parts and its one-dimensional positive root.
zero("v_flux_log_derivative",
     1+v*S.diff(log_w,v)-(3-2*(1+t*t)*v*v+t*v*S.diff(H(d),d).subs(d,t*v)))
zero("ibp_upper_score",
     3-2*(1+x)*v*v+S.sqrt(x)*v*(2*S.sqrt(2*a)-2*S.sqrt(x)*v)
     -(3-2*(1+2*x)*v*v+2*S.sqrt(2*a*x)*v))
u = S.symbols("u", positive=True)
root = (S.sqrt(2*a*x)+S.sqrt(2*a*x+6*(1+2*x)))/(2*(1+2*x))
zero("ibp_positive_root", 2*(1+2*x)*root**2-2*S.sqrt(2*a*x)*root-3)

# Scaled positive mixture, concavity and reflection.
s = S.symbols("s", nonnegative=True)
B_s = 2*(1-s*s)
C_s = t*t*s*s
f_s = -(1+2*t*t)*y*y+2*t*y*S.sqrt(B_s+C_s*y*y)
scaled_log_weight = -(1+t*t)*a*y*y-a*t*t*y*y + 2*a*t*y*S.sqrt(B_s+C_s*y*y)
zero("mixture_exponent", scaled_log_weight-a*f_s)
zero("square_root_factor_log_curvature",
     S.diff(S.log(2-t*t*y*y)/2,y,2)+t*t*(2+t*t*y*y)/(2-t*t*y*y)**2)
zero("f_concavity_upper",
     -2*(1+2*t*t)+4*t*t*s-(-2-4*t*t*(1-s)))
zero("reflection_endpoint_deficit",
     1+2*t*t-2*S.sqrt(2)*t-(1-S.sqrt(2)*t)**2)
zero("reflection_radical_upper", 2-(B_s+C_s)-s*s*(2-t*t))
phi = y**3*(1-y*y)
zero("layer_cake_phi_derivative", S.diff(phi,y)-y*y*(3-5*y*y))
zero("layer_cake_reflection_factor",
     phi.subs(y,1-y)-phi-y*(y-1)*(2*y-1)*(y*y-y+2))
alpha,beta = S.symbols("alpha beta", nonnegative=True)
zero("interval_moment_comparison",
     5*S.integrate(y**4,(y,alpha,beta))-3*S.integrate(y**2,(y,alpha,beta))
     -(beta**5-alpha**5-beta**3+alpha**3))
zero("moment_curvature_bound",
     1/x+2*a-(4+g/a)*S.Rational(3,5)*a
     -(1/x-S.Rational(2,5)*a-S.Rational(3,5)*g))
zero("small_radius_endpoint", (1/x-S.Rational(2,5)*a-S.Rational(3,5)*g)
     .subs({x:S.Rational(1,2),a:S.Rational(10,3)}))
zero("compact_low_t_margin",
     S.Rational(9,4)-S.Rational(8,5)-S.Rational(3,5)*S.Rational(99,98)-S.Rational(43,980))
zero("compact_unrepaired_margin", 2-S.Rational(8,5)-S.Rational(2,3)+S.Rational(4,15))

# Large-radius certificate. Denominators are displayed as positive factors.
threshold = (1/x+2*a)/(4+g/a)
K = 2*(1+2*x)*threshold-3
D = K*K-8*a*x*threshold
T = 18*b*z*z+48*b*z+32*b+77*z*z+201*z+132
den_K = z*(z+1)*T
den_D = den_K**2
certificates = {}
for name, expr, expected_den in [("K",K,den_K),("D",D,den_D)]:
    converted = S.cancel(expr.subs({a:4+b,x:z/(2*(1+z))}))
    numerator, denominator = converted.as_numer_denom()
    zero(name+"_denominator_identity", denominator-expected_den)
    polynomial = S.Poly(numerator,b,z)
    zero(name+"_rational_identity", converted-numerator/expected_den)
    check(name+"_all_coefficients_positive", all(c>0 for c in polynomial.coeffs()))
    check(name+"_positive_constant_coefficient", polynomial.coeff_monomial(1)>0)
    coefficients = [[int(polynomial.coeff_monomial(b**j*z**k))
                     for k in range(polynomial.degree(z)+1)]
                    for j in range(polynomial.degree(b)+1)]
    certificates[name] = {
        "substitution": {"a":"4+b","x":"z/(2*(1+z))","domain":"b>=0, z>0"},
        "denominator": str(expected_den),
        "numerator": str(S.expand(numerator)),
        "coefficient_rows": coefficients,
        "row_convention": "row j gives coefficients of z^0,z^1,... in the coefficient of b^j",
        "degree_b": polynomial.degree(b),
        "degree_z": polynomial.degree(z)
    }
    for j,row in enumerate(coefficients):
        zero(name+f"_coefficient_row_{j}",
             S.Poly(numerator,b).coeff_monomial(b**j)
             -sum(c*z**k for k,c in enumerate(row)))

# Elementary constants, all rational certificates.
pi_lower = 4*sum(sum((-1)**k*S.Rational(1,n)**(2*k+1)/S.Rational(2*k+1)
                         for k in range(4)) for n in [2,3])
check("arctan_angles_add_to_pi_over4", (S.Rational(1,2)+S.Rational(1,3))/(1-S.Rational(1,6))==1)
zero("pi_lower_certificate_value", pi_lower-S.Rational(1538665,489888))
check("pi_lower_exceeds_25_over8", pi_lower>S.Rational(25,8))
zero("pi_upper_integral_certificate",
     S.integrate(y**4*(1-y)**4/(1+y*y),(y,0,1))-(S.Rational(22,7)-S.pi))
r = S.Rational(8,3)
exp_upper = sum(r**k/S.factorial(k) for k in range(7)) + (r**7/S.factorial(7))/(1-r/8)
zero("exp_upper_certificate_value", exp_upper-S.Rational(3306347,229635))
check("exp_upper_below15", exp_upper<15)
check("exp_tail_ratio_below1", r/8<1)
check("rho_lower_squared", S.Rational(18,7)**2<S.Rational(20,3))
zero("boundary_loss_at_half_rho",
     (d/(rho*rho-d*d)).subs(d,rho/2)-S.Rational(2,3)/rho)
zero("boundary_loss_derivative",
     S.diff(d/(rho*rho-d*d),d)-(rho*rho+d*d)/(rho*rho-d*d)**2)
zero("uniform_semicircle_mean",
     S.integrate(S.sqrt(rho*rho-y*y),(y,0,rho))/rho-S.pi*rho/4)
zero("h_prime_ratio_constant",
     S.Rational(18,7)*(S.Rational(25,16)-1)-S.Rational(7,27)-S.Rational(1795,1512))
check("h_prime_ratio_constant_positive", S.Rational(1795,1512)>0)
zero("restricted_integral_radical", S.sqrt(rho*rho-(rho/3)**2)-2*S.sqrt(2)*rho/3)
exponent = -2-t*t+S.Rational(8,3)*t
zero("compact_exponent_at_2_over3", exponent.subs(t,S.Rational(2,3))+S.Rational(2,3))
zero("compact_exponent_derivative", S.diff(exponent,t)-(S.Rational(8,3)-2*t))
check("compact_exponent_derivative_positive", S.Rational(8,3)-2>0)
zero("h_lower_constant", 4*S.Rational(18,7)/(3*S.Rational(22,7)*15)-S.Rational(4,55))
gap_improvement = S.Rational(10,3)*S.Rational(4,55)*S.Rational(1795,1512)
zero("compact_positive_surplus", gap_improvement-S.Rational(4,15)-S.Rational(659,31185))
check("compact_positive_surplus_is_positive", S.Rational(659,31185)>0)
ell = S.Function("ell")
h = S.Function("h")
zero("lens_log_curvature",
     (-S.diff(h(d),d)*ell(d)-h(d)**2)/ell(d)**2
     -(-S.diff(h(d),d)/ell(d)-(h(d)/ell(d))**2))
zero("c_parameter_derivative", S.diff(t*t/(1+t*t),t)-2*t/(1+t*t)**2)
zero("c_parameter_endpoint", (t*t/(1+t*t)).subs(t,1/S.sqrt(2))-S.Rational(1,3))

# Historical original-source checks are not mathematical controls.
# Public source bindings are checked by the root verifier.

(ROOT/"POLYNOMIAL_CERTIFICATES.json").write_text(json.dumps(certificates,indent=2)+"\n")
text = ["# Exact large-radius polynomial certificate", "",
        "Set a=4+b, x=z/[2(1+z)], b>=0, z>0. Let",
        "", "    T=18bz²+48bz+32b+77z²+201z+132.", "",
        "The exact cleared denominators are z(z+1)T for K and its square for D.",
        "They are strictly positive on the stated domain. In each row below, entries",
        "give ascending powers of z in the coefficient of b^j. Zero entries are",
        "absent monomials; all nonzero entries are positive. Each numerator has",
        "a strictly positive constant term.", ""]
for name,cert in certificates.items():
    text += [f"## Numerator for {name}", ""]
    for j,row in enumerate(cert["coefficient_rows"]):
        text += [f"- b^{j}: "+", ".join(map(str,row))]
    text += [""]
text += ["The accompanying script reconstructs the rational expressions from the",
         "definitions of B, K and D, checks these denominator identities, and",
         "checks every row as an exact polynomial identity. No floating point",
         "evaluation or sampling enters this certificate.", ""]
(ROOT/"POLYNOMIAL_CERTIFICATES.md").write_text("\n".join(text))
report = {"method":"67 unchanged exact mathematical controls; historical source integrity is separate",
          "count":len(checks),"all_pass":all(c["pass"] for c in checks),"checks":checks,
          "analytic_arguments_are_in":"candidate/PROOF.md",
          "no_floating_quadrature":True,"no_numeric_radius_ladder":True}
(ROOT/"EXACT_CONTROLS.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"count":len(checks),"all_pass":report["all_pass"]}))
