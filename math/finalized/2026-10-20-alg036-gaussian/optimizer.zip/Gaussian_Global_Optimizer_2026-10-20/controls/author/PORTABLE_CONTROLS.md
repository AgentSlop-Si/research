# Completion author controls

Historical count: 85. Mathematical rows: 67. Original-source hash/length rows: 18.

HISTORICAL_CONTROLS.json preserves all original rows and results, replacing only private source-location details with semantic source labels. exact_controls.py runs the same 67 mathematical expressions and emits EXACT_CONTROLS.json plus both polynomial-certificate files. The polynomial outputs remain byte-identical to the originals. The 18 source checks are historical evidence only; public source integrity is now checked by the root verifier. These are not 85 replayed mathematical tests.
