# Fresh independent controls

Historical count: 143. Mathematical rows: 63. Original-source integrity rows: 80.

HISTORICAL_CONTROLS.json preserves every original row, pass/fail result and independent polynomial certificate, changing only private source-location labels. independent_controls.py retains every mathematical expression, including the independent polynomial reconstruction and comparison to the included author certificate. It reads that certificate locally. The 80 historical source checks are omitted from portable execution, not reinterpreted as mathematical checks. The public root verifier checks current bindings and mathematical-row equality separately.

INDEPENDENT_RECONSTRUCTION.md is the historical pre-candidate reconstruction, not the final verdict. REVIEW.md and VERDICT.json are the final frozen-candidate acceptance. Their original manifest is preserved independently of the public manifest. Common access to an unproved lead and the absence of a proof-repair contribution are explicitly disclosed.
