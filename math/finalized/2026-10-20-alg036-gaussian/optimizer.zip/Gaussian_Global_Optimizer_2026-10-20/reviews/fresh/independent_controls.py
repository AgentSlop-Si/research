"""Independent exact consistency and provenance controls. No floating optimizer census."""
from pathlib import Path
from hashlib import sha256
import json
import sympy as s
BASE=Path(__file__).resolve().parent
checks=[]
def check(name, claim):
    ok=bool(claim)
    checks.append({'name':name,'passed':ok})
    if not ok: raise AssertionError(name)
def zero(name, expr): check(name,s.simplify(expr)==0)
def digest(p):return sha256(Path(p).read_bytes()).hexdigest()

x,a,b,z,y,B,C,R,d,t=s.symbols('x a b z y B C R d t', positive=True)
G=y*s.sqrt(B+C*y*y)
G2=s.diff(G,y,2)
G3=s.diff(G,y,3)
zero('G second derivative',G2-C*y*(3*B+2*C*y*y)/(B+C*y*y)**s.Rational(3,2))
zero('G third derivative',G3-3*B*B*C/(B+C*y*y)**s.Rational(5,2))
u=s.symbols('u',nonnegative=True)
zero('G second upper bound square difference',4*(1+u*u)**3-u*u*(3+2*u*u)**2-(4+3*u*u))
zero('reflection endpoint square',-(1+2*t*t)+2*s.sqrt(2)*t+(s.sqrt(2)*t-1)**2)
q=lambda y:y**3*(1-y*y)
zero('layer cake endpoint factor',q(1-y)-q(y)-y*(y-1)*(2*y-1)*(y*y-y+2))
zero('layer cake q derivative',s.diff(q(y),y)-y*y*(3-5*y*y))
zero('square root factor log curvature',s.diff(s.log(s.sqrt(R*R-d*d)),d,2)+(R*R+d*d)/(R*R-d*d)**2)
g=(2+x)/(2-x)**2
zero('g derivative',s.diff(g,x)-(6+x)/(2-x)**3)
zero('g endpoint',g.subs(x,s.Rational(1,2))-s.Rational(10,9))
zero('g at compact split',g.subs(x,s.Rational(4,9))-s.Rational(99,98))
zero('small-a boundary lower bound',2-s.Rational(2,5)*s.Rational(10,3)-s.Rational(3,5)*s.Rational(10,9))
zero('small-x compact margin',s.Rational(9,4)-s.Rational(8,5)-s.Rational(3,5)*s.Rational(99,98)-s.Rational(43,980))
zero('compact rough curvature bound',2-s.Rational(8,5)-s.Rational(3,5)*s.Rational(10,9)+s.Rational(4,15))
zero('large-a moment threshold', (4+g/a)*a*(x-2)**2*(2*a*x+1)/(x*(4*a*x*x-16*a*x+16*a+x+2))-(1/x+2*a))
threshold=s.factor((1/x+2*a)/(4+g/a))
K=s.factor(2*(1+2*x)*threshold-3)
Q=s.factor(K*K-8*a*x*threshold)
cert={}
for name,expr in [('K',K),('Q',Q)]:
    value=s.factor(expr.subs({a:4+b,x:z/(2*(1+z))}))
    n,de=s.fraction(value)
    pol=s.Poly(n,b,z)
    check(name+' positive numerator coefficients',all(c>0 for _,c in pol.terms()))
    check(name+' positive constant numerator',pol.as_expr().subs({b:0,z:0})>0)
    dp=s.Poly(de,b,z)
    check(name+' nonnegative denominator coefficients',all(c>0 for _,c in dp.terms()))
    # z>0 ensures each displayed monomial of de is positive even when b=0.
    check(name+' denominator nonzero at b=0,z>0',s.Poly(de.subs(b,0),z).terms()!=[])
    cert[name]={'numerator':str(pol.as_expr()),'denominator':str(s.factor(de)),
                'coefficients':[{'b_power':powers[0],'z_power':powers[1],'coefficient':str(c)} for powers,c in pol.terms()]}
    end=s.factor(expr.subs({a:4+b,x:s.Rational(1,2)}))
    en,ed=s.fraction(end)
    check(name+' endpoint numerator positive coefficients',all(c>0 for _,c in s.Poly(en,b).terms()))
    check(name+' endpoint denominator positive coefficients',all(c>0 for _,c in s.Poly(ed,b).terms()))
    cert[name]['x_half']=str(end)

zero('compact exponent reduction',-2-t*t+s.Rational(8,3)*t-(-s.Rational(2,3)+(t-s.Rational(2,3))*(2-t)))
check('compact exponent monotone',s.Rational(8,3)-2>0) # t<=1/sqrt(2)<1
check('R lower bound',s.Rational(20,3)>s.Rational(18,7)**2)
zero('Hprime rational floor',s.Rational(18,7)*(s.Rational(25,16)-1)-s.Rational(7,27)-s.Rational(1795,1512))
zero('h rational floor',4*s.Rational(18,7)/(3*s.Rational(22,7)*15)-s.Rational(4,55))
p=s.Rational(8,3)
exp_bound=sum(p**k/s.factorial(k) for k in range(4))+p**4/s.factorial(4)/(1-p/5)
zero('exact exponential geometric tail bound',exp_bound-s.Rational(8447,567))
check('exp geometric tail exceeds actual convergence ratio',p/5<1)
check('exp upper bound below 15',exp_bound<15)
margin=s.Rational(10,3)*s.Rational(4,55)*s.Rational(1795,1512)-s.Rational(4,15)
zero('compact final margin',margin-s.Rational(659,31185))
check('compact final margin strictly positive',margin>0)

# Gaussian frame and parameter audit, independent of the new author's controls.
c=s.symbols('c',positive=True)
V=s.Matrix([[s.sqrt(1-c),0],[-s.sqrt(c/2),s.sqrt(s.Rational(1,2))],[-s.sqrt(c/2),-s.sqrt(s.Rational(1,2))]])
for i in range(2):
    for j in range(2):
        zero(f'proper complex frame isometry entry {i},{j}',(V.T*V-s.eye(2))[i,j])
ct=t*t/(1+t*t)
zero('parameter Jacobian',s.diff(ct,t)-2*t/(1+t*t)**2)
zero('lens derivative boundary exponent',-y*y-(s.sqrt(R*R-y*y)-d)**2+R*R+d*d-2*d*s.sqrt(R*R-y*y))
zero('Gaussian scalar upper limit',a/(1-ct)-a*(1+t*t))
zero('boundary shift',ct*a*(1+t*t)-a*t*t)
# Fixed-domain w(v): compare exponent after v=sqrt(a)y with mixed moment exponent.
ss=s.symbols('ss',nonnegative=True)
f=-(1+2*t*t)*y*y+2*t*y*s.sqrt(2*(1-ss*ss)+t*t*ss*ss*y*y)
zero('mixed moment exponent',-(1+t*t)*a*y*y-a*t*t*y*y+2*t*s.sqrt(a)*y*s.sqrt(2*a*(1-ss*ss)+a*t*t*y*y*ss*ss)-a*f)

# Historical original-file integrity is handled separately.
# Load only the included exact coefficient certificate for mathematical comparison.
NEW=BASE
claimed=json.loads((NEW/'POLYNOMIAL_CERTIFICATES.json').read_text())
for own_name,new_name in [('K','K'),('Q','D')]:
    polynomial=s.Poly(s.sympify(cert[own_name]['numerator'],locals={'b':b,'z':z}),b,z)
    for j,row in enumerate(claimed[new_name]['coefficient_rows']):
        zero(f'candidate {new_name} coefficient row {j}',polynomial.as_expr().expand().coeff(b,j)-sum(s.Integer(c)*z**k for k,c in enumerate(row)))
    zero('candidate '+new_name+' complete polynomial',polynomial.as_expr()-s.sympify(claimed[new_name]['numerator'],locals={'b':b,'z':z}))

# Independently check the candidate's alternative elementary certificates.
pi_lower=4*sum(sum((-1)**k*s.Rational(1,n)**(2*k+1)/s.Integer(2*k+1) for k in range(4)) for n in [2,3])
zero('candidate pi lower value',pi_lower-s.Rational(1538665,489888))
check('candidate pi lower exceeds 25/8',pi_lower>s.Rational(25,8))
zero('candidate pi upper positive integral',s.integrate(y**4*(1-y)**4/(1+y*y),(y,0,1))-(s.Rational(22,7)-s.pi))
exp_upper=sum(p**k/s.factorial(k) for k in range(7))+p**7/s.factorial(7)/(1-p/8)
zero('candidate exp upper value',exp_upper-s.Rational(3306347,229635))
check('candidate exp upper below 15',exp_upper<15)
L=s.Function('L'); H=s.Function('H'); v=s.symbols('v',positive=True)
zero('independent log P curvature',s.diff(s.log(a)+s.log(t)-a*(1+t*t)+L(s.sqrt(a)*t),t,2)-(-1/t**2-2*a+a*s.diff(L(d),d,2).subs(d,s.sqrt(a)*t)))
zero('independent log w score',s.diff(2*s.log(v)-(1+t*t)*v*v+H(t*v),t)-(-2*t*v*v+v*s.diff(H(d),d).subs(d,t*v)))
zero('independent log w curvature',s.diff(2*s.log(v)-(1+t*t)*v*v+H(t*v),t,2)-(-2*v*v+v*v*s.diff(H(d),d,2).subs(d,t*v)))
result={'status':'all_independent_exact_controls_passed' ,'checks':checks,'count':len(checks),
'positive_polynomial_certificates':cert,'floating_numerics_used':False,'original_source_checks_replayed':False}
(BASE/'INDEPENDENT_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':len(checks)}))
