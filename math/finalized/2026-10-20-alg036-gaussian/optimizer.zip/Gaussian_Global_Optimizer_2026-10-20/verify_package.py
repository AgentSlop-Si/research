#!/usr/bin/env python3
"""Offline exact replay, accepted-scope integrity and negative controls."""
from pathlib import Path, PurePosixPath
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
SOURCE_ANCHORS={'candidate/PROOF.md': {'source_id': 'completion/candidate/PROOF.md', 'source_sha256': '47793701643f3bd803897fd22468c7896519e4c2041c5ec36a5d02737bf4dcb2', 'source_bytes': 19563, 'core': {'start_after': '## 1. Contract, theorem, and accepted dependencies', 'end_before': '## 10. Verification boundary and provenance', 'sha256': '47147732388d3aba04a46f53d02c55a49c73d24a1e8e44298e80b5531070036f', 'bytes': 17881}, 'public_sha256': 'b95e2726e2f736c94f4ba890fcfe1b2e6e6436c32fbc492b78c25debd0893f52'}, 'history/COMPLETION_COLLABORATION.md': {'source_id': 'completion/COLLABORATION.md', 'source_sha256': 'cc50b226e57ad24c4e13e1b33e692085135cef0cd4217ab493ad372ca53fbcec', 'source_bytes': 1617, 'core': None, 'public_sha256': 'c13ce4d51b4a470996511733435cd37499088afe13d7de7d132fc5f7f3f1ba37'}, 'history/COMPLETION_REPORT.md': {'source_id': 'completion/REPORT.md', 'source_sha256': 'e185f4c524547da3b216b5297ba8a34db2047c459d295e77b4cbcb939032d490', 'source_bytes': 1907, 'core': None, 'public_sha256': 'e185f4c524547da3b216b5297ba8a34db2047c459d295e77b4cbcb939032d490'}, 'history/COMPLETION_SCOPE.json': {'source_id': 'completion/SCOPE.json', 'source_sha256': '7919d43f24d2fd380db4ebf2fd98d7f1f3abb83e1685b9d9ced7989861654b71', 'source_bytes': 706, 'core': None, 'public_sha256': '9521cb1929e6875a0ee3dbb158677e9dde010fac0f62a8d1a7dfb00c371d1c2c'}, 'controls/author/POLYNOMIAL_CERTIFICATES.json': {'source_id': 'completion/controls/POLYNOMIAL_CERTIFICATES.json', 'source_sha256': '6cb3c523b118d452fc820d6c7262e648daf64b0e053acb65f9977ec09e5e9800', 'source_bytes': 2612, 'core': None, 'public_sha256': '6cb3c523b118d452fc820d6c7262e648daf64b0e053acb65f9977ec09e5e9800'}, 'controls/author/POLYNOMIAL_CERTIFICATES.md': {'source_id': 'completion/controls/POLYNOMIAL_CERTIFICATES.md', 'source_sha256': 'a023e8bbc617ebfbd398a3ff78d8d61e6cecc067ed793454d10e9ff54140ce4e', 'source_bytes': 1191, 'core': None, 'public_sha256': 'a023e8bbc617ebfbd398a3ff78d8d61e6cecc067ed793454d10e9ff54140ce4e'}, 'controls/author/HISTORICAL_CONTROLS.json': {'source_id': 'completion/controls/EXACT_CONTROLS.json', 'source_sha256': '2039ee5f0d19d410968ec81e734c75bd7a071d70dac8c38c3030722b1f1241cb', 'source_bytes': 9325, 'core': None, 'public_sha256': '35499ed8b88b978743283fa112584077936ee930e16866631de3d7ff4d60d26f'}, 'controls/author/exact_controls.py': {'source_id': 'completion/controls/exact_controls.py', 'source_sha256': '2d3a0276aa778798f1a3c164b0dae2b91c32c0835c579549f9635135ea682ef3', 'source_bytes': 9824, 'core': None, 'public_sha256': 'd5956ba05ceb26a734992522cab66547c9340f89be71cf2ad3614422e0857477'}, 'reviews/fresh/REVIEW.md': {'source_id': 'fresh/REVIEW.md', 'source_sha256': '7a1eb894478a12a86244d9f2ebc1f4bcfbf37a243de73937f810e38414357492', 'source_bytes': 15607, 'core': {'start_after': '## Original model, ratio, and differentiations', 'end_before': '## Frozen-proof comparison, primary source, and replay', 'sha256': '7fa21f55bc992d216e19820b2c447b1464b5f7957ce28c05dec3ac24f1ec29f8', 'bytes': 8355}, 'public_sha256': '861d6429e5b20ecd94ea6cf3ec4032e69889a671e1f0d3e41c97a401db0afc0b'}, 'reviews/fresh/INDEPENDENT_RECONSTRUCTION.md': {'source_id': 'fresh/INDEPENDENT_RECONSTRUCTION.md', 'source_sha256': '6ddd57fee72922ad4e18b786311253097f09f6759e7908a20948ac391bad4c23', 'source_bytes': 9347, 'core': {'start_after': '## Original model, ratio, and differentiations', 'end_before': '## Provenance and current status', 'sha256': '7fa21f55bc992d216e19820b2c447b1464b5f7957ce28c05dec3ac24f1ec29f8', 'bytes': 8355}, 'public_sha256': '6ddd57fee72922ad4e18b786311253097f09f6759e7908a20948ac391bad4c23'}, 'reviews/fresh/VERDICT.json': {'source_id': 'fresh/VERDICT.json', 'source_sha256': '59d59fc3fa7153224624f21d56bd0ec5cfe268cb7124237fbbf6da9b33c07d94', 'source_bytes': 1208, 'core': None, 'public_sha256': '27679d51bc6222cbd17de5c704eaab753d9bdafa6f937637692f85cb002ccb45'}, 'reviews/fresh/HISTORICAL_CONTROLS.json': {'source_id': 'fresh/INDEPENDENT_CONTROLS.json', 'source_sha256': 'dab281b338f32488d34d1fad9dd8df66a727c4ea4dae0d4e46b1d0c1a0fb01e3', 'source_bytes': 22159, 'core': None, 'public_sha256': '8494acc8872c09b27aaeb487a9614a030f2222668e712e7d811a9f477872ed38'}, 'reviews/fresh/independent_controls.py': {'source_id': 'fresh/independent_controls.py', 'source_sha256': 'e3181ccc69cf30ba5b77426e296f5db59919f9ffff5129821d26219304a82d71', 'source_bytes': 8893, 'core': None, 'public_sha256': '7c05d907e803be3e7739b1330e21aa2117421ff3179d18653b95af32c8985353'}}
EXPECTED_RELEASE={'schema': 'gaussian-global-optimizer-release-v1', 'status': 'ACCEPTED_FULL_ORIGINAL_SCOPE', 'scope': 'N3_d2_centered_proper_complex_finite_positive_radius_global_optimizer', 'N': 3, 'complex_rank_d': 2, 'proper_complex_only': True, 'finite_positive_a_only': True, 'full_optimizer_closed': True, 'general_N_claimed': False, 'faster_FFT_claimed': False, 'candidate_proof_source_sha256': '47793701643f3bd803897fd22468c7896519e4c2041c5ec36a5d02737bf4dcb2', 'candidate_manifest_source_sha256': '54006ad6fddd89985a2610457e3ea70841a1e22c5dbaa99e9885c4dd3856038e', 'fresh_review_source_sha256': '7a1eb894478a12a86244d9f2ebc1f4bcfbf37a243de73937f810e38414357492', 'fresh_manifest_source_sha256': '3e58baddcc80938276d5f1ba3d5244e2ee9bbb207a3d143be08392683bd80529', 'prior_scalar_public_manifest_sha256': 'f75ce260afacc3f1a41e8d82da0a20c9e960f204597c617ca086f354e406464e', 'accepted': ['all_radius_strict_log_ratio_convexity', 'unique_nondegenerate_interior_scalar_minimum', 'strict_endpoint_only_scalar_domination', 'full_global_endpoint_only_optimizer_from_accepted_structural_reduction', 'unique_global_transition_from_accepted_endpoint_crossing', 'exact_two_endpoint_types_at_transition'], 'parameter': 'a=r^2', 'transition_bracket': ['1/2', '2'], 'fresh_independent_acceptance': True, 'corrections_required': False, 'historical_open_scalar_gap_superseded': True, 'not_claimed': ['general_N_or_other_rank_optimizer', 'real_Gaussian_analogue', 'strictness_at_zero_or_infinite_radius', 'faster_FFT_algorithm', 'historical_priority']}
EXPECTED_REPLAY={'controls': [{'directory': 'controls/author', 'script': 'exact_controls.py', 'outputs': ['EXACT_CONTROLS.json', 'POLYNOMIAL_CERTIFICATES.json', 'POLYNOMIAL_CERTIFICATES.md'], 'math_checks': 67}, {'directory': 'reviews/fresh', 'script': 'independent_controls.py', 'inputs': ['POLYNOMIAL_CERTIFICATES.json'], 'outputs': ['INDEPENDENT_CONTROLS.json'], 'math_checks': 63}], 'historical_author_checks': 85, 'historical_author_original_source_checks': 18, 'historical_fresh_checks': 143, 'historical_fresh_original_source_checks': 80, 'portable_new_math_checks': 130, 'prior_packet_math_checks': 225, 'total_math_checks': 355, 'dependency': 'dependencies/scalar/verify_package.py --replay --negative-controls --require-accepted'}
EXPECTED_BINDINGS={'sources': [{'role': 'accepted_scalar_lens_derivative_and_regular_coordinate', 'source_sha256': '502d0551a661fe9424775aa83c10858929c9ba9da4e966a2133b48a953789c32', 'source_bytes': 13649, 'public_path': 'dependencies/scalar/candidate/PROOF.md', 'included': True, 'theorem_dependency': True, 'public_sha256': 'a675e9c8ee995842eb75a5b850a61183c60b9da22721e40edd6cc784ac076ed0', 'public_bytes': 13692}, {'role': 'accepted_endpoint_stability_and_unique_crossing', 'source_sha256': '6fec6e5c708b6bddd3b5efdc74007d8cb9bf0cf2978aa89b2e0a137e06457d66', 'source_bytes': 14387, 'public_path': 'dependencies/scalar/endpoint_contribution/PROOF.md', 'included': True, 'theorem_dependency': True, 'public_sha256': '9380234e547690cb57d411e4249590ba1f40bfe4f3e3b261c144b010ba21ba07', 'public_bytes': 14437}, {'role': 'accepted_scalar_packet_manifest', 'source_sha256': '9aa32ed9e8ecf51f663e8185927c82cdee84e33687ba5b3daca1abc9eb986ca7', 'source_bytes': 2100, 'public_path': 'dependencies/scalar/provenance/original_manifests/scalar.json', 'included': True, 'theorem_dependency': True, 'public_sha256': '9aa32ed9e8ecf51f663e8185927c82cdee84e33687ba5b3daca1abc9eb986ca7', 'public_bytes': 2100}, {'role': 'fresh_acceptance_of_prior_scoped_scalar_packet', 'source_sha256': 'e85dc6ae11d0e563dd63d85ff21c7ca277c136fe03dc6f0b1dc523dcede7373b', 'source_bytes': 16683, 'public_path': 'dependencies/scalar/reviews/fresh/REVIEW.md', 'included': True, 'theorem_dependency': True, 'public_sha256': '1b74627f7454b99f815824cfbe5148f28d331af94080811b083dd6440ae18d19', 'public_bytes': 16962}, {'role': 'prior_scalar_acceptance_verdict', 'source_sha256': '9d9a4c64c9f352a0a66394dfdd81916eec2c1156000470a7a23073ce528747f1', 'source_bytes': 1434, 'public_path': 'dependencies/scalar/reviews/fresh/VERDICT.json', 'included': True, 'theorem_dependency': True, 'public_sha256': 'c412ab20aea528137f1eadfaa97de935f9153c241556b11607a6e023f0f85203', 'public_bytes': 1377}, {'role': 'accepted_all_radius_strict_structural_reduction', 'source_sha256': 'c992118d24465076fae1e708725dfd77c82ac5d654c904f976bb7299531692a1', 'source_bytes': 12095, 'public_path': 'dependencies/scalar/dependencies/structural/candidate/PROOF.md', 'included': True, 'theorem_dependency': True, 'public_sha256': '44ffb29cb1df9faefa4e1b1088944ec5ad32bed3f76ed6e1171ce847560675bf', 'public_bytes': 12181}, {'role': 'structural_fresh_acceptance', 'source_sha256': 'fde938fe8939b3cc35df918b730b5ff5bdd7725927e826b591dd0d96fb85a21c', 'source_bytes': 13471, 'public_path': 'dependencies/scalar/dependencies/structural/reviews/fresh/REVIEW.md', 'included': True, 'theorem_dependency': True, 'public_sha256': 'cc17f75f548880686a92a9810057adc63c1bef17a84af566f84e6764f3726ce0', 'public_bytes': 13626}, {'role': 'structural_acceptance_verdict', 'source_sha256': 'f1516513c7b6676613778e1dc7e537799ba5a4478684e9c2546f1c874244c39e', 'source_bytes': 1051, 'public_path': 'dependencies/scalar/dependencies/structural/reviews/fresh/VERDICT.json', 'included': True, 'theorem_dependency': True, 'public_sha256': '07240ed6fecd9b4046fca08794e2ad2b05dabfefeaa831e8f33e310e206db2ad', 'public_bytes': 998}, {'role': 'unproved_research_lead_not_a_theorem_dependency', 'source_sha256': 'ab8cb7da10cef26db11b84ac6827b825ac8e78c95ccfabf5dde4d5dd66b62221', 'source_bytes': 10725, 'public_path': None, 'included': False, 'theorem_dependency': False, 'reason': 'Unproved common research lead is provenance only, not an accepted theorem or premise; its identity is retained without publishing an internal research note.'}], 'external_theorems': [{'author': 'András Prékopa', 'title': 'On logarithmic concave measures and functions', 'publication': 'Acta Scientiarum Mathematicarum 34 (1973), 335–343', 'result': 'Theorem 6, printed page 342: marginalization preserves log-concavity', 'url': 'https://acta.bibl.u-szeged.hu/14411/1/math_034_335-343.pdf', 'repository_record': 'https://acta.bibl.u-szeged.hu/14411/', 'verified_date_utc': '2026-10-20'}], 'mathematical_dependencies_included': True, 'inherited_files_modified': False}
ORIGINAL_MANIFESTS={'completion':'54006ad6fddd89985a2610457e3ea70841a1e22c5dbaa99e9885c4dd3856038e','fresh':'3e58baddcc80938276d5f1ba3d5244e2ee9bbb207a3d143be08392683bd80529'}
PRIOR_MANIFEST='f75ce260afacc3f1a41e8d82da0a20c9e960f204597c617ca086f354e406464e'
FRESH_INTEGRITY_PREFIXES=('source hash ','manifest hash ','manifest size ','inherited source binding ','new candidate exact ','new manifest hash ','new manifest bytes ','new source hash ','new source bytes ')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def need(c,m):
 if not c:raise ValueError(m)
def safe(root,name):
 need(isinstance(name,str),'Nonstring member.')
 r=PurePosixPath(name)
 need(bool(r.parts) and not r.is_absolute() and '..' not in r.parts and str(r)==name,'Unsafe member path.')
 p=root/name
 need(not p.is_symlink() and p.is_file(),'Missing or symbolic-link member: '+name)
 need(root in p.resolve().parents,'Member escapes package.')
 return p

def check_manifest(root,expected=None):
 mb=(root/'MANIFEST.json').read_bytes();digest=sha(mb)
 if expected is not None:need(digest==expected,'Externally trusted digest mismatch.')
 need((root/'MANIFEST.sha256').read_text().split()==[digest,'MANIFEST.json'],'Manifest seal mismatch.')
 m=json.loads(mb)
 need(m.get('schema')=='gaussian-global-optimizer-portable-v1','Manifest schema drift.')
 need(m.get('status')=='ACCEPTED_FULL_ORIGINAL_SCOPE','Manifest acceptance drift.')
 names=[]
 for e in m['files']:
  name=e['path'];need(name not in names,'Duplicate manifest member.');names.append(name)
  b=safe(root,name).read_bytes();need(sha(b)==e['sha256'] and len(b)==e['bytes'],'Member bytes/hash mismatch: '+name)
 actual=[]
 for p in root.rglob('*'):
  need(not p.is_symlink(),'Symbolic links forbidden.')
  if p.is_file():actual.append(p.relative_to(root).as_posix())
 need(set(actual)==set(names)|{'MANIFEST.json','MANIFEST.sha256'},'Unlisted or missing members.')
 # Generic private-location and execution-coordination markers, encoded only to avoid self-match.
 forbidden=[bytes.fromhex(x) for x in ['2f776f726b73706163652f','2f686f6d652f6167656e742f','202f726f6f742f','602f726f6f742f','636f6c6c61626f726174696f6e2e73656e645f6d657373616765','636c6f75645f746872656164732e','636f6465783a2f2f746872656164732f','7375626167656e74','636f6f7264696e6174696e6720706172656e74']]
 for name in names:
  need(not any(x in (root/name).read_bytes() for x in forbidden),'Private path or coordination marker: '+name)
 return digest,len(names)

def verify(root,expected=None,replay=False,require_accepted=False,dependency=True):
 root=root.resolve();digest,count=check_manifest(root,expected)
 release=read(root/'RELEASE.json');need(release==EXPECTED_RELEASE,'Accepted scope, source binding or exclusion drift.')
 verdict=read(root/'reviews/fresh/VERDICT.json')
 need(verdict.get('verdict')=='ACCEPT' and verdict.get('status')=='fresh_independent_source_bound_acceptance','Fresh independent acceptance missing.')
 need(verdict.get('candidate_proof_sha256')==release['candidate_proof_source_sha256'] and verdict.get('candidate_manifest_sha256')==ORIGINAL_MANIFESTS['completion'],'Fresh candidate binding drift.')
 need(verdict.get('accepted_claims')==release['accepted'] and verdict.get('required_corrections')==[],'Fresh review scope/corrections drift.')
 need(verdict.get('new_structural_lemma_or_proof_repair_supplied') is False,'Review independence boundary drift.')
 need(verdict.get('author_generated_outputs_byte_identical') is True,'Historical author replay no longer asserted.')
 original={}
 for label,d in ORIGINAL_MANIFESTS.items():
  p=root/'provenance/original_manifests'/f'{label}.json';need(sha(p.read_bytes())==d,'Historical manifest identity mismatch.')
  for e in read(p)['files']:original[label+'/'+e['path']]=e
 proj=read(root/'provenance/PROJECTIONS.json');need(proj.get('mathematics_unchanged') is True,'Projection mathematics flag changed.')
 records={}
 for r in proj['records']:
  name=r['public_path'];need(name not in records,'Duplicate projection member.');records[name]=r
  need(name in SOURCE_ANCHORS,'Unexpected projected source.')
  anchor=SOURCE_ANCHORS[name];b=safe(root,name).read_bytes()
  need(r['source_id']==anchor['source_id'],'Projection source label drift.')
  o=original[r['source_id']]
  need(r['source_sha256']==o['sha256']==anchor['source_sha256'] and r['source_bytes']==o['bytes']==anchor['source_bytes'],'Historical projected source identity drift.')
  need(r['public_sha256']==sha(b)==anchor['public_sha256'] and r['public_bytes']==len(b),'Public projection or pinned source bytes drift: '+name)
  need(r['byte_identical']==(r['source_sha256']==r['public_sha256'] and r['source_bytes']==r['public_bytes']),'Incorrect byte-identical label.')
  core=anchor['core']
  if core:
   need(r.get('unchanged_analytic_core')==core,'Fixed analytic-core anchor changed.')
   text=b.decode();need(text.count(core['start_after'])==1 and text.count(core['end_before'])==1,'Ambiguous analytic-core markers.')
   cb=text.split(core['start_after'],1)[1].split(core['end_before'],1)[0].encode()
   need(sha(cb)==core['sha256'] and len(cb)==core['bytes'],'Analytic-core bytes changed.')
 need(set(records)==set(SOURCE_ANCHORS),'Missing projected source.')
 bindings=read(root/'SOURCE_BINDINGS.json');need(bindings==EXPECTED_BINDINGS,'Dependency source/role binding drift.')
 for b in bindings['sources']:
  if b['included']:
   p=safe(root,b['public_path']);need(sha(p.read_bytes())==b['public_sha256'] and p.stat().st_size==b['public_bytes'],'Dependency projected bytes drift.')
  else:need(b['theorem_dependency'] is False and b['role']=='unproved_research_lead_not_a_theorem_dependency','Missing theorem dependency.')
 preservation=read(root/'provenance/SOURCE_PRESERVATION.json')
 need(preservation.get('all_unchanged') is True and all(r.get('unchanged') is True for r in preservation['source_identities']),'Source preservation not confirmed.')
 preserved={(r['source_id'],r['sha256'],r['bytes']) for r in preservation['source_identities']}
 for name,a in SOURCE_ANCHORS.items():need((a['source_id'],a['source_sha256'],a['source_bytes']) in preserved,'Missing preservation source record.')
 hist=read(root/'controls/author/HISTORICAL_CONTROLS.json');author=read(root/'controls/author/EXACT_CONTROLS.json')
 math=[c for c in hist['checks'] if not c['name'].startswith('source_')]
 need(hist['count']==len(hist['checks'])==85 and len(math)==67,'Author historical control count drift.')
 need(all(c['pass'] for c in hist['checks']) and author['checks']==math and author['count']==67 and author['all_pass'] is True,'Author exact mathematical-row drift.')
 fresh_hist=read(root/'reviews/fresh/HISTORICAL_CONTROLS.json');fresh=read(root/'reviews/fresh/INDEPENDENT_CONTROLS.json')
 fm=[c for c in fresh_hist['checks'] if not c['name'].startswith(FRESH_INTEGRITY_PREFIXES)]
 need(fresh_hist['count']==len(fresh_hist['checks'])==143 and len(fm)==63,'Fresh historical count drift.')
 need(all(c['passed'] for c in fresh_hist['checks']) and fresh['checks']==fm and fresh['count']==63,'Fresh mathematical-row drift.')
 need(fresh['positive_polynomial_certificates']==fresh_hist['positive_polynomial_certificates'],'Independent polynomial certificate drift.')
 need((root/'reviews/fresh/POLYNOMIAL_CERTIFICATES.json').read_bytes()==(root/'controls/author/POLYNOMIAL_CERTIFICATES.json').read_bytes(),'Fresh certificate input drift.')
 spec=read(root/'REPLAY.json');need(spec==EXPECTED_REPLAY,'Replay specification drift.')
 results=[]
 if replay:
  for item in spec['controls']:
   with tempfile.TemporaryDirectory(prefix='gaussian-control-') as td:
    work=Path(td);folder=root/item['directory'];script=item['script']
    for name in [script]+item.get('inputs',[]):shutil.copy2(folder/name,work/name)
    env=os.environ.copy();env.pop('PYTHONPATH',None);env['PYTHONDONTWRITEBYTECODE']='1'
    p=subprocess.run([sys.executable,'-I',script],cwd=work,env=env,capture_output=True,text=True,timeout=240)
    need(p.returncode==0,'Exact control failed: '+script+'\n'+p.stdout+'\n'+p.stderr)
    for out in item['outputs']:need((work/out).read_bytes()==(folder/out).read_bytes(),'Exact output mismatch: '+item['directory']+'/'+out)
    results.append({'script':item['directory']+'/'+script,'mathematical_checks':item['math_checks'],'all_outputs_byte_identical':True})
 prior=None
 if dependency:
  with tempfile.TemporaryDirectory(prefix='gaussian-dependency-') as td:
   dep=Path(td)/'scalar';shutil.copytree(root/'dependencies/scalar',dep)
   cmd=[sys.executable,'-I',str(dep/'verify_package.py'),'--require-accepted','--expected-manifest-sha256',PRIOR_MANIFEST]
   if replay:cmd+=['--replay','--negative-controls']
   p=subprocess.run(cmd,cwd=dep,capture_output=True,text=True,timeout=600)
   need(p.returncode==0,'Prior accepted packet failed.\n'+p.stdout+'\n'+p.stderr)
   prior=json.loads(p.stdout);need(prior['all_pass'] is True and prior['combined_mathematical_checks']==225,'Dependency mathematical replay mismatch.')
 else:need(sha((root/'dependencies/scalar/MANIFEST.json').read_bytes())==PRIOR_MANIFEST,'Prior dependency seal mismatch.')
 return {'all_pass':True,'manifest_sha256':digest,'manifest_members':count,'archive_files':count+2,'release_status':release['status'],'full_optimizer_closed':True,'scope':release['scope'],'new_author_mathematical_checks':67,'new_fresh_mathematical_checks':63,'prior_mathematical_checks':225,'total_mathematical_checks':355,'historical_new_author_total':85,'historical_new_fresh_total':143,'historical_new_original_source_checks_not_replayed':98,'replays':results,'prior_dependency':prior}

def reseal(root):
 m=read(root/'MANIFEST.json')
 for e in m['files']:
  b=(root/e['path']).read_bytes();e.update(bytes=len(b),sha256=sha(b))
 b=(json.dumps(m,indent=2,ensure_ascii=False)+'\n').encode();(root/'MANIFEST.json').write_bytes(b)
 (root/'MANIFEST.sha256').write_text(sha(b)+'  MANIFEST.json\n')

def negative_controls(root):
 rows=[]
 def run(name,mutate,refresh=False,expected=None):
  with tempfile.TemporaryDirectory(prefix='gaussian-negative-') as td:
   p=Path(td)/'packet';shutil.copytree(root,p);mutate(p)
   if refresh:reseal(p)
   try:verify(p,expected=expected,dependency=False)
   except (ValueError,KeyError,FileNotFoundError,json.JSONDecodeError,StopIteration) as e:rows.append({'name':name,'rejected':True,'reason':str(e)})
   else:raise ValueError('Negative control accepted: '+name)
 def jchange(p,name,key,value):
  j=read(p/name);j[key]=value;(p/name).write_text(json.dumps(j))
 def update_projection(p,name):
  j=read(p/'provenance/PROJECTIONS.json');r=next(r for r in j['records'] if r['public_path']==name);b=(p/name).read_bytes();r.update(public_sha256=sha(b),public_bytes=len(b));(p/'provenance/PROJECTIONS.json').write_text(json.dumps(j))
 run('altered_completion_proof',lambda p:(p/'candidate/PROOF.md').write_bytes((p/'candidate/PROOF.md').read_bytes()+b'\n'))
 run('missing_completion_proof',lambda p:(p/'candidate/PROOF.md').unlink())
 run('unsealed_extra_member',lambda p:(p/'unexpected.txt').write_text('extra'))
 run('resealed_pending_release',lambda p:jchange(p,'RELEASE.json','status','PENDING'),True)
 run('resealed_general_N_overclaim',lambda p:jchange(p,'RELEASE.json','general_N_claimed',True),True)
 run('resealed_faster_FFT_overclaim',lambda p:jchange(p,'RELEASE.json','faster_FFT_claimed',True),True)
 run('resealed_wrong_model_rank',lambda p:jchange(p,'RELEASE.json','complex_rank_d',3),True)
 run('resealed_wrong_proof_source',lambda p:jchange(p,'RELEASE.json','candidate_proof_source_sha256','0'*64),True)
 run('resealed_missing_fresh_acceptance',lambda p:jchange(p,'reviews/fresh/VERDICT.json','verdict','PENDING'),True)
 run('resealed_nonindependent_review',lambda p:jchange(p,'reviews/fresh/VERDICT.json','new_structural_lemma_or_proof_repair_supplied',True),True)
 run('external_trusted_digest_mismatch',lambda p:None,expected='0'*64)
 run('resealed_projection_mismatch',lambda p:(p/'candidate/PROOF.md').write_bytes((p/'candidate/PROOF.md').read_bytes()+b'\n'),True)
 def core_drift(p):
  f=p/'candidate/PROOF.md';f.write_text(f.read_text().replace('659/31185','658/31185'));update_projection(p,'candidate/PROOF.md')
 run('resealed_math_core_drift_with_projection_updated',core_drift,True)
 run('resealed_dependency_manifest_drift',lambda p:(p/'dependencies/scalar/MANIFEST.json').write_bytes((p/'dependencies/scalar/MANIFEST.json').read_bytes()+b'\n'),True)
 run('resealed_source_binding_omission',lambda p:jchange(p,'SOURCE_BINDINGS.json','sources',[]),True)
 def row_drift(p):
  j=read(p/'reviews/fresh/INDEPENDENT_CONTROLS.json');j['checks'][0]['name']='altered';(p/'reviews/fresh/INDEPENDENT_CONTROLS.json').write_text(json.dumps(j))
 run('resealed_mathematical_row_drift',row_drift,True)
 def unsafe(p):
  j=read(p/'MANIFEST.json');j['files'][0]['path']='../outside.txt';(p/'MANIFEST.json').write_text(json.dumps(j));(p/'MANIFEST.sha256').write_text(sha((p/'MANIFEST.json').read_bytes())+'  MANIFEST.json\n')
 run('path_traversal_manifest',unsafe)
 def duplicate(p):
  j=read(p/'MANIFEST.json');j['files'].append(j['files'][0]);(p/'MANIFEST.json').write_text(json.dumps(j));(p/'MANIFEST.sha256').write_text(sha((p/'MANIFEST.json').read_bytes())+'  MANIFEST.json\n')
 run('duplicate_manifest_member',duplicate)
 run('resealed_false_source_preservation',lambda p:jchange(p,'provenance/SOURCE_PRESERVATION.json','all_unchanged',False),True)
 run('resealed_historical_check_count_as_math',lambda p:jchange(p,'REPLAY.json','portable_new_math_checks',228),True)
 return rows

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--replay',action='store_true');ap.add_argument('--negative-controls',action='store_true');ap.add_argument('--require-accepted',action='store_true');ap.add_argument('--expected-manifest-sha256');args=ap.parse_args()
 try:
  result=verify(ROOT,args.expected_manifest_sha256,args.replay,args.require_accepted)
  if args.negative_controls:result['negative_controls']=negative_controls(ROOT)
  print(json.dumps(result,indent=2))
 except Exception as e:
  print(json.dumps({'all_pass':False,'error':str(e)},indent=2));sys.exit(1)
