# Complete dependency chain

The entire earlier accepted public scalar packet is included byte for byte at dependencies/scalar, with manifest SHA-256 f75ce260afacc3f1a41e8d82da0a20c9e960f204597c617ca086f354e406464e. Its own structural packet has manifest SHA-256 85008206156b6eed3c0585900efa450793617987b1e157da7ab4dc4694e2c839. This duplication-free nesting carries every needed proof, review and exact control.

- dependencies/scalar/candidate/PROOF.md supplies the finite Gaussian lens derivative, regular t coordinate, block cusp and endpoint facts.
- dependencies/scalar/endpoint_contribution/PROOF.md supplies the strict symmetric tangent Hessian and the unique transverse endpoint crossing, including 1/2<a_*<2. Its separate fresh scoped acceptance is included under dependencies/scalar/reviews/fresh.
- dependencies/scalar/dependencies/structural/candidate/PROOF.md supplies strict largest-pair smoothing and the global two-equal reduction/equality classification. Its fresh acceptance and collaborative attribution remain included.
- dependencies/scalar/dependencies/structural/dependencies/stationary/REPORT.md supplies the boundary formula and C² regularity used by the endpoint argument, with its original review and controls.

The completion proof then supplies strict log-ratio convexity, the unique nondegenerate minimum, strict scalar endpoint dominance and the resulting exact global optimizer classification. Its source dependency identities and public locators are SOURCE_BINDINGS.json.

Prékopa's marginal log-concavity theorem is the one external theorem used in the new argument: Theorem 6, printed page 342 of the 1973 paper linked directly in the proof and SOURCE_BINDINGS.json. Its hypotheses are checked for the convex Gaussian lens. Offline replay is of the supplied proof and finite controls, not an automated verification of an external paper. Earlier stationary technical citations and their precise roles remain in the nested packet.

The original unproved lead is identity-only provenance, not a theorem dependency or an accepted claim. Earlier effective bounds, localization and centering are preserved background and are not silently extended. Previous scalar-open status statements remain unchanged as dated history; this release supersedes the specific resolved scalar gap, not every earlier research question.
