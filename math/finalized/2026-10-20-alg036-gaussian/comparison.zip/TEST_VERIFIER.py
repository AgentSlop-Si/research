#!/usr/bin/env python3
"""Repeat isolated integrity negative controls; never modifies this packet."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import warnings
import zipfile

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / 'VERIFY_PACKET.py'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(path):
    p = subprocess.run([sys.executable, '-I', '-B', str(VERIFY), str(path)], text=True, capture_output=True)
    obj = json.loads(p.stdout)
    return p.returncode, obj

def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def reseal(folder, target):
    """Deliberately rehash a semantic mutation to test beyond byte checking."""
    bpath = folder/'SOURCE_BINDINGS.json'
    obj = json.loads(bpath.read_text())
    for r in obj['source_files']:
        if r['public_file'] == target:
            b=(folder/target).read_bytes()
            r.update(public_bytes=len(b),public_sha256=sha(b),byte_identical=False)
    write_json(bpath,obj)
    path=folder/'MANIFEST.json'; obj=json.loads(path.read_text())
    for e in obj['files']:
        b=(folder/e['path']).read_bytes(); e.update(bytes=len(b),sha256=sha(b))
    write_json(path,obj)
    (folder/'MANIFEST.sha256').write_text(sha(path.read_bytes())+'  MANIFEST.json\n')

def main():
    rc, baseline = run(ROOT)
    if rc: raise RuntimeError('clean baseline did not pass')
    results=[]
    with tempfile.TemporaryDirectory(prefix='gaussian-public-negative-') as tmp:
        tmp=Path(tmp)
        def trial(label,mutate):
            folder=tmp/label; shutil.copytree(ROOT,folder)
            target=mutate(folder) or folder
            rc,out=run(target)
            if rc==0 or out['status']!='FAIL': raise RuntimeError('negative control accepted: '+label)
            results.append({'control':label,'rejected':True,'reason':out['reason']})
        def change_math(p):
            f=p/'COMPARISON.md';f.write_bytes(f.read_bytes().replace(b'a_* in (1/2,2)',b'a_* in (1/2,3)',1))
        trial('changed_math_byte',change_math)
        trial('missing_supplement',lambda p:(p/'ORIGINAL_CONTRACT_SUPPLEMENT.md').unlink())
        def extra(p): (p/'PRIVATE_EVIDENCE.txt').write_text('negative control only\n')
        trial('extra_private_evidence',extra)
        def digest(p): (p/'MANIFEST.sha256').write_text('0'*64+'  MANIFEST.json\n')
        trial('changed_manifest_digest',digest)
        def clear_gap(p):
            f=p/'SOURCE_REGISTER.json';o=json.loads(f.read_text())
            next(s for s in o['sources'] if s['id']=='G01')['disposition']='cleared_nonmatch'
            write_json(f,o);reseal(p,'SOURCE_REGISTER.json')
        trial('rehashed_gap_clearance',clear_gap)
        def novelty(p):
            f=p/'SCOPE.json';o=json.loads(f.read_text());o['worldwide_novelty_claimed']=True
            write_json(f,o);reseal(p,'SCOPE.json')
        trial('rehashed_worldwide_novelty',novelty)
        def symlink(p):
            f=p/'COMPARISON.md';f.unlink();f.symlink_to(ROOT/'COMPARISON.md')
        trial('symlink_member',symlink)
        def bad_zip(p):
            target=tmp/'traversal.zip'
            with zipfile.ZipFile(target,'w') as z:
                for f in p.iterdir(): z.writestr(f.name,f.read_bytes())
                z.writestr('../outside.txt','negative control')
            return target
        trial('zip_path_traversal',bad_zip)
        def dup_zip(p):
            target=tmp/'duplicate.zip'
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',UserWarning)
                with zipfile.ZipFile(target,'w') as z:
                    for f in p.iterdir():z.writestr(f.name,f.read_bytes())
                    z.writestr('README.md',(p/'README.md').read_bytes())
            return target
        trial('duplicate_zip_member',dup_zip)
    print(json.dumps({'status':'PASS','baseline_files':baseline['files'],'negative_controls':results,'all_rejected':True},indent=2))

if __name__=='__main__':
    main()
