# Gaussian optimizer and measurement rank source comparison

This is a portable public-safe projection of an accepted bounded literature comparison, dated 20 October 2026. It covers the exact proper-complex Gaussian N=3, d=2 all-radius optimizer and a separate original measurement-rank, norm, sampling, and cost supplement. The included independent review accepts the bounded comparison, not worldwide priority, exhaustive novelty clearance, or closure of the broader project.

## Read in this order

1. REVIEW.md and VERDICT.json: accepted result and its exact limits.
2. COMPARISON.md: optimizer theorem, normalization bridges, ten source comparisons, and König–Koldobsky access gap.
3. ORIGINAL_CONTRACT_SUPPLEMENT.md: original information model, norm conversion, cost distinctions, inherited HIKP comparison, and Wasilkowski 1986 access gap.
4. SOURCE_REGISTER.json and SEARCH_SCOPE.json: source catalogue, theorem locators, versions, bounded search, and access qualifications.
5. RIGHTS_AND_ACCESS.md and EXTERNAL_LINKS.json: rights posture, link checks, and access restrictions.
6. SOURCE_BINDINGS.json and PROJECTION_AUDIT.json: original accepted identities and the privacy/portability-only projection.

The candidate's pending-review labels in COMPARISON.md, the supplement, and SCOPE.json are retained historical metadata. REVIEW.md and VERDICT.json supersede only that review status. Source SHA-256 values in the review and verdict identify the original accepted source files, not the projected export bytes. The public export hashes are in MANIFEST.json and SOURCE_BINDINGS.json. Original source files were not modified.

## Qualifications that must travel with this packet

- König–Koldobsky 2013 (G01) and Wasilkowski 1986 (OG01) remain material unresolved primary-access leads, not verified nonmatches.
- Oleszkiewicz–Pełczyński (S02) was checked through its publisher abstract and the accessible later primary paper, not its original full text.
- The mathematical optimizer proof is a separately accepted dependency, not re-proved or fully archived here.
- The earlier HIKP certificate and review links exist at the named commit, but their repository is private. They are restricted provenance links. This packet does not redistribute their contents or promise public access.
- No external literature PDFs, native workflow evidence, private histories, or original assembly scripts are included. This packaging work performed no external write or upload.

## Verify without the source workspace or network

Python 3 standard library only, with no installation needed. From this directory run:

    python3 -I -B VERIFY_PACKET.py .

To check the exact archive without extracting it, run the verifier against the ZIP path:

    python3 -I -B VERIFY_PACKET.py ../alg036_public_comparison_20261020_0652.zip

The verifier checks an exact file inventory, SHA-256 hashes, byte counts, source/public bindings, and retained scope/access safeguards. It rejects extra files, missing files, unsafe paths, symlinks, malformed manifests, and altered qualifications. It does not fetch URLs, execute mathematical proof programs, establish authorship, validate external source claims, or assert completeness of the literature.

Run portable negative controls in isolated temporary directories:

    python3 -I -B TEST_VERIFIER.py

SHA-256 detects corruption against a trusted digest, not authorship. Compare the archive hash with the separately supplied receipt before trusting the bundled checker. A malicious party replacing both manifest and verifier is outside the protection of an unsigned self-contained packet.
