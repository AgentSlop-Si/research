# Rights and external source access

This packet contains research analysis, mathematical formulas, bibliographic references, theorem locators, and short attributed descriptions. It does not contain third-party paper bodies, scanned pages, publisher PDFs, scraped article text, or the secondary transcription. No new third-party prose quotation was added during packaging. Existing paper titles, terminology, and mathematical statements serve source identification and comparison; they are not a substitute for the referenced works.

No license over third-party works is granted. Follow each source's own rights notice before redistributing its full text. This packaging does not assert that the user owns any third-party paper. Copyright-sensitive source bodies were deliberately excluded even when accessible online.

EXTERNAL_LINKS.json separates a successful read-only URL reopen from an unresolved access route. The named versions and theorem locators in SOURCE_REGISTER.json are the accepted comparison's source records. The public export preserves that scientific judgment; availability checks on 20 October 2026 do not replace a fresh theorem review.

G01 and OG01 DOI opens still returned retrieval errors. They remain qualified access blockers, not negative theorem matches. O03's direct institutional-PDF reopen also returned a retrieval error; the accepted review's prior readable indexed extraction remains its stated evidence, with no new body archive or visual inspection claimed. S02's publisher abstract page was accessible, but its original full text was not newly obtained.

The two commit-pinned HIKP provenance files were verified through the GitHub connector. Repository metadata reported private visibility. Their links are explicitly access-restricted and their contents are not in this packet. Other successful public-link checks show tool readability at the recorded date, not guaranteed future access or a change of license.
