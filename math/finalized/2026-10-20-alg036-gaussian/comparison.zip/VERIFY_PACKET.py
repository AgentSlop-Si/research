#!/usr/bin/env python3
"""Offline byte integrity and bounded-scope checks for this exact public packet.

Usage: python3 -I -B VERIFY_PACKET.py [directory-or-zip]
No network, third-party dependencies, source workspace, writes, or proof execution.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat
import sys
import zipfile

FILES = frozenset({
    'COMPARISON.md', 'ORIGINAL_CONTRACT_SUPPLEMENT.md', 'SOURCE_REGISTER.json',
    'SEARCH_SCOPE.json', 'SCOPE.json', 'REVIEW.md', 'VERDICT.json', 'README.md',
    'SOURCE_BINDINGS.json', 'PROJECTION_AUDIT.json', 'EXTERNAL_LINKS.json',
    'RIGHTS_AND_ACCESS.md', 'VERIFY_PACKET.py', 'TEST_VERIFIER.py',
    'MANIFEST.json', 'MANIFEST.sha256',
})
SOURCE_FILES = frozenset({
    'COMPARISON.md', 'ORIGINAL_CONTRACT_SUPPLEMENT.md', 'SOURCE_REGISTER.json',
    'SEARCH_SCOPE.json', 'SCOPE.json', 'REVIEW.md', 'VERDICT.json',
})
SOURCE_MANIFESTS = {
    'candidate': '7edd332d021f4d0e72b7fcfd415ac074cdcea1c6e27d3b00f1feefa76cdad3ed',
    'review': 'bc425c9bcfafdf8db0b81a2b626f02319383d0d020224d0538f3e43b8c87f17d',
}
MAX_BYTES = 5_000_000

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def no_duplicate_keys(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, 'duplicate JSON key: ' + key)
        obj[key] = value
    return obj

def parse(data):
    return json.loads(data.decode('utf-8'), object_pairs_hook=no_duplicate_keys)

def safe_name(name):
    p = PurePosixPath(name)
    require(name in FILES and len(p.parts) == 1 and not p.is_absolute(), 'unapproved or unsafe path: ' + name)
    require('\\' not in name and '\x00' not in name, 'unsafe path encoding')

def load(path):
    require(not path.is_symlink(), 'input must not be a symlink')
    members = {}
    if path.is_dir():
        for child in path.iterdir():
            safe_name(child.name)
            require(child.is_file() and not child.is_symlink(), 'non-regular file: ' + child.name)
            require(child.stat().st_size <= MAX_BYTES, 'oversized file')
            members[child.name] = child.read_bytes()
    elif path.is_file() and zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            require(z.comment == b'', 'unexpected ZIP comment')
            for entry in z.infolist():
                name = entry.filename
                safe_name(name)
                require(name not in members, 'duplicate archive member: ' + name)
                require(not entry.is_dir(), 'directory entry is not allowed')
                mode = (entry.external_attr >> 16) & 0o170000
                require(mode in (0, stat.S_IFREG), 'non-regular archive member: ' + name)
                require(not (entry.flag_bits & 1), 'encrypted archive member')
                require(entry.file_size <= MAX_BYTES, 'oversized archive member')
                members[name] = z.read(entry)
    else:
        raise ValueError('expected directory or ZIP file')
    require(set(members) == FILES, 'file inventory mismatch')
    require(sum(map(len, members.values())) <= MAX_BYTES, 'packet too large')
    return members

def verify(path):
    members = load(path)
    digest_line = members['MANIFEST.sha256'].decode('ascii')
    expected_line = sha(members['MANIFEST.json']) + '  MANIFEST.json\n'
    require(digest_line == expected_line, 'manifest checksum mismatch')
    manifest = parse(members['MANIFEST.json'])
    require(manifest['format'] == 'alg036_public_comparison_manifest_v1', 'manifest format mismatch')
    require(manifest['math_claims_changed'] is False, 'mathematical claims change flag')
    require(manifest['external_write_performed'] is False, 'unexpected external write flag')
    entries = manifest['files']
    require(len(entries) == len(FILES) - 2, 'manifest entry count mismatch')
    names = [e['path'] for e in entries]
    require(len(set(names)) == len(names), 'duplicate manifest entry')
    require(set(names) == FILES - {'MANIFEST.json', 'MANIFEST.sha256'}, 'manifest inventory mismatch')
    for entry in entries:
        name = entry['path']
        safe_name(name)
        data = members[name]
        require(type(entry['bytes']) is int and len(data) == entry['bytes'], 'byte count mismatch: ' + name)
        require(re.fullmatch('[0-9a-f]{64}', entry['sha256']) is not None, 'invalid SHA-256')
        require(sha(data) == entry['sha256'], 'file checksum mismatch: ' + name)
        data.decode('utf-8')
    scope = parse(members['SCOPE.json'])
    verdict = parse(members['VERDICT.json'])
    require(scope['whole_owner_closed'] is False and scope['historical_attribution_gate_closed'] is False,
            'scope closure qualification changed')
    require(scope['worldwide_novelty_claimed'] is False, 'worldwide novelty qualification changed')
    require(verdict['decision'] == 'ACCEPT_BOUNDED_SOURCE_COMPARISON', 'acceptance changed')
    for key in ('optimizer_comparison_accepted', 'original_contract_supplement_accepted', 'recorded_bounded_comparison_stop_satisfied'):
        require(verdict[key] is True, 'accepted scope changed: ' + key)
    for key in ('historical_priority_cleared', 'complete_model_matched_novelty_cleared', 'whole_owner_closed', 'new_publication', 'external_mutation'):
        require(verdict[key] is False, 'retained qualification changed: ' + key)
    require(verdict['candidate_manifest_sha256'] == SOURCE_MANIFESTS['candidate'], 'source acceptance identity changed')
    register = parse(members['SOURCE_REGISTER.json'])
    sources = register['sources']
    require(len(sources) == 15 and len({s['id'] for s in sources}) == 15, 'source catalogue count mismatch')
    indexed = {s['id']: s for s in sources}
    require(indexed['G01']['access'] == 'primary_full_text_access_gap' and indexed['G01']['disposition'] == 'not_cleared', 'G01 blocker qualification changed')
    require(indexed['OG01']['access'] == 'author_institutional_abstract_only_primary_fulltext_gap' and indexed['OG01']['disposition'] == 'material_gaussian_adaptivity_overlap_lead_not_cleared', 'OG01 blocker qualification changed')
    require(indexed['S02']['access'] == 'primary_abstract_only', 'S02 full-text qualification changed')
    require(all(s['local_primary_body_sha256'] is None for s in sources), 'unverified primary body hash added')
    bindings = parse(members['SOURCE_BINDINGS.json'])
    require(bindings['source_manifests'] == SOURCE_MANIFESTS, 'source manifest binding changed')
    require(bindings['math_claims_changed'] is False, 'projection mathematical scope changed')
    records = bindings['source_files']
    require(len(records) == 7 and {r['public_file'] for r in records} == SOURCE_FILES, 'source/public mapping changed')
    for record in records:
        name = record['public_file']
        require(record['source_file'] == name, 'source file mapping changed')
        require(record['source_manifest_sha256'] == SOURCE_MANIFESTS[record['source_group']], 'source group binding changed')
        require(record['public_bytes'] == len(members[name]) and record['public_sha256'] == sha(members[name]), 'public source binding mismatch: ' + name)
        if record['byte_identical']:
            require(record['source_sha256'] == record['public_sha256'] and record['source_bytes'] == record['public_bytes'], 'false byte-identity claim')
    audit = parse(members['PROJECTION_AUDIT.json'])
    require(audit['math_claims_changed'] is False and audit['source_files_modified'] is False, 'projection audit qualification changed')
    scientific = audit['preserved_scientific_text_bindings']
    require(len(scientific) == 7, 'preserved scientific region count mismatch')
    for region in scientific:
        text = members[region['file']].decode('utf-8')
        start, end = region['start_marker'], region['end_marker_exclusive']
        require(text.count(start) == 1 and text.count(end) == 1, 'scientific region markers changed')
        data = text[text.index(start):text.index(end)].encode('utf-8')
        require(len(data) == region['bytes'] and sha(data) == region['source_sha256'] == region['public_sha256'], 'scientific text binding changed')
        require(region['byte_identical'] is True, 'scientific text identity qualification changed')
    for name, data in members.items():
        if name.endswith('.json'):
            parse(data)
        if name.endswith('.py'):
            continue
        text = data.decode('utf-8')
        for forbidden in ('/workspace/', '/home/agent/', 'CellData', 'private/'):
            require(forbidden not in text, 'private evidence marker in ' + name)
    linkcheck = parse(members['EXTERNAL_LINKS.json'])
    hikp = [c for c in linkcheck['checks'] if c['id'].startswith('HIKP_')]
    require(len(hikp) == 2 and all(c['public_access'] is False and c['target_contents_packaged'] is False for c in hikp), 'restricted provenance qualification changed')
    return {
        'status': 'PASS',
        'files': len(members),
        'manifest_entries': len(entries),
        'total_uncompressed_bytes': sum(map(len, members.values())),
        'manifest_sha256': sha(members['MANIFEST.json']),
        'source_files_bound': len(records),
        'scope_checks': 'bounded acceptance and unresolved access qualifications retained',
        'network_required': False,
        'mathematical_validity_reproved': False,
    }

if __name__ == '__main__':
    try:
        require(len(sys.argv) <= 2, 'usage: VERIFY_PACKET.py [directory-or-zip]')
        root = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent
        print(json.dumps(verify(root), indent=2, sort_keys=True))
    except Exception as exc:
        print(json.dumps({'status': 'FAIL', 'reason': str(exc)}, sort_keys=True))
        sys.exit(1)
