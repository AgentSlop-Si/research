# Independent source-scope review of the C8 literature comparison

20 October 2026 UTC. This review checks the named literature comparison, not the C8 proof and not worldwide priority.

## Finding

The thirteen substantive source dispositions are supported by independently reopened primary-source passages. None of the inspected statements supplies the full continuous two-sided diagonal-phase, entrywise-real-core, external spectral-norm minimum for normalized F8. This is a bounded no-match result, not a universal nonduplication certificate or an impact assessment.

The initial comparison, frozen beside this report, has SHA-256 4f55ecb601d85298f0a70fe4bfea2018e4988fdd781fa8a2a7e6825c5c195a15. The three repair categories have now been applied as a documented reviewer revision. The accepted final comparison has SHA-256 fb2228658fefed0b9e92e0906bb8313e0561577c7a59bdd975c8ef111150dad1. The exact diff and revision log are preserved; VERDICT.json records final acceptance.

## Independent source checks

All links below were opened during this review. The conclusions are about the specified definitions and results, not every possible implication of every paper.

1. Östergård–Valtonen: [publisher text](https://link.springer.com/article/10.1007/s10801-026-01568-x), §2.3 and Theorem 9. The quartet product is an exact-equivalence invariant; the Fourier theorem describes its automorphism group. Neither is a sharp metric separation. The change history specifies a LaTeX-compilation correction to Lemma 8, dated 16 August 2026.

2. Szöllősi: [primary PDF](https://arxiv.org/pdf/1204.5160), Remark 2.1, Proposition 2.2 and the fourth-root evaluation following the displayed five-parameter family. The 15 classes are BH(4,8), meaning quaternary order-eight matrices in this paper's notation. Continuous Hadamard families need not remain in the fixed Fourier equivalence orbit.

3. Valtonen: [v3 primary PDF](https://arxiv.org/pdf/2505.22947v3), Theorem 5.2 and Proposition 5.3. The statements concern selected family representatives, pairwise noncontainment, and Butson examples outside those families. They do not minimize a spectral residual. The PDF itself records 18 September 2026 as its v3 date.

4. Liang–Hu–Sun–Chen: [primary PDF](https://arxiv.org/pdf/1904.10181), Definition 7 and Theorems 9–10. R(H) counts real entries; the dimension-six MUB bound is likewise a count. Counting zero imaginary entries is not a largest-singular-value objective.

5. Cintra: [primary PDF](https://arxiv.org/pdf/2007.02232), §2.2 equation (17) and the immediately following norm specification; §3.3. The optimization is a scalar adjustment of a quantized transform kernel under Frobenius error, rather than arbitrary left/right phases and an unrestricted real core. The approximation problem is different even at order eight.

6. Wang–Wen–Nashed–Sun: [author-hosted published PDF](https://sciences.ucf.edu/math/qsun/wp-content/uploads/sites/10/2016/09/appliedoptics_o6_web.pdf), equation (4.1), Theorem 4.1 and its displayed singular-value factors. These decompose the unphased DFT. They do not optimize two independent diagonal phases. The normalized unphased imaginary-part norm of one is a specialization, not a minimax theorem. Some PDF symbols have imperfect text extraction; the phase-domain distinction is explicit and unaffected.

7. Fan–Hoffman: [published scan](https://www.math.pku.edu.cn/teachers/yaoy/Fall2011/Fan_Hoffman1955.pdf), Theorems 1–2. These concern the polar unitary factor and the Hermitian part under unitarily invariant norms. Hermitian and entrywise real are distinct constraints; these statements do not solve the global Fourier phase optimization.

8. Idel–Wolf: [primary PDF](https://arxiv.org/pdf/1408.5728), Theorem 2. The same diagonal-unitary action produces row and column sums of one. Fixing the all-ones vector is not the minimization of the largest singular value of the entrywise imaginary part.

9. Führ–Rzeszotnik: [primary PDF](https://arxiv.org/pdf/1506.06738), Theorem 4.1 and Lemma 9.7. The first concerns biunimodularity, torus intersection, and the infinity-to-one norm; the second relates differential rank to entrywise-imaginary rank. Neither is a spectral distance formula.

10. Awasthi et al.: [primary HTML](https://arxiv.org/html/2604.26392v1), equation (1), its adjacent norm definition, Definition 2 and Theorem 1. The quantity is a Hilbert–Schmidt-based density-operator imaginarity averaged over real states of fixed purity. It is neither the matrix spectral norm nor a minimum over independent row and column phases. The shared symbol 2-norm is not a valid identification.

11. Wu–Wu: [primary PDF](https://arxiv.org/pdf/2506.09747), equations (15)–(17) and Theorem 5. These are operation-level quantities relative to the real-part map and a class of free operations. The maps act on density operators; the feasible competitors and residual are not the amplitude-matrix approximation under review.

12. Fernandes–Wagner–Novo–Galvão: [primary PDF](https://arxiv.org/pdf/2403.15066), the common-basis real-representability definition, doubled-dimension encoding, and Theorems 1–3. The results characterize Gram/Bargmann-invariant regions and witness common-basis imaginarity of state sets. They are not fixed-dimension Fourier-orbit distances.

13. Ikramov: [author-uploaded published text](https://www.researchgate.net/publication/243092347_On_complex_matrices_that_can_be_made_real_by_a_unitary_similarity_transformation), introductory spectral/Jordan conditions and Theorems 1–2. These are sufficient exact-realification conditions under general unitary similarity for specified matrix classes. This is a different action from two independent diagonal phases and supplies no sharp distance in that phase class. The page identifies the upload as the author's content.

## Wording repairs and scope boundaries

The reviewer applied the following three small repair categories under the parent’s explicit direction after the author finished:

- Describe the P8 comparison as minimization of the largest singular value of the entrywise imaginary part, avoiding the ambiguous phrase minimum imaginary singular value.
- Identify P1's recorded Lemma 8 correction as a LaTeX-compilation correction, not an unspecified substantive theorem correction.
- Replace stale proof-pending status. Separate mathematical reviews already accept the proof with SHA-256 776acb79b13199fe5b52c5e352c89135b93ff8100848cbc78598969a53fd7936. That status does not make the literature search exhaustive or establish publication impact.

The exact quartet obstruction is standard and is correctly separated from the proposed sharp quantitative constant. Compactness and non-realifiability alone can yield positivity, but not the displayed sharp value. Finite-alphabet classification cannot be used as an exhaustive search over arbitrary unit phases. The original unrestricted real core is not constrained to be orthogonal, Hadamard, or quantized. Absorption of monomial magnitudes into that core must not be described as nonunitary invariance of the residual norm.

The all-phase lower bound and matching witness are the actual mathematical contribution under comparison. This review does not certify that their proof mechanism is new. A single order-eight constant can be a focused result; it does not by itself establish asymptotic, FFT-complexity, hardware, quantum-channel, or broad-impact consequences.

## Unavailable originals and retrieval boundary

The full original Haagerup chapter, Orthogonal maximal abelian *-subalgebras of the n × n matrices and cyclic n-roots (1997), pp. 296–322, remains uninspected. It must remain explicitly uncleared. Its quartet invariant was inspected directly in the later primary papers P1 and P2.

The comparison reports unsuccessful publisher-endpoint retrievals for P3 and P13. These are not wholly unavailable original papers: the author manuscript for P3 and author-uploaded published text for P13 were independently readable. No claim of publisher-version textual identity beyond the inspected material is made here.

No new all-literature search, author contact, database-priority clearance, or mathematical re-proof was attempted. No repository or external service was modified.
