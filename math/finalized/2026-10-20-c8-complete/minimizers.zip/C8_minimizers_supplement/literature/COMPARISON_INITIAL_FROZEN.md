# Bounded prior-art comparison: the proposed C8 spectral realification minimum

Research cutoff: 20 October 2026 UTC. Prepared from primary-source theorem and definition text, not search snippets. This is a finite literature comparison, not a mathematical correctness review or an exhaustive priority clearance.

## Finding

**No inspected result in the 13 primary papers below subsumes the proposed exact minimax theorem.** The closest bodies of work overlap with its transformations, dimension, or terminology, but have a different feasible set or objective. I found no directly matching published value or theorem for the full continuous diagonal-phase, entrywise-real-core, external spectral-norm problem.

That is a bounded finding, not a claim that the theorem is globally new. The candidate remains provisional pending its separate proof review. The original Haagerup chapter was not retrieved; some relevant literature could be unindexed, differently phrased, unpublished, or absent from this finite search.

## 1. Exact object compared

The supplied candidate uses the normalized matrix

\[
F_8[j,k]=8^{-1/2}\exp(-2\pi i jk/8),\qquad 0\leq j,k<8,
\]

and claims

\[
\delta_8=\min_{P,Q\text{ diagonal unitary}}
\|\operatorname{Im}_{\rm entry}(PF_8Q)\|_{2\to2}
=\tfrac12\sqrt{1+\sqrt{\sqrt2-1}}
\approx0.6410136997181852.
\]

Its claimed equivalent approximation class consists of arbitrary invertible complex-monomial outside factors and an unrestricted real 8-by-8 core, with no additional low-rank correction. The error is measured on the original, external residual. The candidate absorbs real magnitudes and permutations into the unrestricted real core; it does not assert invariance of the norm under nonunitary rescaling. These scope statements are taken from the supplied candidate, not independently certified here.

A subsuming reference would need the same global continuous phase domain and spectral objective, or a stronger theorem that yields this exact value and attainment after legitimate normalization. An inequivalence result, a construction in a restricted phase family, or a numerical upper bound is insufficient.

## 2. Primary-source register

Each entry states the actual part inspected, what it establishes, and the scope mismatch. No exclusion rests solely on an abstract or absence of a search term.

### P1. Östergård and Valtonen, *Equivalence of complex Hadamard matrices* (2026)

[Publisher full text](https://link.springer.com/article/10.1007/s10801-026-01568-x).

Inspected Theorems 1–2, §2.3, Lemmas 7–8, and Theorem 9. The paper develops monomial-equivalence and automorphism algorithms; §2.3 explicitly uses the invariant quartet products of entries. Theorem 9 identifies the automorphism group of the Fourier matrix. Its equivalence question is exact equality, not nearest entrywise-real matrix in spectral norm. Numerical equality tolerances in its algorithm are not approximation guarantees. Thus it supplies relevant background and an exact-realification obstruction, but not the candidate's sharp positive distance. The publisher records a correction to Lemma 8; the live corrected text was used.

### P2. Szöllősi, *On quaternary complex Hadamard matrices of small orders* (2012 preprint)

[Primary PDF](https://arxiv.org/pdf/1204.5160).

Inspected Remark 2.1 and Propositions 2.2–2.6, especially the order-8 classification. Proposition 2.2 gives 15 equivalence classes of quaternary order-8 matrices. The family calculations select fourth-root parameter values and classify the resulting matrices. Remark 2.1 explains the finite recognition test after dephasing. This is finite-alphabet Hadamard classification, not optimization over every diagonal unitary dressing of the single fixed Fourier matrix. A continuous family containing inequivalent Fourier-type and real matrices is not the diagonal-phase orbit of F8. No spectral minimax is supplied.

### P3. Valtonen, *Non-affine Families of 8 x 8 Complex Hadamard Matrices* (2025; inspected v3, 18 September 2026)

[Primary PDF](https://arxiv.org/pdf/2505.22947); [published article](https://doi.org/10.1080/03081087.2026.2666142).

Inspected Definition 2.1, the definition of dephased parameter families, Theorem 5.2, and Proposition 5.3. Theorem 5.2 gives representative matrices belonging uniquely to their listed family, establishing pairwise noncontainment; Proposition 5.3 gives Butson examples outside the listed families. These are constructions and equivalence classifications, not a metric optimization within the F8 orbit. In particular, varying a dephased Hadamard family generally changes the equivalence class and therefore does not give an admissible realification path here. The publisher page failed to open directly, but the actual author manuscript theorem text was read, so the substantive comparison was not blocked.

### P4. Liang, Hu, Sun, and Chen, *Real Entries of Complex Hadamard Matrices and Mutually Unbiased Bases in Dimension Six* (2019)

[Primary PDF](https://arxiv.org/pdf/1904.10181).

Inspected Definition 7, Lemma 8, and Theorems 9–10. The objective R(H) is a count of real entries. Theorem 9 gives possible counts in several dimensions, including the detailed cases 3, 4, and 6; Theorem 10 bounds real-entry counts for dimension-six MUB trios. Diagonal phases occur in constructions, but neither the count nor the MUB restrictions are the candidate's imaginary-part spectral norm. Many tiny nonzero imaginary entries and a few large ones can behave quite differently under these two objectives. No order-8 minimax follows from the inspected statements.

### P5. Cintra, *An Integer Approximation Method for Discrete Sinusoidal Transforms* (arXiv 2020)

[Primary PDF](https://arxiv.org/pdf/2007.02232).

Inspected §2.1–2.2, equation (17), and the approximation-error discussion in §3. The scheme quantizes transform coefficients into a dyadic/integer kernel and optimizes a scalar scaling parameter. The text explicitly says “Adopting the Frobenius norm” before the scalar optimization. Although it discusses other possible error norms and gives an 8-point approximate DFT, it does not solve the arbitrary two-sided continuous phase problem. Its approximate DFT is also not required to be an entrywise-real core: real and imaginary components are approximated. This is an important application comparator, not a duplicate theorem.

### P6. Wang, Wen, Nashed, and Sun, *Direct fast method for time-limited signal reconstruction* (2006)

[Author-hosted published PDF](https://sciences.ucf.edu/math/qsun/wp-content/uploads/sites/10/2016/09/appliedoptics_o6_web.pdf).

Inspected Theorem 4.1 and its real/imaginary DFT decomposition. The theorem gives simultaneous real singular-vector factors for the real and imaginary parts of the ordinary DFT and their nonzero singular values. It analyzes the unphased transform and uses it in a time-limited reconstruction problem. It does not optimize independent left/right diagonal phases or prove a nearest-real-core error. As a normalization check, its stated singular values imply that the normalized unphased F8 has imaginary-part operator norm 1. That last specialization is an inference, not a quoted minimax theorem.

### P7. Fan and Hoffman, *Some metric inequalities in the space of matrices* (1955)

[Published-paper scan](https://www.math.pku.edu.cn/teachers/yaoy/Fall2011/Fan_Hoffman1955.pdf); [DOI](https://doi.org/10.1090/S0002-9939-1955-0067841-7).

Inspected Theorems 1–2. Theorem 1 is the nearest-unitary polar-factor inequality for unitarily invariant norms. Theorem 2 concerns nearest Hermitian matrices via the Hermitian part. Hermitian means A=A*, whereas entrywise real means A=conjugate(A); these are different constraints. The source does not minimize over diagonal phases of F8. It is useful context for separating a simple fixed-phase projection argument from the genuinely global phase optimization; the candidate's entire theorem should not be described as a direct application of Fan–Hoffman.

### P8. Idel and Wolf, *Sinkhorn normal form for unitary matrices* (2015)

[Primary PDF](https://arxiv.org/pdf/1408.5728); [DOI](https://doi.org/10.1016/j.laa.2014.12.031).

Inspected Theorem 2 and its formulation of diagonal-unitary scaling. Every unitary can be left/right scaled by diagonal unitaries to have all row and column sums equal to one. This uses exactly the kind of phase actions relevant here, but its target is a normal form fixing the all-ones vector, not a real matrix or a minimum imaginary singular value. One fixed real vector does not imply that the full linear map is close to entrywise real. The theorem supplies no value of the proposed minimum.

### P9. Führ and Rzeszotnik, *On biunimodular vectors for unitary matrices* (2015)

[Primary PDF](https://arxiv.org/pdf/1506.06738).

Inspected Theorem 4.1 and Lemma 9.7. Theorem 4.1 relates biunimodular vectors, diagonal scaling to a matrix fixing the all-ones vector, torus intersection, and the infinity-to-one operator norm. Lemma 9.7 involves the rank of an entrywise imaginary part in a differential calculation. These are unusually close in notation and phase geometry, but neither result optimizes the largest singular value of the imaginary part throughout the orbit. The infinity-to-one norm is not the Euclidean spectral norm. The rank appearance is not an exact distance formula.

### P10. Awasthi et al., *Imaginarity-generating power of unitaries: A resource-theoretic approach* (2026 preprint)

[Primary PDF](https://arxiv.org/pdf/2604.26392).

Inspected equation (1), the norm definition, and Theorem 1. Theorem 1 provides a formula for purity-constrained average imaginarity generated by a unitary, using a trace expression involving U and its conjugate. The authors' symbol ||·||2 explicitly denotes the Hilbert–Schmidt norm, not spectral norm, and it is applied to density operators. Averaging over real input states differs from worst-case vector error of a linear transform, and no independent P,Q minimization is taken. This is a notation-level false match, not evidence that the proposed constant is already known.

### P11. Wu and Wu, *Quantifying imaginarity of quantum operations* (2025)

[Primary PDF](https://arxiv.org/pdf/2506.09747).

Inspected equations (15)–(17), Theorem 5, and the single-qubit example in §5. These define distances and commutation defects for quantum operations relative to a real-part map, using superoperator norms; Theorem 5 proves an imaginarity-measure property. The explicit qubit formula concerns a channel quantity and restricted gate parameters. A channel acts on density matrices, not on amplitude vectors by the same residual as F8 minus a phase-dressed real core. It neither supplies the 8-dimensional matrix minimum nor a reduction to it.

### P12. Fernandes, Wagner, Novo, and Galvão, *Unitary-Invariant Witnesses of Quantum Imaginarity* (2024)

[Primary PDF](https://arxiv.org/pdf/2403.15066); [PRL DOI](https://doi.org/10.1103/PhysRevLett.133.190201).

Inspected the common-basis realifiability definition and Theorems 1–3. The work characterizes attainable Bargmann-invariant regions and constructs witnesses that a set of quantum states cannot all be real in a common basis. The allowed change is a general common unitary basis transformation, and the invariant regions are not operator-norm distances of a Fourier matrix to a two-sided diagonal-phase real-core class. Its doubled-dimension real encoding also lies outside the fixed 8-by-8 approximation model. The inspected theorems do not subsume the candidate.

### P13. Ikramov, *On complex matrices that can be made real by a unitary similarity transformation* (2010)

[DOI](https://doi.org/10.1134/S1064562410010035); [author-uploaded full text](https://www.researchgate.net/publication/243092347_On_complex_matrices_that_can_be_made_real_by_a_unitary_similarity_transformation).

Inspected the introductory spectral/Jordan conditions and Theorems 1–2 in the full paper. These give sufficient conditions for realification by arbitrary unitary similarity in normal and quadratic-minimal-polynomial cases. Such a Q*AQ action is not independent diagonal-unitary left/right scaling. The paper asks exact realifiability, not a sharp distance if the prescribed phase orbit fails to meet the real matrices. The publisher endpoint failed, but the actual author-uploaded paper was readable. No conclusion about whether F8 satisfies those separate hypotheses is needed for this comparison.

## 3. What is already standard versus the candidate contribution

The following distinction is essential to a defensible novelty statement:

- **Exact non-realifiability is not the prospective new result.** For the unnormalized Fourier matrix, the quartet with rows 0,1 and columns 0,1 has nonreal value exp(-iπ/4). A real Hadamard matrix has only real quartet values. Diagonal phases cancel in these products. This is a direct application/inference from the invariant in P1–P2, so exact equality to a real matrix is already obstructed without the proposed minimax proof.
- **Fixed-phase nearest-real projection is elementary.** Once phases are fixed, the supplied candidate reduces to taking the real part. That local fact should be presented as a lemma, not the main research discovery. P7 concerns an analogous but different Hermitian constraint.
- **A sharp quantitative separation is a different assertion.** A nonzero invariant proves no exact realification, but does not by itself establish the number 0.6410136997 or its attainment. Finite-alphabet classifications and constructed approximate kernels also do not prove a lower bound over all continuous phases.
- **The proposed global lower bound is the meaningful comparison target.** If valid, the potentially new part is the exact worst-case Euclidean-error threshold over the whole phase orbit, with a matching witness. A cost-nonincreasing periodic replacement proved for all competitors is different from merely searching periodic phases. No claim is made here that this reduction is itself absent from all literature.

## 4. Search boundary and unresolved items

The search combined the phrases Fourier/DFT with realification, real core, imaginary part, diagonal-unitary rephasing, monomial equivalence, operator/spectral norm, minimax, nearest real matrix, approximate 8-point transform, Hadamard distance, and quantum imaginarity. Exact decimal and radical searches were also attempted. Such searches are discovery aids only: lack of a keyword hit was not treated as a theorem-level exclusion.

The primary-source comparison above has a deliberate stopping boundary: 13 named papers, with the stated theorem/definition passages actually read. Citation trails were used selectively, not exhaustively. The secondary survey [Tadej and Życzkowski, *A concise guide to complex Hadamard matrices*](https://arxiv.org/pdf/quant-ph/0512154) was used as a map, not counted as an independent primary-source exclusion.

**Unresolved original source:** Uffe Haagerup, *Orthogonal maximal abelian *-subalgebras of the n × n matrices and cyclic n-roots*, in *Operator Algebras and Quantum Field Theory* (1997), pp. 296–322. A full-text original was not retrieved during this bounded check. Metadata and later citations are not a substitute for reading its theorem statements. The relevant quartet invariant was instead read directly in P1 and P2. Do not label the original chapter fully cleared.

No comprehensive MathSciNet/zbMATH review, author correspondence, non-English archive sweep, or unpublished-priority inquiry was performed. This report therefore supports “no matching theorem found in the inspected sources,” not “first in the world.” Source availability was the only retrieval limitation noted above; no denied external action was bypassed.

## 5. Practical publication assessment

**Conditional assessment:** This is not presently identified as a duplicate by the checked sources. It could support a focused, rigorous matrix-analysis/transform-approximation result if the proof and the model equivalence survive independent review. A single order-8 sharp constant is nevertheless a narrow contribution. Nonduplication alone is not evidence of broad impact or a publication guarantee.

Recommended framing:

1. State the normalized F8, full continuous phase domain, unrestricted real core, and external 2-to-2 norm in the abstract/theorem. Avoid the ambiguous bare phrase “2-norm” because P10 uses it for a different norm.
2. Position the theorem as a sharp finite-dimensional obstruction/benchmark for phase-dressed real-core approximations, not as discovery that Fourier matrices are complex or inequivalent to real Hadamards.
3. Separate the model reduction, global lower bound, and attaining witness. Explain that arbitrary monomial magnitudes are absorbed into the real core, not canceled inside the error norm.
4. Explain why the mechanism may be useful: any more restricted rank-zero real-core construction inherits this external-error floor. Broader usefulness would be stronger with a demonstrably reusable argument or a natural family of related cases, but that extension is not established by this comparison.
5. Do not claim an FFT arithmetic-complexity lower bound, asymptotic advantage, hardware-cost result, arbitrary-unitary realification barrier, quantum-channel operational bound, classification of all optimizers, or positive-correction-rank theorem. None follows merely from this scalar minimum.

A defensible related-work sentence, conditional on proof acceptance, is:

“Prior Hadamard-equivalence results distinguish the Fourier orbit from real Hadamard matrices, while integer-transform approximations and quantum-imaginarity measures optimize different objectives. We determine a sharp external spectral-norm realification error for the normalized eight-point Fourier matrix under arbitrary left and right diagonal phases.”

This sentence describes the actual contribution without claiming universal priority. An optional search statement can say that no identical theorem was located in the named inspected sources.

## Deliverable status

The bounded source comparison is complete. No repository, research result table, or candidate proof was modified. The candidate's mathematical acceptance and any wider publication decision remain separate from this report.
