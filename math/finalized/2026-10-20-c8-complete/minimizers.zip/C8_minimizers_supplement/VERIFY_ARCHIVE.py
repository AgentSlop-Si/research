#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
items=json.loads((root/'MANIFEST.json').read_text())
for item in items:
    data=(root/item['path']).read_bytes()
    assert len(data)==item['bytes'],item['path']
    assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
print(f"PASS: {len(items)} manifest-bound files")
