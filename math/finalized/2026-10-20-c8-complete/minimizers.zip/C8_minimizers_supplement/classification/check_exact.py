#!/usr/bin/env python3
"""Fresh exact controls. The analytic equality proofs are in PROOF.md."""
import hashlib,itertools,json,pathlib,time
import sympy as s
from sympy.polys.domains import QQ
start=time.monotonic()
root=pathlib.Path(__file__).resolve().parent
h0=s.sqrt(s.sqrt(2)-1); k0=s.sqrt(2-s.sqrt(2))
print('Building exact algebraic field',flush=True)
K=QQ.algebraic_field(h0,k0,s.I)
print('Algebraic field ready',flush=True)
f=K.from_sympy
zero,one=f(s.S.Zero),f(s.S.One)
i,h,k=f(s.I),f(h0),f(k0)
sqrt2=h*h+one
m=(one-h)/2;n=one-m
zeta=(one+i)/sqrt2
N=0

def check(x,msg):
 global N
 assert x,msg
 N+=1

def eq(a,b,msg): check(a==b,msg)
assert K.ext.as_expr()==h0+k0+s.I
theta_bar=K.unit-2*i
def conj(a):
 result=zero
 for coefficient in a.to_list():
  result=result*theta_bar+K.convert(coefficient)
 return result
def matmul(a,b): return [[sum((x*y for x,y in zip(row,col)),zero) for col in zip(*b)] for row in a]
def trans(a):return list(map(list,zip(*a)))
def diag(a):return [[x if j==q else zero for q in range(len(a))] for j,x in enumerate(a)]
def tr(a):return sum((a[j][j] for j in range(len(a))),zero)
def det2(a):return a[0][0]*a[1][1]-a[0][1]*a[1][0]
def sector(a,b):
 al=(a[0]+a[2])/2;be=(a[0]-a[2])/2
 ga=(a[1]+a[3])/2;de=-i*(a[1]-a[3])/2
 return [matmul([[al,be],[be,al]],diag([b[0],b[2]])),matmul([[ga,de],[de,-ga]],diag([b[0],b[2]])),matmul([[be,al],[al,be]],diag([b[1],b[3]])),matmul([[de,-ga],[-ga,-de]],diag([b[1],b[3]]))]

eq(h*h+k*k,one,'unit h+ik')
eq(sqrt2*sqrt2,2*one,'sqrt2')
eq(m+n,one,'m+n')
eq(zeta*zeta,i,'zeta square')
pairs={}
for typ in (0,1):
 tau=(m,n)[typ];q=2*tau-one
 for signs in itertools.product((1,-1),repeat=4):
  xu,xv,xw,xz=signs
  u=q+i*xu*k;v=-q+i*xv*k;w=q+i*xw*k;z=-q+i*xz*k
  eps=(1 if typ==0 else -1)*xu*xv*xw*xz
  eta=(one+i*eps)/sqrt2
  ts=[m,n*eta,n*eta,m] if typ==0 else [n*eta,m,m,n*eta]
  B0=4*ts[0]/((one+u)*(one+w))
  A1=4*ts[1]/(B0*(one+v)*(one-w))
  B1=4*ts[2]/((one-u)*(one+z))
  a=[one,A1,u,A1*v];b=[B0,B1,B0*w,B1*z]
  # Reciprocal equals complex conjugate for every constructed phase.
  for x in a+b:eq(x*conj(x),one,'unit constructed phase')
  blocks=sector(a,b)
  for j,M in enumerate(blocks):
   eq(tr(M),2*ts[j],f'trace {typ} {signs} {j}')
   center=one if ((typ==0 and j in(0,3)) or (typ==1 and j in(1,2))) else eta
   eq(det2(M),center*center,'determinant from trace phase')
  ratio=tr(blocks[0])*tr(blocks[3])/(tr(blocks[1])*tr(blocks[2]))
  eq(ratio,-i*xu*xv*xw*xz*(tau/(one-tau))**2,'trace ratio')
  pairs[(typ,signs)]=(a,b,eps)
print('All 32 phase formulas checked',flush=True)
check(len(pairs)==32,'32 distinct labels')
# Distinctness of normalized exact pairs.
vals=list(pairs.values())
for j in range(32):
 for l in range(j):check(vals[j][:2]!=vals[l][:2],'distinct normalized pair')

def normpair(a,b):
 g=a[0]
 return [x/g for x in a],[g*x for x in b]
def Rlab(label):
 typ,(a,b,c,d)=label
 return 1-typ,(-b,a,-c,-d)
def Clab(label):
 typ,(a,b,c,d)=label
 return 1-typ,(-a,-b,d,-c)
def Jlab(label):
 typ,(a,b,c,d)=label
 return typ,(-a,b,-c,-d)
for label,(a,b,eps) in pairs.items():
 # The squared Fourier row shift multiplies b_j by i^j.
 ra=[a[(j-1)%4] for j in range(4)];rb=[i**j*b[j] for j in range(4)]
 ca=[(-i)**j*a[j] for j in range(4)];cb=[b[(j+1)%4] for j in range(4)]
 ja=[conj(a[(-j)%4]) for j in range(4)];jb=[conj(x) for x in b]
 for lab,aa,bb in ((Rlab(label),ra,rb),(Clab(label),ca,cb),(Jlab(label),ja,jb)):
  aa,bb=normpair(aa,bb)
  eq((aa,bb),pairs[lab][:2],'phase symmetry formula')
 eq(pairs[Rlab(label)][2],eps,'row preserves epsilon')
 eq(pairs[Clab(label)][2],eps,'column preserves epsilon')
 eq(pairs[Jlab(label)][2],-eps,'conjugation flips epsilon')
 eq(Rlab(Clab(label)),Clab(Rlab(label)),'commuting labels')
 orbit=set()
 rlabel=label
 for rr in range(4):
  clabel=rlabel
  for cc in range(4):
   orbit.add(clabel);clabel=Clab(clabel)
  eq(clabel,rlabel,'column order four')
  rlabel=Rlab(rlabel)
 eq(rlabel,label,'row order four')
 check(len(orbit)==16,'free translation orbit')
 check({pairs[z][2] for z in orbit}=={eps},'constant epsilon orbit')

print('All finite symmetry actions checked',flush=True)
# Full 8x8 Fourier blocks for all 32 algebraic pairs, no numerical phases.
omega=(one-i)/sqrt2
F=[[omega**(j*l)/(2*sqrt2) for l in range(8)]for j in range(8)]
# Unnormalized sector columns have norm sqrt2. Thus transform = B^T U B /2.
S=[]
for j,sgn in ((0,1),(0,-1),(1,1),(1,-1)):
 for off in(0,2):
  col=[zero]*8;col[j+off]=one;col[j+off+4]=sgn*one
  S.append(col)
B=trans(S)
for label,(a,b,eps) in pairs.items():
 U=matmul(matmul(matmul(F,diag(a+a)),F),diag(b+b))
 out=matmul(matmul(trans(B),U),B)
 blocks=sector(a,b)
 for j in range(8):
  for l in range(8):
   expected=2*blocks[j//2][j%2][l%2] if j//2==l//2 else zero
   eq(out[j][l],expected,'full eight dimensional block decomposition')

print('All full Fourier decompositions checked',flush=True)
# Projector onto either pair of low sectors has diagonal 1/2 everywhere.
for blocks in((0,3),(1,2)):
 cols=[S[2*q+r] for q in blocks for r in(0,1)]
 for j in range(8):eq(sum((c[j]*c[j] for c in cols),zero),one,'critical projector diagonal = 1/2')

# The accepted witness normalizes to the announced label.
zz=h+i*k
aw=[-zz,(one-i)/sqrt2*zz,one,(one-i)/sqrt2]
bw=[one,zeta**3/zz,-one/zz,zeta**3]
aw,bw=normpair(aw,bw)
eq((aw,bw),pairs[(0,(1,-1,1,1))][:2],'accepted witness label')

# Generic core spectrahedron algebra; independent symbols, no numerics.
a,b,c,d0,ee,tt=s.symbols('a b c d0 ee tt',real=True)
M=s.Matrix([[a,b],[c,d0]])
G=tt*s.eye(2)-M.T*M-s.I*ee*(M.T-M)
eq(s.expand(G.det()),s.expand((tt-a*a-c*c)*(tt-b*b-d0*d0)-(a*b+c*d0)**2-ee**2*(b-c)**2),'core determinant')

# Destructive controls ensure the frozen conventions matter.
wrong=pairs[(0,(1,-1,1,1))]
wrongblocks=sector(wrong[0],wrong[1])
check(det2(wrongblocks[0])*det2(wrongblocks[3]) != det2(wrongblocks[1])*det2(wrongblocks[2]),'wrong determinant plus sign rejected')
check(Jlab((0,(1,-1,1,1))) != (0,(1,-1,1,1)),'conjugation cannot be ignored')
paths=[root.parent/'sources/global_primary_PROOF.md',root.parent/'sources/global_independent_PROOF.md',root.parent/'sources/global_independent_REVIEW.md']
manifest={str(p.relative_to(root.parent)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in paths}
(root/'SOURCE_BINDINGS.json').write_text(json.dumps(manifest,indent=2)+'\n')
report={'status':'PASS','exact_assertions':N,'seconds':time.monotonic()-start,'algebraic_field_degree':K.mod.degree(),'numerical_optimization_used':False,'sampling_is_a_proof_premise':False}
(root/'CHECK_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
