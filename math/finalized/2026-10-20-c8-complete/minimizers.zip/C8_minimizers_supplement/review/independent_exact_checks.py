#!/usr/bin/env python3
"""Fresh exact controls; no candidate or historical code imported or run."""
import sympy as S
import json
from pathlib import Path
I=S.I
checks=[]
def ck(label, condition):
    assert condition, label
    checks.append(label)
def zero(x): return S.simplify(S.expand(x))==0
# Construct Fourier and all sectors directly, without imported identities.
w=(1-I)/S.sqrt(2)
roots=[S.simplify(w**k) for k in range(8)]
F=S.Matrix(8,8,lambda j,k:roots[(j*k)%8]/S.sqrt(8))
aa=S.symbols('a0:4'); bb=S.symbols('b0:4')
A=S.diag(*(aa+aa)); B=S.diag(*(bb+bb))
vectors=[]
for parity,sign in [(0,1),(0,-1),(1,1),(1,-1)]:
    for index in [parity,parity+2]:
        v=S.zeros(8,1);v[index]=1/S.sqrt(2);v[index+4]=sign/S.sqrt(2);vectors.append(v)
T=S.Matrix.hstack(*vectors)
ck('sector basis real orthogonal',T.T*T==S.eye(8))
a,b=(aa[0]+aa[2])/2,(aa[0]-aa[2])/2
g,h=(aa[1]+aa[3])/2,-I*(aa[1]-aa[3])/2
blocks=[S.Matrix([[a,b],[b,a]])*S.diag(bb[0],bb[2]),S.Matrix([[g,h],[h,-g]])*S.diag(bb[0],bb[2]),S.Matrix([[b,a],[a,b]])*S.diag(bb[1],bb[3]),S.Matrix([[h,-g],[-g,-h]])*S.diag(bb[1],bb[3])]
diff=T.T*F*A*F*B*T-S.diag(*blocks)
ck('generic full eight-dimensional sector identity',all(zero(v) for v in diff))
ck('generic determinant obstruction',zero(blocks[0].det()*blocks[3].det()+blocks[1].det()*blocks[2].det()))
for name,cols in [('diagonal low sectors',[0,1,6,7]),('off-diagonal low sectors',[2,3,4,5])]:
    V=T[:,cols];P=V*V.T
    ck(name+' projector rank four',P.rank()==4)
    ck(name+' projector diagonal one half',all(x==S.Rational(1,2) for x in P.diagonal()))
# Entire sign-parametrized family: generic positive a,b with a^2+b^2=1.
a,b=S.symbols('a b',real=True)
G=S.groebner([a*a+b*b-1],a,b,extension=[S.sqrt(2),I])
def circle_zero(expr):
    expr=S.cancel(S.together(S.expand_complex(expr)))
    num,den=S.fraction(expr)
    return S.simplify(G.reduce(S.Poly(S.expand(num),a,b,extension=[S.sqrt(2),I]).as_expr())[1])==0
# Clear denominators before the circle reduction; denominators do not vanish
# since a,b>0 and |z|=1, kappa and lambda are unit phases.
family_count=0
for pattern in range(2):
 for eps in [-1,1]:
  eta=(1+eps*I)/S.sqrt(2)
  kappa,lam=(1,eta) if pattern==0 else (eta,1)
  for u in [-1,1]:
   for v in [-1,1]:
    for wsign in [-1,1]:
     z=a+I*u*b
     av=[1,-I*v*lam*z/kappa*(b+I*wsign*a),z*z,-I*v*lam*z/kappa*(b-I*wsign*a)]
     ev=a*kappa/z;fv=I*v*b*kappa/z
     gv=I*u*b*lam/z;hv=I*v*wsign*a*kappa*kappa/(lam*z)
     bv=[ev+fv,gv+hv,ev-fv,gv-hv]
     label=f'pattern {pattern}, eps {eps}, signs {u},{v},{wsign}'
     ck(label+' all eight entries unit',all(circle_zero(x*S.conjugate(x)-1) for x in av+bv))
     alpha=(av[0]+av[2])/2;beta=(av[0]-av[2])/2
     gamma=(av[1]+av[3])/2;delta=-I*(av[1]-av[3])/2
     traces=[alpha*(bv[0]+bv[2])/2,gamma*(bv[0]-bv[2])/2,beta*(bv[1]+bv[3])/2,delta*(bv[1]-bv[3])/2]
     targets=[a*a*kappa,b*b*lam,b*b*lam,a*a*kappa]
     ck(label+' exact target traces',all(circle_zero(x-y) for x,y in zip(traces,targets)))
     family_count+=1
ck('complete discrete sign family count',family_count==32)
# Candidate ratio parameterization, independently derived from generic circle factors.
from itertools import product
for xu,xv,xw,xz in product([-1,1], repeat=4):
    u=(a+I*xu*b)**2; v=(b+I*xv*a)**2
    w=(a+I*xw*b)**2; z=(b+I*xz*a)**2
    lhs=(1+u)*(1-v)*(1+w)*(1-z)*b**4
    rhs=(xu*xv*xw*xz)*a**4*(1-u)*(1+v)*(1-w)*(1+z)
    ck(f'generic ratio trace identity {xu},{xv},{xw},{xz}',circle_zero(lhs-rhs))
# Exhaust the complete symbolic label set, not samples of continuous phases.
labels=[(pattern,)+signs for pattern in [0,1] for signs in product([-1,1],repeat=4)]
def row(x):
    p,a,b,c,d=x;return (1-p,-b,a,-c,-d)
def col(x):
    p,a,b,c,d=x;return (1-p,-a,-b,d,-c)
def rev(x):
    p,a,b,c,d=x;return (p,-a,b,-c,-d)
def epsilon(x):
    p,a,b,c,d=x;return (1 if p==0 else -1)*a*b*c*d
def repeat(f,x,k):
    for _ in range(k):x=f(x)
    return x
ck('row-column label actions commute',all(row(col(x))==col(row(x)) for x in labels))
ck('translations have order four',all(repeat(row,x,4)==repeat(col,x,4)==x for x in labels))
ck('translations preserve epsilon',all(epsilon(row(x))==epsilon(col(x))==epsilon(x) for x in labels))
ck('conjugation reversal flips epsilon',all(epsilon(rev(x))==-epsilon(x) for x in labels))
ck('every translation orbit has sixteen distinct labels',all(len({repeat(row,repeat(col,x,j),i) for i in range(4) for j in range(4)})==16 for x in labels))
ck('translations and reversal cover exactly thirty-two labels',len({repeat(row,repeat(col,rev(labels[0]) if r else labels[0],j),i) for r in [0,1] for i in range(4) for j in range(4)})==32)
# The scalar equality polynomial at its opposite-pair endpoint.
x,y=S.symbols('x y',positive=True)
q=(1-x)*(1-y)
ck('opposite-pair equality gives b+c=2sqrt(q)',zero((1-x*y+q)**2-(x-y)**2-4*q))
# The real two-dimensional core freedom, directly from its complex norm LMI.
a,b,c,e,t,d=S.symbols('a b c e t d',real=True)
K=S.Matrix([[a,b],[c,e]])
LMI=d*d*S.eye(2)-(K+I*t*S.eye(2)).conjugate().T*(K+I*t*S.eye(2))
Delta=d*d-t*t
expected=Delta*S.eye(2)-K.T*K-I*t*(K.T-K)
ck('real-core compressed Hermitian LMI',all(zero(x) for x in LMI-expected))
expected_det=Delta**2-Delta*(a*a+b*b+c*c+e*e)+(a*e-b*c)**2-t*t*(b-c)**2
ck('real-core scalar determinant formula',zero(LMI.det()-expected_det))
# Radical identity relevant to the common noncritical singular value.
h=S.sqrt(S.sqrt(2)-1);m=(1-h)/2;n=1-m
s=S.sqrt(2)*n-m
ck('positive candidate square root',bool(s>0))
ck('s^2=1-m^2',zero(s*s-(1-m*m)))
ck('d^2-t^2=(s-m)/2',zero(n/2-(1-s)/2-(s-m)/2))
result={'verdict':'PASS','checks':len(checks),'family_members':family_count,'labels':checks,'method':'exact symbolic identities, generic phase variables and exhaustive discrete signs; no numerical search'}
Path(__file__).with_name('CHECK_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='labels'},indent=2))
