# Complete C8 rank-zero minimizers: supplement

20 October 2026 UTC. The full minimizer classification has passed independent mathematical review.

This is a new, separate supplement to C8_exact_global_minimum_2026-10-20.zip. It does not replace or alter that 24-file value-proof archive.

## Main result

At the already accepted exact rank-zero optimum, every squared-phase pair A=P^2, B=Q^2 is four-periodic. Exactly 32 pairs remain after the inverse scalar gauge is normalized; all are in one orbit under the stated Fourier-compatible translations and conjugation/reversal. Unsquared P,Q can differ by independent real signs. The full original model also has a constrained, four-real-dimensional real-core family and arbitrary real-monomial gauge freedom. The proof gives necessary and sufficient formulas for all of these, not only a special attaining witness.

Read classification/PROOF.md for the complete theorem, equality analysis, explicit formulas, and full-core parameterization. Read review/REVIEW.md for the independent acceptance. The proof's frozen opening says pending review because its mathematical text was not rewritten after the later acceptance. The archived version changes only its source locators; the reviewed original is bound by SHA-256 6d3af7582c56a7b03ab5967503642634a03a14af5f2234c9ab3118615d643c76.

## Reproduce the exact controls

Use Python 3 with SymPy 1.14.0. From this directory, run:

    python VERIFY_ARCHIVE.py
    python classification/check_exact.py
    python review/independent_exact_checks.py

The first checker passes 3,561 exact algebraic-field assertions, including all 32 full Fourier matrices. The independently written reviewer checker passes 100 differently scoped exact symbolic controls, including a separate parameterization. Assertion counts are not interchangeable benchmark units. Neither checker uses floating-point sampling or numerical optimization. Universal equality and exhaustiveness are proved analytically, not inferred from these counts.

PORTABILITY_REPORT.json records fresh executions from a clean temporary copy. Running either checker refreshes its own report and source bindings, so verify the delivered archive before rerunning files.

## Separately reviewed literature comparison

literature/COMPARISON.md is the accepted bounded comparison against thirteen named primary papers. literature/REVIEW.md documents its independent source review and the precise limits. Its conclusion is only that no subsuming theorem was found in the inspected statements. It does not certify worldwide novelty, publication prospects, or broad impact. One older original source was not directly retrieved; this limitation is explicit. The initial version and the reviewer's exact revision diff/log are preserved only for provenance; COMPARISON.md is the accepted final version.

## Integrity and scope

MANIFEST.json binds every delivered content file. PROJECTION_BINDINGS.json binds original and archive SHA-256 hashes and byte lengths. Projection changes replace private machine locators with archive-relative locators only; mathematical content and checking algebra are unchanged. Source-binding hashes continue to identify the reviewed originals, while the projection table identifies the corresponding delivered bytes.

The accepted global-value proofs and reviews are included under sources/ for context. The original value archive has SHA-256 4bf5ffb3a5a52922d762bf460251b72a659dd7ec2a41df8b049ce0a59f6c0e27 and remains unchanged. This supplement settles the C8 rank-zero minimizer classification only. Positive correction ranks, other dimensions, and broader phase-defect questions remain outside its conclusions.
