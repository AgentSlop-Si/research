#!/usr/bin/env python3
"""Fresh exact controls, independent of both proof authors' programs.
No numerical optimizer, finite sampling, source imports, or historical code.
"""
import sympy as s
import hashlib, json, pathlib, time
HERE=pathlib.Path(__file__).resolve().parent
SOURCES={
 'solver_proof':str(HERE.parent/'candidate/PROOF.md'),
 'verifier_proof':str(HERE.parent/'independent/PROOF.md'),
 'accepted_witness':str(HERE.parent/'sources/upper_original.md'),
 'accepted_witness_review':str(HERE.parent/'sources/upper_review_original.md'),
}
def binding():
 return {k:{'path':str(pathlib.Path(p).relative_to(HERE.parent)),'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest(),'bytes':pathlib.Path(p).stat().st_size} for k,p in SOURCES.items()}
before=binding(); (HERE/'SOURCE_BINDINGS_BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
checks=[]
def check(name, value):
 assert value, name
 checks.append(name)
 print('PASS',name,flush=True)
def zero(expr): return s.simplify(s.expand(expr))==0
def matrix_zero(mat): return all(zero(e) for e in mat)
start=time.monotonic(); I=s.I; r=s.sqrt(2)
# Full 8-by-8 Fourier, constructed independently from exact root cycle.
w=[1,(1-I)/r,-I,(-1-I)/r,-1,(-1+I)/r,I,(1+I)/r]
F=s.Matrix(8,8,lambda j,k:w[(j*k)%8]/(2*r))
check('full_Fourier_symmetric',F.T==F)
check('full_Fourier_unitary',matrix_zero(F.conjugate().T*F-s.eye(8)))
H=s.zeros(8)
for j in range(8): H[(j+4)%8,j]=1
all_a=s.symbols('a0:8')
Call=F*s.diag(*all_a)*F
check('all_phase_halfshift_commutation',matrix_zero(H*Call*H-Call))
a=s.symbols('a0:4'); b=s.symbols('b0:4')
A=s.diag(*(a+a)); B=s.diag(*(b+b)); U=F*A*F*B
cols=[]
for j,eta in [(0,1),(0,-1),(1,1),(1,-1)]:
 for k in [j,j+2]:
  col=s.zeros(8,1); col[k]=1/r; col[k+4]=eta/r; cols.append(col)
T=s.Matrix.hstack(*cols)
check('sector_basis_real_orthogonal',matrix_zero(T.T*T-s.eye(8)))
alpha=(a[0]+a[2])/2; beta=(a[0]-a[2])/2
gamma=(a[1]+a[3])/2; delta=-I*(a[1]-a[3])/2
blocks=[s.Matrix([[alpha,beta],[beta,alpha]])*s.diag(b[0],b[2]),
 s.Matrix([[gamma,delta],[delta,-gamma]])*s.diag(b[0],b[2]),
 s.Matrix([[beta,alpha],[alpha,beta]])*s.diag(b[1],b[3]),
 s.Matrix([[delta,-gamma],[-gamma,-delta]])*s.diag(b[1],b[3])]
check('full_generic_sector_decomposition',matrix_zero(T.T*U*T-s.diag(*blocks)))
dets=[a[0]*a[2]*b[0]*b[2],-a[1]*a[3]*b[0]*b[2],-a[0]*a[2]*b[1]*b[3],-a[1]*a[3]*b[1]*b[3]]
traces=[alpha*(b[0]+b[2]),gamma*(b[0]-b[2]),beta*(b[1]+b[3]),delta*(b[1]-b[3])]
for k in range(4):
 check(f'block_{k}_determinant_sign',zero(blocks[k].det()-dets[k]))
 check(f'block_{k}_trace',zero(s.trace(blocks[k])-traces[k]))
check('determinant_center_obstruction',zero(dets[0]*dets[3]+dets[1]*dets[2]))
# Fresh polynomial identities for pair balancing and KKT routes.
a0,b0,c0,d0,q=s.symbols('a b c d q',real=True)
R=s.Matrix([[a0,b0],[c0,d0]])
f=1-a0*a0-b0*b0-c0*c0-d0*d0+(a0*d0-b0*c0)**2
check('norm_boundary_polynomial',zero((s.eye(2)-R.T*R).det()-f))
check('pair_sum_boundary_identity',zero((b0+c0)**2-((1-a0*d0+b0*c0)**2-(a0-d0)**2)+f))
check('pair_q_root_factorization',zero((1-a0*d0+q)**2-(a0-d0)**2-4*q-(q-(1-a0)*(1-d0))*(q-(1+a0)*(1+d0))))
K=a0*a0+d0*d0-a0*a0*d0*d0
check('pair_cosine_radical_identity',zero((1-b0*b0)*(1-c0*c0)-(K+2*a0*d0*b0*c0)-f))
qmax=(1-a0)*(1-d0)
check('pair_endpoint_radical_square',zero(K+2*a0*d0*qmax-(a0+d0-a0*d0)**2))
check('pair_endpoint_cosine',zero(a0+d0-a0*d0-qmax-(1-2*qmax)))
t=s.symbols('t',real=True)
Rp=s.Matrix([[a0,t],[t,d0]])
lam=s.symbols('lambda')
check('balanced_eigenvalue_one',zero((Rp-s.eye(2)).det().subs(t*t,(1-a0)*(1-d0))))
check('balanced_characteristic_polynomial',zero((Rp-lam*s.eye(2)).det().subs(t*t,(1-a0)*(1-d0))-(1-lam)*(a0+d0-1-lam)))
B0,C0=s.symbols('B C',real=True)
station=(c0*(1-b0*b0)+a0*b0*d0)*C0-(b0*(1-c0*c0)+a0*c0*d0)*B0
factor=(B0*C0-a0*d0)*(c0*B0-b0*C0)
gbasis=s.groebner([B0**2+b0**2-1,C0**2+c0**2-1],B0,C0,a0,b0,c0,d0)
check('KKT_one_bound_stationarity_factor',gbasis.reduce(s.expand(station-factor))[1]==0)
dsym=1-b0*b0/(1-a0)
check('KKT_symmetric_radical_square',zero(1-dsym**2-b0*b0*(2*(1-a0)-b0*b0)/(1-a0)**2))
mm,uu,vv,ss=s.symbols('m u v s',real=True)
Ropp=s.Matrix([[mm,uu+vv],[uu-vv,mm]])
gbasis2=s.groebner([ss**2-mm**2-vv**2],ss,mm,uu,vv)
for sign in [1,-1]:
 test=(Ropp.T*Ropp-(uu+sign*ss)**2*s.eye(2)).det()
 check(f'KKT_opposite_singular_square_{sign}',gbasis2.reduce(s.expand(test))[1]==0)
diff=(ss+vv)**2*(1-(uu+vv)**2)-(ss-vv)**2*(1-(uu-vv)**2)-4*mm**2*vv
check('KKT_opposite_derivative_squared_difference',gbasis2.reduce(s.expand(diff.subs(uu,1-ss)))[1]==0)
# Exact endpoint and the accepted explicit legal witness.
h=s.sqrt(r-1); m=(1-h)/2
check('endpoint_h_squared',zero(h*h-(r-1)))
check('endpoint_half_angle',zero((1-m)/2-(1+h)/4))
check('endpoint_angle_radical_square',zero((r*(1-m)-m)**2-(1-m*m)))
# Sign proofs are recorded in REVIEW.md; these exact logical comparisons support them.
check('endpoint_positive_m',bool(m>0))
check('endpoint_m_below_KKT_limit',bool(m<1-1/r))
check('endpoint_positive_radical_rhs',bool(r*(1-m)-m>0))
z=h+I*s.sqrt(2-r); zbar=h-I*s.sqrt(2-r); zeta=(1+I)/r
check('witness_z_unit',zero(z*zbar-1))
check('witness_z_realpart',zero((z+zbar)/2-h))
aw=[-z,(1-I)*z/r,1,(1-I)/r]
bw=[1,(-1+I)*zbar/r,-zbar,(-1+I)/r]
sub=dict(zip(a,aw)); sub.update(dict(zip(b,bw)))
for k in range(4):
 expectedtr=1-h if k in [0,3] else (1-I)*(1+h)/r
 expecteddet=1 if k in [0,3] else -I
 check(f'witness_block_{k}_trace',zero(s.trace(blocks[k]).subs(sub)-expectedtr))
 check(f'witness_block_{k}_determinant',zero(blocks[k].det().subs(sub)-expecteddet))
after=binding(); check('frozen_sources_unchanged',before==after)
(HERE/'SOURCE_BINDINGS_AFTER.json').write_text(json.dumps(after,indent=2)+'\n')
result={'status':'PASS','checks':checks,'exact_check_count':len(checks),'seconds':time.monotonic()-start,'finite_numerics_used':False,'historical_or_author_checker_executed':False,'scope':'Supporting exact algebra controls; universal inequalities independently audited analytically in REVIEW.md.'}
(HERE/'EXACT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
