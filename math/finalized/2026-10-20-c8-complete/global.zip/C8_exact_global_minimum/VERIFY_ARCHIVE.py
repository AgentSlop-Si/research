from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text())
for f in m['files']:
 p=root/f['path']; data=p.read_bytes()
 assert len(data)==f['bytes'],f['path']
 assert hashlib.sha256(data).hexdigest()==f['sha256'],f['path']
print('PASS:',len(m['files']),'delivered files match MANIFEST.json')
