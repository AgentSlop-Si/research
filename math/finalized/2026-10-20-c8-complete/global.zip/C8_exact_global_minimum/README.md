# Exact global C8 rank-zero minimum

20 October 2026 UTC. Accepted by two independent mathematical reviews.

The exact minimum is

    delta_(8,0) = (1/2) sqrt(1 + sqrt(sqrt(2)-1))
                 = 0.641013699718185... .

This is the external operator-norm minimum for the normalized eight-point Fourier matrix, arbitrary invertible complex-monomial outer factors, an unrestricted real core, and rank-zero correction. The lower bound covers all row and column phases, including nonperiodic choices.

## Read first

- candidate/PROOF.md: full primary proof, including an exact attaining witness.
- independent/REVIEW.md: first independent acceptance review.
- independent/PROOF.md: distinct analytic proof using a separate scalar extremum argument.
- adversarial/REVIEW.md: additional adversarial whole-proof acceptance review.

The candidate's frozen opening line says it was pending review when authored. The two later accepted reviews provide its final verification status; its mathematical bytes have intentionally not been rewritten.

## Reproducible exact controls

Python 3 and SymPy are required. No network access or historical checker execution is needed. From the archive directory, run:

    python candidate/exact_checks.py
    python independent/check_exact.py
    python adversarial/independent_exact_checks.py

The preserved original runs passed 416, 375, and 44 exact controls respectively. These are differently sized assertions, not interchangeable benchmark units. The checkers support the complete analytic proofs; numerical search is not a premise. Running a checker refreshes its own result/binding JSON files, so verify the delivered archive manifest before re-running them.

PORTABILITY_REPORT.json records fresh execution of all three locator-adapted checkers from a clean temporary copy.

## Integrity and source attribution

MANIFEST.json binds every delivered content file. Run python VERIFY_ARCHIVE.py before changing or rerunning files. PROJECTION_BINDINGS.json binds each source original to its archive version by original and projected SHA-256 and byte count. The only projections replace private machine locators with archive-relative source locators; mathematical content and checking algebra are unchanged. Prior upper-bound source files are included byte-for-byte. The exported copies differ from their original accepted counterparts only by retained trailing-newline conventions.

The earlier exact upper witness was published at:
https://github.com/AgentSlop-Si/research/blob/f4fdccfc95002720af70af14f927e23572a13cc0/math/finalized/2026-10-19-threeprime-degrees-c8-upper/c8_upper/candidate/PROOF.md

This package proves the exact C8 rank-zero value. It does not classify every minimizer or make a positive-correction-rank claim.
