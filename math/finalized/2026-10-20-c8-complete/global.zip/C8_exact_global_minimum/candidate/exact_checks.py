"""Fresh exact algebra controls for the global C8 minimax proof.
No exploratory or historical checker is imported or executed.
"""
import sympy as s
import time,json,hashlib,pathlib
root=pathlib.Path(__file__).resolve().parent
start=time.monotonic();checks=[]
def zero(expr,label):
 r=s.simplify(s.expand(expr))
 assert r==0,(label,r)
 checks.append(label)
def nonzero(expr,label):
 r=s.simplify(s.expand(expr))
 assert r!=0,(label,r)
 checks.append(label)
def matzero(M,label):
 for j in range(M.rows):
  for k in range(M.cols):zero(M[j,k],f'{label}[{j},{k}]')
I=s.I;rt=s.sqrt(2)
f=[1,(1-I)/rt,-I,-(1+I)/rt,-1,(-1+I)/rt,I,(1+I)/rt]
F=s.Matrix(8,8,lambda j,k:f[(j*k)%8]/s.sqrt(8))
matzero(F.conjugate().T*F-s.eye(8),'normalized Fourier unitarity')
H=s.zeros(8)
for j in range(8):H[(j+4)%8,j]=1
matzero(H*H-s.eye(8),'half shift involution')
a=s.symbols('a0:8');b=s.symbols('b0:4')
c=[s.expand(sum(a[k]*f[(k*l)%8] for k in range(8))/8) for l in range(8)]
C=s.Matrix(8,8,lambda j,k:c[(j+k)%8])
matzero(C-F*s.diag(*a)*F,'arbitrary cyclic Hankel Fourier formula')
matzero(H*C*H-C,'half shift commutes for arbitrary phases')
H2=s.zeros(8)
for j in range(8):H2[(j+2)%8,j]=1
nonzero((H2*C*H2.T-C)[0,0],'control quarter shift is not generic symmetry')
a4=s.symbols('x0:4')
Cp=C.subs(dict(zip(a,a4*2)))
Bp=s.diag(*(b*2));Up=Cp*Bp
S=s.zeros(8)
for block,(j,eta) in enumerate([(0,1),(0,-1),(1,1),(1,-1)]):
 for col,k in enumerate([j,j+2]):
  S[k,2*block+col]=1/rt;S[k+4,2*block+col]=eta/rt
matzero(S.T*S-s.eye(8),'sector basis orthogonal')
alpha=(a4[0]+a4[2])/2;beta=(a4[0]-a4[2])/2
gamma=(a4[1]+a4[3])/2;delta=(a4[1]-a4[3])/(2*I)
blocks=[s.Matrix([[alpha,beta],[beta,alpha]])*s.diag(b[0],b[2]),s.Matrix([[gamma,delta],[delta,-gamma]])*s.diag(b[0],b[2]),s.Matrix([[beta,alpha],[alpha,beta]])*s.diag(b[1],b[3]),s.Matrix([[delta,-gamma],[-gamma,-delta]])*s.diag(b[1],b[3])]
matzero(S.T*Up*S-s.diag(*blocks),'full generic sector decomposition')
E,T,X,Y,U,V,W,R=s.symbols('E T X Y U V W R',nonzero=True)
params={a4[0]:E*X,a4[2]:E/X,a4[1]:T*Y,a4[3]:T/Y,b[0]:U*V,b[2]:U/V,b[1]:W*R,b[3]:W/R}
centers=[E*U,I*T*U,I*E*W,I*T*W]
traces=[(X+1/X)*(V+1/V)/4,(Y+1/Y)*(V-1/V)/(4*I),(X-1/X)*(R+1/R)/(4*I),-(Y-1/Y)*(R-1/R)/4]
for j,M in enumerate(blocks):
 M=M.subs(params)
 zero(s.det(M)-centers[j]**2,f'block {j} determinant center')
 zero(s.trace(M)/(2*centers[j])-traces[j],f'block {j} normalized trace')
zero(centers[0]*centers[3]/(centers[1]*centers[2])+I,'center ratio equals minus i')
# Exact pair-balancing identities.
aa,bb,cc,dd,q=s.symbols('a b c d q',real=True)
boundary=1-aa**2-bb**2-cc**2-dd**2+(aa*dd-bb*cc)**2
zero((bb+cc)**2-((1-aa*dd+bb*cc)**2-(aa-dd)**2)+boundary,'boundary sum identity')
K=aa**2+dd**2-aa**2*dd**2
zero((1-bb**2)*(1-cc**2)-(K+2*aa*dd*bb*cc)-boundary,'boundary cosine radicand identity')
qm=(1-aa)*(1-dd);qh=(1+aa)*(1+dd)
zero((1-aa*dd+q)**2-(aa-dd)**2-4*q-(q-qm)*(q-qh),'q constraint factorization')
zero(K-aa**2*dd**2-(aa**2*(1-dd**2)+dd**2*(1-aa**2)),'strict derivative sign decomposition')
zero(K+2*aa*dd*qm-(aa+dd-aa*dd)**2,'qmax radical square')
zero((aa+dd-aa*dd)-qm-(1-2*qm),'qmax cosine')
lam=s.symbols('lam')
zero((lam-aa)*(lam-dd)-qm-(lam-1)*(lam-(aa+dd-1)),'balanced matrix eigenvalue factorization')
# Radical threshold and explicit upper witness, in a polynomial quotient.
h,z=s.symbols('h z');relz=z*z-2*h*z+1;relh=h*h-rt+1

def reduce(expr):
 expr=s.expand(expr)
 expr=s.Poly(expr,z).rem(s.Poly(relz,z)).as_expr()
 expr=s.expand(expr)
 expr=s.Poly(expr,h).rem(s.Poly(relh,h)).as_expr()
 return s.simplify(s.expand(expr))
def algzero(expr,label):
 r=reduce(expr);assert r==0,(label,r);checks.append(label)
m=(1-h)/2;si=rt*(1-m)-m
algzero(m*m+si*si-1,'radical threshold trigonometric circle')
algzero((m+si)/rt-(1-m),'radical threshold shifted cosine')
algzero((1-m)/2-(1+h)/4,'defect half angle')
zinv=2*h-z;ze=(1+I)/rt
wparams={a4[0]:-z,a4[1]:s.conjugate(ze)*z,a4[2]:1,a4[3]:s.conjugate(ze),b[0]:1,b[1]:ze**3*zinv,b[2]:-zinv,b[3]:ze**3}
algzero(z*zinv-1,'witness reciprocal identity')
for j,M in enumerate(blocks):
 MM=M.subs(wparams)
 tr=1-h if j in [0,3] else s.conjugate(ze)*(1+h)
 det=1 if j in [0,3] else -I
 algzero(s.trace(MM)-tr,f'witness block {j} trace')
 algzero(s.det(MM)-det,f'witness block {j} determinant')
# Destructive controls do not count an accidental zero as a successful rejection.
nonzero((s.sqrt(8)*F).conjugate().T.__mul__(s.sqrt(8)*F)[0,0]-1,'control unnormalized Fourier rejected')
badparams=dict(wparams);badparams[b[2]]=zinv
bad=reduce(s.det(blocks[0].subs(badparams))-1)
assert bad!=0;checks.append('control witness b2 sign rejected')
assert bool(0<rt-1) and bool(rt-1<s.Rational(1,2));checks.append('positive radical embedding bounds')
# Bind the frozen proof and sources.
paths=[root/'PROOF.md',root.parent/'sources/upper_export.md',root.parent/'sources/upper_review_export.md']
receipts=[{'path':str(p.relative_to(root.parent)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
result={'verdict':'PASS_EXACT_ALGEBRA_CONTROLS','assertions':len(checks),'seconds':time.monotonic()-start,'checks':checks,'receipts':receipts,'scope':'Exact algebra controls supporting the written proof. No finite search is used to prove a universal inequality.'}
(root/'EXACT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','assertions','seconds']},indent=2))
