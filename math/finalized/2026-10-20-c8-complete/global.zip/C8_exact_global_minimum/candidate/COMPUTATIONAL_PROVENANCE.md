# Computational provenance and costs

20 October 2026 UTC.

The proof is analytic. No numerical experiment below is a premise of the theorem.

## Instrumented unrestricted discovery search

`explore.py` is newly written and operates on all 15 independent row/column phase variables (one column phase fixed by the exact common gauge). It does not constrain phases to be four-periodic. It uses 600 starts: one at the known witness, 299 unrestricted random perturbations of that witness with variable perturbation scale, and 300 unrestricted uniform random starts. Each start uses six fixed smoothing levels and L-BFGS-B with analytic gradients.

- 232,674 analytic value-and-gradient evaluations.
- 15.271210945007624 seconds measured numerical runtime.
- Smallest final unsmoothed singular norm found: 0.6410173178320361.
- This is above the exact known witness 0.641013699718185..., because smoothing is nonzero.
- No better witness was found. This statement has no global-optimality force.

The first launch failed before process creation because its requested working directory did not yet exist. The directory was then created from an existing workspace and the displayed run completed. No external service was involved.

## Short auxiliary discovery experiments

Three short shell snippets, not imported into the exact checker, tested possible scalar inequalities:

1. Five minimum-entry values (0.1, the exact target rounded in binary floating point, 0.2, 0.3, 0.4), with 20 SLSQP starts each, tested the four-entry contraction optimization. Every reported best value matched the proposed balanced extremum numerically. The SLSQP objective-evaluation count was not instrumented; its exact value is unknown. Each run had a 1,000-iteration maximum. The shell reported 0.658261167 seconds.
2. Fifty SLSQP starts tested a relaxation retaining only entry bounds, entry sum, and Frobenius norm. This produced a numerical counterexample to the *relaxed* sufficient chain, so that approach was abandoned. The objective-evaluation count was not instrumented; its exact value is unknown. Each run had a 1,000-iteration maximum. The shell reported 0.49903434 seconds. This is not a counterexample to the actual contraction inequality.
3. Exactly 100,000 randomly sampled nonnegative 2-by-2 contractions tested the opposite-pair inequality. The smallest floating-point gap was positive, about 8.67e-11. This served only as a sign-error smoke test; the written proof establishes the inequality without sampling. Its total isolated runtime was not separately instrumented.

These auxiliary commands have no mathematical authority and are not offered as certificates. Their missing evaluation counts do not affect the exact theorem.

## Fresh exact algebra controls

`exact_checks.py` is newly written. It does not import, execute, or rely on historical or exploratory code. It completed 416 exact assertions in 0.31478288598009385 seconds. `EXACT_CHECKS.json` records every assertion and binds the frozen proof and accepted upper-bound sources by SHA-256.

Controls include the normalized Fourier matrix, the arbitrary-phase cyclic-Hankel and half-shift identities, the complete orthogonal eight-dimensional sector decomposition, all generic block traces and determinants, all polynomial identities in opposite-pair balancing, threshold radical identities, the exact attaining witness, and destructive controls for normalization, phase sign, and an invalid stronger shift symmetry.

The universal eigenvector normalization lemma, monotonicity arguments, and angle branches are written explicitly in `PROOF.md`; the exact checker supports but does not replace those proofs.
