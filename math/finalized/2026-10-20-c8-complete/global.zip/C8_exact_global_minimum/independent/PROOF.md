# Independent global C8 rank-zero minimax proof

20 October 2026 UTC. This is a fresh derivation. No historical checker or exploratory search is a premise of the proof. The two input texts are pinned in SOURCE_BINDINGS.json.

## Verdict and exact scope

Let F[j,k]=exp(-2 pi i j k/8)/sqrt(8). Then

    min_{P,Q diagonal unitary} ||Im_entry(P F Q)||_2
      = (1/2) sqrt(1 + sqrt(sqrt(2)-1)).

This is also the minimum external operator-norm residual over arbitrary invertible complex-monomial exterior matrices and an unrestricted real core at correction rank zero. The lower-bound proof below quantifies over all phases. Four-periodicity is obtained by a proved cost-nonincreasing replacement, not imposed on an unknown minimizer.

The inherited explicit witness supplies attainment. This packet does not classify all minimizers and makes no claim at positive correction rank.

## 1. Original model and spectral equivalence

Real invertible monomial magnitude/permutation factors can be absorbed into the unrestricted real core. This changes the represented approximant, not the norm of a nonunitarily transformed residual. Thus diagonal-unitary exterior factors suffice without restricting the original approximant class.

For every complex matrix Z, ||Im_entry Z|| <= ||Z||, since Im_entry Z=(Z-conjugate Z)/(2i). Consequently min_{C real} ||V-C||=||Im_entry V||, attained by C=Re_entry V.

For V=P F Q unitary, write V=X+iY and W=V^T V. Then W is symmetric unitary and

    Y^T Y=(I-Re_entry W)/2.

Here Re_entry W=Herm(W), because W is symmetric. Set A=P^2, B=Q^2. The equality

    Q^{-1} W Q = F A F B

is unitary similarity, not merely arbitrary similarity. Therefore, with U=F A F B,

    ||Y||^2 = (1-lambda_min(Herm(U)))/2.                 (1)

Every diagonal unitary A,B has diagonal-unitary square roots, so no phase points are lost.

## 2. The unrestricted-to-four-periodic replacement

Let H e_j=e_{j+4}, indices modulo eight, and C=F A F. Its entries are c_{j+k}, so H C H=C for every A, with no periodicity assumption. Suppose

    Herm(C B) >= t I,  t>0.

Conjugating by H and averaging gives

    Herm(C E) >= t I,   E=(B+H B H)/2.

The diagonal matrix E is four-periodic and each entry has modulus at most one. No diagonal entry can vanish, because the corresponding diagonal entry of Herm(C E) would then be zero. Write E=D T, where D is a four-periodic diagonal unitary and T=|E| is diagonal with 0<T<=I.

Set Z=C D. It is unitary, hence normal. For any unit eigenvector x with Zx=lambda x, normality gives x* Z=lambda x*. Consequently

    t <= x* Herm(Z T) x = Re(lambda) (x* T x).

As 0<x*T x<=1 and t>0, Re(lambda)>=t. By the unitary spectral theorem, Herm(C D)>=t I. No commutation of Z and T is used or asserted.

Thus B can be replaced by a four-periodic diagonal unitary without lowering the Hermitian spectral minimum. The products (F A)(F D) and (F D)(F A) are unitarily similar. Apply the same argument to the latter to replace A by a four-periodic diagonal unitary A', holding D fixed, and swap back. This produces four-periodic A',B'=D with

    Herm(F A' F B') >= t I.                            (2)

The proof establishes existence of a periodic replacement; it does not say every optimum is periodic.

## 3. Four sectors and the trace contraction

Now A=diag(a0,a1,a2,a3,a0,a1,a2,a3), and similarly for B. The four orthogonal parity/half-shift sectors have bases

    (e_j+eta e_{j+4})/sqrt(2),
    (e_{j+2}+eta e_{j+6})/sqrt(2),

where j=0,1 and eta=+1,-1. Put

    alpha=(a0+a2)/2, beta=(a0-a2)/2,
    gamma=(a1+a3)/2, delta=-i(a1-a3)/2.

In sector order even,+; even,-; odd,+; odd,- the exact blocks are

    M0=[[alpha,beta],[beta,alpha]] diag(b0,b2),
    M1=[[gamma,delta],[delta,-gamma]] diag(b0,b2),
    M2=[[beta,alpha],[alpha,beta]] diag(b1,b3),
    M3=[[delta,-gamma],[-gamma,-delta]] diag(b1,b3).

Direct eight-point Fourier multiplication verifies these formulas. In particular

    det M0=a0 a2 b0 b2,    det M1=-a1 a3 b0 b2,
    det M2=-a0 a2 b1 b3,   det M3=-a1 a3 b1 b3,

and therefore

    (det M0)(det M3) = -(det M1)(det M2).               (3)

Define r_i=|tr M_i|/2. Let

    e=|(b0+b2)/2|, f=|(b0-b2)/2|,
    g=|(b1+b3)/2|, h=|(b1-b3)/2|.

Then

    R=[[r0,r2],[r1,r3]]
      = [[|alpha| e, |beta| g],
         [|gamma| f, |delta| h]].

The first factor [[|alpha|,|beta|],[|gamma|,|delta|]] has every row of Euclidean norm one. The second factor [[e,g],[f,h]] has every column of Euclidean norm one. Their entrywise product R is a contraction: for arbitrary x,y, Cauchy-Schwarz gives

    |y*R x| <= (sum_ij U_ij^2 |y_i|^2)^(1/2)
                 (sum_ij V_ij^2 |x_j|^2)^(1/2)
              = ||y|| ||x||.

Thus ||R||_2<=1.

If every eigenphase of the full unitary lies in [-theta,theta], theta<pi/2, let the two phases in sector i be nu_i +/- beta_i, with beta_i>=0. Then

    beta_i+|nu_i|<=theta,  r_i=cos(beta_i)>=cos(theta).

Equation (3) implies nu0+nu3-nu1-nu2 is pi/2 modulo pi. Its absolute value is at least pi/2, so sum_i |nu_i|>=pi/2. Hence

    sum_i arccos(r_i)=sum_i beta_i <= 4 theta-pi/2.     (4)

All arguments here use the actual principal phases inside the fixed right-half-plane arc; no determinant square-root branch is assumed.

## 4. Sharp scalar contraction lemma

Lemma. Fix 0<m<=1-1/sqrt(2). If R is a real two-by-two operator-norm contraction with every entry at least m, then

    sum_ij arcsin(R_ij) <= 2 arcsin(m)+2 arcsin(1-m),

or equivalently

    sum_ij arccos(R_ij) >= 2 arccos(m)+2 arccos(1-m).    (5)

Equality is attained by [[m,1-m],[1-m,m]].

Proof. The feasible set is compact. Every entry is strictly below one because its row contains another entry at least m>0. The objective is smooth, strictly increasing, and strictly convex entrywise. At a maximizer the spectral norm is one: otherwise scaling all entries slightly upward is feasible and improves the objective. Strict positivity makes the top singular value simple and the second singular value strictly below one.

If no entry equals m, perturb R in both directions along its second-singular-vector rank-one direction. For a sufficiently small perturbation the largest singular value remains one and all entries remain above m. Strict convexity excludes a maximum at the midpoint. Thus at least one entry equals m.

Suppose exactly one does. By row/column permutations write R=[[a,b],[c,d]], a=m and b,c,d>m. The smooth active norm boundary is

    f=1-a^2-b^2-c^2-d^2+(ad-bc)^2=0.

Indeed f=det(I-R^T R), and the other singular value is below one. Its derivative f_d=-2[d(1-a^2)+abc] is strictly negative, so locally d is a smooth function of b,c. Stationarity of the objective on this boundary, comparing the b and c equations, gives

    (sqrt((1-b^2)(1-c^2))-ad)
      (b sqrt(1-c^2)-c sqrt(1-b^2))=0.                 (6)

The first factor is strictly positive. The row-norm bounds give sqrt(1-b^2)>=a and sqrt(1-c^2)>=d. Equality in their product would force both rows to have norm one, impossible for a positive contraction because their inner product is strictly positive. Hence the second factor vanishes and b=c.

The matrix is then symmetric positive-entry with largest eigenvalue one, giving

    d=1-b^2/(1-a).

Along this symmetric boundary the objective derivative with respect to b is

    2/sqrt(1-b^2) - 2/sqrt(2(1-a)-b^2) > 0,          (7)

because a=m<1/2. Increasing b slightly decreases d but keeps d>m and all other strict inequalities valid, contradicting maximality. Thus every maximizer has at least two entries equal to m.

If two such entries are adjacent, the remaining row or column has Euclidean norm at most one, so the sum of the arcsines of its two entries is at most pi/2. Since m<=1-1/sqrt(2), pi/2<=2 arcsin(1-m). This proves the required bound in that case, including three or four active entries whenever this case is chosen.

If the two active entries are opposite, permute to R=[[m,b],[c,m]]. Set u=(b+c)/2, v=|b-c|/2, s=sqrt(m^2+v^2). Its norm is u+s, so u<=1-s. Increasing u raises both free entries and the objective; thus an upper bound comes from u=1-s. The derivative in v of arcsin(u+v)+arcsin(u-v) is nonpositive. All factors used in squaring are positive, and the required squared inequality has the exact difference

    (s+v)^2[1-(u+v)^2]-(s-v)^2[1-(u-v)^2]
       =4m^2 v >=0,   where u=1-s and s^2=m^2+v^2.    (8)

The derivative is strictly negative for v>0. At v=0, b=c=1-m, proving (5). The proposed equality matrix is feasible and has singular values 1 and 1-2m. This exhausts the feasible maximizers and proves the lemma.

## 5. Global lower bound and attainment

Set

    q=sqrt(sqrt(2)-1), m=(1-q)/2, theta*=arccos(m).

Here 0<m<1-1/sqrt(2). The exact identity

    sqrt(1-m^2)=sqrt(2)(1-m)-m>0

and theta* in (pi/4,pi/2) imply

    arccos(1-m)=theta*-pi/4.                           (9)

Suppose some original-model phase choice has error strictly smaller than

    d*=(1/2)sqrt(1+q).

By (1), its Hermitian spectral minimum is strictly greater than m>0. Let theta<theta* be the maximum absolute principal eigenphase. The replacement in Section 2 gives four-periodic phases with every eigenphase still in [-theta,theta]. Construct R as above. Every entry is at least cos(theta)>m, so the scalar lemma applies with the FIXED parameter m, even if cos(theta)>1-1/sqrt(2). Equations (5) and (9) give

    sum_i arccos(r_i) >= 4theta*-pi/2,

whereas (4) gives sum_i arccos(r_i)<=4theta-pi/2. These inequalities contradict theta<theta*. Thus every legal phase choice has error at least d*.

The source-pinned exact four-periodic witness already attains d*. Its explicitly legal P,Q and C=Re_entry(PFQ), with exterior L=P*, R=Q*, establish attainment in the original unrestricted complex-monomial model. Therefore the global minimum is exactly d*.

## 6. Verification and limitations

The accompanying fresh checker verifies the unrestricted half-shift commutation, the exact generic eight-by-eight sector decomposition and determinant signs, the scalar boundary algebra and derivative identities, the radical threshold identities, and source hashes. The quantified inequalities are proved analytically above; finite symbolic checks are supporting controls, not an attempted numerical proof of a universal statement.

No numerical optimization was run for this independent proof. No source-packet code was imported or executed. No external state was modified.
