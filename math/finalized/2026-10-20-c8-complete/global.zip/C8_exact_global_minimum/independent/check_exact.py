#!/usr/bin/env python3
"""Fresh exact controls supporting, not replacing, the quantified analytic proof."""
import hashlib, json, time
from pathlib import Path
import sympy as S

start=time.perf_counter()
root=Path(__file__).resolve().parent
checks=[]
def check(label, expr):
    expr=S.sympify(expr)
    z=S.simplify(S.expand_complex(expr)) if not expr.free_symbols else S.simplify(S.expand(expr))
    assert z==0, (label,z)
    checks.append(label)
def checkmat(label, M):
    for j in range(M.rows):
        for k in range(M.cols): check(f'{label}[{j},{k}]',M[j,k])

i=S.I; sq2=S.sqrt(2)
roots=[1,(1-i)/sq2,-i,(-1-i)/sq2,-1,(-1+i)/sq2,i,(1+i)/sq2]
F=S.Matrix(8,8,lambda j,k:roots[(j*k)%8]/S.sqrt(8))
checkmat('Fourier unitarity',F.H*F-S.eye(8))
checkmat('Fourier symmetry',F.T-F)
H=S.zeros(8)
for j in range(8): H[(j+4)%8,j]=1
avec=S.symbols('a0:8')
C=F*S.diag(*avec)*F
checkmat('Unrestricted half-shift commutation',H*C*H-C)

a0,a1,a2,a3=S.symbols('a0 a1 a2 a3')
b0,b1,b2,b3=S.symbols('b0 b1 b2 b3')
A=S.diag(a0,a1,a2,a3,a0,a1,a2,a3)
B=S.diag(b0,b1,b2,b3,b0,b1,b2,b3)
cols=[]
for j,eta in [(0,1),(0,-1),(1,1),(1,-1)]:
    for offset in [0,2]:
        v=S.zeros(8,1);v[(j+offset)%8]=1/S.sqrt(2);v[(j+offset+4)%8]=eta/S.sqrt(2)
        cols.append(v)
T=S.Matrix.hstack(*cols)
checkmat('Orthogonal complete sector basis',T.T*T-S.eye(8))
al=(a0+a2)/2;be=(a0-a2)/2;ga=(a1+a3)/2;de=-i*(a1-a3)/2
blocks=[S.Matrix([[al,be],[be,al]])*S.diag(b0,b2),
        S.Matrix([[ga,de],[de,-ga]])*S.diag(b0,b2),
        S.Matrix([[be,al],[al,be]])*S.diag(b1,b3),
        S.Matrix([[de,-ga],[-ga,-de]])*S.diag(b1,b3)]
checkmat('Full generic sector decomposition',T.T*F*A*F*B*T-S.diag(*blocks))
dets=[a0*a2*b0*b2,-a1*a3*b0*b2,-a0*a2*b1*b3,-a1*a3*b1*b3]
traces=[al*(b0+b2),ga*(b0-b2),be*(b1+b3),de*(b1-b3)]
for j in range(4):
    check(f'Generic sector determinant {j}',blocks[j].det()-dets[j])
    check(f'Generic sector trace {j}',S.trace(blocks[j])-traces[j])
check('Determinant-center negative product',dets[0]*dets[3]+dets[1]*dets[2])
assert S.expand(dets[0]*dets[3]-dets[1]*dets[2])!=0
checks.append('Destructive determinant-sign control rejected')

# Exact algebra for the independent KKT proof.
a,b,c,d=S.symbols('a b c d', positive=True)
f=1-a*a-b*b-c*c-d*d+(a*d-b*c)**2
check('Norm-boundary determinant',f-(S.eye(2)-S.Matrix([[a,b],[c,d]]).T*S.Matrix([[a,b],[c,d]])).det())
check('Boundary derivative d',S.diff(f,d)+2*(d*(1-a*a)+a*b*c))
u,v=S.symbols('u v',positive=True)
check('Stationarity factorization',(b*v*v+a*c*d)*u-(c*u*u+a*b*d)*v-(u*v-a*d)*(b*v-c*u))
check('Symmetric norm-one boundary',f.subs({c:b,d:1-b*b/(1-a)}))
check('Symmetric derivative denominator',(1-(1-b*b/(1-a))**2)-b*b*(2*(1-a)-b*b)/(1-a)**2)
m,s,v=S.symbols('m s v',positive=True)
u=1-s
D=(s+v)**2*(1-(u+v)**2)-(s-v)**2*(1-(u-v)**2)
check('Opposite-bound derivative square difference',S.expand(D-4*v*m*m).subs(s*s,m*m+v*v))
R=S.Matrix([[m,1-m],[1-m,m]])
check('Sharp matrix determinant',R.det()-(2*m-1))
check('Sharp matrix trace',S.trace(R)-2*m)
check('Sharp matrix eigenvalue one', (R-S.eye(2)).det())

# Independent controls for the solver's separate pair-balancing proof.
q=S.symbols('q')
K=a*a+d*d-a*a*d*d
check('Pair norm-boundary cosine radicand',((1-b*b)*(1-c*c)-(K+2*a*d*b*c))-f)
check('Pair offdiagonal sum identity',(b+c)**2-((1-a*d+b*c)**2-(a-d)**2)+f)
check('Pair quadratic factorization',q*q-2*(1+a*d)*q+(1-a*a)*(1-d*d)-(q-(1-a)*(1-d))*(q-(1+a)*(1+d)))
check('Pair endpoint radical square',K+2*a*d*(1-a)*(1-d)-(a+d-a*d)**2)
check('Pair endpoint cosine',a+d-a*d-(1-a)*(1-d)-(1-2*(1-a)*(1-d)))
check('Pair strict derivative positive margin',K-a*a*d*d-(a*a*(1-d*d)+d*d*(1-a*a)))

# Positive embedding and the exact sharp threshold.
h=S.sqrt(S.sqrt(2)-1);m0=(1-h)/2
check('Threshold sine square',(sq2*(1-m0)-m0)**2-(1-m0*m0))
check('Lemma range margin',(1-1/sq2-m0)-(h-h*h)/2)
check('Sharp norm squared',(1-m0)/2-(1+h)/4)
check('Unit-modulus witness z',h*h+(2-S.sqrt(2))-1)
# Exact candidate witness squares and full generic block invariants.
z=h+i*S.sqrt(2-S.sqrt(2));zeta=(1+i)/S.sqrt(2)
rho=S.sqrt(2+S.sqrt(2))/2+i*S.sqrt(2-S.sqrt(2))/2
w=S.sqrt((1+h)/2)+i*S.sqrt((1-h)/2)
check('Witness w square',w*w-z)
check('Witness rho square',rho*rho-zeta)
check('Witness z modulus',z*S.conjugate(z)-1)
check('Witness w modulus',w*S.conjugate(w)-1)
PP=[-i*w,S.conjugate(rho)*w,1,S.conjugate(rho)]
QQ=[1,rho**3*S.conjugate(w),i*S.conjugate(w),rho**3]
AA=[-z,S.conjugate(zeta)*z,1,S.conjugate(zeta)]
BB=[1,zeta**3*S.conjugate(z),-S.conjugate(z),zeta**3]
for j in range(4):
    check(f'Actual P phase square {j}',PP[j]**2-AA[j])
    check(f'Actual Q phase square {j}',QQ[j]**2-BB[j])
sub=dict(zip([a0,a1,a2,a3,b0,b1,b2,b3],AA+BB))
for j in range(4):
    tr_target=1-h if j in [0,3] else S.conjugate(zeta)*(1+h)
    det_target=1 if j in [0,3] else -i
    check(f'Witness sector trace {j}',traces[j].subs(sub)-tr_target)
    check(f'Witness sector determinant {j}',dets[j].subs(sub)-det_target)
# Noncommuting normal-factor identity: no hidden commutation of Z,T.
Z=S.Matrix([[S.Rational(3,5),4*i/5],[4*i/5,S.Rational(3,5)]])
TT=S.diag(1,S.Rational(1,2));x=S.Matrix([1,1])/S.sqrt(2);lam=(3+4*i)/5
checkmat('Noncommuting illustration unitary',Z.H*Z-S.eye(2))
check('Normal-factor eigenvector expectation',(x.H*Z*TT*x)[0]-lam*(x.H*TT*x)[0])
assert Z*TT-TT*Z!=S.zeros(2)
checks.append('Noncommuting T control genuinely noncommuting')

sources=[root.parent/'sources/upper_export.md',
         root.parent/'sources/upper_review_export.md',root/'PROOF.md',root.parent/'candidate/PROOF.md']
bindings=[]
for p in sources:
    data=p.read_bytes();bindings.append({'path':str(p.relative_to(root.parent)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(root/'SOURCE_BINDINGS.json').write_text(json.dumps(bindings,indent=2)+'\n')
result={'status':'PASS','exact_checks':len(checks),'elapsed_seconds':time.perf_counter()-start,
        'numerical_optimization_evaluations':0,'historical_code_executed':False,
        'scope':'Exact algebra controls supporting the complete analytic quantified proof in PROOF.md.',
        'checks':checks,'sources':bindings}
(root/'CHECK_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','sources']},indent=2))
