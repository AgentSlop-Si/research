# Three finite exact-record closure evidence sets

These are byte-identical retained source, certificate and independent-review objects. No research checker was run in the 15 October 19:35 scope-administration audit. Historical files retain their original dates, assertions, filenames and execution language. Consult the parent manifest for archive/member hashes and the exact fresh actions.

M-F8-EXACT: Original full local-existence proof and REVIEW-09 accepted record, full 120-coordinate/64-variable data, approximate inverse, exact rational bounds, unmodified independent checker and its historical receipt. The same checker also handles F4 and bit-reversal controls, so their two inputs are retained solely as unmodified-checker dependencies; no additional record is proposed for closure.

M-N3-POSITIVE: Self-contained original algebraic proof, REVIEW-12 accepted record and historical exact results. Both cube-root embeddings, both quadratic roots and every nonzero guard are included.

M-FIXED-POLE-N4: Complete original projective-family proof, REVIEW-13 accepted record, six-minor/resultant data, original source receipts and three later independent reconstructing checkers with exact historical result files. These cover finite regular, zero-middle-support and infinity charts. The complete REVIEW-13 portable replay receipt also mentions other records outside this minimal set; it is retained as historical evidence, not presented as a runnable wrapper for this subset.

Do not call archival receipts a new replay. The proposed changes concern completion of the original exact finite record only. Worldwide priority, alternative parameters, growing-size constructors, asymptotic performance and numerical production remain unclaimed. The source manifest carries older repository links as historical verified pins; no network read was made here.
