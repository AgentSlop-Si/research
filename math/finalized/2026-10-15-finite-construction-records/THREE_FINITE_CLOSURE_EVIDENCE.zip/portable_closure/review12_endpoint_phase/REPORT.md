# REVIEW-12: endpoint, phase, and restricted Green architectures

Date: 2026-10-10 UTC. Existing-table review only. No new fusion, inherited program execution, repository mutation, or other external write.

## Outcome

All ten assigned rows retain **proved_scoped** status after fresh proof review. This is not a statement that every historical experiment was replayed, that a general Fourier constructor exists, or that the open parameter problems are solved. Fresh exact checks cover twelve groups, including the N256 subset certificates, N13 coefficient exclusion, N3 algebraic realization, N64 sector determinants, N8 pencil determinant, N8/N16 seed-polynomial exclusions, and exact N4 positive-middle certificate.

The current single-Green endpoint theorem is bound to M-SPARSE-PREFIX as a **related supplemental statement**, not silently identified with the older sparse-inverse-prefix/additive-tail theorem. Both statements survive review. The open/reset versus closed-cyclic tour correction is retained.

The material boundaries are:

- Capacity, phase rank, seed balancing, and local coefficient gates are generally necessary conditions. Their passing does not synthesize Fourier coefficients.
- The phase-pencil characterization and sparse-bridge matrix equation are genuine equivalences only in their expressly guarded domains. One pencil determinant or the scalar determinant equation is not sufficient.
- Positivity assumptions are on the specified matrix or combination weights. Arbitrary complex internal diagonal masks do not remove those hypotheses. General signed or complex branch amplitudes cannot be treated as positive by renaming them.
- Finite successful algebraic controls and nonvanishing reductions do not yield a uniform all-length construction. Nonzero modular determinants can certify characteristic-zero nonvanishing under good-reduction guards; arbitrary modular solutions do not lift this way.
- Endpoint count, representation depth, diagonal-defect rank, and sector-mixing rank are distinct from arithmetic runtime. A separately justified evaluator or computational model is necessary for runtime conclusions.

## Evidence and review depth

`SOURCE_PINS.json` identifies 26 exact source/review/data files at repository commit `8604bdf099c01006e3c18030bbf123a59ead893e`. Every assigned full review/theorem body and its catalogue overlay was read. Additional primary Phase35/36 theorem bodies, the original sparse-prefix audit, current endpoint proof, and finite coefficient data were read as applicable. Some archive names contain an original hash while repository exports have a different, previously sanitized hash; both identities are retained rather than falsely asserting original-byte equality.

`checks/fresh_checks.py` was written for this review and uses only the Python standard library. It executes no inherited implementation. Saved JSON is inert mathematical data. `checks/CHECK_RESULTS.json` distinguishes fresh results from prior accepted dependencies. Finite controls support the independently assessed proofs; they do not replace the proofs.

Historical details not newly replayed: the N256 full 3,825-flow optimality scan and all 510 modular block ranks; N8 four-Green assembly and all 12,869 candidate minors; the N16 algebraic seed contraction certificate and copied-inner N64 rational enclosure. These are retained as clearly identified prior accepted dependencies. The N64 signed-sector obstruction and strengthened mixing gate were independently reconstructed without using the algebraic seed.

## 1. M-ALL-STAGE-SUBSETS

Accepted scope: the saved four-QS1 affine N256 layout, natural stage orders, and the fifteen nonempty subsets of four stages. For arbitrary diagonal baselines D_j, including singular baselines, h_j=rank(S_j−D_j) obeys singleton bounds 38,44,69,46; pairs 119,118,112,109,95,105 in the stated order; every triple 127; all stages 128. The total is at least 234, and (70,49,69,46) proves optimality only in this fifteen-inequality relaxation.

Independent proof check: for any coordinate set A, split the strictly lower and upper cross-partition blocks by maximal runs of A. The number of boundaries d(A) bounds the total crossing rank for general order-one propagation generators, including zero transfer coefficients. Transport A through each actual row-sampling permutation. Replacing selected stages by diagonals removes their crossing budgets. A telescoping product difference has rank at most the sum of the replaced h_j, without any inversion. A full-rank Fourier witness block supplies the remaining lower bound.

Fresh evidence: all 255 transported parity boundary tuples match; all fifteen witness blocks have the recorded nonzero determinants at both primes 12289 and 65537, with roots 8340 and 282 of exact order 256. The relaxation vector satisfies every inequality and its sum is 234. An additional 60 QS partition controls and 225 all-subset product-replacement controls include zero propagation and singular baselines.

Limits: the coordinate family is the 255 parity masks, not all 2^256 coordinate subsets. The stored Toffoli sequence is unused. Actual Fourier factors attaining the relaxation vector remain unconstructed. A rank-N−1 scan can still apply in linear work. The inverse-defect extension needs both S and D invertible; the main theorem does not.

## 2. M-PHASE-PENCIL

Accepted scope: fixed invertible A,B and fixed Fourier ordering. Let K_j=A diag(B[:,j+1])−Delta A diag(B[:,j]), with cyclic column indexing. For an all-nonzero d, every K_j d=0 is equivalent to M=A diag(d)B obeying MS=Delta M. Each row is therefore a scalar Fourier row; invertibility makes every row scalar nonzero and supplies the output diagonal L. Conversely L commutes with Delta. This establishes the guarded fixed-stage equivalence.

A nonzero det K_0 rejects every allowed middle diagonal. A singular K_0 alone is insufficient. Fresh controls build eight hidden-gauge positives and the exact countercontrol B=F+e_0e_2^T: K_0=0 but K_1 forces d_0=0. The saved N8 pencil matrix has determinant 55687 modulo 65537 by fresh elimination and an independent 8! Leibniz sum.

The accepted full-spark four-Green witness only defeats **one-sided rank-capacity sufficiency**. The exact Fourier submatrix at rows {0,4}, columns {0,2} has rank one; a full-spark candidate has rank two. Thus exact rank-profile equality rejects that candidate. The full four-branch assembly and exhaustive minors remain bound to the prior accepted receipt, not claimed rerun here.

The Cauchy–Binet generic diagonal-rank argument is correct: independent squarefree parameter monomials cannot cancel, so generic rank is the common-independent-set size of the two represented matroids; the classical matroid-intersection minimum applies. It addresses generic attainable ranks, not target coefficient equality. Graph potentials require exact support equality, self-loop equality, and all closed-walk consistency. Linear graph traversal cost starts after graph entries exist; dense formation and verification remain charged. Free new endpoint permutations require new pencils.

## 3. M-POSITIVE-PHASE

Accepted scope: positive first-cross matrix scaling; entrywise-nonzero phase-rank bounds; a strictly positive real middle with arbitrary invertible complex internal diagonal/permutation masks; and quantitative near-identity exterior factors.

Independent proof check: writing u=r*x, v=s*y converts first-cross calibration to prescribed positive row/column marginal scaling. Equal total masses and strict positivity justify classical scaling; the 2N−1 matched entries do not determine the remaining Fourier entries. For the Markov cyclic resolvent with beta=1−1/N, entry spread is below e, hence bounded projective contraction and O(log(1/epsilon)) iterations. These are approximate-mask ideal-real preprocessing statements, not finite exact rational mask production or a precision theorem.

For H=sqrt(N)F and phase matrix U, the entrywise reverse triangle inequality gives |H−U|≤2|H−sqrt(N)T|. Eckart–Young and the flat Fourier spectrum yield ||F−T||_F≥sqrt(N−r)/2. For positive middle factors the row/column phase form allows the stronger doubled-character estimate ||F−T||_F²≥(N−sqrt(gcd(2,N)N))/2. Exterior singular-value and inverse perturbation bounds yield [s0(1+c_N)−1]_+, s0=(1−delta_A)(1−delta_C).

Fresh evidence: the exact Q(i) N4 cross-ratio for eta=1/100, beta=3/4 and the two specified traversal orders matches both large rational components of the saved receipt and has nonzero imaginary part. Sixty-five exact triangular phase determinant controls reproduce det H(zeta)=(1−zeta)^(N−1), and the necessary rank fraction at delta=1/50 is exactly 5725597/5764801.

Limits: one complex Green already has phase rank N while applying in linear work. Its three-value cross-ratio restriction still obstructs Fourier at 4|N. The rank-one phase case may require a global minus sign for rho>1; this is retained. No unrestricted signed/complex-amplitude network exclusion is inferred. Zero entries lie outside the stated phase-matrix definition. A different middle matrix or exterior factors beyond the quantified perturbation domain require a separate theorem.

## 4. M-SEED-BALANCE

Accepted scope: F=A D B with invertible A and invertible bi-regular B, including an absorbable middle permutation. The invariant A[0,i](A^−1)[i,0]=1/N is necessary and sufficient when B is otherwise unrestricted. The first-row entries must be nonzero; the constructed B=D^−1 A^−1 F is bi-regular but can contain the entire expensive Fourier action.

Independent proof check: the first Fourier row forces d_i=1/(b A[0,i]); applying to the all-ones vector gives A(1/A[0,*])=N e_0. For A=c(I+E), ||E||≤delta<1, the off-diagonal inverse identity gives |A_00(A^−1)_00−1|≤delta²/(1−delta). Delta<1/2 excludes N≥2. Positive real scalar combinations of permutation resolvents with |alpha_s|<1/3 satisfy this after division by their positive total weight. Arbitrary signed combination coefficients or independent endpoint masks do not automatically satisfy the bound.

Fresh evidence: an exact N4 A=J−2I positive control yields a bi-regular B and full Fourier equality. For each fixed N8/N16 cycle pair, the three supplied integer polynomials were checked against fresh determinant/cofactor evaluations at D+1 distinct nodes modulo 2^127−1, D=N(N−1). Lucas–Lehmer establishes primality. The actual and supplied coefficient bounds are below half the modulus, so modular polynomial identity certifies characteristic-zero identity. A new primitive polynomial Euclidean computation gives gcd degrees 46 and 209, and verifies gcd divisibility into det C. Thus common roots force singularity; z^N=1 remains an excluded undefined-Green branch.

Limits: these exclusions concern two specified traversal-order pairs with one common coupling, not independent couplings, all orders, or added masks. Signature matching certifies only the first cross. Exact comparison/sorting, hashing representation, coefficient preparation and storage are charged.

## 5. M-N64-LIFT

Accepted scope: the specified eight nested routes, poles 1/2 through 1/9, one-sided row masks, and stated F8 bank. The frozen two-inner correction is excluded by its prior accepted augmented-minor enclosure. More strongly, any commuting or anticommuting prefix is excluded. A successful unrestricted one-inner lift must have both high-x cross-sector blocks of rank at least four, an odd component of rank at least eight, and at least four unequal coefficient pairs.

Fresh evidence: the eight small and large routes were independently generated from raw shears, cycle splicing and fiber-head rotation; every saved successor agrees, every large cycle is Hamiltonian, quotient identities hold, and each 32nd power is the high-x shift. Eight Green matrices were directly inverted over GF(998244353). All 64 projected 8-square minor residues match. The two 32-square direct-sum residues are 871168069 and 682055007. All denominator guards are units. These certify the rational frame ranks over characteristic zero without specializing the algebraic seed.

Independent proof check: any nonzero available outer row has both sector projections, contradicting the pure sector of a Fourier row after an invertible signed prefix. Four direct-sum row frames force rank A=4 in the zero target-sector equation A D+B C=0. Invertibility of the whole varying layer makes [D;C] injective. D maps ker C injectively into ker A, giving rank A≤rank C. No invertibility of D is needed. Exhausting all 210 injective 4-by-2 columns over GF(2) checks the abstract kernel step, including singular D.

Limits: full 1536-variable and unrestricted one-inner coefficient systems remain open. A singular whole factor cannot appear in a successful product with invertible target, but singular diagonal-sector blocks must not be discarded. General outer row membership must retain every rank stratum and valid pivot chart; a failed chart is not exclusion of all charts. Mixing rank is not computational work. Historical seed-enclosure and frozen-inner interval certificates were not rerun in this packet.

## 6. M-N3-POSITIVE

Accepted scope: a constant-size complex algebraic realization of the forced B=(diag(1,w²,w²)+F_3^−1)^−1, where w is either primitive cube root. "Positive control" means a successful example, not positivity of its complex coefficients.

Fresh exact arithmetic over Q(w) reconstructs all nine entries. With d=(−1+9w)/14, e=(−3−w)/14 and t²+t=2e/d, the opposite 3-cycle resolvents sum to [2I+(t+t²)(P+P²)]/(1−t³). Multiplication by kappa=d(1−t³)/2 and D=diag(w,1,1) on both sides gives B. The exact quadratic norm of 1−t³ is (7860+4344w)/2197, nonzero. Both roots are valid; t and kappa are nonzero and all endpoint masks are invertible.

No modular-to-complex existence inference is used, no singular branch is hidden, and neither an all-N family nor an asymptotic speedup follows.

## 7. M-CHIRP-NECESSARY

Accepted scope: odd N≥3 in a primitive-root field with characteristic not dividing 2N, legal chirp denominator 1+NG, and the precisely stated endpoint grammar.

Independent proof check: X=B^−1=A+F^−1 has every off-diagonal entry nonzero and at least one surviving diagonal, hence a full row. All complex diagonals survive by unequal magnitudes; finite fields can cancel some diagonals. Products of L monomial-ended legal single Greens have inverse row support at most 2^L, giving 2^L≥N. This does not extend to additive stage inverses. The complementary inverse-block rank identity holds without principal-block invertibility, so every B complementary cut inherits the F^−1 cut rank; consecutive half cuts are Vandermonde-full-rank. Arbitrary monomial endpoint routing must contribute its own cut budget. Circular displacement sums count exactly the shorter distances.

Fresh evidence: the GF(521), N5 diagonal cancellation vector [418,24,0,0,24] is reproduced. Direct inversion at N13 reproduces the four-by-four coefficient matrix and determinant 60131 modulo 65521. All 13 half-cut ranks are six while the fixed cycle pair passes the capacity test. The nonzero determinant proves a characteristic-zero fixed-order exclusion by legal cyclotomic reduction, not just failure at one parameter sample.

The inverse-defect continuation also checks algebraically: if B^−1=S+E and S has row degree d, subtracting its known diagonal chirp gives F^−1=(S−A)+E with row degree at most d+1. Selecting consecutive Fourier rows and columns outside their sparse support gives rank E≥floor(N/(d+2)). For actual inverse-factor decompositions, telescoping bounds the accumulated error rank by the sum of defect ranks and multiplies the sparse row-degree budgets. Singular sparse baselines are allowed; the actual inverses and routing descriptions must exist.

The gate is division-free and necessary: the four-vector of denominator coefficient products must be nonzero and decomposable. Rank three alone need not imply decomposability. Formal epsilon replacement of zero endpoint scales extends the polynomial identity to singular endpoints; the Green denominators themselves must remain legal. Fresh tests cover 780 row-pair controls with zero edges, singular masks, and an entirely zero branch. Other orders, additional branches, or arbitrary new endpoint permutations remain unexcluded.

## 8. M-SPARSE-BRIDGE

Accepted exact equivalence for individually invertible A,B,C,D:

M=(A^−1+B^−1)(C^−1+D^−1),
A M D=(A+B)(CB)^−1(C+D).

Thus M=F iff det(CB) A F D=(A+B) adj(CB)(C+D), within the determinant-guarded domain. Noncommutativity fixes the order CB. The scalar determinant equation is necessary only. Literal I−weighted-cycle denominators yield three-sparse sums and four-sparse CB; independent monomial gauges can raise each sum to four-sparse while preserving the general identity.

Fresh evidence: sixteen noncommutative examples with zero edges verify the bridge and literal support bounds. The GF(13) singular-denominator control makes the cleared equation 0=0 with undefined M; it is correctly rejected by the guards. Another GF(13) control has det M=det F=5 but M≠F, refuting determinant-only acceptance.

A supplied CB inverse applies by two supplied cyclic solves in O(N) field operations; synthesis of Fourier-producing coefficients is the open issue. This factor structure must not be mislabeled as an arbitrary hard sparse solve. Conversely, its O(N)-sparse description is not a construction or a runtime lower bound. Singular endpoint-scaled branches outside the inverse parameterization cannot be silently omitted from a broader additive architecture.

## 9. M-SPARSE-PREFIX and current endpoint supplement

### Historical sparse-inverse-prefix/additive-tail theorem

Accepted: for totally nonsingular T=P^−1 H, invertible row-s-sparse P, d distinct independent row/column order pairs, and terminal total separation rank R, floor(N/(s 2^d))≤R. Rank budgets are integers. Handle m=0 as vacuous before applying the halving lemma; the source helper's empty-set convention is not a proof failure and must not be confused with both target cardinalities being zero.

Independent proof check: simultaneous asymmetric halving produces m selected rows and at least sm columns. The union of selected P-row supports has size at most sm; total nonsingularity gives a right inverse of the corresponding T rectangle, preserving row rank m after mixing. Each separated terminal term contributes its own rank budget. Single-Green inverse factors supply s≤2^t, including zero edge weights. Therefore complex prime Fourier requires p<(Q+1)2^(t+d), and the stated first excluded primes 29 and 53 follow in the worst-case d=Q=2.

Fresh exhaustive position-set controls and Cauchy sparse-mixing controls pass. Composite Fourier is not assumed full spark. The fixed-P singular-value approximation certificate can deteriorate arbitrarily with P and is not a uniform conditioning-independent gap. A product of two independently additive Green sums is outside this theorem.

### Related current single-Green sparse-endpoint theorem

The current proof `math/updates/2026-10-10-1200/notes/02_sparse_prefix_bounds.md` establishes nnz(C)+nnz(R)=Omega(N log N/log log N) for F_N=R G C with one nonsingular scalar first-order weighted cyclic Green inverse, arbitrary latent length M, arbitrary uneven endpoints, and zero weights. This is a different grammar from the theorem above.

Write a=nnz(C)/N, b=nnz(R)/N and r=floor(2b). Rank forces a,b≥1. More than half the outputs have degree at most r. If r≥N the quadratic endpoint bound already suffices; otherwise a consecutive cyclic window of r+1 Fourier columns has at most floor((r+1)a) forced recurrence rows. Homogeneous intervals introduce no new projective direction; zero recurrence weights only erase directions. The rank-r+1 Fourier restriction forces at least r+1 directions. Each degree-r output lies in one of at most binom(floor((r+1)a),r) subspaces, each containing at most r Fourier rows by consecutive-column Vandermonde independence. Consequently ceil(N/2)≤r binom(floor((r+1)a),r), and the transpose yields its companion. The elementary logarithmic estimate gives the stated lower bound. This uses all lengths over an exact primitive-root field, not prime-only full spark.

Fresh cyclic recurrence controls include zero weights and verify the projective-direction count. Exact exhaustive tours at B=2,4,8 give open/reset optima 3,11,43 and nonsingular closed-cyclic optima 2,10,42. The general formulas remain (2B²+1)/3 and (2B²−2)/3 respectively, the closed formula requiring dyadic B≥2. A closed collection of blocks is not automatically one scalar cyclic scan.

The lower bound is representation size and runtime only for the specified scalar evaluator that processes every endpoint term. Its counted apply ledger is 4M+2(nnz(C)+nnz(R))+1; setup and arbitrary-record sorting/canonicalization are separate. It excludes uniform O(N) and O(N log log N) explicit endpoint families in this grammar, not implicit endpoint evaluators, packed word operations, multiple interacting scans, approximate/sparse-input promises, or arbitrary DAGs. The proposed matching-order upper construction is still conjectural; the supplied growing construction costs Theta(N^(3/2)).

## 10. M-TWISTED-DISPLACEMENT

Accepted grammar: products of sums of c D^a P B^−1 P^−1 D^b, where B is an invertible constant-coefficient tridiagonal path matrix, P is an affine conjugating permutation, and a,b are integers. Arbitrary masks, arbitrary path orders, independent left/right affine maps, and bare affine multipliers are not covered.

Independent proof check: with T(A)=Z^−1 A Z and W=Z^−1 D, T^k(F)=omega^(k(k−1)/2) W^k F. The common-path displacement budget is two; affine conjugation raises it to at most four by the rank-two boundary correction. The twisted product identity makes branch ranks additive. A polynomial with one root for each distinct surviving branch phase has degree d and gives rank p(T)M≤d sum r_nu. For Fourier, p(T)F=h(W)F, deg h=d. The weighted shift W is cyclic, so nullity h(W)=deg gcd(h,m_W)≤d even without a spectral extension. Therefore N≤d(1+sum r_nu)≤b+rho*t*b².

Fresh exact checks cover thirteen prime and composite lengths, phase powers beyond a full cycle, polynomial rank bounds, and all affine conjugations at those lengths. The bare affine multiplier at N9 has displacement rank eight and rejects the uncharged-wiring overextension. Repeated phases need one root; canceled or zero branches can be removed. If every branch vanishes, M=0 cannot be invertible Fourier and must be rejected separately. For one phase at even N, the stronger N≤sum r_nu remains valid; for odd N the Fourier displacement rank is N−1.

The ancillary one-inverse-row sharpness formula was also checked algebraically: restricting one row of F* to s coordinates, setting beta²=s/N, b=u/beta², r=e_i^T−bF, and M=F+b* r/||b||² gives bM=e_i^T, det M/det F=beta²>0, and ||M−F||₂=sqrt(1−beta²). This is sharpness for a single inverse-row support constraint only, not for all rows or a full Green grammar.

Constant q≥2 and fixed rho imply logarithmic stage depth; q=1 gives t≥(N−1)/rho. Neither conclusion is an unrestricted arithmetic lower bound or an approximation floor. Singular Green denominators are invalid; zero scalar branch coefficients are legal and may simply reduce the surviving branch set.

## Remaining work and stopping condition

This packet closes the assigned existing-table review, not the open mathematical constructions. Uniform Fourier-producing coefficient synthesis, unrestricted one-inner N64 feasibility, matching single-Green endpoint upper construction, and broader signed/complex/amplitude architectures remain open or outside these theorems. No publication priority or practical performance conclusion is added.

Replay: run `python3 checks/fresh_checks.py` from this packet or any copied location preserving its `sources/` directory. It reads inert source parameters and emits `checks/CHECK_RESULTS.json`. `VALIDATION.json` records isolated replay and the source/deliverable seal.
