"""Fresh REVIEW-09 exact checks. Read only inert JSON; execute no inherited code."""
from pathlib import Path
from fractions import Fraction as Q
from math import isqrt
import json, hashlib, ast
D=Path(__file__).resolve().parents[1]; I=D/'inputs'; OUT={}
def load(glob):return json.loads(next(I.glob(glob)).read_text())
def ga(x,y):return (x[0]+y[0],x[1]+y[1])
def gm(x,y):return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def mm(A,B):return [[tuple(map(sum,zip(*(gm(x,y) for x,y in zip(row,col))))) for col in zip(*B)] for row in A]
def l1(x):return abs(x[0])+abs(x[1])
# F8 uses common dyadic denominators and exact integer matrix arithmetic.
v=load('206a*'); den=1<<v['center_bits']; bden=1<<v['inverse_bits']; p=v['permutation']; center=[tuple(x) for x in v['center']]
assert len(center)==120 and len(set(v['selected_columns']))==64 and v['target']=='F8/sqrt(8), positive Fourier sign'
def product(z):
 stages=[]
 for s in range(3):
  a,b,c,e,d=[z[s*40+j*8:s*40+(j+1)*8] for j in range(5)]
  stages.append([[gm(a[i],b[j]) if i>j else gm(c[i],e[j]) if i<j else (d[i][0]*den,d[i][1]*den) for j in range(8)] for i in range(8)])
 middle=mm(stages[1],[stages[0][i] for i in p])
 return mm(stages[2],[middle[i] for i in p])
f0=product(center); denom=den**6
jac=[]
for k in v['selected_columns']:
 z=center.copy();z[k]=(z[k][0]+den,z[k][1]);f=product(z)
 jac.append([(f[i][j][0]-f0[i][j][0],f[i][j][1]-f0[i][j][1]) for i in range(8) for j in range(8)])
J=list(map(list,zip(*jac)));B=[[tuple(y) for y in row] for row in v['approximate_inverse']]
BJ=mm(B,J);eta=max(Q(sum(l1((denom*bden*(i==j)-BJ[i][j][0],-BJ[i][j][1])) for j in range(64)),denom*bden) for i in range(64))
bnorm=Q(max(sum(map(l1,row)) for row in B),bden);r=Q(1,2**30)
q=isqrt(2*2**240);lo,hi=Q(q,2**122),Q(q+1,2**122)
assert q*q<2*2**240<(q+1)*(q+1)
z=Q(0);h=Q(1,4);target=[((lo,hi),(z,z)),((h,h),(h,h)),((z,z),(lo,hi)),((-h,-h),(h,h)),((-hi,-lo),(z,z)),((-h,-h),(-h,-h)),((z,z),(-hi,-lo)),((h,h),(-h,-h))]
res=max(sum(max(abs(Q(f0[i][j][k],denom)-end) for end in target[(i*j)%8][k]) for k in range(2)) for i in range(8) for j in range(8))
assert max(Q(l1(x),den) for x in center)+r<4
H=30*8**2*4**4;L=bnorm*H;beta=bnorm*res;contr=eta+L*r;selfmap=beta+eta*r+L*r*r/2
assert eta<1 and contr<1 and selfmap<r
stored=load('68589*')['bounds'];computed={'residual':res,'B_norm':bnorm,'eta':eta,'beta':beta,'L':L,'radius':r,'contraction':contr,'selfmap':selfmap}
match={k:x==Q(stored[k]['numerator'],stored[k]['denominator']) for k,x in computed.items()}
assert all(match.values())
OUT['M-F8-EXACT']={'full_center_product_and_all_64_unit_derivative_columns_recomputed':True,'approximate_inverse_multiplied_by_fresh_jacobian':True,'stored_exact_rational_bounds_match':match,'bounds':{k:{'numerator':x.numerator,'denominator':x.denominator,'display':float(x)} for k,x in computed.items()},'inert_candidate_sha256':hashlib.sha256(next(I.glob('206a*')).read_bytes()).hexdigest(),'scope':'Particular normalized positive F8, 56 frozen parameters, local exact existence; no coefficient closed form or uniform family.'}
print('F8 full rational certificate passed',flush=True)
# Four quadratic extension generators; d_j are in the earlier tower.
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def neg(a):return tuple(-x for x in a)
def sub(a,b):return add(a,neg(b))
def ds(n):
 if n==1:return (Q(-1),)
 a=[Q(0)]*n;a[0]=1;a[1]={2:-2,4:8,8:-16}[n];return tuple(a)
def mult(a,b):
 if len(a)==1:return (a[0]*b[0],)
 n=len(a)//2;a0,a1=a[:n],a[n:];b0,b1=b[:n],b[n:]
 return add(mult(a0,b0),mult(ds(n),mult(a1,b1)))+add(mult(a0,b1),mult(a1,b0))
def invert(a):
 if len(a)==1:
  assert a[0];return (1/a[0],)
 n=len(a)//2;x,y=a[:n],a[n:];g=invert(sub(mult(x,x),mult(ds(n),mult(y,y))));return mult(x,g)+neg(mult(y,g))
def const(n):return (Q(n),)+(Q(0),)*15
zero=const(0);one=const(1)
def gen(k):return tuple(Q(i==k) for i in range(16))
def parse(s):
 def visit(n):
  if isinstance(n,ast.Constant) and type(n.value)==int:return const(n.value)
  if isinstance(n,ast.Name) and n.id=='I':return gen(1)
  if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return neg(visit(n.operand))
  if isinstance(n,ast.BinOp):
   a,b=visit(n.left),visit(n.right)
   if isinstance(n.op,ast.Add):return add(a,b)
   if isinstance(n.op,ast.Sub):return sub(a,b)
   if isinstance(n.op,ast.Mult):return mult(a,b)
   if isinstance(n.op,ast.Div):return mult(a,invert(b))
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='sqrt' and len(n.args)==1 and not n.keywords:
   a=visit(n.args[0]);roots={add(one,mult(const(-2),gen(1))):gen(2),add(one,mult(const(8),gen(1))):gen(4),add(one,mult(const(-16),gen(1))):gen(8)}
   return roots[a]
  raise ValueError(ast.dump(n))
 return visit(ast.parse(s,mode='eval').body)
def ident(n):return [[one if i==j else zero for j in range(n)] for i in range(n)]
def amul(A,B):return [[sumalg(mult(x,y) for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def sumalg(xs):
 out=zero
 for x in xs:out=add(out,x)
 return out
def ainv(A):
 n=len(A);a=[r.copy()+ident(n)[i] for i,r in enumerate(A)]
 for j in range(n):
  k=next(k for k in range(j,n) if a[k][j]!=zero);a[j],a[k]=a[k],a[j];iv=invert(a[j][j]);a[j]=[mult(x,iv) for x in a[j]]
  for k in range(n):
   if k!=j:
    c=a[k][j];a[k]=[sub(x,mult(c,y)) for x,y in zip(a[k],a[j])]
 return [r[n:] for r in a]
c=load('EXACT_F4*');orders=[[0,1,2,3],[2,3,0,1],[0,1,2,3],[1,0,3,2]];stages=[];nz=0
for key,targetkey in [('first_stage_weight_vectors','first_rook_factor_X'),('second_stage_weight_vectors','second_rook_factor_Y')]:
 branches=[]
 for w,perm in zip(c[key],orders):
  w=list(map(parse,w));nz+=sum(x==zero for x in w);A=ident(4)
  for i in range(4):A[i][perm[i]]=sub(A[i][perm[i]],w[i])
  G=ainv(A);assert amul(A,G)==ident(4) and amul(G,A)==ident(4);branches.append(G)
 stage=[[sumalg(G[i][j] for G in branches) for j in range(4)] for i in range(4)]
 assert stage==[[parse(x) for x in row] for row in c[targetkey]];stages.append(stage)
assert amul(stages[1],stages[0])==[[parse(x) for x in row] for row in c['fourier_unnormalized']]
assert nz==12
assert all(stages[s][r][c]==zero for s in range(2) for r in range(4) for c in range(4) if r//2!=c//2 and r%2!=c%2)
assert parse(c['first_stage_weight_vectors'][2][0])!=parse(c['first_stage_weight_vectors'][2][1])
OUT['M-FOURIER4-GREEN_phase16']={'eight_two_sided_inverse_checks':True,'stage_sums_and_full_negative_F4_identity':True,'zero_edge_occurrences':nz,'identity_branch_nonscalar':True,'all_divisions_checked_units_in_exact_quadratic_tower':True,'no_inherited_eval_or_sympify':True}
print('F4 eight-resolvent exact certificate passed',flush=True)
# Boolean support propagation is a fresh topological verifier, not source graph/BFS code.
def rev(x,k):return int(f'{x:0{k}b}'[::-1],2)
def scan(n,t,inputs,cut):
 x=[i in inputs for i in range(n)];outs=[]
 for s in range(t):
  x=[b and (s,'input',i) not in cut for i,b in enumerate(x)];lo=[False]*n;hi=[False]*n
  for i in range(1,n):lo[i]=(x[i-1] or lo[i-1]) and (s,'lower_state',i) not in cut
  for i in range(n-2,-1,-1):hi[i]=(x[i+1] or hi[i+1]) and (s,'upper_state',i) not in cut
  y=[(x[i] or lo[i] or hi[i]) and (s,'output',i) not in cut for i in range(n)];outs.append([i for i,b in enumerate(y) if b]);x=[y[rev(i,n.bit_length()-1)] for i in range(n)]
 return outs
uniform=[]
for k in range(5,14):
 n=1<<k;m=n//32;cut={(0,'lower_state',13*m),(2,'lower_state',19*m)}
 cut|={(1,'input',32*b+r) for b in range(m) for r in [24,26,28]}
 cut|={(1,'lower_state',32*b+21) for b in range(m)}
 cut|={(1,'upper_state',32*b+31) for b in range(m-1)}
 cut|={(2,'input',b*m+j) for b in [20,22,24,25,26,28,30] for j in range(m)}
 assert len(cut)==12*m+1
 out=scan(n,3,range(13*m),cut)
 assert out==[list(range(13*m)),[32*b+r for b in range(m) for r in range(21)],list(range(19*m))]
 assert scan(n,3,range(13*m),set())[-1]==list(range(n))
 uniform.append({'N':n,'cut':len(cut),'Fourier_rank':13*m,'gap':m-1})
w=load('9b6e*');cut=set(map(tuple,w['removed_nodes']));assert len(cut)==676;out=scan(w['N'],w['stages'],w['J'],cut)
assert not set(out[-1])&set(w['I']);assert scan(2048,4,w['J'],set())[-1]==list(range(2048))
omega=pow(3,32,65537);assert pow(omega,2048,65537)==1 and pow(omega,1024,65537)!=1;nodes=[pow(omega,j,65537) for j in w['J']];det=1
for j in range(683):
 for i in range(j):det=det*(nodes[j]-nodes[i])%65537
assert det==24105
OUT['M-FIXED-BITREV']={'uniform_topological_cut_controls':uniform,'N2048':{'cut':676,'Fourier_rank':683,'fresh_vandermonde_determinant_mod65537':det,'empty_cut_negative_control':True},'scope':'Fixed represented scalar scan graphs only; no all-layout four-stage exclusion.'}
print('Uniform and N2048 cuts passed',flush=True)
(D/'checks/FRESH_FINITE_CERTIFICATES.json').write_text(json.dumps(OUT,indent=2)+'\n')
