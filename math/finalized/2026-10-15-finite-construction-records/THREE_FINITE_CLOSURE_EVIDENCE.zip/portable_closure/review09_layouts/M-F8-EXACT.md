# M-F8-EXACT: Exact eight-point three-stage certificate

Outcome: proved_scoped; complete_scoped.

## Accepted scope

There exists an exact normalized positive F8=S3 P S2 P S1 with P=[0,4,2,6,1,5,3,7], each stage in the stated separated-generator order-one class, 56 Gaussian-rational frozen parameters and 64 complex unknowns within radius 2^-30 of the pinned center. This is existence for the particular Fourier target, not a generic-target dimension assertion.

## Proof revalidation

Reconstructed the actual center product and all 64 unit-increment derivative columns using exact common-denominator Gaussian integer arithmetic. Stage parameter sets are disjoint and every path monomial is square-free in each variable, so these unit differences are exact derivatives. Independently multiplied the supplied dyadic approximate inverse by this fresh Jacobian, enclosed sqrt2 with integer square root, and rebuilt every rational norm bound. The real l1-on-C coordinate norm is submultiplicative. The degree<=6 path-polynomial Hessian bound is 30*8^2*4^4=491520. The contraction/self-map inequalities yield a unique fixed point, eta<1 makes square B invertible, and hence the fixed point satisfies the exact Fourier equations.

## Branch and gauge audit

All 120 center coordinates and 64 selected indices were checked; every coordinate plus the certified radius stays below M=4. No determinant of a principal stage block is assumed. Exact equality to the invertible Fourier matrix implies whole-stage invertibility afterward. The proof describes locally isolated exact coefficients, not a finite rational coefficient list.

## Fresh verification

- Full 120-parameter center/product, all 64 derivative columns, 64x64 B*J, exact residual/sqrt2 enclosure and all eight stored rational bounds freshly recomputed.
- Every stored rational numerator/denominator agrees exactly: contraction 0.027854455457795704..., self-map 1.3033387074529894e-11<2^-30.
- Candidate SHA256 206a8efd5b4a7771f5a0abeeb48031630f46a70479691be8c691e5ec9bec7760 verified against the pinned result.

## Source bound evidence

- The historical search/optimizer, analytic-Jacobian constructor and generation diagnostics were not executed or used as a proof oracle.

## Rejected extensions

- No all-N coefficient family, closed-form parameters, uniform synthesis, growing-size stability or asymptotic evaluator follows.
- This finite N8 result is compatible with N>=64 three-stage repeated-bit-reversal exclusions and with fixed-anchor two-layer exclusions in a different grammar.

## Remaining obligations

- None for local exact N8 existence. Any proposed growing-size use needs its own construction, setup, representation and cost proof.

## Checks

- checks/FRESH_FINITE_CERTIFICATES.json#M-F8-EXACT

