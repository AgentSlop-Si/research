# REVIEW-09: finite kernels, routed cuts and layout obstructions

Review date: 2026-10-10 UTC. Repository source pin: `8604bdf099c01006e3c18030bbf123a59ead893e`.

## Result

All ten assigned rows retain their stated scoped outcomes. M-CHORD retains its explicit conditional reliance on the published odd-polygon extended-line incidence theorem. No new general Fourier algorithm, unrestricted complexity lower bound, fusion, external write, or publication-priority claim is made.

The strongest fresh checks in this packet are the full rational F8 existence certificate, the characteristic-zero eight-resolvent F4 identity, the uniform three-stage cuts through N8192, the N2048 four-stage cut, the exact half-anchor polynomial identities, and the pinned modified N256 routing witness. They all pass. Historical large searches and projective-forest replays are distinguished from fresh checks below.

## Coverage and evidence levels

- Read all 14 distinct assigned full proof/review bodies and all ten current inherited row overlays. Their exact exported hashes pass; six sanitized export hashes differ from original-source identity hashes, which is recorded rather than treated as a byte match to the original.
- Read the relevant complete supplemental F4/F8 source reports and the two short historical cut-verifier implementations as inert text. Read the retained candidate/cut/F4 JSON as data. The F8 candidate was bound by its original SHA256 and the exact Git blob; fresh derivative and matrix arithmetic did not import the source checker.
- `SOURCE_PINS.json` binds all source bodies and 11 supplemental objects to the known repository commit. `PER_ID_OUTCOMES.json` contains the machine-readable current dispositions. Each ID also has a standalone report.
- All executed research-check code was newly written in `checks/`. No supplied program, bytecode, or nested archive executable was run or imported. The two retained inherited Python files have `.inert.txt` suffixes.
- Small modular tests corroborate only the tested field specializations. Characteristic-zero cyclotomic arithmetic, exact rational contraction bounds, written rank proofs and imported published theorems are separately identified. A stored PASS string is not a fresh run.
- Published prime Fourier full spark and prime-power universal sampling remain attributed dependencies. The chord review explicitly preserves the extended-line classification dependency rather than claiming it was independently re-proved or newly bibliographically verified.

## Important scope reconciliations

1. Particular Fourier versus generic targets: M-F8-EXACT proves local exact existence for the specified F8, using its actual residual and Jacobian. Dimension counts and generic exclusion statements do not replace this check. Conversely, passing cuts for a layout does not provide Fourier-compatible coefficients.
2. Fixed layout versus all layouts: repeated-bit-reversal and anchor exclusions fix their routing/support/first-factor grammar. The adjacent-anchor classical cut covers a larger block-diagonal first-factor class, but still fixes the two support cycles. None is a universal F8 or four-stage exclusion.
3. Finite versus uniform: the F4/F8 positive kernels are finite. The N2048 four-stage cut is finite. The N=32m three-stage separator and affine-routing depth/occurrence inequalities have explicit all-size assumptions. No finite example is silently promoted to a growing family.
4. The old adjacent-orbit interface report called the guarded chart open. The later assigned cut proof closes it, including zero-pivot and zero-edge boundaries, for the exact stipulated supports. This is a source-lineage reconciliation, not a newly invented fusion.
5. Guard repairs remain binding: strict integer character witnesses, r-weighted parity capacities, split/distinct quadratic roots, nonzero endpoint numerators and complete denominator guards cannot be dropped. A singular principal block does not invalidate the inverse-cut identity.
6. Nonzero local cyclic masks cannot be turned into a global Hamiltonian batch by simple relabeling. The Phase16 F4 identity has 12 zero edge occurrences and a direct common-gauge escape; it is not an all-edge-nonzero holonomy certificate.

## Fresh verification inventory

- 240 two-stage boundary rank checks, including full transition, zero-transition, singular and order-zero cases; exact N10 Fourier endpoint ranks.
- 5,332 translation-cut identities, 500 strict pigeonhole controls, and 564,480 exhaustive N8 Hamiltonian cycle/step-subset/character bounds.
- 2,584 exact modular parity ranks, weighted capacity correction, bad-prime universal-set control.
- 500 arbitrary-output periodic-column rank checks, 780 permutation edit ranks (including characteristic two), 90 fresh moving-set products; exact reconstruction of the five-Toffoli N256 witness from saved basis columns.
- 15 characteristic-zero cyclotomic FCUT sandwiches, including zero and singular denominator cases; the p11 exact determinant polynomial.
- Symbolic chord determinant identity and full F19,N9 counterexample.
- Full F8 center/product/Jacobian/inverse-norm/residual/contraction reconstruction, with every stored rational bound matching exactly.
- Nine uniform separator sizes N32..8192, plus the 676-vertex N2048 separator and Vandermonde determinant 24105 mod65537.
- 20 split/distinct local F4 positives and 24 missing-split rejections, the F25 repeated-root control, and the full exact Phase16 eight-resolvent identity in the rational quadratic tower.
- Twelve exact half-orbit polynomial identities; adjacent cut determinant/crossings; three guarded rational general-interface positive controls; two endpoint-guard negatives; zero-edge/double-zero-pivot and singular-principal-block controls.

## Reproduction

Run from any working directory with Python 3 and SymPy 1.14 available:

    python -I checks/fresh_finite_certificates.py
    python -I checks/fresh_rank_controls.py
    python -I checks/fresh_orbit_and_routing.py

Use absolute script paths when outside this directory. The first two use only Python's standard library. The third uses SymPy for independently constructed symbolic algebra; it does not parse or execute any supplied source expressions through SymPy. The F4 source expressions use a narrowly whitelisted AST parser implemented in the first script, with every division checked by explicit algebra inversion.

The outputs are `checks/FRESH_FINITE_CERTIFICATES.json`, `checks/FRESH_RANK_CONTROLS.json`, and `checks/FRESH_ORBIT_ROUTING.json`. Fresh isolated-mode replay and source/seal verification are recorded in `VALIDATION.json`.

## Per-row findings

### M-TWO-STAGE — Boundary-window two-stage exclusion

**Disposition:** complete_scoped. For T=S2 P S1, with upper/lower contiguous cut orders at most r2,r1 in the two declared natural layouts, R=r1+r2 and W=floor(N/2), simultaneous full rank W on the two specified boundary blocks forces N<=4R+1. Thus two order-one stages cannot represent Fourier at N>=10 when either Fourier endpoint is affine-coprime; over C at prime N>=11 both endpoint permutations may be arbitrary. Invertible diagonal endpoint gauges are allowed.

**Proof logic:** Split a boundary block into the S1 exterior term (rank <=r1), S2 exterior term (rank <=r2), and interior routed term (rank <= overlap). The two disjoint boundary input windows have routed overlaps with the output prefix summing to <=W. One is <=floor(W/2), giving ceil(W/2)<=R. Consecutive Fourier exponents give the required Vandermonde rank; arbitrary two-sided endpoint permutations at prime complex length instead use classical full spark. The earlier v17 zero-rectangle proof and its fixed-point branch are sound, but the stronger boundary result subsumes its two-stage threshold.

**Branches and gauges:** No inverse of a stage or principal block, no nonzero generator minor, and no genericity are used. Singular stages, zero transitions, order-zero stages and arbitrary internal permutation are retained. Diagonal gauges must be invertible to preserve target rank; an exact dense Fourier representation cannot have a zero external row/column anyway.

**Fresh scope:** 240 exact modular boundary-block rank checks using independently generated transition-generator stages, including zeros/singular/order-zero branches. Both N10 endpoint Fourier blocks have exact rank 5 over F241.

**Source-bound:** The source v17 1,800 rectangles/72 sandwich controls and older generic cross-product enumeration were proof-read, not replayed.

**Not established:** No feasible construction is proved for N<=9. No unrestricted arithmetic lower bound, arbitrary composite two-sided endpoint full spark, or automatically sparse mismatch witness follows.

**Remaining:** None for the stated boundary theorem. An all-layout/composite-endpoint extension would need a target-block rank argument.

### M-AFFINE-STEP — Simultaneous affine-step Green product obstruction

**Disposition:** complete_scoped. For dyadic N>=8, occurrence-counted sums/products of diagonally gauged Hamiltonian Green terms with bounded transformed signed-step magnitudes and exceptional edges, affine interstage routing, and explicitly charged Q occurrences, a common balanced character cut has rank <= min(N/2,T floor((N-1)/r)+sum floor(b_q/2)), r=floor((N-1)^(1/s)). Fixed d,b force Q=Omega(log N/log log N), also for fixed complex operator error epsilon<1/sqrt(2).

**Proof logic:** Integer pigeonhole boxes give 0<h<N and strict r|ha|_centered<N. Dyadicity makes the character semicircle balanced even for nonunit h. A Hamiltonian cycle cannot use both directions of an undirected edge; equal incoming/outgoing counts yield the strengthened sum-of-shifts plus floor(b_q/2) bound. The complementary inverse-block rank identity, rank subadditivity for products, and affine conjugation establish the common cut. The final normalized Fourier block has squared Frobenius norm N/4 and operator norm <=1, giving the exact and approximate rank requirements. The finite-length conclusion retains the exceptional-edge disjunction before taking fixed-parameter asymptotics.

**Branches and gauges:** Zero cycle weights are allowed if each full Green denominator is invertible. Stage sums and the final candidate need not be invertible. The empty step set s=0 and d=0 are separate, with all edges exceptional; Q=0 gives a monomial obstruction. Nonunit h and antipodal shifts are retained. All strides must be transformed before choosing the cut. Arbitrary final diagonal scalings can lower rank, but approximation is always measured against the fixed normalized Fourier matrix, not a freely rescaled target.

**Fresh scope:** 5,332 exact translation-crossing identities and 500 strict integer pigeonhole controls at N4..64. All 5,040 Hamiltonian N8 cycles, seven characters and 16 step subsets: 564,480 crossing-budget checks, including empty step sets. Reconfirmed N16 strides [1,2,8], h=1 fails the strict r|t|<N predicate; N6,h2 produces an unbalanced 4:2 split.

**Source-bound:** The source N256 weighted rank 38, very-large symbolic budget thresholds, detailed affine conjugation examples and historical numerical SVD controls were read, not freshly replayed.

**Not established:** Not a scalar-work bound or a DAG/shared-state reuse theorem. Non-affine interstage routing, non-Hamiltonian permutations with two-cycles, growing d/b, and epsilon tending to 1/sqrt(2) are outside the stated uniform conclusion.

**Remaining:** None for the qualified theorem. The historical floating-tolerance witness and large-bridge finite-length wording repairs must remain in any implementation reuse.

### M-PARITY-DEPTH — Parity Fourier ranks and affine scan depth

**Disposition:** complete_scoped. For complex dyadic Fourier and nonzero parity masks with highest bits u,v, the half-block rank is N/4 when u+v<=k-2 and N/2 otherwise. GF(2)-affine interstage routing between quasiseparable stages of orders r_j obeys the quota obstruction: q_j>=1 and sum r_j 2^(-q_j)<=1/4 require sum q_j>=k. Uniform r>=1 gives k<=t ceil(log2(4rt)). Arbitrary invertible external monomials are permitted for the coarse depth bound.

**Proof logic:** A parity halfset is periodic modulo h=2^(u+1), with representatives forming a complete residue system modulo h/2. The imported prime-power universal-sampling criterion makes that representative set universal over C. Fourier transforms along period repetitions split the matrix by row residues and give the exact ranks. Pullback by affine binary maps makes the low-bit conditions homogeneous linear constraints. Fewer than k constraints leave a nonzero mask whose weighted moving-boundary capacity is strictly below N/4. A flat-unitary Frobenius/operator-norm inequality gives this lower rank for any balanced endpoint subsets, independently of the exact parity formula.

**Branches and gauges:** Affine translations can flip parity signs without changing boundaries. The stages may be singular and transition generators may vanish. All-zero orders are handled directly as a monomial/diagonal-only obstruction, rather than relying on a strict inequality from sum r_j>0. Only internal binary-affine transport supports the nullspace construction. External nonzero diagonal gauges preserve block rank.

**Fresh scope:** 2,584 exact modular parity-block ranks over F12289 and F65537: all mask pairs and all four signs through N16, sampled pairs at N32,N64. Exact deficient-pair counts at k2..6. Reconfirmed the r=2 reporting correction: boundaries [31,31] mean capacity 124, not 62. Reproduced the universal-set specialization ranks 7 mod12289 and 8 mod65537.

**Source-bound:** The 250 historical mixer trials, all large saved nullspace witnesses and full N512/N1024 eliminations were not rerun. The Osgood-Siripuram-Wu universal-sampling theorem remains an attributed imported characteristic-zero dependency, not freshly re-proved by modular tests.

**Not established:** No finite-field universal-sampling theorem is inferred. No arbitrary nonlinear routing exclusion or NlogN arithmetic lower bound follows; finite test survival is not a Fourier coefficient construction.

**Remaining:** None for the qualified rank/depth result. Preserve the r-weight correction in any uniform witness ledger.

### M-CHORD — Chord-rigidity sparse-sandwich bound

**Disposition:** complete_with_explicit_dependency. Conditional on the stated published extended-line incidence theorem for odd regular complex polygons, primitive-affine three-frequency profiles with Hamiltonian right routing have adjacent-row support union >=n-2, locally sharp for odd n>=5. The global all-strong-profile density is ceil(n(n-2)/2), with the source prime hybrid refinement. The stipulated scalar-polynomial bridge requires 4^(L+1)>=1+(n-2)/6.

**Proof logic:** The determinant of h(t)=(1-at,t(1-bt)) is (u-t)[1-b(t+u)+abtu]. Two dependent root pairs force a=conjugate(1/b) and hence chord-line concurrence. Rank two on every three distinct parameter columns prevents three nonzero columns in one proportionality class. The imported odd-polygon extended-line theorem therefore limits cancellation pairs to two. A Hamiltonian cycle uses each unordered pair at most once. The zero-column exception permits at most one cancellation. Summing local union bounds gives density; row-degree 3 outer sums and degree-4 bridge powers give 9 sum_{r=0}^L 4^r per row and the stated degree inequality.

**Branches and gauges:** b=0 gives pairwise independence. A zero h(t0) forces a=b=t0^-1 and leaves all other columns pairwise independent. Zero edge weights are allowed. Primitive-affine step must be coprime; endpoint gauges are nonsingular. The geometric step is complex and uses the complete extended-line result, not merely interior diagonal intersections.

**Fresh scope:** Symbolically re-expanded the two-column determinant identity. Reconstructed the full F19,N9 counterexample with root 4, weights and Hamiltonian right cycle from the report: jointly zero columns [5,7,8], union support 6<7, and both inverse guards 1.

**Source-bound:** The published Rigby/Sidorenko extended-line incidence dependency is retained explicitly as in the assigned review; this run does not claim a new proof or a primary-source re-verification of that classification. Historical all-odd local sharpness controls and prime hybrid examples were proof-read, not replayed.

**Not established:** The near-full bound is false over arbitrary finite fields, even with valid Fourier roots and nonsingular Green denominators. No arbitrary non-affine composite-profile extension, general fast-solve obstruction or two-layer impossibility follows.

**Remaining:** The external incidence theorem remains a named dependency. A self-contained publication treatment would need an adequate primary statement/proof and precise attribution.

### M-FCUT — Fourier-cycle sparse-sandwich density

**Disposition:** complete_scoped. At complex prime p>=3, for arbitrary Hamiltonian alpha,beta and complex weights, the specified Fourier sparse sandwich with nonsingular monomial endpoints has every adjacent-alpha row-pair union >=ceil(p/2), so nnz>=ceil(p ceil(p/2)/2). Denominator invertibility is unnecessary. Composite lengths are covered when the moved three-frequency profiles are primitive-affine.

**Proof logic:** The adjacent-row coefficient matrix on three distinct frequencies has rank two, including zero weights. Prime Fourier full spark makes every three-column restriction rank two. Mark the output columns where the row pair has nonzero support and cut the incoming cycle edges there. If there are m>0 marks, the Hamiltonian cycle splits into m directed paths; cancellation propagation, using multiplication only, bounds each path length by two. If m=0, propagation around the full cycle gives rank at most one and contradicts the same premise. Thus m>=ceil(p/2), and summing adjacent pairs counts each row twice. The q-column generalization has path length <=q-1.

**Branches and gauges:** No division by a cycle weight or inversion of either sandwich denominator occurs. Singular all-one denominators, zero edge weights and all-zero edge vectors are permitted. Invertible monomial endpoint factors preserve the local three-column premise. General composite non-affine triples require a separate target-minor check.

**Fresh scope:** 15 exact characteristic-zero cyclotomic sandwich controls at p3,5,7,11,13, with independent endpoint permutations/scales and random/zero/singular-all-one denominator branches. Recomputed the p11 witness polynomial -2z^2+z^4-z^7+2z^9; its degree is 9, preserving the known wording correction.

**Source-bound:** The classical prime Fourier full-minor theorem is an imported accepted dependency. Historical larger exact sandwich enumerations are not claimed as new executions.

**Not established:** Density is not a quadratic-work lower bound: a dense center may have a compact fast evaluator. The prime >=11 two-resolvent consequence is already subsumed by earlier additive/separator obstructions; no new unrestricted Fourier conclusion is licensed.

**Remaining:** None for the stated density theorem.

### M-NONLINEAR-ROUTING — Moving-set and nonlinear-routing gates

**Disposition:** complete_scoped. Periodic columns C={e+hj} with an explicitly full-spark h-point representative set E have arbitrary-output Fourier rank sum_rho min(n_rho,|E|). Arbitrarily transported sets through quasiseparable stages obey rank M[A_t^c,A_1]<=sum r_j d(A_j). Shuffle replacement adds at most sum rank(P_j-A_j), with permutation edit rank N minus the number of relative cycles. The pinned five-Toffoli N256 layout is excluded at rank 128 versus capacity 124; the stated N2048/N4096 two-edit bounds remain scoped to their pinned baselines.

**Proof logic:** Fourier change along period repetitions block-diagonalizes by output residue class, giving the oracle under its full-spark premise. Each membership boundary contributes one quasiseparable rectangle. Exact transport through shuffles and product telescoping sum those crossing capacities without assuming affinity. A second telescoping argument handles permutation edits. For I-Q, the kernel is one constant vector per cycle over every field, including characteristic two, proving N-c(Q). The coarse robust all-size bound uses balanced target blocks and remains a restricted low-edit theorem.

**Branches and gauges:** No stage invertibility, nonzero transition or generic coefficient chart is required. Controlled-NOT gates have edit rank N/2^(m+1); rank is not a routing-work measure. The perturbation result compares the same endpoint sets to the unedited pinned baseline. The exact complex oracle is not an arbitrary finite-field full-spark claim.

**Fresh scope:** 500 modular periodic-parity-input/arbitrary-output rank controls; 780 direct permutation-edit rank checks across F2,F17,F65537; 90 fresh four-stage arbitrary-shuffle moving-boundary controls. Regenerated the saved N256 basis-column maps as data. For input mask112, baseline [11,53,43,60] becomes [11,53,43,17]; successive last-stage boundary sequence [31,25,23,21,17], Fourier residue counts [64,64], rank 128>capacity 124. The final shuffle differs from its inferred affine map at 160 inputs.

**Source-bound:** No fresh maxflow, complete 504-single-edit enumeration or all historical mixer trials. N2048: 1024>390+512=902. N4096: 2048>887+1024=1911. Their source proof and recorded basis-witness scope are retained, without claiming fresh regeneration here.

**Not established:** The unmodified N256 layout remains unexcluded by these tests, without any coefficient solution. No universal nonlinear routing obstruction, uniform two-Toffoli corollary, or theorem for sums of differently ordered Green banks follows.

**Remaining:** None for these necessary gates. Coefficient feasibility of layouts surviving them remains open and is not a task in this review.

### M-F8-EXACT — Exact eight-point three-stage certificate

**Disposition:** complete_scoped. There exists an exact normalized positive F8=S3 P S2 P S1 with P=[0,4,2,6,1,5,3,7], each stage in the stated separated-generator order-one class, 56 Gaussian-rational frozen parameters and 64 complex unknowns within radius 2^-30 of the pinned center. This is existence for the particular Fourier target, not a generic-target dimension assertion.

**Proof logic:** Reconstructed the actual center product and all 64 unit-increment derivative columns using exact common-denominator Gaussian integer arithmetic. Stage parameter sets are disjoint and every path monomial is square-free in each variable, so these unit differences are exact derivatives. Independently multiplied the supplied dyadic approximate inverse by this fresh Jacobian, enclosed sqrt2 with integer square root, and rebuilt every rational norm bound. The real l1-on-C coordinate norm is submultiplicative. The degree<=6 path-polynomial Hessian bound is 30*8^2*4^4=491520. The contraction/self-map inequalities yield a unique fixed point, eta<1 makes square B invertible, and hence the fixed point satisfies the exact Fourier equations.

**Branches and gauges:** All 120 center coordinates and 64 selected indices were checked; every coordinate plus the certified radius stays below M=4. No determinant of a principal stage block is assumed. Exact equality to the invertible Fourier matrix implies whole-stage invertibility afterward. The proof describes locally isolated exact coefficients, not a finite rational coefficient list.

**Fresh scope:** Full 120-parameter center/product, all 64 derivative columns, 64x64 B*J, exact residual/sqrt2 enclosure and all eight stored rational bounds freshly recomputed. Every stored rational numerator/denominator agrees exactly: contraction 0.027854455457795704..., self-map 1.3033387074529894e-11<2^-30. Candidate SHA256 206a8efd5b4a7771f5a0abeeb48031630f46a70479691be8c691e5ec9bec7760 verified against the pinned result.

**Source-bound:** The historical search/optimizer, analytic-Jacobian constructor and generation diagnostics were not executed or used as a proof oracle.

**Not established:** No all-N coefficient family, closed-form parameters, uniform synthesis, growing-size stability or asymptotic evaluator follows. This finite N8 result is compatible with N>=64 three-stage repeated-bit-reversal exclusions and with fixed-anchor two-layer exclusions in a different grammar.

**Remaining:** None for local exact N8 existence. Any proposed growing-size use needs its own construction, setup, representation and cost proof.

### M-FIXED-BITREV — Repeated-bit-reversal finite and uniform cut obstructions

**Disposition:** complete_scoped. For the represented three-stage order-one scalar scan graph with repeated bit reversal, every dyadic N=32m>=64 has a selected full-rank 13m Fourier block separated by 12m+1 scalar vertices. At N2048, the supplied four-stage repeated-bit-reversal graph has Fourier rank 683 versus an explicit cut 676. These are fixed-layout, declared-state-dimension obstructions.

**Proof logic:** The uniform cut confines stage1 support to the first 13m inputs, stage2 support to residues0..20 in every 32-block, and stage3 support below 19m. Its count is 1+3m+m+(m-1)+7m+1=12m+1. Bit reversal reverses the high-five-bit/block decomposition exactly. At m=1 the ranks tie; at m>=2 the cut is deficient. Prefix Fourier exponents and distinct root nodes give Vandermonde full rank. For the four-stage N2048 certificate, scalar-state reachability gives a rank upper bound676, while the stored endpoint sets define a 683-square Vandermonde matrix.

**Branches and gauges:** Boolean dependency propagation permits every coefficient assignment within the represented graph, including zero transitions and singular stages. It does not assume generic nonzero edges. The rank bound uses actual scalar states and no additional unrepresented communication. Arbitrary non-affine outer endpoint permutations at composite N are not presumed to preserve Vandermonde full rank; appropriate affine-coprime endpoints are valid.

**Fresh scope:** A new topological forward/backward scan-state propagation verifier, distinct from the inherited BFS code, checks exact reachable supports and the empty-cut control at N32,64,128,256,512,1024,2048,4096,8192. Rechecks all 676 supplied N2048 cut vertices and both endpoint sets; recomputes determinant 24105 mod65537 with omega=3^32 of exact order2048.

**Source-bound:** Older saved N64/N128 determinant values and maxflow optimality claims were not rerun. Optimality is unnecessary for the upper-bound separator. General later repeated-layout growth statements belong to separate source lineage/rows and are not additionally certified by this packet.

**Not established:** No arbitrary-layout four-stage exclusion or general FFT arithmetic lower bound. N32 equality in this cut does not establish feasibility; the explicit N2048 witness is finite, while only the stated N=32m three-stage family is uniform here.

**Remaining:** None for these represented-graph obstructions.

### M-FOURIER4-GREEN — Small exact Fourier Green kernels

**Disposition:** complete_scoped. The positive-exponent F4 is one paired cyclic-Green layer over a field with primitive eighth root chi and both distinct roots r,s of z^2+(chi+chi^-1)z+chi^2. Separately, the Phase16 exact F4 certificate is a product of two four-Green sums on the stated s=2 rook topologies. Its supplied matrix convention is the negative-exponent root -i. These are two distinct fixed-N4 constructions.

**Proof logic:** For the paired kernel, [1,chi^-1,-1,chi^-1] is a two-exponential recurrence sequence; finite geometric inversion plus chirp multiplication produces i^(uv). The product of Green guards is8i; rs=i and a is not a quadratic root imply nonzero masks and endpoints. Distinct-root interpolation is essential. For Phase16, safely parsed only the allowed expression AST and verified all arithmetic in the 16-dimensional rational quadratic tower i^2=-1, a^2=1-2i, b^2=1+8i, c^2=1-16i. Every divided element was explicitly inverted and all eight inverse products, two stage sums and the full supplied Fourier product were checked exactly.

**Branches and gauges:** The all-nonzero paired local cyclic kernel and sparse-mask Phase16 construction must not be conflated. The latter has exactly 12 zero edge occurrences and cannot be fed into a nonzero-edge holonomy recognizer. Its identity-topology branch has unequal weights, an exact obstruction to any common scalar-reference diagonal gauge. The stated rook-to-four-resolvent construction allows zero weights. A direct sum of local cycles is not one global Hamiltonian cycle.

**Fresh scope:** 20 split/distinct paired-kernel positives across 11 prime fields and all primitive eighth roots, with every mask/endpoint/guard and full F4 identity checked;24 missing-split cases rejected. Rebuilt the F25 repeated-root control: chi=2t, t^2=2, the quadratic has one repeated root although the Green guard is2. Fresh characteristic-zero verification of all eight Phase16 inverses, exact X/Y stage sums, rook support, Fourier product,12 zero weights and unequal identity-branch weights.

**Source-bound:** The unrelated all-even-square Phase15 spectrum, all Phase16 common-gauge/spectral and generic-defect experiments, and historical larger bank controls are read as context but not newly replayed or merged into this row.

**Not established:** Primitive eighth root alone does not ensure the required split/distinct quadratic. No optimal Green length, all-edge-nonzero Phase16 holonomy certificate, free global Hamiltonian lift or growing-size speedup follows.

**Remaining:** None for the local kernels. A global batch lift of the all-nonzero cyclic kernel remains separate and unprovided.

### M-F8-ORBIT — Eight-point anchor and orbit exclusions

**Disposition:** complete_scoped. Retain the eight stipulated fixed-anchor/order-pair rejections over Q(zeta8) and extensions with their recorded endpoint guards. For the later support maps pi=(1,2,3,4,5,6,7,0), sigma=(2,7,5,0,6,1,3,4), the entire half-anchor nonsingular diagonal orbit is excluded in every primitive-eighth-root field. The adjacent anchor, including all zero-pivot/edge boundaries, is also excluded by the later classical cut proof, even for any invertible first factor block diagonal across {0,1,2,3}|{4,5,6,7}.

**Proof logic:** The diagonal-orbit reduction retains the essential factor1/2 and uses only pair-constant diagonal commutation. Necessary off-support minors are derived by subtraction without division, including when both pivot entries vanish. Eight selected half-anchor minors force w!=0, t2=-t0, E=0, RS=0, q=0, w^2=i and finally 0=8it1, impossible under the stated guards. For the adjacent anchor, inverse off-diagonal rank equals original off-diagonal rank by a kernel bijection; one pi and two sigma crossings give rank<=3, while the Fourier block is rank4 Vandermonde. This closes the older report's open adjacent chart without solving it numerically or relying on a huge unit-ideal certificate.

**Branches and gauges:** Half-orbit rejection does not impose nonzero cycle edges or pivot guards. Nonsingular diagonal endpoints and nonzero anchor ratios remain essential to that normalization. The adjacent cut needs only invertibility of full Q branches, permitting zero diagonals and singular principal blocks as well. The separate40-equation constructive iff chart still requires every listed t,u,a,c, endpoint numerator and determinant guard; it is not a sufficiency statement on zero-pivot branches. Of the older eight charts, the half-anchor/natural-bit-reverse rejection specifically uses nonzero diagonal endpoints.

**Fresh scope:** Fresh symbolic reconstruction of F T K and all 12 principal certificate identities modulo z^4+1, with all eight chosen minor positions verified off support. Recomputed adjacent Fourier determinant -4+4z-4z^2 and crossing counts [1,2]. Invertible zero-diagonal cycle controls have singular principal blocks and inverse-cut ranks [1,2]. Three fresh rational full-edge inverse-sum controls satisfy the general-interface forms of all 40 equations and recover all 24 directions/scales with complete direction, endpoint and determinant guards. These manufactured targets are not F T K and are not Fourier8 solutions. All-zero-edge legal control has 8 double-zero pivot pairs; the necessary minors still vanish. Two zero-endpoint-scale controls satisfy all 40 equations but fail the requisite endpoint numerator guard.

**Source-bound:** The earlier 690 transition/395 internal-quadratic replay for eight fixed charts is explicitly source-bound to its full accepted proof report and exact pinned source documents; not rerun. No claim of checking all 176 stored expanded coefficient arrays or the later full unit-ideal packet in this fresh run. The short symbolic identities and classical cut independently validate the current claimed scopes.

**Not established:** Not a universal Fourier8 obstruction, all-first-factor theorem, arbitrary support/order-pair theorem, or unrestricted two-layer impossibility. An old text saying the adjacent chart is open is superseded only for these precise supports. The older eight charts remain characteristic-zero statements unless separately proved in other characteristics.

**Remaining:** None for the stated anchor scopes. The unrestricted free-first-layer or different-support problem is not closed.

