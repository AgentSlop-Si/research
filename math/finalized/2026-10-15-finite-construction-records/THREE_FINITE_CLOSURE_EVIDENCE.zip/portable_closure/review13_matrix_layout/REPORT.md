# REVIEW-13: existing matrix-layout rows

**Disposition:** all ten assigned rows retain `proved_scoped`, with the exact qualifications below. The historical even-size permutation proof repair is preserved. The finite N4 fixed-pole exclusion and the distinct variable-pole positive point both survive fresh exact reconstruction. Full complex F8 feasibility and a uniform Fourier constructor from cheap global stages remain open.

This review is confined to the ten existing rows in REVIEW-13. It starts no new fusion and makes no external write. No inherited research program was imported or executed. All six executable checkers in `checks/` were authored for this review. One archived checker was inspected as inert text only to resolve a polynomial normalization convention.

## Evidence and identity boundary

- All 25 assigned source/review bodies were read, together with their exact catalogue statement, model, limitations and current overlay. All 25 freshly computed hashes match the recorded **export** hashes.
- Only 21 exports also match their recorded **original source** hashes. The CRT audit, interval-window audit, local-annihilator audit and spectral-determinant audit are transformed exports. Their old source identities have not been replaced by export hashes. `SOURCE_PINS.json` records both identities separately.
- The accepted Q21 repair and ten additional certificate/convention inputs were retrieved read-only at commit `8604bdf099c01006e3c18030bbf123a59ead893e`. `SUPPLEMENT_PINS.json` records exact local hashes and Git blob identities. Only section A of the supplementary omitted-theorems audit is an input to this packet; its unrelated sections are not adopted as REVIEW-13 results.
- An accepted historical review, a freshly checked proof, a freshly executed finite control, and an unreplayed historical enumeration are separately identified. No assertion that every historical suite was rerun is made.

## 1. M-PERMUTATION-DISPLACEMENT

**Accept:** for primitive-root Fourier over a field admitting N distinct roots, the one-permutation displacement rank is `N-z(P)`, where z counts permutation cycles whose index sum is zero modulo N. Its minimum is `floor(N/2)`, attained uniquely by negation.

The cycle block has one-dimensional kernel precisely when its diagonal monodromy is one. Only {0} can be a zero-sum singleton; the counting bound gives z≤ceil(N/2). For odd N, equality consumes {0} and every negative pair. At even N=2k, counting alone leaves an apparent extra possibility. The total index sum is k modulo 2k, so not all cycles can be zero-sum. If {0} were absent, k zero-sum cycles would exhaust all vertices as pairs, a contradiction. With {0} present, the other k−1 zero-sum cycles cannot exhaust all remaining vertices, since that would again make the total sum zero. They therefore all have size two, leaving the unique self-negative nonzero vertex k fixed. This is the previously accepted repair, not a new extremizer claim.

**Fresh controls:** all 409,113 permutations for N=1,…,9 and 270 actual modular matrix ranks. The unique extremizer is negation at every tested size.

**Boundary:** arbitrary weighted monomial permutations are a different class. Rank of a correction space is not runtime. The source's fixed scalar recurrence, adaptive zero-transcript and separately charged row-scan arguments are confined to their specified models. Q21's proof closure is retained; its prior-art comparison is historical evidence, with worldwide priority unresolved.

## 2. M-SORTING-RANK

**Accept:** `rank(W-Z^a)=N-cycles(Z^(-a)W)` over every field. For an iid fair binary word, stable sorting gives `r=2 floor(T/2)`, `Pr(r=2k)=2^(1-N) binom(N,2k+1)`, and for N≥3 mean N/2−1 and variance N/4. The source's explicitly clipped all-stride union bound tends to one.

The permutation cycle identity is field-independent. The distribution follows from the bijection between a word and its first bit plus successive XOR differences. The all-stride bound separately handles a=1; short-stride windows are partitioned into independent residue classes and long strides use a first-moment union bound. No positive guarantee is inferred when the displayed lower bound clips to zero.

**Preserve correction:** T≤1 gives W=Z and no changed edges, including mixed two-run words. For T≥2, changed edges number r+1. One stride costs O(N) to screen; independently screening all strides costs O(N²).

**Fresh controls:** all 8,188 binary words at N=2,…,12, 3,076 word/stride cases through N=8, and 288 actual matrix ranks over characteristics 2, 3 and 5. High rank can still be cheap to apply.

## 3. M-CRT-TRANSFER

**Accept:** for N=2m distinct nonzero Fourier roots partitioned into balanced A,B, the monomial-basis remainder transfers R_A,R_B and their difference are invertible. Their combined literal support is at least 2m, with equality exactly at the parity split, up to exchanging children.

The full Vandermonde matrix factors into invertible child Vandermondes and `[[I,R_A],[I,R_B]]`; block-row subtraction proves invertibility of the difference. Each transfer is invertible, hence has at least m entries. Equality makes it monomial. Its first column forces the root polynomial to be z^m−c; Fourier roots then force c=±1, giving the ordinary even/odd split.

**Fresh controls:** all 350 balanced subsets at N=2,4,6,8,10, exact ranks and unique minimal supports. All four invertible diagonal baselines at N=2 over GF(3) leave residual rank two, preserving the known exception to the optional stronger baseline claim.

**Boundary:** the historical N16 polynomial/transfer histograms remain accepted recorded audits and were not rerun here. Modular nonperiodic support 94 gives a characteristic-zero lower bound, not equality. Literal monomial support, fixed-cut transport, arithmetic cost and freely changing bases are different measures. The fixed cut and entire correction rank must be retained in telescoping arguments.

## 4. M-GLOBAL-STAGES

**Accept as separate stage constructions:**

1. The parity-reordered two-path Green sum, its rank-one Householder modification, and the exact linear-work inverse through a band-two system plus rank-two correction. Algebraically `M^-1=B(B+epsilon A)^-1 A`; the real SPD hypotheses ensure legal pivots. Modular pivots require their own nonzero checks.
2. The random two-path SPD sum, epsilon=1/100, with spectral condition ≤5. For N divisible by 16 and N≥32, the specified probability bound gives every balanced cut at least floor(N/240) singular values ≥1/2500. The two-independent-path proof may fix the first path by simultaneous relabeling. Certifying a sampled graph by dense elimination is separate audit work, not free O(N) setup.
3. The square-grid path sum for even L≥4, N=L², with at least floor(L/15) singular values ≥1/2500 in every balanced cut and condition ≤5. This is order-robust growing rank of order sqrt(N), not linear rank.
4. The Cayley-path/tree-involution construction: exact complex unitarity, linear application and inverse, probabilistic all-order robust cuts under the stated length restriction, and polynomial induced-1-norm growth. Modular unnormalized inverse tests are not unitarity tests.

The edge-matching and singular-value perturbation proofs, grid boundary counting, random-path union bound, Cayley expansion and binary-tree recurrence were checked separately. The parity stage's all-N density statement applies to its positive M; complete density of the Householder-modified S and its inverse was only finite evidence. No stronger all-N density claim is imported.

**Fresh controls:** exact parity inverse identities at N4,8,16; all 12,870 balanced cuts of the 4×4 grid have boundary at least four; separate floating N32 SPD/unitary/involution controls, expressly labelled numerical.

**Current-overlay reconciliation:** Q06's accepted conditional macro compiler is not a proof that any of these stages factors Fourier. It remains necessary to supply the actual target identity, compatible coefficients/masks/routes, paid preparation, and enough stage-count savings. A cheap dense/high-rank operator, even with a cheap inverse and good conditioning, is not a Fourier constructor.

## 5. M-WINDOW-GRAM

**Accept:** the three-sided interval-window lemma and the strengthened necessary `N≤9r²+7r` for r≥1, natural or affine coprime-stride Fourier input order, arbitrary output order, and four oriented budgets ≤r. Inverse-stage use requires invertibility. Arbitrary input orders require actual block ranks rather than a Vandermonde substitution.

The kernel/image argument establishes all three window inequalities. Prefix/suffix windows force first/last marked positions, bounded gaps force `N≤9r²+7r+1`, and equality would put disjoint first/last label sets in the same positions, giving the strict one-unit improvement. The N16 rank-one survivor establishes only necessary-filter sharpness.

**Accept separately:** the bilateral tail inequalities need selected-column full rank (in particular invertible C), consecutive Fourier restrictions and the stated orientations. For even N≥4 and fixed real invertible A, the one-complex-mask architecture exists with real invertible B iff each A column is a reflection eigenvector. Disconnected Gram support is only necessary. Bilinear Gram gates use transpose, not conjugate transpose; nonzero diagonal/entry and square-root guards are essential for the stated recovery routine.

**Fresh controls:** all N8 permutations give 15,728 complete-window survivors; the displayed N16 filter witness passes; 320 tail inequalities pass; the N8 boundary-lock counterexample has rank five with nonzero boundary determinant. The boundary-lock equivalence begins at N≥9.

**Boundary:** filter success, Gram congruence and selected calibration do not prove Fourier equality. Fresh-random oracle soundness requires a fixed linear candidate. The historical `apply_R` per-entry power setup is not uniformly linear without the advancing-power repair. Stronger accepted cutoffs in narrower families are not displaced by this window result.

## 6. M-FIXED-POLE-N4

**Accept complete projective exclusion:** with poles 1/4 and 1/5, cycles Z and (0,2,1,3), identity internal permutations, three nonzero projective two-Green couplings and invertible complex diagonal masks, there is no F4 product in the stated family. Singular square factors are automatically impossible. Both Fourier signs and harmless global normalizations are covered as stated.

**Fresh complete verification:**

- Rebuilt the rational Green matrices, adjugates, exact quartic determinant, all nine zero-middle couplings, and all six monic bivariate minor arrays (every coefficient matches the pinned inert input).
- Verified exact guard division. At a=−16/15 the degrees 7 and 10 have gcd degree three; four independent Sylvester kernel vectors and the annihilating first-derivative functional force order at least five. The irreducible/separable cubic singular factor has the independently checked common monic divisor of degree three, forcing its third power.
- Reconstructed each modular degree-192 resultant by direct 20×20 Sylvester determinant evaluation at 193 distinct points of GF(29²)=GF(29)[u]/(u²−2). The degree bound makes this an exact coefficient identification, not sampling evidence. The saved coefficients match. Both degree-178 quotient identities and their full Bézout identity equal one.
- Recomputed the exact unsaturated Q(i) unit ideal on all nine finite zero-middle support branches.
- Recomputed both one-infinite-outer regular gcd/guard exclusions and all eighteen zero-middle cases. Recomputed the common-infinity K00 and nonzero homogeneous coefficient minor.

The characteristic-zero conclusion uses exact divisibility and degree-preserving good reduction, not absence of GF(29) rational points. An initial checker discrepancy was due to newly imposed monic renormalization after an additional guard division. The archived checker was inspected only as inert text to identify the convention; removing that unrequested renormalization reproduces both exact resultants. This was a control implementation correction, not a theorem defect.

**Boundary:** fixed poles/cycles/orders only; this does not exclude the distinct variable-pole N4 point or all Green products.

## 7. M-PARTIAL-COLUMNS

**Accept:** for q≤N fixed Hamiltonian Green responses with independently variable legal couplings and q selected target columns whose entries are nonzero, generic couplings make every row response matrix invertible and all Cramer gauges nonzero. The distinct distance/exponent tuples prevent determinant monomial cancellation. For q<N, fitting an additional column is generically impossible; exceptional couplings are not excluded by that generic statement.

The dominating-power Fourier specialization is an existence argument with huge exponents. The positive-integer sampling-law bound needs N≥2, or a separate N=q=1 pole exclusion. The result supplies one-sided row gauges; it is not an arbitrary input-gauge or product-stage theorem.

**Fresh controls:** exact N8 q3/q5 and N16 q3 fits match every selected entry but fail every entry of the next column; q=N=8 matches the whole matrix and retains quadratic online work. All row gauges in these controls are nonzero.

**Separate projective-window certificate:** seven quadrics times five variables supply the 35-dimensional cubic space in a 3×4 window. Full 35×35 rank excludes projective common zeros. The recorded exhaustive N4 (576) and N8 (564,480) mapping certificates retain their precisely fixed outer mixers/generators; their rank streams were not rerun in this review. N16's 100,000 mappings are sampled from 146,764,800, not exhaustive. Modular nonzero minors lift through verified good reduction, a different inference from field-point emptiness.

**Boundary:** fitted columns and selected-basis Weyl tests do not determine the full transform. Historical overwritten out-of-sample labels remain corrected: the actual probes are columns 5, 4 and 7 for the respective fits.

## 8. M-LOCAL-ANNIHILATOR

**Accept:** an interior W-window of an order-r quasiseparable matrix has annihilator dimension at least W−2r, without invertibility or nonzero-generator assumptions. A full-row-rank s×w coefficient space, w≤N and primitive root, has nonzero Casoratian `z^(s(s-1)/2) Q(z)` with `degree Q≤s(w-s)`. Cauchy–Binet gives the degree bounds; choosing distinct leading degrees gives a nonzero Vandermonde top coefficient.

The boundary witness uses a prefix output window: at rank one, four output positions leave at most twelve footprint hits and three polynomial exceptions among N−2 input windows, leaving at least N−17 witnesses. Hence N≥18 is accepted. This improves an explicit witness threshold, not the stronger historical N≥17 existential cutoff.

The three-stage necessary bound is `rank T[I,J]≤2r1+2r3+r2+k(layout)`, refined to `b(J)r1+b(I)r3+r2+k` at boundaries. Strict-separation deletion and compression prove it. Natural/affine endpoints permit the Fourier Vandermonde rank replacement; arbitrary endpoints require the actual rank. Random-layout expectation is not a high-probability theorem.

**Fresh controls:** 90 local kernel cases, 60 exact nonzero monomial Casoratians, and 106 actual three-stage boundary-aware window inequalities. The historical explicit witness program and fixed-family Phase28 all-coupling certificate suite were not replayed here.

**Boundary:** Phase28 moment/monomial-equivalence and all-coupling exclusions concern fixed generator families. Freely changing outer mixers or non-affine Green sums need not obey this common-coordinate quasiseparable grammar. Forward linear-work application does not imply a cheap inverse or paid parameter synthesis.

## 9. M-N4-GAUGE-RECURSION

**Accept finite positive point:** the pinned 16-complex-variable dyadic isolator gives an exact algebraic N4 Fourier factorization with variable poles, all six denominator guards, all pole/weight/mask/mixer entries nonzero, and pairwise noncommuting stages.

**Fresh exact replay:** independently implemented integer-directed rectangular intervals at 192 bits, quotient-rule Jacobian and matrix product prove the half-radius box is mapped into itself and is contractive. `eta=9145033794486455575` and `q=212385463402525808956105666627180247578937347` in scale `2^192`; the exact integer self-map inequality holds. Every nonzero guard and commutator witness is checked. This independently certifies the root, rather than numerically fitting one.

**Accept all-size stage identity:** for the specified dyadic cycles and `d≠0`, `p^N≠1`, `q^N≠1`, both principal halves close at `(p²,q²,t,d/p)` when p≠0. Both crossblocks are included. At p=0 the natural term is I and the separate no-division branch is retained. The crossblocks may have growing rank despite linear work.

**Accept natural-term correction only:** for k contiguous blocks, its exact Kronecker compression gives rank k−1 precisely when `(p^N)^(k−1)=1`, otherwise k, with p,d nonzero and p^N≠1; at p=0 rank zero. The characteristic-zero distinct-root assumption is retained. The correction has O(N) application. Whole masked-product telescoping gives only an upper bound, not a lower bound or noncancellation claim.

**Fresh controls:** 16 complete four-block identities including p=0/q=0/t=0, six exact accumulated-correction ranks/compressions, and the exact complex k4 exceptional rank-three case.

**Boundary:** scalar-only principal-half nonclosure is removed by the explicitly enlarged gauge family. Stage closure is not a complete masked-product Fourier recursion. Contiguous Fourier halves are not F_m; target ordering/twiddles/crossblock equations and full preparation costs remain missing for an all-size constructor.

## 10. M-F8-LOCAL-ELIMINATION

**Accept local reductions:** the fixed permutation is [7,0,6,3,4,1,2,5]. The globally separated-generator architecture is narrower than arbitrary order-one quasiseparability. The first-stage chart gives 30 equations in 26 coordinates only on its determinant/corner/normalization locus. The inverse-stage dual/onion reductions give 20 equations in 16 coordinates, then twelve rational equations in eight coordinates with 29 guards. Diag(A)=1 and diag(A^-1)=1 are different charts.

**Fresh local curvature certificate:** rebuilding the polynomial map from the pinned integer coordinates gives rank J=60, rank[J,E07]=61, and the exact selected 61×61 determinant 6913 modulo 12289. Twenty explicit unused-coordinate/internal-scale/intermediate-diagonal gauge vectors have rank twenty and are killed by J. The quadratic diagonal perturbation is exactly E07. With the analytic upper rank bound and differentiated gauge identities, this certifies the saved point's second-order non-liftability. It does not exclude other realization points or show that Fourier itself violates the local equations.

**Accept denominator-sensitive gates:** the adjacent-tail lemma uses independent C columns/shared tails and actual rank-one output constraints, avoiding earlier S/Delta divisions, but retaining its own hypotheses. The four-column structural gate needs invertible C (or nonzero coefficient triples); a zero fourth output multiplier is handled by vanishing cofactors, not division. The substituted polynomial family retains h0 Delta T≠0 and all inherited reconstruction guards. The factorization −DB·DH, regular complex slice exclusion, dimension≤2 necessary locus and at-most-twelve exceptional base points remain accepted pinned review results, not a whole-model solution.

**Fresh guard controls:** the invertible zero-corner anchored-minor false positive is reconstructed; the unit-diagonal A/zero-diagonal inverse example is checked; the exact characteristic-zero S1=0 partial candidate's good mod97 nonvanishing certificate is reproduced (detC=19, B corners 92/90, inverse corners 15/33); exactly ten selected minors vanish while twenty remain nonzero; 235 boundary-defect Fourier rows pass.

**Finite search boundary:** the historical GF17 enumeration of 1,328,244 gamma pairs and 2,546 invertible candidates with zero full second-stage successes was not rerun here. Of those candidates, 1,927 satisfy all four corners; 619 do not. Alpha=0 means dependent columns, not an extra divided denominator. h0=0, t=0, singular-tail and zero-denominator branches remain outside the enumerated scope. No GF17-rational point does not imply no complex point, nor no extension-field point.

## Stopping point

The existing statements have documented review outcomes. Scoped proof acceptance does not close the distinct constructor questions. No new fusion, unrestricted Fourier lower bound, practical speedup, bit-complexity improvement, or worldwide priority claim is licensed. The remaining heavy replay limits are explicitly attached to the relevant rows rather than hidden behind a blanket “all tests passed.”
