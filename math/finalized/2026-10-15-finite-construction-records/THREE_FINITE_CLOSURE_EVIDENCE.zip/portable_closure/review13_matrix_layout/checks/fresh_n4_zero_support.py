"""Exact unsaturated finite-outer zero-middle support controls from fresh definitions."""
from pathlib import Path
from itertools import combinations
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ_I
import json
R,a,c=ring('a,c',QQ_I);aa,cc=s.symbols('a c');x=s.symbols('x');I=s.I
Z=s.zeros(4);V=s.zeros(4);order=[0,2,1,3]
for j in range(4):Z[(j+1)%4,j]=1;V[order[(j+1)%4],order[j]]=1
G0=(s.eye(4)-Z/4).inv();G1=(s.eye(4)-V/5).inv();H=G0+x*G1;A=H.adjugate().applyfunc(s.expand);F=s.Matrix(4,4,lambda i,j:I**(i*j));L=[[R.from_expr(A[i,j].subs(x,aa)) for j in range(4)] for i in range(4)];RR=[[R.from_expr(A[i,j].subs(x,cc)) for j in range(4)] for i in range(4)]
K=[[sum((L[i][u]*R.from_expr(F[u,v])*RR[v][j] for u in range(4) for v in range(4)),R.zero) for j in range(4)] for i in range(4)]
vals=sorted(set(-G0[i,j]/G1[i,j] for i in range(4) for j in range(4)));out=[]
for b in vals:
 B=G0+b*G1;eq=[];z=[];rect=0
 for i in range(4):
  for j in range(4):
   if B[i,j]==0:eq.append(K[i][j].as_expr());z.append([i,j])
 for i,k in combinations(range(4),2):
  for j,l in combinations(range(4),2):
   if all(B[u,v]!=0 for u,v in [(i,j),(k,l),(i,l),(k,j)]):
    eq.append((K[i][j]*K[k][l]*R.from_expr(B[i,l]*B[k,j])-K[i][l]*K[k][j]*R.from_expr(B[i,j]*B[k,l])).as_expr());rect+=1
 gb=s.groebner(eq,aa,cc,domain=QQ_I);assert list(gb)==[1]
 out.append({'coupling':str(b),'zero_positions':z,'supported_rectangles':rect,'exact_Qi_unsaturated_basis':['1']});print('excluded',b,flush=True)
result={'passed':True,'branches':out,'no_guards_divided':True,'inherited_code_executed':False,'scope':'All finite independently variable outer couplings on every zero-middle support branch, fixed poles/cycles/internal orders.'}
Path(__file__).with_name('N4_ZERO_SUPPORT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
