"""Fresh finite-outer N4 certificate checks with a different resultant algorithm.
Rebuilds all six exact minor quotients, checks forced factors, and identifies
both modular resultants by 193 evaluations over F_29[u]/(u^2-2), then Bezout.
No inherited code is imported or executed; JSON coefficients are inert data.
"""
from pathlib import Path
from fractions import Fraction
import json,hashlib
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ_I
D=Path(__file__).parent.parent/'inputs';src=json.loads((D/'N4_OUTER_RANK_MINORS.json').read_text());receipt=json.loads((D/'FINITE_OUTER_RESULTANT_REVIEW.json').read_text())
R,a,c=ring('a,c',QQ_I);aa,cc=s.symbols('a c');xx=s.symbols('x');I=s.I
Z=s.zeros(4);V=s.zeros(4);order=[0,2,1,3]
for j in range(4):Z[(j+1)%4,j]=1;V[order[(j+1)%4],order[j]]=1
G0=(s.eye(4)-Z/4).inv();G1=(s.eye(4)-V/5).inv();H=G0+xx*G1;Adj=H.adjugate().applyfunc(s.expand);F4=s.Matrix(4,4,lambda i,j:I**(i*j));Ja=[[R.from_expr(Adj[i,j].subs(xx,aa)) for j in range(4)] for i in range(4)];Jc=[[R.from_expr(Adj[i,j].subs(xx,cc)) for j in range(4)] for i in range(4)]
K=[[sum((Ja[i][u]*R.from_expr(F4[u,v])*Jc[v][j] for u in range(4) for v in range(4)),R.zero) for j in range(4)] for i in range(4)]
g0=[[R.from_expr(G0[i,j]) for j in range(4)] for i in range(4)];g1=[[R.from_expr(G1[i,j]) for j in range(4)] for i in range(4)]
def coef(i,j):
 v=K[i][j]*K[0][0];w=K[i][0]*K[0][j]
 return [v*g0[i][0]*g0[0][j]-w*g0[i][j]*g0[0][0],v*(g0[i][0]*g1[0][j]+g1[i][0]*g0[0][j])-w*(g0[i][j]*g1[0][0]+g1[i][j]*g0[0][0]),v*g1[i][0]*g1[0][j]-w*g1[i][j]*g1[0][0]]
def determinant3(M):return M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1])-M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0])+M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0])
polys=[]
for rec in src['minors']:
 coords=rec['coords'];raw=determinant3([coef(i,j) for i,j in coords]);j=rec['i'];factor=K[0][0]*(K[j][0] if rec['mode']=='row' else K[0][j]);p=raw.exquo(factor).monic()
 ref=R.zero
 for degrees,re,im in rec['terms']:ref+=R.from_expr(s.Rational(re)+I*s.Rational(im))*a**degrees[0]*c**degrees[1]
 assert p==ref;polys.append(p);print('exact minor',rec['mode'],j,'matched',flush=True)
detpoly=lambda x:(15*x+16)*(10625*x**3+30500*x**2+29920*x+9984)
fac=detpoly(a)*detpoly(c);F=polys[2].exquo(fac);P=[polys[0],polys[1],polys[3],polys[4],polys[5].exquo(fac)]
# The exported six quotients are monic; the further determinant-guard division is NOT renormalized.
# Inert original checker inspected to resolve this representation convention after an initial control mismatch.
Gs=[sum(P,R.zero),sum(((j+1)*p for j,p in enumerate(P)),R.zero)]
h1=a+R.domain.convert(s.Rational(16,15));h3=(10625*a**3+30500*a**2+29920*a+9984)/10625
q3=s.Poly(10625*aa**3+30500*aa**2+29920*aa+9984,aa,domain=QQ_I).monic();assert q3.is_irreducible and s.gcd(q3,q3.diff()).degree()==0 and q3.eval(-s.Rational(16,15))!=0
forced=h1**5*h3**3;assert forced==R.from_expr(s.sympify(receipt['exact_forced_resultant_factor'],locals={'a':aa}))
# Exact linear-root Sylvester corank/first derivative lift.
linear=[]
for G,old in zip(Gs,receipt['resultants']):
 f=s.Poly(F.as_expr().subs(aa,-s.Rational(16,15)),cc,extension=I);g=s.Poly(G.as_expr().subs(aa,-s.Rational(16,15)),cc,extension=I);h=s.gcd(f,g).monic()
 assert [f.degree(),g.degree(),h.degree()]==[7,10,3]
 fa=s.Poly(s.diff(F.as_expr(),aa).subs(aa,-s.Rational(16,15)),cc,extension=I);ga=s.Poly(s.diff(G.as_expr(),aa).subs(aa,-s.Rational(16,15)),cc,extension=I)
 for w in range(4):
  u=g.exquo(h)*s.Poly(cc**w,cc,extension=I);v=-f.exquo(h)*s.Poly(cc**w,cc,extension=I);assert u*f+v*g==s.Poly(0,cc,extension=I);assert (u*fa+v*ga).degree()<=18
 linear.append({'degrees':[7,10],'gcd_degree':3,'four_kernel_vectors_and_derivative_c19':True})
# Exact monic cubic division modulo h3(a), with no algebraic field solver.
def modh(p):return p.rem(h3)
def by_c(p):
 out=[R.zero]*(max((e[1] for e in p),default=0)+1)
 for (i,j),v in p.items():out[j]+=v*a**i
 return [modh(x) for x in out]
def cubic_remainder(p,div):
 A=by_c(p);B=by_c(div);assert B[-1]==R.one
 while len(A)>=len(B):
  q=A[-1];offset=len(A)-len(B)
  for j,b in enumerate(B):A[offset+j]=modh(A[offset+j]-q*b)
  assert not A[-1];A.pop()
 return A
for G,old in zip(Gs,receipt['resultants']):
 divisor=R.from_expr(s.sympify(old['cubic_common_monic_divisor'],locals={'a':aa,'c':cc,'I':I}))
 assert all(not x for x in cubic_remainder(F,divisor));assert all(not x for x in cubic_remainder(G,divisor))
# Finite extension-field operations. 2 is a nonsquare modulo29.
p=29;assert pow(2,14,p)==28
zero=(0,0);one=(1,0)
def plus(x,y):return ((x[0]+y[0])%p,(x[1]+y[1])%p)
def neg(x):return (-x[0]%p,-x[1]%p)
def times(x,y):return ((x[0]*y[0]+2*x[1]*y[1])%p,(x[0]*y[1]+x[1]*y[0])%p)
def recip(x):
 d=pow((x[0]*x[0]-2*x[1]*x[1])%p,-1,p);return (x[0]*d%p,-x[1]*d%p)
def rat(q):q=s.Rational(q);return int(q.p)*pow(int(q.q)%p,-1,p)%p
def reducecoeff(q):return (rat(q.x)+12*rat(q.y))%p
def evalcoeffs(poly,at):
 ap=[one]
 for _ in range(poly.degree(a)):ap.append(times(ap[-1],at))
 co=[zero]*(poly.degree(c)+1)
 for (i,j),v in poly.items():co[j]=plus(co[j],times((reducecoeff(v),0),ap[i]))
 return co

def edet(M):
 M=[row[:] for row in M];res=one;n=len(M)
 for j in range(n):
  k=next((k for k in range(j,n) if M[k][j]!=zero),None)
  if k is None:return zero
  if k!=j:M[k],M[j]=M[j],M[k];res=neg(res)
  pivot=M[j][j];res=times(res,pivot);ip=recip(pivot)
  for k in range(j+1,n):
   q=times(M[k][j],ip)
   for l in range(j+1,n):M[k][l]=plus(M[k][l],neg(times(q,M[j][l])))
 return res

def resultant_eval(F,G,at):
 f=evalcoeffs(F,at);g=evalcoeffs(G,at);df=8;dg=12;M=[[zero]*20 for _ in range(20)]
 # Column Sylvester map uF+vG. Its sign is + since degrees product is even.
 for col in range(dg):
  for j,x in enumerate(f):M[col+j][col]=x
 for col in range(df):
  for j,x in enumerate(g):M[col+j][dg+col]=x
 return edet(M)
def eval_saved(co,a):
 out=zero
 for x in co:out=plus(times(out,a),(x%p,0))
 return out
# Saved lists are descending coefficients; full-degree 192 identified at 193 points.
for idx,(G,old) in enumerate(zip(Gs,receipt['resultants'])):
 for j in range(193):
  at=(j%29,j//29);got=resultant_eval(F,G,at);expected=eval_saved(old['modular_resultant_coefficients'],at)
  assert got==expected,(idx,j,got,expected)
 print('resultant',idx,'identified at 193 extension-field points',flush=True)
def cmul(A,B):
 C=[0]*(len(A)+len(B)-1)
 for i,a0 in enumerate(A):
  for j,b0 in enumerate(B):C[i+j]=(C[i+j]+a0*b0)%29
 return C
def cadd(A,B):
 n=max(len(A),len(B));A=[0]*(n-len(A))+A;B=[0]*(n-len(B))+B;C=[(a+b)%29 for a,b in zip(A,B)]
 while len(C)>1 and C[0]==0:C.pop(0)
 return C
forced_mod=[reducecoeff(v) for _,v in sorted(forced.items(),reverse=True)]
for old in receipt['resultants']:assert cmul(forced_mod,old['modular_quotient_coefficients'])==old['modular_resultant_coefficients']
assert cadd(cmul(receipt['bezout_U'],receipt['resultants'][0]['modular_quotient_coefficients']),cmul(receipt['bezout_V'],receipt['resultants'][1]['modular_quotient_coefficients']))==[1]
out={'passed':True,'six_exact_minor_arrays_identified':True,'input_minors_sha256':hashlib.sha256((D/'N4_OUTER_RANK_MINORS.json').read_bytes()).hexdigest(),'receipt_sha256':hashlib.sha256((D/'FINITE_OUTER_RESULTANT_REVIEW.json').read_bytes()).hexdigest(),'linear_forced_factor_checks':linear,'cubic_divisor_exact_membership_both_resultants':True,'modular_resultants_identified_by_degree_bound':{'field':'GF(29^2)=GF(29)[u]/(u^2-2)','points_each':193,'degree_bound':192,'resultant_degrees':[192,192],'quotient_degrees':[178,178]},'modular_quotient_products_match':True,'bezout_identity_verified':True,'inherited_code_executed':False,'scope':'Fresh finite regular outer certificate. Zero-middle and infinity branches have separate receipts/controls.'}
Path(__file__).with_name('N4_FINITE_CERTIFICATE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print('finite-outer certificate passed')
