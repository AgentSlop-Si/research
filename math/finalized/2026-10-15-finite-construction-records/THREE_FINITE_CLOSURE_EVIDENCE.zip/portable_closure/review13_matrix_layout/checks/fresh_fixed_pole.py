"""Fresh fixed-pole N4 boundary controls. No inherited code execution."""
from pathlib import Path
import sympy as s
import json
x=s.symbols('x');I=s.I
Z=s.zeros(4);V=s.zeros(4);order=[0,2,1,3]
for j in range(4):Z[(j+1)%4,j]=1;V[order[(j+1)%4],order[j]]=1
G0=(s.eye(4)-Z/4).inv();G1=(s.eye(4)-V/5).inv();H=G0+x*G1;F=s.Matrix(4,4,lambda i,j:I**(i*j));adj=H.adjugate().applyfunc(s.expand)
DH=s.factor(H.det());expected=(15*x+16)*(10625*x**3+30500*x**2+29920*x+9984)/159120
assert s.expand(DH-expected)==0 and (H*adj-DH*s.eye(4)).applyfunc(s.expand)==s.zeros(4)
zero=sorted(set(-G0[i,j]/G1[i,j] for i in range(4) for j in range(4)))
assert len(zero)==9

def coeff(K):
 # Coefficients in r^2, r*s, s^2 of homogeneous middle proportionality.
 rows=[]
 for i in range(1,4):
  for j in range(1,4):
   a=K[i,j]*K[0,0];b=K[i,0]*K[0,j]
   rows.append([s.expand(a*G0[i,0]*G0[0,j]-b*G0[i,j]*G0[0,0]),s.expand(a*(G0[i,0]*G1[0,j]+G1[i,0]*G0[0,j])-b*(G0[i,j]*G1[0,0]+G1[i,j]*G0[0,0])),s.expand(a*G1[i,0]*G1[0,j]-b*G1[i,j]*G1[0,0])])
 return s.Matrix(rows)
def pdet3(C,rows):
 m=C[list(rows),:];return s.Poly(s.expand(m[0,0]*(m[1,1]*m[2,2]-m[1,2]*m[2,1])-m[0,1]*(m[1,0]*m[2,2]-m[1,2]*m[2,0])+m[0,2]*(m[1,0]*m[2,1]-m[1,1]*m[2,0])),x,extension=I)
Kinf=G1.adjugate()*F*G1.adjugate();assert Kinf[0,0]==s.Rational(109375,194688);Cinf=coeff(Kinf);mi=s.simplify(Cinf[:3,:].det());assert mi!=0
out={'determinant':str(DH),'zero_middle_values':[str(v) for v in zero],'common_infinity_K00':str(Kinf[0,0]),'common_infinity_first_minor':str(mi),'one_infinity':[],'full_finite_outer_resultants':'separate N4_FINITE_CERTIFICATE_RESULTS.json; independently reconstructed and verified','inherited_code_executed':False}
for side in ['left','right']:
 K=(G1.adjugate()*F*adj if side=='left' else adj*F*G1.adjugate()).applyfunc(s.expand);C=coeff(K)
 d1=pdet3(C,[0,1,2]);d2=pdet3(C,[0,1,3]);g=s.gcd(d1,d2).monic();assert d1.degree()==d2.degree()==18 and g.degree()==5
 guard=s.Poly(s.expand(DH*K[0,0]),x,extension=I);r=g
 while r.degree()>0:
  gg=s.gcd(r,guard)
  if gg.degree()==0:break
  r=r.exquo(gg)
 assert r.degree()==0
 support=[]
 for value in zero:
  B=G0+value*G1;eq=[]
  for i in range(4):
   for j in range(4):
    if B[i,j]==0:eq.append(s.Poly(K[i,j],x,extension=I))
  g0=eq[0]
  for e in eq[1:]:g0=s.gcd(g0,e)
  for i in range(4):
   for k in range(i+1,4):
    for j in range(4):
     for l in range(j+1,4):
      if g0.degree()==0:break
      if all(B[a,b]!=0 for a,b in [(i,j),(k,l),(i,l),(k,j)]):
       e=s.Poly(s.expand(K[i,j]*K[k,l]*B[i,l]*B[k,j]-K[i,l]*K[k,j]*B[i,j]*B[k,l]),x,extension=I);g0=s.gcd(g0,e)
  assert g0.degree()==0;support.append({'middle':str(value),'necessary_equation_gcd_degree':0})
 out['one_infinity'].append({'side':side,'minor_degrees':[d1.degree(),d2.degree()],'gcd_degree':g.degree(),'gcd':str(g.as_expr()),'after_repeated_guard_removal_degree':r.degree(),'all_nine_zero_middle_branches':support})
 print(side,'passed',flush=True)
# The full finite-outer certificate is independently checked by fresh_n4_finite_certificate.py.
f=Path(__file__).parent.parent/'inputs/FINITE_OUTER_RESULTANT_REVIEW.json'
c=json.loads(f.read_text());out['historical_finite_resultant_receipt_keys']=list(c)
Path(__file__).with_name('FIXED_POLE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print('all fixed-pole boundary controls passed')
