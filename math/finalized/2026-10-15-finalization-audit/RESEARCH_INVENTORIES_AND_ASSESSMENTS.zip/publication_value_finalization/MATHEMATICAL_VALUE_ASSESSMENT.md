# Mathematical value: evidence-based shortlist

15 October 2026. Scope: the strongest proof-bearing matrix/Fourier candidates encountered in the local research corpus, especially C03, F018/C05, F014, and projective curvature. This is a mathematical/publication assessment, not an exhaustive ranking of all research. No external write occurred.

## Bottom line

Yes: there is defensible incremental mathematical value here. The most credible specialist-paper material is the independently routed separator obstruction (F018) and the sharp dyadic cut-rank minimax/deficit bounds (C02). The fixed-pair Weyl–Green result (F014), including its later quadratic delta-zero bound, is a useful narrower theorem. The reciprocal diagonal-pencil resultant (C03) is good specialized algebra, better positioned as a formula note or supporting proposition. The single-cycle projective-curvature exclusion is a poor standalone lead: an elementary inverse-support argument proves a stronger exclusion.

None of these inspected results establishes a faster general FFT, an unrestricted Fourier arithmetic lower bound, or commercial value. Internal acceptance labels document reviews performed within this research project; they are not journal or external specialist acceptance. Historical novelty remains distinct from correctness and usefulness.

## 1. F018: routed low-separator inverse sums

**Recommendation: keep and develop as a specialist paper.** This is the strongest of the four expressly requested families.

### Actual theorem

For a complex flat normalized unitary U of size N, suppose

U = S + K + δD + Σ(i=1..r) L_i Q_i^(-1) R_i.

Here S has at most s nonzeros per row, rank(K)≤t, D is diagonal, δ is 0 or 1, Q_i is invertible, and L_i,R_i have independent permutation-contained support, allowing zero endpoint weights. Each symmetric bipartite support lift of Q_i has weighted half-component separators of size at most q for the markings invoked. Put d=s+1+δ. Then

N ≤ d²(qr+t)9^r + dq(3^r−1) + 2(d−1).

Fixed q,s,t force r=Ω(log N). Column-two denominators allow q=2; forest lifts allow q=1. This is uniform over the stated architecture and arbitrary permitted parameters, rather than a rejection of one chosen numerical circuit.

### Correctness assessment

I read the all-size selection and correction proof, including the noncircular check that every selection step has enough marks. The kernel proof of complementary inverse rank, retention of one actual rectangle through unrelated routings, correction elimination, and flat-unitary stable-rank contradiction are coherent. I found no mathematical error in this proof inspection. I did not rerun its large inherited certificate corpus.

### Novelty and use

Inverse cut ranks, graph separators and stable rank are classical. GIRS Proposition 2.3 explicitly composes on the same graph; it does not itself provide a simultaneous retained rectangle for independently routed branches. The plausible increment is this precise synthesis and explicit cutoff. I freshly checked the relevant GIRS passages; the corpus also contains a careful final-TQS comparison. That supports a bounded nonmatch, not a worldwide originality claim. [GIRS primary paper](https://arxiv.org/pdf/1911.05858v3)

It can prune entire proposed low-width additive transform architectures and provides guarded approximation obstructions. Products of such sums, freely changing interstage coordinates, and all arithmetic circuits are outside it. Its fixed-r approximation floor does not imply Ω(log N) branches at a fixed positive tolerance.

**Exact next requirement:** send the existing scoped manuscript to one external specialist in structured matrices, asking specifically whether its independently routed retained-rectangle theorem follows from an existing result. Include a clearly defined application/model and retain the additive-only boundary. Another large finite search is not the missing requirement.

## 2. C02: sharp dyadic endpoint cut-rank minimax

**Recommendation: place alongside F018, possibly ahead of it as a clean mathematical lead.** This additional candidate emerged from reading the proofs rather than their scores.

For q(A) equal to the maximum rank of either off-diagonal block across a coordinate cut,

min over independent row/column permutations of q(P F_N Q) = N/4+1,

for cyclic N=2^m≥8. Double bit reversal attains the bound. Its lower proof works for every (N/2−1)-by-(N/2+1) rectangle of a normalized character table of an abelian 2-group and yields an explicit positive singular-value gap. It does not say that balanced half-square blocks all have rank N/4+1: their minimum is N/4.

### Correctness assessment

I read the fourth-moment/complementary-Gram lower proof and the upper bit-reversal recurrence, including its odd-cut residue guard. The odd-cardinality set cannot be invariant under any nonzero translation of a 2-group, giving the required strict moment deficit. The proof is internally sound at its complex/characteristic-zero scope. Fresh numerical corroboration checks all 3,136 critical rectangles at N=8 against the asserted singular-value gap; this is not a proof for all N.

### Novelty and use

Digit reversal and its rank-one hierarchy are established prior work. The corpus's final Delvaux–Van Barel comparison distinguishes their one-vector support-extremum theorem from this all-order cut-rank minimax and quantitative nullity bound; N=8 already overlaps their theorem. I read that detailed final-paper comparison, not a fresh complete final-journal PDF. The accessible author report is a primary antecedent. [Delvaux–Van Barel report](https://www.cs.kuleuven.be/publicaties/rapporten/tw/TW470.pdf); [final article](https://doi.org/10.1016/j.laa.2008.04.043)

The result explains why coordinate reordering alone cannot make dyadic Fourier uniformly low quasiseparable rank. This is a natural structured-linear-algebra question, with sharp attainment and a robust extension. It is more self-contained than a list of failed transform designs.

**Exact next requirement:** an external reviewer should check the minimax theorem and compare it against generalized uncertainty/subspace-dimension bounds and the authors' related 2007 Kronecker-product paper. The paper must credit bit reversal and state what the fourth-moment bound adds. Broader noncyclic attainment is optional, not needed to present the accepted cyclic theorem.

## 3. F014: fixed-common-pair Weyl–Green branch bounds

**Recommendation: worthwhile short theorem or a section of a representation-obstruction paper; narrower independent-paper case.**

For odd N, an exact-order Nth root, and one common ordered generating Weyl pair U=S^uT^v, V=S^rT^s, the allowed atoms are

c (I−αU)^(-1)(I−βV)^(-1),

with legal nonresonant denominators and scalar numerator. No branch-specific generators, order reversals, extra Weyl endpoints or arbitrary gauges are allowed. The original gcd-sensitive three-rank bound gives at least ceil(√N) atoms for odd N and at least (N+1)/2 for odd prime powers.

A later accepted strengthening is materially stronger on the slice δ=(us−vr−ur−vs)/2=0: **b≥((N+1)/2)² for every odd N.** The pair U=S,V=ST lies in that slice for every odd N, so the condition is not empty.

### Correctness assessment

I read both proofs. Legal atoms become bivariate evaluation moments. The no-wrap lift indexed by {0,…,(N−1)/2}² gives rank at most one per atom. At δ=0 the target lift is the tensor product of two invertible chirp Hankel matrices, giving rank ((N+1)/2)². The residue identity AB=2D² makes the two chirp parameters units. These steps are valid, including zero atom parameters, provided the exponent indices are not wrapped. Fresh exact finite-field lift-rank checks at N=3,5,7,9,15 pass.

### Novelty and use

Harmouch–Khalil–Mourrain define the same truncated multivariate moment construction and rank-one evaluation atoms. Thus the rank method is classical; the finite-Weyl target calculation and arithmetic consequences are the particular application. I freshly checked their definitions and Example 2.4. [Primary paper](https://arxiv.org/pdf/1701.05805v1)

This explains why particular attractive resolvent parameterizations are inherently branch-heavy. It says little about general Fourier complexity because a reverse-ordered or differently generated single atom can violate the lift-rank premise.

**Exact next requirement:** one concise manuscript combining the original and delta-zero statements, with a side-by-side grammar table and explicit comparison to multivariate moment/separation-rank literature. For stronger significance, provide a matching construction or a substantial larger architecture class; neither is required to retain the current correct theorem.

## 4. C03: reciprocal diagonal-pencil resultant

**Recommendation: retain as a useful specialized identity; do not lead a major-discovery pitch with it.**

For arbitrary m-by-m matrices A,B over a commutative ring, D=diag(1,w,…,w^(m−1)), and the fixed homogeneous degree-(m,m) resultant of det(A−aDAD) and det(B−awDBD),

R(w)=w^(v+b)(w−1)^(m²)V(w+w^(-1)),

v=m(m−1)(4m+1)/6, b=m(m−1)(2m−1)/6, deg V≤b.

The universal identity handles singular inputs and degree drops because the resultant remains padded. Generic exact valuations must not be claimed for every specialization. The full package contains a signed leading coefficient and division-free endpoint formulas.

### Correctness and novelty

I read the algebraic proof and coefficient-level Bezoutian/Hankel bridge. Five newly written exact symbolic padded-resultant checks, including singular and zero cases, pass. The argument uses classical resultant covariance, weighted root valuations, and reciprocal trace compression. Barnett's congruence directly supplies the normalized derived Hankel bridge; the raw input moments and that derived Hankel matrix are different. [García-Armas–Ghorpade–Ram, Proposition 3.4](https://arxiv.org/html/1011.1760#S3); [Baker, Appendix B](https://arxiv.org/html/2309.02512v2#A2)

The entire printed specialization may still be original, but that has not been established. Its value is explicit algebra and potentially cheaper resultant reconstruction, not a new general resultant theory. The sample count improves by a constant factor asymptotically while remaining Θ(m³); the O(m³) supplied-node evaluator is not O(m³) full recovery.

**Exact next requirement:** identify one concrete reconstruction/elimination problem where the complete identity produces a meaningful advantage after all evaluation, interpolation and root/gcd costs are counted. If no such application is available, position it honestly as a formula note with an exact classical derivation.

## 5. Projective curvature and fixed-mask pencil exclusions

**Recommendation: retain as a certificate/tool; low standalone publication priority at its current claimed conclusion.**

The reviewed curvature theorem compares anchored cross-ratio exponent ranks for primitive-holonomy single-cycle Green kernels and Fourier matrices at dyadic sizes. The all-anchor lattice argument is coherent. The later certificate rejects every complex scalar λ for specified fixed three-stage pencils at six sizes N=4,…,128, with fixed internal masks, branch parameters and traversals. It does not reject all freely tunable circuits or all lengths.

### A simpler stronger exclusion

If F_N=L G R with invertible monomial endpoints and G=(I−αP)^(-1), then

F_N^(-1)=R^(-1)(I−αP)L^(-1).

The right side has at most two nonzeros in every row. The inverse Fourier matrix has N nonzeros in every row. Thus equality is impossible whenever N>2. This uses no primitive-holonomy condition, no dyadic assumption, and no curvature calculation. It also handles nonconstant weighted permutation P. This argument does not apply to sums or general products of branches.

Consequently, the single-cycle non-equivalence conclusion alone is too elementary to justify a substantial novelty claim. The computed curvature rank may still have uses not captured by inverse support, but those need to be shown. Cross-ratio invariance is also classical: the standard Haagerup invariants are described in the primary complex-Hadamard survey, Section 2. [Tadej–Życzkowski](https://arxiv.org/pdf/quant-ph/0512154)

For the fixed-mask pencils, the modular resultant/Bézout lift is legitimate when coefficient denominators and degrees survive reduction. I read the source review but did not rebuild its twelve polynomial certificates in this pass. A one-parameter family chosen by a seed is an exact case study, not yet a broad structural advance.

**Exact next requirement:** exhibit a nontrivial multi-branch or variable-mask family which the curvature invariant separates and inverse-support/rank tests do not, or demonstrate a robust approximation/certification advantage. Without that, retain this material as supporting diagnostics rather than the headline theorem.

## Evidence and verification limits

- Complete local proof bodies and reviews were read, rather than trusting titles, ranking scores or acceptance filenames.
- Newly written checks are in `independent_math_checks.py`; results are in `independent_math_checks.json`. Five symbolic C03 cases, five exact F014 lift-rank cases with twenty atom controls, and 3,136 numerical C02 rectangles passed.
- F018 was proof-inspected; its historical large certificate counts were not rerun. The projective fixed-pencil certificate arrays were not reconstructed in this pass.
- Primary pages freshly inspected include GIRS, HKM, Barnett/Hankel, reciprocal trace polynomials, and complex-Hadamard invariants. Some broader citation conclusions rely on the specifically identified local prior comparisons. A finite search or a bounded nonmatch is not a proof of global firstness.
- The useful next step is focused external mathematical feedback on one or two strong papers, not indiscriminate generation of more “accepted” variants.
