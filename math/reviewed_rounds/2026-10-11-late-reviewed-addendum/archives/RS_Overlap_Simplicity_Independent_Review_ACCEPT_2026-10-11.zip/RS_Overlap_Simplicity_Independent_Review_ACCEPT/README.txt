RS overlap simplicity independent review: ACCEPT
11 October 2026 UTC

Accepted domain: A >= 1; b=1 and odd d >= 3, or b=3 and odd d >= 5; every primitive d-th root. The original RS normalization tau=dW/g is essential. All residual guards and Disc(J) are nonzero in these two subfamilies. General guards remain in place outside them. No publication-priority conclusion is made.

Read RS_Overlap_Simplicity_Independent_Review_ACCEPT.pdf (5 pages), or its editable .tex and searchable .txt.

Reproduce exact controls: python3 independent_exact_checks.py
Expected: 249 passed, 0 failed. Requires Python 3 and SymPy. Only this newly authored program was run. The audited_candidate folder contains inert copies of the candidate source and certificate, not executable input to the independent checker.

Rebuild the PDF with a complete XeLaTeX installation and Latin Modern fonts: xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error RS_Overlap_Simplicity_Independent_Review_ACCEPT.tex (twice).

SOURCE_PINS.json binds the candidate Library ZIP, all seven candidate members, and frozen manuscript/prior-review inputs. MANIFEST_SHA256.json hashes every payload except itself. Final Library round-trip verification is a separate receipt to avoid recursive hashing. No original file, Sheet, or repository was modified.
