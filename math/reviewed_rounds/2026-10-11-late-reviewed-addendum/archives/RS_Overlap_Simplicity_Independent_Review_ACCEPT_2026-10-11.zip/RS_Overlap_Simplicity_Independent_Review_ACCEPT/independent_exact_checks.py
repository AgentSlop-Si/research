#!/usr/bin/env python3
"""Independent exact audit controls; newly authored for this review.
Historical/candidate proof programs are not imported or executed.
"""
from pathlib import Path
import json, sympy as S
q,r,x,T=S.symbols('q r x T')
checks=[]
def check(name, condition, **data):
    if not bool(condition): raise AssertionError(name)
    checks.append({'name':name,'pass':True,**data})
def field(d):
    phi=S.Poly(S.cyclotomic_poly(d,q),q,domain=S.QQ)
    def reduce(a):return S.Poly(a,q,domain=S.QQ).rem(phi).as_expr()
    def divide(a,b):return reduce(a*S.invert(b,phi.as_expr(),q))
    # Use the complementary odd product, independent of the author's inverse-even implementation.
    tau=1
    for k in range(1,d,2):tau=reduce(tau*(1-q**k))
    return phi,reduce,divide,tau
norms={(1,3):r-1,(1,5):r*r-7*r+11,(3,5):11*r*r-7*r+1,(3,7):r-1,(3,9):19*r**3-129*r*r+282*r-199,(3,11):683*r**5-8684*r**4+42063*r**3-97250*r*r+107618*r-45761}
for (b,d),p in norms.items():
    phi,red,div,t=field(d)
    if b==3:t=div(t*(1+q),2+q)
    bar=red(t.subs(q,q**(d-1)))
    rho=red((t-1)*(bar-1))
    res=S.Poly(S.resultant(phi.as_expr(),r-rho,q),r)
    squarefree=res.sqf_part().monic()
    check(f'norm squarefree b={b}, d={d}',squarefree==S.Poly(p,r).monic(),tau=str(t),rho=str(rho),norm=str(res.as_expr()))
    # The exact resultant additionally certifies that all roots of p occur as conjugates.
    exponent=phi.degree()//S.degree(p,r)
    check(f'norm multiplicity b={b}, d={d}',S.expand(res.as_expr()-S.Poly(p,r).monic().as_expr()**exponent)==0)
check('b1,d5 conjugate outside maximum annulus',norms[1,5].subs(r,4)<0 and norms[1,5].subs(r,5)>0)
check('b3,d5 conjugate inside unit radius',norms[3,5].subs(r,0)>0 and norms[3,5].subs(r,S.Rational(1,4))<0)
check('b3,d9 conjugate outside A>=3 annulus',norms[3,9].subs(r,S.Rational(8,3))<0 and norms[3,9].subs(r,4)>0)
check('b3,d11 conjugate outside maximum annulus',norms[3,11].subs(r,4)<0 and norms[3,11].subs(r,5)>0)
check('b3 reality polynomial',S.expand(q*(1+2*q)**4-(2+q)**4-(q-1)*(q*q+q+1)*(16*q*q+31*q+16))==0)
check('residual nonreality polynomial',S.expand(q**2*(q+q*q)-q-1-(q-1)*(q+1)*(q*q+q+1))==0)
u=S.Rational(22,91); L=S.Rational(471,650)
check('rational tangent upper bound',u/(1-u*u/2)<S.Rational(1,4),margin=str(S.Rational(1,4)-u/(1-u*u/2)))
check('rational cosine upper bound',1-L*L/2+L**4/24<S.Rational(3,4),margin=str(S.Rational(3,4)-(1-L*L/2+L**4/24)))
check('sine bound',S.Rational(1,2)<S.Rational(3,4)**2)
check('sqrt13 rational bound',S.Rational(361,100)**2>13)
check('large-d inequality at13',1+S.Rational(64*13,145)-S.Rational(13*361,1200)>S.Rational(8,3),margin=str(1+S.Rational(64*13,145)-S.Rational(13*361,1200)-S.Rational(8,3)))
check('large-d derivative lower bound',S.Rational(64,145)-S.Rational(13,72)>0)
check('b1,d>=7 endpoint bound',S.Rational(8,3)**2>7)
for A in range(1,13):
    print(f'Checking A={A}',flush=True)
    J=S.expand(x*S.hermite_prob(A,x)-A*T*S.hermite_prob(A-1,x))
    m=(A+1)//2;s=(A+1)%2
    alpha=S.Rational(2*s-1,2)
    # Work directly in y=x^2; no associated-Laguerre function is used here.
    y=S.symbols('y'); C=S.zeros(m)
    for j in range(m):C[j,j]=4*j+2*alpha+2
    for j in range(1,m):C[j,j-1]=1;C[j-1,j]=4*j*(j+alpha)
    C[m-1,m-1]+=A*(T-1)
    char=S.expand((y*S.eye(m)-C).det(method='domain-ge'))
    check(f'parity Jacobi characteristic A={A}',S.expand(x**s*char.subs(y,x*x)-J)==0)
    check(f'Hermite derivative elimination A={A}',S.expand(S.diff(J,x)-(1+A*T)*S.hermite_prob(A,x)-A*x*(1-T)*S.hermite_prob(A-1,x))==0)
    if A%2:
        check(f'zero-root parameter A={A}',S.expand(J.subs(x,0)+A*T*S.hermite_prob(A-1,0))==0)
    else:
        check(f'zero-root derivative A={A}',S.expand(S.diff(J,x).subs(x,0)-(1+A*T)*S.hermite_prob(A,0))==0)
    delta=S.discriminant(J,x)
    for d in [3,5,7,9,11,13,15]:
        phi,red,div,t1=field(d)
        for b in [1,3]:
            if b>=d:continue
            t=t1 if b==1 else div(t1*(1+q),2+q)
            # Independent exact nonvanishing in the cyclotomic quotient.
            value=S.Integer(0)
            for coefficient in S.Poly(delta,T).all_coeffs():
                value=red(value*t+coefficient)
            check(f'finite discriminant A={A}, b={b}, d={d}',value!=0)
for d in range(3,24,2):
    phi,red,div,t=field(d);h=(d-1)//2
    check(f'odd-product square phase d={d}',red(t*t-(-1)**h*d*q**(h*h))==0)
    for b in [1,3]:
        if b>=d:continue
        num=den=1
        for j in range(1,b+1):num=red(num*(1-q**j))
        for j in range(1,(d+b)//2+1):den=red(den*(1-q**(2*j)))
        g=1 if b==1 else 2-q-q*q
        actual=div(d*num,red(den*g));simplified=t if b==1 else div(t*(1+q),2+q)
        check(f'direct W/g specialization b={b},d={d}',red(actual-simplified)==0)
result={'arithmetic':'exact rational polynomial arithmetic only','count':len(checks),'failed':0,'checks':checks,'scope':'Controls support finite normalization and exclusions. The full proof supplies all A and all d; no numerical test substitutes for proof.'}
Path(__file__).with_name('INDEPENDENT_EXACT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':len(checks),'failed':0}))
