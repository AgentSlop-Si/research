# Hero1 Phase21 audit

## Decision

**Accept the universal reciprocal Hankel-resultant identity and the conditional fixed-sparsity recovery theorem.** This is a genuine algebraic strengthening of Phase20's previously observational palindromic pattern. It reduces reconstruction of the order-s resultant to a polynomial in w+w inverse of degree at most s(s+1)(2s+1)/6. For s=4, 31 core samples replace the conservative 226; the executable also takes three witnesses, for 34 actual resultant evaluations.

The full cyclic certificate is sound and essential. The new method remains a structured-input route with explicit degeneracy gates and an ordinary FFT fallback. It does not improve the generic-input FFT bound or establish historical priority.

**Do not accept the source's operation counters as complete cold costs, or its executable domain as every prime field containing an Nth root.** The archive leaves the inherited Phase20 resonance guard, fresh sparse-root-table undercount and zero-diagonal Green-solver limitation unchanged. The new reciprocal path avoids the old resonance guard, but calls the undercounting helper. Its outer Green constructor still fails on some invertible cyclic matrices. These implementation limitations are separate from the new polynomial theorem.

## Provenance and exact predecessor comparison

Archive: `fft_hero1_phase21_20261010.zip`, 9,765,094 bytes, SHA-256

    59b93d506fd4d545e9932ae98c4f290c1ae68b90878a82e344ecffb616d5780a

Initial direct-upload Library identity: `libfile_61b65e63144c819193b9b439ae2bb26a`. The later resend `libfile_1bbcef6523248191b22f31e4599737a9` is byte-identical; its metadata and comparison are preserved. All 48 members were materialized as inert files. All 42 entries in the source's manifest match. The nested Phase20 zip is byte-identical to the previously reviewed archive, SHA-256 `c20b633a0e8a7be1ee81ab65765a15e3fb77a39d3315c7139cef5d88aa1333c3`.

Twenty-one carried-over files are byte-unchanged, including `resultant_gate.py`, `annihilator_engine.py`, `green_sparse.py`, `rational_forcing.py`, `blind_sparse_rational.py` and the legacy hybrid. `LINEAGE_CHECKS.json` gives the full comparison. The new algorithm files are `reciprocal_union.py`, `reciprocal_resultant.py`, `compressed_resultant.py` and the new general-order `resultant_pattern.py`.

The new proof, algorithm, tests, audits and benchmark source were read statically. Uploaded programs were never executed or imported. Publisher-supplied logs and counts remain source claims; the independent checks below are freshly authored, not reruns of the source suite.

## What the new structured family is

Write R=F_N r, where the earlier fixed Green preconditioner gives r=P x. Assume

    Q(S) r = h_u e_u + h_v e_v,

with distinct positions, nonzero amplitudes, at most s coefficients in Q modulo z^N-1, and Q nonzero on every Nth root. Neither Q nor its possible graph factors or defect locations is supplied. Then R_k=H(omega^k)/Q(omega^k).

Set delta=v-u, gamma=-h_v/h_u and A(z)=h_u inverse z^(-u) Q(z) in the cyclic polynomial ring. For nonzero R probes,

    (1-gamma omega^(delta k))/R_k = A(omega^k),

an exponential sum with at most s modes. This reciprocal reformulation reduces two unknown impulses and several unknown binomial graph factors to a single unknown binomial multiplier of the reciprocal probes. The canonical certificate is

    A(S) r = e_0-gamma e_delta.

Globally nonzero A on the root subgroup makes this certificate sufficient for every Fourier output. It need not reconstruct the original shifts or a unique factorization. Collision-free hypercube support permits the optional finite enumeration of a valid binomial factorization; its combinatorial cost depends strongly on the fixed factor count.

## Universal resultant proof

Let m=s+1 and T_0 through T_(2s+1) be formal variables. Define

    P_e(a,w)=det[T_(e+i+j)(1-a w^(e+i+j))]_(0<=i,j<m),
    R_s(w)=Res_a(P_0,P_1),
    D=m squared (2m-1),
    v=s(s+1)(4s+5)/6,
    b=s(s+1)(2s+1)/6.

The fixed-degree-m homogeneous Sylvester convention is important. It remains a polynomial identity when a leading coefficient specializes to zero; a specialized resultant can acquire extra zeroes, including from a root at infinity, so a zero resultant is only a candidate condition.

The accepted identities are

    w^D R_s(1/w)=(-1)^(m squared) R_s(w),
    R_s(w)=w^v (w-1)^(m squared) U_s(w),
    w^(2b) U_s(1/w)=U_s(w),
    U_s(w)=w^b V_s(w+1/w),  degree V_s<=b.

They hold identically, including zero-resultant and singular-Hankel specializations.

The proof's four steps check out:

1. Reversing a and w in each pencil gives P_e(a,1/w)=(-a)^m w^(-E_e)P_e(1/a,w), E_e=me+m(m-1). Reversal of both fixed-degree resultant arguments supplies sign (-1)^(m squared); homogeneity gives grade D.
2. Put w=1+epsilon and a=1+epsilon t. Every matrix entry is divisible by epsilon. The two determinant factors supply epsilon^(2m squared), while the common affine change of variable contributes epsilon^(m squared). Cancellation proves the universal (w-1) factor to power m squared.
3. In the generic coefficient field, Cauchy–Binet gives valuation j(j-1)+ej for the coefficient of a^j. The minimal index sets are uniquely {0,...,j-1}. Their Hankel minors and inverse principal minors are generically nonzero; the latter can also be seen through complementary-minor identities. Thus the Newton slopes are e,e+2,...,e+2s. The two pencils' root valuations have opposite parity, preventing cancellation in their pairwise differences. The resultant valuation is exactly D minus the sum of max(2i,2j+1), namely v. This proves a universal lower divisibility order after any specialization, though the actual order can rise.
4. Dividing the universal factors leaves palindromic grade D-2v-m squared=2b. Symmetric Laurent polynomials are polynomials in w+1/w. Monic division and the integral recurrence for w^k+w^(-k) show the identities specialize to prime fields without assuming that the generic matrices remain nonsingular there.

For s=2 this proves the Phase20 pattern w^13(w-1)^9 with a palindromic grade-10 quotient. For s=4 it gives w^70(w-1)^25 and grade 60. These are universal identities, not degree patterns fitted to test vectors. The generic actual resultant degree is D-v; the formal reciprocity grade remains D.

## Discovery and acceptance conditions

The compressed implementation uses 4s directly computed Fourier probes and rejects if any are zero. It reconstructs V_s from b+1 distinct nodes w+w inverse, excludes w=0,1, and checks three extra values. A nonzero U_s has at most 2b roots, so at most that many nontrivial subgroup shifts need candidate processing. The code restricts 1<=s<=8, N>=4s and p>4b+20, a sufficient field-size condition for its node selection. The algebraic identity itself has no s<=8 restriction.

A candidate needs a degree-one gcd in a, then an at-most-s-mode Prony representation matching all 4s probes. The code evaluates A at all N roots, rejects spectral zeros, and finally checks the full cyclic identity. On acceptance,

    R_k=(1-gamma omega^(delta k))/A(omega^k)

is exact. Zero numerators outside the probe prefix are allowed and simply give zero outputs; nonzero denominators remain mandatory.

The claim of one full certificate at most is justified. Two ratios B/A with at most two numerator and s denominator terms, agreeing on 4s consecutive subgroup samples where denominators do not vanish, have a cross product with at most 4s cyclic monomials. A Vandermonde system forces that cross product to vanish on the whole subgroup. Therefore two globally invertible candidates cannot describe different full spectra after matching the prefix. If the first such candidate fails the time-domain certificate, no later globally invertible candidate can fix the mismatch.

This uniqueness is only among the sparse rational candidates. An arbitrary vector can share the prefix and have different later Fourier entries; the full certificate prevents a false acceptance. Delay reversal and graph-factor alternatives need not be unique.

Completeness is conditional on nonzero probes, nonzero resultant, a usable linear gcd, sparse recovery and globally invertible A. Fewer than s actual terms can increase the gcd multiplicity and cause rejection: two independent collision examples with only three Q terms declined at the s=4 gate. Thus a sparsity cap does not mean every input below the cap takes the fast branch.

For fixed s, direct probes, subgroup scans, reconstruction and certification have O_s(N) field work; resultant construction and optional factor enumeration have s-dependent constants. The displayed O_s(N) is not uniform linear work for growing s. The family has at most s+1 continuous parameters for each fixed pair of supports, and cannot cover generic N-dimensional complex inputs when N>s+1.

## Inherited executable-domain limitations

### Phase20 resonance guard remains unchanged

The legacy guard still rejects alpha^N=1 with noncoprime delay, instead of using the correct resonance condition alpha^(N/gcd(N,delta))=1. Phase21's new reciprocal discovery does not call that guard, but the archive does not fix the old entry points.

The previously established N=8, GF(97), shift-two multiplier-64 case remains pole-free for its true filter. Its residual is (1,50,64,96,22,33,50,75). The new reciprocal branch declines it for a different, documented reason: its second Fourier probe is zero. It should not be advertised as repairing the old family's fast-path completeness.

### Invertible Green matrices can still fail construction

The unchanged CyclicSolver first batch-inverts every diagonal coefficient. Matrix invertibility alone does not justify that operation. A stronger independent control uses

    N=8, p=1201, primitive generator 29, omega=1194=-7.

Here all required Nth, 2Nth and length-16 convolution roots exist. Both project Green matrices P and L have determinant 945 modulo 1201 and are invertible. But L's diagonal entry at index 1 is 7+omega=0. The source constructor therefore attempts inversion of zero. Independent dense solving verifies the mathematical Fourier/Green identity on this instance.

The executable needs either an explicit nonzero-diagonal domain restriction or a zero-safe cyclic solve, in addition to its nonsingularity condition. This is an inherited limitation, not a counterexample to the new resultant identity.

### Fallback roots and small sizes

A supplied primitive Nth root alone is not sufficient for the preserved Bluestein/NTT fallback. Its half-phase convention needs a compatible 2Nth root and its convolution needs the appropriate power-of-two transform roots. Nondyadic sparse polynomial evaluation has related convolution prerequisites. The tested fields have them for the stated test lengths, but an arbitrary prime-field theorem needs these guards or a separately supplied correct fallback.

The new compressed entry point checks N<4s before accessing probe powers, so it avoids the old hybrid's small-N indexing issue. The old hybrid file itself is unchanged. Exact all-input correctness of the composed implementation is accepted only in the domain where its engine, field roots and fallback are valid.

## Operation counts and setup

The quoted 18.4% and 40.9% reductions at N=4096 and 32768 are publisher-reported instrumented warm-state field proxies against its Bluestein/Green baseline. They were not independently rerun, and are not certified complete arithmetic totals or cold-run gains.

The reused `sparse_group_eval` constructs a new SparseInputDFT object. Its constructor really creates a fresh N-entry root table; `from_entries` records N-1 root multiplications. The caller transfers only its NTT multiplication and addition counters and ignores that root count, despite a comment claiming reuse of the existing engine powers. It also omits the helper's explicit negation counter. The new compressed route calls this helper for U_s.

At N=4096, adding only the definitely incurred fresh-root term changes the reported new-method numerator from 464,912 to 469,007. That is not a fully corrected total: other omissions and possible counter overestimates require a unified audit on both paths before asserting an exact percentage. Cold setup for the outer root and Green plans must additionally be paid rather than double-counted or assumed shared with a fresh allocation.

Further static examples include uncharged monic-gcd normalization products, determinant row-swap negations, the w-1 subtraction in compressed sample denominators, cyclic coefficient-fold additions, and portions of optional factor-output construction. Some legacy counters overestimate other formulas, so omitted operations cannot simply be appended and labeled an exact grand total. The valid conclusion here is the conditional field-arithmetic order and algebraic sample compression, not a certified benchmark ratio.

All inversions are unit-cost field primitives only in the stated model. Prime/root search, integer field arithmetic, index operations, memory traffic and numerical precision remain distinct obligations. Prony, reciprocal probes and resultant recovery may be ill-conditioned in floating point.

## Independent controls

Only `independent_checks.py` was executed. It uses independently authored polynomial arithmetic, determinant elimination and product-polynomial Lagrange interpolation rather than the source's Newton interpolation. Prony recovery uses small Hankel linear solves and subgroup enumeration rather than the uploaded Berlekamp–Massey implementation.

Passed controls:

- Ten complete degree-bound resultant reconstructions: orders 1–6 over GF(65537), plus orders 1–4 over GF(12289). Every coefficient satisfies the grade-D reciprocity identity, every predicted universal factor divides exactly, and the entire quotient matches independently compressed interpolation. Extra nodes outside the reconstruction grid agree.
- Eight zero/rank-one specializations through s=8 yield zero compressed resultants safely.
- The valuation-sum and grade formulas agree exactly for s=1 through 64.
- Fourteen newly generated structured residuals across lengths 30,32,64,128: twelve were certified and matched all direct-DFT outputs; two three-term support-collision cases declined at cap s=4. This includes an eight-term, three-factor case at s=8.
- Twelve nonzero perturbations preserve all first 4s Fourier probes exactly. Every one reaches and fails the full cyclic certificate; none is falsely accepted.
- Nine generic controls decline. The zero vector declines at the zero-probe gate.
- The inherited GF(97) Phase20 example takes the expected zero-probe rejection, and the GF(1201) Green-domain control independently verifies the invertible zero-diagonal exception.

These controls do not execute the original fallback or certify its whole API. They validate the new algebra, recovery and certificate logic independently, with the inherited runtime guards treated separately. Publisher claims of 46 tests and 65,042/33,082 audited output coordinates are not replaced by or conflated with these counts.

## Literature and acceptance boundary

Sparse rational interpolation has established prior work, including [Grigoriev, Karpinski and Singer's archived preprint](https://archive.mpim-bonn.mpg.de/id/eprint/2068/). Hankel constructions for rational interpolation and resultant evaluation also appear in [Uteshev and Baravy](https://arxiv.org/abs/1603.08752). These establish relevant prior subject matter; this bounded check neither proves nor disproves historical priority for the precise universal resultant formula.

Accepted: the exact algebraic identity, compressed sample count, full-certificate soundness and conditional O_s(N) structured-input theorem. Qualified: executable all-input correctness requires valid Green and fallback roots/domain; warm proxy counts are not complete cold counts. No general FFT improvement, floating-point stability guarantee or novelty claim is established.
