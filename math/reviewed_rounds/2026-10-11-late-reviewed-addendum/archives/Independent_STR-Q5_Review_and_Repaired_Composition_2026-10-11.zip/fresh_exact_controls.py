"""New independent exact controls. No supplied research module is imported."""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
Z=(F(0),F(0)); O=(F(1),F(0)); I=(F(0),F(1))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def sub(a,b):return add(a,neg(b))
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,q):return (a[0]*q,a[1]*q)
def total(xs):
 s=Z
 for x in xs:s=add(s,x)
 return s
def roots(M,eta):
 r=[O]
 for _ in range(M-1):r.append(mul(r[-1],eta))
 return r
def synth(a,M,r):return [total(mul(v,r[(-h*u)%M]) for h,v in a.items()) for u in range(M)]
def spectrum(y,M,r):return {h:scale(total(mul(v,r[h*u%M]) for u,v in enumerate(y)),F(1,M)) for h in range(M)}
def contains(node,h):
 a,l=node;return (h-a)%(2**l)==0
def branch_levels(S,v):
 a,l=v;return [j for j in range(l) if any(tl>j and (ta-a)%(2**j)==0 and (ta-a)%(2**(j+1))!=0 for ta,tl in S)]
def filt(M,r,S,v):
 a,l=v;A=branch_levels(S,v);G={0:O}
 for j in A:
  q=M//2**(j+1);new={}
  for t,c in G.items():
   new[t]=scale(c,F(1,2));new[(t-q)%M]=scale(mul(c,r[a*q%M]),F(1,2))
  G=new
 assert len(G)<=len(S)
 def fg(h):return total(mul(c,r[t*h%M]) for t,c in G.items())
 for node in S:
  for h in range(M):
   if contains(node,h):assert fg(h)==(O if node==v else Z)
 return G,fg

def discover(y,M,r,b):
 if b==0:return {} if all(v==Z for v in y) else None,0
 ell=M.bit_length()-1;S=[(0,0)];known={};steps=0
 while S:
  if steps>=6*b*ell:return None,steps
  v=min(S,key=lambda v:(len(branch_levels(S,v)),v));G,fg=filt(M,r,S,v);S.remove(v);steps+=1
  pred={h:mul(c,fg(h)) for h,c in known.items()}
  def residual(d):
   return sub(total(mul(c,y[(d-t)%M]) for t,c in G.items()),total(mul(c,r[-h*d%M]) for h,c in pred.items()))
  a,l=v
  if l==ell:
   c=residual(0)
   if c!=Z:known[a]=c
   if len(known)>b:return None,steps
  elif any(residual(d)!=Z for d in range(b)):
   S.extend([(a,l+1),(a+2**l,l+1)])
 return known,steps

def recognize(y,M,r,b):
 a,steps=discover(y,M,r,b)
 if a is None:return False,steps
 if len(a)>b or any(not isinstance(h,int) or not 0<=h<M or c==Z for h,c in a.items()):return False,steps
 return synth(a,M,r)==y,steps

def main():
 cases=0;maxsteps={};alphabet=[Z,O,neg(O),I]
 for M,etas in [(2,[neg(O)]),(4,[I,neg(I)])]:
  for eta in etas:
   r=roots(M,eta)
   for coeff in product(alphabet,repeat=M):
    a={h:c for h,c in enumerate(coeff) if c!=Z};y=synth(a,M,r)
    assert {h:c for h,c in spectrum(y,M,r).items() if c!=Z}==a
    for b in range(M+1):
     ok,steps=recognize(y,M,r,b);assert ok==(len(a)<=b)
     maxsteps[str((M,b))]=max(steps,maxsteps.get(str((M,b)),0));cases+=1
 # Two selected even points miss a genuine two-mode signal; first two do not.
 r=roots(4,I);y=synth({0:O,2:neg(O)},4,r)
 assert y[0]==y[2]==Z and y[1]!=Z
 # A tail perturbation must fail comparison with the unperturbed one-mode candidate.
 original=synth({1:O},4,r);changed=original[:];changed[-1]=add(changed[-1],O)
 assert original[:-1]==changed[:-1] and synth({1:O},4,r)!=changed
 out={'status':'PASS','recognition_cases':cases,'max_discovery_steps':maxsteps,'bad_noncosecutive_sampling_control':'PASS','full_verification_tail_perturbation':'PASS','arithmetic':'Exact rational real and imaginary pairs; no floating-point operations','scope':'Finite checks of fresh 1D tree-filter normalization and cap recognition; analytical proof supplies general correctness and complexity.'}
 Path(__file__).with_name('FRESH_CONTROL_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
