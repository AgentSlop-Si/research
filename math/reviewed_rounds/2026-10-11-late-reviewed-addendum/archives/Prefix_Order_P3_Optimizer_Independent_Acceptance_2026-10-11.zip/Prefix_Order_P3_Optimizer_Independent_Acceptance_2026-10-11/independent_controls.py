"""Fresh bounded review controls; imports no author/accepted mathematical code.
Only saved candidate escape permutations are input data. Every assertion is finite.
"""
import json, random, time, hashlib, zipfile
from pathlib import Path
from math import gcd, factorial
from itertools import product
from bisect import bisect_left
from collections import Counter
from functools import lru_cache
HERE=Path(__file__).resolve().parent
SRC=HERE/'source_snapshots'
R=random.Random(171311102026)
def save(name,data): (HERE/name).write_text(json.dumps(data,indent=2)+'\n')
def v(q,a,p,b=3):
    n=q**a; return a*(n//q)*(q-1)*p**b if b==0 else a*(n//q)*(q-1)*p**b+b*n*p**(b-1)*(p-1)
def qweights(q,a): return [(q**i,q**i-q**(i-1)) for i in range(1,a+1)]
def invariant(q,a,p,sets):
    n=q**a;depth=len(sets)-1;end=sets[0][-1];lookup=list(map(set,sets));out=[]
    for j in range(1,end+1):
        level=max(s for s in range(depth+1) if j in lookup[s])
        if level==depth: cap=gcd(j//p**level,n)
        else:
            cap=1
            for d,c in qweights(q,a):
                if j%(p**level*d): continue
                ok=True
                for s in range(level+1,depth+1):
                    k=bisect_left(sets[s],j);lo,hi=sets[s][k-1:k+1];step=p**s*d
                    if not ((lo+step-1)//step)*step<j<(hi//step)*step:ok=False;break
                if ok:cap+=c
        out.append((level,cap,p**level*cap-1))
    return out

def edge(q,a,p,k,l):
    n=q**a;m=l-k;g=gcd(gcd(k,l),n)
    w={d:max(0,l//d-((k+d-1)//d)) for d,c in qweights(q,a)}
    e=p*gcd(l,n)-1+sum(c*(p*w[d]-(w[d]>0)) for d,c in qweights(q,a))
    direct=p*sum(gcd(t,n) for t in range(k+1,l+1))-m-e
    X=sum(c for d,c in qweights(q,a) if k%d and l%d and (l-1)//d>k//d)
    expanded=p*(m-g+X)+1-m+sum(c for d,c in qweights(q,a) if w[d]>0)
    assert direct==expanded
    assert direct>=0 and (direct==0)==(m==g)
    assert not direct or direct>=p-1
    if not direct:
        assert not k<n<l
        if l<=n and m<n:assert not k<n//q<l
    return e,direct

def missing_top(q,a,p,C):
    n=q**a;N=n*p**3
    u=sum(x[2] for x in invariant(q,a,p,C))
    two=sum(x[2] for x in invariant(q,a,p,C[:3]))
    assert u==two+N-n*p*p
    dense=[C[0],list(range(0,N+1,p)),C[2]]
    den=sum(x[2] for x in invariant(q,a,p,dense))
    assert den>=two
    # Verify each local whole-gap difference by a separate literal eligibility count.
    old_terms=invariant(q,a,p,C[:3]);new_terms=invariant(q,a,p,dense)
    for left,right in zip(C[1],C[1][1:]):
        u0,v0=left//p,right//p
        z=bisect_left(C[2],right);a0=C[2][z-1];z0=C[2][z]
        delta=(p-1)*(v0-u0-1)
        for d,c in qweights(q,a):
            low=max(u0,p*d*((a0+p*p*d-1)//(p*p*d)))
            high=min(v0,p*d*(z0//(p*p*d)))
            nr=sum(1 for t in range(low+1,high) if t%d==0)
            nn=0 if low>=high else max(0,p*(high//d-((low+d-1)//d))-1)
            delta+=c*(p*nr-nn)
        actual=sum(x[2] for x in new_terms[left:right-1])-sum(x[2] for x in old_terms[left:right-1])
        assert delta==actual and delta>=0,(left,right,delta,actual)
    quotient=[list(range(N//p+1)),[x//p for x in C[2]]]
    one=sum(x[2] for x in invariant(q,a,p,quotient))
    assert den==p*one+(p-1)*N//p
    path=[x//(p*p) for x in C[2]]
    es=[edge(q,a,p,x,y) for x,y in zip(path,path[1:])]
    assert one==sum(x[0] for x in es)
    W=p*one+2*(p-1)*n*p*p;loss=p*sum(x[1] for x in es)
    assert v(q,a,p)-W==loss and u<=W<=v(q,a,p)
    if n not in path:assert loss>=p*(p-1)
    if loss==0:assert n in path
    return dict(U=u,W=W,loss=loss,forced_rank_present=n in path)

def arithmetic():
    parameters=[(2,0,3),(2,1,3),(2,2,3),(2,3,3),(3,1,2),(3,2,2),(3,3,2),(5,1,2),(5,2,2),(2,2,5),(7,1,3)]
    rows=[]
    for q,a,p in parameters:
        n=q**a;N=n*p**3;counts=Counter()
        for rep in range(37):
            c2=[0]+[j for j in range(p*p,N,p*p) if R.randrange(5)<2]+[N]
            mode=rep%4
            if mode==0:c2=[0,N]
            elif mode==1:c2=sorted(set(c2+[n*p*p]))
            elif mode==2:c2=[j for j in c2 if j!=n*p*p]
            c1=sorted(set(c2)|{j for j in range(0,N+1,p) if R.randrange(7)<3})
            if rep==36:c2=list(range(0,N+1,p*p));c1=list(range(0,N+1,p))
            rr=missing_top(q,a,p,[list(range(N+1)),c1,c2,[0,N]])
            counts['zero_loss']+=rr['loss']==0;counts['missing_forced_rank']+=not rr['forced_rank_present']
        rows.append(dict(q=q,a=a,p=p,hierarchies=37,results=dict(counts)))
    # Independent all-edge and boundary countersearch, extending beyond n*p.
    total=zero=extended=0;edgepars=[]
    for q,a,p in [(2,a,p) for a in range(5) for p in (3,5)]+[(3,a,p) for a in range(4) for p in (2,5)]+[(5,a,2) for a in range(4)]+[(7,a,3) for a in range(3)]:
        n=q**a;end=n*p
        for k in range(end):
            for l in range(k+1,end+1):
                e,loss=edge(q,a,p,k,l);total+=1;zero+=loss==0;extended+=l>n
        for rep in range(40):
            k=R.randrange(end,4*end+1);l=k+R.randrange(1,end+1)
            edge(q,a,p,k,l);total+=1;extended+=1
        edgepars.append([q,a,p])
    # General C3 hierarchies test the accepted branch-I collapse with retained top unchanged.
    arbitrary=0
    for q,a,p in parameters:
        n=q**a;N=n*p**3
        for rep in range(30):
            C=[list(range(N+1))]
            for s in (1,2,3): C.append([0]+[j for j in C[-1][1:-1] if j%p**s==0 and R.random()<.5]+[N])
            raw=sum(x[2] for x in invariant(q,a,p,C));path=[j//p**3 for j in C[3]]
            collapsed=sum(p*p*edge(q,a,p,k,l)[0]+2*p*p*(p-1)*(l-k) for k,l in zip(path,path[1:]))
            assert raw<=collapsed<=v(q,a,p)
            if len(path)>2 and n//q not in path and a: assert collapsed<=v(q,a,p)-p*p*(p-1)
            arbitrary+=1
    result=dict(seed=171311102026,missing_top_hierarchies=407,parameter_rows=rows,additional_arbitrary_top_hierarchies=arbitrary,all_edges=total,zero_edges=zero,edges_beyond_n=extended,edge_parameter_list=edgepars,failures=0)
    save('ARITHMETIC_CONTROLS.json',result);print('ARITHMETIC',total,flush=True);return result

class FiniteGroup:
    def __init__(self,label,labels,op):
        self.name=label;self.labels=list(labels);self.N=len(self.labels);idx={x:i for i,x in enumerate(self.labels)}
        self.T=tuple(tuple(idx[op(x,y)] for y in self.labels) for x in self.labels)
        self.inv=tuple(next(y for y in range(self.N) if self.T[x][y]==0) for x in range(self.N))
        assert all(self.T[0][x]==x==self.T[x][0] for x in range(self.N))
    @lru_cache(None)
    def generate(self,seeds):
        members={0};frontier=[0]
        for x in frontier:
            for y in seeds:
                z=self.T[y][x]
                if z not in members: members.add(z);frontier.append(z)
        return frozenset(members)
    @lru_cache(None)
    def subgroups(self):
        allsub={frozenset({0})};todo=list(allsub)
        for S in todo:
            for x in range(self.N):
                if x not in S:
                    Q=self.generate(tuple(sorted(S|{x})))
                    if Q not in allsub:allsub.add(Q);todo.append(Q)
        return sorted(allsub,key=lambda S:(len(S),tuple(sorted(S))))
    @lru_cache(None)
    def maximals(self,S):
        proper=[Q for Q in self.subgroups() if Q<S]
        return [Q for Q in proper if not any(Q<U for U in proper)]
    def recursive(self,S=None,J=None):
        if S is None:S=frozenset(range(self.N))
        if len(S)==1:return list(S)
        if J is None:J=R.choice(self.maximals(S))
        remaining=set(S);reps=[]
        while remaining:
            x=min(remaining);remaining-={self.T[y][x] for y in J};reps.append(x)
        R.shuffle(reps)
        return [self.T[y][x] for x in reps for y in self.recursive(J)]
    def prefix_stabilizers(self,order):
        # Incremental action images, compared as full bitsets at every insertion.
        assert sorted(order)==list(range(self.N));actual=0;images=[0]*self.N;result=[]
        for x in order:
            actual|=1<<x
            for g in range(self.N):images[g]|=1<<self.T[g][x]
            result.append(frozenset(g for g in range(self.N) if images[g]==actual))
        return result
    def normal(self,S):return all(self.T[self.T[g][x]][self.inv[g]] in S for g in range(self.N) for x in S)
    def recursive_shape(self,order,S=None):
        if S is None:S=frozenset(range(self.N))
        if len(S)==1:return True
        for J in self.maximals(S):
            m=len(J);valid=True
            for start in range(0,len(order),m):
                block=order[start:start+m];x=block[0]
                if set(block)!={self.T[y][x] for y in J}:valid=False;break
                normalized=[self.T[y][self.inv[x]] for y in block]
                if not self.recursive_shape(normalized,J):valid=False;break
            if valid:return True
        return False
    @lru_cache(None)
    def recursive_count(self,S):
        if len(S)==1:return 1
        return sum(factorial(len(S)//len(J))*self.recursive_count(J)**(len(S)//len(J)) for J in self.maximals(S))

def abelian(*moduli):
    return FiniteGroup('x'.join('C'+str(m) for m in moduli),product(*(range(m) for m in moduli)),lambda x,y:tuple((a+b)%m for a,b,m in zip(x,y,moduli)))
def d8():return FiniteGroup('D8',product(range(4),range(2)),lambda x,y:((x[0]+(1 if x[1]==0 else -1)*y[0])%4,(x[1]+y[1])%2))
def q8():return FiniteGroup('Q8',product(range(4),range(2)),lambda x,y:((x[0]+(1 if x[1]==0 else -1)*y[0]+2*x[1]*y[1])%4,(x[1]+y[1])%2))
def heis(p=3):return FiniteGroup('Heis'+str(p**3),product(range(p),repeat=3),lambda x,y:((x[0]+y[0])%p,(x[1]+y[1])%p,(x[2]+y[2]+x[0]*y[1])%p))
def modular(p=3):return FiniteGroup('Mod'+str(p**3),product(range(p*p),range(p)),lambda x,y:((x[0]+((1+p)**x[1])*y[0])%(p*p),(x[1]+y[1])%p))
def direct(H,P):
    G=FiniteGroup(H.name+'x'+P.name,product(range(H.N),range(P.N)),lambda x,y:(H.T[x[0]][y[0]],P.T[x[1]][y[1]]))
    lattice=[frozenset(h*P.N+z for h in A for z in B) for A in H.subgroups() for B in P.subgroups()]
    G.subgroups=lambda:lattice
    return G

def inspect(H,P,q,a,p,order,kind,G=None):
    if G is None:G=direct(H,P)
    stabs=G.prefix_stabilizers(order);betas=[];ranks=[]
    for j,S in enumerate(stabs,1):
        L={x//P.N for x in S};Q={x%P.N for x in S}
        assert len(S)==len(L)*len(Q) and j%len(S)==0
        r=next(r for r in range(4) if p**r==len(Q));betas.append(len(L));ranks.append(r)
    C=[list(range(G.N+1))]+[[0]+[j for j,r in enumerate(ranks,1) if r>=s] for s in (1,2,3)]
    cap=invariant(q,a,p,C);Z=sum(len(S)-1 for S in stabs);U=sum(x[2] for x in cap);V=v(q,a,p)
    assert all(beta<=h for beta,(r,h,c) in zip(betas,cap));assert Z<=U<=V
    B=G.generate(tuple(sorted(set().union(*stabs[:-1]))));branch='proper_full_P' if len(C[3])>2 else 'no_proper_full_P'
    if kind=='recursive':assert Z==V
    if Z==V:assert B in G.maximals(frozenset(range(G.N))) and G.recursive_shape(order)
    if a and len(B)==G.N:assert V-Z>=p*(p-1)
    Dtop=sum(p**3*(gcd(j//p**3,H.N)-betas[j-1]) for j in C[3][1:]);assert Z<=U-Dtop
    rr=dict(kind=kind,Z=Z,U=U,V=V,B_size=len(B),D_top=Dtop,branch=branch)
    if len(C[3])==2:
        z=missing_top(q,a,p,C);Dmid=sum(p*p*(gcd(j//(p*p),H.N)-betas[j-1]) for j in C[2][1:-1])
        assert Z<=U-Dmid<=z['W']-Dmid<=V-Dmid
        target=H.N*p*p;present=target in C[2]
        if present and betas[target-1]==H.N:
            Q=frozenset(x%P.N for x in stabs[target-1]);assert len(Q)==p*p and P.normal(Q)
            assert all(x%P.N in Q for x in B)
        rr.update(rank_np2_present=present,D_mid=Dmid,collapsed_W=z['W'],scaled_edge_loss=z['loss'])
    elif a and len(B)==G.N:assert Z<=V-p*p*(p-1)
    # Direct prime-index trapping check for every saturated maximal-sized checkpoint.
    for j,S in enumerate(stabs[:-1],1):
        if len(S)==j and S in G.maximals(frozenset(range(G.N))):assert B<=S
    return rr,C,betas,stabs

def tables(P,p):
    assert all(sorted(row)==list(range(P.N)) for row in P.T)
    assert all(P.T[P.T[x][y]][z]==P.T[x][P.T[y][z]] for x in range(P.N) for y in range(P.N) for z in range(P.N))
    maxs=P.maximals(frozenset(range(P.N)));types=Counter()
    for J in maxs:
        assert len(J)==p*p and P.normal(J)
        types['cyclic' if any(len(P.generate((x,)))==p*p for x in J) else 'elementary_abelian']+=1
    return dict(name=P.name,order=P.N,subgroups=len(P.subgroups()),maximals=len(maxs),types=dict(types),nonnormal_order_p=sum(len(S)==p and not P.normal(S) for S in P.subgroups()))

def groups():
    specs=[(abelian(3),P,3,1,2) for P in (abelian(2,2,2),abelian(4,2),abelian(8),d8(),q8())]
    specs += [(abelian(2),P,2,1,3) for P in (abelian(3,3,3),abelian(9,3),abelian(27),heis(),modular())]
    specs += [(d8(),P,2,3,3) for P in (abelian(3,3,3),heis(),modular())]
    specs += [(heis(),P,3,3,2) for P in (d8(),q8())]+[(abelian(1),abelian(3,3,3),2,0,3)]
    rows=[];tab=[];seen=set()
    for H,P,q,a,p in specs:
        if P.name not in seen:tab.append(tables(P,p));seen.add(P.name)
        G=direct(H,P);orders=[]
        for J in G.maximals(frozenset(range(G.N))):orders.append((G.recursive(J=J),'recursive'))
        for k in range(8):
            order=list(range(G.N));R.shuffle(order);orders.append((order,'random'))
            order=G.recursive();x,y=R.sample(range(G.N),2);order[x],order[y]=order[y],order[x];orders.append((order,'swapped_recursive'))
        rs=[]
        for order,kind in orders:
            rr,_,_,_=inspect(H,P,q,a,p,order,kind,G);rr['permutation']=order;rs.append(rr)
        rows.append(dict(group=G.name,N=G.N,q=q,a=a,p=p,orders=rs,recursive_count=str(G.recursive_count(frozenset(range(G.N))))))
        print('GROUP',G.name,len(rs),flush=True)
    save('GROUP_CONTROLS.json',rows);save('GROUP_TABLE_CONTROLS.json',tab)
    # Export independently built multiplication tables and independently recursive counts for exhaustive DP.
    inputs=[]
    for P in (abelian(2,2,2),abelian(4,2),abelian(8),d8(),q8()):
        for G in (P,direct(abelian(3),P)):
            inputs.append(dict(name=G.name,N=G.N,mul=G.T,expected_count=str(G.recursive_count(frozenset(range(G.N))))))
    save('EXHAUSTIVE_INPUT.json',inputs)
    return rows,tab

def escapes():
    sources=json.loads((SRC/'FROZEN_ESCAPE_CONTROLS.json').read_text());out=[]
    for record in sources:
        P={'D8xC3xC3xC3':abelian(3,3,3),'D8xHeis27':heis(),'D8xMod27':modular()}[record['group']]
        H=d8();G=direct(H,P);order=record['order']
        rr,C,beta,S=inspect(H,P,2,3,3,order,record['kind'],G)
        for key in ('Z','V','U','B_size','D_top','branch','rank_np2_present','D_mid','collapsed_W','scaled_edge_loss'):
            if key in record:assert rr[key]==record[key],(key,rr,record)
        assert C==record['checkpoint_sets'] and beta==record['betas'] and rr['B_size']==216
        if 'witness_stabilizers' in record:
            for j,stab in record['witness_stabilizers'].items():assert sorted(S[int(j)-1])==stab
        rr['group']=G.name;rr['order_sha256']=hashlib.sha256(json.dumps(order,separators=(',',':')).encode()).hexdigest();out.append(rr)
    save('ESCAPE_REPLAY.json',out);print('ESCAPES',len(out),flush=True);return out

if __name__=='__main__':
    started=time.monotonic();a=arithmetic();g,t=groups();e=escapes()
    summary=dict(seed=171311102026,missing_top_hierarchies=a['missing_top_hierarchies'],additional_top_hierarchies=a['additional_arbitrary_top_hierarchies'],edges=a['all_edges'],direct_families=len(g),fresh_order_evaluations=sum(len(row['orders']) for row in g),fresh_recursive_orders=sum(x['kind']=='recursive' for row in g for x in row['orders']),source_escape_orders_recomputed=len(e),source_mathematical_code_executed_or_imported=False,failures=0,seconds=time.monotonic()-started)
    save('CONTROL_SUMMARY.json',summary);print(json.dumps(summary,indent=2),flush=True)
