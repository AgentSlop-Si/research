"""Verify immutable source archives and read-only source snapshot bindings."""
import json,hashlib,zipfile,pathlib
HERE=pathlib.Path(__file__).resolve().parent;base=HERE.parent;workspace=base.parent;rows=[]
for name,lid,expected in [('Prefix_Order_P3_Optimizer_Structure_Candidate_2026-10-11.zip','libfile_147dc50eec688191b67c360d3208e933','bf14e2fe3b96bf01e54a1e9c0c78e8a527da7d8163f45232a1d17c408f731da4'),('Prefix_Noncyclic_Two_Sylow_and_Rank_Two_Independent_Acceptance_2026-10-11.zip','libfile_6b306a62e6348191a2f106e3b19a8e44','be001a5b8ea0d2e0f546cdb7967f5155e0a2362935d29456a16150f1ac90f76f')]:
 p=base/'library_sources'/name;raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
 with zipfile.ZipFile(p) as z:
  names=z.namelist();m=next(n for n in names if n.endswith('/MANIFEST.json') or n=='MANIFEST.json');root=m[:-len('MANIFEST.json')];manifest=json.loads(z.read(m));files=manifest.get('files',manifest.get('payload'));checked=[]
  for x in files:
   s=z.read(root+x['path']);assert len(s)==x['bytes'] and hashlib.sha256(s).hexdigest()==x['sha256'];checked.append(x['path'])
  # Match the new and prior proof bytes directly from their independently materialized archives.
  targets={'CANDIDATE_PROOF.md':'FROZEN_CANDIDATE_PROOF.md','ESCAPE_CONTROLS.json':'FROZEN_ESCAPE_CONTROLS.json'} if 'Candidate' in name else {'ACCEPTED_STATEMENT.md':'ACCEPTED_BASELINE_STATEMENT.md','REVIEW.md':'ACCEPTED_BASELINE_REVIEW.md','source_snapshots/ACCEPTED_ALL_B_PROOF.md':'ACCEPTED_NUMERICAL_DEPENDENCY.md'}
  for src,dest in targets.items():assert z.read(root+src)==(HERE/'source_snapshots'/dest).read_bytes()
 rows.append({'name':name,'library_file_id':lid,'version':0,'bytes':len(raw),'sha256':expected,'payload_members_checked':len(checked),'payload_paths':checked})
snap=HERE/'source_snapshots';bind=[]
for target,source in [('FROZEN_CANDIDATE_PROOF.md','prefix_order_p3_1703/packet/CANDIDATE_PROOF.md'),('FROZEN_ESCAPE_CONTROLS.json','prefix_order_p3_1703/packet/ESCAPE_CONTROLS.json'),('ACCEPTED_BASELINE_STATEMENT.md','prefix_noncyclic_review_1626/review/ACCEPTED_STATEMENT.md'),('ACCEPTED_BASELINE_REVIEW.md','prefix_noncyclic_review_1626/review/REVIEW.md'),('ACCEPTED_NUMERICAL_DEPENDENCY.md','prefix_noncyclic_review_1626/review/source_snapshots/ACCEPTED_ALL_B_PROOF.md')]:
 data=(snap/target).read_bytes();assert data==(workspace/source).read_bytes();bind.append({'snapshot':target,'source':source,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'unchanged':True})
(HERE/'SOURCE_VERIFICATION.json').write_text(json.dumps({'archives':rows,'snapshots':bind,'source_mathematical_scripts_executed_or_imported':False},indent=2)+'\n')
print(json.dumps([{'name':r['name'],'payload_members_checked':r['payload_members_checked'],'sha256':r['sha256']} for r in rows],indent=2))
