# Independent adversarial review of the noncyclic prefix extension

11 October 2026 UTC. **Theorem A: ACCEPT. Theorem B: ACCEPT. Direction-switch diagnostic: ACCEPT.** No mathematical correction to the frozen candidate is required.

The accepted scopes are separated in ACCEPTED_STATEMENT.md. In particular, the unrestricted numerical value theorem for two arbitrary Sylow factors must not be reported as an unrestricted optimizer theorem. The complete structural result here is for H×C_p², where H is any finite q-group and p≠q.

## 1. Exact sources and independence

The reviewer independently materialized all three Library archives and checked their bytes:

- New candidate: libfile_b790b12b821c8191b50ec98836c8c6c0 v0, 27,963 bytes, SHA-256 b1b5b8c2fd41d2a7f2334eba82984abe596bc7f10b8c8cfff1335f3ff00994c4.
- Accepted all-b source: libfile_1dae9a88f5108191a048f86017d447d6 v0, 42,673 bytes, SHA-256 f41867be27ab0f77376b6745adff35575aa3af5044ce4f29d201f60179858d3e.
- Independent all-b acceptance: libfile_672d090b20a4819198c511cd125dd489 v0, 80,379 bytes, SHA-256 efddb76d4d402aebedf75e1c095ed7c22776ab90142966c0a3a64049cb94f62d.

All 9, 14, and 26 declared payload members respectively match their manifest lengths and hashes. The new CANDIDATE_PROOF.md is 18,250 bytes with SHA-256 148ddbc0f0d95ad5d0bde66acd901b4cf2fd69c79283e9c243e7ede0e13d22e0. It is identical to the supplied local candidate. Its accepted numerical dependency equals both the prior author THEOREM.md and the independent acceptance's FROZEN_AUTHOR_THEOREM.md, hash e13674de3c970bc3a18417d9f6e01630b388a0632571637e97674c526f56afd9. Its baseline statement equals the actual accepted statement.

The complete new proof, accepted all-b proof and independent audit, accepted one-level proof and audit, and relevant prime-power source were read. Mathematical source snapshots are retained unchanged. Original and inherited mathematical programs were neither executed nor imported. Fresh reviewer programs provide all newly reported calculations. The Library transfer helper is service infrastructure, not mathematical source code.

These bindings establish the precise proof reviewed, not its correctness by themselves.

## 2. Splitting and threshold hierarchies

For any subgroup S≤H×P and (h,z)∈S, coprime-order powers isolate (h,1) and (1,z). Thus S=L×Q, even if H and P are both nonabelian. Applied to each prefix stabilizer, write |L_j|=β_j and |Q_j|=p^r(j).

Defining C_s by the threshold |Q_j|≥p^s gives nested checkpoint sets with C_s⊆p^s Z: the entire stabilizer acts freely on the prefix, so its order divides j. Empty and full endpoints belong to every level. At any checkpoint of level s its P-projection contains a subgroup of order p^s, using the standard subgroup chain in a finite p-group.

No common chain of P-subgroups is claimed. In particular, two different C_1 checkpoints may be invariant under different lines. The numerical definition needs nested sets of indices, not nested actual stabilizers or a fixed subgroup for each threshold.

## 3. The new closure/core lemma is valid

Fix j of actual level r<s, let a<j<z be the surrounding C_s checkpoints, and put L=L_j. Pick any order-p^s subgroup A preserving T_a and any order-p^s subgroup D preserving T_z. They may be incomparable.

Define the lower H-closure F=⋃_(ℓ∈L)ℓT_a and upper H-core E=⋂_(ℓ∈L)ℓT_z. Since T_j is L-invariant and T_a⊆T_j⊆T_z,

    T_a⊆F⊆T_j⊆E⊆T_z.

Left multiplication by any L element permutes the union or intersection factors; this does not require L abelian. The H and P direct factors commute, so A preserves every ℓT_a and D preserves every ℓT_z. Consequently F is invariant under L×A and E under L×D. Their cardinalities are divisible by β_j p^s, by freeness of left translation.

For every d=q^i dividing β_j, this gives

    p^s d ceil(a/(p^s d)) ≤ |F| ≤ j ≤ |E|
                            ≤ p^s d floor(z/(p^s d)).

If j equals the outer left bound, the inequalities force F=T_j. This makes T_j A-invariant and gives |Q_j|≥p^s, contrary to r<s. Equality at the right similarly forces E=T_j and D-invariance. Both clips therefore are strict. Divisibility d|j/p^r follows from β_j p^r|j.

Crucially, the argument never asks A and D to be equal, comparable, normal in P, or related to Q_j. It never asserts persistence of stabilizers. This is precisely the missing group-theoretic bridge from cyclic checkpoints to arbitrary p-group thresholds.

An independent concrete control uses H=C2² and P=C3². At j=8 the H-stabilizer has order 2; the surrounding C_1 endpoints are 6 and 21, with distinct proper P-projections ⟨(1,0)⟩ and ⟨(0,1)⟩. The calculated closure and core have sizes 6 and 18, giving the strict clip 6<8<18. Thus the new lemma has a direct control with genuinely incomparable, non-full endpoint projections.

## 4. The accepted numerical dependency is genuinely group-free

The source does not merely prove a cyclic-group inequality and leave realizability implicit. Its Section 2 explicitly defines U_b on every nested hierarchy C_b⊆...⊆C_0, with C_s⊆p^s Z and the two endpoints at each level, whether or not any group order realizes it.

The relevant induction was rechecked. In a lowest-level gap pu<pv, all higher enclosing endpoints are fixed. For each q-power d, intersect their clipping intervals with [u,v], obtaining L_d,U_d. The old eligible count is N_d=max(0,p[floor(U_d/d)−ceil(L_d/d)]−1), with zero for an empty intersection. Whole-gap densification yields R_d strict interior d-multiple ranks. The exact change is

    Δ=(p−1)(v−u−1)+Σ_d c_d(pR_d−N_d),  c_d=d−d/q.

The only negative terms are −(p−1)c_d, when both endpoints are divisible by d; these require d≤v−u. Their weights sum to at most d_*−1≤v−u−1, so Δ≥0. This includes gaps longer than n. The positive-level caps are unchanged because they use only higher levels.

After filling every multiple of p, the exact rescaling identity is

    U_b(C_dense)=p U_(b−1)(C′)+(p−1)np^(b−1).

All eligibility tests rescale, while the H base stays n=q^a. The induction makes no group quotient or realization claim. The unchanged top endpoints and their actual deficits survive the upper-bound replacements. The outer edge then telescopes to V(a,b). This proves the numerical assertion for arbitrary hierarchies; the new closure/core lemma supplies its hypotheses for arbitrary P.

In particular, the dependent proof's later cyclic implication “B=G forces a proper top checkpoint” is used only for that source's escape theorem. It is not used anywhere in the numerical upper bound imported by Theorem A.

## 5. Theorem A: upper bound and attainment

The positive q-adic weights satisfy β−1=Σ_(d|β)c_d. Every such d satisfies all the new strict clips, so β_j≤h_C(j) pointwise. A full-P checkpoint has the form A×P, and its H-stabilizer acts freely on A, giving β_j≤gcd(j/p^b,n).

Therefore the candidate's exact functional is the already accepted U_b, and

    Z≤U_b−D_top≤U_b≤V(a,b),
    D_top=Σ_(positive j∈C_b)p^b[gcd(j/p^b,n)−β_j].

The entire top contribution deficit has coefficient p^b. No part of it is lost during numerical elimination.

For attainment choose a maximal subgroup R<P, normal of index p, and J=H×R. Consecutive right J-cosets with optimal local orders have all proper stabilizers inside J: an outside element cycles all quotient cosets, and cannot preserve either a unique partially occupied coset or a nonempty proper set of completed cosets. Inside J the global stabilizer equals the active local stabilizer. The final contribution replaces |J|−1 by |G|−1. Induction on a+b therefore gives

    p V(a,b−1)+|G|−|J|=V(a,b).

The b=0 base is the accepted arbitrary finite q-group theorem. The a=0 base is the corresponding arbitrary finite p-group theorem. Both are independently justified by the stabilizer divisor cap, its gcd sum, and normal prime-index recursion. The singleton gives value 0 and one order. Thus no cyclic assumption remains in Theorem A's upper or lower bound.

This establishes a value and a construction, not necessity of that construction for arbitrary P.

## 6. Prime-index trapping and Branch I

If one proper prefix is one right coset of a normal prime-index subgroup J, every proper stabilizer lies in J. Before that checkpoint a nonempty prefix lies in one J-coset and any outside element moves it to a disjoint coset. After the checkpoint it contains a full J-coset, and invariance under an outside element would force every coset, hence all G. This proof works for any prime index and nonabelian G.

For P=C_p², suppose a proper full-P checkpoint exists. Numerical elimination gives top-rank edges on 0≤k≤n, with each nonzero loss at least p(p−1), and zero edges exactly aligned intervals of q-power length.

A nontrivial zero path must hit n/q. A zero edge of length n can only be the whole 0→n path; every smaller q-power length divides n/q and cannot cross it strictly inside an aligned interval. Thus absence of n/q gives the stated positive loss.

If that rank is present and β_(p²n/q)=n/q, the prefix is one coset of K×P, with K normal of index q in H. Trapping contradicts B=G. Otherwise the retained full endpoint deficit is at least p². When n/q=1 the deficient case is impossible, since β≥1. Every permitted case gives at least p(p−1), stronger than the claimed p−1. No existence of a proper full-P checkpoint is inferred from B=G in this argument; this branch assumes it explicitly.

## 7. Branch II: the extended-rank argument is exact

Now C_2={0,N}, where N=np². At any proper C_1 point j=pk, its level is 1 and its only higher-level clip is 0<j<N, for every d|n. Hence h_C(pk)=gcd(k,n). At a level-zero point, the top clip is redundant beside its strict C_1 clips. The complete invariant therefore equals the one-level edge sum along ranks 0=k_0<...<k_t=np, with one final correction:

    U_2=Σ_i E_p(k_i,k_(i+1))+(N−np).

The final edge would assign pn−1; the actual final prefix contributes np²−1, giving exactly N−np. The base in gcd and the q-power weights is still n, not np.

For any integers 0≤k<l, set m=l−k, g=gcd(k,l,n), w_d=max(0,floor(l/d)−ceil(k/d)), and let X consist of d for which both endpoints are indivisible but an interior d-multiple exists. Expanding the gcd sum over strict interior integers gives

    F_p(l)−F_p(k)−E_p(k,l)=pA+B,
    A=m−g+Σ_(d∈X)c_d,
    B=1−m+Σ_(w_d>0)c_d.

Indeed, the difference between the interior-multiple count and w_d is −1 for two divisible endpoints, +1 for two indivisible endpoints with an interior multiple, and zero otherwise. Negative weights telescope to g−1. None of this uses l≤n.

Since g|m, if m>g then m≥2g and the loss is at least

    p(m−g)+1−m=(p−1)(m−2g)+(p−2)g+1≥p−1.

If m=g, the interval has q-power length dividing n and aligned endpoints. Smaller d divide both endpoints, while larger d have no interior multiple. Then A=B=0. Thus the exact zero criterion and positive gap hold on the extended interval, including p=2<q and n=1.

Periodicity gives s(np)=p s(n), so

    F_p(np)+(N−np)=V(a,2).

A zero edge has aligned length d|n, and cannot cross rank n in its interior. Every zero path from 0 to np must therefore visit n, a proper rank.

If rank n is missing, one edge loses at least p−1. If it is present, its actual P-projection is a line. Saturation β_(pn)=n makes the prefix a coset of H×L, normal of prime index p. Trapping again contradicts B=G. A deficient endpoint instead loses the entire p(n−β_(pn))≥p from its cap. This loss is directly subtractable from U_2 because it is a pointwise endpoint surplus. No direction-switch cost or subgroup nesting is needed.

These two branches exhaust the actual C_2 set and prove Theorem B's sufficient escape deficit p−1.

## 8. Equality classification, unique top, and count

Induct on a, with the finite p-group theorem at a=0 and the accepted H×C_p theorem for the line direction. Theorem A supplies value and attainment, and strict escape forces every optimizer to have B<G.

A maximal J containing B must be H×L for one of the p+1 lines L≤C_p², or M×C_p² with M maximal in H. All are normal of prime index, respectively p and q. The first local theorem is accepted one-level theory; the second decreases a. These are all possible maximal subgroups by coprime splitting, so the induction is closed.

At each proper insertion, its global stabilizer S_j is contained in the active local-prefix stabilizer L_j within J. Every local prefix appears once, and the final local/global terms differ by |G|−|J|. Thus the exact identity is

    Z_G=Σ_C Z_J(x restricted to C)+|G|−|J|
         −Σ_(j<N)(|L_j|−|S_j|).

Each deficit is nonnegative. The sum of local maximum values plus |G|−|J| equals V(a,2) in both maximal-subgroup directions. Equality forces each local order optimal and every deficit zero.

At the first completed coset, the local stabilizer is J, hence the global stabilizer is J. Its prefix is a union of full J-cosets. Since no other coset has completed, all others are empty. This forces the first whole block. At each subsequent completion the same reasoning forbids interleaving with unfinished cosets. The final remaining block is automatic. Recursing locally proves necessity of the stated recursive orders.

Conversely the block accounting proves their optimality. Every proper stabilizer lies in the chosen top J and the first full block has stabilizer exactly J. Hence B=J and the top is uniquely recovered. Right translation identifies each labeled coset's orders with J without changing left stabilizers. For fixed J of index t, the count is t!A(J)^t, with no additional representative factor. Distinct tops are disjoint, giving exactly the candidate recurrence.

## 9. Direction-switch certificate

The review reconstructed the order from its set definitions before reading the supplied order list. With D8 elements r^i s^j and P=F3², the initial six-element set is {1,s}×⟨(1,0)⟩, while the final six-element set is {r²,r³s}×⟨(0,1)⟩. Direct translations give S_6=⟨s⟩×⟨(1,0)⟩ and S_66=⟨rs⟩×⟨(0,1)⟩. Their generated group has order 72: s and rs generate D8, and the two lines span P.

The reconstructed order equals the frozen certificate. Every one of its 72 actual stabilizers agrees with the recorded list. Independently calculated values are Z=113, V=204, U_2=194, D_top=0, and C_2={0,72}. Every proper prefix has at least one partially occupied P-fibre, checked directly and also explained by the retained partial r² row and final r³s row.

This is a valid counterexample to the transferred cyclic implication, and only that implication. Its score is well below the optimum. It is neither a counterexample to the new theorem nor a sharp escape witness.

## 10. Independent bounded controls

All fresh mathematical code is included, and source scripts remained inert.

- Arithmetic: 458,640 edges, including 6,258 zero edges and 423,816 whose endpoints go beyond the original rank n. These check direct potential differences, the expanded identity, exact zero criterion, gap p−1, and the rank-n barrier. Parameter lists and seed are explicit. In addition, 245 arbitrary nested hierarchies, 210 exact densification/quotient identities, and 360 exact no-proper-top extended-rank cap identities pass.
- Direct groups: 524 order evaluations across 13 factor specifications, including 132 recursive orders, check every prefix by actual left translations. H includes D8, Q8, C2³, C9, and the nonabelian Heisenberg group of order 27. Arbitrary-P value tests include D8, Q8, C4×C2 and Heisenberg27 as the P factor, alongside rank-two cases and prime-power/singleton axes. These include 6,699 strict clip tests and 5,442 direct closure/core calculations. They test 4,895 choices of incomparable endpoint subgroups; that last tally includes empty/full endpoints.
- Thirty further direct orders test D8×Heisenberg27 with both Sylow factors nonabelian, in each factor orientation. All fourteen recursive orders attain 756; the same arbitrary-hierarchy upper cap holds for random and perturbed orders. These are numerical Theorem A controls, not an unrestricted optimizer classification.
- A further C2²×C3² order verifies incomparable proper endpoint lines with β=2, as described in Section 3.
- Four explicit D8×C3² escape orders cover both alternatives in each proof branch. Their (Z,U,D_top) triples are (85,144,0) for Branch II missing n; (113,194,0) for Branch II present deficient n; (111,144,0) for Branch I missing n/q; and (162,204,18) for Branch I present deficient n/q. Each has B=G. These are controls, not sharpness claims.
- Exhaustive subset DP, independent of an optimizer-form assumption, checks C2², C3², C3×C2², and C2×C3². It carries the subgroup generated by proper-prefix stabilizers, omits the full stabilizer from that subgroup, and partitions extensions by the next labeled element. There are 266,768 subsets in total. Exact maximum/count pairs are respectively 4/24, 12/5,184, 20/169,344, and 33/95,219,712. Every maximizing terminal B is a maximal subgroup, and its exact count agrees with the separate recursive lattice count. No full-B order exists in these four finite tests; null in their escape maximum field denotes an unreachable state, not a numerical upper bound.
- Eleven factor multiplication tables were checked for identity, row permutations, every associativity triple, and subgroup closure.

The 524 base evaluations include the direction-switch example. The four additional escape evaluations re-evaluate that example once, and the incomparable-endpoint evaluation is separate. Counts describe performed evaluations, not distinct permutations. No exhaustive enumeration of subsets or orders for D8×C3² is claimed. The author's 325 orders and 158,142 edges are historical candidate controls and are not counted as fresh review work.

## 11. Scope of acceptance

The universal quantifiers come from Sections 2–8, with the exact accepted numerical dependency. The finite tests corroborate them. This is independent project mathematical review, not formal verification or external peer review.

Theorem A settles the numerical maximum for two arbitrary finite Sylow factors. Theorem B settles the full recursive structure, unique top, labeled count and sufficient escape gap for the elementary-abelian rank-two second factor. The broader arbitrary-P structural problem and any general three-prime or all-nilpotent extension remain open here. Nothing in this review establishes worldwide priority, sharp escaping values, or closes the existing EFK comparison gap. No Sheet or GitHub mutations were made.
