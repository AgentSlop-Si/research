// Fresh subset dynamic program. No optimizer structure assumed by this solver.
#include <algorithm>
#include <bit>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
using U128=unsigned __int128;
string dec(U128 x){if(x==0)return "0";string s;while(x){s.push_back('0'+x%10);x/=10;}reverse(s.begin(),s.end());return s;}
int main(){int cases;cin>>cases;cout<<"[\n";for(int ca=0;ca<cases;ca++){
 string name,expected;int n;cin>>name>>n>>expected;vector<vector<int>>t(n,vector<int>(n));for(auto &r:t)for(int &x:r)cin>>x;
 uint32_t limit=1u<<n;vector<uint8_t>stabilizer(limit,1),best(limit,0);vector<U128>ways(limit,0);ways[0]=1;
 // A subset is g-invariant exactly when it is a union of cycles of left g translation.
 for(int g=1;g<n;g++){
  uint32_t seen=0;vector<uint32_t>cycles;
  for(int x=0;x<n;x++)if(!(seen&(1u<<x))){uint32_t mask=0;int y=x;do{mask|=1u<<y;seen|=1u<<y;y=t[g][y];}while(y!=x);cycles.push_back(mask);}
  vector<uint32_t>unions(1,0);for(uint32_t c:cycles){size_t old=unions.size();for(size_t i=0;i<old;i++)unions.push_back(unions[i]|c);}
  for(uint32_t s:unions)stabilizer[s]++;
 }
 for(uint32_t s=1;s<limit;s++){
  uint32_t left=s;int m=-1;U128 count=0;
  while(left){uint32_t bit=left&-left;left-=bit;uint32_t pred=s^bit;
   if(best[pred]>m){m=best[pred];count=ways[pred];}else if(best[pred]==m)count+=ways[pred];
  }
  best[s]=m+stabilizer[s]-1;ways[s]=count;
 }
 // The expected recursion count is checked only after the unrestricted DP result exists.
 string observed=dec(ways.back());if(observed!=expected){cerr<<"COUNT MISMATCH "<<name<<" "<<observed<<" "<<expected<<endl;return 2;}
 if(ca)cout<<",\n";cout<<"{\"group\":\""<<name<<"\",\"N\":"<<n<<",\"subsets\":"<<limit<<",\"maximum\":"<<int(best.back())<<",\"maximizing_order_count\":\""<<observed<<"\",\"recursive_count_matches\":true}"<<flush;
 }cout<<"\n]\n";}
