# Square-Root Relative-Conductor Renormalization (SRCR)
## Candidate exact O(N log log N) Fourier theory

Date: 2026-10-11
Status: conjectural exact arbitrary-input algorithm.
Target: all N explicit outputs of a fresh exact DFT.
Proposed complexity: O(N log log N).

IMPORTANT:
The macro renormalization identity defined below is not yet proved.
This document does not claim that a new faster FFT has already been established.

---

## 1. Existing exact structure used by SRCR

Let N=2^t.

The Phase 34/36 Haar-conductor factorization rewrites the exact DFT into:

1. an O(N)-work Haar analysis,
2. one small principal/Ramanujan block,
3. a family of exact twisted Fourier blocks,
4. an O(N)-work synthesis.

The detail blocks are indexed by (j,c), with

    2 <= c <= j <= t

and block size

    q_c = 2^(c-2).

For a detail vector b of length q_c,

    (T_c b)_k
      = sum_(a=0)^(q_c-1)
          b_a * zeta_c^((2a+1)(2k+1)),

where zeta_c is a primitive 2^c-th root.

The exact dimension identity is

    (t+1) + sum_(c=2)^t (t-c+1) 2^(c-2) = N.

Thus the full DFT has already been reduced to a graded direct sum whose total state dimension is exactly N.

For dense worst-case inputs, however, Phase 36 still falls back to the full twisted short FFTs and has Theta(N log N) worst-case arithmetic.

---

## 2. Why the existing conductor decomposition does not yet beat FFT

Each twisted block T_c is diagonally equivalent to an ordinary Fourier transform of size q_c.

The largest block has size N/4.

So recursively evaluating the blocks one conductor level at a time only shrinks the largest recursive transform by a constant factor.

Even though the total child dimension is N, constant-factor shrink produces Theta(log N) recursive generations, hence Theta(N log N) work.

Therefore the missing property is not another sparse-input optimization.

We need a macro-step whose children:

    - have total dimension at most N;
    - each have dimension at most about sqrt(N);
    - are produced with only O(N) nonrecursive work.

That immediately changes the recursion depth from Theta(log N) to Theta(log log N).

---

## 3. The new relative-conductor split

Choose

    h = ceil(t/2)

and

    R = 2^h = Theta(sqrt(N)).

Separate the exact conductor blocks into:

LOW:
    c <= h+2,
so q_c <= R.

HIGH:
    c > h+2,
so q_c > R.

Every LOW block already has recursive size at most R.

The problem is to transform the complete HIGH bundle jointly.

Define

    G_(t,h)
      =
      direct_sum_(c=h+3)^t
        T_c ^ direct_sum(t-c+1).

Its total dimension is at most N.

SRCR proposes that this whole high-conductor bundle has an exact relative-conductor normal form that exposes only Fourier blocks of size <= R.

---

## 4. Allowed fusion grammar

The relative-conductor fusion maps are not arbitrary dense matrices.

They may use only uniformly generated combinations of:

1. Haar pair sums/differences;
2. permutations;
3. diagonal powers of the supplied N-th root;
4. Phase-25-type q-Green conjugacy gadgets;
5. cyclic-bidiagonal solves whose complete cost is O(m) on an m-coordinate block;
6. sparse routing whose total number of scalar edges is O(N).

The relevant Phase-25 identity is

    L_s F = F D_s,

where

    (L_s Y)_j
      = Y_j - Y_(j+4) - r omega^j Y_(j+s),

and D_s is cyclic bidiagonal:

    (D_s x)_t
      =
      (1-omega^(4t))x_t
      - r omega^(s(t-1)) x_(t-1).

D_s is solvable in O(N) exact arithmetic.

A single use of this conjugacy does not bypass Fourier; Phase 25 explicitly proves that.
SRCR therefore requires a simultaneous cross-conductor identity, not a hidden basis conversion.

---

## 5. SRCR macro-renormalization conjecture

For every dyadic N=2^t and h=ceil(t/2), there exist uniformly generated linear maps

    A_(t,h), B_(t,h)

from the allowed grammar, with total application and preparation cost O(N), such that

    A_(t,h) * G_(t,h) * B_(t,h)

is block diagonal:

    R_(t,h)
      direct_sum
      direct_sum_(nu=1)^M
          D_nu * F_(n_nu) * E_nu,

where:

    n_nu <= C * 2^h = O(sqrt(N)),
    sum_nu n_nu <= dim(G_(t,h)) <= N,

and D_nu,E_nu are explicit diagonal/permutation gauges.

R_(t,h) must also be computable in O(N) total work and have no recursive block larger than O(sqrt(N)).

This is the single missing theorem.

---

## 6. Conditional exact algorithm

Assume the SRCR macro-renormalization conjecture.

For an input x of length N:

1. Perform the exact Phase-34/36 Haar analysis in O(N).
2. Process the principal block directly.
3. Recurse on every LOW conductor block.
4. Apply A_(t,h), B_(t,h) to the complete HIGH bundle in O(N).
5. Recurse on every resulting block F_(n_nu).
6. Apply the exact inverse Haar/output synthesis.
7. Write every output explicitly.

No sparsity promise is used.

No branch is allowed to call an ordinary FFT as an uncharged operation.

---

## 7. Complexity theorem

Let T(N) be the exact scalar work.

The conjecture gives a recurrence of the form

    T(N)
      <=
      sum_i T(n_i)
      + C N,

with

    sum_i n_i <= N,
    max_i n_i <= K sqrt(N)

for fixed constants C,K.

Put

    S(N)=T(N)/N.

Then

    S(N)
      <=
      max_i S(n_i)
      + C.

After k macro-levels, the largest remaining size is at most approximately

    N^(1/2^k)

up to fixed constants.

To reach a constant-size base case requires

    k = O(log log N).

Therefore

    S(N)=O(log log N),

and hence

    T(N)=O(N log log N).

Thus the SRCR conjecture implies an exact all-input dyadic DFT in

    O(N log log N)

sequential scalar arithmetic.

---

## 8. Why this is different from the previous Conductor-Fused Gauss Ladder

CFGL asked for one O(N log log N) path-sum graph for the entire graded conductor direct sum.

SRCR asks for something narrower:

    one O(N)-work macro renormalization
    that lowers the maximum recursive size from N to sqrt(N)
    while preserving total recursive dimension <= N.

So the needed identity is local-in-scale and recursively testable.

It does not require synthesizing the complete Fourier matrix in one new graph.

---

## 9. Why Phase 36 is important

Phase 36 gives the exact twisted-block form and an exact support-adaptive executor:

    T_c b = sum_(a in support(b)) u_a v_a^k.

Sparse Haar blocks are already handled in O(q_c * support_size).

Dense worst-case blocks still require the short FFT.

SRCR keeps every Phase-36 sparse fast path.

It changes only the dense fallback:

    instead of a full short FFT,
    use the relative-conductor square-root macro recursion.

Therefore a future implementation can be adaptive:

    sparse block -> Phase36 geometric evaluator;
    dense block  -> SRCR recursion.

Worst case would be O(N log log N) if the macro theorem is proved, while structured cases retain O(N) / O(N s) behavior.

---

## 10. Why Phase 25 matters

Phase 25 provides exact O(N) noncommuting conjugacy gadgets with cyclic-bidiagonal time-side solvers.

That gives a concrete grammar for cross-conductor fusion that is richer than:

    - one common cyclic Green denominator;
    - one shift algebra;
    - one Weyl line;
    - low-treewidth sparse elimination.

Those simpler grammars have already been restricted or collapsed to ordinary FFT/Bluestein in the project.

The SRCR fusion must use several conductor-dependent jumps simultaneously.

---

## 11. Existing barriers that SRCR deliberately avoids

SRCR does NOT rely on:

- repeated-input caching;
- input sparsity;
- approximation;
- parallel time;
- one common-order rational Green scan;
- a finite one-dimensional metaplectic word;
- a single Weyl line;
- a depth-three positive-phase-only superconcentrator;
- a small-rank Schur interface;
- fixed support with generic full-spark weights.

The latest project results already show why those are insufficient.

SRCR permits a linear-dimensional state and genuinely noncommuting, scale-dependent O(N)-work maps.

---

## 12. Exact finite test program

The first decisive lengths are:

    N = 16, 32, 64, 256.

For each N:

1. Build the exact Phase-36 Haar/conductor factorization.
2. Set h=ceil(log2(N)/2).
3. Form the complete HIGH bundle exactly.
4. Search A_(t,h),B_(t,h) only in the allowed Haar/Green/diagonal/permutation grammar.
5. Expand the resulting transfer matrix exactly over Q(zeta_N), or over multiple exact finite-field embeddings with a characteristic-zero certificate.
6. Require every residual block to have dimension <= O(sqrt(N)).
7. Count every scalar addition, multiplication, inversion, root preparation and route.
8. Compare against the exact same-length radix-2 / Phase29 baseline.

A numerical fit is not a proof.

---

## 13. Fourier correctness certificate

For the final compiled operator M_N, verify symbolically

    M_N e_0 = ones

and

    M_N S = D M_N,

where S is cyclic input shift and

    D = diag(1,omega,...,omega^(N-1)).

These identities imply

    M_N = F_N.

They also prevent a finite-block fit from being mistaken for a uniform Fourier construction.

---

## 14. Strong falsifier

SRCR should be abandoned if one can prove:

Every allowed O(N)-work relative-conductor fusion of the HIGH bundle leaves at least one recursive Fourier-equivalent block of size

    N^(1-o(1)),

or forces total recursive dimension strictly larger than

    (1+epsilon)N

at each macro level.

Either result restores Omega(N log N) behavior for this recursion.

This would be a meaningful restricted lower bound, not a general FFT lower bound.

---

## 15. Stronger O(N) possibility

If a stronger macro theorem reduced every recursive block from N to

    exp(O(sqrt(log N)))

while preserving total child mass <=N and O(N) overhead,

then recursion depth would become even smaller.

If one O(N)-work macro step could reduce all children to polylog(N), the transform would become O(N).

There is currently no evidence for this stronger form.

The credible first target is sqrt(N), giving O(N log log N).

---

## 16. External comparison

A separate 2026 OpenAI result already reports a uniform exact DFT algorithm with

    O(N (log N)^(1-10^-13))

work in an exact-complex supplied-root model.

SRCR would be asymptotically stronger if proved:

    O(N log log N).

But SRCR is currently only a project-originated conjectural theory.

---

## 17. Novelty boundary

Known ingredients:

- Haar transforms;
- conductor decompositions;
- multiplicative characters and Gauss sums;
- Green/quasiseparable cyclic solves;
- Cooley-Tukey and twisted DFT blocks.

The proposed new ingredient is specifically:

    exact relative-conductor square-root renormalization
    with total recursive mass N,
    maximum child size sqrt(N),
    and O(N) nonrecursive Haar/Green work.

No external priority claim is made until a dedicated literature review is completed.

---

## Bottom line

The theory reduces the desired breakthrough to one exact statement:

    Can the complete high-conductor Fourier bundle
    be renormalized in O(N) work
    into recursive Fourier blocks of total dimension <=N
    and maximum size O(sqrt(N))?

If YES:

    exact DFT = O(N log log N).

If NO:

    the obstruction should identify a new cross-conductor lower bound,
    which is itself valuable research.
