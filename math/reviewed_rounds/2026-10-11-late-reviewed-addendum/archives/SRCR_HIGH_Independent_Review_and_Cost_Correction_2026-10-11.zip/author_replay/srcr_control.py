"""Fresh exact SRCR radix-2 control. Not a fast joint-Green macro.

Scalar model: exact Q(z), z primitive Nth root, N a power of two.
The sparse cyclotomic representation is a verifier, not a unit-cost runtime.
Only addition, subtraction, root multiplication and division by 2 occur in
the macro. Uploaded programs are neither imported nor executed.
"""
from fractions import Fraction
from dataclasses import dataclass


def add(a, b):
    out = dict(a)
    for e, c in b.items():
        out[e] = out.get(e, 0) + c
        if not out[e]:
            del out[e]
    return out


def scale(a, c):
    return {e: x*c for e, x in a.items() if x*c}


def root_mul(a, e, N):
    """Exact reduction modulo z^(N/2)+1; supports negative exponents."""
    out = {}
    D = N // 2
    for k, c in a.items():
        q, r = divmod(k+e, D)
        v = c if q % 2 == 0 else -c
        out[r] = out.get(r, 0) + v
        if not out[r]:
            del out[r]
    return out


ZERO = {}
ONE = {0: Fraction(1)}


@dataclass(frozen=True)
class Block:
    c: int
    q: int
    d: int
    R: int
    copies: int
    sigma: int
    levels: tuple
    output_order: tuple


def compile_block(t, c):
    if type(t) is not int or type(c) is not int or t < 6:
        raise ValueError('Require integer t>=6 and a HIGH conductor c.')
    h = (t+1)//2
    if not h+3 <= c <= t:
        raise ValueError('Conductor is not in the nonempty HIGH range.')
    N, q, R = 1 << t, 1 << (c-2), 1 << h
    d, sigma = c-2-h, 1 << (t-c)
    levels = []
    for ell in range(d):
        m = q >> ell
        pairs = []
        for start in range(0, q, m):
            for a in range(m//2):
                pairs.append((start+a, start+a+m//2, (N//m)*a))
        levels.append(tuple(pairs))
    def reverse_bits(a, width):
        out = 0
        for _ in range(width):
            out, a = 2*out+(a&1), a>>1
        return out
    # New row b*R+r is old Fourier row reverse_bits(b,d)+2^d*r.
    order = tuple(reverse_bits(b, d)+(1 << d)*r
                  for b in range(1 << d) for r in range(R))
    return Block(c, q, d, R, t-c+1, sigma, tuple(levels), order)


def compile_high(t, max_coordinates=1 << 18):
    if type(t) is not int or t < 0:
        raise ValueError('Require nonnegative integer t.')
    if type(max_coordinates) is not int or max_coordinates < 1:
        raise ValueError('Require positive integer coordinate budget.')
    # Bound before shifts/allocations. A caller-supplied budget is mandatory
    # for larger plans; this is an implementation cap, not a theorem cutoff.
    if t > max_coordinates.bit_length()-1:
        raise ValueError('Requested N exceeds coordinate budget.')
    h = (t+1)//2
    return [compile_block(t, c) for c in range(h+3, t+1)]


def check_vector(x, b):
    if len(x) != b.q:
        raise ValueError('Vector length differs from compiled block.')


def K_apply(x, b, N, inverse=False):
    check_vector(x, b)
    x = list(x)
    levels = reversed(b.levels) if inverse else b.levels
    for pairs in levels:
        y = list(x)
        for i, j, e in pairs:
            if inverse:
                v = root_mul(x[j], -e, N)
                y[i] = scale(add(x[i], v), Fraction(1, 2))
                y[j] = scale(add(x[i], scale(v, -1)), Fraction(1, 2))
            else:
                y[i] = add(x[i], x[j])
                y[j] = root_mul(add(x[i], scale(x[j], -1)), e, N)
        x = y
    return x


def B_inverse(x, b, N):
    """B^-1=K C; input map used by the evaluator."""
    check_vector(x, b)
    return K_apply([root_mul(v, 2*b.sigma*a, N)
                    for a, v in enumerate(x)], b, N)


def B_apply(x, b, N):
    """B=C^-1 K^-1; includes legal, charged divisions by 2."""
    y = K_apply(x, b, N, inverse=True)
    return [root_mul(v, -2*b.sigma*a, N) for a, v in enumerate(y)]


def A_apply(y, b, N):
    """A=J R^-1, where R[k,k]=z^(sigma*(2k+1))."""
    check_vector(y, b)
    v = [root_mul(x, -b.sigma*(2*k+1), N) for k, x in enumerate(y)]
    return [v[k] for k in b.output_order]


def A_inverse(y, b, N):
    check_vector(y, b)
    out = [ZERO]*b.q
    for a, k in enumerate(b.output_order):
        out[k] = root_mul(y[a], b.sigma*(2*k+1), N)
    return out


def dft_direct(x, N):
    q = len(x)
    if not q or N % q:
        raise ValueError('Child length must divide ambient N.')
    return [sum_terms(root_mul(v, (N//q)*k*a, N)
                      for a, v in enumerate(x)) for k in range(q)]


def sum_terms(terms):
    out = ZERO
    for x in terms:
        out = add(out, x)
    return out


def T_direct(x, b, N):
    check_vector(x, b)
    return [sum_terms(root_mul(v, b.sigma*(2*a+1)*(2*k+1), N)
                      for a, v in enumerate(x)) for k in range(b.q)]


def children_direct(x, b, N):
    check_vector(x, b)
    return sum([dft_direct(x[a:a+b.R], N)
                for a in range(0, b.q, b.R)], [])


def evaluate_control(x, b, N):
    return A_inverse(children_direct(B_inverse(x, b, N), b, N), b, N)


def evaluate_high(x, t):
    blocks = compile_high(t)
    if len(x) != ledger(t)['high_mass']:
        raise ValueError('Input length differs from complete HIGH mass.')
    out, off = [], 0
    for b in blocks:
        for _ in range(b.copies):
            out.extend(evaluate_control(x[off:off+b.q], b, 1 << t))
            off += b.q
    return out


def ledger(t):
    """Symbolic exact charges. Does not allocate an exponential plan."""
    if type(t) is not int or t < 0 or t > 10000:
        raise ValueError('Ledger supports integer 0<=t<=10000.')
    N, h = 1 << t, (t+1)//2
    R, L = 1 << h, t-h-2
    if L <= 0:
        H = W = blocks = leaves = 0
    else:
        H = N-2*R*(L+2)
        W = (L-2)*N+(2*L+8)*R
        blocks = L*(L+1)//2
        leaves = H//R
    return dict(t=t, N=N, h=h, R=R, L=L, high_mass=H,
                low_and_principal_mass=N-H, high_block_copies=blocks,
                leaf_count=leaves, leaf_mass=leaves*R,
                butterfly_stage_weight=W,
                online_macro_additions=W,
                online_macro_root_multiplications=W//2+2*H,
                inverse_chart_additions=W,
                inverse_chart_root_multiplications=W//2+2*H,
                inverse_chart_half_multiplications=W,
                inverse_half_preparation_divisions=(1 if H else 0),
                inverse_two_preparation_additions=(1 if H else 0),
                root_power_table_multiplications=max(0, N-2),
                expanded_pair_records=W//2,
                expanded_phase_records=2*H,
                output_permutation_records=H,
                online_macro_arithmetic_reads=4*H+3*W,
                online_macro_arithmetic_writes=2*H+3*W//2,
                online_input_reads=H, online_output_writes=H,
                # Vector buffers use O(H); retained expanded instructions
                # use Theta(H+W), while generated-on-demand loops use O(N).
                expanded_instruction_storage_order='Theta(H+W)',
                streaming_state_and_root_storage_order='O(N)',
                child_radix2_additions=h*H,
                child_radix2_root_multiplications=h*H//2,
                child_direct_additions=H*max(0, R-1),
                child_direct_root_multiplications=H*R)
