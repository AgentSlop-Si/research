"""Fresh exact characteristic-zero controls, independently expanded targets."""
import json
from pathlib import Path
from fractions import Fraction
from srcr_control import *


def basis(n, j):
    return [ONE if a == j else ZERO for a in range(n)]


def test():
    out = {'field':'Q[z]/(z^(N/2)+1), N dyadic',
           'uploaded_programs_executed':False,'cases':[], 'negative_controls':[]}
    for t in [6, 7, 8]:
        N = 1 << t
        cases = []
        for b in compile_high(t):
            entries = 0
            for j in range(b.q):
                x = basis(b.q, j)
                target = T_direct(x, b, N)
                actual = evaluate_control(x, b, N)
                assert actual == target
                assert A_apply(T_direct(B_apply(x, b, N), b, N), b, N) == children_direct(x, b, N)
                assert B_apply(B_inverse(x, b, N), b, N) == x
                assert B_inverse(B_apply(x, b, N), b, N) == x
                assert A_apply(A_inverse(x, b, N), b, N) == x
                assert A_inverse(A_apply(x, b, N), b, N) == x
                entries += b.q
            # Dense rational inputs exercise non-basis scalar propagation.
            x = [{0:Fraction((3*a)%11-5, a%3+1)} for a in range(b.q)]
            assert evaluate_control(x,b,N) == T_direct(x,b,N)
            cases.append({'c':b.c,'q':b.q,'copies':b.copies,'d':b.d,
                          'child_size':b.R,'child_count':1<<b.d,
                          'all_matrix_entries_checked_per_block':entries,
                          'both_inverse_directions_checked':True})
        coordinates=[]
        for b in compile_high(t):
            for copy in range(b.copies):
                coordinates.extend((b.c,copy,a,b.sigma) for a in range(b.q))
        H=len(coordinates)
        for j,(cj,pj,a,sig) in enumerate(coordinates):
            actual=evaluate_high(basis(H,j),t)
            expected=[root_mul(ONE,sig*(2*a+1)*(2*k+1),N)
                      if (ck,pk)==(cj,pj) else ZERO
                      for ck,pk,k,_ in coordinates]
            assert actual==expected
        out['cases'].append({'N':N,'block_types':cases,
            'complete_high_matrix_entries_checked':H*H,
            'zero_cross_packet_entries_checked':H*H-sum(x['copies']*x['q']**2 for x in cases),
            'ledger':ledger(t)})
    # First nonempty complete HIGH bundle: two concrete disjoint F8 leaves.
    b = compile_high(6)[0]
    N = 64
    x = basis(b.q, 1)
    target = T_direct(x,b,N)
    malformed = A_inverse(children_direct(B_apply(x,b,N),b,N),b,N)
    assert malformed != target
    out['negative_controls'].append('Using B instead of B^-1 is rejected.')
    malformed = A_inverse(children_direct(x,b,N),b,N)
    assert malformed != target
    out['negative_controls'].append('Omitting input twist/butterfly is rejected.')
    internal = children_direct(B_inverse(x,b,N),b,N)
    malformed = [root_mul(v,b.sigma*(2*k+1),N) for k,v in enumerate(internal)]
    assert malformed != target
    out['negative_controls'].append('Omitting output deinterleaving is rejected.')
    for t in range(6):
        assert compile_high(t)==[] and ledger(t)['high_mass']==0
    out['negative_controls'].append('N=1,2,4,8,16,32 have empty HIGH; not positive witnesses.')
    for t in range(6, 201):
        h=(t+1)//2
        direct_H=sum((t-c+1)*(1<<(c-2)) for c in range(h+3,t+1))
        direct_W=sum((t-c+1)*(1<<(c-2))*(c-2-h) for c in range(h+3,t+1))
        l=ledger(t)
        assert l['high_mass']==direct_H and l['butterfly_stage_weight']==direct_W
        assert l['leaf_mass']==direct_H
        assert (t+1)+sum((t-c+1)*(1<<(c-2)) for c in range(2,t+1)) == 1<<t
        if t>=12:
            assert direct_W >= (1<<t)*(t-h-2)//4
    out['ledger_checks']={'t_values':195,'scope':'Finite controls supplement the all-t algebraic proof.'}
    rejected=0
    for args in [(-1,), (True,), (20, 1024), (6, 0)]:
        try: compile_high(*args)
        except ValueError: rejected += 1
    assert rejected==4
    out['negative_controls'].append('Invalid type, negative t, and exceeded allocation budget are rejected.')
    # Exact certificate describes every weight by root exponent, all routes.
    c = compile_high(6)[0]
    certificate={'N':64,'root':'z primitive 64th root',
       'quotient':'z^32+1','input_block':'T_6, q=16, multiplicity=1',
       'children':[{'length':8,'root_exponent':8} for _ in range(2)],
       'C_root_exponents':[2*a for a in range(16)],
       'R_root_exponents':[2*k+1 for k in range(16)],
       'K_levels':c.levels,'J_output_order':c.output_order,
       'identity':'(J R^-1) T_6 (C^-1 K^-1) = F_8 direct_sum F_8',
       'evaluation':'T_6 = R J^-1 (F_8 direct_sum F_8) K C',
       'legal_nonzero_divisors':['2','powers of z'],
       'ledger':ledger(6),'status':'author candidate; independent review required'}
    Path('examples/N64_HIGH_CERTIFICATE.json').write_text(json.dumps(certificate,indent=2)+'\n')
    out['status']='PASS: author controls only; independent review required'
    Path('results/AUTHOR_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__ == '__main__': test()
