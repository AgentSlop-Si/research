"""Independent SRCR source, matrix, counter and boundary controls.

Runs only the inspected fresh candidate control module, never original uploaded
research programs. Independent field operations, target entries and recursive
forward construction do not call candidate arithmetic or compilation helpers.
"""
import collections
import hashlib
import importlib.util
import json
from fractions import Fraction
from pathlib import Path

BASE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('inspected_candidate', BASE/'author_replay/srcr_control.py')
C = importlib.util.module_from_spec(SPEC)
import sys
sys.modules[SPEC.name] = C
SPEC.loader.exec_module(C)


def plus(a, b):
    keys = set(a) | set(b)
    return {k: a.get(k, 0)+b.get(k, 0) for k in keys if a.get(k, 0)+b.get(k, 0)}


def scalar(a, s):
    return {k: v*s for k, v in a.items() if v*s}


def phase(a, exp, N):
    ans = {}
    for k, coeff in a.items():
        e = (k+exp) % N
        key, sign = (e, 1) if e < N//2 else (e-N//2, -1)
        ans[key] = ans.get(key, 0) + sign*coeff
    return {k: v for k, v in ans.items() if v}


def product(a, b, N):
    ans = {}
    for e, coeff in b.items():
        ans = plus(ans, scalar(phase(a, e, N), coeff))
    return ans


def root(e, N):
    return phase({0: Fraction(1)}, e, N)


def mm(a, b, N):
    ans = []
    for row in a:
        out = []
        for col in zip(*b):
            s = {}
            for x, y in zip(row, col):
                s = plus(s, product(x, y, N))
            out.append(s)
        ans.append(out)
    return ans


def source_packets(t):
    h = (t+1)//2
    return [(c, p, 2**(c-2), 2**(t-c)) for c in range(h+3, t+1) for p in range(t-c+1)]


def direct_fourier(x, N):
    n = len(x)
    return [sum_polys(phase(v, N//n*a*k, N) for a, v in enumerate(x)) for k in range(n)]


def sum_polys(xs):
    ans = {}
    for x in xs:
        ans = plus(ans, x)
    return ans


def recursive_control(x, R, N):
    """Recursive pairing and output interleaving, without bit reversal code."""
    n = len(x)
    if n == R:
        return direct_fourier(x, N)
    m = n//2
    s = [plus(x[a], x[a+m]) for a in range(m)]
    v = [phase(plus(x[a], scalar(x[a+m], -1)), N//n*a, N) for a in range(m)]
    even, odd = recursive_control(s, R, N), recursive_control(v, R, N)
    return [z for pair in zip(even, odd) for z in pair]


def fresh_twisted(x, t, c):
    N, sigma, R = 2**t, 2**(t-c), 2**((t+1)//2)
    y = recursive_control([phase(v, 2*sigma*a, N) for a, v in enumerate(x)], R, N)
    return [phase(v, sigma*(2*k+1), N) for k, v in enumerate(y)]


def n64_dense_matrices():
    N, q = 64, 16
    T = [[root((2*k+1)*(2*a+1), N) for a in range(q)] for k in range(q)]
    # Construct A directly as one signed routing/phase entry per row.
    order = list(range(0,16,2))+list(range(1,16,2))
    A = [[root(-(2*k+1), N) if j == k else {} for j in range(q)] for k in order]
    # Each column of B=C^-1 K^-1 follows the two explicit pair equations.
    B = [[{} for _ in range(q)] for _ in range(q)]
    for a in range(8):
        B[a][a] = scalar(root(-2*a, N), Fraction(1,2))
        B[a+8][a] = scalar(root(-2*(a+8), N), Fraction(1,2))
        B[a][a+8] = scalar(root(-2*a-4*a, N), Fraction(1,2))
        B[a+8][a+8] = scalar(root(-2*(a+8)-4*a, N), Fraction(-1,2))
    Q = [[root(8*(k%8)*(a%8),N) if k//8 == a//8 else {} for a in range(q)] for k in range(q)]
    assert mm(mm(A,T,N),B,N) == Q
    return {'size':q, 'entries':q*q, 'identity':'A T6 B = F8 direct_sum F8', 'candidate_helpers_used':False}


def complete_matrix_controls():
    cases = []
    for t in (6,7,8,9):
        N = 2**t
        coords = [(c,p,a,sigma) for c,p,q,sigma in source_packets(t) for a in range(q)]
        H = len(coords)
        for col,(c,p,a,sigma) in enumerate(coords):
            actual = C.evaluate_high([{0:Fraction(1)} if j == col else {} for j in range(H)],t)
            expected = [root(sigma*(2*a+1)*(2*k+1),N) if (cc,pp)==(c,p) else {} for cc,pp,k,_ in coords]
            assert actual == expected, (t,col)
        cross = H*H-sum(q*q for _,_,q,_ in source_packets(t))
        cases.append({'N':N,'H':H,'all_entries':H*H,'cross_packet_zeros':cross})
    return cases


def fresh_recursive_controls():
    records = []
    for t in range(6,11):
        N = 2**t
        for c in range((t+1)//2+3,t+1):
            b = C.compile_block(t,c)
            # Every coordinate nonzero; nontrivial polynomial and rational input.
            x = [plus(root((7*a+3)%N,N),scalar(root((11*a+1)%N,N),Fraction((a%5)-2,a%3+1))) for a in range(b.q)]
            independent = fresh_twisted(x,t,c)
            target = [sum_polys(phase(v,b.sigma*(2*a+1)*(2*k+1),N) for a,v in enumerate(x)) for k in range(b.q)]
            assert independent == target == C.evaluate_control(x,b,N)
            for f,g in [(C.A_apply,C.A_inverse),(C.A_inverse,C.A_apply),(C.B_apply,C.B_inverse),(C.B_inverse,C.B_apply)]:
                assert f(g(x,b,N),b,N) == x
            assert C.A_apply(C.T_direct(C.B_apply(x,b,N),b,N),b,N) == C.children_direct(x,b,N)
            records.append({'N':N,'c':c,'q':b.q,'d':b.d,'dense_polynomial_input':True,'both_inverse_directions':True})
    return records


def counters():
    records = []
    originals = {name:getattr(C,name) for name in ('add','root_mul','scale')}
    try:
        for t in (6,7,8,9,10):
            count = collections.Counter()
            def add(a,b):
                count['add'] += 1
                return originals['add'](a,b)
            def root_mul(a,e,N):
                count['root'] += 1
                return originals['root_mul'](a,e,N)
            def scale(a,s):
                if s == Fraction(1,2): count['half'] += 1
                elif s == -1: count['negation_lowering'] += 1
                return originals['scale'](a,s)
            C.add,C.root_mul,C.scale = add,root_mul,scale
            N = 2**t
            l = C.ledger(t)
            H,W,R = l['high_mass'],l['butterfly_stage_weight'],l['R']
            for c,p,q,sigma in source_packets(t):
                b = C.compile_block(t,c)
                x = [{0:Fraction(1)} for _ in range(q)]
                C.A_inverse(C.B_inverse(x,b,N),b,N)
            macro = dict(count)
            assert macro['add'] == W and macro['root'] == W//2+2*H
            count.clear()
            for c,p,q,sigma in source_packets(t):
                b = C.compile_block(t,c)
                C.B_apply(C.A_apply([{0:Fraction(1)} for _ in range(q)],b,N),b,N)
            chart = dict(count)
            assert chart['add']==W and chart['root']==W//2+2*H and chart['half']==W
            count.clear()
            for c,p,q,sigma in source_packets(t):
                b = C.compile_block(t,c)
                C.children_direct([{0:Fraction(1)} for _ in range(q)],b,N)
            child = dict(count)
            assert child['add']==H*R and child['root']==H*R
            assert child['add']-l['child_direct_additions'] == H
            records.append({'N':N,'macro':macro,'chart':chart,'literal_direct_child':child,'declared_direct_child_additions':l['child_direct_additions'],'correct_literal_direct_child_additions':H*R,'understatement':H})
    finally:
        for name,f in originals.items():setattr(C,name,f)
    return records


def boundaries_and_counts():
    for t in range(0,513):
        N,h = 2**t,(t+1)//2
        R,L = 2**h,t-h-2
        H = sum(q for _,_,q,_ in source_packets(t))
        W = sum(q*(c-2-h) for c,_,q,_ in source_packets(t))
        l = C.ledger(t)
        assert l['high_mass']==H and l['butterfly_stage_weight']==W
        assert l['leaf_mass']==H and H<=N
        assert (t+1)+sum((t-c+1)*2**(c-2) for c in range(2,t+1))==N
        if L>0:
            assert N == 2**(L+2)*R
            assert H == N-2*R*(L+2)
            assert W == (L-2)*N+(2*L+8)*R
            assert N*L//4 <= W <= N*L
        else: assert H==W==0
    for t in range(6):assert C.compile_high(t)==[]
    # N=1 is a valid empty HIGH boundary; no quotient field is used there.
    for N in (64,128,256,512,1024):
        for e in range(-3*N,3*N+1):
            assert C.root_mul({0:Fraction(1)},e,N) == root(e,N)
        # Primitive dyadic root checks needed by every butterfly.
        for m in [2**k for k in range(1,N.bit_length())]:
            assert root(N//m*m,N)=={0:Fraction(1)}
            assert root(N//m*(m//2),N)=={0:Fraction(-1)}
    rejected=[]
    for args in [(-1,), (True,), (3.0,), (20,1024), (6,0)]:
        try:C.compile_high(*args)
        except ValueError:rejected.append(str(args))
        else:raise AssertionError(args)
    for t,c in [(5,5),(6,5),(6,7),(True,6),(6,True)]:
        try:C.compile_block(t,c)
        except ValueError:rejected.append(str((t,c)))
        else:raise AssertionError((t,c))
    return {'t_range':[0,512],'root_shift_checks':sum(6*N+1 for N in (64,128,256,512,1024)),'invalid_compiler_cases':rejected}


def targeted_mutants():
    results=[]
    b=C.compile_block(6,6)
    x=[{0:Fraction(1)} if j==1 else {} for j in range(16)]
    target=[root((2*1+1)*(2*k+1),64) for k in range(16)]
    assert C.A_inverse(C.children_direct(C.B_apply(x,b,64),b,64),b,64)!=target
    results.append('N64 wrong reconstruction direction detected')
    unnormalized=[scalar(v,2) for v in C.B_apply(C.B_inverse(x,b,64),b,64)]
    assert unnormalized!=x
    results.append('N64 omitted inverse half normalization detected')
    y=C.evaluate_high([{0:Fraction(1)}]+[{} for _ in range(127)],8)
    contaminated=y[:32]+y[:32]+y[64:]
    assert contaminated!=y and all(v=={} for v in y[32:])
    results.append('N256 merging same-conductor copies detected on cross-packet rows')
    b=C.compile_block(10,10)
    x=[{0:Fraction(1)} if j==1 else {} for j in range(256)]
    target=C.evaluate_control(x,b,1024)
    internal=C.children_direct(C.B_inverse(x,b,1024),b,1024)
    wrong=[{} for _ in range(b.q)]
    for j,v in enumerate(internal):
        packet,r=divmod(j,b.R)
        k=packet+(1<<b.d)*r
        wrong[k]=phase(v,b.sigma*(2*k+1),1024)
    assert wrong!=target
    results.append('N1024 omitting depth-three leaf-bit reversal detected')
    return results


def main():
    out={'n64_independent_dense_matrices':n64_dense_matrices(),
         'complete_high_matrices':complete_matrix_controls(),
         'fresh_recursive_and_inverse_controls':fresh_recursive_controls(),
         'instrumented_literal_counts':counters(),
         'boundaries_roots_counts':boundaries_and_counts(),
         'targeted_negative_controls':targeted_mutants(),
         'original_uploaded_programs_executed':False,
         'candidate_module_inspected_then_executed':True,
         'candidate_source_unchanged':True,
         'finding':'Literal direct-child addition count is HR, not H(R-1).',
         'status':'PASS with exact direct-child cost correction'}
    out['total_complete_high_entries'] = sum(x['all_entries'] for x in out['complete_high_matrices'])
    out['total_cross_packet_zeros'] = sum(x['cross_packet_zeros'] for x in out['complete_high_matrices'])
    (BASE/'evidence/INDEPENDENT_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__ == '__main__':main()
