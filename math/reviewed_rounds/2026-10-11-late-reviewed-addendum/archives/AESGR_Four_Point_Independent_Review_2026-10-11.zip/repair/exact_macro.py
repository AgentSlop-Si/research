"""Fresh exact q=2, B=4 Green macro compiler, recurrent executor and validator.
Only standard-library rational arithmetic is used. Inherited scripts are inert.
Counts are unit-cost Q(i) scalar operations, not rational bit operations.
"""
from fractions import Fraction as F
from collections import Counter
from itertools import product
from pathlib import Path
import copy, json, hashlib

class Q:
    def __init__(self, a=0, b=0):
        if isinstance(a,Q):self.a,self.b=a.a,a.b
        else:self.a,self.b=F(a),F(b)
    def __add__(self,o):
        o=Q(o);return Q(self.a+o.a,self.b+o.b)
    __radd__=__add__
    def __neg__(self):return Q(-self.a,-self.b)
    def __sub__(self,o):return self+-Q(o)
    def __rsub__(self,o):return Q(o)+-self
    def __mul__(self,o):
        o=Q(o);return Q(self.a*o.a-self.b*o.b,self.a*o.b+self.b*o.a)
    __rmul__=__mul__
    def __truediv__(self,o):
        o=Q(o);d=o.a*o.a+o.b*o.b
        if d==0:raise ZeroDivisionError
        return Q((self.a*o.a+self.b*o.b)/d,(self.b*o.a-self.a*o.b)/d)
    def __eq__(self,o):
        o=Q(o);return self.a==o.a and self.b==o.b
    def __pow__(self,n):
        y=Q(1)
        for _ in range(n):y=y*self
        return y
    def encode(self):return [str(self.a),str(self.b)]
    @classmethod
    def decode(cls,v):
        if type(v) is not list or len(v)!=2 or not all(type(x) is str for x in v):raise ValueError('bad exact scalar')
        try:
            parts=[F(x) for x in v]
        except (ValueError, ZeroDivisionError):
            raise ValueError('bad rational scalar') from None
        if any(str(a)!=b for a,b in zip(parts,v)):raise ValueError('noncanonical rational scalar')
        return Q(*parts)

class Ops:
    def __init__(self):self.counts=Counter()
    def add(self,a,b):self.counts['additions']+=1;return a+b
    def sub(self,a,b):self.counts['subtractions']+=1;return a-b
    def mul(self,a,b):self.counts['multiplications']+=1;return a*b
    def div(self,a,b):self.counts['divisions']+=1;return a/b

def compile_macro(root=Q(0,1)):
    op=Ops();one=Q(1);zero=Q(0)
    if op.mul(root,root)!=Q(-1):raise ValueError('root must have exact order four')
    negone=op.sub(zero,one);negroot=op.sub(zero,root)
    two=op.add(one,one);half=op.div(one,two)
    eight=op.mul(op.mul(two,two),two)
    orders=[[0,1,2,3],[0,2,1,3],[0,1,3,2],[0,1,3,2]]
    layers=[]
    for order in orders:
        branches=[]
        for sign in [1,-1]:
            weights=[one,one,one,negone]
            if sign==-1:weights=[op.sub(zero,w) for w in weights]
            h=one
            for w in weights:h=op.mul(h,w)
            den=op.sub(one,h)
            if den==0:raise ValueError('generated singular Green cycle')
            inv=op.div(one,den)
            inverse=[0]*4
            for k,v in enumerate(order):inverse[v]=k
            branches.append({'order':order[:],'inverse_order':inverse,'edge_weights':[w.encode() for w in weights],
                             'alpha':half.encode(),'holonomy':h.encode(),'denominator_inverse':inv.encode()})
        layers.append(branches)
    diags=[[one,one,negone,negone], [one,negone,one,negroot],
           [one,one,negone,negone], [one,one,one,negone], [eight]*4]
    certificate={'schema':'aesgr-f4-exact-v1','B':4,'q':2,'depth':4,'root':root.encode(),
                 'input_diagonal':[x.encode() for x in diags[0]],
                 'interstage_diagonals':[[x.encode() for x in d] for d in diags[1:4]],
                 'output_diagonal':[x.encode() for x in diags[4]],'layers':layers}
    # Counts emitted payload entries, including repeats, not Python object bytes.
    memory={'branch_order_words':32,'branch_inverse_order_words':32,'edge_weight_scalars':32,
            'alpha_scalars':8,'holonomy_scalars':8,'denominator_inverse_scalars':8,
            'diagonal_scalars':20,'supplied_root_scalars':1}
    return certificate,dict(op.counts),memory

def validate_structure(c):
    fields={'schema','B','q','depth','root','input_diagonal','interstage_diagonals','output_diagonal','layers'}
    if type(c) is not dict or set(c)!=fields:raise ValueError('certificate fields')
    if any(type(c[k]) is not int for k in ('B','q','depth')):raise ValueError('exact integer dimensions required')
    if type(c['schema']) is not str:raise ValueError('schema type')
    if any(type(c[k]) is not list for k in ('input_diagonal','interstage_diagonals','output_diagonal','layers')):raise ValueError('certificate list fields')
    if c['schema']!='aesgr-f4-exact-v1' or c['B']!=4 or c['q']!=2 or c['depth']!=4:raise ValueError('fixed certificate dimensions')
    root=Q.decode(c['root'])
    if root*root!=Q(-1):raise ValueError('root is not primitive order four')
    if len(c['layers'])!=4 or len(c['interstage_diagonals'])!=3:raise ValueError('layer count')
    for d in [c['input_diagonal']]+c['interstage_diagonals']+[c['output_diagonal']]:
        if type(d) is not list or len(d)!=4 or any(Q.decode(x)==0 for x in d):raise ValueError('invalid diagonal')
    for layer in c['layers']:
        if type(layer) is not list or len(layer)!=2:raise ValueError('branch count')
        for b in layer:
            fields={'order','inverse_order','edge_weights','alpha','holonomy','denominator_inverse'}
            if type(b) is not dict or set(b)!=fields:raise ValueError('branch fields')
            for key in ('order','inverse_order'):
                if type(b[key]) is not list or len(b[key])!=4 or any(type(v) is not int for v in b[key]):raise ValueError('exact integer order required')
            if type(b['edge_weights']) is not list or len(b['edge_weights'])!=4:raise ValueError('edge list')
            order=b['order'];weights=[Q.decode(w) for w in b['edge_weights']]
            if sorted(order)!=list(range(4)):raise ValueError('not a Hamiltonian order')
            if b['inverse_order']!=[order.index(v) for v in range(4)]:raise ValueError('inverse order mismatch')
            if len(weights)!=4 or any(w==0 for w in weights):raise ValueError('zero or missing edge')
            h=Q(1)
            for w in weights:h=h*w
            if h==1:raise ValueError('singular Green denominator')
            if Q.decode(b['holonomy'])!=h:raise ValueError('holonomy metadata mismatch')
            if Q.decode(b['denominator_inverse'])*(1-h)!=1:raise ValueError('wrong denominator inverse')
            if Q.decode(b['alpha'])==0:raise ValueError('disabled branch')
    return root

def green_action(b,x,op):
    order=b['order'];w=[Q.decode(z) for z in b['edge_weights']]
    # bacc is the constant term of y[v3] after propagating from y[v0].
    bacc=Q(0)
    for k in range(1,4):bacc=op.add(x[order[k]],op.mul(w[k-1],bacc))
    y=[Q(0)]*4
    y[order[0]]=op.mul(op.add(x[order[0]],op.mul(w[3],bacc)),Q.decode(b['denominator_inverse']))
    for k in range(1,4):y[order[k]]=op.add(x[order[k]],op.mul(w[k-1],y[order[k-1]]))
    return y

def execute(c,x):
    # Trusted prepared certificate: call validate_structure once before use;
    # certify is needed for Fourier equality. Do not mutate the certificate/input
    # concurrently. The input guard and snapshot below are paid data traffic.
    if type(x) not in (list,tuple) or len(x)!=4:raise ValueError('exactly four input scalars required')
    snapshot=[]
    for v in x:
        if type(v) is Q and type(v.a) is F and type(v.b) is F:
            snapshot.append(Q(v.a,v.b))
        elif type(v) in (int,F):
            snapshot.append(Q(v))
        else:raise ValueError('input scalars must be exact integers, Fractions or Q values')
    x=snapshot
    op=Ops()
    x=[op.mul(Q.decode(d),v) for d,v in zip(c['input_diagonal'],x)]
    for k,layer in enumerate(c['layers']):
        ys=[green_action(b,x,op) for b in layer]
        x=[op.add(op.mul(Q.decode(layer[0]['alpha']),ys[0][j]),
                  op.mul(Q.decode(layer[1]['alpha']),ys[1][j])) for j in range(4)]
        d=c['output_diagonal'] if k==3 else c['interstage_diagonals'][k]
        x=[op.mul(Q.decode(a),v) for a,v in zip(d,x)]
    return x,dict(op.counts)

def target(root,x):return [sum((root**(i*j))*x[j] for j in range(4)) for i in range(4)]
def certify(c):
    root=validate_structure(c);cols=[];counts=None
    for j in range(4):
        x=[Q(int(j==k)) for k in range(4)];y,counts=execute(c,x)
        if y!=target(root,x):raise ValueError('full Fourier identity fails')
        cols.append(y)
    M=[[cols[j][i] for j in range(4)] for i in range(4)]
    assert all(M[i][0]==1 for i in range(4))
    assert all(M[i][(j+1)%4]==root**i*M[i][j] for i in range(4) for j in range(4))
    return {'all_matrix_entries':16,'seed_entries':4,'weyl_entries':16,
            'matrix':[[x.encode() for x in row] for row in M],'online_scalar_operations':counts}

def main():
    out=Path(__file__).resolve().parent
    c,prep,memory=compile_macro();positive=certify(c)
    (out/'MACRO_CERTIFICATE.json').write_text(json.dumps(c,indent=2)+'\n')
    vectors=0
    for values in product([Q(0),Q(1),Q(-1),Q(0,1),Q(0,-1)],repeat=4):
        actual,_=execute(c,list(values));assert actual==target(Q(0,1),list(values));vectors+=1
    for k in range(1,51):
        x=[Q(F((k+2*j)%11-5,k+1),F((3*k+j)%7-3,k+2)) for j in range(4)]
        assert execute(c,x)[0]==target(Q(0,1),x);vectors+=1
    negative_root,_,_=compile_macro(Q(0,-1));certify(negative_root)
    mutations=[]
    def bad(name,edit):
        z=copy.deepcopy(c);edit(z)
        try:certify(z)
        except (ValueError,ZeroDivisionError,KeyError,TypeError,IndexError) as e:
            mutations.append({'name':name,'rejected':True,'reason':str(e)});return
        raise AssertionError('accepted bad mutation '+name)
    bad('wrong_fourier_sign',lambda z:z['interstage_diagonals'][0].__setitem__(3,Q(0,1).encode()))
    bad('twiddle_removed',lambda z:z['interstage_diagonals'][0].__setitem__(3,Q(1).encode()))
    bad('output_scale_4_not_8',lambda z:z.__setitem__('output_diagonal',[Q(4).encode()]*4))
    bad('singular_holonomy',lambda z:z['layers'][0][0]['edge_weights'].__setitem__(3,Q(1).encode()))
    bad('zero_cycle_edge',lambda z:z['layers'][0][0]['edge_weights'].__setitem__(0,Q(0).encode()))
    bad('duplicate_cycle_vertex',lambda z:z['layers'][0][0]['order'].__setitem__(3,0))
    bad('bad_inverse_order',lambda z:z['layers'][1][0]['inverse_order'].__setitem__(1,1))
    bad('wrong_reciprocal',lambda z:z['layers'][0][0].__setitem__('denominator_inverse',Q(1).encode()))
    bad('disabled_second_branch',lambda z:z['layers'][0][1].__setitem__('alpha',Q(0).encode()))
    bad('zero_interstage_diagonal',lambda z:z['interstage_diagonals'][1].__setitem__(0,Q(0).encode()))
    bad('nonprimitive_root',lambda z:z.__setitem__('root',Q(1).encode()))
    bad('missing_green_layer',lambda z:z['layers'].pop())
    bad('swap_compiler_wrong_sign',lambda z:z['interstage_diagonals'][2].__setitem__(3,Q(1).encode()))
    # Evaluate the tempting two-layer FFT core, with output permutation omitted.
    core=[]
    for j in range(4):
        op=Ops();x=[Q(int(k==j))*Q.decode(c['input_diagonal'][k]) for k in range(4)]
        for r in range(2):
            ys=[green_action(b,x,op) for b in c['layers'][r]]
            x=[(ys[0][k]+ys[1][k])/Q(2) for k in range(4)]
            if r==0:x=[Q.decode(c['interstage_diagonals'][0][k])*x[k] for k in range(4)]
        core.append([Q(4)*v for v in x])
    core_mismatches=[[i,j] for i in range(4) for j in range(4) if core[j][i]!=Q(0,1)**(i*j)]
    assert core_mismatches
    # Independent dense model, test-only; not used by the compiler/executor.
    import sympy as sp
    matrices=[];dense_checks=0
    for layer in c['layers']:
        sm=sp.zeros(4)
        for b in layer:
            W=sp.zeros(4);order=b['order'];ws=[Q.decode(v) for v in b['edge_weights']]
            for k in range(4):W[order[(k+1)%4],order[k]]=sp.Rational(ws[k].a)
            assert W**4==-sp.eye(4)
            sm+=(sp.eye(4)-W).inv()/2;dense_checks+=1
        matrices.append(sm)
    sdiag=lambda d:sp.diag(*[sp.Rational(Q.decode(v).a)+sp.I*sp.Rational(Q.decode(v).b) for v in d])
    M=sdiag(c['input_diagonal'])
    for k,A in enumerate(matrices):
        M=A*M;M=sdiag(c['output_diagonal'] if k==3 else c['interstage_diagonals'][k])*M
    assert M==sp.Matrix(4,4,lambda i,j:sp.I**(i*j))
    results={'status':'AUTHOR_CANDIDATE_PENDING_INDEPENDENT_REVIEW','finite_instance':{'q':2,'B':4,'depth':4},
             'characteristic_zero_field':'Q(i)','positive_root_certificate':positive,
             'negative_primitive_root_passes':True,'fresh_input_vectors':vectors,
             'dense_green_crosschecks':dense_checks,'mutations':mutations,
             'two_layer_core_without_permutation_mismatches':core_mismatches,
             'preparation_scalar_operations':prep,'emitted_storage':memory,
             'scope':'Finite legal full-row macro only. No uniform macro family, arc-code saturation, speedup, novelty, bit/stability or minimal-depth claim.'}
    (out/'EXACT_CONTROL_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({'passed':True,'vectors':vectors,'mutations_rejected':len(mutations),'prep':prep,'online':positive['online_scalar_operations'],'core_mismatches':core_mismatches},indent=2))

if __name__=='__main__':main()
