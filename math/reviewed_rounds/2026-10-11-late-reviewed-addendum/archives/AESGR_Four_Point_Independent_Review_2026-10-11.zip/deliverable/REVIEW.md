# AESGR four point macro independent review

Review date: 11 October 2026 UTC. Existing target: AESGR-20261011, Incoming queue row 29. No spreadsheet or GitHub changes were made.

## Decision

ACCEPT the finite q=2, B=4, depth-4 full Fourier construction. ACCEPT the separately authored and independently tested API repair, under the precise prepared-certificate contract below. The original packet's unqualified “strict data-only certificate validator” description requires this repair. The original compiler-only arithmetic ledger is valid, but it must not be called the whole preparation cost if the structure validator is also run.

This closes only the finite B=4 construction experiment in the permitted Hamiltonian-Green/nonzero-diagonal architecture. The broad AESGR row remains OPEN. This is a classical radix-2 factorization translated into the grammar; it does not close a uniform q family, fixed-depth q^(Theta(q)) size, arc-code saturation, global rewiring, an asymptotic speedup, minimal depth, or novelty. No new theory, row, count or rank is warranted.

The author's original archive is preserved unchanged. Its report, script, source, prior review and historical-review hash are separate objects. The API repair is separately pinned and is not represented as part of the author's original bytes.

## Mathematical verification

Use column vectors and F4[i,j]=zeta^(ij), with indices 0,1,2,3 and zeta in {i,-i}. For an ordered matching ((a,b),(c,d)), the cycle order is (a,c,b,d), with outgoing edge gains (1,1,1,-1). Thus W e_a=e_c, W e_c=e_b, W e_b=e_d, W e_d=-e_a. The source's edge-gain subscript convention is shifted by one; these explicit maps fix the orientation unambiguously.

Every W has W^4=-I. For -W, the fourth power and holonomy are also -1, since B is even. All eight Green denominators are 1-(-1)=2; all edge gains are nonzero. Each branch coefficient is 1/2. The two branches are distinct weighted operators sharing a Hamiltonian order. The core displayed grammar in Sections 2, 5 and 6 does not impose pairwise distinct orders. This review accepts only that core grammar, not the more ambitious arc-code or global-rewiring requirements elsewhere in the source.

The sum S=((I-W)^(-1)+(I+W)^(-1))/2 satisfies S=(I-W^2)^(-1), by direct multiplication by I-W^2. On each ordered pair it is (1/2)[[1,-1],[1,1]]. With E diagonal +1 on a,c and -1 on b,d, H=2SE is [[1,1],[1,-1]] on each pair. There is no interpolation, dense inverse, or root extraction in the compiler or online operator.

For O=((0,2),(1,3)), A=((0,1),(2,3)), X=((0,3),(1,2)), set T=diag(1,1,1,zeta). Direct expansion gives H_A T H_O x=(y0,y2,y1,y3), where y=F4 x. The missing permutation P swaps coordinates 1 and 2. With J=diag(1,1,-1,1), H_X J H_X=2P: the (0,3) pair gives H^2=2I, and the (1,2) pair gives H diag(1,-1) H=2 swap. Consequently

F4 = 8 S_X D3 S_X D2 S_A D1 S_O D_in,

where D_in=diag(1,1,-1,-1), D1=diag(1,-1,1,-zeta), D2=diag(1,1,-1,-1), D3=diag(1,1,1,-1). This agrees exactly with the serialized certificate, including its final output diagonal 8I. Every diagonal is nonzero. The factor order is right-to-left, with two Green branches in every one of four layers. The permutation is paid for by two layers; it is not a free interface. The tempting two-layer core fails six of sixteen target entries.

The independent checker used pairs of Python Fractions, without the candidate's scalar class for its reference arithmetic, and assembled each Green inverse by the finite series (I+W+W^2+W^3)/2. It verifies all sixteen entries, four first-column seed equations, and sixteen Weyl equations for S e_j=e_(j+1 mod 4), D=diag(1,zeta,zeta^2,zeta^3). The algebra proves every valid input, while the finite tests check implementation.

## Executable boundary and repair

Original exact_macro.py SHA256 a71eda0ba196d465ed1ccbbdaea0f867296c2e17af62b5a75e6a1e6efb640d9e.

The original execute function already says to validate the certificate once in preparation. It is therefore a trusted-certificate core. It does not itself claim to prove the Fourier identity. Nonetheless, three concrete defects limit the original packet's strict-validation language:

1. execute(c,[x0,x1,x2,x3,x4]) silently ignores x4 because of zip.
2. A certificate with order entries [0.0,1.0,2.0,3.0] passes validate_structure but execution fails with TypeError.
3. Boolean indices [False,True,2,3] and float dimensions 4.0,2.0,4.0 pass certify.

A further distinction is intentional and remains: changing the final diagonal from 8I to 4I preserves legal structure but destroys Fourier equality. validate_structure accepts it; certify rejects it. Structural admission must never be described as Fourier certification.

The separately supplied repair at repair/exact_macro.py has SHA256 e34654cc71afa5b7b4a8de3850cde1cce682598bcb218105d829c8baf049e782. It adds exact dictionary/list field checks, integer dimensions and index checks excluding bool/float, canonical rational string encodings, and exact four-input admission with a scalar snapshot. This repair was authored separately from this review and then independently tested here. REPAIR.patch preserves the precise diff.

Supported interface:

- compile_macro(root) accepts a normal, unmodified Q instance representing i or -i; the default is i. Arbitrary Python numeric classes, complex floats and malformed Q instances are outside this compiler contract. It emits this fixed finite certificate, compiler ledger, and model-data storage counts. There is no varying-q or varying-B API.
- Imported certificate data must be ordinary JSON-like built-in dictionaries/lists with exactly the listed fields. Scalars are two canonical Fraction strings, such as ["1/2","0"]. Dimensions and indices must be genuine built-in ints. Call validate_structure once before use. It checks the root, cycle permutations and inverse orders, nonzero edges/diagonals/branch coefficients, holonomies, nonzero denominators, and their stored reciprocals.
- If the certificate is not exactly the compiler's known output, call certify when Fourier equality is needed. certify calls validate_structure and evaluates the four basis columns against the Fourier target. It is test/certification work, separate from the compiler and fresh-input online ledgers.
- execute(c,x) then assumes the prepared certificate is unchanged. The caller must not mutate it or the input concurrently. x must be exactly a built-in list or tuple of length four. Each entry must be a built-in int excluding bool, an exact fractions.Fraction, or a normal Q with Fraction components. Floats, builtin complex, generators and subclasses are rejected. The four inputs are admitted and copied before the recurrent calculation. Four exact Q outputs and the arithmetic ledger are returned.
- green_action and target are internal helpers, not separately validated public boundaries. The reference is not a hostile-Python-object sandbox or an immutable prepared-object abstraction.

The repair changes no mathematical coefficient, order, diagonal, certificate, 13 original mutation result, or 675 original-vector result. Its original result status remains historical author-candidate metadata; this review supplies the later scoped decision.

## Cost contract

All arithmetic counts are field operations in Q(i), not the rational numerator/denominator work inside Fraction and not wall-clock runtime. Parsing and canonicalizing rational strings has bit-dependent work. There is no numerical stability or bit-complexity bound.

A Green action uses the two-pass recurrence stated in the author report. The first pass performs three multiplications and three additions; closing the cycle performs two multiplications and one addition; reconstructing the remaining three outputs performs three multiplications and three additions. Therefore one branch costs 8 multiplications and 7 additions, including operations on signs and zero. Residual tests verify (I-W)y=x independently of the Fourier factorization.

Per valid fresh input:

- Eight branches: 64 multiplications and 56 additions.
- Four weighted branch sums: 32 multiplications and 16 additions.
- Five four-entry diagonals: 20 multiplications.
- Total: 116 multiplications, 72 additions, zero field divisions.

Compilation alone: 35 multiplications, 26 subtractions, 1 addition, 9 divisions, and 9 exact field equality tests. The nine divisions prepare the common half and eight individually stored Green reciprocals. This is the author's original valid compiler-only ledger.

One valid structure-validation pass adds 41 multiplications, 8 subtractions and 85 exact scalar comparisons. This was independently checked by instrumenting scalar operator calls. Thus compiler plus one structure pass costs 76 multiplications, 34 subtractions, 1 addition and 9 divisions, with 94 scalar comparisons, before schema/index comparisons, parsing, allocations and traffic. Running certify adds its four executions and reference/covariance tests, and is not included in either number. Validation should not be counted twice merely because certify internally invokes it.

The repair's input shape/type guards, four scalar admission/copy steps, certificate decoding, fixed loops, indices, routing, temporary vectors, and explicit four-output traffic are additional paid word/data work. They do not add field multiplications to the quoted online ledger, but are not asserted free or exactly enumerated as Python machine operations.

The stated 141 slots enumerate model-data scalar/index entries: 32 orders, 32 inverse orders, 32 edge weights, 8 alphas, 8 holonomies, 8 reciprocal denominators, 20 diagonals, 1 root. They exclude schema/dimension metadata, JSON punctuation/strings, object headers, temporaries, parsing storage and rational bit lengths. The fixed-size data/routing work fits the finite O(ell qB) description; this proves no uniform family complexity.

## Fresh verification

The original candidate was inspected and run in an isolated replay directory. The submitted original research and prior-review scripts were never executed; the inherited .py.inert.txt remains inert.

Independent original-candidate controls:

- All 16 matrix entries; 4 seed and 16 Weyl equations.
- Eight independently assembled finite-series Green inverses.
- 200 independently checked Green-action residuals on rational complex vectors.
- 1,350 exact input vectors across both primitive roots, including independent rational complex cases.
- Fresh replay of the author's 675 input vectors, eight SymPy Green cross-checks, 13 rejecting mutations and six-entry missing-permutation regression. Its certificate and result bytes are identical to the delivered originals.

Independent repaired-code controls:

- 105 rejecting boundary/malformed/operator controls, including all three reported boundary defects, field/container shape changes, noncanonical/invalid rationals, wrong input length/type, and a legal non-Fourier operator.
- 1,254 exact vectors across both roots, including admitted mixed int/Fraction/Q inputs.
- The original 675-vector and 13-mutation suite passes unchanged.
- Independently instrumented valid structure-validation cost: 41 multiplications, 8 subtractions, 85 scalar equality tests.

See INDEPENDENT_CONTROL_RESULTS.json and REPAIR_CONTROL_RESULTS.json, plus the reproducible control scripts. Finite testing supplements the explicit algebraic proof; it is not the argument for all inputs or for any family beyond B=4.

## Byte binding and historical distinction

Fresh independent Library materialization on this review run yielded:

- Candidate: libfile_cb4dd383f080819180520b8cebe491d8, version 0, backing file_0000000042888208a64e38b22b8f065b; 50,678 bytes; SHA256 13083b2a5c0f0039b9e54cce253aa857bb261caa560a3e3f60babd2f6b16dba7.
- Original source: libfile_c020faa32d108191af15bd0d1d129e81, version 0, backing file_00000000f5848211b45d22401924d881; 19,421 bytes; SHA256 9a723a072a427aa6c1633981ba0efaf711fd5cc0e5bda8c69da188fab2490daf.
- Prior review archive: libfile_572b1c87905081918559f5d49f4e6560, version 0, backing file_0000000082dc81f5aa1f972ea7a3b333; 28,154 bytes; SHA256 a2698ebc8233cc3877231faba801cb89449accdcea4c6dbc20633767002c04a3.

The author report SHA256 is 15de607ab7caf208b219c4201d3001465c6192a8ec0b7f993b4e7e006ba9c66f. Its fresh control-results SHA256 is 73c763f915f57c62cb9761300d78b7d4f3dff6c8fbcc63680fccb1edd89d7b33. All 17 candidate-manifest payload entries verify, and every archive member matches the independently extracted local file. The candidate manifest omits both its own and the inherited prior-review SHA256SUMS files, contrary to the README's shorthand “except itself”; the pinned archive nevertheless binds both manifests. This review packet's own complete manifest removes that ambiguity.

All eight prior-review/source payloads named in the author binding match the independently retrieved prior archive. The delivered prior AESGR_REVIEW.md hash is e3ce8354ee2af6f1a7173301fadd3820f20047c6ce5f282356dbefb6afcd2b5a. The archive README explicitly distinguishes the historical full-review hash a03541ebf7a31a0f775de5dcf7117d2ca12a1c866d30039acba79763007227fb. Neither this review nor the candidate possesses or purports to verify that historical full-review edition's bytes. The two original source uploads are byte-identical and represent one candidate.

The prior digit-modulus and asymptotic-comparison corrections and conditional theorem are preserved. This finite review does not independently re-prove the historical external Phase 43 theorem or promote its proof status.

## Existing row recommendation

Add a scoped accepted-finite-case note to the existing AESGR-20261011 record only after the parent decides to publish. Retain all prior history and corrections. Record the original candidate pin, this independent review pin, the separately reviewed repair pin, and the precise cost/API distinction. Mark only the B=4 experiment complete. Keep the uniform macro, arc-saturation, global-rewiring and speedup gates open. ROW_PROPOSAL.json gives additive text without applying any cell updates. Reverify the live row identifier before any later write; this review itself did not fetch or mutate the sheet.
