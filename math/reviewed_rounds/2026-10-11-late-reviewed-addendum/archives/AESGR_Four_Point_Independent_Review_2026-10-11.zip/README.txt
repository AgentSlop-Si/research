AESGR four point independent review and separately tested API repair

Start with deliverable/REVIEW.md.
Decision: accept only the finite B=4 identity and the repaired prepared-certificate API.
The broader AESGR macro family remains open. No Sheet or GitHub edits were made.

candidate/ preserves the author's unchanged candidate payload.
download/ preserves the three freshly downloaded Library objects used for independent byte checks.
repair/ contains the separately authored, pinned and independently tested boundary repair.
controls/ contains fresh independent verification programs.
deliverable/ contains findings, results, replay logs and an additive existing-row proposal.

Run from an extracted copy with Python 3 and SymPy installed:
python3 controls/independent_review.py
python3 controls/repair_checks.py
These run only the fresh candidate/repair programs. Never execute the inherited prior-research files.
Inherited programs retain .py.inert.txt filenames. Reruns write only isolated replay/results locations
and regenerate the repair's unchanged certificate/result files.

SHA256SUMS.txt binds every packet file except the top-level manifest itself, including nested manifests.
