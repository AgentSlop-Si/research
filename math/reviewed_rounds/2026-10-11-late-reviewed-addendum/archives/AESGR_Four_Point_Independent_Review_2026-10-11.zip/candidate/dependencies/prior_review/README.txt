AESGR conditional Green macro review

Start with AESGR_REVIEW.md. The proposed fast macro family remains unproved.
The report retains the valid conditional implication and records the digit-modulus and asymptotic-comparison corrections.

Two identical original uploads are included for reproducibility, representing one research candidate.
Run python3 exact_controls.py from the extracted folder to repeat the fresh exact checks. The checker uses only the Python standard library and does not execute the submitted research files.
Check archive member hashes against SHA256SUMS.txt.

The mathematical review was completed before the sheet update. Original full-review SHA-256: a03541ebf7a31a0f775de5dcf7117d2ca12a1c866d30039acba79763007227fb. This delivery edition omits account-specific identifiers and records the completed queue entry.
The external OpenAI theorem statement/model was checked against its official source; its proof was not independently verified.
