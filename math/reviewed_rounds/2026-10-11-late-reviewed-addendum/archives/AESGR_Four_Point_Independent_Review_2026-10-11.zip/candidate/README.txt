AESGR exact four point Green macro

Start with REPORT.md. This is a finite author candidate awaiting independent review.
The existing AESGR-20261011 row stays open for uniform macro existence.

The exact characteristic-zero construction has q=2, B=4 and four Green-sum layers.
All branch holonomies are -1. Every denominator is 2. Every diagonal is nonzero.
The output permutation is realized by two of the layers, not assumed free.

MACRO_CERTIFICATE.json contains all data.
exact_macro.py is fresh code for this packet. It uses standard-library fractions
for the compiler/executor and SymPy only for a separate dense cross-check.
Run: python3 exact_macro.py
It recreates MACRO_CERTIFICATE.json, EXACT_CONTROL_RESULTS.json and prints a summary.
Inherited programs in dependencies remain inert and must not be executed as part
of this check. Their original bytes are preserved under .py.inert.txt names.

ROW_PROPOSAL.json requests only an additive candidate note for the existing row.
No Sheet or GitHub edits occurred. No new theory/count/rank or novelty claim.
SHA256SUMS.txt binds every payload file except itself.
