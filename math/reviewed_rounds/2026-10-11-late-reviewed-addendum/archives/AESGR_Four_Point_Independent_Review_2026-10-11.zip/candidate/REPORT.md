# AESGR exact four point Green macro

Date: 11 October 2026 UTC. Status: author candidate awaiting independent review.
Target: the existing Incoming queue entry AESGR-20261011, row 29.

## Result and scope

The source's first q=2, B=4 experiment has an explicit exact full-row construction in its weighted Hamiltonian Green grammar. It uses four layers, two nonzero Green branches per layer, and only nonzero diagonal interfaces. All eight branch holonomies are -1, so every Green denominator is exactly 2. No external output permutation is assumed free: two of the four layers implement it inside the permitted grammar.

This is a finite constructive certificate for the architecture in source Sections 2, 5, 6 and 16. It supplies all sixteen entries of F4, not just selected rows. It does not establish the all-q macro conjecture, the exp(Theta(q log q)) size scale, injective arc-code saturation, the global-rewiring condition, an asymptotic speedup, or novelty. Its mechanism is a classical four-point radix-2 factorization translated into Green sums. No claim of minimal depth is made.

The source's incorrect digit truncation is not used. The accepted conditional complexity implication and the prior corrections remain unchanged. The broader row must stay open.

## Exact conventions

Work over K=Q(zeta), where zeta has order four, so zeta^2=-1. Either primitive fourth root is supported. Define F4[i,j]=zeta^(ij), with coordinates 0,1,2,3. The positive complex test chooses zeta=i.

For an ordered partition into two pairs M=((a,b),(c,d)), let W_M be the weighted Hamiltonian cycle with order (a,c,b,d) and successive edge gains (1,1,1,-1):

- W e_a=e_c
- W e_c=e_b
- W e_b=e_d
- W e_d=-e_a

Thus W^4=-I and both W and -W are legal nonzero weighted Hamiltonian cycles. Their holonomies are -1. Set

S_M = ((I-W_M)^(-1) + (I+W_M)^(-1))/2.

Each S_M is exactly a sum of q=2 legal Green inverses, with alpha_1=alpha_2=1/2. The two branches may share an order; the source's core macro grammar does not require distinct orders.

Since all factors are polynomials or inverses of polynomials in W,

S_M=(I-W_M^2)^(-1).

This identity follows by multiplying the sum by I-W^2; no singular inverse is introduced. On either ordered pair (a,b) or (c,d), W^2 has matrix [[0,-1],[1,0]], and therefore S_M has matrix (1/2)[[1,-1],[1,1]].

Let E_M be diagonal +1 on a,c and -1 on b,d. Then

H_M=2 S_M E_M

is the ordinary Hadamard butterfly [[1,1],[1,-1]] on both pairs. This proves the conversion without numerical fitting or root extraction.

## Four layer construction

Use these matchings and cycle orders:

- O=((0,2),(1,3)), order (0,1,2,3)
- A=((0,1),(2,3)), order (0,2,1,3)
- X=((0,3),(1,2)), order (0,1,3,2)

In each order the W branch gains are (1,1,1,-1), and the -W branch gains are (-1,-1,-1,1).

Define diagonal matrices

D_in=diag(1,1,-1,-1)
D1=diag(1,-1,1,-zeta)
D2=diag(1,1,-1,-1)
D3=diag(1,1,1,-1)
D_out=8I.

The exact identity is

F4 = D_out S_X D3 S_X D2 S_A D1 S_O D_in.

Products act from right to left. This is depth ell=4, with exactly q=2 branches in every layer and no permutation interface. Every diagonal entry is nonzero.

### Proof including the output permutation

Let T=diag(1,1,1,zeta). Acting on x, H_O gives

(x0+x2, x1+x3, x0-x2, x1-x3).

H_A T H_O then gives Fourier outputs in the order (y0,y2,y1,y3). If P swaps coordinates 1 and 2, the standard exact identity is

F4=P H_A T H_O.

Take J=diag(1,1,-1,1). On pair (0,3), J is the identity; on pair (1,2), it is diag(1,-1). The two-by-two identities H^2=2I and H diag(1,-1) H=2[[0,1],[1,0]] imply

P=(1/2) H_X J H_X.

Substitute H_M=2S_M E_M into P H_A T H_O. The scalar is (1/2)*2^4=8. The diagonal factors are precisely

E_X J=D3, E_X=D2, E_A T=D1, E_O=D_in.

This proves the displayed four-layer identity for every input. In particular, M e0=1 and M S=D M, where S e_j=e_(j+1 mod 4) and D=diag(1,zeta,zeta^2,zeta^3). The fresh checker also verifies all four seed and all sixteen Weyl equations directly.

## Literal execution and cost

The delivered exact_macro.py contains a deterministic coefficient/order compiler, a two-pass cyclic recurrent executor, a strict data-only certificate validator and fresh controls. It never imports or runs inherited research programs. MACRO_CERTIFICATE.json supplies every cycle, edge, scalar, inverse order and interface.

For one branch with cycle order v0,...,v3 and edge gains w0,...,w3, solve y[vk]-w[k-1]y[v(k-1)]=x[vk]. First propagate the constant term b of y[v3] from an unknown y[v0]: initialize b=0 and perform b=x[vk]+w[k-1]b for k=1,2,3. Then

y[v0]=(x[v0]+w3*b)/(1-h).

A second pass reconstructs y[v1],y[v2],y[v3]. The reciprocal of 1-h is prepared once. This uses 8 scalar multiplications and 7 additions per branch in the literal counted program, including operations on zero and signs. No dense inverse, matrix product, hidden FFT or search is performed in online execution.

The complete literal online ledger is:

- Eight Green actions: 64 multiplications and 56 additions
- Four weighted two-branch sums: 32 multiplications and 16 additions
- Five four-entry diagonals: 20 multiplications
- Total per fresh input: 116 multiplications, 72 additions, zero divisions

The coefficient compiler, including its root-order multiplication, uses 35 multiplications, 26 subtractions, 1 addition and 9 divisions. It explicitly checks the supplied root and all eight denominators. Its nine exact equality tests are additional to the arithmetic ledger. Constants are built from 0,1 and the supplied zeta; no algebraic extension or root extraction is needed. The first division prepares 1/2, and eight divisions prepare branch reciprocals; sharing these equal reciprocals would be an optional optimization, not an uncharged assumption.

The emitted coefficient/order data occupy 141 scalar/index slots: 32 order indices, 32 inverse indices, 32 edge gains, 8 alpha values, 8 holonomies, 8 reciprocals, 20 diagonal values and 1 supplied root. All repeated data are counted. Generating these arrays, the fixed-length loops, routing, temporary vectors, four input reads and four output writes take a fixed finite number of word operations, O(ell qB). The 141-slot count concerns emitted model data, not Python object bytes; temporary arithmetic/storage and certificate parsing are separate linear-size overhead. Exact rational Python execution is a demonstrator, not a measured unit-cost machine or a bit-complexity claim.

For this fixed finite instance these are explicit costs. They provide no bound for an unconstructed varying-q family. The circuit is substantially more expensive than an ordinary four-point FFT; no practical speed claim follows.

## Fresh controls and inherited evidence

The author-generated script passes:

- Characteristic-zero full 4x4 equality, all sixteen entries
- Four first-column and sixteen Weyl equations
- Both primitive fourth-root conventions
- 675 exact fresh-input vectors, including rational complex cases
- Eight independently assembled dense Green inverses in SymPy, test-only
- Thirteen malformed or mathematically wrong mutation controls, all rejected

Mutations cover the Fourier sign, omitted twiddle, wrong global scale, singular holonomy, zero edge, repeated vertex, inverse-order corruption, wrong reciprocal, disabled branch, zero diagonal, nonprimitive root, missing layer and wrong swap-compilation sign.

A two-layer radix-2 core with the output permutation omitted fails exactly six of sixteen target entries. This is retained as a regression control. The four-layer construction pays for that missing permutation and passes.

The full identity is proved algebraically above; finite vector tests are additional implementation checks. The delivered SymPy dense-inverse comparison is fresh validation code, never a step of the macro compiler or online algorithm.

The prior review's digit-modulus counterexample, nonzero-coefficient warning, rational Green test and corrected conditional theorem are retained as source evidence. They were read and their hashes verified, not replayed or newly claimed. The inherited Python file is included under an inert .py.inert.txt filename.

## Source binding and existing row proposal

The original AESGR source has SHA256 9a723a072a427aa6c1633981ba0efaf711fd5cc0e5bda8c69da188fab2490daf and Library identity libfile_c020faa32d108191af15bd0d1d129e81. Its duplicate upload is one source, not a second theory.

The retrieved prior review archive is AESGR_review_2026-10-10.zip, Library libfile_572b1c87905081918559f5d49f4e6560, SHA256 a2698ebc8233cc3877231faba801cb89449accdcea4c6dbc20633767002c04a3. Its delivered AESGR_REVIEW.md has SHA256 e3ce8354ee2af6f1a7173301fadd3820f20047c6ce5f282356dbefb6afcd2b5a. The archive README explains that this delivered edition omits account identifiers and records the finished queue entry; it separately cites the historical full-review hash a03541ebf7a31a0f775de5dcf7117d2ca12a1c866d30039acba79763007227fb found in the row. This packet does not claim to possess bytes of that historical full-review edition.

ROW_PROPOSAL.json proposes only an additive pending-review note to existing AESGR-20261011. No new row, rank, catalogue count, theory count or acceptance is proposed. No Sheet or GitHub write was performed.

Independent review should check the exact factor orientation, supplied-root sign, cycle convention, permutation compiler, all cost boundaries and the serialized validator. If accepted, the finite B=4 experiment may be recorded complete. The next genuine construction target is a further legal all-row instance, or a bounded proof of a reusable pattern; a growing-depth FFT translation would not meet the uniform fixed-depth conjecture.
