"""Independent checks of the fixed-boundary repair, including original regressions."""
import copy, hashlib, importlib.util, json, subprocess, sys
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
P=Path(__file__).resolve().parents[1]
R=P/'repair'
path=R/'exact_macro.py'
assert hashlib.sha256(path.read_bytes()).hexdigest()=='e34654cc71afa5b7b4a8de3850cde1cce682598bcb218105d829c8baf049e782'
spec=importlib.util.spec_from_file_location('repaired',path);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
c,prep,storage=r.compile_macro()
checks=[]
def reject(name,fn):
 try:fn()
 except ValueError as e:checks.append({'name':name,'rejected':True,'exception':str(e)});return
 except Exception as e:raise AssertionError(f'{name}: wrong exception {type(e).__name__}: {e}') from e
 raise AssertionError(name+' was accepted')
def mutation(name,edit):
 z=copy.deepcopy(c);edit(z);reject(name,lambda:r.validate_structure(z))
mutation('float_order',lambda z:z['layers'][0][0].__setitem__('order',[0.0,1.0,2.0,3.0]))
mutation('bool_order',lambda z:z['layers'][0][0].__setitem__('order',[False,True,2,3]))
mutation('float_inverse_order',lambda z:z['layers'][0][0].__setitem__('inverse_order',[0.0,1.0,2.0,3.0]))
mutation('bool_inverse_order',lambda z:z['layers'][0][0].__setitem__('inverse_order',[False,True,2,3]))
for key in ('B','q','depth'):
 mutation('float_'+key,lambda z,key=key:z.__setitem__(key,float(z[key])))
 mutation('bool_'+key,lambda z,key=key:z.__setitem__(key,True))
mutation('extra_top_field',lambda z:z.__setitem__('free_permutation',[0,2,1,3]))
mutation('extra_branch_field',lambda z:z['layers'][0][0].__setitem__('junk',None))
mutation('missing_top_field',lambda z:z.pop('root'))
mutation('missing_branch_field',lambda z:z['layers'][0][0].pop('alpha'))
mutation('tuple_diagonal',lambda z:z.__setitem__('input_diagonal',tuple(z['input_diagonal'])))
mutation('tuple_layer',lambda z:z['layers'].__setitem__(0,tuple(z['layers'][0])))
for text in ('1.0','1/1',' 1','+1','01','nan','inf','1/0','-0'):
 mutation('noncanonical_scalar_'+repr(text),lambda z,text=text:z['input_diagonal'].__setitem__(0,[text,'0']))
for root in ([],['0'],['0','1','0'],[0,1],None,{'a':'0','b':'1'}):
 mutation('bad_root_shape_'+repr(root),lambda z,root=root:z.__setitem__('root',root))
for n in (0,1,3,5,8):reject('input_length_'+str(n),lambda n=n:r.execute(c,[0]*n))
for x in ('0000',{0:0,1:0,2:0,3:0},iter([0]*4),None):reject('input_container_'+str(type(x)),lambda x=x:r.execute(c,x))
for x in (True,0.0,0j,'0',None,[],{}):reject('input_scalar_'+repr(x),lambda x=x:r.execute(c,[x,0,0,0]))
q=r.Q(1);q.a=1;reject('mutated_Q_nonfraction',lambda:r.execute(c,[q,0,0,0]))
class SubQ(r.Q):pass
reject('subclass_Q',lambda:r.execute(c,[SubQ(1),0,0,0]))
class SubList(list):pass
reject('subclass_list',lambda:r.execute(c,SubList([0,0,0,0])))
# Systematic JSON leaf/type probes: invalid replacement of all schema/container nodes.
shapes=[None,True,4.0,'bad',{},[]]
paths=[('layers',),('input_diagonal',),('interstage_diagonals',),('output_diagonal',),('layers',0),('layers',0,0),('layers',0,0,'order'),('layers',0,0,'inverse_order'),('layers',0,0,'edge_weights')]
for path_ in paths:
 for value in shapes:
  def edit(z,path_=path_,value=value):
   for key in path_[:-1]:z=z[key]
   z[path_[-1]]=copy.deepcopy(value)
  mutation('shape_'+repr(path_)+'_'+repr(value),edit)
# All valid API scalar variants and vectors for both primitive roots.
def pair(q):return F(q.encode()[0]),F(q.encode()[1])
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def add(a,b):return a[0]+b[0],a[1]+b[1]
def power(a,n):
 v=(F(1),F(0))
 for _ in range(n):v=mul(v,a)
 return v
vectors=0
for s in (1,-1):
 c,_,_=r.compile_macro(r.Q(0,s));r.validate_structure(c);r.certify(c)
 for vals in product([r.Q(0),r.Q(1),r.Q(-1),r.Q(0,1),r.Q(0,-1)],repeat=4):
  y,count=r.execute(c,vals);x=[pair(v) for v in vals]
  wanted=[]
  for i in range(4):
   v=(F(0),F(0))
   for j in range(4):v=add(v,mul(power((F(0),F(s)),i*j),x[j]))
   wanted.append(v)
  assert [pair(v) for v in y]==wanted
  assert count=={'multiplications':116,'additions':72};vectors+=1
 for vals in ([1,2,3,4],(F(1,3),F(2,7),3,r.Q(4,5))):
  got,count=r.execute(c,vals)
  assert got==r.target(r.Q(0,s),[r.Q(v) for v in vals]);vectors+=1
# Structure alone intentionally permits legal operators other than Fourier.
z=copy.deepcopy(c);z['output_diagonal']=[['4','0']]*4
r.validate_structure(z);reject('valid_operator_wrong_DFT',lambda:r.certify(z))
# Count field operations in the valid preparation validator independently of its Ops ledger.
c,_,_=r.compile_macro();counts=Counter();originals={}
for method in ('__mul__','__rsub__','__sub__','__eq__'):
 old=getattr(r.Q,method);originals[method]=old
 def wrapper(self,o,old=old,method=method):counts[method]+=1;return old(self,o)
 setattr(r.Q,method,wrapper)
r.validate_structure(c)
for method,old in originals.items():setattr(r.Q,method,old)
assert counts['__mul__']==41 and counts['__rsub__']+counts['__sub__']==8 and counts['__eq__']==85
# Rerun original author's complete suite on repaired file.
a=subprocess.run([sys.executable,str(path)],capture_output=True,text=True,check=True)
(P/'deliverable/REPAIR_REPLAY_LOG.txt').write_text(a.stdout)
results=json.loads((R/'EXACT_CONTROL_RESULTS.json').read_text())
assert results==json.loads((P/'candidate/EXACT_CONTROL_RESULTS.json').read_text())
assert (R/'MACRO_CERTIFICATE.json').read_bytes()==(P/'candidate/MACRO_CERTIFICATE.json').read_bytes()
output={'status':'ACCEPT_FOR_DOCUMENTED_PREPARED_CERTIFICATE_API','repair_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
 'api_rejections':checks,'api_rejections_count':len(checks),'exact_vectors_both_roots':vectors,
 'validator_operator_counts':dict(counts),'validator_exact_scalar_comparisons':85,
 'original_13_mathematical_mutations_rejected':len(results['mutations']),
 'original_675_vectors_passed':results['fresh_input_vectors'],'original_certificate_and_results_unchanged':True,
 'schema_validation_implies_fourier':False,'certificate_immutability_is_caller_precondition':True,
 'compiler_plus_structure_validation_arithmetic':{'multiplications':76,'subtractions':34,'additions':1,'divisions':9},
 'online_arithmetic':{'multiplications':116,'additions':72,'divisions':0},
 'additional_nonfield_costs':'Paid JSON/rational parsing, guards and comparisons, fixed routing/loops/storage, four input admission/copy steps; no bit complexity or measured runtime claim.'}
(P/'deliverable/REPAIR_CONTROL_RESULTS.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='api_rejections'},indent=2))
