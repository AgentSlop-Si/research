"""Independent exact review. Runs only the fresh candidate, never inherited programs."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import copy, hashlib, importlib.util, json, random, shutil, subprocess, sys, zipfile
P=Path(__file__).resolve().parents[1]
C=P/'candidate'
OUT=P/'deliverable'
OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('fresh_candidate',C/'exact_macro.py')
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
Z=(F(0),F(0)); U=(F(1),F(0)); I=(F(0),F(1))
def dec(v):return F(v[0]),F(v[1])
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[0],-a[1]
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def power(a,n):
 r=U
 for _ in range(n):r=mul(r,a)
 return r
def mzero():return [[Z for j in range(4)] for i in range(4)]
def eye():return [[U if i==j else Z for j in range(4)] for i in range(4)]
def mm(A,B):return [[sumq(mul(A[i][k],B[k][j]) for k in range(4)) for j in range(4)] for i in range(4)]
def sumq(xs):
 r=Z
 for x in xs:r=add(r,x)
 return r
def ma(A,B):return [[add(A[i][j],B[i][j]) for j in range(4)] for i in range(4)]
def ms(a,A):return [[mul(a,A[i][j]) for j in range(4)] for i in range(4)]
def diag(d):return [[dec(d[i]) if i==j else Z for j in range(4)] for i in range(4)]
def mv(A,x):return [sumq(mul(A[i][j],x[j]) for j in range(4)) for i in range(4)]
def emit(v):return [str(v[0]),str(v[1])]
def green(b):
 W=mzero();order=b['order']
 for k in range(4):W[order[(k+1)%4]][order[k]]=dec(b['edge_weights'][k])
 w2=mm(W,W);w3=mm(w2,W);w4=mm(w3,W)
 assert w4==ms(neg(U),eye())
 G=ms((F(1,2),F(0)),ma(ma(eye(),W),ma(w2,w3)))
 assert mm(ma(eye(),ms(neg(U),W)),G)==eye()
 return G,W
cert=json.loads((C/'MACRO_CERTIFICATE.json').read_text())
assembled=diag(cert['input_diagonal']);greens=[]
for k,layer in enumerate(cert['layers']):
 A=mzero()
 for b in layer:
  G,W=green(b);greens.append((b,G,W));A=ma(A,ms(dec(b['alpha']),G))
 assembled=mm(A,assembled)
 assembled=mm(diag(cert['output_diagonal'] if k==3 else cert['interstage_diagonals'][k]),assembled)
F4=[[power(I,i*j) for j in range(4)] for i in range(4)]
assert assembled==F4
assert all(assembled[i][0]==U for i in range(4))
assert all(assembled[i][(j+1)%4]==mul(power(I,i),assembled[i][j]) for i in range(4) for j in range(4))
rng=random.Random(202610111713)
residual_checks=0
for b,G,W in greens:
 for n in range(25):
  x=[(F(rng.randrange(-9,10),rng.randrange(1,9)),F(rng.randrange(-9,10),rng.randrange(1,9))) for j in range(4)]
  qx=[e.Q(*v) for v in x]
  op=e.Ops();actual=[dec(v.encode()) for v in e.green_action(b,qx,op)]
  assert actual==mv(G,x)
  assert mv(ma(eye(),ms(neg(U),W)),actual)==x
  assert dict(op.counts)=={'multiplications':8,'additions':7}
  residual_checks+=1
vectors=0
for sign in (1,-1):
 root=(F(0),F(sign));c,prep,storage=e.compile_macro(e.Q(*root))
 assert prep=={'multiplications':35,'subtractions':26,'additions':1,'divisions':9}
 assert sum(storage.values())==141
 vecs=list(product([Z,U,neg(U),I,neg(I)],repeat=4))
 for n in range(50):
  vecs.append(tuple((F(rng.randrange(-101,102),rng.randrange(1,40)),F(rng.randrange(-101,102),rng.randrange(1,40))) for j in range(4)))
 for x in vecs:
  qx=[e.Q(*v) for v in x];y,counts=e.execute(c,qx)
  assert [dec(v.encode()) for v in y]==[sumq(mul(power(root,i*j),x[j]) for j in range(4)) for i in range(4)]
  assert counts=={'multiplications':116,'additions':72}
  vectors+=1
# Fresh author program rerun in isolated output directory after source inspection.
run=P/'author_rerun';run.mkdir(exist_ok=True)
shutil.copyfile(C/'exact_macro.py',run/'exact_macro.py')
p=subprocess.run([sys.executable,str(run/'exact_macro.py')],capture_output=True,text=True,check=True)
(OUT/'AUTHOR_REPLAY_LOG.txt').write_text(p.stdout)
rerun=json.loads((run/'EXACT_CONTROL_RESULTS.json').read_text())
assert rerun==json.loads((C/'EXACT_CONTROL_RESULTS.json').read_text())
assert (run/'MACRO_CERTIFICATE.json').read_bytes()==(C/'MACRO_CERTIFICATE.json').read_bytes()
# Additional API probes, separated from mathematical rejection tests.
findings=[]
c,_,_=e.compile_macro();x=[e.Q(k) for k in range(4)]
findings.append({'name':'fifth_input_silently_ignored','observed':e.execute(c,x+[e.Q(999)])[0]==e.execute(c,x)[0]})
z=copy.deepcopy(c);z['layers'][0][0]['order']=[float(v) for v in z['layers'][0][0]['order']]
e.validate_structure(z)
try:e.execute(z,x)
except TypeError as ex:findings.append({'name':'float_indices_validate_then_execute_TypeError','observed':True,'exception':str(ex)})
z=copy.deepcopy(c);z['layers'][0][0]['order']=[False,True,2,3];z['B']=4.0;z['q']=2.0;z['depth']=4.0
e.certify(z);findings.append({'name':'boolean_indices_and_float_dimensions_certified','observed':True})
z=copy.deepcopy(c);z['interstage_diagonals'][0][3]=e.Q(0,1).encode()
e.validate_structure(z)
try:e.certify(z)
except ValueError:findings.append({'name':'structure_guard_does_not_prove_DFT','observed':True})
# Independently validate all archive/member/source pins.
sha=lambda x:hashlib.sha256(x).hexdigest()
records=[]
expected={
 'AESGR_Four_Point_Exact_Macro_Candidate_2026-10-11.zip':'13083b2a5c0f0039b9e54cce253aa857bb261caa560a3e3f60babd2f6b16dba7',
 'AESGR_Fourier_Theory_2026-10-11.md':'9a723a072a427aa6c1633981ba0efaf711fd5cc0e5bda8c69da188fab2490daf',
 'AESGR_review_2026-10-10.zip':'a2698ebc8233cc3877231faba801cb89449accdcea4c6dbc20633767002c04a3'}
for fn,h in expected.items():
 b=(P/'download'/fn).read_bytes();assert sha(b)==h;records.append({'name':fn,'bytes':len(b),'sha256':h})
manifest=[]
for line in (C/'SHA256SUMS.txt').read_text().splitlines():
 h,fn=line.split(maxsplit=1);fn=fn.lstrip('*');assert sha((C/fn).read_bytes())==h;manifest.append(fn)
with zipfile.ZipFile(P/'download/AESGR_Four_Point_Exact_Macro_Candidate_2026-10-11.zip') as z:
 assert set(z.namelist())==set(manifest)|{'SHA256SUMS.txt','dependencies/prior_review/SHA256SUMS.txt'}
 assert all(z.read(n)==(C/n).read_bytes() for n in z.namelist())
with zipfile.ZipFile(P/'download/AESGR_review_2026-10-10.zip') as z:
 b=json.loads((C/'SOURCE_BINDING.json').read_text())
 for m in b['prior_review']['members_verified']:
  raw=z.read(m['original_member']);assert sha(raw)==m['sha256'];assert raw==(C/m['included_member']).read_bytes()
 assert sha(z.read('AESGR_REVIEW.md'))=='e3ce8354ee2af6f1a7173301fadd3820f20047c6ce5f282356dbefb6afcd2b5a'
 assert 'a03541ebf7a31a0f775de5dcf7117d2ca12a1c866d30039acba79763007227fb' in z.read('README.txt').decode()
assert (P/'download/AESGR_Fourier_Theory_2026-10-11.md').read_bytes()==(C/'dependencies/AESGR_Fourier_Theory_2026-10-11.md').read_bytes()
result={'finite_identity':'ACCEPT','unqualified_strict_validator_and_full_preparation_claim':'REPAIR',
 'independent_matrix_entries':16,'independent_seed_entries':4,'independent_weyl_entries':16,
 'independent_finite_series_green_inverses':8,'independent_recurrent_residual_checks':residual_checks,
 'independent_exact_input_vectors':vectors,'primitive_roots_tested':['i','-i'],
 'author_replayed_vectors':rerun['fresh_input_vectors'],'author_replayed_mutations':len(rerun['mutations']),
 'author_replay_controls_byte_identical':(run/'EXACT_CONTROL_RESULTS.json').read_bytes()==(C/'EXACT_CONTROL_RESULTS.json').read_bytes(),
 'online_arithmetic':{'multiplications':116,'additions':72,'divisions':0},
 'compiler_arithmetic':prep,'structure_validation_additional_arithmetic':{'multiplications':41,'subtractions':8},
 'model_data_scalar_index_slots':sum(storage.values()),'api_findings':findings,
 'independent_download_pins':records,'candidate_manifest_members_verified':len(manifest),
 'prior_review_members_verified':len(b['prior_review']['members_verified']),
 'inherited_programs_executed':False,'external_edits':[]}
(OUT/'INDEPENDENT_CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
