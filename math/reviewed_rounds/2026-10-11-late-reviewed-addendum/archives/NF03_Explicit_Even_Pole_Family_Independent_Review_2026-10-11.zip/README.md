# NF-03 independent review packet

11 October 2026. Scoped ACCEPT of the exact candidate proof pinned in the review.

Read deliverable/INDEPENDENT_REVIEW.md for the component verdicts and independent proof audit. deliverable/EXISTING_ROW_PROPOSAL.json proposes a scoped update to existing NF-03 only. No Sheet or GitHub edit was performed.

The review accepts the closed-form all-even legal family, its explicit but poor bounds, the certified exhaustive preparation contract, and the exact-rational quadratic-scalar application/relative-error ledger. It does not certify useful conditioning, practical preparation, a production executor, a fast FFT, h-pole optimality, universal t=1, or novelty.

Independent evidence reproduced the 35 good and 4 bad author reductions, added 5 lengths, checked 88,556 exact target entries, verified norm polynomials at N=4,6,8,10 by an independent embedding-product route, checked complex Rouché certificates and negative controls, and verified 16 signed-resolvent recurrences. Neither the author's script nor inherited programs were executed. The enormous complete root grid was not run.

To rerun this review's newly authored controls, use Python with SymPy installed:

    python controls/independent_checks.py

The script uses the copied author results in evidence/AUTHOR_RESULTS.json. No external network or original executable is required.

Every payload is covered by MANIFEST.json and SHA256SUMS. The submitted candidate Library file was independently read back and matched byte-for-byte before this packet was produced.
