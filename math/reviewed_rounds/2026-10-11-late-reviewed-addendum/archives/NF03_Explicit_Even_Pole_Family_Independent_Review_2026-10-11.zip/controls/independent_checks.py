#!/usr/bin/env python3
"""Independent NF-03 audit. No author or inherited script imports/execution."""
import json, math, hashlib, pathlib, time
from fractions import Fraction as F
import sympy as sp
BASE=pathlib.Path(__file__).resolve().parents[1]
AUTHOR=BASE.parent/'even_pole_family_1656'
z,t,q=sp.symbols('z t q')
START=time.time()

def pn(n):
    # Build by the defining product, with coefficients obtained independently by SymPy.
    raw=sp.Poly(sp.prod(z-q**k for k in range(n)),z)
    return sp.Poly(sum(raw.nth(j)*q**((n*(n-1)-j*(j-1))//2)*z**j for j in range(n+1)),z)

def modular(N,p,r):
    assert sp.isprime(p) and sp.n_order(r,p)==N
    h=N//2;tt=pow(2,10*N**3+2,p)
    # Evaluate each product directly in the finite field (no imported polynomial code).
    def one(n):
        R=sp.Poly(1,z,modulus=p)
        for k in range(n):R*=sp.Poly(z-pow(r,k,p),z,modulus=p)
        return sp.Poly(sum(int(R.nth(j))*pow(r,(n*(n-1)-j*(j-1))//2,p)*z**j for j in range(n+1)),z,modulus=p)
    B=sp.Poly(z*one(h).as_expr()+tt*one(h-1).as_expr(),z,modulus=p)
    dg=sp.gcd(B,B.diff()).degree();jg=sp.gcd(B,sp.Poly(z**N+1,z,modulus=p)).degree()
    residual=[sum(int(B.nth(j))*pow(r,(s+j)*(s+j-1)//2,p) for j in range(h+2))%p for s in range(N-h-1)]
    assert not any(residual)
    return {'N':N,'p':p,'q':r,'parameter_mod_p':tt,'derivative_gcd_degree':dg,'forbidden_gcd_degree':jg,'degree':B.degree(),'constant_nonzero':bool(B.nth(0)),'all_recurrences_zero':True}

saved_path=BASE/'evidence/AUTHOR_RESULTS.json'
if not saved_path.exists():saved_path=AUTHOR/'controls/RESULTS.json'
saved=json.loads(saved_path.read_text())
replayed=[]
for key in ('modular_cases','failed_reductions_not_characteristic_zero_counterexamples'):
    for row in saved[key]:
        got=modular(row['N'],row['p'],row['q'])
        for k,v in got.items():assert v==row[k],(k,got,row)
        replayed.append(got)

new=[]
for N in (66,70,98,130,258):
    k=1
    while True:
        p=k*N+1;k+=1
        if not sp.isprime(p):continue
        r=pow(int(sp.primitive_root(p)),(p-1)//N,p)
        got=modular(N,p,r);new.append(got)
        if got['derivative_gcd_degree']==got['forbidden_gcd_degree']==0:break

# Target checks independently use exponents of the actual signed shift entries.
entries=0
for N in range(4,82,2):
    for i in range(N):
        for j in range(N):
            k=(i-j)%N
            phase=(N//2 if i<j else 0)+k*(k-1)//2-i*(i-1)//2-j*(j+1)//2
            assert (phase+i*j)%N==0
            entries+=1

# Norm computed as an explicit product of cyclotomic automorphism images,
# rather than the author's field-norm resultant call.
norms=[]
for N in (4,6,8,10):
    h=N//2;phi=sp.Poly(sp.cyclotomic_poly(N,q),q)
    def red(expr):return sp.rem(sp.Poly(sp.expand(expr),q),phi).as_expr().expand()
    B=red(z*pn(h).as_expr()+t*pn(h-1).as_expr())
    D=red(sp.resultant(B,sp.diff(B,z),z));J=red(sp.resultant(B,z**N+1,z));A=red(D*J)
    H=sp.Integer(1)
    for k in range(1,N):
        if math.gcd(k,N)==1:H=red(H*red(A.subs(q,q**k)))
    assert not H.has(q)
    Hp=sp.Poly(H,t);co=[int(c) for c in Hp.all_coeffs()]
    if N!=10:
        ref=next(x for x in saved['small_exact_norms'] if x['N']==N)
        assert co==[int(c) for c in ref['norm_coefficients_descending']]
    assert sum(map(abs,co))<=2**(10*N**3)
    assert Hp.eval(0)!=0 # Negative t=0 control: legal nonzero-root guard fails separately.
    # Reciprocal polynomial is NOT monic: leading coefficient B(0), constant one.
    Br=sp.Poly(B,z);rev=sp.Poly(sum(Br.nth(j)*z**(h+1-j) for j in range(h+2)),z)
    assert sp.expand(rev.nth(h+1)-Br.nth(0))==0 and rev.nth(0)==1
    assert red(sp.discriminant(rev.as_expr(),z)-sp.discriminant(B,z))==0
    assert red(sp.resultant(rev.as_expr(),z**N+1,z)-J)==0
    norms.append({'N':N,'degree':Hp.degree(),'coefficient_l1':str(sum(map(abs,co))),'coefficient_sha256':hashlib.sha256(json.dumps(co,separators=(',',':')).encode()).hexdigest(),'explicit_embedding_product':True,'reciprocal_degree_leading_constant_and_guards_checked':True})

# Gaussian-rational arithmetic for complex certified disk tests.
class C:
    def __init__(self,a=0,b=0):self.a=F(a);self.b=F(b)
    def __add__(self,v):
        if not isinstance(v,C):v=C(v)
        return C(self.a+v.a,self.b+v.b)
    __radd__=__add__
    def __neg__(self):return C(-self.a,-self.b)
    def __sub__(self,v):return self+-v if isinstance(v,C) else self+C(-v)
    def __mul__(self,v):
        if not isinstance(v,C):v=C(v)
        return C(self.a*v.a-self.b*v.b,self.a*v.b+self.b*v.a)
    __rmul__=__mul__
    def __pow__(self,n):
        out=C(1)
        for _ in range(n):out=out*self
        return out
    def norm2(self):return self.a*self.a+self.b*self.b
    def show(self):return [str(self.a),str(self.b)]

def mul(a,b):
    c=[C() for _ in range(len(a)+len(b)-1)]
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]=c[i+j]+x*y
    return c

def shift(a,w):return [sum((a[j]*math.comb(j,k)*w**(j-k) for j in range(k,len(a))),C()) for k in range(len(a))]

def modulus(v,bits):
    ns=v.norm2();scale=2**bits;k=math.isqrt(ns.numerator*scale*scale//ns.denominator)
    lo=F(k,scale);hi=lo if lo*lo==ns else F(k+1,scale)
    assert lo*lo<=ns<=hi*hi
    return lo,hi

def nearest(v,s):return C(round(v.a/s)*s,round(v.b/s)*s)

def disk_cert(a,w,r,error,bits):
    vec=shift(a,w);iv=[modulus(v,bits) for v in vec]
    lhs=iv[0][1]+error+sum((iv[k][1]+error)*r**k for k in range(2,len(a)))
    rhs=max(F(0),iv[1][0]-error)*r
    return lhs<rhs,rhs-lhs

roots=[C(F(-7,3),F(5,7)),C(F(4,5),F(-9,5)),C(F(13,5),F(8,9))]
m=3;R=F(4);delta=F(1);M2=4;A0=(4*R)**m;d0=delta**(m-1)
r=min(F(1,2**6),delta/8,d0/(16*M2*A0));s=d0*r/(64*M2*A0)
theta=d0*r/(1024*M2*A0);zeta=d0*r/(1024*M2)
bits=zeta.denominator.bit_length()+4
assert all(v.norm2()<=R*R for v in roots)
assert all((roots[i]-roots[j]).norm2()>=delta*delta for i in range(m) for j in range(i))
a=[C(1)]
for v in roots:a=mul(a,[-v,C(1)])
# Give approximation the full stated L1 error budget, oriented in the constant coefficient.
ap=a[:];ap[0]=ap[0]+theta
positive=[]
for alpha in roots:
    w=nearest(alpha,s);assert (w-alpha).norm2()<=s*s
    ok,margin=disk_cert(ap,w,r,theta*A0,bits);assert ok
    assert sum((w-root).norm2()<r*r for root in roots)==1
    positive.append({'root':alpha.show(),'center':w.show(),'certified':ok,'certified_margin':str(margin)})
# No-root, repeated-root, and oversize disks cannot satisfy the one-root certificate.
assert not disk_cert(a,C(0),r,F(0),bits)[0]
repeat=mul([-C(1,1),C(1)],[-C(1,1),C(1)])
assert not disk_cert(repeat,C(1,1),r,F(0),bits)[0]
assert not disk_cert(a,C(0),F(10),F(0),bits)[0]
# Greedy disk geometry: candidate within r of each exact root, repeats overlap and
# are discarded, no cross-root intersection. Use a non-nearest candidate first.
centers=[]
for alpha in roots:
    for w in (alpha+C(r/4),nearest(alpha,s)):
        if all((w-v).norm2()>(2*r)**2 for v in centers):centers.append(w)
assert len(centers)==m
assert all(sum((w-root).norm2()<r*r for root in roots)==1 for w in centers)

# Exact complex rational signed-cycle recurrence, including a=0 and |a|>1.
recurrence_cases=0
for N in (4,6,8,12):
    S=sp.zeros(N)
    for j in range(N-1):S[j+1,j]=1
    S[0,N-1]=-1
    xx=sp.Matrix([sp.Rational(2*j-3,2**(j+1))+sp.I*sp.Rational(j-2,2**(N-j)) for j in range(N)])
    for aa in (sp.Integer(0),sp.Rational(3,2),sp.Rational(1,3)+sp.I/5,-2+3*sp.I):
        b=sum(aa**(N-1-k)*xx[k] for k in range(1,N))
        yy=[sp.cancel((xx[0]-aa*b)/(1+aa**N))]
        for k in range(1,N):yy.append(sp.cancel(aa*yy[-1]+xx[k]))
        residual=(sp.eye(N)-aa*S)*sp.Matrix(yy)-xx
        assert all(sp.simplify(v)==0 for v in residual)
        recurrence_cases+=1

# Exact integer checks of height envelope and power-of-two precision ledgers.
ledger=[]
for N in list(range(4,202,2))+[256,1024,10000]:
    m=N//2+1;L=10*N**3+2;lr=L+N+1
    ld=(1+lr)*N*m*(m-1);leta=(1+N*lr)*N*m;lrho=leta+(N-1)*(1+lr)
    la=m*(2+lr);ld0=(m-1)*ld;lM=(m-1).bit_length()
    # r = 2^-max(p+2,ld+3,ld0+4+lM+la), with p arbitrary.
    for p in (1,53,1000):
        r_exp=max(p+2,ld+3,ld0+4+lM+la)
        s_exp=ld0+r_exp+6+lM+la
        assert s_exp<=p+100*N**7
        assert lr<=11*N**3 and ld<=20*N**6 and lrho<=20*N**6
    # Lower condition bound >= 2^(N^4), with an intentionally weaker universal constant:
    # t-2^h >=2^(L-1), binom(m,2)<=N^2, m<=N.
    assert (m-1)*(L-1-2*N)//2-N>=N**4
    ledger.append({'N':N,'R_log2':lr,'delta_inverse_log2':ld,'rho_inverse_log2':lrho,'root_s_log2_at_p1000':s_exp})

result={'status':'PASS','author_script_executed':False,'inherited_scripts_executed':False,
 'reproduced_good_modular_cases':len(saved['modular_cases']),
 'reproduced_bad_reductions':len(saved['failed_reductions_not_characteristic_zero_counterexamples']),
 'independent_modular_rows':replayed,'additional_modular_rows':new,
 'exact_signed_target_entries':entries,'norm_checks':norms,
 'complex_rouche':{'positive_disks':positive,'radius':str(r),'step':str(s),'theta':str(theta),'zeta':str(zeta),'full_coefficient_error_used':True,'negative_cases':3,'greedy_completeness_control':True,'full_candidate_grid_run':False},
 'signed_resolvent_recurrence_cases':recurrence_cases,'exponent_ledgers':ledger,
 'elapsed_seconds':time.time()-START}
(BASE/'controls/RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','reproduced_good_modular_cases','reproduced_bad_reductions','exact_signed_target_entries','signed_resolvent_recurrence_cases','elapsed_seconds')},indent=2))
print('Norm cases:',[(x['N'],x['degree'],x['coefficient_l1']) for x in norms])
