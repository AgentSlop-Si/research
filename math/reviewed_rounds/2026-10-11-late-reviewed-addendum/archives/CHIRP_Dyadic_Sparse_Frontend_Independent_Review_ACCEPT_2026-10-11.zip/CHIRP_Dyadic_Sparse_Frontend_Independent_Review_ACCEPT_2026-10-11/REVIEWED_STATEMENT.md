# Reviewed dyadic CHIRP frontend contract

11 October 2026. Independent verdict: ACCEPT for the bounded phase-zero sparse frontend with the unchanged, fully paid dense fallback. No source repair is required. This verdict is specific to chirp_dyadic.py SHA256 e9fdd8c89d2e1e8c1569f91cea16159dce690da0793cef78b0d699cac2e200e5 and reference_v1.py SHA256 7d263f616526bd1123658771afc73bb44fc15282ef8ee0131e48ade0b59d18b7. Historical candidate assurance strings in these immutable files are not changed by this external review.

## Exact domain and decisions

The API accepts an exact built-in dict with exactly N, p, r, omega, x; exact built-in integer headers and coordinates; and an exact built-in list or tuple of N canonical residues. Require N>=2, 1<=r<N, a supplied prime p with N dividing p-1, and a canonical supplied omega of exact order N. The implementation verifies primality by bounded trial division and validates the entire root recurrence before any signal decision. It does not discover the prime or root.

The recognized family is x[j]=omega^(a*j*j) sum_b gamma[b]*omega^(b*j), with at most r distinct grid frequencies and nonzero listed weights. Zero has an empty representation. All N positive-sign unnormalized DFT entries are returned only on MEMBER. Every MEMBER representation agrees with every raw coordinate. NONMEMBER is returned only after the accepted dense fallback rejects every canonical phase. A failed phase-zero sparse attempt is never overall nonmembership.

INVALID_INPUT and INVALID_PARAMETERS report detected malformed, domain, or resource-configuration failures. LIMIT is indeterminate and withholds both representation and DFT, including when a valid representation was discovered but the output could not be finished. A limit can precede discovery of invalid parameters; no status asserts more than its completed checks.

Default caps are N=128, r=64, bitlen(p)=32, and 2,000,000 instrumented work units. Hard caps are N=512, r=128, bitlen(p)=64, and 20,000,000 units. Dimension eligibility does not guarantee completion within the work cap. N=1, r>=N, and the order-2N-root curvature family are outside this API. The JSON CLI has a 1 MiB input cap and rejects duplicate keys and nonfinite or malformed JSON; callers must inspect status. The Python input object is already resident at entry. Runtime and operating-system exceptions are not promised to become decision statuses.

## Actual implemented algorithm

For dyadic N, the frontend runs quadratic Berlekamp-Massey on the 2r periodic lookups x[j mod N]. It requires a constant-one connection polynomial whose degree equals its returned order s<=r. A genuine support-pruned radix-two transform evaluates that polynomial at every supplied-grid root. Exactly s distinct roots are required. Reciprocal nodes and the partial-fraction formula recover the weights. Zero weights may be omitted under the accepted cyclic contract. A second genuinely support-pruned transform synthesizes every raw entry; all N comparisons must succeed.

The accepted phase-zero DFT is produced by N zero writes and one scatter per nonzero mode: output[-b mod N]=N*gamma[b] mod p. On any sparse rejection, or on non-dyadic N, the byte-unchanged accepted dense implementation is called with only the remaining global budget. Its repeated input, primality, and root validation, all attempted phases, and any dense output are paid. This preserves the complete common-chirp decision without claiming a sparse cost for fallback.

## Accepted cost scope

The sparse mathematical kernels use O(N log(r+2)+r^2) field additions and multiplications excluding inverse internals, and O(r) scalar inversions. Fermat inversion adds O(r*bitlen(p)) implemented field multiplications. All raw verification and dense accepted output writes are included. Trial division, input encoding/binding, ordinary integer work, and Python overhead retain their separate stated scope. The frontend uses O(N) live field storage; a fallback inherits the dense reference's O(N+r^2) field-storage scope plus the retained frontend state.

The ledger is implementation instrumentation, not processor instructions, a complete bit-cost accounting, a wall-clock bound, or a process-memory limit. Frontend field-array writes are counted more explicitly than in the unchanged dense reference, so aggregate units are not identical-cost machine operations. The exact public ledger is the sum of the frontend ledger and the remaining-budget fallback ledger, with failed work retained. Fresh tests verify the pruning tree and independently predicted kernel counts, actual arithmetic calls, inversion bit work, and interruption semantics.

## Evidence and remaining scope

Independent testing passed 93,615 complete differential decisions against both direct dechirped Fourier support and the accepted dense reference; 384 direct-transform/pruning tests with independently predicted exact kernel ledgers; and 3,177 every-unit budget cutoffs. Two N=512/r=128 final-write cases pass, including independent reconstruction of the author's 247,987-unit case. Both withhold all public outputs at one unit short.

Fifty-four fresh subprocess benchmark samples over the same nine fixtures reproduce every exact decision/output digest and complete operation ledger. They support finite sparse-path improvements against the accepted dense reference and reproduce the disclosed zero and fallback regressions. They do not compare an optimized dense FFT library, prove a uniform speedup, or establish a universal FFT result.

Only the phase-zero frontend is implemented and accepted here. Optimized common-chirp B/H selection, min(B,H), polynomial Toeplitz and Gauss-output integration, broader performance validation, and production readiness remain open. The accepted proof and earlier dense-reference acceptance are preserved. No Sheet, GitHub, manuscript, or original Library item was modified.
