"""Independent cold replay of pinned author fixtures, with separate API/process timers.
No author benchmark script is executed; only freshly copied implementation modules.
"""
from pathlib import Path
import hashlib,json,platform,statistics,subprocess,sys,time,zipfile
import chirp_dyadic as c
import reference_v1 as d
BASE=Path(__file__).resolve().parent
ARCHIVE=BASE/'inputs/CHIRP_Dyadic_Sparse_Frontend_CANDIDATE_2026-10-11.zip'
PREFIX='CHIRP_Dyadic_Sparse_Frontend_CANDIDATE_2026-10-11/'
CAP=d.Limits(512,128,64,20_000_000)
def digest(R):return hashlib.sha256(json.dumps([R['status'],R['dft']],separators=(',',':')).encode()).hexdigest()
if '--child' in sys.argv:
 Q=json.load(sys.stdin);fn=c.recognize if Q['engine']=='frontend' else d.recognize
 start=time.perf_counter_ns();R=fn(Q['problem'],CAP);elapsed=time.perf_counter_ns()-start
 print(json.dumps({'api_ns':elapsed,'ledger':R['ledger'],'status':R['status'],'route':R.get('route','dense_reference'),'decision_output_sha256':digest(R)}));raise SystemExit
with zipfile.ZipFile(ARCHIVE) as archive:
 A=json.loads(archive.read(PREFIX+'BENCHMARK_RESULTS.json'));rows=[]
 for f,h in A['source_sha256'].items():assert hashlib.sha256(archive.read(PREFIX+f)).hexdigest()==h
for row in A['cases']:
 P=row['problem'];fresh={e:[] for e in ['frontend','reference']}
 # Interleave engines, reversing order in the middle sample.
 for sample in range(3):
  for e in (['reference','frontend'] if sample==1 else ['frontend','reference']):
   start=time.perf_counter_ns();proc=subprocess.run([sys.executable,__file__,'--child'],input=json.dumps({'engine':e,'problem':P}),capture_output=True,text=True,check=True);whole=time.perf_counter_ns()-start
   R=json.loads(proc.stdout);R['process_ns']=whole;fresh[e].append(R)
 for e in fresh:
  expected=row['engines'][e]
  assert expected['median_api_ms']==statistics.median(s['api_nanoseconds'] for s in expected['samples'])/1e6
  assert expected['median_process_ms']==statistics.median(s['subprocess_nanoseconds'] for s in expected['samples'])/1e6
  for R in fresh[e]:
   assert R['ledger']==expected['samples'][0]['ledger'],(row['name'],e,'ledger')
   assert R['decision_output_sha256']==expected['samples'][0]['decision_output_sha256']
  for R in expected['samples']:
   assert R['ledger']==expected['samples'][0]['ledger']
   assert R['decision_output_sha256']==expected['samples'][0]['decision_output_sha256']
 for R in fresh['frontend']:assert R['decision_output_sha256']==fresh['reference'][0]['decision_output_sha256']
 result={'name':row['name'],'problem':P,'engines':{e:{'samples':fresh[e],'median_api_ms':statistics.median(s['api_ns'] for s in fresh[e])/1e6,'median_process_ms':statistics.median(s['process_ns'] for s in fresh[e])/1e6,'work_units':fresh[e][0]['ledger']['work_units']} for e in fresh}}
 result['api_reference_over_frontend_ratio']=result['engines']['reference']['median_api_ms']/result['engines']['frontend']['median_api_ms'];rows.append(result)
 print(row['name'],{e:{k:v for k,v in result['engines'][e].items() if k!='samples'} for e in fresh},flush=True)
R={'status':'PASS','method':'Independent script, 3 new subprocesses per engine and fixture; interleaved engine order. Both modules imported before API timing. API timer includes all validation and output; process timer includes startup/imports/JSON/teardown. No numerical optimized FFT baseline. Concurrent review process may contend for CPU; timings are finite observations only.','author_fixture_count':len(rows),'samples':6*len(rows),'python':sys.version,'platform':platform.platform(),'cases':rows,'source_sha256':{f:hashlib.sha256((BASE/f).read_bytes()).hexdigest() for f in ['independent_benchmark.py','chirp_dyadic.py','reference_v1.py']}}
(BASE/'INDEPENDENT_BENCHMARK_RESULTS.json').write_text(json.dumps(R,indent=2)+'\n')
