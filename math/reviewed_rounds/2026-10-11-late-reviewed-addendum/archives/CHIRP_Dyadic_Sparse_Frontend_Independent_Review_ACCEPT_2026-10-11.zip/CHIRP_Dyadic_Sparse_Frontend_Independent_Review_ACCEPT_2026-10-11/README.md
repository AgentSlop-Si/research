# CHIRP dyadic sparse frontend independent review

Independent verdict on 11 October 2026: ACCEPT for the bounded phase-zero sparse frontend and fully paid byte-unchanged dense fallback. No source repair required.

Read REVIEWED_STATEMENT.md for the exact accepted API and cost scope, REVIEW_REPORT.md for the proof, code audit, countercases and benchmark interpretation, and VERDICT.json for a machine-readable decision. ROW_PROPOSALS.json is an unapplied proposal for existing Q13 and STR-Q2 only.

Evidence includes 93,615 independent complete differential decisions, 384 direct/pruning/exact-cost kernel cases, 3,177 every-unit budget cutoffs, two full-size final-write boundaries, arithmetic/inversion instrumentation controls, and 54 fresh cold benchmark subprocess samples. The input candidate archive, reference/checker bytes, source pins, raw results and complete fresh review scripts are included. INPUT_VERIFICATION.json verifies the exact Library input archive and all 32 payloads against their source copies.

To rerun locally with standard-library Python 3, keep this directory structure and execute:

- python3 independent_controls.py
- python3 additional_cost_controls.py
- python3 independent_benchmark.py

The benchmark reads fixed fixture JSON and checks source hashes from the packaged candidate ZIP; it does not execute the author's benchmark script. Rerunning overwrites only the review's result/log files and changes elapsed timings. The exact reviewed snapshot is bound by PACKAGE_MANIFEST.json. The reviewer did not execute inherited unrecognized research scripts. Only the specifically reviewed candidate, accepted dense reference/checker, and fresh independent review code were executed.

This packet does not implement optimized common-chirp B/H, min(B,H), Toeplitz/Gauss output, a 2N-root extension, or a new FFT. It does not compare an optimized FFT library or certify production readiness. Zero and fallback regressions are disclosed and reproduced. No Sheet, GitHub, manuscript, or original Library item was changed.
