"""Independent inverse-work and specified boundary replay controls."""
from pathlib import Path
from dataclasses import replace
from collections import Counter
from unittest.mock import patch
import hashlib,json
import chirp_dyadic as c
import reference_v1 as d
from check_certificate_v1 import check
BASE=Path(__file__).resolve().parent;MAX=d.Limits(512,128,64,20_000_000)
S=Counter();DETAILS=[]
# Count the actual calls from a separate wrapper, including inner exponentiation.
original={k:getattr(d.Field,k) for k in ['add','sub','mul','inverse','power']}
for P in [dict(N=8,p=17,r=2,omega=2,x=[0]*8),dict(N=8,p=17,r=1,omega=2,x=[pow(2,j*j,17) for j in range(8)]),dict(N=16,p=97,r=2,omega=8,x=[(3*pow(8,j,97)+5*pow(8,7*j,97))%97 for j in range(16)]),dict(N=3,p=7,r=1,omega=2,x=[1]*3)]:
 seen=Counter()
 def wrap(k):
  def call(self,*args):
   seen[k]+=1
   if k=='inverse':
    e=self.p-2;seen['expected_inverse_bit_steps']+=e.bit_length();seen['expected_inverse_multiplications']+=e.bit_count()+max(0,e.bit_length()-1)
   return original[k](self,*args)
  return call
 with patch.multiple(d.Field,**{k:wrap(k) for k in original}):R=c.recognize(P,MAX)
 C=R['ledger']['counts'];assert C.get('field_additions',0)==seen['add']+seen['sub'];assert C.get('field_multiplications',0)==seen['mul'];assert C.get('scalar_inversions',0)==seen['inverse'];assert C.get('power_calls',0)==seen['power'];assert C.get('power_bit_iterations',0)==seen['expected_inverse_bit_steps'];assert seen['power']==seen['inverse']
 S['whole_call_arithmetic_instrumentation_cases']+=1;DETAILS.append({'problem':P,'status':R['status'],'route':R['route'],'wrapper_counts':dict(seen),'ledger_counts':C})
for p in [3,5,17,97,257,7681]:
 for a in [1,2,p-1]:
  meter=c.Meter(20_000_000);f=d.Field(p,meter);assert f.inverse(a)==pow(a,-1,p);e=p-2
  assert meter.counts['field_multiplications']==e.bit_count()+e.bit_length()-1
  assert meter.counts['power_bit_iterations']==e.bit_length();S['inverse_bit_and_multiplication_cases']+=1
# Independently reconstruct exact author final-write fixture from its stated formula.
n,p=512,7681;w=next(w for w in range(1,p) if pow(w,n,p)==1 and pow(w,n//2,p)!=1)
P=dict(N=n,p=p,r=128,omega=w,x=[sum((i+1)*pow(w,(i*3%n)*j,p) for i in range(128))%p for j in range(n)])
R=c.recognize(P,MAX);assert R['status']=='MEMBER' and R['ledger']['work_units']==247987;assert check(P,R,20_000_000)['status']=='VERIFIED_MEMBER'
Q=c.recognize(P,replace(MAX,max_work_units=247986));assert Q['status']=='LIMIT' and Q['dft'] is None and Q['representation'] is None and Q['ledger']['stage']=='sparse.accepted_scatter'
S['author_boundary_fixture_independently_reconstructed']+=1
out={'status':'PASS','counts':dict(S),'whole_call_details':DETAILS,'author_boundary':{'full_work_units':R['ledger']['work_units'],'denied_last_write_status':Q['status'],'denied_last_write_reason':Q['reason']},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(BASE/'ADDITIONAL_COST_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(out['counts'])
