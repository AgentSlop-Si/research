from pathlib import Path
import hashlib,json,zipfile
B=Path(__file__).resolve().parent
names=['README.md','REVIEWED_STATEMENT.md','REVIEW_REPORT.md','VERDICT.json','ROW_PROPOSALS.json','SOURCE_PINS.json','INPUT_VERIFICATION.json','chirp_dyadic.py','reference_v1.py','check_certificate_v1.py','independent_controls.py','INDEPENDENT_TEST_RESULTS.json','INDEPENDENT_TEST_RUN.log','additional_cost_controls.py','ADDITIONAL_COST_RESULTS.json','ADDITIONAL_COST_RUN.log','independent_benchmark.py','INDEPENDENT_BENCHMARK_RESULTS.json','INDEPENDENT_BENCHMARK_RUN.log','build_review_packet.py','inputs/CHIRP_Dyadic_Sparse_Frontend_CANDIDATE_2026-10-11.zip']
manifest={name:{'bytes':(B/name).stat().st_size,'sha256':hashlib.sha256((B/name).read_bytes()).hexdigest()} for name in names}
(B/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
title='CHIRP_Dyadic_Sparse_Frontend_Independent_Review_ACCEPT_2026-10-11'
path=B/(title+'.zip')
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in sorted(names+['PACKAGE_MANIFEST.json']):
  info=zipfile.ZipInfo(title+'/'+name,date_time=(2026,10,11,17,51,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,(B/name).read_bytes())
with zipfile.ZipFile(path) as z:
 for name,meta in manifest.items():
  data=z.read(title+'/'+name);assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
print(json.dumps({'archive':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'verified_payloads':len(manifest)},indent=2))
