"""Independent review harness. Candidate/reference bytes are immutable inputs.
No same-author candidate test/control script is imported or executed here.
"""
from pathlib import Path
from collections import Counter
from dataclasses import replace
from unittest.mock import patch
import hashlib, itertools, json, math, random, subprocess, sys, time
import chirp_dyadic as c
import reference_v1 as d
from check_certificate_v1 import check
BASE=Path(__file__).resolve().parent
MAX=d.Limits(512,128,64,20_000_000)
S=Counter(); ROUTES=Counter(); STATUS=Counter(); DETAILS={}; START=time.monotonic()

def roots(n,p):
 return [w for w in range(1,p) if pow(w,n,p)==1 and all(pow(w,n//q,p)!=1 for q in range(2,n+1) if n%q==0 and all(q%i for i in range(2,math.isqrt(q)+1)))]
def make(n,p,r,w,x):return {'N':n,'p':p,'r':r,'omega':w,'x':list(x)}
def wave(n,p,w,a,modes):return [sum(g*pow(w,a*j*j+b*j,p) for b,g in modes)%p for j in range(n)]
CACHE={}
def oracle(P):
 n,p,w,x=(P[k] for k in ('N','p','omega','x'));key=n,p,w
 if key not in CACHE:
  CACHE[key]=[[[pow(w,(-a*j*j-b*j)%n,p) for j in range(n)] for b in range(n)] for a in range(n//math.gcd(2,n))]
 return [sum(sum(v*coeff for v,coeff in zip(x,row))%p != 0 for row in phase) for phase in CACHE[key]]
def dft(P):
 n,p,w,x=(P[k] for k in ('N','p','omega','x'))
 return [sum(v*pow(w,j*k,p) for j,v in enumerate(x))%p for k in range(n)]
def ledger(R):
 a=R['ledger'];assert a['work_units']==sum(a['counts'].values())
 if a['limit'] is not None: assert 0<=a['work_units']<=a['limit']
 if 'stages' in a:assert a['work_units']==sum(a['stages'].values())
 if 'fallback' in a:
  A,B=a['frontend'],a['fallback'];assert A['work_units']+B['work_units']==a['work_units'];assert B['limit']==a['limit']-A['work_units'];assert dict(Counter(A['counts'])+Counter(B['counts']))==a['counts'];assert sum(A['stages'].values())==A['work_units']
def decide(P,kind,expected_support=None,cert=True):
 before=json.dumps(P,sort_keys=True);R=c.recognize(P,MAX);D=d.recognize(P,MAX)
 o=oracle(P) if expected_support is None else expected_support
 E='MEMBER' if min(o)<=P['r'] else 'NONMEMBER'
 assert R['status']==D['status']==E,(P,R,D,o)
 assert R['dft']==D['dft'];assert before==json.dumps(P,sort_keys=True)
 if cert:assert check(P,R,20_000_000)['status']=='VERIFIED_'+E
 if E=='MEMBER':assert R['dft']==dft(P)
 else:assert R['representation'] is None and R['dft'] is None
 if not P['N']&(P['N']-1):assert (R['route']=='sparse_frontend')==(o[0]<=P['r'])
 if R['route']=='dense_reference_fallback':
  assert R['ledger']['fallback']['counts']==D['ledger']['counts']
  assert R['ledger']['counts']['root_table_writes']==2*P['N']
 ledger(R);S[kind]+=1;S['differential_decisions']+=1;ROUTES[R['route']]+=1;STATUS[E]+=1
 return R

# Independent exhaustive alphabets, all primitive roots at these lengths.
for n,p in [(2,3),(2,5),(2,7),(3,7),(4,5),(4,13)]:
 ws=roots(n,p)
 # Full F_13^4 at one primitive root; other fields all supplied roots.
 if p==13:ws=ws[:1]
 for w in ws:
  for x in itertools.product(range(p),repeat=n):
   P=make(n,p,1,w,x); o=oracle(P)
   for r in range(1,n):P['r']=r;decide(P,'exhaustive_full_field',o,cert=False)
print('full-field exhaustive passed',S,flush=True)
# Binary inputs at N=8 and all legal r: wrapped prefixes exercised heavily.
for x in itertools.product([0,1],repeat=8):
 P=make(8,17,1,2,x);o=oracle(P)
 for r in range(1,8):P['r']=r;decide(P,'exhaustive_binary',o)
# Random arbitrary fields, roots and sparse/chirped constructed vectors.
rng=random.Random(0xD1AD1C)
for n,p,reps in [(5,11,30),(6,13,30),(8,17,100),(12,37,25),(16,97,90),(32,193,35)]:
 ws=roots(n,p)
 for _ in range(reps):
  w=rng.choice(ws);r=rng.randrange(1,n)
  decide(make(n,p,r,w,[rng.randrange(p) for j in range(n)]),'random_raw')
  for a in [0,rng.randrange(n)]:
   modes=[(b,rng.randrange(1,p)) for b in rng.sample(range(n),rng.randrange(r+1))]
   decide(make(n,p,r,w,wave(n,p,w,a,modes)),'random_constructed')
print('differential passed',S,flush=True)

# Predict recursion and exact operation counts independently from support parity.
def kernel_expected(indices,n):
 out=Counter()
 def f(I,m):
  out['pruned_active_nodes']+=1
  if m==1:out['field_entry_writes']+=1;return
  even=[j//2 for j in I if j%2==0];odd=[j//2 for j in I if j%2]
  out['sparse_support_routes']+=len(I);out['field_entry_writes']+=len(I)+2*m
  out['pruned_combine_positions']+=m//2
  if odd:
   out['root_table_reads']+=m//2;out['field_multiplications']+=m//2;out['field_additions']+=(m//2)*(2 if even else 1)
  if even:f(even,m//2)
  if odd:f(odd,m//2)
 if indices:f(indices,n)
 else:out['field_entry_writes']+=n
 return out
for n,p in [(2,3),(4,5),(8,17),(16,97),(32,193),(128,257),(512,7681)]:
 w=roots(n,p)[-1];table=[pow(w,j,p) for j in range(n)]
 if n<=8:subsets=[list(I) for s in range(n+1) for I in itertools.combinations(range(n),s)]
 else:
  subsets=[list(range(s)) for s in sorted({0,1,2,3,7,n//2,n})]
  subsets += [rng.sample(range(n),s) for s in sorted({1,2,3,7,n//2,n})]
  subsets += [list(range(j,n,step)) for step in [2,4,8] for j in range(min(step,n))]
 for I in subsets:
  pairs=[(i,rng.randrange(1,p)) for i in I];rng.shuffle(pairs);meter=c.Meter(20_000_000);trace={}
  actual=c._pruned_fft(pairs,n,table,d.Field(p,meter),trace)
  assert actual==[sum(g*pow(w,i*k,p) for i,g in pairs)%p for k in range(n)]
  assert meter.counts==kernel_expected(I,n),(I,meter.counts,kernel_expected(I,n))
  for depth in range(n.bit_length()):
   A=len({i%(1<<depth) for i in I});assert trace['calls_by_depth'].get(depth,0)==A
   assert trace['output_slots_by_depth'].get(depth,0)==A*(n>>depth)
  S['independent_kernel_and_exact_cost_cases']+=1

# Adversarial prefixes, off-grid and confluent sequences, legal zero amplitudes.
P=make(16,97,2,8,[0]*15+[1]);R=decide(P,'adversarial');assert R['frontend']['status']=='FULL_RAW_SYNTHESIS_REJECT'
DETAILS['late_impulse']={'problem':P,'status':R['status'],'frontend':R['frontend']['status']}
for x in [wave(16,97,8,0,[(3,8)])[:-1]+[0],[pow(5,j,97) for j in range(16)],[(j+1)*pow(8,3*j,97)%97 for j in range(16)]]:
 decide(make(16,97,2,8,x),'adversarial')
P=make(8,17,2,2,wave(8,17,2,0,[(0,5)]))
# An extra legitimate grid root with a recovered zero amplitude is safely omitted.
with patch.object(c,'_bm',return_value=(2,[1,7,9])):
 R=c.recognize(P,MAX)
assert R['status']=='MEMBER' and R['route']=='sparse_frontend' and R['representation']['modes']==[{'b':0,'gamma':5}]
assert check(P,R)['status']=='VERIFIED_MEMBER';S['fault_containment_cases']+=1
DETAILS['zero_amplitude_omission']={'problem':P,'injected_connection':[1,7,9],'result_modes':R['representation']['modes']}
for f in [(0,[1]),(1,[1,16]),(3,[1,0,0,1]),(1,[1,0,1])]:
 P=make(8,17,2,2,wave(8,17,2,0,[(1,4),(3,6)]))
 with patch.object(c,'_bm',return_value=f):R=c.recognize(P,MAX)
 assert R['route']=='dense_reference_fallback' and check(P,R)['status']=='VERIFIED_MEMBER';S['fault_containment_cases']+=1

# Every work cap, including setup and a late dense-output interruption.
fixtures=[make(4,5,1,2,[0]*4),make(4,5,1,2,[1]*4),make(8,17,1,2,wave(8,17,2,1,[(0,1)])),make(8,17,2,2,[0]*7+[1]),make(4,5,1,2,[1,0,0,0]),make(3,7,1,2,[1]*3),make(4,13,3,5,[3,7,11,2])]
DETAILS['budget_fixtures']=[]
for P in fixtures:
 R=c.recognize(P,MAX);assert R['status'] in ['MEMBER','NONMEMBER'];T=R['ledger']['work_units']
 for cap in range(T):
  Q=c.recognize(P,replace(MAX,max_work_units=cap));assert Q['status']=='LIMIT';assert Q['representation'] is None and Q['dft'] is None;ledger(Q);S['every_unit_cutoffs']+=1
 assert c.recognize(P,replace(MAX,max_work_units=T))['status']==R['status']
 DETAILS['budget_fixtures'].append({'problem':P,'status':R['status'],'route':R['route'],'full_work_units':T})

# All header/domain boundary branches plus exact builtin type contract.
P=make(8,17,2,2,[0]*8)
class Integer(int):pass
class List(list):pass
class Dict(dict):pass
bad=[(None,'INVALID_INPUT'),({},'INVALID_INPUT'),(Dict(P),'INVALID_INPUT')]
for key,value,status in [('N',1,'INVALID_PARAMETERS'),('N',True,'INVALID_PARAMETERS'),('N',Integer(8),'INVALID_PARAMETERS'),('r',0,'INVALID_PARAMETERS'),('r',8,'INVALID_PARAMETERS'),('r',9,'INVALID_PARAMETERS'),('omega',0,'INVALID_PARAMETERS'),('omega',1,'INVALID_PARAMETERS'),('omega',4,'INVALID_PARAMETERS'),('omega',17,'INVALID_PARAMETERS'),('p',65,'INVALID_PARAMETERS'),('p',19,'INVALID_PARAMETERS'),('x',List([0]*8),'INVALID_INPUT'),('x',[0]*7,'INVALID_INPUT'),('x',[0]*7+[True],'INVALID_INPUT'),('x',[0]*7+[Integer(0)],'INVALID_INPUT'),('x',[0]*7+[17],'INVALID_INPUT'),('x',[0]*7+[-1],'INVALID_INPUT')]:bad.append((dict(P,**{key:value}),status))
for Q,status in bad:
 R=c.recognize(Q,MAX);assert R['status']==status,(Q,R);assert R['dft'] is None and R['representation'] is None;ledger(R);S['invalid_boundary_controls']+=1
for lim in [None,{},replace(MAX,max_n=True),replace(MAX,max_r=-1),replace(MAX,max_n=513),replace(MAX,max_r=129),replace(MAX,max_p_bits=65),replace(MAX,max_work_units=20_000_001)]:
 assert c.recognize(P,lim)['status']=='INVALID_PARAMETERS';S['invalid_boundary_controls']+=1
for k,v in [('max_n',4),('max_r',1),('max_p_bits',4)]:assert c.recognize(P,replace(MAX,**{k:v}))['status']=='LIMIT';S['invalid_boundary_controls']+=1
Q=make(2,(1<<61)-1,1,(1<<61)-2,[0,0]);R=c.recognize(Q,replace(MAX,max_work_units=777));assert R['status']=='LIMIT' and R['ledger']['stage']=='primality';S['invalid_boundary_controls']+=1
assert c.recognize(dict(P,x=tuple(P['x'])),MAX)['status']=='MEMBER';S['invalid_boundary_controls']+=1
# Full boundary with independently known sparse DFT and checker.
n,p,w=512,7681,roots(512,7681)[-1];modes=[(i*5%512,(i*i+3)%p or 1) for i in range(128)];P=make(n,p,128,w,wave(n,p,w,0,modes));R=c.recognize(P,MAX)
assert R['status']=='MEMBER' and R['route']=='sparse_frontend' and R['dft']==dft(P)
assert check(P,R,20_000_000)['status']=='VERIFIED_MEMBER'
T=R['ledger']['work_units'];Q=c.recognize(P,replace(MAX,max_work_units=T-1));assert Q['status']=='LIMIT' and Q['dft'] is None and Q['representation'] is None and Q['ledger']['stage']=='sparse.accepted_scatter'
DETAILS['N512_r128_final_write']={'problem':P,'full_work_units':T,'short_status':Q['status'],'short_reason':Q['reason']};S['large_boundary_cases']+=1
# Unsupported 2N curvature remains NONMEMBER.
P=make(4,17,1,4,[pow(2,j*j,17) for j in range(4)]);assert decide(P,'unsupported_curvature')['status']=='NONMEMBER'
# CLI finite, malformed, duplicate and exact 1MiB byte boundary.
for raw,status in [(json.dumps(make(4,5,1,2,[1]*4)).encode(),'MEMBER'),(b'{"N":4,"N":4}','INVALID_INPUT'),(b'Infinity','INVALID_INPUT'),(b'{} {}','INVALID_INPUT'),(b'\xff','INVALID_INPUT'),(b'['*2000+b']'*2000,'INVALID_INPUT'),(b' '*1048576,'INVALID_INPUT'),(b' '*1048577,'LIMIT')]:
 proc=subprocess.run([sys.executable,str(BASE/'chirp_dyadic.py')],input=raw,capture_output=True,check=True);assert json.loads(proc.stdout)['status']==status;S['cli_controls']+=1
result={'status':'PASS','counts':dict(S),'routes':dict(ROUTES),'statuses':dict(STATUS),'details':DETAILS,'seconds':time.monotonic()-START,'source_sha256':{f:hashlib.sha256((BASE/f).read_bytes()).hexdigest() for f in ['independent_controls.py','chirp_dyadic.py','reference_v1.py','check_certificate_v1.py']}}
(BASE/'INDEPENDENT_TEST_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='details'},indent=2),flush=True)
