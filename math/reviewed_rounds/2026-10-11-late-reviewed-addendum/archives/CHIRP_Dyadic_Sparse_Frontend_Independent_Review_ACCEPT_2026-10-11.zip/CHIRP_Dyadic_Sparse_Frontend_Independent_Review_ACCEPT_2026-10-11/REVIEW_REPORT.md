# Independent review of the dyadic CHIRP sparse frontend

11 October 2026

## Verdict

ACCEPT within the exact API and cost scope in REVIEWED_STATEMENT.md. The reviewed source needs no repair. This closes the independent code-review gate for one bounded phase-zero sparse frontend and its paid dense fallback. It does not close optimized common-chirp integration or production validation.

The review used a fresh materialization of candidate Library libfile_8447757571648191b3b8215650efd4b6, version 0. Its 190,095-byte archive has SHA256 649991c46c79c26de9c2b0a61850dacc62c0da33d29c37642a54c2064a53fa97. All 32 manifest payloads match the candidate workspace. All nine packaged source bindings also match the available original files. INPUT_VERIFICATION.json records every length and hash. The candidate and accepted dense source bytes remain untouched.

## Source dependencies and endpoints

S2 in sources/DYADIC_SPARSE_S2.md, hash 02ec40df49f0585c57f98d3af7cbb9867216773f98a2998db9d51237fd69b787, supplies the quadratic Berlekamp-Massey, reciprocal-grid search, partial-fraction recovery, and support-pruned full synthesis construction. The packaged review decision R20 explicitly accepts the exact-field theorem for that hash and explicitly excludes implementation validation.

S2 itself states t<=N/2. Its wider use with t=r and r<N is justified separately by sections 5 and 7 of CYCLIC_WINDOW_EXTENSION.md, hash e642fd2ee0ff7bb6bf6ba35503a786e9e3a18af4b2fe4f15a79218932a950027, and the accepted CYCLIC_REVIEWED_STATEMENT.md, hash e3abfc5a134f921b1150aa8f6010897dc7b62149961669961b8f433dcbc708f1. This distinction matters: the implementation is not extending S2's stated interval without a proof dependency.

The dense fallback is the already accepted reference hash 7d263f616526bd1123658771afc73bb44fc15282ef8ee0131e48ade0b59d18b7. The decision checker remains hash 556337c6bc1f4215d1782f82fb63bfd67771152a442af1688bf91080f763699f. The prior review archive is included in the candidate source archive and bound by hash 0f90f725ab1a2952929f0332e30f04a9dd9ea135c16352e136cc9cfd9fc084af. This review supplements, rather than replaces, that accepted dense contract.

## Correctness argument tied to the code

### Complete validation precedes recognition

chirp_dyadic.py lines 220-281 implement configuration, raw type and residue checks, trial-division primality, exact-order root validation, and input binding. Prime p and N|(p-1) imply p>N, so all integers 1 through r are nonzero in the field. Checking every successive root power prevents a lower-order root from being used even for zero input. The first detected failure or exhausted budget governs.

### Berlekamp-Massey and wrapped prefixes

Lines 42-74 implement ordinary Berlekamp-Massey; lines 138-149 use exactly 2r periodic raw lookups and require order s<=r, degree s, and constant coefficient one. For a true s-term grid exponential sequence, its leading s-square Hankel matrix is V diag(gamma) V^T with distinct nonzero nodes and nonzero weights, hence invertible. The minimal connection polynomial is product(1-lambda*z), and 2r samples identify it. A valid Nth-root sequence is N-periodic, so wrapped reads when 2r>N are genuine repeated data. For arbitrary input, the prefix supplies only a candidate, never a membership certificate.

### Reciprocal roots and partial fractions

Lines 151-166 evaluate C at every omega^v and require exactly s distinct roots of a degree-s polynomial. The corresponding node is lambda=omega^(-v), implemented as b=-v mod N. Lines 168-188 compute B=C*sum_(j<s) x[j] z^j mod z^s and gamma=-lambda*B(lambda^-1)/C'(lambda^-1). The minus sign and reciprocal convention are correct: differentiating the vanishing factor in C gives C'(lambda^-1)=-lambda times the product of the remaining factors.

With s distinct roots of degree s, the derivative denominator cannot vanish. The internal arithmetic exception is therefore unreachable for valid preceding invariants. Omitting recovered zero weights is legal under the accepted cyclic contract and cannot create false acceptance because every raw coordinate is checked afterward. S2's stricter zero-amplitude rejection is not needed for this later accepted contract.

### Genuine pruning and complete synthesis

Lines 77-128 recurse only into nonempty parity-support children. At depth d, active nodes are exactly the occupied residue classes of support indices modulo 2^d. Their number is at most min(2^d,h), where h is support size. No dense transform is computed and relabeled as pruned.

A node of length m combines its two half-length outputs using omega^(N/m); an absent odd child copies the even result, an absent even child produces opposite signed rotated outputs. These are the positive-sign radix-two identities. Summing active output lengths gives O(N sum_d min(1,h/2^d)) = O(N log(h+2)). Nonzero support routing is also bounded within that order. Empty support explicitly writes N zeros.

Lines 190-204 synthesize all N samples and compare every entry, without early acceptance or a prefix-only shortcut. Therefore any accepted candidate is a legal representation even if recurrence recovery was misleading. Lines 291-303 use character orthogonality to scatter N*gamma into frequency -b, with a fully initialized N-entry output. Distinct root indices prevent collisions. A limit during any initialization or scatter write exposes neither output nor representation.

### Fallback preserves whole-family decisions

Lines 305-320 call the accepted dense reference after any sparse rejection or non-dyadic skip. The remaining limit is cap minus all successful frontend charges. The returned ledgers are added category by category; repeated primality/root validation and all rejected dense phases are preserved. The frontend cannot emit NONMEMBER on its own. Completeness for the full common-chirp family therefore follows from the accepted dense reference whenever the combined budget suffices. Extra frontend costs may instead yield LIMIT, which is correctly indeterminate.

## Resource audit

The mathematical sparse core has O(r^2) Berlekamp-Massey and partial-fraction arithmetic, two O(N log(r+2)) support-pruned transforms, O(r) inversions, and O(N) raw validation/synthesis/output work. Each actual Fermat inverse of nonzero a modulo p uses bitlen(p-2) power-bit iterations and popcount(p-2)+bitlen(p-2)-1 multiplications. These inverse internals are included in the field-multiplication ledger. Prime trial divisions and canonical input-binding bytes are charged separately.

Each pruned internal node charges its complete zero initialization and its later output overwrites, support routing, combine positions, root reads, and field operations. The independent kernel oracle derives every category count from the parity tree without using candidate trace or Meter logic. Four whole-call wrapper tests separately count actual add, subtract, multiply, inverse, and power calls across sparse and fallback routes; all agree with the reported arithmetic ledger. Eighteen standalone inverse tests verify the exact exponent-work formulas.

The budget contract is reservation-style: an amount that would exceed the cap fails before the associated batched allocation or output write, with no partially paid event. Work consumed before an interruption remains recorded. Snapshot stage totals agree with category totals. A fallback receives exactly the unspent amount, never a reset budget. Seven valid complete runs were replayed at every lower cap; all 3,177 such runs return LIMIT with null representation and DFT and never exceed their cap.

This audit accepts the documented instrumentation scope. It does not reinterpret a unit as an instruction or certify every Python read, scalar assignment, branch, allocation, metadata update, integer calculation, JSON encoding step, or operating-system cost. In particular, the byte charge for input binding is not a wall-clock preemption mechanism. The hard arithmetic caps do not constitute a complete process-memory bound. The new frontend and immutable dense reference meter array writes differently, so total-unit ratios are not processor-cost ratios.

## Independent tests

independent_controls.py imports only fresh byte-verified copies of the candidate and accepted reference/checker. It does not import or execute the candidate author's control or benchmark scripts. Its 93,615 complete differential decisions agree with an independent direct dechirped Fourier-support oracle and the accepted dense implementation; every MEMBER also agrees with a direct positive-sign DFT.

- 90,888 full-field exhaustive decisions cover F_3^2, F_5^2, F_7^2, F_7^3, F_5^4, and F_13^4 at all legal r; all primitive supplied roots are used except F_13^4, which uses one root.
- 1,792 further exhaustive decisions cover every binary vector inside F_17^8 at all r=1,...,7. They do not claim exhaustion of F_17^8.
- 930 random raw and constructed decisions cover odd, even, dyadic, non-dyadic, wrapped-prefix, cancellation, and multiple-curvature cases through N=32.
- Four ordinary adversarial decisions and one unsupported order-2N curvature decision complete the differential count.
- 384 kernel cases include every support subset through N=8 and empty, singleton, full, clustered, random, and residue-aligned supports through N=512. Every output, active depth, and independently predicted operation category agrees.
- Five injected misleading or redundant connection-polynomial cases confirm safe fallback or legal zero-weight omission. These fault tests supplement, rather than replace, ordinary-input correctness tests.
- 3,177 budget interruptions cover zero, sparse membership, accepted chirp fallback, full nonmembership, non-dyadic fallback, and a wrapped high-rank fallback.
- 34 malformed/domain/configuration/cap tests and eight CLI tests pass, including exact 1 MiB and one-byte-over transport boundaries.
- A new N=512/r=128 case uses 248,073 units; a separate reconstruction of the author's boundary uses exactly 247,987 units. Both pass full direct or checker verification and return LIMIT without either output when their final scatter write is denied one unit.

The unchanged decision checker is additionally used on 2,727 differential cases, the five fault cases, and both large boundary cases. It authenticates mathematical decisions, not operation traces, pruning, timing, or claimed execution provenance.

## Explicit countercases to stronger claims

A late impulse with a zero short prefix, N=16, p=97, r=2, omega=8, x=[0,...,0,1], reaches FULL_RAW_SYNTHESIS_REJECT and then overall NONMEMBER. Thus zero-prefix acceptance would be unsound; the implementation avoids it.

For N=8, p=17, r=1, omega=2 and x[j]=2^(j*j) mod 17, the sparse frontend rejects but dense fallback returns MEMBER with a nonzero common phase. Thus a frontend rejection is not a common-chirp nonmembership certificate.

For N=4, p=17, r=1, omega=4 and x[j]=2^(j*j) mod 17, the order-2N curvature extension returns NONMEMBER in the stated Nth-root family. The code does not silently adopt a different root-family API.

Injecting C(z)=1+7z+9z^2 over F_17 for the constant signal x[j]=5 creates one zero recovered amplitude. Omitting that amplitude gives the valid sole mode b=0, gamma=5 and full synthesis passes. This tests the accepted cyclic contract's legal zero-weight omission without pretending the injected polynomial is naturally produced by minimal Berlekamp-Massey on that input.

The measured zero case is slower than the accepted dense reference. Every failed attempt and non-dyadic skip adds overhead. These are counterexamples to uniform speedup, not correctness defects.

## Cold benchmark verification

independent_benchmark.py uses the nine recorded fixture inputs but independently orchestrates three fresh subprocess calls per engine and fixture, interleaving engine order. Both modules are imported before API timing; input parsing and fixture generation are outside that timer. The complete call includes validation, setup, recognition, and every output write. Separate process timing includes startup, imports, JSON transport, and teardown. All 54 samples reproduce the author's exact full ledgers and decision/output digests. Stored author medians were independently recomputed from their raw samples.

Fresh API medians in milliseconds are summarized below; the full raw records and process times are in INDEPENDENT_BENCHMARK_RESULTS.json.

| Fixture | Frontend | Dense reference | Frontend units | Reference units |
|---|---:|---:|---:|---:|
| sparse_N16_t1 | 0.242 | 0.343 | 546 | 1,030 |
| sparse_N64_t1 | 0.512 | 2.604 | 1,753 | 9,835 |
| sparse_N128_t4 | 1.676 | 10.071 | 6,094 | 39,071 |
| sparse_N512_t8 | 7.285 | 141.730 | 28,615 | 562,749 |
| sparse_N512_t128 | 96.440 | 2166.833 | 248,167 | 8,102,671 |
| zero_N512_t8 | 1.789 | 0.594 | 8,356 | 4,694 |
| chirp_fallback_N64_r1 | 2.987 | 2.427 | 11,875 | 9,981 |
| nonmember_fallback_N64_r2 | 1.208 | 0.923 | 4,694 | 4,112 |
| nondyadic_fallback_N15_r2 | 0.475 | 0.343 | 1,291 | 1,136 |

The fresh N=512/t=8 API median is 7.285 ms versus 141.730 ms, about 19.46 times faster for that fixture. The author's independently reproducible exact-work fixture originally reported 7.283 ms versus 143.265 ms. These differing elapsed times illustrate why an observed ratio is not a universal speed guarantee. The fresh zero call is about 3.01 times slower; the three fallback cases also regress in API time. Small-process startup overhead can dominate total-process results.

The comparison is against the accepted same-contract dense reference, not an optimized numerical or finite-field FFT library. Nine deterministic fixtures and three samples per engine are not a population performance estimate, confidence interval, asymptotic proof, or production certification.

## Existing-row proposal and stopping condition

ROW_PROPOSALS.json proposes only dated evidence and next-step updates for existing Q13 and STR-Q2. It preserves the accepted theorem, accepted dense reference, scope, history, and open optimized B/H and production obligations. No Sheet or repository change was performed. Any later consolidator must re-read the live cells and resolve the row IDs before applying the separate proposal.

This independent review is complete for the pinned source. No required source repair or unresolved correctness blocker was found. Follow-on engineering remains a new task: optimized common-chirp B/H integration, validation reuse, a cheaper zero branch, Toeplitz/Gauss output kernels, or broader optimized-baseline benchmarking. None is a condition hidden inside the bounded acceptance above.
