# Finite residual independent review

Decision: ACCEPT for the fixed `(A,d,b)=(1,5,2)`, primitive embedding 1
profile, at checker SHA-256
`739759b078f4382fc093c9acf8f2fdd59b54b2250daa369f09d692348d75c800`.

Read `INDEPENDENT_RESIDUAL_REVIEW.md` for the exact scope and proof review,
`VERDICT.json` for the machine-readable decision, and `results/` for the
fresh evidence. The original archive is preserved in `evidence/`; its clean
extraction in `candidate/` is the reviewed implementation, unchanged.

Run the independent review from this directory with Python 3.11 or newer:

    PYTHONDONTWRITEBYTECODE=1 python independent_review_controls.py

Run the author's new controls from `candidate/RS_Residual_1_5_2`:

    PYTHONDONTWRITEBYTECODE=1 python -m unittest -v test_residual_certificate
    PYTHONDONTWRITEBYTECODE=1 python independent_controls.py

The historical source programs are inert evidence and should not be run.
No source or executable repair is required. The accepted v1.1 checker is
unchanged. This packet does not claim a general residual method,
growing-degree stability, production readiness, or novelty.
