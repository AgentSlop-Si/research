#!/usr/bin/env python3
"""Seal this exact review; never modifies or runs a historical source program."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
NAME='RS_Nonconstant_Residual_1_5_2_Independent_Review_ACCEPTED_2026-10-11.zip'
roots=['INDEPENDENT_RESIDUAL_REVIEW.md','README.md','VERDICT.json','independent_review_controls.py','seal_review.py']
files=[ROOT/n for n in roots]
for directory in ['candidate','evidence','results']:
    files += [p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files=sorted(files,key=lambda p:p.relative_to(ROOT).as_posix())
manifest={'decision':'ACCEPT','files':{p.relative_to(ROOT).as_posix():{'bytes':len(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
mf=ROOT/'REVIEW_MANIFEST.json';mf.write_text(json.dumps(manifest,indent=2)+'\n');files.append(mf)
dest=ROOT/NAME
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for p in sorted(files,key=lambda p:p.relative_to(ROOT).as_posix()):
        zi=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),date_time=(2026,10,11,17,0,0))
        zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
        out.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
identity={'file_name':NAME,'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'members':len(files)}
(ROOT/'DELIVERY_IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity,indent=2))
