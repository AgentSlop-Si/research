# Bounded single profile certificate contract

The request and decision-envelope schemas are inherited verbatim from v1.1. All fields are mandatory and unknown fields are rejected. Use `examples/residual.request.json` as the complete template. Source pins now include the original eight sources plus the byte-exact reviewed v1.1 code and its independent review report.

The only profile name is `residual-1-5-2-embedding-1`, with parameters A=1,d=5,b=2,embedding_index=1. The 0 <= geometry_bits <= 64 field now controls dyadic square-root enclosures for the exact radical representation. It does not refer to floating-point precision. Every endpoint arithmetic operation and comparison is charged, and every square root has integer-square enclosure checks.

The canonical rational inputs s,r,eta,X,epsilon_min retain the domains 0<r<s<1, eta>0, X>=0, 0<epsilon_min<=r. For this profile, eta also sets the residual radius rho. This explicit specialization avoids adding an unreviewed input field. Moving local directions are all zero, so X>=eta is mandatory. The residual disks need eta<3/8 and all disks must pass the final cross-cluster separation test.

Limits retained: input 65,536 bytes; certificate 1,048,576 bytes; rational strings 256 characters; integer JSON tokens 10 characters; maximum checked bit budget 65,536 and maximum charged work budget 200,000. The bit budget is an admission limit at explicit arithmetic boundaries. Parsing, geometry, and arithmetic may allocate a larger temporary before the check. No peak-memory bound, wall-time bound, or bit-complexity bound is claimed.

The checker recalculates cyclotomic guards, radical enclosures, all 21 pairwise center distances, 7 modulus and derivative bounds, 5 ordinary leading coefficients, both Cauchy/Rouche tests, root counts, and Q08 squared norm bounds on every validation. There is no trusted cached geometry or supplied guard predicate.

CERTIFIED means the finite analytic inequalities pass for the one profile, conditional on the pinned accepted mathematics and correctness of this new, separately review-pending implementation. The certificate does not establish independent acceptance. A recomputed negative decision envelope may verify without becoming a positive certificate.

REJECT means a malformed request, invalid domain, mismatched exact profile, nonprimitive embedding, source mismatch, or forged envelope. INDETERMINATE means unsupported profile/primitive embedding, a sufficient test not met, inadequate disk separation, or an unmet requested norm ceiling. PRECISION_EXHAUSTED means a checked integer/work budget or outward geometry resolution cannot establish the fixed safe margins. None of these negative results proves a collision.

The envelope holds the complete request, canonical request SHA256 and deterministic result. Verification reruns everything and compares canonical bytes, including code hash and cost trace. A non-JSON Python request instead receives the inherited v1.1 error envelope `rs-q08-certificate-error-v1`; it is not verifiable as a certificate.

The certified geometry contains exact rational rectangles, not point approximations. The matrix bounds concern the exact square monomial Vandermonde at the actual seven perturbed roots. Squared norm outputs avoid display rounding. Since all clusters are singletons, no inverse epsilon factor occurs in this example. The inherited annulus field remains validated, but does not change its norm bound.
