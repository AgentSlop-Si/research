# One finite nonconstant RS residual example

Candidate for separate review, 11 October 2026. This packet specializes the accepted finite theorem to (A,d,b)=(1,5,2), primitive embedding 1. It does not change the accepted v1.1 validator or its scope.

The new single-profile checker certifies five moving singleton tubes and two residual disks for 0 < |epsilon| <= 2^-20. The exact discriminant and resultant have field norms 305 and 3125. It computes all root rectangles from radicals using charged exact arithmetic and outward dyadic square roots, then certifies separation and derivative margins. No floating root finder or external CAS is used by either executable.

Read `RESIDUAL_EXAMPLE.tex` (and its rendered PDF) for the derivation, `CERTIFICATE_FORMAT.md` for the bounded contract, and `examples/residual.certificate.json` for all exact endpoints and bounds.

Run from this directory with Python 3.11 or newer:

    python rs_certificate.py certify examples/residual.request.json --output /tmp/rs-residual-certificate.json
    python rs_certificate.py verify /tmp/rs-residual-certificate.json
    python independent_controls.py
    python -m unittest -v test_residual_certificate

The independently structured controls are executable checks authored with this candidate. They are not an independent review. Separate review is required before this candidate is accepted or merged into the reviewed validator.

## Evidence

- 16 test methods pass, including 65 geometry precisions and 500 request mutations.
- Every geometry precision 6 through 64 certifies the supplied request; precisions 0 through 5 fail closed.
- The chosen 24-bit run uses 15,921 charged primitives with maximum observed checked integer width 809 bits. All algebra, geometry, and source hashing repeat on each validation.
- The original v1.1 implementation is included as inert, byte-pinned source evidence. It is never imported or executed by the candidate.
- The candidate retains strict JSON/canonical rational validation and the repaired non-JSON API error envelope. Input byte, rational string, integer, geometry precision, bit-budget, and work-budget limits are inherited from v1.1.
- No peak-memory, CPU-time, efficient growing-degree, numerical root executor, floating-point solve, production, historical priority, or new general theorem claim is made.

## Scope

Only profile `residual-1-5-2-embedding-1` is supported. Valid alternative embeddings are INDETERMINATE; malformed or mismatched parameters are rejected. The old profiles continue to belong to the unchanged accepted v1.1 checker, not this candidate. Source files are hashed and interpreted as evidence, not executed.

This candidate fills one finite residual-preparation example. General residual and overlap preparation, the growing-degree problem, and production implementation remain open. No Sheet or GitHub changes were made.
