# Independent review of the RS finite parameter certificate

Review date: 11 October 2026 UTC.

## Verdict

**ACCEPT the finite-parameter analytic remainder, root-tube, complete-separation, and discriminant-truncation certificates at the exact frozen source hashes below. No mathematical correction is required.**

This is a sufficient finite-parameter certificate connecting the already accepted F020 initial forms to the already accepted Q08 finite-separation inverse envelope. It does not prove efficient growing-degree stability, numerical implementation accuracy, optimal constants, or historical novelty. The fixed-degree F020 and Q08 theorems are preserved as dependencies and are not relabeled as new results of this review.

The proof was independently checked as mathematics. The research source program was read only as inert text and was not imported, compiled, executed, or used to generate the controls. The companion program was written independently for this review. Its exact finite controls support the proof review; they do not replace the general argument.

## Reviewed bytes and accepted dependencies

- Frozen candidate LaTeX, `RS_Finite_Parameter_Scope_Audit.tex`: SHA-256 `3b472a7adb4a157c52c6ad4f8da5e1d94717e360bce8326e8c4d8732cfbcc100`, 19,346 bytes.
- Matching candidate PDF: SHA-256 `47c987f5541867b15e5bca8ae51a22f8c03276c0502d050ea80cfebb621880a2`, 84,045 bytes. The PDF text was extracted for a content check; the source formulas govern this mathematical review.
- Candidate archive: SHA-256 `2f2180470328e69db523339981b83918698b62f2589ad750010806b4fc8923ef`, 97,295 bytes. Library ID `libfile_730b9b6c2d708191bc51cf5419553afe`, version 0. Every manifest member was independently checked against the local frozen file and its stated hash. A sealed copy is included in this packet.
- Accepted F020 all-order independent review: SHA-256 `aa6fab3492f265fca7a667a213f57f1453dcfb280d94280ce74b330b353bffd3`.
- Final RS working-note LaTeX: SHA-256 `23462defbe98daf588869a27e46f4ad94f67fd02a09e0196d31bf231aa15c1f0`.
- Accepted Q08 source P05, *Structured fusion second pass*, Section S3: SHA-256 `02ec40df49f0585c57f98d3af7cbb9867216773f98a2998db9d51237fd69b787`.
- H01, *Fusion proofs*, Theorem T3: SHA-256 `4afd27bacea1bd896d8b44e7e4c1eb51c1b24b3db997ceca9e554e69f81202bb`.
- Existing research-queue snapshot: SHA-256 `bb8e10663c5fefebee819246c30db0cec2fc33fac033bac9fbea0e367f118764`. Q08 already says that the fixed-degree full singular spectrum is proved, the constants are degree-dependent, and growing-degree stability does not follow.

The accompanying `REVIEWED_INPUT_VERIFICATION.json` records all checked inputs and archive members. The author's files and accepted originals were not modified.

## Analytic normalization and polynomial majorant

Fix the admitted finite integers A, d, b, a complex primitive d-th root omega, and the applicable separated or simple-overlap guards. Every moving center alpha is a root of 1+z^d, so |alpha|=1.

On |epsilon|<1, the value 1+epsilon^2 lies in the open right half-plane: its real part is at least 1-|epsilon|^2>0. Therefore

    q(epsilon) = omega exp(Log(1+epsilon^2)/d)

defines the unique analytic branch with q(0)=omega. Its Taylor series is the formal branch used in F020. There is no unproved convergence step when passing from the accepted formal vanishing to analytic Taylor coefficients. For |epsilon|=s<1,

    |q(epsilon)| <= (1+s^2)^(1/d) = Q_s.

The Gaussian polynomial has nonnegative integer coefficients, coefficient sum binomial(n,k), and q-degree k(n-k). Hence for Q>=1 its modulus on |q|<=Q is bounded by binomial(n,k) Q^(k(n-k)). Summing over k gives the candidate's B_n(Q,Z); replacing each exponent by floor(n^2/4) gives its second bound. This remains valid when q lies inside the unit disk. The polynomial interpretation avoids any spurious denominator singularity at a root of unity.

For fixed |x|<=X, write the analytic function H_n(alpha+epsilon x;q(epsilon)) as sum a_l(x) epsilon^l. On |epsilon|=s it is bounded by B=B_n(Q_s,1+sX). Cauchy's estimate gives |a_l(x)|<=B s^(-l), uniformly on that x-disk. The accepted initial form says a_l=0 for l<m and a_m=P_alpha. Consequently, for |epsilon|<=r<s,

    |epsilon^(-m) H_n - P_alpha|
      <= sum_(l>=m+1) B s^(-l) r^(l-m)
      = B s^(-m) r/(s-r).

This proves equation (8), including the essential s^(-m). The inequality is valid for complex epsilon in the entire punctured disk, not merely a real approach. Equation (13) is exactly the strict inequality obtained by solving E<mu for r. Its right side is positive and smaller than s. Thus the test always admits some nonzero radius for every fixed guarded finite instance, without asserting a useful size as parameters grow.

## Root tubes, overlap conventions, and residual roots

The signs and scaling of the reused initial forms agree with the accepted F020 review. At an ordinary center,

    P_alpha(x) = (-1)^A d^(A/2) G(alpha) He_A(sqrt(d)x/alpha),

so the leading coefficient is (-1)^A d^A G(alpha)/alpha^A, of modulus d^A|G(alpha)|. At the shared center -1 the leading coefficient of d^((A-1)/2)g J_(A+1)(sqrt(d)x) is d^A g. The overlap expression is the same parity-adjusted convention as the accepted theorem. The simple-overlap case retains the original odd-b and nonzero-g context; the factorization by z+1 at b<d itself rules out even b. No extra overlap or squarefreeness case is silently added.

On |x-xi_j|=eta, all other factors obey |x-xi_k|>=|xi_j-xi_k|-eta. Thus equation (9) is a valid lower bound on |P_alpha|. The strict condition eta<delta_xi/2 makes the circles pairwise disjoint. Rouché then supplies exactly one zero counted with multiplicity in each circle. A total multiplicity of one proves simplicity. Multiplication by nonzero epsilon sends these disks exactly to equation (11), for every complex argument of epsilon. The pairwise lower and upper bounds in (12) follow directly by two triangle inequalities.

When m=1, the empty product is one and no direction-gap condition is needed. This also covers ordinary clusters when A=1. For equation (14), use the fixed x-disk of radius X_0 and put eta=2E/L. If eta<=eta_0, every boundary product is at least L eta=2E>E. Equality eta=eta_0 is harmless because eta_0 was strictly below half the gap. Therefore the displayed root error follows. With r=|epsilon| and fixed s, E=O(|epsilon|), giving the claimed O(|epsilon|^2) error.

For each residual root beta the static polynomial F^A G is monic, with a simple factor at beta. The displayed product nu_beta is therefore a valid boundary lower bound. At fixed z, H_n(z;q(epsilon)) is even in epsilon, so the Cauchy tail after its constant term is

    B sum_(j>=1) (r/s)^(2j) = B r^2/(s^2-r^2).

This proves equation (15); no first-order term was discarded without justification. The global Delta test in (16) is additionally necessary for this particular certificate to prevent disks from distinct static centers from overlapping. The certified root counts are Ad+b in the separated case and (d-1)A+(A+1)+(b-1)=Ad+b in the overlap case. Since H_n remains monic of degree n, these counts exhaust its roots.

## Q08 interface and Hermite geometry

For a node in a cluster of size m_a, the Lagrange denominator contains m_a-1 within-cluster factors, each at least |epsilon| gamma_a, and n-m_a cross-cluster factors, each at least Delta. The numerator coefficient l1 norm is at most (1+R)^(n-1). Summing the squared row bounds and taking a square root gives exactly equation (17), including sqrt(n). Allowing a separate gamma_a per cluster is justified by applying this bound row by row. For singleton clusters the absent factor is one. The V norm bound follows from its Frobenius norm. These are applications of the existing Q08 envelope, not a new singular-value exponent theorem.

For b=0 the ordinary directions are alpha times the probabilists' Hermite roots divided by sqrt(d). The Hermite Jacobi matrix has nonzero off-diagonals sqrt(1),...,sqrt(A-1), so its eigenvalues are real and simple. Its trace square is A(A-1), giving the lower bound on the maximum root modulus; its row-sum norm gives the upper bound 2sqrt(A-1). The least consecutive gap is at most the total span divided by A-1.

For the lower gap, u=exp(-y^2/4)He_A(y) satisfies u''+(A+1/2-y^2/4)u=0. Between two consecutive zeros a<b, integration by parts gives

    integral |u'|^2 <= (A+1/2) integral |u|^2,

while the Dirichlet Poincaré inequality gives integral |u'|^2 >= pi^2/(b-a)^2 integral |u|^2. This yields b-a>=pi/sqrt(A+1/2). Scaling proves all four inequalities in (5). The needed recurrence and differential equation were independently checked in [NIST DLMF Table 18.9.1](https://dlmf.nist.gov/18.9.T1) and [Table 18.8.1](https://dlmf.nist.gov/18.8.T1), respectively, on 11 October 2026.

Equation (18) then follows by substituting eta=delta_0/4, the Hermite radius upper bound, and |c|=d^A into the tube test, and using the exact static center gap 2sin(pi/d). The statement that epsilon sqrt(Ad) should be small describes the scale of this sufficient geometric envelope. It is not a necessary root-collision condition. The Cauchy threshold may be much smaller still.

## Exact example certificates and additional controls

Both printed examples pass with s=1/2, r=1/10000, eta=1/8, and X=1.

- Separated (A,d,b)=(2,3,0): B<=1953125/4096 and E<=1953125/5118976<63/64<=mu. The direction radius is 1/sqrt(3)<3/5, their gap is 2/sqrt(3)>1, and the static center gap sqrt(3)>1 exceeds 2r. All six roots are certified. Their within-cluster distances exceed 3|epsilon|/4.
- Simple overlap (1,3,1): in Q[w]/(w^2+w+1), tau=3/(1-w^2)=1-w and tau times its conjugate is 3. At -1 the leading polynomial is 3x^2-tau, with direction modulus 3^(-1/4)<7/8 and gap>1. The common B bound 390625/4096 gives E_exceptional=390625/5118976<21/64 and E_ordinary=390625/10237952<3/8. The ordinary leading coefficients have modulus 3sqrt(3). The disks certify all four roots.

The independent program constructs Gaussian coefficients by enumerating weighted subsets in the finite product, rather than using the author's Pascal program. It checks 91 coefficients through n=12 and their RS recurrence, then reconstructs the three local jets in each of the two examples exactly in the cubic cyclotomic field. It also verifies normalized geometric tails and strict threshold algebra for m=1,...,12, the even residual tail, the Hermite differential/gauge identities through A=24, a six-node exact rational Lagrange envelope with heterogeneous clusters and a singleton, and discriminant-threshold algebra for M=0,1,3,7.

At r=1/1000 in the separated example, the correct sufficient test is inconclusive, while omitting s^(-m) makes the wrong test pass. This mutation detects the normalization error; it does not demonstrate an actual collision. No approximate root solver or floating-point output was used as a certificate.

## Discriminant remainder and final boundary

On |t|=v<1, the coefficient l1 norm of H_n is at most S=B_n((1+v)^(1/d),1). That of its derivative is at most nS. The (2n-1)-square Sylvester matrix has n-1 shifted H_n rows and n shifted derivative rows. Their l2 norms are bounded by the respective l1 norms. Hadamard therefore gives |Disc(H_n)|<=n^n S^(2n-1)=T; the monic discriminant sign does not affect the bound. Applying the same normalized Cauchy argument with the accepted order M proves (19). Solving for the target theta|C| proves (20), including the M=0 case.

The correct update is: **independently accepted explicit conservative finite-parameter remainder and separation certificates now supply Q08 inputs; the existing fixed-degree claims remain intact.** Root preparation, rigorous enclosure computation, arithmetic costs, resonance legality, finite-precision stability, useful growing-degree bounds, and historical priority remain separate. No Sheet or GitHub writes were performed, no child agents were used, and no sealed source was altered.
