#!/usr/bin/env python3
"""Standalone independently structured exact checks; not an independent review.

Uses only Fraction/integer arithmetic. No floating roots, external CAS, network,
or historical executable is used. Candidate import is for differential checks.
"""
from fractions import Fraction as F
from math import isqrt, comb
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent

# Alternative fixed-field representation: reduce exponents modulo 5 first,
# then eliminate w^4 using Phi_5; no use of candidate ring routines.
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def neg(a):return tuple(-x for x in a)
def mul(a,b):
    h=[0]*5
    for i,x in enumerate(a):
        for j,y in enumerate(b):h[(i+j)%5]+=x*y
    return tuple(h[i]-h[4] for i in range(4))
def powk(a,n):
    v=(1,0,0,0)
    for _ in range(n):v=mul(v,a)
    return v
O=(1,0,0,0);Z=(0,0,0,0);W=(0,1,0,0)
def subs(a,k):
    v=Z
    for j,c in enumerate(a):v=add(v,tuple(c*x for x in powk(W,j*k)))
    return v
def norm(a):
    out=O
    for k in (1,2,3,4):out=mul(out,subs(a,k))
    return out

# Independent interval implementation. Direct Fractions, explicit endpoint
# extrema; mathematical enclosure inequalities are asserted for every sqrt.
def iv(x):return (F(x),F(x))
def plus(a,b):return a[0]+b[0],a[1]+b[1]
def minus(a,b):return a[0]-b[1],a[1]-b[0]
def times(a,b):
    q=[x*y for x in a for y in b];return min(q),max(q)
def scale(a,d):return a[0]/d,a[1]/d
def sq(a):return (F(0) if a[0]<=0<=a[1] else min(x*x for x in a),max(x*x for x in a))
def sqrtiv(a,p=32):
    assert a[0]>=0
    s=1<<p; lo=isqrt(a[0].numerator*s*s//a[0].denominator)
    hi=isqrt(a[1].numerator*s*s//a[1].denominator)
    if F(hi*hi,s*s)<a[1]:hi+=1
    out=F(lo,s),F(hi,s)
    assert out[0]*out[0]<=a[0]<=a[1]<=out[1]*out[1]
    return out
def cplus(a,b):return plus(a[0],b[0]),plus(a[1],b[1])
def cminus(a,b):return minus(a[0],b[0]),minus(a[1],b[1])
def ctimes(a,b):return minus(times(a[0],b[0]),times(a[1],b[1])),plus(times(a[0],b[1]),times(a[1],b[0]))
def normsq(a):return plus(sq(a[0]),sq(a[1]))
def decode(d):return tuple(F(x) for x in d['real']),tuple(F(x) for x in d['imag'])
def contained(a,b):return all(b[j][0]<=a[j][0]<=a[j][1]<=b[j][1] for j in (0,1))
CZ=(iv(0),iv(0));CO=(iv(1),iv(0))

def main():
    import rs_certificate as C
    req=json.loads((ROOT/'examples/residual.request.json').read_text())
    result=C.evaluate(req,ROOT/'sources');assert result['status']=='CERTIFIED'
    b=result['bounds'];g=b['geometry']; report={}
    c=add(O,W);disc=add(mul(c,c),(-4,0,0,0));res=O
    for k in range(5):
        a=neg(powk(W,k));res=mul(res,add(add(mul(a,a),mul(c,a)),O))
    assert disc==(-3,2,1,0) and norm(disc)==(305,0,0,0)
    assert res==(5,10,10,0) and norm(res)==(3125,0,0,0)
    for key,value in [('disc_G',disc),('resultant_F_G',res),('norm_disc_G',norm(disc)),('norm_resultant_F_G',norm(res))]:
        assert [str(x) for x in value]==g['guards'][key]
    report['cyclotomic_guards']={'disc_norm':305,'resultant_norm':3125,'pass':True}
    # Gaussian Pascal recurrence specialized in the cyclotomic ring independently
    # proves the actual polynomial identity H_7(z;w)=F(z)G(z).
    previous=[O]
    for n in range(1,8):
        current=[O]
        for k in range(1,n):current.append(add(previous[k],mul(powk(W,n-k),previous[k-1])))
        current.append(O);previous=current
    expected=[O,c,O,Z,Z,O,c,O]
    assert previous==expected
    report['exact_H7_equals_FG_coefficients']=[list(x) for x in previous]
    # Derive a separately computed 32-bit enclosure directly from radicals.
    t5=sqrtiv(iv(5));omega=scale(minus(t5,iv(1)),4),scale(sqrtiv(plus(iv(10),times(iv(2),t5))),4)
    cb=cplus(CO,omega);discb=cminus(ctimes(cb,cb),(iv(4),iv(0)))
    assert discb[1][0]>0
    ab=sqrtiv(normsq(discb));q= sqrtiv(scale(plus(ab,discb[0]),2)),sqrtiv(scale(minus(ab,discb[0]),2))
    roots=[];cur=CO
    for _ in range(5):roots.append(cminus(CZ,cur));cur=ctimes(cur,omega)
    for numerator in [cminus(q,cb),cminus(cminus(CZ,q),cb)]:roots.append((scale(numerator[0],2),scale(numerator[1],2)))
    assert contained(omega,decode(g['omega_rectangle']))
    assert contained(discb,decode(g['discriminant_rectangle']))
    assert contained(q,decode(g['sqrt_discriminant_rectangle']))
    coarse=[decode(x) for x in g['center_rectangles']]
    assert all(contained(a,b) for a,b in zip(roots,coarse))
    report['independent_32bit_radicals_inside_candidate_rectangles']=True
    # Check the claimed scalar bounds straight against candidate rectangle
    # endpoints by squaring, without using candidate sqrt or norm routines.
    distances=g['pairwise_center_distance_lower']
    for i in range(7):
        for j in range(i):
            d=F(distances[i][j]);assert d==F(distances[j][i]) and d>=F(3,8)
            assert d*d<=normsq(cminus(coarse[i],coarse[j]))[0]
        mod=F(g['center_modulus_upper'][i]);assert mod*mod>=normsq(coarse[i])[1]
        deriv=F(1)
        for j in range(7):
            if j!=i:deriv*=F(distances[i][j])
        assert deriv==F(g['static_f0_derivative_modulus_lower'][i]) and deriv>=1
    for i in (5,6):assert F(g['center_modulus_upper'][i])<=F(7,4)
    oldomega=decode(g['omega_rectangle']);oldc=cplus(CO,oldomega)
    for i in range(5):
        a=coarse[i];ga=cplus(cplus(ctimes(a,a),ctimes(oldc,a)),CO)
        L=F(g['ordinary_leading_modulus_lower'][i]);assert L>=5 and (L/5)**2<=normsq(ga)[0]
    report['all_21_separations_7_moduli_7_derivatives_5_leading_margins_checked']=True
    s,r,eta,X=[F(req[k]) for k in ('s','r','eta','X')]
    B=(1+s*s)**3*(2+s*X)**7;mu=5*eta;E=B*r/(s*(s-r));threshold=mu*s*s/(B+mu*s)
    Br=(1+s*s)**3*(1+F(7,4)+eta)**7;nu=eta*(F(3,8)-eta)**6;Er=Br*r*r/(s*s-r*r)
    thr2=nu*s*s/(Br+nu)
    for key,value in [('B_upper',B),('mu_lower',mu),('E_upper',E),('strict_r_threshold',threshold)]:assert F(b['ordinary'][key])==value
    for key,value in [('B_upper',Br),('nu_lower',nu),('E_upper',Er),('strict_r_squared_threshold',thr2)]:assert F(b['residual'][key])==value
    assert E<mu and Er<nu and r<threshold and r*r<thr2
    D=F(3,8)-2*max(r*X,eta);R=max(1+r*X,F(7,4)+eta)
    assert D==F(1,4) and R==F(29,16)
    i2=7*(1+R)**12/D**12;f2=7*sum(R**(2*k) for k in range(7))
    assert F(b['inverse_norm_squared_upper'])==i2
    assert F(b['forward_norm_squared_upper'])==f2
    assert F(b['condition_number_squared_upper'])==i2*f2
    report['direct_Cauchy_Rouche_and_Q08_formulas']=True
    # Ensure residual condition is logically necessary to this certificate:
    # ordinary test alone passes at this radius, residual condition does not.
    rm=F(1,8192)
    assert B*rm/(s*(s-rm))<mu and Br*rm*rm/(s*s-rm*rm)>nu
    report['residual_omission_mutation_radius']='1/8192'
    # Omitting s^-1 can create a false positive against the correct ordinary
    # sufficient condition. This is inconclusive, not a collision assertion.
    rm=F(3,8192)
    assert B*rm/(s-rm)<mu < B*rm/(s*(s-rm))
    report['normalization_omission_mutation_radius']='3/8192'
    report['checker_sha256']=hashlib.sha256((ROOT/'rs_certificate.py').read_bytes()).hexdigest()
    report['status']='PASS';report['review_status']='PENDING_SEPARATE_REVIEW'
    (ROOT/'results/INDEPENDENT_EXECUTABLE_CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
