#!/usr/bin/env python3
"""Bounded single-profile residual candidate using the accepted finite RS/Q08 theorem.

Newly authored implementation. Python standard library only. No source code is
loaded or executed from the evidence directory. This is an analytic certificate
checker, not a numerical root solver or a growing-degree stability theorem.
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from math import gcd, isqrt
from pathlib import Path
import re
import sys

# Decimal rendering has a fixed cap independent of the request arithmetic
# budget. Parsing and geometry preparation may construct larger temporaries
# before the next checked arithmetic boundary; no peak-memory bound is claimed.
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(50000)

VERSION = "rs-q08-residual-1-5-2-candidate-0.1"
REQUEST_FORMAT = "rs-q08-request-v1"
CERTIFICATE_FORMAT = "rs-q08-certificate-v1"
MAX_INPUT_BYTES = 65536
MAX_CERTIFICATE_BYTES = 1048576
MAX_RATIONAL_CHARS = 256
MAX_BITS = 65536
MAX_STEPS = 200000
MAX_N, MAX_A, MAX_D = 128, 16, 31
SOURCE_PINS = {
    "accepted_finite_proof.tex": "3b472a7adb4a157c52c6ad4f8da5e1d94717e360bce8326e8c4d8732cfbcc100",
    "accepted_finite_review.md": "a412af68fbeffe1d6f332280a5b59e3ac74d91481c492232981319c51e0b6033",
    "accepted_example_controls.json": "eaf00162dc76a9296c30193324b199ee4cdd63db2fe3975ca073716b274576c6",
    "accepted_independent_controls.json": "17600b59cff55dc2e8a8d11d102b2243fa1cbc0a8c930987f56ff58d765dc4d4",
    "accepted_scope_archive.zip": "2f2180470328e69db523339981b83918698b62f2589ad750010806b4fc8923ef",
    "accepted_scope_controls.py.txt": "91f960dd2ea9f9ed8583aca33cffea4f519975e7c0424b593d52b7eef70b9889",
    "accepted_review_controls.py.txt": "2c1428f24b5ff380b95aadd2a61279d5bedfc28ad3ca3115149559be2003fdb2",
    "accepted_q08_envelope.md": "02ec40df49f0585c57f98d3af7cbb9867216773f98a2998db9d51237fd69b787",
    'accepted_validator_v1_1.py.txt': '7cf350bfa8037e2addb3f26454a0e047b4f8df501500158292f45b9020d8a60c',
    'accepted_validator_review.md': '9d3793c1aa13024dff27826df02afe1cbff54dc5376d33eccd5f90fe75327998',
}
REQUEST_KEYS = {
    "format", "profile", "parameters", "s", "r", "eta", "X",
    "epsilon_min", "geometry_bits", "budget", "source_pins",
    "max_inverse_norm_squared",
}


class Stop(Exception):
    def __init__(self, status, reason):
        self.status, self.reason = status, reason
        super().__init__(reason)


def reject(reason):
    raise Stop("REJECT", reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")


def strict_loads(data, maximum=MAX_INPUT_BYTES):
    """Bounded JSON, with no duplicate keys, floating numbers, or NaN/Infinity."""
    if not isinstance(data, bytes) or len(data) > maximum:
        reject("INPUT_SIZE_LIMIT")

    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                reject("DUPLICATE_JSON_KEY")
            out[key] = value
        return out

    def forbidden(_):
        reject("NONINTEGER_JSON_NUMBER")

    def bounded_int(text):
        if len(text) > 10:
            reject("JSON_INTEGER_SIZE_LIMIT")
        return int(text)

    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=pairs,
                          parse_float=forbidden, parse_constant=forbidden,
                          parse_int=bounded_int)
    except (ValueError, UnicodeError, RecursionError):
        reject("MALFORMED_JSON")


class Arithmetic:
    """Exact fractions; fail closed on a deterministic bit/work budget.

    Cross products are counted before comparisons. Every primitive operation
    checks unreduced integer intermediates at its explicit check boundaries.
    The bit budget is a checked-arithmetic admission limit, not a hard limit
    on allocation or parsing/geometry temporaries. No unchecked over-budget
    rational is admitted to a certified answer.
    """
    def __init__(self, bits, steps):
        self.bits, self.steps = bits, steps
        self.counts = Counter()
        self.total = 0
        self.max_integer_bits = 0
        self.stage = "input"

    def tick(self, kind):
        self.counts[f"{self.stage}:{kind}"] += 1
        self.total += 1
        if self.total > self.steps:
            raise Stop("PRECISION_EXHAUSTED", "ARITHMETIC_WORK_BUDGET")

    def ints(self, *values):
        width = max((abs(x).bit_length() for x in values), default=0)
        self.max_integer_bits = max(self.max_integer_bits, width)
        if width > self.bits:
            raise Stop("PRECISION_EXHAUSTED", "EXACT_INTEGER_BIT_BUDGET")

    def make(self, numerator, denominator=1):
        self.tick("rational_normalization")
        self.ints(numerator, denominator)
        if denominator == 0:
            reject("ZERO_DENOMINATOR")
        return Fraction(numerator, denominator)

    def parse(self, value):
        if (not isinstance(value, str) or len(value) > MAX_RATIONAL_CHARS
                or re.fullmatch(r"-?(0|[1-9][0-9]*)(/[1-9][0-9]*)?", value) is None):
            reject("NONCANONICAL_RATIONAL")
        parts = value.split("/")
        a = self.make(int(parts[0]), int(parts[1]) if len(parts) == 2 else 1)
        if str(a) != value:
            reject("NONCANONICAL_RATIONAL")
        return a

    def add(self, a, b):
        self.tick("add")
        a, b = Fraction(a), Fraction(b)
        x, y, d = a.numerator*b.denominator, b.numerator*a.denominator, a.denominator*b.denominator
        self.ints(x, y, d, x+y)
        return self.make(x+y, d)

    def neg(self, a):
        self.tick("negate")
        return self.make(-a.numerator, a.denominator)

    def sub(self, a, b):
        return self.add(a, self.neg(Fraction(b)))

    def mul(self, a, b):
        self.tick("multiply")
        a, b = Fraction(a), Fraction(b)
        return self.make(a.numerator*b.numerator, a.denominator*b.denominator)

    def div(self, a, b):
        self.tick("divide")
        a, b = Fraction(a), Fraction(b)
        return self.make(a.numerator*b.denominator, a.denominator*b.numerator)

    def power(self, a, exponent):
        self.tick("power")
        if type(exponent) is not int or exponent < 0 or exponent > 10000:
            reject("INTERNAL_EXPONENT_DOMAIN")
        value, a = Fraction(1), Fraction(a)
        while exponent:
            if exponent & 1:
                value = self.mul(value, a)
            exponent //= 2
            if exponent:
                a = self.mul(a, a)
        return value

    def cmp(self, a, b):
        self.tick("compare")
        a, b = Fraction(a), Fraction(b)
        left, right = a.numerator*b.denominator, b.numerator*a.denominator
        self.ints(left, right)
        return (left > right) - (left < right)

    def sqrt_enclosure(self, a, precision):
        """Dyadic floor/ceiling sqrt, proved with integer square comparisons."""
        self.tick("sqrt_enclosure")
        if self.cmp(a, 0) < 0:
            reject("NEGATIVE_SQRT")
        scale = 1 << precision
        scaled_num = a.numerator * scale * scale
        self.ints(scale, scaled_num, a.denominator)
        self.tick("integer_sqrt")
        lower_int = isqrt(scaled_num // a.denominator)
        self.ints(lower_int*lower_int*a.denominator)
        upper_int = lower_int if lower_int*lower_int*a.denominator == scaled_num else lower_int+1
        low, high = self.make(lower_int, scale), self.make(upper_int, scale)
        if self.cmp(self.power(low, 2), a) > 0 or self.cmp(self.power(high, 2), a) < 0:
            reject("INTERNAL_SQRT_ENCLOSURE")
        return low, high

    def costs(self):
        return {"arithmetic_steps": self.total,
                "maximum_integer_bits_observed": self.max_integer_bits,
                "operations_by_stage": dict(sorted(self.counts.items())),
                "bit_budget": self.bits, "step_budget": self.steps}


def keys(obj, expected, name):
    if type(obj) is not dict or set(obj) != expected:
        reject(f"{name}_FIELDS")


def verify_sources(directory, progress=None):
    total = 0
    for name, digest in sorted(SOURCE_PINS.items()):
        try:
            with (Path(directory) / name).open("rb") as stream:
                data = stream.read(1048577)
        except OSError:
            reject("SOURCE_UNAVAILABLE:" + name)
        if len(data) > 1048576:
            reject("SOURCE_SIZE_LIMIT:" + name)
        total += len(data)
        if progress is not None:
            progress["source_bytes_hashed"] = total
            progress["source_files_read"] += 1
        if hashlib.sha256(data).hexdigest() != digest:
            reject("SOURCE_HASH_MISMATCH:" + name)
    return total


class Intervals:
    """Closed rational rectangles. Every endpoint operation is charged."""
    def __init__(self, ar, bits):
        self.a, self.bits = ar, bits
    def point(self, x):
        x = self.a.make(x)
        return x, x
    def add(self, x, y):
        return self.a.add(x[0], y[0]), self.a.add(x[1], y[1])
    def neg(self, x):
        return self.a.neg(x[1]), self.a.neg(x[0])
    def sub(self, x, y):
        return self.add(x, self.neg(y))
    def min(self, values):
        v = values[0]
        for w in values[1:]:
            if self.a.cmp(w, v) < 0: v = w
        return v
    def max(self, values):
        v = values[0]
        for w in values[1:]:
            if self.a.cmp(w, v) > 0: v = w
        return v
    def mul(self, x, y):
        p = [self.a.mul(a,b) for a in x for b in y]
        return self.min(p), self.max(p)
    def scale(self, x, denominator):
        return self.a.div(x[0], denominator), self.a.div(x[1], denominator)
    def square(self, x):
        sq = [self.a.power(v, 2) for v in x]
        low = self.a.make(0) if self.a.cmp(x[0],0)<=0<=self.a.cmp(x[1],0) else self.min(sq)
        return low, self.max(sq)
    def sqrt(self, x):
        if self.a.cmp(x[0], 0) < 0:
            raise Stop("PRECISION_EXHAUSTED", "RADICAL_SIGN_NOT_RESOLVED")
        return self.a.sqrt_enclosure(x[0],self.bits)[0], self.a.sqrt_enclosure(x[1],self.bits)[1]
    def complex(self, x, y=0):
        return self.point(x), self.point(y)
    def cadd(self, x, y):
        return self.add(x[0],y[0]), self.add(x[1],y[1])
    def cneg(self, x):
        return self.neg(x[0]), self.neg(x[1])
    def csub(self, x, y):
        return self.cadd(x,self.cneg(y))
    def cmul(self, x, y):
        return self.sub(self.mul(x[0],y[0]),self.mul(x[1],y[1])), self.add(self.mul(x[0],y[1]),self.mul(x[1],y[0]))
    def modulus(self, x):
        return self.sqrt(self.add(self.square(x[0]),self.square(x[1])))
    def encode(self,x):
        return {"real":[str(v) for v in x[0]],"imag":[str(v) for v in x[1]]}


class Cyclotomic5:
    """Exact Q[w]/(1+w+w^2+w^3+w^4); fixed-size, charged arithmetic."""
    def __init__(self, ar): self.a=ar
    def scalar(self,x):
        x=Fraction(x)
        return [self.a.make(x.numerator,x.denominator)]+[self.a.make(0) for _ in range(3)]
    def add(self,x,y): return [self.a.add(a,b) for a,b in zip(x,y)]
    def neg(self,x): return [self.a.neg(a) for a in x]
    def mul(self,x,y):
        p=[self.a.make(0) for _ in range(7)]
        for i in range(4):
            for j in range(4): p[i+j]=self.a.add(p[i+j],self.a.mul(x[i],y[j]))
        for k in range(6,3,-1):
            for j in range(4): p[k-4+j]=self.a.sub(p[k-4+j],p[k])
        return p[:4]
    def power(self,x,n):
        v=self.scalar(1)
        for _ in range(n): v=self.mul(v,x)
        return v
    def substitute(self,x,w):
        y=self.scalar(0)
        for c in reversed(x): y=self.add(self.mul(y,w),self.scalar(c))
        return y
    def norm(self,x,w):
        v=self.scalar(1)
        for j in range(1,5): v=self.mul(v,self.substitute(x,self.power(w,j)))
        return v
    def equal(self,x,y): return all(self.a.cmp(a,b)==0 for a,b in zip(x,y))


def prepare_geometry(req,ar):
    if req["profile"] != "residual-1-5-2-embedding-1":
        raise Stop("INDETERMINATE","UNSUPPORTED_PROFILE")
    p=req["parameters"]
    if (p["A"],p["d"],p["b"]) != (1,5,2): reject("PROFILE_PARAMETER_MISMATCH")
    if p["embedding_index"] != 1:
        raise Stop("INDETERMINATE","UNSUPPORTED_PROFILE_EMBEDDING")
    ar.stage="exact_cyclotomic_guards"
    K=Cyclotomic5(ar); one=K.scalar(1); w=[ar.make(0),ar.make(1),ar.make(0),ar.make(0)]
    if not K.equal(K.power(w,5),one) or K.equal(w,one): reject("CYCLOTOMIC_ORDER_GUARD")
    c=K.add(one,w)
    disc=K.add(K.mul(c,c),K.scalar(-4))
    res=one
    for k in range(5):
        alpha=K.neg(K.power(w,k))
        res=K.mul(res,K.add(K.add(K.mul(alpha,alpha),K.mul(c,alpha)),one))
    dn,rn=K.norm(disc,w),K.norm(res,w)
    if all(ar.cmp(v,0)==0 for v in disc) or all(ar.cmp(v,0)==0 for v in res):
        reject("RESIDUAL_DISCRIMINANT_OR_RESULTANT_ZERO")
    # These full exact vectors are evidence, not supplied/trusted predicates.
    guards={"disc_G":[str(x) for x in disc],"resultant_F_G":[str(x) for x in res],
            "norm_disc_G":[str(x) for x in dn],"norm_resultant_F_G":[str(x) for x in rn],
            "basis":"1,w,w^2,w^3; Phi_5(w)=0"}
    ar.stage="outward_radical_preparation"
    I=Intervals(ar,req["geometry_bits"])
    sq5=I.sqrt(I.point(5))
    omega=(I.scale(I.sub(sq5,I.point(1)),4),I.scale(I.sqrt(I.add(I.point(10),I.mul(I.point(2),sq5))),4))
    cbox=I.cadd(I.complex(1),omega)
    t=I.csub(I.cmul(cbox,cbox),I.complex(4))
    if ar.cmp(t[1][0],0)<=0: raise Stop("PRECISION_EXHAUSTED","DISCRIMINANT_BRANCH_NOT_RESOLVED")
    modt=I.modulus(t)
    u=I.sqrt(I.scale(I.add(modt,t[0]),2));v=I.sqrt(I.scale(I.sub(modt,t[0]),2))
    qbox=u,v
    roots=[];wk=I.complex(1)
    for k in range(5):
        roots.append(I.cneg(wk));wk=I.cmul(wk,omega)
    for sign in (1,-1):
        numerator=I.cadd(I.cneg(cbox),qbox if sign==1 else I.cneg(qbox))
        roots.append((I.scale(numerator[0],2),I.scale(numerator[1],2)))
    ar.stage="separation_and_derivative_margins"
    distances=[[None]*7 for _ in range(7)]
    for i in range(7):
        for j in range(i):
            low=I.modulus(I.csub(roots[i],roots[j]))[0]
            distances[i][j]=distances[j][i]=low
            if ar.cmp(low,ar.make(3,8))<0:
                raise Stop("PRECISION_EXHAUSTED","FIXED_SEPARATION_MARGIN_NOT_RESOLVED")
    modulus=[I.modulus(z)[1] for z in roots]
    for j in (5,6):
        if ar.cmp(modulus[j],ar.make(7,4))>0:
            raise Stop("PRECISION_EXHAUSTED","RESIDUAL_MODULUS_MARGIN_NOT_RESOLVED")
    leading=[]
    for alpha in roots[:5]:
        ga=I.cadd(I.cadd(I.cmul(alpha,alpha),I.cmul(cbox,alpha)),I.complex(1))
        low=I.modulus(ga)[0]
        if ar.cmp(low,1)<0: raise Stop("PRECISION_EXHAUSTED","LEADING_MARGIN_NOT_RESOLVED")
        leading.append(ar.mul(5,low))
    derivative=[]
    for i in range(7):
        z=ar.make(1)
        for j in range(7):
            if i!=j:z=ar.mul(z,distances[i][j])
        if ar.cmp(z,1)<0: raise Stop("PRECISION_EXHAUSTED","DERIVATIVE_MARGIN_NOT_RESOLVED")
        derivative.append(z)
    return {"guards":guards,"omega_rectangle":I.encode(omega),"discriminant_rectangle":I.encode(t),
            "sqrt_discriminant_rectangle":I.encode(qbox),"center_rectangles":[I.encode(z) for z in roots],
            "center_labels":["-w^"+str(j) for j in range(5)]+["beta_plus","beta_minus"],
            "pairwise_center_distance_lower":[[None if x is None else str(x) for x in row] for row in distances],
            "center_modulus_upper":[str(x) for x in modulus],
            "ordinary_leading_modulus_lower":[str(x) for x in leading],
            "static_f0_derivative_modulus_lower":[str(x) for x in derivative],
            "certified_coarse_margins":{"center_distance_lower":"3/8","residual_modulus_upper":"7/4",
                "ordinary_leading_modulus_lower":"5","static_f0_derivative_modulus_lower":"1"}}, I


def residual_bounds(req,ar,s,r,eta,X):
    geometry,I=prepare_geometry(req,ar)
    if ar.cmp(X,eta)<0: raise Stop("INDETERMINATE","DIRECTION_DISK_NOT_COVERED")
    gap=ar.make(3,8);beta_radius=ar.make(7,4);rho=eta
    if ar.cmp(rho,gap)>=0: raise Stop("INDETERMINATE","RESIDUAL_DISK_RADIUS_NOT_SEPARATED")
    ar.stage="ordinary_cauchy_rouche"
    common=ar.power(ar.add(1,ar.power(s,2)),3)
    B=ar.mul(common,ar.power(ar.add(2,ar.mul(s,X)),7))
    mu=ar.mul(5,eta)
    E=ar.div(ar.mul(B,r),ar.mul(s,ar.sub(s,r)))
    threshold=ar.div(ar.mul(mu,ar.power(s,2)),ar.add(B,ar.mul(mu,s)))
    if ar.cmp(E,mu)>=0: raise Stop("INDETERMINATE","STRICT_ORDINARY_ROUCHE_TEST_NOT_MET")
    ar.stage="residual_cauchy_rouche"
    Bres=ar.mul(common,ar.power(ar.add(1,ar.add(beta_radius,rho)),7))
    nu=ar.mul(rho,ar.power(ar.sub(gap,rho),6))
    r2=ar.power(r,2);s2=ar.power(s,2)
    Eres=ar.div(ar.mul(Bres,r2),ar.sub(s2,r2))
    threshold2=ar.div(ar.mul(nu,s2),ar.add(Bres,nu))
    if ar.cmp(Eres,nu)>=0: raise Stop("INDETERMINATE","STRICT_RESIDUAL_ROUCHE_TEST_NOT_MET")
    ar.stage="q08_norm_envelope"
    moving_radius=ar.mul(r,X)
    max_radius=I.max([moving_radius,rho])
    Delta=ar.sub(gap,ar.mul(2,max_radius))
    if ar.cmp(Delta,0)<=0: raise Stop("INDETERMINATE","CROSS_CLUSTER_DISKS_NOT_SEPARATED")
    R=I.max([ar.add(1,moving_radius),ar.add(beta_radius,rho)])
    inv2=ar.div(ar.mul(7,ar.power(ar.add(1,R),12)),ar.power(Delta,12))
    R2=ar.power(R,2);term=ar.make(1);series=ar.make(0)
    for _ in range(7):
        series=ar.add(series,term);term=ar.mul(term,R2)
    forward2=ar.mul(7,series)
    return {"n":7,"geometry":geometry,"majorant_integer_exponent":3,
        "ordinary":{"count":5,"multiplicity":1,"direction":"0","direction_radius_upper":"0",
            "leading_modulus_lower":"5","B_upper":str(B),"mu_lower":str(mu),"E_upper":str(E),
            "strict_r_threshold":str(threshold),"tube_radius_factor":str(eta),"passed":True},
        "residual":{"count":2,"multiplicity":1,"rho":str(rho),"B_upper":str(Bres),
            "nu_lower":str(nu),"E_upper":str(Eres),"strict_r_squared_threshold":str(threshold2),"passed":True},
        "moving_center_disk_radius":str(moving_radius),"residual_center_disk_radius":str(rho),
        "Delta_lower":str(Delta),"root_modulus_upper":str(R),
        "inverse_norm_squared_upper":str(inv2),"forward_norm_squared_upper":str(forward2),
        "condition_number_squared_upper":str(ar.mul(inv2,forward2)),"certified_root_count":7,
        "applicability":{"tubes":"0 < |epsilon| <= r","norms":"epsilon_min <= |epsilon| <= r",
            "all_complex_arguments":True,"all_clusters_singletons":True,"epsilon_min_not_used_in_norm":True}}


def evaluate(request, source_directory):
    """Return a deterministic result; only CERTIFIED is a positive certificate."""
    ar, source_bytes, input_bytes = None, 0, 0
    source_progress = {"source_bytes_hashed": 0, "source_files_read": 0}
    try:
        # Reparse canonical bytes to impose identical checks on Python API use.
        try:
            raw = canonical(request)
        except (TypeError, ValueError, RecursionError):
            reject("NON_JSON_REQUEST")
        input_bytes = len(raw)
        req = strict_loads(raw)
        keys(req, REQUEST_KEYS, "REQUEST")
        if req["format"] != REQUEST_FORMAT:
            reject("REQUEST_FORMAT")
        keys(req["parameters"], {"A", "d", "b", "embedding_index"}, "PARAMETER")
        keys(req["budget"], {"max_bits", "max_steps"}, "BUDGET")
        bits, steps = req["budget"]["max_bits"], req["budget"]["max_steps"]
        if type(bits) is not int or not 32 <= bits <= MAX_BITS or type(steps) is not int or not 1 <= steps <= MAX_STEPS:
            reject("BUDGET_DOMAIN")
        ar = Arithmetic(bits, steps)
        if req["source_pins"] != SOURCE_PINS:
            reject("SOURCE_PIN_SET_MISMATCH")
        source_bytes = verify_sources(source_directory, source_progress)
        p = req["parameters"]
        if any(type(v) is not int for v in p.values()):
            reject("NONINTEGER_PARAMETER")
        A, d, b, embedding = (p[k] for k in ("A", "d", "b", "embedding_index"))
        if A < 1 or d < 3 or d % 2 != 1 or b < 0 or b >= d:
            reject("PARAMETER_DOMAIN")
        if not 1 <= embedding < d or gcd(embedding, d) != 1:
            reject("NONPRIMITIVE_EMBEDDING")
        n = A*d+b
        if A > MAX_A or d > MAX_D or n > MAX_N:
            raise Stop("INDETERMINATE", "SUPPORTED_FINITE_PARAMETER_CAP")
        if type(req["geometry_bits"]) is not int or not 0 <= req["geometry_bits"] <= 64:
            reject("GEOMETRY_PRECISION_DOMAIN")
        if type(req["profile"]) is not str:
            reject("PROFILE_TYPE")
        s, r, eta, X, emin = (ar.parse(req[k]) for k in ("s", "r", "eta", "X", "epsilon_min"))
        target = req["max_inverse_norm_squared"]
        if target is not None:
            target = ar.parse(target)
            if ar.cmp(target, 0) <= 0:
                reject("NORM_TARGET_DOMAIN")
        if not (ar.cmp(0, r) < 0 and ar.cmp(r, s) < 0 and ar.cmp(s, 1) < 0):
            reject("RADIUS_DOMAIN")
        if ar.cmp(eta, 0) <= 0 or ar.cmp(X, 0) < 0:
            reject("TUBE_DOMAIN")
        if ar.cmp(emin, 0) <= 0 or ar.cmp(emin, r) > 0:
            reject("ANNULUS_DOMAIN")
        bounds = residual_bounds(req, ar, s, r, eta, X)
        if target is not None and ar.cmp(Fraction(bounds["inverse_norm_squared_upper"]), target) > 0:
            return _result("INDETERMINATE", "REQUESTED_NORM_CEILING_NOT_CERTIFIED", ar, source_bytes, input_bytes, bounds)
        return _result("CERTIFIED", "FINITE_RESIDUAL_TUBES_AND_Q08_ENVELOPE", ar, source_bytes, input_bytes, bounds)
    except Stop as exc:
        return _result(exc.status, exc.reason, ar, source_progress["source_bytes_hashed"], input_bytes)


def _result(status, reason, ar, source_bytes, input_bytes, bounds=None):
    code_bytes = Path(__file__).read_bytes()
    out = {"checker_version": VERSION, "checker_sha256": hashlib.sha256(code_bytes).hexdigest(), "status": status, "reason": reason,
           "implementation_review": "PENDING_INDEPENDENT_REVIEW",
           "costs": {"canonical_input_bytes": input_bytes, "source_bytes_hashed": source_bytes,
                     "source_files_required": len(SOURCE_PINS),
                     "checker_bytes_hashed": len(code_bytes),
                     "cost_model": "byte volumes and exact arithmetic primitive counts; no bit-complexity or wall-time claim",
                     "all_preparation_repeated_on_each_validation": True}}
    if ar is not None:
        out["costs"].update(ar.costs())
    if bounds is not None:
        out["bounds"] = bounds
    return out


def make_certificate(request, source_directory):
    result = evaluate(request, source_directory)
    try:
        raw = canonical(request)
    except (TypeError, ValueError, RecursionError):
        return {"format": "rs-q08-certificate-error-v1", "result": result}
    return {"format": CERTIFICATE_FORMAT, "request": request,
            "request_sha256": hashlib.sha256(raw).hexdigest(),
            "result": result}


def verify_certificate(certificate, source_directory):
    """Recompute everything, then compare canonical bytes including cost trace."""
    try:
        keys(certificate, {"format", "request", "request_sha256", "result"}, "CERTIFICATE")
        if certificate["format"] != CERTIFICATE_FORMAT:
            reject("CERTIFICATE_FORMAT")
        expected = make_certificate(certificate["request"], source_directory)
        if canonical(expected) != canonical(certificate):
            reject("CERTIFICATE_MISMATCH")
        return {"verified": True, "status": expected["result"]["status"],
                "reason": expected["result"]["reason"]}
    except Stop as exc:
        return {"verified": False, "status": exc.status, "reason": exc.reason}
    except (TypeError, ValueError, RecursionError):
        return {"verified": False, "status": "REJECT", "reason": "NON_JSON_CERTIFICATE"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("certify", "verify"))
    parser.add_argument("input", type=Path)
    parser.add_argument("--sources", type=Path, default=Path(__file__).with_name("sources"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    try:
        maximum = MAX_INPUT_BYTES if args.operation == "certify" else MAX_CERTIFICATE_BYTES
        with args.input.open("rb") as stream:
            value = strict_loads(stream.read(maximum+1), maximum)
        out = make_certificate(value, args.sources) if args.operation == "certify" else verify_certificate(value, args.sources)
    except Stop as exc:
        out = {"status": exc.status, "reason": exc.reason}
    except OSError:
        out = {"status": "REJECT", "reason": "INPUT_IO_ERROR"}
    data = canonical(out) + b"\n"
    if args.output:
        args.output.write_bytes(data)
    else:
        sys.stdout.buffer.write(data)
    status = out.get("result", out)["status"]
    return {"CERTIFIED": 0, "REJECT": 2, "INDETERMINATE": 3, "PRECISION_EXHAUSTED": 4}[status]


if __name__ == "__main__":
    raise SystemExit(main())
