#!/usr/bin/env python3
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json,random,subprocess,sys,tempfile,unittest
from pathlib import Path
import rs_certificate as C
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'sources'
def request():return json.loads((ROOT/'examples/residual.request.json').read_text())
class Tests(unittest.TestCase):
    def check(self,q,status,reason=None):
        r=C.evaluate(q,SRC);self.assertEqual(r['status'],status,r)
        if reason:self.assertEqual(r['reason'],reason,r)
        return r
    def test_baseline(self):
        a=self.check(request(),'CERTIFIED');b=self.check(request(),'CERTIFIED')
        self.assertEqual(a,b);self.assertEqual(a['bounds']['certified_root_count'],7)
        self.assertEqual(a['bounds']['Delta_lower'],'1/4');self.assertEqual(a['bounds']['root_modulus_upper'],'29/16')
        self.assertTrue(C.verify_certificate(C.make_certificate(request(),SRC),SRC)['verified'])
    def test_exact_budget_boundaries_and_no_cached_preparation(self):
        q=request();out=self.check(q,'CERTIFIED');steps=out['costs']['arithmetic_steps'];bits=out['costs']['maximum_integer_bits_observed']
        q['budget'].update(max_steps=steps,max_bits=bits);self.check(q,'CERTIFIED')
        q['budget']['max_steps']=steps-1;self.check(q,'PRECISION_EXHAUSTED','ARITHMETIC_WORK_BUDGET')
        q['budget'].update(max_steps=steps,max_bits=bits-1);self.check(q,'PRECISION_EXHAUSTED','EXACT_INTEGER_BIT_BUDGET')
        q=request();q['budget']['max_steps']=1;self.check(q,'PRECISION_EXHAUSTED')
        q=request();q['budget']['max_bits']=32;self.check(q,'PRECISION_EXHAUSTED')
    def test_all_geometric_precisions(self):
        good=[];bad=[]
        for bits in range(65):
            q=request();q['geometry_bits']=bits;r=C.evaluate(q,SRC)
            self.assertIn(r['status'],('CERTIFIED','PRECISION_EXHAUSTED'))
            (good if r['status']=='CERTIFIED' else bad).append(bits)
        self.assertIn(24,good);self.assertIn(0,bad)
        (ROOT/'results/PRECISION_GRID.json').write_text(json.dumps({'certified':good,'exhausted':bad},indent=2)+'\n')
    def test_residual_guard_cannot_be_skipped(self):
        q=request();q.update(r='1/8192',epsilon_min='1/8192')
        self.check(q,'INDETERMINATE','STRICT_RESIDUAL_ROUCHE_TEST_NOT_MET')
    def test_ordinary_normalization(self):
        q=request();q.update(r='3/8192',epsilon_min='3/8192')
        self.check(q,'INDETERMINATE','STRICT_ORDINARY_ROUCHE_TEST_NOT_MET')
    def test_residual_strict_comparison_near_boundary(self):
        # threshold sqrt is generally irrational; take exact dyadic neighbors.
        b=self.check(request(),'CERTIFIED')['bounds'];t=F(b['residual']['strict_r_squared_threshold'])
        from math import isqrt
        scale=1<<50;k=isqrt(t.numerator*scale*scale//t.denominator)
        self.assertLess(F(k,scale)**2,t);self.assertGreater(F(k+1,scale)**2,t)
        for rr,status in [(F(k,scale),'CERTIFIED'),(F(k+1,scale),'INDETERMINATE')]:
            q=request();q.update(r=str(rr),epsilon_min=str(rr));self.check(q,status)
    def test_ordinary_exact_threshold_equality(self):
        b=self.check(request(),'CERTIFIED')['bounds'];q=request();t=b['ordinary']['strict_r_threshold'];q.update(r=t,epsilon_min=t)
        self.check(q,'INDETERMINATE','STRICT_ORDINARY_ROUCHE_TEST_NOT_MET')
    def test_different_profiles_and_embeddings(self):
        q=request();q['profile']='b0-hermite';self.check(q,'INDETERMINATE','UNSUPPORTED_PROFILE')
        for v in (2,3,4):
            q=request();q['parameters']['embedding_index']=v;self.check(q,'INDETERMINATE','UNSUPPORTED_PROFILE_EMBEDDING')
        for key,v,reason in [('A',2,'PROFILE_PARAMETER_MISMATCH'),('b',1,'PROFILE_PARAMETER_MISMATCH'),('d',3,'PROFILE_PARAMETER_MISMATCH'),('embedding_index',5,'NONPRIMITIVE_EMBEDDING'),('A',True,'NONINTEGER_PARAMETER')]:
            q=request();q['parameters'][key]=v;self.check(q,'REJECT',reason)
    def test_disk_domains(self):
        q=request();q['X']='1/32';self.check(q,'INDETERMINATE','DIRECTION_DISK_NOT_COVERED')
        q=request();q.update(eta='3/8',X='3/8');self.check(q,'INDETERMINATE','RESIDUAL_DISK_RADIUS_NOT_SEPARATED')
        q=request();q.update(eta='1/4',X='1/4');self.check(q,'INDETERMINATE','CROSS_CLUSTER_DISKS_NOT_SEPARATED')
    def test_source_tampering(self):
        q=request();q['source_pins']['accepted_finite_proof.tex']='0'*64;self.check(q,'REJECT','SOURCE_PIN_SET_MISMATCH')
        with tempfile.TemporaryDirectory() as td:
            for p in SRC.iterdir():(Path(td)/p.name).write_bytes(p.read_bytes())
            (Path(td)/'accepted_validator_v1_1.py.txt').write_text('wrong')
            self.assertEqual(C.evaluate(request(),td)['reason'],'SOURCE_HASH_MISMATCH:accepted_validator_v1_1.py.txt')
    def test_certificate_tampering(self):
        base=C.make_certificate(request(),SRC)
        for path,value in [(['result','bounds','residual','E_upper'],'0'),(['result','bounds','certified_root_count'],8),(['result','bounds','Delta_lower'],'1'),(['result','costs','arithmetic_steps'],0),(['result','status'],'REJECT')]:
            c=deepcopy(base);v=c
            for k in path[:-1]:v=v[k]
            v[path[-1]]=value;self.assertFalse(C.verify_certificate(c,SRC)['verified'])
        c=deepcopy(base);c['result']['bounds']['geometry']['center_rectangles'][5]['real'][0]='0'
        self.assertFalse(C.verify_certificate(c,SRC)['verified'])
    def test_norm_ceiling_and_epsilon_min(self):
        q=request();base=self.check(q,'CERTIFIED');bound=base['bounds']['inverse_norm_squared_upper']
        q['max_inverse_norm_squared']=bound;self.check(q,'CERTIFIED')
        q['max_inverse_norm_squared']=str(F(bound)-1);self.check(q,'INDETERMINATE','REQUESTED_NORM_CEILING_NOT_CERTIFIED')
        q=request();q['epsilon_min']='1/4194304';self.assertEqual(self.check(q,'CERTIFIED')['bounds'],base['bounds'])
    def test_inherited_parsing_error_contract(self):
        for value in [object(),float('nan'),float('inf'),complex(1,2),{1,2}]:
            q=request();q['s']=value;c=C.make_certificate(q,SRC)
            self.assertEqual(c['format'],'rs-q08-certificate-error-v1');self.assertFalse(C.verify_certificate(c,SRC)['verified'])
        q=request();loop=[];loop.append(loop);q['s']=loop;self.check(q,'REJECT','NON_JSON_REQUEST')
        for data in [b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":1.1}',b' '*65537,b'['*10000]:
            with self.assertRaises(C.Stop):C.strict_loads(data)
    def test_guard_mutation_grid(self):
        rng=random.Random(152);values=[None,True,False,[],{},0,-1,'','00','2/4','1/0','NaN','9'*256,'9'*257,0.125]
        for _ in range(500):
            q=request();q[rng.choice(list(q))]=rng.choice(values)
            self.assertIn(C.evaluate(q,SRC)['status'],('CERTIFIED','REJECT','INDETERMINATE','PRECISION_EXHAUSTED'))
    def test_cli_and_code_pin(self):
        with tempfile.TemporaryDirectory() as td:
            cert=Path(td)/'cert.json';r=subprocess.run([sys.executable,str(ROOT/'rs_certificate.py'),'certify',str(ROOT/'examples/residual.request.json'),'--output',str(cert)],capture_output=True)
            self.assertEqual(r.returncode,0,r.stderr)
            r=subprocess.run([sys.executable,str(ROOT/'rs_certificate.py'),'verify',str(cert)],capture_output=True);self.assertEqual(r.returncode,0,r.stderr)
            out=json.loads(cert.read_text());self.assertEqual(out['result']['checker_sha256'],sha256((ROOT/'rs_certificate.py').read_bytes()).hexdigest())
    def test_original_v11_bytes(self):
        self.assertEqual(sha256((SRC/'accepted_validator_v1_1.py.txt').read_bytes()).hexdigest(),'7cf350bfa8037e2addb3f26454a0e047b4f8df501500158292f45b9020d8a60c')
if __name__=='__main__':unittest.main(verbosity=2)
