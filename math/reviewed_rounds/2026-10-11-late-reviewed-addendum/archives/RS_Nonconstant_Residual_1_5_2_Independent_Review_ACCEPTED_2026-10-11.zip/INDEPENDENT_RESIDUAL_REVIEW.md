# Independent review of the finite nonconstant residual certificate

Review date: 11 October 2026 UTC.

## Decision

**ACCEPT** the single-profile reference checker at SHA-256
`739759b078f4382fc093c9acf8f2fdd59b54b2250daa369f09d692348d75c800`,
version `rs-q08-residual-1-5-2-candidate-0.1`, for the exact profile
`residual-1-5-2-embedding-1`: `(A,d,b)=(1,5,2)` and
`omega=exp(2*pi*i/5)`.

No mathematical or executable repair is required. Acceptance is external to
the checker's historical `PENDING_INDEPENDENT_REVIEW` self-report. Changing
that literal would change its identity and require another verification.

This acceptance covers the finite root preparation and bounded exact
reference API documented here, conditional on the pinned accepted finite
Cauchy/Rouche theorem and Q08 envelope. It does not merge this profile into
the accepted v1.1 checker or change that checker. General residual and
overlap preparation, other embeddings in this implementation, growing-degree
efficiency or stability, numerical RS evaluation/decoding, production/service
hardening, and historical novelty remain outside scope.

## Immutable evidence

The reviewed candidate is Library item
`libfile_a2d018f1d0d881918b6a179e2f79bc85`, version 0, archive SHA-256
`0d27bad1fbbef99ca8736f1f80fdb5f16989385895302dc75c672d1a9cb12ab7`
(245,030 bytes). A fresh archive extraction was used for executable replay.
All 31 members enumerated by its manifest match their byte counts and
hashes, and match the supplied local candidate. The archive has 32 members,
including its manifest. All ten source pins match.

The accepted v1.1 source and its review are byte-identical to the corresponding
members of the earlier accepted review archive, SHA-256
`27e6983a455d0839bcb37e2fadac84309cc62bb60fb988dd255f8b423b5c34f8`.
The preserved v1.1 checker has SHA-256
`7cf350bfa8037e2addb3f26454a0e047b4f8df501500158292f45b9020d8a60c`.
The finite proof dependency has SHA-256
`3b472a7adb4a157c52c6ad4f8da5e1d94717e360bce8326e8c4d8732cfbcc100`;
its accepted review is
`a412af68fbeffe1d6f332280a5b59e3ac74d91481c492232981319c51e0b6033`.
The Q08 envelope source has SHA-256
`02ec40df49f0585c57f98d3af7cbb9867216773f98a2998db9d51237fd69b787`.

Historical `.py.txt` programs and nested source archives were read or hashed
only as inert evidence. They were not imported, compiled, AST-parsed, or
executed. Execution was limited to the newly authored candidate, its fresh
author controls/tests, and the newly authored review controls. No candidate
code or accepted v1.1 source was edited. No Sheet or GitHub write was made.

## Exact algebra and embedding

In Q[w]/(1+w+w^2+w^3+w^4), independently computed exact arithmetic confirms

    F(z) = z^5 + 1
    G(z) = z^2 + (1+w)z + 1
    Disc(G) = -3 + 2w + w^2
    Res(F,G) = 5 + 10w + 10w^2
    Norm(Disc(G)) = 305
    Norm(Res(F,G)) = 3125.

The review computes the resultant with a Sylvester determinant, and each
field norm as a determinant of its multiplication matrix. These differ from
the candidate's products over roots and embeddings. Nonzero discriminant
and resultant establish simple residual roots and no residual/F-root
overlap. The field norms are algebraic norms across all four embeddings;
neither 305 nor 3125 is substituted for a complex modulus.

Weighted-subset enumeration of every Gaussian coefficient independently
proves H7(z;w)=F(z)G(z), in each of the four primitive embeddings. This is
independent of the author's Gaussian Pascal recurrence. Twenty exact static
root/local derivative identities, five per embedding, confirm the A=1
leading form

    P_alpha(x) = 5 alpha^4 G(alpha) x = -5 G(alpha) x / alpha.

The q branch has no linear epsilon term, so this is exactly the first-order
coefficient of H7(alpha+epsilon*x;q(epsilon)). The candidate uses embedding
1 only; testing the other embeddings algebraically does not expand its API.
Conjugation is w -> w^4 and w*conjugate(w)=1; this was checked separately.

## Radical geometry and derivative margins

The positive radicals t=sqrt(5), a=(t-1)/4, and
b=sqrt(10+2t)/4 give omega=a+i*b. They satisfy |omega|=1 and
Phi5(omega)=0. Its positive real and imaginary parts select embedding 1.
For c=1+omega and D=c^2-4, Im(D)>0. The positive square roots

    M = sqrt(Re(D)^2+Im(D)^2)
    u = sqrt((M+Re(D))/2)
    v = sqrt((M-Re(D))/2)

have 2uv=Im(D), so (u+i*v)^2=D. Consequently
beta_plus=(-c+u+i*v)/2 and beta_minus=(-c-u-i*v)/2 are the actual two
residual roots, with no ambiguous sign or unverified numerical root guess.

The candidate's interval addition, negation, multiplication, squaring,
modulus and positive scaling are outward. Its integer-square-root floor and
ceiling check both square inequalities. Negative lower radical arguments
or unresolved fixed margins fail closed. The review independently built
112-bit radical intervals using binary-search rational square comparisons,
without the candidate's arithmetic/interval classes or integer-isqrt
algorithm. These lie inside every accepted candidate rectangle at each
geometry precision 6 through 64. Precisions 0 through 5 exhaust safely.

At every accepted precision, the review checked all 21 pairwise lower
distances directly against the rectangle endpoints, all seven modulus
upper bounds, all seven product derivative lower bounds, and all five
ordinary leading-coefficient lower bounds. At the published 24-bit
precision the least distance lower bound is 7981317/16777216, exceeding
3/8; the residual moduli are at most 7/4; |G(alpha)| is at least 1; and
each product lower bound for |(FG)'(center)| exceeds 1. Thus the ordinary
leading modulus 5 and the simple residual derivative margins are justified.
These are static or leading derivatives, not perturbed numerical derivative
estimates.

The reported residual rectangles reproduce the exact endpoints in the
candidate report. The rectangles enclose the exact algebraic centers; their
midpoints are never substituted for those centers in the theorem.

## Both analytic tests and all seven roots

The branch q(epsilon)=omega*(1+epsilon^2)^(1/5), fixed at omega at zero, is
analytic for |epsilon|<1 and even in epsilon. Nonnegative Gaussian
coefficient bounds give exponent floor(7^2/4)/5=12/5; replacing it by 3 is
an upward bound because 1+s^2>1.

For the published request s=1/2, r=2^-20 and eta=X=rho=1/16, the ordinary
majorant and test are

    B_o = (1+s^2)^3 (2+sX)^7
        = 612778486328125/2199023255552
    mu_o = 5 eta = 5/16
    E_o = B_o r/[s(s-r)]
        = 612778486328125/576459652791795712 < mu_o.

The essential s^-1 normalization factor is present. Each ordinary direction
is zero and X>=eta is checked; each of the five disks
|z-alpha_k|<|epsilon|/16 contains one root counting multiplicity.

For a residual circle, every other static center is at least 3/8 away, so

    nu = rho(3/8-rho)^6 = 15625/268435456
    B_r = (1+s^2)^3 (1+7/4+rho)^7
        = 46708681640625/17179869184
    E_r = B_r r^2/(s^2-r^2)
        = 15569560546875/1574122160950821781504 < nu.

The even-in-epsilon Cauchy series supplies precisely this residual bound.
Its strict threshold is r^2<16/2989355689. Each residual disk
|z-beta_plus/minus|<1/16 therefore contains one simple root. This test is
not redundant: at r=1/8192 the ordinary test passes but the residual test
fails. Failure is inconclusive, not evidence of an actual collision.

The coarse center disk radii are rX=2^-24 and rho=1/16. The common separation
lower bound is Delta=3/8-2*max(rX,rho)=1/4, and the root modulus upper bound
is R=max(1+rX,7/4+rho)=29/16. All disks are disjoint, and the count 5+2=7
exhausts the monic polynomial's degree. Each root is simple. The result holds
for every complex epsilon with 0<|epsilon|<=2^-20, not just real epsilon.

The review checked exact ordinary threshold equality and relative
10^-70 neighbors in a request where the ordinary threshold is active;
180-bit dyadic neighbors of the residual threshold; exact final separation
equality and nearby rational radii; and the omitted-normalization control
at r=3/8192. All return the correct positive or inconclusive decision.

## Q08 factors

All seven clusters are singletons. Thus no within-cluster inverse-epsilon
factor survives; the cross-cluster power is n-1=6 before squaring. The
factor sqrt(n) before squaring is retained as 7:

    ||V^-1||_2^2 <= 7 (1+R)^12 Delta^-12
      = 482667664884521484375/16777216
    ||V||_2^2 <= 7 sum_{k=0}^6 R^(2k)
      = 3559663633456975639/281474976710656
    kappa_2(V)^2 <=
      1718134533735029637122107300906494140625/
      4722366482869645213696.

The bounds concern the exact square monomial Vandermonde on the actual
seven perturbed roots. The validated annulus is
2^-21<=|epsilon|<=2^-20. Its epsilon_min does not change these singleton
bounds. This is neither a rounded-matrix error certificate nor a
size-uniform estimate. The inverse-norm ceiling compares a sufficient upper
bound: its failure does not establish that the actual norm exceeds the
requested ceiling.

## API and resource boundary

The retained strict parser rejects duplicate keys, floating JSON numbers,
NaN/Infinity, excessive integer tokens, excessive input bytes, invalid
rational strings, and invalid domains. The source-pin set is exact and
each source is reread and hashed on each evaluation. Every certificate is
recomputed and compared canonically, including the request, code identity,
source-derived result, and cost trace. There is no trusted supplied geometry
or guard predicate.

Only status CERTIFIED is positive. A verified negative envelope stays
REJECT, INDETERMINATE, or PRECISION_EXHAUSTED. The inherited v1.1 non-JSON
Python error envelope has only format and result, carries REJECT, and is
not accepted as a decision certificate. Ten independently tested non-JSON
cases include NaN/infinities, unsupported objects, mixed-key mappings and
cyclic containers.

Decision reasons are first-failure diagnostics, not an exhaustive validation
report. In particular, the inherited finite-cap check can precede the exact
profile mismatch: A=2 gives REJECT/PROFILE_PARAMETER_MISMATCH, while A=17
gives INDETERMINATE/SUPPORTED_FINITE_PARAMETER_CAP. Both refuse certification.
This qualifies the documentation's shorthand that mismatched parameters
are rejected; it does not require an executable change or alter acceptance.
Likewise early resource exhaustion need not diagnose a later defect.

At geometry precision 24 the baseline charges 15,921 arithmetic primitives
and observes maximum checked integer width 809 bits. Exact budget-boundary
controls pass at those limits and exhaust immediately below each. These
are explicit admission checks, not peak-memory, allocation, CPU-time, or
bit-complexity bounds. Parsing, geometry preparation and arithmetic can
construct a temporary before its next admission check, as the corrected
v1.1 contract already states.

## Fresh test evidence

The archive-extracted author suite passes all 16 methods, including its
65-point precision grid and 500 mutations. The author's direct-Fraction
controls pass. The fresh CLI certificate is byte-identical to the sealed
published certificate and verifies successfully.

The independent review suite additionally passes:

- Sylvester resultant and multiplication-determinant norm calculations;
  four weighted-subset H7 identities and 20 exact first-order local jets.
- Independent 112-bit radical enclosures; every geometry inequality for
  all 59 accepted precisions, with six exhausted precisions.
- 27 valid analytic-parameter combinations within this single profile.
- 126 independently checked outward square-root boundary cases.
- 19 exact threshold, separation, norm-target, annulus, and budget controls.
- All 257 individual scalar-leaf mutations of the positive certificate.
- Ten individually missing sources, ten modified sources, and one oversized
  source, all refused; a changed-code-identity certificate test also refused.
- Ten non-JSON API cases, eight strict-JSON malformed inputs, three
  unsupported primitive embeddings, and three nonprimitive embeddings.
- All four CLI decision statuses with correct exit codes and verification
  behavior; verified negative envelopes remain negative.
- 1,500 independently seeded recursive request-leaf mutations: 1,390
  REJECT, 56 INDETERMINATE, 14 PRECISION_EXHAUSTED, and 40 CERTIFIED. Every
  positive mutation was checked against independent exact scalar formulas.

Tests supplement the proof and source audit; they do not prove arbitrary
future code changes sound. The reproducible controls, logs, sealed original
candidate, full source pins, and manifest accompany this report.

## Accepted next step

This closes one concrete nonconstant-residual preparation example for the
already accepted finite theorem. It supports an additive implementation
note under the existing Q08 work, with this checker hash and profile scope.
It creates no new theorem/fusion identifier and leaves the earlier accepted
v1.1 validator untouched. Any later consolidation needs its own fresh
record read and separately authorized write. No broader residual family,
additional embedding, production executor, or growing-degree claim follows.
