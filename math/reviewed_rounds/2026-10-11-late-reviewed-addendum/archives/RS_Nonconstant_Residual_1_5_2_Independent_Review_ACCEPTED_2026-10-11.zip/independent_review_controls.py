#!/usr/bin/env python3
"""New independent review controls. Only the fresh candidate is imported.

Historical .py.txt files and embedded archives remain inert. Exact Fraction
calculations below do not call the candidate's field, interval or bound code.
"""
from fractions import Fraction as F
from itertools import combinations
from functools import lru_cache
from pathlib import Path
from copy import deepcopy
import hashlib, importlib.util, json, random, shutil, subprocess, sys, tempfile

HERE = Path(__file__).resolve().parent
P = HERE/'candidate/RS_Residual_1_5_2'
SRC = P/'sources'
spec = importlib.util.spec_from_file_location('residual_review_candidate', P/'rs_certificate.py')
C = importlib.util.module_from_spec(spec); spec.loader.exec_module(C)
BASE = json.loads((P/'examples/residual.request.json').read_text())
REPORT = {}

def run(q, status=None, reason=None):
    r = C.evaluate(q, SRC)
    if status: assert r['status'] == status, r
    if reason: assert r['reason'] == reason, r
    return r

# Polynomial-remainder field implementation, independent of the candidate
# fixed-vector multiplication and author's exponent-modulo-5 implementation.
Z = (F(0),)*4
O = (F(1),F(0),F(0),F(0))
W = (F(0),F(1),F(0),F(0))
def reduce_poly(a):
    a=list(map(F,a))
    while len(a)>4:
        leading=a.pop(); offset=len(a)-4
        for i in range(4): a[offset+i]-=leading
    return tuple(a+[F(0)]*(4-len(a)))
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def neg(a): return tuple(-x for x in a)
def sub(a,b): return add(a,neg(b))
def mul(a,b):
    out=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): out[i+j]+=x*y
    return reduce_poly(out)
def scalar(x): return (F(x),F(0),F(0),F(0))
def power(a,n):
    out=O
    for _ in range(n): out=mul(out,a)
    return out
def evalk(coeffs,a):
    out=Z
    for x in reversed(coeffs): out=add(mul(out,a),scalar(x))
    return out
def determinant(matrix):
    n=len(matrix)
    @lru_cache(None)
    def d(columns):
        row=n-len(columns)
        if not columns: return O
        ans=Z
        for j,col in enumerate(columns):
            if matrix[row][col]!=Z:
                term=mul(matrix[row][col],d(columns[:j]+columns[j+1:]))
                ans=add(ans,term if j%2==0 else neg(term))
        return ans
    return d(tuple(range(n)))
def norm_by_det(a):
    columns=[mul(a,power(W,j)) for j in range(4)]
    mat=[[scalar(columns[j][i]) for j in range(4)] for i in range(4)]
    return determinant(mat)
def resultant_by_det(f,g):
    # Descending-coefficient Sylvester determinant, first deg(g) rows from f.
    m,n=len(f)-1,len(g)-1; mat=[]
    for coeff,repeat in [(list(reversed(f)),n),(list(reversed(g)),m)]:
        for shift in range(repeat):
            mat.append([Z]*shift+coeff+[Z]*(m+n-shift-len(coeff)))
    return determinant(mat)

def algebra(g):
    c=add(O,W); disc=sub(mul(c,c),scalar(4))
    f=[O]+[Z]*4+[O]; gg=[O,c,O]
    res=resultant_by_det(f,gg)
    assert disc==tuple(map(F,[-3,2,1,0]))
    assert res==tuple(map(F,[5,10,10,0]))
    assert norm_by_det(disc)==scalar(305)
    assert norm_by_det(res)==scalar(3125)
    for name,val in [('disc_G',disc),('resultant_F_G',res),
                     ('norm_disc_G',norm_by_det(disc)),('norm_resultant_F_G',norm_by_det(res))]:
        assert list(map(str,val))==g['guards'][name]
    jets=[]
    for embedding in range(1,5):
        w=power(W,embedding); cw=add(O,w)
        coeff=[]
        # Gaussian binomial via the weighted-subset identity, not Pascal.
        for k in range(8):
            a=Z
            for subset in combinations(range(7),k):
                a=add(a,power(w,sum(subset)-k*(k-1)//2))
            coeff.append(a)
        assert coeff==[O,cw,O,Z,Z,O,cw,O]
        for k in range(5):
            alpha=neg(power(w,k)); static=Z; derivative=Z
            for j,a in enumerate(coeff):
                static=add(static,mul(a,power(alpha,j)))
                if j: derivative=add(derivative,mul(scalar(j),mul(a,power(alpha,j-1))))
            ga=add(add(mul(alpha,alpha),mul(cw,alpha)),O)
            assert static==Z and derivative==mul(scalar(5),mul(power(alpha,4),ga))
            # Hermite A=1: -5 G(alpha)/alpha equals the derivative above.
            assert mul(derivative,alpha)==mul(scalar(-5),ga)
            jets.append([embedding,k])
    # Conjugation is w -> w^4, distinct from the four-embedding field norm.
    conj=lambda x: evalk(x,power(W,4))
    assert mul(W,conj(W))==O
    assert conj(conj(disc))==disc
    assert norm_by_det(conj(disc))==scalar(305)
    REPORT['algebra']={'sylvester_resultant':list(map(str,res)),
        'multiplication_determinant_norms':[305,3125],
        'weighted_subset_H7_identities':4,'exact_order_one_local_jets':len(jets),
        'conjugation_checks':True}

# Independent interval square roots by binary-search square comparisons.
# The candidate and author controls use integer isqrt instead.
def iv(x): return F(x),F(x)
def ia(a,b): return a[0]+b[0],a[1]+b[1]
def inn(a): return -a[1],-a[0]
def isu(a,b): return ia(a,inn(b))
def im(a,b):
    p=[x*y for x in a for y in b]; return min(p),max(p)
def scale(a,x): return im(a,iv(x))
def square(a):
    p=[a[0]**2,a[1]**2]
    return (F(0) if a[0]<=0<=a[1] else min(p)),max(p)
def bsqrt(x,h=112):
    assert x>=0; s=1<<h
    lo,hi=0,1
    while hi*hi*x.denominator <= x.numerator*s*s: hi*=2
    while hi-lo>1:
        mid=(lo+hi)//2
        if mid*mid*x.denominator <= x.numerator*s*s: lo=mid
        else: hi=mid
    return F(lo,s),F(lo if lo*lo*x.denominator==x.numerator*s*s else hi,s)
def isq(a,h=112): return bsqrt(a[0],h)[0],bsqrt(a[1],h)[1]
def ca(a,b): return ia(a[0],b[0]),ia(a[1],b[1])
def cn(a): return inn(a[0]),inn(a[1])
def cs(a,b): return ca(a,cn(b))
def cm(a,b): return isu(im(a[0],b[0]),im(a[1],b[1])),ia(im(a[0],b[1]),im(a[1],b[0]))
def normsq(a): return ia(square(a[0]),square(a[1]))
def cv(x): return iv(x),iv(0)
def decode(x): return tuple(map(F,x['real'])),tuple(map(F,x['imag']))
def contains(outer,inner): return all(outer[k][0]<=inner[k][0]<=inner[k][1]<=outer[k][1] for k in range(2))
def radicals():
    t=isq(iv(5)); omega=scale(isu(t,iv(1)),F(1,4)),scale(isq(ia(iv(10),scale(t,2))),F(1,4))
    c=ca(cv(1),omega); d=cs(cm(c,c),cv(4)); assert d[1][0]>0
    m=isq(normsq(d)); u=isq(scale(ia(m,d[0]),F(1,2))); v=isq(scale(isu(m,d[0]),F(1,2)))
    assert u[0]>0 and v[0]>0
    sqrtd=u,v; roots=[]; a=cv(1)
    for _ in range(5): roots.append(cn(a)); a=cm(a,omega)
    for term in [sqrtd,cn(sqrtd)]:
        q=cs(term,c); roots.append((scale(q[0],F(1,2)),scale(q[1],F(1,2))))
    return omega,d,sqrtd,roots
HIGH=radicals()

def geometry(g):
    for name,box in zip(['omega_rectangle','discriminant_rectangle','sqrt_discriminant_rectangle'],HIGH[:3]):
        assert contains(decode(g[name]),box)
    centers=list(map(decode,g['center_rectangles']))
    assert all(contains(a,b) for a,b in zip(centers,HIGH[3]))
    distances=g['pairwise_center_distance_lower']
    for i in range(7):
        assert distances[i][i] is None
        prod=F(1)
        for j in range(7):
            if i==j: continue
            d=F(distances[i][j]); assert d==F(distances[j][i]) and d>=F(3,8)
            assert d*d<=normsq(cs(centers[i],centers[j]))[0]
            prod*=d
        assert prod==F(g['static_f0_derivative_modulus_lower'][i]) and prod>=1
        mod=F(g['center_modulus_upper'][i]); assert mod*mod>=normsq(centers[i])[1]
        if i>=5: assert mod<=F(7,4)
    c=ca(cv(1),decode(g['omega_rectangle']))
    for i,a in enumerate(centers[:5]):
        val=ca(ca(cm(a,a),cm(c,a)),cv(1)); lo=F(g['ordinary_leading_modulus_lower'][i])
        assert lo>=5 and (lo/5)**2<=normsq(val)[0]

def formulas(q,b):
    s,r,eta,X,emin=[F(q[k]) for k in ['s','r','eta','X','epsilon_min']]
    assert 0<emin<=r<s<1 and X>=eta>0 and eta<F(3,8)
    B=(1+s*s)**3*(2+s*X)**7; mu=5*eta; E=B*r/(s*(s-r))
    Br=(1+s*s)**3*(1+F(7,4)+eta)**7; nu=eta*(F(3,8)-eta)**6; Er=Br*r*r/(s*s-r*r)
    for name,val in [('B_upper',B),('mu_lower',mu),('E_upper',E),('strict_r_threshold',mu*s*s/(B+mu*s))]:
        assert F(b['ordinary'][name])==val
    for name,val in [('B_upper',Br),('nu_lower',nu),('E_upper',Er),('strict_r_squared_threshold',nu*s*s/(Br+nu))]:
        assert F(b['residual'][name])==val
    assert E<mu and Er<nu
    delta=F(3,8)-2*max(r*X,eta); R=max(1+r*X,F(7,4)+eta); assert delta>0
    inv=7*(1+R)**12/delta**12; forward=7*sum(R**(2*j) for j in range(7))
    for name,val in [('Delta_lower',delta),('root_modulus_upper',R),('inverse_norm_squared_upper',inv),('forward_norm_squared_upper',forward),('condition_number_squared_upper',inv*forward)]:
        assert F(b[name])==val
    assert b['certified_root_count']==7 and b['ordinary']['count']==5 and b['residual']['count']==2
    return B,mu,Br,nu

def boundaries(base):
    controls=[]
    def expect(q,status,reason=None):
        rr=run(q,status,reason)
        if status=='CERTIFIED': formulas(q,rr['bounds'])
        controls.append({'status':rr['status'],'reason':rr['reason']})
    # Put the ordinary threshold below the residual threshold, so its lower
    # neighbor is genuinely certified rather than masked by another failure.
    q=deepcopy(BASE); q.update(eta='1/1048576',X='1/1048576',r='1/1099511627776',epsilon_min='1/1099511627776')
    b=run(q,'CERTIFIED')['bounds']; t=F(b['ordinary']['strict_r_threshold']); h=F(1,10**70)
    for x,status in [(t*(1-h),'CERTIFIED'),(t,'INDETERMINATE'),(t*(1+h),'INDETERMINATE')]:
        w=deepcopy(q); w.update(r=str(x),epsilon_min=str(x)); expect(w,status,None if status=='CERTIFIED' else 'STRICT_ORDINARY_ROUCHE_TEST_NOT_MET')
    t2=F(base['bounds']['residual']['strict_r_squared_threshold']); low,hi=bsqrt(t2,180)
    assert low*low<t2<hi*hi
    for x,status in [(low,'CERTIFIED'),(hi,'INDETERMINATE')]:
        w=deepcopy(BASE); w.update(r=str(x),epsilon_min=str(x)); expect(w,status,None if status=='CERTIFIED' else 'STRICT_RESIDUAL_ROUCHE_TEST_NOT_MET')
    for x,reason in [('1/8192','STRICT_RESIDUAL_ROUCHE_TEST_NOT_MET'),('3/8192','STRICT_ORDINARY_ROUCHE_TEST_NOT_MET')]:
        w=deepcopy(BASE); w.update(r=x,epsilon_min=x); expect(w,'INDETERMINATE',reason)
    B,mu,Br,nu=formulas(BASE,base['bounds']); s=F(BASE['s'])
    x=F(1,8192); assert B*x/(s*(s-x))<mu and Br*x*x/(s*s-x*x)>nu
    x=F(3,8192); assert B*x/(s-x)<mu<B*x/(s*(s-x))
    # Exact final separation equality and close rational neighbors.
    for eta,status in [(F(3,16)-F(1,10**20),'CERTIFIED'),(F(3,16),'INDETERMINATE'),(F(3,16)+F(1,10**20),'INDETERMINATE')]:
        w=deepcopy(BASE); w.update(eta=str(eta),X=str(eta),r=str(F(1,2**100)),epsilon_min=str(F(1,2**100)))
        expect(w,status,None if status=='CERTIFIED' else 'CROSS_CLUSTER_DISKS_NOT_SEPARATED')
    inv=F(base['bounds']['inverse_norm_squared_upper'])
    for v,status in [(inv,'CERTIFIED'),(inv-F(1,10**70),'INDETERMINATE'),(inv+F(1,10**70),'CERTIFIED')]:
        w=deepcopy(BASE); w['max_inverse_norm_squared']=str(v); expect(w,status,None if status=='CERTIFIED' else 'REQUESTED_NORM_CEILING_NOT_CERTIFIED')
    for field,key in [('max_steps','arithmetic_steps'),('max_bits','maximum_integer_bits_observed')]:
        for difference,status in [(0,'CERTIFIED'),(-1,'PRECISION_EXHAUSTED')]:
            w=deepcopy(BASE);w['budget'][field]=base['costs'][key]+difference;expect(w,status)
    for emin in ['1/1048576','1/1099511627776']:
        w=deepcopy(BASE);w['epsilon_min']=emin;out=run(w,'CERTIFIED');assert out['bounds']==base['bounds'];expect(w,'CERTIFIED')
    REPORT['exact_boundary_controls']=controls

def leaves(obj,path=()):
    if isinstance(obj,dict):
        for k,v in obj.items(): yield from leaves(v,path+(k,))
    elif isinstance(obj,list):
        for k,v in enumerate(obj): yield from leaves(v,path+(k,))
    else: yield path,obj
def setpath(obj,path,value):
    for k in path[:-1]:obj=obj[k]
    obj[path[-1]]=value
def tamper_and_api():
    certificate=C.make_certificate(BASE,SRC); paths=list(leaves(certificate))
    for path,v in paths:
        m=deepcopy(certificate);setpath(m,path,0 if v is None else None)
        assert C.verify_certificate(m,SRC)['verified'] is False
    REPORT['certificate_scalar_leaf_mutations']=len(paths)
    with tempfile.TemporaryDirectory() as td:
        target=Path(td)/'sources';shutil.copytree(SRC,target)
        for name in C.SOURCE_PINS:
            p=target/name;data=p.read_bytes();p.unlink()
            out=C.evaluate(BASE,target);assert out['status']=='REJECT' and out['reason']=='SOURCE_UNAVAILABLE:'+name
            p.write_bytes(data+b'\nMUTATION')
            out=C.evaluate(BASE,target);assert out['status']=='REJECT' and out['reason']=='SOURCE_HASH_MISMATCH:'+name
            p.write_bytes(data)
        oversized=target/'accepted_finite_proof.tex';oversized.write_bytes(b'x'*1048577)
        assert C.evaluate(BASE,target)['reason']=='SOURCE_SIZE_LIMIT:accepted_finite_proof.tex'
    REPORT['source_missing_modified_oversized_controls']=21
    cyc=[];cyc.append(cyc);cycd={};cycd['self']=cycd
    bad=[float('nan'),float('inf'),-float('inf'),complex(1,2),object(),{1,2},b'bytes',cyc,cycd,{1:0,'x':1}]
    for value in bad:
        q=deepcopy(BASE);q['s']=value;c=C.make_certificate(q,SRC)
        assert set(c)=={'format','result'} and c['format']=='rs-q08-certificate-error-v1'
        assert c['result']['status']=='REJECT' and c['result']['reason']=='NON_JSON_REQUEST'
        assert C.verify_certificate(c,SRC)['verified'] is False
    REPORT['non_JSON_error_envelopes']=len(bad)
    for embedding in (2,3,4):
        q=deepcopy(BASE);q['parameters']['embedding_index']=embedding
        run(q,'INDETERMINATE','UNSUPPORTED_PROFILE_EMBEDDING')
    for embedding in (0,5,-1):
        q=deepcopy(BASE);q['parameters']['embedding_index']=embedding;run(q,'REJECT','NONPRIMITIVE_EMBEDDING')
    cli=[]
    with tempfile.TemporaryDirectory() as td:
        d=Path(td)
        requests=[]
        for status in ['CERTIFIED','REJECT','INDETERMINATE','PRECISION_EXHAUSTED']:
            q=deepcopy(BASE)
            if status=='REJECT':q['r']='0'
            if status=='INDETERMINATE':q['r']=q['epsilon_min']='1/8192'
            if status=='PRECISION_EXHAUSTED':q['budget']['max_steps']=1
            requests.append((status,q))
        for status,q in requests:
            path=d/'q.json';cert=d/'certificate.json';path.write_bytes(C.canonical(q))
            ret=subprocess.run([sys.executable,str(P/'rs_certificate.py'),'certify',str(path),'--output',str(cert)],capture_output=True)
            code={'CERTIFIED':0,'REJECT':2,'INDETERMINATE':3,'PRECISION_EXHAUSTED':4}[status]
            assert ret.returncode==code,(ret.stderr,ret.stdout)
            out=json.loads(cert.read_bytes()); assert out['result']['status']==status
            ret=subprocess.run([sys.executable,str(P/'rs_certificate.py'),'verify',str(cert)],capture_output=True)
            assert ret.returncode==code
            verified=json.loads(ret.stdout);assert verified['verified'] and verified['status']==status
            cli.append(verified)
        # Different source identity must not accept a certificate bound to the
        # reviewed checker, even if the only change is a harmless comment.
        changed=d/'changed.py';changed.write_bytes((P/'rs_certificate.py').read_bytes()+b'\n# Review mutation\n')
        cert.write_bytes(C.canonical(certificate))
        ret=subprocess.run([sys.executable,str(changed),'verify',str(cert),'--sources',str(SRC)],capture_output=True)
        assert ret.returncode==2 and json.loads(ret.stdout)['reason']=='CERTIFICATE_MISMATCH'
    REPORT['CLI_status_roundtrips']=cli
    malformed=[b'{"x":1,"x":2}',b'{"x":1.0}',b'{"x":NaN}',b'{"x":Infinity}',b'{"x":12345678901}',b' '*65537,b'['*5000,b'\xff']
    for raw in malformed:
        try:C.strict_loads(raw)
        except C.Stop as error:assert error.status=='REJECT'
        else:raise AssertionError(raw)
    REPORT['strict_JSON_controls']=len(malformed)
    rng=random.Random(202610111655);paths=[p for p,_ in leaves(BASE)]
    values=[None,True,False,0,-1,1,5,[],{},'','0','1/2','1/16','00','2/4','1/0','-0','9'*256,'9'*257,0.125]
    counts={}
    for _ in range(1500):
        q=deepcopy(BASE);setpath(q,rng.choice(paths),deepcopy(rng.choice(values)));out=run(q)
        assert out['status'] in ('CERTIFIED','REJECT','INDETERMINATE','PRECISION_EXHAUSTED')
        counts[out['status']]=counts.get(out['status'],0)+1
        if out['status']=='CERTIFIED': formulas(q,out['bounds'])
    REPORT['seeded_recursive_request_mutations']=counts

def main():
    baseline=run(BASE,'CERTIFIED'); b=baseline['bounds']
    algebra(b['geometry']); geometry(b['geometry']); formulas(BASE,b)
    accepted=[];exhausted=[]
    for h in range(65):
        q=deepcopy(BASE);q['geometry_bits']=h;r=run(q)
        if r['status']=='CERTIFIED': geometry(r['bounds']['geometry']);formulas(q,r['bounds']);accepted.append(h)
        else:assert r['status']=='PRECISION_EXHAUSTED';exhausted.append(h)
    assert accepted==list(range(6,65)) and exhausted==list(range(6))
    REPORT['independently_checked_geometry_precisions']={'accepted':accepted,'exhausted':exhausted,'independent_radical_bits':112}
    # Expanded valid request grid: the same exact profile only.
    grid=[]
    for s in [F(1,4),F(1,2),F(3,4)]:
        for eta in [F(1,64),F(1,16),F(1,8)]:
            for multiplier in [1,2,4]:
                q=deepcopy(BASE);q.update(s=str(s),eta=str(eta),X=str(eta*multiplier),r=str(F(1,2**30)),epsilon_min=str(F(1,2**40)))
                r=run(q,'CERTIFIED');formulas(q,r['bounds']);grid.append([str(s),str(eta),str(eta*multiplier)])
    REPORT['valid_analytic_parameter_grid']=len(grid)
    # Outward sqrt checks independent of geometry, including dyadic boundaries.
    n=0
    for h in [0,1,2,6,24,32,64]:
        for k in [0,1,2,3,11,101]:
            exact=F(k,2**h)**2
            for x in [exact,exact+F(1,2**(2*h+13)),max(F(0),exact-F(1,2**(2*h+13)))]:
                a=C.Arithmetic(32768,200000);lo,hi=a.sqrt_enclosure(x,h)
                assert 0<=lo<=hi and lo*lo<=x<=hi*hi and hi-lo<=F(1,2**h)
                assert (lo,hi)==bsqrt(x,h);n+=1
    REPORT['independent_sqrt_boundary_controls']=n
    boundaries(baseline);tamper_and_api()
    REPORT.update(status='PASS',checker_sha256=hashlib.sha256((P/'rs_certificate.py').read_bytes()).hexdigest(),
        baseline_costs=baseline['costs'], inverse_norm_squared_upper=b['inverse_norm_squared_upper'])
    (HERE/'results/INDEPENDENT_REVIEW_CONTROLS.json').write_text(json.dumps(REPORT,indent=2)+'\n')
    print(json.dumps(REPORT,indent=2))

if __name__=='__main__':main()
