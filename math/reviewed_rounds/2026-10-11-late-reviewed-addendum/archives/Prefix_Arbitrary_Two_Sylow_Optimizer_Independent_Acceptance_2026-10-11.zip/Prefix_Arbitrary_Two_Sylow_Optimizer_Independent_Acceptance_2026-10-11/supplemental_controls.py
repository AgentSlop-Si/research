"""Additional independent threshold geometry and escape-state controls."""
import json,time
from collections import Counter
from bisect import bisect_right
from independent_controls import ROOT,FiniteGroup,cyclic,abelian,dihedral,heisenberg,direct,V
from math import gcd
CNT=Counter();start=time.time()
def translated(G,S,g):return {G.table[g][x] for x in S}
def geometry(G,H,P,p,b,seq):
 stabs=G.prefix_stabilizers(seq);prefix=[set()];cur=set()
 for x in seq:cur=cur|{x};prefix.append(cur)
 projections=[set(range(P.n))]+[{g%P.n for g in S} for S in stabs]
 Hproj=[{g//P.n for g in S} for S in stabs]
 checkpoints=[[0]+[j for j in range(1,G.n+1) if len(projections[j])>=p**s] for s in range(b+1)]
 for j,L in enumerate(Hproj,1):
  r=0
  while p**r<len(projections[j]):r+=1
  for s in range(r+1,b+1):
   k=bisect_right(checkpoints[s],j);lo,hi=checkpoints[s][k-1:k+1];unit=p**s*len(L)
   assert ((lo+unit-1)//unit)*unit<j<(hi//unit)*unit
   CNT['strict_actual_clips']+=1
   if len(L)>1:
    closure=set().union(*(translated(G,prefix[lo],ell*P.n) for ell in L))
    core=set.intersection(*(translated(G,prefix[hi],ell*P.n) for ell in L))
    assert prefix[lo]<=closure<=prefix[j]<=core<=prefix[hi]
    assert len(closure)%unit==len(core)%unit==0
    # Checking generators is enough and avoids repeated copies of large sets.
    for Q,S in [(projections[lo],closure),(projections[hi],core)]:
     for z in Q:assert translated(G,S,z)==S
    CNT['actual_closure_core_pairs']+=1
    if not projections[lo]<=projections[hi] and not projections[hi]<=projections[lo]:CNT['incomparable_endpoint_projection_pairs']+=1
 Horders={len(T) for T in H.subgroups()};Porders={len(T) for T in P.subgroups()}
 assert {p**i for i in range(b+1)}<=Porders

H=dihedral(4)
for source in json.loads((ROOT/'source_snapshots/FROZEN_ESCAPE_CONTROLS.json').read_text()):
 P=abelian(3,3,3,3) if 'C3xC3xC3xC3' in source['group'] else direct(heisenberg(3),cyclic(3))
 G=direct(H,P);geometry(G,H,P,3,4,source['order'])

# All subset paths, tracking the generated proper-stabilizer subgroup explicitly.
rows=[]
for H,P,q,a,p,b in [(cyclic(3),cyclic(2),3,1,2,1),(abelian(2,2),cyclic(3),2,2,3,1),(cyclic(3),abelian(2,2),3,1,2,2)]:
 G=direct(H,P);n=G.n;end=(1<<n)-1;subs=G.subgroups();where={S:i for i,S in enumerate(subs)}
 join={}
 for i,A in enumerate(subs):
  for j,B in enumerate(subs):join[i,j]=where[G.generated(tuple(sorted(A|B)))]
 stabs=[]
 for mask in range(end+1):
  E={i for i in range(n) if mask>>i&1};stabs.append(frozenset(g for g in range(n) if translated(G,E,g)==E))
 dp=[{} for _ in range(end+1)];dp[0][where[frozenset([0])]]=(0,())
 for mask in range(1,end+1):
  si=where[stabs[mask]];bits=mask
  while bits:
   bit=bits&-bits;bits-=bit;x=bit.bit_length()-1
   for bi,(score,path) in dp[mask^bit].items():
    nxt=bi if mask==end else join[bi,si];total=score+len(stabs[mask])-1
    if nxt not in dp[mask] or dp[mask][nxt][0]<total:dp[mask][nxt]=(total,path+(x,))
  CNT['escape_dp_states']+=len(dp[mask])
 full=where[frozenset(range(n))];answer=dp[end].get(full)
 if answer:
  gap=(p-1)*p**max(0,b-2);assert answer[0]<=V(q,a,p,b)-gap
  sequence=list(answer[1]);Ss=G.prefix_stabilizers(sequence);proper=sum(len({g%P.n for g in S})==P.n for S in Ss[:-1])
  if proper:assert answer[0]<=V(q,a,p,b)-p**(b-1)*(p-1)
 else:sequence=None;proper=None
 rows.append(dict(group=G.name,N=n,q=q,a=a,p=p,b=b,escape_maximum=None if answer is None else answer[0],witness=sequence,proper_full_P_checkpoints=proper,maximum_value=V(q,a,p,b)))
result=dict(counts=dict(CNT),small_escape_dp=rows,failures=0,seconds=time.time()-start)
(ROOT/'SUPPLEMENTAL_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
