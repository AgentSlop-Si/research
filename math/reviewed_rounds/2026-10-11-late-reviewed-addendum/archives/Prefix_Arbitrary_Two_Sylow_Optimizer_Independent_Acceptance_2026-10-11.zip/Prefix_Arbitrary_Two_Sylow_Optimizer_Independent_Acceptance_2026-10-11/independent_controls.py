"""Fresh review implementation. No author/inherited mathematical code is run or imported."""
from pathlib import Path
from itertools import product,permutations
from functools import lru_cache
from bisect import bisect_right
from math import gcd,factorial
from collections import Counter
import json,random,time
ROOT=Path(__file__).resolve().parent
RAND=random.Random(173611102026)
COUNTS=Counter()
def save(name,data): (ROOT/name).write_text(json.dumps(data,indent=2)+'\n')
def V(q,a,p,b): return q**a*p**b*a*(q-1)//q+q**a*p**b*b*(p-1)//p
def numerical(q,a,p,sets):
 n=q**a;m=len(sets)-1;length=max(sets[0]); membership=[set(x) for x in sets]
 levels=[max(s for s in range(m+1) if j in membership[s]) for j in range(1,length+1)]
 caps=[]
 for j,r in enumerate(levels,1):
  if r==m: caps.append(gcd(j//p**m,n));continue
  cap=1
  for i in range(1,a+1):
   d=q**i
   if j%(p**r*d):continue
   ok=True
   for s in range(r+1,m+1):
    k=bisect_right(sets[s],j);lo,hi=sets[s][k-1:k+1];u=p**s*d
    if not ((lo+u-1)//u)*u<j<(hi//u)*u:ok=False;break
   if ok:cap+=d-d//q
  caps.append(cap)
 return [(r,h,p**r*h-1) for r,h in zip(levels,caps)]
def eval_edge(q,a,p,k,l):
 # Direct physical gap count, independently of the closed edge expression.
 n=q**a; ds=[q**i for i in range(1,a+1)]
 e=p*gcd(l,n)-1
 for d in ds:
  low=((k+d-1)//d)*p*d;high=(l//d)*p*d
  e+=(d-d//q)*max(0,(high-low)//d-1)
 potential=p*sum(gcd(j,n) for j in range(k+1,l+1))-(l-k)
 loss=potential-e;m=l-k;g=gcd(gcd(k,l),n)
 w={d:max(0,l//d-(k+d-1)//d) for d in ds}
 closed=p*(gcd(l,n)+sum((d-d//q)*w[d] for d in ds))-1-sum(d-d//q for d in ds if w[d])
 assert e==closed
 X=[d for d in ds if k%d and l%d and (l-1)//d>k//d]
 identity=p*(m-g+sum(d-d//q for d in X))+1-m+sum(d-d//q for d in ds if w[d])
 assert loss==identity and loss>=0 and ((loss==0)==(m==g))
 assert loss==0 or loss>=p-1
 if loss==0:assert not k<n<l
 COUNTS['edge_identity_checks']+=1
 return e,loss
def audit_collapse(q,a,p,C):
 L=max(C[0]);m=len(C)-1;original=sum(z[2] for z in numerical(q,a,p,C));cur=C
 for eliminated in range(m-1):
  length=max(cur[0]);before=numerical(q,a,p,cur)
  dense=[cur[0],list(range(0,length+1,p))]+cur[2:]
  after=numerical(q,a,p,dense)
  assert sum(z[2] for z in before)<=sum(z[2] for z in after)
  assert all(after[j-1][1:]==(1,0) for j in range(1,length+1) if j%p)
  assert all(before[j-1]==after[j-1] for j in cur[1] if j)
  # Verify exact whole-gap increments individually, keeping all higher clips.
  ds=[q**i for i in range(1,a+1)]
  for left,right in zip(cur[1],cur[1][1:]):
   u,v=left//p,right//p;delta=(p-1)*(v-u-1)
   for d in ds:
    low=u;high=v
    for s in range(2,len(cur)):
     ix=bisect_right(cur[s],left);lo=cur[s][ix-1];hi=cur[s][ix]
     unit=p**s*d;low=max(low,((lo+unit-1)//unit)*unit//p);high=min(high,(hi//unit)*unit//p)
    rcount=sum(1 for t in range(low+1,high) if t%d==0) if low<high else 0
    oldcount=max(0,p*(high//d-(low+d-1)//d)-1) if low<high else 0
    delta+=(d-d//q)*(p*rcount-oldcount)
   measured=sum(after[j-1][2]-before[j-1][2] for j in range(left+1,right))
   assert measured==delta and delta>=0
   COUNTS['whole_gap_comparisons']+=1
  quotient=[list(range(length//p+1))]+[[j//p for j in points] for points in cur[2:]]
  uq=sum(z[2] for z in numerical(q,a,p,quotient))
  assert sum(z[2] for z in after)==p*uq+(p-1)*length//p
  assert original<=p**(eliminated+1)*uq+(eliminated+1)*(p-1)*L//p
  cur=quotient;COUNTS['densification_quotient_steps']+=1
 path=[j//p for j in cur[1]];edges=[eval_edge(q,a,p,k,l) for k,l in zip(path,path[1:])]
 usum=sum(z[2] for z in numerical(q,a,p,cur));assert usum==sum(x[0] for x in edges)
 return p**(m-1)*usum+(m-1)*(p-1)*L//p,sum(x[1] for x in edges)
def make_hierarchy(L,p,m,mode):
 C=[list(range(L+1))]
 for s in range(1,m+1):
  C.append([0]+[j for j in C[-1][1:-1] if j%p**s==0 and RAND.random()<.55]+[L])
 if mode==0:C[-1]=[0,L]
 elif mode==1:C=[C[0]]+[[0,L] for _ in range(m)]
 elif mode==2:C=[C[0]]+[list(range(0,L+1,p**s)) for s in range(1,m)]+[[0,L]]
 return C
def arithmetic():
 records=[]
 specs=[(q,a,p,b) for q,a,p in [(2,0,3),(2,1,3),(2,3,3),(3,1,2),(3,2,2),(5,1,2),(2,2,5),(7,1,2)] for b in range(1,9) if q**a*p**b<=3500]
 specs += [(3,1,2,9),(3,1,2,10),(3,1,2,11),(3,1,2,12),(2,1,7,3),(3,0,2,13)]
 for q,a,p,b in specs:
  n=q**a;N=n*p**b
  for sample in range(16 if b<=8 else 4):
   C=make_hierarchy(N,p,b,sample%4);vec=numerical(q,a,p,C);u=sum(z[2] for z in vec);bound,loss=audit_collapse(q,a,p,C)
   assert u<=bound<=V(q,a,p,b) and V(q,a,p,b)-bound==p**(b-1)*loss
   COUNTS['full_hierarchies']+=1
   if a and len(C[-1])>2 and n//q not in [j//p**b for j in C[-1]]:assert loss>=p-1;COUNTS['proper_top_barriers']+=1
   if b>=2 and C[-1]==[0,N]:
    trunc=numerical(q,a,p,C[:-1]);assert vec[:-1]==trunc[:-1]
    correction=(p-1)*n*p**(b-1);assert u==sum(z[2] for z in trunc)+correction
    w,loss2=audit_collapse(q,a,p,C[:-1]);w+=correction
    assert u<=w<=V(q,a,p,b) and V(q,a,p,b)-w==p**(b-2)*loss2
    if n not in [j//p**(b-1) for j in C[-2]]:assert loss2>=p-1;COUNTS['missing_rank_n_barriers']+=1
    if loss2==0:assert n in [j//p**(b-1) for j in C[-2]];COUNTS['zero_loss_rank_n_paths']+=1
    COUNTS['top_deletions']+=1
   records.append(dict(q=q,a=a,p=p,b=b,checkpoints=C[1:],U=u,collapsed=bound))
 for q,a,p,m,t in [(2,3,3,4,11),(3,2,2,6,7),(5,2,2,3,9),(2,0,3,3,4),(7,1,2,5,3),(5,1,2,9,3),(2,2,3,5,10),(7,2,5,2,23)]:
  for i in range(15):
   C=make_hierarchy(t*p**m,p,m,3);audit_collapse(q,a,p,C);COUNTS['unrelated_extended_domains']+=1
   records.append(dict(q=q,a=a,p=p,depth=m,extended_length=t*p**m,checkpoints=C[1:]))
 # Exhaustive arbitrary hierarchies on short extended lengths via exact levels.
 for q,a,p,m,L in [(3,1,2,2,12),(2,2,3,2,18),(3,0,2,3,16),(5,1,2,2,8)]:
  points=list(range(p,L,p));options=[]
  for j in points:
   v=0
   while v<m and j%p**(v+1)==0:v+=1
   options.append(range(v+1))
  for levels in product(*options):
   C=[list(range(L+1))]+[[0]+[j for j,r in zip(points,levels) if r>=s]+[L] for s in range(1,m+1)]
   audit_collapse(q,a,p,C);COUNTS['exhaustive_extended_hierarchies']+=1
 for q,a,p in [(2,0,3),(2,4,3),(3,3,2),(5,2,7),(7,2,5)]:
  for _ in range(1200):
   k=RAND.randrange(0,10*q**a);l=k+RAND.randrange(1,5*q**a+1);eval_edge(q,a,p,k,l)
 save('FRESH_ARITHMETIC_RECORDS.json',records)
 print('ARITHMETIC',dict(COUNTS),flush=True)

class FiniteGroup:
 def __init__(self,name,elements,multiply):
  self.name=name;self.elements=list(elements);self.n=len(self.elements);labels={x:i for i,x in enumerate(self.elements)}
  self.table=[[labels[multiply(x,y)] for y in self.elements] for x in self.elements]
  assert all(self.table[0][j]==j==self.table[j][0] for j in range(self.n))
 @lru_cache(None)
 def generated(self,seeds):
  found={0};front=[0]
  for x in front:
   for s in seeds:
    y=self.table[s][x]
    if y not in found:found.add(y);front.append(y)
  return frozenset(found)
 @lru_cache(None)
 def subgroups(self):
  result={frozenset([0])};todo=list(result)
  for K in todo:
   for x in range(self.n):
    if x in K:continue
    T=self.generated(tuple(sorted(K|{x})))
    if T not in result:result.add(T);todo.append(T)
  return tuple(sorted(result,key=lambda T:(len(T),tuple(sorted(T)))))
 @lru_cache(None)
 def maxima(self,K):
  candidates=[T for T in self.subgroups() if T<K]
  return tuple(T for T in candidates if not any(T<U for U in candidates))
 def sequence(self,K=None,J=None):
  if K is None:K=frozenset(range(self.n))
  if len(K)==1:return list(K)
  if J is None:J=RAND.choice(self.maxima(K))
  remains=set(K);representatives=[]
  while remains:
   x=min(remains);representatives.append(x);remains-={self.table[y][x] for y in J}
  RAND.shuffle(representatives)
  return [self.table[y][x] for x in representatives for y in self.sequence(J)]
 def prefix_stabilizers(self,seq):
  target=0;translated=[0]*self.n;out=[]
  for x in seq:
   target|=1<<x
   for g in range(self.n):translated[g]|=1<<self.table[g][x]
   out.append(frozenset(g for g,z in enumerate(translated) if z==target))
  return out
def cyclic(n):return FiniteGroup('C'+str(n),range(n),lambda x,y:(x+y)%n)
def abelian(*ns):return FiniteGroup('x'.join('C'+str(n) for n in ns),product(*(range(n) for n in ns)),lambda x,y:tuple((u+v)%n for u,v,n in zip(x,y,ns)))
def dihedral(rotation):return FiniteGroup('D'+str(2*rotation),product(range(rotation),range(2)),lambda x,y:((x[0]+(1 if x[1]==0 else -1)*y[0])%rotation,(x[1]+y[1])%2))
def quaternion():return FiniteGroup('Q8',product(range(4),range(2)),lambda x,y:((x[0]+(-1)**x[1]*y[0]+2*x[1]*y[1])%4,(x[1]+y[1])%2))
def heisenberg(p):return FiniteGroup('Heis'+str(p**3),product(range(p),repeat=3),lambda x,y:((x[0]+y[0])%p,(x[1]+y[1])%p,(x[2]+y[2]+x[0]*y[1])%p))
def direct(A,B):
 G=FiniteGroup(A.name+'x'+B.name,product(range(A.n),range(B.n)),lambda x,y:(A.table[x[0]][y[0]],B.table[x[1]][y[1]]))
 if gcd(A.n,B.n)==1:
  G.subgroups=lambda:tuple(frozenset(x*B.n+y for x in K for y in L) for K in A.subgroups() for L in B.subgroups())
 return G
def inspect(H,P,q,a,p,b,seq,kind):
 G=direct(H,P);return inspect_in(G,H,P,q,a,p,b,seq,kind)
def inspect_in(G,H,P,q,a,p,b,seq,kind):
 assert sorted(seq)==list(range(G.n));stabs=G.prefix_stabilizers(seq);Z=sum(len(S)-1 for S in stabs)
 B=G.generated(tuple(sorted(set().union(*stabs[:-1]))));betas=[];ranks=[]
 for j,S in enumerate(stabs,1):
  hs={g//P.n for g in S};ps={g%P.n for g in S};assert len(S)==len(hs)*len(ps) and j%len(S)==0
  r=0
  while p**r<len(ps):r+=1
  assert p**r==len(ps);betas.append(len(hs));ranks.append(r)
 C=[list(range(G.n+1))]+[[0]+[j for j,r in enumerate(ranks,1) if r>=s] for s in range(1,b+1)]
 vec=numerical(q,a,p,C);U=sum(z[2] for z in vec);value=V(q,a,p,b)
 assert Z<=U<=value and all(beta<=cap[1] for beta,cap in zip(betas,vec))
 if b:
  Dtop=sum(p**b*(gcd(j//p**b,H.n)-betas[j-1]) for j in C[b][1:]);assert Z<=U-Dtop
  if a and len(B)==G.n:
   assert value-Z>=(p-1)*p**max(0,b-2)
   if len(C[b])>2:assert value-Z>=p**(b-1)*(p-1)
  if b>=2 and C[b]==[0,G.n]:
   Dpen=sum(p**(b-1)*(gcd(j//p**(b-1),H.n)-betas[j-1]) for j in C[b-1][1:-1])
   w,loss=audit_collapse(q,a,p,C[:-1]);w+=(p-1)*H.n*p**(b-1)
   assert Z<=U-Dpen<=w-Dpen and value-w==p**(b-2)*loss
   COUNTS['actual_retained_penultimate_deficits']+=1
 if kind=='recursive':assert Z==value and B in G.maxima(frozenset(range(G.n)))
 if Z==value and G.n>1:
  assert B in G.maxima(frozenset(range(G.n)))
  size=len(B)
  for start in range(0,G.n,size):assert {G.table[g][seq[start]] for g in B}==set(seq[start:start+size])
 if a and b and len(B)==G.n:COUNTS['actual_escaping_orders']+=1
 COUNTS['actual_group_orders']+=1
 return dict(kind=kind,order=seq,Z=Z,U=U,V=value,B=sorted(B),proper_full_P_checkpoints=len(C[b])-2 if b else None,checkpoint_sets=C[1:])
def group_checks():
 specs=[(cyclic(3),dihedral(8),3,1,2,4),(cyclic(3),dihedral(16),3,1,2,5),(cyclic(3),abelian(2,2,2,2),3,1,2,4),(cyclic(3),abelian(4,4),3,1,2,4),(heisenberg(3),dihedral(8),3,3,2,4),(dihedral(4),direct(heisenberg(3),cyclic(3)),2,3,3,4),(cyclic(1),dihedral(16),3,0,2,5),(dihedral(4),cyclic(1),2,3,3,0),(cyclic(1),cyclic(1),2,0,3,0),(heisenberg(3),dihedral(16),3,3,2,5),(quaternion(),heisenberg(3),2,3,3,3),(cyclic(3),dihedral(32),3,1,2,6),(cyclic(3),abelian(2,2,2,2,2),3,1,2,5)]
 out=[]
 for H,P,q,a,p,b in specs:
  G=direct(H,P);rows=[]
  if G.n==1:rows.append(inspect_in(G,H,P,q,a,p,b,[0],'singleton'))
  else:
   for J in G.maxima(frozenset(range(G.n))):rows.append(inspect_in(G,H,P,q,a,p,b,G.sequence(J=J),'recursive'))
   for i in range(12):
    if i%2:seq=G.sequence();s,t=RAND.sample(range(G.n),2);seq[s],seq[t]=seq[t],seq[s];kind='perturbed'
    else:seq=list(range(G.n));RAND.shuffle(seq);kind='random'
    rows.append(inspect_in(G,H,P,q,a,p,b,seq,kind))
  out.append(dict(group=G.name,q=q,a=a,p=p,b=b,N=G.n,orders=rows))
  print('GROUP',G.name,len(rows),flush=True)
 save('FRESH_GROUP_RECORDS.json',out)
 # Exact replay of all four saved author escaping permutations.
 replay=[];H=dihedral(4)
 for source in json.loads((ROOT/'source_snapshots/FROZEN_ESCAPE_CONTROLS.json').read_text()):
  P=abelian(3,3,3,3) if 'C3xC3xC3xC3' in source['group'] else direct(heisenberg(3),cyclic(3))
  G=direct(H,P);row=inspect_in(G,H,P,2,3,3,4,source['order'],'source_escape_replay')
  assert row['Z']==source['Z'] and row['U']==source['U'] and len(row['B'])==source['B_size']==G.n
  assert row['proper_full_P_checkpoints']==source['proper_full_P_checkpoints']==0
  replay.append(row);COUNTS['exact_saved_escape_replays']+=1
 save('EXACT_ESCAPE_REPLAYS.json',replay)
 # Fresh switching construction with both factors nonabelian at new p depths.
 fresh=[]
 for P,p,b in [(direct(heisenberg(3),abelian(3,3)),3,5),(dihedral(16),2,5)]:
  H=dihedral(4) if p==3 else heisenberg(3);q,a=(2,3) if p==3 else (3,3)
  G=direct(H,P)
  if p==3:
   maxes=P.maxima(frozenset(range(P.n)));L,M=maxes[:2]
   first={h*P.n+z for h in [0,1] for z in L};last={h*P.n+z for h in [4,7] for z in M};fill=set(range(4*P.n,5*P.n))-last
   middle=list(set(range(G.n))-first-last-fill);RAND.shuffle(middle)
   seq=sorted(first)+sorted(fill)+middle+sorted(last)
   row=inspect_in(G,H,P,q,a,p,b,seq,'fresh_switch');assert len(row['B'])==G.n and row['proper_full_P_checkpoints']==0;fresh.append(row)
 save('FRESH_ESCAPE_STRESS.json',fresh)

def exact_counts():
 rows=[]
 for G in [cyclic(1),cyclic(2),cyclic(3),cyclic(4),abelian(2,2),cyclic(6),cyclic(8),dihedral(4),quaternion(),abelian(2,2,2),cyclic(9),abelian(3,3),cyclic(12),direct(cyclic(3),abelian(2,2))]:
  total=1<<G.n;stabsets=[None]*total;weights=[0]*total
  for mask in range(1,total):
   elements=[i for i in range(G.n) if mask>>i&1];s=[]
   for g in range(G.n):
    translated=sum(1<<G.table[g][x] for x in elements)
    if translated==mask:s.append(g)
   stabsets[mask]=frozenset(s);weights[mask]=len(s)-1
  score=[-1]*total;count=[0]*total;score[0]=0;count[0]=1
  for mask in range(1,total):
   bits=mask
   while bits:
    bit=bits&-bits;bits-=bit;prev=mask^bit;c=score[prev]+weights[mask]
    if c>score[mask]:score[mask]=c;count[mask]=count[prev]
    elif c==score[mask]:count[mask]+=count[prev]
  @lru_cache(None)
  def recurrence(K):
   if len(K)==1:return 1
   return sum(factorial(len(K)//len(J))*recurrence(J)**(len(K)//len(J)) for J in G.maxima(K))
  assert count[-1]==recurrence(frozenset(range(G.n)))
  enumerated=0;tops=Counter()
  if G.n<=8:
   for seq in permutations(range(G.n)):
    mask=0;s=0;gen=set()
    for pos,x in enumerate(seq,1):
     mask|=1<<x;s+=weights[mask]
     if pos<G.n:gen.update(stabsets[mask])
    if s==score[-1]:
     enumerated+=1
     if G.n>1:
      B=G.generated(tuple(sorted(gen)));assert B in G.maxima(frozenset(range(G.n)))
      for start in range(0,G.n,len(B)):assert set(seq[start:start+len(B)])=={G.table[y][seq[start]] for y in B}
      tops[str(sorted(B))]+=1
   assert enumerated==count[-1]
   COUNTS['exhaustive_permutations']+=factorial(G.n)
  COUNTS['subset_dp_states']+=total
  rows.append(dict(group=G.name,N=G.n,maximum=score[-1],labeled_optimum_count=count[-1],recurrence_count=recurrence(frozenset(range(G.n))),subset_states=total,exhaustive_optimizer_count=enumerated if G.n<=8 else None,top_counts=dict(tops)))
 save('EXACT_OPTIMIZER_COUNTS.json',rows);print('COUNTS',rows,flush=True)

if __name__=='__main__':
 start=time.time();arithmetic();group_checks();exact_counts()
 save('CONTROL_SUMMARY.json',dict(seed=173611102026,counts=dict(COUNTS),failures=0,seconds=time.time()-start,independent_code=True,source_programs_run_or_imported=False))
 print('SUMMARY',dict(COUNTS),'seconds',time.time()-start,flush=True)
