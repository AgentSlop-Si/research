# Accepted arbitrary two Sylow prefix optimizer theorem

Independent project mathematical review, 11 October 2026 UTC. Decisions: A ACCEPT, B ACCEPT, C ACCEPT, D ACCEPT, E ACCEPT, with the recurrence explicitly restricted to nontrivial groups and the singleton supplied by its stated base case. No mathematical repair of the proof is required.

Let p and q be distinct primes. Let H be any finite group of order q^a, P any finite group of order p^b, a,b≥0, and G=H×P. Neither factor is required to be abelian. For a labeled element ordering x, define

    T_j={x_1,...,x_j},  S_j={g∈G:gT_j=T_j},
    Z_G(x)=Σ_(j=1)^|G| (|S_j|−1),
    B(x)=⟨S_j:1≤j<|G|⟩,
    V(a,b)=q^a p^b[a(1−1/q)+b(1−1/p)].

The full prefix is scored and is excluded from B. The empty prefix is not scored.

## A Maximum value

For all such groups,

    max_x Z_G(x)=V(a,b).

This was already accepted; the present review preserves and rechecks its use.

## B Sufficient full escape deficit

If a,b≥1 and B(x)=G, then

    Z_G(x)≤V(a,b)−δ_p(b),
    δ_p(1)=p−1,
    δ_p(b)=p^(b−2)(p−1) for b≥2.

If at least one proper prefix has P-projection of its stabilizer equal to all of P, the stronger sufficient loss p^(b−1)(p−1) holds. The sufficient deficit is not asserted to be sharp. Previously accepted stronger cyclic-factor bounds remain valid.

## C Complete optimizer classification

The maximizing orders are exactly those obtained by recursive maximal-subgroup right-coset blocks. For every nontrivial group encountered, choose one maximal proper subgroup J, arrange its distinct right cosets consecutively in any order, and independently use an optimal local element order in each coset after a right-translation identification with J. Recurse until singleton groups.

## D Unique top

For every nontrivial maximizing order, its top subgroup is unique and is exactly B(x). This includes prime-order groups, whose unique top subgroup is the trivial group. The singleton has score 0, one ordering, and no top subgroup.

## E Labeled recurrence

Let A(K) count labeled maximizing element orderings. Set A(1)=1. For |H×P|>1,

    A(H×P)=p! Σ_(R maximal in P) A(H×R)^p
                 +q! Σ_(M maximal in H) A(M×P)^q.

The sum belonging to a trivial factor is empty. On either nontrivial prime-power axis there is one nonempty sum. At the singleton the base case A(1)=1 applies instead of the recurrence. Maximal subgroups are actual subgroups, not conjugacy classes. Counts are not divided by translations or automorphisms. A different coset representative gives no additional element ordering.

## Binding and limits

This acceptance binds Library libfile_bb0d9ff7a2008191a0a0f1ebfa85e419, version 0, a 75,273-byte archive with SHA-256 e8b8aa9ad126047014f82c97588f8025ec10ed5821c51675af1de5385e3815e9. Its unchanged 25,739-byte candidate proof has SHA-256 56959d5056ef4f144b99a9e4969d9dd2e43e75da01389b913760e89c2a9e37ed.

The acceptance rests on the universal symbolic proof, supported by separately reported fresh bounded controls. It is an independent project review, not external peer review or proof-assistant certification. It covers exactly direct products of two arbitrary finite prime-power groups of distinct prime orders, including the axes and singleton. It does not settle three-prime groups, all finite nilpotent groups, sharp escaping maxima, historical novelty, or the existing external source-comparison gap. No Sheet or GitHub mutation is included.
