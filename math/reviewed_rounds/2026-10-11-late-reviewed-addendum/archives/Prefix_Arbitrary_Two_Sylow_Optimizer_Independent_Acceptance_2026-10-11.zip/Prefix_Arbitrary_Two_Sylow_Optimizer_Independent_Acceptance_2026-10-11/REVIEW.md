# Independent review of arbitrary two Sylow prefix optimizers

11 October 2026 UTC. A ACCEPT, B ACCEPT, C ACCEPT, D ACCEPT, E ACCEPT. The claimed extension is supported by an arbitrary-depth symbolic argument. No step needs extrapolation from the accepted depth-two or depth-three cases. No mathematical repair is required. The accepted statement makes explicit that recurrence (3) applies only to nontrivial groups, with A(1)=1 as the separate base case already specified by the candidate.

## Scope and independence

This review addresses the finite groups G=H×P with |H|=q^a, |P|=p^b, p and q distinct primes, and arbitrary group structures in both factors. It checks the numerical hierarchy on extended lengths, the deletion of an absent top level, all b−2 elimination steps, the exact final-endpoint correction, retained actual deficits, maximal-subgroup trapping, the induction on a+b, all equality cases, unique-top recovery, and labeled counting. Axes and singleton are included.

The review independently materialized the candidate and both accepted dependency archives from Library. Their archive bytes, lengths, hashes, ZIP integrity, the candidate's 19 declared payload-member hashes, and all seven reused source snapshots were checked. The frozen candidate proof and relevant accepted statements and proofs were read. Original and inherited mathematical scripts were read as inert source only; none was executed or imported. All fresh mathematical controls were authored independently for this review. The supplemental script imports only the newly authored reviewer implementation.

The candidate's aggregate arithmetic hierarchies and most group permutations are not saved in its packet, so those aggregate tests are not described as exact reruns. The review generated fresh hierarchy instances on the candidate's full parameter coverage and additional stress cases, retained all newly tested group orders, and independently replayed all four saved escaping permutations exactly. Controls corroborate the proof and do not establish universal depth by finite sampling.

## Claim decisions

- A, the accepted maximum V(a,b): ACCEPT. Its threshold upper bound is valid for arbitrary nonabelian factors, and prime-index block recursion attains it.
- B, sufficient full-escape loss δ_p(b), and the stronger proper-top-checkpoint branch: ACCEPT. Sections 4 and 7 prove the stated bounds analytically for every b.
- C, complete recursive maximal-subgroup right-coset optimizer classification: ACCEPT. Strict escape and exact local deficit accounting force every optimal ordering into consecutive maximal-subgroup blocks.
- D, unique top B(x), with no singleton top: ACCEPT. The first completed block supplies the whole top stabilizer, while trapping contains every other proper stabilizer.
- E, labeled recurrence with both prime-power axes: ACCEPT for every nontrivial group, with A(1)=1 as the separate singleton base. This explicit domain removes the possible literal reading of two empty sums at the singleton. It is a clarification of the candidate's stated base-case convention, not a new mathematical premise.
- Three-prime groups, all finite nilpotent groups, sharp escape bounds, priority, and closure of the external source-comparison gap: outside scope, not accepted by this review.

## The actual group hierarchy

Every subgroup of H×P splits as L×Q. For each (h,z) in the subgroup, powers chosen modulo the coprime orders of h and z isolate (h,1) and (1,z). This requires no commutativity inside H or P. Thus S_j=L_j×Q_j is legitimate, and the free left action gives |L_j||Q_j| dividing j. The threshold sets C_s={0}∪{j:|Q_j|≥p^s} are nested, contain 0 and N, and lie in p^s Z. No common chain of endpoint subgroups is selected.

For a current index j at level r<s and consecutive enclosing C_s endpoints a_s,z_s, choose order-p^s subgroups A,D preserving those endpoint sets. Such subgroups exist in the relevant finite p-groups. The lower L_j-closure is a union of L_j-translates of T_(a_s), and the upper L_j-core is an intersection of translates of T_(z_s). They lie respectively below and above T_j. Since H and P commute elementwise across factors, the closure is invariant under L_j×A and the core under L_j×D. Their cardinalities are multiples of β_j p^s.

For every q-power d dividing β_j, these facts bound j between the appropriate rounded multiples of p^s d. Equality at either outer rounded bound forces the closure or core to equal T_j, thereby giving a higher P-level and contradicting r<s. Hence every strict clip in candidate (4) is valid simultaneously. The argument does not require A=D, comparability, or normality of lower endpoint subgroups.

The q-power weight identity β−1=Σ_(d|β,d>1)(d−d/q) gives β_j≤h_C(j). At a top checkpoint, the direct divisibility bound gives β_j≤gcd(j/p^b,n). Consequently Z≤U. The difference U−Z is exactly a sum of nonnegative pointwise terms p^r(h_C−β_j). Selecting actual terms D_top or D_pen and subtracting them before an upper-bound relaxation is therefore valid. An inequality U≤W gives Z≤W−D without scaling or replacing D. This simple ordering of inequalities resolves the retained-deficit issue at every depth.

## Extended numerical domain and whole gap comparison

The essential extension is to arbitrary positive physical lengths L divisible by p^m, with the q-power base n fixed. There is no requirement L/p^m=n, nor that this quotient be a prime power. All defining caps and clips remain meaningful. The argument treats this object numerically and never invokes a group theorem on a fictitious group of mixed base np.

Consider consecutive lowest positive checkpoints pu<pv and r=v−u. There are no positive-level checkpoints in the open gap, so every higher enclosing pair is constant there. For each d=q^i, intersect the higher clipping intervals in rank coordinates with (u,v), giving integer endpoints L_d,U_d. The original physical d-multiples satisfying all clips are counted exactly by

    N_d=max(0,p[floor(U_d/d)−ceil(L_d/d)]−1)

when L_d<U_d, and by zero otherwise. After adding all missing level-one checkpoints pt at once, their eligible d-weights are counted by R_d=#{t:L_d<t<U_d,d|t}. The new baseline is (p−1)(r−1). Every residual nonmultiple of p has adjacent level-one endpoints of consecutive ranks, so no d≥2 can pass its level-one clip. Its H-cap is 1 and its contribution is 0. The candidate now states this correctly.

The exact new-minus-old gap contribution is therefore

    Δ=(p−1)(r−1)+Σ_d (d−d/q)(pR_d−N_d).

If both endpoints are divisible by d, the multiplier is −(p−1). If exactly one is divisible, it is 0 when no eligible rank exists and 1 otherwise. If neither is divisible, it is 0, p, or p+1 for respectively zero, one, or at least two eligible ranks. These cases also handle an empty or too-short interval. A negative term requires d≤U_d−L_d≤r. If d_* is the largest q-power at most min(r,n), including 1, all potentially negative weights sum to at most d_*−1. Hence

    Δ≥(p−1)(r−d_*)≥0.

This estimate uses no upper bound on u,v or L relative to n and permits any number of higher clips. Gaps longer than n are covered by d_*≤n≤r. Positive-level contributions already present do not change because their caps depend only on strictly higher levels. This proves whole-gap densification on the extended domain; it does not claim monotonicity for arbitrary single-checkpoint insertion or group realizability of the modified hierarchy.

## Exact quotient and arbitrary depth induction

After fully densifying C_1, discard zero-contribution nonmultiples of p, divide every remaining physical index by p, and decrement its level. Divisibility tests, top gcd caps, and higher clips correspond exactly, with n unchanged. At each surviving index,

    p^r h−1=p[p^(r−1)h−1]+(p−1).

There are L/p surviving positive indices, so candidate (9) is exact:

    U_dense=p U_quotient+(p−1)L/p.

For depth one, the quotient depth-zero functional is simply Σ_(j=1)^(L/p)(gcd(j,n)−1). The candidate separately defines this case, avoiding an undefined empty hierarchy.

Successively combining densification and quotienting proves by induction on k that

    U_initial≤p^k U_remaining+k(p−1)L/p,  0≤k≤m−1.

At the next step, the local additive term (p−1)L/p^(k+1) is multiplied by p^k and therefore contributes exactly another (p−1)L/p. This verifies the accumulation independently of any finite test. Surviving level-s checkpoints after k steps are the original C_(s+k), divided by p^k. Thus the original top path and its associated actual retained deficits survive unchanged in meaning. In particular, none of the proof needs a unique chain of P-subgroups or an equality assumption on the densification itself.

## Edge potential and barriers

At depth one, each open gap from pk to pl has the exact eligible counts used in E_p(k,l), and the endpoint has contribution p gcd(l,n)−1. The candidate's edge expression is therefore exact for every integer 0≤k<l, including l>n and l>np.

Let m=l−k and g=gcd(k,l,n). Direct counting of strict interior multiples gives

    ℓ_p=pA+B,
    A=m−g+Σ_(d∈X)(d−d/q),
    B=1−m+Σ_(d:w_d>0)(d−d/q),

with X exactly as in candidate (12). Both-endpoint divisibility contributes the telescoping weight g−1. Since g divides m, either m=g or m≥2g. In the latter case,

    ℓ_p≥p(m−g)+1−m
       =(p−1)(m−2g)+(p−2)g+1≥p−1.

If m=g, the endpoints are consecutive multiples of the q-power m dividing n. For all d≤m, both endpoints are divisible and the weighted terms cancel; for d>m there is no interior d-multiple. Thus ℓ_p=0. This proves nonnegativity, the exact zero criterion, and the positive loss quantum on the unrestricted integer range.

A zero edge is an aligned interval of q-power length d|n. It cannot cross the rank n strictly in its interior, proving the rank-n barrier for paths to np. In a nontrivial zero path from 0 to n, the length-n edge 0→n is absent, so every edge length divides n/q. No such aligned edge crosses n/q strictly, proving the other barrier. The nontriviality hypothesis is indispensable and is used exactly in the proper-full-P branch.

Finally, gcd(k,n) is n-periodic. The telescoping q-weight sum gives s(n)=n+an(1−1/q), and hence s(np)=p s(n). This also holds for n=1, with the weight set empty.

## Normal maximal subgroup trapping

For a normal prime-index subgroup J, a proper prefix equal to one right coset Jx traps every proper-prefix stabilizer inside J. Earlier nonempty prefixes are subsets of that coset, and an element outside J sends the coset disjointly elsewhere. Later prefixes contain the full coset; invariance under an outside element cycles it through all quotient cosets and forces the entire group. This proves trapping without requiring stabilizers to persist.

Every maximal subgroup of a finite p-group is normal and has index p. The supplied normalizer argument is correct: a proper K acts by left multiplication on cosets P/K. Nontrivial orbits have size divisible by p, the total number of cosets is divisible by p, and at least the identity coset is fixed. Therefore the number of fixed cosets is at least p; these are N_P(K)/K. A maximal R must consequently satisfy N_P(R)=P, and P/R has order p because it has no nontrivial proper subgroup. The same applies to H. No assertion is made that all smaller subgroups are normal.

## Escape with a proper full P checkpoint

With at least one proper C_b checkpoint, the top path from 0 to n is nontrivial. The b−1 elimination steps and the edge telescope give

    V−Z≥p^(b−1)Σ_edges ℓ_p+D_top.

If n/q is absent, the nontrivial-path barrier forces a positive edge, giving p^(b−1)(p−1). If the rank is present and its actual H-stabilizer has the full possible size n/q, its stabilizer K×P has the same size as the prefix. A nonempty invariant set of that size is one right coset. K is normal of index q, so trapping contradicts B=G. Otherwise the actual deficit there is at least p^b, stronger than needed. When n/q=1 the deficient option is impossible, since β≥1.

For b=1, this branch is exhaustive under B=G: absent a proper full-P checkpoint, all proper P-projections are trivial, so B≤H×1. The bound is therefore p−1 without invoking a missing-top argument at an invalid depth.

## Deleting an absent top level

Suppose b≥2 and C_b={0,N}. For every d|n, the omitted level-b clip is exactly 0<j<N, since p^b d divides N. It is redundant at all proper indices. At a proper level-(b−1) checkpoint the old cap equals gcd(j/p^(b−1),n), which is the new top cap; all lower-level proper contributions also stay unchanged.

Only the final endpoint changes. Its old contribution is N−1, while its new contribution in the truncated hierarchy is

    p^(b−1)gcd(np,n)−1=np^(b−1)−1.

Thus U_b=Ũ_(b−1)+(p−1)np^(b−1) exactly. The deleted numerical level is not represented as an actual group ordering, and the base remains n.

The original proper level-(b−1) deficits are

    D_pen=Σ_(j∈C_(b−1),0<j<N)
                  p^(b−1)[gcd(j/p^(b−1),n)−β_j].

Every term is an actual nonnegative deficit in U_b−Z. The final endpoint is correctly excluded: its contribution was changed by truncation and is instead handled by the explicit correction above. Hence Z≤U_b−D_pen before any numerical relaxation.

## Exactly b minus two eliminations

The truncated hierarchy has m=b−1 and physical length L=N. Applying the proved extended-domain induction with k=b−2 leaves depth one at physical length np² and rank endpoint np. Its path is the original C_(b−1) divided by p^(b−1), and its H-base is still n. For b=2 there are zero elimination steps, so no exceptional undefined procedure is hidden.

Combining the b−2 quotient contributions with the changed final endpoint gives

    W_b=p^(b−2)Σ_edges E_p+(b−1)(p−1)np^(b−1),
    Z≤W_b−D_pen.

The coefficient b−1 has two distinct origins: b−2 numerical quotient corrections and one deleted-endpoint correction. Their sum is exact. By periodicity,

    p^(b−2)F_p(np)+(b−1)(p−1)np^(b−1)=V(a,b).

Consequently V−W_b=p^(b−2)Σ_edges ℓ_p is an identity for the collapsed bound, and

    V−Z≥p^(b−2)Σ_edges ℓ_p+D_pen.

The candidate does not mistakenly assert U_b=W_b before densification. It uses only U_b≤W_b and retains the original endpoint deficits with their original coefficient.

If the path omits rank n, the rank-n barrier forces a positive edge and yields p^(b−2)(p−1). If the path visits rank n, the actual proper prefix has size np^(b−1), and its P-projection has order exactly p^(b−1). If β=n, it is one coset of H×Q with Q maximal of index p. Normal prime-index trapping again contradicts B=G. Otherwise D_pen contains at least p^(b−1), larger than the required loss. Empty proper penultimate checkpoint sets fall into the missing-rank case. This completes the analytical all-b escape proof.

## Prime power bases and structural induction

For any group K of prime-power order t^e, free left action implies |S_j|≤gcd(j,t^e), whose summed cap equals t^e e(1−1/t). Maximal-subgroup coset recursion attains it inductively. Equality forces saturation at j=|K|/t, making that prefix a single coset of its index-t stabilizer. Trapping places every proper stabilizer inside it. The local argument below then forces consecutive blocks. Thus both arbitrary prime-power axes have their own proof, and no escape statement on an axis is required. For e=0 the value is zero and the unique singleton ordering has no top.

For a,b≥1, strict escape excludes B=G for an optimizer. Choose a maximal subgroup J containing B. Coprime subgroup splitting proves J is either H×R with R maximal in P or M×P with M maximal in H; a subgroup with both factors proper could be enlarged. Such J is normal of prime index p or q, and its actual group structure is covered by the induction hypothesis at smaller a+b.

At each insertion, let L_j^local be the active local-prefix stabilizer in J. For j<N, S_j≤B≤J implies S_j≤L_j^local. Every local prefix is counted at exactly one active insertion; the final global prefix substitutes G for the last local full stabilizer J. Therefore

    Z_G=Σ_cosets Z_J(local order)+|G|−|J|
               −Σ_(j<N)(|L_j^local|−|S_j|).

This is an exact identity. The local maximum sum plus |G|−|J| equals V(a,b) in either prime-index direction. Equality forces every local order optimal and every nonnegative local deficit zero.

At the first completion of a J-coset, the local stabilizer is J, so zero deficit makes the global stabilizer J. The prefix is a union of whole J-cosets. No other coset has completed, so all others are empty. This forces the first consecutive block. The same argument at every subsequent completion excludes any simultaneously occupied unfinished coset, forcing all remaining blocks. Local induction supplies their recursive form.

Conversely, in consecutive J-coset blocks with local optimal orders, an outside element induces a nontrivial translation of the prime-order quotient. It cannot preserve a nonempty proper set of completed quotient cosets at a boundary. Inside a block it cannot preserve the unique partially occupied coset, since it cycles all quotient cosets. Thus every proper stabilizer lies in J and equals the active local stabilizer. All deficits vanish and the value is attained.

At the first full block, the proper global stabilizer is exactly J, and all proper stabilizers lie in J. Hence B=J. This also handles prime-order groups where J=1. It gives both uniqueness and the separation of constructions from different maximal subgroups.

For fixed J of index t, t! orders of the distinct labeled cosets and A(J) independent choices per coset give t!A(J)^t. Right-translation identifies each coset with J equivariantly. A different representative changes only the chosen bijection, not the set or number of available local element orders. Block boundaries and local sequences are recovered from a final ordering, so the count is injective within a fixed top. Recovery of B makes different tops disjoint. Summing the two maximal-subgroup families proves the recurrence without any quotient or representative multiplicity.

## Fresh numerical controls

The main independent run completed with zero failures. It checked 900 full hierarchies, including all 864 cases of the candidate's parameter coverage with fresh checkpoint draws and 36 additional cases. Mixed-prime stress reaches p-depth 12, and the empty q-factor numerical stress reaches depth 13. It checked 721 exact top deletions, 120 unrelated extended domains, and 708 exhaustively enumerated small extended-domain hierarchies. Across the arithmetic and actual-group runs there were 7,109 densification/quotient steps, 393,922 exact whole-gap comparisons, and 12,270 edge-identity checks. The saved summary records 467 missing-rank-n barriers, 206 zero-loss paths visiting n, and 41 proper-top barriers.

Every densification step checked the exact quotient, invariance of preexisting positive-level caps, the H-cap 1 at nonmultiples, each exact whole-gap increment, and the accumulated correction. Each top deletion checked equality of all proper-index contributions, the changed final contribution, the resulting bound, and the loss telescope. These tests use a fixed n even when the extended physical length is unrelated to it.

## Fresh group and counting controls

There were 257 directly recomputed group orders: 252 fresh orders across 13 group families, four exact saved escape replays, and one new high-depth escape construction. Of the 252 family orders, 107 are recursive optimizers. Families include C3×D16, C3×D32, C3×D64, C3×C2^4, C3×C2^5, C3×C4², Heis27×D16, Heis27×D32, D8×(Heis27×C3), Q8×Heis27, both nontrivial axes, and the singleton. All scores, actual stabilizers, B, caps, and recursive block properties were recomputed from the multiplication tables. There were 208 actual retained-penultimate-deficit checks.

All four saved author escape permutations were replayed exactly, reproducing their Z, U, B=G, and lack of proper full-P checkpoints. Their two value pairs are (Z,U)=(1719,2214) and (989,1576), each at V=2700 and N=648. The new both-nonabelian example is D8×(Heis27×C3²), p=3, b=5, N=1944, with Z=3293, U=5068, V=9396, B=G, and no proper full-P checkpoint. This stresses the genuinely missing-top branch at a depth beyond the accepted p³ case.

Exact subset dynamic programming checked maximum values and labeled counts on 14 groups through order 12, totaling 10,350 subset states. The recurrence agrees in every case, including A(D8)=2432, A(Q8)=384, A(C2³)=8064, A(C12)=31872, and A(C3×C2²)=169344. In addition, all 162,057 permutations across the tested groups of order at most 8 were enumerated; every optimizer had the predicted consecutive blocks and recovered maximal top, and top-separated counts matched. The singleton produced value 0 and count 1.

The separately saved supplemental controls check actual closure/core geometry and finite escape-state paths. Their exact counters and outputs are in SUPPLEMENTAL_CONTROLS.json. These additional finite maxima are only controls; no general sharp-escape theorem is asserted.

## Source binding and final boundary

Candidate archive: Library libfile_bb0d9ff7a2008191a0a0f1ebfa85e419 v0, 75,273 bytes, SHA-256 e8b8aa9ad126047014f82c97588f8025ec10ed5821c51675af1de5385e3815e9. Frozen proof: 25,739 bytes, SHA-256 56959d5056ef4f144b99a9e4969d9dd2e43e75da01389b913760e89c2a9e37ed.

Accepted two-Sylow/rank-two archive: Library libfile_6b306a62e6348191a2f106e3b19a8e44 v0, 233,898 bytes, SHA-256 be001a5b8ea0d2e0f546cdb7967f5155e0a2362935d29456a16150f1ac90f76f.

Accepted order-p³ archive: Library libfile_948c6d7a48288191a3645a2e3174895c v0, 127,434 bytes, SHA-256 ea5298da2cdae0f75141add6a064c18b86b43372abd6a640d8f1da9a0f899f45.

The seven reused source-file hashes and exact archive-member matches are recorded in SOURCE_VERIFICATION.json and preserved in source snapshots. No source proof was silently edited. This review accepts the universal two-Sylow structure theorem on the basis of the symbolic argument, not bounded experiments. It does not authorize any broader nilpotent extension or novelty claim. No Sheet or GitHub write was performed.
