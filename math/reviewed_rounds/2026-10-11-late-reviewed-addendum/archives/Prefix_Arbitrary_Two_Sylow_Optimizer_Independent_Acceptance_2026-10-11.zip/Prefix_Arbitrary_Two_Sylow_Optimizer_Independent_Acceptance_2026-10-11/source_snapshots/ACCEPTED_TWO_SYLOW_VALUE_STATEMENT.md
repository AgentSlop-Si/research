# Accepted noncyclic two-Sylow value and elementary-abelian rank-two structure

Independent project mathematical review, 11 October 2026 UTC. Decisions: **Theorem A ACCEPT; Theorem B ACCEPT; direction-switch diagnostic ACCEPT.** The frozen candidate needs no mathematical repair.

Let p and q be distinct primes, H a finite q-group of order q^a, P a finite p-group of order p^b, and G=H×P. For a labeled element order x, let T_j be its j-element prefix and S_j its left stabilizer. Set

    Z_G(x) = Σ_(j=1)^|G| (|S_j|−1),
    B(x) = ⟨S_j : 1≤j<|G|⟩.

The full prefix contributes to Z and is excluded from B.

## A. Accepted value theorem

For all a,b≥0 and all such H and P,

    max_x Z_G(x) = q^a p^b [a(1−1/q)+b(1−1/p)].

Both factors may be nonabelian. Consecutive maximal-subgroup coset recursion constructs orders attaining this value. This theorem alone does not classify all optimizers, prove a unique top, give an optimizer count, or give an escape deficit for arbitrary noncyclic P.

## B. Accepted rank-two structural theorem

If P=C_p×C_p, the following additional statements hold:

- The maximizing orders are exactly the recursive maximal-subgroup right-coset orders, with independent local optimal choices in each coset and singleton termination.
- The unique top subgroup of every nontrivial maximizing order is B(x).
- For a≥1, if B(x)=G then Z_G(x)≤V(a,2)−(p−1), where V(a,2)=q^a p²[a(1−1/q)+2(1−1/p)]. This is a sufficient deficit, not the sharp escaping maximum.
- For labeled maximizing-order counts A and A(1)=1,

      A(H×C_p²) = (p+1)p! A(H×C_p)^p
                   +q! Σ_(M maximal in H) A(M×C_p²)^q.

  The second sum is empty when H=1. Counts are not quotiented by translations or automorphisms.

The a=0 base is the accepted finite p-group theorem. Theorem A includes both prime-power axes and the singleton; the singleton has value 0, one order, and no top subgroup.

## C. Accepted diagnostic

The specified D8×C3² order has Z=113, V=204, numerical cap U_2=194, B=G, D_top=0, and C_2={0,72}. Its proper-prefix stabilizers generate the whole group without a proper full-P checkpoint. This disproves transfer of the cyclic proof's proper-checkpoint implication to noncyclic P. It does not refute either accepted theorem or provide a sharp escaping example.

## Frozen binding and boundary

This decision binds Library libfile_b790b12b821c8191b50ec98836c8c6c0, version 0, archive SHA-256 b1b5b8c2fd41d2a7f2334eba82984abe596bc7f10b8c8cfff1335f3ff00994c4; its unchanged 18,250-byte CANDIDATE_PROOF.md has SHA-256 148ddbc0f0d95ad5d0bde66acd901b4cf2fd69c79283e9c243e7ede0e13d22e0.

The acceptance is based on the symbolic proof, with separately reported finite independent controls. It is not external peer review or proof-assistant certification. Arbitrary-P optimizer classification, three-prime groups, all finite nilpotent groups, sharp escape values, worldwide priority, and the existing EFK source-comparison gap remain outside this acceptance. No Sheet or GitHub writes are included.
