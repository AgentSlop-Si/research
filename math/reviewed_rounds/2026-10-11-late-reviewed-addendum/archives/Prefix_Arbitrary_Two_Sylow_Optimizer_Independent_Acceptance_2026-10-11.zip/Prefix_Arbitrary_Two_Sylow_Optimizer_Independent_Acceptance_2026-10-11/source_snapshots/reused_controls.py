"""Fresh reviewer controls, no author or inherited mathematical code imported.
Run from this file's directory. All outputs are bounded corroboration only.
"""
from itertools import product
from math import gcd, factorial
from functools import lru_cache
from bisect import bisect_left
from fractions import Fraction
from pathlib import Path
import random,json,time
HERE=Path(__file__).resolve().parent
RNG=random.Random(162611102026)
def dump(name,data): (HERE/name).write_text(json.dumps(data,indent=2)+'\n')
def powers(q,a): return [q**i for i in range(1,a+1)]
def value(q,a,p,b): return int(q**a*p**b*(a*Fraction(q-1,q)+b*Fraction(p-1,p)))
def cap(q,a,p,b,C):
 n=q**a; N=n*p**b; D=powers(q,a); out=[]
 for j in range(1,N+1):
  r=max(s for s in range(b+1) if j in C[s])
  h=gcd(j//p**b,n) if r==b else 1
  if r<b:
   for d in D:
    if (j//p**r)%d: continue
    yes=True
    for s in range(r+1,b+1):
     z=bisect_left(C[s],j); left,right=C[s][z-1:z+1]; k=p**s*d
     if not k*((left+k-1)//k)<j<k*(right//k): yes=False;break
    if yes:h+=d-d//q
  out.append((r,h,p**r*h-1))
 return out

def edge(q,a,p,k,l):
 n=q**a; D=powers(q,a)
 w={d:max(0,l//d-(k+d-1)//d) for d in D}
 e=p*(gcd(l,n)+sum((d-d//q)*w[d] for d in D))-1-sum(d-d//q for d in D if w[d]>0)
 loss=p*sum(gcd(i,n) for i in range(k+1,l+1))-(l-k)-e
 m=l-k;g=gcd(gcd(k,l),n)
 X=[d for d in D if k%d and l%d and (l-1)//d-k//d>0]
 A=m-g+sum(d-d//q for d in X);B=1-m+sum(d-d//q for d in D if w[d]>0)
 assert loss==p*A+B
 assert loss>=0 and ((loss==0)==(m==g)) and (loss==0 or loss>=p-1)
 if loss==0: assert not k<n<l
 return e,loss

def arithmetic():
 total=zero=extended=0;pars=[]
 for q,a,p in [(2,a,p) for a in range(0,7) for p in [3,5,7]]+[(3,a,p) for a in range(0,5) for p in [2,5]]+[(5,a,p) for a in range(0,4) for p in [2,3]]+[(7,a,p) for a in range(0,3) for p in [2,3]]:
  n=q**a;end=n*p
  # Full edges through np, plus some wholly beyond np to test unrestricted identity.
  count=0
  for k in range(end):
   for l in range(k+1,end+1):
    _,loss=edge(q,a,p,k,l); total+=1;zero+=loss==0;extended+=l>n;count+=1
  for _ in range(30):
   k=RNG.randrange(end,3*end+1);l=k+RNG.randrange(1,end+1);edge(q,a,p,k,l);total+=1;extended+=1;count+=1
  pars.append(dict(q=q,a=a,p=p,edges=count))
 branch2=hierarchies=quotients=0
 for q,a,p,b in [(2,0,3,4),(2,2,3,3),(3,2,2,4),(2,3,3,2),(5,2,2,2),(3,1,2,2),(2,2,3,0)]:
  n=q**a;N=n*p**b
  for t in range(35):
   C=[list(range(N+1))]
   for s in range(1,b+1):
    eligible=[j for j in C[-1] if j%p**s==0 and j not in (0,N)]
    C.append([0]+[j for j in eligible if RNG.random()<.42]+[N])
   u=sum(z[2] for z in cap(q,a,p,b,C)); assert u<=value(q,a,p,b);hierarchies+=1
   if b:
    cd=[list(range(N+1)),list(range(0,N+1,p))]+C[2:]
    ud=sum(z[2] for z in cap(q,a,p,b,cd));assert ud>=u
    cq=[list(range(N//p+1))]+[[j//p for j in z] for z in C[2:]]
    uq=sum(z[2] for z in cap(q,a,p,b-1,cq));assert ud==p*uq+(p-1)*(N//p);quotients+=1
 for q,a,p in [(2,0,3),(2,1,3),(2,3,3),(3,2,2),(5,2,3),(7,1,2)]:
  n=q**a;N=n*p*p
  for t in range(60):
   C=[list(range(N+1)),[0]+[j for j in range(p,N,p) if RNG.random()<.27]+[N],[0,N]]
   u=sum(z[2] for z in cap(q,a,p,2,C));path=[j//p for j in C[1]]
   e=sum(edge(q,a,p,k,l)[0] for k,l in zip(path,path[1:]))+N-n*p
   assert u==e; assert value(q,a,p,2)-u==sum(edge(q,a,p,k,l)[1] for k,l in zip(path,path[1:]))
   branch2+=1
 out=dict(seed=162611102026,edge_count=total,zero_count=zero,edges_beyond_original_rank_n=extended,parameters=pars,arbitrary_hierarchies=hierarchies,exact_densification_quotient_checks=quotients,branch_II_exact_extended_rank_caps=branch2,failures=0)
 dump('ARITHMETIC_CONTROLS.json',out);print('ARITHMETIC', {k:v for k,v in out.items() if k!='parameters'},flush=True)

class Group:
 def __init__(self,name,els,op):
  self.name=name;self.els=list(els);self.N=len(self.els);idx={v:i for i,v in enumerate(self.els)}
  self.mul=[[idx[op(x,y)] for y in self.els] for x in self.els]
  assert all(self.mul[0][i]==i==self.mul[i][0] for i in range(self.N))
  self.inv=[next(j for j in range(self.N) if self.mul[i][j]==0) for i in range(self.N)]
 @lru_cache(None)
 def close(self,seeds):
  out={0};queue=[0];generators=list(seeds)
  for x in queue:
   for y in generators:
    z=self.mul[x][y]
    if z not in out:out.add(z);queue.append(z)
  return frozenset(out)
 @lru_cache(None)
 def subs(self):
  found={frozenset([0])};queue=list(found)
  for S in queue:
   for x in range(self.N):
    if x in S:continue
    T=self.close(tuple(sorted(S|{x})))
    if T not in found:found.add(T);queue.append(T)
  return tuple(sorted(found,key=lambda S:(len(S),sorted(S))))
 @lru_cache(None)
 def maximal(self,S):
  proper=[T for T in self.subs() if T<S]
  return [T for T in proper if not any(T<U for U in proper)]
 def rec(self,S=None,top=None):
  if S is None:S=frozenset(range(self.N))
  if len(S)==1:return list(S)
  J=top if top is not None else RNG.choice(self.maximal(S))
  left=set(S);cosets=[]
  while left:
   x=min(left);C={self.mul[y][x] for y in J};cosets.append((x,C));left-=C
  RNG.shuffle(cosets)
  return [self.mul[y][x] for x,C in cosets for y in self.rec(J)]
 def translate(self,g,mask):
  out=0
  while mask:
   v=(mask&-mask).bit_length()-1;mask&=mask-1;out|=1<<self.mul[g][v]
  return out
 def prefixes(self,order):
  masks=[];stabs=[];images=[0]*self.N;mask=0
  for x in order:
   mask|=1<<x
   for g in range(self.N):images[g]|=1<<self.mul[g][x]
   stabs.append(frozenset(g for g in range(self.N) if images[g]==mask));masks.append(mask)
  return masks,stabs

def cyclic(n):return Group('C'+str(n),range(n),lambda x,y:(x+y)%n)
def abelian(*ns):return Group('x'.join('C'+str(n) for n in ns),product(*(range(n) for n in ns)),lambda x,y:tuple((u+v)%n for u,v,n in zip(x,y,ns)))
def dihedral():return Group('D8',product(range(4),range(2)),lambda x,y:((x[0]+(-1)**x[1]*y[0])%4,(x[1]+y[1])%2))
def quaternion():return Group('Q8',product(range(4),range(2)),lambda x,y:((x[0]+(-1)**x[1]*y[0]+2*x[1]*y[1])%4,(x[1]+y[1])%2))
def heisenberg(p):return Group('Heis'+str(p**3),product(range(p),repeat=3),lambda x,y:((x[0]+y[0])%p,(x[1]+y[1])%p,(x[2]+y[2]+x[0]*y[1])%p))
def direct(H,P):
 G=Group(H.name+'x'+P.name,product(range(H.N),range(P.N)),lambda x,y:(H.mul[x[0]][y[0]],P.mul[x[1]][y[1]]))
 # Every subgroup of coprime direct factors splits; use the two independently enumerated lattices.
 G.subs=lambda:tuple(frozenset(h*P.N+z for h in L for z in Q) for L in H.subs() for Q in P.subs())
 return G

def inspect_order(G,H,P,q,a,p,b,order,kind,full=False):
 assert len(order)==G.N and len(set(order))==G.N
 masks,stabs=G.prefixes(order);ranks=[];betas=[];projs=[]
 for S in stabs:
  L={g//P.N for g in S};Q={g%P.N for g in S};assert len(S)==len(L)*len(Q)
  beta=len(L);ps=len(Q);r=0
  while p**r<ps:r+=1
  assert p**r==ps;betas.append(beta);ranks.append(r);projs.append(Q)
 C=[list(range(G.N+1))]+[[0]+[j for j,r in enumerate(ranks,1) if r>=s] for s in range(1,b+1)]
 caps=cap(q,a,p,b,C);Z=sum(len(S)-1 for S in stabs);U=sum(c[2] for c in caps);V=value(q,a,p,b)
 assert Z<=U<=V
 assert all(beta<=c[1] for beta,c in zip(betas,caps))
 Dtop=sum(p**b*(gcd(j//p**b,H.N)-betas[j-1]) for j in C[b] if j)
 assert Z<=U-Dtop
 B=G.close(tuple(sorted(set().union(*stabs[:-1]))));Bsize=len(B)
 if b==2 and P.name=='C'+str(p)+'xC'+str(p) and a>0 and Bsize==G.N:assert Z<=V-(p-1)
 clipcount=closures=incomparable=0
 for j,(beta,r) in enumerate(zip(betas,ranks),1):
  L={g for g in stabs[j-1] if g%P.N==0}
  for s in range(r+1,b+1):
   z=bisect_left(C[s],j);lo,hi=C[s][z-1:z+1];k=p**s
   for d in powers(q,a):
    if beta%d==0:
     assert (j//p**r)%d==0
     assert k*d*((lo+k*d-1)//(k*d))<j<k*d*(hi//(k*d));clipcount+=1
   # The actual closure and core, independently calculated as sets of elements.
   if full and beta>1:
    lowmask=masks[lo-1] if lo else 0;himask=masks[hi-1]
    F=0;E=(1<<G.N)-1
    for ell in L:F|=G.translate(ell,lowmask);E&=G.translate(ell,himask)
    assert (F & masks[j-1])==F and (E & masks[j-1])==masks[j-1]
    assert F.bit_count()%(beta*k)==E.bit_count()%(beta*k)==0
    Qlo=projs[lo-1] if lo else set(range(P.N));Qhi=projs[hi-1]
    As=[A for A in P.subs() if len(A)==k and A<=Qlo];Ds=[A for A in P.subs() if len(A)==k and A<=Qhi]
    assert As and Ds
    for A in As:
     assert all(G.translate(z,F)==F for z in A)
    for D in Ds:
     assert all(G.translate(z,E)==E for z in D)
    incomparable+=sum(not A<=D and not D<=A for A in As for D in Ds);closures+=1
 if kind.startswith('recursive'):
  assert Z==V
  assert B in G.maximal(frozenset(range(G.N)))
 out=dict(kind=kind,Z=Z,U=U,V=V,D_top=Dtop,B_size=Bsize,proper_full_P_checkpoints=len(C[b])-2 if b else None,clip_tests=clipcount,closure_core_tests=closures,incomparable_endpoint_pairs=incomparable)
 if full:out.update(order=order,checkpoint_sets=C,stabilizers=[sorted(S) for S in stabs],betas=betas)
 return out

def group_checks():
 specs=[(dihedral(),abelian(3,3),2,3,3,2),(quaternion(),abelian(3,3),2,3,3,2),(abelian(2,2,2),abelian(3,3),2,3,3,2),(cyclic(9),abelian(2,2),3,2,2,2),(heisenberg(3),abelian(2,2),3,3,2,2),(cyclic(3),dihedral(),3,1,2,3),(cyclic(3),quaternion(),3,1,2,3),(abelian(3,3),dihedral(),3,2,2,3),(cyclic(3),abelian(4,2),3,1,2,3),(cyclic(2),heisenberg(3),2,1,3,3),(cyclic(1),dihedral(),3,0,2,3),(dihedral(),cyclic(1),2,3,3,0),(cyclic(1),cyclic(1),2,0,3,0)]
 records=[]
 for H,P,q,a,p,b in specs:
  G=direct(H,P);rows=[]
  if G.N>1:
   for top in G.maximal(frozenset(range(G.N))):
    for _ in range(2):rows.append(inspect_order(G,H,P,q,a,p,b,G.rec(top=top),'recursive',True))
  else:rows.append(inspect_order(G,H,P,q,a,p,b,[0],'singleton',True))
  for _ in range(15):
   order=list(range(G.N));RNG.shuffle(order);rows.append(inspect_order(G,H,P,q,a,p,b,order,'random',True))
  for _ in range(15):
   order=G.rec()
   if G.N>1:
    i,j=RNG.sample(range(G.N),2);order[i],order[j]=order[j],order[i]
   rows.append(inspect_order(G,H,P,q,a,p,b,order,'perturbed_recursive',True))
  records.append(dict(group=G.name,N=G.N,q=q,a=a,p=p,b=b,orders=rows))
  print('GROUP',G.name,len(rows),'escape',sum(r['B_size']==G.N for r in rows),'max',max(r['Z'] for r in rows),flush=True)
 dump('GROUP_CONTROLS.json',records)
 # Reconstruct the direction-switch example from set definitions before reading its certificate.
 H=dihedral();P=abelian(3,3);G=direct(H,P)
 L={i for i,z in enumerate(P.els) if z[1]==0};M={i for i,z in enumerate(P.els) if z[0]==0}
 A={h*P.N+z for h,x in enumerate(H.els) if x in [(0,0),(0,1)] for z in L}
 Q={h*P.N+z for h,x in enumerate(H.els) if x in [(2,0),(3,1)] for z in M}
 R={h*P.N+z for h,x in enumerate(H.els) if x==(2,0) for z in range(P.N)}-Q
 order=sorted(A)+sorted(R)+sorted(set(range(G.N))-A-Q-R)+sorted(Q)
 ans=inspect_order(G,H,P,2,3,3,2,order,'direction_switch',True)
 certificate=json.loads((HERE/'source_snapshots/AUTHOR_DIRECTION_SWITCH_CERTIFICATE.json').read_text())
 assert order==certificate['order']
 assert ans['Z']==113 and ans['U']==194 and ans['V']==204 and ans['B_size']==72 and ans['D_top']==0
 assert ans['checkpoint_sets'][2]==[0,72]
 for row,S,beta in zip(certificate['rows'],ans['stabilizers'],ans['betas']):assert row['stabilizer']==S and row['beta']==beta
 for j in range(1,G.N):
  T=set(order[:j]);assert any(0<len(T&set(range(h*9,(h+1)*9)))<9 for h in range(8))
 assert ans['stabilizers'][5]==sorted(A)
 expected66={h*P.N+z for h,x in enumerate(H.els) if x in [(0,0),(1,1)] for z in M}
 assert ans['stabilizers'][65]==sorted(expected66)
 assert len(G.close(tuple(sorted(set(ans['stabilizers'][5])|set(ans['stabilizers'][65])))))==72
 dump('DIRECTION_SWITCH_REVIEW.json',ans)
 summary=dict(total_orders=sum(len(g['orders']) for g in records)+1,group_families=len(records),recursive_orders=sum(r['kind']=='recursive' for g in records for r in g['orders']),escape_orders=sum(r['B_size']==g['N'] for g in records for r in g['orders'])+1,clip_tests=sum(r['clip_tests'] for g in records for r in g['orders'])+ans['clip_tests'],closure_core_tests=sum(r['closure_core_tests'] for g in records for r in g['orders'])+ans['closure_core_tests'],incomparable_endpoint_pairs=sum(r['incomparable_endpoint_pairs'] for g in records for r in g['orders'])+ans['incomparable_endpoint_pairs'],failures=0)
 dump('CONTROL_SUMMARY.json',summary);print('SUMMARY',summary,flush=True)

if __name__=='__main__':
 start=time.time();arithmetic();group_checks();print('SECONDS',time.time()-start,flush=True)
