# Prefix optimizers for a finite q-group times a group of order p³

11 October 2026 UTC. Source-bound author candidate for independent review.

## 1. Exact statement and scope

Let p and q be distinct primes, let H be any finite q-group of order n=q^a, and let P be any finite group of order p³. Neither factor is required to be abelian. For a labeled ordering x of G=H×P, let T_j be its j-element prefix and S_j={g:gT_j=T_j}. Define

    Z_G(x)=Σ_(j=1)^|G| (|S_j|−1),
    B(x)=⟨S_j:1≤j<|G|⟩,
    V(a,3)=np³[a(1−1/q)+3(1−1/p)].

The full prefix contributes to Z and is excluded from B.

The candidate extension is:

1. The maximum equals V(a,3), as already accepted for arbitrary P.
2. If a≥1 and B(x)=G, then

       Z_G(x)≤V(a,3)−p(p−1).                              (1)

   This is a sufficient escape deficit, not a sharp escaping maximum.
3. The maximizing orders are exactly the recursive maximal-subgroup right-coset orders, with independent optimal local orders and singleton termination.
4. Every nontrivial optimizer has one top subgroup, equal to B(x).
5. For labeled maximizing-order counts A and A(1)=1,

       A(H×P)=p! Σ_(R maximal in P) A(H×R)^p
                  +q! Σ_(M maximal in H) A(M×P)^q.         (2)

   The second sum is empty when H=1. No translation or automorphism quotient is taken.

In particular, for P=C_p×C_p×C_p,

       A(H×C_p³)=(p²+p+1)p! A(H×C_p²)^p
                       +q! Σ_(M maximal in H) A(M×C_p³)^q. (3)

Here C_p³ means an elementary-abelian product, whereas C_(p³) denotes the cyclic group. The latter was already covered by the accepted cyclic theorem. Formula (2) also covers the nonabelian groups of order p³ and all abelian types of this order.

The new structural assertion is restricted to |P|=p³. No arbitrary-order P structural theorem, three-prime theorem, all-nilpotent theorem, sharp escape claim, priority claim, or new source-comparison conclusion is made. The accepted maximum theorem and the earlier cyclic and rank-two structural theorems are not modified. This packet is not independent acceptance or formal verification.

## 2. Accepted dependencies used without a new source audit

The accepted noncyclic review, Library libfile_6b306a62e6348191a2f106e3b19a8e44 version 0, archive SHA-256 be001a5b8ea0d2e0f546cdb7967f5155e0a2362935d29456a16150f1ac90f76f, supplies:

- The maximum formula for H×P for arbitrary finite q-group H and finite p-group P.
- Coprime splitting S_j=L_j×Q_j and the threshold checkpoint construction.
- The endpoint H-closure/H-core lemma, valid for different and incomparable P-subgroups at different checkpoints.
- The group-free numerical invariant, including all enclosing strict clips, and the accepted lowest-level whole-gap densification calculation.
- The q-adic edge identity on the extended rank range, with its exact zero criterion and positive loss.
- The rank-two structural theorem for H×C_p².
- The already accepted arbitrary-cyclic-depth structural theorem and the finite-prime-power bases.

The unchanged source texts and reusable control primitives are included under reused_sources. Their hashes and the existing Library acceptance binding are recorded in SOURCE_BINDINGS.json. This extension reuses the proof and controls; it does not present those old tests or source checks as newly independent work.

The new point is a top-deletion identity with its final-endpoint correction, followed by exactly one whole-gap densification on the enlarged physical interval. Its proof is given below. This removes the need to infer a proper full-P checkpoint from B=G.

## 3. Threshold invariant and retained deficits

Write S_j=L_j×Q_j, β_j=|L_j| and |Q_j|=p^r(j). Put N=np³ and

    C_s={0}∪{j:1≤j≤N and |Q_j|≥p^s},  s=1,2,3,
    C_0={0,...,N}.

These are nested sets of indices, C_3⊆C_2⊆C_1⊆C_0, and C_s⊆p^s Z. There is no chosen common chain of P-subgroups. In particular, different C_2 checkpoints can use different order-p² subgroups, and different C_1 checkpoints can use different order-p subgroups.

Let D={q,q²,...,q^a} and c_d=d−d/q. If r(j)<3, the accepted closure/core lemma says that every d∈D dividing β_j satisfies d|j/p^r(j) and, for each s>r(j),

    p^s d ceil(a_s/(p^s d))<j<p^s d floor(z_s/(p^s d)),     (4)

where a_s<j<z_s are the consecutive C_s indices enclosing j. The closure uses only commuting direct factors, not normality of endpoint subgroups. Define h_C(j) as 1 plus the sum of c_d over all d satisfying these tests. At r(j)=3 instead use h_C(j)=gcd(j/p³,n). Put

    U_3(C)=Σ_(j=1)^N[p^r(j)h_C(j)−1].

Then β_j≤h_C(j) pointwise and Z≤U_3(C)≤V(a,3). Any specified collection of actual pointwise deficits p^r(j)(h_C(j)−β_j) can be subtracted before replacing U_3 by a larger numerical bound.

For example, at the full-P checkpoints the retained deficit is

    D_top=Σ_(j∈C_3, j>0)p³[gcd(j/p³,n)−β_j].             (5)

The final term is zero.

## 4. Prime-index trapping, including nonabelian P

If a proper prefix is one right coset Jx of a normal subgroup J of prime index t, all proper-prefix stabilizers lie in J.

Before that prefix, a nonempty prefix is contained in Jx; an element outside J maps this coset to a disjoint coset. After that prefix, invariance under an outside element would include all its translates of Jx. Its nontrivial image in G/J, a group of prime order, cycles all quotient cosets. This would make the prefix full. Thus B≤J.

Every index-p subgroup R of a finite p-group P is normal. One proof uses the action on the p cosets: its image is a transitive p-subgroup of S_p, whose order must be p because the p-part of p! is p. The action kernel has index p and is contained in R, hence equals R. In particular, every order-p² subgroup of a group P of order p³ is normal, without assuming P abelian.

No statement that order-p subgroups are normal is used. Such a statement would fail in some of the nonabelian examples.

## 5. Branch I: at least one proper full-P checkpoint

This branch is the accepted outer-edge argument at depth three, now justified for threshold sets by the accepted closure/core lemma. The complete C_3 rank path runs from 0 to n after dividing physical indices by p³. Eliminating the two lower numerical levels gives the collapsed edges

    E_3(k,l)=p²E_p(k,l)+2p²(p−1)(l−k).

Here, with h(k)=gcd(k,n), s(k)=Σ_(u=1)^k h(u),

    w_d(k,l)=max(0,floor(l/d)−ceil(k/d)),
    E_p(k,l)=p[h(l)+Σ_d c_d w_d(k,l)]
                          −[1+Σ_(d:w_d>0)c_d],
    F_p(k)=p s(k)−k.

The exact edge loss F_p(l)−F_p(k)−E_p(k,l) is zero exactly when

    l−k=gcd(k,l,n),                                       (6)

and otherwise is at least p−1. Thus a nonzero collapsed loss is at least p²(p−1).

The existence of a proper full-P checkpoint makes this rank path nontrivial. If every edge has zero loss, it must visit n/q. Indeed, any edge in such a nontrivial zero path has aligned q-power length at most n/q, and cannot contain the multiple n/q strictly inside it.

If n/q is absent, there is a loss at least p²(p−1). If it is present and β_(p³n/q)=n/q, that prefix has size equal to its stabilizer K×P, hence is one right coset of K×P. K has index q in H, so Section 4 traps B in K×P, contradicting B=G. Otherwise the retained deficit (5) is at least p³. For n/q=1 the deficient possibility is impossible because β≥1.

Therefore this branch gives the stronger bound

    B=G ⇒ Z≤V(a,3)−p²(p−1).                              (7)

## 6. Branch II: there is no proper full-P checkpoint

Assume C_3={0,N}. This case explicitly allows changing order-p² projections, changing order-p projections, and no proper C_2 checkpoint at all.

### 6.1 Delete the empty top level, with an exact correction

Define a depth-two numerical invariant Ũ_2 on the same physical interval 0,...,N, using C_0,C_1,C_2 and the same q-power base n. For r<2 use precisely (4) with levels s≤2. For r=2 use gcd(j/p²,n). Its rank endpoint is N/p²=np, not n. This is a numerical object, not a group theorem at the mixed base np.

For each d|n, the omitted level-three clip is just 0<j<N, since N is divisible by p³d. It is redundant at all proper indices. At a proper C_2 checkpoint, the original only higher clip is this vacuous test, so its original H cap is already gcd(j/p²,n). Thus every proper-index contribution is unchanged by the deletion.

At j=N alone, the original contribution is N−1, whereas the truncated depth-two contribution is p²gcd(np,n)−1=p²n−1. Hence the exact identity is

    U_3(C)=Ũ_2(C_0,C_1,C_2)+(N−np²).                     (8)

The correction is np²(p−1). Omitting it would invalidate the equality calculation.

Also retain all proper C_2 endpoint deficits:

    D_mid=Σ_(j∈C_2,0<j<N)p²[gcd(j/p²,n)−β_j].            (9)

They are nonnegative, and the pointwise cap gives

    Z≤U_3(C)−D_mid.                                       (10)

### 6.2 One whole-gap densification works on this interval

Replace C_1 by every multiple of p, keeping C_2 fixed. Denote the resulting invariant by Ũ_2^dense. We have

    Ũ_2≤Ũ_2^dense.                                       (11)

Here is why the accepted local proof still applies without changing n. In a consecutive C_1 gap pu<pv, put r=v−u. Its enclosing C_2 endpoints are a<j<z. For d∈D define

    L_d=max(u, p d ceil(a/(p²d))),
    U_d=min(v, p d floor(z/(p²d))).

If L_d≥U_d set N_d=R_d=0. Otherwise the old open-gap eligible count and the inserted level-one eligible count are

    N_d=max(0,p[floor(U_d/d)−ceil(L_d/d)]−1),
    R_d=#{t∈Z:L_d<t<U_d and d|t}.

The new minus old open-gap contribution is exactly

    Δ=(p−1)(r−1)+Σ_d c_d(pR_d−N_d).                       (12)

The only negative summands have both endpoints divisible by d and equal −(p−1)c_d. Such d satisfy d≤U_d−L_d≤r. With d_* the largest q-power at most min(r,n), including d_*=1,

    Δ≥(p−1)(r−d_*)≥0.                                   (13)

For completeness, with exactly one endpoint divisible, pR_d−N_d is zero when R_d=0 and one otherwise; with neither endpoint divisible it is zero, p, or p+1 for R_d=0, 1, or at least 2. With both endpoints divisible and nonempty interval it is −(p−1). These are the same arithmetic cases as in the accepted proof. They do not require v≤n or N=np². All old positive-level caps are unchanged because they use only higher checkpoints.

Thus the one-step comparison is valid on the enlarged interval N=np³. This proves the required instance of (11) directly; it is not an application of a q-group theorem with np in place of n.

### 6.3 Exact quotient and extended edge bound

In the dense hierarchy all nonmultiples of p have cap zero. Divide every remaining index by p and decrement its level. This gives a depth-one invariant Ũ_1 on 0,...,np² whose checkpoints are C_2/p. All tests correspond exactly and the q-power base stays n. The identity is

    Ũ_2^dense=p Ũ_1+(p−1)np².                            (14)

Write the C_2 rank path

    0=k_0<...<k_t=np,   p²k_i∈C_2.

The depth-one invariant is precisely

    Ũ_1=Σ_i E_p(k_i,k_(i+1)).                             (15)

Combining (8), (10), (11), (14) and (15) gives

    Z≤U_3−D_mid≤W(C_2)−D_mid,
    W(C_2)=p Σ_i E_p(k_i,k_(i+1))+2(p−1)np².              (16)

This retains both additive terms, one from densification/quotient and one from the changed final endpoint.

The edge identity is valid for all integer k<l, including beyond n. To recall its proof, put m=l−k, g=gcd(k,l,n), and let X be the q-powers for which neither endpoint is divisible but an interior multiple exists. Then

    F_p(l)−F_p(k)−E_p(k,l)=pA+B,
    A=m−g+Σ_(d∈X)c_d,
    B=1−m+Σ_(d:w_d>0)c_d.

If m>g, divisibility gives m≥2g, and the loss is at least

    p(m−g)+1−m
      =(p−1)(m−2g)+(p−2)g+1≥p−1.

If m=g, the interval is aligned with q-power length g dividing n; the displayed loss is zero. This proves (6) and the positive loss on the extended rank range, without assuming endpoints at most n.

Since gcd(k,n) has period n, s(np)=p s(n), where s(n)=n+an(1−1/q). Consequently

    p F_p(np)+2(p−1)np²
      =p³s(n)−np²+2(p−1)np²
      =V(a,3).                                          (17)

Thus

    V(a,3)−W(C_2)
      =p Σ_i [F_p(k_(i+1))−F_p(k_i)−E_p(k_i,k_(i+1))].    (18)

Each nonzero term gives loss at least p(p−1).

### 6.4 The forced checkpoint is of order p², not order p

A zero-loss edge has aligned q-power length d dividing n. It cannot contain the multiple n strictly inside it. Therefore a zero-loss path from 0 to np must visit n, which is a proper rank because p≥2.

If rank n is absent from C_2/p², (18) gives Z≤V−p(p−1). This includes C_2={0,N} without any special group-theoretic argument or assumption about the order-p projections.

If rank n is present, the physical prefix j=np² has P-projection Q of order exactly p²: it is in C_2, and there is no proper C_3 checkpoint. Its numerical H cap is n.

If β_(np²)=n, its actual stabilizer is H×Q of size np², equal to the prefix size. The prefix is therefore one right coset of H×Q. Q has index p in P and is normal by Section 4, even when P is nonabelian. The trapping lemma contradicts B=G.

If β_(np²)<n, its contribution to (9) is

    p²(n−β_(np²))≥p²≥p(p−1),

so (16) gives the desired strict escape deficit. This deficit is retained from the original pointwise invariant before any upper-bound replacements. No assertion of stabilizer persistence is made.

This exhausts Branch II and proves (1). In particular, switching order-p² directions causes no gap in the argument: any single saturated forced checkpoint would already trap B in its own normal prime-index subgroup. Smaller order-p subgroups are never used for trapping.

## 7. Equality, unique top and count

Induct on a, using the accepted finite-p-group structural theorem at a=0. Maximal subgroups R of P have order p². Every group of that order is either cyclic C_(p²) or elementary abelian C_p²: its center is nontrivial, and a cyclic quotient by the center implies the group is abelian; the two abelian possibilities follow from the presence or absence of an element of order p². Thus all required H×R structural inputs are already accepted, from the cyclic theorem or the rank-two theorem.

For a≥1, the accepted value theorem supplies the value and recursive attainment. By (1), any optimizer has B<G. Choose a maximal proper subgroup J containing B. Coprime splitting shows that J is either H×R for R maximal in P, or M×P for M maximal in H. Both are normal of prime index. Their local optimizer theorems are supplied by the accepted order-p² cases or the a−1 induction respectively.

At a proper insertion j, let L_j^local be the stabilizer in J of the active local prefix in its right J-coset. Because S_j≤J, S_j≤L_j^local. Each local prefix appears at its unique active insertion; at the full final prefix the local term is |J|−1 and the global term is |G|−1. Therefore

    Z_G=Σ_(right J-cosets C) Z_J(x restricted to C)
           +|G|−|J|−Σ_(j<N)(|L_j^local|−|S_j|).            (19)

All deficits are nonnegative. In either maximal-subgroup direction, the sum of the local maxima plus |G|−|J| equals V(a,3). Equality forces every local order optimal and every deficit zero.

At the first completed J-coset, the local stabilizer is J, and hence the global stabilizer is J. The prefix is J-invariant and contains only one completed coset, so every other coset is empty. This forces a consecutive first block. At every later completion the same argument excludes any unfinished occupied coset, forcing the next block. The last block is automatic. Local induction proves that all optimizers have the asserted recursion.

Conversely, any such recursive maximal-subgroup coset order attains V by the accepted prime-index block calculation. All proper stabilizers are in the chosen J and the first full block has stabilizer exactly J. Thus B=J, proving unique top recovery.

For a fixed top J of index t there are t! orders of its distinct labeled cosets and A(J)^t independent local orders. Distinct tops are disjoint because B recovers the top. Summing gives (2). For elementary abelian P of rank three, maximal subgroups are kernels of nonzero linear functionals, with p−1 scalar multiples per kernel. There are (p³−1)/(p−1)=p²+p+1 such subgroups, all isomorphic to C_p², proving (3).

## 8. Nonabelian comparison and controls

The proof applies to both nonabelian groups of order 8, D8 and Q8, without assuming their smaller subgroups normal. In D8, the three maximal subgroups have types C4, C2², C2²; in Q8 all three have type C4. Thus their first sums in (2) are respectively

    2![A(H×C4)²+2 A(H×C2²)²],
    3·2! A(H×C4)².

These type counts are directly checked from the included multiplication tables. The general recurrence (2), rather than any optional classification of all nonabelian p³ groups, is the theorem.

A concrete missing-top construction used in the controls is as follows. Let H=D8 with coordinates r^i s^j, take distinct maximal subgroups L,M of an order-27 P, and form disjoint sets

    A={1,s}×L,
    Q={r²,r³s}×M,
    R=({r²}×P)\Q.

List A, then R, then the remaining elements outside A∪Q∪R, then Q, with sorted coordinates inside A, R and Q. The middle may be sorted or shuffled. The first |A| prefix is stabilized by ⟨s⟩×L, and the complement of the final Q is stabilized by ⟨rs⟩×M. These two stabilizers generate D8×P because L and M are distinct maximals and s,rs generate D8. Thus B=G. There is no proper full-P checkpoint: the initial occupied rows are partial; after R starts the r² row stays partial throughout the middle; in the final Q section that row completes before the r³s row, which remains partial until the full group. This explicitly realizes the branch that the cyclic proper-checkpoint implication cannot cover.

The finite table controls also count nonnormal order-p subgroups (for example, reflection subgroups in D8 and noncentral order-three subgroups in Heisenberg27). These lower subgroups are allowed to switch; they are never assumed normal in this proof.

Focused controls use the reused accepted review primitives and new extension-specific assertions. They test the top-deletion correction, the enlarged-interval densification, the exact quotient, the edge potential identity, the forced rank-n barrier, retained intermediate endpoint deficits, normality of all maximal P-subgroups, direct prefix scores of recursive and perturbed orders, and explicit full-B orders with different order-p² projections. They include elementary abelian rank three, C_(p²)×C_p, cyclic p³, D8, Q8, the order-27 Heisenberg group, and the nonabelian modular group of order 27. No large subset enumeration or exhaustive permutation search is used.

The controls establish only their listed finite instances. The universal statement is supported by Sections 3–7, conditional on the already accepted dependencies and pending independent adversarial review of this extension. Detailed control totals and exact constructions are in CONTROL_SUMMARY.json and ESCAPE_CONTROLS.json.

## 9. Proposed status and next boundary

Proposed row text after independent acceptance: “Two-Sylow prefix maximum remains accepted for arbitrary H×P. Recursive optimizer structure, unique top, labeled recurrence, and sufficient escape deficit p(p−1) now extend to every P of order p³, including elementary abelian rank three and nonabelian order-p³ groups, with arbitrary q-group H and p≠q. The new proof handles the missing full-P checkpoint by top deletion, one densification, and a forced normal index-p checkpoint. General arbitrary-order-P structure remains outside this accepted statement.”

Until independent review passes, label this only a source-bound candidate. No Sheet or GitHub writes are part of this packet.
