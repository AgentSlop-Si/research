# Prefix stabilizers for a finite q group times a cyclic prime power

11 October 2026 UTC. Author candidate, pending separate independent review.

## Statement and exact boundary

Let p and q be distinct primes, let H be a finite q-group of order n=q^a, and let P_b=C_(p^b), where a,b≥0. Identify P_0 with the trivial group. For a labeled ordering x of G=H×P_b, put

    T_j={x_1,...,x_j},  S_j={g∈G:gT_j=T_j},
    Z_G(x)=Σ_(j=1)^|G| (|S_j|−1),
    B(x)=⟨S_1,...,S_(|G|−1)⟩.

The full prefix is included in Z and excluded from B. Define

    V_(a,b)=np^b[a(1−1/q)+b(1−1/p)].                          (1)

The candidate theorem is:

1. The maximum of Z_G is V_(a,b).
2. Exactly the recursive maximal-subgroup right-coset orderings maximize Z: list the distinct right cosets of one maximal proper subgroup consecutively, independently recurse within each coset, and terminate at the singleton.
3. For every nontrivial G and every maximizing ordering, its top subgroup is unique and equals B(x).
4. With A(K) the number of labeled maximizing orders and A(1)=1, for b≥1,

       A(H×P_b)=p! A(H×P_(b−1))^p
                  +q! Σ_(M maximal in H) A(M×P_b)^q.           (2)

   The sum is empty for H=1. For b=0 and H≠1,

       A(H)=q! Σ_(M maximal in H) A(M)^q.                      (3)

5. If a≥1, b≥1 and B(x)=G, then

       Z_G(x)≤V_(a,b)−p^(b−1)(p−1).                          (4)

   This is a sufficient strict escape gap, not a claim of sharpness.

The singleton has value zero and one ordering; it has no top subgroup. No strict escape claim is made for it. The theorem concerns precisely one arbitrary finite q-group and one cyclic p-power factor. It does not extend the latter to a noncyclic p-group, treat three distinct prime factors, claim a theorem for all finite nilpotent groups, establish historical priority, or resolve the existing EFK source-access gap.

The all-b proof is a strengthened numerical checkpoint induction. It does not infer an induction from finite controls or simply reuse the two-level statement. The central invariant includes every enclosing higher-level clip. It also allows arbitrary numerical checkpoint hierarchies without claiming that their densifications are realizable by group orderings.

## 1 Splitting and all checkpoint levels

Every subgroup S≤H×P_b splits as L×Q. Indeed, for any (h,z)∈S, coprime-order powers isolate (h,1) and (1,z); taking all such elements gives the splitting. Since P_b is cyclic, Q is one of its unique subgroups P_r of orders p^r, 0≤r≤b.

A prefix is a level-s checkpoint if it is invariant under P_s. Its size is divisible by p^s, and it is a union of complete P_s-fibres. Let C_s be the set of its physical indices, including the empty and full indices. Thus, with N=np^b,

    C_b⊆C_(b−1)⊆⋯⊆C_1⊆C_0={0,...,N},
    C_s⊆p^s Z,  0,N∈C_s.                                    (5)

Use every checkpoint at each level, not a selected subsequence. At j>0 let

    r(j)=max{s:j∈C_s},   β_j=|S_j∩H|.

Then |S_j|=p^r(j) β_j and β_j is a q-power. For

    D={q,q²,...,q^a},   c_d=d−d/q,

we have the telescoping identities

    β−1=Σ_(d∈D,d|β)c_d,
    gcd(t,n)=1+Σ_(d∈D,d|t)c_d.                               (6)

The empty set D is allowed when n=1.

## 2 The multilevel clipping invariant

First derive the necessary clips for an actual ordering. Suppose r=r(j)<b. For every s>r, let a_s<j<z_s be the consecutive C_s indices enclosing j; strict inequalities hold because j∉C_s. If d∈D divides β_j, then

    d | j/p^r,
    p^s d ceil(a_s/(p^s d)) < j
                      < p^s d floor(z_s/(p^s d)).             (7)

To prove (7), quotient the P_r-invariant prefix by P_r. The resulting subset has size j/p^r in H×(P_b/P_r). For the fibres of P_s/P_r, consider its sets of full and nonempty fibres. Both are invariant under the H part of S_j; its action on H×(P_b/P_s) is free. Thus their cardinalities are multiples of d, and the enclosing level-s endpoints have respective fibre ranks a_s/p^s and z_s/p^s. The full/nonempty fibre inequalities give the two non-strict bounds in (7). Equality at either outer bound forces every occupied fibre to be full, which would make the prefix P_s-invariant, a contradiction. Freeness on the P_r quotient gives the divisibility statement.

For a top checkpoint j=p^b k, its H subset has size k, so β_j divides gcd(k,n).

Now define a numerical invariant for ANY hierarchy satisfying (5), whether realizable or not. For j>0 set r=r(j). If r=b, put

    h_C(j)=gcd(j/p^b,n).

If r<b, put

    h_C(j)=1+Σ_(d∈D) c_d I_C(d,j),                            (8)

where I_C(d,j)=1 exactly when d|j/p^r and EVERY inequality (7), for all s>r, holds. Otherwise I_C(d,j)=0. Define

    U_b(C)=Σ_(j=1)^N [p^r(j) h_C(j)−1].                      (9)

No assertion that h_C(j) is realizable, or is necessarily a subgroup order, is required. For the actual checkpoint hierarchy, (6) and (7) imply β_j≤h_C(j), whence Z_G≤U_b(C). Moreover, retain the complete top-endpoint deficit

    D_top=Σ_(k>0, p^b k∈C_b) p^b[gcd(k,n)−β_(p^b k)].        (10)

Every summand is nonnegative and the final one is zero. The stronger bound is

    Z_G≤U_b(C)−D_top.                                        (11)

This is the inductive invariant: the numerical hierarchy, all its enclosing clips, and the unchanged actual top-endpoint deficit.

## 3 Whole-gap densification at the lowest level

Assume b≥1. Let pu<pv be consecutive C_1 indices, and write r=v−u≥1. There is no checkpoint of any positive level in the open physical interval. For every s≥2 its enclosing C_s endpoints a_s,z_s are therefore constant throughout this interval. For each d∈D put

    L_d=max({u} ∪ {p^(s−1)d ceil(a_s/(p^s d)):2≤s≤b}),
    U_d=min({v} ∪ {p^(s−1)d floor(z_s/(p^s d)):2≤s≤b}).        (12)

When b=1 these are simply u,v. Higher-level clipping endpoints in (12) are multiples of d. If L_d≥U_d, define N_d=R_d=0. Otherwise set

    N_d=max(0,p[floor(U_d/d)−ceil(L_d/d)]−1),
    R_d=#{t∈Z:L_d<t<U_d and d|t}.                            (13)

The old open interval contributes exactly Σ_d c_d N_d to U_b. Indeed, its indices all have level zero. Their eligibility for d means divisibility by d and all strict clips. The level-one clip is

    pd ceil(u/d)<j<pd floor(v/d).

Intersecting it with the higher clips and using the divisibility of their endpoints gives

    pd ceil(L_d/d)<j<pd floor(U_d/d).

Counting the eligible multiples of d gives precisely N_d.

Densify C_1 by inserting ALL missing integer inner ranks t=u+1,...,v−1 at once, while keeping every C_s, s≥2, unchanged. At the inserted indices pt, the level is one; their d-eligibility is exactly d|t and L_d<t<U_d. Every remaining level-zero index has cap zero: it lies between adjacent new C_1 ranks of distance one, too short to contain the necessary pair of distinct d-multiples for any d≥q≥2. The new open-interval contribution is consequently

    (p−1)(r−1)+pΣ_d c_d R_d.

The new minus old difference is

    Δ=(p−1)(r−1)+Σ_d c_d(pR_d−N_d).                          (14)

This is nonnegative. To prove it, use the following exhaustive arithmetic cases. When L_d≥U_d the summand is zero. Otherwise:

- If both endpoints are divisible by d, put w=(U_d−L_d)/d≥1. Then R_d=w−1, N_d=pw−1, and pR_d−N_d=−(p−1).
- If exactly one endpoint is divisible by d, then N_d=max(0,pR_d−1). The difference is zero for R_d=0 and one otherwise.
- If neither endpoint is divisible by d, the difference is zero for R_d=0, p for R_d=1, and p+1 for R_d≥2.

Only the first case is negative, and it requires d≤U_d−L_d≤r. Let

    d_*=max{q^i:0≤i≤a and q^i≤r}.

In particular d_*≤min(r,n), including gaps with r>n. Telescoping gives

    Σ_(d∈D,d≤r)c_d=d_*−1≤r−1.

Therefore

    Δ≥(p−1)[r−1−(d_*−1)]=(p−1)(r−d_*)≥0.                   (15)

All pre-existing checkpoint caps are unchanged: a positive-level cap uses only levels strictly above its own. Thus replacing C_1 by all multiples of p, denoted C^dense, gives

    U_b(C)≤U_b(C^dense).                                     (16)

This is a whole-gap comparison of numerical bounds. It makes no claim of monotonicity for single-checkpoint insertion, or existence of a group ordering realizing the densified hierarchy.

## 4 Exact quotient identity and accumulated terms

In C^dense, every nonmultiple of p has zero cap. For each remaining index j=pt, decrement its level by one and divide every higher checkpoint index by p. This gives a hierarchy C′ for total size np^(b−1):

    C′_0={0,...,np^(b−1)},
    C′_s={j/p:j∈C_(s+1)}  for 1≤s≤b−1.                     (17)

The clipping tests, divisibility tests, and top H caps correspond exactly. In particular the retained q-power data remain D={q,...,q^a}. At every positive quotient index,

    p^r h−1=p[p^(r−1)h−1]+(p−1).

Hence the exact identity is

    U_b(C^dense)=p U_(b−1)(C′)+(p−1)np^(b−1).                (18)

For b−1=0 the definition is U_0=Σ_(k=1)^n[gcd(k,n)−1]. Equation (18) is an identity of the numerical invariant, not an application of a group theorem to an artificial quotient ordering.

The intermediate rank length np^(b−1) may have both prime divisors and may be composite; it is NOT substituted for n in gcd(t,n) or in D. The H rank base stays n=q^a, with arbitrary a. Only the p-depth decreases. This avoids an illegitimate use of a q-power identity with a mixed-order rank base.

Apply (16) and (18) repeatedly, stopping after b−1 eliminations. Each additive term, after its preceding scaling by p, equals (p−1)np^(b−1). Thus

    U_b(C)≤p^(b−1) U_1(C^top)
                     +(b−1)(p−1)np^(b−1),                  (19)

where C^top has C^top_1={j/p^(b−1):j∈C_b}. The actual top checkpoints have never been changed. Their retained deficit D_top in (11) remains subtractable after every upper-bound replacement; no earlier endpoint deficit is silently discarded or assumed to stabilize later prefixes.

The same argument can be restricted to one consecutive top interval p^b k<p^b l. It gives the interval additive term (b−1)(p−1)p^(b−1)(l−k).

## 5 The outer q-adic edge and its exact loss

Write h(k)=gcd(k,n), s(k)=Σ_(t=1)^k h(t), s(0)=0. For 0≤k<l≤n define

    w_d(k,l)=max(0,floor(l/d)−ceil(k/d)),
    E_p(k,l)=p[h(l)+Σ_d c_d w_d]
                         −[1+Σ_(d:w_d>0)c_d],
    F_p(k)=p s(k)−k.                                        (20)

At one level, the strict clips count max(0,pw_d−1) eligible open-interval indices for d, while the complete right endpoint cap is ph(l)−1. Therefore the numerical invariant is exactly the sum of E_p over consecutive top ranks. This includes composite n=q^a and the empty D case.

For completeness, the accepted one-level edge calculation is reproduced. Put m=l−k, g=gcd(k,l,n), and let X consist of d∈D such that neither k nor l is divisible by d but an interior d-multiple exists. Direct counting of interior multiples gives

    F_p(l)−F_p(k)−E_p(k,l)=pA+B,
    A=m−g+Σ_(d∈X)c_d,
    B=1−m+Σ_(d:w_d>0)c_d.                                   (21)

Indeed, if N_d counts strict interior d-multiples, then A=m−1+Σ_d c_d(N_d−w_d). This difference is −1 for two divisible endpoints, +1 for two indivisible endpoints with an interior multiple, and zero otherwise. The negative weights sum to g−1, proving (21).

Since g|m, when m>g we have m≥2g and

    pA+B≥p(m−g)+1−m
        =(p−1)(m−2g)+(p−2)g+1≥p−1.                          (22)

When m=g the interval is an aligned q-adic interval: its endpoints are consecutive multiples of the q-power m. For d≤m both are divisible and w_d=m/d; for d>m there is no interior d-multiple. Thus X is empty and A=B=0. We have proved

    F_p(l)−F_p(k)−E_p(k,l)≥0,
    equality iff l−k=gcd(k,l,n),
    nonzero loss at least p−1.                              (23)

For b≥1 define the collapsed edge and potential

    E_b(k,l)=p^(b−1)E_p(k,l)
                  +(b−1)p^(b−1)(p−1)(l−k),
    F_b(k)=p^(b−1)F_p(k)+(b−1)p^(b−1)(p−1)k
          =p^b s(k)+[b p^(b−1)(p−1)−p^b]k.                  (24)

Equations (19)–(20), including their interval version, give

    Z_G≤Σ_(consecutive top k,l) E_b(k,l)−D_top.               (25)

The exact outer loss is

    F_b(l)−F_b(k)−E_b(k,l)
       =p^(b−1)[F_p(l)−F_p(k)−E_p(k,l)].                    (26)

It has the same zero criterion and every nonzero loss is at least p^(b−1)(p−1). In particular there is no unproved loss propagation through a new p-power layer.

Counting the q-adic valuations of 1,...,n gives

    s(n)=n+a n(1−1/q).

Equations (24)–(26) telescope to

    Z_G≤F_b(n)=V_(a,b).                                      (27)

This upper bound is proved for every integer b≥1 by the explicit hierarchy induction. The b=0 group case is established separately below.

## 6 Strict escape from the top

Assume a,b≥1 and B(x)=G. There is a proper top checkpoint. Otherwise every proper stabilizer has p-part contained in the unique P_(b−1), so their generated subgroup is contained in H×P_(b−1)<G. This step uses uniqueness of the cyclic p-power subgroup; several lower projections cannot generate P_b.

Set r_0=n/q. A top-rank path consisting entirely of zero-loss edges either is the single edge 0→n or visits r_0. Indeed, in a nontrivial path each aligned q-adic edge has length d<n, hence d≤n/q, and d divides r_0. No aligned length-d interval can contain the multiple r_0 strictly inside it.

The proper top checkpoint makes the path nontrivial. If it omits r_0, there is a nonzero outer edge, and (26) proves the gap (4).

If r_0 is present with β_(p^b r_0)=r_0, its H subset is a single right coset of its stabilizer K of order r_0. The subgroup K is normal of index q in H. Therefore the whole checkpoint is one right coset of J=K×P_b, normal of prime index q in G. An element outside J acts cyclically on all q quotient cosets. Before this checkpoint a nonempty prefix is contained in its one J-coset and cannot be stabilized by that element. After this checkpoint, a stabilized prefix would contain all translates of the full J-coset and thus all G. Hence every proper stabilizer lies in J, contradicting B(x)=G.

Consequently a present r_0 has β_(p^b r_0)<r_0. Its contribution to D_top is at least p^b, which is greater than p^(b−1)(p−1). Equation (25) again proves (4). When r_0=1 the deficient case is impossible since β≥1. This proves strict escape without assuming persistence of stabilizers across different prefixes.

## 7 The finite prime-power bases

Here is a self-contained proof of every prime-power base needed later. Let Q have order t^e, t prime. Its prefix stabilizer order divides both the prefix size j and |Q|, because it acts freely by left translation. Thus

    Z_Q≤Σ_(j=1)^(t^e)[gcd(j,t^e)−1]
       =t^e e(1−1/t).                                      (28)

For Q=1 the score is zero and the single ordering is the recursion base.

For nontrivial Q, choose a maximal proper subgroup J. Standard finite t-group theory gives J normal of index t. Consecutive right J-cosets with optimal local orders attain (28) inductively. The block accounting used here is as follows. At a proper prefix, an element outside J acts transitively on the t quotient cosets. Such an element cannot preserve the prefix: a partial block is the unique partially occupied coset, and at a block boundary a nonempty proper set of quotient cosets is full. Stabilizers therefore lie in J and equal the active local stabilizer. The full final contribution replaces |J|−1 by |Q|−1. The score is the sum of local scores plus |Q|−|J|, exactly (28).

Conversely, equality in (28) forces equality of every individual prefix cap, especially at j=|Q|/t. This prefix is one right coset of its stabilizer J of order |Q|/t. The normal-prime-index coset argument of Section 6 forces every proper stabilizer inside J. The local accounting and first-completion argument in Section 8 then force consecutive J-coset blocks and optimal local orders, completing induction on e. At the first whole block the stabilizer is J, so B(x)=J and the top is unique. Distinct labeled coset orders give t! A(J)^t possibilities for each maximal J; distinct tops are disjoint. Thus the prime-power value, equality characterization, uniqueness, and recurrence all hold.

Apply this with Q=H for b=0, and with Q=P_b for a=0. It also handles both axes of the later induction and the singleton intersection. No nilpotent-group theorem is assumed as a base.

## 8 Both maximal-subgroup directions and equality

Induct on a+b, with the prime-power axes supplied by Section 7. For a,b≥1 the numerical bound is already (27). Choose J=H×P_(b−1), normal of prime index p. Its local theorem has smaller a+b. Consecutive J-cosets with optimal local orders have score

    p V_(a,b−1)+np^b−np^(b−1)=V_(a,b),                      (29)

so the bound is attained.

For any maximizing order, strict escape implies B(x)<G. Choose a maximal proper subgroup J containing B(x). Coprime splitting and the subgroup chain of P_b show that the maximal subgroups are exactly

    H×P_(b−1), of index p;
    M×P_b, with M maximal in H, of index q.                  (30)

For explanation, a split subgroup with both factors proper can enlarge either factor and is not maximal. If only the p-factor is proper it must be P_(b−1), and if only the H-factor is proper it must be a maximal M. Every subgroup in (30) is normal of its indicated prime index. Its local theorem is either the (a,b−1) case, the (a−1,b) case, or a prime-power base. These are all the proper-subgroup inputs used by the proof.

The exact local accounting is recorded to remove any equality assumption. At insertion j into right J-coset C_j, let L_j^local be the stabilizer in J of the active local prefix T_j∩C_j. For j<|G| we have S_j≤J and S_j≤L_j^local. Every local prefix appears once, at its active insertion, and the final local and global stabilizers are J and G. Hence

    Z_G=Σ_C Z_J(x restricted to C)+|G|−|J|
           −Σ_(j<|G|)(|L_j^local|−|S_j|).                    (31)

Every deficit is nonnegative. If t=[G:J] is p or q, the established local value satisfies t M(J)+|G|−|J|=V_(a,b). Equality forces every local order optimal and every deficit zero.

At the first completion of a J-coset, its local stabilizer is J, so the global prefix is J-invariant. No other coset is yet complete; invariance forces every other coset empty. The first completed coset therefore is the first consecutive block. At each subsequent completion before the last, the same argument, after the already completed blocks, forces exactly the next consecutive block. The last coset occupies the remainder. Local optimality supplies the full recursive structure.

Conversely, each recursive ordering using a top J from (30) attains the value by local induction and the prime-index block calculation in Section 7. Every proper stabilizer lies in J, and the first full block has stabilizer exactly J. Therefore B(x)=J, giving unique top recovery. This completes the induction without needing to classify equality at each numerical densification step.

For a fixed maximal J of index t, the t distinct labeled cosets can be ordered in t! ways and each has A(J) independent local maximizing orders. A fixed right-translation identification with J is a bijection; no extra representative factor appears. Unique top recovery makes the classes for different J disjoint. Equations (2)–(3) follow.

## 9 Why the nearest enclosing clip alone is insufficient

The all-enclosing invariant has a genuine role at b=3. Take n=8, q=2, p=3, b=3 and the numerical hierarchy

    C_1=C_2=C_3={0,27,54,...,216}.

Consider the first outer interval, through index 27. A weakened definition that tests only s=r(j)+1 in (8) gives interval cap 55. Densifying C_1 changes this weakened cap to 48, so its proposed monotonic elimination is false. Explicitly the old open cap is 11·1+5·2+2·4=29, and the endpoint cap is 26. After densification, the eight proper level-one nodes give baseline 16 and q-weight increment 6, for 16+6+26=48.

Under the actual all-enclosing invariant, the level-three clip suppresses all old open q-weights. The original cap is 26 and the first densification gives 16+26=42; the subsequent elimination reaches 54. Thus the correct direction is preserved. This is a counterexample to the weakened method, not to the group theorem, and no group realizability of the numerical hierarchy is required.

## 10 Checks and status

The source bindings preserve the exact accepted one-level theorem and review and the frozen prime-square theorem; the prime-square source archive SHA-256 was independently recomputed before use. Original files were not edited, and no inherited mathematical program was executed or imported.

Fresh controls in controls.py check arbitrary numerical hierarchies, whole-gap comparisons, quotient identities, collapsed outer edges at composite q-power ranks, and direct left-translation stabilizers. The direct examples include D8×C_27 and the order-27 Heisenberg group times C_8. Deliberately constructed B=G orders test both the missing-r_0 and deficient-r_0 branches. All group checks are direct on individual orderings. No exponential subset search at order 72 or larger is used.

These checks are corroboration only; Sections 2–6 provide the unrestricted symbolic induction. The archive is an author candidate pending separate independent review. It contains no Sheet or GitHub mutations, no broader nilpotent claim, no noncyclic-p-factor claim, and no historical-priority conclusion.
