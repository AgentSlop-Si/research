# Prefix stabilizers with two Sylow factors and elementary abelian rank two

11 October 2026 UTC. Author candidate for independent adversarial review.

## Findings and boundaries

This note separates three claims.

1. A new endpoint closure and core lemma transfers the already accepted numerical checkpoint upper bound to H × P for any finite q-group H and any finite p-group P, for distinct primes p and q. Consequently the maximum value formula extends to these two-Sylow-factor groups. This claim does not classify all optimizers when P has arbitrary order.
2. For P = C_p × C_p, a second argument proves a strict escape gap, recursive optimizer characterization, unique top subgroup, and the labeled recurrence. Its missing-top-checkpoint branch explicitly allows different order-p directions.
3. A concrete D8 × C3² order has B(x) = G but no proper P-invariant prefix. It disproves the cyclic proof's implication that full escape forces a proper full-P checkpoint when that implication is transferred to a noncyclic factor. It does not disprove the maximum conjecture or the corrected argument here.

All three are author claims pending independent review. Neither independent acceptance nor historical novelty is asserted. Three or more distinct prime divisors remain outside scope. The finite controls corroborate the proof; no group-size extrapolation or exhaustive 2^72 search is used.

## Notation and accepted dependency

Let H have order n = q^a, let P have order p^b, with p and q distinct primes, and set G = H × P, N = np^b. An ordering x of the labeled group elements gives prefixes T_j, left stabilizers S_j = {g : gT_j = T_j}, score

    Z_G(x) = Σ_(j=1)^N (|S_j| − 1),
    B(x) = ⟨S_j : 1 ≤ j < N⟩.

The full prefix contributes to Z and is excluded from B. The candidate maximum value is

    V(a,b) = np^b [a(1−1/q) + b(1−1/p)].

The accepted cyclic-prime-power source is Library libfile_1dae9a88f5108191a048f86017d447d6, version 0, independently accepted by libfile_672d090b20a4819198c511cd125dd489. Its proof establishes a numerical inequality U_b(C) ≤ V(a,b) for every nested hierarchy C satisfying

    C_b ⊆ ··· ⊆ C_1 ⊆ C_0 = {0,...,N},
    C_s ⊆ p^s Z,  0,N ∈ C_s.

That numerical assertion does not require realization by any group ordering. We use that established numerical theorem and its outer q-adic edge identity as dependencies. We do not reprove the accepted all-b induction. Exact archive and theorem hashes are recorded in SOURCE_BINDINGS.json; the original mathematical text is preserved in source snapshots.

## Lemma 1 Splitting and threshold checkpoints

Every subgroup S of H × P splits as L × Q, with L ≤ H and Q ≤ P. For an element (h,z), coprime-order powers isolate (h,1) and (1,z), proving the assertion for all elements of S. This does not require P, H, or their subgroups to be abelian.

Write S_j = L_j × Q_j, β_j = |L_j|, and |Q_j| = p^r(j). Define

    C_s = {0} ∪ {j : 1 ≤ j ≤ N and |Q_j| ≥ p^s}.

These are threshold sets, not checkpoints for a chosen fixed subgroup of order p^s. They satisfy the displayed numerical hierarchy conditions because |S_j| divides j. They remain nested even when Q_j and Q_k are incomparable subgroups. A point in C_s is invariant under at least one subgroup of P of order p^s, because a finite p-group of order at least p^s has a subgroup of that order.

## Lemma 2 Endpoint closure and core give all strict clips

Fix j with r = r(j) < s. Let a_s < j < z_s be the consecutive C_s indices enclosing j. Choose A_s ≤ P and D_s ≤ P of order p^s such that T_(a_s) is A_s-invariant and T_(z_s) is D_s-invariant. The choices may be different, incomparable, and unrelated to Q_j. At the empty or full endpoint any such subgroup can be used.

Use L = L_j, and define two subsets of G:

    F = ⋃_(ℓ∈L) ℓ T_(a_s),
    E = ⋂_(ℓ∈L) ℓ T_(z_s).

The lower endpoint closure F contains T_(a_s) and lies in T_j, since T_j is L-invariant and contains the endpoint. It is invariant under L. It is also invariant under A_s: the H and P factors commute, so A_s preserves every translated copy ℓ T_(a_s). Thus F is invariant under L × A_s, whose regular left action is free. Its cardinality is a multiple of β_j p^s.

The upper endpoint core E contains T_j and is contained in T_(z_s). It is invariant under L, since left multiplication by an element of L permutes the factors of the intersection. It is invariant under D_s, again because the two direct factors commute. Thus |E| is a multiple of β_j p^s.

For any d ∈ {q,q²,...,q^a} dividing β_j, these containments and cardinality divisibilities imply

    p^s d ceil(a_s/(p^s d)) ≤ |F| ≤ j ≤ |E|
                                  ≤ p^s d floor(z_s/(p^s d)).

Both outer bounds on j are strict. Equality at the left outer bound would force |F| = j and F = T_j, making T_j invariant under A_s and hence |Q_j| ≥ p^s, contrary to r < s. Equality at the right similarly gives E = T_j and D_s-invariance. Therefore

    p^s d ceil(a_s/(p^s d)) < j
                        < p^s d floor(z_s/(p^s d)).             (1)

Also d divides j/p^r because β_j p^r divides j. This proves every enclosing-level clip simultaneously, without a unique p-subgroup chain, a quotient by a common endpoint subgroup, or persistence of stabilizers across prefixes.

## Theorem A Maximum value for two arbitrary Sylow factors

For all finite q-groups H and finite p-groups P, p ≠ q,

    max_x Z_(H×P)(x) = np^b [a(1−1/q) + b(1−1/p)].             (2)

This statement alone makes no claim about all optimizers, their unique top, a counting recurrence, or a strict escape deficit for arbitrary b and arbitrary P.

Proof of the upper bound. Put D = {q,...,q^a} and c_d = d−d/q. For r(j) < b define

    h_C(j) = 1 + Σ_(d∈D) c_d I(d,j),

where I(d,j) requires d | j/p^r(j) and all clips (1) for s > r(j). If r(j) = b, put h_C(j) = gcd(j/p^b,n). Lemma 2 and β−1 = Σ_(d|β)c_d imply β_j ≤ h_C(j). At a top checkpoint Q_j = P, the prefix is a union of full P-fibres, and the H-stabilizer acts freely on the resulting H subset, proving the top gcd cap.

Thus this is exactly the accepted numerical functional

    U_b(C) = Σ_(j=1)^N [p^r(j) h_C(j) − 1].

In particular, with the actual unchanged top deficit

    D_top = Σ_(j>0, j∈C_b) p^b [gcd(j/p^b,n) − β_j],

we have

    Z_G(x) ≤ U_b(C) − D_top ≤ U_b(C) ≤ V(a,b).                 (3)

The last inequality is the accepted numerical theorem for arbitrary nested hierarchies. No step of that numerical theorem asks which subgroup gave an endpoint. The new group-theoretic input needed to apply it is precisely Lemma 2.

Proof of attainment. Induct on a+b. The singleton is immediate; prime-power groups have the accepted prime-power value. If b > 0, choose a maximal subgroup R of P. It is normal of index p. Put J = H × R. List its p right cosets consecutively, using optimal local orders supplied by induction. Every proper global stabilizer lies in J: an element outside J cycles all p quotient cosets and cannot preserve either a prefix with a unique partially occupied coset or a nonempty proper block-boundary prefix. The exact score is

    p V(a,b−1) + |G| − |J| = V(a,b).

This proves (2) for arbitrary P. It constructs recursive optimizers but does not characterize every optimizer in the unrestricted case.

## A standard prime-index trapping lemma

If one proper prefix is a single right coset of a normal prime-index subgroup J of G, then B(x) ≤ J. Before this prefix, a nonempty prefix is contained in that coset and cannot be stabilized by any y outside J, since y sends it into another disjoint coset. After this prefix, y-invariance would force inclusion of all translates of the full J-coset. The nontrivial quotient element yJ cycles all prime-many quotient cosets, so that would force the full group. Hence no proper-prefix stabilizer contains an element outside J.

## Theorem B Rank two escape and equality

Now let P = C_p × C_p and n = q^a, with p ≠ q. Then:

1. The maximum is V(a,2) = np²[a(1−1/q) + 2(1−1/p)].
2. When a ≥ 1 and B(x) = G,

       Z_G(x) ≤ V(a,2) − (p−1).                              (4)

   This is a sufficient gap, not a sharp escaping maximum.
3. Exactly the recursive maximal-subgroup right-coset orderings maximize Z. Each nontrivial optimizer has a unique top subgroup, equal to B(x).
4. Let A(K) count labeled maximizing orders, with A(1)=1. Then

       A(H×C_p²)
         = (p+1) p! A(H×C_p)^p
           + q! Σ_(M maximal in H) A(M×C_p²)^q.              (5)

   The second sum is empty when H is trivial. No quotient by automorphisms or translations is taken.

The proof of the escape bound has two branches. They exhaust the actual full-P checkpoint set; no assertion that B=G forces a proper such checkpoint is used.

### Branch I A proper full P checkpoint exists

The accepted numerical elimination and edge identity apply to the threshold hierarchy by Lemmas 1–2. At the top ranks k = j/p², every nonzero outer q-adic edge loss is at least p(p−1), and zero edges are exactly aligned q-power intervals. A nontrivial zero-loss top path must hit k = n/q.

If this rank is absent, one nonzero edge gives loss at least p(p−1). If it is present with β_(p²n/q) = n/q, the corresponding prefix is one right coset of K × P with |K| = n/q. K is normal of prime index q in H, so the trapping lemma contradicts B=G. Otherwise its retained top deficit is at least p². For n/q = 1 the deficient case is impossible because β ≥ 1. Either permitted case implies (4), with the stronger branch-specific loss at least p(p−1).

### Branch II There is no proper full P checkpoint

Here C_2 = {0,N}. Every proper C_1 checkpoint has stabilizer P-projection equal to some order-p line; different checkpoints may use different lines. Write the complete C_1 rank path as

    0 = k_0 < k_1 < ··· < k_t = np,
    p k_i ∈ C_1.

For any proper such checkpoint j=pk, the sole higher-level clip is 0 < j < N, for each d dividing n. Therefore h_C(pk) = gcd(k,n). At every level-zero point between pk and pl, the higher clip 0 < j < N is redundant beside the strict level-one clips. Consequently the exact U_2 cap is a one-level edge sum over this extended rank range, with a correction only at the final endpoint.

Define h(k)=gcd(k,n), s(k)=Σ_(v=1)^k h(v), D={q,...,q^a}, c_d=d−d/q, and

    w_d(k,l)=max(0,floor(l/d)−ceil(k/d)),
    E_p(k,l)=p[h(l)+Σ_(d∈D)c_d w_d(k,l)]
                        −[1+Σ_(d:w_d(k,l)>0)c_d],
    F_p(k)=p s(k)−k.

Unlike the original one-level group theorem's rank interval, the present k and l range from 0 to np. The base n remains q^a, unchanged. The exact expression is

    U_2(C)=Σ_(i=0)^(t−1) E_p(k_i,k_(i+1)) + (N−np).          (6)

At the final endpoint, the edge formula would use cap p gcd(np,n)−1 = pn−1, whereas the actual full-group cap is N−1. Their difference is N−np. All other endpoints and open intervals have the stated one-level caps.

We next justify the q-adic edge inequality on this longer interval, rather than substituting mixed-order np for n. For arbitrary integers 0 ≤ k < l, let m=l−k and g=gcd(k,l,n). The same direct count of interior d-multiples gives

    F_p(l)−F_p(k)−E_p(k,l) = pA+B,
    A = m−g + Σ_(d∈X)c_d,
    B = 1−m + Σ_(d:w_d>0)c_d,                               (7)

where X consists of the d in D for which neither endpoint is divisible by d but an interior d-multiple exists. This identity never used l ≤ n: divisibility of both endpoints gives negative weights totaling g−1, whether or not the endpoints exceed n.

If m>g, then g divides m, so m≥2g. Dropping nonnegative weights gives

    pA+B ≥ p(m−g)+1−m
          = (p−1)(m−2g)+(p−2)g+1 ≥ p−1.                   (8)

If m=g, then m is a q-power dividing n and the interval is aligned with length m. For d≤m, both endpoints are divisible and w_d=m/d. For d>m, consecutive multiples of m cannot have an interior d-multiple, since d is a multiple of m. Hence A=B=0. Thus on the whole extended range,

    F_p(l)−F_p(k)−E_p(k,l) ≥ 0,
    equality exactly when l−k=gcd(k,l,n),
    every nonzero loss at least p−1.                       (9)

Periodicity of gcd(k,n) gives s(np)=p s(n), with s(n)=n+a n(1−1/q). Consequently

    F_p(np)+(N−np)=V(a,2).                                (10)

Equations (6)–(10) give an exact sum-of-edge-loss expression for V−U_2 in this branch. Every zero edge has aligned q-power length d dividing n. Such an edge cannot cross the rank n strictly inside it. Therefore a path consisting only of zero edges must visit n, which is a proper rank because p≥2.

If rank n is absent, one positive edge gives Z≤U_2≤V−(p−1). If rank n is present, it is a proper C_1 checkpoint and its cap is pn−1. If β_(pn)=n, then its actual stabilizer is H×L for some line L≤P of order p and has order pn equal to the prefix size. The prefix is one right coset of H×L. Since P is abelian and L has index p, H×L is normal of prime index p in G. The trapping lemma contradicts B=G. Otherwise the actual checkpoint contribution is below its cap by p(n−β_(pn)), at least p. This whole endpoint deficit is subtractable from U_2 just as in (3), giving Z≤V−p.

Thus both alternatives imply (4). Multiple line directions are allowed throughout. No direction-count identity or unproved direction-switching cost is needed.

### Optimizer characterization and count

Induct on a, using the accepted prime-power theorem at a=0 and the accepted one-level theorem for H×C_p. For a≥1, Theorem A gives the value and attainment; (4) implies that a maximizer has B<G. Choose a maximal proper subgroup J containing B. Splitting shows that maximal subgroups are exactly H×L, for one of the p+1 lines L of P, and M×P, for M maximal in H. They are all normal of prime index, and their local optimizer theorems are available from the accepted one-level result or the a−1 induction.

For a proper insertion j, let L_j^local be the stabilizer in J of the active local prefix in its right J-coset. Since S_j≤J, S_j≤L_j^local. Every local prefix appears once at its active insertion. The full global prefix replaces the last local stabilizer J by G. Thus

    Z_G = Σ_(right J-cosets C) Z_J(x restricted to C)
            +|G|−|J|−Σ_(j<N)(|L_j^local|−|S_j|).            (11)

All deficits are nonnegative. In either maximal-subgroup direction, the sum of the local maximum values plus |G|−|J| is V(a,2). Equality therefore forces every local order to maximize and every deficit to vanish.

At the first completion of a J-coset, the local stabilizer is J and hence, by zero deficit, so is the global stabilizer. The prefix is a union of full J-cosets. No other coset has yet completed, so all the other cosets are empty. This forces the first consecutive block. The same reasoning at each subsequent completion forces the remaining blocks. Recursing gives exactly the claimed orders.

Conversely, these recursive orders attain V by prime-index block accounting. Every proper stabilizer is contained in the top J, and the first full block has stabilizer exactly J, giving B=J and unique top recovery. For fixed J of index t, there are t! A(J)^t labeled choices. Distinct tops are disjoint. Summing over the p+1 lines and the maximal M proves (5).

## Explicit obstruction to the cyclic proper checkpoint implication

Let D8 = ⟨r,s : r⁴=s²=1, srs=r^−1⟩, encoded by (i,j)=r^i s^j, and let P=F3². Let L=⟨(1,0)⟩ and M=⟨(0,1)⟩. Define

    A={1,s}×L,
    Q={r²,r³s}×M=(⟨rs⟩r²)×M.

These are disjoint six-element sets. Let R be the six elements of {r²}×P outside Q. Order all 72 elements in four consecutive sections:

    A; R; G\(A∪Q∪R); Q,

using increasing coordinate order inside each section, as fixed in DIRECTION_SWITCH_CERTIFICATE.json.

At j=6, T_6=A and S_6=⟨s⟩×L. At j=66, T_66=G\Q and S_66=⟨rs⟩×M. Their generated subgroup is G, since s and rs generate D8, while L and M span F3². Thus B=G.

There is nevertheless no proper P-invariant prefix. During A, some row is partially occupied. During R, the initial A rows stay partial. From the end of R through j=66, the r² row has exactly six occupied points. During the final Q section, that row is completed first while the r³s row remains partial; the latter only completes at j=72. Thus every nonempty proper prefix has a partial P-fibre.

The independently evaluated direct-translation values for this fixed order are

    Z=113, V=204, U_2=194, D_top=0, |B|=72,
    C_2={0,72}.

The score is far below the candidate maximum. This is an obstruction certificate for one invalid cyclic inference, not a sharp escape example or a counterexample to either theorem here.

## Bounded controls and recommended disposition

Fresh controls directly evaluate every prefix stabilizer for 325 individual orders: D8×C3², C2³×C3², C9×C2², C3²×C2², and the cyclic baseline D8×C9. They include three recursive orders per maximal top, 25 random orders per group, 20 perturbed recursive orders per group, and the explicit direction-switch order. All recursive orders have the predicted value; all checked clipping bounds and escape inequalities pass. The D8×C3² value is 204, with seven possible maximal top subgroups: four of index 3 and three of index 2.

A separate fresh arithmetic check covers 158,142 extended-rank edges, including 2,438 zero edges, for the exact bounded parameters recorded in CONTROLS.json. It tests the identity's loss criterion and the rank-n barrier. Neither these tests nor the recurrence are exhaustive enumeration of group orderings or subsets.

Recommended disposition for N6: keep OPEN pending independent review. Split its candidate progress into Theorem A (two arbitrary Sylow factors, maximum value only), Theorem B (rank-two elementary abelian second factor, complete optimizer/escape/count claims), and the verified finite diagnostic showing the old proper-checkpoint implication fails. Do not promote arbitrary-noncyclic optimizer classification, all finite nilpotent groups, three-prime groups, sharp escape values, or historical priority.
