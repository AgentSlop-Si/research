# Independent adversarial review of the order p cubed prefix extension

11 October 2026 UTC. Decision: ACCEPT the maximum specialization, sufficient escape deficit, complete optimizer classification, unique top, and labeled recurrence. There is no mathematical repair or rejected theorem claim. A single terminology clarification in Section 6.3 is recorded below.

## Source binding and independence

The new candidate and its accepted noncyclic baseline were independently materialized from Library and hashed. The candidate archive is libfile_147dc50eec688191b67c360d3208e933 v0, 53,584 bytes, SHA-256 bf14e2fe3b96bf01e54a1e9c0c78e8a527da7d8163f45232a1d17c408f731da4. Its 16 declared payload members match their hashes and lengths. The 20,090-byte proof has SHA-256 65fd51707747ff84487ea16d57b582c290c0d520fa349808a68baf1d52441d90.

The accepted baseline is libfile_6b306a62e6348191a2f106e3b19a8e44 v0, 233,898 bytes, SHA-256 be001a5b8ea0d2e0f546cdb7967f5155e0a2362935d29456a16150f1ac90f76f. All 38 payload members match. The copied accepted statement, accepted review, and all-depth numerical proof match the actual archive members and unchanged local sources. The complete candidate proof and relevant accepted proofs were read.

The author and inherited mathematical programs were not executed or imported. The review has fresh arithmetic, group, and subset-DP implementations. Source escape permutations were used only as data for independent recomputation. The author's aggregate 407-hierarchy and 366-order base checks are not represented as exact reruns: their individual hierarchies and base permutations are not saved in the author records. The reviewer instead generated 407 fresh missing-top hierarchies and 366 fresh orders on the same parameter/family coverage, retained the new permutations, and added further countersearch. The 12 author escape permutations are saved and were exactly replayed independently.

## Threshold invariant and actual endpoint deficits

Coprime powers split every subgroup S≤H×P as L×Q, without abelian hypotheses. If S stabilizes a prefix of size j, its free left action gives |S| dividing j. Thus the threshold sets C_s={0}∪{j:|Q_j|≥p^s} are nested and lie in p^s Z.

The accepted closure/core lemma applies to these thresholds even when distinct surrounding checkpoints have different or incomparable P-subgroups. For a current H-stabilizer L and surrounding endpoints T_a,T_z, the lower H-closure ⋃_(ℓ∈L)ℓT_a and upper H-core ⋂_(ℓ∈L)ℓT_z are invariant under L and the respective endpoint P-subgroups. Their free actions force divisible cardinalities. Equality with either clipping boundary would force the current prefix to have the higher P-level, giving the strict clips used by the numerical invariant.

There is no shared subgroup chain, lower-subgroup normality, or stabilizer persistence assumption. The invariant is defined on nested sets of indices, not on a chain of actual P-projections. Each actual H-order β_j is bounded pointwise by h_C(j). Therefore the sum of any selected actual deficits p^r(h_C−β_j) can be subtracted before increasing the remaining numerical upper bound. This proves that both D_top and D_mid survive every subsequent relaxation with their original coefficients.

## Normal prime index trapping

If a proper prefix is one right coset Jx of a normal prime-index subgroup J, every proper-prefix stabilizer is in J. Earlier nonempty prefixes lie in Jx and are moved disjointly by an outside element. Later proper prefixes contain Jx; invariance under an outside element would cycle its translates through all quotient cosets, forcing the full group.

Every index-p subgroup of a p-group is normal. The coset-action image is a transitive p-subgroup of S_p, hence has order p; the kernel has index p and equals the given subgroup. Accordingly every order-p² subgroup of a group of order p³ is available for trapping. This argument makes no claim about order-p subgroups. D8 and the order-27 nonabelian controls explicitly contain nonnormal smaller subgroups.

## Branch I with a proper full P checkpoint

The accepted group-free elimination applies at depth three while retaining every full-P checkpoint. It yields the collapsed edge

    E_3(k,l)=p²E_p(k,l)+2p²(p−1)(l−k)

on the top-rank path from 0 to n, with retained deficit D_top. The accepted exact one-level edge loss is zero exactly for l−k=gcd(k,l,n), and otherwise is at least p−1. Thus every nonzero collapsed edge loses at least p²(p−1).

A proper full-P checkpoint makes the top path nontrivial. A zero edge is an aligned interval of q-power length. The only possible length-n edge inside [0,n] is the entire path 0→n, so every edge of a nontrivial zero path has length at most n/q and divides n/q. Such an aligned edge cannot cross n/q in its interior. A zero path must therefore visit n/q.

If that rank is absent, the positive collapsed loss proves the stronger branch deficit. If it is present, its actual H-stabilizer has order at most n/q. Equality makes the prefix a single right coset of K×P, with K of index q in H. Prime-index trapping contradicts B=G. A strict endpoint deficit loses at least p³, which is at least p²(p−1). When n/q=1, a deficient H-stabilizer is impossible. This exhausts Branch I without inferring a proper full-P checkpoint from B=G.

## Branch II and the exact deletion correction

Assume C_3={0,N}, N=np³. Keep the q-base n fixed and delete the top level to obtain the numerical depth-two object Ũ_2 on the same physical interval. This is not a group theorem with mixed base np.

For every d dividing n, N is divisible by p³d. The omitted top clip is exactly 0<j<N at every proper index, hence redundant. At a proper C_2 checkpoint the old H-cap is already gcd(j/p²,n), and all other proper contributions also remain unchanged. Only the last term changes: N−1 becomes p²gcd(np,n)−1=np²−1. Consequently

    U_3=Ũ_2+(N−np²).

The positive correction np²(p−1) is necessary and is present in all later identities. The actual proper C_2 deficits have coefficient p² and are recorded in

    D_mid=Σ_(j∈C_2,0<j<N)p²[gcd(j/p²,n)−β_j].

Thus Z≤U_3−D_mid before any densification. No deficit at an inserted artificial checkpoint is claimed.

## Whole gap densification on the enlarged interval

Only one lowest-level densification is required. Consider an old C_1 gap pu<pv. Its enclosing C_2 endpoints are fixed throughout the gap. For each q-power d, intersect the higher-level clipping interval with [u,v] to get L_d,U_d. Both endpoints are integers. The old eligible strict-interior physical indices are counted by

    N_d=max(0,p[floor(U_d/d)−ceil(L_d/d)]−1),

with zero for an empty interval. The inserted level-one eligible ranks are R_d=#{t:L_d<t<U_d, d|t}. The exact difference is

    Δ=(p−1)(v−u−1)+Σ_d (d−d/q)(pR_d−N_d).

If both endpoints are divisible by d and the interval is nonempty, the summand multiplier is −(p−1). With exactly one endpoint divisible it is 0 or 1. With neither divisible it is 0, p, or p+1. Thus only the first case is negative, and it requires d≤U_d−L_d≤v−u. If d_* is the largest q-power at most min(v−u,n), including 1, the total potentially negative weights are at most d_*−1. Therefore

    Δ≥(p−1)(v−u−d_*)≥0.

This arithmetic uses neither v≤n nor physical endpoint np². It remains valid for gaps longer than n and for a=0, when the q-weight sum is empty. Pre-existing positive-level caps use only higher levels and are unchanged. Therefore Ũ_2≤Ũ_2^dense on the enlarged interval, with fixed q-base n.

## Exact quotient and extended edge potential

After densification, every physical index not divisible by p has contribution zero. Its H-cap is 1, not 0; this is the terminology clarification needed in the candidate's Section 6.3. Every remaining index is divided by p and its level decremented. Correspondence of all clips and H-caps gives

    Ũ_2^dense=pŨ_1+(p−1)np².

The rank path for Ũ_1 is 0=k_0<...<k_t=np, where p²k_i∈C_2. The q-base is still n. The one-level edge count gives Ũ_1=Σ_i E_p(k_i,k_(i+1)). Combining the quotient term with the deletion correction gives

    Z≤W(C_2)−D_mid,
    W(C_2)=pΣ_i E_p(k_i,k_(i+1))+2(p−1)np².

Both additive terms have the same size and both are required.

For any integer k<l, let m=l−k, g=gcd(k,l,n), and X be the q-powers for which both endpoints are indivisible but an interior multiple exists. With w_d=max(0,floor(l/d)−ceil(k/d)) and F_p(k)=pΣ_(u=1)^k gcd(u,n)−k, direct counting yields

    F_p(l)−F_p(k)−E_p(k,l)=pA+B,
    A=m−g+Σ_(d∈X)(d−d/q),
    B=1−m+Σ_(d:w_d>0)(d−d/q).

The negative endpoint weights telescope to g−1. Because g divides m, m>g implies m≥2g, and the loss is at least

    p(m−g)+1−m
      =(p−1)(m−2g)+(p−2)g+1≥p−1.

If m=g, the interval is aligned with q-power length g dividing n, and the loss is exactly zero. No step requires l≤n. Periodicity gcd(k+n,n)=gcd(k,n) gives s(np)=p s(n), hence

    pF_p(np)+2(p−1)np²=V(a,3),
    V(a,3)−W(C_2)=pΣ_i [F_p(k_(i+1))−F_p(k_i)−E_p(k_i,k_(i+1))].

This verifies the critical telescope with fixed base n and extended endpoint np. Each nonzero edge loses at least p(p−1).

## Forced intermediate checkpoint and actual deficit

A zero edge has aligned q-power length dividing n, so it cannot contain the multiple n strictly inside. A zero path from 0 to np must therefore visit n, a proper rank since p≥2. If rank n is absent, the edge loss proves Z≤V−p(p−1), including the case C_2={0,N}.

If rank n is present, its physical prefix is j=np². It has P-projection Q of order exactly p² because no proper C_3 point exists, and its numerical H-cap is n. Saturation β_j=n makes that prefix one right coset of H×Q. The subgroup Q is normal of index p, so trapping contradicts B=G. Otherwise the original retained deficit is p²(n−β_j)≥p²≥p(p−1), and the same bound follows from Z≤W−D_mid≤V−D_mid.

Switching order-p² projections is harmless: a single saturated forced checkpoint traps all proper stabilizers in its own prime-index subgroup. Smaller subgroups are never used for this step. Together with Branch I, this establishes the stated escape theorem universally under the accepted numerical and closure/core dependencies.

## Equality induction and unique top

Induct on a. At a=0 the accepted arbitrary finite p-group structural theorem supplies value, recursion, and unique top. At a≥1 the strict escape theorem forces any optimizer to have B<G. Choose a maximal subgroup J containing B.

Coprime splitting shows that J is either H×R with R maximal in P, or M×P with M maximal in H. Both have normal prime index. In the first case |R|=p². A group of order p² is abelian: its center is nontrivial, and a cyclic quotient by its center forces commutativity. It is either cyclic of order p² or elementary abelian of rank two. Therefore the accepted cyclic or rank-two theorem supplies every required local H×R result. In the second case the q-exponent decreases by one. The induction is closed, including a=1 and singleton termination.

For a proper insertion j, S_j≤J and S_j is contained in the stabilizer L_j^local of the active local prefix in its right J-coset. Right translation to J preserves left stabilizers. Every local prefix appears once, at its insertion; only the final local/global terms differ. Thus the exact identity is

    Z_G=Σ_C Z_J(x restricted to C)+|G|−|J|
         −Σ_(j<N)(|L_j^local|−|S_j|).

All deficits are nonnegative. In either maximal-subgroup direction, the sum of local maxima plus |G|−|J| equals V(a,3). Equality forces every local order to be optimal and every deficit zero.

At the first completed J-coset, L_j^local=J, so equality gives S_j=J. The prefix is a union of complete J-cosets. Since only one coset has completed, every other coset is empty. This forces a consecutive first block. At each further completion before the last, the same argument forbids any occupied unfinished coset, forcing the next block. The last block is automatic. Local induction yields the complete recursion without classifying equality in the numerical densification itself.

Conversely, consecutive prime-index blocks with optimal local orders attain the value by the accepted block accounting. All proper stabilizers lie in the chosen J, and the first complete block has stabilizer exactly J. Hence B=J. This proves top recovery and disjointness of the optimizer families associated with distinct top subgroups.

## Count and elementary abelian specialization

For a fixed maximal J of index t, its distinct labeled right cosets have t! possible block orders. Each has A(J) independent local choices, using any fixed right-translation identification. A different choice of identification is a bijection of the same local orders; it contributes no extra multiplicative representative factor. Thus this top contributes t!A(J)^t. Distinct tops are disjoint because B recovers the top. Summing over the two maximal-subgroup types gives exactly the claimed recurrence.

For P=(C_p)^3, every maximal subgroup is the kernel of a nonzero functional, with exactly p−1 scalar multiples per kernel. There are (p³−1)/(p−1)=p²+p+1 such subgroups, all isomorphic to (C_p)^2. This proves the specialization. The D8 maximal types C4,C2²,C2² and Q8 maximal types C4,C4,C4 were checked independently from full multiplication tables.

## Independent finite controls and countersearch

The fresh mathematical code and detailed output are included.

- Arithmetic: 407 fresh missing-top hierarchies on the candidate's 11 parameter families check the exact deletion correction, each individual whole-gap change, densification, quotient, extended edge sum, retained n-base, and forced rank-n barrier. There are 330 additional arbitrary-top hierarchies, and 62,774 exact edge checks, including ranges beyond n and beyond np. These include a=0 and both relative prime orders p<q and p>q.
- Direct groups: 366 fresh order evaluations across 16 factor families include 110 recursive orders, random orders, and perturbed recursive orders. Every prefix stabilizer is calculated by actual left translation. Pointwise caps, total maxima, actual endpoint deficits after all relaxations, saturation trapping, and recursive form for every observed optimizer are checked. Both factors are nonabelian in several families. The new permutations are retained for reproducibility.
- Ten order-p³ multiplication tables, five at order 8 and five at order 27, are checked for identity, Latin rows, every associativity triple, maximal-subgroup order and normality, and cyclic versus elementary-abelian maximal types. The lower nonnormal-subgroup counts include four reflection subgroups in D8, twelve order-three subgroups in Heisenberg27, and three in the modular group of order 27.
- All 12 saved candidate escape orders are independently replayed, including all checkpoint sets, all H-stabilizer orders, stored witness stabilizers, B=G, scores, caps, and reported deficits. Each of the three P models covers Branch I missing n/q, Branch I deficient n/q, Branch II missing n, and Branch II deficient n. The sorted Heisenberg example has Z=429, U=W=594, V=756, D_mid=99 and B=G. The modular sorted example has Z=317, U=494, W=594, D_mid=99 and B=G. The branch-II gap is not inferred from the finite deficit size.
- An unrestricted subset dynamic program evaluates all five order-8 groups and all five products C3×P, totaling 83,887,360 subsets. It computes stabilizers by cycle-union invariance under actual left translations, then calculates the best score and exact number of maximizing labeled orders for each subset by partitioning on the last element. It makes no recursive optimizer assumption. The final count is compared only afterward with the independent subgroup recurrence. For C3×P the maximum is always 52; counts for P=C2³,C4×C2,C8,D8,Q8 are respectively 3,547,802,861,568; 78,165,934,080; 2,044,231,680; 203,047,403,520; and 6,434,684,928. Pure order-8 maximum/count pairs are 12/8,064; 12/1,408; 12/128; 12/2,432; and 12/384. All exact counts agree. Unsigned 128-bit counts are sufficient because 24! is smaller than 2^128.

There are no failed mathematical assertions. The subset program does not separately calculate an exact escaping maximum or carry B as an auxiliary DP state; neither is claimed. No subset or permutation enumeration is performed for orders 54 or 216. None of these finite controls establishes a universal result by extrapolation.

## Scope and proposed use

The accepted statement is precisely every P of order p³, including nonabelian P, with arbitrary finite q-group H and p≠q. The numerical maximum remains accepted for arbitrary finite two-Sylow factors through the earlier theorem. No claim of arbitrary-order-P optimizer classification, three-prime structure, all-nilpotent structure, sharp escape, novelty, or closure of a historical source-comparison gap follows from this review.

For a later clean edition, change only the ambiguous “cap zero” wording in Section 6.3 to “zero contribution”; the source-bound candidate is preserved unchanged here. This is an editorial clarification, not a mathematical repair gate. Earlier accepted proofs and statuses remain intact. No Sheet or GitHub edits were made.
