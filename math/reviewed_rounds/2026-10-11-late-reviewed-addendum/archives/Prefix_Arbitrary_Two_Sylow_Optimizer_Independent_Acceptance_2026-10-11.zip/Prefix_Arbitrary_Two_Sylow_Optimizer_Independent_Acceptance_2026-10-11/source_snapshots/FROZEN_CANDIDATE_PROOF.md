# Prefix optimizers for two arbitrary Sylow factors

11 October 2026 UTC. Source-bound author candidate, pending independent review.

## 1. Statement and exact scope

Let p and q be distinct primes. Let H be any finite q-group of order n=q^a, P any finite p-group of order p^b, and G=H×P, with a,b≥0. Either or both factors may be nonabelian. For a labeled ordering x of the elements of G, write

    T_j={x_1,...,x_j},  S_j={g∈G:gT_j=T_j},
    Z_G(x)=Σ_(j=1)^N (|S_j|−1),
    B(x)=⟨S_j:1≤j<N⟩,  N=np^b,
    V(a,b)=np^b[a(1−1/q)+b(1−1/p)].                         (1)

The full prefix contributes to Z and is excluded from B. The empty prefix is used only as a numerical endpoint and contributes to neither.

The candidate conclusions are:

A. The already accepted maximum formula remains max_x Z_G(x)=V(a,b).

B. For a,b≥1, define

    δ_p(b) = p−1                    if b=1,
             p^(b−2)(p−1)          if b≥2.

If B(x)=G, then

    Z_G(x) ≤ V(a,b)−δ_p(b).                                (2)

In the branch with at least one proper full-P checkpoint, the stronger sufficient loss p^(b−1)(p−1) holds. These are sufficient losses; sharp escaping maxima are not asserted. The previously accepted stronger cyclic-factor estimate remains unchanged.

C. The maximizing orders are exactly the recursive maximal-subgroup right-coset orders: choose one maximal proper subgroup J, arrange its distinct right cosets consecutively in any order, choose an independent optimal local order in each coset, and recurse to singletons.

D. Each nontrivial optimizer has a unique top subgroup, recovered exactly as B(x). The singleton has value zero and one ordering and has no top subgroup.

E. With A(K) denoting the number of labeled maximizing element orders of K, A(1)=1, and an empty sum whenever the indicated factor is trivial,

    A(H×P) = p! Σ_(R maximal in P) A(H×R)^p
                  +q! Σ_(M maximal in H) A(M×P)^q.         (3)

This includes the prime-power axes using their one nonempty sum. There is no translation or automorphism quotient, no division by conjugacy classes of subgroups, and no extra choice of coset representatives.

These conclusions cover exactly direct products of two finite groups of distinct prime-power orders, including all choices of group structure in both factors. They do not address three distinct prime factors, all finite nilpotent groups, sharp escape values, historical priority, or the existing external source-comparison gap. This packet is not independent acceptance, formal verification, or external peer review.

## 2. Accepted dependencies and the new step

The accepted arbitrary-two-Sylow value and rank-two packet is Library libfile_6b306a62e6348191a2f106e3b19a8e44, version 0, archive SHA-256 be001a5b8ea0d2e0f546cdb7967f5155e0a2362935d29456a16150f1ac90f76f. It supplies the subgroup splitting, threshold checkpoint closure/core bound, arbitrary-hierarchy numerical invariant, accepted all-depth cyclic numerical elimination, extended q-adic edge identity, value formula, and arbitrary finite prime-power structural bases.

The accepted order-p³ structure packet is Library libfile_948c6d7a48288191a3645a2e3174895c, version 0, archive SHA-256 ea5298da2cdae0f75141add6a064c18b86b43372abd6a640d8f1da9a0f899f45. It supplies the top-deletion idea, exact final-endpoint correction, and missing-top branch at depth three. We reuse it rather than claiming those components as new.

The new proof extends the numerical domain explicitly, deletes an absent top level at arbitrary depth, then performs exactly b−2 whole-gap densification/quotient steps with the q-power base n fixed. It proves the accumulated correction and rank-n barrier for all b≥2. This gives strict escape at arbitrary p-depth, allowing a double induction on a+b for optimizer structure and count. No order-p⁴ or order-p⁵ case is used as an induction premise.

The exact source snapshots, checksums, Library bindings, and reused control primitives are included. Accepted source text is unchanged. In new text the earlier wording “nonmultiples of p have cap zero” is corrected: their H-cap is 1 and their contribution p^r h−1 is zero.

## 3. Actual threshold hierarchy and endpoint deficits

Every subgroup S≤H×P splits as L×Q. For each (h,z)∈S, coprime-order powers isolate (h,1) and (1,z), giving the splitting without commutativity within either factor.

Write S_j=L_j×Q_j, β_j=|L_j| and |Q_j|=p^r(j). Define

    C_0={0,...,N},
    C_s={0}∪{j:1≤j≤N, |Q_j|≥p^s},  1≤s≤b.

Then C_b⊆⋯⊆C_1⊆C_0, C_s⊆p^s Z, and 0,N∈C_s. These are thresholds on subgroup order; they do not choose a common chain of P-subgroups. Different endpoints may have incomparable projections.

Put D={q,q²,...,q^a} and c_d=d−d/q. If r=r(j)<s and a_s<j<z_s are the consecutive C_s endpoints enclosing j, the accepted closure/core lemma implies, for every d∈D dividing β_j,

    d | j/p^r,
    p^s d ceil(a_s/(p^s d)) < j
                     < p^s d floor(z_s/(p^s d)).           (4)

For clarity, the group reason is as follows. Choose order-p^s subgroups A and D' preserving T_(a_s) and T_(z_s), respectively; they need not coincide. The L_j-closure of the lower endpoint lies inside T_j and is invariant under L_j×A. The L_j-core of the upper endpoint contains T_j and is invariant under L_j×D'. Their cardinalities are divisible by β_j p^s. Equality at either outer bound in (4) would identify T_j with that closure or core and force |Q_j|≥p^s, a contradiction. Only commutation of the two direct factors is used.

For r(j)=b, β_j divides gcd(j/p^b,n). Otherwise let h_C(j) be 1 plus the sum of c_d for d satisfying the divisibility test and every strict clip (4) with s>r(j). At r(j)=b let h_C(j)=gcd(j/p^b,n). Then

    U_b(C)=Σ_(j=1)^N [p^r(j) h_C(j)−1],
    β_j≤h_C(j),  Z_G≤U_b(C)≤V(a,b).                       (5)

Any specified set of pointwise actual deficits can be retained before replacing U_b by a larger numerical bound. We use

    D_top=Σ_(j∈C_b,j>0) p^b[gcd(j/p^b,n)−β_j].             (6)

The final term is zero. In the missing-top branch we instead retain the proper level-(b−1) deficits defined in Section 7. We do not assume that endpoint stabilizers persist at other indices.

## 4. Extended-domain numerical elimination at every depth

This section records the general numerical lemma actually needed for the extension. Keep n=q^a and p fixed. Let m≥1, let L be any positive integer divisible by p^m, and let

    C_m⊆⋯⊆C_1⊆C_0={0,...,L},
    C_s⊆p^s Z,  0,L∈C_s.

Define U(n,p;m,L,C) by the exact rule of Section 3, with top H-cap gcd(j/p^m,n), the same D={q,...,q^a}, and all higher-level clips. L/p^m is not required to equal n or be a q-power. This is only a numerical functional, not a group-ordering theorem with a substituted base.

### 4.1 One whole-gap comparison

Take consecutive C_1 indices pu<pv and put r=v−u. Every positive-level checkpoint is absent in the open gap. For each s≥2 its enclosing C_s endpoints a_s,z_s are therefore constant there. For d∈D put

    L_d=max({u}∪{p^(s−1)d ceil(a_s/(p^s d)):2≤s≤m}),
    U_d=min({v}∪{p^(s−1)d floor(z_s/(p^s d)):2≤s≤m}).

For m=1 these are u,v. If L_d≥U_d set N_d=R_d=0. Otherwise put

    N_d=max(0,p[floor(U_d/d)−ceil(L_d/d)]−1),
    R_d=#{t∈Z:L_d<t<U_d and d|t}.

The old open-gap contribution is Σ_d c_d N_d: all its indices have level zero and these are the exact counts of eligible d-multiples after intersecting every strict clip. Insert every missing C_1 multiple pt, u<t<v, at once. Its new positive-level contribution has baseline (p−1)(r−1) and weighted contribution pΣ_d c_d R_d. Every remaining nonmultiple of p has H-cap 1 and contribution zero, because its adjacent C_1 ranks are consecutive integers and admit no eligible d≥2. Preexisting positive-level caps are unchanged, since they depend only on levels strictly above their own.

Consequently the new minus old contribution is exactly

    Δ=(p−1)(r−1)+Σ_d c_d(pR_d−N_d).                        (7)

When L_d<U_d, the arithmetic cases are exhaustive:

- Both endpoints divisible by d: pR_d−N_d=−(p−1).
- Exactly one endpoint divisible: the difference is zero for R_d=0 and one otherwise.
- Neither endpoint divisible: the difference is zero, p, or p+1 according as R_d is 0, 1, or at least 2.

A negative term requires d≤U_d−L_d≤r. If d_* is the largest q-power at most min(r,n), allowing d_*=1, the negative weights sum to at most d_*−1. Thus

    Δ≥(p−1)(r−d_*)≥0.                                    (8)

No step restricts v or L to a q-power range. This proves lowest-level whole-gap densification on the extended domain, including gaps longer than n and higher clips from arbitrarily many levels. It does not assert monotonicity of single-checkpoint insertion or realizability of a densified hierarchy.

### 4.2 Quotient identity and induction with an unchanged rank base

Replace C_1 by all multiples of p and denote the result C^dense. Every nonmultiple of p contributes zero, as specified above. Divide the remaining indices by p and decrement all levels; let

    C'_0={0,...,L/p},
    C'_s={j/p:j∈C_(s+1)},  1≤s≤m−1.

The top H-caps, divisibility tests, and all strict clips correspond exactly. The q-power base remains n. At every positive quotient index,

    p^r h−1 = p[p^(r−1)h−1]+(p−1).

Therefore

    U(n,p;m,L,C^dense)
       =p U(n,p;m−1,L/p,C')+(p−1)L/p.                     (9)

For m−1=0, define U(n,p;0,L/p,C')=Σ_(j=1)^(L/p)[gcd(j,n)−1]. In combination with (8), repeated application of (9) gives, for 0≤k≤m−1,

    U(n,p;m,L,C)
       ≤p^k U(n,p;m−k,L/p^k,C^(k))+k(p−1)L/p.             (10)

This is an induction on the number of eliminations: each new additive term, multiplied by the preceding p^k, is again (p−1)L/p. The surviving positive-level sets in C^(k) are the original C_(s+k) divided by p^k, so original top endpoints are unchanged. Actual retained endpoint deficits remain subtractable when (10) enlarges a numerical upper bound; they are not scaled or redefined.

At k=m−1, let 0=k_0<⋯<k_t=L/p^m be the original top ranks j/p^m. The remaining depth-one functional is the sum of one-level edges E_p(k_i,k_(i+1)) defined next. Thus (10) is an arbitrary-depth proof on the extended domain, not an extrapolation from m=2 or m=3.

## 5. Extended q-adic edge lemma and two barriers

Let h(k)=gcd(k,n), s(k)=Σ_(u=1)^k h(u), s(0)=0. For arbitrary integers 0≤k<l, define

    w_d(k,l)=max(0,floor(l/d)−ceil(k/d)),
    E_p(k,l)=p[h(l)+Σ_d c_d w_d(k,l)]
                           −[1+Σ_(d:w_d>0)c_d],
    F_p(k)=p s(k)−k,
    ℓ_p(k,l)=F_p(l)−F_p(k)−E_p(k,l).                       (11)

At depth one the open-gap eligible count for d is max(0,pw_d−1), while the right endpoint contributes ph(l)−1. Hence the functional is exactly the edge sum, with no approximation at its endpoints.

The accepted edge identity on this unrestricted integer range is

    ℓ_p(k,l)=pA+B,
    A=m−g+Σ_(d∈X)c_d,
    B=1−m+Σ_(d:w_d>0)c_d,
    m=l−k,  g=gcd(k,l,n),                                 (12)

where X comprises the q-powers d for which neither endpoint is divisible by d but there is an interior d-multiple. The identity follows by counting strict interior multiples; divisible endpoints give total negative weight g−1. It does not require l≤n.

If m>g, divisibility gives m≥2g. Dropping nonnegative weights gives

    ℓ_p(k,l)≥p(m−g)+1−m
      =(p−1)(m−2g)+(p−2)g+1≥p−1.

If m=g, the endpoints are consecutive multiples of the q-power m dividing n. For d≤m both endpoints are divisible and w_d=m/d; for d>m there is no interior d-multiple. Equation (12) then gives zero. Therefore

    ℓ_p(k,l)≥0,
    ℓ_p(k,l)=0 iff l−k=gcd(k,l,n),
    ℓ_p(k,l)>0 implies ℓ_p(k,l)≥p−1.                      (13)

A zero-loss edge is an aligned interval of length a q-power d dividing n. Two consequences will be used:

(i) Every zero-loss path from 0 to np visits n. Indeed, the edge containing n has length d dividing n and endpoints consecutive d-multiples, so it cannot contain n strictly inside.

(ii) Every nontrivial zero-loss path from 0 to n visits n/q when a≥1. An edge of length n could only be 0→n and would make the path trivial. Every edge of a nontrivial zero-loss path has length d≤n/q dividing n/q and cannot cross that multiple strictly.

Finally h is n-periodic and

    s(n)=n+a n(1−1/q),  s(np)=p s(n).                      (14)

The formula also holds when n=1 and D is empty.

## 6. Prime-index trapping for every p-group maximal subgroup

If a proper prefix is one right coset Jx of a normal subgroup J of prime index t, every proper-prefix stabilizer lies in J. Before that prefix, an outside element sends its containing J-coset to a disjoint coset. After that prefix, invariance under an outside element would include all translates of the full J-coset. Its nontrivial quotient image cycles the t quotient cosets, forcing the full group. Thus B≤J.

Every maximal subgroup R of a finite p-group P is normal of index p. For completeness, a proper subgroup K<P is properly contained in its normalizer: let K act by left translation on P/K. The number of fixed cosets is divisible by p, since |P/K| is divisible by p and every nontrivial orbit has size divisible by p; there is at least one fixed coset. Fixed cosets correspond to N_P(K)/K, so [N_P(K):K]≥p. For maximal R, this forces N_P(R)=P. The nontrivial p-group P/R has no nontrivial proper subgroup and hence has order p (take any element of order p). Conversely an index-p subgroup is maximal, and the same assertion, or the action on its p cosets, proves normality.

The same facts hold for H with q replacing p. The argument does not assume that smaller order-p subgroups are normal. Both branches below use only a normal maximal subgroup of one factor.

## 7. Strict escape at arbitrary p-depth

Assume a,b≥1 and B=G.

### 7.1 At least one proper full-P checkpoint

Apply Section 4 to the actual depth-b hierarchy with L=N and k=b−1. Its top ranks are a nontrivial path from 0 to n. Retaining (6) gives

    Z_G≤p^(b−1)Σ_edges E_p(k,l)
            +(b−1)(p−1)np^(b−1)−D_top.                   (15)

By (14), the corresponding full potential is V(a,b). Thus

    V(a,b)−Z_G≥p^(b−1)Σ_edges ℓ_p(k,l)+D_top.             (16)

If the path omits n/q, barrier (ii) gives a positive edge and hence loss at least p^(b−1)(p−1). If it visits n/q and β_(p^b n/q)=n/q, that prefix has stabilizer K×P of size equal to its own size. It is one right coset of that subgroup. K is normal of index q in H, so Section 6 traps B in K×P, a contradiction. Otherwise the retained deficit there is at least p^b, which exceeds p^(b−1)(p−1). When n/q=1, this deficient possibility is impossible because β≥1.

This proves the asserted stronger branch loss for all b≥1. For b=1 this exhausts B=G: if there were no proper full-P checkpoint, every proper P-projection would be trivial and B≤H×1<G.

### 7.2 No proper full-P checkpoint: exact top deletion

Now let b≥2 and C_b={0,N}. Delete level b to form a depth-(b−1) hierarchy on the same interval 0,...,N. Denote its extended-domain functional by

    Ũ_(b−1)=U(n,p;b−1,N,(C_0,...,C_(b−1))).

Every omitted level-b clip is 0<j<N for each d|n, because p^b d divides N. It is redundant at every proper index. If a proper index was at level b−1, its original H-cap is therefore exactly gcd(j/p^(b−1),n), equal to the new top cap. At lower levels the unchanged clips and unchanged level give the same contribution. At the final index alone, the old contribution is N−1 and the new one is p^(b−1)gcd(np,n)−1=np^(b−1)−1. Consequently the exact identity is

    U_b(C)=Ũ_(b−1)+(p−1)np^(b−1).                         (17)

Retain the original proper level-(b−1) endpoint deficits

    D_pen=Σ_(j∈C_(b−1),0<j<N)
               p^(b−1)[gcd(j/p^(b−1),n)−β_j].            (18)

Every summand is nonnegative; the full endpoint is deliberately excluded. Then

    Z_G≤U_b(C)−D_pen.                                     (19)

No actual subgroup ordering is claimed for the truncated numerical hierarchy.

### 7.3 Exactly b−2 eliminations and the total correction

Apply (10) to the truncated hierarchy with m=b−1, L=N, k=b−2. For b=2 this means zero eliminations, so the same formula already includes that boundary. The final depth-one physical length is np², and its top rank path is

    0=k_0<⋯<k_t=np,  p^(b−1)k_i∈C_(b−1).

The H-rank base is still n, not np. Equations (10), (17), and (19) yield

    Z_G≤W_b(C_(b−1))−D_pen,
    W_b=p^(b−2)Σ_edges E_p(k,l)
                  +(b−1)(p−1)np^(b−1).                  (20)

The additive term contains b−2 equal contributions from numerical elimination and one from the changed final endpoint in (17). Explicitly,

    (b−2)(p−1)N/p+(p−1)np^(b−1)
       =(b−1)(p−1)np^(b−1).

Using (14), the corresponding full potential is

    p^(b−2)F_p(np)+(b−1)(p−1)np^(b−1)
      =p^b s(n)−np^(b−1)+(b−1)(p−1)np^(b−1)
      =V(a,b).                                          (21)

Therefore there is an exact loss identity for the collapsed bound,

    V(a,b)−W_b=p^(b−2)Σ_edges ℓ_p(k,l),                  (22)

and hence the retained-deficit inequality

    V(a,b)−Z_G≥p^(b−2)Σ_edges ℓ_p(k,l)+D_pen.            (23)

Equation (22) is an identity for W_b; no equality between U_b and W_b is asserted before densification. All endpoint deficits in (23) are measured against the original actual stabilizers.

### 7.4 The forced normal maximal checkpoint

If the rank-n vertex is missing, barrier (i) gives a positive edge; (13) and (23) give loss at least p^(b−2)(p−1).

If rank n is present, the corresponding proper prefix has physical size j=np^(b−1). Its P-projection Q has order exactly p^(b−1): it is in C_(b−1) and there are no proper C_b checkpoints. If β_j=n, its stabilizer H×Q has size equal to the prefix size, so the prefix is one right coset of H×Q. Q is index p and normal in P by Section 6, even for arbitrary nonabelian P. The trapping lemma contradicts B=G.

Thus β_j<n, and its retained contribution to (18) is

    p^(b−1)(n−β_j)≥p^(b−1)>p^(b−2)(p−1).

Equation (23) gives the required sufficient escape loss again. This also covers C_(b−1)={0,N}, for which rank n is absent. All still-lower checkpoint sets may be empty except for endpoints, or may switch among incomparable subgroup directions; neither alternative changes the proof. No normality of those lower subgroups is needed.

The two branches and the b=1 observation prove (2) at every b≥1. In particular b=2 gives p−1 and b=3 gives p(p−1), exactly the accepted noncyclic bounds. The formula for b≥2 was derived with arbitrary depth, not inferred from those special cases.

## 8. Prime-power axes and singleton

We recall the accepted finite-prime-power argument so that no structural base is hidden. For any finite group K of order t^e, the stabilizer of a j-element prefix acts freely, so its order divides gcd(j,t^e). Therefore

    Z_K≤Σ_(j=1)^(t^e)[gcd(j,t^e)−1]=t^e e(1−1/t).         (24)

For e=0, the value is zero and the one ordering is the singleton base. For e≥1, an index-t maximal subgroup J and consecutive right J-coset blocks with optimal local orders attain (24) by induction: the total is t times the local maximum plus |K|−|J|.

Conversely, equality in (24) forces every pointwise cap to be attained, in particular at j=|K|/t. That prefix is one right coset of its stabilizer J of order |K|/t. Section 6 traps all proper stabilizers in J. The exact local accounting and first-completion argument in Section 9 then force consecutive J-coset blocks with local optimal orders. This proves prime-power structure, uniqueness, and count by induction on e. It supplies a=0 with arbitrary P, b=0 with arbitrary H, and their singleton intersection. No escape claim on either axis is needed for the two-variable induction.

## 9. Double induction, equality, unique top, and no-duplicate count

Induct on a+b, simultaneously for all choices of H and P of the indicated orders. Section 8 supplies both axes. Suppose a,b≥1. The value and recursive attainment are accepted and also follow by the prime-index block calculation below. The strict escape theorem implies that any optimizer has B<G.

Choose a maximal subgroup J containing B. Coprime splitting shows that J is exactly one of

    H×R,  R maximal in P,  [G:J]=p;
    M×P,  M maximal in H,  [G:J]=q.                       (25)

Indeed, a subgroup with both factors proper can enlarge either factor and is not maximal; with one factor full, maximality is exactly maximality of the other. Every subgroup in (25) is normal of prime index. Its structural theorem is supplied by induction at (a,b−1) or (a−1,b), respectively, for its actual group structure, not just its order.

Identify each right J-coset Jx with J by y↦yx; this preserves the left J-action. For each insertion j let L_j^local≤J be the stabilizer of the active local prefix in its right J-coset. Because S_j≤B≤J for j<N, we have S_j≤L_j^local. Every local prefix appears at its unique active insertion. At the final insertion the local stabilizer is J and the global stabilizer is G. Therefore the exact accounting is

    Z_G=Σ_(right J-cosets C) Z_J(x restricted to C)
              +|G|−|J|−Σ_(j<N)(|L_j^local|−|S_j|).        (26)

All deficits are nonnegative. The local value theorem gives, for t=[G:J],

    t max Z_J+|G|−|J|=V(a,b),                              (27)

in either direction of (25). Equality of the global score forces every local order optimal and every deficit in (26) to be zero.

At the first completion of a J-coset, its local stabilizer is J and hence the global stabilizer is J. The prefix is a union of whole J-cosets. No other coset has yet completed, so every other coset is empty. This forces the first consecutive block. At each subsequent completion before the last, zero deficit likewise excludes every other occupied unfinished coset; induction over completions forces the next consecutive block. The final block is the remaining coset. Each local order has the recursive structure by the a+b induction.

Conversely, fix any J in (25), list its cosets in consecutive blocks, and use local maximizing orders. An element outside J cycles the prime-many quotient cosets. It cannot stabilize a proper prefix at a block boundary, where the full quotient-coset set is a nonempty proper subset, or inside a block, where there is exactly one partially occupied coset. Thus every proper stabilizer lies in J and equals the active local stabilizer; completed cosets are J-invariant and empty cosets impose no constraint. Equation (26) has zero deficits and gives (27). This verifies the converse for every possible top, not only one constructing example.

At the first full block, which is a proper prefix because t≥2, the global stabilizer is exactly J. All other proper stabilizers lie in J, so B=J. Thus the top is unique, including the order-prime case J=1. This completes the structural induction for arbitrary P.

For fixed J of index t, its distinct labeled right cosets may be ordered in t! ways. A fixed right-translation identification of each coset with J gives A(J) local choices, independently, hence t!A(J)^t orders. Choosing a different representative only changes that identification bijectively and gives no additional element ordering. Within a fixed top, block boundaries and local sequences are recoverable from the ordering, so none is counted twice. Different tops cannot count the same ordering because each is recovered as B. Summing over the actual maximal subgroups in (25), without an automorphism or conjugacy quotient, proves (3).

## 10. Boundary checklist and review status

- b=1: the missing-top branch cannot occur under B=G; the first branch gives p−1.
- b=2: top deletion is followed by zero elimination steps, and the retained correction yields the accepted p−1 loss.
- b=3: one elimination yields the accepted p(p−1) loss.
- Arbitrary b≥2: the same proved extended-domain induction has b−2 steps; no missing case is filled by finite testing.
- a=0, b=0, and the singleton: supplied separately by Section 8; empty D and empty recurrence sums are legitimate.
- Empty/full checkpoints: both are numerical endpoints; the empty prefix is not scored; the full prefix is scored once, excluded from B, and requires the explicit correction in (17).
- No proper penultimate checkpoints: (22) has one edge 0→np with positive loss.
- Incomparable endpoint subgroups and nonnormal smaller subgroups: allowed; trapping is used only at a saturated maximal-subgroup checkpoint.
- Densification: all enclosing clips are retained, the H-cap at nonmultiples is 1, and actual deficits are retained before upper-bound replacement.
- Count: labeled orderings, actual maximal subgroups, unique top, no representative multiplicity.

The proof above is the universal argument. Reused finite controls and newly written bounded arithmetic/group checks provide corroboration and reproducibility only. Independent adversarial review of this sealed candidate is required before promoting optimizer structure, unique top, recurrence, or arbitrary-depth escape to accepted status. The previously accepted maximum value and previously accepted structural subclasses are unchanged. No Sheet or GitHub mutation is part of this packet.
