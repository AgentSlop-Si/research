# Accepted prefix optimizer theorem for a q group times a group of order p cubed

Independent project mathematical review, 11 October 2026 UTC. All five mathematical claims below are ACCEPTED. The earlier two-Sylow value theorem, cyclic-depth theorem, and elementary-abelian rank-two theorem remain unchanged.

Let p and q be distinct primes, H any finite q-group of order n=q^a, P any group of order p³, and G=H×P. Neither factor need be abelian. For an ordering x of all labeled elements of G, let T_j be its first j elements and S_j its left stabilizer. Define

    Z_G(x)=Σ_(j=1)^|G| (|S_j|−1),
    B(x)=⟨S_j:1≤j<|G|⟩,
    V(a,3)=np³[a(1−1/q)+3(1−1/p)].

The full prefix contributes to Z and is excluded from B.

## Accepted mathematical claims

1. Maximum, carried forward from the accepted arbitrary-two-Sylow theorem:

       max_x Z_G(x)=V(a,3).

2. Sufficient escape deficit, newly accepted for every P of order p³: if a≥1 and B(x)=G, then

       Z_G(x)≤V(a,3)−p(p−1).

   If there is at least one proper prefix with full P-projection of its stabilizer, the proof gives the stronger sufficient deficit p²(p−1). Neither statement asserts sharpness.

3. Equality classification: the maximizing orders are exactly the orders obtained by recursively choosing a maximal subgroup, arranging its right cosets consecutively in any order, and choosing an independent optimal local order in each coset. The recursion terminates at singletons.

4. Unique top: every nontrivial optimizer has a unique top subgroup, recovered exactly as B(x).

5. Labeled count: with A(1)=1, no translation or automorphism quotient, and the second sum empty for H=1,

       A(H×P)=p! Σ_(R maximal in P) A(H×R)^p
                  +q! Σ_(M maximal in H) A(M×P)^q.

   For P=(C_p)^3 this is

       A(H×(C_p)^3)=(p²+p+1)p! A(H×(C_p)^2)^p
                         +q! Σ_(M maximal in H) A(M×(C_p)^3)^q.

Every maximal R<P has order p², so all local H×R classifications needed here are already supplied by the accepted cyclic or elementary-abelian rank-two theorem. The a=0 input is the accepted arbitrary finite p-group theorem. The singleton base has value 0 and exactly one order; it has no top subgroup.

## Exact binding and qualification

This decision binds CANDIDATE_PROOF.md, 20,090 bytes, SHA-256 65fd51707747ff84487ea16d57b582c290c0d520fa349808a68baf1d52441d90, in Library libfile_147dc50eec688191b67c360d3208e933 version 0. Its archive SHA-256 is bf14e2fe3b96bf01e54a1e9c0c78e8a527da7d8163f45232a1d17c408f731da4.

No mathematical repair is required. In Section 6.3, “all nonmultiples of p have cap zero” should read “all nonmultiples of p have zero contribution p^r h_C−1; their H-cap h_C is 1.” This terminology correction changes no identity or theorem.

The universal conclusion rests on the proof audit and accepted dependencies. Finite controls are corroboration, not extrapolation. This is independent project review, not formal verification or external peer review. Arbitrary-order noncyclic P optimizer structure, three-prime groups, all finite nilpotent groups, sharp escaping maxima, historical priority, and the existing source-comparison gap are outside this acceptance. No Sheet or GitHub mutation is part of the review.
