"""Fresh independent review of the pinned structural dispatcher.
Only this new driver, candidate, and accepted implementation bytes execute.
"""
import ast, hashlib, itertools, json, math, random, subprocess, sys, zipfile
from collections import Counter
from dataclasses import replace
from pathlib import Path
import chirp_dispatch as c
import accepted_frontend_v1 as old
import reference_v1 as ref
BASE=Path(__file__).resolve().parent
CAP=ref.Limits(512,128,64,20_000_000)
COUNTS=Counter(); ROUTES=Counter(); DETAILS={}
PINS={'chirp_dispatch.py':'b6ba169043f522f4d419f54b7b3cc24f439e76e9d9b69d76d977da6dfd1c1aad','accepted_frontend_v1.py':'e9fdd8c89d2e1e8c1569f91cea16159dce690da0793cef78b0d699cac2e200e5','reference_v1.py':'7d263f616526bd1123658771afc73bb44fc15282ef8ee0131e48ade0b59d18b7'}
for name,h in PINS.items(): assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==h
ARCH=BASE/'inputs/CHIRP_Metered_Nondyadic_Dispatch_CANDIDATE_v2_2026-10-11.zip'
assert hashlib.sha256(ARCH.read_bytes()).hexdigest()=='b2e7c257963de2fadafe627dc95fc0a378cdf3d52f7b158c78b32bdc2b789e8d'
with zipfile.ZipFile(ARCH) as z:
 assert z.testzip() is None
 prefix='CHIRP_Metered_Nondyadic_Dispatch_CANDIDATE_v2_2026-10-11/'
 for name,h in PINS.items(): assert hashlib.sha256(z.read(prefix+name)).hexdigest()==h
 for name in ['BENCHMARK_RESULTS.json','TEST_RESULTS.json','REPORT.md']:
  assert z.read(prefix+name)==(BASE/'inputs'/name).read_bytes()
DETAILS['source_pins']=PINS

def primitive(n,p):
 return [w for w in range(1,p) if pow(w,n,p)==1 and all(pow(w,d,p)!=1 for d in range(1,n) if n%d==0)]
def transform(x,w,p):
 return [sum(v*pow(w,j*k,p) for j,v in enumerate(x))%p for k in range(len(x))]
def oracle(P):
 n,p,w,r=P['N'],P['p'],P['omega'],P['r'];x=P['x']
 for a in range(n): # Deliberately all phases, independently of canonical reduction.
  y=[v*pow(w,(-a*j*j)%n,p)%p for j,v in enumerate(x)]
  if sum(v!=0 for v in transform(y,w,p))<=r: return 'MEMBER'
 return 'NONMEMBER'
def witness(P,R):
 if R['status']!='MEMBER':
  assert R['representation'] is None and R['dft'] is None;return
 n,p,w,r=P['N'],P['p'],P['omega'],P['r']; rep=R['representation'];m=rep['modes']
 assert 0<=rep['a']<n//math.gcd(2,n)
 assert len(m)<=r and len({v['b'] for v in m})==len(m)
 assert all(type(v['b']) is int and 0<=v['b']<n and type(v['gamma']) is int and 0<v['gamma']<p for v in m)
 assert [sum(v['gamma']*pow(w,(rep['a']*j*j+v['b']*j)%n,p) for v in m)%p for j in range(n)]==list(P['x'])
 assert R['dft']==transform(P['x'],w,p)
 assert R['validation']=={'raw':True,'prime':True,'exact_order':True}
 assert R['input_sha256']==ref.input_digest(P)
 COUNTS['independent_witness_checks']+=1

def ledger(R):
 L=R['ledger'];assert sum(L['counts'].values())==L['work_units']
 if L['limit'] is not None: assert 0<=L['work_units']<=L['limit']
 if 'frontend' in L:
  F,B=L['frontend'],L['fallback']; assert F['work_units']+B['work_units']==L['work_units']
  assert B['limit']==L['limit']-F['work_units']
  combined=Counter(F['counts']);combined.update(B['counts']);assert dict(combined)==L['counts']
  assert sum(F['stages'].values())==F['work_units']
 elif 'stages' in L: assert sum(L['stages'].values())==L['work_units']
 if R['status']!='MEMBER': assert R['representation'] is None and R['dft'] is None

def semantic(R):
 return {k:v for k,v in R.items() if k not in {'implementation','assurance','route','reference_source_sha256','frontend','ledger'}}
def sansguard(counts): return {k:v for k,v in counts.items() if not k.startswith('dispatch_')}
def differential(P,group):
 R,A,D=c.recognize(P,CAP),old.recognize(P,CAP),ref.recognize(P,CAP)
 assert R['status']==A['status']==D['status']==oracle(P)
 assert R['dft']==A['dft']==D['dft'];witness(P,R);ledger(R)
 target=D if P['N']&(P['N']-1) else A
 assert semantic(R)==semantic(target)
 assert R['ledger']['work_units']==target['ledger']['work_units']+8
 assert sansguard(R['ledger']['counts'])==target['ledger']['counts']
 if P['N']&(P['N']-1):
  assert R['route']=='dense_reference_direct';assert R['frontend']=={'status':'SKIPPED_NON_DYADIC'}
  assert R['ledger']['frontend']['work_units']==8
 else: assert R['frontend']==A['frontend']
 ROUTES[R['route']]+=1;COUNTS[group]+=1;COUNTS['differential_decisions']+=1

for n,p,alphabet in [(2,3,range(3)),(3,7,range(7)),(4,5,range(5)),(5,11,range(2)),(6,7,range(2))]:
 for w in primitive(n,p):
  for x in itertools.product(alphabet,repeat=n):
   for r in range(1,n): differential(dict(N=n,p=p,r=r,omega=w,x=list(x)),'exhaustive_'+str(n))
 print('exhaustive',n,COUNTS['differential_decisions'],flush=True)

rng=random.Random(202610111805)
for n,p in [(8,17),(9,19),(10,31),(12,97),(16,97),(24,97),(32,97)]:
 w=primitive(n,p)[-1]
 for j in range(40):
  r=rng.randrange(1,min(n,8)); x=[rng.randrange(p) for _ in range(n)]
  differential(dict(N=n,p=p,r=r,omega=w,x=x),'random_raw')
  r=rng.randrange(1,min(n,8)); a=rng.randrange(n);bs=rng.sample(range(n),rng.randrange(r+1)); gs=[rng.randrange(1,p) for _ in bs]
  x=[sum(g*pow(w,(a*k*k+b*k)%n,p) for b,g in zip(bs,gs))%p for k in range(n)]
  differential(dict(N=n,p=p,r=r,omega=w,x=x),'random_constructed')
print('differential complete',COUNTS['differential_decisions'],flush=True)

# All prefixes of all eight guard events. Rejected builtin subclasses cannot run hooks.
class EvilInt(int):
 def __and__(self,other): raise AssertionError('subclass arithmetic ran')
 def __lt__(self,other): raise AssertionError('subclass comparison ran')
class EvilDict(dict):
 def __len__(self): raise AssertionError('subclass length ran')
 def __contains__(self,k): raise AssertionError('subclass membership ran')
 def __getitem__(self,k): raise AssertionError('subclass read ran')
base=dict(N=3,p=7,r=1,omega=2,x=[1,1,1])
GUARD=[('nondyadic',base,8,True),('dyadic',{**base,'N':4},8,False),('wrong_type',None,1,False),('dict_subclass',EvilDict(base),1,False),('wrong_len',{},2,False),('missing_N',dict(a=1,b=2,c=3,d=4,e=5),3,False),('bool_N',{**base,'N':True},5,False),('subclass_N',{**base,'N':EvilInt(3)},5,False),('float_N',{**base,'N':3.0},5,False),('small_N',{**base,'N':1},6,False),('negative_N',{**base,'N':-7},6,False),('over_cap_N',{**base,'N':513},7,False),('huge_N',{**base,'N':1<<100000},7,False)]
events=['dispatch_problem_type_checks','dispatch_record_length_reads','dispatch_N_presence_checks','dispatch_N_reads','dispatch_N_type_checks','dispatch_N_lower_bound_checks','dispatch_N_upper_bound_checks','dispatch_dyadic_tests']
for name,P,fee,decision in GUARD:
 for cap in range(fee+1):
  m=c.Meter(cap);m.stage='dispatch'
  try:
   answer=c._known_non_dyadic(P,512,m);assert cap==fee and answer is decision
  except ref.Exhausted as e: assert cap<fee and str(e)=='dispatch: '+events[cap]
  assert m.used==cap and dict(m.counts)==dict.fromkeys(events[:cap],1)
  COUNTS['guard_prefix_cutoffs']+=1
 COUNTS['guard_structural_cases']+=1

# Direct-route isolation: neither frontend copying nor sparse kernels can execute.
saved_append,saved_sparse,saved_reference=c._append,c._sparse_attempt,ref.recognize
calls=[]
def prohibited(*a,**k): raise AssertionError('unused frontend work executed')
def reference_spy(P,L):
 assert P is base;calls.append(L.max_work_units);return saved_reference(P,L)
c._append=c._sparse_attempt=prohibited;ref.recognize=reference_spy
try:
 R=c.recognize(base,CAP);assert R['status']=='MEMBER' and calls==[CAP.max_work_units-8]
finally: c._append,c._sparse_attempt,ref.recognize=saved_append,saved_sparse,saved_reference
COUNTS['direct_route_isolation']+=1

invalid=[None,[],{},dict(base,z=0),{'N':3,'p':7,'r':1,'omega':2,'wrong':[]},dict(base,N=True),dict(base,p=False),dict(base,r=True),dict(base,omega=False),dict(base,N=1),dict(base,r=0),dict(base,r=3),dict(base,p=-1),dict(base,omega=7),dict(base,p=11),dict(base,x=[1,1]),dict(base,x='111'),dict(base,x=[True,1,1]),dict(base,x=[1,-1,1]),dict(base,x=[1,1,7]),dict(base,p=25,omega=2),dict(base,omega=1),dict(base,omega=3),dict(base,N=513),dict(base,p=1<<65),dict(base,N=1<<100000),dict(base,x=(1,1,1)),dict(base,x=[1.0,1,1]),dict(base,N=EvilInt(3)),EvilDict(base)]
for P in invalid:
 R=c.recognize(P,CAP);A=old.recognize(P,CAP);D=ref.recognize(P,CAP)
 assert R['status']==A['status']==D['status'];ledger(R)
 if R['status']=='MEMBER':witness(P,R)
 COUNTS['invalid_or_boundary_api_cases']+=1
for L in [None,{},ref.Limits(-1,1,1,1),ref.Limits(513,1,1,1),ref.Limits(1,129,1,1),ref.Limits(1,1,65,1),ref.Limits(1,1,1,20_000_001),ref.Limits(1,1,1,True),ref.Limits(1.0,1,1,1)]:
 R=c.recognize(base,L);assert R['status']=='INVALID_PARAMETERS' and R['ledger']['work_units']==0;COUNTS['invalid_limit_configurations']+=1

# Every cap on both routes, including failed attempted work and output boundaries.
budgets=[base,dict(base,x=[0,0,0]),dict(base,x=[1,0,0]),dict(base,p=25),dict(base,omega=1),dict(base,omega=3),dict(base,x=[1,1,7]),dict(base,N=4,p=5,omega=2,x=[1,2,4,3]),dict(base,N=4,p=5,omega=2,x=[1,2,1,2]),dict(base,N=4,p=5,omega=2,x=[1,0,0,0]),dict(base,N=4,p=5,omega=2,x=[0,0,0,0]),dict(base,N=4,p=5,omega=2,x=[1,1,1,4])]
DETAILS['budget_cases']=[]
for P in budgets:
 full=c.recognize(P,CAP);total=full['ledger']['work_units'];DETAILS['budget_cases'].append({'problem':P,'status':full['status'],'route':full['route'],'work_units':total})
 for cap in range(total+2):
  L=replace(CAP,max_work_units=cap);R=c.recognize(P,L);ledger(R)
  if cap<8:
   assert R['status']=='LIMIT' and R['ledger']['work_units']==cap and R['ledger']['stage']=='dispatch'
  else:
   target=(ref if P['N']&(P['N']-1) else old).recognize(P,replace(L,max_work_units=cap-8))
   assert semantic(R)==semantic(target),(P,cap,R,target)
   assert R['ledger']['work_units']==target['ledger']['work_units']+8
   assert sansguard(R['ledger']['counts'])==target['ledger']['counts']
   if P['N']&(P['N']-1): assert R['ledger']['fallback']==target['ledger']
   else: assert R['frontend']==target['frontend']
   COUNTS['matched_residual_budget_replays']+=1
  if full['status'] in ('MEMBER','NONMEMBER') and cap<total: assert R['status']=='LIMIT'
  if cap>=total: assert R['status']==full['status']
  COUNTS['every_unit_end_to_end_cutoffs']+=1

# Domain caps before arithmetic work and bounded trial-division behavior.
for name,L in [('dimension',replace(CAP,max_n=2)),('rank',replace(CAP,max_r=0)),('bits',replace(CAP,max_p_bits=2))]:
 R=c.recognize(base,L);assert R['status']=='LIMIT';ledger(R);COUNTS['configured_limit_cases']+=1
large=dict(N=3,p=(1<<61)-1,r=1,omega=2,x=[0,0,0])
R=c.recognize(large,replace(CAP,max_work_units=100));assert R['status']=='LIMIT' and R['validation']['raw'] and not R['validation']['prime'];ledger(R);COUNTS['large_prime_validation_limit']+=1

# A distinct maximum-dimension accepted sparse vector, with final-write withholding.
n,p,r=512,12289,128;w=next(v for v in range(2,p) if pow(v,n,p)==1 and pow(v,n//2,p)!=1)
bs=list(range(0,256,2));gs=[(37*i+11)%(p-1)+1 for i in range(r)]
x=[sum(g*pow(w,b*j,p) for b,g in zip(bs,gs))%p for j in range(n)]
P=dict(N=n,p=p,r=r,omega=w,x=x);R=c.recognize(P,CAP);A=old.recognize(P,CAP)
assert R['route']=='sparse_frontend' and semantic(R)==semantic(A);assert R['ledger']['work_units']==A['ledger']['work_units']+8
witness(P,R);ledger(R);total=R['ledger']['work_units']
for cap in [total-1,total,total+1]:
 S=c.recognize(P,replace(CAP,max_work_units=cap));ledger(S)
 assert S['status']==('LIMIT' if cap<total else 'MEMBER')
 if cap<total:assert S['ledger']['stage']=='sparse.accepted_scatter'
DETAILS['maximum_dimension_case']={'problem':P,'candidate_work':total,'accepted_frontend_work':A['ledger']['work_units'],'one_short_status':'LIMIT','one_short_stage':'sparse.accepted_scatter'}
COUNTS['maximum_dimension_boundaries']+=3

# Ensure the implementation delta leaves all numerical kernels and CLI unchanged.
T1=ast.parse((BASE/'chirp_dispatch.py').read_text());T0=ast.parse((BASE/'accepted_frontend_v1.py').read_text())
D1={x.name:x for x in T1.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))};D0={x.name:x for x in T0.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
for name in ['Meter','_append','_copy','_bm','_pruned_fft','_horner','_sparse_attempt','main']:
 assert ast.dump(D1[name],include_attributes=False)==ast.dump(D0[name],include_attributes=False);COUNTS['unchanged_asts']+=1

cli=[(json.dumps(base).encode(),'MEMBER'),(b'{"N":3,"N":3,"p":7,"r":1,"omega":2,"x":[1,1,1]}','INVALID_INPUT'),(b'{"N":NaN}','INVALID_INPUT'),(b'{}','INVALID_INPUT'),(b'\xff','INVALID_INPUT'),(b'['*5000,'INVALID_INPUT'),(b' '*(1_048_577),'LIMIT'),(b'{"N":3,"p":7,"r":1,"omega":2,"x":[1,1]}','INVALID_INPUT')]
for raw,expected in cli:
 proc=subprocess.run([sys.executable,str(BASE/'chirp_dispatch.py')],input=raw,capture_output=True,check=True)
 R=json.loads(proc.stdout);assert R['status']==expected
 if expected!='MEMBER':assert R['representation'] is None and R['dft'] is None
 COUNTS['fresh_cli_processes']+=1
R={'status':'PASS','author':'independent review driver','counts':dict(COUNTS),'routes':dict(ROUTES),'details':DETAILS,'source_sha256':{name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in [*PINS,'independent_controls.py']}}
(BASE/'INDEPENDENT_TEST_RESULTS.json').write_text(json.dumps(R,indent=2)+'\n')
print(json.dumps({'status':'PASS','counts':dict(COUNTS),'routes':dict(ROUTES)},sort_keys=True),flush=True)
