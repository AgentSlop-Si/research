"""Build the immutable independent review from verified local evidence."""
from pathlib import Path
import hashlib,json,zipfile
B=Path(__file__).resolve().parent
T=json.loads((B/'INDEPENDENT_TEST_RESULTS.json').read_text());Q=json.loads((B/'INDEPENDENT_BENCHMARK_RESULTS.json').read_text());I=json.loads((B/'INPUT_VERIFICATION.json').read_text())
assert T['status']==Q['status']==I['status']=='PASS'
assert T['counts']['differential_decisions']==6843 and T['counts']['every_unit_end_to_end_cutoffs']==1957
assert Q['new_subprocess_samples']==153 and Q['author_samples_audited']==255
assert T['details']['maximum_dimension_case']['candidate_work']==240707
pins={f:hashlib.sha256((B/f).read_bytes()).hexdigest() for f in ['chirp_dispatch.py','accepted_frontend_v1.py','reference_v1.py','independent_controls.py','independent_benchmark.py','build_review_packet.py']}
assert pins['chirp_dispatch.py']==I['candidate_sha256']
(B/'SOURCE_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
V={'verdict':'ACCEPT','date_utc':'2026-10-11','source_repair_required':False,'scope':'Bounded metered structural non-dyadic dispatch; inherited accepted sparse kernels and fully paid accepted dense reference retained unchanged.','source_sha256':pins,'candidate_library_file_id':I['library_file_id'],'candidate_archive_sha256':I['sha256'],'independent_test_counts':T['counts'],'independent_benchmark_samples':153,'author_benchmark_samples_audited':255,'limitations':['Same-cap cutoff thresholds change; compare residual budgets.','Eight guard events are instrumentation, not full machine or bit cost.','Non-dyadic setup work is removed, not free inspection. Actual dyadic attempts and repeated fallback setup remain paid.','Finite shared-machine cold timings can regress; no uniform speedup or optimized FFT baseline.','No common-chirp B/H or min(B,H), polynomial Toeplitz/Gauss-output integration, production or novelty claim.','No Sheet, GitHub, manuscript or prior Library modification.']}
(B/'VERDICT.json').write_text(json.dumps(V,indent=2)+'\n')
rows={'status':'PROPOSAL_ONLY_NOT_APPLIED','date_utc':'2026-10-11','existing_row_ids':['Q13','STR-Q2'],'proposed_evidence':'Independent ACCEPT for pinned CHIRP metered non-dyadic dispatcher b6ba169043f522f4d419f54b7b3cc24f439e76e9d9b69d76d977da6dfd1c1aad. No source repair. Ordinary non-dyadic inputs run one unchanged dense-reference validation/decision/output call plus eight paid guard units; dyadic accepted frontend and all actual attempted fallback work remain intact plus eight units. Fresh independent checks: 6,843 differential decisions, 1,957 every-unit cutoffs, 1,861 matched residual replays, 77 guard prefixes, direct-route isolation and N512/r128 final-write withholding. 153 independent cold samples reproduce all 17 original fixture ledgers/digests; all 255 author samples audited. Timing gains remain mixed and zero/true-fallback regressions remain. No optimized common-chirp min(B,H), optimized FFT comparison or novelty claim.','application_condition':'Do not apply as part of this review. Re-read current row identities and contents; preserve accepted proof and all dated history before separately authorized consolidation.'}
(B/'ROW_PROPOSALS.json').write_text(json.dumps(rows,indent=2)+'\n')
selected=['nondyadic_fallback_N15_r2','nondyadic_zero_N96_r2','nondyadic_phase_zero_N96_r2','nondyadic_phase_zero_N3_r2','sparse_N512_t8','sparse_N512_t128','zero_N512_t8','chirp_fallback_N64_r1','nonmember_fallback_N64_r2']
by={r['name']:r for r in Q['cases']}
table=[]
for name in selected:
 r=by[name];vals=[r['engines'][e] for e in ['candidate','accepted_frontend','reference']]
 table.append('- '+name+': '+ ' / '.join(f"{v['median_api_ms']:.3f}" for v in vals)+' ms; '+ ' / '.join(str(v['work_units']) for v in vals)+' units.')
report='''# CHIRP bounded dispatch independent review

11 October 2026. Verdict: ACCEPT. No source repair required.

## Reviewed target and result

The reviewed source is chirp_dispatch.py SHA256 b6ba169043f522f4d419f54b7b3cc24f439e76e9d9b69d76d977da6dfd1c1aad. Candidate archive SHA256 b2e7c257963de2fadafe627dc95fc0a378cdf3d52f7b158c78b32bdc2b789e8d, 325742 bytes, Library libfile_403bec05b4c881919b7411a36f7029f9 version 0. All 25 candidate payload manifest entries were independently checked; the worker's Library-readback confirmation binds the same archive. This review preserves both source baselines unchanged and includes its own full evidence.

The change is correctly limited to routing structural non-dyadic lengths around inapplicable frontend setup. It does not avoid validation, add a family, change arithmetic kernels, or discount genuinely attempted work. Historical candidate assurance strings remain immutable; this independent verdict supplies acceptance.

## Source and accounting audit

The guard has eight separately paid events. The exact-type/length/key/header/range checks occur in a fixed short-circuit order, and the upper bound precedes the dyadic bit test. No coordinate lookup, raw copy, prime trial or root operation occurs in the guard. Invalid input is not declared valid by the guard: a positive structural result delegates complete checks to the accepted dense reference.

The original fallback merge was factored into one local helper. It takes a snapshot of all paid prefix work, passes cap minus used to the unchanged reference, and sums both count dictionaries and work totals. Direct calls retain only the guard in the frontend subledger; genuine sparse rejections retain the whole attempt and repeated reference setup. Direct-route isolation replaced candidate _append and _sparse_attempt with raising sentinels, wrapped the reference to check object identity and its exact residual cap, and still obtained the correct result.

The Meter class, six numerical/support functions and CLI have identical ASTs to the accepted frontend. The accepted reference is byte-identical. For ordinary completed non-dyadic inputs the total equals dense work plus eight; for ordinary completed dyadic inputs it equals accepted frontend work plus eight. This review does not reinterpret the dense reference's coarser original instrumentation as the sparse frontend's finer write accounting.

Matched residual budgets are essential. Removing old duplicate setup may allow a formerly limited non-dyadic call to finish; the eight new dyadic units may prevent a formerly complete dyadic result. Those changed cutoff locations are expected actual-cost effects, explicitly documented by the candidate. Both paths preserve indeterminate LIMIT and output withholding.

## Independently authored tests

The review driver used a direct dechirped Fourier-support oracle over every phase, deliberately independent of the implementation's canonical phase reduction. Each accepted witness was synthesized against every raw coordinate and its DFT was directly recomputed. Validity, input binding, aggregate ledgers, residual limits, complete statuses, phase records and public decision metadata were checked.

- 6,843 complete differential cases against the independent oracle, old frontend and dense reference. Exhaustive cases: F3^2 at N2 (9), F7^3 at both order-3 roots and all legal r (1,372), F5^4 at both order-4 roots and all legal r (3,750), binary N5 at all four roots/legal r (512), and binary N6 at both roots/legal r (640). Another 280 raw and 280 constructed cases cover N8,9,10,12,16,24,32.
- 2,831 independent complete member representation/DFT checks, including the maximum boundary fixture. Differential routes: 2,844 direct reference, 1,065 sparse acceptance, 2,934 genuine attempted fallback.
- All 77 every-unit guard prefixes across 13 structural controls: non-dyadic/dyadic, wrong type/length/key, bool/float/int subclass, dict subclass, small/negative/over-cap N and a 100001-bit N. Rejected subclasses never execute the injected arithmetic/lookup hooks. The existing API is not claimed to sandbox arbitrary hostile object hooks.
- 1,957 every-unit end-to-end caps across 12 small cases, including member/nonmember, raw/composite/root failures, dyadic zero/sparse success and genuine rejection. Of these, 1,861 occur after the eight paid guard units and match a residual-budget accepted engine result, including every public semantic field and exact non-guard counts. Direct fallback subledgers exactly equal reference ledgers.
- 30 malformed/domain/boundary/tuple API controls, nine invalid resource configurations, three configured cap controls and one large-prime trial-division exhaustion control.
- A separate N512/r128 fixture uses p=12289, 128 even-indexed modes and explicit nonzero weights. Candidate work is 240,707, accepted-frontend work is 240,699. One unit short gives LIMIT at sparse.accepted_scatter and withholds both outputs; exact and one-extra caps complete. Its full input is in INDEPENDENT_TEST_RESULTS.json.
- Eight fresh CLI subprocess checks cover a valid call, duplicate keys, nonfinite JSON, malformed record, invalid bytes, excessive nesting, oversized payload and wrong raw length.
- Eight unchanged AST comparisons cover Meter, all six kernel/support functions and main.

The author's 13,472-case report was read and source-bound, but it is not counted as independently executed review evidence. The new drivers alone were executed against the current candidate and accepted references; no historical candidate test program was run.

## Cold comparison and reproducibility

A separate fresh driver ran three new processes per engine/fixture over the same 17 exact input fixtures, for 153 independent subprocess samples. It rotated engine order and imported all three engines before each API timer. Every timed call includes its complete validation, actual attempted work, full result construction and ledger. A separate process timer includes startup, imports, JSON and teardown. All three use the same full hard caps and supplied-prime/root contract.

All new status/output digests and complete engine ledgers match the original records exactly. The driver also recomputed every reported author median from all 255 original raw samples, checked every repeated ledger/digest and checked the archived source hashes. It did not run the author's benchmark script.

Selected independent API medians below are candidate / accepted frontend / dense reference; units are in the same order.

'''+ '\n'.join(table)+'''

Twelve independent median API times were lower and five higher than the accepted frontend. This happens to match the author's aggregate win/loss count, but not its fixture-level timing pattern. The N3 phase-zero case loses in the independent replay despite fewer counted units; the author's N96 phase-zero loss becomes a gain here. That instability is direct evidence against uniform timing claims. All process-level and per-sample variation remains visible in the attached JSON. Small apparent dyadic wins are not attributed to the guard, which adds work.

The substantial existing sparse-path advantage over this dense reference survives these finite fixtures. Dyadic zero, true chirp fallback and dyadic nonmember fallback still lose against the reference and retain their extra counted work. There is no comparison with an optimized FFT library, no process-memory measurement and no significance test.

## Accepted scope and remaining limitations

REVIEWED_STATEMENT.md is the concise controlling scope. Primality/root checks, exact built-in data contract, positive-sign full DFT, raw verification, Nth-root family, dimension/work/CLI caps and LIMIT semantics remain inherited. Work units are instrumentation, not full bit complexity, processor instructions, wall-clock or memory bounds. Input is resident at Python API entry, and ordinary plumbing and runtime/OS exceptions retain inherited scope.

This accepts one bounded engineering optimization. Common-chirp B/H or min(B,H), polynomial Toeplitz and Gauss-output integration, optimized-library comparisons and production readiness remain open. No theoretical novelty or unrestricted FFT result is claimed. No Sheet, GitHub, manuscript or original Library item was changed; included row proposals require separately authorized reconciliation that preserves earlier history.
'''
(B/'REVIEW_REPORT.md').write_text(report)
name='CHIRP_Metered_Dispatch_Independent_Review_ACCEPT_2026-10-11'
files=[p for p in B.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not any(x in p.parts for x in ['helpers','readback']) and not p.name.startswith('LIBRARY_') and p.name!='PACKAGE_MANIFEST.json' and p.suffix!='.zip']
files.append(B/'inputs/CHIRP_Metered_Nondyadic_Dispatch_CANDIDATE_v2_2026-10-11.zip')
manifest=[{'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
(B/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(B/'PACKAGE_MANIFEST.json')
archive=B/(name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files): z.write(p,name+'/'+str(p.relative_to(B)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:
  data=z.read(name+'/'+row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_payloads':len(manifest)},indent=2))
