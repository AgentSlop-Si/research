"""Fresh independent 3-way cold replay; authors' benchmark code is not executed."""
from pathlib import Path
import hashlib,json,platform,statistics,subprocess,sys,time,zipfile
import chirp_dispatch as candidate
import accepted_frontend_v1 as accepted
import reference_v1 as dense
BASE=Path(__file__).resolve().parent
CAP=dense.Limits(512,128,64,20_000_000)
ENGINES={'candidate':candidate.recognize,'accepted_frontend':accepted.recognize,'reference':dense.recognize}
def digest(R): return hashlib.sha256(json.dumps([R['status'],R['dft']],separators=(',',':')).encode()).hexdigest()
if '--child' in sys.argv:
 Q=json.load(sys.stdin);fn=ENGINES[Q['engine']]
 start=time.perf_counter_ns();R=fn(Q['problem'],CAP);ns=time.perf_counter_ns()-start
 print(json.dumps({'api_ns':ns,'ledger':R['ledger'],'status':R['status'],'route':R.get('route','dense_reference'),'decision_output_sha256':digest(R)}));raise SystemExit
A=json.loads((BASE/'inputs/BENCHMARK_RESULTS.json').read_text())
with zipfile.ZipFile(BASE/'inputs/CHIRP_Metered_Nondyadic_Dispatch_CANDIDATE_v2_2026-10-11.zip') as archive:
 prefix='CHIRP_Metered_Nondyadic_Dispatch_CANDIDATE_v2_2026-10-11/'
 for name,h in A['source_sha256'].items():assert hashlib.sha256(archive.read(prefix+name)).hexdigest()==h
rows=[];author_samples=0;names=list(ENGINES)
for i,row in enumerate(A['cases']):
 P=row['problem'];samples={e:[] for e in names}
 for e in names:
  expected=row['engines'][e]
  assert expected['median_api_ms']==statistics.median(s['api_ns'] for s in expected['samples'])/1e6
  assert expected['median_process_ms']==statistics.median(s['process_ns'] for s in expected['samples'])/1e6
  assert expected['work_units']==expected['samples'][0]['ledger']['work_units']
  for S in expected['samples']:
   assert S['ledger']==expected['samples'][0]['ledger']
   assert S['decision_output_sha256']==row['engines']['reference']['samples'][0]['decision_output_sha256'];author_samples+=1
 for repeat in range(3):
  shift=(i+repeat)%3
  for e in names[shift:]+names[:shift]:
   start=time.perf_counter_ns();proc=subprocess.run([sys.executable,__file__,'--child'],input=json.dumps({'engine':e,'problem':P}),text=True,capture_output=True,check=True);process_ns=time.perf_counter_ns()-start
   S=json.loads(proc.stdout);S['process_ns']=process_ns
   expected=row['engines'][e]['samples'][0]
   assert S['ledger']==expected['ledger'],(row['name'],e,'ledger')
   assert S['decision_output_sha256']==expected['decision_output_sha256']
   samples[e].append(S)
 result={'name':row['name'],'problem':P,'engines':{e:{'samples':samples[e],'median_api_ms':statistics.median(s['api_ns'] for s in samples[e])/1e6,'median_process_ms':statistics.median(s['process_ns'] for s in samples[e])/1e6,'work_units':samples[e][0]['ledger']['work_units']} for e in names}}
 result['accepted_over_candidate_api_ratio']=result['engines']['accepted_frontend']['median_api_ms']/result['engines']['candidate']['median_api_ms']
 result['reference_over_candidate_api_ratio']=result['engines']['reference']['median_api_ms']/result['engines']['candidate']['median_api_ms']
 rows.append(result);print(row['name'],{e:{k:v for k,v in result['engines'][e].items() if k!='samples'} for e in names},flush=True)
R={'status':'PASS','method':'Fresh independent driver; 3 new interpreter processes per engine/fixture, order rotated over engine/fixture index. All three modules imported before API timer. API timer includes complete validation, guard/failed attempts/decision/output/ledger; process timer includes startup/imports/JSON/teardown. Same original fixture bytes and full hard caps. Existing 255 samples and medians audited. No optimized FFT-library baseline. Shared-machine timings, no significance or uniform-speed claim.','author_samples_audited':author_samples,'fixture_count':len(rows),'new_subprocess_samples':len(rows)*9,'python':sys.version,'platform':platform.platform(),'cases':rows,'source_sha256':{n:hashlib.sha256((BASE/n).read_bytes()).hexdigest() for n in ['independent_benchmark.py','chirp_dispatch.py','accepted_frontend_v1.py','reference_v1.py','inputs/BENCHMARK_RESULTS.json']}}
(BASE/'INDEPENDENT_BENCHMARK_RESULTS.json').write_text(json.dumps(R,indent=2)+'\n')
with (BASE/'INDEPENDENT_BENCHMARK_SUMMARY.csv').open('w') as f:
 f.write('fixture,candidate_api_ms,accepted_api_ms,dense_api_ms,candidate_units,accepted_units,dense_units\n')
 for row in rows:f.write(','.join([row['name']]+[str(row['engines'][e]['median_api_ms']) for e in names]+[str(row['engines'][e]['work_units']) for e in names])+'\n')
print('PASS',R['new_subprocess_samples'],'new samples;',author_samples,'author samples audited',flush=True)
