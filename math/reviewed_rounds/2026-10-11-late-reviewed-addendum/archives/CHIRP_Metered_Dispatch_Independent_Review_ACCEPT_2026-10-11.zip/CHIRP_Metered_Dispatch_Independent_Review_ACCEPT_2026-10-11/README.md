# CHIRP metered dispatch independent review

Independent verdict: ACCEPT for the pinned bounded non-dyadic dispatch improvement, without source repair. Read REVIEWED_STATEMENT.md for the precise accepted contract and REVIEW_REPORT.md for the audit and cold observations.

The review preserves the immutable candidate archive and accepted source bytes. Only freshly authored independent drivers and the current candidate/accepted implementation modules were executed. The author's archived test and benchmark scripts were inspected as evidence, not executed.

Python 3.10 or later, standard library only:

    python independent_controls.py
    python independent_benchmark.py

Both scripts verify the pinned candidate/archive or sample provenance before trusting evidence. They write reproducible machine-readable results beside the scripts; timing values naturally vary. The archive's manifest records the exact reviewed run, and a new run should be kept separately if preserving those bytes.

- REVIEWED_STATEMENT.md: exact acceptance scope and limitations
- REVIEW_REPORT.md: independent checks and selected timing observations
- VERDICT.json: machine-readable verdict and source hashes
- INDEPENDENT_TEST_RESULTS.json and run log: fresh controls and complete maximum-boundary fixture
- INDEPENDENT_BENCHMARK_RESULTS.json, summary CSV and run log: 153 fresh samples over all 17 original fixtures
- INPUT_VERIFICATION.json: immutable candidate binding and 25 verified archive payloads
- SOURCE_PINS.json and PACKAGE_MANIFEST.json: review source and payload integrity
- ROW_PROPOSALS.json: proposal-only evidence for the existing Q13 and STR-Q2 rows
- inputs/: unchanged candidate packet and reviewed author evidence

The historical assurance labels in the implementation files remain unchanged. This review accepts only the metered dispatch optimization within the inherited bounded contract. No optimized FFT baseline or novelty claim is made, and no Sheet or GitHub mutation was performed.
