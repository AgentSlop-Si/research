# CHIRP: metered non-dyadic dispatch before unused setup

11 October 2026. Status: CANDIDATE, same-author controls pass; separate independent review required before promotion.

## Result and exact scope

One bounded dispatcher improvement removes the accepted frontend's duplicate validation/setup on structurally inapplicable non-dyadic inputs. It does not change the sparse algorithm, skip mathematical validation, recognize an additional family, optimize a real rejected attempt, or implement common-chirp B/H or min(B,H).

Candidate chirp_dispatch.py SHA256:
b6ba169043f522f4d419f54b7b3cc24f439e76e9d9b69d76d977da6dfd1c1aad

The unchanged accepted frontend is preserved as accepted_frontend_v1.py, SHA256 e9fdd8c89d2e1e8c1569f91cea16159dce690da0793cef78b0d699cac2e200e5. Its independent acceptance packet, Library libfile_f909fa94fc948191b7f9447c5218a045, is included unchanged and hashes to 33fc3ccd184a9c7e6b064b80cc07b96379172a81aa3afdc393e397bbfc2e0ea0. The accepted dense reference remains SHA256 7d263f616526bd1123658771afc73bb44fc15282ef8ee0131e48ade0b59d18b7. Historical candidate assurance strings in accepted source bytes remain unchanged.

## The one change

Before the accepted frontend's header/raw/prime/root setup, a new metered guard checks an exact built-in dict, its length, presence and value of N, exact integer type, N>=2, N<=the configured dimension cap, and the exact bit test N & (N-1). It inspects no signal coordinate. A true result means only that the sparse radix-two path is structurally inapplicable; it never means that the problem is valid.

A true guard immediately calls the unchanged accepted dense reference with the original global budget minus the guard's eight paid operations. The reference then performs its complete original validation and decision/output work. Every MEMBER still requires canonical raw integers, certified primality, N dividing p-1, and a supplied root of exact order N. Zero still reaches an accepted zero decision only after all those checks and input binding.

A false guard continues through the byte-equivalent original frontend body. The ordinary dyadic sparse attempt, BM, two support-pruned transforms, partial-fraction weights, full-raw comparison and DFT scatter are unchanged. All six kernel function ASTs and the CLI AST match the old source exactly. A genuinely failed dyadic attempt still calls the unchanged reference after paying the attempted work, and still repeats the reference's validation/setup. The old late non-dyadic check remains a defensive compatibility path; ordinary valid non-dyadic records take the early route.

The preexisting fallback code was extracted into a local helper and reused for the early route. The only route-label addition is dense_reference_direct; rejected dyadic calls retain dense_reference_fallback. The nested ledger retains the existing frontend/fallback keys, with the direct route's frontend ledger containing only its paid guard work.

## Contract and budget semantics

The input has exactly N,p,r,omega,x. Headers and raw entries must be exact built-in integers, not booleans or subclasses; x is an exact built-in list or tuple of length N. The mathematical family, canonical phase enumeration, positive-sign unnormalized full DFT, dimension/modulus/work hard caps and 1 MiB CLI cap are unchanged. N=1, r>=N and the order-2N-root curvature extension remain unsupported.

MEMBER returns a complete representation and all N DFT entries. NONMEMBER requires every canonical phase to reject in the accepted reference. INVALID_INPUT and INVALID_PARAMETERS report only completed invalidity checks. LIMIT remains indeterminate and withholds both representation and DFT, even when only the final output write is missing. Limited validation may stop before invalidity is discovered.

The guard pays immediately before each introduced type check, dictionary-length read, key-presence check, N read, range check and dyadic test. On an ordinary five-field exact-int record within the configured N range these are eight separately recorded units. Short-circuit paths pay only their executed prefix. The upper bound is tested before the bit operation; a huge N does not cause a huge-width dyadic operation in the new guard. The supplied configured bound and ordinary local/call plumbing retain the inherited instrumentation's Python-overhead scope.

For completed well-formed non-dyadic cases:

    candidate work = unchanged reference work + 8

For completed well-formed dyadic cases:

    candidate work = accepted frontend work + 8

The aggregate ledger is exactly the paid frontend/guard counts plus the actual unchanged-reference counts. The fallback receives only the remaining budget. The previous duplicate non-dyadic frontend work is absent because it is genuinely not executed. The direct-route isolation test makes both frontend _append and _sparse_attempt fail if called, and still succeeds.

Same-cap decisions can differ at resource boundaries: removing duplicate work can turn a previous LIMIT into a completed non-dyadic answer; the eight new guard units can turn a previous completed dyadic answer into LIMIT. This is an explicit actual-cost change, not a claim of identical cutoff thresholds. Matched-remaining-budget replays compare all semantic result fields and exact reference ledgers.

These units remain implementation instrumentation, not processor instructions, a wall-clock guarantee, full bit complexity or a process-memory cap. The inherited reference's coarser accounting is preserved without relabeling it as the frontend's finer write accounting. Input objects are already resident at Python API entry. Runtime/OS exceptions are not promised to become decision statuses.

## Fresh tests

TEST_RESULTS.json and TEST_RUN.log record the final passing run. The test author independently formulated a direct dechirped-Fourier-support oracle, but this is still same-author candidate testing, not an independent review.

- 13,472 differential decisions against the mathematical oracle, the accepted frontend and the accepted dense reference
- 9,174 exhaustive non-dyadic decisions: all F7^3 inputs at both primitive roots and all legal r; binary N=5 and ternary N=6 at all primitive roots and legal r
- 3,667 exhaustive dyadic decisions, 630 randomized raw/constructed cases, and a late-impulse adversary
- 631 certificate-checker calls within the differential suite, plus the maximum-dimension certificate
- 11 exact guard-cost controls and 53 every-unit guard cutoffs, including hostile builtin subclasses and enormous N
- 2,280 every-unit end-to-end budget cutoffs covering member/nonmember, raw/prime/root failure, both routing types and late output withholding
- Matched-residual-budget replay against the original reference or accepted frontend, checking status, reason, output, hash, validation, phase records and related decision metadata
- 25 invalid-input/domain controls, eight invalid limit configurations, three dimension-cap controls, tuple input, a large-prime validation LIMIT and eight CLI controls
- N=512/r=128 sparse boundary: original 248,073 units, candidate 248,081 units; one unit short withholds both outputs at sparse.accepted_scatter
- Seven unchanged function AST checks, plus original accepted source/reference byte bindings

The maximum-boundary numbers above are from the independently constructed test fixture, not the benchmark's distinct N512/t128 fixture. Exact fixture inputs and observed ledgers are retained in the results; the values are checked again by the packet build.

## Cold same-contract comparison

BENCHMARK_RESULTS.json contains all 255 new subprocess samples: five samples per engine over 17 fixtures. The engines are this candidate, the accepted frontend and the unchanged dense reference. The same caps and full prime/root/raw validation and complete output contract apply to all. Engines are rotated between samples; every timed call runs in a fresh interpreter. All three modules are imported before the API timer. The separate whole-process timer includes startup, imports, JSON and teardown.

Nine fixtures are the original acceptance-era benchmark inputs; eight are fresh explicit non-dyadic controls at N=3 and N=96. Every sample reproduces its engine's full ledger, and every engine has the same exact decision/output digest for each fixture. No optimized FFT-library baseline was run. Shared-machine timing variation remains visible.

Selected median API times, in milliseconds (candidate / accepted frontend / dense reference):

- Non-dyadic N15/r2: 0.397 / 0.441 / 0.383; units 1,144 / 1,291 / 1,136
- Non-dyadic zero N96/r2: 0.264 / 0.410 / 0.154; units 918 / 1,628 / 910
- Non-dyadic impulse N96/r2: 1.488 / 1.726 / 1.354; units 6,006 / 6,716 / 5,998
- Non-dyadic phase-zero N96/r2: 5.379 / 5.281 / 5.165; units 21,676 / 22,519 / 21,668. This observed timing loses to the old frontend despite the guaranteed removal of counted duplicate work.
- Dyadic sparse N512/t8: 7.522 / 7.482 / 151.238; units 28,623 / 28,615 / 562,749. The existing sparse advantage survives, with guard overhead.
- Dyadic sparse N512/t128: 88.962 / 85.023 / 2,198.444; units 248,175 / 248,167 / 8,102,671
- Dyadic zero N512/t8: 1.866 / 2.010 / 0.614; units 8,364 / 8,356 / 4,694. The zero regression versus the dense reference remains.
- Rejected dyadic chirp N64/r1: 3.113 / 3.136 / 2.480; units 11,883 / 11,875 / 9,981. Real attempted work and duplicate validation remain fully paid.
- Dyadic nonmember fallback N64/r2: 1.338 / 1.217 / 1.042; units 4,702 / 4,694 / 4,112

Across all 17 fixtures the candidate has 12 lower and five higher observed median API times than the old frontend. Those finite timings do not prove uniform speedup, and small apparent dyadic gains are not algorithmic claims. The deterministic claim is narrower: ordinary non-dyadic input executes one validation/decision call plus the guard; ordinary dyadic input adds eight guard units and changes no mathematical kernels. Whole-process results, including cases whose process timing loses despite API improvement, are preserved rather than omitted.

## Promotion and next scope

This packet stops at the correct bounded candidate, source pins, fresh tests, cold observations and proposal-only existing-row updates. It must receive a separate independent review before acceptance. No Sheet or GitHub changes, no new row IDs, no manuscript changes and no replacement of earlier Library deliverables were made.

The accepted proof, original dense-reference acceptance and original sparse-frontend acceptance remain intact. Dyadic-zero improvement is a possible later task. Optimized common-chirp B/H selection, min(B,H), polynomial Toeplitz/Gauss-output integration, broad optimized-library comparisons and production readiness remain open. No new theoretical novelty or unrestricted FFT claim is made.
