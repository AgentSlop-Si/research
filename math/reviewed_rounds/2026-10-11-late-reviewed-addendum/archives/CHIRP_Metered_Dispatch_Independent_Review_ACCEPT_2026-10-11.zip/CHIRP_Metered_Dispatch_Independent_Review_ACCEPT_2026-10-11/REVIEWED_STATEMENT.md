# Reviewed bounded CHIRP dispatch contract

11 October 2026. Independent verdict: ACCEPT for the metered non-dyadic dispatch change. No source repair is required. This verdict is specific to chirp_dispatch.py SHA256 b6ba169043f522f4d419f54b7b3cc24f439e76e9d9b69d76d977da6dfd1c1aad, accepted_frontend_v1.py SHA256 e9fdd8c89d2e1e8c1569f91cea16159dce690da0793cef78b0d699cac2e200e5, and reference_v1.py SHA256 7d263f616526bd1123658771afc73bb44fc15282ef8ee0131e48ade0b59d18b7. Source assurance strings remain historical and unchanged; this external review supplies the acceptance record.

## Accepted change

An eight-event structural guard precedes the accepted frontend. It checks the input's exact dict type, record length, N-key presence, N value, exact int type, lower bound, configured upper bound, and non-dyadic bit test. Each executed event is paid before it runs. Short-circuits pay only the executed prefix; no signal coordinate is inspected by this guard. Bounding N precedes the bit test.

A structurally eligible non-dyadic length calls the byte-unchanged accepted dense reference directly with the remaining global work budget. The guard grants no validity, primality, root-order or signal decision. The reference performs all of its original checks and complete decision/output work. There is no unused frontend raw copy, prime trial, root preparation or sparse attempt on that route.

A dyadic input follows the unchanged accepted sparse frontend body, including actual Berlekamp-Massey, two support-pruned transforms, all-coordinate synthesis verification and complete positive-sign DFT scatter. A genuinely rejected attempt still pays all preceding work, then calls the unchanged dense reference with the remaining budget and pays its repeated setup. No new recognized family or mathematical kernel is introduced.

For a completed well-formed non-dyadic record, candidate instrumented work equals original dense-reference work plus eight. For a completed well-formed dyadic record, candidate work equals accepted frontend work plus eight. Aggregate counts equal the paid prefix plus the actual reference counts, and the reference budget is exactly the original cap minus the paid prefix. These are instrumentation identities, not equal-cost machine operations.

## Decisions and limits

The accepted domain, root family, representation, positive-sign unnormalized full DFT and hard caps are unchanged. An exact dict with N,p,r,omega,x, exact integer headers and canonical integer coordinates, and an exact list or tuple is required. Require N>=2, 1<=r<N, a supplied prime p, N dividing p-1, and a supplied omega of exact order N. Primality is checked by bounded trial division. N=1, r>=N and the order-2N-root curvature extension remain outside this API.

MEMBER supplies a complete representation agreeing with every raw coordinate and all N DFT entries. NONMEMBER follows rejection of every canonical phase in the accepted dense reference. LIMIT is indeterminate and withholds representation and DFT, even if only the final output write remains. INVALID_INPUT and INVALID_PARAMETERS describe completed invalidity checks; a small budget can stop before invalidity is discovered.

Default caps remain N=128, r=64, bitlen(p)=32 and 2,000,000 units; hard caps remain N=512, r=128, bitlen(p)=64 and 20,000,000 units. The JSON CLI retains its 1 MiB byte cap and finite-JSON/duplicate-key checks. Same-cap status need not match the prior frontend at a resource boundary: avoided non-dyadic work can turn LIMIT into a decision, while eight extra dyadic units can turn a decision into LIMIT. Matched-residual-budget behavior is the accepted equivalence claim.

## Independent evidence and exact limitations

Fresh independent drivers passed 6,843 mathematical/reference differentials, 2,831 independent member witness/DFT checks, 1,957 every-unit end-to-end cutoffs, 1,861 matched-residual-budget replays, 77 guard-prefix cutoffs, direct-route isolation, malformed/limit/CLI controls and a distinct N=512/r=128 final-write boundary. Eight kernel/class/CLI AST comparisons are unchanged. An additional 153 cold subprocess samples across 17 fixtures reproduce all original ledgers and decision/output digests; all 255 author samples and reported medians were also audited.

The new change removes counted unused non-dyadic setup. It does not promise uniform timing improvement. A small non-dyadic fixture lost in the independent timing replay despite fewer units; dyadic zero and actual rejected attempts still regress against the dense reference. The units are not processor instructions, full bit complexity, process-memory limits or wall-clock bounds. Already-resident Python input, ordinary plumbing and runtime/OS exceptions retain the inherited reference scope; this is not a sandbox for hostile Python object hooks.

Only this bounded engineering change is accepted. No optimized FFT-library comparison, common-chirp B/H or min(B,H) implementation, polynomial Toeplitz/Gauss integration, production readiness, theoretical novelty or unrestricted FFT result is claimed. Earlier accepted proof and implementation milestones are preserved. No Sheet, GitHub, manuscript or earlier Library deliverable was changed.
