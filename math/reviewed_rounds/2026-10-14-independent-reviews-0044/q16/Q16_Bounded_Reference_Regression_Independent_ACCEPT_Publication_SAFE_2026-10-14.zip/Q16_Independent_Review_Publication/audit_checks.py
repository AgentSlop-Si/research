"""New independent reviewer controls. Imports only the copied new regression.

Historical files are hashed/read as inert bytes, never imported or executed.
No transcendental floating-point calls; exact integer/Fraction comparisons only.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import ast
import hashlib
import importlib.util
import json
import math
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
started = time.monotonic()
counts = Counter()
exact_expected_errors = []

def check(condition, category):
    counts[category] += 1
    assert condition, category

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

input_pins = []
for name in ('bounded_reference_regression', 'outer_contract_static_acceptance'):
    base = ROOT/name
    manifest = json.loads((base/'MANIFEST.json').read_text())
    seal = json.loads((base/'SEAL.json').read_text())
    check(digest(base/'MANIFEST.json') == seal['manifest_sha256'], 'manifest_seal')
    for row in manifest['files']:
        path = base/row['path']
        check(path.stat().st_size == row['bytes'], 'payload_size')
        check(digest(path) == row['sha256'], 'payload_hash')
        input_pins.append(dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=digest(path)))

for row in json.loads((ROOT/'outer_contract_static_acceptance/INPUT_PINS.json').read_text())['reviewed_archive_and_directory_integrity']:
    path = ROOT/row['path']
    check(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'static_input_pin')

original = ROOT/'bounded_reference_regression/regression.py'
copy = OUT/'rerun/regression.py'
check(original.read_bytes() == copy.read_bytes(), 'rerun_source_identity')
check((ROOT/'bounded_reference_regression/RESULTS.json').read_bytes() == (OUT/'rerun/RESULTS.json').read_bytes(), 'rerun_exact_results_identity')
tree = ast.parse(copy.read_text())
oracle_ast = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Oracle')
check(not any(isinstance(n, ast.Name) and n.id == 'Reference' for n in ast.walk(oracle_ast)), 'oracle_no_reference_calls')
check(not any(isinstance(n, ast.Name) and n.id in {'eval', 'exec', '__import__'} for n in ast.walk(tree)), 'no_dynamic_evaluation')
spec = importlib.util.spec_from_file_location('new_regression_review_copy', copy)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
R, O, Paid = module.Reference, module.Oracle, module.Paid

result = json.loads((OUT/'rerun/RESULTS.json').read_text())
N, M, D = (1 << 55)-1, 1 << 57, 5
support = (0, 1710, (1 << 55)+1, M-1)
ref = R(N, M, D, support, bytes(range(32)))
check((ref.m, ref.s, ref.J, ref.K, ref.p, ref.A) == (57, 285, 587, 623, 459, 456), 'metadata')

# Enumeration checked independently by solving the row inequality for each j.
# This avoids relying on the same lifted-interval implementation for the expected set.
expected = set()
for k in support:
    for j in range(-ref.h, ref.h+2):
        c = (k-j) % M
        lo = -((-c*N)//M)
        hi = -((-(c+1)*N)//M)
        for ell in range(lo, hi):
            check(0 <= ell < N and ell*M//N == c, 'row_first_center')
            expected.add((ell, k))
emitted = [(ell, k) for label, k, ell in ref.incidences()]
check(len(emitted) == len(set(emitted)) == 9123, 'enumeration_unique_count')
check(set(emitted) == expected, 'enumeration_exact_set')
check(ref.L.setup_count == 0, 'no_setup_during_enumeration')
check((1 << 53)*M - ((1 << 55)+1)*N == 1, 'minimum_residue_identity')

# Preparation is paid once, never reset or repeated by a second prepare call.
before_prepare = ref.L.report()
ref.prepare()
after_prepare = ref.L.report()
check(after_prepare['scalar_setup_count'] == 1 and after_prepare['arithmetic_bit_work_upper'] > before_prepare['arithmetic_bit_work_upper'], 'paid_prepare')
ref.prepare()
check(ref.L.report() == after_prepare, 'idempotent_prepare')
oracle = O(900)
for engine, bits, root in [(ref, ref.K, ref.root), (oracle, oracle.B, oracle.sqrt)]:
    z = M*(1 << (2*bits))//N
    check(root == (math.isqrt(z), math.isqrt(z)+1), 'sqrt_independent_isqrt')
    check(root[0]**2*N <= M*(1 << (2*bits)) < root[1]**2*N, 'sqrt_exact_rational_enclosure')

empty = R(N, M, D, (), bytes(32))
check(list(empty.incidences()) == [] and empty.L.setup_count == 0, 'empty_no_scalar_setup')
check(empty.L.report()['total_bit_work_upper'] > 0 and empty.L.counts['sine_call'] == 0, 'empty_positive_header_zero_sine')
dense = R(1, 4, D, (), bytes(32))
check(dense.dense and not dense.ready and list(dense.incidences()) == [] and dense.L.setup_count == 0, 'dense_guard_no_scalar_setup')

# Separate exact algebraic sine values across multiple positive/negative periods.
# For reduced rational f in [0,1/2], sin(pi*f)^2 is 0, 1/4, 1/2, 3/4 or 1.
algebraic = {F(0):F(0), F(1,6):F(1,4), F(1,4):F(1,2), F(1,3):F(3,4), F(1,2):F(1)}
for den in (2, 3, 4, 6):
    for num in range(-3*den, 3*den+1):
        f = F(num, den) % 2
        sign = -1 if f > 1 else 1
        if f > 1: f = 2-f
        if f > F(1,2): f = 1-f
        sq = algebraic[f]
        for name, bits, sine in [('reference', ref.K, ref.sin), ('oracle', oracle.B, oracle.sine)]:
            lo, hi = sine(num, den)
            if sign < 0: lo, hi = -hi, -lo
            if sq == 0:
                check(lo <= 0 <= hi, name+'_algebraic_sine')
            else:
                check(0 <= lo <= hi and F(lo*lo, 1 << (2*bits)) <= sq <= F(hi*hi, 1 << (2*bits)), name+'_algebraic_sine')

denominator_evidence = []
for name, bits, sine in [('reference', ref.K, ref.sin), ('oracle', oracle.B, oracle.sine)]:
    lo, hi = sine(1, N*M)
    check(0 < lo <= hi, 'minimum_residue_positive_denominator')
    denominator_evidence.append(dict(engine=name,bits=bits,numerator=1,denominator=N*M,enclosure=[lo,hi]))

# Exhaustive modest grids use Python integer pow, distinct from Paid.power.
for K in range(1, 6):
    U = 1 << K
    obj = R.__new__(R)
    obj.L = Paid('independent_power_controls')
    obj.K, obj.U = K, U
    points = sorted(set((-U, -U+1, -U//2, -1, 0, 1, U//2, U-1, U)))
    for a in points:
        for b in points:
            if a > b: continue
            for s in (1, 2, 3, 4, 7, 8, 17, 285):
                low = min(a**s,b**s)
                high = max(a**s,b**s)
                if s%2 == 0 and a <= 0 <= b: low = 0
                div = U**(s-1)
                expected_pair = (low//div, -((-high)//div))
                check(obj.signed_power((a,b),s) == expected_pair, 'exact_signed_power')
check(ref.signed_power((-(1 << 622), -(1 << 621)), 285) == (-(1 << 338), -(1 << 53)), 'large_odd_sentinel')

for rec, enc, prior in zip(result['reference_outputs'], result['oracle_outputs'], result['exact_comparisons']):
    check((rec['ell'], rec['k']) == (enc['ell'], enc['k']) == (prior['ell'],prior['k']), 'record_identity')
    check((rec['ell'],rec['k']) in expected, 'selected_record_membership')
    ref_radii, oracle_radii = [], []
    for key, pointkey in [('real_interval','real_integer'),('imag_interval','imag_integer')]:
        a,b = (F(v,1 << rec['bits']) for v in rec[key])
        c,d = (F(v,1 << enc['bits']) for v in enc[key])
        z = F(rec[pointkey],1 << rec['p'])
        check(a <= c <= d <= b, 'oracle_exact_nesting')
        check(rec[pointkey] == round((a+b)*(1 << rec['p'])/2), 'independent_nearest_even')
        ref_radii.append(max(abs(z-a),abs(z-b)))
        oracle_radii.append(max(abs(z-c),abs(z-d)))
    cert = sum(x*x for x in ref_radii)
    err = sum(x*x for x in oracle_radii)
    check(cert == F(rec['certificate_radius_squared'],1 << (2*rec['bits'])), 'certificate_exact_recompute')
    check(cert <= F(1, 1 << 912), 'certificate_eta_squared')
    check(err == F(prior['exact_error_squared_upper_numerator'],1 << prior['exact_error_squared_upper_denominator_exponent']), 'oracle_error_exact_recompute')
    p2 = prior['absolute_error_upper_power_two_exponent']
    check(err <= F(1,1 << (-2*p2)), 'advertised_power_two_error_bound')
    exact_expected_errors.append(dict(ell=rec['ell'],k=rec['k'],squared_error_upper_numerator=prior['exact_error_squared_upper_numerator'],squared_error_upper_denominator_exponent=1800,absolute_error_upper_power_two_exponent=p2))

check(result['reference_outputs'][1]['normalized_ratio_interval'][1] < 0, 'negative_ratio_interval')
check(result['oracle_outputs'][1]['real_interval'][0] > 0, 'negative_ratio_positive_coefficient')
check(result['reference_outputs'][1]['real_integer'] == result['reference_outputs'][1]['imag_integer'] == 0, 'tiny_witness_rounds_to_zero')
check(result['reference_paid_ledger']['scalar_setup_count'] == result['oracle_paid_ledger']['scalar_setup_count'] == 1, 'original_setup_counts')
check(result['reference_paid_ledger']['operations']['sine_call'] == result['oracle_paid_ledger']['operations']['oracle_sine_call'] == 12, 'original_sine_counts')
for key in ('reference_paid_ledger', 'oracle_paid_ledger', 'exact_comparison_paid_ledger', 'empty_support_paid_ledger'):
    ledger = result[key]
    events = sum(ledger['operations'].values())+256
    width = ledger['max_integer_bits']+events.bit_length()+16
    check(ledger['control_bookkeeping_bit_work_upper'] == 4096*events*width*width, 'ledger_envelope_recompute')
    check(ledger['total_bit_work_upper'] == ledger['arithmetic_bit_work_upper']+ledger['control_bookkeeping_bit_work_upper'], 'ledger_total_recompute')
    check(ledger['cumulative_storage_upper_bits'] == ledger['cumulative_produced_integer_bits']+4096*events*width, 'ledger_storage_recompute')

bad_headers = [
    (True,M,D,support,bytes(32),'exact int required'),
    (N,M,D-1,support,bytes(32),'domain'),
    (N,M+1,D,support,bytes(32),'M header'),
    (N,M,D,list(support),bytes(32),'tuple/binding'),
    (N,M,D,support,bytes(31),'tuple/binding'),
    (N,M,D,(False,),bytes(32),'support type'),
    (N,M,D,(1,0),bytes(32),'support order/range'),
    (N,M,D,(-1,),bytes(32),'support order/range'),
    (N,M,D,(M,),bytes(32),'support order/range'),
    (N,M,D,(0,0),bytes(32),'support order/range'),
]
for *args, message in bad_headers:
    try:
        R(*args)
    except ValueError as e:
        check(str(e) == message, 'exact_malformed_header_error')
        exact_expected_errors.append(dict(control='malformed_header',expected_error=str(e)))
    else:
        raise AssertionError('malformed header accepted')

report = dict(verdict='PASS_INDEPENDENT_BOUNDED_CONTROLS',assertions=sum(counts.values()),categories=dict(sorted(counts.items())),
    input_pins=input_pins,source_sha256=digest(copy),result_sha256=digest(OUT/'rerun/RESULTS.json'),
    exact_results=exact_expected_errors,denominator_evidence=denominator_evidence,
    scalar_control_sine_calls=dict(reference=ref.L.counts['sine_call'],oracle=oracle.L.counts['oracle_sine_call']),
    elapsed_monotonic_seconds=time.monotonic()-started,historical_code_executed=False,
    original_files_modified=False,external_writes=False,model_token_counters=None,
    scope='Independent source/proof audit and finite exact controls for the new three-record reference regression. No production wrapper or general FFT claim.')
(OUT/'INDEPENDENT_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(verdict=report['verdict'],assertions=report['assertions'],categories=report['categories'],elapsed_monotonic_seconds=report['elapsed_monotonic_seconds']),indent=2))
