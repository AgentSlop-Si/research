"""New same-agent implementation-diverse Q16 reference/oracle regression.
No imports of historical code. Fixed finite three-record experiment only.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json

HERE=Path(__file__).resolve().parent
class Paid:
    """Conservative binary-operation ledger, not CPU/RSS accounting."""
    def __init__(self,name):
        self.name=name; self.counts=Counter(); self.work=0; self.bits=0; self.maxbits=1
        self.input_bits=0; self.setup_count=0
    def rec(self,kind,args,out):
        widths=[max(1,abs(x).bit_length()) for x in (*args,out)]
        self.counts[kind]+=1; self.maxbits=max(self.maxbits,*widths)
        self.bits+=widths[-1]; self.work+=16*(sum(widths)+2)**2
        return out
    def read(self,x):
        self.input_bits+=max(1,abs(x).bit_length()); return self.rec('read',(),x)
    def event(self,kind): self.counts[kind]+=1
    def add(self,a,b): return self.rec('add',(a,b),a+b)
    def sub(self,a,b): return self.rec('sub',(a,b),a-b)
    def mul(self,a,b): return self.rec('mul',(a,b),a*b)
    def div(self,a,b):
        assert b>0
        return self.rec('floor_div',(a,b),a//b)
    def cd(self,a,b): return self.sub(0,self.div(self.sub(0,a),b))
    def mod(self,a,b): return self.rec('mod',(a,b),a%b)
    def shift(self,n):
        assert n>=0
        return self.rec('shift',(n,),1<<n)
    def bl(self,n): return self.rec('bit_length',(n,),n.bit_length())
    def power(self,a,n):
        out=1
        while n:
            self.event('power_loop')
            if n&1: out=self.mul(out,a)
            n=self.div(n,2)
            if n: a=self.mul(a,a)
        return out
    def report(self):
        ev=sum(self.counts.values())+256
        W=self.maxbits+ev.bit_length()+16
        controls=4096*ev*W*W
        return dict(name=self.name,operations=dict(sorted(self.counts.items())),
            arithmetic_bit_work_upper=self.work,control_bookkeeping_bit_work_upper=controls,
            total_bit_work_upper=self.work+controls,max_integer_bits=self.maxbits,
            cumulative_produced_integer_bits=self.bits,
            cumulative_storage_upper_bits=self.bits+4096*ev*W,
            parameter_input_bits=self.input_bits,scalar_setup_count=self.setup_count,
            model='16*(sum operand/result widths+2)^2 per binary arithmetic operation; 4096*(events+256)*(max width+bit_length(events)+16)^2 control/bookkeeping envelope; fixed constants, no CPU/RSS claim')

class Reference:
    def __init__(self,N,M,D,support,binding):
        self.L=Paid('new_contract_reference'); L=self.L
        if type(N) is not int or type(M) is not int or type(D) is not int: raise ValueError('exact int required')
        N=L.read(N); M=L.read(M); D=L.read(D)
        if N<1 or D<5: raise ValueError('domain')
        m=L.bl(L.sub(L.mul(4,N),1))
        if M!=L.shift(m): raise ValueError('M header')
        if type(support) is not tuple or type(binding) is not bytes or len(binding)!=32: raise ValueError('tuple/binding')
        L.input_bits+=256; L.event('fixed_256_bit_binding_copy')
        prev=-1
        for k in support:
            L.event('support_validation')
            if type(k) is not int: raise ValueError('support type')
            L.read(k)
            if not prev<k<M: raise ValueError('support order/range')
            prev=k
        self.N=N; self.M=M; self.m=m; self.D=D; self.support=tuple(support); self.binding=bytes(binding)
        self.s=L.mul(D,m); self.h=L.add(L.mul(16,self.s),1); self.t=L.add(L.mul(2,self.h),2)
        self.dense=self.t>=M; self.ready=False
        if self.dense: return
        self.A=L.mul(L.add(D,3),m); self.p=L.add(self.A,3)
        self.J=L.add(L.add(L.mul(L.add(D,5),m),L.bl(self.s)),8)
        self.K=L.add(L.add(self.J,L.mul(2,L.bl(L.add(self.J,1)))),16)
        self.U=L.shift(self.K); self.n=L.add(self.K,8)
        self.a0=L.div(L.sub(N,1),2); self.lk=L.div(M,4); self.q=L.div(M,L.mul(8,self.s)); self.Q=L.mul(N,M)
    def incidences(self):
        if self.dense: return
        L=self.L
        for k in self.support:
            lo=L.cd(L.mul(self.N,L.sub(L.sub(k,self.h),1)),self.M)
            hi=L.cd(L.mul(self.N,L.add(L.add(k,self.h),1)),self.M)
            for r in range(lo,hi):
                L.event('emitted_incidence'); ell=L.mod(r,self.N)
                yield self.binding,k,ell
    def prepare(self):
        if self.ready: return
        L=self.L; L.setup_count+=1; L.event('scalar_setup')
        def atan(d):
            pw=d; d2=L.mul(d,d); lo=hi=0
            for j in range(self.n):
                L.event('atan_iteration'); den=L.mul(L.add(L.mul(2,j),1),pw)
                a=L.div(self.U,den); b=L.cd(self.U,den)
                if j&1: lo=L.sub(lo,b); hi=L.sub(hi,a)
                else: lo=L.add(lo,a); hi=L.add(hi,b)
                pw=L.mul(pw,d2)
            rem=L.cd(self.U,L.mul(L.add(L.mul(2,self.n),1),pw))
            if self.n&1: lo=L.sub(lo,rem)
            else: hi=L.add(hi,rem)
            return lo,hi
        a=atan(5); b=atan(239)
        self.pi=(L.sub(L.mul(16,a[0]),L.mul(4,b[1])),L.sub(L.mul(16,a[1]),L.mul(4,b[0])))
        assert L.mul(3,self.U)<self.pi[0]<=self.pi[1]<L.mul(4,self.U)
        Z=L.div(L.mul(self.M,L.shift(L.mul(2,self.K))),self.N)
        lo=0;hi=L.shift(L.add(self.K,2))
        for _ in range(L.add(self.K,2)):
            L.event('sqrt_iteration'); mid=L.div(L.add(lo,hi),2)
            if L.mul(mid,mid)<=Z:lo=mid
            else:hi=mid
        assert hi-lo==1
        self.root=(lo,L.add(lo,1)); self.ready=True
    def clip(self,a,bnd):
        self.L.event('interval_clip'); lo,hi=bnd
        if a[1]<lo or a[0]>hi:raise ArithmeticError('disjoint analytic enclosure')
        return max(a[0],lo),min(a[1],hi)
    def sin(self,num,den):
        L=self.L;L.event('sine_call'); U=self.U
        r=L.mod(num,L.mul(2,den));sgn=1
        if r>den:r=L.sub(L.mul(2,den),r);sgn=-1
        if L.mul(2,r)>den:r=L.sub(den,r)
        if r==0:L.event('exact_zero_sine');return 0,0
        if L.mul(2,r)==den:L.event('exact_unit_sine');return sgn*U,sgn*U
        lo=L.div(L.mul(self.pi[0],r),den);hi=L.cd(L.mul(self.pi[1],r),den)
        x=L.div(L.add(lo,hi),2);rad=max(L.sub(x,lo),L.sub(hi,x))
        assert 0<=x<=2*U
        x2=L.mul(x,x); U2=L.mul(U,U); tl=th=sl=sh=x
        for j in range(1,self.n):
            L.event('taylor_iteration'); d=L.mul(U2,L.mul(L.mul(2,j),L.add(L.mul(2,j),1)))
            tl=L.div(L.mul(tl,x2),d);th=L.cd(L.mul(th,x2),d)
            if j&1:sl=L.sub(sl,th);sh=L.sub(sh,tl)
            else:sl=L.add(sl,tl);sh=L.add(sh,th)
        fact=1
        for j in range(2,L.add(L.mul(2,self.n),2)):
            L.event('factorial_iteration');fact=L.mul(fact,j)
        tail=L.cd(L.shift(L.add(self.K,L.add(L.mul(2,self.n),1))),fact);assert tail<=1
        rad=L.add(rad,tail);a=(L.sub(sl,rad),L.add(sh,rad))
        if sgn<0:a=(L.sub(0,a[1]),L.sub(0,a[0]))
        a=self.clip(a,(-U,U));assert L.sub(a[1],a[0])<=L.mul(64,L.add(self.n,1))
        return a
    def quotient(self,a,b,c):
        L=self.L;assert b[0]>0; lowers=[];uppers=[]
        for x in a:
            for y in b:
                L.event('quotient_corner');num=L.mul(x,self.U);den=L.mul(c,y)
                lowers.append(L.div(num,den));uppers.append(L.cd(num,den))
        return self.clip((min(lowers),max(uppers)),(-self.U,self.U))
    def mul(self,a,b):
        L=self.L;v=[L.mul(x,y) for x in a for y in b]
        return L.div(min(v),self.U),L.cd(max(v),self.U)
    def signed_power(self,a,s):
        L=self.L;L.event('signed_power_call')
        if s&1:lo,hi=a
        else:lo=0 if a[0]<=0<=a[1] else min(abs(a[0]),abs(a[1]));hi=max(abs(a[0]),abs(a[1]))
        den=L.shift(L.mul(self.K,L.sub(s,1)))
        return self.clip((L.div(L.power(lo,s),den),L.cd(L.power(hi,s),den)),(-self.U,self.U))
    def coefficient(self,ell,k):
        self.prepare();L=self.L;L.read(ell);L.read(k);U=self.U
        nu=L.mod(L.sub(L.mul(ell,self.M),L.mul(k,self.N)),self.Q)
        if nu==0:
            f=L.mul(L.add(L.mul(2,self.lk),1),L.shift(L.sub(self.K,self.m)));F=(f,f);R=(U,U)
            L.event('exact_dirichlet_limit')
        else:
            b=self.sin(nu,self.Q)
            F=self.quotient(self.sin(L.mul(L.add(L.mul(2,self.lk),1),nu),self.Q),b,self.M)
            cq=L.add(L.mul(2,self.q),1)
            R=self.quotient(self.sin(L.mul(cq,nu),self.Q),b,cq)
        P=self.signed_power(R,self.s)
        V=self.clip(self.mul(F,P),(-U,U));H=self.clip(self.mul(V,self.root),(-3*U,3*U))
        aell=L.mul(self.a0,ell)
        pr=self.sin(L.sub(self.N,L.mul(4,aell)),L.mul(2,self.N));pi=self.sin(L.mul(-2,aell),self.N)
        re=self.clip(self.mul(H,pr),(-3*U,3*U));im=self.clip(self.mul(H,pi),(-3*U,3*U))
        def rounded(a):
            d=L.shift(L.sub(L.add(self.K,1),self.p));sm=L.add(*a);v=L.div(sm,d);rem=L.sub(sm,L.mul(v,d))
            if L.mul(2,rem)>d or (L.mul(2,rem)==d and v&1):v=L.add(v,1)
            z=L.mul(v,L.shift(L.sub(self.K,self.p)))
            radius=max(abs(L.sub(z,a[0])),abs(L.sub(z,a[1])))
            return v,radius
        zr,rr=rounded(re);zi,ri=rounded(im);radius2=L.add(L.mul(rr,rr),L.mul(ri,ri));bound=L.shift(L.mul(2,L.sub(self.K,self.A)))
        assert radius2<=bound
        L.event('output_record')
        return dict(ell=ell,k=k,n_u=nu,bits=self.K,p=self.p,real_interval=list(re),imag_interval=list(im),real_integer=zr,imag_integer=zi,certificate_radius_squared=radius2,certificate_bound=bound,normalized_ratio_interval=list(R),binding_hex=self.binding.hex())

class Oracle:
    """Distinct alternate-pi + interval-Horner sine, no reference Scalar reuse."""
    def __init__(self,bits=900):
        self.L=Paid('separate_interval_horner_oracle');L=self.L;self.B=L.read(bits);self.U=L.shift(bits)
        self.N=L.sub(L.shift(55),1);self.M=L.shift(57);self.s=L.read(285)
        self.q=L.div(self.M,L.mul(8,self.s));self.a0=L.div(L.sub(self.N,1),2);self.Q=L.mul(self.N,self.M)
        self.terms=L.add(bits,16);self.pi=self.pi_bounds();L.setup_count=1
        # Distinct restoring integer-square-root recurrence, two input bits/step.
        z=L.div(L.mul(self.M,L.shift(L.mul(2,bits))),self.N)
        digitpairs=L.div(L.add(L.bl(z),1),2);root=0;rem=0
        for i in range(digitpairs-1,-1,-1):
            L.event('restoring_sqrt_pair')
            pair=L.mod(L.div(z,L.shift(L.mul(2,i))),4)
            rem=L.add(L.mul(rem,4),pair);root=L.mul(root,2);trial=L.add(L.mul(root,2),1)
            if rem>=trial:rem=L.sub(rem,trial);root=L.add(root,1)
        assert L.mul(root,root)<=z<L.mul(L.add(root,1),L.add(root,1))
        self.sqrt=(root,L.add(root,1))
    def pi_bounds(self):
        L=self.L;U=self.U;N=self.terms
        sums=[]
        for base in (2,3):
            lo=hi=0;pw=base;base2=L.mul(base,base)
            for j in range(N):
                L.event('alternate_pi_term');den=L.mul(L.add(L.mul(2,j),1),pw)
                fl=L.div(U,den);ce=L.cd(U,den)
                if j%2==0:lo=L.add(lo,fl);hi=L.add(hi,ce)
                else:lo=L.sub(lo,ce);hi=L.sub(hi,fl)
                pw=L.mul(pw,base2)
            tail=L.cd(U,L.mul(L.add(L.mul(2,N),1),pw))
            if N%2==0:hi=L.add(hi,tail)
            else:lo=L.sub(lo,tail)
            sums.append((lo,hi))
        result=(L.mul(4,L.add(sums[0][0],sums[1][0])),L.mul(4,L.add(sums[0][1],sums[1][1])))
        assert 3*U<result[0]<result[1]<4*U
        return result
    def times(self,X,Y):
        L=self.L;lower=None;upper=None
        for x in X:
            for y in Y:
                v=L.mul(x,y)
                lower=v if lower is None else min(lower,v)
                upper=v if upper is None else max(upper,v)
        return L.div(lower,self.U),L.cd(upper,self.U)
    def sine(self,numerator,denominator):
        L=self.L;U=self.U;L.event('oracle_sine_call')
        # Reduce into [-1/2,1/2] using parity of the unit interval.
        whole=L.div(numerator,denominator);r=L.sub(numerator,L.mul(whole,denominator));sign=-1 if whole%2 else 1
        if L.mul(2,r)>denominator:r=L.sub(denominator,r)
        if r==0:return 0,0
        if L.mul(2,r)==denominator:return sign*U,sign*U
        X=(L.div(L.mul(self.pi[0],r),denominator),L.cd(L.mul(self.pi[1],r),denominator))
        assert 0<=X[0]<=X[1]<=2*U
        Z=self.times(X,X);Y=(U,U)
        for j in range(self.terms-1,0,-1):
            L.event('sine_horner_iteration');V=self.times(Z,Y);den=L.mul(L.mul(2,j),L.add(L.mul(2,j),1))
            V=(L.div(V[0],den),L.cd(V[1],den));Y=(L.sub(U,V[1]),L.sub(U,V[0]))
        V=self.times(X,Y);fac=1
        for j in range(2,L.add(L.mul(2,self.terms),2)):
            L.event('oracle_factorial_iteration');fac=L.mul(fac,j)
        tail=L.cd(L.shift(L.add(self.B,L.add(L.mul(2,self.terms),1))),fac)
        assert tail<=1
        V=(L.sub(V[0],tail),L.add(V[1],tail))
        if sign<0:V=(L.sub(0,V[1]),L.sub(0,V[0]))
        return max(-U,V[0]),min(U,V[1])
    def divide(self,numer,denom,scale):
        L=self.L;assert denom[0]>0
        lows=[];highs=[]
        for x in numer:
            for y in denom:
                n=L.mul(x,self.U);d=L.mul(y,scale)
                lows.append(L.div(n,d));highs.append(L.cd(n,d))
        return max(-self.U,min(lows)),min(self.U,max(highs))
    def odd_power(self,interval):
        L=self.L;ans=[]
        for endpoint in interval:
            v=1
            for _ in range(self.s):L.event('oracle_repeated_power_step');v=L.mul(v,endpoint)
            ans.append(v)
        denominator=L.shift(L.mul(self.B,L.sub(self.s,1)))
        return L.div(ans[0],denominator),L.cd(ans[1],denominator)
    def coefficient(self,ell,k):
        L=self.L;L.read(ell);L.read(k);U=self.U
        residue=L.mod(L.sub(L.mul(ell,self.M),L.mul(k,self.N)),self.Q)
        if residue==0:
            f=L.add(L.div(U,2),L.div(U,self.M));F=(f,f);R=(U,U)
        else:
            base=self.sine(residue,self.Q)
            kernel_order=L.add(L.div(self.M,2),1)
            F=self.divide(self.sine(L.mul(kernel_order,residue),self.Q),base,self.M)
            q_order=L.add(L.mul(2,self.q),1)
            R=self.divide(self.sine(L.mul(q_order,residue),self.Q),base,q_order)
        amp=self.times(self.times(F,self.odd_power(R)),self.sqrt)
        # sin(pi/2-theta) and sin(-theta), separately constructed.
        twice_aell=L.mul(2,L.mul(self.a0,ell))
        realphase=self.sine(L.sub(self.N,L.mul(2,twice_aell)),L.mul(2,self.N))
        imagphase=self.sine(L.sub(0,twice_aell),self.N)
        re=self.times(amp,realphase);im=self.times(amp,imagphase);L.event('oracle_output')
        return dict(ell=ell,k=k,bits=self.B,real_interval=list(re),imag_interval=list(im),normalized_ratio_interval=list(R))

def run():
    N=(1<<55)-1;M=1<<57;support=(0,1710,(1<<55)+1,M-1);binding=bytes(range(32))
    ref=Reference(N,M,5,support,binding);selected={(0,0),(1<<53,(1<<55)+1),(0,1710)};seen=set();E=0
    for label,k,ell in ref.incidences():
        E+=1
        assert label==binding
        # Separate diagnostic predicate; charge its arithmetic too.
        L=ref.L;shift=L.mod(L.sub(k,L.div(L.mul(ell,M),N)),M)
        assert shift<=ref.h+1 or shift>=M-ref.h
        if (ell,k) in selected:seen.add((ell,k))
    assert seen==selected and E==9123
    setup_before=ref.L.setup_count;assert setup_before==0
    empty=Reference(N,M,5,(),binding);assert list(empty.incidences())==[] and empty.L.setup_count==0
    outputs=[ref.coefficient(ell,k) for ell,k in sorted(selected)]
    U=ref.U;sentinel=ref.signed_power((-U//2,-U//4),285)
    assert sentinel==(-(1<<338),-(1<<53))
    # Deliberately incorrect replacements must be caught at operator level.
    absolute_mutant=ref.signed_power((U//4,U//2),285)
    assert absolute_mutant==(1<<53,1<<338)
    assert sentinel!=absolute_mutant
    def fresh_even_only_mutant(interval,exponent):
        if exponent%2:raise ValueError('even exponent required')
        return interval
    try:fresh_even_only_mutant((-U//2,-U//4),285)
    except ValueError as e:odd_rejection=str(e)
    else:raise AssertionError('even-only mutant unexpectedly accepted odd exponent')
    oracle=Oracle(900);oracles=[];comparisons=[];diagnostics=Paid('exact_comparison_diagnostics')
    for record in outputs:
        o=oracle.coefficient(record['ell'],record['k']);oracles.append(o)
        C=diagnostics;shift=C.sub(o['bits'],record['bits']);radii=[]
        for key,pointkey in [('real_interval','real_integer'),('imag_interval','imag_integer')]:
            lo,hi=record[key];olo,ohi=o[key]
            scale=C.shift(shift)
            assert C.mul(lo,scale)<=olo<=ohi<=C.mul(hi,scale),(record['ell'],record['k'],key,'oracle not nested')
            point=C.mul(record[pointkey],C.shift(C.sub(o['bits'],record['p'])))
            radii.append(max(abs(C.sub(point,olo)),abs(C.sub(point,ohi))))
        e2=C.add(C.mul(radii[0],radii[0]),C.mul(radii[1],radii[1]))
        bound=C.shift(C.mul(2,C.sub(o['bits'],ref.A)));assert e2<=bound
        error_bits=C.div(C.sub(C.mul(2,o['bits']),C.bl(e2)),2) if e2 else None
        comparisons.append(dict(ell=record['ell'],k=record['k'],oracle_nested_in_reference=True,
          exact_error_squared_upper_numerator=e2,exact_error_squared_upper_denominator_exponent=2*o['bits'],
          eta_squared_denominator_exponent=2*ref.A,normalized_error_squared_numerator=e2,
          normalized_error_squared_denominator=bound,absolute_error_upper_power_two_exponent=-error_bits if error_bits is not None else None))
    minimum=next(r for r in outputs if (r['ell'],r['k'])==(1<<53,(1<<55)+1))
    assert minimum['n_u']==1
    result=dict(verdict='ACCEPT_NEW_REFERENCE_REGRESSION_ONLY',D=5,m=57,N=N,M=M,s=285,J=ref.J,K=ref.K,p=ref.p,
      eta_denominator_exponent=ref.A,enumerated_incidences=E,selected_coefficient_count=len(outputs),
      reference_outputs=outputs,oracle_outputs=oracles,exact_comparisons=comparisons,
      signed_power_sentinel=list(sentinel),reference_paid_ledger=ref.L.report(),oracle_paid_ledger=oracle.L.report(),
      exact_comparison_paid_ledger=diagnostics.report(),
      negative_controls=dict(absolute_power_mutant_rejected=True,even_only_mutant_exact_error=odd_rejection),
      empty_support_paid_ledger=empty.L.report(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      historical_code_executed=False,production_wrapper_integrated=False,independent_agent_review=False,
      implementation_diversity='Same author; distinct pi identities, sine formulations, sqrt algorithms, and power algorithms. Low-level paid arithmetic is shared.',
      note='All numeric preparation, coefficient calculations, and exact comparisons have paid ledgers. Fixed control/validation/copy bookkeeping is covered by the declared conservative envelope. JSON serialization, OS runtime and host memory are not claimed as part of the arithmetic model; this is not a production complexity certificate.')
    (HERE/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(verdict=result['verdict'],incidences=E,selected_coefficients=len(outputs),reference_max_integer_bits=ref.L.maxbits,oracle_max_integer_bits=oracle.L.maxbits,source_sha256=result['source_sha256']),indent=2))

if __name__=='__main__':run()
