"""Bounded launcher for only the newly authored adjacent regression.py."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
source=here/'regression.py'
before=hashlib.sha256(source.read_bytes()).hexdigest()
started=time.monotonic()
try:
    result=subprocess.run([sys.executable,str(source)],capture_output=True,text=True,timeout=180,check=False)
    stdout,stderr,code=result.stdout,result.stderr,result.returncode
    timed_out=False
except subprocess.TimeoutExpired as e:
    stdout=e.stdout or '';stderr=e.stderr or '';code=None;timed_out=True
    if isinstance(stdout,bytes):stdout=stdout.decode(errors='replace')
    if isinstance(stderr,bytes):stderr=stderr.decode(errors='replace')
elapsed=time.monotonic()-started
after=hashlib.sha256(source.read_bytes()).hexdigest()
(here/'RUN.log').write_text(stdout)
(here/'RUN.stderr').write_text(stderr)
receipt=dict(source_sha256_before=before,source_sha256_after=after,source_unchanged=before==after,
  process_exit_code=code,timeout_seconds=180,timed_out=timed_out,elapsed_monotonic_seconds=elapsed,
  exact_stderr=stderr,scope='Executed only newly authored regression.py; no historical scientific code.',
  host_utc_clock_used=False)
(here/'EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
if timed_out or code!=0 or before!=after:raise SystemExit(1)
