"""New checker. Imports no uploaded research programs; exact integer residues only."""
import hashlib, itertools, json, pathlib
OUT=pathlib.Path(__file__).parent/'deliverable'

def polynomial(roots,p):
    a=[1]
    for z in roots:
        b=[0]*(len(a)+1)
        for i,v in enumerate(a):
            b[i]=(b[i]+v)%p; b[i+1]=(b[i+1]-z*v)%p
        a=b
    return a

def direct(z,a,N,p):
    return [sum(x*pow(y,m,p) for x,y in zip(a,z))%p for m in range(N)]

def evaluate(z,a,N,b,p):
    powers=list(dict.fromkeys(pow(x,b,p) for x in z))
    r=polynomial(powers,p);d=len(powers);M=min(N,b*d)
    taps=[(b*i,(-v)%p) for i,v in enumerate(r) if i and v]
    out=[0]*M;mul=add=0
    for j,(node,amplitude) in enumerate(zip(z,a)):
        v=amplitude%p
        for m in range(M):
            if j: out[m]=(out[m]+v)%p;add+=bool(j)
            else:out[m]=v
            if m+1<M:v=v*node%p;mul+=1
    for m in range(M,N):
        s=None
        for distance,c in taps:
            assert 0<=m-distance<m
            v=c*out[m-distance]%p;mul+=1
            if s is None:s=v
            else:s=(s+v)%p;add+=1
        out.append(s)
    k=len(z);tau=len(taps)
    expected={'mul':k*(M-1)+(N-M)*tau,'add':(k-1)*M+(N-M)*(tau-1)}
    assert (mul,add)==(expected['mul'],expected['add'])
    assert out==direct(z,a,N,p)
    return {'d':d,'M':M,'tau':tau,**expected,'checked_coordinates':N}

tests=[];basis_controls=0
for p in (5,7,11,17):
    for k in range(1,min(4,p-1)+1):
        supports=list(itertools.combinations(range(1,p),k))
        supports=supports if len(supports)<=25 else supports[::max(1,len(supports)//25)][:25]
        for z in supports:
            for b in (1,2,3,5,19):
                for N in (1,2,3,8,23):
                    for j in range(k+2):
                        a=[int(i==j) for i in range(k)] if j<k else ([0]*k if j==k else [(i+2)**2%p for i in range(k)])
                        result=evaluate(z,a,N,b,p);basis_controls+=int(j<k)
                        tests.append({'p':p,'k':k,'N':N,'b':b,**result})

big=[]
for p in (65537,998244353):
    N=4096;omega=pow(3,(p-1)//N,p)
    assert pow(omega,N,p)==1 and pow(omega,N//2,p)!=1
    z=[pow(omega,a+256*j,p) for a in (1,3) for j in range(8)]
    assert len(set(z))==16
    minimal=polynomial(z,p);assert sum(bool(x) for x in minimal[1:])==16
    candidate=evaluate(z,list(range(1,17)),N,2,p)
    assert (candidate['d'],candidate['M'],candidate['tau'])==(16,32,2)
    assert (candidate['mul'],candidate['add'])==(8624,4544)
    # All modal basis vectors certify this exact finite linear output map.
    for j in range(16):evaluate(z,[int(i==j) for i in range(16)],N,2,p)
    baseline=evaluate(z,list(range(1,17)),N,1,p)
    assert baseline['mul']+baseline['add']==126960
    L=16;ell=4;B=N//L-1
    fallback_online=16*(L-1)+B*(4*L*ell+12*L)+(16-1)*L+4*B*L*(ell+1)+4*B*L*(ell+1)+B*L
    big.append({'p':p,'omega':omega,'current_source_example':candidate,'minimal_Q_taps':16,'minimal_Q_online_total':126960,'fallback_online_from_stated_formula':fallback_online,'arbitrary_amplitude_basis_vectors':16,'cold_discovery_1188_and_fallback_preparation_not_replayed':True})

report={'verdict':'PASS_SCOPED','supplied_code_executed':False,'new_checker_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'small_cases':len(tests),'basis_controls':basis_controls,'small_coordinates':sum(t['checked_coordinates'] for t in tests),'fields':[5,7,11,17],'tested_positive_strides':[1,2,3,5,19],'N_values':[1,2,3,8,23],'large_examples':big,'fresh_scope':'Annihilator recurrence, all-coordinate outputs, and exact online arithmetic ledger; source setup counters, planner, fallback implementation, benchmark, and mathematical priority not revalidated.'}
(OUT/'ALG014_FRESH_CONTROL_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
