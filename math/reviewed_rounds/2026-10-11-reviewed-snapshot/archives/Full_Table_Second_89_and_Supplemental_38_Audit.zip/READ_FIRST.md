# Research catalogue coverage audit

This package covers every canonical catalogue row from 93 through 181 and
all 38 supplemental novelty-register views. It is a coverage and evidence
audit, with one new narrow mathematical reconstruction for ALG-014.

## Results

- All 89 assigned canonical IDs are present exactly once.
- All 223 historical source references match recovered bytes at their
  recorded SHA-256 values, representing 208 distinct source documents.
- Twenty canonical rows have at least one exact-hash current-task review
  binding verified from the recovered baseline proof pack. This is scoped
  to those actual reviewed artifacts, not every historical statement,
  implementation, or later appended refinement in the same family.
- Each of the 38 supplemental views has zero additional canonical-claim
  count and zero claimed discovery count. A shared family label does not
  establish theorem equivalence.
- The audit does not claim 89 complete proof rereads or any new exhaustive
  external-priority review. The row ledgers preserve both inherited status
  and the actual depth of this pass.

## Important corrections

ALG-074's previously unbound conditional-exponent PROOF was recovered from
the Library master at exactly its recorded hash. Its body explicitly states
that its conditional claims lack independent mathematical review. The
separately recovered cancellation-search audit does not review that exponent
module. Source availability improves; exponent correctness status does not.

ALG-014's historical independent review names a README hash different from
the current canonical README. A new independent proof and exact controls now
bind the current document's annihilator recurrence and online arithmetic
ledger. This does not validate its whole planner, discovery counters,
fallback implementation, timings, or all historical computations.

ALG-067's newer novelty-register text correctly treats 25 multiplications as
an upper/fixed-instruction count. The historical catalogue formula must not
be silently reinterpreted as exactly 25 nonidentity multiplications for every
legal field/root. The register's F_61/root-12 correction was already present;
this audit adds no new discovery credit for it.

ALG-075's source-access note is available and verified, while the cited 1976
Brockett-Dobkin construction remains unaudited in this pass. Missing primary
text is not a negative theorem about that algorithm.

Historical pending-audit descriptions for M-MULTISCALE-CHIRP,
M-TWO-SIDED-GAUGE, M-PAIRED-JACOBI and M-HADAMARD-SEGRE are superseded only
at the explicitly accepted scopes of Q24, Q19/Q25, Q22 and Q23 respectively.
The baseline proof and decision hashes were checked; the historical text
remains useful as dated history. M-OUTER-STABILITY likewise retains its
accepted Q28 scope, not an invented global infeasibility claim.

## Neglected material outside the main Q27 to Q32 construction queue

These are existing recorded obligations, not newly observed implementation
failures. The uploaded implementations were not executed in this pass.

1. ALG-009: replace the over-restrictive alpha^N resonance test with the
   correct gcd-sensitive condition, then bind tests to an actual patched
   recognizer. The source is recorded as unchanged.
2. ALG-033: the adaptive offset/Bessel certificate has an exact N=3
   counterexample. Keep theorem acceptance separate from the false
   implementation certificate; repair needs a correct deterministic error
   and chosen-grid contract.
3. ALG-062: the greedy reset/anchor recognizer misses a known N=16 witness;
   the uploaded dispatcher never calls the newer branches. Repaired
   mathematics does not establish shipped dispatcher behavior.
4. ALG-079: preview after full completion can return an incorrect DC value;
   the Green constructor's nonzero-diagonal restriction is stronger than
   invertibility. A guard/API patch and bound regression controls remain.
5. ALG-027: stale or cross-input plans are invalid; plans must bind the
   actual input and tolerance. ALG-060/063 retain repeated-power and
   singular-branch implementation caveats.
6. ALG-025/026 and F016: weak output-error scales must not be promoted to
   relative-l2 guarantees or practical full-FFT claims. Their remaining
   implementation and model-matched priority work is separate.
7. ALG-074: independently audit the conditional exponent's inherited
   compiler, carrier, finite-certificate and assembly dependencies before
   promoting the module. ALG-075 needs the primary construction, rather
   than another inference from an abstract or nonscalar-count excerpt.

## Files

- CANONICAL_89_COVERAGE_LEDGER.json: complete per-canonical-row statements,
  recorded proof, source hashes, current queue crosschecks, exact review
  bindings versus inheritance, novelty depth and remaining obligations.
- SUPPLEMENTAL_38_COVERAGE_LEDGER.json: every noncanonical view with
  deduplication rules, current scopes, source availability and remaining work.
- COVERAGE_INDEX.csv: a compact sortable index of all 127 audit records.
- ALG014_FRESH_SCOPED_REVIEW.md and ALG014_FRESH_CONTROL_RESULTS.json:
  new bounded mathematical certificate and exact results.
- source_documents: all 208 historical source bodies, content-addressed.
- baseline_proof_pack: independently hash-verified baseline proof pack.
- MINIMAL_CELL_RECOMMENDATIONS.json: proposed append-only corrections;
  this audit itself makes no Sheet or repository changes.
- PACKAGE_MANIFEST.json: hash and size of each delivered file.

Later supplemental hashes not recovered in the bounded available-source
pass are labeled as such. That label does not assert the files are absent
from the user's full Library or repository, and it does not reverse an
inherited acceptance.
