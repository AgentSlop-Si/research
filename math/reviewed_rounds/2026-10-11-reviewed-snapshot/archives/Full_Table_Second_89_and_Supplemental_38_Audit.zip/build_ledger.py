import csv,hashlib,json,pathlib,re,shutil,collections
ROOT=pathlib.Path(__file__).resolve().parent.parent
BASE=ROOT/'coverage_audit_1334';OUT=ROOT/'coverage_audit_second89/deliverable'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):return json.loads((BASE/(name+'.json')).read_text())['structuredContent']['values']
C,N,Q=load('FULL_CATALOGUE'),load('FULL_NOVELTY_REGISTER'),load('LIVE_RESEARCH_QUEUE')
ids={r[0] for r in C[1:]};nr={r[2]:(i,r) for i,r in enumerate(N[1:],6)};qr={r[0]:(i,r) for i,r in enumerate(Q[1:],4)}
PACK=ROOT/'coverage_audit_first89/current_packet'
ps={r['Proof ID']:r for r in csv.DictReader((PACK/'tables/07-proof-sources.csv').open(encoding='utf-8-sig'))}
dec={r['id']:r for r in json.loads((PACK/'review/DECISIONS.json').read_text())['rows']}
newtasks={r['id']:r['tasks'] for r in json.loads((PACK/'STATUS_REGISTER.json').read_text())['new_results']}
master=json.loads((ROOT/'coverage_audit_first89/evidence/SOURCE_HASH_MATCHES.json').read_text())
by=collections.defaultdict(list)
for r in master:by[r['sha256']].append({'path':r['local_path'],'archive_member':r['archive_member'],'source':'Library source archive; exact bytes rehashed in this pass'})
for r in json.loads((ROOT/'coverage_audit_second89/evidence/GITHUB_SOURCE_READBACK.json').read_text()):by[r['actual_sha256']].append({'path':r['path'],'url':r['url'],'git_blob':r['git_blob'],'source':'repository base64 readback; exact bytes rehashed in this pass'})

alltargets=set()
for r in N[1:]:
    if r[2] not in ids:alltargets.update(re.findall(r'(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9])','\n'.join(str(x or '') for x in r)))
for r in Q[1:]:alltargets.update(re.findall(r'(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9])','\n'.join(str(x or '') for x in r)))
extra=collections.defaultdict(list)
for p in ROOT.rglob('*'):
    if not p.is_file() or 'coverage_audit_second89' in p.parts or any(x in p.parts for x in ['.git','.codex','.agents','.aws']) or p.stat().st_size>12_000_000:continue
    h=sha(p)
    if h in alltargets:extra[h].append(str(p.relative_to(ROOT)))
for r in json.loads((ROOT/'coverage_audit_second89/evidence/SUPPLEMENT_HASH_MATCHES.json').read_text()):
    if r['location'] not in extra[r['sha256']]:extra[r['sha256']].append(r['location'])
(OUT/'REFERENCED_LATER_HASH_AVAILABILITY.json').write_text(json.dumps({h:extra[h] for h in sorted(alltargets)},indent=2))

def queue_binding(task):
    if task not in qr:return None
    rowno,r=qr[task];r=r+[None]*(12-len(r))
    pids=re.findall(r'\b(?:P|H|D|SP|L)\d+\b',str(r[10] or ''))
    rids=re.findall(r'\b(?:R|S|I|N|H)\d+\b',str(r[11] or ''))
    proof=[]
    for pid in pids:
        if pid not in ps:proof.append({'id':pid,'status':'not in recovered baseline proof pack; later/inherited locator'});continue
        x=ps[pid];p=PACK/x['Proof-pack member'];actual=sha(p) if p.is_file() else None
        proof.append({'id':pid,'member':x['Proof-pack member'],'recorded_sha256':x['SHA-256'],'actual_sha256':actual,'matches':actual==x['SHA-256'],'indexed_review_status':x['Independent review']})
    reviews=[]
    for rid in dict.fromkeys(rids):
        if rid not in dec:reviews.append({'id':rid,'status':'later/inherited review ID, not in baseline DECISIONS'});continue
        x=dec[rid];h=x.get('reviewed_artifact_sha256');match=[p['id'] for p in proof if h and p.get('actual_sha256')==h]
        reviews.append({'id':rid,'verdict':x['verdict'],'scope_boundary':x['scope_boundary'],'explicit_reviewed_hash':h,'matching_current_task_proof_ids':match,'status':'explicit review-to-proof hash binding verified' if match else 'decision recovered; acceptance association inherited/indexed, no matching explicit hash in this decision'})
    laterhashes=sorted(set(re.findall(r'(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9])','\n'.join(str(x or '') for x in r))))
    return {'task_id':task,'sheet_row':rowno,'activity':r[2],'paper_proof':r[3],'current_finding':r[4],'remaining':r[5],'dependencies':r[7],'implementation':r[9],'proof_bindings':proof,'review_bindings':reviews,'later_referenced_hashes':[{'sha256':h,'byte_locations':extra[h],'status':'bytes rehashed; semantic review binding not automatically established' if extra[h] else 'not recovered in bounded pass'} for h in laterhashes],'important_scope_note':'Task association is not theorem equivalence. Baseline accepted hash binding does not certify every later appended result or historical implementation.'}

canonical=[];source_dir=OUT/'source_documents';source_dir.mkdir(exist_ok=True)
for rowno,r in enumerate(C[1:],4):
    if rowno<93:continue
    ni,n=nr[r[0]];evidence=[]
    for e in json.loads(r[13]):
        h=e['sha256'];choices=by[h];assert choices,(r[0],h)
        x=choices[0];p=ROOT/x['path'];actual=sha(p);assert actual==h
        dst=source_dir/(h+'__'+pathlib.Path(e['archive_relative_path']).name);shutil.copyfile(p,dst)
        txt=p.read_text(errors='replace');review_like=bool(re.search('audit|review',pathlib.Path(e['archive_relative_path']).name,re.I))
        evidence.append({**e,'actual_sha256':actual,'actual_bytes':p.stat().st_size,'availability':'recovered exact historical bytes','verified_source':x,'package_member':str(dst.relative_to(OUT)),'review_document_by_filename':review_like,'embedded_sha256s':sorted(set(re.findall(r'(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9])',txt)))})
    tasks=json.loads(r[4]);qb=[queue_binding(t) for t in tasks];reviews=[e for e in evidence if e['review_document_by_filename']];proofhashes={e['sha256'] for e in evidence if not e['review_document_by_filename']}
    historical_explicit=[{'review_sha256':e['sha256'],'matching_proof_sha256':h} for e in reviews for h in e['embedded_sha256s'] if h in proofhashes]
    baseline_explicit=any(any(a['status']=='explicit review-to-proof hash binding verified' for a in t['review_bindings']) for t in qb if t)
    binding='explicit scoped current-task review hash verified; historical row is not automatically reaccepted' if baseline_explicit else ('historical review embeds matching source hash; correctness conclusion remains inherited' if historical_explicit else 'saved review/status inherited; no complete explicit proof-to-review hash binding established in this pass')
    if r[0]=='ALG-014':binding+='; new independent narrow recurrence/online-ledger acceptance binds current README; old README mismatch remains'
    if r[0]=='ALG-074':binding='conditional exponent PROOF recovered; it expressly lacks independent mathematical review; unrelated cancellation audit must not be transferred to that claim'
    if r[0]=='ALG-075':binding='source-access note recovered; primary 1976 construction not recovered/audited here; no negative theorem'
    canonical.append({'claim_id':r[0],'catalogue_physical_row':rowno,'novelty_register_physical_row':ni,'title':r[2],'record_kind':'canonical','recorded_historical_proof_status':r[9],'historical_exact_statement':r[7],'historical_model':r[8],'historical_limitations':r[11],'catalogue_current_proof_overlay':r[19] if len(r)>19 else None,'register_correctness_status':n[9],'register_current_claim':n[11],'recorded_novelty_depth':n[10],'recorded_novelty_status':n[19],'new_novelty_audit_depth':'claim/model/status/limitation/source-locator screen only; no new model-matched external primary-literature audit','source_evidence':evidence,'source_hashes_all_match':True,'independent_review_binding':binding,'historical_explicit_bindings':historical_explicit,'current_queue_crosschecks':qb,'remaining_task':{'recorded_catalogue':r[21] if len(r)>21 else r[12],'recorded_register':n[13],'next_novelty_check':n[14],'fresh_audit_obligation':'Keep source-byte recovery separate from complete proof reread and novelty clearance; request a fresh scoped audit only for the named unclosed obligation.'},'fresh_proof_reread':'only ALG-014 recurrence/online ledger independently reconstructed; otherwise no full proof reread claimed' if r[0]=='ALG-014' else 'not completed in this coverage pass','canonical_count_increment':1,'discovery_count_increment':0})

supp=[]
for rowno,n in enumerate(N[1:],6):
    if n[2] in ids:continue
    tasks=[n[2]] if n[2] in qr else newtasks.get(n[2],[])
    hashes=sorted(set(re.findall(r'(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9])','\n'.join(str(x or '') for x in n))))
    family_ids=[r[2] for r in N[1:] if r[2] in ids and r[5]==n[5]]
    supp.append({'claim_id':n[2],'novelty_register_physical_row':rowno,'record_kind':n[3],'title':n[4],'family':n[5],'role_deduplication':n[6],'recorded_proof_status':n[9],'claim_and_current_scope':n[11],'recorded_model':n[12],'recorded_novelty_depth':n[10],'recorded_novelty_status':n[19],'new_novelty_depth':'view/statement/source-binding screen only; no new external priority audit','source_locators':n[16],'canonical_source_sheet_row':n[17],'explicit_referenced_hash_availability':[{'sha256':h,'byte_locations':extra[h],'status':'rehashed exact bytes; not by itself an acceptance binding' if extra[h] else 'not recovered in bounded pass'} for h in hashes],'current_queue_crosschecks':[queue_binding(t) for t in tasks],'same_family_canonical_ids':family_ids,'deduplication_note':'Supplemental/refinement view, not a new canonical or discovery count. Shared family is not theorem equivalence. Multiple supplemental views may describe distinct scoped refinements.','remaining_task':n[13],'next_novelty_check':n[14],'fresh_full_proof_reread':False,'canonical_count_increment':0,'discovery_count_increment':0})
assert len(canonical)==89 and len(supp)==38
for name,data in [('CANONICAL_89_COVERAGE_LEDGER.json',canonical),('SUPPLEMENTAL_38_COVERAGE_LEDGER.json',supp)]: (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
with (OUT/'COVERAGE_INDEX.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['claim_id','catalogue_row','register_row','record_kind','title','source_references','exact_hash_matches','review_binding','novelty_depth_this_pass','remaining_task'])
    for r in canonical:w.writerow([r['claim_id'],r['catalogue_physical_row'],r['novelty_register_physical_row'],'canonical',r['title'],len(r['source_evidence']),len(r['source_evidence']),r['independent_review_binding'],r['new_novelty_audit_depth'],r['remaining_task']['recorded_register']])
    for r in supp:w.writerow([r['claim_id'],'',r['novelty_register_physical_row'],'supplemental view',r['title'],len(r['explicit_referenced_hash_availability']),sum(bool(e['byte_locations']) for e in r['explicit_referenced_hash_availability']),'see scoped queue bindings; later acceptance inherited unless exact receipt verified',r['new_novelty_depth'],r['remaining_task']])
stats={'canonical_rows':len(canonical),'supplemental_views':len(supp),'canonical_source_references':sum(len(x['source_evidence']) for x in canonical),'distinct_source_hashes':len({e['sha256'] for x in canonical for e in x['source_evidence']}),'canonical_source_hash_matches':sum(e['actual_sha256']==e['sha256'] for x in canonical for e in x['source_evidence']),'canonical_rows_with_related_queue':sum(bool(r['current_queue_crosschecks']) for r in canonical),'canonical_rows_with_any_explicit_current_task_binding':sum(any(any(a['status']=='explicit review-to-proof hash binding verified' for a in t['review_bindings']) for t in r['current_queue_crosschecks'] if t) for r in canonical),'new_full_proof_rereads':0,'new_narrow_proof_reconstructions':1,'new_external_novelty_audits':0,'new_discoveries_claimed':0,'supplied_programs_executed':False}
(OUT/'SUMMARY_COUNTS.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats,indent=2))
