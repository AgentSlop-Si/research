# ALG-014: fresh source-bound recurrence and online-ledger review

Date: 2026-10-11. Disposition: ACCEPTED FOR THE NARROW MATHEMATICAL SCOPE BELOW.

This is a new independent reconstruction of the recurrence identity and online
arithmetic ledger in the current canonical README. It is not a replay of the
uploaded implementation, a full acceptance of its planner/fallback, or an
originality finding. No supplied research program was executed.

## Exact source binding

- Current canonical README: SHA-256
  `f1b1856375df9240f253a4e1f124c455b5b22e92bb26df544c7f5f01abffda1c`.
- Historical independent review: SHA-256
  `0df64bd669a94b8166f8d8abc0fa6592f078b5a6db9e87c30e249d698c65d619`.
- That review's final hash table names README SHA-256
  `0415cb65f72aa0e56a871a832908ae3b3c20fbf1bc4830f6cebe0f5b41b88e6f`,
  which is different. The two recovered documents are authentic at their
  catalogue hashes, but the old receipt is not a cryptographic acceptance of
  the current README. This pass does not pretend to repair that historical
  receipt. It adds the explicitly bounded acceptance below.

The original source bytes are in the accompanying source_documents directory.

## Fresh proof

Let K be a field, N >= 1, k >= 1, z_1,...,z_k distinct nonzero elements of K,
and a_1,...,a_k arbitrary amplitudes. For a positive integer b, put
Lambda = {z_s^b}, d = |Lambda|, and
R(t) = product over lambda in Lambda of (1 - lambda t) = sum r_i t^i.
For f_m = sum a_s z_s^m and m >= bd,

f_m + sum_(i=1)^d r_i f_(m-bi)
= sum_s a_s z_s^m R(z_s^(-b)) = 0.

The equality uses only ordinary field operations, not separability of t^b
or a characteristic restriction. Each z_s^(-1) is a root of R(t^b).
Distinctness of the z_s therefore makes Q(t) = product(1-z_s t) divide
R(t^b), and degree comparison gives k <= bd. Nonzero powered roots give
r_d != 0, so the number tau of nonzero nonconstant coefficients is at least
one. At every generated index m >= bd, all m-bi lie in [0,m-1]. Thus the
first min(N,bd) directly computed values determine the entire output.

For M = min(N,bd), initialize the prefix separately for each mode by advancing
its weighted value multiplicatively. This costs k(M-1) multiplications and
(k-1)M additions. Each of the N-M recurrence steps uses tau multiplications
and tau-1 additions, with coefficient negation prepaid. The exact online
ledger is consequently

- multiplications: k(M-1) + (N-M)tau;
- additions: (k-1)M + (N-M)(tau-1).

These are fixed arithmetic-instruction counts, including multiplication by
special values. Eliminating arithmetic with zero amplitudes or coefficients
equal to one may reduce actual nonidentity-operation counts. The theorem
must not claim the displayed ledger is a universal minimum.

The source already excludes free root/amplitude extraction and free transform
roots. The proof establishes a restricted-support evaluator. Sparse
annihilating-polynomial identities are classical and supply no new universal
Fourier algorithm or historical-priority claim.

## New independent exact controls

The newly authored alg014_fresh_controls.py imports no uploaded research code.
It independently constructs the powered-root polynomial, executes a simple
prefix/recurrence evaluator, counts online operations, and compares every
output with separately computed direct power sums.

- 28,950 small cases in F_5, F_7, F_11 and F_17; 214,230 output coordinates.
- 16,600 modal basis-vector controls plus zero and mixed-amplitude controls.
- N in {1,2,3,8,23}; strides in {1,2,3,5,19}; covers N<k, merged powered
  roots, characteristic-dividing strides, no-recurrence cases and b>N.
- At N=4096 in F_65537 and F_998244353, the stated support
  {omega^(a+256j): a in {1,3}, 0<=j<8} has all 16 minimal-denominator taps,
  while b=2 has d=16, M=32 and tau=2. All 16 modal basis vectors are checked
  in each field. The online ledger is exactly 8,624 multiplications plus
  4,544 additions. The separately counted b=1 online total is 126,960.

## Remaining obligations

The numerical result 14,412 includes 1,188 source discovery/setup operations;
this new checker validates the online subtotal 13,168, not that setup
implementation. The source's complete cold totals, fallback code, candidate
selection completeness, historical broad runs, timings, bit complexity and
numerical stability remain outside this fresh acceptance. The old receipt's
README mismatch remains documented. A whole-package production acceptance
needs its own final file-by-file binding and review.
