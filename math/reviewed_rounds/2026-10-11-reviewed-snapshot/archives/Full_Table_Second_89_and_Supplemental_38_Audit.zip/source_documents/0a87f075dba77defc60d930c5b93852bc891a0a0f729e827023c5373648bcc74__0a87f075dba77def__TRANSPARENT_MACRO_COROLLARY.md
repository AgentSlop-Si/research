# Transparent macro-FFT: using #130 as a slowly growing stable block

**Date:** 9 October 2026  
**Status:** theorem-form continuation. The algebraic composition and condition-reset mechanism are proved at the matrix level and tested numerically. The remaining formal work is to extract an effective intermediate-condition bound from the printed local #130 block and match the exact condition definition to Ailon's extra-space model.

## 1. The key #130 ingredient already exists

The explicit DFT manuscript proves a replay lemma for a linear DAG `M : C^e -> C^a`:

`(x,y,z) -> (x, y + Mx, z)`

using a finite word of shears, while restoring the borrowed coordinates `z` even when their initial contents are arbitrary and correlated with the data. The count is at most `8g+2a` shears for a DAG with `g` gates and `a` outputs.

This is stronger than the zero-workspace reversible simulation originally contemplated in `CONDITION_RESET_THEOREM.md`: it gives a **transparent linear addition primitive with arbitrary scratch**.

The same manuscript also states that the all-length exact DFT program performs only addition, subtraction, and multiplication by prepared input-independent scalars on the variable data. Therefore, for a fixed local length `B`, unrolling the variable-data operations gives a finite linear DAG for `F_B`; normalization adds only `B` scalar multiplications.

Let

`U_B = F_B / sqrt(B)`.

Then `U_B` is unitary.

---

## 2. Three transparent additions give a unitary bank exchange

Assume a transparent primitive

`ADD_M : (x,y,z) -> (x,y+Mx,z)`.

Apply:

1. `y <- y + U_B x`;
2. `x <- x - U_B^{-1} y`;
3. `y <- y + U_B x`.

Algebra gives

`(x,y) -> (-U_B^{-1} y, U_B x)`.

The two-bank matrix is

`W_B = [[0, -U_B^{-1}], [U_B, 0]].`

Since `U_B` is unitary, `W_B` is unitary. Scratch is restored after each transparent addition, hence the completed operation on both data banks plus scratch is `W_B direct-sum I_scratch`, also unitary.

If the inactive bank starts at zero, the actual data movement is simply

`(x,0) -> (0,U_B x)`.

Thus successive macro-stages may alternate the active data bank without copying a whole vector.

`transparent_swap_check.py` verifies this identity for `B=2,4,8,16` to floating-point precision.

---

## 3. Local replay work stays sub-`B log B`

Let `A(B)` be the variable-data work of the local exact DFT program, and unroll those operations into a DAG with `g(B)=O(A(B))` gates. The transparent replay lemma implements `ADD_{U_B}` using

`O(g(B)+B)=O(A(B)+B)`

shears.

The inverse normalized transform has the same asymptotic cost. For the usual Fourier convention, `F_B^2=BJ` with `J` index negation, so `U_B^{-1}` is obtained from `U_B` with only a permutation/scaling convention change.

Three transparent additions therefore implement one unitary bank exchange in

`O(A(B)+B)`

charged linear operations.

For #130,

`A(B)/(B log B) -> 0`, so transparentization preserves the local sub-`B log B` property up to a constant factor and an `O(B)` term.

---

## 4. Macro-level condition reset with arbitrary scratch

Fix a local `B`. The transparent replay word and the three-shear exchange are a finite sequence of invertible shear/monomial matrices on

`2B + g(B)`

coordinates. Define `K(B)` to be the maximum spectral condition number of any cumulative prefix of this finite word. Then `K(B)<infinity`.

Process the global transform one `B`-fiber at a time, reusing the same restored scratch. During one fiber:

- previously processed fibers carry completed unitary `W_B` blocks;
- untouched fibers carry identity blocks;
- the currently processed fiber carries one prefix of the local transparent word;
- all previously completed Fourier macro-levels and all twiddle/permutation passes are unitary.

Therefore the global condition at every such point is at most `K(B)`. After a whole macro-level completes, the global two-bank transformation is unitary again.

So the condition does not accumulate with the number of macro-levels.

---

## 5. Full power-of-two work bound

For `N=2^k`, choose `B=2^b` and group `b` binary Fourier levels into each macro-level.

Using the transparent `B`-point exchange on all `N/B` fibers, one macro-level costs

`O((N/B)(A(B)+B) + N)`.

There are `floor(k/b)` full macro-levels. Unit-modulus twiddles and permutations are linear passes. The `r=k mod b` leftover binary levels can use the ordinary normalized FFT at cost `O(Nr)` and condition one.

Hence

`T(N)/(N log N)`

is bounded, up to absolute constants, by

`A(B)/(B log B) + 1/log B + log B/log N`.

If `B(N)->infinity` sufficiently slowly and `log B=o(log N)`, #130's local power saving implies

`T(N)=o(N log N)`.

This is still a **fresh arbitrary dense input, all-output DFT**.

---

## 6. Arbitrarily slow condition growth

For each fixed block exponent `b`, the transparent word is finite, so `K(2^b)` is finite.

Let `R(N)` be any prescribed nondecreasing unbounded condition budget. Choose a staircase sequence of block sizes `B_t=2^{b_t}` such that

- the normalized local work ratio is at most `1/t`;
- `b_t` grows;
- the global input threshold `N_t` is large enough that `R(N)>=K(B_t)` for all `N>=N_t`;
- `b_t/log_2 N_t <=1/t`.

Use `B_t` on `[N_t,N_{t+1})`.

Then asymptotically

`T(N)=o(N log N)`

and

`max intermediate condition <= R(N)`.

So in this transparent macro model the condition budget can, in principle, diverge **arbitrarily slowly**.

This does not contradict Ailon's lower bound: the corresponding speedup must also diverge sufficiently slowly. The construction makes no claim of a fixed positive power saving under a constant condition bound.

---

## 7. Effectivity of `K(B)`

To turn the staircase from a nonuniform existence argument into one fixed algorithm, it suffices to compute any finite upper bound on `K(B)` for each printed local block.

Every elementary shear has the form

`E = I + alpha e_j e_i^T`, `i != j`,

with inverse `I - alpha e_j e_i^T`. Therefore

`||E||_2 <= 1+|alpha|`,
`||E^{-1}||_2 <= 1+|alpha|`,

so

`kappa_2(E) <= (1+|alpha|)^2`.

For a word of shears, multiplying these elementary bounds gives a crude but finite prefix-condition bound.

The #130 constants are explicitly prepared from rationals and specified roots of unity. Thus the remaining effectivity task is to produce certified upper bounds on the magnitudes of the printed shear coefficients. The bounds can be extremely crude; the slow-radix diagonalization absorbs any finite growth by moving the threshold `N_t` farther out.

A finite program generating the staircase may include the time needed to compute these bounds in the threshold choice itself: choose `N_t` larger than both the condition threshold and the preprocessing time. This is asymptotic and will have astronomical crossover points.

---

## 8. Model caveat

Ailon's principal theorem is phrased for defining matrices of a layered computation and also has an extension with extra space. Our transparent construction uses two `N`-coordinate data banks plus reused local scratch and keeps the entire completed macro transformation unitary on those banks while restoring scratch.

This is deliberately close to the extra-space well-conditioned setting, but **a line-by-line model identification has not yet been written**. Until that is done, the conditioned macro theorem should be stated in its own explicit square full-state model rather than claimed as a theorem inside Ailon's exact formalism.

---

## 9. What is genuinely new in this research branch

We are no longer trying to improve #130's finite certificate. We use the existing exact sub-`B log B` transform only as a local black box.

The research object is the composition principle:

> transparentize the local transform; complete every macro-stage as a unitary bank exchange; let the macro radix grow slowly so local instability is reset rather than multiplied.

The next work is proof-model alignment and an explicit computable `K(B)` extractor, not another center/side/rank optimization.
