# Retuning the explicit exact-DFT network: h = 24 candidate

**Date:** 2026-10-09  
**Status:** proof-level candidate derived by parameterizing the published construction; arithmetic checked by script. This retuned constant choice has **not** been separately Lean-formalized or peer reviewed.

## Result

The explicit OpenAI exact-DFT manuscript fixes `h=100`, with

- `m=h^3=1,000,000`,
- `W_*=2^71`,
- `Delta=6,871,402,692,000,000`,
- `theta = log_m(m - Delta/W_*) = 0.999999999999789...`.

The network proof itself gives, for the same triple construction at a general fixed integer `h`,

`v = C(h,3)`

`d_nbr = C(h-3,3) + 3(h-3)`

`N0 = v^3`

`I0 = 3 v^2`

`W = 2 N0 + I0 (v d_nbr + h + 1)`

`m = h^3`

and, crucially,

`Delta = 2 v^2 (v - 3h(h+1))`.

Thus the margin is positive as soon as

`C(h,3) > 3h(h+1)`.

The smallest integer satisfying this is `h=22`. A sweep of the unchanged construction shows a substantially better exponent at **h=24**, helped by the fact that its physical role count lies just below a power of two.

## h = 24 constants

For `h=24`:

- `v = C(24,3) = 2024`
- `N0 = 8,291,469,824`
- `I0 = 12,289,728`
- `d_nbr = C(21,3)+63 = 1393`
- `m = 24^3 = 13,824`
- `W = 34,666,942,577,344`
- `W_* = 2^45 = 35,184,372,088,832`
- `Delta = 1,835,266,048`
- `S = W_* m - Delta = 486,388,757,920,747,520`
- `lambda = m - Delta/W_* = 13,823.9999478386...`
- `theta = log_m(lambda) = 0.9999999996042389976...`
- `1-theta = 3.957610023859...e-10`

This increases the raw logarithmic exponent saving by about **1,879x** relative to the manuscript's `h=100` choice.

## Why the proof appears to generalize

The scalar exchange identity uses only triples and the intersection value `|S intersect T|`; it does not rely on `h=100`.

The neighbor count generalizes from `C(97,3)+3*97` to `C(h-3,3)+3(h-3)`.

The frame proof uses that triple indicators have odd norm, and that coordinate units exist outside supports of sizes at most 3 and 6. `h=24` easily satisfies these conditions. The exceptional tensor indicator still has Hamming weight `3^3=27`, which remains odd.

The residual-dimension proof explicitly derives the general formula

`Delta = 2 v^2 (v - 3h(h+1))`.

Exact batching only needs `W_*` to be a power of two. For `h=24`, `W_*=2^45`; replace every use of 71 by `p=45`. The base threshold becomes

`K = m(p+1) = 13,824 * 46 = 635,904`.

Then `f=floor(k/m) >= p+1`, so the number of transform fibers is divisible by `2^p=W_*`, exactly as in the original proof.

The synthesis appendix likewise changes the role-index contribution from 71 tensor axes to 45: its finite-win tensor exponent becomes `b=mf+45`. The inequality

`g <= b 2^(b-1) - (Delta f - 2H) 2^(mf-1)`

is unchanged in form and is strict for any fixed `f > 2H/Delta`.

All later Fourier synchronization, CRT, and Bluestein steps depend on this network only through the fixed exponent `theta`.

## Conservative improved corollary

Let

`epsilon = Delta/(m W_*) = 448063 / 118747255799808 = 3.7732493...e-9`.

Since

`1-theta = -log(1-epsilon)/log(m) > epsilon/log(m)`, 

the numerical value above gives `1-theta ~= 3.95761e-10`. Hence the same final absorption of the fixed `(log log n)^(4-theta)` factor gives, conservatively,

`T(n) = O(n (log n)^(1 - 3e-10)) = o(n log n)`.

This would improve the manuscript's displayed `1e-13` corollary by a factor of 3000 in the stated exponent decrement, while using the same proof architecture.

## What this does NOT mean

- It does not make the algorithm practical. The base threshold is still enormous (`k >= 635,904` for the tensor recursion), so the crossover is astronomical.
- It is not a stable floating-point FFT result.
- It does not change the exact-complex-register computation model.
- It is not yet independently formalized. The existing Lean artifact corresponds to the published constants, not this retuned choice.

## Reproduction

Run:

`python verify_h24.py`

and inspect `network_parameter_sweep.csv` for the integer sweep.
