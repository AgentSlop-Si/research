# Lookup tables and the N log N transform barrier

Research note dated 8 October 2026

## Main conclusion

Repeated lookup across transform levels can genuinely beat N log N for a constant-field Walsh–Hadamard transform. A proof that rules out replacing only the bottom FFT leaves does not rule out that algorithm. The decisive question is whether the state at every reused boundary stays small, and whether all numerical, routing, coefficient-selection, and preparation work is included.

The analysis below gives a precise batching criterion, an explicit finite-field example, and three concrete obstructions to transferring it directly to an ordinary complex FFT or NTT. It also identifies a narrowly testable research direction in the recent integer-multiplication framework. No new general sub-N-log-N complex DFT algorithm is established here.

## Claims and computational models

| Claim | Status and scope |
|---|---|
| Replace binary FFT leaves of length K by complete tables | Leaves Θ(N log(N/K)) ordinary combination work. Polynomial-size tables do not remove the leading asymptotic factor. |
| Constant-field WHT with repeated tables | Published O(N log N / log log N) bit-operation bound, with preparation charged, in Alman's RAM bit-cost model. |
| WHT over an extension of a fixed base field | A coordinatewise corollary survives; the field-extension degree multiplies the bit work. |
| Ordinary length-N NTT with explicit field-element outputs | Its field must contain N distinct roots; conventional output alone occupies Ω(N log N) bits. This says nothing comparable about field-operation counts. |
| Alman–Rao complex FFT | A leading-constant arithmetic improvement. Their stated reduction retains Θ(N log N) work even if its WHT calls were free. |
| Recent integer multiplication below n log n | The supplied project points to a specific 2026 manuscript and conditional community refinements. Its synthetic transforms and machine model need separate evaluation; it is not a theorem about an arbitrary scalar complex DFT. |

Here N denotes the number of transform coordinates; n denotes integer input bit length. Arithmetic operations, word operations, bit operations, and output encoding are different accounting systems.

## What the published lookup theorem actually establishes

Alman’s Theorem 3.2 works over fixed-size F_q. It sets K to a power of two of order log N/(2 log q), tabulates all q^K inputs to H_K, and applies that same table throughout the tensor decomposition H_N = H_K ⊗ ··· ⊗ H_K. A lookup reads and returns Θ(K) bits; it is not free. Table preparation is O(q^K K²), bounded by O(√N log²N). There are log_K N grouped layers, each using N/K lookups, so the online cost is O(N log N/log K). The paper also handles the leftover levels when log K does not divide log N. The model is RAM bit cost, not an asserted fixed-tape Turing-machine bound. [Alman, Sections 1.1 and 3](https://arxiv.org/html/2211.04643v1#S3)

## Why the leaf argument remains correct

Suppose only the original binary-input leaves are tabulated, and every higher radix-two combination is executed normally. A complete length-K table has K2^K scalar entries. Its online use, including reading the input and producing the output, leaves

T_leaf(N,K) = Θ(N + N log₂(N/K)).

If K2^K ≤ N^C for a fixed C, then K = O(log N). Consequently log(N/K) = log N − O(log log N), and T_leaf remains Θ(N log N). This is a statement about that restricted algorithm, even under generous unit-cost scalar accounting. Counting exact stored-value bit lengths cannot make it cheaper.

Alman’s batching removes groups of levels throughout the computation. It does not merely cut off the bottom of the recursion. The corresponding online expression is N log N/log K, not N log(N/K). Confusing those expressions discards the central mechanism.

## An explicit reuse example over F3

Let H4 map (a,b,c,d) to

(a+b+c+d, a−b+c−d, a+b−c−d, a−b−c+d),

with every value reduced modulo 3. Store the outputs for all 3⁴ = 81 possible input vectors. These are 324 field symbols of output data.

For a length-16 input, arrange the coordinates as four rows:

    1 0 1 0
    0 1 0 0
    0 0 1 1
    1 0 0 1

Four row lookups produce:

    2 2 0 0
    1 2 1 2
    2 0 1 0
    2 0 0 2

Now use the same table on the four columns. For example, its already-stored entry for (2,1,2,2) returns (1,1,2,1). The completed result is:

    1 1 2 1
    1 0 0 2
    2 1 0 0
    1 0 1 0

This computes H4 ⊗ H4 = H16 using eight table calls. All four binary butterfly levels are included. The intermediate values need not remain binary; they remain in F3, which is exactly the domain the table covers. A fixed small example demonstrates correctness, not an asymptotic speedup; the asymptotic choice lets K grow with N.

## A reusable batching criterion

The following is a direct accounting lemma, not a novelty claim.

Assume an N-wire transform of depth D can be grouped into blocks of r levels, each acting on disjoint K = 2^r wires. Each wire state uses b bits. Suppose there are R distinct block maps across the full schedule, each evaluable during preparation in C(K,b) bit operations. A complete table construction costs at most

P = O(R · 2^(bK) · [C(K,b) + bK]).

If each known table can be queried and its result materialized in O(bK), the online cost is

O(N b D / log₂ K) + routing + dispatch + encoding/decoding.

The proof counts N/K block calls per grouped layer and D/log₂K grouped layers. Any cost of choosing the block type, producing twiddles, obtaining the table, or moving state is additional unless already included.

For D = Θ(log N), an absolute o(N log N) bit bound requires b = o(log K), negligible preparation, and negligible extra work. K → ∞ alone is insufficient. A polynomial-size table is also insufficient if building it exceeds the claimed runtime. Nonuniform or amortized preparation must be labeled as such.

For whole-field-element tables, the number of valid keys is q^K, rather than every bK-bit string. Under the conventional b = ⌈log₂q⌉ encoding, when b = Θ(log N), polynomial table size forces K = O(1). This is a precise obstruction to that table design, not a lower bound on every bit-sliced or symbolic algorithm.

## Three transfer tests

### Exact binary inputs do not preserve a small complex alphabet

For L = 2^t, let ω be a primitive Lth complex root and consider one DFT coefficient of binary inputs:

y = Σ_(j=0)^(L−1) x_j ω^j.

Since the cyclotomic polynomial is z^(L/2)+1,

y = Σ_(j=0)^(L/2−1) (x_j − x_(j+L/2)) ω^j.

The powers 1, ω, …, ω^(L/2−1) are linearly independent over Q. Each difference independently takes values −1, 0, or 1. Hence this single coefficient has exactly 3^(L/2) attainable values. The counts begin 9, 81, 6561 for L = 4, 8, 16.

This independently proves that exact scalar-state closure fails rapidly, even with binary original inputs. It does not prove a lower bound for shared symbolic encodings of the entire output, whose coefficients are correlated.

### Twiddles cannot simply be moved outside a Hadamard core

For a matrix with nonzero entries, a four-entry cross-ratio A_ij A_kl/(A_il A_kj) is invariant under row and column scaling. Permutations only rearrange the set of such ratios. Every Hadamard-matrix ratio is ±1. A cyclic DFT matrix has the ratio F_00 F_11/(F_01 F_10) = ω, or ω⁻¹ under the opposite sign convention.

For N > 2 this is not ±1. Therefore no row/column scaling and permutation turns the cyclic DFT into H_N. The proposed shortcut already fails at length four. This rules out that particular factorization, not deeper factorizations containing multiple layers.

### Growing fields require careful representation accounting

A length-N multiplicative NTT over F_Q requires N | (Q−1), so Q ≥ N+1. Explicitly writing N fixed-width outputs therefore costs Ω(N log N) bits. This does not prohibit o(N log N) field operations or word operations.

There is an important positive exception for WHT. In F_(p^s), its coefficients ±1 belong to the base field F_p. When inputs and outputs use a fixed F_p basis, run the same WHT separately on the s coordinate arrays. For fixed odd p, this gives O(sN log N/log log N) bit work, plus charged linear-volume layout conversion, using one common table. Conversion from some other field representation would be an additional obligation. This is an elementary coordinatewise corollary. NTT twiddles usually mix these basis coordinates, so this corollary does not supply an NTT algorithm.

Moreover, fixed-base-field extension degree can be large: for p=3 and N=2^t with t≥3, a primitive Nth root requires s divisible by 2^(t−2). For p=2, extension fields have no even-order multiplicative roots. A fixed practical NTT modulus supports only finitely many power-of-two lengths; an asymptotic family must specify what grows.

## Arithmetic FFT improvements and finite precision

Alman–Rao prove a complex FFT using (15/4)N log₂N + O(N) real arithmetic operations. Their Lemma 1.1 gives coefficient (2c/3 + 28/9) when the requisite WHT costs cN log₂N + O(N). Thus even formally setting c=0 leaves a positive N log N term. Also, a finite-field table cannot substitute for a call on arbitrary real values. [Alman and Rao, introduction and Lemma 1.1](https://arxiv.org/html/2211.06459v2#S1)

A rounded fixed-b-bit FFT is a finite-state computation, but its numerical guarantee must be stated. For bounded inputs and a 1/N-normalized transform, contractive butterflies give a simple accumulated-error upper bound proportional to log N · 2^(−b). This bound is satisfied with b = O(log log N + log(1/ε)) for fixed absolute accuracy ε, up to guard and representation details. This is not a lower bound on necessary precision.

Substituting b of order log log N into the batching criterion consumes the apparent log log N bit saving. A practical or word-operation speedup could remain. A new absolute bit bound requires a sharper mechanism, not silently holding precision fixed while claiming an unchanged exact or uniform-accuracy problem.

## A concrete research hypothesis

The most credible next target is shared algebraic work in a specified synthetic-transform representation, rather than repeated numerical values.

The pinned 2026 integer-multiplication manuscript uses normalized multidimensional transforms in C[y]/(y^r+1). Powers of y act as signed permutations of coefficient lists. Its transform section explicitly charges layout conversion and numerical precision and groups butterfly work across dimensions. This is a relevant way to handle twiddles, but it changes the representation and the task being accelerated. [Pinned transform construction](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Integer-multiplication-below-n-log-n-September-23-2026/build/sections/06-transforms.tex)

The community repository currently reports a conditional integer-multiplication exponent improvement and names its audited witness. It explicitly assumes the upstream framework and distinguishes its checks from full formal verification or independent peer review. These are claims with identifiable proof obligations, not evidence that an unrestricted complex DFT has been accelerated. [Project evidence and limits](https://github.com/CrocSwap/integer-mult-bounds#evidence-and-limits)

**Hypothesis to test:** Within that specified layer interface, a shared-sum implementation that fuses a short sequence of normalized butterfly layers and signed-permutation twiddles can improve the fully charged recursive profile over composing the chosen baseline layers. No novelty or improvement is assumed.

**First bounded milestone:** Reconstruct one small finite baseline network independently, then check a proposed fused network using exact rational linear algebra. Verify the whole map on input and dirty scratch, not only the desired output coordinates. Include every copied role, frame transition, sign, restoration, and cleanup. Compute the resulting weighted recurrence certificate under the same parameter convention as the source, including its strict saving inequality. Prefer the source's actual certified weights over an unweighted gate count.

Reject the candidate if the exact maps differ, dirty scratch leaks into the output, the resource accounting exceeds the baseline, or the strict recurrence inequality fails. A bounded exhaustive search with an independently checked UNSAT certificate could reject the chosen circuit grammar at that size; an unsuccessful heuristic search cannot.

A successful small circuit is only a candidate. An asymptotic result still needs a uniform scalable family, a composition proof, precision control, table or circuit preparation, tape movement, normalization, and every remaining transform cost. A general scalar-DFT claim additionally needs a fully charged reduction into and out of the synthetic representation.

## Research result of this pass

The leaf-only obstruction is correctly scoped. The repeated-stage mechanism is explicit. The F3 example checks the closed-state requirement constructively. Exact complex scalar closure and simple Hadamard-core equivalence fail by short proofs. Extension-field WHT retains a valid coordinatewise improvement, while ordinary explicit NTT output already sets a different bit-size baseline. The next experiment has a precise object, verification rule, rejection conditions, and an identifiable gap between a finite witness and an asymptotic theorem.

No new implementation or machine-assisted circuit search was run for this note. Its new calculations are elementary deductions and research tests, not claims of publication novelty.
