# OpenAI #130 + Adaptive FFT: sparse/low-rank research merger

A reproducible **algebraic merger** of our existing AdaptiveFFT cache with a
Cooley–Tukey sparse-input decomposition. The theoretical bound uses OpenAI #130
**as a hypothetical exact-DFT backend** for the small transforms. No actual
implementation of #130 is included; SciPy/NumPy implement those transforms
for testing and are still `O(N log k)` in the general numerical setting.

Read [RESEARCH.md](RESEARCH.md) for derivation, assumptions and results.

## Files
- `hybrid_sparse.py`: group k sparse changes into N/b length-b transforms.
- `adapter.py`: `HybridAdaptiveFFT`, extending our existing research engine.
- `adaptive_fft.py`: previous adaptive reuse engine, unchanged.
- `tests/test_hybrid.py`: numerical correctness vs NumPy and original engine.
- `tests/test_exact_modular.py`: EXACT integer-mod-prime decomposition checks.
- `tests/test_adapter.py`: adapter compatibility.
- `benchmark.py`: SciPy/NumPy timings, no claim to benchmark #130.
- `benchmark_results.json`: captured local measurements.

## Run
```bash
pip install numpy scipy
python -m unittest discover -s tests -v
python benchmark.py
```

## Quick example
```python
import numpy as np
from adapter import HybridAdaptiveFFT

N = 1024
eng = HybridAdaptiveFFT(mode='plain')
x = np.arange(N, dtype=float)
previous_spectrum = eng.fft(x)

# The producer explicitly knows the change; no comparison/search scan.
updates = [(7, 2.5), (200, -1.0)]
updated_spectrum, plan = eng.fft_from_delta(previous_spectrum, updates)

x[7] += 2.5
x[200] -= 1.0
assert np.allclose(updated_spectrum, np.fft.fft(x))
print(plan)
```

The mathematical power-saving composition uses an **unimplemented exact
DFT oracle** for block size b. This project is not a new uniform Fourier or
integer-multiplication complexity theorem; it is a conditional corollary
and a verified prototype of the supporting algebra.

## Practical known-position streaming updates

```python
from scipy.fft import rfft
from prepared_update import PreparedPointEdit
import numpy as np

x=np.arange(65536,dtype=float)
cache=rfft(x)
updater=PreparedPointEdit(len(x), index=7)

for delta in [0.25, -0.5, 1.0]:
    x[7] += delta
    cache = updater.update(cache,delta)

assert np.allclose(cache,rfft(x))
```

The `benchmark_prepared.py` experiment **charges initial spectrum computation
and phase preparation** and observed 4.6–10.7x speedups for 40 known-location
edits on this local runtime. That is an ordinary dynamic Fourier technique,
not a performance measurement of OpenAI #130.

## Projected relation-aware continuation

The next research layer is in [RELATION_VIEW_RESEARCH.md](RELATION_VIEW_RESEARCH.md):

- `relation_view.py`: dynamic coefficient + sparse-residual state with persistent selected-bin views.
- `projected_fourier.py`: stores only an `r x q` basis projection; query planner uses replay vs rebuild.
- `pruned_output.py`: reusable first-K and contiguous-band output-pruned DFT plans.
- `relation_view_bench.cpp`: compiled benchmark validating the `H ~ r+k` crossover.
- `benchmark_pruned_plan.py`, `benchmark_registration.py`, `benchmark_end_to_end_view.py`: reproducible performance/memory experiments.

This path deliberately targets producer-aware, consumer-aware Fourier workloads rather than the current integer-multiplication kappa optimization race.
