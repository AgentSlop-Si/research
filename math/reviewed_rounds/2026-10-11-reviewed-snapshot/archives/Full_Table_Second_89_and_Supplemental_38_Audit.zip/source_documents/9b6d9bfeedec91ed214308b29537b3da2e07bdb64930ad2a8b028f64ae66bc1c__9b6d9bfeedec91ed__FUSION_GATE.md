# Exact fusion gate: sparse surrogates plus reusable graph corrections

The approximate signed-atom decoder and the existing exact low-defect graph solvers can be composed correctly. The resulting identity is useful on certified inputs, but their existing guarantees do not combine into an exact sub-N-log-N transform for arbitrary inputs. The following statements identify precisely what the missing mechanism must change. They are restrictions on these compositions, not lower bounds for unrestricted FFT algorithms.

## 1. A sparse surrogate cannot erase a dense local defect

For any vector v, write `supp(v)` for its nonzero coordinates and `|v|_0` for their count. Let D be a linear map with at most c nonzeros per column. For any x and any k-sparse y,

    |D y|_0 <= c k,
    |D(x-y)|_0 >= |D x|_0 - c k.                     (1)

Proof: D y is a linear combination of at most k columns. A coordinate of D x can disappear in D x-D y only inside supp(D y). No randomness, independence, approximation assumption, or choice of y is needed. Consequently (1) applies even when y is chosen adversarially after inspecting x and D.

For an invertible monomial matrix M and `D_lambda=I-lambda M`, every column has at most two nonzeros. Therefore

    |(I-lambda M)(x-y)|_0
       >= |(I-lambda M)x|_0 - 2k.                 (2)

The signed-atom surrogate uses at most K distinct coordinates, even if some samples collide or cancel. With K=O(log N), (2) only permits an O(log N) reduction in defect support. The simpler residual support bound is `|x-y|_0 >= |x|_0-k`.

This is immediately relevant to the existing one-defect/constant-defect exact routes: a generic linear-size defect does not become constant-sized merely because its Fourier approximation was obtained from a logarithmic-size surrogate.

## 2. An explicit witness defeats every cyclic shift and every lambda

Let g be a field element of multiplicative order

    ord(g) > 2(N-1)^2,

and put `x_i=g^(i^2)` for `0<=i<N`. Let `(S^s x)_i=x_((i+s) mod N)`, with `1<=s<N`.

For a fixed s, the N ratios `x_i/(S^s x)_i` are pairwise distinct. Before wraparound their exponents are

    -2 s i - s^2,                  0<=i<N-s,

which are distinct and negative. After wraparound they are

    2(N-s)i - (N-s)^2,             N-s<=i<N,

which are distinct and positive. All exponents lie in `[-(N-1)^2,(N-1)^2]`, so the order condition prevents modular collisions. Thus, simultaneously for every nonzero cyclic shift s and every field scalar lambda,

    |(I-lambda S^s)x|_0 >= N-1.

Combining this with (2), every k-sparse surrogate y satisfies

    |(I-lambda S^s)(x-y)|_0 >= N-1-2k              (3)

for every s and lambda, including choices made after seeing x and y. To reach a defect cap S0 on this witness one needs at least `(N-1-S0)/2` surrogate coordinates. The logarithmic-sample decoder does not provide that.

The bound can be attained. In F_257 with primitive generator g=3 and N=8, take shift s=2, lambda=g^(-12), and a one-coordinate correction `y_3=g^9(1-g^4)`. The residual defect has exactly `N-1-2=5` nonzeros. The audit verifies this and exhaustively checks all 257 lambda values for all seven nonzero shifts on a collection of sparse corrections. Distinct-ratio checks prove the all-lambda claim; the arbitrary-y support lemma is analytic, not inferred from finite testing.

## 3. A finite graph dictionary does not remove the one-step witness

For a general monomial M, `(Mx)_i=w_i x_(pi(i))`. On a vector with every coordinate nonzero, a zero of `(I-lambda M)x` means

    lambda = x_i / (w_i x_(pi(i))).

If pi has no fixed points, these ratio functions are pairwise distinct as rational functions. Equality of two ratios is a nonzero degree-two polynomial condition. Over the complex numbers, a generic x avoids all such equalities simultaneously for every matrix in any fixed finite dictionary of derangements. Each candidate then has defect support at least N-1 for every lambda, and (2) applies uniformly to every dictionary choice.

For a finite field F_q and a dictionary of J derangements, the elementary polynomial root bound gives a sufficient existence condition

    q > N + J N(N-1).

Indeed, a uniformly random x has a zero coordinate with probability at most N/q. The sum of degree-two ratio-collision probabilities over all J*N(N-1)/2 pairs is at most J*N(N-1)/q. Their sum is less than one. This is an existence statement, not an efficient deterministic search bound or an assumed free preprocessing step.

Fixed points require care. If a monomial matrix has fixed-point weights with maximum repeated reciprocal multiplicity c_M, then generic ratio multiplicity is at most `max(1,c_M)` and the bound becomes `N-max(1,c_M)`. For M=I, lambda=1 annihilates every vector; it supplies no reconstruction information because its kernel has dimension N. A defect-zero identity matrix is not a fast transform. Matrices chosen from an unrestricted input-dependent continuous family are outside the finite-dictionary statement.

## 4. Chains: a composition dimension gate

Fix N and a finite, input-independent dictionary of monomial matrices. This includes all affine monomial graphs

    (M_(a,b,c) v)_i = q^(c i) v_((a i+b) mod N),

where q is fixed, a,b,c are residues modulo N, and gcd(a,N)=1. Consider a chain of d invertible factors

    D_j = I-lambda_j M_j,
    u = D_d ... D_1 x,
    |u|_0 <= s.

For fixed graph choices and a fixed support T of u, every accepted input has the representation

    x = D_1^(-1) ... D_d^(-1) E_T z,

where z consists of at most s free residual coefficients. Every coordinate of this expression is a rational function of the d scalar parameters lambda_j and the s entries of z, because matrix inversion is adjugate divided by determinant. Its image has algebraic dimension at most d+s. If all lambda values are algebraic/rational functions of r shared free parameters, the bound is r+s instead.

There are finitely many graph choices and residual supports. A finite union of these rational images cannot contain a generic vector in C^N whenever

    d+s < N,                                      (4)

or `r+s<N` in the shared-parameter version. This continues to hold when the algorithm adaptively chooses a graph sequence, support, and lambda values after reading x: all possible choices already occur in that finite union.

An elementary justification avoids treating dimension as an unexplained oracle. A rational map in m<N variables has algebraically dependent N coordinate functions. After clearing denominators, the number of output monomials of degree at most t grows as t^N, while their substituted numerators lie in a polynomial space of dimension O(t^m). For sufficiently large t there is a nontrivial polynomial relation among the outputs. Each image therefore lies inside a proper algebraic zero set. Multiplying the finitely many nonzero relation polynomials gives a nonzero polynomial vanishing on the union; its complement is nonempty and Zariski open.

The actual invertible-chain code excludes singular factors. Singular branches cannot silently be added to (4): their kernel amplitudes are extra free information that must be retained and reconstructed. For example, a singular product A with nullity h can add up to h free kernel coefficients, giving a corresponding s+h-dimensional linear solution family for fixed A. Any new singular-chain proposal must count those degrees of freedom and their decoding cost.

Equation (4) is an expressiveness obstruction for the specified exact certificates. It is not an arithmetic-circuit lower bound, and it does not rule out a different global factorization, a graph with additional independent state, or a correction computed by a new transform algorithm.

## 5. Repeating the approximate pass does not presently give exactness

The available Fourier approximation bounds the transformed residual; it does not give a contraction of the original residual in the l1 norm used by the next sampling guarantee. This failure is explicit. For the real vector x=(1,...,1), K<N signed-atom samples produce positive y with total mass N and support S<=K. Every occupied coordinate has value at least N/K>1. Hence

    ||x-y||_1 = 2(N-S) >= 2(N-K).

The residual is still nonzero at every coordinate. For K=o(N), its l1 norm is nearly twice the original norm, even though the Fourier sample average has the advertised probabilistic additive accuracy.

After T sparse corrections with a total of K_total coordinate occurrences, their sum has support at most K_total. Replacing k by K_total in (1)-(3) shows exactly how much local defect can have changed. On the explicit witness, reaching constant defect requires K_total=Omega(N). If every refinement explicitly computes all N outputs at O(N) cost, repeatedly using O(log N) new atoms costs at least Omega(N^2/log N) in this particular full-pass scheme. Aggregating corrections before decoding avoids repeated outputs but leaves the logarithmic-sample regime of the proved linear decoder. This does not rule out a new shared computation across refinements; that shared computation needs its own complete bound.

## 6. Integer rounding and shrinking error

The DFT of an integer vector generally has noninteger algebraic coordinates. It cannot be made exact just by rounding each complex coordinate to the nearest integer. If a different target is known to lie on an integer lattice, an error certificate `epsilon*S` suffices for exact rounding only when it is strictly below one half (or half the relevant lattice spacing).

For a scale S=Theta(N), this requires epsilon=O(1/N). Substituting this into this construction's sufficient Monte-Carlo budget gives `K=Theta(N^2 log(N/delta))`, instead of K=O(log N). The fixed-accuracy linear-time theorem does not apply. This is a limitation of this sufficient error-and-cost proof, not a lower bound on all exact integer algorithms.

For example, let A and B be the unnormalized Fourier transforms of integer convolution inputs a,b. If their entrywise errors are bounded by `epsilon L_a` and `epsilon L_b`, then pointwise product errors are bounded by

    (2epsilon + epsilon^2) L_a L_b.

Even granting an exact inverse transform, the same expression bounds the coefficient error after averaging by 1/N. Certification of integer rounding through this estimate therefore needs that expression below 1/2, with additional budget required for an approximate inverse. A constant epsilon does not certify worst-case exact integer convolution when the masses grow.

## Useful next gate

A successful exact fusion now needs a concrete mechanism satisfying at least one of these checkable alternatives:

1. Produce an exact residual certificate on arbitrary inputs whose independent parameters and residual values cover N dimensions, while evaluating and decoding that information in o(N log N) total work.
2. Replace local sparse corrections by a shared graph operation that changes a linear-size defect cheaply, with every coefficient, lookup table, and kernel amplitude charged.
3. Prove an exact or adequately precise correction decoder with a cost bound that remains sub-N-log-N when accuracy depends on N; fixed-accuracy sampling alone is insufficient.

The existing methods still compose into a useful adaptive exact algorithm: inspect the fresh input, use a verified cheap graph route when its certificate passes, and fall back to the general transform otherwise. That composition preserves the structured-input gains. Its present arbitrary-input guarantee remains O(N log N).
