# Independent review: composed affine Fourier filters

Date: 2026-10-09. Reviewer: macro-audit agent, independently of the author.

**Conclusion: accepted after two small validation/accounting fixes.** The
ordered composition, common coefficient table, shared closure inverse, and
exact cost formula are correct in the stated field-operation model. This is
an exact all-output fast path for a verified family with supplied parameters.
Its all-input wrapper retains O(N log N) worst-case work.

## Algebra and order

For Mx[j]=q^(bj)x[aj+c], substitution l=aj+c gives

\[
(FMx)[k]=q^{-ca^{-1}(k+b)}(Fx)[a^{-1}(k+b)].
\]

Thus the source sequence L₁, then L₂, …, then L_d produces
u=L_d…L₁x and Fu=Lhat_d…Lhat₁Fx. Solving for Fx requires undoing Lhat_d
first and Lhat₁ last, exactly the reversed filter loop in the implementation.
Reversing the source filters instead would generally change the residual.

For dyadic N≥4, a=1 mod4 and odd b,c give full cycles in both coordinate
systems. The target permutation visits all residues, and therefore its edge
product is

\[
\prod_k\lambda q^{-c\pi(k)}
=\lambda^Nq^{-cN(N-1)/2}=-\lambda^N.
\]

The source cycle has the same product, using odd b instead of −c. Thus
1+λ^N is the correct closure denominator and exactly the nonsingularity
condition for both filters. Sharing its inverse between filters using the
same pool entry is valid regardless of their distinct affine graphs.
The two backward traversals solve the cycle even when λ=0; no division by
individual edge coefficients occurs.

## Exact cost

The independently recomputed accepted-query bill is

\[
N+rN+r(\log_2N+2)+2dN+2sN+d(4N+1),
\]

where s is the actual verified final support. It equals the implementation's
reported formula. For d=2,r=1,s=1 it is exactly 16N+log₂N+4. Parameters are
supplied and paid for when tables and inverses are created; their discovery
is not included or claimed.

Every source layer is evaluated in full, including dense intermediate
residuals. All N final outputs are produced. Root-power preparation and
primitive-order validation are included. Word indexing, graph traversal,
parameter normalization, and Euclidean index inversion are separately
bounded under the stated O(log N)-bit descriptor contract. These are field
operation counts, not exact-complex bit costs or wall-clock speed claims.

## Fixes made during review

1. Materialization of the supplied filter and lambda iterables now precedes
   the nonempty check. Empty generators previously bypassed that check.
2. The fallback now records its ordinary FFT work in the stages map as well
   as the overall field-operation tally. The complete stage sum now equals
   the independently observed total on successful fallbacks.

Affine descriptors are also reduced modulo N after validation, and the
README explicitly bounds their input word lengths. No algebraic correction
to the transform or shared closure was required.

## Focused exact checks

`review_edge_checks.py` imports only the evaluated public implementation.
It supplies its own modular field-operation probe, direct DFT, matrix
construction, matrix inversion, and source-filter evaluator. It does not
reuse the author's structured input generator or audit helpers.

The checks pass:

- all 625 inputs over F5 at N=4, each with defect budgets zero and one:
  1,250 checks, 18 exact acceptances and 1,232 correct declines;
- four independently Gaussian-generated N=8 cases, covering one shared
  parameter, equal values in distinct pool entries, a zero parameter,
  negative descriptors, and a depth-three composition;
- the N=8 shared-parameter case returns all outputs in 135 operations,
  exactly 16·8+3+4; its correct residual has support one, whereas the swapped
  source order has support seven;
- both singular-parameter and excessive-defect fallbacks, including their
  complete independently traced field counts and stage sums;
- seven validation cases, including empty iterators, unused/out-of-range
  pool entries, invalid shift/budget, and a nonprimitive root.

These are targeted additions to the inspected main audit, not a duplicate
run of its large benchmarks. The code and dependency hashes are recorded in
`review_edge_results.json` and below.

## Coverage limitation

For fixed finite discrete graph choices and defect support, accepted x is
L₁⁻¹…L_d⁻¹u. On the nonsingular domain its coordinates are rational functions
of at most r supplied scalar parameters and s residual values. Its complex
Zariski closure therefore has dimension at most r+s. There are finitely many
choices when N,d,r,s are bounded. Consequently r+s<N cannot cover every
complex input, even if parameter search were free. This argument is correctly
restricted to the stated complex family, not asserted as a finite-field
counting result or a lower bound for general Fourier algorithms.

The concrete witness proves that composing the two tested constituent
graphs accepts an input that each of those graphs separately rejects.
It does not, by itself, prove rejection by every possible prior affine
graph. The README keeps this distinction. General exact sub-NlogN Fourier
evaluation has not been established.


## Final reviewed hashes

| File | SHA-256 |
|---|---|
| README.md | 837c563f27047531043692615f6cdfa3d59b395cff17446e60d10e6d7c261cd1 |
| composed_cycle.py | 6c52234f3a5f13501e70ac743817de70f58fbeddece0b5a4eec3059686ee5bf9 |
| run_audit.py | 02c184476675449ef416e14ddbd0cb7ce4030e1ff16c146b7a72d80cf5173f9a |
| review_edge_checks.py | 58599c273f7a6101c25dc228d9aca748be6ff1c43f4bb9e6f2ebeed2ef7f13e4 |
| ../fft_bidirectional_graph_research/affine_cycle.py | 0e9dbaf5691fcdc5c7daf69002b22470785dd4f7a9685d5dc50810421655dbd6 |
| ../fft_bidirectional_graph_research/exact_fields.py | c3f2eaf750d0be8c3b88f7132e7a60e0212c420dad1e16cff5c38c5bd5d44ed4 |
