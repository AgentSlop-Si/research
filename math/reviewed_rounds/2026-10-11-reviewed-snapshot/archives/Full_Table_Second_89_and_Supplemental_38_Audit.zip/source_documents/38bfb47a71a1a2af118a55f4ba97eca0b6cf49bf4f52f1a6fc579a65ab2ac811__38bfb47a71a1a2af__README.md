# FFT Stage-Template and Near-Linear Approximation Research

This experiment continues `FFT_RESEARCH_CANONICAL_CHECKPOINT_2026-10-09.md` and does **not** restart its catalogued failed/known approaches.

## Two distinct approximate models

**A. Full-table quantized FFT:** Inputs bounded by magnitude 1, outputs approximate `FFT(x)/N` to additive absolute error epsilon. In a `Theta(log N)`-word RAM with finite-precision arithmetic and tables charged, the group-stage construction conditionally yields `O(N log N/log log N)` online word work with `o(N)` table preprocessing for fixed epsilon. The enormous complete table is impractical at real sizes. Full tables are actually built only for tiny toy precisions; `lazy` mode is a demonstration, **not** a fast full-table realization.

**B. Random sampling/pruned FFT:** For arbitrary fresh magnitude<=1 inputs, a randomized estimator of the same normalized transform gives uniform-**across-bins** epsilon error with failure <=eta, and uses `O(N log log N)` arithmetic for fixed epsilon/eta, plus `N` outputs. Not exact; not a new sparse-FFT theorem or a practical beating of native libraries.

Neither result improves OpenAI's exact DFT #130 on its own terms. No threading or cached previous FFT input is used.

## Run

```bash
pip install numpy
cd fft_multilevel_quantized_tabulation
PYTHONPATH=. python -m unittest discover -s tests -v
python exact_group_audit.py
python benchmark.py
python cost_model.py
```

Start in `RESEARCH.md` for all definitions, accounting, proof sketches, rigorous scope, and a do-not-repeat boundary. `benchmark_results.json` is machine-produced and is not a proof of theoretical speedup.

## Code

- `lookup_fft.py`: exact group-phase identity as a numerical prototype, complete toy quantized tables, lazy miss-computing emulator.
- `exact_group_audit.py`: independent exact-modular Cooley-Tukey grouping checks.
- `cost_model.py`: asymptotic table size/word-access tradeoff for log2(N) sizes without allocating huge tables.
- `sampled_pruned_fft.py`: random sample estimator plus pruned full-spectrum sparse-input FFT.
- `tests/`: independent grouping, quantization, exact modular, sparse-FFT, sampling checks.
- `benchmark.py`: exploratory data capture and realistic negative controls.

All results are exploratory research. This package is not a production FFT library.
