"""Fresh Q30 route controls; no author/inherited program imported or executed."""
from pathlib import Path
from fractions import Fraction
import json, math, random
import mpmath as mp
ROOT=Path(__file__).resolve().parent
rng=random.Random(13281328)

def rnd(a,d):
    sg=-1 if a<0 else 1
    q,r=divmod(abs(a),d)
    return sg*(q+(2*r>=d))
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def cmul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def mul(a,b,h):
    v=cmul(a,b); s=1<<h
    return (rnd(v[0],s),rnd(v[1],s))
def conj(a): return (a[0],-a[1])
def naive(a,b):
    n=len(a); out=[(0,0)]*n
    for j in range(n):
        for k in range(n): out[(j+k)%n]=add(out[(j+k)%n],cmul(a[j],b[k]))
    return out

def pack(a,ell):
    # Test-sized integer instrumentation. Production packing uses indexed limbs,
    # as explicitly required by the report; this helper has no linear-time claim.
    return sum(x<<(ell*j) for j,x in enumerate(a))

def packed(a,b,ell):
    n=len(a); mask=(1<<ell)-1
    ar=[[max(s*z[t],0) for z in a] for t in range(2) for s in (1,-1)]
    br=[[max(s*z[t],0) for z in b] for t in range(2) for s in (1,-1)]
    raw=[[0]*(2*n-1) for _ in range(2)]
    calls=0
    for ia in range(4):
        for ib in range(4):
            pa,pb=ia//2,ib//2
            sign=(-1 if ia%2 else 1)*(-1 if ib%2 else 1)
            if pa==pb==1: sign=-sign
            target=(pa+pb)%2
            val=pack(ar[ia],ell)*pack(br[ib],ell); calls+=1
            for k in range(2*n-1): raw[target][k]+=sign*((val>>(ell*k))&mask)
    out=[]
    for k in range(n):
        out.append(tuple(raw[t][k]+(raw[t][k+n] if k+n<2*n-1 else 0) for t in (0,1)))
    assert calls==16
    return out

results={'status':'PASS','policy':'Fresh code only. Imported standard libraries and mpmath, never inherited research programs.'}
exact=[]
for D in (1,2,44,257):
    for N in list(range(5,1026,2))+[4097,65537,2**30+1,2**128+1]:
        n=N.bit_length(); h=(D+10)*n+32; ell=2*h+(D+2)*n+16
        Delta=Fraction(32*N*N,1<<h); Hupper=Fraction(N*(1<<(D*n)),1<<h)
        err=Fraction(128*N**4+2*N*N*(1<<(D*n)),1<<h)
        assert Delta+Hupper<=1 and N*Delta<=1 and N*N*8<1<<h
        assert err < Fraction(1,1<<45)
        assert N*(1<<(2*h+D*n+5)) < 1<<ell
        if N>=17:
            m=N//8
            assert 12*m>=N
            assert Fraction(N,1<<(2*D*n+1)) < Fraction(1,64)
            # Exact arithmetic versions, also covering huge N.
            assert Fraction(48*m*m-m*N,256*N)>=Fraction(N,1024)
            assert Fraction(27*m*m-m*N,144*N)>=Fraction(5*N,6912)
        exact.append({'D':D,'N':N,'n':n,'h':h,'ell':ell})
results['exact_parameter_cases']=len(exact)
results['parameter_ranges']={'D':[1,2,44,257],'N':'all odd 5..1025 plus 4097,65537,2^30+1,2^128+1'}

packs=[]; negatives=0
for N in (5,7,9,17,31,33,65):
    for D in (1,3):
        n=N.bit_length(); h=(D+10)*n+32; ell=2*h+(D+2)*n+16
        for mode in range(3):
            a=[(rng.randrange(-(1<<(h+2)),1<<(h+2)),rng.randrange(-(1<<(h+2)),1<<(h+2))) for _ in range(N)]
            b=[(rng.randrange(-(1<<(h+D*n)),1<<(h+D*n)),rng.randrange(-(1<<(h+D*n)),1<<(h+D*n))) for _ in range(N)]
            if mode==1:
                a=[(((-1)**j)*(1<<(h+2)),0) for j in range(N)]
                b=[(0,((-1)**j)*(1<<(h+D*n))) for j in range(N)]
            if mode==2:
                a=[(0,0)]*N; b=[(0,0)]*N; a[-1]=(7,-3); b[-1]=(-9,11)
            out=packed(a,b,ell); ref=naive(a,b); assert out==ref
            packs.append({'N':N,'D':D,'mode':mode,'products':16})
        # A deliberately undersized radix must corrupt this nonnegative product.
        a=[(3,0)]*N; b=[(3,0)]*N
        assert packed(a,b,2)!=naive(a,b); negatives+=1
        # Omitting cyclic folding loses the only nonzero high-degree coefficient.
        assert (0,0)!=cmul((7,-3),(-9,11)); negatives+=1
results['exact_packing_cases']=len(packs)
results['packing_products_per_case']=16
results['negative_controls']=negatives

canonical=[]
for D in (1,3):
  for N in (5,9,17,33,65):
    n=N.bit_length(); h=(D+10)*n+32; ell=2*h+(D+2)*n+16; S=1<<h
    mp.mp.dps=int(h*.31)+90
    q=mp.exp(-2j*mp.pi/N); c=mp.cos(mp.pi/N)
    def seed(z):
        def r(x): return int(mp.floor(x+mp.mpf('.5'))) if x>=0 else -int(mp.floor(-x+mp.mpf('.5')))
        return (r(mp.re(z)*S),r(mp.im(z)*S))
    def val(x,scale=S): return mp.mpc(x[0],x[1])/scale
    qh=seed(q); ch=seed(c)[0]; phase=(S,0); chirp=(S,0); As=[];Bs=[];Ts=[]
    for j in range(N):
        As.append(chirp)
        Bs.append(mul(chirp,mul(phase,phase,h),h))
        Ts.append(mul(conj(chirp),(2*phase[0]+2*ch,0),h))
        chirp=mul(chirp,phase,h); phase=mul(phase,qh,h)
    delta=mp.mpf(32*N*N)/S
    errA=max(abs(val(As[j])-q**(j*(j-1)//2)) for j in range(N))
    errB=max(abs(val(Bs[j])-q**(j*(j+3)//2)) for j in range(N))
    errT=max(abs(val(Ts[j])-q**(-j*(j-1)//2)*(q**j+2*c+q**(-j))) for j in range(N))
    assert max(errA,errB,errT)<=delta
    for mode in range(3):
        if mode==0: z=[(0,0)]*N; z[-1]=(1<<(h-D*n),0)
        elif mode==1: z=[(((-1)**j)*(1<<(h+D*n)),1<<(h-D*n)) for j in range(N)]
        else:
            cap=min(100,(1<<(2*D*n))-1)
            z=[(rng.randrange(-cap,cap+1)<<(h-D*n),rng.randrange(-cap,cap+1)<<(h-D*n)) for _ in range(N)]
        assert all(abs(a)<=1<<(h+D*n) and abs(b)<=1<<(h+D*n) for a,b in z)
        vs=[mul(Bs[j],z[j],h) for j in range(N)]
        conv=packed(Ts,vs,ell); assert conv==naive(Ts,vs)
        w=[]
        for j in range(N):
            vv=cmul(As[j],conv[j]); w.append((rnd(vv[0],S*S),rnd(vv[1],S*S)))
        zz=[val(vv) for vv in z]
        ref=[sum(q**(k*j)*(q**(2*j-k)+2*c*q**j+q**k)*zz[j] for j in range(N)) for k in range(N)]
        rel=mp.sqrt(sum(abs(val(w[k])-ref[k])**2 for k in range(N))/sum(abs(vv)**2 for vv in ref))
        bd=mp.mpf(128*N**4+2*N*N*(1<<(D*n)))/S
        assert rel<bd
        canonical.append({'N':N,'D':D,'mode':mode,'relative_error':mp.nstr(rel,12),'proven_envelope':mp.nstr(bd,12),'max_coefficient_error_over_Delta':mp.nstr(max(errA,errB,errT)/delta,12)})
results['canonical_numerical_cases']=canonical
results['numerical_scope']='High precision corroboration only, not interval-certified seeds or stability proof. Production theorem uses certified seed construction in REPORT.md.'
results['execution_scope']='The test-sized packing helper uses Python growing integer shifts and generic multiplication and is not claimed linear-time or FFT-free. Exact finite checks only; no backend performance claim.'
(ROOT/'CONTROL_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v for k,v in results.items() if k!='canonical_numerical_cases'},indent=2))
print('Canonical numerical cases:',len(canonical))
