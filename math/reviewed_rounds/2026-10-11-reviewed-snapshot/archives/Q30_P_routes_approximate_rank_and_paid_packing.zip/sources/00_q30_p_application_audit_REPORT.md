# Q30 b=1: the remaining P application is Fourier-equivalent

11 October 2026. Existing-task algebraic audit. No new intake, fusion, FFT, novelty claim, or unrestricted lower bound is proposed. This report does not review or change the separately reviewed outer-chirp inverse contract.

## Result

P has substantial exact structure beyond its N(N-2) nonzero entries. It is simultaneously a three-diagonal output filter of the Fourier transform and a chirp-gauged circulant. Both descriptions retain a Fourier-equivalent arbitrary-input operation. They supply an O(N log N) conventional route, not an independent O(N) route.

The exact identities below prove that P and F have the same arithmetic-application complexity up to O(N) overhead in the exact unit-cost field model. This is an equivalence, not a Fourier lower bound. A finite-word equivalence must additionally pay coefficient construction, input/output representation, stable solve directions and the relevant error norm; the exact identity is not that theorem.

Two restricted shortcuts are ruled out: a rational function of the cyclic shift with bounded numerator/denominator bandwidth, and an exact bounded-rank off-diagonal representation. A cheap coefficient recurrence by itself also fails to close the arbitrary-input convolution.

The final composition needs careful wording. A fixed relative Q-inverse norm guarantee alone can lose a factor kappa(Q)=Theta(N), but the actual solver need not realize those adverse directions. The exact useful condition is its relative Q residual. If that residual is rho and the P executor has relative error eta, then the Fourier relative error is at most rho+eta(1+rho). Thus an O(1/N) P tolerance is not a necessary condition for the original P Q-inverse route.

## 1. Scope and frozen sources

Throughout, N>=5 is odd, q=exp(-2 pi i/N) is canonical, c=cos(pi/N), and indices are cyclic. Set

    F[k,j]=q^(kj), (Sx)_k=x_(k-1),
    C=S+2c I+q S^(-1), Q=L C R, P=FQ.

The accepted b=1 source and independent review establish a cold arbitrary-input C inverse in O_d(N+n^20) word work for fixed dyadic input-description constant d, with n=ceil(log2(N+1)), paid seeds, guarded contracting scans and O_d(n)-bit words. The sealed verdict accepts relative 1/16 and the finite target window through 2^(-n). This audit imports that accepted scope only.

The outer-chirp author report is included as an inert source for its object definitions and scope; its independent review belongs to the separate task. This report neither promotes nor changes that result. INPUT_BINDINGS.json records exact source bytes and SHA-256 values. All new derivations use these frozen definitions, with no external theorem needed beyond the elementary polynomial-root argument reproduced in section 4.

## 2. Entrywise formula and a sparse output filter

The original b=1 columns are

    Q[j-1,j]=q^(2j), Q[j,j]=2c q^j, Q[j+1,j]=1.

Direct multiplication, including cyclic wrap, gives

    P[k,j]=q^(kj)(q^(2j-k)+2c q^j+q^k)
          =q^(j(k+1))(q^(k-j)+2c+q^(j-k)).              (1)

The offset factor vanishes exactly at k-j=(N-1)/2 and (N+1)/2. Indeed, after multiplying it by q^(k-j), its two roots are precisely those two distinct N-th roots, and the polynomial is quadratic. Thus each column has exactly N-2 nonzeros. This count does not imply quadratic application complexity.

For y=Fx, (1) reorganizes into

    (Px)_k=q^k y_k+2c y_(k+1)+q^(-k)y_(k+2).

Define T by this three-diagonal formula. Then

    P=T F, T=F Q F^(-1).                              (2)

An existing Fourier executor plus an O(N) filter therefore applies P without materializing its dense array. Calling this a new P acceleration is valid only if the Fourier cost remains in the ledger. Using (2) as the missing O(N) P theorem would assume the target operation.

## 3. Chirp-gauged convolution and the exact reverse reduction

Let

    A_k=q^(k(k-1)/2), E_j=q^(j(j+1)/2),
    B_j=q^(j(j+3)/2), gamma_delta=q^(-delta(delta-1)/2),
    t_delta=gamma_delta(q^delta+2c+q^(-delta)),
    H=q S+2c I+S^(-1)=C^T.

A,E,B denote the corresponding diagonal matrices, and C_gamma,C_t denote cyclic convolution by gamma,t. Odd N makes every displayed quadratic sequence N-periodic: shifting its integer index by N changes the exponent by a multiple of N. The elementary exponent identity

    k(k-1)/2+j(j+1)/2-(k-j)(k-j-1)/2=kj

proves

    F=A C_gamma E, P=A C_t B.                         (3)

Moreover q^delta gamma_delta=q gamma_(delta-1) and q^(-delta)gamma_delta=gamma_(delta+1). Consequently

    C_t=H C_gamma, T=A H A^(-1)S^(-1),
    T^(-1)=S A H^(-1)A^(-1).                         (4)

The second identity can also be checked entrywise: its coefficients at y_k,y_(k+1),y_(k+2) are exactly q^k,2c,q^(-k). Let J reverse an array, (Jx)_k=x_(N-1-k). Then H=J C J, so H^(-1)=J C^(-1)J. Its stable finite-word solve uses exactly the accepted contracting C scans, with paid reversals. A growing-root forward recurrence is not a substitute for those stable directions.

For completeness, the exact-field O(N) reverse overhead does not need a square-root oracle. To solve Hv=b, use the two-state recurrence

    [v_(k+1),v_k]^T = M[v_k,v_(k-1)]^T+[b_k,0]^T,
    M=[[-2c,-q],[1,0]].

One N-step scan forms M^N and the inhomogeneous term d. The periodic initial state satisfies (I-M^N)X_0=d. This 2-by-2 system is invertible because a nonzero periodic homogeneous state would be a nonzero kernel vector of H, whereas the accepted canonical C is invertible. Solving it and replaying the recurrence costs O(N) field operations. This proof concerns exact arithmetic only: unstable intermediate growth can make it an invalid finite-word implementation. The contracting solver is the appropriate finite-word building block.

All phase vectors in (3)-(4) have constant-step multiplicative recurrences, so they cost O(N) field work with q supplied. Reading/writing every coordinate remains charged. Thus

    Apply(P) <= Apply(F)+O(N),
    Apply(F) <= Apply(P)+O(N)                         (5)

in the exact field model, at canonical odd lengths. A conventional fast Fourier routine gives an O(N log N) P routine. Nothing in (3) computes C_gamma for free: C_gamma=A^(-1)F E^(-1) is already Fourier-equivalent through unit-modulus diagonals alone.

The output-filter condition number is also exact. Since F/sqrt(N) is unitary, T is unitarily similar to Q. Hence

    kappa(T)=kappa(Q)=kappa(C)=Theta(N), kappa(Q)<=N.

This condition number must not be silently replaced by one merely because (3) uses chirps.

## 4. Two precise structural obstructions

### 4.1 No bounded-degree rational-shift replacement

Suppose, at a canonical odd N, that the convolution C_t could be written

    C_t=U(S)V(S)^(-1),

where V is invertible and U,V are Laurent polynomials with cyclic radii u,v. The circulants commute; since H is invertible, (3)-(4) imply

    F=A U(S)[H V(S)]^(-1)E.

It follows that

    u+v >= (N-3)/2.                                   (6)

Here is the full support proof. A nonzero vector supported on s consecutive cyclic coordinates has a Fourier transform with at least N-s+1 nonzeros: remove its starting monomial, regard its coefficients as a nonzero polynomial of degree at most s-1, and evaluate at the N distinct roots q^k. Such a polynomial has at most s-1 roots. Multiplication by invertible diagonal matrices preserves zero positions. Each column of H V has consecutive support of length at most 2(v+1)+1 and is nonzero, while each column of U has at most 2u+1 nonzeros. The preceding inequality gives 2(v+1)+1+2u+1>=N+1, which is (6). If either nominal width already covers the full cycle, the claimed lower bound is immediate.

Thus a constant-bandwidth numerator followed by a constant-bandwidth cyclic solve cannot realize C_t at all large N. This is a degree/support obstruction for this rational-shift class, not a lower bound on arbitrary circuits or on all ways to evaluate a high-degree expression. It is a specialization of the frozen Hero17 interface theorem, with its proof made explicit here.

### 4.2 Off-diagonal ranks grow

Take m consecutive rows I, with m+2<=N, and any m distinct columns J0. Expand I by one row at each end to the m+2 consecutive rows K. From C_t=H C_gamma,

    C_t[I,J0]=H[I,K] C_gamma[K,J0].

The first factor has row rank m: its leftmost m columns form a triangular matrix with nonzero diagonal q. By (3), the second factor differs from a consecutive-row Fourier submatrix only by invertible diagonal factors. Its first m consecutive rows form a Vandermonde matrix on m distinct nodes q^j, so its column rank is m. The elementary product-rank inequality gives

    rank C_t[I,J0] >= m-2.                             (7)

The same bound holds for P[I,J0] because (3) only adds diagonal factors. Choose I and J0 disjoint of size m=floor((N-1)/2). Then off-diagonal ranks are unbounded. An exact constant-rank off-diagonal or quasiseparable representation is therefore unavailable. This says nothing about approximate low-rank blocks, multilevel ranks, nonstandard orderings, or algorithms that do not use such a representation.

## 5. Why the coefficient recurrence does not execute the convolution

The chirp recurrence gamma_(delta+1)=q^(-delta)gamma_delta is cheap to generate. For a fresh arbitrary vector x, however, define

    W_k^(r)=sum_j gamma_(k-j) q^(rj) x_j.

Then the attempted output recurrence is

    W_(k+1)^(r)=q^(-k) W_k^(r+1).                     (8)

Advancing the desired r=0 output asks for a new modulated-input convolution. For each fixed k, the N functionals W_k^(0),...,W_k^(N-1) are linearly independent: their coefficient matrix is the Fourier matrix with each column multiplied by the nonzero gamma_(k-j). Thus this straightforward moment hierarchy has N independent states, not a proved constant-state closure. An O(N) seed scan cannot be substituted for the N-input convolution.

Likewise, a nonzero constant-coefficient polynomial of degree less than N cannot annihilate t cyclically in the canonical case. C_t is invertible by (3)-(4), so every cyclic Fourier eigenvalue of t is nonzero. Such an annihilator would have to vanish at all N distinct roots of unity. This excludes only that homogeneous constant-coefficient recurrence, not all recurrences or nonlinear algorithms.

## 6. Finite-word errors: residuals are the right interface

Exact field equivalence (5) must not be promoted to a fixed-tolerance finite-word equivalence without a composition proof. The underlying paid model has O(log N)-bit words, fixed polynomial input magnitude/denominator bounds, and no supplied numerical chirps or uncharged preprocessing. Stable H inversion is available from the accepted C theorem and reversal. Outer chirps require their own seed, accumulated error, range and representation charges; their separate review is not duplicated here.

### The original P Q-inverse route

For any candidate inverse output z and nonzero x, unitarity of F/sqrt(N) gives the exact identity

    ||Pz-Fx||_2 / ||Fx||_2
       = ||Qz-x||_2 / ||x||_2 =: rho.                 (9)

This includes every correlation between the actual solve error and Q's singular directions. If a P executor, on the represented z, returns w with ||w-Pz||<=eta||Pz||, then

    ||w-Fx|| / ||Fx|| <= rho+eta(1+rho).               (10)

Indeed, (9) bounds ||Pz|| by (1+rho)||Fx||, after which the triangle inequality proves (10). For example rho,eta<=1/16 suffice for a final relative error below 1/4. All norms in this section are full-vector 2-norms.

A bare inverse forward-error guarantee ||z-Q^(-1)x||<=delta||Q^(-1)x|| implies only rho<=kappa(Q)delta. This implication is sharp as a norm-contract statement, not just an upper-bound worry. Choose Q's right singular vectors v_min,v_max, take x=Q v_min and z=v_min+delta v_max. The inverse relative error is delta, while rho=delta sigma_max(Q)/sigma_min(Q). This algebraic example demonstrates what the norm-only contract permits. It is not asserted to be the error made by the actual dyadic executor, and it is not a supplied implementation on the represented-input model.

Consequently, the fixed 1/8 Q-inverse contract alone, even after independent acceptance, is insufficient to assert a small Fourier tolerance after exact P. It also does not prove failure. The useful next composition fact is an all-legal-input Q-relative residual certificate for the actual rounded inverse, with its real errors and precision budget. Its finite residual tests can corroborate that fact but cannot replace its uniform proof. Tightening forward error to O(1/N) is a sufficient alternative, not a necessary one.

### The alternative output-filter route

For w_hat approximating Px and y=Fx, exact inversion of T gives

    error = T^(-1)(w_hat-Px).

The natural P error norm is therefore ||T^(-1)(w_hat-Px)||/||Fx||. A plain relative P-error guarantee eta yields the sufficient bound kappa(T)eta, and independent singular directions can attain that amplification. If a stable approximate inverse has relative error tau on its actual represented input, the idealized bound becomes

    tau+(1+tau)kappa(T)eta,

before the separately paid chirp/representation errors. Requiring eta=O(1/N) is a sufficient black-box allocation for fixed final tolerance here. It does not establish a necessary P tolerance in general, nor in (10).

Numerically, an additional factor N costs O(log N) guard bits, still a constant number of the stated O_d(log N)-bit words for a fixed input-description family. This observation does not supply a missing executor: every recurrence, coefficient, conversion, intermediate range and final write must still be charged. The exact two-state transfer-matrix proof from section 3 must not be used to bypass the stable-direction requirement.

## 7. Gate decision and the next necessary lemma

P's dense entry count should be replaced by the sharper statement: its literal band multiply is quadratic, while its proved structured descriptions are Fourier-equivalent. This narrows the remaining task without asserting that no other O(N) algorithm can exist.

To close the original finite-word Fourier route, the remaining constructive deliverable must provide:

1. A uniform cold arbitrary-input P executor with a stated accuracy/range/representation contract, including all coefficients, input reads, arithmetic and output writes. A reference to F, C_gamma, or a Fourier-based diagonalization keeps the target operation unpaid.
2. A compatible represented-input interface for the actual inverse output z, with the enlarged fixed description constant and conversions explicitly paid.
3. Either a proved small relative Q residual rho for that inverse implementation and equation (10), or another fully charged error argument that handles the actual directions. A fixed inverse forward-error contract alone is not enough.

No specific independent O(N) P algorithm is presently established by these sources or this audit. The banded-rational and exact low-rank shortcuts above are ruled out at their stated scopes. Existing FFT-based application remains a legitimate conventional fallback; no mathematical lower bound excludes a different structured algorithm.

## 8. Fresh controls and limitations

The newly authored fresh_controls.py checks every displayed matrix orientation over 28 exact length/prime pairs at 14 odd lengths from 5 to 65. It checks P=FQ=TF, the entry formula, P=A C_t B, C_t=H C_gamma, F=A C_gamma E, the T factorization, transpose orientation, exact support count, full moment rank and the off-diagonal rank bound. When H is nonsingular in the test field, 96 total full-vector controls additionally verify F=T^(-1)P. Four modular cases have singular H and intentionally do not claim that inverse reduction; canonical complex invertibility is separately proved by the accepted source.

These are exact algebraic controls, not complex stability experiments or universal-field nonsingularity claims. They do not establish the all-N theorems, which are proved above, and do not benchmark performance. No uploaded or inherited research program was executed or imported. The packet contains source snapshots, fresh controls, results and hash manifests. No Sheet or repository mutation is performed.
