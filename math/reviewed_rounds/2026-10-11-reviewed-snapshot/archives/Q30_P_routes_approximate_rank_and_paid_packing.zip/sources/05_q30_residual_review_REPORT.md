# Independent review of the Q30 actual solver residual contract

11 October 2026. Verdict: ACCEPTED WITH THE STATED SCOPE. VERDICT.json and AUTHOR_BINDING.json bind this decision to the exact author archive and report.

The mathematical result is correct under the accepted canonical b=1 finite-word contract. The already accepted full-Q executor has a small actual equation residual without changing its precision, coefficients, rounding schedule or work. For every fixed integer d>=1, every odd N>=5, n=ceil(log2(N+1)), and every nonzero legal dyadic input x, the returned vector y satisfies

    ||Qy-x||_2 / ||x||_2 <= 8 * 2^(-(d+16)n-64) <= 2^-112.

The all-zero branch returns exactly zero and has zero absolute residual. The relative ratio is undefined there. This is an additional interface certificate for the existing algorithm. It is not a new inverse algorithm, a P executor or a linear Fourier algorithm.

## The reviewed contract

The operator orientation is fixed throughout:

    q=exp(-2 pi i/N), c=cos(pi/N), (Sv)_j=v_(j-1),
    C=S+2c I+q S^(-1), Q=L C R,
    L_j=q^(-j(j-1)/2), R_j=q^(j(j+1)/2).

All cyclic indices are modulo N. Real and imaginary input components have magnitude at most 2^(dn) and dyadic denominator exponent at most dn, in ordinary O_d(n)-bit descriptions; extra parsing for padded encodings is charged. The unchanged production parameters are

    a=(2d+20)n+64, u=2^-a, D=2d+42,
    p=(4d+96)n+64, v=2^-p, W=1024(d+64)n.

The original input is converted exactly to the a-grid. A shared rounded chirp recurrence yields ellhat_j approximating q^(j(j-1)/2), with max coefficient error gamma=4N^2u. The input pass forms b_j=round_a(ellhat_j x_j). The accepted two contracting first-order solves act on the exact represented b after an exact conversion to the p-grid. Their output is shat. The final pass is the actual mixed-grid operation

    y_j=round_a(conjugate(ellhat_(j+1)) shat_j).

That j+1 offset is essential. Rounding a mixed a-grid/p-grid numerator after division by 2^p yields the final a-grid result directly. No intermediate downcast, unitary correction or normalization is omitted from the description.

## The closure row cannot be treated as an ordinary row

For one solve (I-zS)h=b, write zhat for the stored coefficient, with |zhat|<=1 and |zhat-z|<v. The N-step rounded power has error E relative to zhat^N, and the rounded Horner sum has error H relative to the exact polynomial in zhat. Each satisfies |E|,|H|<=Nv. With dhat=1-Phat, Nv<=1 implies |dhat|<=3. If e_div is the final division error, then

    dhat hhat_(N-1)=that+dhat e_div.

The N-1 replay rows have errors e_j, each of modulus below v. Unrolling those rows proves the exact terminal identity

    ((I-zhat S)hhat-b)_(N-1)
      = H+E hhat_(N-1)+dhat e_div
        -sum_(j=0)^(N-2) zhat^(N-1-j)e_j.

In particular, the closure row is bounded by [NV+2N+2]v, where V=||hhat||_infinity. The remaining rows contribute at most sqrt(N-1)v in 2-norm. Switching to the exact coefficient contributes at most sqrt(N)Vv. Thus

    ||(I-zS)hhat-b||_2
      <=[(N+sqrt(N))V+2N+2+sqrt(N-1)]v
      <=2N(V+2)v.

The last comparison is valid for N>=2, hence throughout the reviewed scope. Reversal is unitary, so the same estimate applies to the opposite scan direction. The accepted range bound V<=3N(||b||_infinity+1) then gives the convenient 8N^2(||b||_infinity+1)v form.

This proof uses the actual rounding defects. It neither assumes independent error directions nor treats an input-relative or componentwise relative arithmetic model as given. In particular, checking only the N-1 replay equations would be insufficient: a wrong terminal value can satisfy those equations exactly and leave the last equation wrong.

## Composing the actual first order defects

Use the accepted factorization

    alpha=-c+sqrt(c^2-q), beta=-c-sqrt(c^2-q), r=1/beta,
    A=I-alpha S^(-1), B=I-rS, C=-beta AB.

The square root is the accepted principal root with positive real and imaginary parts. Let t and w be the actual outputs of the first and second scans. Define g1=At-b and g2=Bw-t. The exact identity

    C(-r w)-b=g1+A g2

follows solely from beta r=1 and the displayed factor order; no statistical or singular-vector assumption is involved. The accepted range bounds give

    ||g1||_2 <=8N^2(B0+1)v,
    ||g2||_2 <=32N^3(B0+1)v,
    ||w||_infinity <=12N^2(B0+1), B0=||b||_infinity.

The final rounded multiplication by -rhat differs from -r w by at most sqrt(N)(||w||_infinity+1)v. Since ||A||<=2 and ||C||<=4, the resulting bound is

    ||C shat-b||_2
      <=[8N^2+64N^3+52N^(5/2)](B0+1)v
      <=128N^3(B0+1)v.

The last constant is conservative even at N=5. These range estimates are imported from the accepted inner analysis; importing them does not require importing its final forward-error guarantee.

## Both chirp applications and the original input norm

Let X=||x||_2. A nonzero represented input has X>=2^-dn. The prechirped magnitude bound B0<2^(dn+2) gives

    ||C shat-b||_2 / X <= R0=2^10 N^3 2^(2dn-p).

With h=sqrt(N)2^(dn)u and delta=gamma+h, the input pass satisfies ||b-L^(-1)x||<=delta X. The accepted minimum singular value gives ||C^(-1)||<=N/4, so

    ||shat||_2 <= (N/4)(1+delta+R0)X.

This is a range consequence of the actual residual. The final diagonal perturbation and final output rounding then give

    ||Qy-x||_2 / X
      <=R0+gamma+5h+N gamma(1+gamma+h+R0).

Every term has a paid origin: inner residual, prechirp coefficient error, prechirp rounding, output chirp coefficient error or final down-rounding. The approximate chirps are not treated as norm-preserving. The exact unitary diagonals and the accepted spectral bound are used only where justified.

For xi=2^((d+4)n-a), the production inequalities gamma<=xi, N delta<=xi, 4h<=xi and R0<=xi hold uniformly for d>=1,n>=3. Therefore the right side is at most 4xi+2xi^2<=5xi<=8xi. Since xi<=2^-115, the advertised 2^-112 bound follows. The independent budget controls even use the looser rational replacement sqrt(N)<=N and still pass the advertised envelope.

This argument handles minimum nonzero inputs, coordinate cancellation and mixed magnitudes. Tiny coordinates may individually round to zero, but their absolute rounding errors are included. No uncharged rescaling or underflow convention is used. The prechirped vector cannot become identically zero when x is nonzero, since delta<1.

## Representation cold setup and complete costs

The transformed input is an a-grid vector, so the enlarged inner description constant D is mandatory: a<=Dn and each component magnitude is below 2^(Dn). Reusing the original d would be invalid. The final output also has denominator exponent a<=Dn and magnitude below 2^((d+2)n+10)<=2^(Dn), making it a valid D-description input for a future compatible executor.

The roots are unchanged. The outer seed is certified to absolute error below 2^-a. The inner alpha/r seeds are certified below 2^-p. The accepted cold constructions use rational Machin/Taylor enclosures and integer-square-root enclosures, with their actual multiword integer costs included. No trigonometric, square-root, phase-table or inverse-table oracle is introduced by this residual proof. The exact coefficient and denominator guards remain mandatory. The accepted W bound covers stored and unrounded scan arithmetic, signs, guards and addressing; longer setup integers are charged as multiword values.

There is no runtime residual evaluation, extra solve or residual correction. The nonzero-input count remains 2N chirp-generation products, N prechirp products, 7N-2 inner products and two divisions, and N final mixed-grid products: 11N-2 complex products and two complex divisions. Input reads, exact conversion, zero detection, additions, reversals, signs, guards and every output write remain charged. Cold word work is O_d(N+n^20), storage O_d(N+n^8), bit work O_d(N n^2+n^20), and output size Theta_d(Nn) bits. These statements fix d and use O_d(log N)-bit words, not fixed hardware precision.

Zero additional bits suffice for the theorem. This is not a claim that either inherited precision is minimal, nor an arbitrary requested-accuracy construction.

## Fresh independent controls

review_controls.py was written independently for this review. It imports no author or inherited research program. Its exact dyadic integer arithmetic reproduces the production scan and rounding schedule. Canonical coefficients are independently enclosed by outward integer interval arithmetic, rational Machin terms, interval Taylor series and integer square-root bounds. These controls choose valid certified seeds at the prescribed precision; they do not claim byte-identity to one particular implementation's interval-midpoint choices. The uniform proof covers every seed satisfying the accepted error and guard conditions.

All decisive comparisons are exact integer/rational inequalities. The recorded decimal summaries are informative only; exact numerator/denominator residual certificates are retained in CONTROL_RESULTS.json. The reference Q residual is formed directly from the original matrix entries Q[j-1,j]=q^(2j), Q[j,j]=2c q^j, Q[j+1,j]=1, using reduced binary powers, rather than reusing the execution chirp recurrence or relying on an approximate dense inverse.

The passing controls comprise:

- 162 canonical production cases at d in {1,3,9} and N in {5,7,9,13,17,25,33,65,129}. Inputs include zero, minimum nonzero imaginary impulses, maximum complex constants, mixed-scale alternating vectors, reproducible random legal dyadics and tiny alternating vectors. Nonzero cases certify the original-Q relative residual below 8xi and hence below 2^-112, both local residual bounds, the inner residual, seed errors, chirp errors, guards, representation conversion, literal counts and scan width. The largest certified squared relative residual is below 1.103e-76.
- 2,580 exact parameter-budget cases, including every odd N from 5 through 1025 plus 4097, 65537, 1048577, 2^30+1 and 2^128+1, with d in {1,2,7,64,257}. They check the final residual envelope, transformed-input description and precision ordering.
- 18 lower-precision rational closure-identity and local-residual cases, at six lengths and three precisions, including near-boundary contracting coefficients and a nonzero exact-coefficient perturbation. The maximum squared ratio to the local bound is below 0.01092.
- Six negative controls in which every ordinary replay row is exact while the omitted closure row has residual magnitude one. They demonstrate why that row needs its own estimate.

Finite cases corroborate the written uniform proof; they are not a proof of the all-N statement, the cold complexity estimate or a speed benchmark. The very large d and N values in budget tests do not extend the theorem to a growing-d cost model.

## Consequence and limits of acceptance

The separately accepted identity P=FQ and unitarity of F/sqrt(N) imply

    ||Py-Fx||/||Fx||=||Qy-x||/||x||=rho.

If a separately implemented P executor is valid on the actual represented y and has relative error eta to Py, then its Fourier error is at most rho+eta(1+rho). This residual review supplies the missing small-rho assertion for the already accepted inverse. It does not supply that P executor, its coefficient precision, its representation conversion or its cost. The conditional choice eta<=1/16 yields error below 1/8 with the certified rho.

A generic forward-error contract alone would yield only the condition-number upper bound, but that observation is not evidence that the actual rounded solver fails and does not make O(1/N) extra accuracy necessary for this algorithm. Here the operations themselves give the needed residual at unchanged precision.

Acceptance is restricted to canonical complex b=1, odd N>=5 and the fixed-d represented-input model. No general-b, arbitrary primitive embedding, finite-field stability, arbitrary-precision-target, fixed-IEEE, exact differentiable-source or unrestricted lower-bound theorem follows. No Sheet or GitHub changes were made. The independent checkpoint and final review archives are preserved in Library with exact-byte verification.
