# Q30 b=1: the actual accepted solver has a small relative Q residual

11 October 2026. Author candidate for independent review. This is a stronger interface certificate for the already accepted full-Q executor, with unchanged coefficient-accuracy requirements, precision, rounding schedule and costs. It is not a new solver, an algorithmic novelty claim, a P executor or a Fourier algorithm.

## Result

Fix an integer d>=1. For every odd N>=5 put n=ceil(log2(N+1)). Each real and imaginary input component is an exactly represented dyadic of magnitude at most 2^(dn), with denominator exponent at most dn; ordinary encodings have O_d(n) bits, and extra padding is charged. The accepted canonical b=1 operator is

    q=exp(-2 pi i/N), c=cos(pi/N), (Sv)_j=v_(j-1 mod N),
    C=S+2cI+qS^(-1), Q=LCR,
    L_j=q^(-j(j-1)/2), R_j=q^(j(j+1)/2).

Run the actual accepted executor with its existing parameters:

    a=(2d+20)n+64, u=2^(-a), D=2d+42,
    p=(2D+12)n+64=(4d+96)n+64, v=2^(-p),
    W=1024(d+64)n.

If x is nonzero and y is its returned a-grid output, then

    ||Qy-x||_2 / ||x||_2 <= 8 xi <= 2^(-112),
    xi=2^((d+4)n-a)=2^(-(d+16)n-64).                 (T)

The all-zero input returns exactly zero. The relative ratio is not defined at zero; its absolute residual is exactly zero.

No precision increase is required. This is the existing executor's very conservative fixed precision budget, analyzed through its local equation defects. The proof does not multiply the accepted global 1/8 forward bound by kappa(Q). The operation count remains 11N-2 rounded complex products and two rounded complex divisions after setup, together with O_d(N) other charged word operations. Cold word work is O_d(N+n^20), storage O_d(N+n^8), bit work O_d(N n^2+n^20), and fixed-width output Theta_d(Nn) bits. All these are for fixed d and the stated O_d(log N)-bit word model, not fixed IEEE precision or linear bit complexity.

## 1. The unchanged accepted algorithm and premises

The accepted inner factorization is

    alpha=-c+sqrt(c^2-q), beta=-c-sqrt(c^2-q), r=1/beta,
    A=I-alpha S^(-1), B=I-rS, C=-beta AB.

The square root has positive real and imaginary parts. The accepted proof establishes

    |alpha|=|r|<=sqrt(N/(N+2))<=1-1/(2N),
    |alpha|^N, |r|^N<=1/2,
    ||C||_2<=4, sigma_min(C)=2 sin(pi/N)>=4/N.       (1)

Certified p-grid seeds obey |alphahat-alpha|<v and |rhat-r|<v. The mandatory exact seed guard is |zhat|<=1-1/(4N). Each first-order solve constructs a rounded N-step power Phat of zhat and an N-step rounded Horner sum that. It sets the terminal coordinate to round_p(that/(1-Phat)), requires |1-Phat|>=1/4, and then replays N-1 rounded recurrence steps. The reversed solve is implemented with paid reversal or equivalent charged index-direction work. Every complex product or division rounds each Cartesian component once, nearest with ties away from zero. Its absolute complex rounding error is strictly below v; p-grid additions are exact.

The inner algorithm returns t after the reversed alpha solve, w after the ordinary r solve, and

    shat_j=round_p(-rhat w_j).

The accepted, already proved range estimates, independently of its final forward-error guarantee, are

    ||t||_infinity<=3N(B0+1),
    ||w||_infinity<=3N(||t||_infinity+1),
    B0=||b||_infinity.                                (2)

They hold under the production small-v premises, including 64Nv<=1. Section 2 below uses the actual computed vector's range, not a relative forward-error assertion.

The outer algorithm generates ellhat_0,...,ellhat_N from one cold qhat seed by the two rounded recurrences approximating t_j=q^j and ell_j=q^(j(j-1)/2). The accepted construction guarantees

    |qhat-q|<u, max_j |ellhat_j-ell_j|<=gamma=4N^2u.  (3)

The prechirped input and final output are exactly

    b_j=round_a(ellhat_j x_j),
    y_j=round_a(conjugate(ellhat_(j+1)) shat_j).       (4)

The shift j+1 is required. Each outer or mixed final product contributes complex absolute rounding error <u. Input conversion a->p is exact, with no intermediate resampling. The zero test reads every coordinate before the exact-zero output branch.

These are the accepted executor's actual operations. No residual correction, projection, extra solve or normalization is added. The existing cold scalar constructions use rational Machin and Taylor enclosures, outward dyadic rounding, and integer square-root enclosures; the outer target is a-bit seed error and the inner target is p-bit seed error. Their already charged O_d(n^20) work and O_d(n^8) scratch remain unchanged. This theorem imports the accepted seed, guard and range proofs, but derives a new residual assertion from the operations themselves.

## 2. A local residual lemma, including the cyclic closure row

Consider one solve of (I-zS)h=b. Let zhat be its represented seed with |zhat|<=1 and |zhat-z|<v. Let hhat be the returned vector and V=||hhat||_infinity. Assume Nv<=1, as production parameters guarantee.

Use distinct symbols for every actual rounded defect. In the N-step power scan, Phat=zhat^N+E with |E|<=Nv. In the N-step Horner scan,

    that=t_exact+H,
    t_exact=sum_(j=0)^(N-1) zhat^(N-1-j)b_j,
    |H|<=Nv.                                         (5)

These are sums of the local product-rounding errors with powers of zhat, so the coefficient is the represented zhat, not the exact z. Additions are exact. Let dhat=1-Phat. Then |dhat|<=2+Nv<=3. The terminal division has some actual error e_div with |e_div|<v and

    dhat hhat_(N-1)=that+dhat e_div.                  (6)

The N-1 replay steps have local errors e_j with |e_j|<v:

    hhat_j=zhat hhat_(j-1)+b_j+e_j, 0<=j<N-1,

where the first preceding coordinate is hhat_(N-1). Consequently every nonterminal row of ghat=(I-zhat S)hhat-b is exactly e_j. Expanding only those replay equations in the remaining row gives the exact closure identity

    ghat_(N-1)=H+E hhat_(N-1)+dhat e_div
                 -sum_(j=0)^(N-2) zhat^(N-1-j)e_j. (7)

Thus

    |ghat_(N-1)| <= [NV+2N+2]v,
    ||ghat||_2 <= [NV+2N+2+sqrt(N-1)]v.             (8)

The N-step power and Horner scans both matter in this exceptional row. Treating it as one ordinary recurrence rounding would be invalid.

Switching from zhat to exact z adds at most sqrt(N)Vv to the 2-norm. Since sqrt(N)<=N and 2N+2+sqrt(N-1)<=4N for N>=2, the returned vector satisfies

    ||(I-zS)hhat-b||_2 <= 2N(V+2)v.                 (9)

Reversal is unitary and changes S to S^(-1), so the identical bound holds for the reverse-direction solve. Combining (9) with the accepted range V<=3N(||b||_infinity+1) gives the convenient uniform form

    ||(I-zS)hhat-b||_2 <=8N^2(||b||_infinity+1)v.  (10)

All displayed bounds include cancellation-heavy and tiny represented right-hand sides. The lemma imposes no componentwise relative-error assumption.

## 3. Compose the two local equation defects

Write the exact-coefficient defects of the two actual solve outputs as

    g1=A t-b, g2=B w-t.

By (10), (2), and N>=5,

    ||g1||_2 <=8N^2(B0+1)v,
    ||g2||_2 <=8N^2[3N(B0+1)+1]v
              <=32N^3(B0+1)v,
    ||w||_infinity <=3N[3N(B0+1)+1]
                    <=12N^2(B0+1).                 (11)

Because C=-beta AB and beta r=1, the exact algebraic identity is

    C(-r w)-b =g1+A g2.                            (12)

It holds for the actual vectors t,w, regardless of how their errors align with singular directions. The final scale returns shat=-r w+e3 where

    ||e3||_2 <=sqrt(N)(||w||_infinity+1)v.

Using ||A||_2<=2 and ||C||_2<=4,

    ||C shat-b||_2
      <=[8N^2+64N^3+52N^(5/2)](B0+1)v
      <=128N^3(B0+1)v.                            (13)

For the last inequality, divide by N^3: 8/N+64+52/sqrt(N)<=8/5+64+52/2<128, since N>=5 and sqrt(N)>2. This is a direct equation-residual proof, not a transported global forward-error estimate.

For the outer prechirped b, the accepted bounds give B0<2^(dn+2), hence B0+1<=2^(dn+3). Every nonzero legal x has ||x||_2>=2^(-dn). Therefore (13) implies

    ||C shat-b||_2 / ||x||_2 <=R0,
    R0=2^10 N^3 2^(2dn-p).                         (14)

The denominator here is the original input norm; the claim does not incorrectly reuse the original d for b. The inner D-description invocation remains mandatory.

## 4. Compose with both actual chirp applications

Let U=L^(-1), V=R^(-1), with their approximate diagonal matrices Uhat,Vhat from (3). Exact U,V are unitary; ||Uhat-U||,||Vhat-V||<=gamma. Set X=||x||_2 and

    h=sqrt(N)2^(dn)u, delta=gamma+h.

The rounded input pass obeys

    ||b-Ux||_2<=delta X.                            (15)

The actual inner residual (14), together with the accepted spectral bound ||C^(-1)||_2<=N/4, gives an a posteriori range estimate useful for this composition:

    ||shat||_2 <= (N/4)(1+delta+R0)X.              (16)

This uses the small equation defect and the already accepted minimum, not the global inverse forward-error bound.

Write y=Vhat shat+e_out, ||e_out||_2<=sqrt(N)u. Expanding Qy-x through exact LCR and applying the triangle inequality yields

    ||Qy-x||_2/X
      <=R0+delta+4 gamma||shat||_2/X+4h
      <=R0+gamma+5h+N gamma(1+gamma+h+R0)
      =(1+N gamma)(R0+delta)+N gamma+4h.          (17)

This separates the inner local residual, input chirp error, output chirp error, and final down-rounding. Neither rounded chirps nor the numerical inverse are silently treated as exactly unitary.

## 5. Exact production-parameter envelope and tiny inputs

N<2^n, n>=3 and d>=1. With xi=2^((d+4)n-a), the existing outer budget proves

    gamma<=xi, N delta<=xi, 4h<=xi.                (18)

For completeness, N delta=(4N^3+N^(3/2)2^(dn))u. Its two summands are each at most xi/2: their exponent gaps from (d+4)n are at least (d+1)n-2>=4 and (5/2)n>=7.5, respectively. The gamma and 4h estimates follow directly from 2n+2<=(d+4)n and 2+(d+1/2)n<=(d+4)n. Thus also N gamma<=xi and delta<=xi.

The inner residual bound satisfies

    R0 < 2^(10+(2d+3)n-p)
       =2^(-(2d+93)n-54) <=xi,                    (19)

because the exponent difference from xi is 10-(d+77)n<=10-78*3=-224. In particular this is not an implicit claim that the original accepted 1/16 inner contract alone implies the result: (19) uses the new local-defect proof and the actual p.

Since xi<=2^(-115)<1/2, substituting (18)-(19) into (17) gives

    rho<=(1+xi)(xi+xi)+xi+xi
         =4xi+2xi^2<=5xi<=8xi.                   (20)

The final conservative advertised bound is 8xi=2^(-(d+16)n-61)<=2^(-112), attained as an envelope at the smallest allowed d=1,n=3. No limiting or large-N argument is used for this minimum case.

If x=0 the branch outputs zero, so the absolute residual is zero. If x is nonzero, its minimum possible nonzero Cartesian component gives X>=2^(-dn); that is the only division-by-input lower bound used. A tiny input is not normalized for free and is not rounded to an unstated floating-point underflow threshold. Indeed delta<1 ensures b cannot be the zero vector when x is nonzero. All down-rounding of individual small coordinates is already counted by u. The guarantee concerns the full-vector 2-norm, not every coordinate relatively.

## 6. Cost and the compatible represented-input interface

Nothing runs in addition to the accepted executor. Local defects are proof quantities, not extra runtime residual computations. Literal nonzero-input calls after seed construction are:

- 2N a-grid products for the shared chirps and ratio sequence;
- N a-grid prechirp products;
- 7N-2 p-grid products and two complex divisions for the two cyclic solves and final scale;
- N mixed-grid products/down-roundings for the output chirp.

The total remains 11N-2 products and two divisions, plus charged O_d(N) input reads, zero detection, exact conversion, additions, reversal/address work, guards, signs and output writes. The cold root constructions, existing W bound, setup scratch and output layout are unchanged. There is no minimally necessary precision increase to calculate: zero additional bits suffice for this certificate. The present work does not claim that the existing a,p are minimal.

The output is an exactly represented a-grid vector. The accepted range is |y_j|<2^((d+2)n+10). It fits the same fixed enlarged description constant D=2d+42 because a<=Dn and (d+2)n+10<=Dn for n>=3,d>=1. Consequently a future P executor can receive this represented output under a D-description contract, with any required grid conversion explicitly paid. That statement supplies an interface, not the missing P algorithm or its accuracy guarantee.

## 7. Consequence and the still-open P gate

For P=FQ and F/sqrt(N) unitary, the exact residual identity gives

    ||Py-Fx||_2/||Fx||_2=||Qy-x||_2/||x||_2=rho.

If a separately supplied P executor, on this represented y, returns w with relative error eta to Py, then

    ||w-Fx||_2/||Fx||_2<=rho+eta(1+rho).             (21)

Thus the actual inverse is now certified to satisfy the correct small-residual interface under its original finite-word contract. For example eta<=1/16 and the above rho imply Fourier relative error below 1/8, conditionally on such a fully charged P executor.

No independent uniformly linear arbitrary-input P executor is provided. P's known structured descriptions remain Fourier-equivalent; a coefficient recurrence alone does not execute its convolution. Closing this residual interface does not establish an O(N) FFT, an unrestricted Fourier lower bound, arbitrary target precision, a general-b theorem, noncanonical embeddings, finite-field stability or a differentiable arithmetic source for a sparse-jet compiler.

## 8. Evidence, fresh controls and limits

INPUT_BINDINGS.json freezes the accepted direct-inverse author and review, the accepted outer-chirp author and review, their verdicts/seals, and the P-interface audit/review. Those files are inert source snapshots. No inherited research program is imported or executed.

The newly written fresh_controls.py checks the local closure identity with exact rational arithmetic, local residual estimates with certified canonical coefficient intervals, each actual intermediate range, and the full residual directly through the original three-diagonal Q entries. Production cases use the unchanged a,D,p and integer-grid rounding schedule, including the final mixed-grid down-rounding. They choose canonical seeds using the higher-precision reference enclosures, then explicitly certify each production-grid seed against the accepted seed-error bounds and mandatory guards. They therefore exercise valid instances of the accepted seed interface; they do not claim byte-identity to the output of one particular cold-interval implementation. The uniform proof applies to every seed satisfying those accepted bounds and guards. The reference arithmetic is test instrumentation, not an uncharged replacement for the accepted cold setup. Independent canonical references use rational interval trigonometry and reduced binary powers rather than the executor's chirp recurrence. Finite controls also test boundary-sized abstract first-order rounding defects, the minimum input size, extreme mixed magnitudes, cancellation-heavy inputs, the zero branch, counts and word bounds. CHECK_RESULTS.json records 210 passing canonical cases (180 nonzero and 30 exact zero), at d in {1,2,5} and N in {5,7,9,11,17,31,33,65,129,257}; 45 exact rational closure cases with deliberately coarse grids; and 2,575 exact parameter-budget cases at d in {1,2,4,19,257}, all odd N from 5 through 1025, plus 2049, 4097, 65537 and 1048577. Every nonzero production case checks both local residuals, the direct C residual, original-entry full-Q residual, seed guards, chirp drift, ranges and literal counts. These controls corroborate the uniform proof and do not substitute for it or measure asymptotic speed.

This candidate requires independent review before promotion. No Sheet or GitHub operation belongs to this task.
