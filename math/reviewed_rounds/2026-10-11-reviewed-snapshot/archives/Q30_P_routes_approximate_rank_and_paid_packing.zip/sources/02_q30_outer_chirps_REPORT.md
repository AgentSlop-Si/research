# Q30 b=1: fully charged outer chirps and full Q inverse

11 October 2026. Author candidate for independent review. This continues the existing accepted Q30 b=1 inverse executor. It supplies the previously unpaid chirp generation and diagonal applications. The method is a classical composition of diagonal chirps and cyclic first-order solves, with an explicit finite-word contract. No novel FFT, all-length Fourier algorithm, or P executor is claimed.

## Result and contract

For each fixed integer input-description constant d>=1 and every odd N>=5, let n=ceil(log2(N+1)). Each real and imaginary component of the supplied x is an exactly represented dyadic number with magnitude at most 2^(dn) and denominator exponent at most dn. Ordinary sign/numerator/exponent representations therefore occupy O_d(n) bits per component; extra padding incurs its actual parsing cost. No arbitrary unbounded-bit real input or free transcoding is assumed.

Use the canonical complex embedding and the accepted orientation

    omega=exp(2 pi i/N), q=omega^(-1), c=cos(pi/N),
    (Sv)_j=v_(j-1 mod N), C=S+2c I+q S^(-1),
    L_j=omega^(j(j-1)/2), R_j=omega^(-j(j+1)/2), Q=L C R.

The full target is Q^(-1)x, not merely C^(-1)x. The only problem data are N, the canonical-root specification, d, and the represented input. Nothing is transformed in advance, and there is no supplied phase table, cached plan or stored inverse.

Put

    a=(2d+20)n+64, u=2^(-a), D=2d+42,
    p=(2D+12)n+64=(4d+96)n+64,
    W=1024(d+64)n.

A cold uniform executor returns all N complex a-grid dyadics y with

    ||y-Q^(-1)x||_2 <= (1/8)||Q^(-1)x||_2.                 (T)

The zero vector returns zero exactly. This is a fixed-tolerance theorem. The inner solver is reused solely at its already accepted relative 1/16 contract, with the enlarged input-description constant D and exactly its prescribed p. No new tighter-accuracy inner solver is assumed or asserted.

The fully charged ledger is

    word work O_d(N+n^20), retained/scratch storage O_d(N+n^8),
    bit work O_d(N n^2+n^20), fixed-width output Theta_d(Nn) bits.

For fixed d this is asymptotically O_d(N) word work and words. The finite-parameter n^20 cold setup remains visible. The W-bit integer RAM has charged addition, subtraction, multiplication, Euclidean division, shifts, comparisons, Boolean operations, addressing and memory traffic. All scan integers, including unrounded product/division intermediates, fit in W bits. One may instead use a fixed base word of 64n bits with O_d(1) charged limbs. Setup uses explicitly charged multiword arithmetic. This is not an O(N) bit-time or fixed-hardware-precision claim.

Independent review is required before promotion of (T). The accepted premises and finite controls are identified below.

## 1. Exact diagonal identities and the shared chirp vector

Define the unit-modulus scalar sequence

    ell_j=q^(j(j-1)/2), 0<=j<=N.

Then

    (L^(-1))_j=ell_j,
    (R^(-1))_j=conjugate(ell_(j+1)), 0<=j<N.              (1)

This follows since j(j+1)/2 is integral, and conjugation in the canonical embedding inverts q. In particular ell_N=q^(N(N-1)/2)=1 for odd N. The shift by one in the second formula is essential: using conjugate(ell_j) would omit the b=1 linear phase.

Both vectors come from one cold recurrence:

    t_0=1, ell_0=1,
    ell_(j+1)=ell_j t_j,
    t_(j+1)=t_j q,       0<=j<N.                         (2)

It makes exactly 2N complex multiplications if even the unused t_N is formed. It never forms j^2 as a phase angle and never asks for N trigonometric evaluations. Storing ell_0,...,ell_N costs N+1 complex words up to the fixed d-dependent limb factor; conjugation changes one integer sign exactly. Reading and using this vector in two diagonal passes costs O(N) additional charged work.

The underlying factor orientation is also visible directly. The original b=1 Q has

    Q_(j-1,j)=q^(2j), Q_(j,j)=2c q^j, Q_(j+1,j)=1,        (3)

with cyclic row indices. Equation Q=L C R reproduces all three entries. The source transfer audit fixes this orientation; neither the proof nor the controls silently substitute the transpose or adjoint.

## 2. Cold generation of the only outer transcendental seed

A single complex a-grid qhat is constructed with

    |qhat-q|<u.                                          (4)

There is no trigonometric oracle. Here is a concrete parameter-only construction using only rational/integer arithmetic.

Set K=a+16 and e=2^(-K). Bound pi by Machin's identity

    pi=16 arctan(1/5)-4 arctan(1/239).

Use alternating rational sums, stopping once each omitted-term error is at most e/4096. Round the resulting interval outward to a (K+16)-fractional-bit dyadic grid, and divide by N. At the midpoint of the resulting angle interval, evaluate sine and cosine by rational alternating Taylor sums with omitted term at most e/64. The argument is in (0,1), so terms decrease and the alternating remainders apply. Add half the angle-interval width to each scalar error, using the 1-Lipschitz bounds for sine and cosine. Outward rounding to the same grid and intersection with [0,1] give c_int,s_int containing c,s and of width at most e. These generous constants follow the accepted cold scalar construction; all interval widths can also be checked by exact integer comparisons.

Form, with exact rational interval operations,

    q_int=(c_int^2-s_int^2) - 2i s_int c_int.

Because c_int,s_int are subsets of [0,1] and each has width at most e, each Cartesian q_int interval has width at most 4e. Round each coordinate midpoint once to the a-grid, with nearest rounding and ties away from zero. The complex error is bounded by

    sqrt(2)(u/2+2e)<u,

which proves (4). No branch depends on x. The qhat used for the outer recurrence need not equal the independently seeded coefficient used inside the accepted solver; both are certified approximations to the same specified canonical q.

Machin sums require O(K) rational terms. Their common-product denominator bit sizes are O(K^2+K log K); after immediate dyadic rounding of pi, the Taylor input has O(K+n) bits and common-denominator sizes O(K(K+n+log K)). The constant number of interval products and roundings has polynomial bit cost. Elementary schoolbook rational arithmetic fits well within O_d(n^20) work and O_d(n^8) scratch words. No constant depends on an unbounded target precision or growing d. The accepted inner seed construction is separately paid at its own p and uses a constant number of rational square-root enclosures. Combining the two setups preserves the displayed cold ledger.

## 3. Finite-grid chirp error, including radial drift

Every rounded complex a-grid multiplication forms exact integer products and rounds each Cartesian coordinate once. Its complex absolute rounding error is less than u. Additions and conjugations of stored dyadics are exact.

Run (2) with qhat, rounding after each multiplication. Write that result as that_j and ellhat_j. We do not assume |qhat|=1, do not discard radial drift, and do not insert an uncharged normalization. The stated precision satisfies

    N^2 u <= 1/8.                                       (5)

First |qhat|<=1+u. Let E_j=|that_j-q^j|. Comparing one rounded recurrence with the exact one gives

    E_(j+1) <= (1+u)E_j+2u, E_0=0.

For j<=N, the geometric sum and (1+u)^N<=1/(1-Nu)<=2 imply

    E_j <= 4ju,  |that_j|<=1+4Nu.                       (6)

The elementary inequality used here follows by expanding the binomial and bounding each binomial coefficient by N^k; it requires only Nu<1. Now H_j=|ellhat_j-ell_j| obeys

    H_(j+1) <= (1+4Nu)H_j+(4j+1)u, H_0=0.

Since 4N^2u<=1/2, the same binomial bound gives (1+4Nu)^N<=2. Therefore, for 0<=j<=N,

    H_j <= 2u sum_(k=0)^(j-1)(4k+1)
        = 2u(2j^2-j) <= 4N^2u =: gamma.                (7)

This is a uniform complex coefficient-error bound, including both phase and amplitude error. In particular every approximate diagonal entry has modulus at most 1+gamma, and the two diagonal operator errors in 2-norm are at most gamma. No norm-preserving property of rounded chirps is assumed. Equation (7) is the required precision charge for the accumulated quadratic-phase recurrence.

## 4. Literal executor and legal invocation of the accepted inverse

Read all x and determine whether it is zero. If zero, write N exact zeros. Otherwise generate qhat and the N+1 chirps as above. Convert each input component exactly to the a-grid; a>=dn makes this legal. Form

    b_j=round_a(ellhat_j x_j).                           (8)

The rounded b is now a represented dyadic vector, not an exact mathematical chirp transform passed implicitly to the old theorem. Its denominator exponent is at most a. Because n>=3,

    a=(2d+20)n+64 <= (2d+42)n=Dn.                       (9)

Moreover, using (7) and |x_j|<=sqrt(2)2^(dn),

    |b_j| <= (1+gamma)sqrt(2)2^(dn)+u < 2^(dn+2)
           <=2^(Dn).                                   (10)

Hence every real and imaginary component of b satisfies exactly the accepted inverse's D-description contract, and its numerator/denominator representation has O_D(n) bits. The enlargement D is fixed once d is fixed; it does not grow with N. Merely reusing the original d here would be invalid because a exceeds dn.

Invoke the accepted b=1 C inverse with this b, the enlarged D, precision p=(2D+12)n+64 and its accepted seed/guard construction. Convert the a-grid input to its p-grid exactly. It returns zhat satisfying

    ||zhat-C^(-1)b||_2 <= epsilon ||C^(-1)b||_2,
    epsilon=1/16.                                      (11)

The accepted two recurrence solves, denominator guards, final scaling and all reversals remain unchanged. In particular there are no Fourier calls. The accepted stronger precision margin is not needed or imported as a fresh accuracy theorem.

Finally compute, for 0<=j<N,

    y_j=round_a(conjugate(ellhat_(j+1)) zhat_j).          (12)

This really down-rounds the final output to the outer a-grid. If the stored coefficient numerator is U at denominator 2^a and zhat's numerator is V at denominator 2^p, form the exact complex numerator product and round each coordinate after division by 2^p. Thus the final absolute complex rounding error is less than u, with no extra resampling step omitted.

## 5. Composed full-output relative 2-norm proof

Let f=L^(-1)x, z=C^(-1)f, y*=R^(-1)z=Q^(-1)x. The exact L and R are unitary diagonals, so

    ||f||_2=||x||_2, ||z||_2=||y*||_2,
    ||z||_2>=||x||_2/||C||_2>=||x||_2/4.               (13)

The accepted b=1 minimum is sigma_min(C)=2 sin(pi/N)>=4/N, and ||C||_2<=4. Therefore

    kappa(C)=kappa(Q)<=N.                               (14)

The known matching order kappa(C)=Theta(N) is not replaced by a constant-condition assumption.

For a nonzero legal input, ||x||_2>=2^(-dn). From (8), the coefficient bound (7) and N rounded output coordinates,

    ||b-f||_2 <= gamma||x||_2+sqrt(N)u
              <= delta ||x||_2,
    delta=gamma+sqrt(N)2^(dn)u.                         (15)

Applying C^(-1) to this perturbation costs the condition number in the desired output-relative norm. Equations (13)-(15) give

    ||C^(-1)b-z||_2/||z||_2 <= N delta =: eta,
    ||C^(-1)b||_2/||z||_2 <= 1+eta.                     (16)

This is the prechirp error amplification that cannot be skipped. In particular eta<1 implies b is nonzero whenever x is nonzero; the argument remains valid even without using that consequence explicitly.

Combining (11) and (16),

    ||zhat-z||_2/||z||_2 <= epsilon+(1+epsilon)eta.      (17)

The final approximate diagonal has norm at most 1+gamma and differs from R^(-1) by at most gamma. The N final down-roundings contribute at most sqrt(N)u. Therefore

    ||y-y*||_2/||y*||_2
    <= (1+gamma)[epsilon+(1+epsilon)eta]+gamma+zeta,
    zeta=4sqrt(N)2^(dn)u.                               (18)

This is a full-vector output-relative guarantee for every input in the exact dyadic contract. It does not require a lower bound on any individual coordinate, generic inputs, favorable cancellation, or a shared direction for rounding errors.

For complete explicit smallness, set xi=2^((d+4)n-a)=2^(-(d+16)n-64). Since N<2^n, d>=1 and n>=3,

    gamma=4N^2u <= xi,
    eta=(4N^3+N^(3/2)2^(dn))u <= xi,
    zeta=4sqrt(N)2^(dn)u <= xi.                         (19)

For example, in eta the first summand is at most 2^(3n+2)u and the second is at most 2^((d+3/2)n)u; each is at most one half of 2^((d+4)n)u. The other two inequalities are immediate from their exponents. Thus xi<=2^(-115)<1/1024. Substituting the weaker 1/1024 bounds and epsilon=1/16 into (18) gives

    (1+1/1024)[1/16+(17/16)/1024]+2/1024 <1/8.

This proves (T). All uses of (5), the seed-accuracy premises and the range estimates follow from the same explicit a. Conditioning has been paid through logarithmic precision, not assumed away.

## 6. Range and complete resource ledger

The outer ratio/chirp values have modulus below 2. The prechirped vector has B_b=max|b_j|<2^(dn+2). The accepted executor bounds its solve and final-scale outputs by 32N^2(B_b+1), hence below 2^((d+2)n+8). The final approximate diagonal and rounding keep output magnitudes below 2^((d+2)n+10). Every value is an exact dyadic on its indicated grid; there is no machine underflow convention or silently discarded tiny coordinate.

Outer stored chirp numerators have at most a+2 bits, and prechirp/output numerators at most a+(d+2)n+12 bits. Their unrounded outer products have at most 2a+(d+2)n+O(1) bits. A mixed final product has at most a+p+(d+2)n+O(1) bits, followed by a division by 2^p. Inner operations fit the accepted width 256(D+20)n=256(2d+62)n. Its more explicit worst scan numerator bound is at most 3p+(D+8)n+64, a conservative enlargement of the accepted division estimate. All are strictly below W=1024(d+64)n for n>=3,d>=1. The power-of-two denominators and guard/address products are included. Setup's longer rational integers are multiword quantities whose full schoolbook costs are charged separately.

The nonzero-input execution makes the following literal complex multiplication calls after setup:

- 2N rounded a-grid multiplications to prepare ell_0,...,ell_N and t_1,...,t_N;
- N rounded a-grid multiplications to form b;
- 7N-2 rounded p-grid multiplications and exactly two complex divisions in the unchanged accepted C inverse;
- N mixed-grid multiplications and down-roundings to form y.

Total: 11N-2 complex multiplication calls and two complex divisions, plus O_d(N) additions, conjugations, exact conversions, sign/guard/address operations, input reads, reversals and output writes. Each complex call is a constant number of the explicitly charged W-bit integer operations. No multiplication is a hidden entire-vector operation.

Cold outer setup costs O_d(n^20), and cold inner setup costs O_D(n^20)=O_d(n^20). Both are performed for this one application. A few length-N work vectors and the N+1 chirps cost O_d(N) words; the seed construction has O_d(n^8) scratch. Schoolbook multiplication/division on O_d(n)-bit scan integers yields O_d(Nn^2) bit work, with the separate polynomial setup preserved. All output writes cost Omega(N) words; the fixed-width two-integer-per-complex-coordinate format with shared a has Theta_d(Nn) bits. Plan reuse can improve constants for repeated calls but is neither required nor used to remove a cold charge.

## 7. Fresh controls and their limits

fresh_controls.py was written for this packet. It does not execute or import any inherited research program. It reimplements integer-grid complex primitives, the chirp recurrence and both guarded cyclic solves. Its high-precision reference engine uses outward integer interval arithmetic, rational Machin bounds, interval Taylor sums and integer-square-root enclosures.

Each canonical reference chirp is enclosed independently using binary exponentiation of the interval q at the reduced integer exponent j(j-1)/2 modulo N, rather than the executor's two-step chirp recurrence. This reference work is test instrumentation, not part of the linear executor. The references use extra interval precision to certify every seed and residual; they do not change the actual a-grid and p-grid arithmetic or the accepted seed-error condition. The original matrix residual is enclosed as L C R y-x, with an independent finite-field check against entrywise Q. Using sigma_min(Q)>=4/N and ||Q||<=4, each nonzero vector has the exact rational certificate

    ||y-Q^(-1)x||_2/||Q^(-1)x||_2
       <= N ||Q y-x||_2/||x||_2 <=1/8.

The actual comparisons are squared integer comparisons; the decimal summaries are only for readability.

CHECK_RESULTS.json records:

- 162 canonical full-vector cases: d in {1,2,4}; N in {5,7,9,15,17,31,33,65,129}; zero, minimum nonzero impulse, maximum complex constant, maximum alternating, random dyadic and mixed-scale vectors. Each nonzero case checks all N returned coordinates, both guards, the prescribed a/D/p, full-Q residual and every generated chirp. Zero is checked exactly.
- 2,044 exact precision/description/range-budget cases: every odd N from 5 through 1025, at d in {1,2,4,16}.
- 14 finite-field length cases and 56 full vectors checking Q=L C R, both chirp index formulas and the odd-length wrap. These are orientation controls only; no canonical-complex conditioning or finite-field nonsingularity assertion is inferred from them.

The tests corroborate the written all-N argument. They are not the proof of asymptotic complexity, a practical speed benchmark, or independent acceptance of this packet. The fresh independent reviewer has a separate responsibility to audit (T) and the exact-byte package before promotion.

## 8. Gate decision and what remains open

Subject to independent acceptance of this new extension, the existing b=1 full-Q inverse gate closes at fixed relative output tolerance 1/8 for all odd N>=5 and the explicit represented-input model. The earlier accepted C inverse alone did not pay these chirps; this packet now pays their generation, application, error amplification, exact representation changes, cold setup and all output traffic.

The Hero17 Fourier identity remains

    F_N=P Q^(-1)=P R^(-1) C^(-1) L^(-1).

At b=1, the stated P representation has N(N-2) nonzeros. Its literal application is quadratic. That is a representation-specific count, not a universal lower bound. No uniformly O(N) arbitrary-input P executor is supplied here, so a linear Fourier algorithm remains unproved. A finite-word Fourier composition would additionally need the actual P executor's precision/range/error contract; a full-Q inverse alone does not establish it.

No new general-b, full-chirp-endpoint, arbitrary-primitive-embedding, finite-field stability, arbitrary-precision-target, or fixed IEEE-hardware theorem follows. This is classical composition, not an algorithmic novelty claim. There is no new intake or fusion, and no Sheet or GitHub modification in this task.

## 9. Accepted premises and classical context

The exact input bindings and SHA-256 hashes are in INPUT_BINDINGS.json. The C-inverse author report's accepted hash is 05849dd581dd7b8c70456d598cb60c64b00f25b6efb2e1d3cfda6180e963423d. Its independent verdict accepts the canonical b=1 executor, the explicit dyadic contract, the cold setup and the fixed 1/16 output-relative guarantee. This packet invokes that theorem at D rather than d and does not reuse any unproved extension.

The frozen transfer audit supplies the exact Q=L C R orientation, the remaining P gap and the accepted canonical minimum. The frozen independent C review confirms kappa(C)<=N. The author report, independent review, verdict and transfer audit are included as inert source snapshots for reproducibility.

For classical background only, the official Numerical Recipes routines index lists cyclic tridiagonal solving in section 2.7 and ordinary tridiagonal/banded solving in section 2.4: https://numerical.recipes/routines/. The official LAPACK GTSV documentation describes the conventional tridiagonal solver family: https://netlib.org/lapack/explore-html/d6/ddb/group__gtsv.html. Neither source supplies the finite-word composition proof above, and no third-party solver code is imported.
