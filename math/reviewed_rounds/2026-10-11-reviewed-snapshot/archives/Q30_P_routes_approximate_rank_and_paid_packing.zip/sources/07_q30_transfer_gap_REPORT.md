# Q30 preparation to Fourier execution audit

11 October 2026. Existing-task audit. This report identifies what the current Q30 results do and do not imply. It does not propose a new FFT, open a new theory, change the research queue, or make a novelty claim.

## Result

The current results do not establish an O(N) Fourier transform on arbitrary inputs at all odd lengths. This remains true after the uniform minimum and all-length preparation results are accepted at their stated scopes.

There are two distinct execution gaps in the original route:

1. Q30 prepares the N reciprocal spectral coefficients of one structured operator. Its accepted inverse-application formula still calls a forward and an inverse Fourier transform on the input-dependent vector. Computing the coefficients is not computing these transforms.
2. The original Hero17 identity is F_N Q = P, with Q = L C_h R. After invertibility is known, F_N = P R^(-1) C_h^(-1) L^(-1). This is an exact identity, but neither a uniformly linear-cost arbitrary-input executor for C_h^(-1) nor one for P is supplied by the Q30 preparation theorem. The literal P representation has N(N−2b) nonzeros.

There is also a precision obstruction to the particular fast approximate inverse compiler. The accepted normalized b=1 dominance gives the stronger all-boundary consequence κ_b≥cos(π/N)/sin(π/(2N))≥N/π for every nonchirp b, including b depending on N. For fixed b≥1, the sharper order is κ_b=Θ_b(N^b). No nonchirp parameter schedule in this canonical family satisfies its subpolynomial-conditioning premise. The all-boundary consequence is derived in §5.1; this audit does not itself promote it through a new independent review. The exact place where the existing fallback spends Θ(N log N) work is identified below; this is not a universal Fourier lower bound.

The live Q30 row still records accepted complete fixed-boundary scopes b=1,2,3,4, the fixed-b infinite tail, and the growing-b obstruction. The new general minimum and preparation packets were read separately. During this audit, the final all-length preparation review became available and was added to the source freeze: it accepts author-report SHA-256 dc32b77cade43c5af09dfc817ed3f1cd33f589db87f67c4eb83e853be3918040. The minimum's final reconciliation separately accepts its normalized reflection and b=1 dominance corollaries. These reviewed results close their stated spectral/preparation tasks, while the live Sheet snapshot predates their incorporation. No Sheet update is implied.

## 1 Models and exact objects

Use the negative unnormalized Fourier matrix F_N[k,j]=ω^(−kj), the unitary transform U_N=F_N/√N, and q=ω^(−1)=exp(−2πi/N) in the canonical complex embedding. Let N=2(a+b)+1 be odd. Define

    g(z) = product from r=0 to 2b−1 of (z−q^(a+1+r))
         = sum from r=0 to 2b of c_r z^r,
    h_s = c_(s+b) q^(s(s−1)/2),  −b≤s≤b,
    λ_k = sum_s h_s q^(ks),       μ_k = 1/λ_k.

C_h is the cyclic convolution with this kernel. Its exact spectral identity is

    C_h = U_N* diag(λ) U_N,
    C_h^(-1) = U_N* diag(μ) U_N,                 (1)

when all λ_k are nonzero. The star denotes the complex adjoint.

Three computational statements must stay separate:

- Exact field preparation: the source's coefficient and second-order spectral recurrences prepare λ and, when legal, μ in O(N) unit-cost field operations, with a primitive root supplied. This does not account for bit size or numerical stability and does not apply the inverse to a fresh vector.
- Finite-word preparation: the accepted all-length construction produces dyadic approximations to μ. For n=ceil(log2(N+1)), 2≤t≤n and fixed b, its cold work is O_b(N+(n+t)^20), with every seed, integer division, reciprocal guard and write paid. In full parameters it is O(N(b+1)^3+D^20), D=b+p+n. Its words have 64n bits, with charged multiword operations. It is asymptotically O_b(N) for fixed b, not a constant independent of b and not O(N) bit work.
- Arbitrary-input execution: given a new represented vector x, produce all N coordinates of the desired operator applied to x. Neither of the preceding preparation results is this operation.

The accepted output format uses Θ_b(Nn) bits in its fixed-width format. Reading N constant-word input coordinates and writing N output coordinates costs Ω(N) word operations, and these linear costs must be included even when an internal packed operation is cheap. They are compatible with an O(N) word target; they do not prove a logarithmic lower bound.

## 2 What has actually been proved

The original Hero17 interface [S2, Theorems 4–5] gives the following matrices with the stated orientation:

    Q_(j+s,j) = c_(s+b) ω^(j(s−b)),  −b≤s≤b,
    L_(t,t) = ω^(t(t−1)/2),
    R_(j,j) = ω^(−j(j−1)/2−bj),
    Q = L C_h R,      P = F_N Q.                         (2)

P has column-band radius a. The scalar phase identity proving Q=L C_h R is

    [(j+s)(j+s−1)−j(j−1)−s(s−1)]/2 − bj = j(s−b).

This equality is exact and cheap to state. Its algorithmic content depends on how the convolution, its inverse, and the other factor are applied.

The independently reviewed uniform minimum result [S3, S4] proves, for the canonical nonchirp domain N≥2b+3,

    σ = min_k |λ_k| = 2^b product_(j=1)^b sin((2j−1)π/N),

with precisely the three central minimizers. The full-chirp endpoint N=2b+1 is separate and has all |λ_k|=√N. The independent adversarial audit [S4] found no gap in the analytic argument. The independently accepted all-length preparation result [S5] uses this floor and a first-order fixed-grid scan with reduced seed angles. It does not numerically evaluate the potentially unstable original second-order spectral recurrence.

For each fixed b≥1, the spectral bounds give

    σ=Θ_b(N^(−b)),  1≤max|λ_k|≤4^b,
    κ(C_h)=Θ_b(N^b).                                   (3)

Nonsingularity turns the conditional algebraic rearrangement in (2) into an exact factor identity over the canonical complex numbers. It does not establish the application-cost assertion

    “Every factor in F_N = P R^(-1) C_h^(-1) L^(-1)
     has a uniformly generated O(N) arbitrary-input executor.”

That assertion is absent. It must not be substituted for the proved identities. Nor do canonical-complex positive inequalities extend automatically to all primitive embeddings or finite fields; the accepted source includes root-specific singular finite-field countercontrols.

## 3 Costed dependency diagram

The diagram separates parameter-only preparation from each fresh-input application. B is the boundary parameter b, not a machine-word size. T_U(N,r) denotes a fully charged Fourier routine at relative normwise error 2^(−r), on legal represented inputs.

    PARAMETER BRANCH (independent of the fresh input x)
    N,b,t
      ↓ validate integers and construct reduced phase seeds/kernel
      ↓ paid setup O(D^20), scratch O(D^8)
    first-order λ scan, reciprocal guards, μ divisions, N writes
      ↓ O(N(b+1)^3) word work; O(N(b+1)) output words
    stored diag(μ) coefficients, consumed at the matching stage below

    FRESH INPUT BRANCH
    read all N coordinates x                         Ω(N) traffic
      ↓
    apply L^(-1)                                     O(N), paid phases
      ↓
    apply U_N                                        T_U(N,r)
      ↓
    apply stored diag(μ)                             O_b(N), guarded rounding
      ↓
    apply U_N*                                       T_U(N,r)
      ↓
    apply R^(-1)                                     O(N), paid phases
      ↓ now approximates Q^(-1)x
    apply P                                          Θ(N(N−2b)) literal band work
      ↓                                              O(N) alternative NOT PROVIDED
    scale by 1/√N if unitary Fourier is requested     O(N), paid scale
      ↓
    write all N Fourier outputs                      Ω(N) traffic

A formula for a phase coefficient is not a free transcendental instruction. O(N) diagonal execution presumes paid coefficient generation, word/range legality, and a charged rounding budget; the underlying source gives these qualifications explicitly. Preparation of P's numerical coefficients and certification of its executor are separate obligations, not included in the μ scan.

For C_h^(-1) alone, the cold ledger is

    Prep_μ + Prep_diagonal_execution
    + 2 T_U(N,r) + O_b(N) + paid precision/range conversions.  (4)

For the Hero17 Fourier factor route, add chirp setup/application, P setup/application, normalization, and final output. Fourier coefficients may be shared or indexed by a paid root table; one need not materialize the whole P. The diagram makes no claim that dense storage is mandatory. It records that an O(N)-cost P application theorem is missing.

Preparing μ once can amortize Prep_μ over many inputs. It does not remove the two input-dependent transforms in (4) or the application of P.

## 4 The exact P application gap

Each column Q e_j is described by a nonzero polynomial of degree exactly 2b whose roots are precisely the 2b forbidden Fourier frequencies. The evaluation points are N distinct roots of unity. A degree-2b nonzero polynomial with those 2b distinct roots has no additional root among the other evaluation points. Consequently every column of P=F_N Q has exactly N−2b=2a+1 nonzero entries, not merely at most that many. Thus

    nnz(P)=N(N−2b).                                    (5)

A literal column-band multiply visits every one of those entries. Its arithmetic and coefficient-access count is Θ(N(N−2b)); an explicit P array has that many scalar slots. At fixed b, both are Θ(N²). At a fixed a, the band multiply is O_a(N), but then b=(N−1)/2−a grows, so one cannot import the fixed-b constant-word preparation theorem as a b-uniform O(N) statement.

Equation (5) is a representation count, not a matrix-vector complexity lower bound. Dense matrices can have short structured circuits. This report has not proved that P lacks one; it has identified the missing executor in this specific claimed transfer.

The endpoints show why neither side disappears for free:

- b=0: Q=I, hence P=F_N. Preparing the all-one inverse multipliers solves nothing about Fourier execution.
- a=0, b=(N−1)/2: all c_r=1 and a direct geometric sum in (2) gives

      P_(j,j)=N ω^(−j²−bj),    P_(k,j)=0 for k≠j.

  Hence Q^(-1)=P^(-1)F_N and C_h^(-1)=R P^(-1)F_N L. Conversely F_N=P R^(-1)C_h^(-1)L^(-1). Apart from paid diagonal phases and normalization, arbitrary-input inverse-chirp convolution and Fourier application are equivalent. Flat spectrum and O(N) coefficient preparation do not provide the missing executor at this endpoint.

This endpoint equivalence is a specialization of the existing identities, not a new algorithm or a proof of impossibility.

## 5 Conditioning and the hidden transform cost

### 5.1 Uniform conditioning consequence and the accepted error contract

Put M0=(N−1)/2, θ=π/N, and E_m^(b)=λ_(k0+m)/λ_k0 for centered −M0≤m≤M0. Because the accepted minimum is |λ_k0|, κ_b=max_m |E_m^(b)|. The accepted root-pair product depends on b only through s_b=sin²((2b+1/2)θ), and every factor is increasing in s_b for m≥2; m=0,±1 have modulus one. For 1≤b≤M0−1, (2b+1/2)θ lies in [5θ/2,π−5θ/2]. Its smallest sine square is attained at the two endpoints b=1 and b=M0−1. Hence every normalized mode dominates the b=1 mode, and taking maxima gives κ_b≥κ_1. This uses exactly the final accepted comparison [S4, additional corollaries 2–3], including the N=5 single-b case.

For completeness the exact b=1 maximum can be checked directly. Write y=sin²(mθ). Then H_2=4y+exp(2iθ)−1 and |H_2|² is a convex quadratic in y. The grid has 0≤y≤cos²(θ/2), with both endpoints attained. At y=0 the modulus is 2sin θ; at y=cos²(θ/2) it is 4cos θ cos(θ/2). The latter is larger for 0<θ≤π/5, since cos θ>sin(θ/2). Dividing by σ_1=2sin θ yields

    κ_b ≥ κ_1 = cos θ / sin(θ/2) ≥ N/π.                (3a)

The final inequality uses cos θ≥1/2 and sin(θ/2)≤π/(2N). Therefore log κ_b≥log N−log π for every nonchirp b, even a varying b(N). No choice within this nonchirp family meets log κ=o(log N). This is an obstruction to that sufficient compiler hypothesis, not a theorem that all inverse algorithms fail. The endpoint b=M0 is excluded: it has κ=1 and the Fourier equivalence in §4.

The following fixed-b analysis additionally locates a supported conventional execution cost; growing b may require much larger precision and cannot borrow the fixed-b word-width conclusion.

Let M=max|μ_k|, m=min|μ_k|, κ=M/m. The accepted Q30 contract [S1, §1] states that approximate forward/inverse transforms of relative error δ, multiplier sup error η, and diagonal-execution norm error ρ produce

    ||y−C_h^(-1)x||
      ≤ [M(2δ+δ²)+(η+ρ)(1+δ)²] ||x||.                 (6)

Since ||C_h^(-1)x||≥m||x||, one sufficient output-relative rule is η+ρ≤δM and δ≤ε/(4κ). Approximate endpoint chirps need their own additional error allocations. All intermediates must satisfy the transform's representation contract.

The κ factor is not just careless norm arithmetic in a black-box theorem of this form. In spectral coordinates, choose unit input at an index where |μ|=m and allow the forward routine an error δ in a direction where |μ|=M. A rank-one perturbation of operator norm δ realizes this as an abstract transform satisfying only the pointwise norm guarantee. With exact diagonal and final inverse transform, the output-relative error equals κδ. Therefore a guarantee based only on the stated per-call normwise contract cannot allow arbitrary such errors at δ≫ε/κ. This is sharpness of the norm-only implication, not an implementation of the adverse map in the represented finite-word model. It does not assert that the actual Q01 executor realizes the adverse direction, nor rule out a sharper error analysis for a particular composed algorithm.

For fixed b≥1 and fixed nonzero target ε,

    r = ceil(log2(4κ/ε)) = b log2 N + O_b,ε(1).         (7)

Thus log(κ/ε)=o(log N) is false. Scalar rescaling leaves κ unchanged. Increasing the precision used to prepare μ does not reduce κ or enlarge the supported Fourier-executor domain.

### 5.2 What Q01 actually promises

The accepted paired Q01 theorem and review [S6–S8] give, for represented O(c log N)-bit dyadics, polynomial dynamic range, and supplied 2≤r≤n,

    T_U(N,r)=O_c(N(r+log2(n+1))) words of work,
    storage O_c(N) words.                              (8)

In particular fixed or inverse-polylog accuracy gives O(N log log N), not O(N). Accuracy r=Θ(log N) gives only O(N log N). The finite-precision and exact-field objectives remain different.

The fast interpolation branch explicitly requires r≤n/4, backend precision r+10 within its own domain, distinct stencil indices, and a literal preparation cap. Equation (7) eventually fails the r≤n/4 test. For b≥2 it also eventually lies outside r≤n; for b=1 the upper-domain status depends on the fixed constants, so it must be checked rather than assumed. The accepted separate arbitrary-r fallback remains available with width C(c)(n+r+1), or with charged multiword arithmetic. For fixed b and fixed ε this is still O_b,c(log N) bits per word; it is the fallback proposition, not an extension of the fast theorem.

### 5.3 Exact cost location in the existing fallback

[S6, §4] implements one arbitrary-length transform by Bluestein with H=nextpow2(2N−1), 2N≤H<4N. It executes three explicit scalar radix-2 transforms: one on the input chirp, one on the convolution kernel, and one inverse transform after pointwise multiplication. Each length-H transform has log2 H stages and H/2 butterflies per stage. Therefore the literal executor performs exactly

    3 H log2 H / 2

butterfly invocations, in addition to O(N) passes and paid polynomial-precision coefficient certificates. Its chosen lattice precision is r+log2 H+ceil(log2(log2 H+1))+13. This gives the stated O(N log N+poly(n+r)) cold work; for this fixed, full-stage scalar executor, the butterfly count itself is Θ(N log N).

Two unshared calls in (4) perform 6 H log2 H/2 such invocations. Reusing a parameter-only kernel transform can reduce a constant, but the fresh-input forward/inverse transforms retain their full stage loops. No source theorem removes those loops.

At fixed b, fixed ε, and sufficiently large N so the selected multiplier precision remains in 2≤t≤n, the already-proved preparation and supported fallback can be combined into a conditioned inverse execution with O_b(N log N) word work and O_b(N) words, subject to the stated diagonal rounding and representation checks. This identifies a usable conventional cost scale; it is not an O(N) Fourier result and does not pay for P. Target precisions outside the preparation theorem's domain still need separately charged treatment.

There is also a visible cost in a hypothetical forced interpolation path: it retains 2h+2=O(r+1) samples per output, with h=16(r+16)+1, and explicitly performs those sums. At r=Θ(log N) that literal stencil ledger is Θ(N log N), while its table-preparation guard is another restriction. The actual algorithm chooses the supported fallback instead of assuming an out-of-range fast branch.

No statement here establishes Ω(N log N) for every Fourier or inverse-convolution algorithm. The count is a proof about the cited stage/stencil executors.

## 6 Why another existing compiler does not fill the gap automatically

### Conditioned macro compiler Q06

The existing local-template compiler [S9, T1] needs an actual layer factorization, supplied or cheaply generated routes/templates, paid coefficient certification, and bounds on both prefix norms and inverse-prefix norms. It charges O(N) per full-vector layer for gathers, normalization, key packing, lookup, scaling and scatter; the table lookup is not an O(1)-cost whole-vector operation. Its ledger is O(NL+table preparation+coefficient preparation), subject to the key-width and template-diversity budget.

The μ array does not supply that layer factorization, its prefix bounds, or an O(1)-layer Fourier circuit. Calling C_h^(-1) a single macro gate would assume the very executor being sought. Paid balancing is useful only within its proved bounds; a scalar normalization cannot change the terminal inverse's κ from (3).

### Exact regular-source compiler Q31

The accepted sparse-jet theorem [S10, §§2–4] says: a uniformly generated scalar arithmetic program Φ_N, regular at the origin, whose formal quadratic jet is (1/2)x^T F_N x, yields an arbitrary-input Fourier circuit in O(s(N)+N) field/index work and storage. Every inverse gate must have a proved nonzero base value. Constants, code, addressing, differentiation, transpose transport and all N output writes are charged. The source must be one shared regular program, not support-selected branches. For finite fields the identity must hold formally, not merely on the finite set of input points.

In the existing transport formulation the required identity is P_transport^T H P_transport=F_N; P_transport is a different object from the banded P in (2). Uniform inexpensive construction of that transport remains missing in the live Q31 row. Finite-word rounding and lookup do not provide an exact origin-regular arithmetic source and cannot be differentiated as though they were one.

Q30's parameter-only recurrence for λ has no arbitrary x and no Fourier quadratic-jet certificate. It cannot be inserted as the missing Φ_N. This paragraph records a dependency boundary between already-existing tasks, not a proposed fusion.

## 7 One minimal next existing task

Continue Q30 with the first accepted nonchirp case b=1, but require an arbitrary-input inverse executor rather than another coefficient preparation or spectral minimum result.

Precise success criterion: for every fixed input-description constant c, every odd N≥5, and represented O(cn)-bit dyadic x of polynomial dynamic range, construct and prove a cold algorithm returning all N dyadic coordinates y with

    ||y−C_(h^(1))^(-1)x||_2
       ≤ (1/16) ||C_(h^(1))^(-1)x||_2,

in O_c(N+poly(n))=O_c(N) asymptotic word work and O_c(N) words on an explicitly stated C(c)n-bit integer multiplication/division RAM. Here h_(-1)=q, h_0=2cos(π/N), h_1=1, q=exp(−2πi/N). N, the canonical root specification, and x are the inputs; no transformed x, uncharged spectral oracle, uncharged dense inverse, or uncharged preprocessing is supplied. All coefficient generation, elimination/recurrence guards, rounding, dynamic range, input reads and output writes must be covered by the proof. Any invoked Fourier call must be included at its actual charged cost, which currently prevents this O(N) target by the present route. Finite tests can corroborate the all-N proof but cannot replace it.

The fixed 1/16 tolerance deliberately avoids conflating this first application gate with a new all-precision theorem. A theorem for growing precision would be a later, separately stated extension. Failure of one candidate executor should be reported with its exact error or cost obstruction, not generalized to all solvers.

Even success would close only the b=1 inverse-application gate. It would not prove a linear Fourier transform, because applying its P still requires a separate charged structure theorem. The full-chirp inverse endpoint already has the stronger property of being Fourier-equivalent, so claiming its O(N) executor would need essentially the missing arbitrary-input Fourier execution result itself.

## 8 Evidence and verification

The audit read the live Research queue rows Q30, Q01, Q06 and Q31 after checking spreadsheet metadata. Full live-cell snapshots remain local and are excluded from the deliverable. Minimal read provenance and snapshot hashes are included. Q30 is row 33 in [the existing research Sheet](https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit#gid=1877766156&range=A33:L33). No Sheet, repository, source artifact, intake queue or fusion queue was edited.

The archive's accepted fixed-b tail/review, b=3 review, and b=4 review were read alongside the new candidates. Local source hashes and original locations are in INPUT_BINDINGS.json. Repository texts were fetched read-only, saved byte-exactly and checked against their Git blob identities; REPOSITORY_PINS.json and SOURCE_VERIFICATION.json record the binding. The original research programs were neither executed nor imported.

Freshly written fresh_interface_checks.py verifies Q=L C_h R, the exact P support count and endpoint diagonal formula in 135 odd-length/boundary finite-field cases through N=31. It also checks exact rational realizations of the black-box κδ error example and the literal fallback loop count. All 76,611 assertions pass. These finite controls check signs, conventions and bookkeeping; the general proofs are in §§4–5. They are not canonical complex spectral evidence, stability evidence, speed measurements or general lower bounds.

### Sources

- S1. Accepted INVERSE_MULTIPLIER_CONTRACT, §§1–3. [Repository](https://github.com/AgentSlop-Si/research/blob/main/math/current/research_cycle_0958/backends/final_v1/INVERSE_MULTIPLIER_CONTRACT.md), Git blob 24bde85532615efa0393d03dc69d8a0f454c4412; recovered exact SHA-256 19d08dee1b75098d579612b054f53f2a86e9d793e08e31bee2ec011f8bd7dd6c.
- S2. Hero17 Phase 16 PROOF_CERTIFICATE, Theorems 1–5. [Repository](https://github.com/AgentSlop-Si/research/blob/main/math/current/research_finalization_0923/intake/extracted/fft_hero17_phase16_fourier_green_interface_2026-10-10/PROOF_CERTIFICATE.md), Git blob 4e1c15d1632d64a922fa1534f1e3ed406cd04785.
- S3. Existing Q30 uniform minimum candidate, REPORT and PROOF_OUTLINE, frozen in sources/local_00 and local_01 snapshots; exact hashes in INPUT_BINDINGS.json.
- S4. Existing Q30 independent adversarial minimum audit, frozen in sources/local_03 snapshot, plus final accepted reconciliation in sources/MINIMUM_FINAL_RECONCILIATION.md and its binding. Exact hashes in INPUT_BINDINGS.json.
- S5. Existing Q30 all-length preparation final author REPORT, frozen in sources/local_02 snapshot, with independent acceptance in sources/PREPARATION_REVIEW.md and PREPARATION_REVIEW_SEAL.json. Exact hashes in INPUT_BINDINGS.json.
- S6. Packed all-length theorem, §§2–4, including its separate arbitrary-precision fallback. [Repository](https://github.com/AgentSlop-Si/research/blob/main/math/reviewed-results/2026-10-10-packed-fft/theorems/CONDITIONAL_ALL_LENGTH_THEOREM.md), Git blob 48d5b668af35013a0cc500cf52897cfb8c66a70d.
- S7. Paired dyadic packed theorem. [Repository](https://github.com/AgentSlop-Si/research/blob/main/math/reviewed-results/2026-10-10-packed-fft/theorems/DYADIC_PACKED_THEOREM.md), Git blob 331567a9a5217bc8044458d690acc83ad989d1ab.
- S8. Independent acceptance of the paired all-length theorem. [Repository](https://github.com/AgentSlop-Si/research/blob/main/math/reviewed-results/2026-10-10-packed-fft/reviews/ALL_LENGTH_INDEPENDENT_ACCEPTANCE.md), Git blob 854a30fc736354ba480bfea6cbdaecc30d4ea9b8.
- S9. Existing structured compiler proof, T1 and T7 only. [Repository](https://github.com/AgentSlop-Si/research/blob/main/math/current/research_finalization_0923/fusions/final_v1/PROOF_DRAFTS.md), Git blob 80eac2af06c6918b26f392c00d475ccbd9335525. Its historical directory name does not denote new work in this audit.
- S10. Existing coherent sparse-jet lifting theorem, §§2–4 and 7. [Repository](https://github.com/AgentSlop-Si/research/blob/main/math/current/research_finalization_0923/intake/extracted/fft_coherent_sparse_jet_lifting_2026-10-10/fft_sparse_jet_lifting/THEORY.md), Git blob 0ee8db9c43dd469a1c9303ab673db2315efbca86.

The conclusion is an execution and model audit. It leaves the spectral/preparation progress intact while locating the operations and hypotheses that an actual linear all-odd Fourier algorithm would still have to supply.
