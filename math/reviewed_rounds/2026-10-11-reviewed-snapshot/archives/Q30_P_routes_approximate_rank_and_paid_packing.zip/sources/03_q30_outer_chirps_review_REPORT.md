# Q30 b1 full Q inverse independent acceptance

11 October 2026. PASS for the stated canonical b=1 full-Q inverse, with relative output 2-norm error at most 1/8 and cold O_d(N+n^20) word work. The accepted author report has SHA-256 ed24fefa93bd9a6eb34fa1efa7aaab41ed063d035248b5148a2485fbc558743b. AUTHOR_BYTE_VERIFICATION.json binds the final author archive and its embedded files. This is an acceptance of the stated finite-word composition theorem, not a new Fourier algorithm or a novelty claim.

The extension pays for both quadratic-chirp diagonals around the already accepted C inverse. It includes their cold seed, recurrence drift, applications, representation change, condition-number amplification, final output rounding, and memory traffic. Applying the remaining Hero17 P remains an open execution requirement.

## Exact object and orientation

For odd N>=5, set n=ceil(log2(N+1)), q=exp(-2 pi i/N), omega=q^(-1), c=cos(pi/N), and (Sv)_j=v_(j-1) with cyclic indexing. The accepted nonchirp operator is C=S+2c I+q S^(-1). At b=1 the original factorization is

    Q=L C R,
    L_j=omega^(j(j-1)/2), R_j=omega^(-j(j+1)/2).

Consequently Q^(-1)=R^(-1) C^(-1) L^(-1). The left input multiplier is q^(j(j-1)/2), and the right output multiplier is q^(-j(j+1)/2). With ell_j=q^(j(j-1)/2), the latter is conjugate(ell_(j+1)), including the essential index shift. Conjugate(ell_j) would be wrong. Odd N gives ell_N=1 and makes the diagonal expressions periodic across the cyclic wrap.

I independently checked the original entry formula

    Q_(j-1,j)=q^(2j), Q_(j,j)=2c q^j, Q_(j+1,j)=1.

The canonical full-vector residual controls evaluate these entries directly. They do not certify the output merely by multiplying it back through the same implemented L C R factorization. Exact finite-field checks at every odd length from 5 through 67 also verify all three entries and both inverse-chirp exponents, including wrapped indices. These field checks establish orientation only and do not import canonical complex conditioning into finite fields.

## Accepted input contract and its required enlargement

Fix the original description constant d>=1. Each real and imaginary input component must be an exactly represented dyadic of magnitude at most 2^(dn), with denominator exponent at most dn. Arbitrarily long encodings or unbounded-precision real inputs are outside the contract. All coordinates are read and all outputs are written; extra padding has its actual parsing charge.

The author uses

    a=(2d+20)n+64, u=2^(-a), D=2d+42,
    p=(2D+12)n+64, W=1024(d+64)n.

The initial rounded chirp multiplication returns an a-grid vector b. Because n>=3, a<=Dn: the 64-bit additive term is absorbed by 22n>=66. Also |b_j|<2^(dn+2)<=2^(Dn). Thus every Cartesian component satisfies the accepted inner executor's D-description contract. The a-grid vector converts exactly to the p-grid because p>=a. This is a legal invocation of the old theorem with a new fixed constant D. Invoking it with the original d would not have been justified.

D depends only on the fixed d, so its inclusion preserves O_d constants. Neither D, word width, nor output format is uniform over unbounded growing d. The chosen W dominates the accepted inner width 256(D+20)n and the new mixed-grid intermediates. The stated model uses charged integer multiplication and Euclidean division, or a d-dependent constant number of 64n-bit limbs. It is not fixed IEEE arithmetic or linear bit-time computation.

## Independent chirp error calculation

The stored qhat has complex absolute error less than u. Hence |qhat|<=1+u; exact unit modulus is not assumed. Let the rounded ratio and phase recurrences be

    that_0=ellhat_0=1,
    ellhat_(j+1)=round_a(ellhat_j that_j),
    that_(j+1)=round_a(that_j qhat).

Each complex product is formed with exact integer numerator arithmetic, followed by one nearest-grid rounding of each Cartesian component. Its complex rounding error is below u. The author establishes N^2 u<=1/8 and obtains gamma=4N^2u as a bound for every phase coefficient through ellhat_N. I verified its geometric-sum proof, including possible radial growth.

For an independent check of the constants, write e_j=|that_j-q^j| and h_j=|ellhat_j-ell_j|. The exact nonnegative majorants satisfy

    e_(j+1)<=(1+u)e_j+2u,
    h_(j+1)<=(1+e_j)h_j+e_j+u.

Since N>=5 and Nu<=1/(8N)<=1/40, the first recurrence gives e_j<=2ju/(1-ju)<3ju. Thus sum_(j<N)e_j<=(3/2)N^2u<=3/16. Expanding products, or summing their elementary symmetric terms, bounds the second recurrence by

    h_N <= [sum e_j+Nu]/[1-sum e_j]
         <= (136/65)N^2u <4N^2u.

The same argument holds at every earlier index. This independent rational majorant confirms the author's conservative gamma without assuming that rounding preserves phase or norm. My separate finite majorant controls run at the much larger boundary u=1/(8N^2), for 100 odd lengths, rather than relying only on the exceptionally small production u.

The single shared sequence also has exactly the same integer-grid values as two separately evolved inverse-chirp sequences. My controls compare them bit-for-bit, including nearest rounding and conjugation. The shared implementation makes exactly 2N complex products when the unused last ratio is also formed.

## Cold coefficients are paid

The outer seed is computed from rational Machin bounds for pi, rational alternating Taylor bounds for sine and cosine at pi/N, and outward dyadic interval rounding. For K=a+16 and e=2^(-K), the resulting c and s intervals have width at most e and lie in [0,1]. Each Cartesian interval for (c^2-s^2)-2isc has width at most 4e. Rounding its midpoint to the a-grid gives complex error at most sqrt(2)(u/2+2e)<u.

The constant number of trigonometric seed computations is independent of N as a count. Their bit precision is O_d(n), with rational terms and denominator sizes charged polynomially in n. The accepted inner seed procedure is independently paid at its larger p and includes its certified square roots and guards. The loose O_d(n^20) setup and O_d(n^8) scratch bounds safely cover both constructions with schoolbook multiword operations.

The executor does not evaluate N transcendental phases, form huge quadratic phase angles, use a free primitive root, or import a transformed input. Its N phases are obtained by the explicitly charged recurrence. The test reference engine uses higher interval precision and binary powers for certification; that instrumentation is separate from the executor and is not substituted for its cold-cost argument.

## Full output error and conditioning

Let A=L^(-1), B=R^(-1), f=Ax, z=C^(-1)f, and y*=Bz. Exact A and B are unitary. The accepted canonical lower singular value is 2 sin(pi/N)>=4/N, while ||C||_2<=4, giving kappa(C)=kappa(Q)<=N. The known condition-number order is Theta(N), not O(1).

For nonzero legal x, ||x||_2>=2^(-dn). The prechirped represented b satisfies

    ||b-f||_2 <= gamma||x||_2+sqrt(N)u.

Therefore its propagated error, relative to the desired inverse output, is bounded by

    ||C^(-1)b-z||_2/||z||_2 <= eta,
    eta=N[gamma+sqrt(N)2^(dn)u].

The factor N is essential. The report does not confuse small diagonal error with small output-relative inverse error in a condition-number-independent way.

Invoke the accepted solver only at epsilon=1/16. If its output is zhat, then

    ||zhat-z||_2/||z||_2 <= epsilon+(1+epsilon)eta.

The output diagonal has norm at most 1+gamma and operator error at most gamma. Each final mixed-grid product is down-rounded once to a. Since ||z||_2>=||x||_2/4, these final roundings contribute at most zeta=4sqrt(N)2^(dn)u. The total relative error is bounded by

    (1+gamma)[epsilon+(1+epsilon)eta]+gamma+zeta.

All three of gamma, eta, and zeta are below 1/1024 under the prescribed parameters. Substitution proves a strict bound below 1/8. The author's stronger common envelope xi=2^(-(d+16)n-64)<=2^(-115) is also valid. My parameter checks replace sqrt(N) by the larger N and still pass, but the universal conclusion comes from the displayed inequalities, not enumeration.

This proof covers every legal vector, including tiny components, severe cancellation, and mixed magnitudes. It requires no relative accuracy for individual coordinates. If x=0, the algorithm writes exact zeros. If x is nonzero, eta<1 ensures the represented prechirped vector cannot be zero. Grid underflow is not a machine convention here: every stored integer is exact, and any component rounded to zero is already included in the absolute-error budget. The minimum allowed nonzero dyadics are explicitly tested.

## Ranges and literal operation counts

The ratio and phase moduli stay below two. The represented prechirped input has sup norm below 2^(dn+2), and the accepted inner range bounds give |zhat_j|<2^((d+2)n+8). The final output has magnitude below 2^((d+2)n+10).

A final coefficient with a-grid numerator U and an inner p-grid numerator V is multiplied as an exact complex integer product. Dividing that product by 2^p and rounding yields the a-grid result. No additional approximate downcast is hidden. The final product has O(a+p+(d+2)n) bits. The inner division intermediates, guard products, shifts and address integers also fit the advertised W. Longer cold-setup rationals use charged multiword arithmetic rather than being treated as single words.

The literal nonzero-input scan makes 2N chirp products, N input-diagonal products, 7N-2 products and two divisions for the accepted C solver, and N final mixed-grid products. Total: 11N-2 complex products and two complex divisions. Input scans, zero detection, conjugation, exact grid conversion, reversals, guards, addressing, and all output writes contribute O_d(N) more work. The two cold setups contribute O_d(n^20). A few vectors plus setup scratch give O_d(N+n^8) storage. The separate bit-work claim is O_d(N n^2+n^20), and fixed-width output has Theta_d(Nn) bits.

## Fresh verification and evidence

Both review programs were written for this review. No author or inherited research program was executed or imported. They use standard-library rational and integer arithmetic only. The full-vector test computes a rigorous upper bound on the squared residual norm directly from the original Q entries, then certifies

    relative forward error <= N ||Q y-x||_2/||x||_2.

All decisive comparisons are exact rational inequalities. Approximate decimal summaries are informational only. In particular an approximate dense inverse is not used as ground truth.

- 252 canonical full-Q cases use d in {1,2,5} and N in {5,7,9,11,15,17,31,33,49,65,97,129,257,513}, with the exact prescribed a, D, and p. They include zero, a minimum nonzero last-coordinate imaginary impulse, maximum complex constants, extreme mixed-scale alternation, cancellation-heavy dyadics, and reproducibly random legal dyadics. Every case passes the 1/8 residual certificate. The maximum certified squared relative error is below 5.41e-75.
- 32 finite-field length controls check the entrywise orientation, both inverse diagonals, and cyclic wrapping at every odd N from 5 through 67.
- 10,260 precision, input-description and integer-range cases cover every odd N from 5 through 4097, plus five larger lengths through 1,048,577, at d in {1,2,5,19,257}. The extra large d values are finite robustness controls, not a growing-d complexity theorem.
- 100 exact recurrence-majorant cases cover every odd N from 5 through 203 at u=1/(8N^2). Every accumulated phase-error majorant is below gamma; the largest ratio is below 0.267.

The canonical controls also check the mandatory inner coefficient and denominator guards, exact input conversion, final down-rounding, bit ranges, shared-versus-separate chirp agreement, and literal multiplication/division counts. The scripts and full certificates are included. Finite controls support the mathematical proof; they are neither an all-N proof nor a timing-based complexity argument.

## Scope and remaining execution requirement

This accepts the full matrix Q inverse at b=1, for odd N>=5, the canonical complex embedding, fixed description constant d, and relative tolerance 1/8. The phrase full Q means that both outer diagonals are now included. It does not mean the separate full-chirp endpoint b=(N-1)/2. The report makes no general-b, arbitrary-embedding, finite-field stability, arbitrary target-precision, or fixed-hardware claim.

The Hero17 identity remains F_N=P Q^(-1). At b=1, the literal P representation has N(N-2) nonzeros and its literal multiply is quadratic. This count is not a lower bound against a better structured executor. A uniformly linear arbitrary-input P executor with its own coefficient, representation, error and output contracts is still absent. Thus the new accepted inverse does not establish a linear Fourier algorithm. It also supplies no origin-regular scalar source Phi for a sparse-jet compiler. Rounding and finite-word operations cannot silently serve as an exact differentiable arithmetic source.

Chirp multiplication and cyclic solving are classical operations. The [Numerical Recipes routines index](https://numerical.recipes/routines/) documents the classical cyclic/tridiagonal solver class. The primary [FFTW3 paper](https://www.fftw.org/fftw-paper-ieee.pdf) provides conventional FFT context and distinguishes parameter planning from data-dependent execution. Neither source proves this packet's finite-word estimate, and no code was imported from them. This review is an instance-specific execution/model certificate and does not establish historical originality.

The accepted predecessor reports, direct-inverse acceptance seal, and transfer audit are frozen in BASELINE_BINDINGS.json. Final author bytes and the review seal are separately bound. No Sheet, GitHub, intake, fusion, or unrelated research state was changed.
