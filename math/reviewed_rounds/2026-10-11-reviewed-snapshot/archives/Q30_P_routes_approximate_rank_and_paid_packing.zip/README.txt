Q30 remaining P route audit, 11 October 2026.

Read REPORT.md first. This is an author checkpoint awaiting independent review.
The newly scoped result excludes bounded-rank approximation of one ordinary
large off-diagonal block at the stated constant spectral tolerances. A separate
conditional reduction specifies all precision and carry costs for exact packed
convolution. No linear special-product backend or Fourier executor is supplied.

Reproduce the fresh controls with:
python fresh_controls.py
Python 3, its standard library, and mpmath are required. Do not execute any
frozen source artifact. Frozen sources here are mathematical text and verdicts.

The test-sized packed multiplication uses generic Python integers and is not
claimed linear-time or FFT-free. It verifies algebra and carries, not backend
complexity. Canonical complex controls are numerical corroboration, not interval
certificates. All-N arguments are in REPORT.md.

No Sheet or GitHub write belongs to this task. The bounded audit ends at the
stated special-product lemma; no additional search is in progress.
