# Prefix manuscript fidelity review

11 October 2026 UTC. Decision: PASS. The frozen 11-page working note faithfully presents the accepted theorem, retains its limits, and is readable on every page. No mathematical, transcription, counting, or presentation correction is required. This decision clears the exact PDF, LaTeX source, and source package identified below; it is a fidelity review, not a new theorem-proof audit or a historical-priority determination.

## Exact deliverables checked

All three files were freshly and independently materialized from Library version 0 after the author supplied final frozen pins. Every readback matches the supplied length and SHA-256. The separately delivered PDF and source also match the corresponding members of the sealed package byte for byte.

- PDF: `libfile_78c45eb171c08191b2f53963f2aa4845`, 104,885 bytes, SHA-256 `24448fdfa5652d6c6c8a182cab38c035cd39d96bba37e1b2abf6f5e65c884b19`.
- LaTeX: `libfile_ea8ce3f6559481919dfddff2ec859e21`, 32,673 bytes, SHA-256 `cb9cd8f829ce0efc1bec90eed3f5ef896224238515be25fc204024055aacb9d0`.
- Source package: `libfile_d2e3566fd3e08191b6c589e14cd43813`, 406,953 bytes, SHA-256 `245121a1567f6dc4bf35b2b29b775dadae108e968e3bebb1a3e67f0a42cac36d`.

All 22 declared package payload members verify. The review checks the complete contents rather than accepting the author's presentation map or QA report as evidence by themselves.

## Source binding

The primary theorem is the unchanged 15,027-byte `THEOREM.md`, SHA-256 `290e120fd40a464144c2b92ce23576a21b6aed4c5d0f70603125bba7b9d346b1`. Its source archive is `libfile_38c2907665a88191a9f2a8d6aff48a09`, SHA-256 `57ff2f6d35bc41e0bb8f827fa478866d5b6c990fae8ac7d283759c94a0c1a9fe`.

The accepted scope and proof were compared with the complete independent `REVIEW.md`, `ACCEPTED_STATEMENT.md`, and `ACCEPTANCE.json`. A fresh independent materialization of `libfile_c0c6044d21ec81919e9086451f65ff24` returned the 161,861-byte version-0 archive with SHA-256 `8a3394d996903c49dc5a58732fc6e6a293b771019fa893b8959db011eccfb52a`. Its 25 declared payload members verify. The local review, statement, and decision bytes are identical to their archived counterparts.

The historical comparison is the complete `REVIEW.md` from the prior-work packet, SHA-256 `729240793699e82f6a3f41ef58039ca46c790223219cc361913aa61d07750392`. Its 12,425-byte archive has SHA-256 `f6bffb4b177ba1cb067ce09765af64ff8c853f3fdebd59f3653354c9abd37ada`. The finite q-group dependency and historical D8 theorem and acceptance were read in their unchanged, hash-bound source copies. All 14 original-to-package source bindings match independently.

## Theorem and proof fidelity

The main theorem retains arbitrary finite H of order q^a, distinct primes p and q, a >= 0, and specifically p=2<q. The action is left multiplication on labeled elements; right cosets, full-prefix inclusion in Z, full-prefix exclusion from B, and the absence of translation or automorphism quotients are explicit.

Every claim agrees with the accepted statement: the value np[a(1-1/q)+1-1/p], the if-and-only-if recursive maximal-subgroup optimizer classification, unique recovery of the top subgroup as B, the factorial/power labeled recurrence, and the sufficient strict escape loss p-1 for a>=1. H=1 gives C_p, value p-1, count p!, and the trivial top subgroup. The separate singleton recursion base has value 0, count 1, and no top subgroup.

The original numbered equations map correctly to the typeset equations: (1)->(4), (2)->(5), (3)->(7), (4)->(10)-(11), (5)->(15), (6)->(16), (7)->(17), (8)->(20), (9)->(21), and (10)->(23). All intervening displayed and inline equations were compared too. The A,B-to-alpha,beta coefficient renaming, rank-based checkpoint subset indexing, and D8 V-to-V_4 renaming are consistent presentation changes.

All proof dependencies and transitions are retained: coprime subgroup splitting; every checkpoint rather than a selected subsequence; free-action divisibility; the strict floor-ceiling interval count; the full endpoint loss coefficient p; the three endpoint-divisibility cases in the q-adic identity; the positive loss at p=2; zero-loss aligned paths; the n/q checkpoint; the complete prime-quotient orbit trap; both escape cases including n/q=1; attainment before classification; the exhaustive list of maximal subgroups; the induction within the permitted family; exact nonnegative local deficits; consecutive-block necessity; converse attainment; unique top recovery; and disjoint labeled counting without an extra representative factor.

Appendix A faithfully supplies the inherited finite q-group argument, including normalizer induction, normal maximal subgroups of prime index, pointwise saturation, agreement of boundary stabilizers, the block decomposition, and singleton handling. It imports no pairwise-permutability premise and no general nilpotent theorem.

## Historical D8 result and numerical controls

The older D8 x C_p result remains separately attributed and stronger: value 20p-8 and escaping score at most 18p-7, a loss of 2p-1. The labeled counts T, U, V_4 and A(D8)=2432 match the source, as does A(D8 x C_p)=p!2432^p+2U^2+4V_4^2. At p=3 the stated value 52 and count 203,047,403,520 are correct transcriptions. The displayed escaping order and its fibre expansion retain score 18p-8. Being one below the specialized upper bound is not promoted to a sharpness claim.

All reported finite-control figures agree with the independent acceptance: 29 arithmetic rank spaces, 415,758 edges, 5,598 small paths, 11,200 interval instances, 13 products, 1,287 complete orders, 3,496 actual checkpoint-interval checks, and 50,873,422 subset states across eleven groups. Every table row agrees with the archived exhaustive results. The DP recurrence and its empty-set base are faithfully reported. The text keeps arithmetic p=q checks separate from group hypotheses, labels larger group controls nonexhaustive, and treats every finite control as corroboration rather than a proof premise.

## Related work and scope limits

The contribution description follows the narrowed comparison: the objective-specific maximum and all-optimizer necessity in this mixed-prime class are substantive; unique top recovery and labeled counting are consequences. Classical connectivity, fixed-chain signatures, older coset-dependent constructions with compatibility conditions, and ordinary sum/factorial/product counting receive appropriate credit. Independent branching is not claimed as a new general idea.

The EFK boundary is current: Theorem 2.1 and the principal incidence calculation were recovered; the remaining definitions/Lemma 2.1, much of Section 4, Proposition 5.1 proof, and Section 6 ending remain partly unread. Failed direct substitutions are not treated as a whole-paper exclusion. The note makes no all-nilpotent theorem, enlarged second-Sylow theorem, sharp escaping maximum, journal-acceptance, or worldwide-priority claim. This review checks fidelity to the bounded historical report; it does not claim a new literature search.

## Independent PDF and source checks

All eleven pages were independently rendered at 130 dpi and visually inspected individually. Equations, inequalities, subscripts, superscripts, floor and ceiling delimiters, table values, references, hashes, headers, footers, and page transitions are readable. No clipped equations, overlapping text, missing mathematical glyphs, or unresolved references were found. A span-bound check found no text outside any page.

The frozen LaTeX source was independently rebuilt with two XeLaTeX passes and shell escape disabled. Every rebuilt page is pixel-identical to the frozen PDF at 144 dpi and has identical extracted text. This establishes source/PDF correspondence beyond matching filenames or trusting the build log. The default local format cache was unavailable; using the existing TeX format with explicit font/search paths resolved the environment issue without changing the source.

The fresh Library readbacks have exactly the hashes of that inspected source/PDF pair. The clearance therefore applies to the delivered bytes as well as the local draft. No inherited mathematical program was executed, no theorem reproof was substituted for the requested fidelity review, and no source, Sheet, or GitHub content was changed.

## Verdict

PASS with no required correction. The exact three version-0 deliverables above are cleared as a faithful, readable working-note presentation of the independently accepted H x C_p theorem. The general nilpotent and historical-priority questions remain outside this clearance. Supporting check records accompany this review. Its own Library round-trip receipt is kept outside the review archive to avoid a self-referential hash.
