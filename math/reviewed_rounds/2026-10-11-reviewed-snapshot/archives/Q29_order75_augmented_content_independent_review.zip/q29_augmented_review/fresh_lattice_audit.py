#!/usr/bin/env python3
"""New integer-lattice valuation audit, separate from author pi-J division code."""
import sys,json,hashlib
from pathlib import Path
import sympy as s
sys.set_int_max_str_digits(100000)
HERE=Path(__file__).resolve().parent
q=s.Symbol('q');P=s.Poly(s.cyclotomic_poly(75,q),q);pc=[int(P.nth(i)) for i in range(41)]
def red(a):
 a=list(a)
 while len(a)>40:
  c=a.pop();k=len(a)-40
  for j in range(40):a[k+j]-=c*pc[j]
 return a+[0]*(40-len(a))
def multiply_pi(a):return red([0,0]+list(a)) if False else red([sum(a[i-j] for j in range(3) if 0<=i-j<40) for i in range(42)])
cols=[multiply_pi([int(i==j) for i in range(40)]) for j in range(40)]
M=s.Matrix(40,40,lambda i,j:cols[j][i]); inv=M.inv(); W=5*inv
assert all(x.q==1 for x in W) and M*W==5*s.eye(40)
W=[[int(W[i,j]) for j in range(40)] for i in range(40)]
def residue(a):
 a=[x%5 for x in a]
 for k in range(39,1,-1):
  a[k-1]=(a[k-1]-a[k])%5;a[k-2]=(a[k-2]-a[k])%5
 return a[:2]
def val(a):
 a=list(a);n=0;hasher=hashlib.sha256()
 while True:
  hasher.update((json.dumps(a,separators=(',',':'))+'\n').encode())
  b=[sum(x*y for x,y in zip(row,a)) for row in W]
  if any(x%5 for x in b):
   assert residue(a)!=[0,0]
   return {'valuation':n,'residue':residue(a),'normalized_coordinates':a,'every_integral_division_multiplied_back':True,'division_chain_sha256':hasher.hexdigest(),'failed_next_numerator_mod5':[x%5 for x in b]}
  b=[x//5 for x in b];assert multiply_pi(b)==a;n+=1;a=b
own=json.loads((HERE/'INDEPENDENT_EXACT_GUARDS.json').read_text())
res={k:val(a) for k,a in own['guard_coordinates'].items()}
GG=own['guard_coordinates']
pair_poly=s.rem(s.Poly.from_list(list(reversed(GG['Gamma'])),q)*s.Poly.from_list(list(reversed(GG['Gamma_iota'])),q),P)
pair=[int(pair_poly.nth(j)) for j in range(40)]
res['pair']=val(pair)
from math import gcd
assert gcd(*pair)==3**72*5**106
assert val([1]+[0]*39)['valuation']==0
# Own exact arrays compared with inert author certificate after completed reconstruction.
author_path=HERE.parent/'q29_augmented75/EXACT_CERTIFICATE.json'
author=json.loads(author_path.read_text())
for k,a in author['coordinates'].items():
 if k=='pair':
  assert a==pair
  continue
 assert own['guard_coordinates'][k]==a
for k,a in author['local_pi5'].items():
 for field in ['valuation','residue','normalized_coordinates']:assert res[k][field]==a[field]
assert author['content']==own['content_certificates']['A']['content']
assert sum(x*y for x,y in zip(own['guard_coordinates']['A'],author['bezout_vector']))==author['content']
assert own['integral_U75_coefficients']==author['U75']
summary={'author_certificate_sha256':hashlib.sha256(author_path.read_bytes()).hexdigest(),'exact_guard_vectors_agree':True,'all_author_normalized_vectors_agree':True,'author_bezout_saturation_checked':True,'multiplication_by_pi_matrix':[[int(x) for x in row] for row in M.tolist()],'five_times_inverse_pi_matrix':W,'local_pi5':res}
(HERE/'INDEPENDENT_LATTICE_CONTROLS.json').write_text(json.dumps(summary,indent=2)+'\n')
for k,v in res.items():print(k,v['valuation'],v['residue'])
