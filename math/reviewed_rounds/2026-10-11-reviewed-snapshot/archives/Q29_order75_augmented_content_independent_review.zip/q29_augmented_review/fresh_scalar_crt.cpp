// Independent reviewer scalar reconstruction. No research source imported.
#include <vector>
#include <iostream>
#include <fstream>
#include <numeric>
#include <cstdint>
#include <algorithm>
using namespace std;
using I=int64_t;
I p;
I mod(I a){a%=p;return a<0?a+p:a;}
I mul(I a,I b){return a*b%p;}
I power(I a,I b){I r=1;for(;b;b>>=1,a=mul(a,a))if(b&1)r=mul(r,a);return r;}
using V=vector<I>;
void trim(V &a){while(!a.empty()&&a.back()==0)a.pop_back();}
V rem(V a,const V&b){I inv=power(b.back(),p-2);for(int k=(int)a.size()-b.size();k>=0;k--){I f=mul(a[k+b.size()-1],inv);for(int j=0;j<(int)b.size();j++)a[k+j]=mod(a[k+j]-mul(f,b[j]));}trim(a);return a;}
I result(V a,V b){I r=1;while(b.size()>1){int m=a.size()-1,n=b.size()-1; V t=rem(a,b);if(t.empty())return 0;int k=t.size()-1;r=mul(r,power(b.back(),m-k));if((m*n)&1)r=mod(-r);a=b;b=t;}if(b.empty())return 0;return mul(r,power(b[0],a.size()-1));}
I value(const V &a,I q){I r=0;for(int j=(int)a.size()-1;j>=0;j--)r=mod(mul(r,q)+a[j]);return r;}
V deriv(const V &a){V b;for(int k=1;k<(int)a.size();k++)b.push_back(mul(k,a[k]));trim(b);return b;}
V gaussian(I q,int n){V a{1};for(int m=1;m<=n;m++){V b(m+1,1);for(int j=1;j<m;j++)b[j]=mod(a[j]+mul(power(q,m-j),a[j-1]));a=b;}return a;}
V rogers(I q,int n){if(n==0)return {1};V a{1},b{1,1};for(int m=1;m<n;m++){V c(m+2);for(int j=0;j<=m;j++){c[j]=mod(c[j]+b[j]);c[j+1]=mod(c[j+1]+b[j]);}I f=mod(1-power(q,m));for(int j=0;j<m;j++)c[j+1]=mod(c[j+1]-mul(f,a[j]));a=b;b=c;}return b;}
V guards(I q){auto h=gaussian(q,37);if(h!=rogers(q,37))throw 1;V u(37);u[0]=h[0];for(int j=1;j<37;j++)u[j]=mod(h[j]-u[j-1]);if(u.back()!=1)throw 2;I g=value(u,p-1),v=1;for(int j=1;j<=18;j++)v=mul(v,mod(1-power(q,2*j)));for(int j=0;j<37;j++)v=mul(v,mod(1-power(q,2*j+1)));I delta=mod(2*g-v);I d=result(u,deriv(u)); // deg36, discriminant sign +
V z75(76);z75[0]=1;z75[75]=1;I r=result(z75,u);I G=mul(d,r);I dh=result(h,deriv(h));return {g,v,delta,d,r,G,dh};}
int main(int argc,char**argv){ifstream ps(argv[1]);ofstream out(argv[2]);int count=0;while(ps>>p){I root=0;for(I a=2;!root;a++){I b=power(a,(p-1)/75);if(power(b,75)==1&&power(b,25)!=1&&power(b,15)!=1)root=b;}
V P(41);P[0]=1;P[5]=p-1;P[15]=1;P[20]=p-1;P[25]=1;P[35]=p-1;P[40]=1;V dp=deriv(P);vector<V> vals(75);for(int k=1;k<75;k++)if(gcd(k,75)==1)vals[k]=guards(power(root,k));vector<V> coords(9,V(40));
for(int k=1;k<75;k++)if(gcd(k,75)==1){I x=power(root,k);V a=vals[k];I Gi=vals[75-k][5];V vv{a[0],a[1],a[2],a[3],a[4],a[5],Gi,mul(mul(a[5],Gi),a[2]),a[6]};if(a[6]!=mul(mul(a[0],a[0]),a[3]))throw 3;V quot(40);quot[39]=1;for(int j=38;j>=0;j--)quot[j]=mod(P[j+1]+mul(x,quot[j+1]));if(mod(P[0]+mul(x,quot[0])))throw 4;I iv=power(value(dp,x),p-2);if(!value(dp,x))throw 5;for(int t=0;t<9;t++)for(int j=0;j<40;j++)coords[t][j]=mod(coords[t][j]+mul(mul(vv[t],iv),quot[j]));}
// Full interpolation check at every primitive component.
for(int k=1;k<75;k++)if(gcd(k,75)==1){I x=power(root,k);auto a=vals[k];I Gi=vals[75-k][5];V vv{a[0],a[1],a[2],a[3],a[4],a[5],Gi,mul(mul(a[5],Gi),a[2]),a[6]};for(int t=0;t<9;t++)if(value(coords[t],x)!=vv[t])throw 6;}
out<<p;for(auto a:coords)for(I x:a)out<<" "<<x;out<<"\n";out.flush();cerr<<++count<<" "<<p<<"\n";}
}
