#!/usr/bin/env python3
import json,math
from pathlib import Path
import sympy as s
BASE=Path(__file__).resolve().parent
own=json.loads((BASE/'INDEPENDENT_EXACT_GUARDS.json').read_text());d=own['guard_coordinates'];z=s.Symbol('z')
rows=[]
for k in range(1,75):
 if math.gcd(k,75)>1:continue
 q=pow(5,k,151);v={n:sum(c*pow(q,j,151) for j,c in enumerate(a))%151 for n,a in d.items()}
 rows.append({'exponent':k,'q':q,'values':v})
cs={r['q']:r for r in rows};assert len(cs)==40
q=21;v=cs[q]['values'];w=cs[pow(q,-1,151)]['values'];phi={0:1,5:-1,15:1,20:-1,25:1,35:-1,40:1}
dp=sum(k*c*pow(q,k-1,151) for k,c in phi.items() if k)%151
Q=75*pow(q,74,151)*pow(dp,-1,151)%151
tau=v['v']*pow(v['g'],-1,151)%151;taui=w['v']*pow(w['g'],-1,151)%151
assert all(v[k] and w[k] for k in ('g','v','D','R'))
assert (pow(tau,-1,151)+pow(taui,-1,151))%151==1 and tau!=2 and taui!=2 and Q
control={}
for q in (5,21):
 ev=lambda a:sum(c*pow(q,j,151) for j,c in enumerate(a))%151
 U=s.Poly(sum(ev(a)*z**j for j,a in enumerate(own['integral_U75_coefficients'])),z,modulus=151)
 gd=s.gcd(U,U.diff());gr=s.gcd(U,s.Poly(z**75+1,z,modulus=151))
 control[str(q)]={'derivative_gcd_ascending':[int(c)%151 for c in reversed(gd.all_coeffs())],'resonance_gcd_ascending':[int(c)%151 for c in reversed(gr.all_coeffs())]}
assert control['5']=={'derivative_gcd_ascending':[1],'resonance_gcd_ascending':[1,74,1]}
assert control['21']=={'derivative_gcd_ascending':[1],'resonance_gcd_ascending':[1]}
out={'prime':151,'generator':5,'all40_primitive_components':rows,'good_component_count':sum(r['values']['A']!=0 for r in rows),'fresh_symbolic_gcd_controls':control,'good_q21_denominator_audit':{'q':21,'q_inverse':36,'g':v['g'],'g_iota':w['g'],'v':v['v'],'v_iota':w['v'],'Phi75_derivative':dp,'Q75':Q,'tau':tau,'tau_iota':taui,'inverse_pair_identity_checked':True,'p_does_not_divide_75':True,'A_equals_75_less_than_p':True,'P_A_product_of_j_to_j_mod151':math.prod(pow(j,j,151) for j in range(1,76))%151}}
assert out['good_component_count']==34
(BASE/'F151_COMPONENT_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
print('34 good components; both gcd controls and all good-component denominators verified')
# Validate all author CRT input columns as inert data using independently exact coordinates.
AP=BASE.parent/'q29_augmented75';a=json.loads((AP/'EXACT_CERTIFICATE.json').read_text());M=1;primes=[]
for line in (AP/'MODULAR_GUARDS.txt').read_text().splitlines():
 p,r,*vals=map(int,line.split());assert s.isprime(p) and p%75==1 and p not in primes;primes.append(p)
 assert pow(r,75,p)==1 and pow(r,25,p)!=1 and pow(r,15,p)!=1
 for i,name in enumerate(['D','R','g','v','delta','Gamma']):assert vals[40*i:40*i+40]==[c%p for c in d[name]]
 M*=p
assert M==a['CRT']['modulus'] and len(primes)==115
for b in a['CRT']['coefficient_bounds'].values():assert M>2*b
print('All 115 producer primes, roots, 6 full columns, CRT modulus and 5 rigorous bound comparisons verified')
