#!/usr/bin/env python3
"""Fresh reviewer reconstruction; reads only our scalar residue output."""
import json, math, hashlib, sys
from pathlib import Path
from functools import reduce
import sympy as s
sys.set_int_max_str_digits(100000)
HERE=Path(__file__).resolve().parent
q=s.Symbol('q');P=s.Poly(s.cyclotomic_poly(75,q),q); pc=[int(P.nth(j)) for j in range(41)]
assert pc==[1 if j in (0,15,25,40) else -1 if j in (5,20,35) else 0 for j in range(41)]
def ring(a):
 a=list(a)
 while len(a)>40:
  c=a.pop(); k=len(a)-40
  for j in (0,5,15,20,25,35):a[k+j]-=c*pc[j]
 return a+[0]*(40-len(a))
def add(a,b):return [x+y for x,y in zip(a,b)]
def mul(a,b):
 c=[0]*79
 for j,x in enumerate(a):
  if x:
   for k,y in enumerate(b):
    if y:c[j+k]+=x*y
 return ring(c)
def power(a,n):
 r=ring([1])
 while n:
  if n&1:r=mul(r,a)
  a=mul(a,a);n//=2
 return r
def scale(a,x):return [x*y for y in a]
one=ring([1]); qq=ring([0,1]);zero=ring([])
def invq(a):
 r=zero
 for j,x in enumerate(a):
  if x:r=add(r,scale(power(qq,(-j)%75),x))
 return r
names=['g','v','delta','D','R','Gamma','Gamma_iota','A','D37']
vals=[[0]*40 for _ in names]; M=1; primes=[]
for line in (HERE/'scalar_crt_residues.txt').read_text().splitlines():
 line=list(map(int,line.split()));p=line[0];assert s.isprime(p) and p%75==1 and p not in primes;primes.append(p)
 inv=pow(M,-1,p)
 for t in range(9):
  for j in range(40):vals[t][j]+=M*((line[1+40*t+j]-vals[t][j])%p*inv%p)
 M*=p
# Conservative algebraic bound documented in REVIEW.md: every coordinate <2^13278.
assert M>2**13279
vals=[[x if x<=M//2 else x-M for x in row] for row in vals]
assert all(abs(x)<2**13278 for row in vals for x in row)
G=dict(zip(names,vals))
assert mul(G['D'],G['R'])==G['Gamma']
assert invq(G['Gamma'])==G['Gamma_iota']
assert mul(mul(G['Gamma'],G['Gamma_iota']),G['delta'])==G['A']
assert mul(mul(G['g'],G['g']),G['D'])==G['D37']
assert add(scale(G['g'],2),scale(G['v'],-1))==G['delta']
# Reconstruct H37 in the integral cyclotomic ring, independent of every modular table.
h=[one]
for n in range(1,38):
 h=[one]+[add(h[k],mul(power(qq,n-k),h[k-1])) for k in range(1,n)]+[one]
u=[h[0]]
for x in h[1:-1]:u.append(add(x,scale(u[-1],-1)))
assert u[-1]==one and len(u)==37 and u==u[::-1]
g=zero
for j,a in enumerate(u):g=add(g,scale(a,(-1)**j))
v=one
for k in list(range(2,37,2))+list(range(1,74,2)):v=mul(v,add(one,scale(power(qq,k),-1)))
assert G['g']==g and G['v']==v
# Exact integral extended-gcd certificate of every content, especially augmented saturation.
def content_certificate(a):
 d=0; w=[]
 for x in a:
  u,v,g=s.gcdex(d,x);u,v,g=int(u),int(v),int(g)
  w=[u*z for z in w]+[v];d=g
 assert d>0 and sum(x*y for x,y in zip(a,w))==d
 primitive=[x//d for x in a];assert sum(x*y for x,y in zip(primitive,w))==1
 rest=d; factors={}
 for p in (3,5):
  n=0
  while rest%p==0:rest//=p;n+=1
  factors[str(p)]=n
 return {'content':d,'bezout':w,'primitive_coordinates':primitive,'supported_3_5_exponents':factors,'remaining_content_after_3_5':rest}
cert={name:content_certificate(row) for name,row in G.items()}
# Independent scalar controls at q=5 in F151 using SymPy's finite-field resultants.
p=151;x=5;assert pow(x,75,p)==1 and pow(x,25,p)!=1 and pow(x,15,p)!=1
z=s.Symbol('z')
def ev(a):return sum(c*pow(x,j,p) for j,c in enumerate(a))%p
hz=s.Poly(sum(ev(a)*z**j for j,a in enumerate(h)),z,modulus=p);uz=s.Poly(sum(ev(a)*z**j for j,a in enumerate(u)),z,modulus=p)
scalar={'D37':int(hz.discriminant())%p,'D':int(uz.discriminant())%p,'R':int(s.resultant(s.Poly(z**75+1,z,modulus=p),uz))%p}
for key,value in scalar.items():assert ev(G[key])==value
scalar.update({key:ev(a) for key,a in G.items()})
# Mutating a single CRT coefficient fails the exact defining product.
bad=G['A'].copy();bad[0]+=1
assert bad!=mul(mul(G['Gamma'],G['Gamma_iota']),G['delta'])
report={'scope':'exact intrinsic order75 nine integral guards and reduced augmented content','independent_reconstruction':True,'prime_count':len(primes),'crt_modulus_bits':M.bit_length(),'uniform_coordinate_bound_power_of_2':13278,'crt_modulus_exceeds_twice_bound':True,'phi75_coordinates':pc,'guard_coordinates':G,'content_certificates':cert,'F151_q5':scalar,'integral_H37_coefficients':h,'integral_U75_coefficients':u,'all_product_involution_and_discriminant_identities':True,'one_coordinate_mutation_rejected':True}
(HERE/'INDEPENDENT_EXACT_GUARDS.json').write_text(json.dumps(report,indent=2)+'\n')
for name,c in cert.items():print(name,'content factors',c['supported_3_5_exponents'],'remaining',c['remaining_content_after_3_5'],'max coordinate bits',max(abs(x).bit_length() for x in G[name]))
print('CRT bits',M.bit_length(),'F151',scalar)
