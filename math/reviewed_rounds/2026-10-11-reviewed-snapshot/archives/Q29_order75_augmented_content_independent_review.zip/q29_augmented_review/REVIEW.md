# Independent review: Q29 finite order-75 augmented content

11 October 2026 UTC.

## Verdict

SCOPED ACCEPT. Independent exact reconstruction proves

    c_75^+ = 3^72 · 5^107.

Every canonical coordinate, all integral products and involution factors, the content-saturation identity, and every reported mixed-characteristic normalized guard agree with freshly computed results. The final author archive and its Library round-trip are pinned by AUTHOR_LIBRARY_BYTE_VERIFICATION.json. This acceptance applies to those exact bytes, not to later changes.

The accepted augmented overlap bridge therefore adds 75 to the fixed-base list, giving {3,7,11,15,19,23,75}. For every prime p congruent to 1 modulo 4 with p different from 5, H_((75p-1)/2)(z;zeta_(75p)) is squarefree at every primitive characteristic-zero root. Q29's general support problem remains open. This is not a repeated-prime step with p=5, an arbitrary-base transfer theorem, or a claim of worldwide novelty. The scalar-bank minimum is unchanged.

## Exact definitions and dependencies

The reviewer reconstructed the definitions from the accepted COMPOSITE_GUARD_EXTENSION.md, Section 2, and manuscript.md, Section 7, before reading the candidate computation. Let O=Z[q]/Phi75, with its free basis 1,q,...,q^39. The defining polynomial is

    Phi75=q^40-q^35+q^25-q^20+q^15-q^5+1.

Let H37 be the integral Gaussian-binomial polynomial, U=H37/(z+1), g=U(-1), and

    v=product_(j=1..18)(1-q^(2j)) product_(j=0..36)(1-q^(2j+1)).
    delta=2g-v; D=Disc_z(U); R=Res_z(z^75+1,U).
    Gamma=DR; iota(q)=q^(-1); A=Gamma·iota(Gamma)·delta.

All discriminants use the ordinary z derivative. The augmented content is the positive gcd of the 40 canonical integral coordinates of A, after reduction by the monic Phi75. It is neither the unreduced polynomial content nor an algebraic norm.

The nine guards independently reconstructed here are g,v,delta,D,R,Gamma,iota(Gamma),A,Disc(H37). The producer instead includes Gamma·iota(Gamma) among its nine displayed elements and obtains the full discriminant through g²D. Both enumerations are explicitly accounted for: the extra pair is checked by exact multiplication, and all ten elements are covered between the two packets.

The prior accepted residual calculation established the finite mixed-characteristic values 338 for Disc(H37) and 60 for its integral residual E. That calculation alone did not supply R or augmented prime support. The new proof obtains complete intrinsic order-75 coordinates instead of deriving them from embedded order-15 guards.

## Independent exact reconstruction

No producer, uploaded, or historical research program was imported or executed. The reviewer wrote fresh C++ and Python controls. Producer code was inspected as inert text; producer JSON and modular arrays were used only for comparison after independent reconstruction.

The fresh scalar implementation uses 455 distinct primes congruent to 1 modulo 75. Every prime is independently checked with SymPy. For each prime it constructs a root rho, verifies rho^75=1 and rho^25,rho^15 are not 1, and uses every rho^a with gcd(a,75)=1. These are all 40 distinct roots of Phi75. q-Pascal and the Rogers-Szego recurrence agree coefficient by coefficient at every root.

The reviewer directly computes the full degree-36 discriminant and the degree-(75,36) resonance resultant by finite-field Euclid, retaining all leading-coefficient powers and swap signs. It also directly computes Disc(H37). This does not use the producer's degree-18 reciprocal-polynomial shortcut. The relevant discriminant signs are positive: 36·35/2=630 and 37·36/2=666. The resultant argument swap also has positive sign, since 75·36 is even.

All nine complete guard columns, including Gamma, its involution, and A, are reconstructed independently by Lagrange interpolation and CRT. Involution is evaluated at the actual inverse primitive root, rather than replacing Gamma·iota(Gamma) by Gamma². Every interpolated column is checked at every one of the 40 roots of every reconstruction prime.

### A deliberately independent uniqueness bound

Put B=2^37. Gaussian coefficient positivity bounds each coefficient of H37 at every complex primitive root by binom(37,k). Integral synthetic division gives |u_j|<=B. Hence |g|<2^43, |v|<=2^55 and |delta|<2^56.

Every row of the 71-by-71 Sylvester matrix for D has Euclidean norm less than 2^46, so |D|<2^3266. The root-product formula, whose 75 evaluation roots all have modulus one, gives |R|<2^3225. Thus |Gamma|<2^6491 and |A|<2^13038 in every complex embedding. The full discriminant g²D and the remaining elements obey this same common upper bound.

To bound canonical coefficients, any two distinct 75th roots have distance at least 4/75. Consequently |Phi75'(a)|>=(4/75)^39. Each coefficient of Phi75(x)/(x-a), a monic polynomial with 39 unit-modulus roots, is bounded by 2^39. Lagrange interpolation with 40 terms therefore bounds each coordinate by

    40 · 2^13038 · 2^39 · (75/4)^39 < 2^13278.

The reviewer CRT modulus has 13604 bits and exceeds 2^13279. Symmetric reconstruction is therefore unique. Stabilization or small observed coefficients is not used as a proof. This independently certifies all nine complete arrays, including A itself, under a single explicit bound.

The producer's sharper 280-times-embedding bound is also valid. Its synthetic quotient coefficients have magnitude at most 7. The cyclotomic derivative identity and the primitive-15th-root geometric-sum estimate give |Phi75'(a)|>=75/28>1. Its 115-prime modulus exceeds twice each stated D,R,g,v,delta bound. The producer forms the remaining products integrally rather than reconstructing them under an insufficient bound. Every one of its 115 prime/root pairs and all six saved modular columns was checked against the reviewer's independently exact arrays.

## Integrality, saturation, and guard values

A separate exact integer-ring q-Pascal construction recovers all H37 and U coefficients. Synthetic division multiplies back, U is monic and reciprocal, and the integral g,v,delta agree with CRT. Exact ring multiplication verifies

    Gamma=DR; Gamma_iota=iota(Gamma);
    A=Gamma·Gamma_iota·delta; Disc(H37)=g²D.

The full vectors agree with the producer. Fresh extended-gcd certificates show the exact coordinate contents:

- g: 1; v: 5; delta: 1
- D: 5^15
- R: 3^36·5^37
- Gamma and Gamma_iota: 3^36·5^53
- Gamma·Gamma_iota: 3^72·5^106
- A: 3^72·5^107
- Disc(H37): 5^16

The reviewer independently checks the producer's integer Bezout vector against A and supplies its own. Dividing each array by its claimed content leaves an integer array with an integer linear combination equal to 1. Thus no unexamined factor remains. The content of a product is not inferred by multiplying contents: extra factors of 5 are accounted for in the exact ring products.

For pi=q²+q+1, the reviewer constructs the complete integer matrix M_pi of multiplication by pi. Its rational inverse satisfies 5 M_pi^(-1) integral. Every division is performed by applying this matrix, requiring integral coordinates, and multiplying back exactly. The next failed division and a nonzero F25 residue prove maximality. This is an independent lattice implementation of the producer's pi J=5 criterion. No division by a zero residue is performed.

The independently verified valuations and leading residues are:

- g: 10, 4q
- v: 30, 3+2q
- delta: 10, 3q
- D: 318, 1
- R: 750, 4+4q
- Gamma: 1068, 4+4q
- Gamma_iota: 1068, q
- A: 2146, 3q
- Disc(H37): 338, 4+4q

The extra pair has valuation 2136 and residue 1 by exact multiplication. Every normalized vector, not merely its first residue, agrees with the producer. The relation pi^20=5u, with u a global integral unit, and the F25 residue field are accepted, independently reviewed dependencies. These valuations do not equate mixed-characteristic order with mod-5 polynomial multiplicity in general.

## Same-component controls, embeddings, and denominator admissibility

At q=5 over F151 the reviewer independently reproduces Disc(H37)=9, but R=Gamma=Gamma_iota=A=0. Fresh symbolic gcds give gcd(U,U')=1 and gcd(U,z^75+1)=z²+74z+1. The old isolated squarefreeness witness is therefore not an augmented witness.

At q=21=5^4, whose inverse is 36, the values are

    (g,v,delta,D,R,Gamma,Gamma_iota,A,Disc(H37))
    =(146,9,132,36,135,28,71,129,145).

Both ordinary derivative and resonance gcds are 1. Across all 40 primitive components, 34 have nonzero A. This is a same-component assertion. A rational norm-unit test would be stronger than necessary: the bad component shows the norm is divisible by 151, while the exact content is not. The review does not assert a numerical value for that norm.

No good-prime conclusion is made without checking denominators. At q=21, g_iota=58 and v_iota=102; all four quantities g,g_iota,v,v_iota are nonzero. Phi75'=99 and Q75=(q^75-1)/Phi75 has value 41. The parameters tau=119 and tau_iota=33 satisfy 1/tau+1/tau_iota=1, and neither equals 2. For the bridge at p=151, A_local=75<p and product_(j=1..75)j^j=112 modulo 151, also nonzero.

More generally, p not dividing 75 makes q^75-1 separable, so Phi75' and Q75 are units at every primitive component. The exact content selects one component where Gamma,Gamma_iota,delta are simultaneously nonzero. Resonance supplies g and g_iota; every exponent in v and v_iota lies strictly between 0 and 75, making these units. The accepted inverse-pairing and augmented bridge hypotheses are therefore all met. No claim is made for p=5, where this argument loses its denominator/separability hypotheses.

## Negative controls and persistence

Attempting to divide 1 by pi is rejected by the integral-lattice test. A single-coordinate mutation of A fails its defining product. Separate SymPy finite-field discriminants, resultants, and gcds verify the good/adverse controls. All producer CRT arrays and bounds are checked as inert data.

The final archive includes the freshly written programs, complete exact arrays, lattice matrices, modular residues, logs, source snapshots, and source/byte seals. AUTHOR_LIBRARY_BYTE_VERIFICATION.json records independent download of the frozen producer archive and a check of every sealed member. The review's own Library round-trip seal is kept outside its archive to avoid a circular hash assertion. No Sheet or GitHub writes were performed.
