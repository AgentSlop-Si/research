Independent exact finite Q29 review. See REVIEW.md for scope and proof.
Reproduce from this directory:
  g++ -O3 -std=c++17 fresh_scalar_crt.cpp -o /tmp/q29_review_scalar
  /tmp/q29_review_scalar split_primes.txt scalar_crt_residues.txt
  python3 fresh_integer_audit.py
  python3 fresh_lattice_audit.py
  python3 fresh_component_checks.py
The last two scripts compare inert author data from the sibling q29_augmented75 directory.
The archive includes that frozen source directory. No producer code is executed.
