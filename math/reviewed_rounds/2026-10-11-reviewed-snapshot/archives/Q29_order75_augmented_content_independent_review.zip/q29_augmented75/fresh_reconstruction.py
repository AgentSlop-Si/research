"""Fresh exact CRT and integral controls. Read prior sources only as inert JSON/text."""
from pathlib import Path
from math import prod,gcd
import json,sys,time
sys.set_int_max_str_digits(20000)
BASE=Path(__file__).resolve().parent
PHI=[0]*41
for i in (0,15,25,40):PHI[i]=1
for i in (5,20,35):PHI[i]=-1
N=40
zero=(0,)*N
one=(1,)+(0,)*(N-1)
def red(a):
 a=list(a)+[0]*max(0,N-len(a))
 for k in range(len(a)-1,N-1,-1):
  c=a[k]
  if c:
   for j in range(N):
    if PHI[j]:a[k-N+j]-=c*PHI[j]
 return tuple(a[:N])
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def neg(a):return tuple(-x for x in a)
def sub(a,b):return add(a,neg(b))
def scale(a,n):return tuple(n*x for x in a)
def mul(a,b):
 c=[0]*(2*N-1)
 for i,x in enumerate(a):
  if x:
   for j,y in enumerate(b):
    if y:c[i+j]+=x*y
 return red(c)
def power(a,n):
 r=one
 while n:
  if n&1:r=mul(r,a)
  a=mul(a,a);n//=2
 return r
q=red([0,1]);qs=[power(q,j) for j in range(75)]
def invol(a):
 r=zero
 for j,c in enumerate(a):r=add(r,scale(qs[-j%75],c))
 return r
def content(a):return gcd(*a)
def bezout_vector(a):
 def egcd(a,b):
  x0,y0,x1,y1=1,0,0,1
  while b:
   d=a//b;a,b=b,a-d*b;x0,x1=x1,x0-d*x1;y0,y1=y1,y0-d*y1
  return a,x0,y0
 g=0;w=[]
 for x in a:
  gg,u,v=egcd(g,x);w=[u*y for y in w]+[v];g=gg
 if g<0:g=-g;w=[-x for x in w]
 assert sum(x*y for x,y in zip(a,w))==g
 return g,w
rows=[[int(x) for x in line.split()] for line in (BASE/'MODULAR_GUARDS.txt').read_text().splitlines()]
M=1;acc=[[0]*40 for _ in range(6)]
for row in rows:
 p,rho,*data=row
 assert len(data)==240
 inv=pow(M,-1,p)
 for t in range(6):
  for j in range(40):acc[t][j]+=M*(((data[40*t+j]-acc[t][j])*inv)%p)
 M*=p
vectors=[tuple(x if 2*x<=M else x-M for x in a) for a in acc]
B=2**37
bounds=[280*(37*B)**35*(666*B)**36,280*(37*B)**75,280*37*B,280*2**55,280*(2*37*B+2**55)]
for b in bounds:assert M>2*b
D,R,g,v,delta=vectors[:5]
# Exact integral q-Pascal construction with no modular input.
h=[one]
for n in range(1,38):
 h=[add(h[k] if k<n else zero,mul(qs[(n-k)%75],h[k-1]) if k>0 else zero) for k in range(n+1)]
u=[h[0]]
for k in range(1,37):u.append(sub(h[k],u[-1]))
assert h[37]==u[-1]==one and u==u[::-1]
gx=zero
for k,c in enumerate(u):gx=add(gx,scale(c,(-1)**k))
vx=one
for i in list(range(2,37,2))+list(range(1,74,2)):vx=mul(vx,sub(one,qs[i]))
assert gx==g and vx==v and sub(scale(g,2),v)==delta
Gamma=mul(D,R);Gamma_i=invol(Gamma);pair=mul(Gamma,Gamma_i);A=mul(pair,delta)
allguards={'D':D,'R':R,'g':g,'v':v,'delta':delta,'Gamma':Gamma,'Gamma_iota':Gamma_i,'pair':pair,'A':A}
C,w=bezout_vector(A)
Cpart=C;fac={}
for p in (3,5):
 e=0
 while Cpart%p==0:Cpart//=p;e+=1
 fac[str(p)]=e
# pi exact division from pi J=5. polynomial division Phi by pi.
a=PHI[:];quot=[0]*39
for k in range(40,1,-1):
 c=a[k];quot[k-2]=c
 for j in range(3):a[k-2+j]-=c
assert a[:2]==[5,5]
J=red([5]+quot)
pi=red([1,1,1]);assert mul(pi,J)==scale(one,5)
def residue(a):
 b=[x%5 for x in a]
 for k in range(39,1,-1):
  c=b[k];b[k-1]=(b[k-1]-c)%5;b[k-2]=(b[k-2]-c)%5
 return b[:2]
def valuation(a):
 n=0
 while True:
  b=mul(a,J)
  if any(x%5 for x in b):return {'valuation':n,'residue':residue(a),'normalized_coordinates':a}
  b=tuple(x//5 for x in b);assert mul(b,pi)==a
  n+=1;a=b
local={k:valuation(x) for k,x in allguards.items()}
print('c75 exponents',fac,'remaining',Cpart,flush=True)
print('local', {k:(x['valuation'],x['residue']) for k,x in local.items()},flush=True)
print('D/R digits',max(len(str(abs(x))) for x in D),max(len(str(abs(x))) for x in R),flush=True)
result={'scope':'Candidate full finite order75 augmented content; independent review pending','phi75':PHI,'U75':u,'coordinates':allguards,'content':C,'content_factor_3_5':fac,'remaining_content_factor':Cpart,'bezout_vector':w,'local_pi5':local,'CRT':{'prime_count':len(rows),'modulus':M,'coefficient_bounds':dict(zip(['D','R','g','v','delta'],bounds)),'bound_allows_unique_symmetric_reconstruction':True,'Gamma_column_used_for_reconstruction':False},'content_of_each':{k:content(x) for k,x in allguards.items()}}
(BASE/'EXACT_CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')
