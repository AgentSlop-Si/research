"""Fresh post-generation certificate controls, independent ring implementation."""
from pathlib import Path
from math import prod,gcd
import json,sys,hashlib
import sympy as s
sys.set_int_max_str_digits(20000)
B=Path(__file__).resolve().parent;x=s.Symbol('q')
c=json.loads((B/'EXACT_CERTIFICATE.json').read_text());g=c['coordinates'];F=s.Poly(s.cyclotomic_poly(75,x),x)
def poly(a):return s.Poly.from_list(list(reversed(a)),x)
def arr(f):return [int(f.nth(i)) for i in range(40)]
def mult(a,b):return arr((poly(a)*poly(b)).rem(F))
assert arr(F)==c['phi75'][:40] and int(F.nth(40))==1
assert mult(g['D'],g['R'])==g['Gamma']
inv=[0]*40
for k,a in enumerate(g['Gamma']):
 term=s.Poly(x**((-k)%75),x).rem(F)
 inv=[z+a*int(term.nth(j)) for j,z in enumerate(inv)]
assert inv==g['Gamma_iota']
assert mult(g['Gamma'],inv)==g['pair']
assert mult(g['pair'],g['delta'])==g['A']
assert g['delta']==[2*a-b for a,b in zip(g['g'],g['v'])]
for k,a in g.items():assert gcd(*a)==c['content_of_each'][k]
C=3**72*5**107
assert C==c['content']==gcd(*g['A'])
assert sum(a*b for a,b in zip(g['A'],c['bezout_vector']))==C
normalized=[a//C for a in g['A']];assert all(a%C==0 for a in g['A'])
assert sum(a*b for a,b in zip(normalized,c['bezout_vector']))==1
rows=[[int(a) for a in line.split()] for line in (B/'MODULAR_GUARDS.txt').read_text().splitlines()]
for p,rho,*dat in rows:
 assert s.isprime(p) and p%75==1
 assert pow(rho,75,p)==1 and pow(rho,25,p)!=1 and pow(rho,15,p)!=1
 for t,k in enumerate(['D','R','g','v','delta','Gamma']):assert [a%p for a in g[k]]==dat[40*t:40*(t+1)]
assert prod(row[0] for row in rows)==c['CRT']['modulus']
assert len(set(row[0] for row in rows))==len(rows)
assert all(c['CRT']['modulus']>2*b for b in c['CRT']['coefficient_bounds'].values())
# Accepted F151 control is independently reproduced from fresh integral coefficients.
u=[[sum(a*pow(5,j,151) for j,a in enumerate(row))%151] for row in c['U75']]
z=s.Symbol('z');up=s.Poly.from_list(list(reversed([row[0] for row in u])),z,modulus=151)
D151=int(s.discriminant(up.as_expr(),z))%151
g151=int(up.eval(-1))%151
assert g151*g151*D151%151==9
assert sum(a*pow(5,j,151) for j,a in enumerate(g['D']))%151==D151
R151=int(s.resultant(z**75+1,up.as_expr(),z))%151
assert sum(a*pow(5,j,151) for j,a in enumerate(g['R']))%151==R151
# Old witness is bad for resonance; another same-characteristic component is good.
components=[]
for root in [5,21]:
 vals={k:sum(a*pow(root,j,151) for j,a in enumerate(v))%151 for k,v in g.items()}
 ui=s.Poly.from_list(list(reversed([sum(a*pow(root,j,151) for j,a in enumerate(row))%151 for row in c['U75']])),z,modulus=151)
 rg=s.gcd(ui,s.Poly(z**75+1,z,modulus=151))
 dg=s.gcd(ui,ui.diff())
 components.append({'q':root,'guards':vals,'resonance_gcd_ascending':[int(rg.nth(i))%151 for i in range(rg.degree()+1)],'derivative_gcd_ascending':[int(dg.nth(i))%151 for i in range(dg.degree()+1)]})
 assert pow(root,75,151)==1 and pow(root,25,151)!=1 and pow(root,15,151)!=1
assert components[0]['guards']['A']==0 and len(components[0]['resonance_gcd_ascending'])>1
assert components[1]['guards']['A']==129
# Mutation controls fail before allowing a certificate to pass.
mut=g['A'][:];mut[0]+=1
assert gcd(*mut)!=C
mutD=g['D'][:];mutD[0]+=1
assert mult(mutD,g['R'])!=g['Gamma']
mutprime=rows[0][0]**2
assert not s.isprime(mutprime)
receipt={'all_checks_passed':True,'checks':['Independent SymPy cyclotomic reconstruction','Exact Gamma/involution/pair/A recomputation','Exact all-nine coordinate contents','Normalized A Bezout identity equals 1','Every split prime is prime and has exact-order75 root','All six modular columns agree with exact integer vectors','CRT modulus is distinct-prime product and exceeds every 2*bound','F151 full ordinary discriminant recovers accepted D37=9','F151 full resultant matches reconstruction','One-coordinate A mutation rejected','One-coordinate D mutation rejected','Composite replacement modulus rejected'],'F151':{'D_U':D151,'g':g151,'D_H37':9,'R':R151},'F151_components':components,'certificate_sha256':hashlib.sha256((B/'EXACT_CERTIFICATE.json').read_bytes()).hexdigest()}
(B/'FRESH_CONTROL_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
