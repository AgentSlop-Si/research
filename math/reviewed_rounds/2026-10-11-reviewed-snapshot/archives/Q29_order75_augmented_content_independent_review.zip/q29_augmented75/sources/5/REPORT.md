# Q29 residual discriminant at order 75

11 October 2026 UTC. This packet computes the genuine mixed-characteristic valuation and leading unit of the existing finite target

    E(q) = D37(q) / (Phi3(q)^210 Phi15(q)^17),
    D37(q) = Disc_z H37(z;q),
    Hn(z;q) = sum_k [n choose k]_q z^k.

The ordinary z derivative is used throughout. The accepted lower-factor theorem makes E an element of Z[q]. The computation takes place at q = zeta75 in O = Z[q]/Phi75(q), with pi = Phi3(q), and in its 5-adic completion B. It does not substitute the historical order of E mod 5 in F5[q] for a local valuation.

## Result

Fresh exact finite-ring computations prove

    v_pi(D37(zeta75)) = 338,
    D37(zeta75)/pi^338 mod pi = 4+4q = q^2 in F25,

and consequently

    v_pi(E(zeta75)) = 60,
    E(zeta75)/pi^60 mod pi = 4+4q = q^2.

In particular, E(zeta75) is nonzero and is not a local unit. More explicitly,

    E(zeta75) = 125 W,  W in O,
    W mod pi = q^2,  W a unit in B.

Thus the largest integer k for which E(zeta75) belongs to 5^k O is exactly 3. This is a statement about the integral cyclotomic value, rather than polynomial multiplicity modulo 5.

The valuation happens to equal the historical residual polynomial order 60. It is established here by a new mixed-characteristic calculation, with an independently reconstructed H37 and verified integral divisions. Equality of the two numbers was not assumed and is not promoted to a general rule.

## Denominator and intrinsic guards

The accepted pullback packet, whose final archive SHA-256 is caff8aaa8fbc0bd7e2588a89e5b190e45c9ab2bf0860e21014eabdba9f77e3fc, proves

    Phi3(q^5) = pi^5 v_pullback,
    pi^20 = 5u,
    v_pullback mod pi = 1,   u mod pi = q^2,

with integral global units v_pullback and u. The exact polynomial identity Phi3(q^5) = Phi3(q) Phi15(q) therefore gives

    Phi15(q) = pi^4 v_pullback,
    Phi3(q)^210 Phi15(q)^17 = pi^278 v_pullback^17.       (1)

Fresh integral ring arithmetic rederives this identity, checks all 278 successive pi divisions of the denominator, and constructs the integral inverse of v_pullback. Its normalized residue is exactly 1. Dividing D37 by (1) therefore subtracts 278 from the valuation and leaves the leading residue unchanged. The accepted integrality of E is invoked before this quotient is reduced. The displayed 125 W assertion follows from pi^60 = 125u^3 and u^3 mod pi = q^6 = 1. To pass from local to global integrality, use O intersect 125B = 125O in the free integral basis: an integer coordinate divisible by 125 in Z5 is divisible by 125 in Z. Since E(zeta75) is already in O, its local valuation 60 therefore implies E(zeta75)/125 is in O. Its residue is u^3(4+4q) = 4+4q.

For the intrinsic order-75 guards let U75 = H37/(z+1) and g75 = U75(-1). This is an integral monic quotient: fresh exact coefficient reconstruction verifies the factor z+1. The usual discriminant product identity, with ordinary derivatives, is

    D37 = g75^2 Disc_z(U75).                              (2)

The packet independently computes both sides. It obtains

    g75:          valuation 10, normalized residue 4q,
    Disc_z(U75):  valuation 318, normalized residue 1.

The residues in (2) agree because (4q)^2 = q^2 = 4+4q. The entire normalized unit vectors agree modulo pi^380, beyond merely comparing their first nonzero residues.

For additional intrinsic controls, reconstructing the product defining v75 and delta75 = 2g75-v75 integrally gives

    v75:      valuation 30, normalized residue 3+2q,
    delta75:  valuation 10, normalized residue 3q.

These are the guards defined at order 75 itself. They are distinct from the images under t -> q^5 of the lower order-15 guards. In particular the accepted embedded g15 has valuation 5, whereas intrinsic g75 has valuation 10. Formula (2) connects the computed residual discriminant to intrinsic guards; it is not a relation expressing them in terms of embedded lower guards. No value for the intrinsic resonance R75, augmented support c75+, or a new accepted augmented fixed base is asserted.

## Local arithmetic and integral division

The defining polynomial is

    P(q) = q^40-q^35+q^25-q^20+q^15-q^5+1.

The packet rederives P as Phi75 with an independent symbolic polynomial construction. It uses the free integral basis 1,q,...,q^39. Dividing P by pi in Z[q] gives P = pi A + 5(q+1). Thus J = qA+5 satisfies pi J = 5 in O. The accepted pullback proof establishes

    O/(pi) = F5[q]/(q^2+q+1) = F25,
    B is a DVR, and v_pi(5)=20.

For a chosen integral representative x in the 40-coordinate basis, the division procedure is:

1. Compute xJ by exact integer convolution and reduction by P, without first reducing the resulting coordinates modulo 5^K.
2. Require every coordinate to be divisible by 5.
3. Divide those integer coordinates by 5, obtaining y.
4. Verify pi y = x exactly in the integral basis, before modular reduction.
5. Only then reduce y's coordinates modulo 5^K for storage.

This succeeds exactly when x is in pi O. It never divides inside characteristic 5. The C++ determinant engine performs and checks this integral division for every extracted matrix entry; the separate arbitrary-integer Python controls do so for the displayed guard and denominator chains. The unit inversions are only inversions of elements with nonzero F25 residue. Newton iteration is continued to precision 20K and the product is checked to be 1 modulo 5^K.

After the first pi division, a stored vector modulo 5^K must not be described as knowing the true quotient to the full 20K digits. The tracked precision is pi-adic: if a chosen representative agrees with the true element modulo pi^L, exact division gives agreement modulo pi^(L-1). Reduction of the chosen quotient modulo 5^K introduces an error of valuation at least 20K and therefore causes no additional loss. Arithmetic and unit inversion preserve the current lower precision bound.

## Determinant and precision certificate

Two constructions freshly reconstruct H37 from its definition. One uses q-Pascal and one uses the Rogers-Szego recurrence

    H_(n+1) = (1+z)H_n - z(1-q^n)H_(n-1).

They agree on all coefficients. The primary determinant is the 37 by 37 matrix for multiplication by the ordinary derivative H37' in O[z]/H37. Since H37 is monic its determinant is Res(H37,H37'). The discriminant sign is (-1)^(37*36/2)=+1.

A second matrix is the direct 73 by 73 Sylvester matrix. A third determinant computes the ordinary discriminant of the fresh monic degree-36 quotient U75. These are distinct constructions by this packet's author; the independent review is supplied separately and is not claimed as authorship here.

The determinant algorithm uses row and column swaps and unit-pivot elimination. Whenever every entry of the active m by m block has zero residue, it divides all entries of that block by pi, checks each integral quotient, adds m to the determinant valuation, and loses one pi digit from the common matrix precision. Each pivot is a certified unit; its inverse and the determinant sign are retained.

For the derivative quotient matrix, the resulting invariant exponents are

    0,0,0,1,1,1,2,4,4,5,5,5,6,6,6,7,7,7,8,8,
    10,13,13,13,14,14,14,15,15,15,16,16,16,17,17,17,20.

Their sum is 338 and maximum is 20. The complete block extraction trace is in the determinant JSON certificates.

Here is the precision lemma used by the computation. If a DVR matrix known modulo pi^N is reduced by this algorithm, the sum a of all common-block extraction counts is an upper bound on the precision lost from the normalized active entries and pivots. If N>a and every final pivot is a unit, the determinant has the reported valuation v, and its normalized unit is known modulo pi^(N-a). The lemma follows by induction: swaps preserve precision and only change determinant sign; extraction gives a factor pi^m in the determinant and loses exactly one entry digit; a Schur complement using a unit pivot preserves the current precision. Multiplying the normalized unit pivots preserves their common precision. This also proves the displayed invariant exponents, which are the cumulative extraction counts at successive pivots.

Accordingly, the following finite precisions all certify the same valuation and leading residue:

- Input modulo 25: N=40, extraction loss=20, normalized unit precision at least pi^20.
- Input modulo 5^20: N=400, extraction loss=20, normalized unit precision at least pi^380.
- Input modulo 5^26: N=520, extraction loss=20, normalized unit precision at least pi^500.

The lowest run is already decisive. A control with input only modulo 5 halts at precision exhaustion before declaring the last pivot a unit. This is a necessary refusal by this computation, not a vanishing statement. The packet does not claim that 25 is an information-theoretically minimal modulus for every possible method.

For comparison, a scalar D37 approximation followed by division by the lower divisor loses 278 pi digits. To identify residual valuation 60 and its leading unit, that scalar route needs D37 known modulo at least pi^339; modulus 5^17 would supply 340 digits. A determinant computed only as a scalar modulo 25 would be zero and cannot be divided naively by the denominator. The much cheaper modulo-25 certificate works because it preserves and normalizes the matrix structure before taking the determinant. No 278-digit precision loss is charged twice: formula (1) removes an exact known power after the determinant's normalized unit has already been computed.

## Checks and reproducibility

The exact Python controls verify the following:

- Symbolically computed ordinary discriminants for n=3 and n=7, followed by exact evaluation in O75 and integral pi division, agree with the finite-ring engine. The n=3 result is valuation 0, residue 3; n=7 is valuation 5, residue 2+q.
- The K=2 and K=20 normalized vectors agree modulo pi^20.
- The K=20 and K=26 normalized vectors agree modulo pi^380.
- The quotient and Sylvester normalized vectors agree modulo pi^380.
- The normalized product g75^2 Disc(U75) agrees with D37 modulo pi^380.
- A bad division of 1 by pi is rejected, and an altered leading residue is rejected by cross-comparison.
- Every denominator and displayed guard normalization is integral before taking its residue.

The C++ arithmetic uses only bounded integer operations. For K<=26, 40(5^26-1)^2 is less than 2^128, so each unsigned convolution accumulator fits. In exact J multiplication, |J_i|<=5 and at most eight descending cyclotomic-reduction generations are possible because each use of P lowers a term's degree by at least 5; even the conservative bound 200*5^26*7^8 is less than 2^127. Exact multiplication-back uses the same safe signed range. Python controls use arbitrary integers.

To reproduce the author computations from this directory:

    g++ -O3 -std=c++17 fresh_mixed_characteristic.cpp -o /tmp/q29_mixed
    /tmp/q29_mixed 3 8 quotient D3_K8.json
    /tmp/q29_mixed 7 8 quotient D7_K8.json
    /tmp/q29_mixed 37 2 quotient D37_K2.json
    /tmp/q29_mixed 37 20 quotient D37_K20.json
    /tmp/q29_mixed 37 26 quotient D37_K26.json
    /tmp/q29_mixed 37 20 sylvester D37_SYLVESTER_K20.json
    /tmp/q29_mixed 37 20 udisc U75_DISC_K20.json
    python3 fresh_integral_controls.py

The code was written fresh for this task. Historical and uploaded research code was not executed or imported. Sources were read as inert text or JSON. Runtime fields can change when reproducing certificates; the mathematical outputs are deterministic.

## What this settles and what remains

The finite target is now evaluated with an exact local valuation and nonzero leading residue. It supplies another proof that H37(z;zeta75) is squarefree, consistent with the accepted independent F151 discriminant-9 witness. It also proves that removing the known lower cyclotomic factors does not produce a unit at the ramified prime: the residual retains exactly 60 pi digits, or exactly three integral factors of 5.

This is a bounded order-75 result. It does not prove a lower-to-upper guard transfer theorem, does not establish a uniform repeated-prime family, and does not resolve Q29's general augmented-content support question. The precise missing statement remains an identity or controlled inequality linking embedded lower guards to the intrinsic higher discriminant and resonance, uniformly in the repeated-prime parameters. The accepted augmented fixed bases remain {3,7,11,15,19,23}. Q29 remains open. No spreadsheet or GitHub writes are part of this packet.
