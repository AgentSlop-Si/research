# Q29 continuation: a certified repeated order and an exact ramified obstruction

11 October 2026 UTC. Scope: existing Research queue Q29, row 32 only. No new materials or fusion; no external writes. The live row and local proof sources are pinned in `SOURCE_BINDING.json`.

## Result and status

1. **The repeated order 75 is now certified:** for every primitive 75th root of unity ζ in characteristic zero, H₃₇(z;ζ) is squarefree. This settles the previously excluded p=5 instance of the existing s=15 family. An exact certificate over F₁₅₁ has ordinary discriminant 9 and includes a complete polynomial Bézout identity.
2. **The ramified failure is quantified for every lower order s=pᵉt, p≡1 mod 4, p∤t, t≡3 mod 4.** In every reduced residue component, U_s=(zᵗ+1)^((pᵉ−1)/2) U_t. Thus all the ordinary discriminant, resonance, g, v, and δ lower guards collapse together. Under the corresponding good lower-t guards, both derivative and resonance gcds are given exactly below.
3. A general finite-jet replacement for the unramified value test is stated and proved. **It still fails at the first repeated target 75, even after extracting the exact known lower cyclotomic factors.** Two independently constructed exact determinants give ord_Φ₃(D₃₇ mod 5)=338. The remaining order is 60, whereas the exclusion threshold is 20.

This is a bounded repeated-prime result plus a precise obstruction. It does not prove or disprove the unramified general augmented-content support conjecture, does not certify c₇₅⁺, and does not establish any all-p repeated-prime family. Q29 remains open. The accepted augmented fixed-base set remains {3,7,11,15,19,23}. No historical priority claim is made.

## 1. Definitions and accepted dependencies

H_n(z;q)=Σₖ [n choose k]_q zᵏ, with the q-Pascal definition, and D_n(q)=Disc_z H_n(z;q) use the ordinary z derivative. D_n belongs to Z[q].

For s≡3 mod 4 put b_s=(s−1)/2 and U_s=H_b_s/(z+1). This quotient is monic and integral in Z[q,z], since odd reciprocity gives H_b_s(−1;q)=0 identically. At a primitive s-th root define

- g_s=U_s(−1)
- v_s=∏_{j=1}^{(s−3)/4}(1−q^{2j}) ∏_{j=0}^{(s−3)/2}(1−q^{2j+1})
- δ_s=2g_s−v_s
- Γ_s=Disc(U_s) Res(zˢ+1,U_s).

The accepted manuscript supplies: root-of-unity q-Lucas factorization (Lemma 2.1); the one-simple-overlap exact local order (Theorem 3.2); uniform characteristic-zero nonvanishing of g, v, δ and resonance plus the Hermite guard (Section 5); and accepted exact lower-base s=15 squarefreeness through its augmented certificate. The lower-base support conjecture is not assumed.

## 2. General ramified-collapse theorem

**Theorem 1.** Let p≡1 mod 4 be prime, e≥1, t≡3 mod 4 with p∤t, and s=pᵉt. Work in a field k of characteristic p containing a primitive t-th root θ. Put A=(pᵉ−1)/2 and F=zᵗ+1. Then, at q=θ,

U_s(z;θ)=F(z)^A U_t(z;θ).                                      (1)

Consequently:

- F^(A−1) divides gcd(U_s,U_s′), so Disc(U_s)=0.
- F^A divides gcd(U_s,zˢ+1), so the resonance resultant is zero.
- g_s=v_s=δ_s=Γ_s=0.

The same statements hold at θ⁻¹. If U_t is squarefree and coprime to F, then the monic gcds are exactly

gcd(U_s,U_s′)=F^(A−1),        gcd(U_s,zˢ+1)=F^A.                 (2)

**Proof.** Since b_s=At+b_t and θ has exact odd order t, the integral q-Lucas factorization specializes to

H_b_s(z;θ)=(1+zᵗ)^A H_b_t(z;θ).

Cancel the common polynomial factor z+1 to obtain (1). Here A≥2, p∤t, and A≡−1/2 mod p is nonzero. The polynomial F is separable. Differentiating (1) gives

U_s′=F^(A−1)(A F′ U_t+F U_t′).

This proves the derivative divisibility, and gives the first equality in (2) if the two lower guards hold: at roots of F the parenthesis is nonzero, and at roots of U_t its F U_t′ term is nonzero. In characteristic p, zˢ+1=F^{pᵉ}; since A<pᵉ, the claimed resonance divisibility and guarded equality follow.

F(−1)=0 gives g_s=0. The odd-exponent product defining v_s includes exponent t, because t is odd and 1≤t≤s−2, so v_s=0. The remaining conclusions follow directly. Replace θ by θ⁻¹ for the inverse orientation. ∎

**What this proves about ramification.** Modulo p, Φ_s=Φ_t^{φ(pᵉ)}. Every reduced residue component therefore has precisely the collapse above. This is stronger than merely observing that qˢ−1 is inseparable or Q_s is not a unit: changing the residue component cannot restore any of the stated guards. The augmented product lies in the radical of pO_s. This last statement is deliberately not identified with membership in pO_s, because O_s/pO_s is nonreduced.

The six exact controls in `RAMIFIED_SPECIALIZATION_CONTROLS.json` verify the full coefficient identity (1), together with g=v=δ=0, for (t,p,e)=(3,5,1),(3,5,2),(7,5,1),(7,13,1),(11,5,1),(15,13,1). These are controls for a proved general identity, not its proof by enumeration.

## 3. A finite-jet criterion for a repeated target

**Theorem 2.** Let p∤t, e≥1, and let D∈Z[q]. Suppose the monic product

B=∏_{j=0}^e Φ_{tpʲ}(q)^{L_j}

is known to divide D, with L_j≥0. Let f be any irreducible factor of Φ_t over F_p, and suppose ν_f=ord_f(D mod p) is finite. Set

W=L₀+Σ_{j=1}^e φ(pʲ)L_j.

If ν_f−W < φ(p^{e+1}), then Φ_{tp^{e+1}} does not divide D.

**Proof.** Monicity gives D=BE with E∈Z[q]. The standard cyclotomic/Frobenius identities give

Φ_{tpʲ} mod p = Φ_t^{φ(pʲ)}  (j≥1).

Since p∤t, Φ_t mod p is squarefree, and ord_f(B mod p)=W. Finiteness of ν_f shows E mod p is nonzero, and ord_f(E mod p)=ν_f−W. If Φ_{tp^{e+1}} divided D, its characteristic-zero coprimality with B would force it to divide E integrally. Reduction would give ord_f(E mod p)≥φ(p^{e+1}), a contradiction. ∎

This is a sufficient criterion only. An order at or above the threshold is not a nonsimplicity result. The criterion works at any one residue factor, preserving the existential-component logic of the accepted unramified bridge. It requires higher q-adic information rather than a nonzero value at the lower root.

### Exact obstruction at target 75

Take D=D₃₇, p=5, t=3, e=1.

- At order 3: 37=12·3+1, so the accepted overlap formula gives L₀=3·12·11/2+12=210. Its lower U₃=1 and all guards hold.
- At order 15: 37=2·15+7, so L₁=15·2·1/2+2=17. The accepted s=15 certificate gives lower squarefreeness, and the uniform half-order theorems supply all other guards.

Thus D₃₇=Φ₃²¹⁰ Φ₁₅¹⁷ E with integral E and exact indicated exponents. Modulo 5,

Φ₁₅=Φ₃⁴,       Φ₇₅=Φ₃²⁰,       W=210+4·17=278.

Two newly written, independent constructions give

ord_Φ₃(D₃₇ mod 5)=338,
ord_Φ₃(E mod 5)=338−278=60.                                    (3)

The target threshold is 20. Hence even after removing all known lower members of the 3·5ʲ tower, the residual mod-5 multiplicity is three times the threshold. Merely replacing the old point-value test by its first 20 q-jets cannot settle this target. This is a certified limitation of this natural ramified extension of the method.

For an explicit normalization, let θ²+θ+1=0 over F₅ and q=θ+u. Then

D₃₇(θ+u) = (3+3θ)u³³⁸ + O(u³³⁹).

The leading coefficient is nonzero. The result does not come from floating-point evaluation or interpolation.

## 4. The repeated order 75 nevertheless is squarefree

**Theorem 3.** For every primitive 75th root ζ in characteristic zero, H₃₇(z;ζ) is squarefree.

**Proof.** The prime 151 and q₀=5 satisfy

5⁷⁵=1,   5²⁵=118,   5¹⁵=59   in F₁₅₁.

Thus q₀ has exact order 75, so Φ₇₅(q₀)=0. Fresh q-Pascal reconstruction and a separate q-factorial reconstruction agree on every coefficient of H₃₇(z;5). The certificate gives complete polynomials A(z),B(z) over F₁₅₁ for which

A(z)H₃₇(z;5)+B(z)∂_zH₃₇(z;5)=1.

An independent direct resultant also gives D₃₇(5)=9≠0. If D₃₇ vanished at a primitive 75th root in characteristic zero, irreducibility and monicity of Φ₇₅ would force Φ₇₅|D₃₇ in Z[q]. Reducing modulo 151 and evaluating at 5 contradicts 9≠0. ∎

The full coefficient arrays, the two Bézout multipliers and power checks are in `ORDER75_SQUAREFREE_CERTIFICATE.json`. The certificate is a finite exact proof of a single repeated target order. It does not use the failed mod-5 criterion and does not promote modular testing to a uniform repeated-prime theorem.

**Inherited local consequence.** The accepted uniform half-order resonance and parameter-disk theorems now remove all remaining local guards at order 75. For every integer A≥1,

ord_Φ₇₅ D_{75A+37} = 75A(A−1)/2+A.

The root −1 remains simple and resonant; the legal scalar-bank grammar and its minima do not change.

## 5. Independent calculations and falsification controls

All executed programs were newly written in this directory. Existing research programs were read only as inert text; none were imported or run.

- `fresh_dvr_control.py` builds H₃₇ by q-Pascal in F₂₅[[u]], constructs the 37×37 multiplication matrix of the ordinary derivative in the quotient by H₃₇, and computes its determinant with minimum-valuation full pivoting. Runs at initial precisions 340 and 400 both give order 338 and leading coefficient (3,3).
- `independent_sylvester_control.py` builds H₃₇ by the three-term Rogers–Szegő recurrence, constructs the direct 73×73 Sylvester matrix, and uses column valuation extraction with no column swaps and a separate quadratic-field inverse formula. Its precision-400 computation gives the same order and leading coefficient, with 62 normalized coefficients of precision remaining. It imports no producer code or certificate.
- Precision is tracked conservatively: extracting a pivot valuation v reduces the working precision by v. The final nonzero unit coefficient makes the reported valuation exact, rather than a lower bound from a truncated zero.
- `fresh_modular_certificates.py` produces the order-75 Bézout certificate and full ramified-specialization controls. Its ordinary gcd is also checked with an independent installed SymPy implementation.
- `verify_packet_fresh.py` compares the power-series determinant with exact symbolic discriminants for n=3 and n=7, verifies both cyclotomic reductions, rechecks the Bézout identity from saved arrays, rejects a one-coefficient mutation, and checks the two precision runs against the independent Sylvester result.

`FINAL_CHECK_RECEIPT.json` records the successful checks and explicitly records that the ramified valuation criterion fails. SHA-256 hashes are in `SHA256SUMS.txt`.

## 6. Exact remaining tasks

The unramified statement still open in Q29 is: for every admissible lower s and prime p≡1 mod 4 with p∤s, prove that Γ_sΓ_s^ιδ_s is nonzero in at least one common factor of O_s/pO_s, together with general lower squarefreeness where it is not yet known. Nothing here asserts that result.

For repeated primes, Theorem 1 shows that reduced residue components cannot supply the original guards. Theorem 2 gives a legitimate higher-jet route, but (3) proves that its straightforward lower-factor extraction does not suffice even at 75. A general repeated-prime theorem needs further arithmetic structure, a different good-characteristic argument with a uniform witness, or a method beyond this first jet bound. The exact order-75 certificate closes that one previously excluded case only.
