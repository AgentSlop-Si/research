# Q29 finite ramified pullback from order 15 to order 75

11 October 2026 UTC. This packet proves the first mixed-characteristic pullback lemma for the nine accepted order-15 guard elements. It does not calculate the order-75 discriminant or transfer squarefreeness to it.

## Result

Let

O_15 = Z[t]/Phi_15(t),   pi_15 = t^2+t+1,
O_75 = Z[q]/Phi_75(q),   pi_75 = q^2+q+1,

and let i: O_15 -> O_75 send t to q^5. There are explicitly certified integral elements v_pullback, u, and their integral inverses in O_75 such that

    i(pi_15) = q^10+q^5+1 = pi_75^5 v_pullback,
    pi_75^20 = 5u,
    v_pullback mod pi_75 = 1,
    u mod pi_75 = -q-1.

In particular v_pullback is a local unit (in fact the certificate proves it is a global unit), the 5-adic completion of O_75 is a discrete valuation ring with uniformizer pi_75, and

    v_pi75(5) = 20.

Every one of the nine accepted order-15 guard valuations therefore acquires the factor 5 under this embedding. Their exact orders are 5, 15, 5, 15, 75, 90, 90, 185, and 25. The normalized residues are given below. All quotients are integral before any residue is taken.

This is a finite algebraic transport theorem. The guards here are i(g_15), i(D_15), i(R_15), and the other embedded lower elements. They are not the separately defined order-75 guards. Q29 remains open; the accepted augmented fixed bases remain {3,7,11,15,19,23}.

## The integral lattice and embedding

The defining polynomials are

    Phi_15(t) = t^8-t^7+t^5-t^4+t^3-t+1,
    P(q) = Phi_75(q) = q^40-q^35+q^25-q^20+q^15-q^5+1
                         = Phi_15(q^5).

Thus O_75 is free over Z in the basis 1,q,...,q^39. The relation P(q)=Phi_15(q^5) makes i a ring homomorphism. The eight images 1,q^5,...,q^35 are different members of this free basis, which proves injectivity without assuming any local result.

Write f=q^2+q+1, and divide P by f over Z[q]:

    P = f A + 5(q+1).

Because q(q+1)=f-1, the polynomial J=qA+5 satisfies

    fJ = qP+5,   hence pi_75 J = 5 in O_75.                  (1)

The exact 40 coordinates of J are in EXACT_CERTIFICATE.json. Formula (1) already proves the following necessary and sufficient integral division test. For x in O_75, reduce xJ into the free basis. Then

    x belongs to pi_75 O_75
    if and only if all 40 coordinates of xJ are divisible by 5.       (2)

If the test succeeds, form y by dividing those integer coordinates by 5. Multiplication by pi_75 gives 5 pi_75 y=5x; torsion-freeness permits cancellation of 5, and pi_75 y=x. Conversely, x=pi_75 y implies xJ=5y. This is an integral lattice criterion, not division inside a characteristic-5 quotient.

The calculation first applies (2) five times to q^10+q^5+1. Every intermediate numerator and integer quotient is recorded. The result v_pullback has the following coordinates in ascending powers q^0,...,q^39:

    [-239,527,-373,-87,468,-220,-453,739,-410,-257,
     710,-570,-54,641,-685,-105,1070,-1123,207,895,
     -990,-26,1033,-1160,286,605,-728,214,500,-787,
     385,360,-794,536,185,-500,126,358,-534,254].

Exact multiplication verifies f^5 v_pullback=q^10+q^5+1 in O_75. Only after this integral identity is established do we reduce v_pullback modulo pi_75, obtaining 1. The attempted sixth integral division fails, as it must.

For a stronger independent unit control, the producer forms all conjugates v_pullback(q^a), with 1<=a<75 and gcd(a,75)=1. Their exact product is 1. The product excluding a=1 is an explicit integral inverse; its 40 coordinates are recorded. No numerical norm approximation is used.

## The residue field and the valuation of 5

Since P mod f=5(q+1), and q+1 is a unit in Z[q]/f with inverse -q, the ideals (P,f) and (5,f) are equal. Consequently

    O_75/(pi_75) = F_5[q]/(q^2+q+1) = F_25.                 (3)

The quadratic has no root in F_5. Also P mod 5=f^20. More precisely, the integer polynomial

    u = (f^20-P)/5

has degree at most 39 and all integer coefficients, so

    pi_75^20 = 5u in O_75.                                  (4)

The producer checks these integer coefficients before forming u. It constructs an integral inverse by reducing J^20 and checking that each of its 40 coordinates is divisible by 5^19; their exact quotients give u_inverse. Equation (1) combined with (4), or direct multiplication, verifies u u_inverse=1. Full coordinates and multiplication checks are provided. The reduction of u in (3) is -q-1, which is nonzero.

For completeness, let B_75=O_75 tensor_Z Z_5. It is finite free and complete over Z_5. By (4) and the global unit u, the 5-adic and pi_75-adic topologies agree. An element with nonzero residue in (3) has an inverse in B_75: lift a residue inverse, then invert the resulting 1+pi_75 b by its convergent geometric series. Thus (pi_75) is the unique maximal ideal. The element pi_75 is a non-zero-divisor because pi_75^20 is 5 times a unit and B_75 is Z_5-free. Its powers have zero intersection by 5-adic separatedness. Every nonzero element is therefore a unit times a unique nonnegative power of pi_75. This proves that B_75 is a discrete valuation ring, without silently identifying a polynomial multiplicity with a valuation. Relation (4) gives v_pi75(5)=20.

## Transport of the nine accepted guards

The accepted order-15 certificate gives, for each listed x, an integral identity

    x = pi_15^n y in O_15,

where y has nonzero residue c(t) in F_5[t]/(t^2+t+1). Applying i and using the proved pullback identity gives the integral identity

    i(x) = pi_75^(5n) Y,
    Y = v_pullback^n i(y) in O_75.                          (5)

In the residue field q^3=1, so q^5=q^2=-q-1. The induced map of residue fields is the Frobenius automorphism c(t) -> c(q^5)=c(q)^5. It preserves nonzero elements. Since v_pullback has residue 1, the residue of Y is exactly c(q^2), and is nonzero. Hence (5) proves the exact value v_pi75(i(x))=5n, retaining the ramification factor rather than treating normalized lower guards as unweighted units.

Here D_15 means Disc_z U_15, R_15 means Res_z(z^15+1,U_15), Gamma_15=D_15 R_15, and A_15=Gamma_15 Gamma_15^iota delta_15. The symbol v_15 in this table is the previously defined product guard, distinct from v_pullback. Every table element is the image under i.

| Lower element x | Accepted n at order 15 | Exact pi_75 order of i(x) | Residue of i(x)/pi_75^(5n) | Largest k with i(x) in 5^k O_75 |
| --- | ---: | ---: | --- | ---: |
| g_15 | 1 | 5 | q-1 | 0 |
| v_15 | 3 | 15 | -2q | 0 |
| delta_15 | 1 | 5 | 2q-2 | 0 |
| D_15 | 3 | 15 | 2q-1 | 0 |
| R_15 | 15 | 75 | 2q-2 | 3 |
| Gamma_15 | 18 | 90 | 3 | 4 |
| Gamma_15^iota | 18 | 90 | 3 | 4 |
| A_15 | 37 | 185 | 2-2q | 9 |
| Disc_z H_7 | 5 | 25 | 1-q | 1 |

The table residues use coefficients in F_5. The ordinary involution t->t^(-1) commutes with i and q->q^(-1), so the row Gamma_15^iota has the same meaning as in the accepted source. The certificate checks that source element directly; no missing involution prefactor is discarded.

Because 5^k O_75=pi_75^(20k) O_75 by the global unit identity, the last column is floor(5n/20)=floor(n/4). The valuation normalized by v_5(5)=1 is 5n/20=n/4, unchanged from the lower field. The integral coordinate program separately checks all these divisibilities and failures of the next 5-division.

## Fresh checks and separating controls

Two programs were freshly written for this packet. Neither imports or executes an author or historical research program. Accepted JSON is used only as inert source data.

1. fresh_pullback_controls.py constructs ring arithmetic by integer tuple convolution and monic reduction. It derives J directly from the polynomial identity, checks the exact division criterion at every step, builds the global unit inverses, and transports all nine accepted identities. It then checks all 505 pi_75 divisions across the nine guard rows independently of formula (5), including every multiplication back and all failed next divisions. The separate pullback-unit and additive controls have their own division chains.
2. fresh_matrix_crosscheck.py constructs Phi_75 and the complete integer multiplication matrix M_pi using a separate SymPy polynomial implementation. It verifies det(M_pi)=25, computes its exact rational inverse, and requires integrality at every solved quotient before multiplication back. It reconstructs both unit inverses and all nine transport results, and only then compares them with the producer output.

These are independent implementations by the author, not independent authorship or an external acceptance decision. MATRIX_CROSSCHECK.json records the second construction. A one-coordinate mutation of v_pullback is rejected by both implementations. An exponent without the factor 5 leaves a zero normalized residue in every guard row, so the proposed unscaled transport fails its own terminal-unit test.

Two additional controls preserve the distinction between mixed-characteristic valuation and mod-5 polynomial order. Let F(q)=R_15(q^5) be the original integral lower resonance polynomial after substitution, and let x be its class in O_75. Fresh exact controls give:

- ord_Phi3(F mod 5)=75 and v_pi75(x)=75.
- F+5 has the same reduction modulo 5 and the same polynomial order 75, but its class has v_pi75(x+5)=20. Its normalized residue is q.
- F+Phi_75 has the same class x and local valuation 75, but its mod-5 polynomial order is 20.

Thus neither polynomial order nor local valuation can replace the other without controlling the lift. These statements concern the embedded R_15, not the order-75 resonance R_75 and not D_37.

## Exact boundary and next gap

The retained continuation has ord_Phi3(D_37 mod 5)=338 and residual order 60 after extraction of the known lower cyclotomic factors, against threshold 20. Those are statements in F_5[q]. This packet does not reinterpret 60 as a pi_75 valuation, recompute the residual discriminant, or show it is a unit. The separate accepted F_151 discriminant-9 squarefreeness witness at order 75 remains unchanged.

The result provides a rigorously normalized input to a possible mixed-characteristic transfer argument: when the order-15 guards are embedded at order 75, their positive valuations are exactly those in the table. It supplies no identity or inequality relating these embedded values to D_37, its residual factor, or the intrinsic order-75 guards. That relation is the next gap. Neither squarefreeness nor a new augmented fixed base follows from this pullback lemma.

## Reproduction and seals

From the extracted checkpoint root, run

    python research_cycle_1253/q29_ramified_pullback/fresh_pullback_controls.py
    python research_cycle_1253/q29_ramified_pullback/fresh_matrix_crosscheck.py

The packet includes the four pinned source documents under their original relative paths. SOURCE_BINDING.json gives their hashes. EXACT_CERTIFICATE.json contains every integral quotient and normalized residue. MATRIX_CROSSCHECK.json contains the fresh multiplication-matrix control. STATUS.json states the bounded scope; SHA256SUMS.txt seals the final research files. Regeneration changes runtime metadata but not the mathematical certificate content.

No spreadsheet or GitHub changes are included.
