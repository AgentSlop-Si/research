# Q29 finite order-75 augmented-content certificate

11 October 2026 UTC. Author certificate; independent acceptance is recorded separately. This is a finite fixed-base computation within the existing Q29 task, not a general support or repeated-prime transfer theorem. No novelty or historical-priority claim is made.

## Result

For the intrinsic order-75 guards defined below, the exact canonical-coordinate content is

    c_75^+ = 3^72 · 5^107.

The certificate contains all 40 integer coordinates of every guard and an integer vector w with

    sum_j w_j (A_75)_j = 3^72 · 5^107.

Every coordinate is divisible by this number, so the identity proves equality of the gcd, not merely a common factor. It follows from the accepted augmented overlap bridge that

    H_((75p−1)/2)(z;ζ_(75p))

is squarefree over characteristic zero for every prime p ≡ 1 (mod 4), p ≠ 5, and every primitive 75p-th root. Equivalently the bridge hypotheses are p ≡ 1 (mod 4) and p ∤ 75; the prime 3 is already outside the congruence class. This would add 75 to the fixed-base list after independent acceptance. It does not establish a repeated-prime step at p=5, or the general Q29 support statement. The existing isolated order-75 squarefreeness certificate is a distinct result.

## 1. Definitions and the exact remaining guard condition

Put O = Z[q]/Φ_75(q), with the canonical basis 1,q,...,q^39 and

    Φ_75(q) = q^40 − q^35 + q^25 − q^20 + q^15 − q^5 + 1.
    H_n(z;q) = sum_k [n choose k]_q z^k.
    U = U_75 = H_37/(z+1).
    g = U(−1).
    v = product_(j=1..18)(1−q^(2j)) product_(j=0..36)(1−q^(2j+1)).
    δ = 2g−v.
    D = Disc_z(U),  R = Res_z(z^75+1,U).
    Γ = DR,  ι(q)=q^(−1),  A = Γ·ι(Γ)·δ.
    c_75^+ = gcd of the 40 canonical coordinates of A, positive.

All derivatives and discriminants are ordinary, with Disc(1)=1. The certificate enumerates D, R, g, v, δ, Γ, ι(Γ), Γι(Γ), and A. The full discriminant Disc(H_37) is a different element, related by Disc(H_37)=g²D.

For p ∤ 75 the quotient O/pO is a product of fields. The augmented condition is that there is one field component in which D, R, their inverse-parameter counterparts, and δ are all nonzero. This is equivalent to A being nonzero in some component, hence to p ∤ c_75^+. Separate nonzero factors in different components do not suffice, nor is nonvanishing in every component required.

The accepted half-order results give characteristic-zero nonvanishing of g,v,δ and resonance once their stated hypotheses hold. The previous finite computation gave the 5-adic values vπ(Disc H_37)=338, vπ(D)=318 and vπ(E)=60, where π=q²+q+1 and E removes the lower Φ_3 and Φ_15 factors. Those values alone do not establish any unramified prime-support statement for A. The present certificate computes the full integral element and its exact content instead of deriving it from embedded order-15 guards.

## 2. Exact reconstruction and the finite uniqueness bound

### Modular computation

The program `fresh_modular_guards.cpp` uses 115 distinct certified primes p ≡ 1 (mod 75), beginning just above 10^9. Trial division through sqrt(p) certifies every prime. For each p, a root ρ is constructed and checked to satisfy

    ρ^75=1, ρ^25≠1, ρ^15≠1.

The 40 roots ρ^a, gcd(a,75)=1, are exactly the simple roots of Φ_75 over F_p. At each root, H_37 is freshly constructed both by q-Pascal and by the Rogers–Szegő recurrence, and the two complete coefficient arrays must agree. Synthetic division by z+1 verifies an integral monic reciprocal U of degree 36.

For efficiency write U=z^18 P(z+z^(−1)), with monic P of degree 18. P is reconstructed with S_0=2, S_1=t, S_(j+1)=tS_j−S_(j−1), using

    P(t) = u_18 + sum_(j=1..18) u_(18+j) S_j(t).

Let C_1=1, C_3=t−1 and C_(s+2)=tC_s−C_(s−2). The accepted integral identities give

    D = P(2)P(−2) Disc(P)^2,
    R = P(−2) Res(P,C_75)^2.

The sign in the latter is positive because 18 is even. Scalar resultants are computed by exact polynomial Euclid over F_p, including every leading-coefficient and swap factor. At every one of the 40 components of the first reconstruction prime, the two formulas are also checked against direct full-degree ordinary discriminant and resonance resultant computations. D, R, g, v, δ and Γ are interpolated with the explicit Lagrange basis Φ_75(x)/((x−a)Φ_75′(a)). Every interpolated vector is checked at all 40 roots. The Γ column is only a residue cross-check; it is not independently reconstructed under the D/R-sized bound.

### Rigorous canonical-coordinate bound

All bounds below are integers; no numerical interpolation or heuristic stabilization is used. At any complex primitive 75th root a, the Gaussian-binomial coefficients have magnitude at most binom(37,k), because their q-polynomial coefficients are nonnegative and sum to this binomial coefficient. Synthetic division therefore bounds every coefficient of U by B=2^37.

The 71-by-71 Sylvester determinant for D has 35 U rows, with row norm at most 37B, and 36 derivative rows, with row norm at most (1+...+36)B=666B. Hadamard's inequality thus gives

    |D(a)| ≤ (37B)^35 (666B)^36 = M_D.

The root-product formula for R, evaluated at the 75 roots of z^75+1, gives

    |R(a)| ≤ (37B)^75 = M_R.

Also |g(a)|≤37B, |v(a)|≤2^55, and |δ(a)|≤2·37B+2^55.

It remains to turn a bound at all embeddings into a bound on canonical coordinates. Each coefficient of Φ_75(x)/(x−a) is a partial sum of at most the seven nonzero unit-magnitude terms of Φ_75, so its magnitude is at most 7. From

    Φ_75(x) = (x^75−1)(x^5−1)/((x^25−1)(x^15−1))

at a primitive root a,

    |Φ_75′(a)| = 75|a^5−1|/(|a^25−1||a^15−1|) > 1.

Indeed b=a^5 is a primitive 15th root; 15=sum_(k=1..14)(1−b^k) implies 15≤105|1−b|, so the displayed derivative is at least 75/28. The denominators are nonzero because a is primitive. Summing the 40 Lagrange terms now bounds each canonical coefficient of an element with embedding bound M by 280M.

`EXACT_CERTIFICATE.json` records these five integer coefficient bounds. Their bit lengths are 3156, 3174, 51, 64 and 64. The product of the 115 split primes has bit length 3439 and exceeds twice every bound. Consequently symmetric CRT uniquely reconstructs the actual integer vectors D,R,g,v,δ. Their sizes being smaller in practice is not used as a stopping rule. The exact integral products Γ, ι(Γ), Γι(Γ), A are then formed without truncation, so no separate CRT bound for them is needed.

## 3. Integral controls, content and ramified values

A separate arbitrary-integer computation constructs H_37 and U in O by q-Pascal and obtains g,v,δ integrally before comparing with CRT. Involution is implemented by q^(−j)=q^((−j) mod75), followed by canonical reduction. Fresh SymPy polynomial arithmetic independently rechecks every product and the involution, all coordinate gcds, the Bézout identity, all reconstruction-prime tests, all modular columns, and the integer uniqueness bounds.

The exact contents are:

| Element | Canonical-coordinate content |
|---|---|
| D | 5^15 |
| R | 3^36 · 5^37 |
| g | 1 |
| v | 5 |
| δ | 1 |
| Γ | 3^36 · 5^53 |
| ι(Γ) | 3^36 · 5^53 |
| Γι(Γ) | 3^72 · 5^106 |
| A | 3^72 · 5^107 |

Contents are not multiplied mechanically: Γ gains one factor of 5 beyond the product of the separate D and R contents, and multiplication by the primitive δ gains another factor of 5 in A.

The accepted π-adic normalization has π^20=5u, u a global integral unit, and residue field F_25=F_5[q]/(q²+q+1). Deriving Φ_75=πQ+5(q+1) gives J=qQ+5 with πJ=5. For each integral vector x, successive division is performed only when all coordinates of xJ are divisible by 5; each quotient is multiplied back by π and checked exactly. A failed next division gives a nonzero residue. This reconstructs the following values without confusing mod-5 polynomial order with mixed-characteristic valuation:

| Element | vπ | Residue after division by π^vπ |
|---|---:|---|
| D | 318 | 1 |
| R | 750 | 4+4q |
| g | 10 | 4q |
| v | 30 | 3+2q |
| δ | 10 | 3q |
| Γ | 1068 | 4+4q |
| ι(Γ) | 1068 | q |
| Γι(Γ) | 2136 | 1 |
| A | 2146 | 3q |

In particular floor(2146/20)=107 agrees with the exact 5-content exponent. The unequal normalized residues of Γ and ι(Γ) are retained; the involution is not silently removed. The accepted discriminant values are recovered from 2vπ(g)+vπ(D)=338. This does not supply a general lower-to-upper guard identity.

## 4. Exact adverse and good components over F_151

The older order-75 squarefreeness witness q=5 satisfies

    Disc(H_37)=9, D=148, g=86, v=60, δ=112,
    R=Γ=ι(Γ)=A=0.

The exact monic gcds are

    gcd(U,U′)=1,
    gcd(U,z^75+1)=z²+74z+1.

Thus the old squarefreeness witness fails the intrinsic resonance guard, even though δ is nonzero. It is an exact counterexample to using that particular discriminant-only witness as an augmented witness. It is not a counterexample to the true same-component content criterion.

At the different primitive root q=21=5^4 mod151, the certificate gives

    D=36, R=135, g=146, v=9, δ=132,
    Γ=28, ι(Γ)=71, Γι(Γ)=25, A=129.

Both ordinary derivative and resonance gcds are 1 there, and the nonzero A value supplies all augmented factors in the same component. A bad component and a good component coexist. In particular a norm-unit requirement would be unnecessarily strong.

One-coordinate changes in A and D, and a composite replacement for a reconstruction prime, are rejected by the fresh controls. No uploaded or historical research program was executed or imported.

## 5. Consequence and exact boundary

The nonzero exact A proves the characteristic-zero lower guards, including D,R,δ and their required inverse counterparts. For every p≡1 mod4 with p≠5 the computed content is not divisible by p, and p∤75. The accepted same-component lemma selects a common good residue field, makes g and the inverse g units through the resonance factors, and makes v a unit because all its exponents lie strictly between 0 and 75. Nonzero δ excludes the exceptional Hermite parameter. The accepted denominator guard Q_75 is a unit since p∤75. Therefore the accepted augmented bridge applies with all its hypotheses, proving the family stated above.

No conclusion is drawn for the excluded repeated-prime step p=5, nor for arbitrary lower bases. The previously accepted local discriminant-order formula at order 75 stays intact. The resonant root −1 remains, and no scalar-bank cost or minimum changes. Mathematical correctness and the independent acceptance of this finite extension are separate from historical priority, which was not researched here. No Sheet or GitHub writes are included.

## Files and reproduction

Run only these newly authored programs from the packet directory:

    g++ -O3 -std=c++17 fresh_modular_guards.cpp -o /tmp/q29_augmented75
    /tmp/q29_augmented75 115 MODULAR_GUARDS.txt
    python3 fresh_reconstruction.py
    python3 fresh_certificate_checks.py

The certificate is deterministic. `SOURCE_BINDING.json` pins the existing-table source and accepted proof dependencies. `EXACT_CERTIFICATE.json` contains complete integer vectors, all normalized π quotients, contents, Bézout weights and rigorous reconstruction bounds. `FRESH_CONTROL_RECEIPT.json` records the additional controls and adverse/good F_151 components. The external independent review is not represented as a second author implementation in this packet.
