// Fresh author computation, 11 October 2026. No research code imported.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <vector>
using V=std::vector<int64_t>; using i64=int64_t; using u64=uint64_t;
i64 p;
i64 norm(i64 a){ a%=p; return a<0?a+p:a; }
i64 mul(i64 a,i64 b){return (u64)a*b%p;}
i64 pw(i64 a,u64 n){i64 r=1;while(n){if(n&1)r=mul(r,a);a=mul(a,a);n>>=1;}return r;}
void trim(V& a){while(!a.empty()&&a.back()==0)a.pop_back();}
V rem(V a,const V& b){i64 inv=pw(b.back(),p-2);while(a.size()>=b.size()){int sh=a.size()-b.size();i64 c=mul(a.back(),inv);for(int j=0;j<(int)b.size();j++)a[sh+j]=norm(a[sh+j]-mul(c,b[j]));trim(a);}return a;}
i64 resultant(V a,V b){i64 out=1;while(b.size()>1){int m=a.size()-1,n=b.size()-1;if(m<n){if(m*n%2)out=norm(-out);std::swap(a,b);continue;}V r=rem(a,b);if(r.empty())return 0;int d=r.size()-1;if(m*n%2)out=norm(-out);out=mul(out,pw(b.back(),m-d));a=b;b=r;}return b.empty()?0:mul(out,pw(b[0],a.size()-1));}
i64 ev(const V&a,i64 x){i64 r=0;for(auto it=a.rbegin();it!=a.rend();it++)r=norm(mul(r,x)+*it);return r;}
V deriv(const V&a){V b;for(int i=1;i<(int)a.size();i++)b.push_back(mul(i,a[i]));trim(b);return b;}
V pascal(int n,i64 q){V h{1};for(int m=1;m<=n;m++){V r(m+1,0);i64 qp=1;for(int k=m;k>=0;k--){if(k<m)r[k]=h[k];if(k>0)r[k]=norm(r[k]+mul(qp,h[k-1]));qp=mul(qp,q);}h=r;}return h;}
V recur(int n,i64 q){V a{1},b{1,1};i64 qpow=q;if(n==0)return a;for(int m=1;m<n;m++){V c(m+2,0);for(int k=0;k<(int)b.size();k++){c[k]=norm(c[k]+b[k]);c[k+1]=norm(c[k+1]+b[k]);}for(int k=0;k<(int)a.size();k++)c[k+1]=norm(c[k+1]-mul(norm(1-qpow),a[k]));a=b;b=c;qpow=mul(qpow,q);}return b;}
V times_t(const V&a){V b(a.size()+1);std::copy(a.begin(),a.end(),b.begin()+1);return b;}
V minus(V a,const V&b){a.resize(std::max(a.size(),b.size()));for(int i=0;i<(int)b.size();i++)a[i]=norm(a[i]-b[i]);trim(a);return a;}
std::array<i64,6> guards(i64 q,bool control){V h=pascal(37,q);if(h!=recur(37,q))throw 1;V u(37);u[0]=h[0];for(int k=1;k<=36;k++)u[k]=norm(h[k]-u[k-1]);if(u.back()!=1||h[37]!=u.back())throw 2;for(int k=0;k<=36;k++)if(u[k]!=u[36-k])throw 3;
V P(19);P[0]=u[18];V a{2},b{0,1};for(int j=1;j<=18;j++){for(int k=0;k<(int)b.size();k++)P[k]=norm(P[k]+mul(u[18+j],b[k]));V c=minus(times_t(b),a);a=b;b=c;}
V c0{1},c1{p-1,1};for(int s=3;s<75;s+=2){V c2=minus(times_t(c1),c0);c0=c1;c1=c2;}
i64 dp=norm(-resultant(P,deriv(P))),rc=resultant(P,c1),pp=ev(P,2),pm=ev(P,p-2);i64 D=mul(mul(pp,pm),mul(dp,dp)),R=mul(pm,mul(rc,rc));
if(control){i64 directD=resultant(u,deriv(u)); // sign degree36: 630 even
V z75(76);z75[0]=z75[75]=1;i64 directR=resultant(z75,u);if(D!=directD||R!=directR)throw 4;}
i64 g=ev(u,p-1),v=1;for(int j=1;j<=18;j++)v=mul(v,norm(1-pw(q,2*j)));for(int j=0;j<37;j++)v=mul(v,norm(1-pw(q,2*j+1)));i64 delta=norm(2*g-v);return {D,R,g,v,delta,mul(D,R)};}
bool prime(i64 n){if(n<2)return false;for(i64 d=2;d*d<=n;d+=(d==2?1:2))if(n%d==0)return false;return true;}
int main(int argc,char**argv){int count=argc>1?std::stoi(argv[1]):120;std::ofstream out(argv[2]);V phi(41);phi[0]=phi[15]=phi[25]=phi[40]=1;phi[5]=phi[20]=phi[35]=-1;std::vector<int> units;for(int a=1;a<75;a++)if(std::gcd(a,75)==1)units.push_back(a);i64 cand=(1000000000/75)*75+1;for(int run=0;run<count;run++){while(!prime(cand))cand+=75;p=cand;V f=phi;for(auto &c:f)c=norm(c);i64 rho=0;for(i64 a=2;!rho;a++){i64 r=pw(a,(p-1)/75);if(pw(r,75)==1&&pw(r,25)!=1&&pw(r,15)!=1)rho=r;}std::vector<std::array<i64,6>> vals;V roots;for(int a:units){i64 root=pw(rho,a);if(ev(f,root))throw 5;roots.push_back(root);vals.push_back(guards(root,run==0));}
std::array<V,6> coeff;for(auto&v:coeff)v.resize(40);for(int j=0;j<40;j++){i64 root=roots[j];V quot(40);quot[39]=1;for(int k=38;k>=0;k--)quot[k]=norm(f[k+1]+mul(root,quot[k+1]));if(norm(f[0]+mul(root,quot[0])))throw 6;i64 d=ev(quot,root),id=pw(d,p-2);if(mul(d,id)!=1)throw 7;for(int t=0;t<6;t++){i64 c=mul(vals[j][t],id);for(int k=0;k<40;k++)coeff[t][k]=norm(coeff[t][k]+mul(c,quot[k]));}}
for(int j=0;j<40;j++)for(int t=0;t<6;t++)if(ev(coeff[t],roots[j])!=vals[j][t])throw 8;
out<<p<<' '<<rho;for(auto v:coeff)for(i64 c:v)out<<' '<<c;out<<'\n';out.flush();if(run%10==0)std::cerr<<run+1<<" primes\n";cand+=75;} }
