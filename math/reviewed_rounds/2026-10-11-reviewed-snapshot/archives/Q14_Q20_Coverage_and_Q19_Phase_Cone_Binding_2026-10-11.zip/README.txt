Q14–Q20 scoped coverage and Q19 phase-cone binding
11 October 2026

Read REPORT.md first. It states the recovered Q19 acceptance binding and the exact remaining limits for each of the seven already closed scopes.

SOURCE_BINDINGS.json links the exact source and review identities. SOURCE_VERIFICATION.json records fresh byte checks. The evidence directory contains immutable copies of relevant source bodies, public-export records, decisions, scoped table snapshots and the write-cancellation receipt.

RECOMMENDED_EXISTING_ROW_UPDATES.json contains two queued append-only row clarifications. They have NOT been applied. Sheet writes remain paused and GitHub writes blocked. Future writes need renewed authorization and fresh live key/cell checks. No rank, proof status or discovery count is changed.

FRESH_EXACT_BOUNDARY_CHECKS.json contains six new arithmetic controls for strict threshold/equality interpretation. These do not replace the all-size analytic proof. No supplied program was run.

Original and public-export hashes are intentionally different where the archived transformation manifest says so. In particular the original phase-cone theorem is recovered exactly; the original reviewer bytes are identified through the acceptance receipt but are not included as recovered originals. The accepted public review is included at its own verified hash.
