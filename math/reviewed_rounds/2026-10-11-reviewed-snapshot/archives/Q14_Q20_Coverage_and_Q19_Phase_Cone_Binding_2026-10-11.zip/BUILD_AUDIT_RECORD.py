from pathlib import Path
from fractions import Fraction
import json,zipfile,hashlib,csv,io,re,glob,shutil
root=Path(__file__).resolve().parent
packet=root/'packet';packet.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,x):
 p=packet/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def put(p,b):
 p=packet/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
archives=[
 ('baseline',Path('queue_scope_1454/library/Research-cycle-proofs-and-fusion-queue-v1.zip'),'libfile_8002d4c6ba148191b59499d34004d057','MANIFEST.json',''),
 ('supplement_v3',Path('queue_scope_1454/library/Research-review-supplement-2026-10-10-v2-delivery.zip'),'libfile_c587a06594ac8191b9479f3c402f42db','MANIFEST.json',''),
 ('phase_cone_public',root/'library/math-update-2026-10-10-1340-public.zip','libfile_1f28e1476ed08191929ab0029a0e4203','ARTIFACT_MANIFEST.json','math/updates/2026-10-10-1340/'),
 ('phase_cone_original',root/'library/FFT/FFT_HOLONOMY_PHASE_CONE_RIGIDITY_2026-10-10.zip','libfile_ce97f23b4b988191b774751d637b4861',None,'fft_phase_cone_20261010/')]
zs={};source_archives=[];verification=[]
for name,p,lib,m,pre in archives:
 z=zipfile.ZipFile(p);zs[name]=(z,pre)
 assert z.testzip() is None
 source_archives.append(dict(name=name,filename=p.name,library_file_id=lib,bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
 if m:
  b=z.read(pre+m);d=json.loads(b);entries=d.get('members',d.get('files',[]));out=[]
  for e in entries:
   n=e.get('member',e.get('path'));b1=z.read(pre+n)
   assert len(b1)==e['bytes'] and sha(b1)==e['sha256'],(name,n)
   out.append(dict(member=pre+n,bytes=len(b1),sha256=sha(b1),match=True))
  put(Path('evidence')/name/m,b)
  verification.append(dict(archive=name,crc_pass=True,manifest_members=len(out),members=out))
 else:
  entries=[]
  for line in z.read(pre+'SHA256SUMS.txt').decode().splitlines():
   if not line.strip():continue
   h,n=line.split(maxsplit=1);n=n.strip().lstrip('*');b=z.read(pre+n)
   assert sha(b)==h,(n,h,sha(b));entries.append(dict(member=pre+n,sha256=h,match=True))
  verification.append(dict(archive=name,crc_pass=True,manifest_members=len(entries),members=entries))
# Byte-preserve all selected bodies and acceptance records; no supplied program is executed.
selected={
'baseline':['tables/07-proof-sources.csv','review/DECISIONS.json','proofs/02-algebra-closures.md','proofs/05-structured-fusions.md','proofs/06-composite-weyl.md','proofs/11-weil-curvature.md','dependencies/03-growing-fiber-theory.md','dependencies/04-growing-fiber-review.md','comparisons/02-structured.md'],
'supplement_v3':['evidence/SP11.md','reviews/supplement_v3/review_ledger.json','reviews/supplement_v3/ACCEPTANCE_RECEIPT.json','reviews/supplement_v3/REVIEW_SUMMARY.md'],
'phase_cone_public':['reviews/03_phase_cone.md','sources/phase_cone/THEOREM.md','sources/phase_cone/README.md','PROOF_STATUS.json','SOURCE_ACCEPTANCE.json','SOURCE_EXPORT_TRANSFORMS.json','controls/phase_cone/EXACT_REJECTION_CERTIFICATE.json','controls/phase_cone/FRESH_CONTROL_RESULTS.json'],
'phase_cone_original':['THEOREM.md']}
selected_pins=[]
for name,ns in selected.items():
 z,pre=zs[name]
 for n in ns:
  b=z.read(pre+n);dest=Path('evidence')/name/n;put(dest,b)
  selected_pins.append(dict(archive=name,archive_member=pre+n,packet_member=str(dest),bytes=len(b),sha256=sha(b)))
# Verify exact original theorem identity twice and confirm documented export edit.
z,pre=zs['phase_cone_original'];original=z.read(pre+'THEOREM.md');standalone=(root/'library/FFT/THEOREM(20261010-123847).md').read_bytes()
assert original==standalone and sha(original)=='62fac4ad0add32886b77c54329bd590eda9f3a61d439478e4353d12c1acfeb64'
z,pre=zs['phase_cone_public'];transforms=json.loads(z.read(pre+'SOURCE_EXPORT_TRANSFORMS.json'))['files'];t=next(x for x in transforms if x['export_path']=='sources/phase_cone/THEOREM.md')
a=original.decode();start=a.index('Run `OPENBLAS_NUM_THREADS=1 python verify.py`');end=a.index('\n',start);before=a[start:end]
assert len(before.encode())==t['replacements'][0]['before_utf8_bytes'] and sha(before.encode())==t['replacements'][0]['before_sha256']
b=t['prepended_export_notice']+'\n\n'+a.replace(before,t['replacements'][0]['after'],1)
assert b.encode()==z.read(pre+'sources/phase_cone/THEOREM.md')
review=z.read(pre+'reviews/03_phase_cone.md');assert sha(review)=='06caeaf44b5dfbdea31cc45ed62bea26ba78529c3545a5bf114850b39119cadb'
receipt=json.loads(z.read(pre+'SOURCE_ACCEPTANCE.json'));rr=next(x for x in receipt['accepted_review_identities'] if x['family']=='Holonomy phase-cone obstruction')
assert rr['public_review_sha256']==sha(review)
phase_binding={
 'queue':'Q19','new_mathematical_acceptance':False,'result':'later accepted addendum source and separate review recovered',
 'original_theorem_sha256':sha(original),'original_archive_sha256':source_archives[3]['sha256'],
 'standalone_theorem_library_file_id':'libfile_93813d7c16f081919b2a7d4f11aa98c6','original_archive_library_file_id':'libfile_ce97f23b4b988191b774751d637b4861',
 'public_packet_library_file_id':'libfile_1f28e1476ed08191929ab0029a0e4203',
 'public_review_sha256':sha(review),'accepted_original_review_sha256':rr['original_review_sha256'],
 'public_theorem_export_sha256':sha(b.encode()),'theorem_export_transform_verified_exactly':True,
 'review_qualification':'Public review is a declared two-location text/link export, not byte-identical to the original reviewer artifact. Original reviewer bytes were not recovered in this pass. Acceptance receipt explicitly maps the two hashes; the public review itself identifies the exact original theorem hash and reproduces the accepted proof and scope.',
 'disjoint_from':'baseline proof P11 and baseline review R29; no R29 extension inferred'}
# Frozen existing rows and cross-table relation, never theorem equivalence.
qs={f'Q{n}' for n in range(14,21)};snapshots={};pins=[]
for name,start in [('LIVE_RESEARCH_QUEUE',3),('FULL_CATALOGUE',3),('FULL_NOVELTY_REGISTER',5)]:
 p=Path('coverage_audit_1334')/(name+'.json');raw=p.read_bytes();d=json.loads(raw)['structuredContent'];head=d['values'][0];out=[]
 for i,r in enumerate(d['values'][1:],1):
  if name=='LIVE_RESEARCH_QUEUE':keep=r and r[0] in qs
  elif name=='FULL_CATALOGUE':keep=bool(qs.intersection(json.loads(r[4])))
  else:keep=any(re.search(r'\bQ(?:1[4-9]|20)\b',str(c)) for c in r)
  if keep:out.append({'sheet_row':start+i,'values':r,'record':dict(zip(head,r))})
 snapshots[name]=out;dump(Path('evidence/snapshots')/(name+'_SCOPED.json'),{'source':str(p),'source_sha256':sha(raw),'source_range':d['range'],'header':head,'rows':out})
 pins.append({'path':str(p),'bytes':len(raw),'sha256':sha(raw)})
# Check later fixed-cell receipts; record both successful and canceled writes without confusing them.
catrows={x['sheet_row'] for x in snapshots['FULL_CATALOGUE']};novrows={x['sheet_row'] for x in snapshots['FULL_NOVELTY_REGISTER']}
rs={1877766156:set(range(17,24)),214001001:catrows,214001003:novrows};later=[]
for p in sorted(glob.glob('consolidation_*/EXACT_BATCH.json')):
 raw=Path(p).read_bytes();d=json.loads(raw);hits=[]
 for i,r in enumerate(d.get('requests',[])):
  u=r.get('updateCells',{});st=u.get('start',{});sid=st.get('sheetId');row=st.get('rowIndex',0)
  for j,values in enumerate(u.get('rows',[])):
   if row+j+1 in rs.get(sid,set()):hits.append({'request_index':i,'sheet_id':sid,'sheet_row':row+j+1,'column_index':st.get('columnIndex',0),'values':values})
 later.append({'path':p,'sha256':sha(raw),'request_count':len(d.get('requests',[])),'scoped_row_hits':hits})
for p in sorted(glob.glob('consolidation_*/QUEUED_CELL_PLAN.json')):
 raw=Path(p).read_bytes();d=json.loads(raw);hits=[]
 for u in d.get('updates',[]):
  sh=u.get('sheet');row=int(re.sub(r'\D','',u.get('cell','0')) or '0');relevant=(sh=='Research queue' and row in range(17,24))or(sh=='Catalogue' and row in catrows)or(sh=='novelity breakthough' and row in novrows)
  if relevant:hits.append(u)
 later.append({'path':p,'sha256':sha(raw),'status':d.get('status'),'scoped_row_hits':hits,'not_applied':True})
put(Path('evidence/receipts/CANCELLED_WRITE_RECEIPT.json'),Path('consolidation_1450/CANCELLED_WRITE_RECEIPT.json').read_bytes())
dump(Path('evidence/LATER_CONSOLIDATION_SCREEN.json'),later)
# Bind current accepted statements to exact documents and namespace-scoped reviews.
z,pre=zs['baseline'];decisions=json.loads(z.read('review/DECISIONS.json'))['rows'];src=list(csv.DictReader(io.StringIO(z.read('tables/07-proof-sources.csv').decode('utf-8-sig'))));src={x['Proof ID']:x for x in src}
qmap={'Q15':('P06','R17','Section 1–4'),'Q16':('P05','R18','Section S6'),'Q17':('P02','R15','Section A'),'Q18':('P11','R28','Section 1'),'Q19':('P11','R29','Section 2'),'Q20':('P02','R16','Section B')};bindings=[]
for q,(p,r,section) in qmap.items():
 s=src[p];v=next(x for x in decisions if x['id']==r);actual=sha(z.read(s['Proof-pack member']));assert actual==s['SHA-256']==v['reviewed_artifact_sha256'] and v['verdict']=='ACCEPT'
 bindings.append({'queue':q,'proof_namespace':'baseline','proof_id':p,'section':section,'member':s['Proof-pack member'],'sha256':actual,'review_namespace':'baseline/review/DECISIONS.json','review_id':r,'review_verdict':v['verdict'],'scope':v['scope_boundary'],'remaining':v['remaining_obligation']})
z,pre=zs['supplement_v3'];body=z.read('evidence/SP11.md');ledger=z.read('reviews/supplement_v3/review_ledger.json');rec=json.loads(z.read('reviews/supplement_v3/ACCEPTANCE_RECEIPT.json'));assert sha(ledger)==rec['ledger_sha256'];lr=json.loads(ledger)['rows']
relevant=[x for x in lr if x['id'] in ['H06','H07','H08','H09','H10','H11','H12','H14','H15']]
assert all(x['reviewed_artifact_sha256']==sha(body) for x in relevant)
bindings.insert(0,{'queue':'Q14','proof_id':'SP11','member':'evidence/SP11.md','sha256':sha(body),'section':'Section 3','review_namespace':'supplement_v3','accepted':['H06','H07','H08','H09','H10'],'rejected':['H11','H12'],'open':['H14','H15'],'ledger_sha256':sha(ledger),'ledger_rows':relevant})
# Small fresh exact controls for the newly resolved addendum's endpoint semantics.
# These are independently authored arithmetic checks, not supplied-code replay or a replacement proof.
checks=[]
for n,c2,e,want,label in [(4,Fraction(1,2),Fraction(1,10),Fraction(41,100),'source certificate strict rejection'),(2,Fraction(1,2),Fraction(0),Fraction(0),'N2 equality does not reject'),(4,Fraction(1,4),Fraction(0),Fraction(0),'N4 threshold equality does not reject'),(4,Fraction(1),Fraction(1,3),Fraction(0),'positive cone error-floor equality'),(4,Fraction(1),Fraction(1,4),Fraction(11,16),'positive cone stricter tolerance rejects')]:
 delta=n*c2*(1-e)**2-(1+e)**2;assert delta==want
 checks.append({'label':label,'N':n,'cos_squared_half_width':str(c2),'error_tolerance':str(e),'exact_gap':str(delta),'strict_reject':delta>0,'pass':True})
# The N2 threshold has a flat unitary attaining it: [[1,i],[i,1]] / sqrt(2).
# Integer Gaussian multiplication verifies numerator times conjugate transpose = 2I.
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
A=[[(1,0),(0,1)],[(0,1),(1,0)]];prod=[]
for i in range(2):
 row=[]
 for j in range(2):
  terms=[mul(A[i][k],(A[j][k][0],-A[j][k][1])) for k in range(2)];row.append(tuple(sum(t[d] for t in terms) for d in range(2)))
 prod.append(row)
assert prod==[[(2,0),(0,0)],[(0,0),(2,0)]]
checks.append({'label':'N2 equality witness exact Gaussian-integer unitarity','numerator_gram':prod,'pass':True})
dump(Path('SOURCE_BINDINGS.json'),{'source_archives':source_archives,'snapshot_pins':pins,'selected_members':selected_pins,'queue_bindings':bindings,'q19_later_phase_cone':phase_binding})
dump(Path('SOURCE_VERIFICATION.json'),{'archive_checks':verification,'original_standalone_matches_archive':True,'original_theorem_matches_accepted_review_pin':True,'theorem_export_transformation_exact':True,'supplied_programs_executed':False,'source_programs_imported_or_parsed':False})
dump(Path('FRESH_EXACT_BOUNDARY_CHECKS.json'),{'scope':'Six exact arithmetic boundary controls only; source suite not rerun; not a complexity or sharpness claim.','checks':checks})
dump(Path('CROSS_TABLE_COVERAGE.json'),{'scope':'Navigation relationships only, not theorem equivalence or blanket accepted overlays.','canonical_count':len(snapshots['FULL_CATALOGUE']),'novelty_count':len(snapshots['FULL_NOVELTY_REGISTER']),'catalogue':[{'row':x['sheet_row'],'id':x['values'][0],'title':x['values'][2],'queue_ids':json.loads(x['values'][4])} for x in snapshots['FULL_CATALOGUE']],'novelty':[{'row':x['sheet_row'],'id':x['values'][2],'title':x['values'][4]} for x in snapshots['FULL_NOVELTY_REGISTER']]})
# Queued append-only recommendations. No live write and no status/rank/count change.
q14note='[2026-10-11; exact source-binding clarification] The controlling fresh F015 audit is SP11 section 3, SHA-256 4aed4e38953ac9266f8dbe8995dae1d61046f02972f11c5434c018681eac8df5, in Research-review-supplement-2026-10-10-v2-delivery.zip (Library libfile_c587a06594ac8191b9479f3c402f42db). In the supplement_v3 review namespace H06-H10 ACCEPT its scoped cap, aggregate, guarded Green, coverage and optional prefix claims; H11 REJECTS replacing local Green guards by mere invertibility, H12 REJECTS unrestricted promotion, and H14-H15 keep implementation and priority gates open. These are not baseline proof IDs or uniformly accepting verdicts. Existing proof closure remains unchanged.'
q19note='[2026-10-11; exact later-addendum binding] Baseline P11/R29 accepts the Phase18 curvature/holonomy theorem at SHA-256 9be4a2795988244f0658fc9e90c0e7181d5d02a0325a738ee2045e3b4377ddfa. The separate phase-cone addendum is accepted in math-update-2026-10-10-1340-public.zip (Library libfile_1f28e1476ed08191929ab0029a0e4203), reviews/03_phase_cone.md, public-review SHA-256 06caeaf44b5dfbdea31cc45ed62bea26ba78529c3545a5bf114850b39119cadb. Its acceptance receipt maps original review SHA-256 f591dd311d86f64f6cda23246255ba3b215eaf6e41cd790f01f3dca02ec8dd6c; the exact original theorem SHA-256 62fac4ad0add32886b77c54329bd590eda9f3a61d439478e4353d12c1acfeb64 is recovered from original Library libfile_ce97f23b4b988191b774751d637b4861. The public review and theorem are declared textual exports, not byte-identical originals. For N>=2 and c=cos(W/2), the normalized complex operator-error floor is max(0,(sqrt(N)c-1)/(sqrt(N)c+1)); a positive rejection requires a strict threshold, and equality is inconclusive. The common-cone, effective-mask and damped jointly dephasable Green guards, separate certification costs and unresolved priority remain. This is provenance reconciliation, not a new theorem or extension of R29.'
qr={x['values'][0]:x for x in snapshots['LIVE_RESEARCH_QUEUE']}
recommendations=[]
for q,cell,txt in [('Q14','E17',q14note),('Q19','E22',q19note)]:
 old=qr[q]['values'][4];recommendations.append({'sheet':'Research queue','row_key':q,'cell':cell,'current_snapshot_text':old,'append_text':txt,'proposed_snapshot_text':old+'\n\n'+txt,'operation':'Append to the freshly re-read current existing cell only after Sheet writes are explicitly reauthorized; preserve all current history.','no_status_rank_count_change':True})
dump(Path('RECOMMENDED_EXISTING_ROW_UPDATES.json'),{'status':'QUEUED_ONLY_SHEET_PAUSED_GITHUB_BLOCKED','updates':recommendations,'cross_table_action':'No Catalogue or novelty-row mutation recommended: their historic scopes and related-current-status qualifiers are deliberately distinct. Preserve all 12 linked canonical records and 12 novelty records.','write_performed':False,'fresh_live_read_required_before_future_write':True})
dump(Path('VERDICT.json'),{'verdict':'SCOPED_COVERAGE_CONFIRMED_AND_Q19_ADDENDUM_BINDING_RECOVERED','queues':sorted(qs),'new_proofs':0,'new_discovery_count':0,'existing_scope_reopened':False,'q18_historical_gap_reported_as_current':False,'q19_phase_cone_original_theorem_hash_verified':True,'fresh_boundary_control_count':len(checks),'sheet_writes':0,'github_writes':0,'uploaded_programs_executed':0,'children_spawned':0})
print(json.dumps({'archives':[(x['archive'],x['manifest_members']) for x in verification],'selected_members':len(selected_pins),'scoped_catalogue':len(catrows),'scoped_novelty':len(novrows),'later_scoped_hits':sum(len(x['scoped_row_hits']) for x in later),'checks':len(checks)},indent=2))
