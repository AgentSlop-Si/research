# Independent Phase38 review: two-mask projective elimination

## Decision and coverage

**Accepted, with the source's finite-family scope.** At N=4,8,16,32,64, the precise six-Green network cannot equal the unnormalized Fourier matrix for any complex middle pencil coefficient, any two nonzero complex internal diagonal masks, or any two internal permutations. The six generator orders and their six Green couplings, together with both outer mixing coefficients, remain fixed. No all-size or unrestricted FFT lower bound follows.

At N=128 and 256, only the fixed-order exclusion and finite sampling are verified. All-permutation exclusion at these sizes remains open. The four source sample sequences were not replayed in exactly their original order; instead 200,000 fresh deterministic samples were checked per size and prime. Sampling proves no universal exclusion.

All new mathematical text was inspected: THEOREM.md Sections 1–7, CHECKPOINT.md, README.md, VALIDATION.md, both identical start-here copies, PRIOR_ART.md and RUN.md. Theorems 38A/38B, all five exhaustive sizes, the modular collision, direct characteristic-zero N4 control, calibration counts, separate Weyl failures and cost/scope statements were independently checked. The uploaded Python/C++ programs and their 14/14 and inherited 13/13 test-run assertions were not executed or certified as software. Original timing and rolling-checksum claims were not reproduced. Historical nested appendices retain their earlier review scope; byte identity does not mean all of them were newly audited.

## Algebraic gate and permutations

Because A and C are invertible, equality is equivalent to T=A^−1 F C^−1=diag(u)P1(G2+lambda G3)P2diag(v). The first two rows and first three columns of T pull back to any ordered distinct row pair and ordered distinct column triple in the middle pencil. There are exactly N²(N−1)²(N−2) such witnesses, covering every pair of internal permutations without enumerating complete permutations.

For j=1,2, the source equations are precisely the cross-multiplied identity

T[1,j]T[0,0]B[r1,c0]B[r0,cj]−T[1,0]T[0,j]B[r1,cj]B[r0,c0]=0.

The mask factors cancel. This uses no division by candidate entries, so accidental zeros do not invalidate necessity. Each polynomial has degree at most two. For ascending coefficients a,b, its displayed resultant

(a2 b0−a0 b2)²−(a2 b1−a1 b2)(a1 b0−a0 b1)

is exactly the padded degree-two Sylvester determinant. A nonzero value is sufficient to exclude a common finite root in any algebraic extension. If both degrees drop, this padded determinant can vanish even when the actual lower-degree polynomials are coprime; the source uses only the safe nonzero direction. Three hundred independently generated degree-two and degenerate controls agree with direct 4-by-4 determinant elimination.

Allowing zero diagonal entries would not create an omitted exact Fourier solution: a zero on either diagonal makes the circuit singular. The statement remains representation-specific; new outer endpoint permutations or freely varying Green generator couplings are not included in the audited architecture.

## Exact reconstruction and exhaustive results

The reviewer independently regenerates all seeded cycle orders, all six Green kernels, the outer mixers, both outer inverses and T. Kernel orientation is predecessor-row action corresponding to the supplied cycle successor on basis columns; it agrees with the inherited positive Fourier convention. Every one of the 524,256 entries in the fourteen supplied T/G2/G3 instance triples is reproduced exactly at the two primes. All Green guards and outer inverses are valid.

The fresh C++ checker is reviewer-authored and compiled locally. It exhausts **2,076,565,824 ordered mappings** over the five sizes and two primes. The counts per prime are:

- N4: 288;
- N8: 18,816;
- N16: 806,400;
- N32: 29,521,920;
- N64: 1,007,935,488.

At p=998244353 every resultant is nonzero. At p=2013265921 there is exactly one zero, only at N64, for (r0,r1;c0,c1,c2)=(53,55;19,26,5). Independent elimination shows its gcd is linear with root 1869802666. At the same mapping the first-prime resultant is 470304279, so this is a modular coincidence, not a complex solution.

For N128/256 both fixed-order resultants agree exactly with source data, and 800,000 fresh samples in total have no zero. The source Bezout identities for all fourteen fixed-order pairs were independently checked. Thirty planted masked-and-permuted pencils vanish at their planted parameter and calibrate exactly, guarding against a reject-everything test. The mathematical planted full-Fourier construction is valid with an explicitly dense/expensive outer factor; its exact source seeded software instance was not rerun.

## Characteristic-zero validity

The couplings lie in Q(i), and the Fourier root in Q(zeta_N), with i=zeta_N^(N/4). Both reductions use a consistent primitive root of order N and its induced fourth root. Every used denominator and determinant has nonzero residue. A zero algebraic resultant would map to zero under any valid reduction. Thus one nonzero modular image per mapping proves the characteristic-zero exclusion; no bound on a numerator's size or numerical root test is needed.

Independently of modular lifting, the reviewer wrote rational-pair arithmetic for Q(i), inverted both N4 outer matrices exactly, constructed the two degree-two polynomials, and obtained a nonzero exact resultant. Its reductions match both independently rebuilt modular pairs. This establishes the N4 gcd degree zero directly, with no SymPy or uploaded implementation.

## Mask recovery, Weyl checks and costs

When all target and candidate anchor entries are nonzero, v_j=T_0j/B_0j and u_i=T_i0/(B_i0 v_0) give u_0=1 and match the first row/column. The masks are unique up to a common reciprocal scalar rescaling. A complete factorization requires every remaining entry. For lambda=7 and identity internal permutations, all fourteen field/size instances match exactly 2N−1 anchors and mismatch every (N−1)² interior entry. Fresh reconstruction of the full circuit also shows that each of the two Fourier Weyl equations separately fails in these cases.

Eighty-four fresh cyclic scan controls check 6,096 recurrence coordinates. A supplied six-Green circuit has six O(N) solves, three branch additions, two internal mask applications, two paid internal permutations and scalar/endpoint work, still O(N) online for this fixed stage count. Computing T by dense inversions costs O(N³); exhaustive certification costs O(N⁵). Mask calibration is linear only after target anchors have been supplied. None of those research costs are hidden in a claimed fast executor, because the family is excluded.

## Provenance and prior art

The direct ZIP SHA-256 is c8a40348996fa451a1414492484a8dce576d9524206628ffbddc3d8a0d6fef84 (3,284,826 bytes), Library libfile_9ae9df8ea5188191888de28d8e8ac9f0. CRC and all 39 source-manifest entries pass. The nested complete Phase37 archive is byte-identical to the earlier direct source: SHA-256 96ad7b12122e2160c8cc104eefe9b1ab93f7da054881610a37d2c91325218430. The vendored Phase37 generator's byte identity is recorded separately; it stayed inert. Phase38 changes the architecture from fixed internal masks to jointly free masks by moving to the transformed target. Its quadratic gate is therefore a stronger finite-family statement, not merely renaming the earlier degree-2N phase test.

Diagonal equivalence through graph multiplicative invariants is classical; see the primary [Saunders–Schneider paper](https://people.math.wisc.edu/hans/paper_archive/scanned_papers/hs058.pdf). The present low-degree elimination follows directly from that elementary invariant and the affine pencil. External priority of this precise project-specific application is not established. The source correctly avoids applying [Ailon's unitary-gate result](https://arxiv.org/abs/1305.4745) or [well-conditioned model result](https://arxiv.org/abs/1403.1307) to arbitrary nonunitary Green circuits. Those abstracts were inspected for model scope, not their full proofs. The source's Haagerup web link was unavailable in this pass, and its detailed historical citation was not needed for the independent algebraic proof.

## Reproducibility

All executed programs were reviewer-authored. Python uses only the standard library; exhaustive replay additionally requires a C++17 compiler. All three result JSON files have been compared byte-for-byte against a fully isolated replay, including the billion-scale enumerations. Source files are read only as inert matrix/certificate data. See REPRODUCE.md and PORTABILITY.json for exact commands and scope.
