# Accepted prefix theorem: a q-group times a cyclic prime power

Independent review, 11 October 2026 UTC. Decision: ACCEPT as written. No mathematical correction is required.

Let p and q be distinct primes, let H be any finite group of order n=q^a, and let G=H×C_(p^b), with integers a,b≥0. For an ordering x of its labeled elements, let T_j be its first j elements, S_j={g:gT_j=T_j},

    Z_G(x)=Σ_(j=1)^|G|(|S_j|−1),
    B(x)=⟨S_1,...,S_(|G|−1)⟩.

The full prefix contributes to Z and is excluded from B. The accepted conclusions are:

1. The exact maximum is

       M(G)=np^b[a(1−1/q)+b(1−1/p)].

2. Exactly the recursive maximal-subgroup right-coset orders attain it: choose a maximal proper subgroup, list its distinct right cosets consecutively, and independently use a maximizing local order inside each coset. Recursion ends at the singleton.
3. For every nontrivial G, the top subgroup of an optimizer is unique and equals B(x).
4. With A(K) the number of labeled maximizing orders and A(1)=1, for b≥1,

       A(H×C_(p^b))=p! A(H×C_(p^(b−1)))^p
                       +q! Σ_(M maximal in H) A(M×C_(p^b))^q.

   The sum is empty for H=1. For b=0 and H≠1,

       A(H)=q! Σ_(M maximal in H) A(M)^q.

   There is no automorphism or translation quotient, and no extra representative factor.
5. For a,b≥1 and B(x)=G,

       Z_G(x)≤M(G)−p^(b−1)(p−1).

   This is a sufficient gap, not a sharpness claim.

The theorem includes arbitrary b, arbitrary q-group structure, p=2<q, and both prime-power axes. The singleton has score zero and one ordering, with no top subgroup; no strict escape assertion is made for it.

The all-b result follows from the invariant retaining every enclosing checkpoint clip, whole-gap densification, an exact quotient identity, explicit retained top-endpoint deficits, and induction on a+b through both maximal-subgroup types. It is not inferred from b=2 or finite controls.

Acceptance binds Library libfile_1dae9a88f5108191a048f86017d447d6, version 0: archive 42,673 bytes, SHA-256 f41867be27ab0f77376b6745adff35575aa3af5044ce4f29d201f60179858d3e; unchanged THEOREM.md 21,879 bytes, SHA-256 e13674de3c970bc3a18417d9f6e01630b388a0632571637e97674c526f56afd9. Fresh independent Library readback and all fourteen payload checks passed.

This does not accept a noncyclic p-group factor, three distinct prime factors, all finite nilpotent groups, a sharp escaping maximum, historical priority, or closure of the EFK source-access gap. It is an independent project mathematical review, not external peer review or proof-assistant certification.
