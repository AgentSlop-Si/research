# Reviewed cyclic window theorem

11 October 2026. Independent mathematical review of the exact candidate bytes identified in INPUT_VERIFICATION.json. Verdict: PASS. This statement is a consolidated, qualified version of the candidate, with no mathematical repair required. The original candidate is preserved unchanged.

## Scope and output

Let N >= 2, let p be a supplied prime with N dividing p-1, and let omega in F_p be supplied with certified exact order N. Let 1 <= r < N. Given all N raw coordinates of x in F_p^N, there is a deterministic exact recognizer for

    x_j = omega^(a j^2) sum_(ell=1)^s gamma_ell omega^(b_ell j), 0 <= j < N,

where a and b_ell are integers modulo N, 0 <= s <= r, the b_ell are distinct modulo N, and each listed gamma_ell is nonzero. The zero vector has the empty representation. The algorithm accepts exactly this family, returns one fully verified representation, and on acceptance returns all N positive-sign unnormalized DFT values. Rejection asserts nonmembership; it does not provide the rejected vector's transform.

There is no N >= 3r condition. Every nonzero raw input has a usable center c with x_c != 0. Use the periodic lookup xbar_j = x_(j mod N), including negative j. The valid model itself is N-periodic, since the exponent change under j -> j+N is a multiple of N. Repeated coordinates are lookups from the given data, not additional observations or an inferred promise about arbitrary data.

## Certificate and decision

Set f(d)=d(d-1)/2 and

    E_c(t) = det[xbar_(c+i-j) t^f(i-j)]_(i,j=0)^r.

Its constant coefficient is x_c^(r+1) != 0, its degree is at most D=binom(r+2,3), and every leading k-square minor has constant coefficient x_c^k. Every genuine phase a satisfies E_c(omega^(-2a))=0. These conclusions hold with wrapped sample indices and even when D >= p.

Set L=N/gcd(2,N). Testing a=0,...,L-1 covers every representation: for even N, the change a -> a+N/2 can be absorbed into b_ell -> b_ell+N/2. This removes that universal parameter redundancy only; accepted canonical phases need not be unique. At most C=min(D,L) phases survive, including the possibility that every phase survives. Reduction modulo t^L-1 does not preserve a nonzero-polynomial certificate and is used only for evaluation.

For each surviving phase, dechirp every raw entry and use at most the first 2r entries of its periodic continuation for recurrence recovery. In the all-length construction, compute the rank s of the r-square Hankel matrix, require its leading s-square block to be nonsingular, solve its monic node polynomial, and require exactly s distinct supplied-grid roots. Check all N-s ordinary unwrapped recurrence residuals and solve the first s moments for weights. These checks force agreement with every raw entry, even when 2r>N. Omit zero weights. An all-zero prefix alone never authorizes acceptance of a nonzero raw vector.

For dyadic N, ordinary Berlekamp-Massey on the 2r periodic-prefix values can instead recover a connection polynomial C(z) with constant coefficient 1. Require order s <= r, degree exactly s, and exactly s distinct grid roots. Recover weights through the candidate's partial-fraction formula and synthesize all N samples for exact comparison. A prefix failure or any failed root/synthesis test rejects that phase. This remains sound for arbitrary negative inputs and complete for all true s-term signals.

## Paid complexity

Write kappa=log_2(3). Inheriting the audited D05 polynomial Toeplitz construction, the blocked all-length verification routines, and D06's every-length Gauss evaluator, the costs are

    O(N r^(2+kappa) + r^(2+3kappa)) field additions/multiplications,
    O(1+r^4) scalar field inversions,
    O(N+r^4) live field elements.

For dyadic N only, input-support FFT pruning gives

    O(N r^3 log(r+2) + r^(2+3kappa)) additions/multiplications,

with the same conservative inversion and storage bounds. The all-length bound does not inherit this dyadic refinement for arbitrary N.

These bounds pay for all raw reads, coefficient/root-table work, all candidate failures, and accepted output writes. All-length blocked routines require s+1<=N, which follows from r<N. A single scalar inverse seeds the Toeplitz/Newton calculations; each surviving candidate requires O(r) additional scalar inversions. Integer gcd/modular-inverse and index arithmetic for the Gauss formulas are separate from field-operation counts. The result does not supply field/root discovery, a bit-complexity theorem, numerical robustness, optimized implementation timings, or a constant-depth/constant-round algorithm.

The r>=N case is separately trivial via dense Fourier representation of every vector; N=1 is immediate. Neither branch is a new structured fast-transform result. For growing r comparable to N, the stated bounds are conservative and expensive.

## Claims this review does not establish

No historical-priority conclusion follows. No additional raw-sample reduction, common-phase uniqueness, universal fast Fourier algorithm, or optimized Toeplitz/FFT implementation is claimed. The constant-vector Vandermonde specialization establishes degree sharpness for this eliminant, not optimality over other certificates or maximality of distinct phase roots.
