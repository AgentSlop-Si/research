import json,csv,re,hashlib,collections
from pathlib import Path
R=Path(__file__).resolve().parent;BASE=R.parent/'coverage_audit_1334'
def read(n):return json.loads((BASE/n).read_text())['structuredContent']['values']
C=read('FULL_CATALOGUE.json');N=read('FULL_NOVELTY_REGISTER.json');Q=read('LIVE_RESEARCH_QUEUE.json')
current={r[0]:dict(zip(Q[0],r)) for r in Q[1:]}
novelty={r[2]:(i,dict(zip(N[0],r))) for i,r in enumerate(N[1:],6)}
matches=json.loads((R/'evidence/SOURCE_HASH_MATCHES.json').read_text());byhash=collections.defaultdict(list)
for m in matches:byhash[m['sha256']].append(m)
packet=R/'current_packet';ps=list(csv.DictReader((packet/'tables/07-proof-sources.csv').open(encoding='utf-8-sig')));proofs={p['Proof ID']:p for p in ps};reviews={r['id']:r for r in json.loads((packet/'review/DECISIONS.json').read_text())['rows']}
live=json.loads((R/'evidence/LIVE_FIRST89_IDS.json').read_text())['structuredContent']['values'];assert [r[0] for r in C[1:90]]==[r[0] for r in live]
special={
 'M-SCAN-DIMENSION':'N=8 depths1,2,3 and the20-dimensional depth2 tangent gauge kernel independently reconstructed in this pass. Next: replay the N=16 and N=32 saved witnesses and gauge certificates with an independent verifier; do not infer all-N saturation. No Fourier target exclusion follows from generic dimension.',
 'M-HARPER':'Bind the parity-resolved Harper theorem itself to an independent proof audit, then check its zero-mode/eigenvalue and minimal polynomial-degree assertions. The attached downstream phase-pencil audit alone is not blanket acceptance of these upstream claims.',
 'M-SPARSE-PREFIX':'Recover and bind the cited earlier separate audit to this exact sparse-prefix theorem and its s-sparse preconditioner assumptions. Do not reopen the accepted theorem solely because its review is inherited; no composite Fourier full-spark or product-of-two-additive-sums extension is included.',
 'M-GLOBAL-STAGES':'Separate the parity, random SPD, grid and Cayley/involution stage primitives; bind each order-robust rank and quantitative singular-value claim to its exact theorem/audit. Q06 macro-compiler closure does not certify these distinct construction claims. Identify a concrete non-Fourier family with paid norm envelopes/template budget if pursuing Q06.',
 'ALG-WEIL-TENSOR':'Keep Q18 corrected higher-local-ring theorem acceptance distinct from this v24 finite-field parabolic representation and certificate package. Bind the exact v24 normal-form convention and claimed exhaustive arrays if promoting that source; source-program execution remains unperformed.',
 'ALG-WEIL-LOCAL':'Q18 corrected v26 theorem is already closed. Repair the supplied implementation association to U(E)=F^-1 C_(-E) F and independently test conventions before declaring the source implementation coherent. No source suite executed in this pass.',
 'ALG-BIVARIATE-MASK-ELIMINATION':'Do not reopen the already independently reviewed N16 cubic enumeration. Preserve quartic N16 and N32+ as sampled only; exhaustive larger-degree/size certification is a distinct optional extension, not current acceptance.',
 'M-PERMUTATION-DISPLACEMENT':'Historical missing-audit wording is superseded for the current Q21 scope by exact P07/R32 acceptance, whose body-hash binding is verified here. No new proof reread is needed. Weighted monomial extensions and priority remain separate.',
 'C03':'Current Q17 general-pencil extension is closed at P02/R15; do not retain the historical not-separately-audited wording as a current blocker. Preserve generic versus special vanishing-order distinction.',
 'ALG-EVEN-PRONY-EXTRA-POLE':'Current Q20 h+1-pole extension is closed at P02/R16. Exact h-pole optimum and universal t=1 remain open; choosing poles, roots and residues must be charged.',
 'ALG-CHIRP-ELIM':'Current recognition proof remains closed. Exact historical D06 bytes are recovered and byte-verified, superseding the old unrecovered note. Integrated production recognition and field/bit/runtime accounting still need implementation validation.',
 'ALG-OPEN-UNIFORM-SQUAREFREE':'General lower squarefreeness and augmented-content prime support remain unproved. Preserve only individually reviewed bounded Q29 results; broad arithmetic continuation belongs to the separately assigned Q29 work.'
}
ledger=[];mismatch_rows=[]
for sheetrow,r in enumerate(C[1:90],4):
 rid=r[0];nr,nd=novelty[rid];assert nd['Record kind']=='Canonical catalogue claim'
 taskids=json.loads(r[4]);tasks=[current[t] for t in taskids]
 src=[]
 for e in json.loads(r[13]):
  found=byhash[e['sha256']];assert found
  p=Path(found[0]['local_path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']
  src.append({**e,'availability':'exact bytes available and SHA-256 freshly matched','actual_bytes':p.stat().st_size,'matching_locations':found,'review_binding_note':'Artifact byte identity verified; presence or historical inspection wording alone does not prove exact theorem-to-review acceptance.'})
 bindings=[]
 for task in tasks:
  for reviewid in re.findall(r'R\d+',task.get('Review IDs','')):
   rv=reviews.get(reviewid)
   if not rv:
    bindings.append({'task_id':task['Task ID'],'review_id':reviewid,'state':'not in checked original packet; later review attribution inherited'});continue
   pin=rv.get('reviewed_artifact_sha256');pb=[]
   for pid in rv.get('proof_ids',[]):
    p=proofs.get(pid)
    if not p:continue
    f=packet/p['Proof-pack member'];actual=hashlib.sha256(f.read_bytes()).hexdigest()
    assert actual==p['SHA-256'];pb.append({'proof_id':pid,'member':p['Proof-pack member'],'actual_sha256':actual,'review_pin_matches':bool(pin and actual==pin)})
   bindings.append({'task_id':task['Task ID'],'review_id':reviewid,'recorded_verdict':rv['verdict'],'claim':rv['claim'],'scope':rv['scope_boundary'],'reviewed_artifact_sha256':pin,'proofs':pb,'state':'explicit reviewed-body SHA-256 binding freshly verified' if any(p['review_pin_matches'] for p in pb) else 'proof bytes checked; acceptance binding is inherited by IDs/scope, not an explicit reviewed-body hash','fresh_math_review':False})
 export=[]
 for line in nd.get('Proof and audit locators','').splitlines():
  m=re.search(r'(https://github.com/[^\s]+/objects/[a-f0-9]{2}/([a-f0-9]{64})[^\s]*)\s*\| export SHA256 ([a-f0-9]{64})',line)
  if m and m[2]!=m[3]:export.append({'repository_url':m[1],'hash_in_object_name':m[2],'recorded_export_sha256':m[3],'state':'two different identities explicitly recorded; live repository bytes not fetched in this pass; no automatic corruption or review-equivalence conclusion'})
 if export:mismatch_rows.append({'catalogue_id':rid,'novelty_row':nr,'variants':export})
 remain=[]
 if rid in special:remain.append(special[rid])
 for task in tasks:
  remain.append(task['Task ID']+': '+task['What would finish this?']+' Practical executor: '+task['Practical executor'])
 if not tasks and rid not in special:
  remain.append('Retain the historical scoped result without needless proof repetition. Before promotion, bind the exact theorem body and cited review; preserve these specific limits: '+r[11])
 remain.append('Novelty next check: '+nd['Next novelty check'])
 depth='Inventory and cross-register/source-hash reconciliation only; no full proof reread or new literature review for this row.'
 if rid=='M-SCAN-DIMENSION':depth='Full text of the short certificate read; analytical all-N dimension upper bound checked; fresh independent exact N8 T1/T2/T3 reconstruction and N8 T2 gauge-kernel check. N16/N32 and all-N saturation not reviewed.'
 ledger.append({'catalogue_row':sheetrow,'catalogue_id':rid,'title':r[2],'catalogue_url':f'https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit#gid=214001001&range=A{sheetrow}:V{sheetrow}','historical_record':dict(zip(C[0],r)),'matching_novelty_view':{'sheet_row':nr,'matching_rule':'exact canonical claim ID, not family equivalence','record':nd},'linked_queue_entries':tasks,'source_evidence':src,'independent_review_binding':{'historical_acceptance':'inherited; all cited historical bytes hash-verified, not all proof-to-review claim bindings independently inspected','current_related_scope_bindings':bindings,'fresh_bounded_check':'N8 scan Jacobian and gauge certificate reconstructed' if rid=='M-SCAN-DIMENSION' else None},'novelty_audit_depth':{'recorded':nd['Review depth this pass'],'current_pass':'No fresh external primary-source comparison; inventory reconciliation only. Recorded R1/R2/manuscript states remain attributed.'},'current_pass_review_depth':depth,'exact_remaining_tasks':remain,'repository_export_variant_notes':export})
assert len(ledger)==89 and len({x['catalogue_id'] for x in ledger})==89
stats={'canonical_total_in_input':len(C)-1,'canonical_rows_audited':89,'rows':[4,92],'first_id':ledger[0]['catalogue_id'],'last_id':ledger[-1]['catalogue_id'],'matching_canonical_novelty_views':89,'novelty_views_in_input':len(N)-1,'queue_entries_in_input':len(Q)-1,'distinct_linked_queue_entries':len({t for r in C[1:90] for t in json.loads(r[4])}),'historical_source_references_byte_matched':sum(len(x['source_evidence']) for x in ledger),'distinct_historical_source_hashes_byte_matched':len({s['sha256'] for x in ledger for s in x['source_evidence']}),'novelty_depth_R1_screen_only':sum(x['novelty_audit_depth']['recorded'].startswith('R1:') for x in ledger),'novelty_depth_more_than_R1_recorded':sum(not x['novelty_audit_depth']['recorded'].startswith('R1:') for x in ledger),'rows_with_related_exact_current_review_hash_binding':sum(any(b['state']=='explicit reviewed-body SHA-256 binding freshly verified' for b in x['independent_review_binding']['current_related_scope_bindings']) for x in ledger),'fresh_bounded_mathematical_replays':1,'full_89_proof_review_complete':False,'export_variant_rows':len(mismatch_rows),'export_variant_references':sum(len(x['variants']) for x in mismatch_rows)}
payload={'scope':'First half of178 canonical claims.89 row-by-row inventory/source/queue/novelty checks; one bounded mathematical replay. No global mathematical acceptance.','as_of':'2026-10-11T13:46:00Z','statistics':stats,'rows':ledger}
(R/'FIRST89_COVERAGE_LEDGER.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
(R/'evidence/REGISTER_EXPORT_VARIANTS.json').write_text(json.dumps(mismatch_rows,indent=2)+'\n')
(R/'SUMMARY.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats,indent=2))
