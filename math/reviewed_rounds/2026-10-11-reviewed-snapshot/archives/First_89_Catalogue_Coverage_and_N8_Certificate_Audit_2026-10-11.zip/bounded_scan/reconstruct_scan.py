"""New independent verifier. Reads JSON as data; no supplied code is imported or run."""
import json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
W=json.loads((ROOT/'WITNESS_N8_T3.json').read_text())
assert hashlib.sha256((ROOT/'WITNESS_N8_T3.json').read_bytes()).hexdigest()=='200a13db448ea479219862107d98ee819e7457e77ec5126415cda9f36837b775'
n=W['n']; perm=W['permutation']; groups=['d','L','V','U','W']
stages=[{k:[int(v[0] if isinstance(v,list) else v) for v in s[k]] for k in groups} for s in W['stages']]
def eye(n):return [[int(i==j) for j in range(n)] for i in range(n)]
def zero(n):return [[0]*n for _ in range(n)]
def mm(A,B,p):return [[sum(a*b for a,b in zip(row,col))%p for col in zip(*B)] for row in A]
def stage(s,p):return [[(s['L'][i]*s['V'][j] if i>j else s['U'][i]*s['W'][j] if i<j else s['d'][i])%p for j in range(n)] for i in range(n)]
P=[[int(i==perm[j]) for j in range(n)] for i in range(n)]
def derivative(s,g,k):
 D=zero(n)
 for i in range(n):
  for j in range(n):
   if g=='d' and i==j==k:D[i][j]=1
   if g=='L' and i==k and i>j:D[i][j]=s['V'][j]
   if g=='V' and j==k and i>j:D[i][j]=s['L'][i]
   if g=='U' and i==k and i<j:D[i][j]=s['W'][j]
   if g=='W' and j==k and i<j:D[i][j]=s['U'][i]
 return D
def jacobian(t,p):
 S=[stage(s,p) for s in stages[:t]];cols=[]
 for k in range(t):
  # Direct ordered factor replacement: S_(t-1) P ... S_0.
  for g in groups:
   for a in range(n):
    result=eye(n)
    for i in range(t):
     result=mm(derivative(stages[i],g,a) if i==k else S[i],result,p)
     if i<t-1:result=mm(P,result,p)
    cols.append([v for row in result for v in row])
 return [list(row) for row in zip(*cols)]
def eliminate(A,p):
 B=[[x%p for x in row] for row in A];m=len(B);r=0;det=1;piv=[]
 for j in range(len(B[0])):
  k=next((i for i in range(r,m) if B[i][j]),None)
  if k is None:continue
  if k!=r:B[r],B[k]=B[k],B[r];det=-det
  pivot=B[r][j];det=det*pivot%p;iv=pow(pivot,-1,p)
  B[r]=[x*iv%p for x in B[r]]
  for i in range(r+1,m):
   a=B[i][j]
   if a:B[i]=[(x-a*y)%p for x,y in zip(B[i],B[r])]
  piv.append(j);r+=1
  if r==m:break
 return r,det%p,piv
def gauge_columns(t,p):
 cols=[];size=t*5*n
 def index(s,g,i):return s*5*n+groups.index(g)*n+i
 for s in range(t):
  for g,i in [('L',0),('V',n-1),('U',n-1),('W',0)]:
   v=[0]*size;v[index(s,g,i)]=1;cols.append(v)
  for g,h in [('L','V'),('U','W')]:
   v=[0]*size
   for i in range(n):v[index(s,g,i)]=stages[s][g][i];v[index(s,h,i)]=-stages[s][h][i]
   cols.append(v)
 for s in range(t-1):
  for k in range(n):
   v=[0]*size
   for g in ['d','L','U']:v[index(s,g,k)]=stages[s][g][k]
   l=perm[k]
   for g in ['d','V','W']:v[index(s+1,g,l)]=-stages[s+1][g][l]
   cols.append(v)
 return [list(row) for row in zip(*cols)]
results=[]
for p in [12289,65537]:
 assert all(p%d for d in range(2,int(p**0.5)+1))
 for t in [1,2,3]:
  assert all(eliminate(stage(s,p),p)[0]==n for s in stages[:t])
  J=jacobian(t,p);rank,_,piv=eliminate(J,p);upper=min(n*n,n+t*(4*n-6))
  rec={'n':n,'t':t,'prime':p,'jacobian_shape':[len(J),len(J[0])],'rank':rank,'theoretical_upper':upper,'matches_upper':rank==upper,'stage_determinants':[eliminate(stage(s,p),p)[1] for s in stages[:t]],'point':'first t stages of archived N8 T3 integer witness; t1/t2 are new sub-witnesses'}
  assert rank==upper
  if t==3:
   c=W['certificates_by_field'][str(p)];minor=[[row[j] for j in c['full_rank_minor_column_indices']] for row in J];r,d,_=eliminate(minor,p);rec.update({'published_minor_determinant':c['full_rank_minor_det_mod_prime'],'reconstructed_minor_determinant':d,'minor_hash':hashlib.sha256(json.dumps(minor,separators=(',',':')).encode()).hexdigest()});assert r==64 and d==c['full_rank_minor_det_mod_prime']
  if t==2:
   G=gauge_columns(t,p);JG=mm(J,G,p);gr,_,_=eliminate(G,p);rec.update({'gauge_rank':gr,'jacobian_nullity':len(J[0])-rank,'jacobian_times_gauge_zero':not any(any(row) for row in JG)});assert gr==20==len(J[0])-rank and not any(any(row) for row in JG)
  results.append(rec)
mutations=[]
stages[0]['L'][1]+=1
for p in [12289,65537]:
 J=jacobian(3,p);c=W['certificates_by_field'][str(p)];minor=[[row[j] for j in c['full_rank_minor_column_indices']] for row in J];_,d,_=eliminate(minor,p)
 mutations.append({'prime':p,'mutation':'increase first-stage L[1] by one','determinant':d,'published_value_rejected':d!=c['full_rank_minor_det_mod_prime']});assert d!=c['full_rank_minor_det_mod_prime']
stages[0]['L'][1]-=1
out={'source_witness_sha256':hashlib.sha256((ROOT/'WITNESS_N8_T3.json').read_bytes()).hexdigest(),'method':'Independent direct polynomial differentiation and exact modular Gaussian elimination; supplied code neither run nor imported','results':results,'mutation_controls':mutations,'scope':'N8 T1,T2,T3 only. T3 reproduces archived minor; T1/T2 use first stages of T3 as new sub-witnesses. No N16/N32 replay, no full catalogue proof audit, no novel FFT claim.'}
(ROOT/'RECONSTRUCTION_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
