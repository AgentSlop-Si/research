# Constructive extension: a polynomial-cost phase eliminant

## Result and scope

The factorial permutation expansion in Hero #17 is unnecessary. A centered Toeplitz normalization provides two explicit, deterministic replacements, valid over every field admitted by the original theorem:

1. Exact polynomial Bareiss: O(r^3 (D+1)^2) field operations, at most r−1 scalar inversions, and O(r^2(D+1)) coefficient storage, with schoolbook multiplication and division.
2. A stronger Toeplitz recursion: O(r^2 (D+1)^log₂3) field operations, one scalar inversion, and O(r(D+1)) coefficient storage, using independently implemented Karatsuba multiplication and Newton series inversion. Schoolbook series arithmetic instead gives O(r^2(D+1)^2).

Here D = binom(r+2,3), so these are O(r^9), O(r^6.754888…), and O(r^8), respectively. All setup, coefficient writes, divisions, and polynomial degrees are included. These are conservative arithmetic bounds, not measured speed claims. The original one-window eliminant and raw-input recognition theorem are being extended, not replaced by an unrestricted Fourier algorithm. No literature-wide novelty claim is made.

This folder contains independently written code and tests. No uploaded code was executed or imported.

## 1. Normalize before taking the determinant

Let c=s+r, x_c≠0, n=r+1, and ε=(−1)^(r(r+1)/2). Define

A(t)[i,j] = x_(c+i−j) t^f(i−j),  0≤i,j≤r,

where f(d)=d(d−1)/2 for every integer d, including negative d. This is a polynomial Toeplitz matrix because f(d)≥0 for every integer d.

Reverse the columns of the original H_s. Since

binom(r+i−j,2) = binom(r,2) + r(i−j) + f(i−j),

the reversed H_s equals diag(t^(binom(r,2)+ri)) A diag(t^(−rj)) in the Laurent-polynomial ring. The total exponent of these row and column factors is

E = n binom(r,2) = (r+1)r(r−1)/2.

Consequently det A = ε t^(−E) det H_s = ε P_s, and therefore P_s=ε det A.

Only f(0) and f(1) vanish. Thus A(0) is lower bidiagonal, with diagonal x_c and subdiagonal x_(c+1). In particular every k×k leading principal minor has constant coefficient x_c^k≠0. This prevents every potential pivot breakdown used below.

The sign and constant coefficient agree with the original certificate:

P_s(0)=ε x_c^(r+1).

The degree is at most D; it need not equal D if the extreme coefficient vanishes.

## 2. Uniform degree bounds, including all Bareiss intermediates

A full determinant monomial has exponent

Σ_i f(i−σ(i)) = Σ_i i² − Σ_i i σ(i).

Rearrangement makes the maximum occur at reversal σ(i)=r−i, giving

2Σ_i i² − rΣ_i i = r(r+1)(r+2)/6 = D.

Every monomial in every square minor corresponds to a partial matching of rows and columns. Complete that matching arbitrarily to a full permutation. The added exponents are nonnegative, so the partial exponent is at most the full exponent, hence at most D. Therefore every minor of A has degree at most D. This bound does not depend on characteristic or on nonvanishing of its leading coefficient.

## 3. Exact polynomial Bareiss

Start B=A and d=1. For k=0,…,n−2, let h=B[k,k], then update every i,j>k by

B[i,j] ← (h B[i,j] − B[i,k] B[k,j]) / d,

clear B[i,k] for i>k, and replace d by h. Each update uses the old row k and column k. The final bottom-right entry is det A.

The Sylvester determinant identity identifies each stored trailing entry with the original minor formed by the previously selected leading rows/columns plus its own row/column. It also proves that every displayed division is exact. The pivot h is the next leading principal minor; its nonzero constant term proves h is never zero. Thus no permutation, search for pivots, rational-function expansion, or generic-position assumption is hidden.

There are Σ_(m=1)^r m² = r(r+1)(2r+1)/6 updates. Stored entries have degree at most D; each pre-division numerator and each multiplication result has degree at most 2D. Schoolbook multiplication and long division therefore use O((D+1)^2) field operations per update. Cache the inverse of the previous divisor's leading scalar coefficient once per stage. The first divisor is one, giving at most r−1 scalar inversions in total. The implementation checks every remainder is zero.

This proves the first bound, including degenerate windows, cancellation, and primes p<D. It does not rely on interpolation at D+1 field elements.

Reference for the classical determinant identity and method: [Erwin H. Bareiss, 1968, Sylvester's Identity and Multistep Integer-Preserving Gaussian Elimination](https://www.ams.org/mcom/1968-22-103/S0025-5718-1968-0226829-0/S0025-5718-1968-0226829-0.pdf). The special normalization and degree accounting above are derived here.

## 4. Stronger bound from the Toeplitz structure

All calculations in this section take place in R=F_p[t]/(t^(D+1)). This truncation is exact for the final determinant, whose polynomial degree is at most D. Write a_d=x_(c+d)t^f(d), and T_k=[a_(i−j)]_(i,j=1)^k, with det T_0=1.

Define predictor vectors u^(k),v^(k), indexed 0,…,k, with u_0=v_0=1 and

Σ_(j=0)^k a_(i−j)u_j=0,   Σ_(j=0)^k a_(j−i)v_j=0,   1≤i≤k.

These vectors exist uniquely because T_k and its transpose are invertible over R: det T_k has nonzero constant coefficient x_c^k. Define

e_k=Σ_(j=0)^k a_(−j)u_j = Σ_(j=0)^k a_j v_j = det T_(k+1)/det T_k.

Both equalities follow by taking the Schur complement of T_k in T_(k+1), and by transposing. In particular e_k(0)=x_c for every k.

Initialize u=v=(1), e=a_0, and det=a_0. At step k=1,…,r, using the previous length-k vectors, form

A_k=a_k+Σ_(j=1)^(k−1) a_(k−j)u_j,
B_k=a_(−k)+Σ_(j=1)^(k−1) a_(j−k)v_j,
α_k=−A_k/e,  β_k=−B_k/e.

For 1≤j≤k−1, simultaneously update

u'_j=u_j+α_k v_(k−j),   v'_j=v_j+β_k u_(k−j),

and set u'_0=v'_0=1, u'_k=α_k, v'_k=β_k. Finally set

e' = e+α_k B_k = e−A_k B_k/e,
det' = det e'.

To check the recurrence directly, the reversed v-vector contributes zero to the first k−1 equations for u by the previous equations for v, and contributes e to the last equation. The choice α_k cancels exactly A_k. The same argument proves the update for v. Expanding the definition of e' gives e+α_k B_k. Thus these formulas preserve the displayed invariants over R without ordering, positivity, or conjugation assumptions. After the last step, det=det T_(r+1)=det A. Multiply by ε to obtain P_s.

Every reciprocal in this recurrence is legitimate because e(0)=x_c≠0. To compute e^−1 modulo t^(D+1), begin with g=x_c^−1 and repeatedly double the precision using

g ← g(2−eg).

If eg=1 mod t^m, the new error is −(1−eg)^2, so the precision doubles. The formula works in characteristic two as well: no division by 2 or by any integer k occurs. The single scalar x_c^−1 is reused for every reciprocal.

There are O(r²) truncated ring additions/multiplications and r reciprocal computations. Karatsuba polynomial multiplication obeys M(m)=3M(ceil(m/2))+O(m)=O(m^log₂3), using only field additions and multiplications. Newton reciprocals cost Σ_j M(2^j)=O(M(D+1)). Hence total arithmetic is O(r² M(D+1)), and live coefficient storage is O(r(D+1)). All initial diagonals and the output fit in that storage bound.

This is a standard nonsymmetric Levinson-type recursion applied after a problem-specific normalization. A classical reference for the nonsingular-leading-minor requirement and O(n²) scalar Toeplitz algorithms is [Freund and Zha, 1993, Formally biorthogonal polynomials and a look-ahead Levinson algorithm for general Toeplitz systems](https://www.sciencedirect.com/science/article/pii/002437959390471Y). The proof above makes the ring and degree requirements explicit, rather than importing floating-point stability claims.

## 5. Optional geometric candidate scan

Let g=gcd(2,N), L=N/g, and q=omega^(−2), which has exact order L. The canonical phase scan needs P_s(q^a), 0≤a<L.

First reduce P_s modulo t^L−1 by adding each coefficient into its degree modulo L. This costs O(D+L), not an uncharged symbolic operation. Let the result have m≤L coefficients f_j.

The integer identity

aj = binom(a,2)+binom(j+1,2)−binom(a−j,2)

gives

F(q^a)=q^binom(a,2) Σ_(j=0)^(m−1) [f_j q^binom(j+1,2)] q^(−binom(a−j,2)).

The sum is one coefficient of an ordinary linear convolution of arrays of lengths m and L+m−1. Build the supplied-root power table in O(L), including the negative exponents through residue indices. Karatsuba evaluates this convolution in O(L^log₂3), with no square root of q, no field extension, no factorization, and no smooth-length assumption. This is a standard chirp-convolution reduction, not a new fast Fourier claim.

Choose between this scan and Horner evaluation, preserving the fixed-r linear bound:

S(N,r)=O(min{L(D+1), D+L^log₂3}).

The implementation returns all values so that a=0,…,L−1 can be tested directly. The nonzero polynomial still has at most C=min(D,L) candidate phases. The geometric scan improves only the scan subroutine; it does not eliminate verification of those candidates.

## 6. Fully charged recognition ledger after this replacement

Keeping the original bounded BM, admissible-root scan, generic Vandermonde solve, and exhaustive verification, the total conservative bound becomes

O(T(r)+S(N,r)+C(Nr+r³)+N),

where C=min(D,L), and T(r) is either construction bound above. The additional all-output Gauss evaluator costs O(rN+N); this is covered by the same displayed upper bound because C≥1 as an upper-bound parameter. Initial input scans and construction of the length-N root table are charged.

The all-zero vector must be handled separately as rank-zero success. If a nonzero vector has no interior nonzero center, reject before forming the eliminant, by the original no-r-consecutive-zeros argument. Construction of A requires only the witness window; the improvements here neither weaken nor replace full-input verification.

Memory with the faster Toeplitz route is O(N+r(D+1)); with Bareiss it is O(N+r²(D+1)). These are O_r(N) for fixed r. They are not O(N) uniformly in growing r.

For fixed r the complete method is still O_r(N), with a polynomial rather than factorial r-dependent construction. For r growing with N, candidate verification and the construction bounds remain expensive. There is no general O(N) exact DFT, no sub-N-log-N full-rank theorem, and no optimized FFT/NTT benchmark in this extension.

The arithmetic model treats field additions/multiplications as unit-cost and accounts separately for scalar inversion. With p=N^O(1), ordinary modular inversion contributes O(log N) word operations per scalar inversion; Python arbitrary-precision timings do not establish fixed-word deployment performance.

## 7. Reproduction and verification

Run, from this folder:

python test_eliminant_extension.py

The script creates test_results.json. It compares independent implementations rather than importing the uploaded prototype:

- Original raw-Hankel permutation expansion versus polynomial Bareiss, including small characteristics 2 and 3 as extra algebraic tests.
- Scalar Gaussian determinants at field points versus t^E P(t).
- Genuine structured signals at every quadratic parameter for several odd/even lengths, including admissible primes smaller than D.
- Geometric-convolution values versus direct Horner evaluation.
- Karatsuba products versus schoolbook products.
- Sparse and cancellation-heavy witness windows, and growing-r degree/inversion ledgers.
- Truncated Toeplitz recursion versus exact polynomial Bareiss, including rank 16.

The JSON records test totals and arithmetic-kernel counters. These counters exclude Python allocation, indexing, comparisons, and modular-reduction bit costs; the separately proved arithmetic and storage bounds include coefficient processing. Finite tests support the implementation; correctness and the complexity claims rest on the proofs above.
