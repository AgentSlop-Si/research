# Independent packed Fourier backend review

Verdict: ACCEPT the dense and chirp-packed mathematical backends after the two literal repairs (H>=2, H=1 exact copy; full product fits at most v/4 bits). Finite precision, exact byte-addressed word model, coefficient preparation, scalar bit-length table, full twiddle-circle work and interpolation costs remain part of the theorem. No supplied research program was run.

The dense real packing uses B>4rQ² at every digit. Every convolution digit has at most r nonnegative terms, so no carry anywhere can contaminate selected dot-product digits. At exponent (i+1)r-1, (i'-i)r+j-l=0 and |j-l|<r force i'=i,j=l. The signed correction subtracts Q times the original signed matrix row sum, Q times the original signed input sum, and rQ². The entire integer product uses at most (r²+r-1)D bits, and this rather than just the input key width must fit the word. Four real products give exact complex multiplication. Gathering, packing, correction, output and quantization cost O(r).

The chirp backend uses local Bluestein directly, with no approximate global chirp-spectrum call. Prechirped integer data have components <=2Q², biased products have digits below 8rQ³, and (3r-2)D_chirp bounds the whole product. At every requested middle coefficient the complete r-term convolution is present. Signed kernel sliding sums and the original signed input sum give the stated exact bias correction. The final postchirp and scalar multiply have exact denominator Q^5, so restoring R/Q^5 is correct.

Boundary-safe rational enclosures avoid pretending exact transcendental rounding decisions are free. The approximate matrix-entry error is below16/Q, hence its operator error <=16r/Q<=u/4096. The locally normalized input error plus coefficient error remains belowu/1000; the global quantizer then satisfies the inherited3u relative plus underflow stage bound. Separate local normalization is nonlinear but the all-input local error proof composes correctly.

The leading-bit helper is an explicitly populated scalar chunk table with O(H^1/4) cold cost, not a vector-response table. Assuming CLZ permits removing it only if CLZ is part of the stated machine. Packed products occupy a bounded number of words; arbitrary precision is never a unit-cost scalar.

The dense radix is Theta(sqrt(v/(p+log v))); the chirp radix is Theta(v/(p+log v)). These preserve the previous asymptotic Fourier upper bound while removing the exponential vector-response table. They do not remove the all-length interpolation coefficient table or improve the polynomial-accuracy boundary. The closely matching Bluestein/Kronecker/short-transform ingredients are classical; no priority, Turing bit-complexity, hardware or verified production claim is accepted.

The author's fresh exact controls are corroboration and were read as results, not rerun by this reviewer. Complete bounded-word execution and certified coefficient generation still require implementation validation.
