# Q31 exact conditional review

Source: research_finalization_0923/intake/extracted/fft_coherent_sparse_jet_lifting_2026-10-10/fft_sparse_jet_lifting/THEORY.md.

Independent verdict: ACCEPT the mathematical conditional reduction and its supporting representation gates; PENDING the constructive task of supplying a new fast regular source. No supplied source program was run or audited as executable code.

In a field of characteristic not two with the required primitive root, an origin-regular scalar arithmetic straight-line program has a formal quadratic Taylor jet. Its diagonal and mixed quadratic coefficients are completely determined by formal restrictions to every one- and two-coordinate plane. The stated Fourier sparse-jet identity therefore gives Hessian Phi(0)=F. Forward tangent propagation followed by directional differentiation of reverse adjoints evaluates this Hessian-vector product with a bounded number of field operations per original add/multiply/inverse gate, plus N output writes. All base inverse values must be nonzero. The inverse derivative constants -a^-2 and 2a^-3 are prepared and charged. Work and storage O(s+N) are valid; O(N) space does not follow from s=O(N log log N).

Conversely an origin-regular exact Fourier straight-line program gives the scalar potential x^T F x/2 with O(N) further work. This is a same-model circuit equivalence. It does not extend by fiat to quantization, input-dependent support dispatch, arbitrary lookups, singular-at-origin decoders, or a wider machine model.

The fixed linear transcript Hessian rank bound, Fourier-minus-diagonal Vandermonde block bound, and separable-product rank bounds including zero-anchor cases all check. Finite-field equality on every field-valued input is insufficient: (x0^p-x0)x1 has a nonzero formal quadratic coefficient despite vanishing pointwise. Thus source finite test claims cannot replace the formal identity.

The source's implementation counts and saved controls remain attributed, not freshly replayed here. The conditional differentiation mechanism is classical. No uniformly prepared new origin-regular o(N log N) Fourier-jet source is supplied, so Q31's constructive objective remains open.
