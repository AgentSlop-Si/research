FIRST-HALF CATALOGUE COVERAGE AUDIT
11 October 2026

Coverage
The ledger covers every one of Catalogue rows 4 through 92: 89 distinct canonical IDs, F020 through M-PARTIAL-COLUMNS. Their IDs were also checked against a live, bounded Sheet read after retrieving Sheet metadata. The inputs contain 178 canonical claims, 216 novelty-register views and 46 queue entries; this report does not claim to have mathematically reviewed all of them.

Each ledger row records the historical proof status, exact historical source bytes and SHA-256, the matching canonical novelty view, current related queue entries, explicit versus inherited review binding, recorded novelty-audit depth, and remaining tasks. Family membership and a shared Q number are not theorem equivalence.

Results
- All 155 cited historical source references for these 89 rows resolve to freshly hash-matched bytes, representing 124 distinct SHA-256 values.
- Exactly 89 canonical novelty-register views match these 89 IDs. 79 retain R1 screening-only novelty depth; 10 have deeper comparison/manuscript-review descriptions, which remain attributed to their recorded earlier audits.
- Nineteen distinct live queue tasks are linked. Twenty catalogue rows have at least one related current review with an explicit reviewed-body SHA-256 matching the checked proof-pack bytes. That verifies artifact binding, not a new proof reread or blanket equivalence of the historical claim and current overlay.
- The original 0958 proof packet's manifest was independently checked: all 52 listed members match both size and SHA-256.
- Thirty-four rows contain 35 repository links whose filename/object hash differs from the separately recorded export hash. These are explicitly different identities in the register. This pass did not fetch those repository variants and does not classify them as corruption or assume byte equivalence. The historical originals named by the catalogue are available and verified. Preserve both identities.

Fresh bounded mathematical result
M-SCAN-DIMENSION had a real outstanding finite-certificate replay gap. A new verifier, written solely from the displayed mathematical parameterization, reconstructed the N=8 separated-generator stage Jacobians. Supplied programs were neither executed nor imported.

At depths 1, 2 and 3, the ranks are 34, 60 and 64 over each of the primes 12289 and 65537. The saved depth-3 64-by-64 minor determinants reproduce exactly: 5222 and 41948. All three integer stages are invertible in both fields. At the new depth-2 sub-witness formed from the first two archived depth-3 stages, the 20 explicit local/interstage gauge directions have rank 20 and are annihilated by the Jacobian; they therefore span its kernel. A one-unit mutation of one active generator is rejected by the published determinant comparison in both fields.

The short upper-bound argument was also checked. The lower and upper triangular rank-one parameter charts each have dimension 2N-3, giving stage dimension 5N-6. On the dense invertible locus, the (t-1) independent diagonal interstage tori act freely while preserving the product. Subtracting their dimension gives N+t(4N-6), capped by N^2. The exact modular minors certify nonzero integer minors and hence the corresponding complex Jacobian lower bounds. Thus the N=8 dimension equalities at depths 1,2,3 are independently supported. The depth-2 point here is explicitly different from any unspecified saved depth-2 recipe; no claim is made to reproduce that historical point.

The algebraic gauge directions are exact polynomial identities: inactive coordinates do not occur; each lower/upper pair scaling leaves its outer product unchanged; paired interstage left-row and permutation-matched right-column scalings cancel. Their nonzero modular rank certifies independence over the rationals/complex numbers. The checked dimension bound and rank-60 minor then force the complex kernel dimension to be 20 as well.

Scope limits
This is one finite certificate replay and an analytical check of its upper bound. N=16 and N=32 witnesses and their tangent certificates were not replayed. Saturation for all N remains conjectural. Generic-matrix dimension does not exclude a specific Fourier matrix. No faster Fourier algorithm, new original theorem or historical priority clearance is claimed.

Recommended next work outside Q27-Q32 and the separately owned leading families
1. M-SCAN-DIMENSION: complete independent N=16/N=32 witness and gauge replay before upgrading the whole finite package. The N=8 part is now closed at the precise scope above. Keep the all-N saturation conjecture separate.
2. M-GLOBAL-STAGES: reconcile four different stage constructions and bind each order-robust rank/probability/singular-value theorem to its actual independent audit. Q06 compiler acceptance does not blanket-certify the unrelated construction claims. Choose one concrete construction with explicit quantitative statements first.
3. M-HARPER: obtain an audit directly covering the upstream parity-resolved Harper polynomial-degree and zero-mode theorem. The cited phase-pencil audit is downstream and does not by itself settle all upstream finite-certificate assertions.
4. M-SPARSE-PREFIX: recover and bind the earlier separate scoped audit rather than needlessly reproving a theorem that may already be accepted. Preserve full-spark and sparse-preconditioner hypotheses.
5. Q18 implementation: the corrected theorem is closed; the remaining actionable issue is implementation sign/convention coherence and its own certification. No supplied implementation was run here.

Do not reopen these stale historical gaps
Q17's arbitrary-pencil extension is accepted at P02/R15; Q20's h+1 even-bank extension at P02/R16; and Q21's repaired permutation-displacement theorem at P07/R32. Their explicit current body-hash bindings check. Historical source descriptions that said no independent audit was located are not current blockers for those accepted scopes. Likewise the original D06 chirp audit bytes are available with the historical hash; earlier unrecovered-byte wording is superseded. Current source-implementation and novelty limits remain separate.

Files
FIRST89_COVERAGE_LEDGER.json is the complete row-by-row deliverable.
SUMMARY.json is a compact count summary.
bounded_scan/ contains the source integer witness, saved rank report, newly authored verifier and fresh results.
source_bytes/ contains all 124 distinct historical source objects cited by the first-half ledger, identified by their actual SHA-256.
current_packet/ supplies the small original proof/review packet used for exact binding checks.
inputs/ preserves the three checkpoint table snapshots.
evidence/ preserves live ID/metadata reads, source-byte provenance and export-variant distinctions.
MANIFEST.json lists every packaged member's exact byte count and SHA-256.

No Google Sheet or GitHub file was written by this auditor.
