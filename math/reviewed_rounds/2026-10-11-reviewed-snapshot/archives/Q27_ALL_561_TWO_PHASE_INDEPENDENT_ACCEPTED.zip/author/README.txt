Q27 all 561 pinned two-coordinate slices: finite characteristic-zero exclusion.
Read REPORT.txt for the proof, scope, polynomial templates, and saturation.
COVERAGE.json gives all pair IDs and primary coefficient minors.
EXACT_SUPPORT.json verifies exact forbidden coefficients and admissible rings.
REDUCTIONS.json gives the fixed minors in three split primes, both embeddings.
Run the three fresh Python programs listed in REPORT.txt using standard Python.
Only CHART.json and documented predecessor files were read as input data.
The full 34-phase Fourier fiber remains open. No Sheet/GitHub changes.
