"""Fresh exhaustive two-coordinate slice reconstruction, from JSON data only."""
import json, itertools, hashlib, time, sys
from pathlib import Path
from math import isqrt
R=Path(__file__).resolve().parent
CHART=json.loads((R/'CHART.json').read_text())
N=8
P=1000000009
II=569522298
COORDS=[(s,e) for s in range(2) for e in range(7,24)]
MONS=list(itertools.product(range(4),repeat=2))
ZERO={}
def p_add(a,b):
 d=a.copy()
 for k,v in b.items():d[k]=(d.get(k,0)+v)%P
 return {k:v for k,v in d.items() if v}
def p_scale(a,v):return {k:q*v%P for k,q in a.items() if q*v%P}
def p_mul(a,b):
 d={}
 for (i,j),u in a.items():
  for (k,l),v in b.items():d[i+k,j+l]=(d.get((i+k,j+l),0)+u*v)%P
 return {k:v for k,v in d.items() if v}
def p_div(a,h,axes):
 # Divide by 1-h*x^axes[0]*y^axes[1], using a terminating top-degree recurrence.
 rem=a.copy();out={};hi=pow(h,-1,P)
 while rem:
  k=max(rem,key=lambda m:(sum(m),m))
  if any(k[j]<axes[j] for j in range(2)):break
  v=-rem[k]*hi%P;kk=tuple(k[j]-axes[j] for j in range(2))
  out[kk]=v
  rem=p_add(rem,p_scale(p_mul({kk:v},{(0,0):1,axes:-h%P}),-1))
 assert not rem,('nonexact pole division',axes,len(rem))
 assert p_mul(out,{(0,0):1,axes:-h%P})==a
 return out
def mzero():return [[{} for _ in range(8)]for _ in range(8)]
def madd(A,B):return [[p_add(a,b) for a,b in zip(ar,br)] for ar,br in zip(A,B)]
def mpscale(A,d):return [[p_mul(a,d)for a in row]for row in A]
def mmul(A,B):
 C=mzero()
 for r in range(8):
  for c in range(8):
   for k in range(8):C[r][c]=p_add(C[r][c],p_mul(A[r][k],B[k][c]))
 return C
def reconstruct(pair,ii):
 stages=[];guards=[];frozen_guards=[]
 for si,stage in enumerate(CHART['stages']):
  gains=[1]*7+[((a+ii*b)*pow((a-ii*b)%P,-1,P))%P for a,b in stage['gaussian_pairs']]
  branches=[]
  for bi,cycle in enumerate(stage['cycles']):
   h=1;ax=[0,0]
   for j in range(8):h=h*gains[8*bi+j]%P
   for vi,coord in enumerate(pair):
    if coord[0]==si and coord[1]//8==bi:ax[vi]=1
   B=mzero()
   for start in range(8):
    v=cycle[start];coef=1;ex=[0,0]
    for length in range(8):
     B[cycle[(start+length)%8]][v]={(ex[0],ex[1]):coef}
     j=(start+length+1)%8;coef=coef*gains[8*bi+j]%P
     for vi,coord in enumerate(pair):
      if coord==(si,8*bi+j):ex[vi]+=1
   if sum(ax):
    d={(0,0):1,tuple(ax):-h%P};guards.append((h,tuple(ax),si,bi))
   else:
    assert h!=1;d={(0,0):(1-h)%P};frozen_guards.append((si,bi,(1-h)%P))
   branches.append((B,d))
  stage_num=mzero();stage_den={(0,0):1}
  for _,d in branches:stage_den=p_mul(stage_den,d)
  for k,(B,d) in enumerate(branches):
   extra={(0,0):1}
   for l,(_,q)in enumerate(branches):
    if l!=k:extra=p_mul(extra,q)
   stage_num=madd(stage_num,mpscale(B,extra))
  # retain constant fixed denominators in D; avoids all inverse denominators besides phases
  stages.append((stage_num,stage_den))
 numerator=mmul(stages[1][0],stages[0][0]);den=p_mul(stages[0][1],stages[1][1])
 return numerator,den,guards,frozen_guards

def rank_det(rows):
 A=[row[:] for row in rows];n=len(A[0]);selected=[];pivots=[];d=1;sgn=1;r=0
 for c in range(n):
  k=next((k for k in range(r,len(A)) if A[k][c]),None)
  if k is None:continue
  if k!=r:A[r],A[k]=A[k],A[r];sgn=-sgn
  # Keep row provenance separate. RREF is for rank; determinant recomputed selected originals.
  v=A[r][c];pivots.append(c);iv=pow(v,-1,P)
  for k in range(r+1,len(A)):
   a=A[k][c]*iv%P
   if a:
    for j in range(c,n):A[k][j]=(A[k][j]-a*A[r][j])%P
  r+=1
  if r==len(A):break
 return r,pivots

def independent_rows(rows):
 basis=[];selected=[];piv=[]
 for ix,row in enumerate(rows):
  a=row[:]
  for b,col in zip(basis,piv):
   v=a[col]
   if v:a=[(x-v*y)%P for x,y in zip(a,b)]
  c=next((j for j,v in enumerate(a)if v),None)
  if c is not None:
   inv=pow(a[c],-1,P);a=[v*inv%P for v in a]
   basis.append(a);selected.append(ix);piv.append(c)
 return selected,piv

def det(A):
 A=[r[:]for r in A];d=1
 for c in range(len(A)):
  k=next((k for k in range(c,len(A))if A[k][c]),None)
  if k is None:return 0
  if k!=c:A[c],A[k]=A[k],A[c];d=-d
  v=A[c][c];d=d*v%P;inv=pow(v,-1,P)
  for k in range(c+1,len(A)):
   v=A[k][c]*inv%P
   for j in range(c,len(A)):A[k][j]=(A[k][j]-v*A[c][j])%P
 return d%P

def run_pair(pair,full=False):
 A,D,guards,frozen=reconstruct(pair,II)
 B,Db,gb,fb=reconstruct(pair,-II)
 Ps=[];Qs=[]
 for r,c in itertools.product(range(1,8),repeat=2):
  f=p_mul(A[r][c],A[0][0]);g=p_mul(A[r][0],A[0][c])
  fc=p_mul(B[r][c],B[0][0]);gc=p_mul(B[r][0],B[0][c])
  fs={(2-i,2-j):v for(i,j),v in fc.items()};gs={(2-i,2-j):v for(i,j),v in gc.items()}
  q=p_add(p_mul(f,fs),p_scale(p_mul(g,gs),-1));Ps.append(q)
  for h,axes,_,_ in guards:q=p_div(q,h,axes)
  Qs.append(q)
 support=sorted(set().union(*(q.keys()for q in Qs)))
 rows=[[q.get(m,0) for m in support]for q in Qs]
 selected,piv=independent_rows(rows)
 sub=[[rows[i][j]for j in piv]for i in selected]
 dd=det(sub);assert dd
 out={'pair':pair,'pair_id':'__'.join(f's{s+1}e{e:02d}'for s,e in pair),'class':('same_Green'if pair[0][0]==pair[1][0] and pair[0][1]//8==pair[1][1]//8 else 'same_stage'if pair[0][0]==pair[1][0] else 'different_stage'),'support':support,'rank':len(selected),'ncols':len(support),'selected_windows':[[i//7+1,i%7+1]for i in selected],'pivot_monomials':[support[j]for j in piv],'minor_determinant':dd,'guards':guards,'fixed_guards':frozen}
 if full:out.update(quotient_rows=rows,minor=sub)
 return out

def main():
 global P,II
 if len(sys.argv)>1 and sys.argv[1]=='pilot':
  pairs=[((0,7),(1,7)),((0,8),(0,9)),((0,7),(0,8)),((0,8),(1,8)),((0,15),(0,16)),((1,19),(1,23))]
 else:pairs=list(itertools.combinations(COORDS,2))
 start=time.monotonic();out=[]
 for k,pair in enumerate(pairs):
  ans=run_pair(pair,True);out.append(ans)
  print(k+1,ans['pair_id'],ans['class'],ans['rank'],ans['ncols'],ans['minor_determinant'],round(time.monotonic()-start,2),flush=True)
  (R/'PILOT.json'if len(pairs)<10 else R/'COVERAGE.json').write_text(json.dumps({'p':P,'i':II,'chart_sha256':hashlib.sha256((R/'CHART.json').read_bytes()).hexdigest(),'pairs':out},indent=2)+'\n')
if __name__=='__main__':main()
