"""Fresh exact Gaussian rational support and coefficient-ring audit."""
import json,itertools,hashlib,time
from fractions import Fraction as F
from pathlib import Path
R=Path(__file__).resolve().parent
class G:
 __slots__=('a','b')
 def __init__(self,a=0,b=0):self.a=F(a);self.b=F(b)
 def __add__(self,z):
  if not isinstance(z,G):z=G(z)
  return G(self.a+z.a,self.b+z.b)
 __radd__=__add__
 def __neg__(self):return G(-self.a,-self.b)
 def __sub__(self,z):return self+-z
 def __mul__(self,z):
  if not isinstance(z,G):z=G(z)
  return G(self.a*z.a-self.b*z.b,self.a*z.b+self.b*z.a)
 __rmul__=__mul__
 def __truediv__(self,z):
  if not isinstance(z,G):z=G(z)
  return self*z.bar()*(1/(z.a*z.a+z.b*z.b))
 def __bool__(self):return bool(self.a or self.b)
 def __eq__(self,z):return self.a==z.a and self.b==z.b
 def bar(self):return G(self.a,-self.b)
 def data(self):return [str(self.a),str(self.b)]
O=G(1);Z=G()
def mat():return [[Z for j in range(8)]for i in range(8)]
def add(A,B):return [[a+b for a,b in zip(x,y)]for x,y in zip(A,B)]
def scale(A,v):return [[a*v for a in x]for x in A]
def mul(A,B):return [[sum((A[r][k]*B[k][c]for k in range(8)if A[r][k] and B[k][c]),Z)for c in range(8)]for r in range(8)]
def dagger(A):return [[A[c][r].bar()for c in range(8)]for r in range(8)]
C=json.loads((R/'CHART.json').read_text());start=time.monotonic()
BRANCHES=[];STAGES=[];GAINS=[]
for si,s in enumerate(C['stages']):
 gains=[O]*7+[G(a*a-b*b,2*a*b)*(F(1,a*a+b*b))for a,b in s['gaussian_pairs']]
 assert all(g*g.bar()==O for g in gains);GAINS+=gains
 bs=[]
 for bi,cy in enumerate(s['cycles']):
  h=O
  for w in gains[8*bi:8*bi+8]:h=h*w
  assert h and h!=O
  paths=[];B=mat()
  for j in range(8):
   weight=O;edges=[]
   for length in range(8):
    r,c=cy[(j+length)%8],cy[j]
    B[r][c]=weight;paths.append((r,c,weight,edges[:]))
    k=(j+length+1)%8;weight=weight*gains[8*bi+k];edges.append(8*bi+k)
  bs.append({'h':h,'d':O-h,'B':B,'paths':paths})
 stage=mat()
 for bi,b in enumerate(bs):
  factor=O
  for bj,q in enumerate(bs):
   if bj!=bi:factor=factor*q['d']
  stage=add(stage,scale(b['B'],factor))
 BRANCHES.append(bs);STAGES.append(stage)
log=[]
for si in range(2):
 for bi in [1,2]:
  b=BRANCHES[si][bi];others=[q for j,q in enumerate(BRANCHES[si])if j!=bi]
  factor=others[0]['d']*others[1]['d']
  T=add(scale(others[0]['B'],others[1]['d']),scale(others[1]['B'],others[0]['d']))
  for e,f in itertools.combinations(range(8*bi,8*bi+8),2):
   mats={(i,j):mat()for i,j in itertools.product(range(2),repeat=2)}
   for r,c,w,edges in b['paths']:mats[int(e in edges),int(f in edges)][r][c]=w
   mats={k:scale(A,factor)for k,A in mats.items()}
   mats[0,0]=add(mats[0,0],T);mats[1,1]=add(mats[1,1],scale(T,-b['h']))
   if si==0:mats={k:mul(STAGES[1],A)for k,A in mats.items()}
   else:mats={k:mul(A,STAGES[0])for k,A in mats.items()}
   def fcoeff(r,c,rr,cc,i,j):
    return sum((mats[a][r][c]*mats[d][rr][cc]for a in mats for d in mats if (a[0]+d[0],a[1]+d[1])==(i,j)),Z)
   # P03 = f01 conjugate(f20)+f02 conjugate(f21), and similarly P30.
   checks=0
   for r,c in itertools.product(range(1,8),repeat=2):
    fp={(i,j):fcoeff(r,c,0,0,i,j)for i,j in [(0,1),(2,0),(0,2),(2,1),(1,0),(1,2)]}
    gp={(i,j):fcoeff(r,0,0,c,i,j)for i,j in fp}
    for k in [(0,3),(3,0)]:
     if k==(0,3):a,d,aa,dd=(0,1),(2,0),(0,2),(2,1)
     else:a,d,aa,dd=(1,0),(0,2),(2,0),(1,2)
     q=fp[a]*fp[d].bar()+fp[aa]*fp[dd].bar()-gp[a]*gp[d].bar()-gp[aa]*gp[dd].bar()
     assert not q,(si,e,f,r,c,k,q.data());checks+=1
   pid=f's{si+1}e{e:02d}__s{si+1}e{f:02d}';log.append({'pair_id':pid,'exact_zero_coefficients':[[0,3],[3,0]],'windows_checked':49,'coefficient_checks':checks})
   print(len(log),pid,'98 exact support zero checks',round(time.monotonic()-start,2),flush=True)
# Inventory exact rational coefficient ring and all guard reductions in both embeddings.
primes=[(1000000009,569522298),(998244353,911660635),(2013265921,1728404513)]
def red(z,p,i):
 assert z.a.denominator%p and z.b.denominator%p
 return (z.a.numerator*pow(z.a.denominator,-1,p)+i*z.b.numerator*pow(z.b.denominator,-1,p))%p
rings=[]
for p,ii in primes:
 for i in [ii,-ii%p]:
  pairres=[]
  for si,s in enumerate(C['stages']):
   for e,(a,b)in enumerate(s['gaussian_pairs'],7):
    values=[(a+i*b)%p,(a-i*b)%p,(a*a+b*b)%p]
    assert all(values);pairres.append({'stage':si+1,'edge':e,'a_plus_ib':values[0],'a_minus_ib':values[1],'norm':values[2]})
  branches=[]
  for si,bs in enumerate(BRANCHES):
   for bi,b in enumerate(bs):
    h,d=red(b['h'],p,i),red(b['d'],p,i)
    assert h and d;branches.append({'stage':si+1,'branch':bi,'h':h,'1_minus_h':d})
  rings.append({'p':p,'i':i,'phase_denominators':pairres,'branch_guards':branches})
out={'chart_sha256':hashlib.sha256((R/'CHART.json').read_bytes()).hexdigest(),'same_Green_pairs':log,'all_6_holonomies':[[b['h'].data()for b in bs]for bs in BRANCHES],'coefficient_ring_checks':rings,'rational_coefficient_domain':'Z[i,1/(a+ib),1/(a-ib) for every frozen witness phase]; all holonomies h are units; every polynomial division by 1-h*x^a*y^b uses only h^-1. Fixed guards remain scalar factors in the cleared numerator and are proven nonzero.'}
(R/'EXACT_SUPPORT.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS exact same-Green support, phase denominators, and fixed guards',flush=True)
