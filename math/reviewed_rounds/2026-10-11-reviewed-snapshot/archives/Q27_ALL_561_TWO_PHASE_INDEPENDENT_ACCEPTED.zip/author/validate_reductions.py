"""Redundant embeddings, coefficient-space constraints, and adverse controls.
Imports only the newly written companion generator, never any supplied research code.
"""
import importlib.util,json,itertools,time
from pathlib import Path
from math import isqrt
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fresh_generator',R/'classify_pairs.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=json.loads((R/'COVERAGE.json').read_text());expected=list(itertools.combinations(m.COORDS,2))
assert len(base['pairs'])==561 and [tuple(map(tuple,q['pair']))for q in base['pairs']]==expected
assert len({q['pair_id']for q in base['pairs']})==561
counts={c:sum(q['class']==c for q in base['pairs'])for c in ['same_Green','same_stage','different_stage']}
assert counts=={'same_Green':112,'same_stage':160,'different_stage':289}
for q in base['pairs']:
 assert (q['rank'],q['ncols'])==({'same_Green':(14,14),'same_stage':(13,16),'different_stage':(16,16)}[q['class']])
 assert m.det(q['minor'])==q['minor_determinant']
 bad=[r[:]for r in q['minor']];bad[-1]=bad[0][:];assert m.det(bad)==0
out=[];start=time.monotonic()
for p,ii in [(1000000009,569522298),(998244353,911660635),(2013265921,1728404513)]:
 assert p>1 and all(p%d for d in range(2,isqrt(p)+1));assert ii*ii%p==p-1
 for sign in [1,-1]:
  m.P=p;m.II=sign*ii%p;records=[]
  for k,(pair,prior) in enumerate(zip(expected,base['pairs'])):
   q=m.run_pair(pair,True)
   assert q['pair_id']==prior['pair_id'] and q['class']==prior['class'] and q['support']==[tuple(v)for v in prior['support']]
   assert q['rank']==prior['rank']
   # Reuse the immutable first-pass minor, not an opportunistic different minor.
   row_indices=[(a-1)*7+b-1 for a,b in prior['selected_windows']]
   col_indices=[q['support'].index(tuple(v))for v in prior['pivot_monomials']]
   det=m.det([[q['quotient_rows'][r][c]for c in col_indices]for r in row_indices]);assert det
   if q['class']=='same_stage':
    hx=next(h for h,axes,_,_ in q['guards']if axes==(1,0));hy=next(h for h,axes,_,_ in q['guards']if axes==(0,1))
    x,y=pow(hx,-1,p),pow(hy,-1,p)
    for row in q['quotient_rows']:
     assert sum(v*pow(x,i,p)*pow(y,j,p)for (i,j),v in zip(q['support'],row))%p==0
     assert sum(i*v*pow(x,i-1,p)*pow(y,j,p)for (i,j),v in zip(q['support'],row)if i)%p==0
     assert sum(j*v*pow(x,i,p)*pow(y,j-1,p)for (i,j),v in zip(q['support'],row)if j)%p==0
   records.append({'pair_id':q['pair_id'],'minor_determinant':det,'rank':q['rank']})
  out.append({'p':p,'i':m.II,'pairs':records})
  print(p,m.II,'all 561 fixed minors nonzero; exact-space modular constraints passed',round(time.monotonic()-start,2),flush=True)
 (R/'REDUCTIONS.json').write_text(json.dumps({'class_counts':counts,'embeddings':out,'all_561_duplicate_row_controls_passed':True},indent=2)+'\n')
print('PASS all 3366 fixed-minor nonvanishings and 141120 same-stage Taylor scalar checks',flush=True)
