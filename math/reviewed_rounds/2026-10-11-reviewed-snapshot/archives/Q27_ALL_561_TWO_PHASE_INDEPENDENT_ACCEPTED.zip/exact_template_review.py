"""Independent Q(i) template check, written for this review.
Reconstruct same-Green numerator by four direct inversions and interpolation,
then check both corner coefficients exactly. No candidate program is imported.
"""
from fractions import Fraction as F
from itertools import combinations,product
from pathlib import Path
import json,time,hashlib,sys
ROOT=Path(__file__).resolve().parent
C=json.loads((ROOT/'CHART.json').read_text());N=8
Z=(F(0),F(0));O=(F(1),F(0));NEG=(-O[0],O[1])
def add(x,y):return(x[0]+y[0],x[1]+y[1])
def neg(x):return(-x[0],-x[1])
def sub(x,y):return(x[0]-y[0],x[1]-y[1])
def mul(x,y):return(x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def conj(x):return(x[0],-x[1])
def divide(x,y):
 d=y[0]*y[0]+y[1]*y[1];assert d;v=mul(x,conj(y));return(v[0]/d,v[1]/d)
def total(xs):
 s=Z
 for x in xs:s=add(s,x)
 return s
def scale(A,v):return[[mul(x,v)for x in row]for row in A]
def plus(A,B):return[[add(x,y)for x,y in zip(a,b)]for a,b in zip(A,B)]
def dot(A,B):return[[total(mul(A[r][k],B[k][c])for k in range(N))for c in range(N)]for r in range(N)]
def eye():return[[O if r==c else Z for c in range(N)]for r in range(N)]
def zero():return[[Z]*N for _ in range(N)]
def inverse(A):
 a=[r[:]+e for r,e in zip(A,eye())]
 for j in range(N):
  k=next(r for r in range(j,N)if a[r][j]!=Z);a[k],a[j]=a[j],a[k]
  v=a[j][j];a[j]=[divide(x,v)for x in a[j]]
  for r in range(N):
   if r!=j:
    v=a[r][j]
    if v!=Z:a[r]=[sub(x,mul(v,y))for x,y in zip(a[r],a[j])]
 B=[r[N:]for r in a]
 assert dot(A,B)==eye()==dot(B,A)
 return B
G=[]
for s in C['stages']:
 gs=[O]*7
 for a,b in s['gaussian_pairs']:
  g=(F(a*a-b*b,a*a+b*b),F(2*a*b,a*a+b*b));assert mul(g,conj(g))==O;gs.append(g)
 G.append(gs)
def lap(s,b,replace):
 cyc=C['stages'][s]['cycles'][b];L=eye()
 for j in range(N):L[cyc[j]][cyc[j-1]]=neg(replace.get(8*b+j,G[s][8*b+j]))
 return L
fixed=[[inverse(lap(s,b,{}))for b in range(3)]for s in range(2)]
for gs in fixed:
 for A in gs:assert plus(A,[[conj(A[c][r])for c in range(N)]for r in range(N)])==eye()
S=[plus(plus(gs[0],gs[1]),gs[2])for gs in fixed]
def entry_product(M,r,c):
 # Product M[r,c]*M[0,0] as a bivariate polynomial.
 out={}
 for (i,j),A in M.items():
  for(k,l),B in M.items():
   e=(i+k,j+l);out[e]=add(out.get(e,Z),mul(A[r][c],B[0][0]))
 return out
def product_at(M,r,c):
 out={}
 for(i,j),A in M.items():
  for(k,l),B in M.items():
   e=(i+k,j+l);out[e]=add(out.get(e,Z),mul(A[r][0],B[0][c]))
 return out
def target_star_coefficient(f,target):
 out=Z
 for(i,j),v in f.items():
  e=(i+2-target[0],j+2-target[1])
  if e in f:out=add(out,mul(v,conj(f[e])))
 return out

def main():
 start=time.time();results=[];count=0
 for s in range(2):
  for b in(1,2):
   T=plus(fixed[s][(b+1)%3],fixed[s][(b+2)%3])
   for e,f in combinations(range(8*b,8*b+8),2):
    h=O
    for k in range(8*b,8*b+8):
     if k not in(e,f):h=mul(h,G[s][k])
    assert h!=Z and mul(h,conj(h))==O and h!=O
    values={}
    for t,u in product((Z,NEG),repeat=2):
     den=sub(O,mul(h,mul(t,u)))
     H=scale(plus(inverse(lap(s,b,{e:t,f:u})),T),den)
     values[(t,u)]=H
    A=values[(Z,Z)];B=values[(NEG,Z)];D=values[(Z,NEG)];E=values[(NEG,NEG)]
    aff={(0,0):A,(1,0):plus(A,scale(B,NEG)),(0,1):plus(A,scale(D,NEG)),(1,1):plus(plus(A,E),scale(plus(B,D),NEG))}
    # The polynomial resolvent identity certifies the interpolated branch numerator.
    branch={k:plus(v,scale(T,NEG))if k==(0,0)else plus(v,scale(T,h))if k==(1,1)else v for k,v in aff.items()}
    L00=lap(s,b,{e:Z,f:Z});Le=plus(lap(s,b,{e:O,f:Z}),scale(L00,NEG));Lf=plus(lap(s,b,{e:Z,f:O}),scale(L00,NEG))
    lp={(0,0):L00,(1,0):Le,(0,1):Lf};wanted={(0,0):eye(),(1,1):scale(eye(),neg(h))}
    for reverse in(False,True):
     prod={}
     for(i,j),X in lp.items():
      for(k,l),Y in branch.items():
       ee=(i+k,j+l);V=dot(Y,X)if reverse else dot(X,Y);prod[ee]=plus(prod.get(ee,zero()),V)
     assert all(A==wanted.get(k,zero())for k,A in prod.items())
    M={k:dot(S[1],A)if s==0 else dot(A,S[0])for k,A in aff.items()}
    for r,c in product(range(1,N),repeat=2):
     fpoly=entry_product(M,r,c);gpoly=product_at(M,r,c)
     for target in((0,3),(3,0)):
      assert sub(target_star_coefficient(fpoly,target),target_star_coefficient(gpoly,target))==Z,(s,e,f,r,c,target)
      count+=1
    results.append({'coordinate_ids':[17*s+e-7,17*s+f-7],'coordinates':[[s+1,e],[s+1,f]],'exact_missing_coefficients':98,'both_resolvent_orders':True})
    if len(results)%8==0:print(len(results),round(time.time()-start,2),flush=True)
 out={'same_green_pairs':len(results),'exact_zero_coefficient_checks':count,'method':'Four-point direct Q(i) inversion/interpolation, both polynomial resolvent identities, exact P03=P30=0; d=1-h*t*u gives Q03=P03 and Q30=P30.','candidate_program_loaded':False,'pairs':results,'chart_sha256':hashlib.sha256((ROOT/'CHART.json').read_bytes()).hexdigest()}
 (ROOT/'EXACT_TEMPLATE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(results),count,round(time.time()-start,2),flush=True)
if __name__=='__main__':main()
