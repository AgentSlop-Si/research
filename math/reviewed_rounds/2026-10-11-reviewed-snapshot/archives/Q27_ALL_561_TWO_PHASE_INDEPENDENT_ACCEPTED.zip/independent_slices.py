"""Independent finite-coordinate Q27 review. Candidate code is never loaded.
Reconstructs the coefficient matrix by weighted cycle paths, separately under
both Gaussian embeddings. The monomial ambient space is fixed before reduction.
"""
import json,hashlib,time,sys
from pathlib import Path
from itertools import combinations,product
from math import isqrt
ROOT=Path(__file__).resolve().parent
C=json.loads((ROOT/'CHART.json').read_text())
N=8
MON=list(product(range(4),repeat=2));WINDOWS=list(product(range(1,8),repeat=2))
COORD=list(product(range(2),range(7,24)))
P=1000000009;II=569522298

def clean(a):return {e:v%P for e,v in a.items() if v%P}
def add(a,b):
    c=a.copy()
    for e,v in b.items():c[e]=(c.get(e,0)+v)%P
    return clean(c)
def scale(a,v):return clean({e:c*v for e,c in a.items()})
def mul(a,b):
    c={}
    for (i,j),v in a.items():
        for (k,l),w in b.items():
            e=(i+k,j+l);c[e]=(c.get(e,0)+v*w)%P
    return clean(c)
def div(a,b):
    a=a.copy();q={};e=max(b);v=pow(b[e],-1,P)
    while a:
        f=max(a)
        if f[0]<e[0] or f[1]<e[1]:break
        d=(f[0]-e[0],f[1]-e[1]);w=a[f]*v%P;q[d]=w
        a=add(a,scale({(g[0]+d[0],g[1]+d[1]):h for g,h in b.items()},-w))
    assert not a,('inexact division',a,b)
    return q
ONE={(0,0):1};ZERO={}
def matmul(A,B):
    return [[sum(A[r][k]*B[k][c] for k in range(N))%P for c in range(N)] for r in range(N)]
def polymatmul(A,B):
    out=[[{} for _ in range(N)]for _ in range(N)]
    for r,c in product(range(N),repeat=2):
        for k in range(N):out[r][c]=add(out[r][c],mul(A[r][k],B[k][c]))
    return out

def gains(ii):
    gs=[];raw=[]
    for s in C['stages']:
        a=[1]*7
        for x,y in s['gaussian_pairs']:
            vals=[(x+y*ii)%P,(x-y*ii)%P,(x*x+y*y)%P];assert all(vals)
            raw+=vals;a.append(vals[0]*pow(vals[1],-1,P)%P)
        gs.append(a)
    return gs,raw

def stage(s,pair,gs):
    hs=[];ds=[];fixed=[]
    for b,cycle in enumerate(C['stages'][s]['cycles']):
        g=[]
        for j in range(N):
            edge=8*b+j
            if (s,edge)==pair[0]:g.append({(1,0):1})
            elif (s,edge)==pair[1]:g.append({(0,1):1})
            else:g.append({(0,0):gs[s][edge]})
        hol=ONE
        for a in g:hol=mul(hol,a)
        d=add(ONE,scale(hol,-1))
        H=[[{} for _ in range(N)]for _ in range(N)]
        for k in range(N):
            v=ONE
            for m in range(N):
                H[cycle[(k+m)%N]][cycle[k]]=v
                v=mul(v,g[(k+m+1)%N])
        if len(d)==1 and (0,0) in d:
            den=d[(0,0)];assert den
            fixed.append(den)
            H=[[scale(v,pow(den,-1,P))for v in row]for row in H];d=ONE
        else:assert len(d)==2 and d[(0,0)]==1
        hs.append(H);ds.append(d)
    d=ONE
    for a in ds:d=mul(d,a)
    S=[[{}for _ in range(N)]for _ in range(N)]
    for b,H in enumerate(hs):
        fac=ONE
        for j,D in enumerate(ds):
            if j!=b:fac=mul(fac,D)
        for r,c in product(range(N),repeat=2):S[r][c]=add(S[r][c],mul(H[r][c],fac))
    return S,d,fixed

def coefficient_rows(pair,ii):
    gs,raw=gains(ii);S=[];d=ONE;guards=[]
    for s in range(2):
        M,den,f=stage(s,pair,gs);S.append(M);d=mul(d,den);guards+=f
    M=polymatmul(S[1],S[0]);assert all(i<=1 and j<=1 for row in M for a in row for i,j in a)
    return M,d,guards,raw

def reciprocal(a):return {(-i,-j):v for (i,j),v in a.items()}
def defects(A,B):
    ps=[]
    for r,c in WINDOWS:
        f=mul(A[r][c],A[0][0]);g=mul(A[r][0],A[0][c])
        fb=mul(B[r][c],B[0][0]);gb=mul(B[r][0],B[0][c])
        p=add(mul(f,reciprocal(fb)),scale(mul(g,reciprocal(gb)),-1))
        p={(i+2,j+2):v for (i,j),v in p.items()};assert all(0<=i<=4 and 0<=j<=4 for i,j in p)
        ps.append(p)
    return ps

def select_minor(rows):
    basis={};selected=[]
    for idx,row in enumerate(rows):
        a=row[:]
        for col,b in basis.items():
            v=a[col]
            if v:a=[(x-v*y)%P for x,y in zip(a,b)]
        col=next((j for j,v in enumerate(a)if v),None)
        if col is None:continue
        v=pow(a[col],-1,P);a=[x*v%P for x in a];basis[col]=a;selected.append(idx)
        if len(basis)==16:break
    return selected,list(basis)
def determinant(rows):
    a=[r[:]for r in rows];n=len(a);d=1
    assert all(len(r)==n for r in a)
    for j in range(n):
        k=next((r for r in range(j,n)if a[r][j]),None)
        if k is None:return 0
        if k!=j:a[j],a[k]=a[k],a[j];d=-d
        pivot=a[j][j];d=d*pivot%P
        for r in range(j+1,n):
            q=a[r][j]*pow(pivot,-1,P)%P
            a[r]=[(x-q*y)%P for x,y in zip(a[r],a[j])]
    return d

def evaluate(a,t,u):return sum(v*pow(t,i,P)*pow(u,j,P)for(i,j),v in a.items())%P
def invert(A):
    a=[row[:]+[int(r==c)for c in range(N)]for r,row in enumerate(A)]
    for j in range(N):
        k=next(r for r in range(j,N)if a[r][j]);a[k],a[j]=a[j],a[k]
        v=pow(a[j][j],-1,P);a[j]=[v*x%P for x in a[j]]
        for r in range(N):
            if r!=j:
                v=a[r][j];a[r]=[(x-v*y)%P for x,y in zip(a[r],a[j])]
    B=[r[N:]for r in a]
    assert matmul(A,B)==[[int(r==c)for c in range(N)]for r in range(N)]
    return B

def direct_product(pair,ii,t,u):
    gs,_=gains(ii);ss=[]
    for s in range(2):
        S=[[0]*N for _ in range(N)]
        for b,cycle in enumerate(C['stages'][s]['cycles']):
            L=[[int(r==c)for c in range(N)]for r in range(N)]
            for j in range(N):
                idx=8*b+j;v=gs[s][idx]
                if(s,idx)==pair[0]:v=t
                if(s,idx)==pair[1]:v=u
                L[cycle[j]][cycle[j-1]]=(L[cycle[j]][cycle[j-1]]-v)%P
            G=invert(L)
            S=[[(x+y)%P for x,y in zip(a,b)]for a,b in zip(S,G)]
        ss.append(S)
    return matmul(ss[1],ss[0])

def main():
    assert C['N']==8 and C['product_order']=='M=S2*S1' and C['sum_coefficients']==[1,1,1]
    assert C['free_phase_indices']==list(range(7,24))
    assert all(sorted(c)==list(range(N))for s in C['stages']for c in s['cycles'])
    assert P>2 and all(P%d for d in range(2,isqrt(P)+1)) and II*II%P==P-1
    out=[];counts={};start=time.time()
    for idx,pair in enumerate(combinations(COORD,2)):
        case='cross_stage' if pair[0][0]!=pair[1][0] else('same_green'if pair[0][1]//8==pair[1][1]//8 else'same_stage_different_green')
        A,d,guards,raw=coefficient_rows(pair,II);B,db,guardb,rawb=coefficient_rows(pair,-II)
        Ps=defects(A,B);Qs=[div(p,d)for p in Ps]
        assert all(i<=3 and j<=3 for q in Qs for i,j in q)
        assert all(mul(q,d)==p for q,p in zip(Qs,Ps))
        rows=[[q.get(e,0)for e in MON]for q in Qs];selected,cols=select_minor(rows)
        record={'pair_id':f'q27-pair-{idx:03d}','author_style_pair_id':'__'.join(f's{s+1}e{e:02d}'for s,e in pair),'coordinate_ids':[17*s+e-7 for s,e in pair],'coordinates':[[s+1,e]for s,e in pair],'case':case,'pole_factor':[[*e,v]for e,v in sorted(d.items())],'fixed_guard_residues_plus':guards,'fixed_guard_residues_minus':guardb,'rank':len(selected),'selected_window_indices':selected,'pivot_columns':cols,'coefficient_rows_sha256':hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()}
        if len(selected)=={'cross_stage':16,'same_green':14,'same_stage_different_green':13}[case]:
            matrix=[[rows[k][j]for j in cols]for k in selected];det=determinant(matrix);assert det
            broken=[r[:]for r in matrix];broken[-1]=broken[0][:];assert determinant(broken)==0
            record.update(status='EXCLUDED_BY_FULL_TEMPLATE_RANK_PENDING_EXACT_TEMPLATE_REVIEW',determinant_mod_prime=det,coefficient_minor=matrix)
            if case=='same_green':
                assert all(q.get((0,3),0)==q.get((3,0),0)==0 for q in Qs)
            if case=='same_stage_different_green':
                a=-pow(d[(1,0)],-1,P)%P;b=-pow(d[(0,1)],-1,P)%P
                assert evaluate(d,a,b)==0
                for q in Qs+[d]:
                    assert evaluate(q,a,b)==0
                    for axis in range(2):
                        der={(i-int(axis==0),j-int(axis==1)):v*(i if axis==0 else j)%P for(i,j),v in q.items()if(i if axis==0 else j)}
                        assert evaluate(der,a,b)==0
                record['double_pole_intersection']=[a,b]
                record['target_polynomial']=record['pole_factor']
            else:record['target_polynomial']=[[0,0,1]]
        else:record.update(status='UNKNOWN_BY_THIS_REVIEW_TEST')
        # A direct, structurally unrelated Gauss inversion test for every slice.
        t,u=7,11
        if not evaluate(d,t,u):t,u=13,17
        assert evaluate(d,t,u)
        for ii,num,den in[(II,A,d),(-II,B,db)]:
            M=direct_product(pair,ii,t,u);D=evaluate(den,t,u);assert D
            assert all(evaluate(num[r][c],t,u)==D*M[r][c]%P for r,c in product(range(N),repeat=2))
        # Conjugate reciprocal control uses direct inversions at reciprocal variables.
        M=direct_product(pair,II,t,u);Mb=direct_product(pair,-II,pow(t,-1,P),pow(u,-1,P))
        scale_factor=pow(t,2,P)*pow(u,2,P)*pow(evaluate(d,t,u),2,P)*pow(evaluate(db,pow(t,-1,P),pow(u,-1,P)),2,P)%P
        for(r,c),p in zip(WINDOWS,Ps):
            v=(M[r][c]*M[0][0]*Mb[r][c]*Mb[0][0]-M[r][0]*M[0][c]*Mb[r][0]*Mb[0][c])%P
            assert evaluate(p,t,u)==v*scale_factor%P
        record['direct_inverse_entry_checks']=128;record['conjugate_reciprocal_defect_checks']=49
        out.append(record);counts[(case,record['status'])]=counts.get((case,record['status']),0)+1
        if(idx+1)%25==0:print(idx+1,round(time.time()-start,2),counts,flush=True)
    result={'chart_sha256':hashlib.sha256((ROOT/'CHART.json').read_bytes()).hexdigest(),'prime':P,'gaussian_i':II,'monomials':[list(x)for x in MON],'gaussian_gain_input_residues_plus':raw,'gaussian_gain_input_residues_minus':rawb,'pair_count':len(out),'counts':{str(k):v for k,v in counts.items()},'pairs':out,'candidate_program_loaded':False,'full_34_phase_fiber':'OPEN'}
    (ROOT/'INDEPENDENT_PAIR_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print('DONE',len(out),round(time.time()-start,2),counts,flush=True)
if __name__=='__main__':main()
