"""Validate final review inputs and write the bounded acceptance verdict."""
from pathlib import Path
from itertools import combinations,product
from collections import Counter
import json,hashlib
R=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=R/'author';ours=json.loads((R/'INDEPENDENT_PAIR_RESULTS.json').read_text());exact=json.loads((R/'EXACT_TEMPLATE_RESULTS.json').read_text());cmp=json.loads((R/'CANDIDATE_COMPARISON.json').read_text())
expected=list(combinations(list(product(range(2),range(7,24))),2))
assert len(ours['pairs'])==len(expected)==561
assert [tuple((s-1,e)for s,e in p['coordinates'])for p in ours['pairs']]==expected
counts=Counter((p['case'],p['rank'])for p in ours['pairs']);assert counts=={('same_green',14):112,('same_stage_different_green',13):160,('cross_stage',16):289}
assert all(p.get('determinant_mod_prime',0)!=0 for p in ours['pairs'])
assert exact['same_green_pairs']==112 and exact['exact_zero_coefficient_checks']==10976
assert sorted(p['coordinate_ids']for p in exact['pairs'])==sorted(p['coordinate_ids']for p in ours['pairs']if p['case']=='same_green')
assert ours['chart_sha256']==exact['chart_sha256']==H(R/'CHART.json')==H(A/'CHART.json')
assert cmp['status']=='PASS' and len(cmp['pairs'])==561
for f,h in cmp['author_data_sha256'].items():assert H(A/f)==h
for entry in json.loads((A/'MANIFEST.json').read_text()):
 p=A/entry['path'];assert H(p)==entry['sha256']and p.stat().st_size==entry['bytes']
checkpoint=R/'AUTHOR_CHECKPOINT.zip'
assert checkpoint.stat().st_size==2575853 and H(checkpoint)=='53693e8efc0a93fe714bc2d086ce20b1c16da5a9eeb67643039e7e1fefed4044'
accepted=[]
for p in ours['pairs']:
 accepted.append({'pair_id':p['author_style_pair_id'],'review_pair_id':p['pair_id'],'coordinate_ids':p['coordinate_ids'],'coordinates':p['coordinates'],'case':p['case'],'status':'INDEPENDENTLY_EXCLUDED_PINNED_WITNESS_SLICE','witness_file':'INDEPENDENT_PAIR_RESULTS.json','witness_pair_id':p['pair_id'],'rank':p['rank'],'determinant_mod_prime':p['determinant_mod_prime']})
coverage={'accepted_pair_count':561,'unexcluded_pairs':[],'pairs':accepted}
(R/'ACCEPTED_COVERAGE.json').write_text(json.dumps(coverage,indent=2)+'\n')
verdict={'status':'INDEPENDENT_ACCEPTED_ALL_561_PINNED_TWO_PHASE_SLICES','date_utc':'2026-10-11','accepted_claim':'All 561 coordinate-pair unit-phase slices through the pinned N8 Phase42 witness exclude external invertible complex monomial equivalence to F8 or any constant-entry-modulus matrix.','chart_sha256':ours['chart_sha256'],'pair_count':561,'case_counts':{'same_green':112,'same_stage_different_green':160,'cross_stage':289},'unexcluded_pairs':[],'full_34_variable_fourier_fiber':'OPEN','other_frozen_witnesses':'UNKNOWN_NOT_COVERED','three_or_more_simultaneous_changes':'UNKNOWN_NOT_COVERED','author_checkpoint':{'library_file_id':'libfile_f298635f0794819193e2b888321a7b31','file_id':'file_0000000021348208b5765aae612df2c8','version':0,'bytes':2575853,'sha256':H(checkpoint),'independent_library_readback_byte_identical':True,'all_payload_manifest_hashes_verified':True},'author_report_sha256':H(A/'REPORT.txt'),'independent_results_sha256':H(R/'INDEPENDENT_PAIR_RESULTS.json'),'exact_template_results_sha256':H(R/'EXACT_TEMPLATE_RESULTS.json'),'candidate_comparison_sha256':H(R/'CANDIDATE_COMPARISON.json'),'proof':'Exact characteristic-zero templates of dimension16/14/13, admissible nonzero minor reductions, and F or F^2 membership in the original necessary-modulus ideal. No modular Groebner lifting.','candidate_program_executed':False,'sheet_changed':False,'github_changed':False}
(R/'VERDICT.json').write_text(json.dumps(verdict,indent=2)+'\n')
print('PASS: sealed bounded acceptance for all 561 pairs; full 34-phase fiber OPEN.')
