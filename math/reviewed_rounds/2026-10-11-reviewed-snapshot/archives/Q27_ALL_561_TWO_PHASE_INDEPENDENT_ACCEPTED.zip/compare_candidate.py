"""Compare inert author JSON with an independently reconstructed coefficient system.
Only independent_slices is imported; candidate Python is never imported or run.
"""
from pathlib import Path
import sys,json,hashlib,importlib.util
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('review',R/'independent_slices.py');V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
A=Path(sys.argv[1])if len(sys.argv)>1 else R/'author'
C=json.loads((A/'COVERAGE.json').read_text());ours=json.loads((R/'INDEPENDENT_PAIR_RESULTS.json').read_text())
assert C['p']==ours['prime']==V.P and C['i']==ours['gaussian_i']==V.II
assert C['chart_sha256']==ours['chart_sha256']==hashlib.sha256((A/'CHART.json').read_bytes()).hexdigest()
assert len(C['pairs'])==len(ours['pairs'])==561
G,_=V.gains(V.II);seen=set();results=[]
for a,r in zip(C['pairs'],ours['pairs']):
 pair=tuple(tuple(x)for x in a['pair']);assert pair==tuple((s-1,e)for s,e in r['coordinates'])
 assert a['pair_id']==r['author_style_pair_id'] and a['pair_id']not in seen;seen.add(a['pair_id'])
 assert a['rank']==r['rank'] and len(a['quotient_rows'])==49
 n,d,guards,_=V.coefficient_rows(pair,V.II);nb,db,guardsb,_=V.coefficient_rows(pair,-V.II)
 Q=[V.div(p,d)for p in V.defects(n,nb)]
 kp=km=1
 for v in guards:kp=kp*v%V.P
 for v in guardsb:km=km*v%V.P
 w1=G[pair[0][0]][pair[0][1]];w2=G[pair[1][0]][pair[1][1]]
 scale=pow(kp*km,2,V.P)*pow(w1*w2,-2,V.P)%V.P
 supports=[tuple(x)for x in a['support']]
 for row,q in zip(a['quotient_rows'],Q):
  assert len(row)==len(supports)
  stored=dict(zip(supports,row))
  assert all(stored.get((i,j),0)==scale*pow(w1,i,V.P)*pow(w2,j,V.P)*q.get((i,j),0)%V.P for i,j in V.MON)
  assert all(m in V.MON for m in supports)
 selected=[(x-1)*7+y-1 for x,y in a['selected_windows']]
 pivots=[supports.index(tuple(m))for m in a['pivot_monomials']]
 minor=[[a['quotient_rows'][i][j]for j in pivots]for i in selected]
 assert minor==a['minor'] and V.determinant(minor)==a['minor_determinant']!=0
 results.append({'pair_id':a['pair_id'],'coordinate_ids':r['coordinate_ids'],'rank':r['rank'],'author_minor_determinant_verified':a['minor_determinant'],'all_49_quotient_rows_match_after_exact_coordinate_scaling_recipe':True})
out={'status':'PASS','pairs':results,'author_data_sha256':{f:hashlib.sha256((A/f).read_bytes()).hexdigest()for f in('CHART.json','COVERAGE.json')},'comparison':'absolute gains t=w1*x,u=w2*y; Qauthor_ij=(Kplus*Kminus)^2*w1^(i-2)*w2^(j-2)*Qreview_ij. Frozen Green denominators K retained only by author.','candidate_code_executed':False}
(R/'CANDIDATE_COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS 561 pair identities, all 27489 quotient rows, and all 561 supplied minor determinants.')
