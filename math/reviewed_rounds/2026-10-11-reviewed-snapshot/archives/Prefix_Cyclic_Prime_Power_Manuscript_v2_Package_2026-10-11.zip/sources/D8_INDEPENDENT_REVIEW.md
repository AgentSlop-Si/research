# Independent review of the uniform D8 prefix theorem

11 October 2026 UTC. Decision: ACCEPT for D8×C_p at every odd prime p. The submitted family theorem needs no mathematical correction. The earlier correction restricting the general nilpotent escape conjecture to nontrivial groups remains essential and is preserved.

The new proof is genuinely uniform. The subgroup and interval arguments reduce every ordering, with no assumption about synchronizing its partial fibres, to affine inequalities on the fixed ranks 0 through 8. Fresh independent arithmetic verifies all 36 edges and every one of the 128 rank paths. The finite p=3,5,7 group controls are corroboration only.

The exact theorem and limitations accepted here are in ACCEPTED_STATEMENT.md. SOURCE_THEOREM_UNCHANGED.md is a byte-identical copy of the submitted THEOREM.md. ACCEPTANCE.json binds both texts and this review to the source archive; MANIFEST.json binds the sealed payload. No source file was edited, and no supplied program or binary was executed or imported.

## Source identity and inherited inputs

A new materialization from Library file libfile_9551b0f569f8819188b1b69b68315f44 returned version 0. Its 18,363 bytes hash to 1ff417248d5b230a2abc96d694a25db15468acd0132cbd2ceb6ea487294b0e6a, matching the task's pinned candidate. Every one of its 16 listed payload members matches its declared size and SHA-256. The theorem member is 11,995 bytes and hashes to d94c822c2895903dde924969454519ce82f4ba8ec878702883929a630abc60e8. These are provenance checks, not mathematical evidence by themselves.

The unchanged earlier escape-reduction archive hashes to 9a9bb08f935948e2c797758af02cf7c5df592728500cad5bdd713191519397c6. The earlier independent ACCEPT_WITH_CORRECTION review archive hashes to e8a03e01edad74c8a579be04aa7519140369090d978a45982055c453fcd57834. The accepted base manuscript hashes to b15dc520910febb2f0336eb6874ea56835512c835182cda55992309d8b9f96a8. All three local byte pins were checked. The relevant complete theorem statements and proofs in the base manuscript, together with the earlier independent correction, were read.

The needed inherited theorem is the value, recursive equality characterization, unique top subgroup, and labeled-count recurrence for finite p-groups and groups whose subgroups pairwise permute. In this task, its uses are only D8, its subgroups, and abelian groups. Its exact local accounting and prime-index block lemmas were also checked directly below. The family proof does not assume an unresolved theorem for general nilpotent groups.

## Splitting and the meaning of a checkpoint

For any subgroup H≤D8×C_p and any (n,c)∈H, the orders of n and c are coprime because the first divides 8 and the second divides the odd prime p. Integer powers chosen by the Chinese remainder theorem isolate (n,1) and (1,c), so both belong to H. Hence H=L×Q, with L≤D8 and Q≤C_p. Since p is prime, Q is trivial or the whole C_p. This eliminates diagonal and partially periodic alternatives for every stabilizer, not just a selected set of examples.

A subset is invariant under the whole C_p precisely when each vertical fibre is either full or empty. Thus all and only checkpoints are prefixes A×C_p. The actual sequence of checkpoint ranks is strictly increasing from 0 to 8, and a noncheckpoint has H_j=L_j×{1}. No assumptions are made about the subsets selected inside its partially occupied fibres; the proof retains only necessary conditions on their empty or full status.

The left regular action of L_j is free. Consequently a_j=|L_j| belongs to {1,2,4,8} and divides j. At checkpoint rank k, the full stabilizer is Stab_D8(A)×C_p and a_j divides both k and 8. Therefore a_j≤gcd(k,8). The final checkpoint has a=8 and contributes 8p−1 to Z; it must not be included in B.

For a∈{1,2,4,8}, the identity

    a−1 = 1_(2 divides a)+2·1_(4 divides a)+4·1_(8 divides a)

is exact. At a checkpoint, the extra factor p adds (p−1)a. This proves the score decomposition used in the candidate. It neither drops nor duplicates any full-prefix term.

## Strict intervals and divisibility

Fix consecutive checkpoints of ranks k<l. For an intermediate prefix let F be the set of full vertical fibres and E the set of nonempty ones. If d∈{2,4,8} divides a_j, then F and E are invariant under L_j, so their sizes are multiples of d. Nesting gives A_k⊆F⊆E⊆A_l. Thus, with u=ceil(k/d) and v=floor(l/d),

    pdu ≤ p|F| ≤ j ≤ p|E| ≤ pdv.

If j=pdu, all the inequalities on the left are equalities and the prefix contains exactly its full fibres, with no other occupied point. It is a checkpoint. Likewise j=pdv forces every occupied fibre to be full. Both are impossible for an intermediate noncheckpoint. Consequently pdu<j<pdv. Independently, the free action gives d|j.

When v>u, division by d leaves the integers pu+1,...,pv−1, numbering p(v−u)−1. When v≤u the open interval contains none. This is exactly max(0,p·max(0,v−u)−1), including coincident endpoints and reversed bounds. Nothing here assumes d|kp or d|lp in advance. The divisibility at an actual checkpoint follows instead from a_j|k, or from d|kp and gcd(d,p)=1.

Adding these bounds over disjoint open checkpoint intervals and counting the checkpoints separately yields the candidate's C_d bound. Some admitted indices may fail stronger fibre constraints; that only makes this an upper bound. There is no relaxation in the wrong direction and no claim that an occupancy count is sufficient for an actual stabilizer.

## Exact affine arithmetic and the uniform potential

Let c_2=1,c_4=2,c_8=4 and w_d=max(0,floor(l/d)−ceil(k/d)). For one interval ending at rank l, its relaxed checkpoint contribution is p·gcd(l,8)−1, and its open-interval contribution is

    sum_d c_d (p w_d−1_(w_d>0)).

This gives exactly the edge E_p(k,l) in the candidate, after combining its two displayed counting formulas. The computation holds for every integer p≥1; its use for group theory is restricted to the stated odd primes.

The independently computed potential partial sums are

    s=(0,1,3,4,8,9,11,12,20),  F_p(k)=p s(k)−k.

The reviewer-authored program represents every affine expression as an exact pair of integers (coefficient of p, constant). It recomputes each edge directly from floor and ceiling, subtracts it from the potential difference, and compares all 36 results with the printed table. All agree. Every nonzero loss D has D−(2p−1) with nonnegative slope and nonnegative value at p=1. Therefore D≥2p−1 for all p≥1, as a symbolic conclusion rather than a finite-prime inference.

As a second independent arithmetic organization, the program forms the score relaxation directly from the checkpoint counts and the three C_d formulas for each of the 128 subsets of the seven possible internal ranks. It compares that result to the sum of the affine edges. All 128 agree coefficient by coefficient and are bounded by 20p−8. There are 26 zero-loss paths. The complete affine outputs are AFFINE_EDGES.json and ALL_128_PATHS.json.

The zero-predecessor argument is sufficient without enumerating the paths. A zero edge entering 8 comes from 0,4,6,7. A zero path entering 7 comes from 6; a zero path entering 6 comes from 4 or 5; a zero path entering 5 comes from 4. Thus a zero-loss 0-to-8 path is either the lone edge 0→8 or contains rank 4. The direct 128-path check independently confirms this consequence.

Telescoping now proves Z≤20p−8 for every ordering. The potential proof uses a fixed finite rank calculation whose entries are polynomials in the arbitrary prime p. It is not induction from the primes 3,5,7.

## Escape gap and the half-size trapping lemma

If B=G, at least one proper checkpoint must exist. Otherwise every proper-prefix stabilizer is contained in D8×{1}, and the group they generate is also contained there.

Suppose rank 4 is a checkpoint and its D8 stabilizer has order 4. Its set of four fibres is a right coset of that order-four subgroup K, which is normal of index two. Therefore the prefix is a right coset of J=K×C_p. Any element outside J exchanges the two J-cosets. Before or at that checkpoint, a nonempty prefix is confined to one coset and cannot be preserved by such an exchange. Later, a proper prefix contains that entire coset but not the entire other one, so it also cannot be preserved by an exchange. Every proper-prefix stabilizer is therefore contained in J. This gives B≤J<G.

This statement is valid for every earlier and later proper prefix. It does not rely on earlier stabilizers persisting or on unconditional accumulated-coset containment, which the known D8 example refutes.

For B=G there are consequently two exhaustive possibilities. If rank 4 is absent, the path has an internal vertex but cannot have zero total loss. One nonzero edge loses at least 2p−1, proving Z≤18p−7. If rank 4 is present, its a is at most 2. The relaxed checkpoint contribution 4p−1 exceeds the actual contribution pa−1 by at least 2p. All the other relaxations remain valid, proving Z≤18p−8. For odd p≥3, the strict inequality 18p−7<20p−8 follows from 2p−1>0.

Both the escape theorem and its quantitative gap therefore follow for every odd prime. The second case's 2p penalty includes the entire checkpoint contribution, not just the (p−1)a part, and the reviewer verified that point explicitly.

## Attainment and every optimizer

For existence, D8 has maximum 12. Arrange the p cosets of D8×{1} consecutively and put an optimal D8 order in each. Its subgroup is normal of prime index p. At a proper block boundary, the quotient subset in C_p is nonempty and proper, so its translation stabilizer is trivial. Inside a block, a stabilizing element must fix the unique partial coset, hence belongs to D8×{1}. The score is p·12+8p−8=20p−8. This establishes attainment independently of the classification of new-group optimizers.

For an optimizer, the strict escape bound forces B<G. Choose a maximal subgroup J containing B. Every subgroup splits as L×Q. If L=D8 and the subgroup is proper, Q must be trivial and the subgroup is D8. If L is proper in D8, it has order at most four and is abelian; hence L×Q is abelian. These are all cases, including the trivial subgroup. Thus every proper subgroup needed by the induction has its full theorem already available. Every maximal subgroup here is normal of prime index.

At each insertion into a right J-coset C, let L_local be the stabilizer in J of the current portion of that active coset. Since each proper-prefix H_j is contained in J, it preserves C and hence lies in L_local. Every local prefix of every coset is used exactly once. At the final insertion the local stabilizer is J and the global stabilizer is G. Therefore

    Z_G = sum_C Z_J(x restricted to C) + |G|−|J|
          − sum_(j<|G|)(|L_local|−|H_j|).

All deficits are nonnegative. The accepted proper-subgroup maximum makes this upper bound equal to |G|W(|G|)=20p−8, because the index is prime. At equality, every local order is optimal and every deficit is zero.

When the first coset becomes complete its local stabilizer is J, so zero deficit makes the whole prefix J-invariant. No other coset has completed and one insertion can complete only its own coset, so every other coset is empty. The same argument at the next completion forces another untouched complete block; continue until the last coset, which occupies the remainder. The induction supplies an independent recursive hierarchy inside each block. No unjustified ordering of the stabilizer subgroups is used.

Conversely, every recursively chosen maximal-subgroup block order attains the maximum by the same prime-index block calculation. Its proper-prefix stabilizers lie in J and its first full block has stabilizer exactly J, so their generated subgroup is J. This proves unique recovery B=J and the disjointness needed for counting.

## Labeled multiplicities and the p equals 3 boundary

For a fixed top subgroup K of index q, there are q! orders of its distinct cosets and A(K) independent labeled orders inside each of the q blocks. Fixing coset representatives identifies each coset with K. A different representative is a right translation of the same labeled collection and introduces no new order. Thus the term is q! A(K)^q. The unique recovered top subgroup ensures that different K give disjoint classes; there is no division by translations or automorphisms.

The base counts are A(C_2)=2, A(C_4)=8, A(C_2×C_2)=24, A(C_p)=p!, and A(D8)=2·8²+4·24²=2432. For C_2×C_p, the two maximal subgroups have indices p and 2, yielding T=p!·2^p+2(p!)². For C_4×C_p the terms yield U=p!·8^p+2T². For (C_2×C_2)×C_p there are three index-two subgroups, yielding V=p!·24^p+6T².

D8×C_p has one D8 top subgroup of index p, one C_4×C_p of index two, and two (C_2×C_2)×C_p of index two. Hence its labeled count is p!·2432^p+2U²+4V². At p=3, T=120, U=31,872, V=169,344 and the three combined terms are 86,306,193,408, 2,031,648,768, and 114,709,561,344, totaling 203,047,403,520. The value is 52. This agrees with the earlier accepted exhaustive certificate, without rerunning or importing its program.

The construction e,s,r,rs,r²,r²s,r³,r³s has proper D8 stabilizers generating D8 and score 10. In its fibre-expanded version, each noncheckpoint has exactly one partially occupied fibre. A stabilizer in D8 must fix that fibre and is therefore trivial; a nontrivial C_p component is impossible because p is prime and the fibre is proper. At rank k the entire stabilizer is the D8 prefix stabilizer times C_p. Summing gives p·10+8(p−1)=18p−8 and the proper stabilizers generate all of G. This verifies the lower example while leaving the one-unit escaping-maximum question unresolved.

## Fresh finite controls and reproducibility

independent_controls.py was written for this review from the mathematical definitions and uses only Python's standard library. It does not import or execute any candidate or earlier-review code. Its source archive handling reads only bytes, JSON manifests, and text.

Besides the symbolic checks, it checks all 540 strict-open-interval counting instances with 0≤k<l≤8, d in {2,4,8}, and p in {1,3,5,7,11}. The p=1 instance is only an arithmetic endpoint stress check, not a group-theorem extension.

It constructs D8 as the eight symmetries of the square on four vertices and composes those permutations. It directly determines all 256 subset stabilizers, then checks all 5,040 identity-first orders, representing all 40,320 labeled orders by the free right-translation action. This independently recovers maximum 12, count 2432, and escaping maximum 10.

For p=3,5,7 it builds the direct-product multiplication tables, checks identity, inverses and every associativity triple, closes all subgroups independently, and finds 20 subgroups in each case. It verifies their actual product decompositions and all maximal-subgroup types. A separate count recurrence over that enumerated subgroup lattice matches the displayed family formula. An explicitly generated hierarchy for each of the four maximal top subgroups has the correct value and B equal to that subgroup. The escape construction is tested by direct translations on every prefix, including equality of the actual checkpoint subgroups, not just their orders. These are supplementary finite controls, not the uniform proof.

Run python3 independent_controls.py in the original scoped workspace to reproduce the checks and their JSON outputs. The program intentionally checks the specified source and dependency locations before doing arithmetic. The sealed output includes all substantive results so that reading the proof does not require execution. A source-only verifier can adapt those input locations without changing the mathematics.

## Accepted scope and exclusions

The family escape bound, value, every-optimizer characterization, unique top subgroup, and labeled formula are accepted. No mathematical correction to that family statement is required. The earlier singleton correction is not reversed or weakened: the general nilpotent escape assertion is still quantified over nontrivial groups and remains open outside accepted cases. The singleton remains score 0, count 1, with no top subgroup.

The review does not establish optimality of the bound 18p−7, a general nilpotent theorem, an algorithmic complexity improvement, historical priority, or additional EFK source access. No Sheet or GitHub write was made. The sealed archive is a mathematical review and evidence package; its successful Library roundtrip is documented separately so that the seal is not changed by recording its own delivery.
