# Prefix escape for D8 times an odd prime cyclic group

11 October 2026 UTC. Candidate theorem. Independent review pending.

## Result and scope

Let P=C_p, where p is an odd prime, and let N=D8 be the dihedral group of order eight. Put G=N×P. For an ordering x of G, let T_j be its first j elements, H_j={g:gT_j=T_j}, and

    Z(x)=Σ_{j=1}^{8p} (|H_j|−1),
    B(x)=⟨H_1,…,H_{8p−1}⟩.

The full prefix is included in Z and excluded from B. This note proves the candidate family statement

    B(x)=G  ⇒  Z(x)≤18p−7<20p−8.                         (1)

In particular this proves the corrected strict top-escape assertion for this family, not for all finite nilpotent groups. The accepted normalization gives |G|W(|G|)=8p(3/2+1−1/p)=20p−8.

The proof is uniform in p. Its only finite arithmetic is a displayed 36-edge table on the fixed ranks 0,…,8. Finite group or path enumerations are checks, not the justification for passing from p=3 to arbitrary primes.

As a consequence, the family has maximum 20p−8, every maximizing ordering is a recursive maximal-subgroup right-coset ordering, and its top subgroup is uniquely B(x). Section 7 gives an explicit labeled count. No historical-priority or implementation-performance claim is made.

## 1 Splitting the stabilizers

Every subgroup H of N×P has the form L×Q with L≤N and Q≤P. Indeed, for (n,c)∈H, the orders of n and c divide 8 and p respectively. The Chinese remainder theorem supplies powers isolating (n,1) and (1,c), so these components belong to H. Taking all elements proves the assertion. Since p is prime, Q is either {1} or P.

A subset is P-invariant exactly when it is a union of whole P-fibres {n}×P. Call a prefix of this form a checkpoint. Include T_0=∅ as a checkpoint and the final T_{8p}=G. The checkpoint ranks form a strictly increasing sequence

    0=k_0<k_1<⋯<k_r=8,

where T_{k_i p}=A_i×P and |A_i|=k_i. These are all the checkpoints, not an arbitrarily chosen subsequence. Set L_j=H_j∩(N×{1}), identified with a subgroup of N, and a_j=|L_j|∈{1,2,4,8}.

At a noncheckpoint, |H_j|=a_j. At a checkpoint of rank k>0, |H_j|=p a_j and a_j=|Stab_N(A_i)|≤gcd(k,8). The latter divisibility follows from the free regular action. Let

    C_d=#{j∈{1,…,8p}:d divides a_j},  d∈{2,4,8}.

The exact binary decomposition a−1=1_{2|a}+2·1_{4|a}+4·1_{8|a} gives

    Z=C_2+2C_4+4C_8+(p−1)Σ_{i=1}^r a_{k_i p}.          (2)

## 2 The checkpoint interval bound

Fix consecutive checkpoint ranks k<l and d∈{2,4,8}. Define

    w_d(k,l)=max(0, floor(l/d)−ceil(k/d)).

Among the noncheckpoint indices kp<j<lp with d|a_j, there are at most

    max(0,p w_d(k,l)−1)                                (3)

such indices.

Proof. Let F_j⊆N be the set of full P-fibres and E_j⊆N the set of nonempty P-fibres of T_j. Both are invariant under L_j, so their cardinalities are multiples of a_j, hence of d. Nesting gives A_i⊆F_j⊆E_j⊆A_{i+1}. Consequently

    |F_j|≥d ceil(k/d),    |E_j|≤d floor(l/d),
    p d ceil(k/d)≤p|F_j|≤j≤p|E_j|≤p d floor(l/d).

Each outer endpoint is forbidden at a noncheckpoint. Equality at the left endpoint would force j=p|F_j|, hence T_j=F_j×P. Equality at the right endpoint would force j=p|E_j|, hence T_j=E_j×P. Either would be a checkpoint strictly between the two declared consecutive ones. Thus

    p d ceil(k/d)<j<p d floor(l/d).

Also d|j, since L_j acts freely on T_j. The number of multiples of d in this open interval is exactly p(floor(l/d)−ceil(k/d))−1 when the difference is positive, and is zero otherwise. This proves (3), including the equal-endpoint and reversed-endpoint cases.

At a checkpoint of rank k, d|a_j implies d|k because p is coprime to d, or equivalently because a_j divides k. Thus (3) and the checkpoint contributions imply

    C_d≤#{i≥1:d|k_i}+Σ_{i=0}^{r−1} max(0,p w_d(k_i,k_{i+1})−1).      (4)

## 3 A nine-node potential proves the uniform bound

Write c_2=1, c_4=2, c_8=4, and g(k)=gcd(k,8) for k>0. Replacing each checkpoint a_{kp} by g(k) in (2), and using (4), yields Z≤U_p(k_0,…,k_r), where

    U_p=Σ_{i=0}^{r−1} E_p(k_i,k_{i+1}),
    E_p(k,l)=p[g(l)+Σ_{d=2,4,8} c_d w_d(k,l)]
             −[1+Σ_{d=2,4,8} c_d·1_{w_d(k,l)>0}].       (5)

For completeness, the cancellation giving (5) uses

    g(l)=1+Σ_d c_d·1_{d|l},
    max(0,pw−1)=pw−1_{w>0}  for integers w≥0 and p≥1.

Define a potential on the nine ranks:

    s(0),…,s(8) = 0,1,3,4,8,9,11,12,20,
    F_p(k)=p s(k)−k.

Thus s(k)=Σ_{t=1}^k gcd(t,8). The following complete triangular table gives

    D_p(k,l)=F_p(l)−F_p(k)−E_p(k,l),

with entries on row l listed in order k=0,…,l−1:

    l=1:  0
    l=2:  0,       0
    l=3:  2p−1,    2p−1,    0
    l=4:  0,       2p−1,    0,       0
    l=5:  4p−1,    6p−2,    4p−1,    4p−1,    0
    l=6:  4p−2,    6p−3,    4p−2,    4p−1,    0,       0
    l=7:  6p−3,    8p−4,    6p−3,    6p−2,    2p−1,    2p−1,    0
    l=8:  0,       6p−3,    4p−2,    4p−1,    0,       2p−1,    0,       0

Every entry follows by direct substitution in (5); the table is small enough to verify without a program. Every nonzero entry is at least 2p−1 for p≥1. Therefore telescoping proves

    Z≤U_p≤F_p(8)−F_p(0)=20p−8.                         (6)

The table also proves the equality structure of the rank path. A path 0→8 using only zero entries either is the single edge 0→8 or passes rank 4. Indeed, the zero predecessors of 8 are 0,4,6,7; those of 7 consist of 6; those of 6 are 4,5; and those of 5 consist of 4. Tracing backward proves the assertion. This argument does not rely on an empirical optimizer classification.

## 4 A half-size subgroup checkpoint traps every stabilizer

Suppose a checkpoint has rank 4 and a_{4p}=4. Its four-element set A is a single right coset Kx of K=Stab_N(A), where |K|=4. The subgroup K has index two in N and is therefore normal. Let J=K×P, an index-two normal subgroup of G. The prefix T_{4p}=A×P is a right J-coset.

Every proper-prefix stabilizer lies in J. To see this, an element outside J swaps the two right J-cosets. For j≤4p, T_j is nonempty and contained in the first coset, so an outside element cannot stabilize it. For 4p<j<8p, T_j contains the entire first coset and omits some point of the other; an outside element preserving T_j would force that entire other coset into T_j, a contradiction. Therefore B(x)≤J<G.

This trapping argument uses only the one half-size subgroup checkpoint. It does not assume that earlier stabilizers stabilize later prefixes or that accumulated subgroups lie inside arbitrary prefixes.

## 5 Strict top escape and a quantitative gap

Assume B(x)=G. There must be a proper checkpoint: otherwise every proper-prefix H_j lies in N×{1}, making B proper.

If rank 4 is not a checkpoint, the rank path has a proper internal vertex and cannot consist entirely of zero table entries. Its potential loss is at least 2p−1, so (6) improves to

    Z≤20p−8−(2p−1)=18p−7.

If rank 4 is a checkpoint, Section 4 shows that a_{4p}≠4. Thus a_{4p}≤2. In forming (5), the rank-4 checkpoint was bounded by g(4)=4. Its total score contribution was therefore overestimated by at least p(4−2)=2p: its actual term is p a_{4p}−1, and the checkpoint term used is 4p−1. All remaining bounds still hold. Consequently

    Z≤U_p−2p≤18p−8.

These two cases prove (1). In particular, they prove the weaker integer strict bound Z≤20p−9 requested by the strict-escape condition. The stronger bound is an upper bound; no attainment claim for the escaping maximum is made.

## 6 Value and every optimizer

The value upper bound is (6). Recursive maximal-subgroup right-coset orders attain 20p−8 by the accepted normal-prime-index block construction. Alternatively, placing the p cosets of N consecutively and using an optimal D8 ordering in each gives p·12+(8p−8)=20p−8.

For any optimizer, strict escape gives B<G. Choose a maximal subgroup J containing B. All proper subgroups of D8×C_p lie within the already accepted theorem: a subgroup splits as L×Q; if L=D8 and the subgroup is proper it is D8×{1}, a 2-group; otherwise L is an abelian proper subgroup of D8, and L×Q is abelian. The maximal subgroups are normal of prime index.

The accepted exact local accounting gives

    Z_G=Σ_C Z_J(x|_C)+|G|−|J|−Σ_{j<|G|}(|L_j^local|−|H_j|).

Every deficit is nonnegative. The accepted proper-subgroup values give an upper bound of 20p−8, which is achieved here. Equality therefore makes each local ordering optimal and every deficit zero. At the first completion of a J-coset, its local stabilizer is J; zero deficit forces the entire prefix to be J-invariant. No other coset was already complete, so all other cosets are empty. Repeating this argument forces consecutive whole coset blocks. Accepted proper-subgroup equality characterization gives the recursive hierarchy in each block.

Conversely, the normal-prime-index block calculation makes every such hierarchy optimal. Its first full block has stabilizer J and all proper-prefix stabilizers lie in J, so B=J and the top subgroup is unique. No statement for a singleton escape inequality is used: the corrected conjecture quantifies only over nontrivial groups, while the recursive singleton base case remains value 0 and count 1.

## 7 Explicit labeled count

Put f=p! and

    T=f·2^p+2f²,
    U=f·8^p+2T²,
    V=f·24^p+6T².

The accepted abelian recurrence identifies these respectively as A(C_2×C_p), A(C_4×C_p), and A(C_2×C_2×C_p). The elementary base counts are A(C_2)=2, A(C_4)=8, A(C_2×C_2)=24, and A(C_p)=p!.

D8 has one cyclic maximal subgroup of order four and two Klein-four maximal subgroups. Its accepted count is A(D8)=2·8²+4·24²=2432. The maximal subgroups of D8×C_p are one D8 of index p, one C_4×C_p of index two, and two C_2×C_2×C_p of index two. Unique top subgroups make these disjoint classes of labeled orders. Hence

    A(D8×C_p)=p!·2432^p+2U²+4V².                       (7)

No quotient by translations or automorphisms is taken and no extra coset-representative factor occurs. For p=3, (7) gives 203,047,403,520, agreeing with the accepted independent certificate; the value is 52.

## 8 Relation to the known accumulation counterexample

In D8, the order e,s,r,rs,r²,r²s,r³,r³s has proper-prefix stabilizers generating D8 and score 10. Replacing each listed element by its full P-fibre gives checkpoints at all ranks. Proper-prefix stabilizers generate D8×P, while

    Z=p·10+8(p−1)=18p−8.

This is a uniform escaping example one unit below bound (1), and is an actual counterexample to unconditional accumulated-coset containment. It is consistent with, and distinct from, the high-score escape theorem proved here. In particular no invalid unconditional accumulation lemma is used in Sections 1–7.

## 9 Evidence and review boundary

The accepted inputs are the original candidate libfile_29b83a99a3608191a9e0850eacac899e, SHA-256 9a9bb08f935948e2c797758af02cf7c5df592728500cad5bdd713191519397c6, and the independent ACCEPT_WITH_CORRECTION review libfile_c3d57d4ddf4c8191bd40163ef658f040, SHA-256 e8a03e01edad74c8a579be04aa7519140369090d978a45982055c453fcd57834. Their unchanged local archives were hash-checked. The full accepted manuscript and review were read for the definitions and proper-subgroup theorem.

Fresh controls verify all 36 affine edge expressions, all 128 checkpoint-rank sequences, the p=3 labeled-count specialization, the uniform escaping construction at small primes, and bounded occupancy-path optimizations. No uploaded or inherited program was executed or imported. No Sheet or GitHub write was performed. This note is a new candidate theorem pending independent review; it does not alter the accepted source archives, prove the general nontrivial nilpotent escape conjecture, resolve historical priority, or close any EFK source-access gap.
