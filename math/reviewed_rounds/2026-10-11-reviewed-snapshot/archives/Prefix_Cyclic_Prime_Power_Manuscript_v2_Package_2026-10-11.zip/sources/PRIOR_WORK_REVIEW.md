# Prior work comparison for the q group times prime prefix theorem

11 October 2026 UTC. Bounded historical comparison of the submitted H×C_p theorem. This is not an independent mathematical acceptance, a worldwide-priority certificate, or a revision of the sealed submission.

## Conclusion

No exact earlier equivalent was located in this pass. The defensible contribution remains the **objective-specific upper bound and necessity of the complete optimizer hierarchy for arbitrary finite q-groups H times C_p**, where p and q are distinct primes. This extends the project’s accepted scope in a genuine mixed-prime direction if the independent mathematical review accepts the proof.

The comparison also supplies an important correction to how that contribution should be described: **coset-dependent local choices already occur in older logarithmic-signature constructions**. Independent branching, unique decomposition language, or factorial/product counting alone are not defensible novelty claims. The top-subgroup recovery is a short consequence of the hierarchy; its role in avoiding double counting is useful but should not be presented as a separate discovery of comparable magnitude.

Historical priority remains bounded by the unresolved EFK source sections described below and by the nonexhaustive nature of the literature search. The previous audit already recovered EFK Theorem 2.1 and its principal incidence calculation; the older claim that this entire theorem is unread must not be reinstated.

## Fixed target and exact scope

The submission is Library file `libfile_38c2907665a88191a9f2a8d6aff48a09`, archive SHA-256 `57ff2f6d35bc41e0bb8f827fa478866d5b6c990fae8ac7d283759c94a0c1a9fe`. Its `THEOREM.md` is 15,027 bytes, SHA-256 `290e120fd40a464144c2b92ce23576a21b6aed4c5d0f70603125bba7b9d346b1`. The local archive and theorem member were checked against those identities.

Let |H|=q^a, a≥0, and G=H×C_p, with primes p≠q. For an ordering x of all labeled elements, let T_j be its j-element prefix and S_j its setwise stabilizer under left translation. The target claims:

1. max Z_G=|G|[a(1−1/q)+1−1/p], where Z_G=Σ_{j=1}^{|G|}(|S_j|−1).
2. All and only maximizers are recursively consecutive right cosets of maximal subgroups, with independently optimal internal orders.
3. For each maximizer, its top subgroup is B(x)=⟨S_1,…,S_{|G|−1}⟩.
4. A(H×C_p)=p!A(H)^p+q!Σ_{M maximal in H}A(M×C_p)^q, counting actual labeled orders.
5. If a≥1 and B(x)=G, then Z_G≤max Z_G−(p−1). The gap is not asserted sharp.

This is equivalently the class of finite nilpotent groups whose order is q^a p, with distinct primes and exponent one on the second Sylow factor. It includes p=2<q. It is not a theorem for all finite nilpotent groups, for H×C_{p^b} with b>1, or for three distinct primes.

The earlier project theorem already handles all prime-power groups and groups with pairwise permutable subgroups. For this product family, pairwise subgroup permutability holds exactly when it holds in H: restriction gives necessity, and coprime subgroup splitting gives sufficiency. Thus the genuinely enlarged portion includes nonpermutable H, rather than merely nonabelian H. The accepted D8×C_p theorem already covers its D8 subfamily for odd p and has a stronger escape estimate. Neither the new general family nor the older permutable family contains the other in full.

## Claim level comparison matrix

| Target claim | Verified antecedents | What the inspected results do not supply | Assessment |
|---|---|---|---|
| Maximum over all labeled orders on H×C_p | Orbit–stabilizer weights; prime-index transversal constructions; known connectivity statistic | An upper bound for this simultaneous regular-group relabeling objective with incompatible mixed-prime periods | Plausible objective-specific extension, conditional on proof acceptance |
| Every optimizer is a recursive maximal-subgroup coset hierarchy | Fixed-chain signatures, coset-dependent signature constructions, canonical interval decompositions | Necessity of this exact hierarchy from equality in the prefix-score problem for arbitrary q-group H | Strongest structural claim |
| B(x) uniquely recovers the top subgroup | Classical decompositions and top-choice recursions | The exact formula for this optimizer objective | Useful short consequence of the structural classification |
| Labeled recurrence with factorials and powers | Classical sum/product enumeration and rooted-tree wreath products | Identification of the counted objects with all optimizers, disjoint across top subgroups | Exact consequence, not a new counting principle |
| Uniform escape loss at least p−1 | None of the inspected external statements gives this prefix objective | The claimed q-adic compatibility bound and trapping implication | A proof-specific ingredient; no sharpness or general nilpotent consequence |

“Does not supply” refers to the identified statements and their tested hypotheses, not a claim that every possible deduction from an entire paper is impossible.

## Primary bodies and explicit implication tests

### Connectivity and Coxeter terminology

[Stanley, The Descent Set and Connectivity Set of a Permutation](https://math.mit.edu/~rstan/papers/decset.pdf), equation (1), Proposition 1.1 and Theorems 1.2/1.4, studies cuts of a single permutation and their distribution with descents. [Bergeron–Hohlweg–Zabrocki](https://arxiv.org/pdf/math/0509271), equation (3), Definition 1 and Theorem 2, extends connectivity to the complement of reduced-word simple-generator support in Coxeter groups and studies a graded poset. These primary statements were freshly inspected.

For the target, after choosing a common labeling, Z_G=Σ_{g∈G}|C(g)|. Thus connectivity is already the correct statistic. The missing implication is the optimization over **simultaneous conjugates of an entire fixed regular group**, preserving multiplication relations, followed by equality classification. Neither inspected statement provides that optimization. Coxeter support here is not the set of moved points. This distinction continues to apply when H is nonabelian.

### Fixed chain logarithmic signatures

[González Vasco–Rötteler–Steinwandt, On Minimal Length Factorizations of Finite Groups](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/11/On-Minimal-Length-Factorizations-of-Finite-Groups.pdf), Definition 2.1 and Proposition 3.1 with proof, constructs exact transversal signatures from subgroup chains and gives minimum-length signatures for solvable groups. Its minimized length is the sum of factor-block sizes. Ordered versus unordered blocks are explicitly set aside for that objective.

This supplies familiar constructions for the present solvable groups, not a prefix-score upper bound or necessity theorem. The project’s C12 witness uses order-two subblocks in one top coset and order-three subblocks in another. It excludes description by one fixed subgroup flag containing both stabilizers. It does **not** exclude all generalized logarithmic signatures, nor establish independent branching as an original idea.

### Coset dependent factorizations already exist

[Baumeister–de Wiljes, Aperiodic logarithmic signatures](https://arxiv.org/pdf/1104.4503), Algorithm 5.2, combines local abelian factorization data indexed by transversal choices; every specified index combination must form a signature of the subgroup. Theorem 5.4 validates the construction. Theorems 5.11/5.15 characterize block periods under explicit subgroup or nontranslate hypotheses. These bodies were freshly read in the 2011 preprint.

The local choices have compatibility requirements, unlike the target’s unrestricted independent optimizer choices. The conclusions concern factorization blocks, periods and efficient factorization, rather than the score over every nested element prefix. No inspected theorem gives the target maximum or necessity. This narrows the novelty language without establishing theorem equivalence.

### Double coset constructions

[Lempken–van Trung, On Minimal Logarithmic Signatures of Finite Groups](https://www.researchgate.net/publication/38338583_On_Minimal_Logarithmic_Signatures_of_Finite_Groups), Theorem 4.1 and its proof, was read from the author-uploaded primary body. If H∩gKg^{-1}=1 for every g, H and K have minimum-length signatures, and the number of double cosets is 1, 4 or prime, concatenation with representatives supplies a minimum-length signature of G. The direct-product case is contained in the n=1 remark. This does not optimize nested-prefix stabilizers or classify arbitrary equality cases. The citation is to the 2005 article, not its later web upload date. A separate CiteSeer open failed and was not treated as body access.

### Subgroup chains and rooted trees

[Ștefănescu–Tărnăuceanu, Counting maximal chains of subgroups of finite nilpotent groups](https://www.carpathian.cunbm.utcluj.ro/wp-content/uploads/2009-vol-25-1/carpathian_2009_25_1_119_127.pdf), Theorem 2.1, counts chains through Sylow products with a multinomial interleaving factor. Section 3 recursively sums over the unique top maximal subgroup. In particular, its formula specializes to c(H×C_p)=(a+1)c(H). The counted objects are subgroup chains, not labeled element orders with independent choices in each coset. For C4 there is one subgroup chain but eight target optimizers. The exposed PDF has six pages, printed 119–124, despite the 119–127 filename/masthead; no missing pages are claimed read.

[Matsen–Billey–Kas–Konvalinka, Tanglegrams](https://matsen.fredhutch.org/papers/Matsen2018-bg.pdf), §2.2, Theorem 5 and Example 6, gives the classical direct/wreath-product recursion for rooted-tree automorphisms, attributing it to Jordan. The cyclic prime-power target count is exactly the complete rooted q-ary tree count (q!)^{(q^a−1)/(q−1)}. For variable subgroup hierarchies, the factorial and independent-child product remain ordinary counting. Summing across top choices without overlap requires the target characterization. The original Jordan paper was not read.

### Further alternate terminology

[Burcroff–Defant, Pattern-Avoiding Permutation Powers](https://arxiv.org/pdf/1907.09451), Definition 1.2, Theorem 1.5 and Corollary 1.1 with its proof, concerns embeddings of groups into symmetric groups whose elements avoid a pattern. Its direct-product construction uses disjoint-support permutation sums, not the fixed-degree regular product action; it does not optimize the total number of invariant initial cuts. This is a meaningful simultaneous-group antecedent, but its constraint and conclusion differ from the target.

[Dhand, Symmetric Chain Decomposition of Necklace Posets](https://arxiv.org/pdf/1104.4147), Theorem 4.1 and its proof, decomposes cyclic quotient posets into symmetric chains. It does not maximize reciprocal orbit weights along a lifted saturated chain. The previously checked B4/C4 example admits long symmetric chains with both optimal and nonoptimal prefix scores, so the decomposition property alone cannot imply this objective’s equality classification. This cyclic comparison is even further from arbitrary nonabelian H.

[Hulpke–Linton, Total Ordering on Subgroups and Cosets](https://www.math.colostate.edu/~hulpke/paper/order.pdf), introduction and algorithmic setup, gives efficient lexicographic comparisons of subgroups and cosets of permutation groups. It does not optimize an ordering of all underlying regular-group elements by setwise prefix stabilizers. Ordinary pointwise stabilizer chains must not be confused with the generally nonnested setwise prefix stabilizers here.

## EFK access boundary

[Erdős–Faigle–Kern, A Group-Theoretic Setting for Some Intersecting Sperner Families](https://doi.org/10.1017/S0963548300000377), 1992, remains partially unread. The later project audit recovered Theorem 2.1 and its main double count from indexed primary text. The natural empty-base prefix substitution requires Z_G≤|G| as its hypothesis; the C8 optimizer has Z=12>8. The translated proper-prefix chains also fail Theorem 5.1’s intersection condition. These are failed direct applications, not whole-paper exclusions.

Still missing are full definitions/Lemma 2.1, most of §4, Proposition 5.1’s proof, the complete Corollary 6.1/§6 ending, and full page-render verification. This pass’s targeted indexed searches added no decisive new section coverage. The known explicitly denied direct-download route was not retried, altered, proxied or bypassed. Earlier metadata-only and restricted-access records were preserved as such. No contact, login, purchase or CAPTCHA completion was attempted.

## Exact replacement paragraphs for the update queue

### Contribution paragraph

For H an arbitrary finite q-group and p≠q prime, the proposed extension determines the maximum prefix-stabilizer score on H×C_p and characterizes every maximizing labeled order as a recursive maximal-subgroup coset ordering. The substantive increment is the objective-specific upper bound and necessity result in this mixed-prime class. Recovery of the top subgroup and the labeled recurrence follow from that structure, using standard recursive counting. Independent mathematical review and bounded historical comparison are separate.

After an independently bound ACCEPT decision, “proposed extension” may be changed to “extension”; this historical report itself does not authorize that change.

### Related work paragraph

Fixed-chain transversal signatures, more general coset-dependent factorization constructions, permutation connectivity statistics, and classical subgroup/tree recursions are relevant antecedents. The inspected statements do not establish the present prefix-score maximum or its complete equality classification. In particular, branching constructions and the factorial/product count are not claimed as independently new. The remaining EFK sections prevent a complete whole-paper exclusion, and no worldwide-first claim is made.

### Status row wording

Bounded comparison supports a plausible structural extension for arbitrary H×C_p, conditional on independent correctness acceptance. No exact equivalent located. New antecedent BDW2011 shows coset-dependent branching already exists; retain novelty only for the objective-specific upper bound and all-optimizer necessity. Unique top and labeled counting are consequences. EFK gap is narrowed but remains open. No Sheet or GitHub mutation performed.

## Search and preservation boundary

The search covered exact prefix-stabilizer terms, setwise stabilizers of initial segments, simultaneous permutation connectivity, Young-subgroup intersections, sums of indecomposable components of powers, reciprocal-orbit necklace weights, maximal subgroup chains, rooted-tree recurrences, and exact/amalgamated/aperiodic logarithmic signatures. Most exact-phrase searches returned unrelated uses of “prefix”, “stabilizer” or “connectivity”; those were not evidence against priority. The new useful source trail was the generalized logarithmic-signature neighborhood.

`SOURCE_LEDGER.json` distinguishes freshly inspected primary bodies, inherited comparisons and unread sections. `SEARCH_LOG.json` records the bounded search families. `INPUT_PINS.json` fingerprints the target and the later versus earlier comparison records; `SOURCE_UNCHANGED.json` records the final identity check. No supplied executable was run, no mathematical proof audit was duplicated, and no theorem, ranking or sealed source was edited. The package contains original comparison text and metadata, not third-party full texts.
