# Prefix stabilizer maxima manuscript version 2

11 October 2026. A separate 14-page version extending the original eleven-page H times C_p note to H times C_(p^b), for arbitrary finite q-group H, distinct primes p and q, and a,b >= 0.

The output directory contains the verified PDF and editable XeLaTeX source. BUILD.sh rebuilds on a standard XeLaTeX installation; BUILD_LOCAL.sh records the explicit format and font paths used in this workspace.

The accepted all-depth mathematical proof and independent ACCEPT record are preserved unchanged, with the original version 1 PDF, LaTeX and sealed package. SOURCE_BINDINGS.json and SOURCE_UNCHANGED.json record exact hashes. SOURCE_CHANGE_INDEX.json maps the new presentation to the frozen theorem and original note.

The proof retains all enclosing clips, whole-gap densification, the fixed q-power rank base, exact affine quotient reduction, the full actual top deficit, both maximal-subgroup directions, both prime-power axes and the singleton guards. The escape gap p^(b-1)(p-1) applies only when a,b >= 1 and B equals G, and is not claimed sharp. The stronger historical D8 times C_p gap remains separate at b=1. The bounded prior-work comparison has not been silently extended into an all-depth priority audit.

No noncyclic second Sylow factor, three-prime, all-nilpotent, sharpness, or worldwide-first claim is made. Finite controls are corroboration, not proof premises. No source mathematical programs were executed, and no original or sealed input was edited. No Sheet, GitHub or external publication action was performed.

MANIFEST.json and SHA256SUMS bind all payload members. The Library delivery receipt and independent document fidelity review are separate records, avoiding archive self-reference.
