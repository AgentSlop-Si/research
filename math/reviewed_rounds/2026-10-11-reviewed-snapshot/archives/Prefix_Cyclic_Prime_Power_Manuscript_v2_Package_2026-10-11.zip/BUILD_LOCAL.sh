#!/bin/sh
set -eu
export TEXFORMATS=/tmp/rs_texmf_var:
export TEXINPUTS=.:/usr/share/texlive/texmf-dist/tex//:
export TFMFONTS=/usr/share/texlive/texmf-dist/fonts/tfm//:/usr/share/texmf/fonts/tfm//:
export VFFONTS=/usr/share/texlive/texmf-dist/fonts/vf//:/usr/share/texmf/fonts/vf//:
export T1FONTS=/usr/share/texlive/texmf-dist/fonts/type1//:/usr/share/texmf/fonts/type1//:
export ENCFONTS=/usr/share/texlive/texmf-dist/fonts/enc//:/usr/share/texmf/fonts/enc//:
export TEXFONTMAPS=/usr/share/texlive/texmf-dist/fonts/map//:/usr/share/texmf/fonts/map//:/var/lib/texmf/fonts/map//:
export OSFONTDIR=/usr/share/texmf/fonts/opentype//:
export XDG_CACHE_HOME=/tmp/prefix_v2_fontcache
sh "$(dirname "$0")/BUILD.sh"
