#!/bin/sh
set -eu
cd "$(dirname "$0")"
xelatex -interaction=nonstopmode -halt-on-error -output-directory output output/Prefix_Cyclic_Prime_Power_Manuscript_v2.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory output output/Prefix_Cyclic_Prime_Power_Manuscript_v2.tex
