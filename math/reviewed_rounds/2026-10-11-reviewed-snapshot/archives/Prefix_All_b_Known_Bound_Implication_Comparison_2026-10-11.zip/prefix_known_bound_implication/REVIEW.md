# All-b prefix theorem: bounded known-bound implication test

11 October 2026 UTC. This comparison concerns the frozen theorem for H × C_(p^b). It is not a new correctness review, historical-priority certificate, or ranking change.

## Outcome

**No direct derivation of the full theorem from the inspected classical statements has been established.** The tests below give two specific reasons a proposed derivation is incomplete:

1. An exact, legitimate divisor-weighted incidence encoding reduces the numerical upper bound to a mixed-prime compatibility inequality. Independent incidence caps miss the target by exactly N A B, with A = a(1 − 1/q) and B = b(1 − 1/p). The missing inequality is stated explicitly below.
2. Minimum-length logarithmic signatures, even restricted to amalgamated-transversal signatures and a fixed ordered block type, do not characterize prefix-optimal flattened orders. A uniform cyclic family gives a counterexample. At the first newly relevant depth b = 3, C24 has two signatures of type (3,2,2,2), both of minimum length 9, whose flattened orders have scores 23 and 52.

These are bounded failures of identified reductions. They do not prove that every possible weighted encoding or generalized factorization theorem fails. The objective-specific mixed-prime upper bound and all-optimizer necessity remain plausible contributions relative to this packet. Branching constructions, factorial/product counting, and unique-top recovery as a consequence of the hierarchy are not promoted to independent novelty claims.

## 1. Exact target and source boundary

The target is Library file `libfile_1dae9a88f5108191a048f86017d447d6`, archive SHA-256 `f41867be27ab0f77376b6745adff35575aa3af5044ce4f29d201f60179858d3e`. Its theorem member has 21,879 bytes and SHA-256 `e13674de3c970bc3a18417d9f6e01630b388a0632571637e97674c526f56afd9`. Freshly materialized Library bytes match the local theorem exactly.

Let |H| = q^a, let p ≠ q be primes, and let G = H × C_(p^b), of order N = q^a p^b. For an ordering x, let T_j be its j-element prefix, S_j its left-translation stabilizer, and Z(x) = Σ_(j=1)^N (|S_j| − 1). The full prefix is included. The target value is N(A+B), with A and B as above. Its structural claim is that all and only recursive maximal-subgroup right-coset orders attain that value.

This pass read the prior-work comparison and the later and earlier originality audits identified in `INPUT_PINS.json`. It freshly inspected the linked González Vasco–Rötteler–Steinwandt and Baumeister–de Wiljes primary statements. Other packet antecedents are inherited comparisons, not newly claimed complete-body readings. No inaccessible or denied route was retried.

## 2. A legitimate weighted incidence reduction, with its missing step

The following calculation is original to this comparison, using elementary subgroup splitting, freeness and divisor telescoping. It is not asserted to be an EFK theorem.

For every j, coprime subgroup splitting gives

    S_j = L_j × P_(r_j),       |L_j| = q^(u_j),

where P_s is the unique order-p^s subgroup of C_(p^b). Define weights

    c_0 = e_0 = 1,
    c_i = q^i − q^(i−1)  (i ≥ 1),
    e_s = p^s − p^(s−1)  (s ≥ 1).

For 0 ≤ i ≤ a and 0 ≤ s ≤ b, define the incidence count

    n_(i,s)(x) = #{j ∈ {1,...,N}: i ≤ u_j and s ≤ r_j}.

Both telescoping sums are exact, so

    Z(x) = Σ_((i,s)≠(0,0)) c_i e_s n_(i,s)(x).             (I)

This encoding matches arbitrary, including nonabelian, H in the target. It does not replace H by a cyclic group. Since S_j acts freely on T_j, each counted j is divisible by q^i p^s. Consequently

    n_(i,s)(x) ≤ N/(q^i p^s).                               (II)

Summing these independent caps yields

    Z(x) ≤ N[(1+A)(1+B) − 1] = N(A+B+AB).                   (III)

The same expression is Σ_(j=1)^N [gcd(j,N) − 1]. Thus reweighting the rank-divisibility incidences in this natural way reproduces the elementary gcd bound, not the target mixed-prime bound.

For an exact statement of the reduction gap, put

    Δ(x) = Σ_((i,s)≠(0,0)) c_i e_s
               [N/(q^i p^s) − n_(i,s)(x)].

Every summand is nonnegative, and (I) gives the identity

    Z(x) = N(A+B+AB) − Δ(x).                                (IV)

Therefore the target numerical upper bound is equivalent, for this encoding, to

    Δ(x) ≥ N A B  for every ordering x.                      (V)

Equations (I)–(IV) are proved here. **Equation (V) is the unresolved reduction step to a classical bound.** Independent rank caps only give Δ ≥ 0. A cited theorem would need hypotheses establishing enough incompatibility among the n_(i,s), rather than assuming (V) or the desired score budget. To obtain the full target, it would also need an equality theorem forcing precisely the recursive coset hierarchy when Δ = NAB.

On the prime-power axes A = 0 or B = 0, this obstruction disappears, consistently with the elementary numerical proof for those axes. For C24 = C3 × C8, A = 2/3 and B = 3/2: (III) is 76, the target is 52, and (V) demands the additional loss 24. The hierarchical order in Section 3 has Δ = 24; the natural order has Δ = 53.

The prior audit already recovered EFK Theorem 2.1 and its principal double count. Its conditional incidence budget is not an independent proof of (V). The old C8 empty-base and intersection obstructions are inherited facts and were not rerun or advertised as new. The accessible material supplies no matched auxiliary family and verified loading hypothesis that proves (V).

## 3. A logarithmic-signature encoding that actually fails

### Inspected classical input

[González Vasco–Rötteler–Steinwandt, 2003](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/11/On-Minimal-Length-Factorizations-of-Finite-Groups.pdf), Definition 2.1, Remark 2.2 and Proposition 3.1, defines unique product signatures with block-size sum f, proves f ≥ Σ_l v_l(|G|)l, and obtains equality for solvable groups using prime-index subgroup chains. Its length objective does not depend on how entries are ordered inside each block. These statements were inspected on PDF pages 2–3.

The tested proposed implication is stronger than the source: flattening a minimum-length signature in mixed-radix lexicographic order, with the last block varying fastest, always gives a prefix optimizer. The following exact counterexample refutes that implication.

### Uniform counterexample inside the all-b family

Work additively in C_N, where N = q p^b, p ≠ q primes and b ≥ 1. By the Chinese remainder isomorphism, this is H × C_(p^b) with H = C_q. Consider these two ordered signatures, both of type (q,p,...,p):

    Bad:  [ {0,p^b,...,(q−1)p^b},
            {0,p^(b−1),..., (p−1)p^(b−1)}, ...,
            {0,1,...,p−1} ].

    Good: [ {0,1,...,q−1},
            {0,q,...,(p−1)q},
            {0,qp,...,(p−1)qp}, ...,
            {0,qp^(b−1),...,(p−1)qp^(b−1)} ].

List each displayed block in increasing order and vary the final coordinate fastest. Unique representation for the Bad signature is ordinary mixed-radix expansion. For the Good signature, first reduce modulo q, then expand the remaining quotient in base p. Both therefore are legitimate logarithmic signatures, and both have minimum length q + bp. Their ordered block sizes are identical.

The Bad flattening is the natural cyclic order (0,1,...,N−1). Every nonempty proper prefix I has trivial translation stabilizer. Indeed, I \ (I+1) is the singleton {0}; a translation stabilizing I also stabilizes that difference, hence fixes 0 and is the identity. Thus

    Z(Bad) = N − 1.

The Good signature is exact transversal for the subgroup chain

    C_N > q Z/NZ > qp Z/NZ > ... > qp^b Z/NZ = {0}.

Its flattening consecutively lists the corresponding cosets. The elementary prime-index block accounting gives

    Z(Good) = N[(1−1/q) + b(1−1/p)].

This value can be verified directly without assuming the all-optimizer theorem: a prime-index block step J < K contributes |K|−|J| beyond the sum of local scores. Iterating that identity along the displayed chain gives the formula. For b ≥ 1 the two scores differ: the Good order strictly outperforms the Bad order.

### Explicit b = 3 witness

For C24 the two signatures are

    Bad:  ([0,8,16], [0,4], [0,2], [0,1]),
    Good: ([0,1,2], [0,3], [0,6], [0,12]).

Their common type is (3,2,2,2), and their common minimum length is 9. The Good flattening is

    (0,12,6,18,3,15,9,21,
     1,13,7,19,4,16,10,22,
     2,14,8,20,5,17,11,23).

The scores are respectively 23 and 52. `CONTROLS.json` includes every stabilizer size and every weighted incidence cell for these orders. Six additional parameter choices check the same formula, but the general argument above supplies the counterexample family independently of those controls.

### Why familiar signature enlargements do not remove this example

[Baumeister–de Wiljes, 2011 preprint](https://arxiv.org/pdf/1104.4503), Section 4.2, allows block permutations in the amalgamated-transversal class. Reversing the Bad block sequence produces an exact transversal signature for the chain of multiples of p. Hence Bad itself belongs to that enlarged class. Minimum length plus amalgamated-transversal membership still does not imply prefix optimality.

Algorithm 5.2 and Theorem 5.4 concern compatible local signatures in an abelian group; Remark 5.5 also permits every signature through the degenerate choice U = G. Membership alone therefore cannot supply the missing objective criterion. The inspected period theorems concern individual factor blocks under stated subgroup or nontranslate assumptions, not every flattened prefix. Extending them to arbitrary nonabelian H and recovering prefix-score and equality information would require another argument.

These observations reject the stated decoder. They do not reject arbitrary generalized signatures or claim that no reduction with substantial additional structure could work. Restricting to prefix-compatible prime-index transversal trees recovers the known attaining construction; deriving that compatibility for every optimizer is exactly the structural issue, not a consequence of minimum length.

## 4. What would close the comparison

A successful weighted derivation would supply an accessible primary theorem, a concrete auxiliary incidence object for every ordering in H × C_(p^b), verification of all its hypotheses, and a conclusion proving (V). To recover the full theorem it must additionally identify all equality cases. A successful logarithmic-signature derivation must retain enough ordered-prefix information to distinguish the two same-type minimum-length signatures above and must handle arbitrary q-groups H.

Neither matching statement is in the inspected input. This is a precise missing-implication result, not proof of historical novelty. The EFK source gap remains: full definitions/Lemma 2.1, most of Section 4, Proposition 5.1's proof, the complete Corollary 6.1/Section 6 ending, and full page-render verification. Theorem 2.1 is not wholly unread. No claim excluding the entire EFK paper is made.

The defensible wording remains: the all-b result gives an objective-specific upper bound and complete optimizer characterization for one arbitrary finite q-group times one cyclic p-power factor; no exact classical implication was established in this bounded comparison. No statement is added for noncyclic second Sylow factors, three primes, or all nilpotent groups.

## 5. Preservation and controls

`INPUT_PINS.json` binds the target and inherited comparisons. `SOURCE_LEDGER.json` separates fresh primary-body reading from inherited evidence. The original `controls.py` checks the signature constructions, flattened scores, incidence identity, and the target Library hash. `SOURCE_UNCHANGED.json` verifies the compared local originals were not modified. No theorem, ranking, Sheet, or GitHub content was edited; no supplied executable was run. The archive contains original comparison prose, metadata and original controls, with no third-party full texts.
