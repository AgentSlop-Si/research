"""Original finite controls for two reduction tests, not a novelty proof."""
from itertools import product
from fractions import Fraction
from math import gcd
from pathlib import Path
import json, hashlib, zipfile

BASE = Path(__file__).resolve().parent

def digest(p):
    data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def stabilizers(order):
    n=len(order)
    prefix=set()
    result=[]
    for x in order:
        prefix.add(x)
        result.append([g for g in range(n) if {(g+t)%n for t in prefix}==prefix])
    return result

def flatten(blocks,n):
    order=[sum(t)%n for t in product(*blocks)]
    assert sorted(order)==list(range(n))
    return order

def phi_power(prime,e):
    return 1 if e==0 else prime**e-prime**(e-1)

def incidence(order,q,a,p,b):
    n=len(order)
    st=stabilizers(order)
    counts=[]
    weighted=Fraction(0)
    deficit=Fraction(0)
    for i in range(a+1):
        for s in range(b+1):
            if i==s==0: continue
            d=q**i*p**s
            # In the cyclic control, d divides |S| iff the unique subgroup of order d is contained.
            count=sum(len(S)%d==0 for S in st)
            cap=n//d
            weight=phi_power(q,i)*phi_power(p,s)
            weighted+=weight*count
            deficit+=weight*(cap-count)
            counts.append({'i':i,'s':s,'order':d,'weight':weight,'count':count,'rank_cap':cap})
    A=Fraction(a*(q-1),q); B=Fraction(b*(p-1),p)
    raw=n*(A+B+A*B); target=n*(A+B)
    z=sum(len(S)-1 for S in st)
    assert weighted==z and raw-deficit==z
    assert sum(gcd(j,n)-1 for j in range(1,n+1))==raw
    return {'score':z,'raw_bound':int(raw),'target_value':int(target),'required_deficit':int(n*A*B),'actual_deficit':int(deficit),'cells':counts}

cases=[]
for q,p,b in [(3,2,1),(3,2,2),(3,2,3),(3,2,4),(2,3,2),(2,3,3),(5,2,3)]:
    n=q*p**b
    bad=[[t*p**b for t in range(q)]]+[[t*p**k for t in range(p)] for k in reversed(range(b))]
    good=[list(range(q))]+[[t*q*p**k for t in range(p)] for k in range(b)]
    bad_order=flatten(bad,n); good_order=flatten(good,n)
    reverse_order=flatten(list(reversed(bad)),n)
    assert bad_order==list(range(n))
    bad_st=stabilizers(bad_order); good_st=stabilizers(good_order)
    target=n*(Fraction(q-1,q)+b*Fraction(p-1,p))
    assert sum(len(S)-1 for S in bad_st)==n-1
    assert sum(len(S)-1 for S in good_st)==target
    assert sum(len(S)-1 for S in stabilizers(reverse_order))==target
    assert [len(A) for A in bad]==[len(A) for A in good]==[q]+[p]*b
    cases.append({'q':q,'p':p,'b':b,'N':n,'type':[q]+[p]*b,'minimal_length':q+b*p,
        'bad_blocks':bad,'good_blocks':good,'bad_order':bad_order,'good_order':good_order,
        'bad_stabilizer_sizes':[len(S) for S in bad_st],'good_stabilizer_sizes':[len(S) for S in good_st],
        'bad_incidence':incidence(bad_order,q,1,p,b),'good_incidence':incidence(good_order,q,1,p,b)})

input_paths=[
    Path('prefix_prior_work_1437/REVIEW.md'),Path('prefix_prior_work_1437/SOURCE_LEDGER.json'),
    Path('prefix_1341/later/research_originality_audit_2026-10-11/research_cycle_0019/prefix_originality/AUDIT.md'),
    Path('prefix_1341/later/research_originality_audit_2026-10-11/research_cycle_0019/prefix_originality/SOURCE_STATUS.json'),
    Path('prefix_1341/later/originals/research_cycle_2102/prefix_priority_followup/PRIMARY_COMPARISON.md'),
    Path('prefix_cyclic_power_induction_1540/THEOREM.md')]
archive=BASE/'frozen_library/Prefix_Cyclic_Prime_Power_Induction_Candidate_2026-10-11.zip'
with zipfile.ZipFile(archive) as z:
    members=[name for name in z.namelist() if name.endswith('/THEOREM.md') or name=='THEOREM.md']
    assert len(members)==1
    theorem=z.read(members[0])
    assert hashlib.sha256(theorem).hexdigest()=='e13674de3c970bc3a18417d9f6e01630b388a0632571637e97674c526f56afd9'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='f41867be27ab0f77376b6745adff35575aa3af5044ce4f29d201f60179858d3e'
assert theorem==input_paths[-1].read_bytes()
pins={'target_library_file_id':'libfile_1dae9a88f5108191a048f86017d447d6',
      'target_archive':digest(archive),'target_theorem_member':members[0],
      'target_theorem_bytes':len(theorem),'target_theorem_sha256':hashlib.sha256(theorem).hexdigest(),
      'sources':[digest(p) for p in input_paths]}
(BASE/'INPUT_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
(BASE/'CONTROLS.json').write_text(json.dumps({'status':'PASS','scope':'Finite reduction counterexamples and exact incidence identities only','cases':cases},indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':len(cases),'C24':{'scores':[cases[2]['bad_incidence']['score'],cases[2]['good_incidence']['score']],'raw_bound':cases[2]['good_incidence']['raw_bound'],'required_deficit':cases[2]['good_incidence']['required_deficit']},'target_sha256':pins['target_theorem_sha256']},indent=2))
