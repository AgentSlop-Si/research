from pathlib import Path
import zipfile
p=Path(__file__).resolve().parent
for d in ('final','rebuild','library_inputs'):(p/d).mkdir(exist_ok=True)
with zipfile.ZipFile(p/'final/CHIRP_Exact_Recognition_Working_Note_v2_Source_Package.zip') as z:
 for ext in ('md','docx','pdf'):
  n='CHIRP_Exact_Recognition_Working_Note_v2.'+ext
  (p/'final'/n).write_bytes(z.read(n))
 for n in ('build_note.py','CHIRP_Exact_Recognition_Working_Note_v2.md'):(p/'rebuild'/n).write_bytes(z.read(n))
 for n in z.namelist():
  if n.startswith('sources/') and len(Path(n).parts)==2:(p/'library_inputs'/Path(n).name).write_bytes(z.read(n))
print('Prepared fixed source members. Build and render in rebuild/ before running fidelity checks.')
