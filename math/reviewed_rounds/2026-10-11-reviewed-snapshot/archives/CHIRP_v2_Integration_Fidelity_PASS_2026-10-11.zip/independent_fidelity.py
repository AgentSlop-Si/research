"""Independent read-only verification of CHIRP v2 integration artifacts.
Run after placing the frozen deliverables in final/ and rebuilding in rebuild/.
"""
from pathlib import Path
import re,json,hashlib,zipfile,subprocess
from lxml import etree
import fitz
P=Path(__file__).resolve().parent
NS={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
def sha(b): return hashlib.sha256(b).hexdigest()
def readxml(p):
 with zipfile.ZipFile(p) as z:return etree.fromstring(z.read('word/document.xml'))
def canon(e):return etree.tostring(e,method='c14n')
def eqs(s):return [(int(n),re.sub(r'\s+',' ',m.strip())) for m,n in re.findall(r'\$\$(.*?)\\tag\{(\d+)\}\s*\$\$',s,re.S)]
def ast(p,fmt):return json.loads(subprocess.check_output(['/usr/bin/pandoc',str(p),'-f',fmt,'-t','json']))
def prose(o):
 if isinstance(o,dict):
  if o.get('t')=='Math':return ['<MATH>']
  if o.get('t')=='Str':return [o['c']]
  if o.get('t') in ('Space','SoftBreak','LineBreak'):return [' ']
  return sum((prose(v) for k,v in o.items() if k!='meta'),[])
 if isinstance(o,list):return sum((prose(v) for v in o),[])
 return []
def norm(o):return re.sub(r'\s+',' ',''.join(prose(o))).strip()
with zipfile.ZipFile(P/'library_inputs/CHIRP_Exact_Recognition_Working_Note_Source_Package.zip') as z:
 old=z.read('CHIRP_Exact_Recognition_Working_Note.md')
 for ext in ('docx','pdf'):assert z.read('CHIRP_Exact_Recognition_Working_Note.'+ext)==(P/('library_inputs/CHIRP_Exact_Recognition_Working_Note.'+ext)).read_bytes()
(P/'ORIGINAL_NOTE.md').write_bytes(old)
new=(P/'final/CHIRP_Exact_Recognition_Working_Note_v2.md').read_bytes()
# Only front matter subtitle and the appended section may differ.
oldbody=old[old.index(b'## 1 Purpose'):]
newbody=new[new.index(b'## 1 Purpose'):new.index(b'\n## Appendix A Supplementary')]
assert oldbody==newbody
assert eqs(old.decode())==eqs(new.decode())[:33]
assert [i for i,e in eqs(new.decode())]==list(range(1,40))
oldroot=readxml(P/'library_inputs/CHIRP_Exact_Recognition_Working_Note.docx')
newroot=readxml(P/'final/CHIRP_Exact_Recognition_Working_Note_v2.docx')
oldm=oldroot.findall('.//m:oMath',NS);newm=newroot.findall('.//m:oMath',NS)
assert len(oldm)==345
assert [canon(e) for e in oldm]==[canon(e) for e in newm[:345]]
labels=[int(re.search(r'\((\d+)\)\s*$',''.join(e.itertext())).group(1)) for e in newroot.findall('.//m:oMathPara',NS)]
assert labels==list(range(1,40))
s=ast(P/'final/CHIRP_Exact_Recognition_Working_Note_v2.md','markdown+tex_math_dollars')
d=ast(P/'final/CHIRP_Exact_Recognition_Working_Note_v2.docx','docx')
(P/'SOURCE_AST.json').write_text(json.dumps(s))
(P/'DOCX_AST.json').write_text(json.dumps(d))
assert norm(d['blocks'][0])==norm(s['meta']['date'])
assert norm(d['blocks'][1:])==norm(s['blocks'])
assert d['meta']['title']==s['meta']['title'] and d['meta']['subtitle']==s['meta']['subtitle']
rebroot=readxml(P/'rebuild/CHIRP_Exact_Recognition_Working_Note_v2.docx')
assert canon(newroot)==canon(rebroot)
a=fitz.open(P/'final/CHIRP_Exact_Recognition_Working_Note_v2.pdf')
b=fitz.open(P/'rebuild/render/CHIRP_Exact_Recognition_Working_Note_v2.pdf')
assert len(a)==len(b)
checks=[]
for i,(x,y) in enumerate(zip(a,b),1):
 px=x.get_pixmap(matrix=fitz.Matrix(1.5,1.5));py=y.get_pixmap(matrix=fitz.Matrix(1.5,1.5))
 assert (px.width,px.height,px.samples)==(py.width,py.height,py.samples)
 assert x.get_text()==y.get_text()
 checks.append({'page':i,'width':px.width,'height':px.height,'pixel_identical':True,'text_identical':True})
(P/'FINAL_PDF_TEXT.txt').write_text('\n\f\n'.join(x.get_text() for x in a))
verdict={'status':'PASS','original_body_bytes_unchanged':True,'all_original_33_equations_unchanged':True,'original_345_editable_math_objects_unchanged':True,'total_editable_math_objects':len(newm),'display_equation_labels':labels,'source_docx_prose_and_metadata_match':True,'fresh_source_rebuild_document_xml_exact':True,'fresh_source_rebuild_pdf_pages':checks,'mathematical_programs_executed':False,'document_builder_executed':True}
(P/'STRUCTURAL_VERIFICATION.json').write_text(json.dumps(verdict,indent=2)+'\n')
print(json.dumps(verdict,indent=2))
