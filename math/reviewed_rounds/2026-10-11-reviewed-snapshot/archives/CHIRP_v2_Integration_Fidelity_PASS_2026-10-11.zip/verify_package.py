from pathlib import Path
import json,zipfile,hashlib,io
p=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
zpath=p/'final/CHIRP_Exact_Recognition_Working_Note_v2_Source_Package.zip'
assert sha(zpath.read_bytes())=='478ba14a1ac8a0d54aef65016e3631e8f8fe74f8292703973d9ff088ec1d3e46'
with zipfile.ZipFile(zpath) as z:
 manifest=json.loads(z.read('PACKAGE_MANIFEST.json'))['members']
 assert set(x['path'] for x in manifest)==set(z.namelist())-{'PACKAGE_MANIFEST.json'}
 for t in manifest:
  b=z.read(t['path']); assert len(b)==t['bytes'] and sha(b)==t['sha256']
 for ext in ('md','docx','pdf'):
  n='CHIRP_Exact_Recognition_Working_Note_v2.'+ext
  assert z.read(n)==(p/'final'/n).read_bytes()
 assert z.read('build_note.py')==(p/'rebuild/build_note.py').read_bytes()
 originals=[]
 for t in json.loads(z.read('INPUT_BYTE_VERIFICATION.json')):
  b=z.read('sources/'+t['file_name'])
  assert len(b)==t['bytes'] and sha(b)==t['sha256']
  original=Path(t['original_path'])
  original_check=None
  if original.exists():
   assert b==original.read_bytes();original_check=True
  local=p/'library_inputs'/t['file_name']
  if local.exists():assert b==local.read_bytes()
  originals.append({'filename':t['file_name'],'library_file_id':t['library_file_id'],'sha256':sha(b),'unchanged_original_local':original_check,'independent_library_materialization':local.exists()})
 for t in json.loads(z.read('SOURCE_MEMBER_PINS.json')):
  with zipfile.ZipFile(io.BytesIO(z.read('sources/'+t['archive']))) as sub:
   b=sub.read(t['member']);assert b==z.read(t['local_copy']);assert len(b)==t['bytes'] and sha(b)==t['sha256']
 with zipfile.ZipFile(p/'library_inputs/CHIRP_Bit_Contract_Independent_Review_2026-10-11.zip') as sub:
  for n in ('REVIEWED_STATEMENT.md','INDEPENDENT_REVIEW.md','CORRECTIONS.md'):assert sub.read(n)==z.read('source_text/'+n)
  assert sub.read('sources/CHIRP_Bit_Contract_Audit_and_Supplement_2026-10-11.zip')==z.read('sources/CHIRP_Bit_Contract_Audit_and_Supplement_2026-10-11.zip')
r={'status':'PASS','archive_bytes':zpath.stat().st_size,'archive_sha256':sha(zpath.read_bytes()),'all_manifest_members_verified':len(manifest),'deliverable_members_match_frozen_files':True,'all_source_member_pins_checked':5,'controlling_review_independently_materialized_and_exact':True,'embedded_author_archive_matches_review_archive':True,'originals':originals}
(p/'PACKAGE_VERIFICATION.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
