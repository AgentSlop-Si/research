# Independent review of the RS working note revision

11 October 2026 UTC

## Verdict

**ACCEPT the Version 2 editorial integration at the exact frozen bytes listed below. No correction remains.** The 15-page working note faithfully integrates the independently accepted finite-parameter certificate into the original F020 account. Its mathematical hypotheses, normalization factors, parameter domains, conservative bounds, and Q08 interface agree with the accepted sources.

This verdict covers editorial fidelity, source-to-PDF fidelity, all-page visual quality, preserved originals, and Library byte integrity. It does not reopen or reprove the accepted theory, provide new numerical implementation validation, or change historical priority or research ranking.

## Accepted deliverables

All are Library version 0 and were independently materialized after the author froze them.

- PDF: `libfile_f257084c294c8191abe36e846be6a948`, 127660 bytes, SHA256 `219ec10dc6d996b9c79454aed8a698e7633546a24f983e061c80a724a7108a83`.
- LaTeX: `libfile_91a6f50346e48191bf17888a30532ff6`, 46702 bytes, SHA256 `d87554f92f3914d90486599d4eef4e3b9c78977573010420fd8ee2776b6e730d`.
- Sealed manuscript package: `libfile_5972d3a94bbc8191937ef9ae0cc7a51e`, 547630 bytes, SHA256 `d697bbd36dbad163dff006ee6ec9f69e3f701cbc0b518e93a4de82d2ecf8e8e5`.

Each Library readback is byte-identical to its frozen local counterpart. All 20 members listed by the manuscript package manifest match their declared byte counts and SHA256 hashes. The package's revised PDF and LaTeX also match the individually saved Library items.

## Preserved F020 content

The complete source bodies of Sections 2–8 and Appendices A–B are unchanged, including all 28 originally tagged display equations. A separate extraction comparison verifies every original tagged display, ignoring only whitespace. Direct source-body comparison also passes, so the equation check is not the sole preservation evidence.

In particular, the original account preserves:

- Odd d, characteristic zero, fixed A,d,b, monic ordinary z-discriminants, and the constant/linear discriminant convention.
- The separated initial form and the sign, d-power, Hermite discriminant product, residual discriminant, and resultant powers in its leading coefficient.
- Odd b, G=(z+1)U, g=U(-1), tau=dW/g, the nonzero denominator explanation, the parity-equivalent shared-root initial form, and the extra overlap guards.
- The overlap exponent, complete discriminant coefficient, and extra g-squared factor.
- The distinction between q-omega, q^d-1, and cyclotomic coefficients, with the scale factors in the accepted direction.
- The exact all-order operator/block argument, root counts, formal remainder convention, lower-jet versus leading-coefficient distinction, and qualified prior-work account.

The earlier-body changes are limited to the version label, a purpose paragraph announcing the addition, and the finite-parameter clarification in Section 9. The preamble's paragraph spacing changes from 5pt to 4pt for pagination. These differences and the added Appendices C/D are disclosed in the revision. No original Library file or accepted research source was replaced.

## Integrated certificate

The appended equations map to the accepted source as recorded in `verification/CERTIFICATE_EDITORIAL_MAP.json`.

1. **Domain and branch.** Appendix C fixes a complex embedding and the original finite integer parameters, retains either the separated guards or every simple-overlap hypothesis, explicitly including odd b, and defines the principal analytic branch on |epsilon|<1. The local multiplicity is m_alpha, distinguished from the original m=(d+b)/2. Ordinary and exceptional leading coefficients use the accepted initial forms and moduli.
2. **Normalized Cauchy remainder.** C2–C3 retain the positive coefficient majorant, the degree ceiling, and the essential s^(-m_alpha). The stated domain is 0<|epsilon|<=r<s<1, |x|<=X. This is a fixed-finite-data certificate valid for complex epsilon, with no unstated degree-uniform constant.
3. **Rouche tubes.** C4–C8 retain the strictly less than half-gap radius, positive product lower bound, singleton empty-product rule, strict error test, solved radius, open disks, multiplicity-one conclusion, within-cluster distances, and the quadratic-error construction with eta=2E/L. The original accepted argument supports the strict pairwise bounds because the root tubes are open.
4. **Residual roots and complete separation.** C9 retains the monic residual boundary product and even epsilon tail r^2/(s^2-r^2). Its final inequality is a stated test, not an unconditional conclusion. C10 uses one common r,s, the distinct-center Delta>0 test, and the full node-radius bound. Root counts exhaust n in both cases. The simple residual root's even local analytic branch is consistent with the accepted setup.
5. **Q08 interface.** C11 defines the square moment Vandermonde and Euclidean operator norm, keeps the sqrt(n), (1+R)^(n-1), within-cluster and cross-cluster powers, and sets the singleton factor to one. Q08's fixed-degree singular profile is attributed as an existing result. The new appendix supplies verified separation inputs; it does not promote a discriminant into a singular-spectrum proof. Root preparation, rigorous enclosures, costs, resolvent nonresonance, and the fixed-order primitive-root-path warning remain explicit.
6. **Parameter-only subfamily.** C12–C13 retain b=0, A>=2, odd d>=3, the Hermite radius/gap estimates, and the two strict sufficient thresholds. The suggested epsilon*sqrt(Ad) scale is clearly only a feature of the sufficient geometry, not a necessary collision threshold. The potentially much smaller Cauchy radius is disclosed.
7. **Exact examples.** C14–C15 preserve the accepted rational constants for (A,d,b)=(2,3,0) and (1,3,1), with s=1/2, r=1/10000, eta=1/8 and X=1. The independent finite controls are correctly reported as supporting evidence, not extrapolated into the general theorem. The failed sufficient test at r=1/1000 remains inconclusive about actual collisions.
8. **Discriminant truncation.** C16–C17 retain the Sylvester/Hadamard majorant n^n*S^(2n-1), the normalized v^(-M) tail, the correct strict relative-error threshold, and the M=0 case. This remains a truncation-error certificate, not a floating-point algorithm guarantee.

One draft notation issue was corrected before freezing: the normalization-mutation paragraph used s^(-m), which could conflict with the original overlap notation; the final version uses s^(-m_alpha). No remaining mathematical or editorial correction was found.

## Source-to-PDF and visual verification

A new build directory received only the frozen standalone LaTeX file. Two direct XeLaTeX passes were run with shell escape disabled; neither the research programs nor the author's build script was executed. Both passes succeeded. The environment and command are recorded in `verification/BUILD_INFO.json`.

The freshly rebuilt PDF and frozen author PDF have:

- Exactly 15 pages each.
- Byte-identical layout-preserving text extraction.
- Byte-identical PNG renderings for every corresponding page at 120 dpi.

The PDF files themselves differ in build bytes; the review does not claim PDF-byte reproducibility across builds. It establishes exact extracted-text and rendered-page fidelity. The rebuilt PDF, logs, hashes and comparison record are included.

Every frozen PDF page was opened and visually inspected. All mathematical displays, symbols, signs, equation tags, tables, headings, citations, source hashes, and footers are legible, without clipping or overlap. The final tables have no empty repeated header, and the transition into Appendix C has no nearly blank extra page. The complete page-specific inspection record is in `verification/VISUAL_REVIEW.json`.

An inherited underfull-hbox warning and nonfatal Fontconfig cache warnings do not affect the successful build or the identical rendered pages. There are no overfull-box or missing-reference defects in the final build.

## Accepted dependencies and preservation evidence

The following source identities were checked against the records used in this review:

- Original PDF `libfile_72ddfda84adc8191b5ed994749139490`: SHA256 `c65f50a5dc3acc0580f35e17ead1adbd9b5dc6a7d7f42d4970e8e1c3809e9372`.
- Original LaTeX `libfile_46168cfa2b3481918766ba14fbc98d66`: SHA256 `23462defbe98daf588869a27e46f4ad94f67fd02a09e0196d31bf231aa15c1f0`.
- F020 independent accepted review body: SHA256 `aa6fab3492f265fca7a667a213f57f1453dcfb280d94280ce74b330b353bffd3`.
- Accepted finite-parameter LaTeX: SHA256 `3b472a7adb4a157c52c6ad4f8da5e1d94717e360bce8326e8c4d8732cfbcc100`.
- Independent finite review archive `libfile_30c794c5011c819196acc7d3104d8aad`: SHA256 `b5a00e74f00f1f9d2b5ebfc1afb9479bb950efca792504d63a1c79ce6ffc3e72`; its accepted review body is SHA256 `a412af68fbeffe1d6f332280a5b59e3ac74d91481c492232981319c51e0b6033`.
- Q08 source P05, Section S3: SHA256 `02ec40df49f0585c57f98d3af7cbb9867216773f98a2998db9d51237fd69b787`.
- H01, Theorem T3: SHA256 `4afd27bacea1bd896d8b44e7e4c1eb51c1b24b3db997ceca9e554e69f81202bb`.

The two original note files and accepted finite review archive received fresh Library readbacks before comparison. The final sealed manuscript package preserves the same original note bytes and accepted dependency bytes, verified independently after its Library readback.

## Acceptance boundary

The supported update is: **the accepted finite-parameter certificate is now integrated into an independently verified 15-page RS working-note revision.** Fixed-parameter F020 and Q08 theory remains unchanged. Efficient growing-degree stability, finite-precision implementation, unresolved historical comparisons, and research priority remain separate. No Sheet or GitHub writes were made in this review.
