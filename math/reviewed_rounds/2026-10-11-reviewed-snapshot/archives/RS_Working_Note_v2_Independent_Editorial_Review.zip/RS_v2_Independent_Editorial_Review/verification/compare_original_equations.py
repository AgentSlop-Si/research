#!/usr/bin/env python3
"""Editorial byte comparison of the accepted note's tagged displays.
This script extracts inert text only and does not run research code.
"""
from pathlib import Path
import re,hashlib,json,sys
old,new=map(Path,sys.argv[1:3])
def displays(p):
 text=p.read_text()
 items={}
 for x in re.findall(r'\\\[(.*?)\\\]',text,re.S):
  m=re.search(r'\\tag\{([^}]+)\}',x)
  if m:
   k=m.group(1)
   if k in items: raise ValueError('Duplicate equation tag '+k)
   items[k]=re.sub(r'\s+','',x)
 return items
baseline,candidate=displays(old),displays(new)
checks=[dict(tag=k,unchanged=candidate.get(k)==v) for k,v in baseline.items()]
print(json.dumps(dict(original_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256(new.read_bytes()).hexdigest(),equations=checks,all_original_tagged_displays_unchanged=all(x['unchanged'] for x in checks)),indent=2))
