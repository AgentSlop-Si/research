#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent
cases=[];maxbound=F(0)
for n in list(range(3,66))+[128,257]:
    N=2**n-1
    for D in [1,3,9,64]:
        h=(D+10)*n+32;u=F(1,2**h);tau=32*N*N*u
        e=tau+N*2**(D*n)*u
        # Replace sqrt(N) by N and N^(3/2) by N^2 only in upper bounds.
        err=tau+(1+tau)*(N*e+F(N*N,4)*tau*(1+e))+F(N,4)*2**(D*n)*u
        assert err<F(1,16)
        ell=2*h+(D+2)*n+16
        assert N*(2**(h+D*n+2)-1)*(2**(h+3)-1)<2**ell
        assert h<=((D+10)+11)*n  # absorbs the additive 32 for n>=3
        maxbound=max(maxbound,err)
        cases.append({'n':n,'N':str(N),'D':D,'h':h,'ell':ell,'pass':True})
obj={'status':'PASS','cases':cases,'case_count':len(cases),'maximum_upper_error_float_informational':float(maxbound),'decisive_comparisons':'exact rational','seed_error_hypothesis':'Every stored outer phase and kernel coefficient has absolute error <=32*N^2*2^-h. Cold generation is separately reviewed.'}
(root/'PRECISION_RESULTS.json').write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps({k:v for k,v in obj.items() if k!='cases'},indent=2))
