#!/usr/bin/env python3
"""Fresh independent finite controls. No author research modules are imported.
Dense matrices and Python big-int products here are reference instruments only.
"""
from pathlib import Path
from fractions import Fraction as F
import json, math, random
import numpy as np
ROOT=Path(__file__).resolve().parent
rng=random.Random(202610111329)

def factors(n):
    out=[]; t=2
    while t*t<=n:
        if n%t==0:
            out.append(t)
            while n%t==0:n//=t
        t+=1
    if n>1:out.append(n)
    return out

def isprime(n):
    return n>=2 and all(n%d for d in range(2,math.isqrt(n)+1))

def field(n,start=1):
    for mult in range(start,10000):
        p=mult*n+1
        if not isprime(p):continue
        for base in range(2,p):
            q=pow(base,mult,p)
            if pow(q,n,p)==1 and all(pow(q,n//f,p)!=1 for f in factors(n)):
                return p,q,mult
    raise AssertionError('prime search')

def rank(a,p):
    a=[r[:] for r in a]; i=0
    for j in range(len(a[0])):
        k=next((k for k in range(i,len(a)) if a[k][j]%p),None)
        if k is None:continue
        a[i],a[k]=a[k],a[i]
        inv=pow(a[i][j],-1,p);a[i]=[v*inv%p for v in a[i]]
        for k in range(len(a)):
            if k!=i:
                v=a[k][j];a[k]=[(x-v*y)%p for x,y in zip(a[k],a[i])]
        i+=1
        if i==len(a):break
    return i

exact=[]; failures_rejected=0
for n in [5,7,9,13,17,21,25,31,41,49,65,73]:
    start=1
    for embedding in range(2):
        p,q,start=field(n,start);start+=1
        if embedding:q=pow(q,n-1,p)
        pw=[pow(q,j,p) for j in range(n)]
        qp=lambda k:pw[k%n]
        cc=-(qp((n-1)//2)+qp(-(n-1)//2))%p
        P=[[qp(j*(k+1))*(qp(k-j)+cc+qp(j-k))%p for j in range(n)] for k in range(n)]
        wrong=False; wrongb=False
        for k in range(n):
            for j in range(n):
                fq=(qp(k*(j-1))*qp(2*j)+cc*qp(j)*qp(k*j)+qp(k*(j+1)))%p
                tf=(qp(k)*qp(k*j)+cc*qp((k+1)*j)+qp(-k)*qp((k+2)*j))%p
                ct=qp(-(k-j)*(k-j-1)//2)*(qp(k-j)+cc+qp(j-k))%p
                acb=qp(k*(k-1)//2)*ct*qp(j*(j+3)//2)%p
                assert P[k][j]==fq==tf==acb
                wrong |= P[k][j] != (qp(k)*qp(k*j)+cc*qp((k-1)*j)+qp(-k)*qp((k-2)*j))%p
                wrongb |= P[k][j] != qp(k*(k-1)//2)*ct*qp(j*(j+1)//2)%p
        assert wrong and wrongb;failures_rejected+=2
        m=max(1,n//8);block=[row[m:2*m] for row in P[:m]]
        assert rank(block,p)>=max(0,m-2)
        # Rank-one training shortcut R=P e0 e0^T passes x=e0, fails legal z=e1.
        assert any(row[1] for row in P)
        failures_rejected+=1
        exact.append({'N':n,'prime':p,'q':q,'block_size':m,'block_rank':rank(block,p),'identities':'pass'})

budgets=[]
lengths=list(range(17,16386,2))+[2**20+1,2**40+1,2**128+1]
for n in lengths:
    m=n//8; bits=n.bit_length()
    assert 12*m>=n
    # 3m^2 <= 16Nr + mN/16 implies r >= 3m/256 >= N/1024.
    assert F(3*m*m,1)-F(m*n,16)>=F(9*m*m,4)
    assert F(9*m*m,64*n)>=F(3*m,256)>=F(n,1024)
    # The dyadic-net enlargement gives epsilon <= sqrt(N)/3.
    assert F(3*m*m,1)-F(m*n,9)>=F(5*m*n,36)
    assert F(5*m,576)>=F(5*n,6912)
    for d in [1,2,7,64]:
        delta_squared=F(n,2**(2*d*bits+1))
        assert delta_squared<=F(1,64)
        assert F(9,7)*F(1,16)*4 <= F(1,3)
        budgets.append({'N':str(n),'d':d,'n':bits,'pass':True})

numerical=[]
for n in [17,19,23,31,33,47,65,97,129,193,257,385,513]:
    m=n//8;theta=math.pi/n;q=np.exp(-2j*theta);c=math.cos(theta)
    kk=np.arange(m)[:,None];jj=np.arange(m,2*m)[None,:]
    block=np.exp(-2j*theta*jj*(kk+1))*(2*c+2*np.cos(2*theta*(kk-jj)))
    singular=np.linalg.svd(block,compute_uv=False)
    min_entry=float(np.min(np.abs(block)));frob2=float(np.sum(np.abs(block)**2))
    op=float(singular[0]);pnorm=float(np.max(np.abs(2*c+2*np.exp(-1j*theta)*np.cos((2*np.arange(n)+1)*theta)))*math.sqrt(n))
    eps=pnorm/16
    rr=int(np.sum(singular>eps));netrr=int(np.sum(singular>math.sqrt(n)/3))
    assert min_entry>=math.sqrt(3)*(1-1e-12)
    assert frob2>=3*m*m*(1-1e-12)
    assert op<=4*math.sqrt(n)*(1+1e-12)
    assert rr>=n/1024 and netrr>=5*n/6912
    numerical.append({'N':n,'m':m,'min_abs_entry':min_entry,'frob_squared':frob2,'block_norm':op,'P_norm':pnorm,'rank_required_at_Pnorm_over16':rr,'rank_required_at_sqrtN_over3':netrr,'rank_over_N_lower_bound':1/1024})

def conv(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return out

def pos(v):return [max(0,x) for x in v]
def neg(v):return [max(0,-x) for x in v]
def pack(v,ell):
    # Reference expression only: no word-operation complexity is claimed for this Python code.
    return sum(x<<(ell*i) for i,x in enumerate(v))
def unpack(v,ell,length):return [(v>>(ell*i))&((1<<ell)-1) for i in range(length)]

def packed_signed(a,b,ell):
    out=[0]*(len(a)+len(b)-1)
    for aa,sgna in [(pos(a),1),(neg(a),-1)]:
        for bb,sgnb in [(pos(b),1),(neg(b),-1)]:
            exact=conv(aa,bb)
            assert max(exact)<(1<<ell)
            got=unpack(pack(aa,ell)*pack(bb,ell),ell,len(out))
            assert got==exact
            out=[x+sgna*sgnb*y for x,y in zip(out,got)]
    assert out==conv(a,b)
    return out

packing=[]
for n in [5,7,17,33,65]:
    bits=n.bit_length()
    for d in [1,3,9]:
        h=(d+10)*bits+32;ell=2*h+(d+2)*bits+16
        ab=2**(h+d*bits+2)-1;kb=2**(h+3)-1
        arrays=[]
        for bound in [ab,ab,kb,kb]:
            arrays.append([rng.randrange(-bound,bound+1) for _ in range(n)])
        a,b,c,e=arrays
        ac=packed_signed(a,c,ell);be=packed_signed(b,e,ell)
        ae=packed_signed(a,e,ell);bc=packed_signed(b,c,ell)
        real=[x-y for x,y in zip(ac,be)];imag=[x+y for x,y in zip(ae,bc)]
        folded=[(real[i]+(real[i+n] if i+n<len(real) else 0),imag[i]+(imag[i+n] if i+n<len(imag) else 0)) for i in range(n)]
        ref=[]
        for k in range(n):
            rr=ii=0
            for j in range(n):
                l=(k-j)%n;rr+=a[j]*c[l]-b[j]*e[l];ii+=a[j]*e[l]+b[j]*c[l]
            ref.append((rr,ii))
        assert folded==ref
        assert any(folded[i]!=(real[i],imag[i]) for i in range(n-1))
        failures_rejected+=1
        # The maximum legal magnitude envelope, independently of random signs.
        assert n*ab*kb < 2**ell
        # A single packed operand is not one O_d(log N)-bit machine word.
        assert (n-1)*ell > 4*h
        packing.append({'N':n,'D':d,'h':h,'ell':ell,'packed_operand_bits_upper':n*ell,'unsigned_products':16,'cyclic_fold':'pass'})
# Too-narrow digits are genuinely invalid, even with small positive arrays.
assert unpack(pack([7,7],3)**2,3,3)!=conv([7,7],[7,7]);failures_rejected+=1

result={'status':'ALL_FRESH_CONTROLS_PASSED','source_programs_executed_or_imported':False,
 'exact_field_controls':exact,'exact_budget_count':len(budgets),
 'exact_budget_N_count':len(lengths),'largest_budget_N':str(max(lengths)),
 'numerical_block_controls':numerical,'numerical_controls_are_certificates':False,
 'packed_integer_controls':packing,'negative_controls_rejected':failures_rejected,
 'scope':'Finite corroboration and bookkeeping; all-N conclusions require the written proof. Reference integer multiplication and dense/SVD operations are fully distinct from any proposed executor.'}
(ROOT/'CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['exact_field_controls','numerical_block_controls','packed_integer_controls']},indent=2))
