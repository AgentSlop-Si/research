# Q30: remaining P routes, approximate-rank obstruction and paid packing

11 October 2026. Bounded author audit, requiring independent review. Existing canonical b=1 Q30 only. No new intake, cross-theory construction, Sheet or GitHub write. No independent linear P or Fourier executor is claimed.

## Result

The accepted full-Q inverse and actual residual certificate have closed the inverse-side interface. The remaining current P representations still leave an arbitrary-input operation unpaid. This audit adds two precise facts beyond the earlier exact-field equivalence audit:

1. An ordinary off-diagonal block of P requires rank proportional to N even for a fixed 1/16 operator-norm approximation. A fixed linear approximation valid on every legal fixed-D dyadic input has the same obstruction, with a slightly weaker explicit constant. The result does not cover nonlinear/data-dependent rounded algorithms, other block orderings, or complementary-scale hierarchies.
2. The existing chirp convolution can be reduced, with explicit finite-word precision, to 16 nonnegative integer products of length Theta_D(N log N) bits. Packing is linear-word work; the long products are not single word operations. This isolates a concrete sufficient special-multiplication lemma. That lemma remains unproved. A conventional superlinear multiplication backend supplies only a superlinear baseline.

The following statements concern mathematical routes, not a practical speed benchmark or a historical novelty claim. The approximation argument is the elementary Frobenius/operator-norm rank bound specialized to this family; packing is conventional polynomial encoding.

## 1. Frozen objects and accepted interface

Odd N>=5, n=ceil(log2(N+1)), q=exp(-2 pi i/N), c=cos(pi/N), F[k,j]=q^(kj). The accepted objects are

    Q[j-1,j]=q^(2j), Q[j,j]=2c q^j, Q[j+1,j]=1,
    P=FQ,
    A_j=q^(j(j-1)/2), B_j=q^(j(j+3)/2),
    gamma_j=q^(-j(j-1)/2),
    t_j=gamma_j(q^j+2c+q^(-j)), P=A C_t B.

Indices are cyclic. C_t[k,j]=t_(k-j). The accepted results give ||P||_2<=4 sqrt(N), sigma_min(P)=2 sqrt(N) sin(pi/N)>=4/sqrt(N), and P=TF with an O(N)-overhead exact-field reverse reduction. The bounded rational-shift and exact off-diagonal-rank obstructions are imported at their already accepted scopes.

For every fixed original input-description d, the accepted actual inverse returns an exactly represented a-grid vector y, where a=(2d+20)n+64, obeying

    ||Qy-x||/||x|| <= 8*2^(-(d+16)n-64) <= 2^-112.

Its output is a legal D-description input with D=2d+42. All-zero input has zero absolute residual. Given a separately charged P executor with relative error eta on that represented y, the Fourier error is at most rho+eta(1+rho). No additional inverse precision is needed here. This audit does not reopen that accepted solver.

INPUT_BINDINGS.json freezes the reports and verdict used. No inherited research program is executed or imported.

## 2. New restricted approximate-rank obstruction

Let odd N>=17, m=floor(N/8), I={0,...,m-1}, J={m,...,2m-1}, and K=P[I,J]. These are disjoint adjacent intervals in the ordinary ordering. The entry identity gives

    |P[k,j]|=|2c+2cos(2 pi(k-j)/N)|.

On this block, 1<=j-k<=2m-1<N/4, so the cosine is nonnegative. Since N>=17 implies c>=sqrt(3)/2,

    ||K||_F^2 >= 3m^2,   ||K||_2^2 <=16N.                 (1)

Suppose a rank-r matrix R approximates K with ||K-R||_2<=sqrt(N)/4. Let Pi be orthogonal projection onto the range of R (dimension at most r). Then

    ||K||_F^2=||Pi K||_F^2+||(I-Pi)K||_F^2
              <=16Nr+m||K-R||_2^2
              <=16Nr+mN/16.                              (2)

For N>=24, floor(N/8)>=N/12; the odd N=17,19,21,23 cases satisfy it directly. Hence (1)-(2) imply

    r >= 3m/256 >= N/1024.                               (3)

This applies in particular whenever ||K-R||<=||P||/16, and to the corresponding block of a fixed linear global approximation with ||P-R_global||<=||P||/16. A relative-to-block error ||K-R||<=||K||/16 is also covered. Thus a constant-rank approximation of this growing block cannot meet these stated fixed spectral tolerances for all lengths. The prior exact-rank theorem alone did not establish this approximate version.

### Fixed-D represented-input extension

A contract on a finite dyadic grid must not silently be called an all-complex operator-norm contract. Here is a separate extension for a single fixed linear map R_global. Suppose it satisfies

    ||(P-R_global)z|| <= (1/16)||Pz||

for every legal D-description dyadic z, D>=1. Round any complex unit vector to Cartesian grid 2^(-Dn), producing a legal z with error at most delta=sqrt(N/2)2^(-Dn). Since n>=5 and N<2^n, delta^2<2^(-n-1)<=1/64. If E=P-R_global, the triangle inequality gives

    ||E|| <= (1/16)||P||(1+delta)/(1-delta)
           <=(9/112)||P|| <=(9/28)sqrt(N)<sqrt(N)/3.

Using mN/9 in (2) now yields

    rank(R_global[I,J]) >=5m/576 >=5N/6912.               (4)

The same fixed linear map must serve every legal input. Actual rounded or data-dependent executors generally are not such a map; (4) is not an unrestricted word-RAM lower bound. Nor does a large block's high rank preclude a hierarchy built from smaller complementary blocks. No arithmetic-time lower bound follows solely from (3) or (4).

## 3. Explicit finite-word reduction to exact cyclic convolution

This is a conditional reduction, not a supplied fast convolution implementation. It makes the precision and input interface of that remaining operation concrete.

Let D>=1 be fixed. Each Cartesian input component z_j has magnitude at most 2^(Dn) and denominator exponent at most Dn. Put

    h=(D+10)n+32, u=2^-h, Delta=32N^2u.

Use the accepted rational Machin/Taylor seed construction, at h bits, to construct h-grid qhat and chat with complex/scalar absolute errors below u. Its cold cost remains O_D(n^20), with O_D(n^8) setup scratch; no transcendental oracle or supplied table is assumed. Generate phase p_j and chirp ell_j by

    p_0=ell_0=1,
    ell_(j+1)=round_h(ell_j p_j),
    p_(j+1)=round_h(p_j qhat).

A complex rounding incurs absolute error below u. The accepted elementary drift argument, valid since N^2u<=1/8, gives phase error <=4Nu and chirp error <=4N^2u. Generate the three needed arrays by

    Ahat_j=ell_j,
    Bhat_j=round_h(ell_j round_h(p_j p_j)),
    that_j=round_h(conjugate(ell_j)(p_j+2chat+conjugate(p_j))).

These formulas pay O(N) scalar products, signs, reads and writes. Because |p_j|,|ell_j|<=2, the B error is at most 4N^2u+26Nu+u<=10N^2u. The kernel error is at most 16N^2u+20Nu+u<=21N^2u. Thus every A, B and t coefficient has absolute error <=Delta. Approximate diagonals have norm <=2 and |that_j|<=5. No rounded chirp is assumed unitary.

Convert z exactly to the h-grid and form v_j=round_h(Bhat_j z_j). The one still-required operation is the exact complex cyclic convolution C_that v, retained on its exact 2h-grid. Then return

    w_j=round_h(Ahat_j (C_that v)_j).

The final operation forms the exact 3h-grid numerator and rounds directly to the h-grid; no intermediate downcast is omitted.

For nonzero z, Z=||z||>=2^(-Dn), H0=sqrt(N)2^(Dn)u, and ||v-Bz||<=(Delta+H0)Z. The displayed h ensures Delta+H0<=1 and N Delta<=1<=sqrt(N). Since ||C_t||<=4sqrt(N) and ||C_that-C_t||<=N Delta, the complete error is bounded by

    ||w-Pz||/Z
      <= Delta(4sqrt(N)+N Delta)(1+Delta+H0)
         +(4sqrt(N)+N Delta)(Delta+H0)+N Delta+H0
      <=16N Delta+6sqrt(N)H0
      =512N^3u+6N 2^(Dn)u.

Dividing by sigma_min(P)>=4/sqrt(N), and using sqrt(N)<=N, gives

    ||w-Pz||/||Pz||
      <=128N^4u+2N^2 2^(Dn)u
      <2^-45<1/16.                                     (5)

Indeed the two terms are respectively at most 2^(-(D+6)n-25)<=2^-46 and 2^(-8n-31)<=2^-55. This large margin is convenient, not a minimum-precision claim. Zero input returns zero exactly. All guarantees are full-vector 2-norm guarantees, not coordinate-relative accuracy.

Consequently an exact cyclic-convolution backend would finish a compatible P executor at logarithmic word precision, without any new inverse-side error argument. The missing question is its charged application time.

## 4. Packing the remaining exact operation without hiding its cost

Write v_j=(V_Rj+iV_Ij)/2^h and that_j=(T_Rj+iT_Ij)/2^h with signed integers. The previous bounds give

    |V_Rj|,|V_Ij| <2^(h+Dn+2),
    |T_Rj|,|T_Ij| <2^(h+3).

Split each signed array into its nonnegative positive and negative parts. There are four kernel arrays and four input arrays. Their 16 pairwise ordinary polynomial products reconstruct the exact real and imaginary products using additions and subtractions.

Choose the integer radix 2^ell, where

    ell=2h+(D+2)n+16.

Encode a nonnegative length-N array a by the integer sum_j a_j 2^(ell j). Every ordinary product coefficient is below N*2^(2h+Dn+5)<2^ell. Thus no carry can cross the digit fields. Compute the ordinary length-(2N-1) products first, unpack them, reconstruct signed real/imaginary coefficients, and fold coefficient k+N into coefficient k. This last operation gives the desired cyclic convolution; it is not a cyclic packed-integer multiplication assumption.

Each packed operand has at most L=N ell=Theta_D(Nn) bits. Packing and unpacking use indexed limb writes and reads, not repeated shifts/additions of a growing multiword integer. The digit width ell is O_D(n), so this traffic costs O_D(N) words. Intermediate unpacked convolution coordinates and final unrounded products have O_D(n) bits, for example below 3h+(D+2)n+16 up to a fixed additional constant. A sufficiently large fixed-D multiple of n bits covers all scalar arithmetic. The packed operands themselves emphatically do not fit in one such word.

If M_word(L;n) and S_word(L;n) are the paid work and scratch bounds for the selected exact nonnegative long-integer multiplier on O_D(n)-bit words, this route has the explicit cold ledger

    work <=16 M_word(N ell;n)+O_D(N+n^20),
    storage <=S_word(N ell;n)+O_D(N+n^8).

Input parsing, zero detection, all phase/kernel construction, exact grid conversion, pre/postchirps, packing, signed recombination, cyclic folding and final writes are included. Oversized padded input encodings incur their actual parsing cost. The h-grid fixed-width output has Theta_D(Nn) bits.

A literal schoolbook backend gives quadratic word work. A conventional balanced three-product multiplication has recurrence K(m)=3K(m/2)+O(m) for power-of-two-padded limb length m=Theta_D(N), hence O_D(N^(log_2 3)) word work, with carry handling charged. It is an FFT-free superlinear baseline, not a linear theorem. No such backend was implemented for this audit. Calling an unexamined arbitrary-precision multiplication primitive once does not establish its word cost or establish that it avoids FFT internally.

## 5. Current route audit and the precise next lemma

- Literal current P band multiplication: exactly N(N-2) nonzeros at b=1, quadratic literal work. This is not a universal matrix-vector lower bound.
- Sparse output filter P=TF: O(N) extra scalar work after F. No independent P executor.
- Chirp-gauged P=A C_t B: O(N) paid coefficient/diagonal work; C_t remains input dependent. Section 3 supplies a compatible fixed-D error interface but not its fast execution.
- Parameter-only Q30 spectral or reciprocal recurrences: they prepare coefficients. They do not transform an arbitrary fresh input into spectral coordinates. The accepted direct Q inverse does not apply P.
- Bounded rational-shift and exact bounded-rank routes: already excluded at the prior exact scopes. Section 2 now excludes the specified fixed-accuracy large-block rank route as well.
- Polynomial/packed evaluation: section 4 leaves 16 paid long products. No one-word collapse is legal on the stated word model.
- A literal level-by-level hierarchy retaining and processing Theta(N) scalars at every one of Theta(log N) levels costs Theta(N log N) traffic regardless of cheap coefficient seeds. This statement prices that implementation only. The block bound neither proves nor disproves a different hierarchical execution schedule.

A concrete sufficient next lemma is now isolated: for the four nonnegative kernel digit strings constructed in sections 3-4, prove exact multiplication by arbitrary legal packed input strings, with all required ordinary coefficients recovered, in O_D(N+n^20) work on O_D(log N)-bit words, with paid cold setup and O_D(N+n^8) storage. The strings are generated from the specified canonical h-grid seed/recurrence and are not supplied as free advice. A deterministic certified seed choice suffices; universal success over every allowed seed is not necessary if that choice is fully specified and charged.

Such a lemma would close this particular P route through (5) and the already accepted inverse residual. It is sufficient, not necessary: an independently charged approximate or direct convolution method could instead work. The present sources prove no such special-product lemma. Relabeling the packed operation as multiplication, or describing the kernel recurrence, does not prove it. This audit ends here; it does not propose a new unrestricted search, accept a linear FFT, or claim a universal Fourier lower bound.

## 6. Fresh controls and status

The fresh program accompanies this report. It checks the packed signed complex cyclic convolution exactly against direct sums, the digit-width and precision inequalities with exact rational/integer arithmetic, and the approximate-rank constants and represented-input net estimates. Numerical canonical matrix/phase controls are separately labeled corroboration, not interval certificates or proofs. No uploaded/inherited research code is imported or executed. The written arguments supply the all-N statements; finite controls do not establish asymptotic speed.

Independent review is required before promotion. The package is a meaningful bounded checkpoint: the approximate-rank extension and conditional packing contract are new scoped audit conclusions; the linear special-product/convolution gate remains open.
