# Independent review of Q30 P executor routes

11 October 2026. Verdict: ACCEPTED WITH THE STATED RESTRICTED SCOPES. The accepted results are a fixed-accuracy block-rank obstruction and a fully charged reduction to exact long-integer products. The cold linear P executor remains open. This is a bounded audit of the existing canonical b=1 task, with no new research search or broader complexity conclusion.

The final verdict binds the exact author report and archive. The already accepted P equivalence and actual-Q-residual archives were checked against their recorded SHA-256 values; all manifest members and the report copies used here agree. No author or inherited research program was executed or imported. Fresh controls are included separately from their mathematical conclusions.

## Accepted starting point

For odd N>=5, n=ceil(log2(N+1)), q=exp(-2 pi i/N), c=cos(pi/N), F[k,j]=q^(kj), the reviewed object is P=FQ, with Q[j-1,j]=q^(2j), Q[j,j]=2c q^j and Q[j+1,j]=1. Its chirp factorization is P=A C_t B, where A_j=q^(j(j-1)/2), B_j=q^(j(j+3)/2), gamma_j=q^(-j(j-1)/2), and t_j=gamma_j(q^j+2c+q^(-j)). The accepted bounds are ||P||<=4 sqrt(N) and sigma_min(P)>=4/sqrt(N).

The accepted full-Q executor already has actual relative equation residual rho<=2^-112 at unchanged precision, and its returned vector is a legal fixed-D dyadic input with D=2d+42. A compatible P executor with relative tolerance eta would give Fourier error at most rho+eta(1+rho). There is no remaining inverse-side precision objection in this audit. The newer residual certificate supersedes any attempt to infer failure of that actual solver from its weaker advertised forward-error contract.

## Approximate rank proof

For N>=17 set m=floor(N/8), I={0,...,m-1}, J={m,...,2m-1}, and K=P[I,J]. Since 1<=j-k<=2m-1<N/4, its entry magnitudes satisfy |P[k,j]|=2c+2cos(2pi(k-j)/N)>=sqrt(3). Therefore ||K||_F^2>=3m^2 and ||K||_2^2<=16N.

For a rank-r approximant R with ||K-R||<=sqrt(N)/4, projection Pi onto its range gives ||K||_F^2=||Pi K||_F^2+||(I-Pi)K||_F^2<=16Nr+mN/16. This proof does not assume that R is an SVD truncation. Since m>=N/12, 3m^2-mN/16>=(9/4)m^2 and r>=3m/256>=N/1024. The small odd cases N=17,19,21,23 satisfy the floor bound directly; the floor estimate proves it for N>=24.

The hypothesis is met by error at most ||P||/16 or ||K||/16, and by the corresponding block of a global linear approximation with operator error at most ||P||/16. It rules out uniformly bounded numerical rank in this particular growing off-diagonal block at those errors. The earlier exact-rank theorem alone did not justify this approximate conclusion.

### The finite dyadic input distinction

The author correctly includes a separate argument for a single fixed linear map R_global whose relative 1/16 guarantee holds on every legal fixed-D dyadic input. Round any complex unit vector to the Cartesian grid 2^(-Dn). The resulting vector is legal and the error delta satisfies delta^2=N 2^(-2Dn-1)<2^(-n-1)<=1/64, since n>=5 and D>=1. With E=P-R_global, the triangle inequality yields ||E||<=(1/16)||P||(1+delta)/(1-delta)<=9||P||/112<=9sqrt(N)/28<sqrt(N)/3. Substituting mN/9 in the projection bound gives rank(R_global[I,J])>=5m/576>=5N/6912.

Every quantifier matters. One fixed linear map must serve every legal input. A rounded word algorithm, branch-selected map, or input-dependent compression generally does not have this form. A rank-one map constructed to fit a single input says nothing about the other inputs. Nor does the theorem rule out smaller complementary-scale blocks, another ordering, or a hierarchy that does not represent this block by one bounded-rank factorization. No unrestricted arithmetic or word-time lower bound follows.

## Precision and the remaining convolution

For legal fixed-D input z, the author chooses h=(D+10)n+32, u=2^-h and Delta=32N^2u. The accepted cold rational seed construction is invoked at this fixed-D logarithmic precision. All setup is charged O_D(n^20), with O_D(n^8) scratch. Nothing supplies a free phase table, transformed input, or transcendental operation.

The ratio/chirp recurrences have coefficient errors at most 4Nu and 4N^2u. The formulas Bhat_j=round_h(ell_j round_h(p_j p_j)) and that_j=round_h(conjugate(ell_j)(p_j+2chat+conjugate(p_j))) have the correct exponents. Decomposing errors against the exact unit phases gives the author's valid conservative bounds 4N^2u+26Nu+u for B and 16N^2u+20Nu+u for t. At N>=5 these are at most 10N^2u and 21N^2u, hence below Delta. The use of |p_j|,|ell_j|<=2 includes radial drift; rounded phases are not silently treated as unitary.

The input is converted exactly to the h-grid. The prechirp is rounded once. The remaining operation is exact cyclic convolution of the represented h-grid prechirp and represented h-grid kernel, retained on the 2h-grid. The final outer multiplication forms a 3h-grid numerator and rounds directly once to h. This ordering avoids an unbudgeted intermediate downcast.

The author's complete error expansion is valid. The first term charges the outer coefficient error, the second the prechirp error, the third the kernel perturbation, and the fourth the final rounding. Its simplification to 16N Delta+6sqrt(N)H0, where H0=sqrt(N)2^(Dn)u, follows from Delta+H0<=1 and N Delta<=sqrt(N). Dividing by sigma_min(P) yields relative error <=128N^4u+2N^2 2^(Dn)u<2^-45. The two terms are bounded respectively by 2^-46 and 2^-55 even at the smallest allowed parameters. Zero input returns exact zero; nonzero input has norm at least 2^(-Dn).

For an independent derivation, write e=Delta+sqrt(N)2^(Dn)u. A separate decomposition gives the valid upper bound

    Delta+(1+Delta)[N e+(N^(3/2)Delta/4)(1+e)]
        +(N/4)2^(Dn)u.

Replacing sqrt(N) by N and N^(3/2) by N^2 gives rational upper bounds. All 260 fresh parameter controls pass, with maximum numerical display below 8.72e-16. Exact rational comparisons, rather than that displayed decimal, are decisive. The written inequalities establish the all-N result.

This accepts a conditional finite-word reduction to the explicitly represented exact convolution. It does not provide that operation in linear work.

## Packed products and complete cost

The signed real/imaginary input and kernel numerators obey |V|<2^(h+Dn+2) and |T|<2^(h+3). Splitting each complex array into four nonnegative signed parts gives sixteen ordinary polynomial products. The radix digit width ell=2h+(D+2)n+16 satisfies N*2^(2h+Dn+5)<2^ell, so every coefficient of every nonnegative ordinary product fits one digit without carries crossing fields.

It is essential to unpack the ordinary 2N-1 coefficients before folding the coefficient at k+N into that at k. The report does this. Signed recombination and folding retain O_D(n)-bit scalar coordinates. No cyclic packed multiplication identity is assumed. My fresh controls compare all sixteen products and the fold against independent direct integer cyclic sums, and deliberately reject an omitted fold and an undersized radix.

Each packed operand contains Theta_D(Nn) bits, or Theta_D(N) of the stated O_D(n)-bit words. The report explicitly packs with indexed limb writes and reads rather than repeatedly shifting and copying a growing integer. There is no superlinear dense input expansion: the packed representation is the same asymptotic bit size as the original vector. That fact does not make its multiplication a single-word operation.

The correct ledger is 16 M_word(N ell;n)+O_D(N+n^20) work and S_word(N ell;n)+O_D(N+n^8) storage, with M_word and S_word belonging to a separately supplied exact long-integer backend. Parsing, zero detection, coefficients, conversions, signs, folding, guards, range and writes are charged. The output has Theta_D(Nn) bits. Constants depend on fixed D; this is neither fixed hardware precision nor a growing-D theorem.

The balanced three-product recurrence is a valid FFT-free superlinear baseline. No backend implementation or timing is claimed. A library big-integer multiplication may internally use transforms; without a bound for that implementation it cannot supply a hidden linear word operation. Preparing four kernel integers once does not remove their fresh-input multiplications.

The proposed sufficient special-product lemma is correctly identified as unproved. It must include cold generation of its particular four kernel strings, multiplication against arbitrary legal packed input strings, all coefficient recovery, scratch and traffic. The lemma is sufficient for this reduction, not necessary for every possible P executor.

## Route specific verdicts

The sparse output filter P=TF still calls F. The literal N(N-2)-entry matrix implementation is quadratic as an implementation, while density alone is no lower bound. Kernel or reciprocal recurrences prepare parameters, not the arbitrary input-dependent convolution. The existing exact rational-shift restriction and the new approximate-rank restriction cover only their stated representations. A specified hierarchy that processes Theta(N) scalars through Theta(log N) full levels pays that traffic; this says nothing universal about other schedules.

No positive cold O_D(N+n^20) P executor is established. None of these failures implies that such an executor is impossible. The audit closes a concrete constant-rank approximation route and makes a conditional packed-product route fully costed, while leaving the special-product or direct-convolution operation open.

## Fresh evidence and preservation

Fresh controls pass: 24 exact finite-field orientation/rank cases, 32,752 exact rank/net parameter checks over 8,188 lengths, 13 numerical canonical block SVD checks, 15 exact signed packing/folding cases, 260 exact precision/carry checks and 88 negative controls. Finite-field identities do not import canonical-complex norm inequalities. SVD checks are numerical corroboration, not interval certificates. The Python dense matrices and arbitrary-precision products in the review program are reference instruments, not a claimed implementation with the report's word bound.

SOURCE_BINDINGS.json, AUTHOR_BINDING.json and VERDICT.json pin the evidence. PACKAGE_MANIFEST.json and SHA256SUMS bind the review packet. The final Library copy is read back and checked byte-for-byte. No Sheet, GitHub, intake or fusion state was changed. No author correction was required after the finite-dyadic input clarification was incorporated.
