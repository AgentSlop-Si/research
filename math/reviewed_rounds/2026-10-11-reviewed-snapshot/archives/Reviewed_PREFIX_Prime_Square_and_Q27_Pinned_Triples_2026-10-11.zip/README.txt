REVIEWED PREFIX PRIME-SQUARE AND Q27 PINNED-TRIPLE SUPPLEMENT
11 October 2026, verified through 15:48 UTC

Two newly sealed results are included with their unchanged author and independent-review archives.

1. PREFIX: the exact maximum, complete optimizer hierarchy, unique top subgroup and labeled recurrence now extend from H times C_p to H times the cyclic group C_(p²), for any finite q-group H and distinct primes p,q. The mixed-family sufficient escape gap is p(p−1). This is a standalone algebraic extension; it does not supply an unrestricted faster Fourier algorithm.

2. Q27: 128 specified three-coordinate unit-phase slices through the pinned N=8 Phase42 witness are excluded. The previous 561 coordinate-pair exclusions remain accepted. There are 5,856 other coordinate triples; the full 34-phase Fourier fiber and construction remain open. This is a bounded necessary-modulus exclusion.

The existing table was updated in 11 scope/source cells and 2 Progress cells, with exact readback and all previous cell text retained. Family ranks, inventory counts and historical-priority status are unchanged. The earlier coverage index and working manuscripts remain immutable. In particular, the already delivered PREFIX H×C_p manuscript does not yet include the prime-square theorem.

Contents
- original_archives/: four byte-identical source/review archives
- SOURCE_ARCHIVES.json: original Library IDs, hashes and byte lengths
- ACCEPTED_SCOPES_AND_GATES.json: precise accepted claims and open boundaries
- TABLE_UPDATE_SUMMARY.json: narrow existing-table update record
- MANIFEST.json: hashes for every payload in this supplement

Original candidate/provisional filenames have intentionally been retained. Acceptance is supplied by the separate final review bound to those exact bytes. Finite control counts are supporting checks, not extrapolations or additional discoveries. No human/journal review, worldwide priority, or success probability is asserted. No GitHub action was performed.
