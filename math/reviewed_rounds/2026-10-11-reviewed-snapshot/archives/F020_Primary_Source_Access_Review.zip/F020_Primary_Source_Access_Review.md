# F020 primary source access review

11 October 2026 UTC

## Result

The two named source gaps remain open: the exact six-page body of Zhedanov 1997 and the image of printed page 360 of Lubinsky–Saff 1987. This pass establishes a more precise cause for the latter: the user's uploaded Lubinsky–Saff PDF actually omits printed page 360. Its remaining relevant pages are readable and were freshly inspected as images.

The accepted all-A implication proof is unchanged. Its status is ACCEPT_SCOPED_ALL_A_IMPLICATION, not an outstanding derivation task. Historical publication priority remains unresolved. Missing text is not evidence of absent precedent, and no family-rank change follows from this access review.

## Authorized uploaded source

The Library item 76.pdf, stable ID libfile_b4ae763aa1b0819197aca39308634cb5, version 0, contains the original scanned article:

D. S. Lubinsky and E. B. Saff, Convergence of Padé Approximants of Partial Theta Functions and the Rogers–Szegő Polynomials, Constructive Approximation 3 (1987), 331–361. DOI: https://doi.org/10.1007/BF01890574

The file is 962,409 bytes, SHA256 034c2af8f6b6696d90d2f744e2932740f9fe1696b3a937b984fd7faca4f39b56. The complete page-header contact sheet was visually inspected. PDF pages 1–29 contain printed pages 331–359; PDF page 30 contains printed 361; PDF pages 31–32 are blank. Printed page 360 is absent. The PDF has no usable embedded text, which explains why title/content search alone did not recover it. A Library inventory found the authorized copy.

Full-page images were inspected for printed 331, 332, 340, 343, 346, 347, 358, 359 and 361. Other pages received header-only inventory inspection. This is not a full mathematical review of every article page.

## Mathematical comparison now grounded in page images

The article's G_n is the manuscript's H_n: printed page 332, equations (1.5)–(1.7), defines the Gaussian-binomial polynomial without a q power in its z coefficients.

Printed page 343, Lemma 4.1, equations (4.1)–(4.5), gives its three-term recurrence, the q-shift relation, initial values, reciprocity and polynomial dependence on q. These are explicit classical ingredients, consistent with the recurrence used in the independent F020 controls.

The same page defines an auxiliary polynomial called H_n in equations (4.6)–(4.7), with coefficient factor q^[j(j+1)/2], and factors it as the product of 1+q^j z for j=1,...,n. This auxiliary H_n must not be confused with the manuscript's unweighted H_n. Replacing z by z/q yields the finite-product identity P_n(z;q)=product_(j=0)^(n-1)(1+q^j z), with coefficient factor q^[j(j-1)/2], used in the accepted all-A heat-operator derivation. The article expressly cites Szegö [41, p.245] here.

Printed page 346, Lemma 4.5/(4.15), gives the exact static root-of-unity factorization. Set its order nu=d, its quotient k=A and its remainder l=b to get H_(Ad+b)(z;omega)=(1+z^d)^A H_b(z;omega). The inspected statement fixes the static multiplicities. It does not itself display the transverse initial polynomial when q=omega(1+epsilon^2)^(1/d) and z=alpha+epsilon x.

Printed page 340, Theorem 3.2/(3.11)–(3.12), concerns the m,n Toeplitz determinant associated with the partial theta function and the associated normalized Padé denominator. The paper explicitly defines that determinant there. It is not the ordinary z-discriminant Disc_z H_n. No q-difference discriminant is substituted for the ordinary discriminant in this review.

The accepted exact comparison target remains: the separated He_A initial form; the one-simple-overlap polynomial J_(A+1)=He_(A+1)+A(1-tau)He_(A-1), with tau=dW/g; and their fully normalized ordinary-discriminant coefficients, under the existing residual discriminant, resultant and simple-initial-root guards. The q-minus-omega and cyclotomic quotient scaling factors remain essential. No missing coefficient or sign has been inferred from a static identity.

The independently accepted proof explicitly derives the all-A coefficients from the finite product identity plus its block-filtration, overlap-derivative and root-product arguments. Being derivable from these classical ingredients does not establish when those complete formulas were first published.

## Citation chain findings

Directly inspected citation locations now replace the prior inherited attributions:

- Printed page 332 associates positive-real-q orthogonality with Szegö [41] and Askey–Ismail [2], and the partial-theta continued fraction/Padé denominators with Balk [5], Gragg [16], Perron [30] and Wynn [45].
- Printed page 340 attributes the antecedent of Theorem 3.2 to Balk [5], Gragg [16] and Wynn [45].
- Printed page 343 points specifically to Szegö [41, p.245] for the finite product.
- Printed page 359 contains references 1–8; printed page 361 contains references 37–45. The intervening references are absent from this uploaded scan. The previously recovered publisher inventory remains separate evidence; it does not restore the missing image.
- Printed page 361 itself prints Szegö's page range as 242–251. Other bibliographies give 242–252; this pass records the visible LS87 text without silently correcting or resolving that discrepancy.

A bounded search of legitimate deposits found Magnus's own institutional bibliography, which confirms the final publication details of the item that LS87's publisher inventory marked “to appear”: Journal of Computational and Applied Mathematics 19 (1987), 23–38, DOI 10.1016/0377-0427(87)90168-3. Its substantive original body was not obtained. The author's bibliography and a review excerpt are not treated as the paper.

A possible Szegö-era proceedings scan at IGNCA was too large for web extraction (29,570,540 bytes); one ordinary direct retrieval then returned HTTP 403. Retrieval stopped. No original Szegö body or p.245 image is claimed read. No restricted source was bypassed.

## Zhedanov and access boundary

Exact target: A. S. Zhedanov, Gauss sums and orthogonal polynomials, International Journal of Modern Physics A 12(1) (1997), 289–294, DOI https://doi.org/10.1142/S0217751X97000438.

SciSpace returned the exact DOI record, ID 2063837308, with is_oa=false and fulltext_url=null; it exposed a bibliographic/abstract link to the ADS record. The LS87 exact record likewise had is_oa=false and fulltext_url=null. Available SciSpace tools supply search metadata and table columns; they did not deliver an original body in this pass. An abstract is not a six-page-body comparison.

New domain-targeted deposit searches did not recover the Zhedanov body. The Renmin institutional bibliography again identified the correct citation, separately from the distinct Spiridonov–Zhedanov Duke paper. No claim about Zhedanov's exact hypotheses, equations, normalization or absence of the target theorem is made.

The previously denied Vanderbilt route and blocked ResearchGate route were not retried. There was no paywall bypass, purchase, login, external outreach, browser detour, Sheet write or GitHub write.

## Precise remaining inputs and stopping point

1. A readable, authorized image of LS87 printed page 360.
2. The exact complete Zhedanov pp.289–294 body.
3. Substantive original bodies along the relevant LS87 citation chain, including the finite-product citation to Szegö p.245 and any source proposed as an exact moving-root antecedent.

The current named-channel pass is complete. Further source closure requires new source material or a genuinely new authorized delivery channel, rather than repeated blocked searching. No further proof work is required by this access outcome.

The review archive includes the unchanged uploaded PDF, inspected page images, the page-header inventory, the source ledger and exact input/review hashes. It excludes unrelated Library metadata.

