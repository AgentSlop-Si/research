# Independent review of Q01's conservative two-lane extension

11 October 2026 UTC. Final source binding is recorded in SOURCE_BINDING.json.

Reviewed author note: Q01_TWO_LANE_GUARD_CANDIDATE.md, SHA-256 d761e888825518211547bd2039963048aa466215cbd36482418f7f26373c4a9e. Its frozen 61,041-byte archive is Library libfile_d596732a27f881919dfb18c6b646da4d, version 0, SHA-256 1c96cbd217a87c9ee03b60e0725c144966b9740b5a66b13e31f9b511e41848b4. This reviewer independently materialized those Library bytes, recomputed the archive and note hashes, and verified the note equals the fully reviewed draft.

## Decision and exact scope

SCOPED PASS at mathematical proof level for the frozen conservative rule identified in SOURCE_BINDING.json. The accepted change is only this:

- Replace the packed-branch guard 64b <= v by 8b <= v.
- If 8b <= v < 32b, set P=2.
- If v >= 32b, choose the largest power of two P <= v/(16b), as in the old construction.
- Retain all precision, finite-state encoding, total quantizer, coefficient certification, split-table rounding, output-lattice, charged word-RAM, and literal preparation-budget rules.

This is not acceptance of the earlier alternative that chooses the largest power of two P <= v/(4b) throughout the new domain. That alternative is absent from this verdict. In particular, the conservative rule preserves exactly the old packing parameter on every instance satisfying the old guard.

No blocking mathematical, packing, addressing, error, or paid-asymptotic-work defect was found in the conservative extension. The uniform cold transform-time theorem remains O_c(M(T+log(v+1))) for the dyadic backend M=2^v, and O_c(N(t+log(n+1))) for the existing all-length wrapper, n=ceil(log2(N+1)). The new uniform backend preparation upper bound is O(M^(1/2)). The old eligible regime still has its old O(M^(1/8)) split-table preparation bound.

This accepts a sufficient new guard and a paper-level algorithm. It does not establish an optimal guard, a successful real-parameter table build, a production executor, fixed-hardware performance, a practical crossover, a new bit-complexity theorem, or historical priority. It makes no claim about ALG-033's invalid sampler/aggregator.

## 1. Source contract used

The unchanged source chain is included as inert text under sources/:

1. PACKED_DYADIC.md, SHA-256 bb40decffd28b87a88065880363ff099b0d22071ef976bc67a8195c9b9db6d6f, especially Sections 2-8 and Appendix A.
2. Its FROZEN_PROOF_REVIEW.md acceptance, SHA-256 c8ccac0e576240c4b95dc9f9a58829b0fd33c17062526c5e19324a1a6156fb28.
3. SPLIT_TABLE_CONSTRUCTION.md, SHA-256 be8de35159ed47f2a5d0bad71937d83bb7053ef83ae6ce358c0dfd80add78ded, especially Sections 1-6.
4. Its SPLIT_TABLE_INDEPENDENT_REVIEW.md acceptance, SHA-256 7aa359016f6d51108c1c8c0dfdbc61b770d9865616b1cbae179b8475f569c89d.
5. PACKED_ALL_LENGTH.md, SHA-256 71d85d704058bd245d14ce5aad65f747cb1a5b038e69510b21b41d3c8a217927, especially Sections 1-3 and the independently charged scalar fallback in Section 4.
6. Its PACKED_ACCEPTANCE.md acceptance, SHA-256 cbd6224db8650509c18acc6658dadbc5b491dcb9f0d711829c2cc8c1c3545dcd.

The original interpolation source is also included for the inherited common-lattice and short-sum interface. All seven copied source hashes were recomputed; no predecessor program was executed, imported, or compiled. The present review is source-bound to the author's final additive proof and archive, not to a mutable title or an unreviewed future revision.

For 2 <= T <= v+1, the retained parameters are

    p = T+10+ceil(log2(v+1)), u = 2^-p,
    E = 2v+p+5, k = ceil(log2(E+1)), b = 2(p+k+1),
    e_min = -v-p, e_max = v+4, tau = 2^(-v-p),
    g = p+10, Q = 2^g, R = 2^b, S = R^P, d = log2(P).

The exponent interval contains exactly E representable exponent values; k bits suffice because E < 2^k. Malformed exponent fields remain total zero decodings. One complex state still has exactly b bits. Changing a guard or a packing parameter does not shrink the exponent field, drop a sign bit, reduce p, or change an unreachable clipping response.

## 2. Packing, addresses, and carry capacity

When the new guard holds, p < b/2 <= v/16. For the P=2 branch, 8b<=v gives 2bP=4b<=v/2. For the second branch the old stronger inequality 2bP<=v/8 applies. Both branches therefore satisfy

    P >= 2, P a power of two, P > v/(32b),
    bP <= v/4, 2bP <= v/2.

At v=32b the second branch selects P=2, so there is no boundary discontinuity that leaves P undefined. At and beyond v=64b the second branch is exactly the old rule. The array is still divisible into P-lane words because M is a power of two and d<=v.

The split unary response occupies bP bits. Its flattened key has at most g+bP bits, bounded by 5v/16+10. A Hadamard pair key and response have at most 2bP<=v/2 bits. Scalar helper keys have g+b or 2b bits, at most 3v/16+10 or v/4. Small-stage addresses add only O(log v) bits. Catalogue initialization can compute Q(Ph+l) with at most 2g+d bits; this is O(v). Runtime phase identification retains the proved shift/add formula with exactly Q-1 catalogue rows, including long spans r>g.

The original sufficiently large, fixed w=C(c)(v+1) word contract therefore still contains these objects. Accepted allocations are capped at M preparation words, so arena bases and live addresses use v+O(1) bits. Pre-abort size checks remain possible with arithmetic saturated at M+1, and proposed offsets already have O(v) bits. No unbounded address multiplication or new word-size dependence is introduced.

The Cartesian construction lemma remains applicable at P=2. A pair digit is radix R^2, and its two separated b-bit fields together partition the dense 2bP-bit key. Replacing a digit clears and ORs disjoint masked fields; it does not add values across lanes. A carry in the odometer triggers explicit resets and field replacements. Every output state is re-encoded after the total quantizer, so no wider intermediate is silently stored in a b-bit lane. Pair outputs occupy exactly 2b bits before packing. The proof's digit-change bound below 2D^m pays every carry/reset and every actual-key write.

Exact arithmetic inside scalar preparation is separate from packed-field arithmetic. A decoded state has common denominator 2^(v+2p), magnitude below 32M, and numerator length at most 2v+2p+O(1). Multiplication by a retained p+10-bit dyadic coefficient, or the scaled sum in H, requires at most 2v+3p+O(1) numerator bits after alignment. This remains O(v), including unreachable but valid codes and the extra carry from addition. The previously allowed fixed-word routines and leading-bit chunk table suffice. Polynomial-bit rational coefficient certificates retain their full elementary multiword charge.

## 3. Paid preparation, fallback, and uniformity

The exact scalar-helper-inclusive response count is unchanged:

    E_new = S^2 + (Q-1+d)S + QR + R^2.

The complete Cartesian expansion costs O(E_new), including O(P) initialization per pattern/stage and explicit scalar helper reads. The scalar helpers cost O(QR+R^2). All Q coefficient certificates are separately charged at Q poly(v+p); no coefficient or table response is an oracle. The leading-bit table costs O(2^floor(v/8)), with the inherited bounded small-v handling.

Throughout the new eligible domain,

    S^2 <= 2^(v/2),
    QS <= 2^(5v/16+10),
    QR <= 2^(3v/16+10),
    R^2 <= 2^(v/4),
    dS <= O(log v) 2^(v/4),
    Q poly(v+p) <= 2^(v/16+10) poly(v).

Every term besides S^2 has a strict exponential gap from 2^(v/2). Fixed coefficients and fixed polynomial degrees are absorbed uniformly, giving unbudgeted backend preparation work and space O(2^(v/2))=o(M). This is a backend bound; the all-length wrapper's own N^(1/4)poly(n+t) and 2^t(t+1)^2 poly(n+t) preparation terms remain charged.

The literal M-instruction/M-word preparation cap is still essential. It counts certificate arithmetic, enumeration, accesses, budget checks, and scratch allocations before use. Completion uses only fully built tables. Failure discards or reuses partial storage at O(M) cost and runs the certified scalar fallback. The asymptotic proof supplies one absolute finite threshold beyond which eligible builds finish; it does not identify that threshold with the first parameter-guard pass or a cardinality-cap pass.

Execution costs O(M+Mv/P)=O(Mb), since P>v/(32b). Initial scan, normalization, quantization, bit reversal, packing, loop controls, table accesses, output decoding, restoration, and M output writes retain their charges. If 8b>v, scalar work O(Mv) is below 8 O(Mb). If an eligible build aborts, v lies below one fixed finite threshold; its fully charged scalar cost is again O(Mb) with a uniform, possibly enormous constant. Thus the broader guard preserves the full uniform theorem, rather than merely an eventual fast subsequence.

## 4. Error and all-length contract

The scalar split butterfly remains

    (a,b) -> q(H_hat(a, q(c_q b))).

Its two quantization sites, certified phase error below u/128, scale error at most u/1024, total decoding, and clipping behavior are unchanged. P changes grouping and preparation only. The catalogue identity supplies the same phase index to every DIT butterfly; small-stage tables implement disjoint scalar butterflies in one lookup. P=2 is covered without any additional numerical assumption.

The accepted split proof therefore retains stage error at most 3u||z||+2sqrt(2M)tau and the J=v+1 recurrence giving relative error at most 22uJ <= (22/1024)2^-T. Both candidate first-clipping sites remain below 2sqrt(2M)<32M, using only the already-controlled prefix and the quantizer's norm-nonincreasing property. None of these inequalities used 64b<=v or P>=4. The output lattice stays 2^(-v-2p)Z[i] before scale restoration, with O(v+p)-bit numerators and constant-word decoding.

The all-length wrapper still calls this backend once at T=t+10 and tests its precision domain explicitly. Its spectral interpolation error proof requires only the retained all-input certificate and output representation; it never assumes the rounded backend is linear. The short exact sums retain their old carry/width accounting. The independently certified scalar Bluestein fallback remains the all-length fallback. The deterministic all-input theorem and absence of any failure-probability premise are unchanged.

## 5. Finite eligibility versus practicality

At wrapper target t=2 the backend target is T=12. Exact integer evaluation gives the first new guard pass at

    v=704, p=32, k=11, b=88, P=2, g=42.

All smaller eligible-domain v fail 8b<=v. The response/helper table count is exactly

    E_new = 2^352 + 2^218 + 2^176 + 2^130,
    2^352 < E_new < 2^353.

The smallest all-length N producing M=2^704 is N=2^701+1, at which n=702. The wrapper's displayed structural guards all hold. No successful coefficient/table construction within either literal preparation cap has been established there.

For comparison, the old wrapper guard first passes at v=6400. Direct dyadic precision T=2 has its own new guard minimum v=544; it must not be confused with the wrapper's T=12. The fresh results file records further precision cases.

For fixed T=12 and forced P=1,2,4, the exact inequality E_new<=2^v first holds at v=162,337,705 respectively. These are response-cardinality-only necessary tests. They do not count all coefficient, leading-bit, scratch, or operation costs; they do not establish an admissible branch, and P=1 is outside the proposed rule. In particular they do not make v=337 a proved successful P=2 executor. The new sufficient guard remains conservative.

HP alone has 2^(2bP) entries and additional arrays are positive, so the literal M-word cap necessarily requires 2bP<v, strictly. For fixed (v,T), E_new is nondecreasing along power-of-two P. Consequently no P>=2 choice in this exact complete-table design can pass its entry-count cap at T=12 and v<337. This is a design-specific obstruction; coefficient or instruction costs can only strengthen it. The P=1 comparison also confirms that every admissible v<=128 fails the unchanged T=12 cardinality test, even before genuine packing is required.

Even the improved v=704 catalogue exceeds 2^352 model words. No practical speedup or fixed 64/128-bit realization follows. These are exact symbolic eligibility and storage calculations, not measured runtimes or allocated arrays.

### Numerical slack observations, not adopted variants

The draft's two separate precision observations are algebraically correct. If only the displayed backend recurrence is considered, p=T+5+ceil(log2 J) would give 22uJ <= (22/32)2^-T, with 3uJ<1/2. If wrapper coefficients retain rho=2^-(t+10), its error decomposition with a generic backend tolerance 2^-T is 6*2^-T+16rho. Thus T=t+3 gives exactly (49/64)2^-t as the stated upper bound; the pre-output norm remains below twice the input norm for t>=2.

These observations do not modify the accepted parameter schedule. They would change state widths, coefficient/state tables, output lattices, branch domains, or the actual rounded program and need their own frozen source-bound treatment. This review accepts their classification as numerical slack and accepts neither altered-precision executor. The unchanged +10 constants are used for every reported guard and cardinality threshold.

## 6. Fresh independent controls and their limits

Only fresh_parameter_controls.py was authored and executed for this review. It uses Python's standard library and reads source files solely as inert bytes for hashing. It independently passed:

- 8,390,656 finite-domain (v,T) parameter checks through v=4096, including 385,821 new-eligible cases and their width/packing inequalities.
- 841,533 old-eligible instances through v=20000 and T<=128, all preserving the exact old P.
- 57,008 exact lane/catalogue identities, including newly permitted P=2 and long spans beyond the phase-grid depth.
- 66,064 complete synthetic separated-field Cartesian entries and 70,524 explicit odometer digit changes, checking unique dense-key coverage, payload width, and the charged carry bound.
- Exact rational local-error constants, the stated guard minima, three cardinality-only minima, and wrapper structural checks at N=2^701+1.

The finite controls are falsification checks. They do not prove the all-size theorem, certify a transcendental implementation, execute the author's program, allocate theorem-sized response tables, or establish practical performance. The all-size acceptance rests on the source-bound argument above and the unchanged accepted numerical/representation contract.

## 7. Existing-row disposition

Record this as an independently accepted additive guard/packing refinement of Q01 and its existing Fourier entry, if an authorized consolidator elects to update those rows. Preserve the old source versions, proof-level status, deterministic scope, supplied-precision limitation, and implementation/priority gates. Do not create a separate algorithm identity or characterize this as a repair of ALG-033. No Sheet or GitHub write was performed by this reviewer.
