# Q01 two lane guard extension

11 October 2026 UTC. Candidate for independent review. No new transform-time order, numerical executor, successful-build threshold, practical crossover, or priority claim.

## Main result

The accepted split-table backend can keep its numerical map, precision, coefficients, complete tables, word model, and literal preparation budgets while replacing the conservative guard `64b <= v` by `8b <= v`. Use two lanes in the newly admitted short-packing range; retain the original packing everywhere it was already defined with at least two lanes. A sufficient, fully charged proof follows below.

For the unchanged all-length request `t=2`, the backend still receives `T=t+10=12`. The new guard first passes at backend exponent `v=704`, versus `v=6400` for the frozen guard. This only permits a budgeted build attempt. At the new guard threshold the mandatory split tables still contain strictly between `2^352` and `2^353` model words. The construction remains impractical at that threshold, and successful completion of either literal preparation budget has not been demonstrated there.

All old accepted sources remain unchanged. This candidate extends one branch rule and packing schedule. It is pending source-bound independent review.

## Frozen sources and notation

Write `D=2^v` for the dyadic backend length, reserving `N` for the original all-length input. The backend accuracy input is `T`, with `2 <= T <= v+1`. The sources are:

- `sources/PACKED_DYADIC.md`, SHA-256 `bb40decffd28b87a88065880363ff099b0d22071ef976bc67a8195c9b9db6d6f`.
- `sources/SPLIT_TABLE_CONSTRUCTION.md`, SHA-256 `be8de35159ed47f2a5d0bad71937d83bb7053ef83ae6ce358c0dfd80add78ded`.
- Its exact independent acceptance `sources/SPLIT_TABLE_INDEPENDENT_REVIEW.md`, SHA-256 `7aa359016f6d51108c1c8c0dfdbc61b770d9865616b1cbae179b8475f569c89d`.
- `sources/PACKED_ALL_LENGTH.md`, SHA-256 `71d85d704058bd245d14ce5aad65f747cb1a5b038e69510b21b41d3c8a217927`.
- Exact original acceptances and prior scope notes are included in `sources/` and pinned in `SOURCE_PINS.json`.

These exact bytes were present in the Q01 dependency-audit archive, Library `libfile_2d9b0c7d214081918a01bd6bb51f3a2f`, whose SHA-256 was independently recomputed as `1045092a472d7e171b5befc9ff61c08b135c5adc083db07a80828bd6817051e1`. Repository paths and Git blob identities are preserved in `sources/PRIOR_SOURCE_PROVENANCE.json`.

Retain, without modification,

    p = T + 10 + ceil(log2(v+1)),    u = 2^-p,
    e_min = -v-p,                   e_max = v+4,
    tau = u/D,                     E = 2v+p+5,
    k = ceil(log2(E+1)),            b = 2(p+k+1),
    g = p+10,                      Q = 2^g,
    R = 2^b,                       S = R^P,   d = log2(P).

Retain the exact accepted coefficient certificates, total decoder/quantizer, malformed-code semantics, scalar helpers F and H, complete Q-1 phase catalogue, Cartesian expansion, normalized radix-2 DIT stages, common output lattice, bit reversal, final decoding, and certified scalar fallback. Retain the address-capable RAM word width `w=C(c)(v+1)` with the same sufficiently large fixed constant and actual multiword certificate charges. This proposal neither shrinks precision nor charges Python big integers as RAM words.

## The one proposed branch and packing change

Use this rule in place of the frozen low-b guard and its packing selection:

    If 8b > v, select the unchanged scalar fallback.
    If 8b <= v < 32b, set P=2.
    If 32b <= v, choose the largest power of two P <= v/(16b).
    Attempt the unchanged split-table construction with literal
      D-instruction and D-word preparation caps.
    Count every elementary instruction and allocation before executing it.
    On failure, discard/reuse the partial build and use the scalar fallback.
    Only a completed build is eligible for execution.

The first two cases ensure P exists and is a genuine two-lane packing. The third includes equality `v=32b`, at which P=2. In every attempted instance:

    P >= 2,
    P > v/(32b),
    2bP <= v/2,
    p <= b/2 <= v/16.

For `v<32b`, these follow from P=2 and `8b<=v`; the strict lower packing inequality is especially weak because `v/(32b)<1`. For `v>=32b`, maximal power-of-two rounding gives `P>v/(32b)`, and the stronger original `2bP<=v/8` applies.

In particular, throughout the OLD guard domain `64b<=v`, the new schedule chooses exactly the OLD P. It does not enlarge old response arrays, change the arithmetic ordering, or replace successful old-domain executions with a different numerical program. The formerly unused range `32b<=v<64b` already admits the original P=2 construction. Only `8b<=v<32b` needs a larger key-width allowance.

## Sufficient mathematical and machine proof

### Total tables and exact numerical semantics

The accepted table construction and phase-index identity require a positive power-of-two P with legal packed fields; they do not require P>=4. With P=2, its small-stage table has one disjoint butterfly (`P/2=1`), the Cartesian radix remains a power of two, and all key bits remain densely partitioned. Every other stage uses the same two scalar operations

    (a,b) -> q(H_hat(a, q(c_phase * b))).

Changing where whole disjoint butterflies lie inside words cannot change their inputs, coarse phase `floor(Q j/L)`, arithmetic or rounding sites. The catalogue identity remains exact for every P: if `r=ell-d>g`, write `a=2^(r-g)h+c`; the residual `(Pc+lane)/(P*2^(r-g))` is in [0,1), so the phase is h, including boundary lanes. Thus execution at any allowed P realizes the identical split-rounded radix-2 map. No hidden linearity of rounding is used.

Consequently the accepted all-input error proof is literally unchanged: for `J=v+1`, including input quantization,

    relative error <= 22 u J <= (22/1024) 2^-T < 2^-T.

Both possible first-clipping sites remain covered. Output states still lie on `2^(-v-2p) Z[i]` with the same constant-word decoding and O(v+p)-bit numerators.

### Words, addresses, and preparation

Packed keys/responses now have at most v/2 bits in the newly admitted range. The original address-capable word already holds v-bit addresses; no larger RAM word or new instruction is requested. The old scalar helper arithmetic has unchanged O(v+p)-bit operands and already fits its fixed number of original words. Coefficient certification still uses its separately charged polynomial-bit arithmetic.

Before any build, the full size calculation may be saturated at D+1. Before passing that cap, candidate unary addresses have at most `g+bP <= 5v/16+10` bits, scalar F addresses at most `g+b <= 3v/16+10`, and HP keys at most v/2 bits. These are O(v)-bit computations using the already specified fixed-word arithmetic. After the allocation cap passes, actual arena addresses have at most v+O(1) bits. The construction never allocates an oversized table and never executes a partial table.

Retain the exact entry count, with all scalar helpers explicitly paid:

    E_new = S^2 + (Q-1+d)S + QR + R^2.

The accepted Cartesian expansion gives actual unbudgeted preparation

    O(E_new + 2^h + Q poly(v+p)),   h=max(1,floor(v/8)),

plus O(P)+poly(v+p) scratch; no P factor is charged for every packed entry. On the new entire guard domain:

    S^2 <= 2^(v/2),       QS <= 2^(5v/16+10),
    QR <= 2^(3v/16+10),   R^2 <= 2^(v/4),
    dS <= log2(v) 2^(v/4),
    Q <= 2^(v/16+10),     2^h <= 2 * 2^(v/8).

Here P<=v and p=O(v), with fixed constants. Strict exponential gaps absorb the fixed coefficient polynomial, scratch polynomial, and logarithm uniformly over all eligible T. Therefore unbudgeted preparation work and space are `O(D^1/2)=o(D)`. This is a weaker preparation exponent than the accepted `O(D^1/8)` bound, deliberately traded for wider eligibility. The old parameter domain still retains its old tighter bound. No all-length `O(N^1/2)` preparation claim is inferred; its own wrapper preparation remains separately charged.

There is consequently one finite implementation-dependent threshold after which every eligible build meets both literal D budgets. Its numerical value is not provided by asymptotic notation. The actual program tests the budgets, not that unknown threshold.

### Uniform cost, including failures

As before, small stages cost D/P updates, large stages D/(2P) pair updates, and conversions and writes cost O(D). Since `P>v/(32b)`, successful execution costs `O(D+Dv/P)=O(Db)`. Successful and aborted capped builds cost O(D), including bookkeeping and cleanup.

If the new guard fails, `v<8b`, so the already charged scalar cost O(Dv) is O(Db). If an eligible build aborts, the uniform preparation estimate proves v lies below one fixed finite threshold; its O(Dv) fallback is again O(Db), with one uniform constant. Space remains O(D). Because `b=Theta(T+log(v+1))`, this is the unchanged cold bound `O_c(D(T+log(v+1)))`.

Every supplied T=o(v) eventually lies in the old guard domain and therefore uses the same eventual parameters as the accepted construction. This candidate establishes no stronger transform-time order or new low-precision asymptotic regime.

### All-length interface

The all-length compiler still requests `M=nextpow2(4N)`, `T=t+10` and the original p. Every backend interface requirement is preserved. The compiler's explicit precision-domain and stencil guards, its own N-instruction/N-word build cap, and its independent Bluestein fallback remain unchanged and charged. Its deterministic all-input error and cold `O_c(N(t+log log N))` theorem therefore remain available, pending review of this extension. There is no ALG-033 sampling or failure-probability premise.

## Exact finite eligibility and cardinality results

The fresh integer controls exhaust every smaller admissible v for each displayed first-pass value. They allocate no response table and establish no successful-build threshold.

| All-length t | Backend T | Frozen first guard v | New first guard v | New p | New k | New b | P | Exact interval for E_new |
|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 2 | 12 | 6400 | 704 | 32 | 11 | 88 | 2 | 2^352 < E_new < 2^353 |
| 8 | 18 | 7168 | 800 | 38 | 11 | 100 | 2 | 2^400 < E_new < 2^401 |
| 16 | 26 | 8448 | 928 | 46 | 11 | 116 | 2 | 2^464 < E_new < 2^465 |
| 53 | 63 | 13184 | 1552 | 84 | 12 | 194 | 2 | 2^776 < E_new < 2^777 |

For the first row, `Q=2^42`, `R=2^88`, `S=2^176`, d=1, and the count is exactly

    E_new = 2^352 + 2^218 + 2^176 + 2^130.

The smallest original length producing this backend exponent is `N=2^701+1`. Its elementary wrapper guards hold; the wrapper and backend build budgets are both still unverified there. At a different length, a smaller absolute table count does not by itself compare runtimes. The original direct dyadic T=2 guard changes from 5120 to 544; it must not be substituted for the wrapper's T=12 result.

## What is slack and what constrains this design

### Proof slack that this candidate actually removes

The constants 64, the demand for P>=4, and the v/8 key-width allowance are conservative sufficient choices. They provide an especially small preparation exponent; none is used by the split map's error argument, catalogue identity, or Cartesian construction. The new schedule removes only those restrictions, retaining them wherever the old branch was eligible.

### Numerical slack diagnosed but not changed here

The +10 in p is not an intrinsic precision lower bound. The displayed recurrence `22uJ` would already meet the backend tolerance with `p=T+5+ceil(log2 J)`; `22/32<1`, and all smallness inequalities used by that recurrence still hold. Applying that change would alter state widths and the actual rounded program and requires those changes to be bound and checked. This candidate leaves it unchanged.

The wrapper's +10 backend request also contains error-budget slack. With its own coefficients still prepared at `rho=2^-(t+10)`, the same decomposition reads `6*2^-T + 16rho`. Thus `T=t+3` would satisfy the error estimate because `6/8+16/1024=49/64<1`; the pre-output norm also stays below 2 times the input norm for t>=2. That observation concerns the numerical estimate, not a second implemented parameter variant. The present candidate retains T=t+10, the compiler's original guard, and its exact output-lattice interface.

The logarithmic precision overhead and exponent bits are necessary to use the current stated recurrence and current fixed encoding, respectively; neither is a lower bound for all FFT algorithms. Specifically k is the smallest fixed exponent-field width covering E valid fields plus zero, and b is exactly two signed p-fraction/k-exponent component fields. The exponent interval is itself conservative relative to reachable norms. Revising that interval, changing phase accuracy, compressing only reachable states, deduplicating rows, or evaluating responses lazily would change this design and is not done here.

### Exact remaining bottleneck certificate

For this literal fully enumerated split-table design, HP alone has `S^2=2^(2bP)` one-word entries, and other positive arrays are also charged. Consequently the D-word preparation cap necessarily requires

    2bP < v.

This is an exact cardinality obstruction, independent of coefficient routine constants. It is not a lower bound for all algorithms or all alternative implementations.

For unchanged backend T=12, exact enumeration of the complete E_new inequality `E_new<=2^v` first succeeds at:

| Fixed P | First v passing entry count alone | p | k | b | Lower table exponent |
|---:|---:|---:|---:|---:|---:|
| 1 | 162 | 30 | 9 | 80 | 161 |
| 2 | 337 | 31 | 10 | 84 | 336 |
| 4 | 705 | 32 | 11 | 88 | 704 |

The P=1 row uses the literal distinct helpers/packed arrays, including duplicate-sized arrays; aliasing them would be a different count. None of these passes pays coefficient storage, certificates, scratch, initialization, or more than one instruction per table entry. Thus none is sufficient for a build. For genuine packing P>=2, E_new is nondecreasing as P increases, so all v<337 are ruled out by table storage alone at T=12. In particular every v<=128 fails even with P=1. At v=128, b=80, so HP alone has 2^160 entries for P=1 and 2^320 for P=2, before other costs.

The remaining interval between the P=2 count gate v=337 and this conservative guard v=704 is not an impossibility result. Further guard tuning could admit attempts there. It would still leave astronomical tables and an unresolved instruction/certificate budget. No unique optimal numerical guard is established: any fixed exponential slack can support an asymptotic argument, whereas literal success depends on actual charged routines.

## Smallest concrete next implementation obligation

Freeze this source and select the already accepted split map. Implement one certified scalar transition `q(H_hat(a,q(c_q b)))` using the specified finite code, exact integer/dyadic operations and certificates, including malformed codes, underflow and clipping. Produce a machine-checkable trace of coefficient interval containment, code/lattice widths, every charged word operation and allocation, and the two distinct rounding sites. Test boundary and cancellation cases against a separate exact rational reference.

Then bind a bounded table-builder to that transition: test the saturated cardinality rejection before allocation, stop before exceeding either budget, expose no partial table, and verify the certified fallback result after forced budget exhaustion. Exhaustive small-state controls must be labelled toy controls; the theorem's actual eager table at v=704 has not been built. This is the smallest executable seam that would advance the current fidelity/cost gate. Another guard inequality, stochastic sample, or uncharged native FFT benchmark would not establish it.

## Evidence limits

Only the freshly authored `fresh_guard_controls.py` is executed for this candidate. Sources and all predecessor programs remain inert. The controls use exact integer/rational arithmetic for parameters and inequalities and finite exact phase-layout checks. They do not simulate a faithful RAM executor, implement transcendental certification, time FFTs, or claim empirical speed. The infinite-size conclusions above are analytical proofs, not consequences of finite enumeration. Sheet and GitHub writes were not performed.
