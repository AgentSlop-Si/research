#!/usr/bin/env python3
"""Independent exact controls; never execute or import any supplied program."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent

def clog2(x):
    assert x > 0
    return (x - 1).bit_length()

def parameters(v, T):
    p = T + 10 + clog2(v + 1)
    k = clog2(2*v + p + 6)
    b = 2*(p + k + 1)
    return p, k, b, p + 10

def selected(v, b):
    assert 8*b <= v
    if v < 32*b:
        return 2
    return 1 << ((v // (16*b)).bit_length() - 1)

def table_count(v, T, P):
    p, k, b, g = parameters(v, T)
    R, S, Q = 1 << b, 1 << (b*P), 1 << g
    d = P.bit_length() - 1
    return S*S + (Q - 1 + d)*S + Q*R + R*R

def guard_threshold(T, factor):
    v = max(1, T - 1)
    while factor * parameters(v, T)[2] > v:
        v += 1
    return v

def cap_threshold(T, P):
    v = max(1, T - 1)
    while table_count(v, T, P) > (1 << v):
        v += 1
    return v

def parameter_checks():
    total = eligible = old_preserved = 0
    for v in range(1, 4097):
        for T in range(2, v + 2):
            total += 1
            p, k, b, g = parameters(v, T)
            if 8*b > v:
                continue
            eligible += 1
            P = selected(v, b)
            d = P.bit_length() - 1
            assert P >= 2 and P & (P-1) == 0
            assert 32*b*P > v
            assert 4*b*P <= v
            assert 16*p <= v
            assert 16*(g+b*P-10) <= 5*v
            assert 16*(g+b-10) <= 3*v
            assert 8*b <= v and 8*b*2 <= 2*v
            # Prove the sizes symbolically in bits; no theorem-sized arrays.
            assert 2*b*P <= v//2
            assert b*P <= v//4
            # Catalogue numerator Q*(P*h+l) is smaller than 2^(2g+d).
            assert 2*g + d < 2*v
            if 64*b <= v:
                old_P = 1 << ((v // (16*b)).bit_length() - 1)
                assert P == old_P
                old_preserved += 1
    # The first old-eligible case is beyond 4096. Check a separate rectangle.
    for v in range(1,20001):
        for T in range(2,min(v+1,128)+1):
            b = parameters(v,T)[2]
            if 64*b <= v:
                old_P = 1 << ((v // (16*b)).bit_length() - 1)
                assert selected(v,b) == old_P
                old_preserved += 1
    return dict(parameter_pairs=total, eligible_pairs=eligible,
                old_eligible_packing_preserved=old_preserved,
                old_preservation_range='1<=v<=20000, 2<=T<=min(v+1,128)',
                maximum_v=4096)

def phase_checks():
    checks = 0
    for P in (2,4,8):
        for g in range(1,9):
            Q = 1 << g
            for r in range(1,g+4):
                s = min(r,g)
                for a in range(1 << (r-1)):
                    h = a >> max(r-g,0)
                    ident = (1 << (s-1)) - 1 + h
                    assert 0 <= ident < Q - 1
                    for lane in range(P):
                        actual = Q*(P*a+lane)//(P*(1<<r))
                        catalogue = Q*(P*h+lane)//(P*(1<<s))
                        assert actual == catalogue
                        checks += 1
    return checks

def odometer_checks():
    writes = changes = 0
    for b, P in ((1,2),(2,2),(1,4),(2,4)):
        R, D = 1 << b, 1 << (2*b)
        mask = R - 1
        digits = [0] * P
        def fields(i, digit):
            return ((digit & mask) << (b*i)) | ((digit >> b) << (b*(P+i)))
        def local(digit):
            a, z = digit & mask, digit >> b
            return ((a+z) & mask) | (((a-z) & mask) << b)
        key = out = 0
        visited = set()
        local_changes = 0
        for number in range(D**P):
            assert key not in visited
            visited.add(key)
            direct = 0
            for i in range(P):
                direct |= fields(i, local(digits[i]))
            assert out == direct
            assert key < (1 << (2*b*P)) and out < (1 << (2*b*P))
            writes += 1
            if number + 1 == D**P:
                break
            i = 0
            while True:
                clear = fields(i, D-1)
                digits[i] = (digits[i] + 1) % D
                key = (key & ~clear) | fields(i, digits[i])
                out = (out & ~clear) | fields(i, local(digits[i]))
                local_changes += 1
                if digits[i]:
                    break
                i += 1
        exact = sum((D**P-1)//D**i for i in range(P))
        assert local_changes == exact < 2*D**P
        assert len(visited) == (1 << (2*b*P))
        changes += local_changes
    return dict(writes=writes, digit_changes=changes,
                tests='synthetic total pair maps with separated input/output fields')

def main():
    thresholds = []
    for T in (2,8,12,16,18,26,53,63):
        v = guard_threshold(T,8)
        p,k,b,g = parameters(v,T)
        P = selected(v,b)
        E = table_count(v,T,P)
        thresholds.append(dict(T=T,new_v=v,old_v=guard_threshold(T,64),
            p=p,k=k,b=b,g=g,P=P,
            lower_table_exponent=E.bit_length()-1,
            upper_table_exponent=E.bit_length(),
            exact_table_count=str(E)))
    assert guard_threshold(12,8) == 704
    assert parameters(704,12) == (32,11,88,42)
    expected = (1<<352)+(1<<218)+(1<<176)+(1<<130)
    assert table_count(704,12,2) == expected
    caps = {str(P): cap_threshold(12,P) for P in (1,2,4)}
    assert caps == {'1':162,'2':337,'4':705}
    # All wrapper structural tests at the smallest N with v=704.
    N = (1<<701)+1
    n = clog2(N+1)
    t,T,s,h = 2,12,18,289
    M = 1 << clog2(4*N)
    assert M == 1<<704 and n == 702
    assert t*4 <= n and T <= 705 and M >= 16*s and 2*h+2 < M
    # Exact sufficient local constants retained from the split source.
    u = Fraction(1,4)
    bracket = (1+u/512)*(1+Fraction(5,512)) + Fraction(1,512) + 1+u/32
    assert bracket == Fraction(2118149,1048576) < 3
    assert (1+u/512)**2 < 2
    assert Fraction(22,1024) < 1
    assert Fraction(22,32) < 1 and Fraction(3,128) < Fraction(1,2)
    assert Fraction(6,8)+Fraction(16,1024) == Fraction(49,64) < 1
    result = dict(status='PASS', supplied_code_executed=False,
        literal_eager_executor_built=False,
        thresholds=thresholds, cardinality_only_thresholds_T12=caps,
        wrapper_minimal_N='2^701+1', wrapper_n=702,
        first_guard_table_formula='2^352+2^218+2^176+2^130',
        finite_parameters=parameter_checks(),
        phase_catalogue_lane_checks=phase_checks(),
        cartesian_controls=odometer_checks(),
        local_error_bracket=str(bracket),
        source_hashes={str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                       for p in sorted((ROOT/'sources').glob('*.md'))})
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
