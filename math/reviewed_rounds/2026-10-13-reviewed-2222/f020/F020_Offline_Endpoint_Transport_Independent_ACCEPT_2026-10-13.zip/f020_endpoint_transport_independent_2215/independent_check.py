#!/usr/bin/env python3
"""Independent F020 audit. Candidate and historical programs are never imported/run.

Polynomials are immutable sets of exponents, rather than candidate bit arithmetic.
Gaussian coefficients use [r,k]=[r-1,k-1]+q^k[r-1,k].
Only the three specified symbolic certificates are computed; larger controls
check identities, not a new endpoint/collision census.
"""
import hashlib
import json
import pathlib
import sys
import zipfile
from functools import lru_cache

Z = frozenset()
ONE = frozenset({0})
Q = frozenset({1})
COUNT = 0

def check(condition, label):
    global COUNT
    COUNT += 1
    if not condition:
        raise AssertionError(label)

def add(a, b):
    return a ^ b

def shift(a, k):
    return frozenset(x + k for x in a)

def mul(a, b):
    out = Z
    for x in a:
        out ^= shift(b, x)
    return out

def divmodp(a, b):
    if not b:
        raise ZeroDivisionError
    quotient = Z
    r = a
    while r and max(r) >= max(b):
        k = max(r) - max(b)
        quotient ^= frozenset({k})
        r ^= shift(b, k)
    return quotient, r

def rem(a, b):
    return divmodp(a, b)[1]

def gcd(a, b):
    while b:
        a, b = b, rem(a, b)
    return a

def power(a, k, modulus=None):
    r = ONE
    while k:
        if k & 1:
            r = mul(r, a)
            if modulus is not None:
                r = rem(r, modulus)
        a = mul(a, a)
        if modulus is not None:
            a = rem(a, modulus)
        k >>= 1
    return r

def rev(a, deg):
    return frozenset(deg - x for x in a)

def mask(a):
    return hex(sum(1 << x for x in a))

def unmask(s):
    x = int(s, 16)
    return frozenset(i for i in range(x.bit_length()) if (x >> i) & 1)

@lru_cache(None)
def gaussian_row(r):
    if r == 0:
        return (ONE,)
    previous = gaussian_row(r - 1)
    return tuple(add(previous[k-1] if k else Z,
                     shift(previous[k], k) if k < r else Z)
                 for k in range(r + 1))

@lru_cache(None)
def endpoint(j):
    # H'_(2j+1)(1), from the original Gaussian polynomial definition.
    out = Z
    for k, c in enumerate(gaussian_row(2*j + 1)):
        if k & 1:
            out ^= c
    return out

def products(j):
    c, d = ONE, ONE
    for r in range(1, j+1):
        c = mul(c, frozenset({0, 2*r}))
        d = mul(d, frozenset({0, 2*r-1}))
    return c, d

def fg(j):
    e = endpoint(j)
    es = rev(e, j*(j+1))
    c, _ = products(j)
    return add(power(e, 8), shift(power(c, 8), 1)), add(shift(power(es, 8), 1), power(c, 8))

def support(j):
    out = ONE
    for r in range(j+1):
        out = mul(out, frozenset({0, 2*r+1}))
    return out

@lru_cache(None)
def phi(d):
    # Exact factorization of q^d+1; for odd d all factors are separable.
    out = frozenset({0, d})
    for e in range(1, d):
        if d % e == 0:
            out, residual = divmodp(out, phi(e))
            check(not residual, 'cyclotomic exact division')
    return out

def prime_divisors(d):
    return [p for p in range(2, d+1) if d % p == 0 and all(p % x for x in range(2, p))]

def sha(data):
    return hashlib.sha256(data).hexdigest()

archive = pathlib.Path(sys.argv[1]).resolve()
target = pathlib.Path(sys.argv[2]).resolve()
source_root = pathlib.Path(sys.argv[3]).resolve() if len(sys.argv) > 3 else None
archive_sha = '6dcafc0ede275e0bbe439400ca3c2fa3f1c246d212a8860d204f8f7f17ebce3d'
check(sha(archive.read_bytes()) == archive_sha, 'pinned candidate archive')
root = 'f020_offline_endpoint_transport_2204/'
with zipfile.ZipFile(archive) as z:
    names = set(z.namelist())
    manifest = json.loads(z.read(root + 'FILE_MANIFEST.json'))
    seal = json.loads(z.read(root + 'SEAL.json'))
    check(sha(z.read(root + 'FILE_MANIFEST.json')) == seal['manifest_sha256'], 'manifest seal')
    check(names == {root + x['path'] for x in manifest} | {root + 'FILE_MANIFEST.json', root + 'SEAL.json'}, 'archive closure')
    for entry in manifest:
        data = z.read(root + entry['path'])
        check(len(data) == entry['bytes'] and sha(data) == entry['sha256'], 'candidate payload ' + entry['path'])
    bindings = json.loads(z.read(root + 'SOURCE_BINDINGS.json'))
    for binding in bindings:
        data = z.read(root + binding['snapshot'])
        check(len(data) == binding['bytes'] and sha(data) == binding['sha256'], 'source snapshot ' + binding['snapshot'])
        if source_root is not None:
            original = source_root / binding['source_path']
            check(original.read_bytes() == data, 'local source identity ' + binding['snapshot'])
    expected = json.loads(z.read(root + 'RESULTS.json'))
    theorem_sha = sha(z.read(root + 'THEOREM_AND_CONTRACT.md'))

source_audit = {'candidate_archive_sha256': archive_sha, 'candidate_theorem_sha256': theorem_sha,
                'candidate_manifest_sha256': seal['manifest_sha256'], 'candidate_payload_files': len(manifest),
                'bound_snapshots': len(bindings), 'local_originals_checked': source_root is not None}
if source_root is not None:
    prior_path = source_root / bindings[2]['source_path']
    prior_base = prior_path.parent
    prior_seal = json.loads(prior_path.read_text())
    prior_manifest_bytes = (prior_base / 'FILE_MANIFEST.json').read_bytes()
    check(sha(prior_manifest_bytes) == prior_seal['manifest_sha256'], 'prior accepted review manifest')
    prior_manifest = json.loads(prior_manifest_bytes)['files']
    for entry in prior_manifest:
        data = (prior_base / entry['path']).read_bytes()
        check(len(data) == entry['bytes'] and sha(data) == entry['sha256'], 'prior review payload ' + entry['path'])
    source_audit['prior_review_bound_files_checked'] = len(prior_manifest)

certificates = []
mutations = {}
for n, entry in enumerate(expected['certificates']):
    e, es = endpoint(n), rev(endpoint(n), n*(n+1))
    c, _ = products(n)
    f, g = fg(n)
    gg = gcd(f, g)
    l = support(n)
    actual = {'E':e, 'Es':es, 'C':c, 'F':f, 'G':g, 'gcd':gg, 'L':l}
    for key, value in actual.items():
        check(mask(value) == entry[key], 'symbolic comparison ' + key)
    u, v, a, b = (unmask(entry[k]) for k in ('u', 'v', 'a', 'b'))
    check(add(mul(u, f), mul(v, g)) == gg, 'exact Bezout gcd')
    check(not rem(f, gg) and not rem(g, gg), 'gcd divides both')
    check(add(mul(a, f), mul(b, g)) == power(l, entry['L_exponent']), 'exact support certificate')
    declared = power(frozenset({0,1}), (1, 8, 16)[n])
    if n >= 1:
        declared = mul(declared, frozenset({0,1,2}))
    if n == 2:
        declared = mul(declared, frozenset({0,1,2,3,4}))
    check(gg == declared, 'claimed gcd factorization')
    check(max(f) == 8*n*(n+1)+1, 'F actual degree')
    # Exact support certificate also proves multiplicity safety.
    _, r = divmodp(power(l, 8*n*(n+1)+1), gg)
    check(not r, 'universal-exponent bound for fixed symbolic instance')
    for key in ('u', 'v'):
        uu, vv = (add(u, ONE), v) if key == 'u' else (u, add(v, ONE))
        bad = add(mul(uu, f), mul(vv, g)) != gg
        check(bad, 'reject changed Bezout coefficient')
        mutations[f'change_{key}_n{n}'] = bad
    certificates.append({**{k:mask(v) for k,v in actual.items()}, 'n':n, 'u':mask(u), 'v':mask(v),
                         'a':mask(a), 'b':mask(b), 'support_exponent':entry['L_exponent'],
                         'all_exact_checks_pass': True})

cases = [(m, n) for m in (1,2,12) for n in (0,1,2)] + [(0,n) for n in (0,1,2)] + [(2,4)]
case_results = []
transport_failures = {k:[] for k in ('omit_alpha_squared', 'wrong_second_alpha', 'fourth_power', 'complement_off_by_one', 'D_fourth_equals_alpha', 'wrong_reversal_degree')}
for m, n in cases:
    d = 2*m + 2*n + 3
    h = (d-1)//2
    modulus = phi(d)
    rr = lambda a: rem(a, modulus)
    mm = lambda *args: rr(__import__('functools').reduce(mul, args, ONE))
    pp = lambda a,k: power(a,k,modulus)
    check(power(Q,d,modulus) == ONE, 'd-th root')
    for p in prime_divisors(d):
        check(gcd(add(power(Q,d//p,modulus),ONE), modulus) == ONE, 'all components exact primitive order')
    derivative = frozenset(i-1 for i in modulus if i&1)
    check(gcd(modulus, derivative) == ONE, 'cyclotomic reduced')
    for j in range(h+1):
        cc, dd = products(j)
        check(gcd(cc,modulus) == ONE and gcd(dd,modulus) == ONE, 'all product unit guards')
    for j in set((m,n,h)):
        ee = endpoint(j)
        check(max(ee) == j*(j+1), 'actual endpoint degree')
        if j:
            _, dj = products(j)
            check(ee == add(dj, mul(frozenset({0,2*j}),endpoint(j-1))), 'Gaussian versus first-order recurrence')
        if j >= 2:
            aj = frozenset({2*j-1,2*j})
            cj = mul(frozenset({0,2*j-1}), frozenset({0,2*j-2}))
            check(ee == add(mul(aj,endpoint(j-1)),mul(cj,endpoint(j-2))), 'Gaussian versus trace continuant endpoint')
    em, en = rr(endpoint(m)), rr(endpoint(n))
    ems, ens = rr(rev(endpoint(m),m*(m+1))), rr(rev(endpoint(n),n*(n+1)))
    cm, dm = map(rr,products(m))
    cn, dn = map(rr,products(n))
    ch, dh = map(rr,products(h))
    invq = power(Q,d-1,modulus)
    evaluate = lambda p,x: __import__('functools').reduce(add, (power(x,k,modulus) for k in p), Z)
    check(evaluate(products(h)[0],invq) == dh and evaluate(products(h)[1],invq) == ch, 'inverse swaps half products')
    check(mm(ch,dh) == ONE and pp(dh,8) == Q and pp(ch,8) == invq, 'half-product eighth-root identities')
    check(evaluate(gaussian_row(d)[0],Q) == ONE and all(rr(a) == Z for a in gaussian_row(d)[1:-1]), 'full Gaussian root specialization')
    check(rr(endpoint(h)) == ONE, 'full endpoint boundary')
    check(add(mm(ch,cn,em),mm(dh,cm,ens)) == mm(cm,cn), 'accepted complementary identity')
    check(add(mm(ch,cm,en),mm(dh,cn,ems)) == mm(cm,cn), 'accepted swapped complementary identity')
    f,g = map(rr,fg(n))
    lhs1, rhs1 = mm(pp(cm,8),f), mm(pp(Q,2),pp(cn,8),pp(ems,8))
    lhs2, rhs2 = mm(Q,pp(cm,8),g), mm(pp(cn,8),pp(em,8))
    check(lhs1 == rhs1 and lhs2 == rhs2, 'two cleared transports')
    check(gcd(gcd(em,ems),modulus) == gcd(gcd(f,g),modulus), 'componentwise common-zero equivalence')
    if n in (0,1,2):
        check(gcd(gcd(em,ems),modulus) == ONE, 'three-line endpoint exclusion')
    changed = {
        'omit_alpha_squared': lhs1 != mm(pp(cn,8),pp(ems,8)),
        'wrong_second_alpha': mm(pp(Q,2),pp(cm,8),g) != rhs2,
        'fourth_power': mm(pp(cm,4),add(pp(en,4),mm(Q,pp(cn,4)))) != mm(pp(Q,2),pp(cn,4),pp(ems,4)),
        'complement_off_by_one': mm(pp(cm,8),rr(fg(n+1)[0])) != mm(pp(Q,2),pp(rr(products(n+1)[0]),8),pp(ems,8)),
        'D_fourth_equals_alpha': pp(dh,4) != Q,
        'wrong_reversal_degree': lhs1 != mm(pp(Q,2),pp(cn,8),pp(mm(Q,ems),8))}
    for k,v in changed.items():
        if v:
            transport_failures[k].append([m,n,d])
    case_results.append({'m':m,'n':n,'d':d,'cyclotomic_modulus':mask(modulus),'E_m':mask(em),'E_m_star':mask(ems),
                         'all_primitive_components':True, 'all_exact_checks_pass':True,
                         'scope':'identity control' if n > 2 else 'identity and stated endpoint line'})

for label, witnesses in transport_failures.items():
    check(bool(witnesses), 'negative control ' + label)
    mutations[label] = {'rejected':True,'witnesses':witnesses}

check(gcd(products(1)[0], phi(1)) != ONE, 'q=1 product guard rejection')
mutations['q1_cannot_be_inverted'] = True
# A primitive ninth root satisfies q^27=1 but is not exact order 27.
check(power(Q,27,phi(9)) == ONE and gcd(products(13)[0],phi(9)) != ONE,
      'lower-order element cannot stand in for exact order 27')
mutations['order9_mislabeled_order27_rejected'] = True
check(fg(0) == (frozenset({0,1}),frozenset({0,1})), 'm0 affine boundary F0 G0')
check(endpoint(0) == ONE, 'm0 endpoint seed')

results = {'status':'INDEPENDENT_CHECKS_PASS','assertions':COUNT,'source_audit':source_audit,
           'certificates':certificates,'identity_controls':case_results,'negative_controls':mutations,
           'candidate_or_historical_programs_executed':False,
           'external_writes':False,'all_m_conclusion_from':'human-reviewed algebraic proof; finite controls only validate interfaces',
           'scope':'Endpoint-only orders d=2m+3,2m+5,2m+7; full gate remains open58, general endpoint open53.'}
target.write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':results['status'],'assertions':COUNT,'result_sha256':sha(target.read_bytes())},sort_keys=True))
