# F020 endpoint transport: independent ACCEPT

The independent verdict and proof audit are in REVIEW.md and VERDICT.json.
INDEPENDENT_RESULTS.json is the local-source audit with 478 exact assertions.
PORTABLE_RESULTS.json and COLD_REPLAY.json record two fresh-directory executions
of the newly authored checker. Only independent_check.py was executed.

The supplied candidate ZIP is copied unchanged under candidate/. Its proof and
source snapshots are inert inputs, not executable dependencies.

Portable replay:

    python independent_check.py candidate/F020_Offline_Endpoint_Transport_Candidate_2026-10-13.zip result.json

For the additional original-path source checks, supply the original workspace as
a third argument. This audits local bytes without importing historical code.

Accepted scope: all-m endpoint-only paired-zero exclusion at exact odd orders
d=2m+3, 2m+5, 2m+7, with the fixed eighth-root complementary affine transport.
Full F020 remains open58; general endpoint remains open53. Completed lemma cap15.
