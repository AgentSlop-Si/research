"""Fresh read-only Q16 result audit. Historical bytes are data, never executed.

Uses only standard-library ZIP/JSON/AST parsing, hashes and fresh integer checks.
No imported, compiled, evaluated or executed candidate/archived program text.
"""
import ast
import collections
import datetime
import fractions
import hashlib
import io
import json
import pathlib
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
PRODUCER = 'Q16_Pinned_Integration_Observer_v2_Execution_Candidate_2026-10-13.zip'
EXPECTED_ARCHIVE = '6130d03f2afeccf2b0a23f6ef8db3faf0e0d1bc99bc00ac8ee1283f6fbacf549'
EXPECTED_RESULT = 'f4842bff0aa524fb1d8dd8a25e3c58b3ebcab182ff86e3533e6b041e52bdcd26'
checks = []
archive_records = []

def check(value, label):
    if not value:
        raise AssertionError(label)
    checks.append(label)

def sha(value):
    return hashlib.sha256(value).hexdigest()

def obj(value):
    return json.loads(value)

def inspect_archive(data, label):
    z = zipfile.ZipFile(io.BytesIO(data))
    names = z.namelist()
    check(len(names) == len(set(names)), label + ': unique archive paths')
    check(all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names), label + ': safe archive paths')
    check(z.testzip() is None, label + ': complete CRC checks')
    manifests = 0
    for name in names:
        if not name.endswith('/MANIFEST.json'):
            continue
        manifests += 1
        prefix = name[:-len('MANIFEST.json')]
        manifest = obj(z.read(name))
        rows = manifest['files'] if type(manifest) is dict else manifest
        check(len(rows) == len({r['path'] for r in rows}), label + ': manifest unique ' + name)
        sealname = prefix + 'SEAL.json'
        if sealname in names:
            seal = obj(z.read(sealname))
            check(seal['manifest_sha256'] == sha(z.read(name)), label + ': sealed manifest ' + name)
        for record in rows:
            contents = z.read(prefix + record['path'])
            check(sha(contents) == record['sha256'] and ('bytes' not in record or len(contents) == record['bytes']), label + ': manifest member ' + prefix + record['path'])
    archive_records.append({'label':label,'sha256':sha(data),'members':len(names),'manifests':manifests})
    for name in names:
        if name.endswith('.zip'):
            inspect_archive(z.read(name), label + '/' + name)
    return z

data = (HERE/'evidence'/PRODUCER).read_bytes()
check(sha(data) == EXPECTED_ARCHIVE, 'producer archive matches parent-pinned digest')
z = inspect_archive(data, PRODUCER)
ep = 'q16_observer_v2_execution_2048/'
cp = 'q16_observer_v2_candidate_2034/'
rp = 'q16_observer_v2_independent_review_2042/'
lp = 'q16_observer_v2_launcher_review_2049/'
candidate_bytes = z.read(ep+'evidence/Q16_Observer_v2_Static_Equivalence_Candidate_2026-10-13.zip')
candidate = zipfile.ZipFile(io.BytesIO(candidate_bytes))
review_bytes = z.read(ep+'evidence/Q16_Observer_v2_Independent_Static_ACCEPT_2026-10-13.zip')
review = zipfile.ZipFile(io.BytesIO(review_bytes))
launcher_review_bytes = z.read(ep+'evidence/Q16_Observer_v2_Launcher_Static_ACCEPT_2026-10-13.zip')
launcher_review = zipfile.ZipFile(io.BytesIO(launcher_review_bytes))
c = obj(candidate.read(cp+'CONTRACT.json'))
hbytes = candidate.read(cp+'integration_harness.py')
h = ast.parse(hbytes)
source = {p['module']:candidate.read(cp+p['path']) for p in c['files']}
source_trees = {name:ast.parse(value) for name,value in source.items()}
result_bytes = z.read(ep+'results/EXECUTION_RESULT.json')
r = obj(result_bytes)
launch = obj(z.read(ep+'LAUNCH_RECEIPT.json'))
receipt = obj(z.read(ep+'POSTEXIT_RESOURCE_RECEIPT.json'))
check(len(result_bytes) == 84807 and sha(result_bytes) == EXPECTED_RESULT, 'exact result length and digest')
check(sha(candidate_bytes) == '207aaa4e8732681f730463957085592635e5ffafd6b97bab92de04dd7eea3fe4', 'exact observer candidate digest')
check(sha(review_bytes) == '759390d50d69a094c66142fa147cea6618e4566d9bba9177c7e21aba125cdb0b', 'exact independent static review digest')
check(sha(launcher_review_bytes) == '3f1d8def3dcdbe0a1bfd0a38188216373695455cdcbffc6854ad7376e9af9caf', 'exact launcher review digest')
check(sha(hbytes) == c['fresh_harness']['sha256'] == '02c7bf20b6c4f5cafa8ecaec74bfe12dd586ecd8cb9087f9179750859499300d', 'executed harness matches static candidate')
check(sha(candidate.read(cp+'CONTRACT.json')) == r['contract_sha256'] == launch['contract_sha256'] == receipt['contract_sha256'] == '7d38025fbfbc8ffb54ccddff5f0ca63ea72d44f4d79e007012c71f17bb103ef0', 'single contract binding across result and receipts')
check(sha(review.read(rp+'REVIEW.md')) == launch['review_sha256'], 'launch binds independent static review text')
runner = z.read(ep+'run_once_with_receipt.py')
check(runner == launcher_review.read(lp+'runner_source.py.txt') and sha(runner) == launch['runner_sha256'] == '2c2282350c103bb7d9a87dae222c0f906ac2c30a9094435b881be5798a491f9f', 'exact static-reviewed launcher')
future = obj(review.read(rp+'FUTURE_EXECUTION.json'))
check(launch['command'] == receipt['command'] == future['command_argv'], 'exact agreed isolated child argv')
check(launch['caps'] == receipt['runtime_caps'] == future['caps'] == c['caps'], 'unchanged installed hard caps')
check(launch['source_pins'] == future['source_files'] == c['files'] and launch['harness'] == c['fresh_harness'], 'launch binds all six sources and harness')
old_contract = obj(candidate.read(cp+'evidence/original_CONTRACT.json'))
for key in ('files','runtime','caps','cases','consumer','rejections','identity_controls','expected_execution','exclusions','scope'):
    check(c[key] == old_contract[key], 'original scientific boundary retained: '+key)
for p in c['files']:
    check(len(source[p['module']]) == p['bytes'] and sha(source[p['module']]) == p['sha256'], 'scientific source pin '+p['module'])
check(r['exclusions'] == c['exclusions'], 'result preserves all frozen exclusions')
check(r['status'] == 'BOUNDED_EXECUTION_PASSED_REQUIRES_INDEPENDENT_REVIEW' and r['historical_execution'] is True, 'producer status accurately remains pending independent review')
check(c['authorization']['received'] is False and c['observer_revision']['execution_authorized'] is False, 'unchanged preparation metadata does not purport to be fresh approval')
check(receipt['exit_code'] == receipt['raw_wait_status'] == 0 and receipt['terminating_signal'] is None and receipt['wall_limit_triggered'] is False, 'normal successful child exit')
check(receipt['retries'] == 0 and receipt['result_json_parse'] == 'PASS' and receipt['scientific_result_exists'] is True, 'one-shot completed result receipt')
check(receipt['scientific_result']['sha256'] == EXPECTED_RESULT and receipt['scientific_result']['bytes'] == len(result_bytes), 'post-exit result byte binding')
check(receipt['scientific_status'] == r['status'], 'post-exit producer status binding')
caps = c['caps']
check(0 <= receipt['full_child_total_cpu_seconds'] < caps['cpu_seconds_soft'], 'complete CPU below original soft cap')
check(abs(receipt['full_child_total_cpu_seconds']-receipt['full_child_user_cpu_seconds']-receipt['full_child_system_cpu_seconds']) < 1e-10, 'complete user/system CPU sum')
check(0 <= receipt['full_child_wall_seconds'] < caps['wall_seconds'], 'complete elapsed time below original cap')
utc_delta = (datetime.datetime.fromisoformat(receipt['finished_utc'])-datetime.datetime.fromisoformat(receipt['started_utc'])).total_seconds()
check(abs(utc_delta-receipt['full_child_wall_seconds']) < .01, 'wall and timestamp duration consistent')
check(receipt['full_child_peak_rss_kib'] == 45412, 'reported Linux RSS highwater retained separately from address space and model storage')

stdout = z.read(ep+'CHILD_STDOUT.log')
stderr = z.read(ep+'CHILD_STDERR.log')
for name,contents in [('CHILD_STDOUT.log',stdout),('CHILD_STDERR.log',stderr)]:
    check(receipt[name] == {'bytes':len(contents),'sha256':sha(contents)}, 'post-exit log binding '+name)
lines = stdout.splitlines(keepends=True)
check(all(x.endswith(b'\n') for x in lines), 'all progress lines complete')
progress = [obj(line) for line in lines]
check(progress == obj(z.read(ep+'PARSED_STAGE_PROGRESS.json')), 'independently parsed progress equals retained parser output')
expected_stages = [('preflight_passed',None),('scientific_start',None),('constructor_module_loaded',None),('constructor_rejections_returned',None),('zero_case_checked','zero_N1'),('zero_case_checked','zero_N17'),('dependencies_loaded',None)]
for case in c['cases']:
    if case['pattern'] == 'zero': continue
    expected_stages.append(('nonzero_case_checked',case['id']))
    if case['pipeline']:
        expected_stages.extend((stage,case['id']) for stage in ['actual_pipeline_start','actual_pipeline_returned','reference_pipeline_start','reference_pipeline_returned','pipeline_pair_checked'])
expected_stages.extend((stage,None) for stage in ['source_controls_start','extra_engine_start','extra_engine_returned','source_controls_returned','final_reconciliation_start','final_reconciliation_returned','result_serialization_start','result_written'])
check([(p['stage'],p['case']) for p in progress] == expected_stages and len(progress) == 34, 'all 34 exact stage/case records in frozen control-flow order')
check(all(set(p)=={'kind','stage','case','elapsed_seconds','user_cpu_seconds','system_cpu_seconds'} and p['kind']=='stage_progress' for p in progress), 'progress has exact declared stage-only schema')
for field,bound in [('elapsed_seconds',receipt['full_child_wall_seconds']),('user_cpu_seconds',receipt['full_child_user_cpu_seconds']),('system_cpu_seconds',receipt['full_child_system_cpu_seconds'])]:
    values = [p[field] for p in progress]
    check(values == sorted(values) and 0 <= values[0] <= values[-1] <= bound, 'nondecreasing progress fits whole-child receipt: '+field)
check(len(lines)<=64 and max(map(len,lines))<=1024 and len(stdout)<=65536, 'progress caps independently verified')
check(receipt['progress'] == {'complete_records':34,'max_line_bytes':max(map(len,lines)),'total_bytes':len(stdout),'within_declared_bounds':True,'malformed_records':[],'last_complete_stage':progress[-1]}, 'complete parser summary independently verified')
check(len(stderr.splitlines()) == 1 and len(stderr) <= 1024, 'single successful stderr summary within cap')
summary = obj(stderr)
check(summary == {'status':r['status'],'contract_sha256':r['contract_sha256'],'assertions':593,'result_path':receipt['scientific_result']['path']}, 'stderr binds the exact completed result')

# Reconcile all sealed post-run source receipts without trusting the boolean alone.
post = obj(z.read(ep+'POSTRUN_PINS.json'))
original_zip = zipfile.ZipFile(io.BytesIO(review.read(rp+'evidence/Q16_Pinned_Integration_Execution_Contract_2026-10-13.zip')))
for p in post['files']:
    container = candidate if p['packet']=='q16_observer_v2_candidate_2034' else original_zip
    check(p['unchanged'] is True and sha(container.read(p['packet']+'/'+p['path'])) == p['sha256'], 'postrun payload pin '+p['packet']+'/'+p['path'])
check(post['all_original_and_v2_frozen_payloads_unchanged'] is True and post['launcher_unchanged'] is True, 'postrun summary consistent with all authenticated payload hashes')
blocker = zipfile.ZipFile(io.BytesIO(z.read(ep+'evidence/Q16_Pinned_Integration_Resource_Blocker_2026-10-13.zip')))
old_receipt = obj(blocker.read('q16_pinned_integration_execution_2027/POSTEXIT_RESOURCE_RECEIPT.json'))
old_status = obj(blocker.read('q16_pinned_integration_execution_2027/STATUS.json'))
check(old_receipt['exit_code']==-24 and old_receipt['terminating_signal']==24 and old_receipt['scientific_result_exists'] is False and old_receipt['retries']==0, 'earlier SIGXCPU attempt preserved with no result and no retry')
check(old_status['individual_case_completion']=='UNKNOWN_NO_CHECKPOINTS', 'earlier unknown stopping stage is not reinterpreted')
execution_status = obj(z.read(ep+'STATUS.json'))
check(execution_status['observer_v2_attempts']==1 and execution_status['observer_v2_retries']==0 and execution_status['total_historical_attempts_across_versions']==2, 'attempt counts distinguish original and observer-v2 runs')

# Result and independently rederived constructor event/receipt formulas.
rows = {case['id']:case for case in r['cases']}
check(len(rows) == len(r['cases']) == 6 and set(rows) == {c0['id'] for c0 in c['cases']}, 'exact six distinct constructor cases')
check([case['id'] for case in r['cases']] == ['zero_N1','zero_N17','unit_N1','odd_N9_unit','even_N16_bound','odd_N17_mixed_q0'], 'zero-first constructor order')
work = storage = 0
fixture_summary = []
plans={p['id']:p for p in obj(candidate.read(cp+'results/PREFLIGHT.json'))['case_plans']}
for case in c['cases']:
    n,d = case['N'],case['d']
    m=(4*n-1).bit_length(); M=1<<m; zero=case['pattern']=='zero'
    row = rows[case['id']]; rec=row['receipt']
    check(row['zero'] is zero and ('pipeline' in row) == case['pipeline'], case['id']+': exact route')
    events={'header_validation':1,'metadata_preparation':1,'raw_cell_read':n,'raw_field_read':2*n,'field_range_validation':2*n,'field_absolute_value':2*n,'maximum_comparison':2*n,'retained_pair_copy':n,'global_validation_complete':1,'zero_test':1,'return_record':1}
    if zero:
        events.update(temporary_slot_initialization=2*n,zero_output_cell=n,zero_outer_reference_copy=n)
        slots,headers = 256+11*n,67+4*n
    else:
        events.update(normalization_metadata=1,temporary_slot_initialization=n+M,center_map_addition=M,center_wrap_comparison=M,occupied_comparison=M,retained_pair_read=n,padding_zero_cell=M-n,source_cell_construction=M,source_outer_reference_copy=M,source_record_construction=1)
        if (n-1)//2: events['center_wrap_subtraction']=(n-1)//2
        slots,headers=258+3*n+8*M,68+n+3*M
    meta=(d*m+m+16)**2; width=64+(d+16)*(m+1)
    units=sum(events.values())+slots+headers+meta+256
    expected={'events':[[k,v] for k,v in sorted(events.items())],'allocated_slots':slots,'allocated_headers':headers,'metadata_bit_budget':meta,'growing_word_bits':width,'word_operations_upper':1024*units,'local_bit_operations_upper':65536*units*width*width,'cumulative_storage_bits_upper':64*units*width}
    check(rec == expected, case['id']+': entire independent constructor receipt')
    work += expected['local_bit_operations_upper']; storage += expected['cumulative_storage_bits_upper']
    limit=1<<(d*m)
    values=[(0,0)]*n
    if case['pattern']=='unit': values[0]=(1,-1)
    if case['pattern']=='bound': values[0]=(1,-1); values[-1]=(limit,-limit)
    if case['pattern']=='mixed':
        values=[((j%5)-2,3-(j%7)) for j in range(n)]
        values[n//2]=(limit-1,-limit)
    maximum=max(abs(v) for pair in values for v in pair)
    k=(maximum-1).bit_length() if maximum else None
    if zero:
        literal=[[[0,0],[0,0]] for j in range(n)]
        norm=None
    else:
        literal=[[[0,k],[0,k]] for j in range(M)]
        for j,pair in enumerate(values): literal[(j-(n-1)//2)%M]=[[pair[0],k],[pair[1],k]]
        norm=fractions.Fraction(sum(a*a+b*b for a,b in values),1<<(2*k))
        check(fractions.Fraction(1,4)<norm<=2*n and all(abs(v)<=1<<k for pair in values for v in pair), case['id']+': independent exact normalized finite-domain bounds')
    check(sha(json.dumps(literal,separators=(',',':')).encode())==plans[case['id']]['literal_sha256'], case['id']+': independently reconstructed literal-source digest agrees with frozen preflight')
    fixture_summary.append({'id':case['id'],'N':n,'M':M,'d':d,'e':case['e'],'pattern':case['pattern'],'pipeline':case['pipeline'],'maximum_absolute_raw_field':maximum,'k0':k,'lambda_exp':k-case['e'] if k is not None else None,'normalized_norm_squared':str(norm) if norm is not None else None})
rejections=[('VECTOR_TYPE',0,None,None),('EMPTY_VECTOR',0,None,None),('D_DOMAIN',0,None,None),('EXPONENT_TYPE',0,None,None),('EXPONENT_RANGE',0,None,None),('CELL_TYPE',4,2,None),('CELL_LENGTH',4,2,None),('FIELD_TYPE',5,2,1),('FIELD_RANGE',4,2,0),('PRACTICAL_D_LIMIT',0,None,None)]
check([(x['code'],x['validated_fields'],x['cell_index'],x['component']) for x in r['rejections']] == rejections, 'ten exact constructor rejection diagnostics')
check(r['identity_controls'] == [{'id':'foreign_pipeline','error':'exact immutable already represented DyadicSource required'},{'id':'true_class_wrong_length','error':'source header mismatch'},{'id':'foreign_buckets','error':'immutable, already represented DyadicSource required'}], 'three exact source identity/header controls')

# Guard ASTs establish what a successful archived process asserted; no execution.
require_nodes = [n for n in ast.walk(h) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='require']
guards = {n.args[1].value:ast.unparse(n.args[0]) for n in require_nodes if len(n.args)>1 and isinstance(n.args[1],ast.Constant) and type(n.args[1].value) is str}
for label,expression in {'actual constructor same-class binding':'type(out.source) is bk.DyadicSource is pp.DyadicSource','pipeline and buckets share exact class':'pp.DyadicSource is bk.DyadicSource','complete actual/reference pipeline equality':'actual == reference','complete source coordinates':"data == ref['values']",'source does not alias outer input':"out.source.values == frozen == ref['values']",'consumer same candidate object':'run.estimation_trace[0].candidates is run.candidates'}.items():
    check(guards[label] == expression, 'reached source-pinned guard: '+label)
inventory=[]
source_preflight_count=1+7
for p in c['files']:
    tree=source_trees[p['module']]
    imports=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Import): imports.extend(a.name for a in n.names)
        if isinstance(n,ast.ImportFrom): imports.append(n.module)
    inventory.append({'module':p['module'],'bytes':p['bytes'],'sha256':p['sha256'],'imports':imports})
    source_preflight_count += 3+len(tree.body)+sum(isinstance(n,ast.Expr) for n in tree.body)+sum(isinstance(n,ast.Assign) for n in tree.body)
check(r['source_inventory']==inventory, 'independent source AST import inventories')
assertion_breakdown={'source_preflight':source_preflight_count,'plan_checks':26,'six_module_loads':12,'initial_lazy_import_guard':1,'constructor_rejections':10,'zero_cases':28,'cross_module_identity':2,'nonzero_source_cases':68,'three_pipeline_pairs_and_trace_checks':111,'fourteen_in_profile_report_comparisons':126,'nine_final_report_comparisons':81,'final_control_count':1}
check(source_preflight_count+26 == 153, 'preflight assertion count reconstructed from source AST')
check(sum(assertion_breakdown.values()) == r['assertions'] == 593, '593 assertion invocations independently reconciled from successful control flow')

reports=r['observer']['ledger_reports']; paired=[]; aggregate=collections.Counter(); consumers=[]
check(len(reports)==r['observer']['ledger_instances']==9 and r['observer']['reports_checked']==14, 'nine ledger instances and fourteen in-profile reports')
check(r['observer']['profile_calls']==1186060 and r['observer']['profile_calls']<caps['total_scientific_profile_calls'], 'selected-call counter below unchanged cap; no claim of operand-trace reconstruction')
check(c['consumer']=={'B':4,'r':1,'P':16,'beta':None,'location_schedule':[[1,0]],'estimation_schedule':[[3,1]],'W':63}, 'exact reduced consumer specification')
for case in c['cases']:
    if not case['pipeline']: continue
    name=case['id']; row=rows[name]; p=row['pipeline']; M=1<<(4*case['N']-1).bit_length(); T=M//4; q=case['q']; K=q*T
    check(p['ledger']==row['reference_ledger'], name+': full serialized actual/reference ledger equality')
    paired.extend([p['ledger'],row['reference_ledger']])
    check(len(p['location_trace'])==len(p['estimation_trace'])==1, name+': one location and one estimation trace')
    loc,est=p['location_trace'][0],p['estimation_trace'][0]
    check(loc['affine']==[1,0] and est['affine']==[3,1], name+': exact affine schedules')
    for role,trace in [('location',loc),('estimation',est)]:
        coords=trace['buckets']['numerators']
        check(trace['buckets']['bits']==16 and len(coords)==4 and all(len(pair)==2 and all(type(v)is int for v in pair) for pair in coords), name+': '+role+' exact bucket grid and type')
    coords=loc['buckets']['numerators']
    selected=sorted(range(4),key=lambda i:(-sum(v*v for v in coords[i]),i))[:q]
    members=[(j*T-T//2+t)%M for j in selected for t in range(T)]
    check(loc['selected_buckets']==selected and loc['memberships']==members, name+': independent exact ranking and membership enumeration')
    check(p['candidates']==sorted(members) and len(set(p['candidates']))==K and est['candidates']==p['candidates'], name+': sorted distinct candidate binding')
    estimates=est['estimates']
    check(estimates['bits']==16 and len(estimates['numerators'])==K and all(len(pair)==2 and all(type(v)is int for v in pair) for pair in estimates['numerators']), name+': exact estimate grid and shape')
    check(p['output']=={'bits':16,'pairs':[[i,pair] for i,pair in zip(p['candidates'],estimates['numerators'])]}, name+': one-row Cartesian median independently interpreted')
    wanted={'bucket_engine_constructor':1,'buckets_call':2,'window_validation_call':4,'source_query':126,'sample_alignment':252,'decode_call':1,'membership_output':K,'estimate_call':1,'phase_preparation':K,'median_call':1,'bucket_output':8}
    check(row['expected_inventory']==wanted, name+': independently derived consumer inventory')
    for k,v in wanted.items(): check(p['ledger']['operations'].get(k,0)==v, name+': paid operation '+k)
    R=1<<16; A=2*M*M
    check(p['bucket_error']==[(A*R+126)*(R+1)**3-A*(1<<64)+(1<<48),64], name+': independent exact bucket-error formula')
    aggregate.update({k:2*v for k,v in p['ledger']['operations'].items()})
    consumers.append({'id':name,'M':M,'q':q,'K':K,'selected_buckets':selected})
check(reports[:6]==paired, 'all six final consumer ledger reports in exact observed order')
for key,value in {'buckets_call':12,'source_query':756,'sample_alignment':1512,'decode_call':6,'membership_output':64,'estimate_call':6,'phase_preparation':64,'median_call':6,'median_output':64}.items():
    check(aggregate.get(key,0)==value, 'aggregate successful/reference paid inventory '+key)
for i,report in enumerate(reports):
    ops=report['operations']; events=sum(ops.values())+256; width=report['max_observed_integer_bits']+events.bit_length()+2
    check(all(type(v)is int and v>=0 for v in ops.values()) and list(ops)==sorted(ops), 'ledger '+str(i)+': canonical nonnegative integer operations')
    check(report['bookkeeping_bit_work_upper']==512*events*width*width, 'ledger '+str(i)+': exact bookkeeping formula')
    check(report['total_bit_work_upper']==report['arithmetic_bit_work_upper']+512*events*width*width, 'ledger '+str(i)+': exact arithmetic/control sum')
    check(report['allocated_slots']==ops.get('allocated_slots',0) and report['cumulative_storage_upper_bits']-512*events*width>=report['allocated_slots'], 'ledger '+str(i)+': cumulative storage/allocation consistency')
    check(report['arithmetic_bit_work_upper']%16==0 and report['parameter_input_bits']>=ops.get('parameter_input',0) and report['max_parameter_bits']<=report['max_observed_integer_bits'], 'ledger '+str(i)+': primitive width consistency')
    check(report['model']=='schoolbook binary arithmetic plus conservative control and cumulative-storage envelope; excludes Python runtime and test oracle', 'ledger '+str(i)+': unchanged accounting model')
foreign,wrong,extra=reports[6:]
for label,report in [('foreign',foreign),('wrong-length',wrong)]:
    ops=report['operations']
    check(ops.get('pipeline_call')==ops.get('pipeline_validation')==ops.get('window_validation_call')==1, label+': rejected initialization charged')
    check(ops.get('bucket_engine_constructor',0)==ops.get('buckets_call',0)==ops.get('source_query',0)==0, label+': no consumer/source read after failure')
check(foreign['operations'].get('source_length',0)==0 and wrong['operations']['source_length']==1, 'foreign identity and genuine wrong length remain distinct')
check(extra['operations']['bucket_engine_constructor']==1 and extra['operations']['buckets_call']==1 and extra['operations']['window_validation_call']==2 and extra['operations'].get('source_query',0)==extra['operations'].get('pipeline_call',0)==0, 'extra engine preparation and failed bucket call fully retained')
rw=10*65536*(15*17+18*128+8+589+(9*7+7+16)**2)*(64+25*8)**2
rs=10*64*(15*17+18*128+8+589+(9*7+7+16)**2)*(64+25*8)
lw=sum(p['total_bit_work_upper'] for p in reports); ls=sum(p['cumulative_storage_upper_bits'] for p in reports)
totals={'successful_constructor_bit_work_upper':work,'successful_constructor_storage_bits_upper':storage,'all_consumer_and_control_bit_work_upper':lw,'all_consumer_and_control_storage_bits_upper':ls,'constructor_rejection_reserve_bit_work_upper':rw,'constructor_rejection_reserve_storage_bits_upper':rs,'total_scientific_bit_work_upper':work+lw+rw,'total_scientific_storage_upper_bits':storage+ls+rs}
for key,value in totals.items(): check(r['paid_resources'][key]==value, 'independent paid total '+key)
for partial,complete in [('wall_seconds','full_child_wall_seconds'),('user_cpu_seconds','full_child_user_cpu_seconds'),('system_cpu_seconds','full_child_system_cpu_seconds'),('peak_rss_kib','full_child_peak_rss_kib')]:
    check(r['paid_resources'][partial]<=receipt[complete], 'partial harness snapshot bounded by complete receipt: '+partial)
prior=obj((HERE/'evidence/PRIOR_PARTIAL_RESULT_CHECKS.json').read_bytes())
check(prior['verdict']=='PASS_INDEPENDENT_RESULT_DATA_CHECKS' and prior['checks']==len(prior['check_labels'])==275 and prior['result_sha256']==EXPECTED_RESULT, 'preserved prior 275-check record belongs to exact result')
check(prior['paid_resources_independently_summed']==totals, 'new data-only totals agree with preserved partial audit')

output={'verdict':'PASS_FRESH_STATIC_AND_RESULT_EVIDENCE_AUDIT','checks':len(checks),'check_labels':checks,'archived_programs_executed':False,'scientific_reruns':0,'external_writes':False,'producer_sha256':EXPECTED_ARCHIVE,'result_sha256':EXPECTED_RESULT,'archive_records':archive_records,'assertion_breakdown':assertion_breakdown,'fixture_summary':fixture_summary,'consumer_summary':consumers,'independent_paid_totals':totals,'scope':'Static authentication and interpretation of the already completed bounded observer-v2 run. Source-model component theorems and full primitive accumulator reconstruction rely on the authenticated prior component/observer reviews; no fresh historical execution.'}
print(json.dumps(output,indent=2))
