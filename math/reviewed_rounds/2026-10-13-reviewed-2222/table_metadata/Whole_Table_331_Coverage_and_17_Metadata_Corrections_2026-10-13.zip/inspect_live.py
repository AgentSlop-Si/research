import json, re, collections, pathlib, hashlib
P=pathlib.Path(__file__).parent
def col(i):
    s=''
    while i:
        i,r=divmod(i-1,26);s=chr(65+r)+s
    return s
rows={}
for p in P.glob('raw_*.json'):
    d=json.loads(p.read_text())['structuredContent']
    name=d['range'].split('!')[0].strip("'")
    rows[name]={str(i):{col(j):v for j,v in enumerate(r,1)} for i,r in enumerate(d['values'],1)}
(P/'LIVE_ROWS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
base=json.load(open(P.parent/'current_round_reconciliation_v4_2049/BASELINE_ROWS.json'))
diff=[]
for sh in rows:
    for rn in set(rows[sh])|set(base[sh]):
        for c in set(rows[sh].get(rn,{}))|set(base[sh].get(rn,{})):
            a=base[sh].get(rn,{}).get(c,'');b=rows[sh].get(rn,{}).get(c,'')
            if a!=b:diff.append({'sheet':sh,'cell':c+rn,'before':a,'after':b})
(P/'LIVE_VS_V4_BASELINE_DIFF.json').write_text(json.dumps(diff,ensure_ascii=False,indent=2))
bind=json.load(open(P.parent/'current_round_reconciliation_v4_2049/STABLE_ID_VIEW_BINDINGS.json'))
scorebind=json.load(open(P.parent/'current_round_reconciliation_v4_2049/ALL_SCORE_BINDINGS.json'))
badbind=[b for b in bind if rows[b['sheet']][str(b['row'])].get(b['id_column'])!=b['record_id']]
badscore=[]
for b in scorebind:
    c,rn=re.match(r'([A-Z]+)(\d+)',b['cell']).groups()
    if rows[b['sheet']][rn].get(c)!=b['score']:badscore.append({**b,'actual':rows[b['sheet']][rn].get(c)})
print('diff vs baseline',len(diff),collections.Counter(x['sheet'] for x in diff))
print('badbindings',len(badbind),'badscorebind',len(badscore));print(str(badbind+badscore)[:1000])
cat={r['A']:(rn,r) for rn,r in rows['Catalogue'].items() if int(rn)>3 and r.get('A')}
nov={r['C']:(rn,r) for rn,r in rows['novelity breakthough'].items() if int(rn)>5 and r.get('C')}
over={r['B']:(rn,r) for rn,r in rows['Research overview'].items() if int(rn)>4 and r.get('B')}
print('counts',len(cat),len(nov),len(over),'canonical-paired',len(set(cat)&set(nov)))
def head(x):
    return re.split(r'\n\s*(?:Earlier dated history|Earlier record|\[Earlier record)',str(x),maxsplit=1)[0].strip()
mismatch=[]
fields={'title':('C','E','D'),'priority':('AA','U','L'),'proof':('AC','W','N'),'novelty':('AD','X','O'),'action':('AE','Y','P'),'stop':('AF','Z','Q')}
for id in set(cat)&set(nov)&set(over):
    for field,cols in fields.items():
        vals=[head(z[id][1].get(c,'')) for z,c in zip([cat,nov,over],cols)]
        if len(set(vals))>1:mismatch.append({'id':id,'field':field,'values':vals})
(P/'CROSS_VIEW_HEAD_DIFFERENCES.json').write_text(json.dumps(mismatch,ensure_ascii=False,indent=2))
print('mirror differences',collections.Counter(x['field'] for x in mismatch))
print('title-diffs',[x for x in mismatch if x['field']=='title'])
print('priority-diffs',[x for x in mismatch if x['field']=='priority'])
print('proof/action diffids',sorted(set(x['id'] for x in mismatch if x['field'] in ['proof','action'])))
print('statuses',collections.Counter(r.get('E') for _,r in over.values()))
print('missing overview fields', {col:sum(not r.get(col) for _,r in over.values()) for col in 'CDEFGHIJKLMNOPQ'})
summ=[]
for id,(rn,r) in over.items():
    summ.append({'id':id,'row':rn,'priority':r.get('L'),'status':r.get('E'),'title':r.get('D'),'action':head(r.get('P','')),'proof':head(r.get('N','')),'evidence':head(r.get('J',''))})
(P/'ALL327_CURRENT_HEADS.json').write_text(json.dumps(summ,ensure_ascii=False,indent=2))
print('done')
