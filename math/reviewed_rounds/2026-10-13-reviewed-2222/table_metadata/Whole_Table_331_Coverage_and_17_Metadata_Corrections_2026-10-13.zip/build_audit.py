"""Fresh read-only metadata/source audit. No historical scientific program runs."""
import json, re, csv, hashlib, collections
from pathlib import Path
P=Path(__file__).parent; W=P.parent
BASE='https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit'
def read(f): return json.loads((P/f).read_text())
def prior(f): return json.loads((W/f).read_text())
def dump(name,obj): (P/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def head(s):return re.split(r'\n\s*(?:Earlier dated history|Earlier record|\[Earlier record)',str(s or ''),maxsplit=1)[0].strip()
def col(n):
 s=''
 while n:n,r=divmod(n-1,26);s=chr(65+r)+s
 return s
def coln(s):
 n=0
 for c in s:n=n*26+ord(c)-64
 return n
rows=read('LIVE_ROWS.json');meta=read('LIVE_METADATA.json')['structuredContent'];gids={s['properties']['title']:s['properties']['sheetId'] for s in meta['sheets']}
def link(sh,cell):return f'{BASE}#gid={gids[sh]}&range={cell}'
def value(sh,cell):
 c,r=re.fullmatch(r'([A-Z]+)(\d+)',cell).groups();return rows[sh][r].get(c,'') or ''
ranking=prior('current_round_reconciliation_v4_2049/ALL_331_CURRENT_RANKING.json'); rank={r['record_id']:r for r in ranking}
bindings=prior('current_round_reconciliation_v4_2049/STABLE_ID_VIEW_BINDINGS.json')
scores=prior('current_round_reconciliation_v4_2049/ALL_SCORE_BINDINGS.json')
pending=prior('current_round_reconciliation_v4_2049/PROPOSED_CELL_DIFF.json')
coverage=prior('complete_source_coverage_1453/packet/CANONICAL_225_COVERAGE.json')
sourcepins=read('SOURCE_REFERENCE_REHASH.json')
covbyid={i:r for r in coverage for i in r['record_ids']}
last165={r['record_id']:r for r in prior('breadth_last165_1752/LAST165_COVERAGE_LEDGER.json')}
byid=collections.defaultdict(list)
for b in bindings:byid[b['record_id']].append(b)
scoreby=collections.defaultdict(list)
for b in scores:scoreby[b['record_id']].append(b)
cat={r['A']:(n,r) for n,r in rows['Catalogue'].items() if int(n)>3 and r.get('A')}
nov={r['C']:(n,r) for n,r in rows['novelity breakthough'].items() if int(n)>5 and r.get('C')}
ov={r['B']:(n,r) for n,r in rows['Research overview'].items() if int(n)>4 and r.get('B')}
idcols={'Theorem register':'A','Research queue':'A','Fusion list':'A','New results':'A','Prior work':'A','Next cycle':'A','Incoming queue':'A','Catalogue':'A','novelity breakthough':'C','Research overview':'B'}
actual_bindings=[];non_atomic=[]
for sh,c in idcols.items():
 for rn,r in rows[sh].items():
  if int(rn)<(6 if sh=='novelity breakthough' else 5 if sh=='Research overview' else 4):continue
  if r.get(c) in rank:actual_bindings.append((r[c],sh,int(rn),c))
  elif r.get(c):non_atomic.append({'sheet':sh,'row':int(rn),'related_ids_text':r[c]})
assert set(actual_bindings)=={(b['record_id'],b['sheet'],b['row'],b['id_column']) for b in bindings}
assert len(rank)==331 and len(bindings)==916 and len(scores)==775
assert len(cat)==178 and len(nov)==216 and len(ov)==327
assert set(cat)<=set(nov) and set(nov)<=set(ov)
for b in scores:assert value(b['sheet'],b['cell'])==b['score'] and type(b['score']) is int and 1<=b['score']<=100

# Exact metadata-only follow-up: old locators and retired b31 cross-references.
spec=[]
b31text=('This named residual workflow remains CLOSED / COMPLETE at priority 15. Both the later b31 ordinary-residual construction/review and the original-tau all-A overlap stage are independently accepted complete. Follow F020 only for a separately declared remaining all-m paired reciprocal-support or general endpoint task, preserving its exact guards. No fixed-b successor is selected automatically; keep the Q29 repeated-prime lane separate.')
for id,targets in {
 'NEXT-RS-RESIDUAL-B27':[('Next cycle','D13'),('Next cycle','K13'),('Research overview','C283'),('Research overview','P283')],
 'NEXT-RS-RESIDUAL-B29':[('Next cycle','D15'),('Next cycle','K15'),('Research overview','C331'),('Research overview','P331')]
}.items():
 for sh,cell in targets:spec.append((id,sh,cell,'RETIRED_B31_CROSS_REFERENCE',b31text))
spec.append(('F020','novelity breakthough','N7','RETIRED_SCORE_COMMENTARY',
 'The current work priority 58 applies to the remaining all-m paired reciprocal-support gate. The general endpoint task remains separately open at 53. Both b31 ordinary-residual and original-tau all-A overlap stages are independently accepted complete; their former task scores 60 and 57 are historical. Preserve the balanced-order endpoint completion and the remaining off-line endpoint and other obstruction channels. No further fixed-b certificate is selected automatically. Current numeric score, theorem scope and source limitations are unchanged.'))
wrongloc={
 'M-PERMUTATION-DISPLACEMENT':('J91',85),
 'M-TWO-SIDED-GAUGE':('J105',97),
 'M-HADAMARD-SEGRE':('J230',100),
 'M-OUTER-STABILITY':('J235',98),
 'M-PAIRED-JACOBI':('J236',99)}
for id,(cell,oldrow) in wrongloc.items():
 old=value('Research overview',cell)
 new=old.replace(f'Catalogue{oldrow} X:Z',f'Catalogue stable ID {id}, fields X:Z (resolve by ID)')
 assert new!=old
 spec.append((id,'Research overview',cell,'WRONG_CURRENT_EVIDENCE_ROW_LOCATOR',new))
for id,cell in [('NEW-16','I252'),('NEW-16::order-p3','I307'),('NEW-16::v3-fidelity','I308')]:
 old=value('Research overview',cell)
 new=old.replace('novelity breakthough 6','novelity breakthough: NEW-16')
 assert new!=old
 spec.append((id,'Research overview',cell,'WRONG_PARENT_SOURCE_ROW_LOCATOR',new))
assert len(spec)==17 and len({(sh,c) for _,sh,c,_,_ in spec})==17
assert not ({(p['sheet'],p['cell']) for p in pending}&{(sh,c) for _,sh,c,_,_ in spec})
cellmap={}
for s in read('FOLLOWUP_PREIMAGE_CELLDATA.json')['structuredContent']['sheets']:
 for grid in s['data']:
  for i,r in enumerate(grid.get('rowData',[]),grid.get('startRow',0)+1):
   for j,v in enumerate(r.get('values',[]),grid.get('startColumn',0)+1):cellmap[(s['properties']['title'],col(j)+str(i))]=v
delta=[]
for id,sh,c,issue,new in spec:
 before=value(sh,c);cd=cellmap[(sh,c)]
 assert cd['userEnteredValue']['stringValue']==before
 after='[2026-10-13; stable-ID catalogue consistency correction]\n'+new+'\n\nEarlier dated history (preserved verbatim):\n'+before
 delta.append({'record_id':id,'sheet':sh,'sheet_id':gids[sh],'cell':c,'issue':issue,'before':before,'after':after,
  'before_sha256_utf8':digest(before),'after_sha256_utf8':digest(after),'before_CellData':cd,
  'field_mask':'userEnteredValue','current_priority':rank[id]['existing_work_priority_1_to_100'],'recommended_priority':rank[id]['existing_work_priority_1_to_100'],'numeric_delta':0,
  'status_preserved':rank[id]['status'],'source_link':link(sh,c),'stable_id_guards':byid[id],
  'evidence':(['last165_independent_review_v2/REVIEW.md#Q08; Catalogue!AB4:AC4; Catalogue!AE4; Research queue!F11; Research overview!C116/P116'] if 'B31' in issue or 'SCORE' in issue else [f'Current stable-ID Catalogue/novelty binding for {id.split("::")[0]}; LIVE_ROWS.json'])})
dump('FOLLOWUP_17_CELL_DELTA.json',delta)
requests=[]
for d in delta:
 c,r=re.fullmatch(r'([A-Z]+)(\d+)',d['cell']).groups()
 requests.append({'updateCells':{'start':{'sheetId':d['sheet_id'],'rowIndex':int(r)-1,'columnIndex':coln(c)-1},'rows':[{'values':[{'userEnteredValue':{'stringValue':d['after']}}]}],'fields':'userEnteredValue'}})
dump('FOLLOWUP_17_REQUESTS_NOT_APPLIED.json',{'spreadsheet_id':meta['spreadsheetId'],'requests':requests})
exceptions_by=collections.defaultdict(list)
for d in delta:exceptions_by[d['record_id']].append(d['issue'])
pending_by=collections.defaultdict(list)
for d in pending:pending_by[d['record_id']].append(d)
sourcecols={'Catalogue':['N','Q','R','Y'],'novelity breakthough':['P','Q'],'Research overview':['I','J'],
 'Theorem register':['I','J'],'Research queue':['H','K','L'],'Fusion list':['G','H'],'New results':['G','H'],'Prior work':['B'],
 'Next cycle':['E'],'Incoming queue':['C','D']}
def band(score):
 return next(label for upper,label in [(15,'Completed/inactive named scope'),(34,'Low-leverage optional follow-up'),(49,'Supporting bounded task/source gate'),(64,'Consequential uncertain parent gate'),(79,'Unusually tractable source-ready high-leverage gate'),(100,'Decisive time-critical opportunity')] if score<=upper)
out=[]
for id in sorted(rank):
 rr=rank[id]; binds=byid[id]; op=ov.get(id); val=op[1] if op else rows['Incoming queue'][str(binds[0]['row'])]
 action=head(val.get('P' if op else 'K',''));proof=head(val.get('N' if op else 'I',''));novelty=head(val.get('O' if op else 'J',''));stop=head(val.get('Q' if op else 'L',''))
 sourcefields=[]
 for b in binds:
  r=rows[b['sheet']][str(b['row'])]
  for c in sourcecols[b['sheet']]:
   if r.get(c):sourcefields.append({'sheet':b['sheet'],'cell':c+str(b['row']),'current_text':head(r[c]),'sheet_link':link(b['sheet'],c+str(b['row']))})
 sourcejoined='\n'.join(x['current_text'] for x in sourcefields)
 urls=sorted(set(re.findall(r'https?://[^\s<>"\]]+',sourcejoined)))
 hashes=sorted(set(re.findall(r'(?<![a-fA-F0-9])[a-fA-F0-9]{64}(?![a-fA-F0-9])',sourcejoined)))
 flags=list(dict.fromkeys(exceptions_by[id]))
 if pending_by[id]:flags.append('STALE_CURRENT_OUTCOME_IN_SEPARATE_163_CELL_CHECKPOINT')
 if id=='ALG-074':flags.append('EXPLICIT_WHOLE_RECORD_REVIEW_MISSING_SOURCE_INTERFACE_HOLD')
 if id=='PR622-REPACKING-CANDIDATE-20261013':flags.append('OWNER_MAP_AND_FULL_ADMISSION_UNREVIEWED')
 if id=='STRUCTURED-RESIDUAL-EXECUTOR-20261012':flags.append('STATIC_ONLY_IMPLEMENTATION_COLD_REPLAY_OUTSTANDING')
 if not flags:flags=['NO_NEW_METADATA_EXCEPTION_IDENTIFIED']
 rdy=covbyid.get(id)
 mirrorcheck='NOT_CANONICAL; stable ID and every existing numeric binding verified'
 if id in cat:
  for f,cols in {'title':('C','E','D'),'priority':('AA','U','L'),'proof':('AC','W','N'),'novelty':('AD','X','O'),'action':('AE','Y','P'),'stop':('AF','Z','Q')}.items():
   vals=[head(z[id][1].get(c,'')) for z,c in zip([cat,nov,ov],cols)]
   assert len(set(vals))==1,(id,f)
  mirrorcheck='PASS: title/priority/proof/novelty/action/stop current heads identical across canonical, novelty and overview views'
 out.append({'record_id':id,'title':rr['title'],'status':val.get('E') if op else 'INTAKE_ALIAS',
  'current_work_priority_1_to_100':rr['existing_work_priority_1_to_100'],'proposed_work_priority_1_to_100':rr['existing_work_priority_1_to_100'],'proposed_numeric_delta':0,
  'priority_band':band(rr['existing_work_priority_1_to_100']),'score_rationale':'Preserve the existing scope-specific ordinal score. This audit supplies metadata consistency and source-binding evidence, not a new value/readiness judgment warranting re-ranking.',
  'obligation_group':rr['obligation_group'],'shared_group_records':rr['shared_group_records'],'is_canonical_claim':id in cat,'is_novelty_view':id in nov,'is_main_overview_record':bool(op),
  'topic_and_overlay_consistency':mirrorcheck,'view_count':len(binds),'view_bindings':[{**b,'source_link':link(b['sheet'],b['id_column']+str(b['row']))} for b in binds],
  'score_bindings':scoreby[id],'current_action':action,'current_proof_status_attributed':proof,'current_novelty_status_attributed':novelty,'stop_condition':stop,
  'source_evidence_fields':sourcefields,'source_urls_observed':urls,'source_hashes_observed':hashes,'source_reference_assessment':'Declared locators and metadata only; URL presence is not a successful network retrieval or proof-review acceptance.',
  'frozen_225_group_source_readiness':rdy['frozen_readiness'] if rdy else None,'frozen_readiness_packet':rdy['packet_id'] if rdy else None,
  'frozen_readiness_limits':rdy['selection_or_source_limit'] if rdy else None,'frozen_readiness_is_current_census':False,
  'last165_audit_provenance':{'audit_flag':last165[id]['audit_flag'],'audit_finding':last165[id]['audit_finding']} if id in last165 else None,
  'audit_flags':flags,'separate_pending_checkpoint_cells':[{k:d[k] for k in ['sheet','cell','semantic_field']} for d in pending_by[id]],
  'proposed_metadata_correction_cells':[{'sheet':d['sheet'],'cell':d['cell'],'issue':d['issue']} for d in delta if d['record_id']==id],
  'fresh_scientific_proof_review':False,'fresh_scientific_code_execution':False,'external_write':False})
dump('ALL_331_COVERAGE_LEDGER.json',out)
csvfields=['record_id','title','status','current_work_priority_1_to_100','proposed_work_priority_1_to_100','proposed_numeric_delta','priority_band','obligation_group','is_canonical_claim','is_novelty_view','is_main_overview_record','topic_and_overlay_consistency','view_count','current_action','current_proof_status_attributed','current_novelty_status_attributed','stop_condition','source_urls_observed','source_hashes_observed','frozen_225_group_source_readiness','frozen_readiness_packet','frozen_readiness_limits','audit_flags','proposed_metadata_correction_cells','fresh_scientific_proof_review','fresh_scientific_code_execution','external_write']
with (P/'ALL_331_COVERAGE_LEDGER.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=csvfields);wr.writeheader()
 for r in out:wr.writerow({k:json.dumps(r[k],ensure_ascii=False) if isinstance(r[k],(list,dict)) else r[k] for k in csvfields})
normalized_diff=[d for d in read('LIVE_VS_V4_BASELINE_DIFF.json') if (d['before'] or '')!=(d['after'] or '')]
assert not normalized_diff
formuladata=read('FORMULA_LINK_READBACK.json')['structuredContent']['sheets'][0]['data'];linkchecks=[]
for grid in formuladata:
 if grid.get('startColumn')!=17:continue
 for rn,rd in enumerate(grid.get('rowData',[]),grid.get('startRow',0)+1):
  cell=rd.get('values',[{}])[0];formula=cell.get('userEnteredValue',{}).get('formulaValue')
  if not formula:continue
  id=rows['novelity breakthough'][str(rn)]['C'];target=cat[id][0];u=cell.get('hyperlink','')
  check={'record_id':id,'cell':'R'+str(rn),'formula_bound_id':id,'expected_catalogue_row':int(target),'display':cell.get('formattedValue'),'hyperlink':u,
   'pass':cell.get('formattedValue')==id and f'gid={gids["Catalogue"]}&range=A{target}' in u and f'MATCH("{id}";' in formula}
  linkchecks.append(check)
assert len(linkchecks)==178 and all(c['pass'] for c in linkchecks)
dump('ALL_178_FORMULA_LINK_CHECKS.json',linkchecks)
summary={'audit_as_of_utc':'2026-10-13T22:13:20Z','live_values_read_utc':'2026-10-13T22:06:15Z/2026-10-13T22:06:39Z',
 'scope':'All 13 tabs; stable-ID, topic/view, ordinal priority, lifecycle status, current action and source-locator audit. No fresh proof acceptance or global novelty ranking.',
 'stable_ids':331,'main_overview_records':327,'intake_aliases':4,'canonical_claims':178,'canonical_novelty_pairs':178,'novelty_views':216,'supplemental_novelty_views':38,
 'stable_id_view_bindings':916,'priority_bindings':775,'canonical_three_view_field_sets_verified':178,'formula_links_live_readback_verified':178,
 'status_counts':dict(collections.Counter(x['status'] for x in out)),
 'open_obligation_groups':len({x['obligation_group'] for x in out if x['status']=='TO RESEARCH' and x['obligation_group']}),
 'out_of_range_or_missing_numeric_priorities':0,'numeric_score_conflicts':0,'missing_overview_required_fields':0,'new_numeric_rank_deltas':0,
 'old_count_semantics':'306 and 178 are narrower/historical inventory views. Neither supersedes the full 331-record identity census. 216 is the novelty view, not the main overview count.',
 'live_vs_v4_baseline_substantive_differences':len(normalized_diff),'connector_null_vs_blank_differences':170,
 'pending_checkpoint':{'cells':163,'record_ids_excluding_global_summary':len({p['record_id'] for p in pending if p['record_id']!='GLOBAL_SUMMARY'}),'handled_separately':True},
 'new_followup_metadata_corrections':{'cells':len(delta),'record_ids':len({d['record_id'] for d in delta}),'categories':dict(collections.Counter(d['issue'] for d in delta)),'overlap_with_163_cell_patch':0,'applied':False},
 'source_rehash':{'register_references':701,'exact_hash_matches':579,'distinct_bound_paths':539,'unbound_references_not_cleared':122,'mismatches':0,'undeclared_byte_lengths':10,
 'meaning':'Reference bindings, not distinct theorem/proof acceptances. Hashes were freshly rechecked; no supplied scientific code was executed.'},
 'frozen_source_readiness':{'groups':225,'member_record_ids':239,'dated_counts':{'NEEDS_SCOPE_SELECTION':168,'SOURCE_BLOCKED':53,'READY':4},'current_249_group_census':False},
 'explicit_nonclearance_records':['ALG-074','PR622-REPACKING-CANDIDATE-20261013','STRUCTURED-RESIDUAL-EXECUTOR-20261012'],
 'review_vs_proof':'Accepted or existing proof files remain attributed to their exact previous review. Full-row or whole-pipeline review is never inferred from source existence, finite controls, or this metadata audit.',
 'url_availability':'Current spreadsheet internal links checked as stated. External endpoint availability was not retested; preserved local exact-source register was rehashed.',
 'historical_code_executed':False,'external_writes':False,'non_atomic_prior_work_crosslinks':non_atomic}
dump('SUMMARY.json',summary)
rubric=prior('current_round_reconciliation_v4_2049/SCORING_RUBRIC.json')
rubric.update({'audit_application':'All331 actual scores preserved, delta0. Closed15 b27/b29 stages stay closed. Retired b31 task references60/57 are removed from current language, not live numeric cells. The F01848 successor is separately scoped and must not replace the completed15 row.', 'unsupported_precision':'Do not assign rank movement merely from metadata cleanup or a source file existing. Source-ready dispatch and scientific importance remain distinct.'})
dump('SCORING_RUBRIC.json',rubric)
dump('SOURCE_PROVENANCE_INPUTS.json',[{'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [
 W/'current_round_reconciliation_v4_2049/ALL_331_CURRENT_RANKING.json',W/'current_round_reconciliation_v4_2049/STABLE_ID_VIEW_BINDINGS.json',W/'current_round_reconciliation_v4_2049/ALL_SCORE_BINDINGS.json',W/'current_round_reconciliation_v4_2049/PROPOSED_CELL_DIFF.json',W/'complete_source_coverage_1453/packet/CANONICAL_225_COVERAGE.json',W/'complete_source_coverage_1453/packet/SOURCE_PIN_RECHECKS.json',W/'last165_independent_review_v2/REVIEW.md',W/'last165_independent_review_v2/REVIEWED_MINIMAL_CELL_CORRECTIONS.json',W/'breadth_last165_1752/LAST165_COVERAGE_LEDGER.json']])
print(json.dumps(summary,ensure_ascii=False,indent=2))
