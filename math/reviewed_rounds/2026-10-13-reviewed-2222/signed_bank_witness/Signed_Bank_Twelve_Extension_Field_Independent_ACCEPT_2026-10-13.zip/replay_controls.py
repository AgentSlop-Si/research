#!/usr/bin/env python3
"""Cold replay and rejection controls for the independent exact checker."""
import copy, hashlib, json, pathlib, shutil, subprocess, sys, tempfile
here=pathlib.Path(__file__).resolve().parent
baseline=json.loads((here/'RESULTS.json').read_text())
source=json.loads((here/'MINIMAL_WITNESS.json').read_text())
results=[]
with tempfile.TemporaryDirectory(prefix='twelve-independent-cold-') as td:
    d=pathlib.Path(td)
    shutil.copyfile(here/'independent_check.py',d/'independent_check.py')
    (d/'MINIMAL_WITNESS.json').write_bytes((here/'MINIMAL_WITNESS.json').read_bytes())
    run=subprocess.run([sys.executable,'independent_check.py'],cwd=d,capture_output=True,text=True)
    assert run.returncode==0,run.stderr
    actual=json.loads((d/'RESULTS.json').read_text())
    expected=copy.deepcopy(baseline);expected['candidate_manifest_members_verified']=[]
    assert actual==expected
    (here/'COLD_REPLAY.log').write_text(run.stdout)
    results.append({'control':'standalone, only independent_check.py and MINIMAL_WITNESS.json','expected':'ACCEPT','returncode':run.returncode,'all_computed_results_match':True})
    variants=[]
    bad=copy.deepcopy(source);bad['banks'][0]['raw_weights'][0][0]=(bad['banks'][0]['raw_weights'][0][0]+1)%23
    variants.append(('one raw-weight coefficient changed',bad))
    bad=copy.deepcopy(source);bad['banks'].pop();variants.append(('one same-sign bank removed',bad))
    bad=copy.deepcopy(source);bad['banks'][5]['alpha']=[3,0,0,0,0];variants.append(('cross-sign singleton changed from 4 to 3',bad))
    bad=copy.deepcopy(source);bad['modulus'][0]=(bad['modulus'][0]+1)%23;variants.append(('modulus constant changed',bad))
    for label,bad in variants:
        (d/'MINIMAL_WITNESS.json').write_text(json.dumps(bad))
        run=subprocess.run([sys.executable,'independent_check.py'],cwd=d,capture_output=True,text=True)
        assert run.returncode!=0
        results.append({'control':label,'expected':'REJECT','returncode':run.returncode,'last_error_line':run.stderr.strip().splitlines()[-1]})
(here/'REPLAY_AND_CONTROLS.json').write_text(json.dumps(results,sort_keys=True,indent=2)+'\n')
print(json.dumps(results,indent=2))
