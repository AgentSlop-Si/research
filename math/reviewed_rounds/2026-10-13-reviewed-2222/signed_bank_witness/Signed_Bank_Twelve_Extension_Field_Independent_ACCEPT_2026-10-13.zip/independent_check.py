#!/usr/bin/env python3
"""Independent exact checker. Standard library only; no candidate code is loaded.
Default: verify MINIMAL_WITNESS.json and write RESULTS.json.
Optional --candidate PATH additionally compares all stored bank matrices and rows.
"""
import argparse, collections, functools, hashlib, itertools, json, pathlib, zipfile
P, N, Q = 23, 11, 13
MOD = [6,4,18,1,8,1]
ZERO, ONE, Z = (0,)*5, (1,0,0,0,0), (0,1,0,0,0)
EXPECTED_ARCHIVE='aca8229b5b48c6829b6b41005220b2e25aef03685243413602d1875b92feb431'

def trim(a):
    a=[x%P for x in a]
    while a and a[-1]==0: a.pop()
    return a

def poly_sub(a,b):
    return trim([(a[i] if i<len(a) else 0)-(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])

def poly_rem(a,b):
    a=trim(a); b=trim(b); assert b
    inv=pow(b[-1],-1,P)
    while len(a)>=len(b):
        shift=len(a)-len(b); c=a[-1]*inv%P
        for j in range(len(b)): a[j+shift]=(a[j+shift]-c*b[j])%P
        a=trim(a)
    return a

def poly_mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]=(c[i+j]+x*y)%P
    return trim(c)

def poly_pow(a,e,m):
    b=[1]
    while e:
        if e&1: b=poly_rem(poly_mul(b,a),m)
        a=poly_rem(poly_mul(a,a),m); e//=2
    return b

def poly_gcd(a,b):
    while b: a,b=b,poly_rem(a,b)
    return [(x*pow(a[-1],-1,P))%P for x in a]

def add(a,b): return tuple((x+y)%P for x,y in zip(a,b))
def neg(a): return tuple(-x%P for x in a)
def sub(a,b): return tuple((x-y)%P for x,y in zip(a,b))
def sc(a,c): return tuple(x*c%P for x in a)
def const(n): return (n%P,0,0,0,0)
def mul(a,b):
    if a==ZERO or b==ZERO: return ZERO
    if a==ONE: return b
    if b==ONE: return a
    c=[0]*9
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b): c[i+j]+=x*y
    for k in range(8,4,-1):
        t=c[k]%P
        if t:
            for j in range(5): c[k-5+j]-=t*MOD[j]
    return tuple(x%P for x in c[:5])
def fpow(a,e):
    b=ONE
    while e:
        if e&1:b=mul(b,a)
        a=mul(a,a);e//=2
    return b
@functools.lru_cache(maxsize=None)
def inv(a):
    assert a!=ZERO
    b=fpow(a,P**5-2)
    assert mul(a,b)==ONE
    return b

def mat_zero(): return [[ZERO for _ in range(N)] for _ in range(N)]
def mat_identity(): return [[ONE if i==j else ZERO for j in range(N)] for i in range(N)]
def matmul(a,b):
    c=mat_zero()
    for i in range(N):
        for k in range(N):
            if a[i][k]!=ZERO:
                for j in range(N):
                    if b[k][j]!=ZERO:c[i][j]=add(c[i][j],mul(a[i][k],b[k][j]))
    return c

def invert_matrix(a):
    r=[row[:] + identity for row,identity in zip(a,mat_identity())]
    determinant=ONE
    for c in range(N):
        k=next(k for k in range(c,N) if r[k][c]!=ZERO)
        if k!=c:r[c],r[k]=r[k],r[c];determinant=neg(determinant)
        pivot=r[c][c]; determinant=mul(determinant,pivot)
        scale=inv(pivot);r[c]=[mul(x,scale) for x in r[c]]
        for k in range(N):
            if k!=c and r[k][c]!=ZERO:
                scale=r[k][c]
                r[k]=[sub(x,mul(scale,y)) for x,y in zip(r[k],r[c])]
    assert [row[:N] for row in r]==mat_identity()
    return [row[N:] for row in r],determinant

def vector(v):
    assert isinstance(v,list) and len(v)==5 and all(type(x) is int and 0<=x<P for x in v)
    return tuple(v)
def matrix_from_json(m):
    assert len(m)==N and all(len(row)==N for row in m)
    return [[vector(x) for x in row] for row in m]
def digest_json(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def base_rref(matrix):
    r=[row[:] for row in matrix]; pivots=[];lead=0
    for c in range(len(r[0])):
        ks=[k for k in range(lead,len(r)) if r[k][c]%P]
        if not ks: continue
        k=ks[0];r[lead],r[k]=r[k],r[lead]
        u=pow(r[lead][c],-1,P);r[lead]=[x*u%P for x in r[lead]]
        for j in range(len(r)):
            if j!=lead:
                u=r[j][c];r[j]=[(x-u*y)%P for x,y in zip(r[j],r[lead])]
        pivots.append(c);lead+=1
        if lead==len(r):break
    return r,pivots

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--candidate');ap.add_argument('--out',default='RESULTS.json');args=ap.parse_args()
    here=pathlib.Path(__file__).resolve().parent
    w=json.loads((here/'MINIMAL_WITNESS.json').read_text())
    assert (w['p'],w['N'],w['q'],w['modulus'])==(P,N,Q,MOD)
    assert pow(Q,N,P)==1 and Q!=1 and pow(N,-1,P)==21
    candidate=None; manifests=[]
    if args.candidate:
        raw=pathlib.Path(args.candidate).read_bytes();assert hashlib.sha256(raw).hexdigest()==EXPECTED_ARCHIVE
        with zipfile.ZipFile(args.candidate) as z:
            for f in json.loads(z.read('MANIFEST.json')):
                contents=z.read(f['path']);assert len(contents)==f['bytes'];assert hashlib.sha256(contents).hexdigest()==f['sha256'];manifests.append(f['path'])
            candidate=json.loads(z.read('TWELVE_BANK_WITNESS.json'))
    frobenius=[poly_pow([0,1],P**k,MOD) for k in range(1,6)]
    gcds=[poly_gcd(MOD,poly_sub(frobenius[k-1],[0,1])) for k in (1,2)]
    assert gcds==[[1],[1]] and frobenius[4]==[0,1]
    linear_factors=[a for a in range(P) if not poly_rem(MOD,[a,1])]
    quadratic_factors=[(a,b) for a in range(P) for b in range(P) if not poly_rem(MOD,[a,b,1])]
    assert not linear_factors and not quadratic_factors
    roots=[fpow(Z,P**i) for i in range(5)]
    assert len(set(roots))==5 and all(x!=ZERO for x in roots)
    for root in roots:
        v=ZERO
        for c in reversed(MOD):v=add(mul(v,root),const(c))
        assert v==ZERO
    root_product=[ONE]
    for x in roots:
        next_product=[ZERO]*(len(root_product)+1)
        for i,c in enumerate(root_product):
            next_product[i]=sub(next_product[i],mul(x,c));next_product[i+1]=add(next_product[i+1],c)
        root_product=next_product
    assert root_product==[const(x) for x in MOD]
    # Literal S and T; columns encode action on e_t.
    S,T=mat_zero(),mat_zero()
    for t in range(N):S[(t+1)%N][t]=ONE;T[t][t]=const(pow(Q,t,P))
    assert matmul(T,S)==[[sc(x,Q) for x in row] for row in matmul(S,T)]
    target=[[const(pow(Q,(-k*t)%N,P)) for t in range(N)] for k in range(N)]
    total=mat_zero();bank_records=[];counts=collections.Counter();all_h=[]
    C=sum(pow(Q,(-t*t)%N,P) for t in range(N))*pow(N,-1,P)%P
    assert C==18
    for bi,b in enumerate(w['banks']):
        eps,delt=b['orientation'];assert eps in (-1,1) and delt in (-1,1);counts[(eps,delt)]+=1
        alpha,beta=vector(b['alpha']),vector(b['beta']);assert alpha!=ZERO and beta==ONE
        delta=sub(sub(ONE,fpow(alpha,N)),fpow(beta,N));assert delta!=ZERO and delta==neg(fpow(alpha,N))
        weights=list(map(vector,b['raw_weights']));assert len(weights)==N and any(x!=ZERO for x in weights)
        if eps==delt:assert alpha in roots
        else:assert alpha==const(4)
        bank=mat_zero();branch_digests=[];branch_determinants=[]
        for j,weight in enumerate(weights):
            # Direct original matrix I - alpha S^eps - beta q^(eps*delt*j) T^delt.
            A=mat_identity()
            for t in range(N):
                A[(t+eps)%N][t]=sub(A[(t+eps)%N][t],alpha)
                v=mul(beta,const(pow(Q,(eps*delt*j+delt*t)%N,P)))
                A[t][t]=sub(A[t][t],v)
            Ai,det=invert_matrix(A)
            assert det==delta
            assert matmul(A,Ai)==mat_identity() and matmul(Ai,A)==mat_identity()
            branch_determinants.append(det);branch_digests.append(digest_json(Ai))
            for k in range(N):
                for t in range(N):bank[k][t]=add(bank[k][t],sc(mul(weight,Ai[k][t]),pow(N,-1,P)))
        assert any(v!=ZERO for row in bank for v in row)
        for k in range(N):
            for t in range(N):total[k][t]=add(total[k][t],bank[k][t])
        h=[]
        for ell in range(N):
            acc=ZERO
            for j in range(N):acc=add(acc,sc(weights[j],pow(Q,(eps*delt*j*ell)%N,P)))
            h.append(mul(acc,inv(sc(delta,C*N%P))))
        all_h.append(h)
        if candidate:
            cb=candidate['banks'][bi]
            assert cb['index']==bi and tuple(cb['orientation'])==(eps,delt)
            assert vector(cb['alpha'])==alpha and vector(cb['beta'])==beta and vector(cb['delta'])==delta
            assert list(map(vector,cb['raw_weights']))==weights
            assert matrix_from_json(cb['bank_matrix'])==bank
            assert list(map(vector,cb['normalized_sector_amplitudes']))==h
            assert cb['branch_checks']==[{'inverse_sha256':v,'j':j,'left_inverse':True,'right_inverse':True} for j,v in enumerate(branch_digests)]
        bank_records.append({'index':bi,'orientation':[eps,delt],'alpha':alpha,'delta':delta,'all_11_determinants_equal_delta':True,'branch_inverse_sha256':branch_digests,'bank_matrix_sha256':digest_json(bank),'bank_nonzero':True})
        print('bank %d: 11 two-sided inverses, Delta, raw weights and nonzero matrix verified'%bi,flush=True)
    assert len(w['banks'])==12
    orientation_counts=[counts[s] for s in [(1,1),(-1,1),(1,-1),(-1,-1)]]
    assert orientation_counts==[5,1,1,5]
    for indices in [range(5),range(7,12)]:assert [vector(w['banks'][i]['alpha']) for i in indices]==roots
    assert total==target
    trace_gram=[]
    for a in range(5):
        row=[]
        for j in range(5):
            tr=ZERO
            for root in roots:tr=add(tr,fpow(root,a+j))
            assert tr[1:]==(0,0,0,0);row.append(tr[0])
        trace_gram.append(row)
    _,trace_pivots=base_rref(trace_gram);assert len(trace_pivots)==5
    for offset in [0,7]:
        for ell in range(N):
            for i in range(5):assert all_h[offset+i][ell]==fpow(all_h[offset][ell],P**i)
    # Independently rebuild row systems by LEFT multiplication in the algebra.
    # (U+V) U^r V^ell = U^(r+1)V^ell + q^(eps*delt*r)U^r V^(ell+1).
    gaussian={}
    for eps,delt in [(1,1),(-1,1),(1,-1),(-1,-1)]:
        layer={(0,0):1};coeffs={}
        for degree in range(N+1):
            if degree<N:coeffs.update(layer)
            else:assert layer=={(N,0):1,(0,N):1}
            nxt={}
            for (r,ell),c in layer.items():
                nxt[(r+1,ell)]=(nxt.get((r+1,ell),0)+c)%P
                nxt[(r,ell+1)]=(nxt.get((r,ell+1),0)+c*pow(Q,(eps*delt*r)%N,P))%P
            layer={key:v for key,v in nxt.items() if v}
        gaussian[(eps,delt)]={(a,b):coeffs.get(((eps*a)%N,(delt*b)%N),0) for a in range(N) for b in range(N)}
    # Rebuild the two forced moment sequences and their six recurrence gates.
    moments=[];forced=[];gate=[]
    for b in [1,2]:
        t=pow(pow(4,b,P)*gaussian[(-1,1)][(N-b,b)]%P,-1,P);forced.append(t)
        seq=[]
        for a in range(b,N-b):
            top=(pow(Q,(3*(a+b)**2)%N,P)-t*pow(4,N-a,P)*gaussian[(-1,1)][(a,b)])%P
            seq.append(top*pow(gaussian[(1,1)][(a,b)],-1,P)%P)
        moments.append(seq);gate.extend(seq[i:i+6] for i in range(len(seq)-5))
    _,gatepiv=base_rref(gate);assert len(gatepiv)==5
    assert all(sum(x*y for x,y in zip(row,MOD))%P==0 for row in gate)
    minor=0
    for perm in itertools.permutations(range(5)):
        inversions=sum(perm[i]>perm[j] for i in range(5) for j in range(i+1,5))
        product=(-1)**inversions
        for i in range(5):product=product*gate[i][perm[i]]%P
        minor=(minor+product)%P
    assert minor==3
    gate_certificate={'matrix':gate,'moments':moments,'forced_amplitudes':forced,'rank':len(gatepiv),'first_five_minor':minor,'unique_monic_kernel':MOD,'all_six_residuals_zero':True}
    if candidate:
        with zipfile.ZipFile(args.candidate) as z:nine=json.loads(z.read('FRESH_NINE.json'))
        entry=next(item for item in nine if (item['q'],item['y'])==(Q,4))
        for key,value in [('matrix',gate),('moments',moments),('forced_amplitudes',forced),('rank',5),('minor',3),('g',MOD)]:assert entry[key]==value
    powers=[poly_pow([0,1],a,MOD)+[0]*5 for a in range(N)]
    powers=[p[:5] for p in powers]
    rows=[];coefficient_checks=0
    for b in range(N):
        A=[];rhs=[]
        for a in range(N):
            coeff=sum(pow(Q,(-b*t)%N,P)*pow(Q,(-((t+a)%N)*t)%N,P) for t in range(N))*pow(N,-1,P)%P
            f=pow(Q,(3*(a+b)**2)%N,P);assert coeff==C*f%P;coefficient_checks+=1;rhs.append(f)
            A.append([gaussian[(1,1)][(a,b)]*x%P for x in powers[a]]+
                     [gaussian[(-1,1)][(a,b)]*pow(4,(-a)%N,P)%P,gaussian[(1,-1)][(a,b)]*pow(4,a,P)%P]+
                     [gaussian[(-1,-1)][(a,b)]*x%P for x in powers[(-a)%N]])
        rr,piv=base_rref(A);_,augpiv=base_rref([row+[r] for row,r in zip(A,rhs)])
        assert len(piv)==len(augpiv)
        # Recover the 12 solution coordinates directly from the supplied weights.
        sol=[]
        for a in range(5):
            s=ZERO
            for i in range(5):s=add(s,mul(all_h[i][b],fpow(roots[i],a)))
            assert s[1:]==(0,0,0,0);sol.append(s[0])
        for i in [5,6]:
            h=all_h[i][(w['banks'][i]['orientation'][1]*b)%N];assert h[1:]==(0,0,0,0);sol.append(h[0])
        for a in range(5):
            s=ZERO
            for i in range(5):s=add(s,mul(all_h[i+7][(-b)%N],fpow(roots[i],a)))
            assert s[1:]==(0,0,0,0);sol.append(s[0])
        assert all(sum(x*y for x,y in zip(row,sol))%P==r for row,r in zip(A,rhs))
        if candidate:
            cb=candidate['row_systems'][b]
            assert cb=={'b':b,'matrix':A,'pivots':piv,'rank':len(piv),'rhs':rhs,'solution':sol}
        rows.append({'b':b,'rank':len(piv),'pivots':piv,'solution':sol})
    assert [r['rank'] for r in rows]==[11,7,9,10,11,11,11,11,10,9,7]
    if candidate:
        assert matrix_from_json(candidate['summed_literal_matrix'])==total
        assert matrix_from_json(candidate['target'])==target
        assert candidate['roots']==[list(r) for r in roots]
        assert candidate['modulus']==MOD and candidate['C']==C
    result={'verdict':'ACCEPT','candidate_archive_sha256':EXPECTED_ARCHIVE,'candidate_manifest_members_verified':manifests,
        'minimal_witness_sha256':hashlib.sha256((here/'MINIMAL_WITNESS.json').read_bytes()).hexdigest(),
        'field':{'p':P,'degree':5,'cardinality':P**5,'modulus_ascending':MOD,'frobenius_residues_k1_to_k5':frobenius,'gcd_k1_k2':gcds,'monic_linear_candidates_tested':P,'monic_quadratic_candidates_tested':P**2,'linear_factors':linear_factors,'quadratic_factors':quadratic_factors,'roots':roots},
        'q':Q,'order':N,'C':C,'bank_count':12,'orientation_counts':orientation_counts,'banks':bank_records,
        'raw_weights':132,'literal_branch_inversions':132,'matrix_product_identities':264,'determinants_equal_legal_denominator':132,
        'bank_matrices_nonzero':12,'fourier_entries_equal':121,'independent_target_coefficient_checks':coefficient_checks,'row_systems':rows,
        'trace_gram':trace_gram,'trace_gram_rank':5,'amplitude_frobenius_checks':110,'rank_five_gate':gate_certificate,'summed_matrix_sha256':digest_json(total),'target_matrix_sha256':digest_json(target),
        'scope':'Exact fixed N=11 extension-field upper bound 12; no optimality, speed, all-N, characteristic-zero, arbitrary-singleton, or novelty claim.'}
    pathlib.Path(args.out).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('ACCEPT: all 132 literal branch inverses and 121 target entries verified.',flush=True)
if __name__=='__main__':main()
