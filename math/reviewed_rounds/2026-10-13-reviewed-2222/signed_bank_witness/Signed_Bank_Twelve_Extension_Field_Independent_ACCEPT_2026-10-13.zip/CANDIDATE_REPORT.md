# Candidate: twelve original signed banks over F23^5 at N=11

13 October 2026. **Candidate, pending independent review.**

## Decisive scoped result

For q=13 in F23, the negative Fourier matrix F[k,t]=13^(-kt), 0<=k,t<=10, has an exact representation by twelve original legal banks over

    L = F23[z]/(g(z)),
    g(z)=z^5+8z^4+z^3+18z^2+4z+6.

The polynomial is irreducible of degree five, so L has exactly 23^5=6,436,343 elements. Orientation counts are (5,1,1,5) in the order (++,-+,+-,--). Both cross-sign singleton nodes are 4. Both same-sign groups use the five distinct roots of g. Every beta is 1, all twelve banks are nonzero, and every legal denominator Delta=-alpha^11 is nonzero.

This is an explicit extension-field witness, and it refutes extending the prior all-F23 fourteen-bank lower bound to arbitrary extension-valued bank nodes under the same cross-sign-singleton architecture. It does not contradict that accepted base-field theorem. It is only an upper bound of twelve at this fixed N and field; it is not a proof that twelve is optimal. No characteristic-zero transfer, extension-valued-singleton theorem, all-N result, arithmetic-speed claim, or historical novelty claim is made.

## Exact roots and encoding

A vector (a0,...,a4) means a0+a1*z+...+a4*z^4 in L. The five roots, in order, are z^(23^i), i=0,...,4:

    (0,1,0,0,0)
    (22,19,22,2,11)
    (0,4,14,16,6)
    (6,16,9,3,6)
    (10,6,1,2,0)

Their pairwise distinctness and g(root)=0 are directly checked. Irreducibility is proved by gcd(g,t^23-t)=gcd(g,t^(23^2)-t)=1 and t^(23^5)-t=0 modulo g. Every reducible degree-five polynomial has an irreducible factor of degree at most two, so these checks suffice. A second finite factor-enumeration route tests every monic linear and quadratic factor.

## Original legal objects

No new generators or transformations are introduced. Set S e_t=e_(t+1 mod11), T e_t=q^t e_t. Then TS=qST. Each bank is exactly

    B_(epsilon,delta)(alpha,1;w)
      = (1/11) sum_(j=0)^10 w_j
        (I-alpha S^epsilon-q^(epsilon*delta*j)T^delta)^(-1).

The file TWELVE_BANK_WITNESS.json is the complete explicit witness: it lists every bank's signs, alpha, beta, Delta, all eleven raw phase weights, all eleven normalized sector amplitudes, and its full 11-by-11 literal bank matrix. All values use the fixed field-vector encoding above. There are 12 parameter/sign pairs, 132 raw weights and 132 branch inverses.

For the five same-sign nodes, the Delta vectors are respectively

    (7,15,5,0,6), (14,14,21,21,21), (10,9,5,10,16),
    (3,17,21,19,9), (15,14,17,19,17).

Both singleton Deltas are (22,0,0,0,0). All are nonzero in the field. No supplied algebraic root is treated as a cost-free numerical operation: the field and roots are exact mathematical parameters of this finite construction. This packet does not estimate the cost of constructing field arithmetic or evaluating those branches, and it does not turn a bank count into an FFT runtime claim.

## Construction and complete row compatibility

Fresh original noncommutative coefficient recurrence gives, for r=[epsilon*a]_11 and ell=[delta*b]_11,

    D(r,ell)=q^(epsilon*delta*ell)D(r-1,ell)+D(r,ell-1),
    D(0,0)=1.

The Gaussian factor G is D(r,ell) if r+ell<=10 and zero otherwise. Degree-eleven mixed terms vanish. Direct finite target extraction gives C*f(a,b), with C=18 and f(a,b)=q^(3(a+b)^2); all 121 extracted coefficients are checked against the direct finite sum.

The forced b=1 and b=2 moments for q=13,y=4 produce the unique monic recurrence g, with a nonzero 5-by-5 minor equal to 3. All six original recurrence residuals are zero. The squarefree polynomial g has nonzero constant term. To construct the full target, let p_a be the length-five ascending vector for t^a modulo g. For each b solve the original coefficient matrix with a-th row

    (G_++(a,b)*p_a,
     G_-+(a,b)*4^([-a]_11),
     G_+-(a,b)*4^a,
     G_--(a,b)*p_([-a]_11)).

The twelve unknown coordinates are the first five ++ moments, the two singleton amplitudes, and the first five -- moments. Every complete 11-equation row is compatible. Ranks for b=0,...,10 are

    11,7,9,10,11,11,11,11,10,9,7.

TWELVE_BANK_WITNESS.json contains every original row matrix, right-hand side, pivot set, and solution. No sufficiency is inferred merely from the first two recurrence gates.

To recover individual amplitudes from a group's five moments K_a, solve the trace pairing

    sum_(j=0)^4 Tr_(L/F23)(z^(a+j))*H_j=K_a, 0<=a<=4.

Its invertibility is directly verified. The amplitude at root x is H(x). This trace construction is simply simultaneous Vandermonde interpolation because Tr(H(z)z^a)=sum_(g(x)=0)H(x)x^a. For --, the sector index is ell=[-b]_11. For each actual bank the raw weights are reconstructed by

    w_j = C*Delta*sum_(ell=0)^10 h_ell*q^(-epsilon*delta*j*ell).

The original 1/11 factor is retained. Beta=1 and nonzero Delta establish legality.

## Literal validation, independent of coefficient tables

The decisive validation explicitly builds every 11-by-11 matrix

    I-alpha S^epsilon-q^(epsilon*delta*j)T^delta

in the field L. It computes each inverse by Gauss-Jordan elimination; it does not use the Gaussian coefficient formula or a recurrence-derived inverse. Both multiplication orders are checked against identity for all 132 branches, giving 264 inverse-product checks. Each weighted inverse is added with the actual factor 1/11. The twelve resulting bank matrices sum to the direct target q^(-kt) in every one of its 121 entries, with zero extension coordinates beyond the constant coordinate.

Every individual bank has at least one nonzero raw weight. Since alpha is nonzero and beta=1, the full finite-character sector transform is invertible, so these are nonzero banks. The stored bank matrices are additionally available to inspect their nonzero values directly. The same-sign nodes are distinct. The witness therefore uses the stated twelve actual banks with the desired effective orientation counts.

## Replay and status

Run the fresh standard-library checker:

    python fresh_check.py --only-twelve --out replay

The two scientific files FRESH_NINE.json and TWELVE_BANK_WITNESS.json reproduce exactly. The checker never executes or imports historical programs. It rebuilds the moments, polynomial, field, all row systems, roots, raw weights and literal branch inverses from its declared constants. The other code paths are for the separately documented one-sided classification and are not needed to verify this packet.

The predecessor scientific claims used for context are the accepted nine-case report/review identified in SOURCE_PROVENANCE.json. Their programs were not run. Exploratory freshly written probes preceded the final check; the contract does not claim to predate those probes. No external writes were made.

Next priority: **88/100**, independent exact review of this counterexample and its extension-field scope before incorporating it into any accepted research table. The larger extension-node classification is a separate candidate deliverable. Historical novelty remains unresolved.
