# Candidate scope and check contract

13 October 2026. Written after the exploratory modular row tests in probe_fresh.py and factor_probe_fresh.py, before the final literal-resolvent checker.

Resolve the nine rank-five N11/F23 pairs under extension-valued same-sign nodes and legal parameters. Preserve q and the minus-plus singleton y as the stated base-field values. Do not claim anything for extension-valued singleton nodes, arbitrary characteristic, unrestricted minima, or FFT complexity.

Prove the repeated-root case cannot use five ordinary plus-plus nodes over any extension. For the eight squarefree cases, reconstruct original legal banks over the splitting fields and verify all 121 entries by literal 11-by-11 branch inverses. In particular, check the exploratory mirrored (5,1,1,5) template for q=13, y=4. Beta=1 is permitted; Delta=-alpha^11 must be nonzero for every bank.

All scientific programs executed are newly written in this directory. Historical reports and JSON may be read as inert source data after fresh calculations; historical scientific programs are not executed or imported. No external writes are authorized for this task.

Reports remain candidate pending independent review. Finite validation workloads and supplied algebraic roots are reported separately from bank counts and computation cost. Historical novelty is unresolved.
