"""Fresh independent arithmetic/support controls; no candidate or historical imports."""
import itertools
import json
import random
from pathlib import Path

P = 17
RNG = random.Random(261353)

def ident(n):
    return [[int(i == j) for j in range(n)] for i in range(n)]

def rank(a, p=P):
    a = [[x % p for x in row] for row in a]
    h = len(a)
    w = len(a[0]) if h else 0
    r = 0
    for j in range(w):
        pivot = next((i for i in range(r,h) if a[i][j]), None)
        if pivot is None:
            continue
        a[r],a[pivot] = a[pivot],a[r]
        z = pow(a[r][j],-1,p)
        a[r] = [x*z%p for x in a[r]]
        for i in range(r+1,h):
            z=a[i][j]
            a[i]=[(x-z*y)%p for x,y in zip(a[i],a[r])]
        r += 1
        if r == h:
            break
    return r

def inv(a,p=P):
    n=len(a)
    rows=[[x%p for x in row]+irow for row,irow in zip(a,ident(n))]
    for j in range(n):
        pivot=next((i for i in range(j,n) if rows[i][j]),None)
        if pivot is None:
            raise ValueError('singular')
        rows[j],rows[pivot]=rows[pivot],rows[j]
        c=pow(rows[j][j],-1,p)
        rows[j]=[c*x%p for x in rows[j]]
        for i in range(n):
            if i!=j:
                c=rows[i][j]
                rows[i]=[(x-c*y)%p for x,y in zip(rows[i],rows[j])]
    return [row[n:] for row in rows]

def mul(a,b):
    return [[sum(x*y for x,y in zip(row,col))%P for col in zip(*b)] for row in a]

def cut(a,v,w):
    return [[a[i][j] for j in w] for i in v]

def conj(a,pi):
    n=len(a)
    b=[[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            b[pi[i]][pi[j]]=a[i][j]
    return b

def denominator(m,alpha,beta):
    n=m*m
    q=pow(3,16//m,P)
    a=ident(n)
    for x in range(m):
        for y in range(m):
            i=x*m+y
            a[i][((x-1)%m)*m+y]=(a[i][((x-1)%m)*m+y]-alpha[x])%P
            a[i][x*m+(y-1)%m]=(a[i][x*m+(y-1)%m]-beta*pow(q,x,P))%P
    return a

counts={'small_inverse_checks':0,'qtgf_cut_checks':0,'endpoint_checks':0,'grid_deletions':0}
# All invertible 2x2 matrices over GF(3), including singular principal blocks.
for vals in itertools.product(range(3),repeat=4):
    a=[list(vals[:2]),list(vals[2:])]
    try: b=inv(a,3)
    except ValueError: continue
    for v,w in [([0],[1]),([1],[0])]:
        assert rank(cut(a,v,w),3)==rank(cut(b,v,w),3)
        counts['small_inverse_checks']+=1

# Actual q-torus denominators with nonzero q-directions, transport by grid symmetries,
# and intermediate diagonal masks that may be singular.
for m in [2,4,8]:
    n=m*m
    for trial in range(3):
        word=ident(n)
        budgets={}
        for d in range(1,4):
            while True:
                alpha=[RNG.randrange(P) for _ in range(m)]
                qmat=denominator(m,alpha,3)
                try: inv(qmat); break
                except ValueError: pass
            swap=RNG.randrange(2)
            sx,sy=RNG.choice([-1,1]),RNG.choice([-1,1])
            tx,ty=RNG.randrange(m),RNG.randrange(m)
            pi=[]
            for x in range(m):
                for y in range(m):
                    u,v=(y,x) if swap else (x,y)
                    pi.append(((sx*u+tx)%m)*m+(sy*v+ty)%m)
            qmat=conj(qmat,pi)
            iq=inv(qmat)
            stage=[[(2*iq[i][j]-int(i==j))%P for j in range(n)] for i in range(n)]
            diag=[RNG.randrange(P) for _ in range(n)]
            word=mul(stage,[[diag[i]*x%P for x in row] for i,row in enumerate(word)])
            rp=list(range(n));cp=list(range(n));RNG.shuffle(rp);RNG.shuffle(cp)
            left=[RNG.randrange(P) for _ in range(n)];right=[RNG.randrange(P) for _ in range(n)]
            output=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(n):
                    output[rp[i]][cp[j]]=left[i]*word[i][j]*right[j]%P
            for k in [k for k in [2,4,8] if m%k==0]:
                for j in range(k):
                    v=list(range(j*n//k,(j+1)*n//k));w=sorted(set(range(n))-set(v))
                    r=rank(cut(qmat,v,w))
                    assert r<=m
                    assert rank(cut(iq,v,w))==r
                    budgets[k,j]=budgets.get((k,j),0)+r
                    assert rank(cut(word,v,w))<=budgets[k,j]<=d*m
                    counts['qtgf_cut_checks']+=1
                    assert rank(cut(output,[rp[x] for x in v],[cp[x] for x in w]))<=budgets[k,j]
                    counts['endpoint_checks']+=1

arbitrary=[]
for m in [2,4,8]:
    n=m*m
    pi=[(c%2)*(n//2)+a*(m//2)+c//2 for a in range(m) for c in range(m)]
    ranks=[]
    for beta in [0,3]:
        mat=conj(denominator(m,[0]*m,beta),pi)
        rr=rank(cut(mat,list(range(n//2)),list(range(n//2,n))))
        assert rr==(0 if beta==0 else n//2)
        ranks.append(rr)
    arbitrary.append({'m':m,'beta_zero_rank':ranks[0],'beta_nonzero_rank':ranks[1]})

# Lift of Qv Qh has identity, horizontal, vertical and diagonal grid edges.
# Exhaust all deletion sets smaller than the proved m/sqrt(2) threshold.
for m in [2,3,4,5]:
    n=m*m
    adj=[set() for _ in range(2*n)]
    for x in range(m):
        for y in range(m):
            i=x*m+y
            js=[i]
            if x: js.append((x-1)*m+y)
            if y: js.append(x*m+y-1)
            if x and y: js.append((x-1)*m+y-1)
            for j in js:
                adj[i].add(n+j);adj[n+j].add(i)
    for s in range(m):
        if 2*s*s>=m*m: break
        for deleted in itertools.combinations(range(2*n),s):
            remain=set(range(2*n))-set(deleted)
            maxsize=0
            while remain:
                seed=remain.pop();todo=[seed];size=0
                while todo:
                    v=todo.pop();size+=1
                    new=adj[v]&remain
                    remain-=new;todo.extend(new)
                maxsize=max(maxsize,size)
            assert maxsize>n
            counts['grid_deletions']+=1

result={'status':'PASS','counts':counts,'routing_countercontrol':arbitrary,
        'limits':'Exact finite fields test algebraic ranks and support only. Complex error inequalities were checked by independent proof, not inferred from modular tests. No source/candidate checker was executed.'}
Path(__file__).with_name('CHECK_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
