"""Fresh exact small polynomial controls and inert legacy-coordinate comparisons.

Does not import or execute the producer or any predecessor scientific code.
"""
import hashlib,json,math,pathlib,time
H=pathlib.Path(__file__).resolve().parent;ROOT=H.parent
t=time.monotonic()
f=[sum(math.comb(25*k,j) for k in range(5) if j<=25*k)%25 for j in range(101)]
def power_q(exponent):
    a=exponent%27;b=exponent%125
    row=[math.comb(b,j)%25 for j in range(b+1)]+[0]*max(0,100-b-1)
    for j in range(len(row)-1,99,-1):
        c=row[j]
        for k in range(100):row[j-100+k]=(row[j-100+k]-c*f[k])%25
    alpha=[(a,1)] if a<18 else [(a-9,-1),(a-18,-1)]
    return [(j*18+i,(c*s)%25) for j,c in enumerate(row[:100]) if c for i,s in alpha]
def qadd(a,b,shift=0):
    d=a.copy()
    for e,c in b.items():d[e+shift]=d.get(e+shift,0)+c
    return {e:c for e,c in d.items() if c}
def gaussian(n):
    row=[{0:1}]
    for nn in range(1,n+1):
        row=[qadd(row[k] if k<len(row) else {},row[k-1] if k else {},nn-k) for k in range(nn+1)]
    return row
cases=[]
for m in range(9):
    n=2*m+1;g=gaussian(n);quot=[];last={}
    for k in range(n):
        last=qadd(g[k],{e:-c for e,c in last.items()});quot.append(last)
    assert quot[-1]==g[-1]
    for step in [1,1001]:
        raw=bytearray(2*(m+1)*1800)
        images={e:power_q(step*e) for poly in quot for e in poly}
        for degree,poly in enumerate(quot):
            for v in range(degree+1):
                s=(-1 if degree%2 else 1)*math.comb(degree,v)
                for e,c in poly.items():
                    scalar=(s*c)%25
                    if scalar:
                        for pos,w in images[e]:raw[v*1800+pos]=(raw[v*1800+pos]+scalar*w)%25
        got=(H/f'small_m{m}_q{step}_U_ap.bin').read_bytes()
        assert raw==got,(m,step,'raw U mismatch')
        cases.append({'m':m,'q_exponent':step,'coordinates_compared':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
raw=(H/'R843_U_ap.bin').read_bytes();F=(H/'R843_F_pi140.bin').read_bytes()
assert len(raw)==360000 and len(F)==360000
refs=[]
paths=['bounded_normalization_recovery/fresh/center0_full.json','bounded_higher_layer_source/independent_reciprocal/u1687_independent.json','bounded_normalization_review/recomputed.json']
for path in paths:
    p=ROOT/path;obj=json.loads(p.read_bytes())
    if 'coefficients_v_x_eta' in obj:
        arr=obj['coefficients_v_x_eta'];degrees=len(arr);ref=bytes(c for v in arr for a in v for c in a)
    else:
        degrees=max(item[1] for item in obj['coefficients'])+1
        a=bytearray(degrees*1800)
        for j,v,coeff in obj['coefficients']:a[v*1800+j*18:v*1800+j*18+18]=bytes(coeff)
        ref=bytes(a)
    observed=bytes(c%5 for c in raw[:len(ref)])
    assert observed==ref,(path,'legacy mismatch')
    refs.append({'path':path,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'raw_degrees':degrees,'coordinates_compared':len(ref),'canonical_mod5_sha256':hashlib.sha256(ref).hexdigest()})
A=[1,1,0,4,4,1,2,3,2,3,0,0,4,2,2,3,2,1]
residue=bytearray(200*18)
for v,mult in [(10,1),(30,3),(50,1)]:residue[v*18:v*18+18]=bytes(mult*c%5 for c in A)
observed=bytes(F[v*1800+a]%5 for v in range(200) for a in range(18))
assert observed==residue
def val(v):return min([j+(100 if c%5==0 else 0) for j in range(100) for c in v[j*18:j*18+18] if c] or [200])
vals=[val(raw[v*1800:(v+1)*1800]) for v in range(200)]
assert min(v+vals[v] for v in range(200))==60
assert [(v,vals[v]) for v in [0,10,50,60,62]]==[(0,75),(10,50),(50,10),(60,1),(62,0)]
result={'status':'PASS','fresh_gaussian_cases':cases,'old_raw_reference_checks':refs,'F_residue_A_Y10_times_Y4_minus1_power10':True,'content_exactly60':True,'raw_newton_selected_vertices':[[v,vals[v]] for v in [0,10,50,60,62]],'all_raw_U_coefficient_valuation_or_lower_bounds':vals,'seconds':time.monotonic()-t,'authorship':'Implementation-diverse checks by producer; separate reviewer acceptance is not claimed.'}
(H/'CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['fresh_gaussian_cases','all_raw_U_coefficient_valuation_or_lower_bounds']},indent=2))
