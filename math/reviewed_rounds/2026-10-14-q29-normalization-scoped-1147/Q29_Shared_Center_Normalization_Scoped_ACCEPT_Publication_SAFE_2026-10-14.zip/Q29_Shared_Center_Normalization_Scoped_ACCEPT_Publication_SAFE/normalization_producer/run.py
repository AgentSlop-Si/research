"""New, sequential, bounded controller. No predecessor code is imported."""
import hashlib, json, math, os, pathlib, resource, signal, subprocess, time
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent
start=time.monotonic()
def cpu():
    a=resource.getrusage(resource.RUSAGE_SELF);b=resource.getrusage(resource.RUSAGE_CHILDREN)
    return a.ru_utime+a.ru_stime+b.ru_utime+b.ru_stime
cpu0=cpu()
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
signal.alarm(180)
records=[]
def run(name,args):
    remaining_cpu=120-(cpu()-cpu0)
    remaining_wall=180-(time.monotonic()-start)
    assert remaining_cpu>2 and remaining_wall>2
    def caps():
        resource.setrlimit(resource.RLIMIT_CPU,(max(1,int(remaining_cpu)-1),max(2,int(remaining_cpu))))
        resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    t=time.monotonic();c=cpu()
    p=subprocess.run(args,cwd=HERE,capture_output=True,timeout=remaining_wall-1,preexec_fn=caps)
    (HERE/(name+'.stdout')).write_bytes(p.stdout);(HERE/(name+'.stderr')).write_bytes(p.stderr)
    records.append({'name':name,'args':args,'exit_code':p.returncode,'wall_seconds':time.monotonic()-t,'charged_cpu_seconds':cpu()-c})
    (HERE/'PARTIAL_RECEIPT.json').write_text(json.dumps(records,indent=2)+'\n')
    if p.returncode: raise RuntimeError(f'{name} failed: '+p.stderr.decode(errors='replace'))
    return p.stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=ROOT/'sparse_kernel_producer/R843_w100_mod25_zbasis.bin'
assert len(source.read_bytes())==180000 and sha(source)=='ebf51150ffbed6e87f3e08875451176963670801c59ffd9128336a02c43ca38c'
run('compile',['g++','-O3','-std=c++17','-Wall','-Wextra','-Werror','convert.cpp','-o','convert'])
selftest=json.loads(run('selftest',['./convert','--selftest']))
for m in range(9):
    for q in [1,1001]:
        src=ROOT/f'sparse_kernel_producer/control_m{m}_w{m+1}_q{q}.bin'
        run(f'small_m{m}_q{q}',['./convert',str(src),f'small_m{m}_q{q}',str(m),str(m+1)])
run('benchmark',['./convert',str(ROOT/'sparse_kernel_producer/bench_m192_w48_r0.bin'),'benchmark','192','48'])
bench=records[-1]
# Whole small-process interval is overcharged as conversion cost. Full ring
# normalization performs fewer than 60000 pi operations, while the isolated
# normalization control performs 3*(1+25+60+99+100+125+199)=1827 operations.
estimate=8*(5*max(bench['wall_seconds'],bench['charged_cpu_seconds'])+34*selftest['normalization_control_wall_seconds'])+5
gate={'wall_estimate_seconds':estimate,'cpu_estimate_seconds':estimate,'wall_remaining_seconds':180-(time.monotonic()-start),'cpu_remaining_seconds':120-(cpu()-cpu0),'memory_limit_bytes':512*1024**2,'small_controls_passed':True,'estimate_is_heuristic':True}
gate['admitted']=estimate<min(gate['wall_remaining_seconds'],gate['cpu_remaining_seconds'])
(HERE/'FULL_GATE.json').write_text(json.dumps(gate,indent=2)+'\n')
assert gate['admitted']
result=json.loads(run('full',['./convert',str(source),'R843','843','100']))
run('inert_reference_check',['python3','check_outputs.py'])
receipt={'admission':'ADMISSION.md','full_gate':gate,'selftest':selftest,'full':result,'processes':records,'total_wall_seconds':time.monotonic()-start,'total_charged_cpu_seconds':cpu()-cpu0,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'parent_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'input_sha256':sha(source),'outputs':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in HERE.glob('R843*.bin')}}
(HERE/'EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
