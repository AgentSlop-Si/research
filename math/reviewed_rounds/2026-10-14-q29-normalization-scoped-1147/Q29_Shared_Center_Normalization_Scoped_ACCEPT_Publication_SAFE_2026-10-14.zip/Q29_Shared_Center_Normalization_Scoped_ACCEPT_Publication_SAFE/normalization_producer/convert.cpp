#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using V=std::vector<int>;
constexpr int D=1800, MOD=25;
int md(int x){x%=MOD;return x<0?x+MOD:x;}
std::array<std::array<int,201>,844> choose{};
std::array<int,100> f{};
std::vector<V> zimages;
void init(){
  for(int n=0;n<=843;n++){
    choose[n][0]=1;
    for(int j=1;j<=std::min(n,200);j++)choose[n][j]=md(choose[n-1][j-1]+choose[n-1][j]);
  }
  for(int j=0;j<100;j++)for(int k=0;k<5;k++)f[j]=md(f[j]+choose[25*k][j]);
  zimages.assign(3375,V(D));
  zimages[0][0]=1;
  const int ex[]={0,225,675,900,1125,1575};
  const int co[]={1,-1,1,-1,1,-1};
  for(int e=1;e<3375;e++){
    int top=zimages[e-1][1799];
    for(int j=1;j<D;j++)zimages[e][j]=zimages[e-1][j-1];
    for(int t=0;t<6;t++)zimages[e][ex[t]]=md(zimages[e][ex[t]]-co[t]*top);
  }
}
V forward(const V& z){
  V ab(D),ap(D);
  for(int e=0;e<D;e++)if(z[e]){
    int a=e%27,b=e%125;
    std::vector<std::pair<int,int>> as,bs;
    if(a<18)as={{a,1}};else as={{a-9,-1},{a-18,-1}};
    if(b<100)bs={{b,1}};else bs={{b-25,-1},{b-50,-1},{b-75,-1},{b-100,-1}};
    for(auto [aa,s]:as)for(auto [bb,t]:bs)ab[bb*18+aa]+=s*t*z[e];
  }
  for(int &x:ab)x=md(x);
  for(int b=0;b<100;b++)for(int j=0;j<=b;j++)if(choose[b][j])
    for(int a=0;a<18;a++)ap[j*18+a]+=choose[b][j]*ab[b*18+a];
  for(int &x:ap)x=md(x);
  return ap;
}
V reverse(const V& ap){
  V ab(D),z(D);
  for(int j=0;j<100;j++)for(int b=0;b<=j;b++)if(choose[j][b]){
    int s=((j-b)%2?-1:1)*choose[j][b];
    for(int a=0;a<18;a++)ab[b*18+a]+=s*ap[j*18+a];
  }
  for(int &x:ab)x=md(x);
  for(int b=0;b<100;b++)for(int a=0;a<18;a++)if(ab[b*18+a]){
    int e=(1000*a+2376*b)%3375,c=ab[b*18+a];
    for(int t=0;t<D;t++)if(zimages[e][t])z[t]=md(z[t]+c*zimages[e][t]);
  }
  return z;
}
V mulpi(const V& x){
  V y(D);
  for(int a=0;a<18;a++){
    int t=x[99*18+a];
    y[a]=md(-f[0]*t);
    for(int j=1;j<100;j++)y[j*18+a]=md(x[(j-1)*18+a]-f[j]*t);
  }
  return y;
}
V divpi(const V& x){
  V y(D);
  for(int a=0;a<18;a++){
    if(x[a]%5)throw std::runtime_error("pi division guard failed");
    int t=-x[a]/5;y[99*18+a]=md(t);
    for(int j=1;j<100;j++)y[(j-1)*18+a]=md(x[j*18+a]+f[j]*t);
  }
  if(mulpi(y)!=x)throw std::runtime_error("division multiply-back failed");
  return y;
}
V canonical(V x,int precision){
  if(precision<1||precision>200)throw std::runtime_error("invalid precision");
  for(int j=0;j<100;j++)for(int a=0;a<18;a++){
    int m=(precision<=j?1:(precision<=100+j?5:25));
    x[18*j+a]%=m;
  }
  return x;
}
int valuation(const V& x){
  int v=200;
  for(int j=0;j<100;j++)for(int a=0;a<18;a++)if(x[j*18+a])
    v=std::min(v,j+(x[j*18+a]%5?0:100));
  return v;
}
void write(const std::string& p,const std::vector<V>& x){
  std::ofstream o(p,std::ios::binary);if(!o)throw std::runtime_error("output open");
  for(const auto &v:x)for(int c:v){unsigned char b=c;o.write(reinterpret_cast<const char*>(&b),1);}
  if(!o)throw std::runtime_error("output write");
}
void small(){
  for(int e=0;e<D;e++){
    V u(D);u[e]=1;
    if(reverse(forward(u))!=u)throw std::runtime_error("unit basis round trip");
  }
  V one(D);one[0]=1;
  V p=one;
  for(int i=0;i<200;i++){
    if(valuation(p)!=i)throw std::runtime_error("nilpotence valuation");
    p=mulpi(p);
  }
  if(valuation(p)!=200)throw std::runtime_error("pi200 nonzero");
  bool rejected=false;try{divpi(one);}catch(const std::runtime_error&){rejected=true;}
  if(!rejected)throw std::runtime_error("unit division not rejected");
  V u(D);for(int j=0;j<D;j++)u[j]=(j*7+3)%25;
  auto norm_start=std::chrono::steady_clock::now();
  for(int h: {1,25,60,99,100,125,199}){
    V a=u;for(int i=0;i<h;i++)a=mulpi(a);
    for(int i=0;i<h;i++)a=divpi(a);
    if(canonical(a,200-h)!=canonical(u,200-h))throw std::runtime_error("guarded quotient precision");
  }
  double norm_seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-norm_start).count();
  std::cout<<"{\"basis_roundtrips\":1800,\"pi_valuation_checks\":201,\"unit_rejected\":true,\"division_exponents\":[1,25,60,99,100,125,199],\"normalization_control_wall_seconds\":"<<norm_seconds<<"}\n";
}
int main(int argc,char **argv){
 try{
  auto start=std::chrono::steady_clock::now();init();
  if(argc==2&&std::string(argv[1])=="--selftest"){small();return 0;}
  if(argc!=5)throw std::runtime_error("usage: convert INPUT PREFIX M L");
  int m=std::stoi(argv[3]),L=std::stoi(argv[4]),K=2*L;
  if(m<0||m>843||L<1||L>100||L>m+1)throw std::runtime_error("bounds");
  std::ifstream in(argv[1],std::ios::binary);if(!in)throw std::runtime_error("input open");
  std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(in)),{});
  if(bytes.size()!=size_t(L*D))throw std::runtime_error("input length");
  std::vector<V> r(L,V(D)),u(K,V(D));
  for(int k=0;k<L;k++){
    V z(D);for(int e=0;e<D;e++){z[e]=bytes[k*D+e];if(z[e]>=25)throw std::runtime_error("noncanonical input");}
    r[k]=forward(z);if(reverse(r[k])!=z)throw std::runtime_error("full roundtrip");
    for(int j=2*k;j<K&&j<=m+k;j++){
      int c=choose[m-k][j-2*k];if((m+k)%2)c=-c;
      for(int i=0;i<D;i++)u[j][i]+=c*r[k][i];
    }
  }
  for(auto &v:u)for(int &x:v)x=md(x);
  std::string prefix=argv[2];
  write(prefix+"_R_ap.bin",r);write(prefix+"_U_ap.bin",u);
  if(m!=843||L!=100){std::cout<<"{\"small\":true,\"m\":"<<m<<",\"L\":"<<L<<"}\n";return 0;}
  std::vector<V> numerator(K,V(D)),normalized(K,V(D)),rich(K,V(D));
  int minimum=200;long long guards=0;
  std::ofstream prec(prefix+"_precision.csv");
  prec<<"Y_degree,raw_U_valuation_or_lower_bound,normalization_shift,coefficient_absolute_precision,materialized_precision\n";
  for(int j=0;j<K;j++){
    int v=valuation(u[j]);minimum=std::min(minimum,v+j);
    V n=u[j];for(int i=0;i<j;i++)n=mulpi(n);numerator[j]=n;
    for(int i=0;i<60;i++){n=divpi(n);guards++;}
    normalized[j]=canonical(n,140);
    V x=u[j];
    if(j<60)for(int h=0;h<60-j;h++){x=divpi(x);guards++;}
    else for(int h=0;h<j-60;h++)x=mulpi(x);
    int p=std::min(200,140+j);rich[j]=canonical(x,p);
    if(canonical(rich[j],140)!=normalized[j])throw std::runtime_error("two normalization routes disagree");
    prec<<j<<","<<v<<","<<(j-60)<<","<<(140+j)<<","<<p<<"\n";
  }
  if(minimum!=60)throw std::runtime_error("unexpected content");
  write(prefix+"_numerator_pi200.bin",numerator);
  write(prefix+"_F_pi140.bin",normalized);write(prefix+"_F_coefficientwise.bin",rich);
  double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  std::cout<<"{\"m\":843,\"w_exclusive\":100,\"v_exclusive\":200,\"coefficient_modulus\":25,\"basis\":\"pi-major alpha-minor\",\"raw_U_precision\":200,\"F_uniform_precision\":140,\"content_valuation\":"<<minimum<<",\"division_guard_and_multiply_back_checks\":"<<guards<<",\"full_R_roundtrip_count\":100,\"program_wall_seconds\":"<<elapsed<<"}\n";
 }catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 2;}
}
