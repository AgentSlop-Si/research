#!/usr/bin/env python3
"""Fresh tests of integral-center expansion from the independent F array."""
import hashlib
import json
import math
import time
from pathlib import Path
from audit import OUT, ROOT, WIDTH, valuation, project, seal

start=time.perf_counter()
raw=(OUT/'independent_F_pi140.bin').read_bytes()
f=[list(raw[WIDTH*j:WIDTH*(j+1)]) for j in range(200)]
assert len(raw)==360000

def shift_coeff(c,l):
    out=[0]*WIDTH
    for j in range(l,200):
        factor=math.comb(j,l)*pow(c,j-l,25)%25
        if factor:
            for i,v in enumerate(f[j]):
                out[i]+=factor*v
    return project(out,140)

legacy_path=ROOT/'bounded_normalization_recovery/controls/NORMALIZATION_AUDIT.json'
legacy=json.loads(legacy_path.read_text())
centers=[]
for entry in legacy['translations']:
    c=entry['residue_center']
    coeff=[shift_coeff(c,l) for l in range(11)]
    vals=[valuation(row,140) for row in coeff]
    h=entry['constant_valuation']
    assert vals[0]==h and vals[10]==0
    # Every intermediate point lies on or above the accepted first face.
    assert all(10*vals[l] >= h*(10-l) for l in range(11))
    edge={str(l):[v%5 for v in coeff[l][18*vals[l]:18*(vals[l]+1)]]
          for l in range(11) if 10*vals[l]==h*(10-l)}
    assert edge==entry['edge_coefficients_by_degree']
    centers.append({'ordinary_integer_center':c,'first_11_coefficient_valuations':vals,
                    'edge_coefficients':edge,'matched_legacy_face':True})

teich=[]
for c,t in [(0,0),(1,1),(2,7),(3,18),(4,24)]:
    diff=[(x-y)%25 for x,y in zip(shift_coeff(t,0),shift_coeff(c,0))]
    teich.append({'integer_center':c,'teichmuller_mod25':t,
                  'F_at_centers_difference_valuation':valuation(project(diff,140),140)})

# Independent root-variable trap: q-1 is a unit, unlike pi=xi-1.
q_minus_one=[0]*WIDTH
q_minus_one[0]=24
q_minus_one[1]=1
q_minus_one[19]=1
assert valuation(q_minus_one)==0

result={'verdict':'PASS: five shared-center expansions; integer/Teichmuller distinction explicit',
        'code':seal(Path(__file__)),'input_F':seal(OUT/'independent_F_pi140.bin'),
        'legacy_face_source':seal(legacy_path),'centers':centers,
        'integer_vs_teichmuller_centers':teich,
        'q_minus_one_valuation':0,'pi_valuation':1,
        'certified_precision_exclusive':140,
        'warning':'140 in a valuation field means only >=140; no repeated branch is resolved.',
        'wall_seconds':time.perf_counter()-start}
(OUT/'CENTER_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
