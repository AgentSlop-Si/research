#!/usr/bin/env python3
"""New completion verifier. Saved programs are read/hashed, never imported/run.

Builds z^e by successive multiplication by alpha*(1+pi), then independently
recomputes all saved arrays. Writes only a new receipt, not prior evidence.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import resource
import signal
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROD = ROOT / 'normalization_producer'
W = 1800
START = time.perf_counter()
CPU = time.process_time()
signal.alarm(180)
resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))

def digest(path):
    b = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(b),
            'sha256': hashlib.sha256(b).hexdigest()}

checked = []
def check_binding(entry):
    actual = digest(ROOT / entry['path'])
    assert actual['bytes'] == entry['bytes'], entry['path']
    assert actual['sha256'] == entry['sha256'], entry['path']
    checked.append(actual)

snapshot = json.loads((HERE / 'PREEXISTING_SNAPSHOT.json').read_text())
for entry in snapshot['files']:
    check_binding(entry)
saved = json.loads((HERE / 'RESULT.json').read_text())
centers = json.loads((HERE / 'CENTER_CONTROLS.json').read_text())
receipt = json.loads((PROD / 'EXECUTION_RECEIPT.json').read_text())
controls = json.loads((PROD / 'CONTROLS.json').read_text())
for entry in saved['sources'] + saved['outputs'] + [saved['code'], centers['code'],
        centers['input_F'], centers['legacy_face_source']]:
    check_binding(entry)
for entry in json.loads((PROD / 'INPUT_BINDINGS.json').read_text()):
    check_binding(entry)
for name, entry in receipt['outputs'].items():
    check_binding(dict(entry, path=str((PROD / name).relative_to(ROOT))))
assert all(p['exit_code'] == 0 for p in receipt['processes'])
assert receipt['full']['division_guard_and_multiply_back_checks'] == 13830
assert json.loads((HERE / 'audit.stdout').read_text()) == {
    k: v for k, v in saved.items() if k not in ['sources', 'coefficient_numerator_valuations']}
assert json.loads((HERE / 'centers.stdout').read_text()) == centers

# Exact integer f coefficients, reduced only after construction.
f = [sum(math.comb(25*r, j) for r in range(5) if j <= 25*r) for j in range(101)]
assert f[0] == 5 and f[100] == 1 and all(c % 5 == 0 for c in f[:100])
low = [(i, c % 25) for i, c in enumerate(f[:100]) if c % 25]
assert low == [(0,5),(25,10),(50,10),(75,5),(80,20),(85,15),(90,15),(95,20)]
assert pow(5,18,27) == 1 and all(pow(5,d,27) != 1 for d in [1,2,3,6,9])
assert (1000 % 27, 1000 % 125, 2376 % 27, 2376 % 125) == (1,0,0,1)

def mul_pi(a):
    b = [0]*18 + list(a[:-18])
    for j, c in low:
        for i, top in enumerate(a[-18:]):
            b[18*j+i] = (b[18*j+i] - c*top) % 25
    return b

def mul_alpha(a):
    b = []
    for j in range(100):
        row = a[18*j:18*j+18]
        out = [0] + list(row[:-1])
        out[0] = (-row[-1]) % 25
        out[9] = (out[9] - row[-1]) % 25
        b.extend(out)
    return b

def val(a, ceiling=200):
    return min([ceiling]+[i//18 + (100 if c % 5 == 0 else 0)
                         for i,c in enumerate(a) if c])

def project(a, p):
    return [c % (25 if p > i//18+100 else 5 if p > i//18 else 1)
            for i,c in enumerate(a)]

def divide(a):
    assert all(c % 5 == 0 for c in a[:18]), 'divisibility guard'
    top = [-(c//5) % 25 for c in a[:18]]
    b = list(a[18:]) + top
    for j,c in low:
        if j:
            for i,t in enumerate(top):
                b[18*(j-1)+i] = (b[18*(j-1)+i] + c*t) % 25
    assert mul_pi(b) == a, 'division multiplication-back'
    return b

def rows(path):
    raw = path.read_bytes()
    assert len(raw) % W == 0 and max(raw) < 25
    return [list(raw[j:j+W]) for j in range(0,len(raw),W)]

def flatten(x):
    return bytes(c for row in x for c in row)

def compare(x, path):
    raw = flatten(x)
    assert raw == path.read_bytes(), str(path)
    return {'path': str(path.relative_to(ROOT)), 'compared_bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}

# A successive-q map, without producer alpha/beta decomposition or saved
# reviewer's binomial expansion of (1+pi)^e.
one = [1] + [0]*(W-1)
power = one
maps = []
for e in range(W):
    maps.append([(i,c) for i,c in enumerate(power) if c])
    shifted = mul_pi(power)
    power = mul_alpha([(a+b) % 25 for a,b in zip(power,shifted)])
source = ROOT / 'sparse_kernel_independent_review/review_R843_w100.bin'
r_z = rows(source)
assert len(r_z) == 100
r = []
for zr in r_z:
    converted = [0]*W
    for c, image in zip(zr,maps):
        if c:
            for i,t in image:
                converted[i] += c*t
    r.append([x % 25 for x in converted])
matches = [compare(r,HERE/'independent_R_alpha_pi.bin'),compare(r,PROD/'R843_R_ap.bin')]

# Exact integral reciprocal identity, ordinary binomial coefficients.
u = [[0]*W for _ in range(200)]
for k,rk in enumerate(r):
    for j in range(2*k,200):
        c = ((-1)**(843+k)*math.comb(843-k,j-2*k)) % 25
        if c:
            u[j] = [x+c*y for x,y in zip(u[j],rk)]
u = [[c % 25 for c in row] for row in u]
matches += [compare(u,HERE/'independent_U_v200.bin'),compare(u,PROD/'R843_U_ap.bin')]
raw_values = [val(row) for row in u]
assert raw_values == controls['all_raw_U_coefficient_valuation_or_lower_bounds']

numerators, normalized, richer = [], [], []
guards = 0
for j,row in enumerate(u):
    n = row
    for _ in range(j):
        n = mul_pi(n)
    numerators.append(n)
    current = n
    for _ in range(60):
        current = divide(current)
        guards += 1
    normalized.append(project(current,140))
    current = row
    if j < 60:
        for _ in range(60-j):
            current = divide(current)
            guards += 1
    else:
        for _ in range(j-60):
            current = mul_pi(current)
    richer.append(project(current,min(200,140+j)))
    assert project(richer[-1],140) == normalized[-1]
num_values = [val(row) for row in numerators]
assert num_values == saved['coefficient_numerator_valuations']
assert min(num_values) == 60
assert [j for j,v in enumerate(num_values) if v == 60] == [10,30,50]
assert guards == 13830
matches += [compare(numerators,PROD/'R843_numerator_pi200.bin'),
            compare(normalized,HERE/'independent_F_pi140.bin'),
            compare(normalized,PROD/'R843_F_pi140.bin'),
            compare(richer,PROD/'R843_F_coefficientwise.bin')]
with (PROD/'R843_precision.csv').open() as stream:
    prec = list(csv.DictReader(stream))
assert len(prec) == 200
for j,row in enumerate(prec):
    assert list(map(int,row.values())) == [j,raw_values[j],j-60,140+j,min(200,140+j)]

legacy_checks = []
for entry in controls['old_raw_reference_checks']:
    obj = json.loads((ROOT/entry['path']).read_text())
    if 'coefficients_v_x_eta' in obj:
        ref = bytes(c for layer in obj['coefficients_v_x_eta'] for coeff in layer for c in coeff)
    else:
        ref = bytearray((max(item[1] for item in obj['coefficients'])+1)*W)
        for j,v,c in obj['coefficients']:
            ref[v*W+j*18:v*W+j*18+18] = bytes(c)
        ref = bytes(ref)
    assert ref == bytes(c % 5 for c in flatten(u)[:len(ref)])
    assert len(ref) == 180000
    assert hashlib.sha256(ref).hexdigest() == entry['canonical_mod5_sha256']
    legacy_checks.append({'source':entry['path'],'compared_bytes':len(ref)})

def translated(c,l):
    out = [0]*W
    for j in range(l,200):
        t = math.comb(j,l)*pow(c,j-l,25) % 25
        if t:
            out = [a+t*b for a,b in zip(out,normalized[j])]
    return project(out,140)

for entry in centers['centers']:
    c = entry['ordinary_integer_center']
    jet = [translated(c,j) for j in range(11)]
    v = [val(row,140) for row in jet]
    assert v == entry['first_11_coefficient_valuations']
    h = v[0]
    assert v[10] == 0 and all(10*v[j] >= h*(10-j) for j in range(11))
    edge = {str(j):[x % 5 for x in jet[j][18*v[j]:18*(v[j]+1)]]
            for j in range(11) if 10*v[j] == h*(10-j)}
    assert edge == entry['edge_coefficients']
for entry in centers['integer_vs_teichmuller_centers']:
    a = translated(entry['integer_center'],0)
    b = translated(entry['teichmuller_mod25'],0)
    assert val(project([(x-y)%25 for x,y in zip(a,b)],140),140) == entry['F_at_centers_difference_valuation']
residue = {str(j):[x%5 for x in row[:18]] for j,row in enumerate(normalized)
           if any(x % 5 for x in row[:18])}
assert residue == saved['residual_nonzero_coefficients']

# Recheck unchanged prior files after computation.
for entry in snapshot['files']:
    check_binding(entry)
result = {
    'verdict':'PASS: fresh reconstruction of saved shared-center data; no discriminant claim',
    'method':'Successive multiplication by q=alpha*(1+pi); exact binomial transfer; both normalization routes; saved programs never imported or executed',
    'preexisting_files_preserved':len(snapshot['files']),
    'source_bindings_checked':len(checked)-2*len(snapshot['files']),
    'matched_outputs':matches,
    'guarded_divisions_with_multiplyback':guards,
    'uniform_route_guards':12000,'coefficientwise_route_guards':1830,
    'minimum_numerator_valuation':60,'content_witness_degrees':[10,30,50],
    'F_precision_exclusive':140,'precision_csv_rows_verified':200,
    'legacy_comparisons':legacy_checks,
    'translated_centers_verified':[0,1,2,3,4],
    'integer_teichmuller_difference_valuations':[140,140,111,111,111],
    'valuation_140_means':'at least 140',
    'fresh_verifier_source':digest(Path(__file__)),
    'wall_seconds':time.perf_counter()-START,'cpu_seconds':time.process_time()-CPU,
    'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'runtime_limits':{'wall_seconds':180,'cpu_seconds':120,'per_process_address_space_bytes':512*1024**2},
    'saved_programs_executed':False,'network_used':False,'external_writes':False}
target = HERE/'RESUME_VERIFICATION.json'
assert not target.exists(), 'Refuse to replace earlier completion receipt'
target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
