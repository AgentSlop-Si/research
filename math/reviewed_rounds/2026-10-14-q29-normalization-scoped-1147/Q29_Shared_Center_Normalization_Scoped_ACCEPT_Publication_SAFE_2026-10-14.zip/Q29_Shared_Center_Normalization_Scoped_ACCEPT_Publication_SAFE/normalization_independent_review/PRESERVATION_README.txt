Q29 shared-center normalization: scoped accepted evidence preservation

This archive seals the saved independent review and producer evidence. The
original 124 files in the two normalization directories are preserved unchanged.
The original 116-entry pre-completion snapshot also verifies. The saved review
accepts only the shared-center conversion and normalized F modulo pi^140.
It does not resolve repeated branches, cover the other 26 primary centers,
compute the discriminant, prove its nonvanishing, or close full Q29.

Files added during this sealing are SOURCE_HASHES.json,
PRESERVATION_VERIFICATION.json, this PRESERVATION_README.txt, and MANIFEST.json.
SOURCE_HASHES.json was missing when the saved review was recovered; its present
creation is explicit. Existing source, output, receipt, and review files have
not been repaired, rewritten, or relabeled.

The only fresh checks were file sizes, SHA-256 hashes, saved JSON consistency,
three producer/reviewer array byte comparisons, and archive integrity. Saved
scientific programs, including resume_verify.py, were not executed or imported.
Counts and timings in saved receipts remain historical observations.

Layout and dependencies
The archive retains original workspace-relative paths. It contains the complete
producer and independent-review directories, every direct saved hash-bound
dependency, and the specifically listed historical failure disclosures. It is
not a recursively complete archive of every predecessor's own dependencies.
The historical producer report mentions a future inputs/ portable reproduction
package and README.txt. Those unmaterialized packaging claims have not been
retroactively certified. This is a preservation package, not a tested portable
scientific-reproduction environment. No historical replay was performed.

Integrity
MANIFEST.json lists every ZIP member except itself, with byte count and SHA-256.
The archive's adjacent .seal.json binds the archive and manifest hashes and
records final member validation and unchanged-source checks. The outer seal is
intentionally outside the ZIP, avoiding circular hashes. SOURCE_HASHES.json
binds all pre-existing preserved evidence. No new proof claim follows merely
from matching hashes.

No external write, upload, repository commit, or publication was performed.
