#!/usr/bin/env python3
"""Fresh independent Q29 conversion and guarded-normalization audit.

Uses only the standard library. No predecessor program is imported/executed.
Canonical ring arrays use offset 18*pi_degree + alpha_degree.
"""
import hashlib
import json
import math
from pathlib import Path
import resource
import time

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
START = time.perf_counter()
CPU = time.process_time()
F = [sum(math.comb(25*r, j) if j <= 25*r else 0 for r in range(5)) for j in range(101)]
FS = [(j, F[j] % 25) for j in range(100) if F[j] % 25]
WIDTH = 1800

def seal(path):
    b = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def scalar_pi_power(n, modulus=25):
    # Independent descending monic division of T^n, using full integer f.
    p = [0] * max(100, n+1)
    p[n] = 1
    for d in range(len(p)-1, 99, -1):
        lead = p[d] % modulus
        if lead:
            for j, fj in enumerate(F[:100]):
                p[d-100+j] = (p[d-100+j] - lead*fj) % modulus
        p[d] = 0
    return [c % modulus for c in p[:100]]

def xi_power(n):
    # No beta-basis reduction: expand (1+T)^n then divide directly by f(T).
    p = [math.comb(n, j) % 25 for j in range(n+1)] + [0]*max(0, 99-n)
    for d in range(n, 99, -1):
        lead = p[d] % 25
        if lead:
            for j, fj in enumerate(F[:100]):
                p[d-100+j] = (p[d-100+j] - lead*fj) % 25
        p[d] = 0
    return [c % 25 for c in p[:100]]

def alpha_power(n):
    p = [0]*max(18, n+1)
    p[n] = 1
    for d in range(n, 17, -1):
        lead = p[d]
        p[d-9] -= lead
        p[d-18] -= lead
        p[d] = 0
    return [(i, c % 25) for i, c in enumerate(p[:18]) if c % 25]

def times_pi(a):
    b = [0]*WIDTH
    for j in range(1, 100):
        b[j*18:(j+1)*18] = a[(j-1)*18:j*18]
    top = a[99*18:100*18]
    for j, fj in FS:
        for i in range(18):
            b[j*18+i] = (b[j*18+i] - fj*top[i]) % 25
    return b

def divide_pi(a):
    if any(c % 5 for c in a[:18]):
        raise ValueError('Input is not divisible by pi')
    top = [(-c//5) % 25 for c in a[:18]]
    b = a[18:] + top
    for j, fj in FS:
        if j:
            for i in range(18):
                b[(j-1)*18+i] = (b[(j-1)*18+i] + fj*top[i]) % 25
    return b

def valuation(a, capacity=200):
    return min([capacity] + [j + (100 if c % 5 == 0 else 0)
               for j in range(100) for c in a[j*18:(j+1)*18] if c])

def project(a, precision):
    b=[]
    for j in range(100):
        modulus = 5**max(0, (precision-j+99)//100)
        b.extend(c % modulus for c in a[j*18:(j+1)*18])
    return b

def scalar_valuation(a, capacity):
    vals=[]
    for j,c in enumerate(a):
        if c:
            v=0
            while c % 5 == 0:
                c//=5
                v+=1
            vals.append(j+100*v)
    return min([capacity]+vals)

def polynomial_u(r):
    m=len(r)-1
    out=[0]*(2*m+1)
    for k, rk in enumerate(r):
        for j in range(2*k+1):
            out[m-k+j] += rk*math.comb(2*k,j)
    return out

def translate_minus_one(poly):
    out=[0]*len(poly)
    for n,c in enumerate(poly):
        for j in range(n+1):
            out[j] += c*((-1)**n)*math.comb(n,j)
    return out

def small_controls():
    cases=0
    for m in range(1,9):
        r=[(-1)**k*(k*k+3*k+7) for k in range(m+1)]
        direct=translate_minus_one(polynomial_u(r))
        transformed=[0]*(2*m+1)
        for k,rk in enumerate(r):
            for d in range(2*k, m+k+1):
                transformed[d] += (-1)**(m+k)*rk*math.comb(m-k,d-2*k)
        assert direct == transformed
        for L in range(1,m+1):
            partial=[0]*(2*m+1)
            for k,rk in enumerate(r[:L]):
                for d in range(2*k,m+k+1):
                    partial[d] += (-1)**(m+k)*rk*math.comb(m-k,d-2*k)
            assert direct[:2*L] == partial[:2*L]
            assert direct[2*L]-partial[2*L] == (-1)**(m+L)*r[L]
            cases+=1
    one=[0]*WIDTH; one[0]=1
    try:
        divide_pi(one)
        raise AssertionError('Nonunit guard did not reject one')
    except ValueError:
        pass
    current=one
    for h in range(200):
        assert valuation(current)==h
        if h:
            quotient=divide_pi(current)
            assert times_pi(quotient)==current
            assert project(quotient,199)==project(previous,199)
        previous=current
        current=times_pi(current)
    assert not any(current)
    # Sharp precision witnesses: pi^200 is invisible at coefficient modulus 25,
    # but after dividing by pi^60 its pi^140 image is visible modulo pi^141.
    assert not any(scalar_pi_power(200,25))
    assert scalar_valuation(scalar_pi_power(140,25),200)==140
    assert scalar_valuation(scalar_pi_power(200,125),300)==200
    assert scalar_valuation(scalar_pi_power(199,25),200)==199
    # The last retained raw degree 199 can matter after normalization: valuation139.
    assert scalar_valuation(scalar_pi_power(139,25),200)==139
    # Other primary centers have unit w: alpha!=1 in the residue field.
    for j in range(1,27):
        ap=dict(alpha_power(j)); ap[0]=(ap.get(0,0)-1)%5
        assert any(c%5 for c in ap.values())
    # Monicity can be retained by perturbing w^100 in a degree843 polynomial.
    # At x=1, its U perturbation is 4^100, a unit modulo5.
    assert pow(4,100,5)==1
    return {'integral_identity_and_tail_cases':cases,
            'division_inverse_checks':199,
            'unit_division_rejected':True,
            'pi_nilpotence_index':200,
            'tail_witness_first_normalized_valuation':140,
            'raw_degree199_can_contribute_at':139,
            'other_primary_centers_with_unit_w':26}

def main():
    controls=small_controls()
    src=ROOT/'sparse_kernel_independent_review/review_R843_w100.bin'
    raw=src.read_bytes()
    assert len(raw)==180000 and max(raw)<25
    assert hashlib.sha256(raw).hexdigest()=='ebf51150ffbed6e87f3e08875451176963670801c59ffd9128336a02c43ca38c'
    xi=[xi_power(n) for n in range(125)]
    a=[alpha_power(n) for n in range(27)]
    maps=[]
    for e in range(WIDTH):
        maps.append([(18*j+i,(c*d)%25) for j,c in enumerate(xi[e%125]) if c
                     for i,d in a[e%27] if c*d%25])
    r=[]
    for k in range(100):
        out=[0]*WIDTH
        for e,c in enumerate(raw[k*WIDTH:(k+1)*WIDTH]):
            if c:
                for index,t in maps[e]:
                    out[index]+=c*t
        r.append([x%25 for x in out])
    (OUT/'independent_R_alpha_pi.bin').write_bytes(bytes(x for row in r for x in row))
    # Make the raw v jet by direct integer binomial summation.
    u=[]
    for d in range(200):
        out=[0]*WIDTH
        for k in range(min(99,d//2)+1):
            c=(-1)**(843+k)*math.comb(843-k,d-2*k)%25
            if c:
                for i,t in enumerate(r[k]):
                    out[i]+=c*t
        u.append([x%25 for x in out])
    (OUT/'independent_U_v200.bin').write_bytes(bytes(x for row in u for x in row))
    legacy_path=ROOT/'bounded_higher_layer_source/independent_reciprocal/u1687_independent.json'
    old=json.loads(legacy_path.read_text())['coefficients_v_x_eta']
    old_flat=[x for row in old for coeff in row for x in coeff]
    assert [x%5 for row in u[:100] for x in row]==old_flat
    # Deliberately unlike optimized coefficient normalization, construct the whole
    # numerator pi^d U_d and divide each coefficient by pi exactly sixty times.
    normalized=[]
    valuations=[]
    guard_count=0
    for d,row in enumerate(u):
        numerator=row
        for _ in range(d):
            numerator=times_pi(numerator)
        valuations.append(valuation(numerator))
        current=numerator
        for _ in range(60):
            next_value=divide_pi(current)
            assert times_pi(next_value)==current
            current=next_value
            guard_count+=1
        check=current
        for _ in range(60):
            check=times_pi(check)
        assert check==numerator
        normalized.append(project(current,140))
    assert min(valuations)==60
    normfile=OUT/'independent_F_pi140.bin'
    normfile.write_bytes(bytes(x for row in normalized for x in row))
    A=[1,1,0,4,4,1,2,3,2,3,0,0,4,2,2,3,2,1]
    nonzero_residual={d:[x%5 for x in row[:18]] for d,row in enumerate(normalized)
                      if any(x%5 for x in row[:18])}
    assert nonzero_residual=={10:A,30:[3*x%5 for x in A],50:A}
    sources=[src,legacy_path]+[ROOT/p for p in [
        'precision_contract/PRECISION_CONTRACT.md',
        'precision_contract_review/REVIEW.md',
        'sparse_execution_design/SPARSE_EXECUTION_CONTRACT.md',
        'bounded_normalization_recovery/REPORT.md',
        'sparse_kernel_independent_review/INDEPENDENT_VERDICT.md']]
    result={'verdict':'PASS: shared-center F modulo pi^140; no discriminant claim',
        'sources':[seal(p) for p in sources],
        'code':seal(Path(__file__)),
        'small_controls':controls,
        'converted_R_coefficients':100,
        'raw_U_coefficients':200,
        'legacy_mod5_coordinate_comparisons':len(old_flat),
        'guarded_pi_divisions_with_multiplyback':guard_count,
        'numerator_minimum_valuation':min(valuations),
        'coefficient_numerator_valuations':valuations,
        'F_precision_exclusive':140,
        'layout':'offset 1800*Y_degree + 18*pi_degree + alpha_degree; 200 by 100 by 18',
        'F_canonical_moduli':'mod25 for pi_degree<40, mod5 for pi_degree>=40',
        'residual_nonzero_coefficients':nonzero_residual,
        'outputs':[seal(OUT/p) for p in ['independent_R_alpha_pi.bin','independent_U_v200.bin','independent_F_pi140.bin']],
        'wall_seconds':time.perf_counter()-START,'cpu_seconds':time.process_time()-CPU,
        'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'historical_programs_executed':False,'external_writes':False}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['sources','coefficient_numerator_valuations']},indent=2))

if __name__=='__main__':
    main()
