#!/usr/bin/env python3
"""Independent exact review. No candidate/historical Python is loaded or run.

Scientific calculations finish and are saved before candidate numerical data is
read. Inputs are a byte-pinned ZIP, parsed strictly as inert JSON/CSV/text bytes.
"""
from pathlib import Path
import argparse, csv, gzip, hashlib, io, itertools, json, math, zipfile

P, N = 23, 11
PIN = '841e5170f693db12053e23a081bd5394b4de2da072c9f05a3019eb234096a805'
PREFIX = 'signed_bank_nine_resolution_2014/'
SIGNS = [(1,1),(-1,1),(1,-1),(-1,-1)]
ap=argparse.ArgumentParser()
ap.add_argument('--source', type=Path, default=Path(__file__).with_name('CANDIDATE_SOURCE.zip'))
ap.add_argument('--out', type=Path, default=Path(__file__).parent)
args=ap.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
def save(name, obj):
    (args.out/name).write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')
def inv(x): return pow(x % P, -1, P)
def qpow(q,e): return pow(q, e % N, P)
def dot(a,b): return sum(x*y for x,y in zip(a,b)) % P

def determinant(A):
    """Full Leibniz expansion, not elimination."""
    d=len(A); ans=0
    for perm in itertools.permutations(range(d)):
        sign=(-1)**sum(perm[i]>perm[j] for i in range(d) for j in range(i+1,d))
        ans+=sign*math.prod(A[i][perm[i]] for i in range(d))
    return ans % P

def rref(A):
    A=[r[:] for r in A]; row=0; piv=[]
    for col in range(len(A[0])):
        pivot=next((i for i in range(row,len(A)) if A[i][col]),None)
        if pivot is None: continue
        A[row],A[pivot]=A[pivot],A[row]
        A[row]=[(x*inv(A[row][col]))%P for x in A[row]]
        for i in range(len(A)):
            if i!=row:
                a=A[i][col]; A[i]=[(x-a*y)%P for x,y in zip(A[i],A[row])]
        piv.append(col); row+=1
        if row==len(A): break
    return A,piv

def trim(a):
    a=[x%P for x in a]
    while len(a)>1 and a[-1]==0: a.pop()
    return a
def divrem(a,b):
    a=trim(a); b=trim(b); out=[0]*max(1,(len(a)-len(b)+1))
    while a!=[0] and len(a)>=len(b):
        d=len(a)-len(b); v=a[-1]*inv(b[-1])%P; out[d]=v
        for j,bj in enumerate(b): a[d+j]=(a[d+j]-v*bj)%P
        a=trim(a)
    return trim(out),a
def gcd(a,b):
    while b!=[0]: a,b=b,divrem(a,b)[1]
    return [x*inv(a[-1])%P for x in a]
def peval(a,x): return sum(c*pow(x,k,P) for k,c in enumerate(a))%P
def nodepoly(nodes):
    """Vieta elementary-symmetric formula, not iterative factor multiplication."""
    d=len(nodes)
    return [((-1)**(d-k)*sum(math.prod(s) for s in itertools.combinations(nodes,d-k)))%P for k in range(d+1)]
def moments(nodes, weights, start, length):
    return [sum(w*pow(x,a,P) for x,w in zip(nodes,weights))%P for a in range(start,start+length)]
def windows(v1,v2): return [v1[i:i+6] for i in range(4)]+[v2[i:i+6] for i in range(2)]

def power_coeffs(z):
    # Multiplication on the right by U+V in U^r V^ell order, VU=z UV.
    a={(0,0):1}
    for n in range(1,N+1):
        for r in range(n+1):
            ell=n-r
            a[r,ell]=(a.get((r-1,ell),0)*pow(z,ell,P)+a.get((r,ell-1),0))%P
    assert [a[r,N-r] for r in range(1,N)] == [0]*10
    assert a[N,0]==a[0,N]==1
    return a
def make_G(q):
    D={s:power_coeffs(qpow(q,s[0]*s[1])) for s in SIGNS}
    def G(e,d,a,b):
        r=(e*a)%N; ell=(d*b)%N
        return D[e,d][r,ell] if r+ell<N else 0
    return G

def identity(): return [[int(i==j) for j in range(N)] for i in range(N)]
def mm(A,B): return [[sum(A[i][k]*B[k][j] for k in range(N))%P for j in range(N)] for i in range(N)]
def matrix_inverse(A):
    R,piv=rref([A[i]+identity()[i] for i in range(N)])
    assert piv==list(range(N))
    return [r[N:] for r in R]

roots=[q for q in range(2,P) if pow(q,N,P)==1]
assert len(roots)==10
allcases=[]; bank_controls=[]; target_checks=reflection_checks=0
for q in roots:
    G=make_G(q)
    C=sum(qpow(q,-t*t) for t in range(N))*inv(N)%P
    assert C
    for a,b in itertools.product(range(N),repeat=2):
        direct=sum(qpow(q,-t*t-(a+b)*t) for t in range(N))*inv(N)%P
        assert direct == C*qpow(q,3*(a+b)**2)%P
        target_checks+=1
        for e,d in SIGNS:
            assert G(e,d,a,b)==G(-e,-d,-a,-b)
            reflection_checks+=1
    for y in range(1,P):
        sequences=[]; amps=[]; denominators=[]
        for b in (1,2):
            a=N-b; factors=[G(e,d,a,b) for e,d in SIGNS]
            assert factors[0]==factors[2]==factors[3]==0 and factors[1]
            assert qpow(q,3*(a+b)**2)==1
            T=inv(pow(y,b,P)*factors[1]); amps.append(T)
            v=[]; den=[]
            for a in range(b,N-b):
                assert G(1,-1,a,b)==G(-1,-1,a,b)==0
                fwd=G(1,1,a,b); assert fwd; den.append(fwd)
                v.append((qpow(q,3*(a+b)**2)-T*pow(y,N-a,P)*G(-1,1,a,b))*inv(fwd)%P)
            sequences.append(v)
            denominators.append({'b':b,'exclusive_G':factors[1],'forward_G':den})
        M=windows(*sequences); d=determinant(M); R,piv=rref(M)
        assert bool(d)==(len(piv)==6)
        allcases.append({'q':q,'minus_plus_node':y,'matrix':M,'determinant_mod_23':d,
                         'rank':len(piv),'v1':sequences[0],'v2':sequences[1],
                         'forced_amplitudes':amps,'denominators':denominators,'C':C})
    # Direct 11x11 inversion of literal resolvent branches. These are controls;
    # the universal formula is established by the noncommutative identity above.
    for e,d in SIGNS:
        for alpha,beta in [(0,5),(5,0),(1,1),(2,5)]:
            Delta=(1-pow(alpha,N,P)-pow(beta,N,P))%P; assert Delta
            weights=[(j*j+3*j+alpha+2*beta+e+2*d)%P for j in range(N)]
            bank=[[0]*N for _ in range(N)]
            for j in range(N):
                A=identity()
                for t in range(N):
                    A[(t+e)%N][t]=(A[(t+e)%N][t]-alpha)%P
                    A[t][t]=(A[t][t]-beta*qpow(q,e*d*j+d*t))%P
                B=matrix_inverse(A)
                assert mm(A,B)==identity() and mm(B,A)==identity()
                for k,t in itertools.product(range(N),repeat=2):
                    bank[k][t]=(bank[k][t]+inv(N)*weights[j]*B[k][t])%P
            for a,b in itertools.product(range(N),repeat=2):
                r=e*a%N; ell=d*b%N
                predicted=(pow(alpha,r,P)*G(e,d,a,b)*pow(beta,ell,P)*inv(N)*inv(Delta)
                           *sum(weights[j]*qpow(q,e*d*j*ell) for j in range(N)))%P
                observed=sum(qpow(q,-b*t)*bank[(t+a)%N][t] for t in range(N))*inv(N)%P
                assert observed==predicted
            bank_controls.append({'q':q,'epsilon':e,'delta':d,'alpha':alpha,'beta':beta,'Delta':Delta,'weights':weights,'checked_branches':N,'checked_coefficients':N*N})

nine=[]
for case in allcases:
    if case['determinant_mod_23']: continue
    M=case['matrix']; top=M[:5]
    cofactor=[(-1)**j*determinant([row[:j]+row[j+1:] for row in top])%P for j in range(6)]
    assert cofactor[-1]
    c=[x*inv(cofactor[-1])%P for x in cofactor]
    assert [dot(row,c) for row in M]==[0]*6
    minor=determinant([row[:5] for row in top]); assert minor
    R,piv=rref(M); assert piv==list(range(5))
    assert R==[[int(i==j) for j in range(5)]+[(-c[i])%P] for i in range(5)]+[[0]*6]
    evaluations=[peval(c,x) for x in range(P)]
    nonzero_roots=[x for x in range(1,P) if evaluations[x]==0]
    assert len(nonzero_roots)<5 and c[0]
    deriv=[i*c[i]%P for i in range(1,6)]; g=gcd(c,deriv)
    residual=c[:]; factors=[]
    for x in range(P):
        multiplicity=0
        while len(residual)>1 and peval(residual,x)==0:
            residual,rem=divrem(residual,[(-x)%P,1]); assert rem==[0]; multiplicity+=1
        if multiplicity: factors.append({'root':x,'multiplicity':multiplicity})
    # Complete factorization of the rootless remainder, using trial division by
    # every monic polynomial through half of its degree.
    remaining_factors=[]; remainder=residual[:]
    for degree in range(2,len(residual)//2+1):
        for cs in itertools.product(range(P),repeat=degree):
            factor=list(cs)+[1]
            while len(remainder)>=len(factor):
                quotient,rem=divrem(remainder,factor)
                if rem!=[0]: break
                remaining_factors.append(factor); remainder=quotient
    if remainder!=[1]: remaining_factors.append(remainder)
    nine.append({**case,'y':case['minus_plus_node'],'kernel_monic_ascending':c,'cofactor_vector':cofactor,
                 'rank_five_minor':minor,'rref':R,'root_evaluations':evaluations,
                 'distinct_nonzero_basefield_roots':nonzero_roots,'derivative_gcd':g,
                 'squarefree':g==[1],'basefield_linear_factors':factors,
                 'remaining_factor_ascending':residual,'remaining_irreducible_factors':remaining_factors})
assert len(nine)==9

survivors=[[0]*6 for _ in nine]
stream=io.StringIO(newline=''); writer=csv.writer(stream,lineterminator='\n')
header=['nodes']+[f'c{i}' for i in range(6)]+[f"q{c['q']}_y{c['y']}_residuals" for c in nine]
writer.writerow(header); subset_count=0
for X in itertools.combinations(range(1,P),5):
    c=nodepoly(X); row=[';'.join(map(str,X)),*c]
    for k,case in enumerate(nine):
        residuals=[dot(r,c) for r in case['matrix']]
        row.append(';'.join(map(str,residuals)))
        for j in range(6):
            if any(residuals[:j+1]): break
            survivors[k][j]+=1
        assert any(residuals)
    writer.writerow(row); subset_count+=1
assert subset_count==math.comb(22,5)==26334
for case,counts in zip(nine,survivors): case['subset_successive_survivor_counts']=counts
csv_bytes=stream.getvalue().encode()
(args.out/'INDEPENDENT_ALL_FIVE_NODE_SUBSETS.csv.gz').write_bytes(gzip.compress(csv_bytes,mtime=0))

synthetic=[]
for X,w1,w2 in [([1,2,3,4,5],[1,2,4,8,16],[2,3,5,7,11]),
                 ([2,4,7],[1,3,9],[4,6,10]),
                 ([2,2,4,7],[1,2,3,9],[2,2,6,10]),
                 ([0,2,4,7],[12,1,3,9],[19,4,6,10])]:
    v1=moments(X,w1,1,9); v2=moments(X,w2,2,7); M=windows(v1,v2)
    padded=sorted(set(X)-{0})
    for x in range(1,P):
        if len(padded)==5: break
        if x not in padded: padded.append(x)
    padded=sorted(padded); c=nodepoly(padded)
    assert [dot(row,c) for row in M]==[0]*6
    synthetic.append({'nodes':X,'weights1':w1,'weights2':w2,'padded_nodes':padded,
                      'v1':v1,'v2':v2,'annihilator':c,'rank':len(rref(M)[1]),'residuals':[dot(row,c) for row in M]})
assert synthetic[0]['rank']==5
save('FRESH_ALL_220.json',allcases)
save('FRESH_NINE_CERTIFICATES.json',nine)
save('FRESH_LITERAL_BANK_CONTROLS.json',bank_controls)
save('FRESH_PADDING_CONTROLS.json',synthetic)

# Scientific results above are complete before reading candidate numerical data.
source_bytes=args.source.read_bytes(); assert hashlib.sha256(source_bytes).hexdigest()==PIN
with zipfile.ZipFile(io.BytesIO(source_bytes)) as archive:
    def read(name): return archive.read(PREFIX+name)
    def js(name): return json.loads(read(name))
    manifest=js('MANIFEST.json')
    file_verification=[]
    for name,entry in manifest['files'].items():
        b=read(name); h=hashlib.sha256(b).hexdigest()
        assert h==entry['sha256'] and len(b)==entry['bytes']
        file_verification.append({'name':name,'sha256':h,'bytes':len(b)})
    expected_cases=js('NINE_CASES.json')
    compare_fields=['q','y','C','matrix','rank','v1','v2','forced_amplitudes','kernel_monic_ascending',
                    'root_evaluations','distinct_nonzero_basefield_roots','derivative_gcd','squarefree',
                    'basefield_linear_factors','remaining_factor_ascending','rref','subset_successive_survivor_counts']
    assert len(expected_cases)==len(nine)
    for candidate,fresh in zip(expected_cases,nine):
        for field in compare_fields: assert candidate[field]==fresh[field],(fresh['q'],fresh['y'],field)
        assert candidate['rank_five_minor_certificate']['rows']==list(range(5))
        assert candidate['rank_five_minor_certificate']['columns']==list(range(5))
        assert candidate['rank_five_minor_certificate']['determinant']==fresh['rank_five_minor']
        assert candidate['recurrence_residuals']==[0]*6 and candidate['pivots']==list(range(5))
    historical=js('sources/ALL_220_MATRICES.json')
    assert len(historical)==220
    for old,fresh in zip(historical,allcases):
        for key in old: assert old[key]==fresh[key],(fresh['q'],fresh['minus_plus_node'],key)
    candidate_csv=list(csv.reader(io.StringIO(gzip.decompress(read('ALL_FIVE_NODE_SUBSETS.csv.gz')).decode())))
    fresh_csv=list(csv.reader(io.StringIO(csv_bytes.decode())))
    assert candidate_csv==fresh_csv
    # Verify supplied synthetic controls as inert claims, too; our separate
    # independently generated controls above also check each relevant edge case.
    for c in js('SYNTHETIC_GUARD_CONTROLS.json'):
        assert c['annihilator']==nodepoly(c['padded_distinct_nonzero_nodes'])
        M=windows(c['v1'],c['v2'])
        assert [dot(r,c['annihilator']) for r in M]==c['residuals']==[0]*6
        assert len(rref(M)[1])==c['rank']
    prior_report=read('sources/REPORT.md')
    (args.out/'PRIOR_ACCEPTED_REPORT.md').write_bytes(prior_report)
    (args.out/'CANDIDATE_REPORT.md').write_bytes(read('REPORT.md'))
    (args.out/'CANDIDATE_CONTRACT.md').write_bytes(read('CONTRACT.md'))
save('SOURCE_VERIFICATION.json',{'candidate_zip_sha256':PIN,'candidate_zip_bytes':len(source_bytes),
                               'manifest_entries_verified':file_verification,'candidate_code_executed':False,
                               'historical_code_executed':False,'fresh_first_comparison_second':True})
summary={'verdict':'ACCEPT','scope':'N=11; every primitive q in F23; all bank parameters in F23; one effective cross-sign node',
         'primitive_q':roots,'all_pairs':220,'nonsingular_pairs':211,'new_singular_pair_exclusions':9,
         'nine_pairs':[[c['q'],c['y']] for c in nine],
         'target_checks':target_checks,'reflection_checks':reflection_checks,'literal_bank_controls':len(bank_controls),
         'literal_inverse_branches':len(bank_controls)*N,'literal_bank_coefficients':len(bank_controls)*N*N,
         'all_subsets':subset_count,'pair_subset_tests':subset_count*len(nine),'all_csv_rows_equal':True,
         'root_evaluations':len(nine)*P,'monic_kernel_method':'signed 5x5 cofactors',
         'kernel_rank_verification':'nonzero 5x5 minor plus six zero residuals; RREF crosscheck',
         'nonsingular_211_extension_scope_preserved':True,'attainment_claim':False,'other_fields_claim':False,
         'unrestricted_bank_optimality_claim':False}
save('SUMMARY.json',summary)
print(json.dumps(summary,sort_keys=True)); print('PASS')
