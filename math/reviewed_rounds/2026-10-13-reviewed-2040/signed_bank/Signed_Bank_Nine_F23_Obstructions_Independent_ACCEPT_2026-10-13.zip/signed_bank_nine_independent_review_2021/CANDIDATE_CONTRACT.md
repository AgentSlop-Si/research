# Frozen contract: nine surviving N11/F23 bank gates

Declared 13 October 2026 before the fresh recurrence computation.

- Target: negative Fourier matrix F[k,t]=q^(-kt), N=11.
- Coefficient field and all original bank parameters: F23. Primitive q is one of 3,4,9,12,13,16,18 in the nine accepted singular (q,y) pairs.
- Original grammar: (1/11) sum_j w_j (I-alpha S^epsilon-beta q^(epsilon delta j)T^delta)^(-1), with Delta=1-alpha^11-beta^11 nonzero. No generators, gauge transformations, coordinate maps, products, or confluent atoms are added.
- The minus-plus orientation has exactly one effective node y equal to the specified nonzero base-field value. We ask whether at most five effective plus-plus nodes can occur. All alpha, beta and phase weights are in F23. Negative-delta orientations have no count restriction.
- Repeated ordinary nodes merge by sector; zero nodes cannot alter the selected positive-exponent moments. The original beta value is unrestricted subject to Delta != 0.
- Compute fresh original word coefficients, forced moments, every kernel polynomial, and its exact finite-field factor/split and squarefree guards. Test every five-element subset of F23* independently if the recurrence route gives a base-field obstruction. If a recurrence permits five distinct nonzero nodes, solve all original coefficient rows and reconstruct and test literal legal resolvent banks before claiming a witness.
- Stop with a legal base-field witness or exact additional obstruction for each of the nine pairs, and a replayable source-bound packet. Bound: nine 6x6 nullspaces, nine degree-at-most-five factorizations, at most 9*C(22,5)=237006 subset checks, and at most nine full coefficient reconstructions. Python standard library, exact arithmetic only. No historical scientific program is executed or imported.
- This contract does not restrict the already accepted 211 exclusions, which continue to allow same-sign nodes in extensions. A newly found base-field nonsplitting obstruction must not be promoted to a prohibition over splitting fields. No new characteristic-zero, extension-valued-singleton, unrestricted fourteen-bank optimum, or arithmetic-speed claim.
