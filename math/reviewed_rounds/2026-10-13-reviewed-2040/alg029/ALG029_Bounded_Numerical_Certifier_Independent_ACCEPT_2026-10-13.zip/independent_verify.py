"""Independent sealed-data verifier. Never import/execute any candidate program.
The Q128 reconstruction checks finite setup. The Q256 direct oracle uses
quadrant symmetry and consecutive powers, rather than DIF or recursive
root interleaving. Integer inequalities certify all numerical comparisons.
"""
import ast
import hashlib
import json
import math
import pathlib
import sys
import zipfile
from fractions import Fraction as F
from collections import Counter

ARCHIVE_SHA='afcc7641db413ed56a750350a2f86efe852665cf74e028e27fb091407d41563c'
S=1<<128
T=1<<256
E=1<<16
CHECKS=Counter()

def need(condition,label):
    CHECKS[label]+=1
    if not condition: raise AssertionError(label)

def sha(b): return hashlib.sha256(b).hexdigest()
def ceildiv(x,y): return -((-x)//y)
def plus(x,y): return (x[0]+y[0],x[1]+y[1])
def minus(x,y): return (x[0]-y[1],x[1]-y[0])
def negative(x): return (-x[1],-x[0])
def product(x,y,q):
    vals=(x[0]*y[0],x[0]*y[1],x[1]*y[0],x[1]*y[1])
    return (min(vals)//q,ceildiv(max(vals),q))
def radical(x,q):
    need(0<=x[0]<=x[1],'radical_input')
    lo=math.isqrt(x[0]*q)
    hi=math.isqrt(x[1]*q)
    hi+=hi*hi<x[1]*q
    need(lo*lo<=x[0]*q<(lo+1)**2,'radical_lower_enclosure')
    need((hi-1)**2<x[1]*q<=hi*hi if hi else x[1]==0,'radical_upper_enclosure')
    return (lo,hi)
def half(x): return (x[0]//2,ceildiv(x[1],2))
def times(z,w,q):
    return (minus(product(z[0],w[0],q),product(z[1],w[1],q)),
            plus(product(z[0],w[1],q),product(z[1],w[0],q)))
def scale(c,z,q): return (product(c,z[0],q),product(c,z[1],q))
def boxnorm(v):
    lower=upper=0
    for z in v:
        for a,b in z:
            lower+=0 if a<=0<=b else min(a*a,b*b)
            upper+=max(a*a,b*b)
    l=math.isqrt(lower); h=math.isqrt(upper)
    return (l,h+(h*h<upper))

def reconstruct_setup(n):
    """A fresh functional specification, independent of candidate classes."""
    one=(S,S); zero=(0,0); neg=(-S,-S)
    tables={1:[(one,zero)]}
    if n>=2: tables[2]=[(one,zero),(neg,zero)]
    if n>=4: tables[4]=[(one,zero),(zero,neg),(neg,zero),(zero,one)]
    c=radical((S//2,S//2),S)
    # Candidate sqrt uses 7 fixed operations and an optional increment.
    ops=7+(c[0]!=c[1])+2
    old_cos=zero
    for exponent in range(3,n.bit_length()):
        size=1<<exponent
        ca=half(plus(one,old_cos)); sa=half(minus(one,old_cos))
        co=radical(ca,S); si=radical(sa,S)
        # add/sub 2, half 4, sqrt 7+optional 1, negative sine 2.
        ops+=2*(2+4+7)+(si[1]*si[1]!=sa[1]*S)+(co[1]*co[1]!=ca[1]*S)+2
        # The optional-increment test above compares final ceil square with
        # input; non-square is exactly the condition for the increment.
        primitive=(co,negative(si)); previous=tables[size//2]
        even=list(previous); odd=[times(primitive,z,S) for z in previous]
        tables[size]=[z for pair in zip(even,odd) for z in pair]
        ops+=60*(size//2)
        old_cos=co
    width=0
    for row in tables.values():
        for z in row:
            for lo,hi in z:
                need(-2*S<=lo<=hi<=2*S,'root_range_order')
                width=max(width,hi-lo)
                need(hi-lo<=1<<20,'root_width_budget')
                ops+=4
    return c,tables,width,ops

REF_ROOTS={}
def direct_roots(n):
    """Q256 roots using first-quadrant consecutive powers plus symmetry."""
    if n in REF_ROOTS:return REF_ROOTS[n]
    one=(T,T);zero=(0,0)
    card=[(one,zero),(zero,(-T,-T)),((-T,-T),zero),(zero,one)]
    if n<=4:
        row=[card[(4*j)//n] for j in range(n)]
    else:
        co=zero
        si=None
        for size in (1<<k for k in range(3,n.bit_length())):
            si=radical(half(minus(one,co)),T)
            co=radical(half(plus(one,co)),T)
        step=(co,negative(si));first=[(one,zero)]
        for j in range(1,n//4): first.append(times(first[-1],step,T))
        row=[]
        for quadrant in range(4):
            for z in first:
                # Exact quarter rotations introduce no extra rounding.
                a,b=z
                row.append((a,b) if quadrant==0 else (b,negative(a)) if quadrant==1
                           else (negative(a),negative(b)) if quadrant==2 else (negative(b),a))
    REF_ROOTS[n]=row
    return row

def direct_node(x,r,s):
    n=len(x);m=n//s;w=direct_roots(n)
    h=math.isqrt(T*T//s)
    inv=(h,h+(h*h*s!=T*T))
    ans=[]
    for j in range(m):
        real=imag=(0,0)
        for t in range(s):
            index=j+t*m
            a,b=x[index]
            raw=((a*(T//256),)*2,(b*(T//256),)*2)
            val=times(raw,w[(r*index)%n],T)
            real=plus(real,val[0]);imag=plus(imag,val[1])
        ans.append(scale(inv,(real,imag),T))
    return ans


def audit_receipt(receipt,tag):
    x=receipt['input'];e=receipt['epsilon_numerator'];ans=receipt['result']
    n=len(x);ledger=ans['ledger'];ell=ans['ell_numerator']; rows=ans['nodes']
    need(ans['status']=='OK','receipt_status')
    need(ans['output_fraction_bits']==129 and len(ans['output'])==n,'dense_Q129')
    raw=sum(a*a+b*b for a,b in x)
    need(ell*ell*256**2<=raw*S*S<(ell+1)**2*256**2,'exact_root_floor')
    need(4*ell*ell*256**2>=raw*S*S and ell>=S//256,'ell_budget')
    need(ans['delta_numerator']==e*ell and ans['delta_denominator']==4*E*S,'delta_identity')
    occupied=set();retained=0;volume=0;depths=Counter();split=0;pruned=0;pruned_coords=0
    largest_norm_error=F(0)
    for row in rows:
        r,s,m,d=(row[k] for k in ('offset','stride','m','depth'))
        lo,hi=row['norm_lo'],row['norm_hi']
        need(s==1<<d and m*s==n and 0<=r<s,'node_index_identity')
        v=direct_node(x,r,s);nl,nh=boxnorm(v)
        need(lo*(T//S)<=nl<=nh<=hi*(T//S),'direct_norm_inside_receipt')
        err=max(abs((lo+hi)*(T//S)-2*nl),abs((lo+hi)*(T//S)-2*nh))
        largest_norm_error=max(largest_norm_error,F(err,2*T))
        need(err*(1<<64)<2*T,'absolute_norm_error_2^-64')
        need(2*E*S*err<=e*ell*T,'direct_node_delta')
        need(2*E*(hi-lo)<=e*ell,'receipt_norm_budget_guard')
        guard=2*E*(lo+hi)<=3*e*ell
        need(guard is row['pruned'],'exact_guard')
        if not guard:depths[d]+=1
        if guard or m==1:
            these=set(range(r,n,s))
            need(len(these)==m and not occupied&these,'terminal_partition_disjoint')
            occupied|=these
        else:volume+=m;split+=1
        if guard:pruned+=1;pruned_coords+=m
        if m==1 and not guard:
            retained+=1
            z=ans['output'][r]
            errors=[max(abs(z[c]*(T//(2*S))-v[0][c][0]),abs(z[c]*(T//(2*S))-v[0][c][1])) for c in (0,1)]
            need(sum(errors)*(1<<69)<T,'absolute_leaf_error_2^-69')
            need(4*E*S*sum(errors)<=e*ell*T,'direct_leaf_delta')
    need(occupied==set(range(n)),'terminal_partition_complete')
    for k,z in enumerate(ans['output']):
        truth=direct_node(x,k,n)[0]
        errors=[max(abs(z[c]*(T//(2*S))-truth[c][0]),abs(z[c]*(T//(2*S))-truth[c][1])) for c in (0,1)]
        # A stronger epsilon*ell target implies the requested epsilon*r target.
        need(sum(v*v for v in errors)*(E*S)**2<=(e*ell*T)**2,'global_unitary_DFT_error')
    expected={'input_pairs':n,'validated_components':2*n,'dense_zero_writes':n,
              'state_entries_created':n+volume,'norm_entries':n+volume,'split_volume':volume,
              'split_nodes':split,'butterflies':volume//2,'visited_nodes':len(rows),
              'node_receipt_rows':len(rows),'retained_writes':retained,
              'pruned_nodes':pruned,'pruned_coordinates':pruned_coords,'root_entries':2*n-1}
    for key,value in expected.items():need(ledger.get(key,0)==value,'structural_ledger_'+key)
    need(ledger['peak_state_entries']<=2*n,'live_storage_bound')
    need(volume<=n*(n.bit_length()-1),'V_full_tree_bound')
    need(sum(ledger['arithmetic_counts'].values())==ledger['arithmetic_primitives'],'arithmetic_sum')
    need(ledger['arithmetic_primitives']<=131*n+84*volume+790,'independent_primitive_bound')
    need(ledger['arithmetic_primitives']<=160*n+100*volume+2048,'declared_primitive_bound')
    need(ledger['maximum_integer_bits']<=291<=320,'bit_bound')
    need(len(json.dumps(ans,separators=(',',':')).encode())<1<<20,'receipt_size')
    for d,count in depths.items():
        need(count<=min(1<<d,16*E*E//(e*e)),'energy_node_bound')
    return {'receipt':tag,'N':n,'e':e,'nodes':len(rows),'split_volume':volume,
            'global_output_coordinates_checked':n,'retained_leaf_certificates':retained,
            'maximum_norm_error_rational':str(largest_norm_error),
            'primitive_count_from_receipt':ledger['arithmetic_primitives']}


def check_static_code(code):
    tree=ast.parse(code)
    imports=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.ImportFrom):imports.append((node.module,[a.name for a in node.names]))
        need(not isinstance(node,(ast.Import,ast.AsyncFunctionDef,ast.Await,ast.With,ast.AsyncWith)),'no_dynamic_program_features')
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name):
            need(node.func.id not in ('eval','exec','compile','open','__import__'),'no_dynamic_execution_or_IO')
    need(imports==[('math',['isqrt']),('collections',['Counter'])],'limited_imports')
    # Exact source guards, checked after parsing. Manual report establishes
    # their short-circuit ordering and successful/failed branch behavior.
    guards=["type(op_limit) is not int or not 0<=op_limit<=MAX_OPS",
            "type(x) is not list or len(x) not in (1,2,4,8,16,32,64,128,256)",
            "type(e) is not int or e.bit_length()>18 or not 0<=e<=2*E",
            "type(z) not in (tuple,list) or len(z)!=2",
            "type(t) is not int or t.bit_length()>16 or not -32768<=t<=32767"]
    for guard in guards:need(guard in code,'exact_builtin_validation_guard')
    need('except Halt as h:' in code and 'return result(h.status,None,a,ledger,[])' in code,'fail_closed_result')
    return {'candidate_AST_parsed_only':True,'candidate_executed':False,'static_guards':len(guards)}


def universal_bounds():
    q=F(1,S);R=F(1,1<<108)
    need(128**2*2*256<4096**2,'input_norm_magnitude')
    B=65564*q+8194*R
    need(B< F(1,1<<93),'width_recurrence_constant')
    w=F(0);record=[]
    for d in range(9):
        t=2*w+16390*q
        need(w<1 and t<1,'width_induction_closure')
        need(w<F(1,1<<69),'uniform_state_width')
        need((32*w+2*q)/2<F(1,1<<64),'uniform_norm_midpoint_error')
        record.append({'depth':d,'width_bound':str(w),'scaled_width_bound':str(t)})
        w=8*w+B
    need(F(1,1<<16)*F(1,1<<8)/4==F(1,1<<26),'minimum_delta')
    need(F(1,1<<64)<F(1,1<<26) and F(1,1<<69)<F(1,1<<26),'error_budget_margin')
    need(2*256*(4097*S)**2<1<<291,'norm_accumulator_bits')
    need(160*256+100*2048+2048==247808<1000000,'default_resource_margin')
    for n in (1,2,4,8,16,32,64,128,256):
        for v in range(n*(n.bit_length()-1)+1):
            need(131*n+84*v+790<=160*n+100*v+2048,'primitive_bound_domination')
    # Exact comparator ties and opposite perturbations at multiple scales.
    for k in (1,3,1<<100):
        lo=k;hi=2*k;d=2*E*k
        need(2*E*(lo+hi)==3*d,'guard_tie_constructed')
        need(2*E*(lo+hi)<=3*d,'guard_equality_prunes')
        need(not 2*E*(lo+hi+1)<=3*d,'guard_one_above_retains')
        need(2*E*(lo+hi-1)<=3*d,'guard_one_below_prunes')
    return record


def primitive_controls():
    # Exhaustive signed endpoint product controls at a nontrivial small scale;
    # endpoint monotonicity and floor/ceil identities make this scale-generic.
    scale_=16
    boxes=[(a,b) for a in range(-20,21) for b in range(a,21)]
    for x in boxes:
        for y in boxes:
            lo,hi=product(x,y,scale_)
            exact=[F(a*b,scale_) for a in x for b in y]
            need(lo<=min(exact)<=max(exact)<=hi,'signed_product_enclosure')
            need(min(exact)-lo<1 and hi-max(exact)<1,'directed_product_rounding')
    for lo in range(65):
        for hi in range(lo,65):radical((lo,hi),scale_)
    # Mutation controls on independent predicates, not candidate programs.
    need(not (ceildiv(-1,16)<=F(-1,16)),'reject_ceil_as_lower_bound')
    need(not (F(1,16)<=1//16),'reject_floor_as_upper_bound')
    need(not (math.isqrt(2)**2>=2),'reject_floor_sqrt_as_upper')
    need(not (2*E*(1+2)<3*(2*E)),'reject_strict_guard_equality')
    need(not (F(1,2)==F(1,1)),'reject_raw_vs_unitary_N4_scale')
    return {'signed_interval_pairs':len(boxes)**2,'nonnegative_sqrt_boxes':65*66//2,'negative_controls':5}



def receipt_negative_controls(receipt):
    x=receipt['input'];ans=receipt['result'];n=len(x)
    e=receipt['epsilon_numerator'];ell=ans['ell_numerator']
    threshold=(e*ell*T)**2
    def lower_error(z,truth,output_scale=1,truth_scale=1):
        lower=[]
        for c in (0,1):
            val=z[c]*(T//(2*S))*output_scale
            lo,hi=(truth[c][0]*truth_scale,truth[c][1]*truth_scale)
            lower.append(lo-val if val<lo else val-hi if val>hi else 0)
        return sum(v*v for v in lower)*(E*S)**2
    k=1;z=ans['output'][k];truth=direct_node(x,k,n)[0]
    need(lower_error(z,direct_node(x,n-k,n)[0])>threshold,'negative_wrong_exponent_rejected')
    rev=int(format(k,'08b')[::-1],2)
    need(lower_error(z,direct_node(x,rev,n)[0])>threshold,'negative_bit_reversal_rejected')
    need(lower_error(z,truth,truth_scale=16)>threshold,'negative_raw_normalization_rejected')
    need(lower_error(z,truth,output_scale=2)>threshold,'negative_Q128_output_scale_rejected')
    altered=list(z);altered[0]+=2*S
    need(lower_error(altered,truth)>threshold,'negative_corrupted_output_rejected')
    row=ans['nodes'][0];nl,nh=boxnorm(direct_node(x,0,1))
    shifted=(row['norm_lo']+row['norm_hi']+2*S)*(T//S)
    err=max(abs(shifted-2*nl),abs(shifted-2*nh))
    need(2*E*S*err>e*ell*T,'negative_corrupted_node_norm_rejected')
    return {'wrong_exponent':True,'bit_reversal':True,'raw_normalization':True,
            'Q128_instead_of_Q129_output':True,'corrupted_output':True,'corrupted_node_norm':True}


def main():
    archive=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'candidate.zip')
    destination=pathlib.Path(sys.argv[2] if len(sys.argv)>2 else 'INDEPENDENT_RESULTS.json')
    raw=archive.read_bytes();need(sha(raw)==ARCHIVE_SHA,'archive_seal')
    with zipfile.ZipFile(archive) as z:
        data={name:z.read(name) for name in z.namelist()}
    manifest=json.loads(data['MANIFEST.json'])
    for entry in manifest['files']:
        need(len(data[entry['path']])==entry['bytes'],'manifest_size')
        need(sha(data[entry['path']])==entry['sha256'],'manifest_hash')
    for pin in json.loads(data['SOURCE_PINS.json']):
        need(sha(data[pin['copy']])==pin['sha256'],'source_pin_hash')
        need(len(data[pin['copy']])==pin['bytes'],'source_pin_size')
    code_report=check_static_code(data['certifier_fresh.py'].decode())
    claimed=json.loads(data['RESULTS.json'])
    setups=[]
    for expected in claimed['root_setup']:
        n=expected['N'];c,tables,w,ops=reconstruct_setup(n)
        digest=sha(json.dumps(tables,sort_keys=True,separators=(',',':')).encode())
        need(digest==expected['root_table_sha256'],'cold_root_hash_match')
        need(w==expected['maximum_coordinate_width_Q128_units'],'cold_root_width_match')
        need(ops==expected['arithmetic_primitives'],'cold_root_operation_count_match')
        need(sum(map(len,tables.values()))==2*n-1,'cold_root_entries')
        need(0<=c[0]<=c[1]<=S and c[1]-c[0]<=2,'normalizer_enclosure_bound')
        for m,row in tables.items():
            reference=direct_roots(m)
            for k,z in enumerate(row):
                for coord in (0,1):
                    # Strong independent control: a much tighter certified
                    # oracle is wholly contained, not merely intersecting.
                    a,b=z[coord];u,v=reference[k][coord]
                    need(a*(T//S)<=u<=v<=b*(T//S),'direct_root_contained_in_Q128')
        setups.append({'N':n,'width_Q128_units':w,'root_table_sha256':digest,'primitive_count':ops})
    bounds=universal_bounds()
    controls=primitive_controls()
    selected=json.loads(data['SELECTED_RECEIPTS.json'])
    receipts=[audit_receipt(rec,i) for i,rec in enumerate(selected)]
    negatives=receipt_negative_controls(selected[2])
    report={'status':'PASS','candidate_archive_sha256':ARCHIVE_SHA,
            'candidate_source_sha256':sha(data['certifier_fresh.py']),
            'proof_sha256':sha(data['PROOF_API_LEDGER.md']),
            'candidate_or_historical_programs_executed':False,
            'static_review':code_report,'root_setups':setups,
            'universal_rational_bounds':bounds,'primitive_controls':controls,
            'independent_direct_receipts':receipts,'receipt_negative_controls':negatives,
            'total_checks':sum(CHECKS.values()),'checks_by_category':dict(CHECKS),
            'scope':'Exact bounded certificate API only. No exact mask, runtime, novelty, all-size or scientific-parent closure.'}
    destination.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'total_checks':report['total_checks'],
                      'root_widths':[s['width_Q128_units'] for s in setups],
                      'receipts':len(receipts),'report':str(destination)},indent=2))
if __name__=='__main__': main()
