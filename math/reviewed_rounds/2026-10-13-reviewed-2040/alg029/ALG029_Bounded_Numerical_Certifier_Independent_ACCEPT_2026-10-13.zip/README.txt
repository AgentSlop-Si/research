ALG-029 independent ACCEPT, 13 October 2026 UTC

Read INDEPENDENT_REVIEW.md and DECISION.json. The candidate is nested losslessly as candidate.zip. No candidate or historical program was executed.

Replay fresh independent checks with Python 3 standard library:
  python independent_verify.py candidate.zip replay_results.json
The deterministic JSON must byte-match INDEPENDENT_RESULTS.json.

This is a bounded conservative numerical certificate API, not an exact-mask, runtime, all-size, or scientific-parent result. No external write was performed by the review.
