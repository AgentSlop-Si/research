"""Independent byte-bound NTT extension audit. No candidate code is loaded.

Scientific evaluation uses freshly constructed power-table Vandermonde rows,
not the candidate radix-2 generator or its polynomial-Horner verifier.
Only Python standard-library modules are imported; no timers are sampled.
"""
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import resource
import struct
import zipfile

# Install hard caps before opening evidence or doing scientific work.
resource.setrlimit(resource.RLIMIT_CPU, (180, 180))
resource.setrlimit(resource.RLIMIT_AS, (268435456, 268435456))
resource.setrlimit(resource.RLIMIT_FSIZE, (67108864, 67108864))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
HERE = Path(__file__).resolve().parent
P = 998244353
G = 3
PREFIX = 'paid_ntt_extension_candidate_2013/'
ARCHIVE_SHA = 'c36757feea1a39a520ed42a8251bf81618fea08a00a870f77b5c4e44505592fb'
CASES = ['zero', 'ones', 'minus_ones', 'impulse_0', 'impulse_1', 'impulse_floor_n3', 'alternating', 'ramp'] + ['dense_'+str(i) for i in range(8)]
checks = []
controls = []


def sha(b):
    return hashlib.sha256(b).hexdigest()


def put(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def demand(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)


def legal(n, p=P, g=G):
    if type(p) is not int or p != P or type(g) is not int or g != G:
        raise ValueError('unapproved constants')
    if type(n) is not int or n < 2 or n > 1024 or n & (n-1):
        raise ValueError('outside independently bounded length domain')
    return n


def residues(values, n):
    legal(n)
    if type(values) not in (list, tuple) or len(values) != n:
        raise ValueError('bad residue extent or container')
    if any(type(v) is not int or not 0 <= v < P for v in values):
        raise ValueError('bad canonical residue')


def decode(raw, n):
    legal(n)
    if type(raw) is not bytes or len(raw) != 4*n:
        raise ValueError('bad wire length/type')
    values = list(struct.unpack('<' + str(n) + 'I', raw))
    residues(values, n)
    return values


def encode(values):
    residues(values, len(values))
    # Explicit octet extraction, separate from candidate codecs.
    return bytes(octet for v in values for octet in (v & 255, (v >> 8) & 255, (v >> 16) & 255, v >> 24))


def positive_root(n):
    legal(n)
    return pow(3, (998244353-1)//n, 998244353)


def root_guard(n, r):
    if type(r) is not int or r != positive_root(n):
        raise ValueError('wrong pinned root')
    if pow(r,n,P) != 1 or pow(r,n//2,P) != P-1:
        raise ValueError('wrong root order')


def vandermonde(values, inverse=False):
    """Dense exact matrix evaluation from a fresh O(n) power table.

    table[e]=omega**e. Row k uses table[(j*k) % n]. The full
    arbitrary-precision sum is reduced once per coordinate, with no
    butterflies, coefficient Horner loop, inherited tables, or pruning.
    """
    n = len(values)
    residues(values, n)
    omega = positive_root(n)
    if inverse:
        omega = pow(omega, P-2, P)
    powers = [1]
    for _ in range(1,n):
        powers.append(powers[-1]*omega % P)
    scale = pow(n,P-2,P) if inverse else 1
    return [(sum(values[j]*powers[(j*k) % n] for j in range(n)) % P)*scale % P for k in range(n)]


def compare(received, expected):
    residues(expected, len(expected))
    residues(received, len(expected))
    for a,b in zip(received, expected):
        if a != b:
            raise ValueError('complete-coordinate disagreement')


def reject(label, fn):
    try:
        fn()
    except (ValueError, TypeError):
        controls.append({'name':label,'rejected':True})
        return
    raise AssertionError('negative control escaped: '+label)


def closed_form(case,n):
    if case == 'zero': return [0]*n
    if case == 'ones': return [n]+[0]*(n-1)
    if case == 'minus_ones': return [P-n]+[0]*(n-1)
    if case == 'alternating': return [n if k==n//2 else 0 for k in range(n)]
    if case in ('impulse_0','impulse_1','impulse_floor_n3'):
        loc = {'impulse_0':0,'impulse_1':1,'impulse_floor_n3':n//3}[case]
        return [pow(positive_root(n), loc*k, P) for k in range(n)]
    return None


def main():
    archive = HERE/'inputs/candidate.zip'
    demand(sha(archive.read_bytes()) == ARCHIVE_SHA, 'requested candidate archive SHA-256')
    z = zipfile.ZipFile(archive)
    names = z.namelist()
    demand(len(names)==61 and len(set(names))==61, '61 unique archive members')
    demand(all(s.startswith(PREFIX) and '..' not in PurePosixPath(s).parts and not s.endswith('/') for s in names), 'safe candidate archive paths')
    demand(z.testzip() is None, 'archive CRCs')
    def raw(name): return z.read(PREFIX+name)
    def doc(name): return json.loads(raw(name))
    manifest = doc('FILES_SHA256.json')
    demand(len(manifest)==60 and len({e['file'] for e in manifest})==60, '60 unique packet hash entries')
    demand({PREFIX+e['file'] for e in manifest}|{PREFIX+'FILES_SHA256.json'} == set(names), 'packet manifest exact member coverage')
    binding_rows = []
    for group, entries, prefix in (
        ('packet',manifest,''),
        ('immutable_inputs',doc('INPUTS_SHA256.json'),''),
        ('protocol',doc('inputs/protocol/FILES_SHA256.json'),'inputs/protocol/'),
        ('prior_candidate',doc('inputs/candidate/FILES_SHA256.json'),'inputs/candidate/'),
        ('preexecution',doc('PREEXECUTION_SOURCE_SEAL.json')['sources'],'')):
        for e in entries:
            b=raw(prefix+e['file'])
            demand(len(b)==e['bytes'] and sha(b)==e['sha256'], group+' binding '+e['file'])
            binding_rows.append({'group':group,'file':prefix+e['file'],'bytes':len(b),'sha256':sha(b),'pass':True})
    declaration = doc('PREDECLARATION.json')
    prior_receipt=doc('inputs/PRIOR_ACCEPTANCE_RECEIPT.json')
    demand(sha(raw('INPUTS_SHA256.json'))==declaration['inputs_manifest_sha256'], 'declaration input manifest pin')
    demand(sha(raw('inputs/PRIOR_ACCEPTANCE_RECEIPT.json'))==declaration['prior_acceptance_receipt_sha256'], 'declaration prior receipt pin')
    demand(prior_receipt['decision']=='ACCEPT_BOUNDED_EXACT_ORACLE_CANDIDATE', 'prior acceptance decision preserved')
    for key,path in [('candidate_manifest_sha256','inputs/candidate/FILES_SHA256.json'),('protocol_manifest_sha256','inputs/protocol/FILES_SHA256.json'),('oracle_source_sha256','inputs/candidate/exact_oracle.py'),('candidate_test_source_sha256','inputs/candidate/test_exact_oracle.py'),('historical_cpp_sha256','inputs/historical/fft_engine.cpp'),('corpus_input_sha256','inputs/protocol/corpus_inputs.bin'),('accepted_output_sha256','inputs/candidate/tiny_expected_outputs.bin'),('review_report_sha256','inputs/PRIOR_INDEPENDENT_REVIEW.md')]:
        demand(prior_receipt[key]==sha(raw(path)), 'prior receipt binds '+key)
    protocol_receipt=doc('inputs/prior_acceptance/ACCEPTANCE_RECEIPT.json')
    for key,path in [('accepted_contract_sha256','PAID_NTT_CONTRACT.md'),('accepted_protocol_sha256','PROTOCOL.json'),('accepted_manifest_sha256','FILES_SHA256.json')]:
        demand(protocol_receipt[key]==sha(raw('inputs/protocol/'+path)), 'protocol acceptance binds '+key)
    for entry in doc('inputs/protocol/SOURCE_IDENTITIES.json')['sources']:
        b=raw('inputs/historical/'+Path(entry['path']).name)
        demand(len(b)==entry['bytes'] and sha(b)==entry['sha256'], 'historical source bytes '+Path(entry['path']).name)
    # Text/AST-only inventory; ast.parse does not import/compile/execute source.
    source_inventory=[]
    allowed={'struct','hashlib','json','pathlib','resource','sys','fresh_forward','ast','runpy'}
    for name in ['fresh_forward.py','generate_packet.py','verify_packet.py','run_bounded.py']:
        tree=ast.parse(raw(name).decode())
        imports=[]
        calls=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Import): imports.extend(a.name for a in node.names)
            elif isinstance(node,ast.ImportFrom): imports.append(node.module)
            elif isinstance(node,ast.Call): calls.append(ast.unparse(node.func))
        demand(set(imports)<=allowed,'source import allowlist '+name)
        demand(not any(s in calls for s in ('eval','exec','compile','__import__')), 'no hidden dynamic execution '+name)
        if name=='verify_packet.py': demand('fresh_forward' not in imports, 'candidate checker no producer import')
        source_inventory.append({'file':name,'sha256':sha(raw(name)),'imports':imports,'calls':sorted(set(calls)),'mode':'TEXT_AND_AST_ONLY_NEVER_EXECUTED'})
    # Establish scalar constants from scratch.
    demand(P % 2 == 1 and all(P%d for d in range(3,31600,2)), 'complete trial division primality of 998244353')
    demand(P-1==2**23*7*17, 'complete p-1 factorization')
    generator_checks={str(q):pow(G,(P-1)//q,P) for q in [2,7,17]}
    demand(all(v!=1 for v in generator_checks.values()), 'primitive generator order')
    root_rows=[]
    protocol_roots=doc('inputs/protocol/MODULUS_ROOT_CERTIFICATE.json')['length_root_checks']
    for n in (512,1024):
        w=positive_root(n); root_guard(n,w)
        q=pow(w,n//4,P)
        demand(q*q % P == P-1, 'quarter root n='+str(n))
        r={'n':n,'omega':w,'omega_to_n':pow(w,n,P),'omega_to_half_n':pow(w,n//2,P),'quarter_root':q}
        pinned=next(e for e in protocol_roots if e['n']==n)
        demand(all(r[k]==pinned[k] for k in ['n','omega','omega_to_n','omega_to_half_n']), 'protocol root pin n='+str(n))
        root_rows.append(r)
    # Full corpus identity/extent audit, including data only for larger lengths.
    corpus=doc('inputs/protocol/CORPUS_MANIFEST.json'); input_bytes=raw('inputs/protocol/corpus_inputs.bin')
    demand(corpus['modulus']==P and corpus['case_ids']==CASES and corpus['lengths']==[2**e for e in range(1,19)], 'corpus domain and cases')
    demand(len(input_bytes)==corpus['bytes']==33554304 and sha(input_bytes)==corpus['sha256'], 'full 33,554,304-byte corpus identity')
    demand(len(corpus['vectors'])==288, '288 corpus vectors')
    cursor=0
    corpus_rows=[]
    for i,e in enumerate(corpus['vectors']):
        n=2**(1+i//16)
        b=input_bytes[cursor:cursor+4*n]
        demand(e['n']==n and e['case']==CASES[i%16] and e['offset_bytes']==cursor and e['length_bytes']==4*n, 'corpus order extent '+str(i))
        demand(sha(b)==e['sha256'] and all(v[0]<P for v in struct.iter_unpack('<I',b)), 'corpus hash range '+str(i))
        corpus_rows.append({'ordinal':i,'n':n,'case':e['case'],'bytes':len(b),'sha256':sha(b),'pass':True})
        cursor+=4*n
    demand(cursor==len(input_bytes), 'corpus complete no trailing bytes')
    # Retain all prior accepted bytes; do not rerun the old accepted programs.
    tiny=doc('inputs/candidate/TINY_EXPECTED_MANIFEST.json'); tiny_bytes=raw('inputs/candidate/tiny_expected_outputs.bin')
    demand(len(tiny['vectors'])==128 and len(tiny_bytes)==32640 and sha(tiny_bytes)==declaration['unchanged_accepted_scope']['output_sha256'], '128 prior accepted outputs preserved')
    small_cursor=0
    for e,c in zip(tiny['vectors'],corpus['vectors'][:128]):
        n=c['n']; b=tiny_bytes[small_cursor:small_cursor+4*n]
        demand(e['n']==n and e['case']==c['case'] and e['offset_bytes']==small_cursor and e['length_bytes']==4*n and sha(b)==e['sha256'], 'prior output complete extent hash '+str(small_cursor))
        demand(all(v[0]<P for v in struct.iter_unpack('<I',b)), 'prior output canonical '+str(small_cursor))
        small_cursor+=4*n
    demand(small_cursor==32640, 'prior 8,160 coordinates')
    ext=doc('EXTENSION_EXPECTED_MANIFEST.json'); wire=raw('extension_expected_outputs.bin')
    demand(ext['protocol_id']=='paid-ntt-v2-20261013' and ext['lengths']==[512,1024] and ext['p']==P and ext['g']==G, 'extension constants/domain')
    demand(ext['direction']=='positive exponent; unnormalized; natural order', 'extension exact sign normalization order')
    demand(ext['format']=='little-endian uint32; no header; ascending n then frozen case order', 'extension wire semantics')
    demand(ext['source_sha256']==sha(raw('fresh_forward.py')) and ext['predeclaration_sha256']==sha(raw('PREDECLARATION.json')), 'extension source/declaration pins')
    demand(ext['input_corpus_sha256']==sha(input_bytes), 'extension corpus pin')
    demand(len(wire)==ext['bytes']==98304 and sha(wire)==ext['sha256']=='7ad3b732c3be717408ca2634a86a1518530225bd6428de043410655bc527863f', 'extension complete wire identity')
    demand(len(ext['vectors'])==ext['vectors_count']==32 and ext['coordinates']==24576, 'extension declared counts')
    # Literal anchors precede scientific evaluation of frozen extension vectors.
    anchors=[([2,7],[9,P-5]),([0,1,0,0],[1,911660635,P-1,86583718]),([2,3,5,7],[17,(2-5+911660635*(3-7))%P,P-3,(2-5-911660635*(3-7))%P])]
    for i,(a,b) in enumerate(anchors):
        compare(vandermonde(a),b); compare(vandermonde(b,True),a)
        demand(True,'literal forward/inverse anchor '+str(i))
    # Fresh transform evidence, all coordinates; nothing here calls input code.
    rebuilt=bytearray(); per_vector=[]; mutants=0; closed_count=0
    for i,e in enumerate(ext['vectors']):
        n=512 if i<16 else 1024; case=CASES[i%16]; c=corpus['vectors'][128+i]
        demand(e['n']==n and e['case']==case and e['input_offset_bytes']==c['offset_bytes'] and e['input_sha256']==c['sha256'], 'new vector input linkage '+str(i))
        demand(e['offset_bytes']==len(rebuilt) and e['length_bytes']==4*n, 'new vector wire extent '+str(i))
        xb=input_bytes[c['offset_bytes']:c['offset_bytes']+4*n]; x=decode(xb,n); before=list(x)
        yb=wire[e['offset_bytes']:e['offset_bytes']+4*n]; y=decode(yb,n)
        demand(sha(yb)==e['sha256'], 'new vector SHA-256 '+str(i))
        reference=vandermonde(x)
        compare(y,reference)
        demand(encode(reference)==yb, 'new full coordinate and wire equality '+str(i))
        compare(vandermonde(y,True),x)
        compare(vandermonde(y),[n*x[(-j)%n]%P for j in range(n)])
        demand(y[0]==sum(x)%P and sum(y)%P==n*x[0]%P,'new DC/sum '+str(i))
        closed=closed_form(case,n)
        if closed is not None: compare(y,closed); closed_count+=1
        demand(x==before and encode(x)==xb,'new input immutability '+str(i))
        changed=y.copy()
        for pos in range(n):
            changed[pos]=(y[pos]+1)%P
            try: compare(changed,reference)
            except ValueError: mutants+=1
            else: raise AssertionError('coordinate mutant escaped')
            changed[pos]=y[pos]
        if case=='impulse_1':
            reject('opposite_sign_'+str(n),lambda:compare([y[-k%n] for k in range(n)],reference))
            reject('wrong_primitive_root_'+str(n),lambda:compare([y[(3*k)%n] for k in range(n)],reference))
            reject('normalized_forward_'+str(n),lambda:compare([a*pow(n,P-2,P)%P for a in y],reference))
            depth=n.bit_length()-1
            reject('bit_reversed_'+str(n),lambda:compare([y[int(format(k,'0'+str(depth)+'b')[::-1],2)] for k in range(n)],reference))
            reject('big_endian_'+str(n),lambda:compare(list(struct.unpack('>'+str(n)+'I',yb)),reference))
        if case=='dense_0':
            corrupt=y.copy(); corrupt[1]=(corrupt[1]+1)%P; corrupt[2]=(corrupt[2]-1)%P
            demand(corrupt[0]==y[0] and sum(corrupt)%P==sum(y)%P, 'double mutant preserves scalar invariants '+str(n))
            reject('scalar_preserving_double_mutant_'+str(n),lambda:compare(corrupt,reference))
            for label,bad in [('short',y[:-1]),('long',y+[0]),('iterator',iter(y)),('boolean',[True]+y[1:]),('noncanonical',[P]+y[1:]),('negative',[-1]+y[1:])]:
                reject('output_'+label+'_'+str(n),lambda bad=bad:compare(bad,reference))
            for label,bad in [('short',yb[:-1]),('long',yb+b'\0'),('bytearray',bytearray(yb)),('noncanonical',P.to_bytes(4,'little')+yb[4:])]:
                reject('wire_'+label+'_'+str(n),lambda bad=bad:decode(bad,n))
        rebuilt.extend(encode(reference))
        per_vector.append({'ordinal':i,'n':n,'case':case,'coordinates_compared':n,'complete_wire_equal':True,'sha256':sha(yb),'inverse_equal':True,'forward_squared_equal':True,'DC_and_sum_equal':True,'closed_form_checked':closed is not None,'input_immutable':True,'single_coordinate_mutants_rejected':n})
    for n in [512,1024]:
        w=positive_root(n)
        for k,bad in enumerate([0,1,-1,P,True,pow(w,P-2,P),pow(w,3,P)]): reject('root_'+str(n)+'_'+str(k),lambda bad=bad,n=n:root_guard(n,bad))
    for k,bad in enumerate([False,True,-1,0,1,3,6,2048,2**23+1,2**24,512.0,'512',None]): reject('length_'+str(k),lambda bad=bad:legal(bad))
    for k,(p,g) in enumerate([(P+1,G),(P,4),(float(P),G),(P,True)]): reject('constant_'+str(k),lambda p=p,g=g:legal(512,p,g))
    for k,bad in enumerate([None,range(512),iter([0]*512),[0]*511,[0]*513]): reject('input_shape_'+str(k),lambda bad=bad:residues(bad,512))
    for k,bad in enumerate([-1,P,P+1,2**32-1,True,0.0,'0',None]): reject('coefficient_'+str(k),lambda bad=bad:residues([bad]+[0]*511,512))
    demand(len(set(c['name'] for c in controls))==len(controls), 'unique independent negative controls')
    demand(mutants==24576 and closed_count==14 and bytes(rebuilt)==wire, 'all new coordinates mutants closed forms and entire wire')
    # Recompute the candidate's accounting from literal sizes, not reports.
    ledger=doc('PAID_LEDGER.json'); p=ledger['producer_paid']; c=ledger['checker_paid']
    small_butterflies=sum(16*(2**e//2)*e for e in range(1,9)); new_butterflies=sum(16*(n//2)*(n.bit_length()-1) for n in [512,1024])
    matrix_terms=16*(512**2+1024**2)
    demand(p['successful_forward_butterflies']==small_butterflies+new_butterflies==147472 and p['extension_forward_butterflies']==new_butterflies==118784 and p['small_validation_forward_butterflies']==small_butterflies==28688, 'candidate butterfly ledger exact')
    demand(p['bit_reversal_bit_iterations_all_successful_calls']==2*(small_butterflies+new_butterflies)==294944,'candidate bit reversal ledger exact')
    demand(c['new_forward_horner_coefficient_steps']==c['forward_squared_horner_coefficient_steps']==c['inverse_matrix_summands']==matrix_terms==20971520,'candidate dense evaluation ledger exact')
    demand(declaration['resource_caps']['aggregate_cpu_seconds_cap']==360 and ledger['caps']['aggregate_cpu_seconds_for_original_two_serial_runs']==360,'candidate aggregate CPU cap is bound not timing')
    demand(sum(e['n'] for e in tiny['vectors'])+sum(e['n'] for e in ext['vectors'])==32736 and len(tiny['vectors'])+len(ext['vectors'])==160, 'combined accepted 160 vectors and 32,736 coordinates')
    remaining=corpus['vectors'][160:]
    demand(len(remaining)==128 and sorted(set(e['n'] for e in remaining))==[2**e for e in range(11,19)],'remaining 128 larger outputs absent')
    for name,expected in [('GENERATOR_CONTROLS.json',34),('CHECKER_CONTROLS.json',59)]:
        rows=doc(name)
        demand(len(rows)==expected and len({e['name'] for e in rows})==expected and all(e['rejected'] is True for e in rows),'author controls source-consistent recorded '+name)
    demand(sha(archive.read_bytes())==ARCHIVE_SHA,'candidate complete archive unchanged after independent run')
    put('BINDING_CHECKS.json',binding_rows)
    put('CORPUS_INPUT_AUDIT.json',corpus_rows)
    put('SOURCE_INVENTORY.json',source_inventory)
    put('INDEPENDENT_CONSTANTS.json',{'prime':P,'generator':G,'primality_method':'All odd divisors 3..31599, together with factor 2; upper bound exceeds floor sqrt(p).','generator_nonunity_checks':generator_checks,'roots':root_rows})
    put('PER_VECTOR_RESULTS.json',per_vector)
    put('INDEPENDENT_NEGATIVE_CONTROLS.json',controls)
    put('CHECKS.json',checks)
    (HERE/'independently_reconstructed_outputs.bin').write_bytes(rebuilt)
    put('INDEPENDENT_RESULTS.json',{'decision':'ACCEPT_BOUNDED_512_1024_EXACT_OUTPUT_EXTENSION','candidate_archive_sha256':ARCHIVE_SHA,'complete_new_vectors':32,'complete_new_coordinates':24576,'complete_new_bytes':len(rebuilt),'output_sha256':sha(rebuilt),'single_coordinate_mutants_rejected':mutants,'independent_conceptual_negative_controls':len(controls),'closed_form_vectors':closed_count,'literal_forward_inverse_anchors':len(anchors),'inverse_and_forward_squared_vectors':32,'full_corpus_input_vectors_audited_as_data':288,'prior_accepted_vectors_preserved':128,'prior_accepted_coordinates_preserved':8160,'combined_accepted_vectors':160,'combined_accepted_coordinates':32736,'remaining_missing_vectors':128,'remaining_lengths':[2**e for e in range(11,19)],'source_binding_checks':len(binding_rows),'asserted_checks':len(checks),'maximum_executed_transform_n':1024,'fresh_matrix_terms_each_of_forward_inverse_squared':matrix_terms,'candidate_or_prior_programs_executed':False,'author_negative_controls_rerun':False,'inherited_schedule_acceptance':False,'source_adapter_build_acceptance':False,'full_corpus_ready':False,'benchmark_ready':False,'performance_measurements':False,'resource_caps':{'CPU_seconds':180,'address_space_bytes':268435456,'single_file_bytes':67108864,'core_dump_bytes':0},'candidate_archive_unchanged':True})
    print('PASS: 32 vectors; 24576 exact coordinates; 98304 wire bytes; 24576 coordinate mutants; '+str(len(controls))+' fresh conceptual controls. No candidate or historical code executed.')


if __name__=='__main__': main()
