"""Read-only archive/workspace provenance recheck; executes no evidence code."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
CANDIDATE='Paid_NTT_512_1024_Exact_Output_Extension_Candidate_2026-10-13.zip'
PRIOR='Paid_NTT_Bounded_Exact_Oracle_Independent_Acceptance_2026-10-13.zip'
PREFIX='paid_ntt_extension_candidate_2013/'

def sha(b): return hashlib.sha256(b).hexdigest()
def save(n,v): (HERE/n).write_text(json.dumps(v,indent=2)+'\n')

assert sha((ROOT/CANDIDATE).read_bytes())=='c36757feea1a39a520ed42a8251bf81618fea08a00a870f77b5c4e44505592fb'
assert (ROOT/CANDIDATE).read_bytes()==(HERE/'inputs/candidate.zip').read_bytes()
c=zipfile.ZipFile(ROOT/CANDIDATE)
workspace=[]
for name in c.namelist():
    b=c.read(name)
    assert (ROOT/name).read_bytes()==b
    workspace.append({'file':name,'bytes':len(b),'sha256':sha(b),'workspace_matches_candidate_archive':True})
previous_seal=json.loads((HERE/'inputs/prior_acceptance.seal.json').read_text())
assert len((ROOT/PRIOR).read_bytes())==previous_seal['bytes']
assert sha((ROOT/PRIOR).read_bytes())==previous_seal['sha256']=='8fb4dba8f90387ac400bde1c2b108e0dc358c8c9fbe156e202a27a18a2d89bd7'
p=zipfile.ZipFile(ROOT/PRIOR)
assert p.testzip() is None
prior_prefix='paid_ntt_oracle_independent_review_1801/'
prior_manifest_bytes=p.read(prior_prefix+'FILES_SHA256.json')
assert sha(prior_manifest_bytes)==previous_seal['package_manifest_sha256']
prior_manifest=json.loads(prior_manifest_bytes)
assert {prior_prefix+e['file'] for e in prior_manifest}|{prior_prefix+'FILES_SHA256.json'}==set(p.namelist())
for e in prior_manifest:
    b=p.read(prior_prefix+e['file'])
    assert sha(b)==e['sha256'] and len(b)==e['bytes']
snapshots=[]
rows=json.loads(c.read(PREFIX+'WORKSPACE_PRESERVATION_RECHECK.json'))
for e in rows:
    b=c.read(PREFIX+e['snapshot'])
    assert (ROOT/e['original']).read_bytes()==b
    assert len(b)==e['bytes'] and sha(b)==e['sha256']
    prior_archived=e['original'] in p.namelist()
    if prior_archived: assert p.read(e['original'])==b
    snapshots.append({'snapshot':e['snapshot'],'original':e['original'],'bytes':len(b),'sha256':sha(b),'original_workspace_match':True,'prior_sealed_archive_match':prior_archived})
assert len(snapshots)==35 and sum(e['prior_sealed_archive_match'] for e in snapshots)==34
historical=[]
identities=json.loads(c.read(PREFIX+'inputs/protocol/SOURCE_IDENTITIES.json'))
for e in identities['sources']:
    path=Path(e['path']); b=path.read_bytes()
    assert len(b)==e['bytes'] and sha(b)==e['sha256']
    assert b==c.read(PREFIX+'inputs/historical/'+path.name)
    historical.append({'file':str(path),'bytes':len(b),'sha256':sha(b),'original_source_workspace_match':True})
save('WORKSPACE_PRESERVATION_RECHECK.json',{'candidate_workspace_members':workspace,'input_snapshots':snapshots,'original_historical_sources':historical,'prior_archive':{'file':PRIOR,'sha256':previous_seal['sha256'],'manifest_sha256':sha(prior_manifest_bytes),'all_members_verified':len(p.namelist()),'candidate_input_snapshots_rebound':34},'summary':{'candidate_workspace_members_equal':61,'input_originals_equal':35,'original_historical_sources_equal':2,'prior_archive_members_verified':41,'all_pass':True,'no_external_writes':True}})
print('PASS: all 61 candidate workspace members; all 35 original input snapshots; 34 prior-archive rebounds; 41 prior archive members; two original historical sources.')
