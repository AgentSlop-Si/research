"""Fresh inert review: reads JSON, hashes, archive entries and Python AST only."""
import ast,datetime,hashlib,json,os,pathlib,signal,sys,zipfile
B=pathlib.Path('/workspace/scratch/928904ebc9b0'); E=B/'q16_pinned_integration_execution_2027'; O=B/'q16_resource_blocker_independent_review_2032'; P=B/'q16_pinned_integration_contract_2014'
A=B/'Q16_Pinned_Integration_Resource_Blocker_2026-10-13.zip'
checks=[]
def ck(v,s):
 if not v:raise AssertionError(s)
 checks.append(s)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def check_manifest(folder):
 m=load(folder/'MANIFEST.json'); s=load(folder/'SEAL.json')
 ck(sha(folder/'MANIFEST.json')==s['manifest_sha256'],'manifest seal '+folder.name)
 for r in m['files']:
  f=folder/r['path']; ck(f.stat().st_size==r['bytes'] and sha(f)==r['sha256'],'manifest member '+folder.name+'/'+r['path'])
 return m
m=check_manifest(E); check_manifest(P); check_manifest(B/'q16_pinned_contract_static_review_2023')
with zipfile.ZipFile(A) as z:
 names=z.namelist(); ck(len(names)==len(set(names))==13,'13 unique resource archive members')
 for n in names:
  ck(n.startswith(E.name+'/') and '..' not in pathlib.PurePosixPath(n).parts,'safe member '+n)
  ck(z.read(n)==(B/n).read_bytes(),'archive current byte match '+n)
ck(sha(E/'evidence/Q16_Pinned_Integration_Execution_Contract_2026-10-13.zip')=='56e1e8f1812a0cf671e0197c31ad8334c36b03f6cb47ae0c17769519e4b3f4eb','exact frozen contract archive')
ck(sha(E/'evidence/Q16_Pinned_Integration_Contract_Independent_Static_Review_2026-10-13.zip')=='a39b2c4ca2ffd4d8fd2e713564f34ae42ea47375ec00c4f8bd5bc3f248c7d3a5','exact prior independent review archive')
c=load(P/'CONTRACT.json'); launch=load(E/'LAUNCH_RECEIPT.json'); receipt=load(E/'POSTEXIT_RESOURCE_RECEIPT.json'); after=load(E/'POSTRUN_PINS.json'); status=load(E/'STATUS.json')
ck(sha(P/'CONTRACT.json')==launch['contract_sha256']==receipt['contract_sha256']=='5cacca0da872029d62c7f5d498310ae4c6a1a1a4ef997c735ec650163fb7ffce','shared exact contract digest')
ck(launch['source_pins']==c['files'],'launch exact six pins')
ck(launch['harness']==c['fresh_harness'],'launch exact harness pin')
ck(launch['caps']==receipt['runtime_caps']==c['caps'],'launch and exit exact approved caps')
for r in after['files']:
 f=P/r['path']; ck(r['unchanged'] and f.stat().st_size==r['bytes'] and sha(f)==r['sha256'],'postrun current pin '+r['path'])
for r in c['files']:
 f=P/r['path']; ck(sha(f)==r['sha256'],'scientific runtime source retained '+r['module'])
rt=c['runtime']; ck(sha(pathlib.Path(rt['executable']))==rt['sha256'],'current interpreter exact pin'); ck(sys.version==rt['version'],'same current version')
for rel,h in rt['direct_stdlib_pins'].items():ck(sha(pathlib.Path(rt['stdlib_root'])/rel)==h,'current direct stdlib source '+rel)
command=[rt['executable'],'-I','-S','-B',str(P/'integration_harness.py'),'--run-approved',receipt['contract_sha256']]
ck(launch['command']==receipt['command']==command,'exact same approved command')
ck(sha(E/'run_once_with_receipt.py')==launch['runner_sha256']=='526fd4fd652fe98dc88182baf68667d9eaaadf718645a69ac46eb01eea2f7369','launcher frozen pin')
s=(E/'run_once_with_receipt.py').read_text(); tree=ast.parse(s)
ck(sum(isinstance(n,ast.Call) and ast.unparse(n.func)=='subprocess.Popen' for n in ast.walk(tree))==1,'one launch call site')
for literal in ["(HERE/'LAUNCH_RECEIPT.json').open('x')","(HERE/'CHILD_STDOUT.log').open('xb')","(HERE/'CHILD_STDERR.log').open('xb')",'preexec_fn=limits','close_fds=True','start_new_session=True','stdin=subprocess.DEVNULL','os.wait4(p.pid,os.WNOHANG)','os.waitstatus_to_exitcode(status)',"(HERE/'POSTEXIT_RESOURCE_RECEIPT.json').write_text",'os.killpg(p.pid,signal.SIGKILL)']:
 ck(literal in s,'launcher guard '+literal)
limits=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='limits')
vals={}
for n in limits.body:
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call):
  vals[ast.unparse(n.value.args[0])]=ast.literal_eval(n.value.args[1])
ck(vals=={'resource.RLIMIT_CPU':(120,125),'resource.RLIMIT_AS':(536870912,536870912),'resource.RLIMIT_FSIZE':(8388608,8388608),'resource.RLIMIT_NOFILE':(64,64),'resource.RLIMIT_CORE':(0,0)},'exact pre-exec hard and soft limits')
ck("if time.monotonic()-start>=180:" in s,'external wall deadline 180')
ck(receipt['raw_wait_status']==24 and os.WIFSIGNALED(24) and os.WTERMSIG(24)==signal.SIGXCPU,'wait status SIGXCPU')
ck(receipt['exit_code']==os.waitstatus_to_exitcode(24)==-24 and receipt['terminating_signal']==24,'exit code and signal decode')
ck(abs(receipt['full_child_user_cpu_seconds']+receipt['full_child_system_cpu_seconds']-receipt['full_child_total_cpu_seconds'])<1e-12,'CPU sum')
ck(receipt['full_child_total_cpu_seconds']==122.135224,'actual CPU retained exactly')
ck(120<receipt['full_child_total_cpu_seconds']<125,'actual CPU exceeds soft but below hard backstop')
ck(receipt['full_child_wall_seconds']==122.19877721200464 and not receipt['wall_limit_triggered'],'wall receipt no external wall trigger')
wall=(datetime.datetime.fromisoformat(receipt['finished_utc'])-datetime.datetime.fromisoformat(receipt['started_utc'])).total_seconds()
ck(abs(wall-receipt['full_child_wall_seconds'])<.01,'UTC and monotonic elapsed agree within stamping overhead')
ck(receipt['full_child_peak_rss_kib']==45240,'peak RSS receipt exact')
ck(not receipt['scientific_result_exists'] and not after['scientific_result_exists'] and not (P/'results/EXECUTION_RESULT.json').exists(),'no numerical result in receipt or current filesystem')
for name in ['CHILD_STDOUT.log','CHILD_STDERR.log']:
 f=E/name; ck(f.stat().st_size==receipt[name]['bytes']==0 and sha(f)==receipt[name]['sha256'],'empty log with correct digest '+name)
ck(receipt['retries']==status['retries']==0 and status['historical_execution_attempts']==1,'one recorded attempt zero retries')
ck(status['numerical_integration']=='INCONCLUSIVE_NO_RESULT' and status['individual_case_completion']=='UNKNOWN_NO_CHECKPOINTS','correct inconclusive scope')
ck('No partial case pass is inferred' in (E/'DELIVERY_ADDENDUM.md').read_text(),'absence does not grant partial pass')
ck('nonzero' in (E/'DELIVERY_ADDENDUM.md').read_text(),'alias clarification included')
ck(not any(r['module'] in sys.modules for r in c['files']),'review never loaded scientific modules')
result={'status':'PASS_INERT_RESOURCE_EVIDENCE_CHECKS','assertions':len(checks),'candidate_archive':A.name,'candidate_archive_sha256':sha(A),'candidate_manifest_sha256':sha(E/'MANIFEST.json'),'postexit_receipt_sha256':sha(E/'POSTEXIT_RESOURCE_RECEIPT.json'),'launcher_sha256':sha(E/'run_once_with_receipt.py'),'scientific_execution_by_reviewer':False,'harness_or_launcher_execution_by_reviewer':False,'checks':checks}
(O/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
