from pathlib import Path
import hashlib,json,re,zipfile,subprocess
roots=[Path('/workspace/scratch/928904ebc9b0'),Path('/workspace/shared')]
pat=re.compile(r'fragmentation|common.refinement|summed Frobenius|sibling rectangles|stable arc|A2.{0,35}Frobenius|one shared order|separator.{0,50}(Frobenius|approximation)',re.I)
seen=set();results=[];fails=[];n=0
for root in roots:
 for p in root.rglob('*'):
  if p.suffix.lower() not in ['.pdf','.docx']:continue
  h=hashlib.sha256(p.read_bytes()).hexdigest()
  if h in seen:continue
  seen.add(h);n+=1
  try:
   if p.suffix=='.pdf':s=subprocess.run(['pdftotext','-layout',str(p),'-'],capture_output=True,text=True,timeout=20,check=True).stdout
   else:
    with zipfile.ZipFile(p) as z:s=re.sub('<[^>]+>',' ',z.read('word/document.xml').decode())
  except Exception as e:fails.append([str(p),str(e)]);continue
  hits=[{'line':i,'text':line[:4000]} for i,line in enumerate(s.splitlines(),1) if pat.search(line)]
  if hits:results.append({'path':str(p),'sha256':h,'matches':hits})
Path('/workspace/shared/fragmentation_prior_art_20261013/document_duplicate_scan.json').write_text(json.dumps({'unique_documents':n,'pattern':pat.pattern,'matches':results,'failures':fails},indent=2))
print(n,'documents;',len(results),'matching;',len(fails),'failed')
for r in results:
 print(r['path'])
 for m in r['matches']:print(m['line'],m['text'][:200])
