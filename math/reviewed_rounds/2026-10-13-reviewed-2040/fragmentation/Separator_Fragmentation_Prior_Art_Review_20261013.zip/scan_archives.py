from pathlib import Path
import zipfile,io,hashlib,json,re,time
roots=[Path('/workspace/scratch/928904ebc9b0'),Path('/workspace/shared')]
pat=re.compile(r'recursive fragmentation|simultaneous.energy|common.refinement|disjoint sibling|summed Frobenius|A2.{0,35}Frobenius|one shared order|asymptotic.{0,25}unit.error',re.I)
seen=set();textseen=set();matched=[];skipped=[];zcount=0;tcount=0
start=time.time()
def scan(data,label,depth=0):
 global zcount,tcount
 sha=hashlib.sha256(data).hexdigest()
 if sha in seen:return
 seen.add(sha);zcount+=1
 try:z=zipfile.ZipFile(io.BytesIO(data))
 except Exception as e:skipped.append([label,str(e)]);return
 for i in z.infolist():
  ext=Path(i.filename).suffix.lower()
  if ext not in ['.md','.txt','.tex','.zip','.docx']:continue
  limit=100_000_000 if ext in ['.zip','.docx'] else 16_000_000
  if i.file_size>limit or depth>64:skipped.append([label+'!'+i.filename,'size/depth cap']);continue
  try:d=z.read(i)
  except Exception as e:skipped.append([label+'!'+i.filename,str(e)]);continue
  child=label+'!'+i.filename
  if ext=='.zip':scan(d,child,depth+1);continue
  if ext=='.docx':
   try:
    zz=zipfile.ZipFile(io.BytesIO(d));d=zz.read('word/document.xml');d=re.sub(b'<[^>]+>',b' ',d)
   except:continue
  h=hashlib.sha256(d).hexdigest()
  if h in textseen:continue
  textseen.add(h);tcount+=1
  try:s=d.decode('utf8')
  except:continue
  hits=[{'line':n,'text':line[:2200]} for n,line in enumerate(s.splitlines(),1) if pat.search(line)]
  if hits:matched.append({'path':child,'sha256':h,'matches':hits})
for root in roots:
 for p in root.rglob('*.zip'):
  if any(x in p.parts for x in ['.git','.aws','.codex']):continue
  if p.stat().st_size>300_000_000:skipped.append([str(p),'outer size cap']);continue
  scan(p.read_bytes(),str(p))
out={'unique_archives_scanned':zcount,'unique_text_members_scanned':tcount,'pattern':pat.pattern,'matches':matched,'skipped':skipped,'seconds':time.time()-start}
Path('/workspace/shared/fragmentation_prior_art_20261013/archive_duplicate_scan.json').write_text(json.dumps(out,indent=2))
print({k:v for k,v in out.items() if k not in ['matches','skipped']});print('matching',len(matched),'skipped',len(skipped))
for r in matched:
 if any(re.search('A2.{0,35}Frobenius|disjoint sibling|one shared order|asymptotic.{0,25}unit.error',m['text'],re.I) for m in r['matches']):
  print(r['path'])
  for m in r['matches']:print(m['line'],m['text'][:550])
