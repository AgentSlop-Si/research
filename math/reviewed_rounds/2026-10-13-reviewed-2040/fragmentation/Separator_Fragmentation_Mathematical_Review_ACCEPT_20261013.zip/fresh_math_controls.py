from fractions import Fraction as F
from itertools import product
from random import Random
import json, time
start=time.monotonic(); rng=Random(13102026)
out={}
# Fresh independent code. It imports no local candidate or historical module.
def rank(a):
    a=[list(map(F,row)) for row in a]
    if not a:return 0
    m,n=len(a),len(a[0]); k=0
    for j in range(n):
        p=next((i for i in range(k,m) if a[i][j]),None)
        if p is None:continue
        a[k],a[p]=a[p],a[k]
        pivot=a[k][j]; a[k]=[x/pivot for x in a[k]]
        for i in range(k+1,m):
            v=a[i][j]
            if v:a[i]=[x-v*y for x,y in zip(a[i],a[k])]
        k+=1
        if k==m:break
    return k

def inverse(a):
    n=len(a); z=[[F(x) for x in row]+[F(i==j) for j in range(n)] for i,row in enumerate(a)]
    for j in range(n):
        p=next((i for i in range(j,n) if z[i][j]),None)
        if p is None:return None
        z[j],z[p]=z[p],z[j]
        v=z[j][j];z[j]=[x/v for x in z[j]]
        for i in range(n):
            if i==j:continue
            v=z[i][j]
            if v:z[i]=[x-v*y for x,y in zip(z[i],z[j])]
    return [row[n:] for row in z]

def sub(a,I,J):return [[a[i][j] for j in J] for i in I]
# Every ordered positive component-size sequence of total <= W, W <= 14.
packing=0;maxbins=0
for W in range(1,15):
    def visit(seq,total):
        global packing,maxbins
        bins=[]
        for x in seq:
            if not bins or 2*(bins[-1]+x)>W:bins.append(x)
            else:bins[-1]+=x
        assert len(bins)<=3
        assert all(2*x<=W for x in bins)
        packing+=1;maxbins=max(maxbins,len(bins))
        for x in range(1,min(W//2,W-total)+1):visit(seq+(x,),total+x)
    visit((),0)
out['ordered_packing_sequences']=packing;out['maximum_bins_seen']=maxbins
# All invertible 3x3 ternary matrices and all complementary cuts.
matrices=cuts=singular_principal=0
for values in product((-1,0,1),repeat=9):
    A=[list(values[k:k+3]) for k in (0,3,6)]; B=inverse(A)
    if B is None:continue
    matrices+=1
    for mask in range(8):
        I=[i for i in range(3) if mask>>i&1];J=[i for i in range(3) if not mask>>i&1]
        assert rank(sub(A,I,J))==rank(sub(B,I,J));cuts+=1
        if I and rank(sub(A,I,I))<len(I):singular_principal+=1
out.update(invertible_ternary_3x3=matrices,complementary_cut_checks=cuts,cuts_with_singular_principal_block=singular_principal)
# Exact weighted separator test for identity's matching lift.
matching_weights=0
for weights in product(range(3),repeat=6):
    total=sum(weights); heavy=[i for i in range(3) if 2*(weights[i]+weights[i+3])>total]
    assert len(heavy)<=1
    deleted=set()
    if heavy:
        i=heavy[0];deleted={i if weights[i]>=weights[i+3] else i+3}
    for i in range(3):
        assert 2*sum(weights[j] for j in (i,i+3) if j not in deleted)<=total
    matching_weights+=1
out['matching_zero_approximant_weightings']=matching_weights
# Independent branch routing and fragmentation of path lifts from bidiagonal Q.
def components(adj,V):
    todo=set(V);res=[]
    while todo:
        seed=min(todo);todo.remove(seed);S={seed};stack=[seed]
        while stack:
            v=stack.pop()
            for w in adj[v]&todo:todo.remove(w);S.add(w);stack.append(w)
        res.append(S)
    return res

def fragment(adj,h):
    deleted=set();leaves=[]
    def rec(V,path,d):
        if not V:return
        if d==h:
            leaves.append((V,path));return
        candidates=[set()]+[{v} for v in sorted(V)]
        for X in candidates:
            C=components(adj,V-X)
            if all(2*len(c)<=len(V) for c in C):break
        else:raise AssertionError('A forest lacks a one-vertex separator')
        assert len(X)<=1;deleted.update(X);bins=[]
        for c in C:
            if not bins or 2*(len(bins[-1])+len(c))>len(V):bins.append(set(c))
            else:bins[-1].update(c)
        assert len(bins)<=3
        for S in bins:rec(S,path|X,d+1)
    rec(set(range(len(adj))),set(),0)
    labels={}
    for c,(S,path) in enumerate(leaves):
        assert len(path)<=h and 2**h*len(S)<=len(adj)
        for v in S:
            assert adj[v]-S<=path;labels[v]=c
    assert len(deleted)<=((3**h-1)//2)
    assert deleted|set(labels)==set(range(len(adj)))
    return deleted,leaves,labels

families=cells=branch_rank_checks=positive_bounds=0
for N,r,h in [(16,r,h) for r in range(1,4) for h in range(1,5)]+[(64,1,h) for h in range(1,5)]:
    branches=[]
    for branch in range(r):
        edge=[rng.choice((-2,-1,1,2)) for _ in range(N-1)]
        Q=[[int(i==j)+(edge[i] if j==i+1 else 0) for j in range(N)] for i in range(N)]
        Inv=[[0]*N for _ in range(N)]
        for i in range(N):
            Inv[i][i]=1
            for j in range(i+1,N):Inv[i][j]=-Inv[i][j-1]*edge[j-1]
        assert all(sum(Q[i][k]*Inv[k][j] for k in range(N))==int(i==j) for i in range(N) for j in range(N))
        adj=[set() for _ in range(2*N)]
        for i in range(N):
            for j in range(N):
                if Q[i][j]:adj[i].add(N+j);adj[N+j].add(i)
        X,leaves,labels=fragment(adj,h)
        rowmap=list(range(N));colmap=list(range(N));rng.shuffle(rowmap);rng.shuffle(colmap)
        ls=[rng.choice((0,-1000000,-1,1,1000000)) for _ in range(N)]
        rs=[rng.choice((0,-3,1,2)) for _ in range(N)]
        M=[[ls[i]*Inv[rowmap[i]][colmap[j]]*rs[j] for j in range(N)] for i in range(N)]
        branches.append((X,leaves,labels,rowmap,colmap,M))
    rows=[i for i in range(N) if all(N+B[3][i] not in B[0] for B in branches)]
    cols=[j for j in range(N) if all(B[4][j] not in B[0] for B in branches)]
    qtot=(3**h-1)//2;P=(3**h*(3**h-1))**r;R=r*h
    assert 2*N-len(rows)-len(cols)<=r*qtot
    rt={i:tuple(B[2][N+B[3][i]] for B in branches) for i in rows}
    ct={j:tuple(B[2][B[4][j]] for B in branches) for j in cols}
    rg={t:[i for i in rows if rt[i]==t] for t in set(rt.values())}
    cg={t:[j for j in cols if ct[j]==t] for t in set(ct.values())}
    area=0;num=0;seen=set();T=[[sum(B[5][i][j] for B in branches) for j in range(N)] for i in range(N)]
    for a,I in rg.items():
        for b,J in cg.items():
            if any(x==y for x,y in zip(a,b)):continue
            num+=1;area+=len(I)*len(J)
            for i in I:
                for j in J:assert (i,j) not in seen;seen.add((i,j))
            for B in branches:
                assert rank(sub(B[5],I,J))<=h;branch_rank_checks+=1
            assert rank(sub(T,I,J))<=R;cells+=1
    assert num<=P
    assert area>=F(N*N)*(1-F(r,2**h))-r*qtot*N
    s=int(N**0.5);assert s*s==N
    err=sum((F((-1)**((i&j).bit_count()),s)-T[i][j])**2 for i in range(N) for j in range(N))/N
    floor=max(F(0),1-F(r,2**h)-F(r*qtot+R*P,N))
    assert err>=floor
    if floor>0:positive_bounds+=1
    families+=1
out.update(routed_path_families=families,good_rectangles=cells,branch_cell_rank_checks=branch_rank_checks,nonvacuous_universal_bounds=positive_bounds)
# Exact formula checks for small/large h and ceiling choices; no float logs.
growth=0
for r in range(1,41):
    for q in (1,2,7):
        for delta in (F(1),F(3,4),F(1,2),F(1,10),F(1,1000)):
            h=1
            while F(r,2**h)>delta/2:h+=1
            assert F(r,2**h)<=delta/2
            b=3**h;Q=q*(b-1)//2;R=r*q*h;P=(b*(b-1))**r
            exact=F(2,1)/delta*(r*Q+R*P)
            coarser=F(4*r*q*h,1)/delta*b**(2*r)
            assert exact<=coarser
            N=exact.numerator//exact.denominator+1
            raw=1-F(r,2**h)-F(r*Q+R*P,N)
            assert raw>1-delta
            growth+=1
out['growth_and_rounding_checks']=growth
out['finite_comparison_new']=str(F(1,2)-F(7,64));out['finite_comparison_old']=str(F(377,4096))
assert F(1,2)-F(7,64)>F(377,4096)
out['elapsed_seconds']=round(time.monotonic()-start,3);out['status']='PASS'
print(json.dumps(out,indent=2))
