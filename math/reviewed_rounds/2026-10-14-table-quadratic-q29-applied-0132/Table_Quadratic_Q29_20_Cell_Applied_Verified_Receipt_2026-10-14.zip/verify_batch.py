"""Verify a completed native batch against its exact before/request snapshot."""
import pathlib,json,sys
from check_source_runs import expected_native_cell
P=pathlib.Path(__file__).resolve().parent;i=int(sys.argv[1]);stem=f'BATCH_{i:02d}';read=lambda n:json.loads((P/n).read_text())
g=read(stem+'_GUARDS.json');req=read(stem+'_REQUEST.json');r=read(stem+'_AFTER.json')['result'];receipt=read(stem+'_RECEIPT.json')['result']
def flatten(data):
 out={}
 for s in data['sheets']:
  for b in s.get('data',[]):
   for ri,row in enumerate(b.get('rowData',[]),b.get('startRow',0)+1):
    for ci,c in enumerate(row.get('values',[]),b.get('startColumn',0)+1):out[s['properties']['title'],ri,ci]=c
 return out
after=flatten(r['structuredContent']);problems=[];applied=0;unchanged=0
for x,w in zip(g['targets'],req['requests']):
 k=tuple(x['key']);a=after.get(k);write=w['updateCells']['rows'][0]['values'][0]
 if a==x['before']:unchanged+=1;continue
 try:
  expected=expected_native_cell(x['before'],write,a);assert a==expected,'Unintended native field change';applied+=1
 except Exception as e:problems.append({'key':k,'problem':str(e)})
for x in g['ids']:
 if after.get(tuple(x['key']),{}).get('userEnteredValue')!=x['value']:problems.append({'key':x['key'],'problem':'Stable ID changed'})
v={'batch':i,'status':'PASS' if not receipt.get('isError') and applied==len(g['targets']) and not problems else 'STOP','applied_text_cells':applied,'unchanged_text_cells':unchanged,'new_source_link_spans':sum(sum('link' in x.get('format',{}) for x in w['updateCells']['rows'][0]['values'][0]['textFormatRuns']) for w in req['requests']),'problems':problems,'receipt_is_error':receipt.get('isError',False)}
(P/(stem+'_VERIFICATION.json')).write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
if v['status']!='PASS':sys.exit(1)
