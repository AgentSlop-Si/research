import json,pathlib,hashlib,zipfile,datetime,shutil
P=pathlib.Path(__file__).resolve().parent;R=P.parent;Q=R/'later_table_proposal_0117';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(pathlib.Path(p).read_text())
ver=read(P/'FINAL_AFTER_VERIFICATION.json');assert ver['status']=='PASS'
for name in ['SOURCE_BINDINGS.json','GUARDED_DELTA.json','EXACT_REQUEST.json','PROPOSAL.md','VALIDATION.json']:
 shutil.copyfile(Q/name,P/('REVIEWED_'+name))
summary={'status':'APPLIED_AND_FULLY_VERIFIED','spreadsheet_id':'1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU','spreadsheet_url':'https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit','scope':'Frozen quadratic-bank/Q29 update after the completed 38-cell checkpoint; later research is separate','applied_text_cells':20,'source_link_spans':21,'pending_text_cells':0,'stable_id_guards':19,'full_native_cells_compared':19795,'unexpected_native_differences':0,'prior_three_link_repairs_preserved':True,'numeric_scores_formulas_cell_styles_history_and_existing_links_preserved':True,'new_link_styles':'Only the 21 new source-label spans receive native hyperlink formatting; every following historical span resets to its original inherited formatting.','batches':3,'new_cancellations':0,'new_denials':0,'source_acceptances':read(Q/'SOURCE_BINDINGS.json'),'reviewed_proposal_zip_sha256':'e9aecc2038f819d2c6f6257aeb023f7048159b8647380ecde94fccede4c7a63f','reviewed_request_sha256':sha((Q/'EXACT_REQUEST.json').read_bytes()),'reviewed_delta_sha256':sha((Q/'GUARDED_DELTA.json').read_bytes()),'full_verification_sha256':sha((P/'FINAL_AFTER_VERIFICATION.json').read_bytes()),'completion_verified_at':ver['verified_at'],'scientific_limits':['Pinned original-bank minimum b4(F23^2)=14 at N=11, q=13, exactly one effective cross-sign alpha node per orientation, both pinned to 4; all legal beta allowed. Exact equality also holds over F23^d when d is even and not divisible by 5.','The quadratic result does not establish an exact d=3 value or an unrestricted orientation-allocation optimum. Later free-cross evidence is outside this frozen update.','Q29 is bounded to t=27, p=5, e=3 shared-center Newton data and integral degree-1686 normalization with coefficients certified strictly below precision 40.','The local discriminant bound is at least 4092; Disc R843 nonvanishing/value and full Q29 remain open.','No numeric priority, novelty or general FFT-speed claim changes.']}
(P/'APPLICATION_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(P/'README.md').write_text('''# Quadratic-bank and Q29 table update: applied and verified

14 October 2026. Twenty short dated notes were applied to the existing research spreadsheet, one per necessary view. Their 21 source labels link to exact independently reviewed text at verified immutable GitHub commits. Three small batches each passed fresh native-cell and stable-ID guards and readback. The final comparison covers 19,795 native cells and full sheet metadata, with zero unexpected differences and nothing pending.

All prior text remains verbatim. Numeric priorities, formulas, cell formats, notes, validation and existing links are unchanged. Only the new source-label spans receive hyperlink styling; the following historical text retains its original formatting. The three older rich-text repairs remain intact. The earlier 229-cell and 38-cell receipts remain separate and immutable. Edit counts from these overlapping updates are not counts of distinct research cells or discoveries.

## Frozen scientific scope

- Signed banks: b4(F23^2)=14 for the original N=11, q=13 dictionary with both effective cross-sign singleton nodes pinned to alpha=4 and arbitrary legal beta. Exact equality extends to even degrees d not divisible by 5. The prior base-field pinned minimum 16 remains valid. The quadratic review does not establish a d=3 value or unrestricted allocation optimum.
- Q29: independent bounded acceptance at t=27, p=5, e=3 of shared-center Newton data and integral degree-1686 normalization, with coefficient precision strictly below 40. The local discriminant lower bound is 4092. Disc R843 value/nonvanishing and full Q29 remain open.
- Later free-cross or other research is outside this frozen update and must receive a separate dated reconciliation.

## Evidence

APPLICATION_SUMMARY.json binds the precise request, source archives, immutable review URLs and full verification. REVIEWED_PROPOSAL.md lists the short notes by exact cell. REVIEWED_GUARDED_DELTA.json preserves complete before/after text, stable IDs and exact UTF-16 source-link spans. BATCH_* files preserve requests, guards, tool receipts and native before/after readbacks. BEFORE_* and FINAL_AFTER_* are lossless JSON DAG snapshots. FINAL_AFTER_VERIFICATION.json reports the full comparison.

The included newly authored scripts perform table-data checks only. No historical scientific program was executed by this task. No visual layout redesign was attempted or claimed. All evidence files are hashed in MANIFEST.json.
''')
files=sorted(p for p in P.iterdir() if p.is_file() and p.name not in ['MANIFEST.json','ORCHESTRATION_FUNCTIONS.json']);entries=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files];(P/'MANIFEST.json').write_text(json.dumps(entries,indent=2)+'\n')
dest=R/'Table_Quadratic_Q29_20_Cell_Applied_Verified_Receipt_2026-10-14.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[P/'MANIFEST.json']:z.write(p,p.name)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for e in entries:
  b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256']
seal={'archive':dest.name,'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size,'manifest_entries':len(entries),'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'APPLIED_AND_FULLY_VERIFIED','applied_text_cells':20,'source_link_spans':21,'pending_text_cells':0,'full_native_cells_compared':19795,'unexpected_native_differences':0,'summary_sha256':sha((P/'APPLICATION_SUMMARY.json').read_bytes()),'verification_sha256':sha((P/'FINAL_AFTER_VERIFICATION.json').read_bytes()),'source_bindings_sha256':sha((P/'REVIEWED_SOURCE_BINDINGS.json').read_bytes())};dest.with_suffix('.zip.seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
