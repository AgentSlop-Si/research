"""Validate the intended new rich-text source links without changing old styling."""
import copy
def check_runs(actual,requested):
 assert len(actual)==len(requested),(len(actual),len(requested))
 for a,r in zip(actual,requested):
  assert a.get('startIndex',0)==r.get('startIndex',0)
  af=a.get('format',{});rf=r.get('format',{})
  if not rf:assert not af,af
  else:
   assert af.get('link')==rf['link'],(af,rf)
   assert set(af)<=set(['link','foregroundColor','foregroundColorStyle','underline']),af
   assert af.get('underline',True) is True
   for color in [af.get('foregroundColor'),af.get('foregroundColorStyle',{}).get('rgbColor')]:
    if color:
     assert set(color)<=set(['red','green','blue','alpha'])
     assert abs(color.get('red',0)-17/255)<1e-6 and abs(color.get('green',0)-85/255)<1e-6 and abs(color.get('blue',0)-204/255)<1e-6,color
     assert color.get('alpha',1)==1
def expected_native_cell(before,write,actual):
 assert not before.get('textFormatRuns') and not before.get('hyperlink')
 check_runs(actual.get('textFormatRuns',[]),write['textFormatRuns'])
 links={r.get('format',{}).get('link',{}).get('uri') for r in write['textFormatRuns']};links.discard(None)
 if actual.get('hyperlink'):assert len(links)==1 and actual['hyperlink'] in links
 expected=copy.deepcopy(before);expected['userEnteredValue']=copy.deepcopy(write['userEnteredValue']);expected['textFormatRuns']=copy.deepcopy(actual['textFormatRuns'])
 if 'hyperlink' in actual:expected['hyperlink']=actual['hyperlink']
 if 'effectiveValue' in expected:expected['effectiveValue']=copy.deepcopy(write['userEnteredValue'])
 if 'formattedValue' in expected:expected['formattedValue']=write['userEnteredValue']['stringValue']
 return expected
