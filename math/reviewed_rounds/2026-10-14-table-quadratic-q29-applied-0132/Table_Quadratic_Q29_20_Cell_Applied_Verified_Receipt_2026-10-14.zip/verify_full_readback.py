"""Compare every native cell against this application's full prewrite snapshot."""
import json,pathlib,copy,hashlib,datetime
from check_source_runs import expected_native_cell
P=pathlib.Path(__file__).resolve().parent;Q=P.parent/'later_table_proposal_0117'
read=lambda p:json.loads(pathlib.Path(p).read_text())
def unpack(p):
 d=read(p);o=[]
 for t,n in d['nodes']:o.append(n if t==0 else [o[i] for i in n] if t==1 else {k:o[i] for k,i in n})
 return o[d['root']]
def flatten(docs):
 out={}
 for d in docs:
  for s in d['data']['sheets']:
   for b in s.get('data',[]):
    for ri,r in enumerate(b.get('rowData',[]),b.get('startRow',0)+1):
     for ci,c in enumerate(r.get('values',[]),b.get('startColumn',0)+1):out[s['properties']['title'],ri,ci]=c
 return out
bf=sorted(P.glob('BEFORE_??_PACKED.json'));af=sorted(P.glob('FINAL_AFTER_??_PACKED.json'));assert len(bf)==len(af)==17
before=flatten([unpack(p) for p in bf]);afterdocs=[unpack(p) for p in af];after=flatten(afterdocs)
expected={k:copy.deepcopy(v) for k,v in before.items()}
g=read(Q/'GUARDED_DELTA.json');changed=[]
for e in g['edits']:
 k=e['sheet'],e['row'],e['col'];assert e['before']==before[k]
 assert e['fields']=='userEnteredValue,textFormatRuns' and e['after_string'].endswith(before[k]['userEnteredValue']['stringValue'])
 expected[k]=expected_native_cell(before[k],e['write_cell'],after[k]);changed.append(k)
mismatches=[{'key':k,'expected':expected.get(k),'actual':after.get(k)} for k in set(expected)|set(after) if expected.get(k)!=after.get(k)]
metadata_equal=read(P/'BEFORE_METADATA.json')==read(P/'FINAL_AFTER_METADATA.json')
for e in g['stable_id_guards']:assert after[e['sheet'],e['row'],e['col']]['userEnteredValue']==e['before']
for i in range(len(read(P/'BATCH_PLAN.json'))):assert read(P/f'BATCH_{i:02d}_VERIFICATION.json')['status']=='PASS'
numeric_diffs=[k for k in set(before)|set(after) if (before.get(k,{}).get('userEnteredValue',{}).get('numberValue')!=after.get(k,{}).get('userEnteredValue',{}).get('numberValue'))]
formula_diffs=[k for k in set(before)|set(after) if (before.get(k,{}).get('userEnteredValue',{}).get('formulaValue')!=after.get(k,{}).get('userEnteredValue',{}).get('formulaValue'))]
link_keys=[('Research overview',r,9) for r in [252,307,308]]
links_unchanged=all(before[k]==after[k] for k in link_keys)
result={'status':'PASS' if not mismatches and metadata_equal else 'FAIL','completion':'COMPLETE_REVIEWED_QUADRATIC_Q29_20_CELL_DELTA','verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_started_at':min(d['started_at'] for d in afterdocs),'read_finished_at':max(d['finished_at'] for d in afterdocs),'all_native_cells_compared':len(after),'baseline_cells':len(before),'verified_applied_text_cells':len(changed),'pending_text_cells':0,'stable_id_guards_verified':len(g['stable_id_guards']),'batches_verified':len(read(P/'BATCH_PLAN.json')),'new_source_link_spans_verified':sum(len(e['source_link_segments']) for e in g['edits']),'spreadsheet_metadata_unchanged':metadata_equal,'unexpected_native_differences':len(mismatches),'all_old_text_preserved_verbatim':True,'numeric_cell_changes':numeric_diffs,'formula_changes':formula_diffs,'cell_formats_notes_validation_and_existing_links_preserved':not mismatches,'three_previous_rich_text_repairs_preserved':links_unchanged,'mismatches':mismatches}
(P/'FINAL_AFTER_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='mismatches'},indent=2));assert result['status']=='PASS' and links_unchanged and not numeric_diffs and not formula_diffs
