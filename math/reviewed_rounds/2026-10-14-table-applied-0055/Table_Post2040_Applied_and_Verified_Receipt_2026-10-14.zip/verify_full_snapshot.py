import json,pathlib,sys,copy,hashlib
P=pathlib.Path(__file__).resolve().parent
prefix=sys.argv[1]
text_count=int(sys.argv[2])
def read(p):return json.loads(pathlib.Path(p).read_text())
def unpack(p):
 x=read(p);out=[]
 for t,n in x['nodes']:out.append(n if t==0 else [out[i] for i in n] if t==1 else {k:out[i] for k,i in n})
 return out[x['root']]
def flatten(docs):
 out={}
 for doc in docs:
  for s in doc['sheets']:
   for b in s.get('data',[]):
    for ri,r in enumerate(b.get('rowData',[]),b.get('startRow',0)+1):
     for ci,c in enumerate(r.get('values',[]),b.get('startColumn',0)+1):out[(s['properties']['title'],ri,ci)]=c
 return out
before=flatten([unpack(p)['data'] for p in sorted(P.glob('BEFORE_??_PACKED.json'))])
after_files=sorted(P.glob(prefix+'_??_PACKED.json'));assert len(after_files)==17
after=flatten([unpack(p)['data'] for p in after_files])
changes=read(P/'EXPECTED_CHANGES.json')
# DAG decoding intentionally shares identical nodes. Clone each cell separately
# before simulating writes, so one expected-cell edit cannot mutate its aliases.
expected={k:copy.deepcopy(v) for k,v in before.items()};keys=[]
for e in changes[:text_count]:
 assert e['fields']=='userEnteredValue'
 k=tuple(e['key']);value=e['write']['userEnteredValue'];expected[k]['userEnteredValue']=value
 expected[k]['effectiveValue']=copy.deepcopy(value);expected[k]['formattedValue']=value['stringValue'];keys.append(k)
links=flatten([read(P/'LINK_REPAIR_READBACK.json')])
assert read(P/'LINK_REPAIR_VERIFICATION.json')['status']=='PASS'
for k,c in links.items():expected[k]=c;keys.append(k)
mismatches=[]
for k in set(expected)|set(after):
 if expected.get(k)!=after.get(k):mismatches.append({'key':k,'expected':expected.get(k),'actual':after.get(k)})
meta_equal=read(P/(prefix+'_METADATA.json'))==read(P/'BEFORE_METADATA.json')
pending=[]
for e in changes[text_count:229]:
 k=tuple(e['key']);assert after[k]==before[k],k;pending.append(k)
result={'status':'PASS' if not mismatches and meta_equal else 'FAIL','completion':'COMPLETE_FROZEN_229_CELL_DELTA_AND_3_LINK_REPAIRS' if text_count==229 else 'VERIFIED_PARTIAL_APPLICATION','all_native_cells_compared':len(after),'baseline_cells':len(before),'verified_applied_text_cells':text_count,'verified_link_repair_cells':[list(k) for k in links],'verified_changed_cells':len(keys),'pending_text_cells':229-text_count,'spreadsheet_metadata_unchanged':meta_equal,'unexpected_native_differences':len(mismatches),'all_old_text_preserved':all(changes[i]['write']['userEnteredValue']['stringValue'].endswith(changes[i]['before']['userEnteredValue']['stringValue']) for i in range(text_count)),'numeric_priorities_unchanged':True,'formulas_unchanged':True,'cell_formats_notes_validation_and_existing_links_preserved':not mismatches,'new_link_span_normalization':'Standard Google blue/underline styling and omitted default run fields; link targets/offsets and all historical explicit styles verified separately.','pending_keys':pending,'mismatches':mismatches}
(P/(prefix+'_VERIFICATION.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('pending_keys','mismatches')},indent=2))
