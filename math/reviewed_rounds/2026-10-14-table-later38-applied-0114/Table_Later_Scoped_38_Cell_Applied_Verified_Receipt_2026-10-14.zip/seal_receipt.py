import json,pathlib,hashlib,zipfile,datetime,shutil
P=pathlib.Path(__file__).resolve().parent;R=P.parent;Q=R/'later_table_proposal_0055';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(pathlib.Path(p).read_text())
ver=read(P/'FINAL_AFTER_VERIFICATION.json');assert ver['status']=='PASS'
for name in ['SOURCE_BINDINGS.json','GUARDED_DELTA.json','EXACT_REQUEST.json','VIEW_BINDINGS.json','PROPOSAL.md','VALIDATION.json']:
 shutil.copyfile(Q/name,P/('REVIEWED_'+name))
summary={'status':'APPLIED_AND_FULLY_VERIFIED','spreadsheet_id':'1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU','spreadsheet_url':'https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit','scope':'Separate later 2026-10-14 update; earlier 229-cell checkpoint remains immutable','applied_text_cells':38,'pending_text_cells':0,'stable_id_guards':24,'full_native_cells_compared':19795,'unexpected_native_differences':0,'prior_three_link_repairs_preserved':True,'numeric_scores_formulas_styles_history_links_preserved':True,'batches':8,'new_cancellations':0,'new_denials':0,'source_acceptances':read(Q/'SOURCE_BINDINGS.json'),'reviewed_proposal_zip_sha256':'eaaa048dcb4b9edc538d83038c9e7944eb7fdec40c29306269ba7986e0062591','reviewed_request_sha256':sha((Q/'EXACT_REQUEST.json').read_bytes()),'reviewed_delta_sha256':sha((Q/'GUARDED_DELTA.json').read_bytes()),'full_verification_sha256':sha((P/'FINAL_AFTER_VERIFICATION.json').read_bytes()),'completion_verified_at':ver['verified_at'],'scientific_limits':['Q16 independent bounded-reference regression only; production provenance/API and full outer execution remain open.','H16 conditional lift only; required exact <=31-forward-H2 word is absent, and ALG-074 h23/h25 source HOLD remains separate.','Signed banks: b4(F23)=16 only at N=11, q=13, original legal grammar and both effective cross-sign singleton alphas fixed at 4; arbitrary legal beta allowed. Broader free-singleton/uniform parent and other fields are not closed.','No new score, novelty, unrestricted optimum or general FFT claim.']}
(P/'APPLICATION_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(P/'README.md').write_text('''# Later scoped table update: applied and verified

14 October 2026. The existing research spreadsheet received 38 reviewed, dated text updates. Eight small batches each passed fresh native-cell and stable-ID guards, then exact readback. The final full comparison covers 19,795 native cells and sheet metadata, with zero unexpected differences and nothing pending.

All previous text remains verbatim. Numeric scores, formulas, styles, notes, validation and links are unchanged. The three earlier rich-text repairs remain intact. No new row or spreadsheet was created. The earlier 229-cell update and its receipt are separate frozen records; these counts must not be added as a count of distinct cells.

## Scientific scope

- Q16: independently accepted three-coefficient bounded reference regression, with 9,123 incidences and 11,015 independent checks. Production integration and full outer execution remain open.
- H16: independently accepted conditional DFT lift, assuming an admitted exact word with at most 31 forward H2 calls on exactly 16 independent inputs. The word is absent. The separate ALG-074 h23/h25 source HOLD remains.
- Signed banks: exact pinned F23 minimum 16 accepted for N=11, q=13 and both effective cross-sign singleton alphas 4 in the original legal grammar. The unrestricted and uniform parents remain open.

## Evidence

APPLICATION_SUMMARY.json identifies the exact reviewed request, source seals and verification. REVIEWED_PROPOSAL.md gives the short notes by exact cell. REVIEWED_GUARDED_DELTA.json preserves each full before/after text and exact stable-ID binding. BATCH_* files preserve requests, native before/after cells, tool receipts and checks. BEFORE_* and FINAL_AFTER_* are lossless JSON DAG snapshots of the full bounded native sheet state. FINAL_AFTER_VERIFICATION.json reports the complete comparison.

The newly authored scripts perform table-data auditing only. No historical scientific program was executed by this application task. The source review archives are bound by SHA-256 and are not duplicated here. All files are hashed in MANIFEST.json.
''')
files=sorted(p for p in P.iterdir() if p.is_file() and p.name!='MANIFEST.json');entries=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files];(P/'MANIFEST.json').write_text(json.dumps(entries,indent=2)+'\n')
dest=R/'Table_Later_Scoped_38_Cell_Applied_Verified_Receipt_2026-10-14.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[P/'MANIFEST.json']:z.write(p,p.name)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for e in entries:
  b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256']
seal={'archive':dest.name,'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size,'manifest_entries':len(entries),'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'APPLIED_AND_FULLY_VERIFIED','applied_text_cells':38,'pending_text_cells':0,'full_native_cells_compared':19795,'unexpected_native_differences':0,'summary_sha256':sha((P/'APPLICATION_SUMMARY.json').read_bytes()),'verification_sha256':sha((P/'FINAL_AFTER_VERIFICATION.json').read_bytes()),'source_bindings_sha256':sha((P/'REVIEWED_SOURCE_BINDINGS.json').read_bytes())};dest.with_suffix('.zip.seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
