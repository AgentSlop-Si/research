# Small later scoped table proposal

Not applied. No scientific programs executed. All old strings are preserved once; only short new dated notes are prefixed. No new history copy, row, ID, score, formula or cell-format change is proposed.

{
  "status": "PREPARED_NOT_APPLIED",
  "cells": 38,
  "new_note_characters": 12840,
  "maximum_note_characters": 445,
  "stable_id_guards": 24,
  "numeric_changes": 0,
  "formula_changes": 0,
  "style_changes": 0,
  "old_strings_preserved_verbatim": true,
  "existing_rich_text_preserved_cells": 0,
  "source_keys": [
    "Q16_REFERENCE",
    "H16_CONDITIONAL",
    "SIGNED_ATTAINMENT"
  ],
  "bank_attainment_state": "SEALED_ACCEPTANCE_INCLUDED_AT_EXACT_SCOPE",
  "requires_parent_scope_review": true
}

H16 mapping: Catalogue!A179 is ALG-074; Catalogue!X179 explicitly discusses the fixed width 16/32-call butterfly and arbitrary 31-call H16 words. Novelty!C218 and overview!B306 are exact ALG-074 aliases. The separate h23/h25 HOLD is preserved.

## 'Research queue'!E19 (Q16)

[2026-10-14; later scoped review] Independent reference-only ACCEPT: 3 selected coefficients at D=5,m=57 meet eta=2^-456; all 9,123 incidences match. The 11,015-check review reproduces result bytes exactly. Production API/provenance, full stream/scatter, accumulation, scale-back and all-length dispatch remain open.

## 'Research queue'!F19 (Q16)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research queue'!L19 (Q16)

[2026-10-14; later scoped review] Q16 reference review: Q16_Bounded_Reference_Regression_Independent_ACCEPT_2026-10-14.zip; ZIP SHA256 12a83cdc49a1e3d7e8dde76b78d9a48352419a3cceb0908d61c28fc907b65279; REVIEW.md SHA256 eb87ae39422797e4d2b9d30c59306aba6013a5fca1e057ca82ba0c0a7bef0073. Independent acceptance is bounded-reference only.

## 'Next cycle'!K4 (STR-Q1)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Fusion list'!F15 (FUS-09)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Theorem register'!G31 (F016)

[2026-10-14; later scoped review] Related Q16 dependency; Gaussian/Green theorem unchanged. Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Catalogue'!AE5 (F016)

[2026-10-14; later scoped review] Related Q16 dependency; Gaussian/Green theorem unchanged. Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'novelity breakthough'!Y6 (F016)

[2026-10-14; later scoped review] Related Q16 dependency; Gaussian/Green theorem unchanged. Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!C5 (STR-Q1)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!P5 (STR-Q1)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!C6 (F016)

[2026-10-14; later scoped review] Related Q16 dependency. Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!P6 (F016)

[2026-10-14; later scoped review] Related Q16 dependency. Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!C7 (FUS-09)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!P7 (FUS-09)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!C8 (Q16)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Research overview'!P8 (Q16)

[2026-10-14; later scoped review] Q16 static/reference gate complete: independent bounded-reference ACCEPT (3 coefficients; 9,123 incidences). Next is a source-pinned production wrapper/sparse-output binding and bounded real-API replay. Full outer/all-length execution stays open; score unchanged.

## 'Catalogue'!AC179 (ALG-074)

[2026-10-14; later scoped review] H16 conditional lift independently ACCEPTED: an admitted exact word for the four-fold tensor power of H2 on exactly 16 independent inputs, using <=31 forward H2 calls and invertible monomials, implies O(n(log n)^.995(log log n)^3.005), hence eventual O(n(log n)^.997), in the specified-root exact-complex charged model. The required word is absent. ALG-074 review_missing and its separate h23/h25 HOLD remain.

## 'Catalogue'!Y179 (ALG-074)

[2026-10-14; later scoped review] Separate H16 conditional review: H16_Conditional_DFT_Lift_Independent_ACCEPT_2026-10-14.zip; ZIP SHA256 cdcae615f8a63ecd859540ed6b1ca60276fbd4093848b77ec60624ea90e85a64; review SHA256 384ce273a39d15a8ef1172b9ca2c64d293c119922262c2c7a8200126fb0bb5b1. Bound via this row's explicit width 16/fixed 32-call/H16 subcase, not acronym similarity; no actual <=31-call word is supplied.

## 'novelity breakthough'!W218 (ALG-074)

[2026-10-14; later scoped review] H16 sub-result only: the <=31-call, exactly 16-register hypothesis now has an independently accepted conditional DFT lift. The actual word and end-to-end implementation remain absent. This does not resolve ALG-074 whole-record review_missing or its separate h23/h25 source HOLD; score unchanged.

## 'Research overview'!G306 (ALG-074)

[2026-10-14; later scoped review] H16 sub-result only: the <=31-call, exactly 16-register hypothesis now has an independently accepted conditional DFT lift. The actual word and end-to-end implementation remain absent. This does not resolve ALG-074 whole-record review_missing or its separate h23/h25 source HOLD; score unchanged.

## 'Catalogue'!AC10 (M-MAGNETIC-SPAN)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research queue'!F38 (Q35)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Next cycle'!K10 (NEXT-MAGNETIC-SIGNED)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'New results'!D20 (NEW-17)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'novelity breakthough'!Y8 (NEW-17)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'novelity breakthough'!Y9 (M-MAGNETIC-SPAN)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'novelity breakthough'!Y10 (Q35)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Catalogue'!AE10 (M-MAGNETIC-SPAN)

[2026-10-14; later scoped review] Do not redispatch pinned N=11, q=13, F23, cross-singleton alpha=4 attainment: exact minimum 16 is accepted. Broader free-singleton/uniform bank work remains open; no FFT speed or novelty conclusion.

## 'Research queue'!L38 (Q35)

[2026-10-14; later scoped review] Pinned 16 attainment review: Signed_Bank_Pinned_F23_Exact_Sixteen_Independent_ACCEPT_2026-10-14.zip; ZIP SHA256 78066876770ace551f023ede4a759910c73f0c7c0dd35e28d80091ca5f464052; review SHA256 f3980c0256783e69d20b73f9d8968716ea636aeb54214f03fab3f486ea49c1d5.

## 'Research overview'!C10 (M-MAGNETIC-SPAN)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research overview'!P10 (M-MAGNETIC-SPAN)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research overview'!C11 (NEW-17)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research overview'!P11 (NEW-17)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research overview'!C12 (Q35)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research overview'!P12 (Q35)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research overview'!C13 (NEXT-MAGNETIC-SIGNED)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Research overview'!P13 (NEXT-MAGNETIC-SIGNED)

[2026-10-14; later scoped review] Pinned F23 subcase complete: b4(F23)=16 is independently accepted for N=11, q=13, original legal banks (arbitrary legal beta), both effective cross-sign singleton alphas 4. The attained (7,1,1,7) witness matches the accepted lower bound. The free-singleton/uniform parent and other fields remain separate; score unchanged.

## 'Progress'!A1 (None)

[2026-10-14; later scoped review] Later scoped reviews: Q16 bounded reference independently accepted; production integration remains open. H16 conditional lift accepted; its required <=31-call word remains absent. Scores and broader parent statuses are unchanged. Pinned N=11, q=13, F23 bank minimum 16 is now accepted; unpinned/uniform bank work remains open.

