ALG 068 complete small marker schedule independent acceptance

Verdict: scoped ACCEPT. Read REVIEW.txt for the accepted theorem, exact paid ledger, boundary cases, and local-linear rank restriction. The unchanged submitted candidate archive is included under candidate/ and bound by PROVENANCE.json.

The evidence programs are newly authored review controls, not candidate or historical programs. independent_controls.py runs with only Python's standard library and one output-path argument. negative_controls.py imports only that fresh review program. CONTROLS.json and REPLAY_CONTROLS.json are byte-identical; NEGATIVE_CONTROLS.json records explicit loss/horizon witnesses.

This is a private research evidence packet. It establishes Theta(Nn) for one fully paid schedule and excludes one local scalar linear-payload compression premise. It establishes no faster transform and no general FFT or arithmetic lower bound. No external Sheet, score, or repository changes were made.
