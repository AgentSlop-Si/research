#!/usr/bin/env python3
"""Negative and horizon controls; imports only this review's freshly authored code."""
import json
from pathlib import Path
from independent_controls import Graph, root, rank_mod, require

out={}
g=Graph(5,2,97,root(5,97))
cols=[]
for original_state in (0,16):
 x=[0]*g.N; x[original_state]=1
 col=[]
 for t in range(2):
  x=g.gather(x); col.append(x[1])
 cols.append(col)
m=[list(row) for row in zip(*cols)]
det=(m[0][0]*m[1][1]-m[0][1]*m[1][0])%97
require(m==[[1,96],[1,1]] and det==2,'concrete two-column witness')
out['candidate_two_source_example']={'n':5,'b':2,'p':97,'original_states':[0,16],'local_payload_matrix':m,'determinant':det,'rank':rank_mod(m,97)}
# A chosen one-scalar time-0 summary loses the second lambda input entirely.
g=Graph(6,3,257,root(6,257))
label=1 << (g.L-2)
x=[0]*g.N; x[label << g.b]=1
payload=[]
for t in range(g.b):
 x=g.gather(x); payload.append(x[1])
require(payload==[0,256,1],'time-zero loss witness')
out['one_scalar_time_zero_summary_fails']={'n':6,'b':3,'p':257,'original_state':label<<g.b,'time_zero_summary':payload[0],'full_payload':payload,'zero_source_full_payload':[0,0,0],'return_times':[4,5,6]}
# Direct path support inside the horizon is distinct from output-rank claims.
paths=[]
for n,b in [(2,1),(4,2),(6,3),(10,5),(17,3)]:
 for t in range(b):
  states=[1]
  for j in range(b): states.append((2*states[-1])%(1<<n))
  require(states[-1]==1<<b and t+b+1<=n,'in-horizon zero tail')
  paths.append({'n':n,'b':b,'time_label':t,'states':states,'start_time':t+1,'retained_return_time':t+b+1})
out['in_horizon_zero_edge_paths']=paths
out['rejected_extrapolations']=[
 'A k-scalar linear summary has rank at most k only when it alone, with fixed metadata, supports linear reconstruction; rereading original inputs or injecting new independent information is outside that premise.',
 'The local payload rank is not a rank lower bound for selected external outputs or an operation lower bound for another transform algorithm.',
 'The b-value certificate uses b<=L and 2b<=n; it is not asserted outside those restrictions.',
 'The exact n+1 visit lower count applies to the stated unconditional bucket schedule, not to arbitrary algorithms or compressed interfaces.'
]
Path(__file__).with_name('NEGATIVE_CONTROLS.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','explicit_witnesses':2,'finite_horizon_paths':len(paths)}))
