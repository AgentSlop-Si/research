#!/usr/bin/env python3
"""Fresh exact controls for the complete small-marker schedule, 2026-10-13.
Only standard-library imports. No candidate/historical code is loaded.
The oracle propagates Q by destination-pair gather; the schedule uses edges.
"""
import json
import sys
from collections import Counter
from pathlib import Path


def require(ok, label):
    if not ok:
        raise AssertionError(label)


def b_frozen(n):
    b, cap = 1, 4
    while cap < n:
        b, cap = b + 1, cap * 4
    return b


def is_prime(p):
    if p < 2: return False
    d = 2
    while d*d <= p:
        if p % d == 0: return p == d
        d += 1
    return True


def root(n, p):
    N = 1 << n
    require(is_prime(p) and (p-1) % N == 0, ('field', n, p))
    a = 2
    while True:
        w = pow(a, (p-1)//N, p)
        if pow(w, N, p) == 1 and pow(w, N//2, p) != 1: return w
        a += 1


def rank_mod(mat, p):
    a = [row[:] for row in mat]
    nr = len(a)
    nc = len(a[0]) if nr else 0
    r = 0
    for c in range(nc):
        pivot = next((k for k in range(r, nr) if a[k][c] % p), None)
        if pivot is None: continue
        a[r], a[pivot] = a[pivot], a[r]
        q = pow(a[r][c], p-2, p)
        a[r] = [(v*q) % p for v in a[r]]
        for k in range(nr):
            if k != r:
                q = a[k][c]
                a[k] = [(x-q*y) % p for x,y in zip(a[k],a[r])]
        r += 1
        if r == nr: break
    return r


class Graph:
    def __init__(self, n, b, p, w):
        require(n >= 2 and 1 <= b and 2*b <= n, 'domain')
        self.n, self.b, self.p, self.w = n,b,p,w
        self.N, self.L = 1 << n, n-b
        N,L = self.N,self.L
        self.r, self.h, self.ell, self.q = 1 << L, L+1, L+2, b-2
        self.R, self.A, self.F = [], [], []
        self.grade, self.tau, self.kind = {}, {}, ['']*N
        self.buckets = [[] for _ in range(L+1)]
        self.wp = [1]*N
        for s in range(1,N): self.wp[s] = self.wp[s-1]*w % p
        require(self.wp[N//2] == p-1 and self.wp[-1]*w % p == 1, 'root order')
        mask = (1 << b)-1
        for s in range(N):
            # Numerical bit windows; positions count from the left.
            starts = [k for k in range(L+1) if (s >> (L-k)) & mask == 0]
            if s & mask == 0:
                self.R.append(s); self.kind[s] = 'R'
            elif not starts:
                self.A.append(s); self.kind[s] = 'A'
            else:
                a = L-starts[-1]
                self.F.append(s); self.kind[s] = 'F'
                self.grade[s] = a; self.buckets[a].append(s)
            if self.kind[s] != 'F': self.tau[s] = L-starts[-2] if len(starts)>1 else L+1
        self.ri = {s:i for i,s in enumerate(self.R)}
        self.T = self.R+self.A
        self.exits = {}
        for s in self.F:
            for y,_ in self.edges(s):
                if self.kind[y]=='F': require(self.grade[y] == self.grade[s]+1,'free grade')
                else:
                    require(self.tau[y] == self.grade[s]+1,'row delay')
                    self.exits[y] = self.grade[s]
        for s in self.A: require(all(self.kind[y] != 'F' for y,_ in self.edges(s)), 'A cannot enter F')
        for s in self.R:
            y = (2*s+1) % N
            require(self.kind[y]=='F' and self.grade[y]==1,'R entry grade')
        self.W = sum(self.grade.values())
        self.V = sum(n-a+1 for a in self.grade.values())
        self.U = sum(max(0,self.q-a+1) for a in self.grade.values())
        require(self.W+self.V == (n+1)*len(self.F),'symbolic visit total')
        self.source_slots = len(self.T)+sum(self.exits.values())
        require(self.source_slots == N+L*len(self.buckets[L]) <= 2*N,'coalesced source slots')

    def edges(self,s):
        return ((2*s % self.N,1),((2*s+1) % self.N,self.wp[s]))

    def gather(self,x):
        # Independent destination-row formula obtained from the two paired predecessors.
        half=self.N//2
        y=[0]*self.N
        for a in range(half):
            y[2*a]=(x[a]+x[a+half]) % self.p
            y[2*a+1]=self.wp[a]*(x[a]-x[a+half]) % self.p
        return y

    def source(self,x):
        f = {s:[x[s]]+[0]*self.exits.get(s,0) for s in self.T}
        cur = {s:x[s] for s in self.F}
        visits=Counter()
        for j in range(self.L):
            nxt={s:0 for a in range(j+2,self.L+1) for s in self.buckets[a]}
            for a in range(j+1,self.L+1):
                for s in self.buckets[a]:
                    visits[s]+=1
                    z=cur[s]
                    for y,weight in self.edges(s):
                        if self.kind[y]=='F': nxt[y]=(nxt[y]+weight*z)%self.p
                        else: f[y][j+1]=(f[y][j+1]+weight*z)%self.p
            cur=nxt
        require(sum(visits.values())==self.W and all(visits[s]==self.grade[s] for s in self.F),'source exact visits')
        return f,visits

    def source_gather_oracle(self,x,f):
        cur=[x[s] if self.kind[s]=='F' else 0 for s in range(self.N)]
        checked=0
        for j in range(1,self.n+1):
            y=self.gather(cur)
            for s in self.T:
                wanted=f[s][j] if j<len(f[s]) else 0
                require(y[s]==wanted,('source coefficient',s,j))
                checked+=1
            cur=[y[s] if self.kind[s]=='F' else 0 for s in range(self.N)]
        return checked

    def solve(self,x,check_source):
        f,src_visits=self.source(x)
        source_checks=self.source_gather_oracle(x,f) if check_source else 0
        n,b,r,p=self.n,self.b,self.r,self.p
        pending=[]
        a_prev={s:0 for s in self.A}
        for t in range(n+1):
            g=[f[s][t] if t<len(f[s]) else 0 for s in self.R]
            a_now={s:f[s][t] if t<len(f[s]) else 0 for s in self.A}
            for s,z in a_prev.items():
                for y,weight in self.edges(s):
                    if self.kind[y]=='A': a_now[y]=(a_now[y]+weight*z)%p
                    else: g[self.ri[y]]=(g[self.ri[y]]+weight*z)%p
            pending.append(g)
            a_prev=a_now
        a0_n=a_prev
        g_original=[row[:] for row in pending]
        u=[]
        base={s:0 for s in self.F}
        visits=Counter()
        v_prev={s:0 for s in self.A}
        short=[]
        for t in range(n+1):
            u_t=pending[t][:]
            u.append(u_t)
            if t==n: break
            k=min(self.L,n-t)
            acc={s:0 for a in range(1,k+1) for s in self.buckets[a]}
            Eu={s:0 for s in self.A} if t<b else None
            for s,z in zip(self.R,u_t):
                yz,yo=self.edges(s)
                pending[t+1][self.ri[yz[0]]] = (pending[t+1][self.ri[yz[0]]]+z)%p
                acc[yo[0]]=(acc[yo[0]]+yo[1]*z)%p
            for a in range(1,k+1):
                for s in self.buckets[a]:
                    visits[s]+=1
                    z=acc[s]
                    if t+a==n: base[s]=z
                    for y,weight in self.edges(s):
                        if self.kind[y]=='F':
                            if self.grade[y]<=k: acc[y]=(acc[y]+weight*z)%p
                        elif self.kind[y]=='R':
                            if t+self.tau[y]<=n:
                                target=pending[t+self.tau[y]]
                                target[self.ri[y]]=(target[self.ri[y]]+weight*z)%p
                        elif Eu is not None:
                            require(k==self.L and t+self.h<=n,'early E complete')
                            Eu[y]=(Eu[y]+weight*z)%p
            if Eu is not None:
                v=Eu
                for s,z in v_prev.items():
                    for y,weight in self.edges(s):
                        if self.kind[y]=='A': v[y]=(v[y]+weight*z)%p
                if t<=self.q:
                    wt=[0]*r
                    for s,z in v.items():
                        for y,weight in self.edges(s):
                            if self.kind[y]=='R': wt[self.ri[y]]=(wt[self.ri[y]]+weight*z)%p
                    if short:
                        for i,z in enumerate(short[-1]): wt[2*i%r]=(wt[2*i%r]+z)%p
                    short.append(wt)
                v_prev=v
        require(sum(visits.values())==self.V,'inverse visit total')
        require(all(visits[s]==n-self.grade[s]+1 and visits[s]+src_visits[s]==n+1 for s in self.F),'each free state n+1 visits')
        core=[row[:] for row in u]
        for t,wt in enumerate(short):
            core[self.ell+t]=[(a+z)%p for a,z in zip(core[self.ell+t],wt)]
        base_before_correction=base.copy()
        corr_visits=Counter()
        for t in range(max(0,self.q)):
            k=self.q-t
            acc={s:0 for a in range(1,k+1) for s in self.buckets[a]}
            for s,z in zip(self.R,short[t]):
                y,weight=self.edges(s)[1]
                acc[y]=(acc[y]+weight*z)%p
            for a in range(1,k+1):
                for s in self.buckets[a]:
                    corr_visits[s]+=1
                    z=acc[s]
                    if a==k: base[s]=(base[s]+z)%p
                    for y,weight in self.edges(s):
                        if self.kind[y]=='F' and self.grade[y]<=k: acc[y]=(acc[y]+weight*z)%p
        require(sum(corr_visits.values())==self.U and all(corr_visits[s]==max(0,self.q-self.grade[s]+1) for s in self.F),'correction F visits')
        out=[0]*self.N
        for s,z in zip(self.R,core[n]): out[s]=z
        for s,z in base.items(): out[s]=z
        for s in self.A: out[s]=(a0_n[s]+v_prev[s])%p
        # Independent first-H_R oracle: forced Q restricted to R union F.
        state=[0]*self.N
        first_checks=0
        for t in range(n+1):
            if t: state=self.gather(state)
            for s in self.A: state[s]=0
            for s,z in zip(self.R,g_original[t]): state[s]=(state[s]+z)%p
            require([state[s] for s in self.R]==u[t],('first inverse oracle',t))
            first_checks+=r
        # Direct Q trajectory and full corrected R-jet oracle.
        state=x[:]
        jet_checks=0
        for t in range(n+1):
            require([state[s] for s in self.R]==core[t],('corrected R jet',t))
            jet_checks+=r
            if t<n: state=self.gather(state)
        require(out==state,'all selected external outputs')
        return out, {'source_coefficients':source_checks,'first_inverse_coefficients':first_checks,'corrected_R_coefficients':jet_checks,'selected_outputs':self.N,'F_correction_changed_outputs':sum(base[s]!=base_before_correction[s] for s in self.F),'R_correction_changed_outputs':sum(a!=b for a,b in zip(core[n],u[n]))}

    def payload_certificate(self):
        # Read grade-one payloads directly from original-source Q trajectories.
        columns=[]
        labels=[1 << (self.L-k-1) for k in range(self.b)]
        for label in labels:
            x=[0]*self.N
            x[label << self.b]=1
            col=[]
            for t in range(self.b):
                x=self.gather(x)
                col.append(x[1])
            columns.append(col)
        mat=[list(row) for row in zip(*columns)]
        expected=[[(self.p-1 if t==k else 1 if k<t else 0) for k in range(self.b)] for t in range(self.b)]
        require(mat==expected and rank_mod(mat,self.p)==self.b,'original-source rank-b')
        for t in range(self.b):
            s=1
            for step in range(self.b):
                require(self.kind[s]=='F','witness path remains free')
                s=(2*s)%self.N
            require(self.kind[s]=='R' and t+self.b+1<=self.n,'witness finite horizon')
        return {'rank':self.b,'labels':labels,'matrix':mat,'return_state':1 << self.b,'return_times':list(range(self.b+1,2*self.b+1))}

    def fourier(self,x,out):
        for v in range(self.N):
            bits=[(v >> (self.n-1-i)) & 1 for i in range(self.n)]
            rev=sum(bit << i for i,bit in enumerate(bits))
            gamma,prefix=0,0
            for bit in bits:
                if bit: gamma+=prefix
                prefix=2*prefix+bit
            actual=sum(z*self.wp[(s*rev)%self.N] for s,z in enumerate(x))%self.p
            require(out[v]==self.wp[gamma%self.N]*actual%self.p,'DFT sign phase reversal')
        return self.N


def symbolic_census(n):
    b=b_frozen(n); L=n-b; N=1<<n
    avoid=[1]
    for k in range(1,n+1):
        avoid.append((1<<k) if k<b else sum(avoid[max(0,k-b):k]))
    fs=[(1 << (L-a))*avoid[a-1] for a in range(1,L+1)]
    W=sum(a*f for a,f in enumerate(fs,1))
    V=sum((n-a+1)*f for a,f in enumerate(fs,1))
    F=sum(fs); R=1<<L; A=avoid[n]
    require(R+A+F==N,'symbolic partition')
    require(W+V==(n+1)*F,'symbolic complete census')
    require(W<=N*((1<<(b+1))-b-2),'W upper')
    require(W*32>=N*(1<<b),'W lower')
    return {'n':n,'b':b,'L':L,'N':N,'R':R,'A':A,'F':F,'W':W,'V':V,'W_plus_V':W+V}


def main(path):
    cases=[]
    for p,nmax in [(5,2),(17,4),(97,5),(257,8),(65537,10)]:
        for n in range(2,nmax+1):
            w=root(n,p)
            for b in range(1,n//2+1): cases.append((n,b,p,w))
            cases.append((n,b_frozen(n),p,pow(w,p-2,p)))
    # The first frozen b=3 case activates the otherwise-empty F correction.
    for n in (16,17): cases.append((n,b_frozen(n),998244353,root(n,998244353)))
    totals=Counter(); results=[]
    for n,b,p,w in cases:
        g=Graph(n,b,p,w)
        sources=[]
        if n<=5:
            for s in range(g.N):
                x=[0]*g.N; x[s]=1; sources.append(x)
        elif n<=10:
            for s in sorted(set([0,1,2,g.N//2,g.N-1]+[a[0] for a in g.buckets if a])):
                x=[0]*g.N; x[s]=1; sources.append(x)
        sources.append([(s*s*13+7*s+3)%p for s in range(g.N)])
        if n<=10: sources.append([((s*37)^(s>>2)^91)%p for s in range(g.N)])
        counts=Counter()
        for i,x in enumerate(sources):
            out,c=g.solve(x,check_source=(n<=8 or i==len(sources)-1))
            counts.update(c)
            if n<=5 and i==len(sources)-1: counts['DFT_outputs']+=g.fourier(x,out)
        counts['sources']=len(sources)
        cert=g.payload_certificate()
        totals.update(counts)
        totals['cases']+=1
        totals['rank_certificates']+=1
        results.append({'n':n,'b':b,'p':p,'omega':w,'frozen':b==b_frozen(n),'N':g.N,'R':g.r,'A':len(g.A),'F':len(g.F),'W':g.W,'V':g.V,'U':g.U,'source_slots':g.source_slots,'counts':dict(counts),'payload_certificate':cert})
    # Integer-only parameter boundaries and theorem-ledger checks beyond feasible graphs.
    for n in range(2,20001):
        b=b_frozen(n)
        require(2*b<=n and n-b >= 1<<(b-1),'frozen domain and W regime')
        require((1<<(2*b))>=n and (1<<(2*b-2))<n,'sqrt bracketing')
    symbolic=[symbolic_census(n) for n in [2,3,4,5,6,8,16,17,32,64,65,128,256,257,512,1024]]
    report={'status':'PASS','date_utc':'2026-10-13','independence':'Fresh script; no candidate or historical program executed or imported. Exact prime-field gather oracles differ from edge-scatter schedule.','totals':dict(totals),'cases':results,'symbolic_censuses':symbolic,'integer_parameter_checks':19999,'scope':'Specific paid schedule and local linear payload rank only. No general FFT/arithmetic lower bound.'}
    Path(path).write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':'PASS','totals':dict(totals),'output':path},sort_keys=True))

if __name__=='__main__': main(sys.argv[1])
