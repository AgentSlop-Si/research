"""New, read-only byte/roster verifier. Does not execute any archived research."""
import json, hashlib
from pathlib import Path

P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read('MANIFEST.json')
for entry in manifest['files']:
    p=P/entry['path']
    assert p.is_file() and p.stat().st_size==entry['bytes']
    assert digest(p)==entry['sha256']
sel=read('SELECTED_BASE_GROUPS.json')
remaining=read('FULL_REMAINING_125_ROSTER.json')
assert sel==remaining[100:125]
assert len(sel)==25 and len({x['obligation_group'] for x in sel})==25
assert len({i for x in sel for i in x['record_ids']})==25
groups=read('SOURCE_READINESS_25_GROUPS.json')['groups']
assert [g['obligation_group'] for g in groups]==[g['obligation_group'] for g in sel]
assert sum(g['source_readiness']=='NEEDS_SCOPE_SELECTION' for g in groups)==19
assert sum(g['source_readiness']=='SOURCE_BLOCKED' for g in groups)==6
assert all(g['source_readiness']!='READY' for g in groups)
for c in read('SOURCE_BYTE_CHECKS.json'):
    assert c['bound_hash_match'] and digest(P/c['file'])==c['sha256']
assert read('LIVE_BASELINE_COMPARISON.json')['all_match']
print(json.dumps({'status':'PASS','manifest_payloads':len(manifest['files']),'groups':25,'stable_ids':25,'source_readiness_only':True}))
