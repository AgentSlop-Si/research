# Exact FFT research: generic-data compression gate

**Date:** 13 October 2026  
**Mission:** a genuinely new all-input, all-output, fully charged exact `O(N)` algorithm, or at least `o(N log log N)`; not faster implementations of `Theta(N log N)` circuits.  
**Status:** a complete negative theorem for broad adaptive sparse-filter fusion, a project-specific multistage Weyl extension, and exact modular tests. **No unrestricted `O(N)` or `o(N log log N)` algorithm is claimed.**

## Why this note matters

The previous fusion plan attempted to combine CWFS, WFTA, Green/scan/QTGF executors with Weyl sparse-residual completion (WSRC/WDRR). This sounded like a recipe, but the *ability to make the residual cheap for every dense input* was never proved. The present note establishes a sharp obstacle for an extensive family of such mechanisms. It also identifies a circular assumption in WDRR.

## Theorem 1 — generic circulants are totally nonsingular

Write `C_x[i,j] = x[(i-j) mod N]` for cyclic convolution by `x` over `C`. There is a nonempty Zariski-open dense subset `U_N ⊂ C^N` such that **every square minor of `C_x` is nonzero for every `x ∈ U_N`**.

### Proof

Let `omega` be a primitive `N`-th root of unity. Pick any complex `u` with `|u|>1`, e.g. `u=2`, and the explicit vector

\[
x_j=\frac1{u-\omega^j}.
\]

Then

\[
 C_x[i,j]=\frac1{u-\omega^{i-j}}
 =\frac{\omega^j}{u\omega^j-\omega^i}.
\]

For any selected distinct rows `i_1,...,i_r` and columns `j_1,...,j_r`, this is an invertible diagonal column scaling of the Cauchy matrix

\[
[1/(u\omega^{j_b}-\omega^{i_a})]_{a,b}.
\]

Its determinant is nonzero: selected row points `omega^{i_a}` are distinct; selected column points `u omega^{j_b}` are distinct; the two point sets are disjoint by magnitude. Therefore every square minor of this one circulant is nonzero.

Every fixed minor is a polynomial in the `N` coordinates of `x`. Since no such polynomial is identically zero, and there are finitely many minors, their simultaneous nonvanishing defines a nonempty Zariski-open dense set. QED.

**Historical boundary:** Cauchy total nonsingularity and Zariski-open genericity are classical; the stated packaging is a research gate for our fusion architecture, not certified worldwide novelty.

## Theorem 2 — exact and sharp adaptive filter support barrier

For `x ∈ U_N`, let `p` be **any nonzero vector with exactly `t` nonzero coordinates**, chosen in an arbitrary input-dependent fashion. Put

\[
y=C_x p=P(X)x.
\]

Then

\[
\boxed{\operatorname{nnz}(y)+t\ge N+1.}\tag{2.1}
\]

This is sharp **for every filter support and every prescribed set of `t−1` residual zeros**. Indeed, on selected input/filter columns `A` with `|A|=t` and desired zero rows `R` with `|R|=t−1`, the restricted matrix `C_x[R,A]` has rank `t−1`. Its kernel has dimension one, its unique generator has every coordinate nonzero by the nonvanishing `(t−1)×(t−1)` minors, and the output cannot vanish at any additional row because all `t×t` minors are nonzero.

To prove (2.1), if the output had `t` zero coordinates, those `t` rows and the `t` nonzero filter columns would give an invertible square minor annihilating a nonzero coefficient vector, a contradiction.

In particular, `t=polylog(N)` forces `nnz(P(X)x)=N-polylog(N)+1` for generic `x`. Feeding that residual into a pruned radix-two FFT still costs `Theta(N log N)` (using this particular executor). The theorem is **not** a lower bound against every way of applying/solving `P(X)`.

## Theorem 3 — multistage adaptive Weyl filters also retain a dense forcing

Let `m | N`, `1≤m<N`, and let

\[
 B(\theta)= (I-X^m)\prod_{i=1}^{\ell}(a_iI+b_iZ-c_iX),
\]

where each coefficient triple `(a_i,b_i,c_i)` is nonzero; the choice and order of coefficients may depend arbitrarily on the input. Each triple is only relevant projectively: multiplying a factor by a nonzero scalar does not change output support. Thus the parameter space has dimension at most `d=2ell`.

### Lemma: nullity at most one per Weyl factor

If `c_i !=0`, the homogeneous equation `(a_iI+b_i Z-c_iX)y=0` is one cyclic first-order recurrence determining all coordinates from one starting coordinate. Thus `nullity ≤1`.

If `c_i=0`, it is the diagonal operator `a_i I+b_iZ`; since all diagonal root powers are distinct, at most one diagonal entry can vanish unless the triple were zero. Thus `nullity ≤1` again.

The nullity of a product is at most the sum of nullities, and

\[
\operatorname{nullity}(I-X^m)=m
\]

because `m` divides `N`. Therefore

\[
\boxed{\operatorname{nullity} B(\theta)\le m+\ell.}\tag{3.1}
\]

### Algebraic incidence bound

Fix an output support set `S` with `|S|≤s`. For any fixed parameter `theta`, the condition

\[
 B(\theta)x\in\mathbb C^S
\]

imposes at least `N−(m+ell)−s` independent linear conditions on `x`. Its solution space has dimension at most `m+ell+s`.

Allowing the `2ell` projective parameter dimensions raises the incidence image dimension to at most

\[
 m+s+3\ell.
\]

There are finitely many support sets and rational parameter charts, so if

\[
\boxed{m+s+3\ell<N,}\tag{3.2}
\]

all inputs admitting such a support reduction belong to a proper algebraic subset of `C^N`.

Thus for generic `x`, **every** adaptive coefficient choice obeys

\[
\boxed{\operatorname{nnz}(B(\theta)x)\ge N-m-3\ell.}\tag{3.3}
\]

The integer bound is deliberately not maximally sharp (the `+1` convention and exceptional parameter strata may permit minor refinements); it suffices to eliminate the claimed generic sparsification.

### General dimension principle

The same proof works for *any* rational `d`-parameter family of `N×N` operators `B(theta)` having nullity at most `kappa` at every regular parameter point: if `d+kappa+s<N`, a generic `x` cannot yield a residual supported on at most `s` coordinates for any parameter choice.

For `ell=O(log log N)` and `m=polylog(N)`, (3.3) forces residual support `N-o(N)`, not `O(1)` or `polylog(N)`. A literal Weyl-filter-plus-pruned-FFT design cannot yield the desired `o(N log log N)` on arbitrary dense inputs.

**Novelty boundary:** This strengthens and systematizes the one-stage dimension argument already present in the user's `Filtered_Fourier_Fusion` research package. It is not claimed to be a worldwide-first theorem.

## Proposition 4 — the WDRR small-row-error assumption is circular

Let `E=MX−ZM` and `g=1−Me_0` as in Phase 49. If `E[k,:]=0` and `g_k=0` for a row index `k`, then that row of `M` equals row `k` of the full Fourier matrix:

\[
 M[k,j+1]=\omega^k M[k,j],\qquad M[k,0]=1
 \implies M[k,j]=\omega^{kj}.
\]

Consequently, assuming both Weyl/seed defects are supported on `s` exceptional output rows assumes that the candidate **already computes the other `N−s` full Fourier outputs exactly**. At `s=\sqrt N` this means almost the entire Fourier map is already solved.

The rectangular correction formula itself is correct, but a cheap base with this property is not provided by the theorem. Synthesizing it with `M=F−correction` hides the expensive FFT inside `M`. This cannot be promoted to an `O(N)` algorithm by declaring `M` fast.

## What remains viable for the requested exact bound

The most plausible surviving **research target** is an input-independent arithmetic circuit employing coefficients outside the bounded-coefficient regime, with genuine cross-axis sharing of *data-dependent* linear forms. Phase 45 root-bank sharing reduces setup but not asymptotic online work; Phase 56 finite exact Green factorizations are genuine but `Theta(N^2)` when extended by their present term-count pattern. The supplied-root complex-arithmetic uniform external comparator has `O(N(log N)^(1−10^(−13)))` complexity, not `O(N)`.

A target of `o(N log log N)` needs more than a hypothetical half-union at the `N log log N` threshold. For example, along the bit-length scale `w=2^j`, suppose a *real exact compiler* achieved

\[
 f_j\le \left(1-\frac{c}{j^\alpha}\right)f_{j-1}+K,
 \quad 0<\alpha<1,\ c>0,
\]

where `f_j=C(2^(2^j))/2^(2^j)` is normalized total work. Then elementary induction gives `f_j=O(j^alpha)`, hence

\[
 C(N)=O(N(\log\log N)^\alpha)=o(N\log\log N)
\]

on the controlled lengths. A uniform fixed `c>0` contraction gives `O(N)`. **We do not have this compiler**. Stating the recurrence is an evaluation target, not a claimed solution.

Finally, in a standard fan-in-two bounded-coefficient exact linear circuit for the unnormalized DFT, the determinant/volume argument implies that any `K N`-gate candidate needs at least one mixing step with

\[
 |a|+|b|\ge N^{1/(2K)}.
\]

So merely rearranging bounded unit-twiddle butterflies cannot reach `O(N)` in that model. This is Morgenstern-type restricted prior art, not a universal exact arithmetic lower bound.

## Exact experiment: explicit rational full-spark circulant at N=8

`verify_generic_barrier.py` independently constructs an **integer input** `x`, checks all `binom(16,8)−1 = 12,869` nonempty square circulant minors are nonzero modulo the explicitly primality-checked prime `2013265921`, and exhaustively constructs sharp `t`-tap filters for **every** filter support and every prescribed `t−1` zero rows, for `t=1..5`.

The test is independent of floating point or any FFT implementation. Since the matrices have integer entries, each nonzero modular minor certifies the corresponding rational/complex minor is nonzero. It does not substitute for the all-N Cauchy proof above.

`CERTIFICATE.json` records the chosen input and exact test counts.

## Result and next decision

**Proved now:** broad adaptive sparse-residual filters cannot be the missing **generic-data** shortcut. The WDRR near-complete-output assumption is circular without a genuine low-work base. These corrections remove a large collection of false-positive fusion proposals.

**Not proved:** an input-independent uniform exact all-input `O(N)` or `o(N log log N)` Fourier algorithm.

**The only valid next success artifact:** a fully expanded uniform scalar DAG with a *proved* count below `N log log N` for every sufficiently large `N`, and no use of a Fourier oracle or unsupported macro executor. Any finite small-size win without a scaling identity is a benchmark, not the asymptotic result.
