# Independent review: matched borrowed-compiler comparison

Review date: 13 October 2026 UTC. Source package manifest: `d42781f8737b83c1e886eb70560128169ae39aa057da7f43325d12bfb868d060`.

## Verdict

**Accept the bounded matched-local comparison with two corrections and a stricter global-theorem evidence label.** Close the obsolete asymptotic-comparison obligation. Do not close the complete-program constant comparison, historical originality, ALG-022's unrelated recurrence obligations, or verification of the external global theorem.

The pinned prior source already states an exact-r, arbitrary-input O(log²r) compiler with charged polynomial preparation. Consequently the candidate's p=2 compiler does not support a new (loglog N)² saving over the complete cited prior corpus. That comparison used the older written p=4 bound. This is a source-level comparison of the stated constructions, with a fresh bounded audit of the local macros, rather than an independent rebuild of either full formal compiler or global tensor theorem.

Corrections:

1. The q=8,a=4,e=5 literal prior example has **170**, not 162, layers. The symbolic formula 48d+26 and the producer's executable result are already correct.
2. Sixteen prior FFT calls is a literal-order count. A legal disjoint-support cancellation reduces it to **12 FFT calls**, preserving 24d+18 parallel depth and arbitrary dirty-bank correctness. The candidate's eight FFT calls must therefore be compared with at least this improved baseline for an implementation claim. No optimality claim is made for either schedule.

## 1. Integrity, inputs, and what ran

The producer manifest hash matches the assigned hash exactly. All 49 manifest entries match byte counts and SHA-256. All 40 saved primary-source files match their recorded SHA-256, byte count, and Git blob SHA-1. All nine local input bindings match. These checks verify preserved bytes against their supplied pins; this review did not independently refetch remote HEAD or establish a new history timestamp.

The producer's 202-line standard-library checker was read before execution, copied into this separate review directory, and replayed without changing the sealed original. Its new RESULTS.json is byte-for-byte identical to the source result. It passes:

- 117 local accumulation schedules; 2,436 basis columns and 117 dense vectors
- 18 shared-scratch product schedules; 358 basis columns and 18 dense vectors
- 63 direct-DFT FFT basis columns and 13 omitted-correction negative controls

The review also contains a newly written checker, `checks/independent_matrix_audit.py`, that imports no producer implementation. It applies sparse scalar gates to all columns of an identity matrix and compares the entire resulting operator with a directly assembled Toeplitz target matrix. It passed:

- 192 local words, covering the candidate, literal prior, parallel prior, and cancellation prior; 4,452 full basis columns
- 96 literal/cancelled duct-boundary words; 2,424 full basis columns, checking that the first scratch bank and every role except the specified second-bank target are unchanged
- 63 direct-DFT FFT columns and 12 omitted-correction negative controls
- Inverse round trips of every checked local word

All review execution was newly authored/reviewed local audit code using Python's standard library. No downloaded Lean source, external verifier, repository generator, build script, package install, tensor implementation, or certificate search program was executed. There were no external writes, table edits, repository edits, uploads, or child tasks.

### Test limits

The producer uses Q(i) for q≤4 and F257 for q≤32. Its Q(i) cases use the actual norm regularizer, including zero/singular kernels. Its finite-field cases select a nonzero shift separately; they do not prove that the complex norm construction transfers to finite fields. The new matrix checker uses **F257 only**, with explicitly checked primitive power-of-two roots and separately selected nonzero shifts. For each fixed schedule, full-operator equality covers arbitrary dirty states over that tested field. It is not an all-width/all-complex proof. The all-complex cancellation argument is given separately below.

The producer's negative controls all remove the final alpha correction; they are useful sensitivity checks but not an extensive mutation campaign. Neither checker executes the full recursive Fourier compiler, C-slot normalization, root/preparation DAG, tensor engine, or all-length CRT/Bluestein adapter. Tests omit coefficient-preparation cost. Gate counters retain zero/one coefficients and idle permutation layers. Interpreter storage is not the emitted word's data width.

## 2. All-complex cancellation identity

Use disjoint roles x,y,u,v, with u and v the q-coordinate dirty scratch banks. Write P for u←u+Ex, L for y←y+Rv, U for Fq on u, V for Fq on v, and S for v←v+diag(lambda)u, where lambda=Fq h. Products below are written in **chronological execution order**. U and V are invertible; S⁻¹ negates its coefficient vector. No invertibility of K=Fq⁻¹diag(lambda)Fq is required.

The prior eddy is U V S U⁻¹ V⁻¹. Its duct is

P U V S U⁻¹ V⁻¹ P⁻¹ U V S⁻¹ U⁻¹ V⁻¹.

V⁻¹ acts only on v. P⁻¹ acts only on x,u, and U acts only on u. Thus V⁻¹ commutes with both P⁻¹ and U, and the fragment

V⁻¹ P⁻¹ U V = P⁻¹ U V⁻¹ V = P⁻¹ U.

The entire duct is therefore exactly

P U V S U⁻¹ P⁻¹ U S⁻¹ U⁻¹ V⁻¹.

This is an identity of linear operators over C, for every q with a valid invertible FFT and arbitrary input values. It is not inferred merely from finite-field tests. Its first U,V pair and final U⁻¹,V⁻¹ pair can run in parallel. It uses six FFT/inverse calls rather than eight.

The unchanged dirty-state contract is direct: the original duct first adds K(u₀+Ex) to v, restores u₀ with P⁻¹, then subtracts Ku₀. Hence

(x,y,u₀,v₀) ↦ (x,y,u₀,v₀+KEx).

The cancelled duct is the identical linear map. The outer well is D(K) L D(−K) L⁻¹. It leaves x,u,v unchanged and adds RKEx to y. Applying the cancellation inside each of its two ducts reduces the total count from 16 FFT calls to 12 and restores both arbitrary scratch banks at the end. The independent boundary checks specifically test this intermediate duct contract, as well as the final well contract.

## 3. Corrected local ledger

Let q=2^d≥a+e−1, m=min(a,e), and f=1+3d be the matched radix-two FFT depth.

| Resource | Candidate | Prior literal | Prior parallel | Prior parallel + cancellation |
|---|---:|---:|---:|---:|
| Scratch coordinates | q | 2q | 2q | 2q |
| Total local coordinates | a+e+q | a+e+2q | a+e+2q | a+e+2q |
| FFT / inverse calls | 8 | 16 | 16 | 12 |
| Layers | 8f+9 | 16f+10 | 8f+10 | 8f+10 |
| Layers, expanded | 24d+17 | 48d+26 | 24d+18 | 24d+18 |
| Scalar arithmetic | 20qd+4q+4(a+e)+2m | 40qd+8q+8e+4a | 40qd+8q+8e+4a | 30qd+8q+8e+4a |

An FFT uses qd shears and qd/2 scalings, hence 5qd/2 scalar operations under the stated primitive ledger. The cancelled prior has twelve FFTs, four q-wide spectral shear layers, four e-wide injection layers, and two a-wide selection layers. This gives its displayed arithmetic formula. Its duct depth is 4f+4, so well depth is 8f+10. All coefficients, inverse construction, and schedule preparation remain separately charged and are excluded from these numbers.

At q=8,a=4,e=5:

| Route | Width | Layers | Arithmetic | Data accesses | Coefficient reads |
|---|---:|---:|---:|---:|---:|
| Candidate | 17 | 89 | 556 | 962 | 342 |
| Prior literal | 25 | 170 | 1080 | 1844 | 636 |
| Prior parallel | 25 | 90 | 1080 | 1844 | 636 |
| Prior cancelled | 25 | 90 | 840 | 1428 | 492 |

The data convention is three accesses per shear, two per scaling, four per swap, with coefficient reads reported separately. These are comparison conventions, not extracted RAM costs. The literal sixteen-call count remains valid historical data for the literal macro, but an optimized-prior narrative should use at least the verified twelve-call baseline.

This refinement establishes neither an optimal prior schedule nor a complete-program constant advantage. No further optimization search was performed. The q versus 2q scratch distinction remains valid for these macros; it still gives no global r versus 2r result because **both complete compilers already borrow within exactly r data coordinates**.

## 4. Full-compiler and transfer boundaries

The saved OpenAI `FourierWords.lean` supplies `sound_ballad`, `creates_ballad`, `beats_ballad`, and `score_le`: at n≤2^e, score≤20,000,000(e+1)²+7. Its `Creates` predicate quantifies arbitrary input data, and `Sound n` confines the word to n coordinates. `LocalCompiler.publish` states the preparation interface. This is substantive primary-source evidence for the prior p=2 compiler statement, not a new full Lean replay.

The formal prior's measured partition enumerates 16³ chunk products, while the candidate uses the written rank-three displacement/chunk arrangement. The complete schedules cannot be compared by scaling one local macro's count or treating the loose native score upper bound as an optimized implementation. Native beats must also be normalized to the same C/monomial basis before numerical comparison. The existing change-of-basis discussion is an elementary source-level argument, not a newly verified Lean equivalence theorem.

Under the **same assumed charged tensor engine** with exponent theta=1−a and the **same assumed charged outer reduction**, the displayed substitution gives

T_p(N)=O(N(log N)^theta(loglog N)^(p−theta)).

Both stated p=2 local compilers yield the same exponent 1+a on loglog N. The earlier written p=4 statement yields 3+a. This algebraic comparison does not independently establish the imported engine or outer reduction. It cannot be promoted to a new global exact-DFT improvement.

Exact-r denotes local complex data coordinates. Prepared constants, roots, table/index storage, execution arrays, and global memory are distinct. The supplied canonical root contract, exact complex arithmetic, and logarithmic-word index operations are part of the model. No bit-complexity, stability, or practical-speed result is established here.

## 5. Required softening of global theorem wording

The producer's opening assertion “The finite tensor savings are genuine prior results in their exact-arithmetic model” should not be treated as this review's independent endorsement. Replace that paragraph's opening with:

> The pinned upstream repository contains source-level Lean theorem declarations claiming the stated exact-arithmetic tensor and all-length savings, and reports prior verification runs. This comparison statically inspected selected declarations and interfaces; it did not rebuild the project, replay the full dependency closure, or independently establish the correctness of the global theorem.

The same qualification applies to “known/attributed ... tensor exponent savings, and all-length sub-NlogN transfer” in the producer's disposition: these are **attributed upstream claims/theorem dependencies**, not independently verified outcomes of these local checks.

Specifically, the saved `Seam.hillsE8_program` is a source-level closed declaration referring to the scalar closure fields of `GXD.E8.scalOK`, and `Main.transform_mainE8` states `DFTGoalE8`. The latter goal includes the all-input DFT program and asymptotic time assertions. The declared kernel saving is 8762479/10^10; the declared all-length pure-log saving is 8762478/10^10. Those numbers identify the upstream claims, not a freshly kernel-checked result here.

The comparator configuration allows `propext`, `Quot.sound`, and `Classical.choice` and has `enable_nanoda=false`. `#print axioms` commands in source are not their execution output. Upstream VERIFY.md reports earlier Lean/comparator checks and expressly notes no real-sandbox comparator run, no second independent kernel, and no single empty-directory build of the fourth revision. The reviewer neither repeated those checks nor audited the entire dependency graph. The global theorem is therefore **inherited, source-pinned, statically inspected, and independently unverified in this review**. Local comparison acceptance does not change that label.

## 6. Table disposition and bounded next gate

The preserved applied-readback baseline records ALG-022 at overview row 114 and BORROWED-FOURIER-COMPILER-20261012 at row 324, each TO RESEARCH and priority 53. The later local 03:45 projection also retains those values. These are recorded snapshots; this review made no fresh live-sheet read and changed no cells.

Recommended **BORROWED** current-stage update:

- Status: TO RESEARCH, restricted to the residual complete-program implementation/priority claim
- Compiler/asymptotic comparison gate: CLOSED, BOUNDED ACCEPTANCE WITH CORRECTIONS
- Work-priority score: **32/100**, a triage judgment, not a proof or novelty probability
- Proof scope: local dirty-scratch identities and bounded exact schedules accepted; full recursive/global proof status remains inherited; no independent global-kernel acceptance
- Novelty scope: prior exact-r O(log²r) asymptotic is credited; one-bank historical priority and optimized total-program benefit remain unestablished
- Next bounded gate: extract both complete recursive schedules for a predeclared pilot set, suggested r in {2,3,4,5,8,16,17,32}, with identical supplied-root contracts; normalize to one C/monomial slot basis, incorporate the verified prior cancellation, and separately charge coefficient/root preparation, schedule generation, copies, padding, and peak live data. Derive the paired symbolic recurrences alongside the finite ledger instead of generalizing performance from samples.
- Stopping condition: deliver the reproducible pilot ledger plus its symbolic-recurrence audit and identify whether a credible total-resource benefit remains. A benefit in samples is only a bounded implementation result; a uniform complete-program constant claim requires the corresponding all-width bound. If the proposed benefit fails in the matched ledger or rests only on a loose prior upper bound, close that claim at its tested scope. Do not reopen the obsolete p=4-only asymptotic comparison.

Recommended **ALG-022** handling:

- Attach this closed compiler-comparison result to the compiler slice only; that slice's residual score is 32
- Preserve the parent row's recorded status and priority 53 until its other live obligations receive their own current-scope ranking
- Do not assign 32 to the entire ALG-022 row merely because BORROWED receives it
- The distinct F096 finite q-exponential tail/first-layer recurrence and sparse q-difference forcing/application-cost obligations are **not audited, not re-ranked, and not closed** by this review

The two unrelated source hashes are retained in the pre-existing source binding: `4571d3e8e6f06f0ddfe0c57b78b84b2c03c77ea5f5b78643f1a7766ef201473e` and `58001a15deae9625ae6b4bf9e98327fc3c6138a8e5196e2fd152ede1894193de`. No finding about those sources is inferred from a shared factorization or family identifier.

## Primary pinned references

- [OpenAI FourierWords](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/OAI/Computability/FourierTransform/FourierWords.lean), especially the four compiler declarations near lines 101–119
- [OpenAI LocalCompiler](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/OAI/Computability/FourierTransform/LocalCompiler.lean), `Bench.publish`
- [Pinned CirculantUpdates](https://github.com/jacobalansussman/wht-power-saving-lean/blob/9c94857bbaee886f8649edee0bc2d3c738f9555e/OAI/Computability/FourierTransform/CirculantUpdates.lean), `eddy`
- [Pinned ToeplitzUpdates](https://github.com/jacobalansussman/wht-power-saving-lean/blob/9c94857bbaee886f8649edee0bc2d3c738f9555e/OAI/Computability/FourierTransform/ToeplitzUpdates.lean), `duct` and `well`
- [Pinned Seam](https://github.com/jacobalansussman/wht-power-saving-lean/blob/9c94857bbaee886f8649edee0bc2d3c738f9555e/Work/FourierE8/Seam.lean), `RAM.hillsE8_program`
- [Pinned Main](https://github.com/jacobalansussman/wht-power-saving-lean/blob/9c94857bbaee886f8649edee0bc2d3c738f9555e/Work/FourierE8/Main.lean), `transform_mainE8`
- [Upstream verification account](https://github.com/jacobalansussman/wht-power-saving-lean/blob/9c94857bbaee886f8649edee0bc2d3c738f9555e/VERIFY.md), especially section 10.7

All cited contents were inspected from the hash-bound saved source package. The links identify the primary pinned sources; they do not imply a fresh network fetch or independent upstream build.
