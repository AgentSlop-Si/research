"""Verify this frozen review's closure and result identity; no scientific run."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((root/'MANIFEST.json').read_text())
s=json.loads((root/'SEAL.json').read_text())
assert sha(root/'MANIFEST.json')==s['manifest_sha256']
for x in m['files']:
    p=root/x['path']
    assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],x['path']
# Original candidate MANIFEST/SEAL snapshots live inside evidence and are
# included; only this review's two root-level seal files are self-excluded.
files={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts
       and str(p.relative_to(root)) not in ('MANIFEST.json','SEAL.json')}
assert files=={x['path'] for x in m['files']}
v=json.loads((root/'VERDICT.json').read_text())
r=json.loads((root/'evidence/INDEPENDENT_RESULTS.json').read_text())
b=json.loads((root/'evidence/BINDINGS.json').read_text())
assert v['overall']=='ACCEPT' and not v['required_repairs'] and r['status']==b['status']=='PASS'
assert v['production_source_sha256']==sha(root/'sources/phase_medians.py')==b['production_sha256']
assert all(x['detected'] for x in r['mutants']) and len(r['mutants'])==25
assert v['independent_checks']==r['baseline_counts']
print(json.dumps(dict(status='PASS',files=len(m['files']),verdict=v['overall'],
                     production_sha256=v['production_source_sha256']),indent=2))
