# Q16 inverse-phase estimation and Cartesian medians: independent acceptance

13 October 2026. **ACCEPT**, with the precise deterministic scope below. No required repairs.

## 1. Accepted object and boundary

The reviewed candidate archive is `Q16_Certified_Phase_Medians_Candidate_2026-10-13.zip`, SHA256 `d02c18db66e662c45787780e4b0acb751c4b1098019de62ca526df51aba63366`. Its production module is `src/phase_medians.py`, SHA256 `45c0c6a59cac18912278dcda183fe8e5bea2a19398cb61fc1bf8ec97cac5a788`. The supplied candidate Library identity is `libfile_9f54aeb595ac8191a6b030f25d9c588d`, version 0; the acceptance itself is bound to the verified bytes.

Accept the two deterministic public APIs `estimate_round` and `cartesian_medians`, their numerical behavior on the documented exact immutable inputs, and their conservative source-level finite-bit work and cumulative auxiliary-storage account. This closes the numerical steps 6 and 7 after suitable candidates and bucket rows have been supplied. No change to the production source was needed or made.

The source uses only the accepted `compact_window.py` Ledger, Scalar, CertificationError and nearest-even functionality. That module is byte-identical to the accepted dependency with SHA256 `e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59`. BUCKETS and the location decoder were compared as source/acceptance evidence, not executed. The inherited E(beta) and downstream mathematical premises are not freshly accepted in their entirety by this review.

This is not executable composition of WINDOW, BUCKETS, decoding, estimation and medians. The supplied rows carry no authenticated upstream origin or matching M/B/sigma/tau metadata. EstimateResult also carries no candidate identities: all estimation rows must use the same candidate ordering as the median caller. Neither equal row lengths nor exact object types establish that binding. Candidate support K <= 2qT, source normalization, theorem parameter guards and all prior work charges remain caller obligations.

Also excluded: random generation/scheduling, independence, successful-recovery probability, full recovery, the dense exceptional branch, outer transfer, an all-length executable, Python/host totality, physical RAM/time, practical speed and novelty. The checks are deterministic reduced-component fixtures; large-M tests use tiny supplied bucket/candidate sets and do not run a theorem-scale sparse recovery.

## 2. Byte/source correspondence

The fresh binding checker verified all 29 candidate manifest entries, the manifest seal, all pinned sources, ZIP CRCs, unique safe member names and equality of all 31 archive files to the supplied candidate folder. It also established direct byte equality to the accepted BUCKETS source, accepted location-decoder source, and the recovered algorithm/proof text. The report is therefore about the intended frozen candidate, not a reconstructed variant.

The source algorithm and proof pins are respectively:

- ALGORITHM.txt: `17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1`
- PROOF.md: `0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b`

Source correspondence in the frozen production module:

- Lines 34-73: exact scalar/container/candidate/Cartesian-pair recognition.
- Lines 76-110: freshly paid inverse-phase preparation and its enclosing certificate.
- Lines 113-164: step 6 deterministic half-open hash, exact undivided complex product and final P-grid rounding.
- Lines 167-200: explicit signed bottom-up mergesort, including incomplete final runs.
- Lines 203-255: step 7 independent coordinate sorting, unique middle elements for odd L, no further numerical rounding, sorted candidate order and retained zero values.

The source specifies inverse phase omega^(-tau*i), not an inverse modular index. The code computes r = tau*i mod M using the complete exact product, then cos(2*pi*r/M) and -sin(2*pi*r/M). Sigma affects only the frequency hash. The half-open bucket cell centered at jT includes jT-T/2 and excludes jT+T/2. The final mod B correctly sends the final half-cell to bucket zero. No division by response G occurs; division by 2^(P+2) is solely fixed-point numerator rescaling.

## 3. Paid root proof, sign and rounding

For P >= 8 put rho = 2^-P, Q = P+2, J = P+8 and Kwork = J + 2 bit_length(J+1) + 16. Every call actually constructs Scalar(Kwork, ledger), including both finite Machin arctangent sums. It then evaluates the two indicated sines and rounds both midpoint intervals to Q bits. There is no supplied certificate, reused pi cache or zero-bucket/axis exemption from preparation work. K=0 correctly performs no phase preparation.

The accepted Scalar's predetermined number of terms is Kwork+8. Its sine interval width is at most 64(Kwork+9) 2^-Kwork. The guard 64(Kwork+9) <= 2^(Kwork-J) is universally valid here. For J >= 16, bit_length(J+1) <= (J+1)/2, so Kwork+9 <= 2J+26 <= 4(J+1), while 2^(Kwork-J) > 2^16(J+1)^2. Thus the interval width is at most 2^-J, with no data-dependent refinement or timeout.

Nearest-even midpoint rounding to the Q grid has scalar error at most rho/8 + rho/512 < rho/4 against every point of the enclosure. The Euclidean complex error is consequently below rho. The code independently tests the squared endpoint-distance sum against 2^(2(Kwork-P)), using exact integers. Exact axes are handled algebraically inside Scalar and all argument reduction is exact. The two preparation intervals and their working-width diagnostics stay out of the returned numerical payload.

For bucket (a+ib) 2^-P and root (u+iv) 2^-Q the exact numerator products are au-bv and av+bu. Rounding those integers divided by 2^Q gives the P-grid estimate. Negative nearest-even behavior is correct: floor quotient, nonnegative remainder, comparison of twice the remainder and odd quotient tie-breaking. The reviewer oracle instead used magnitude quotient, symmetric sign restoration and explicit tie parity, including positive and negative halfway witnesses. There is no intermediate product rounding.

## 4. Exact forward-error transfer

Let p be the unit inverse phase, phat its prepared approximation, bt the supplied bucket, and b an ideal bucket. Suppose |phat-p| <= rho, |bt-b| <= D and |b| <= A. The final two coordinate roundings contribute at most rho/sqrt(2), hence at most rho. Exactly decomposing the pre-round error gives

    phat*bt - p*b = phat*(bt-b) + (phat-p)*b.

Because |phat| <= 1+rho,

    |estimate - p*b| <= (1+rho)D + A*rho + rho.

This deterministic bound holds on every valid input satisfying those numerical premises. It does not depend on successful recovery, a heavy-coordinate gap or a good random tape. For completely arbitrary supplied P-grid numerators, D=0 and A=|bt| gives the weaker but unconditional phase-only bound

    |estimate - p*bt| <= (|a|+|b|)rho^2 + rho.

For a genuine accepted matching BUCKETS result, inherit D=24(m+1)M^2*rho and A=2M^2. Since rho <= 1,

    (1+rho)D + A*rho + rho
      <= [48(m+1)M^2 + 2M^2 + 1]rho
      <= 64(m+1)M^2*rho.

The last step follows already for m >= 2 and M >= 4. In particular it applies to P=16m+16 and is exactly section 6's source eta bound. Parsing an arbitrary tuple does not certify the BUCKETS premises. The unconditional generic bound and the inherited stronger bound are deliberately kept separate.

## 5. Odd-L medians and the majority quantifiers

For each candidate column independently, exact integer comparison orders its real coordinates and separately orders its imaginary coordinates. All values have the same positive denominator, so these are the true signed dyadic orders. For positive odd L, index floor(L/2) is the unique middle entry. Bottom-up mergesort doubles the run length; every pass writes every array position exactly once, including the incomplete last run. It terminates after ceil(log2 L) passes. Returned numerator components are existing input integers; no rounding is added.

For each fixed candidate i, if a strict majority of its L supplied complex estimates is within e of target z_i, a strict majority of each coordinate lies in the corresponding interval of radius e. A middle coordinate cannot lie outside that interval: at most (L-1)/2 entries are outside on either side. Hence

    |median_i - z_i| <= sqrt(2)*e.

This statement is per candidate and deterministic. The set of good rows may differ between candidates; no one common majority across all candidates is required. More generally, separate strict majorities in the two coordinate intervals suffice even when those two majority sets do not share a strict majority. The tested source application uses e=a+eta after a separately justified strict majority of ideal estimates within a and the uniform deterministic numerical error eta. Source L=4m+1 is odd. The candidate does not prove that probabilistic majority event, and an arbitrary collection of supplied rows gains no independence from the median routine.

## 6. Recognition, rejection and width audit

The two public APIs require exact built-in integer types, rejecting booleans and integer subclasses before arithmetic/coercion. Exact tuples are required at every scientific container boundary; mutable containers, tuple subclasses, callbacks and nonexact EstimateResult row types are rejected before their scientific fields can be used. Fields already reached before numeric-domain rejection retain their actual magnitude-width charges. Missing/unreached later fields are not claimed parsed after a rejection.

M is a power of two at least 4; P >= 8. Estimation additionally requires dyadic 2 <= B <= M/2, odd 1 <= sigma < M and 0 <= tau < M, so T=M/B is even and all divisors are positive. Candidates are sorted, distinct exact indices, with K <= M. The bucket grid must equal P before any denominator based on a supplied grid can be allocated. All B pairs are parsed, including for K=0. Medians require positive odd L, every row's exact grid and K-pair shape, and both numerator fields of every reached pair, including empty-candidate row recognition.

Arbitrary-width signed bucket/estimate numerators are allowed and paid, not silently truncated. Tests include 17,003-bit valid numerators, 32,770-bit reached malformed fields, a rejected 65,540-bit exponent, 194-bit geometry encodings, empty candidates, and source-target P=16m+16 at m=57 and 97. These are finite data/precision witnesses, not a claim that any finite host can supply unlimited resources. Deliberate object mutation through Python internals and adversarial instrumentation objects are outside the documented scientific deserialization interface.

No valid-domain cap, random rejection, retry, unbounded refinement or overflow path is introduced. CertificationError guards are proved invariants, not allowed probabilistic failures. Host memory exhaustion and Python VM behavior are explicitly outside acceptance.

## 7. Independent resource reconstruction and static coverage

Each recorded primitive was independently recomputed for addition, subtraction, multiplication, signed quotient/remainder and binary powers. Independent binary-width computation reconstructed its 16(2+sum operand/result widths)^2 charge, output signed-storage contribution, input magnitude-width totals, maximum width, events and allocated slots. This was checked on early and late rejection paths plus a shared ledger containing successful estimates, successful medians and a later malformed call. The previous work was retained. Eight traces contain 7,222 primitive records.

Let E be the sum of all recorded operation/event/slot counts plus 256, and Dmax the largest observed integer width plus bit_length(E)+2. The report's control envelope 512*E*Dmax^2 and cumulative-storage envelope recorded produced bits + 512*E*Dmax were reconstructed exactly. Source inspection shows that every nonconstant loop iteration has recorded arithmetic, an event or a batch allocation; fixed-arity tuple/interval/certificate work, built-in comparisons, sign/bit operations, counters, indexing and rejection branches fit the conservative envelope. This is a source-level schoolbook-bit model, not a formally verified Python bytecode allocator or CPU certificate.

For K candidates, valid estimation pays B bucket parses, K candidate reads, K bucket accesses, K fresh root preparations, 2K sine evaluations, 2K(Kwork+8) arctangent terms, 4K nearest-even calls, 2K+1 numerical output integer records and 16K+2 allocated slots. Zero data does not bypass these preparation counts.

For odd L rows and K candidates, medians pay L row parses, KL pair parses/accesses, 2K signed sorts, 2KL initial sort copies, 2KL ceil(log2 L) merge copies, zero numerical roundings, 3K+1 output integer records and 6KL+6K+2 allocated slots. K=0 still pays O(L) recognition. The returned indices are already ordered; retained zeros are permitted by step 7.

Writing H for reached data numerator width, m=log2 M and p=P+1, the estimator's arithmetic widths are O(H+m+p log(p+1)); exact address/phase products include the full roughly 2m-bit products. The finite Scalar uses O(p) terms with O(p log(p+1))-bit factorial/Machin intermediates. Estimation event count is O(B+K(1+p)). Median event count is O(L+K+KL(1+log(L+1))) with widths O(H+m+log(L+1)+bit_length(P)), plus the explicitly bounded control counters. Arbitrary standalone P or H is not hidden inside O(m).

A prepared Cartesian root has magnitude at most 1+rho per component. An output component numerator is therefore at most (|a|+|b|)(1+rho)+1/2, so H+3 bits is a safe bound; medians cannot increase component widths. Genuine accepted BUCKETS inputs with H=O_d(m) and P=16m+16 yield O_d(m)-bit numerical outputs. Given caller-established K <= 2qT and L=4m+1, all L estimator calls and medians fit O((LB+LK)poly_d(m)) work and O((B+LK)poly_d(m)) cumulative auxiliary storage. Retained inputs and preceding stages remain additive caller costs.

## 8. Independent controls and execution discipline

The freshly written checks do not import or rerun producer tests. The exact rational transcendental oracle uses pi = 4(atan(1/2)+atan(1/3)), with alternating-series endpoint bounds, then direct cosine and sine Taylor polynomials at a rational midpoint. It includes the pi-radius, midpoint-quantization radius and factorial remainder, intersected with the analytic [-1,1] range. This differs from production's Machin 5/239 formula and sine argument reduction. There is no floating-point oracle. Half-open buckets are independently reconstructed by enumerating their source-defined residue cells.

Controls cover all small phase residues; positive/negative axes; large-M points immediately next to singular axes; signed exact product/tie behavior; non-axis arbitrary-width data; multiple B geometries; hash endpoints/wrap; candidate-independent coordinate columns; exhaustive short signed/tied medians; per-candidate different majority sets; partial merge runs; complete zero-candidate parsing; malformed types, shapes, domains and huge widths; exact error-constant transfer; actual pi preparation; returned integer encodings and cumulative accounting.

Twenty-five fresh source mutants are detected, covering wrong phase variable/period/sign/cosine shift, affine contamination of the hash, endpoint and wrap changes, product cross-terms/signs, denominator scaling, imaginary floor and incorrect signed ties, skipped parsing/grids/candidate distinction, root/output/allocation undercharges, wrong median index/coordinate, skipped sort copying and even-L extension. Frozen candidate files were never modified; only in-memory copies were mutated.

See `evidence/INDEPENDENT_RESULTS.json` for the completed counts, reconstructed accounts and each mutation's triggering check. The successful final run and byte bindings are sealed with the report. No producer test script, historical scientific program, BUCKETS engine, decoder, full recovery process, Sheet write, GitHub write, publication or access-permission change was performed.

## 9. Reproduction and verdict

`python checks/independent_checks.py` runs only the archived reviewed modules and fresh reviewer tests. It rewrites its result receipts, so use a disposable copy if preserving the review seal. `checks/verify_bindings.py` additionally requires the named original candidate/dependency folders alongside this review; its retained successful receipt supplies the source binding when they are absent. `verify_review.py` verifies the portable review's hashes and its successful final status without those external folders.

**ACCEPT** the frozen deterministic inverse-phase estimator, odd-L Cartesian medians and conservative finite-bit work/cumulative auxiliary-storage contract. There are no required production repairs. This adds component acceptance only; the caller/provenance, randomness and full-composition exclusions in section 1 remain open boundaries.
