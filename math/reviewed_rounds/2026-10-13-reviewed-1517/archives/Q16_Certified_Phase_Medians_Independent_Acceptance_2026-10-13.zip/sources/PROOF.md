# A constructive finite-dyadic E(beta) candidate

## 0. Status and exact interface

This is a new mathematical candidate requiring independent review. It is not a prior acceptance, worldwide novelty claim, practical speed result, or source-pinned integrated executable certificate. Its local constructive lemmas are stated and proved rather than inferred from numerical experiments.

Fix rational 0 < beta < 1/2 and fixed d. Let M=2^m, m>=1. The input is a fixed random-access vector v in C^M whose Cartesian components are dyadics with O_d(m) bits, absolute value at most 1, and whose norm R satisfies R>1/2. The vector is fixed before fresh independent fair bits. This is the nonzero normalized embedded domain of the accepted downstream transfer. The caller has already paid for its full original-input validation and deterministic max-component normalization. This front end does not scan the input, estimate its norm, or compute its maximum. The all-zero case is handled by that caller. Malformed unbounded encodings are outside this finite input domain.

Write omega=exp(2*pi*i/M), and use the negative-sign unitary transform

    z_j = M^(-1/2) sum_t v_t omega^(-jt).

The candidate finite algorithm returns distinct valid indices and dyadic values, zero elsewhere, with

    Pr[||ztilde-z||_infinity <= 4 M^(-beta) R] >= 1-1/M.

Every tape terminates. Work and storage, including preparation and source access, are M^(1/2+beta) polylog(M); all output widths and exponents are O_d(m). Integer intermediates may have polynomially many bits in m and are charged their full finite cost. There are no probabilistic aborts in the specified valid-domain algorithm. Resource errors of a concrete host are not silently excluded: the mathematical machine must provide the proved storage, and an actual host implementation remains to be validated.

## 1. Parameters and finite exceptional branch

Set

    k = 2^ceil(2*beta*m),   B = 2^ceil((1/2+beta)*m),
    T = M/B,   r=2m+1,   ell=8B,
    W = 2r(ell-1)+1,   q=512k,   L=4m+1,
    P=16m+16,   rho=2^(-P),   delta=M^(-4).

All exponents and ceilings are computed exactly from rational beta. Use the sparse branch only if B divides M, B>=4, T>=4, B>=4096k and W<M. Otherwise use the certified finite dense branch in section 8. The sparse branch conditions hold eventually: both B/k and M/(mB) grow like a positive power of M. Thus only finitely many dyadic lengths use the dense branch, for each fixed beta. The big-O constants may depend on beta and d. No practical crossover claim follows; the deliberately conservative constants make the threshold very large.

For the sparse branch, let g=T/4 and H=3T/4, which are integers. The proof uses a=R/sqrt(k), but the implementation never computes a or R.

## 2. Explicit compact window with paid construction

Let F_t be the probability mass function of the sum of r independent differences U-U', where U,U' are uniform on {0,...,ell-1}. This is a deterministic definition, not a request to sample the filter. Its exact coefficients are

    F_t = [X^(t+r(ell-1))](1+X+...+X^(ell-1))^(2r) / ell^(2r).

They are nonnegative dyadics, sum to one, and have support |t|<=r(ell-1). Their unnormalized Fourier response is

    Phi_j = |ell^(-1) sum_(u=0)^(ell-1) omega^(-ju)|^(2r).

Thus 0<=Phi_j<=1, Phi_0=1. If circular distance |j|_M>=g, then

    |sin(pi*j/M)| >= 2|j|_M/M,
    |sin(pi*ell*j/M)/(ell*sin(pi*j/M))| <= 1/4,
    Phi_j <= 16^(-r).

The bound uses ell=8B and g=M/(4B). At zero use the exact value 1; zeros of the numerator cause no division problem.

Define

    C = sum_(j=-g)^g Phi_j,
    D_H(t) = sum_(u=-H)^H omega^(ut),
    w_t = M F_t D_H(t)/C,
    G_j = sum_(u=-H)^H Phi_(j-u)/C.

Here 1<=C<=2g+1<=M and D_H is real. Direct Fourier multiplication gives the exact normalization

    (1/M) sum_t w_t omega^(-jt) = G_j.             (1)

The factor M in w_t is essential. Under an unnormalized DFT, multiplication in time has a 1/M convolution factor; this packet fixes that factor explicitly instead of importing ambiguous conventions.

The response satisfies

    1 <= G_j <= 1+delta       if |j|_M<=T/2,
    0 <= G_j <= delta         if |j|_M>T,
    0 <= G_j <= 1+delta       for every j.          (2)

Proof: for a passband j, the shifted interval [j-H,j+H] contains [-g,g]. Every added term has distance at least g and hence is at most 16^(-r). For a stopband j, circular triangle inequality gives |j-u|_M>g for every |u|<=H. For a general j, terms inside [-g,g] sum to at most C and all others are bounded by 16^(-r). Since (2H+1)16^(-r)<=M16^(-r)<=M^(-4), (2) follows. Intervals have no duplicated residues because 2H+1<M in this branch.

Also

    sum_t |w_t| <= M(2H+1)<=M^2,                (3)

since sum F_t=1 and C>=1.

### 2.1 Exact integer part of preparation

Compute (1+...+X^(ell-1))^(2r) by 2r sliding-window convolution passes. Each pass updates a running sum by adding one old coefficient and removing the coefficient ell positions back. The total number of integer additions/subtractions is O(r^2 ell), and each integer has at most 2r log2(ell)+1=O(m^2) bits. Divide by the power of two ell^(2r) symbolically. Store only the W supported coefficients; do not create a length-M dense filter.

### 2.2 Certified transcendental part of preparation

C needs only 2g+1=O(T) evaluations. Evaluate Phi_j through the sine ratio above, not by summing ell roots per j. Evaluate D_H(t) through its sine ratio for each of the W taps, with its exact value 2H+1 at t=0. For nonzero residues, the denominator sine has absolute value at least 2/M. Exact rational argument reduction is performed before trigonometric evaluation.

Certified rational intervals for these expressions need O(m) fractional precision with a sufficiently large fixed guard factor. Here is a constructive finite route: bound pi by truncating the alternating Machin series 16 arctan(1/5)-4 arctan(1/239); evaluate sine and cosine by Taylor polynomials after reduction to [-pi,pi], using their explicit factorial remainder bounds. O(m) terms suffice for 2^(-A m) absolute error for every fixed A. Exact rational intermediate bit lengths and operations are polynomial in m. Integer-square-root bracketing similarly provides 1/sqrt(M). This does not assume unit-cost transcendental operations or externally supplied roots.

More explicitly, compute C and D_H(t) within epsilon=rho/(16M^3). C is a sum of O(T)<=M terms, so request epsilon/(4M) error for each Phi term. Round every enclosing interval outward to one common O(m)-bit dyadic grid before summing its endpoints by exact integers. This is essential: accumulating arbitrary unrelated rational denominators over T terms would not establish the claimed width. Sine denominators are at least 2/M; powers have exponent 2r=O(m), and the underlying normalized ratio has magnitude at most one. Requesting O(m) additional guard bits controls division and powering. In particular no exponentially ill-conditioned denominator is present. Evaluate the final ratio M F_t D_H(t)/C with these enclosures and round to a dyadic with absolute error at most rho. Indeed Ctilde>=1/2 and the analytic sensitivity is at most 4M^2 epsilon, leaving ample final rounding allowance. The known exact F_t is used, not a rounded probability mass. Temporary exact rational arithmetic inside one scalar evaluation has polynomial bit width; scalar interval outputs are converted to the specified common dyadic grids before cross-coordinate accumulation.

Thus all tap preparation costs O((B+T) poly(m)), including O(Bm) taps. In this parameter regime T<=B. No per-output-coordinate evaluation of G, no full length-M Fourier transform, and no M-by-B table is prepared. The evaluator is an algorithmic specification; an actual source-level interval evaluator remains part of the implementation gate.

## 3. Buckets, normalization and unbiased randomness

For one round draw sigma=2A+1 from an (m-1)-bit uniform word A and tau from a fresh m-bit word. No rejection occurs. Rounds use disjoint independent bits, so their exact cost is (2m-1) bits each.

For j in {0,...,B-1}, define the ideal scaled bucket

    b_j = M^(-1/2) sum_t w_t v_(sigma*t+tau) omega^(-jTt).

Using (1) and the unitary inverse transform,

    b_j = sum_i z_i omega^(tau*i) G_(jT-sigma*i).  (4)

Compute buckets by folding supported products w_t v_(sigma*t+tau) into their t mod B bins, then a B-point radix-two FFT, then scaling by 1/sqrt(M). All W source accesses and all B log B FFT operations are paid.

Use the exact half-open hash

    h_sigma(i)=floor(((sigma*i mod M)+T/2)/T) mod B.

The circular offset jT-sigma*i at j=h_sigma(i) has magnitude at most T/2. Each bucket has exactly T preimages: enumerate residues jT-T/2,...,jT+T/2-1 mod M, then multiply by sigma^(-1) mod M. The inverse is computed by extended Euclid on O(m)-bit integers. Hence decoding a selected set of q buckets costs O(qT poly(m)); the unknown frequency locations are not assumed known.

## 4. A direct second-moment recovery lemma

For each i, the ideal undivided estimate is

    e_i=omega^(-tau*i) b_(h_sigma(i)).

No division by G is used. For fixed sigma, orthogonality of the uniform shift tau gives

    E_tau |e_i-z_i|^2
      = |G_(hT-sigma*i)-1|^2 |z_i|^2
        + sum_(l!=i) |z_l|^2 |G_(hT-sigma*l)|^2.

For nonzero d mod M and uniformly odd sigma,

    Pr[|sigma*d|_M <= C0] <= 4 C0/M              (5)

when 0<=C0<=M/2. To see this, write d=2^s u with u odd. The resulting odd residue modulo M/2^s is uniform. If C0<2^s the event is empty; otherwise the symmetric interval contains at most 2C0/2^s odd residues, out of M/2^(s+1). This proves (5).

If |hT-sigma*l|_M<=T, then |sigma(i-l)|_M<=3T/2, so (5) bounds that event by 6/B. Combining (2), (5) and Parseval yields the conservative bound

    E_(sigma,tau) |e_i-z_i|^2
       <= (24/B + 2delta^2) R^2.                (6)

For a=R/sqrt(k), Markov therefore gives

    Pr[|e_i-z_i|>a] <= 24k/B+2kdelta^2 <1/128. (7)

This follows from B>=4096k, k<=M and M>=4 in the sparse branch. The estimate is for every fixed i and arbitrary v in the stated domain. There is no spectral heavy-gap or tail-energy promise.

The total expected bucket energy also obeys

    E_tau sum_j |b_j|^2
      = sum_i |z_i|^2 sum_j G_(jT-sigma*i)^2
      <= (12+Bdelta^2)R^2.                     (8)

There are at most three centers jT within circular distance T of any residue; all remaining terms are at most delta^2. Thus, with K={j:|b_j|>=2a},

    E|K| <= (13/4)k,
    Pr[|K|>512k] <= 13/2048 <1/128.           (9)

This is the additional location argument that a known-coordinate second moment alone would not provide.

## 5. Robust selection, including ties

Suppose every computed bucket btilde_j differs from b_j by at most a/4. Select exactly q=512k buckets of largest computed squared magnitude, breaking ties by increasing bucket index. All squared-magnitude comparisons are exact comparisons of dyadic integers; no square-root comparison is needed.

Fix i with |z_i|>=4a. If |e_i-z_i|<=a then |b_(h(i))|>=3a, so |btilde_(h(i))|>=11a/4. Any bucket that ranks at least as high has ideal magnitude at least 5a/2>2a. Consequently, if |K|<=q, h(i) must be selected: excluding it would require q distinct other buckets in K in addition to h(i). This argument covers exact computed ties, exact threshold equality |z_i|=4a, and changed finite-versus-ideal sorting branches. It does not assume branch preservation or a spectral separation promise.

Equations (7) and (9) show that each heavy i is missed by one location round with probability less than 1/64, hence less than 1/16.

## 6. Finite-dyadic bucket and phase arithmetic

Approximate each supported w_t, each required FFT root, each required phase root and 1/sqrt(M) with absolute complex error at most rho. Roots can be stored on grid 2^(-(P+2)); certified evaluation plus final rounding establishes the bound. Coefficients and the scale are produced by section 2's finite interval route. Cache at most O(B+W) preparation data; per-candidate phases may instead be prepared on demand and charged.

Use exact integer/dyadic multiplication and addition for filtering, folding and every FFT butterfly. There is no uncharged arbitrary-precision operation: initial input widths are O_d(m), each FFT layer increases dyadic denominator width by at most P+2, and there are at most m layers. Numerator widths, denominator exponents and signed scratch widths are O_d(m^2). Schoolbook arithmetic therefore has polynomial bit cost in m. All index products use their exact O(m)-bit or O(2m)-bit values; no fixed-width wrap is allowed.

At the end of scaling a bucket, round each Cartesian component once to grid 2^(-P). When estimating a candidate, multiply that bucket by the approximated inverse phase exactly and round again to this same grid.

Here is an all-tape forward-error bound. By (3) and |v_t|<=sqrt(2), the exact raw products have l1 norm at most 2M^2. Approximating at most W<M taps changes that l1 norm by at most 2M rho. The approximate folded input thus has l1 norm at most 4M^2. Each FFT output coefficient is a product of at most b=log2 B approximate roots along its unique input-to-output path. Its difference from the ideal unit-modulus product is at most

    (1+rho)^b-1 <= 2b rho.

The FFT discrepancy against the exact transform of that folded input is consequently at most 8b M^2 rho. Adding the tap, scaling and final rounding discrepancies bounds every computed bucket by

    |btilde_j-b_j| <= 24(m+1)M^2 rho.

Also |b_j|<=2M^2. Including inverse-phase preparation and final estimate rounding gives

    |etilde_i-e_i| <= eta :=64(m+1)M^2 rho.     (10)

These deliberately loose bounds hold on every tape, without a successful-recovery amplitude hypothesis. Since m+1<=M and k<=M,

    eta = (m+1)M^(-14)/1024
        <= 1/(8sqrt(M)) < a/4.                (11)

Thus section 5's numerical hypothesis is established by a fixed precision independent of any norm query. All final numerators have O(m) bits: bucket and estimate magnitudes are bounded by a fixed multiple of M^2 and their denominator is 2^P. Intermediate O(m^2)-bit values are not returned to the downstream interface.

## 7. Global success probability, support and all-tape cost

Run L=4m+1 independent location rounds. Enumerate every preimage of their q selected buckets. Retain exactly those indices appearing in at least ceil(L/2) rounds, forming I'. Each round contributes exactly qT distinct indices, so on every tape

    |I'| <= 2qT.                              (12)

The complete temporary candidate list has at most LqT entries. Sorting this explicit list and counting repetitions costs O(LqT log(LqT)) comparisons of O(m)-bit indices. No length-M counter array is used.

Next use L fresh independent estimation rounds. Estimate all indices in I' from their buckets as in section 6. For each index return separate real and imaginary medians. These medians remain on the same dyadic grid; no additional rounding is required.

For a fixed index, independent bad-round probability at most 1/16 implies

    Pr[at least ceil(L/2) bad rounds]
      <= 2^L (1/16)^(L/2) = 2^(-L).

A union bound over the at most M heavy locations shows that all |z_i|>=4a enter I' except with probability M2^(-L). Independently, define the hypothetical estimate of every one of the M indices in the estimation rounds, even though the implementation computes only I'. A second union bound shows all coordinates have a strict majority of ideal estimates within a except with probability M2^(-L). This does not charge hypothetical computations to the algorithm; it is a probability proof on the same finite random tape. Alternatively condition on I' and use fresh estimation randomness.

On both events, included indices have median error at most sqrt(2)*(a+eta)<2a; omitted indices have magnitude less than 4a. Therefore

    ||ztilde-z||_infinity <=4a <=4M^(-beta)R.

The single simultaneous all-coordinate failure probability is at most

    2M2^(-L)=M^(-3)<=1/M.                     (13)

The guarantee is for every fixed input with fresh randomness, not one tape good for every input, and not merely a pointwise guarantee passed to interpolation without a union bound.

The exact random-bit count is 2L(2m-1). There is no rejection, retry, timeout, hidden entropy source or conditioning on successful tapes.

Preparation, all 2L bucket FFTs, all failed-round candidates, modular inverses, address arithmetic, source queries, squared-magnitude comparisons, candidate sorting, phase preparation, medians, serialization and storage are bounded by

    (B + T + W + LqT) poly_d(m)
      = O_(beta,d)(M^(1/2+beta) polylog M).     (14)

Indeed B<2M^(1/2+beta), W=O(Bm), T<=M^(1/2-beta), and kM/B<=2M^(1/2+beta). A fixed polynomial bit-arithmetic overhead is allowed and paid. This is an all-tape bound; (12) is combinatorial and does not invoke correctness. A concrete exponent can be extracted from the elementary interval and schoolbook routines, but no speed claim depends on minimizing it.

## 8. Dense finite exceptional branch

For lengths failing the exact sparse-branch predicates, evaluate each Fourier sum directly with individually prepared roots to absolute accuracy rho and an approximation to 1/sqrt(M) to that accuracy. Use exact dyadic products/sums, then one final P-grid rounding. Its coordinate error is at most 8M rho < M^(-beta)R under R>1/2 and beta<1/2. It has no random bits and no abort. Numerator and exponent widths remain O_d(m).

Its work is O(M^2 poly_d(m)), output support M and storage O(M poly_d(m)). This does not generally fit a sublinear bound. It fits (14) here only because the branch occurs at finitely many M for each fixed beta. The resulting beta-dependent constants can be extremely large. This device is an abstract all-length finite algorithm, not a claim of a useful implementation at those lengths. M=1, if needed outside the downstream use, is handled by exact identity output.

## 9. What this does and does not close

The displayed derivation is a constructive candidate for the precise normalized-domain E(beta) mathematical obligation. It uses HIKP's general filter/hash/rank architecture but reproves the weaker total-energy target, eliminating response division and the stronger tail-optimal obligation. It is not merely HIKP's ideal arithmetic theorem relabeled as finite.

Independent review must check the window normalization, circular boundary counts, exact coefficient construction and evaluator complexity, FFT perturbation/path accounting, unknown-frequency enumeration, sorting ties, exceptional-length argument and the simultaneous probability quantifiers. The next implementation gate is a source-pinned realization of ALGORITHM.txt and its certified rational-interval primitives, with exact arithmetic/resource instrumentation and separate tests. This packet supplies only new exact local controls and an implementation-level mathematical specification; it does not certify that any existing or historical executable meets it.

Until that review and realization are complete, preserve the accepted downstream transfer as conditional and do not promote the user's integrated finite-word engine to complete.
