"""Fresh Q16 deterministic step-6 phase correction and step-7 medians.

Supplied immutable buckets are data, not authenticated BUCKETS executions.
No randomness, response division, source scan, or recovery theorem is claimed.
The pinned accepted Scalar is actually invoked for every candidate phase.
"""
from dataclasses import dataclass
from compact_window import Ledger, Scalar, nearest_even, CertificationError


@dataclass(frozen=True)
class EstimateResult:
    numerators: tuple  # In the caller's strictly increasing candidate order.
    bits: int


@dataclass(frozen=True)
class MedianResult:
    pairs: tuple  # (frequency, (real numerator, imaginary numerator)).
    bits: int


@dataclass(frozen=True)
class PhaseCertificate:
    real: int
    imag: int
    bits: int
    real_interval: object
    imag_interval: object
    real_error_units: int
    imag_error_units: int


def _field(x, L):
    L.event('integer_field_attempt')
    return L.parameter(x)


def _geometry(M, P, L):
    L.event('geometry_validation')
    _field(M, L)
    _field(P, L)
    if M < 4 or M & L.sub(M, 1) or P < 8:
        raise ValueError('M must be a power of two >=4; P>=8 required')
    return L.sub(M.bit_length(), 1)


def _candidates(M, candidates, L):
    L.event('candidate_container_validation')
    if type(candidates) is not tuple:
        raise ValueError('exact immutable candidate tuple required')
    count = L.record('candidate_count', (), len(candidates))
    if count > M:
        raise ValueError('too many candidates')
    previous = -1
    for i in candidates:
        _field(i, L)
        L.event('candidate_read')
        if not 0 <= i < M or i <= previous:
            raise ValueError('candidates must be valid, sorted and distinct')
        previous = i
    return count


def _pair(pair, L, name):
    L.event(name + '_pair_validation')
    if type(pair) is not tuple:
        raise ValueError('exact Cartesian tuple required')
    size = L.record('pair_length', (), len(pair))
    if size != 2:
        raise ValueError('Cartesian pair must have two fields')
    _field(pair[0], L)
    _field(pair[1], L)


def _phase(M, P, tau, i, L):
    """Private valid-field routine. Every call pays for fresh Machin pi.

    Return on Q=P+2 grid with complex root error <=2^-P. Certificates stay
    separate from the numerical estimate interface.
    """
    Q = L.add(P, 2)
    J = L.add(P, 8)
    K = L.add(J, L.add(L.mul(2, L.add(J, 1).bit_length()), 16))
    if L.mul(64, L.add(K, 9)) > L.shift(L.sub(K, J)):
        raise CertificationError('phase working precision guard')
    scalar = Scalar(K, L)
    residue = L.mod(L.mul(tau, i), M)
    # cos(2*pi*r/M) and -sin(2*pi*r/M), each with exact reduction.
    real_interval = scalar.sin_pi(L.add(M, L.mul(4, residue)), L.mul(2, M))
    imag_interval = scalar.sin_pi(L.mul(-2, residue), M)
    unit = L.shift(L.sub(K, Q))
    denominator = L.mul(2, unit)
    values = []
    errors = []
    L.allocate(4)
    for a in (real_interval, imag_interval):
        n = nearest_even(L.add(a.lo, a.hi), denominator, L)
        center = L.mul(n, unit)
        error = max(abs(L.sub(center, a.lo)), abs(L.sub(center, a.hi)))
        values.append(n)
        errors.append(error)
        L.event('phase_scalar_round')
    error_sq = L.add(L.mul(errors[0], errors[0]), L.mul(errors[1], errors[1]))
    if error_sq > L.shift(L.mul(2, L.sub(K, P))):
        raise CertificationError('complex phase rho certificate')
    L.allocate(7)
    L.event('phase_preparation')
    return PhaseCertificate(values[0], values[1], Q, real_interval,
                            imag_interval, errors[0], errors[1])


def estimate_round(M, B, P, candidates, sigma, tau, numerators, bits, ledger=None):
    """ALGORITHM step 6 for one supplied deterministic round.

    Parse every candidate and every bucket component, even for no candidates.
    B is dyadic, 2<=B<=M/2; T=M/B. sigma is an odd residue and tau a residue.
    Bucket grid must equal P; arbitrary integer numerators are accepted and
    charged at their actual widths. No claim of BUCKETS origin is attached.
    """
    L = ledger if ledger is not None else Ledger()
    L.event('estimate_call')
    _geometry(M, P, L)
    for x in (B, sigma, tau, bits):
        _field(x, L)
    if B < 2 or B & L.sub(B, 1) or B > L.div(M, 2):
        raise ValueError('B must be dyadic with 2<=B<=M/2')
    if not 1 <= sigma < M or L.mod(sigma, 2) != 1 or not 0 <= tau < M:
        raise ValueError('odd residue sigma and residue tau required')
    if bits != P:
        raise ValueError('bucket grid must equal P')
    T = L.div(M, B)
    count = _candidates(M, candidates, L)
    L.event('bucket_container_validation')
    if type(numerators) is not tuple:
        raise ValueError('exact immutable bucket tuple required')
    size = L.record('bucket_count', (), len(numerators))
    if size != B:
        raise ValueError('bucket count differs from B')
    for pair in numerators:
        L.event('bucket_parse')
        _pair(pair, L, 'bucket')
    output = []
    L.allocate(count)
    half = L.div(T, 2)
    for i in candidates:
        residue = L.mod(L.mul(sigma, i), M)
        h = L.mod(L.div(L.add(residue, half), T), B)
        real, imag = numerators[h]
        L.event('bucket_access')
        phase = _phase(M, P, tau, i, L)
        real_product = L.sub(L.mul(real, phase.real), L.mul(imag, phase.imag))
        imag_product = L.add(L.mul(real, phase.imag), L.mul(imag, phase.real))
        divisor = L.shift(phase.bits)
        out_real = nearest_even(real_product, divisor, L)
        out_imag = nearest_even(imag_product, divisor, L)
        L.record('numerical_output_integer', (), out_real)
        L.record('numerical_output_integer', (), out_imag)
        output.append((out_real, out_imag))
        L.allocate(3)
        L.event('estimate_output')
    L.allocate(L.add(count, 2))
    L.record('numerical_output_integer', (), P)
    return EstimateResult(tuple(output), P)


def _sort(values, L):
    """Exact signed-integer bottom-up mergesort, including partial last runs."""
    n = L.record('sort_length', (), len(values))
    L.allocate(L.mul(2, n))
    src = list(values)
    dst = [None] * n
    L.event('sort_initial_copy', n)
    width = 1
    while width < n:
        step = L.mul(2, width)
        for start in range(0, n, step):
            middle = min(L.add(start, width), n)
            end = min(L.add(start, step), n)
            left, right = start, middle
            for out in range(start, end):
                if left >= middle:
                    take_left = False
                elif right >= end:
                    take_left = True
                else:
                    take_left = src[left] <= src[right]
                    L.event('sort_compare')
                if take_left:
                    dst[out] = src[left]
                    left = L.add(left, 1)
                else:
                    dst[out] = src[right]
                    right = L.add(right, 1)
                L.event('sort_copy')
            L.event('sort_merge')
        src, dst = dst, src
        width = step
        L.event('sort_pass')
    return src


def cartesian_medians(M, P, candidates, rounds, ledger=None):
    """Step 7 on an odd positive number of immutable EstimateResult rows.

    Retains zero coefficients; no extra numerical rounding. Returned pairs
    are sorted/distinct because candidate order is validated at entry.
    Supplying rows does not authenticate their origin or independent sampling.
    """
    L = ledger if ledger is not None else Ledger()
    L.event('median_call')
    _geometry(M, P, L)
    count = _candidates(M, candidates, L)
    L.event('round_container_validation')
    if type(rounds) is not tuple:
        raise ValueError('exact immutable tuple of estimate rows required')
    length = L.record('round_count', (), len(rounds))
    if length == 0 or L.mod(length, 2) != 1:
        raise ValueError('a positive odd number of rounds is required')
    for row in rounds:
        L.event('round_parse')
        if type(row) is not EstimateResult:
            raise ValueError('exact EstimateResult required')
        _field(row.bits, L)
        if row.bits != P or type(row.numerators) is not tuple:
            raise ValueError('estimate row grid/container mismatch')
        size = L.record('estimate_row_length', (), len(row.numerators))
        if size != count:
            raise ValueError('estimate row length differs from candidate count')
        for pair in row.numerators:
            L.event('estimate_parse')
            _pair(pair, L, 'estimate')
    middle = L.div(length, 2)
    output = []
    L.allocate(count)
    for column, i in enumerate(candidates):
        real = []
        imag = []
        L.allocate(L.mul(2, length))
        for row in rounds:
            a, b = row.numerators[column]
            real.append(a)
            imag.append(b)
            L.event('median_input_access')
        real = _sort(real, L)
        imag = _sort(imag, L)
        L.record('numerical_output_integer', (), i)
        L.record('numerical_output_integer', (), real[middle])
        L.record('numerical_output_integer', (), imag[middle])
        output.append((i, (real[middle], imag[middle])))
        L.allocate(4)
        L.event('median_output')
    L.allocate(L.add(count, 2))
    L.record('numerical_output_integer', (), P)
    return MedianResult(tuple(output), P)
