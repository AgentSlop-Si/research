Q16 phase estimation and Cartesian medians: independent ACCEPT.
Read REVIEW_REPORT.md for the exact accepted scope and exclusions.
VERDICT.json gives machine-readable scope; evidence/ contains successful independent controls and frozen input bindings.
Run python verify_review.py to verify this packet. Run fresh numerical controls only in a disposable copy because receipts are regenerated.
No full recovery, randomness, upstream provenance authentication, Sheet or GitHub changes are certified.
