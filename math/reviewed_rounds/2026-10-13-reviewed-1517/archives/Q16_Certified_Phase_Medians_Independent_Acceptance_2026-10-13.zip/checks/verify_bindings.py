"""Fresh byte/CRC/source binding check. Does not execute inherited programs."""
from pathlib import Path
import hashlib, json, zipfile
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT.parent
CAND=WORK/'q16_phase_medians_20261013'
ZIP=WORK/'Q16_Certified_Phase_Medians_Candidate_2026-10-13.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected='d02c18db66e662c45787780e4b0acb751c4b1098019de62ca526df51aba63366'
assert sha(ZIP.read_bytes())==expected
m=json.loads((CAND/'MANIFEST.json').read_text())
s=json.loads((CAND/'SEAL.json').read_text())
assert sha((CAND/'MANIFEST.json').read_bytes())==s['manifest_sha256']
for f in m['files']:
    b=(CAND/f['path']).read_bytes()
    assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
for p,h in s['source_pins'].items(): assert sha((CAND/p).read_bytes())==h,p
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(set(names))
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
    for n in names:
        if not n.endswith('/'):
            rel=n.removeprefix(CAND.name+'/')
            assert z.read(n)==(CAND/rel).read_bytes(),n
bindings=[
 ('src/phase_medians.py',ROOT/'sources/phase_medians.py'),
 ('src/compact_window.py',ROOT/'sources/compact_window.py'),
 ('src/compact_window.py',WORK/'q16_certified_buckets_20261013/src/compact_window.py'),
 ('sources/BUCKETS_SOURCE.txt',WORK/'q16_certified_buckets_20261013/src/buckets.py'),
 ('sources/LOCATION_SOURCE.txt',WORK/'q16_review/audit/sources/location_decode.py'),
 ('sources/ALGORITHM.txt',WORK/'q16_review/audit/sources/ALGORITHM.txt'),
 ('sources/PROOF.md',WORK/'q16_review/audit/sources/PROOF.md'),
 ('sources/ALGORITHM.txt',WORK/'q16_recovered_from_context_20261013/reconstructed/E_BETA_ALGORITHM_V1.txt'),
 ('sources/PROOF.md',WORK/'q16_recovered_from_context_20261013/reconstructed/E_BETA_PROOF_V1.md'),
]
results=[]
for p,q in bindings:
    a=(CAND/p).read_bytes();b=q.read_bytes()
    assert a==b,(p,str(q))
    results.append(dict(candidate=p,reference=str(q.relative_to(WORK)),sha256=sha(a)))
out=dict(status='PASS',archive_sha256=expected,manifest_entries=len(m['files']),
         archive_entries=len(names),byte_bindings=results,
         production_sha256=s['source_pins']['src/phase_medians.py'],
         candidate_library_file_id='libfile_9f54aeb595ac8191a6b030f25d9c588d',candidate_library_version=0,
         executed_historical_programs=False)
(ROOT/'evidence/BINDINGS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
