"""Independent deterministic Q16 estimator/median audit, written 2026-10-13.

No producer tests or inherited scientific programs are executed. The reviewed
candidate and its pinned accepted Scalar/Ledger primitives alone are imported.
The transcendental oracle uses pi=4(atan(1/2)+atan(1/3)), direct cos/sin Taylor
polynomials and exact rational error bounds; no production sine reduction.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from functools import lru_cache
from math import factorial
import ast, hashlib, itertools, json, random, sys, types
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'sources'))
sys.dont_write_bytecode=True
import phase_medians as c
COUNTS=Counter()
DETAILS={}

def check(b,tag='assertions'):
    COUNTS[tag]+=1
    if not b: raise AssertionError(tag)

def w(n):
    n=abs(n); ans=0
    while n:
        n//=2; ans+=1
    return max(ans,1)

def nearest(n,d):
    # Magnitude quotient, symmetric signed restoration; unlike production's
    # floor quotient and nonnegative remainder on signed n.
    sign=-1 if n<0 else 1
    q,r=divmod(abs(n),d)
    return sign*(q+int(2*r>d or (2*r==d and q%2)))

@lru_cache(None)
def pi_bounds(bits):
    n=bits+12
    out=[]
    for q in (2,3):
        s=sum((F((-1)**k,(2*k+1)*q**(2*k+1)) for k in range(n)),F(0))
        t=F((-1)**n,(2*n+1)*q**(2*n+1))
        out.append((min(s,s+t),max(s,s+t)))
    return 4*(out[0][0]+out[1][0]),4*(out[0][1]+out[1][1])

@lru_cache(None)
def root_bounds(M,r,bits):
    # Axes are algebraically exact. Otherwise use a centered angle without
    # production's rational-sine quadrant reduction or shifted cos formula.
    if 4*r%M==0:
        a,b=((1,0),(0,-1),(-1,0),(0,1))[(4*r//M)%4]
        return (F(a),F(a)),(F(b),F(b))
    if r>M//2:r-=M
    pl,ph=pi_bounds(bits+12)
    ends=sorted((-2*F(r,M)*pl,-2*F(r,M)*ph))
    mid=(ends[0]+ends[1])/2
    denom=1<<(bits+20)
    x=F(mid.numerator*denom//mid.denominator,denom)
    radius=max(abs(x-ends[0]),abs(x-ends[1]))
    n=max(36,(bits+40)//2)
    cs=F(0);sn=F(0);ct=F(1);st=x
    for k in range(n):
        cs+=ct;sn+=st
        ct=-ct*x*x/F((2*k+1)*(2*k+2))
        st=-st*x*x/F((2*k+2)*(2*k+3))
    cr=radius+F(4**(2*n),factorial(2*n))
    sr=radius+F(4**(2*n+1),factorial(2*n+1))
    return (max(F(-1),cs-cr),min(F(1),cs+cr)),(max(F(-1),sn-sr),min(F(1),sn+sr))

def far(z,interval):return max(abs(z-interval[0]),abs(z-interval[1]))
def scale(iv,a):return tuple(sorted((iv[0]*a,iv[1]*a)))
def exact_hash(M,B,sigma,i):
    # Enumerate the source's half-open inverse bucket cells, not floor formula.
    T=M//B;x=sigma*i%M
    choices=[j for j in range(B) if any((j*T+s)%M==x for s in range(-T//2,T//2))]
    check(len(choices)==1,'unique_hash_cell')
    return choices[0]

class Trace(c.Ledger):
    def __init__(self):
        super().__init__();self.rec=[];self.ev=[];self.alloc=[];self.par=[]
    def record(self,k,ins,out):
        self.rec.append((k,ins,out));return super().record(k,ins,out)
    def event(self,k,n=1):self.ev.append((k,n));return super().event(k,n)
    def allocate(self,n):self.alloc.append(n);return super().allocate(n)
    def parameter(self,n):
        if type(n) is int:self.par.append(n)
        return super().parameter(n)

def reconstruct(t):
    ops=Counter();work=0;storage=0;maximum=1
    rules={'add':lambda a,b:a+b,'subtract':lambda a,b:a-b,
           'multiply':lambda a,b:a*b,'floor_divide':lambda a,b:divmod(a,b)[0],
           'modulo':lambda a,b:divmod(a,b)[1],'binary_power':lambda a:2**a}
    for kind,inputs,out in t.rec:
        if kind in rules:check(rules[kind](*inputs)==out,'primitive_semantics')
        ws=[w(x) for x in (*inputs,out)]
        work+=16*(sum(ws)+2)**2;storage+=ws[-1]+1
        maximum=max(maximum,*ws);ops[kind]+=1
    for k,n in t.ev:ops[k]+=n
    slots=sum(t.alloc)
    if t.alloc:ops['allocated_slots']+=slots
    storage+=slots
    E=sum(ops.values())+256;D=maximum+w(E)+2
    expected=dict(arithmetic_bit_work_upper=work,bookkeeping_bit_work_upper=512*E*D*D,
                  total_bit_work_upper=work+512*E*D*D,cumulative_storage_upper_bits=storage+512*E*D,
                  max_observed_integer_bits=maximum,allocated_slots=slots,
                  parameter_input_bits=sum(map(w,t.par)),max_parameter_bits=max([1]+list(map(w,t.par))))
    got=t.report()
    check(got['operations']==dict(ops),'reconstructed_operation_counts')
    for k,v in expected.items():check(got[k]==v,'reconstructed_accounting_fields')
    COUNTS['traced_primitive_records']+=len(t.rec)
    return dict(records=len(t.rec),events=len(t.ev),allocation_records=len(t.alloc),**expected)

def reject(fn,*args,ledger=None):
    t=Trace() if ledger is None else ledger
    try:fn(*args,ledger=t)
    except ValueError:COUNTS['malformed_rejections']+=1
    else:raise AssertionError('malformed accepted')
    check(t.report()['total_bit_work_upper']>0,'rejection_charged')
    return t

def check_phase(module,M,P,tau,i):
    t=module.Ledger();z=module._phase(M,P,tau,i,t)
    ref=root_bounds(M,tau*i%M,P+30)
    err=[]
    for value,iv,claimed,limit in zip((z.real,z.imag),(z.real_interval,z.imag_interval),ref,
                                     (z.real_error_units,z.imag_error_units)):
        check(F(iv.lo,1<<iv.bits)<=claimed[0]<=claimed[1]<=F(iv.hi,1<<iv.bits),'independent_interval_containment')
        v=F(value,1<<z.bits);err.append(far(v,claimed))
        units=max(abs(value*(1<<(iv.bits-z.bits))-iv.lo),abs(value*(1<<(iv.bits-z.bits))-iv.hi))
        check(units==limit,'root_certificate_endpoints')
    check(err[0]**2+err[1]**2<=F(1,1<<(2*P)),'independent_complex_root_error')
    kw=P+8+2*(P+9).bit_length()+16
    check(t.operations['atan_term']==2*(kw+8),'paid_pi_preparation')
    check(t.operations['sine_evaluation']==2 and t.operations['phase_scalar_round']==2,'paid_scalar_preparation')
    check(z.bits==P+2,'root_grid')
    return z,ref

def check_estimate(module,M,B,P,I,sigma,tau,buckets,interval=True,trace=False):
    t=Trace() if trace else module.Ledger()
    out=module.estimate_round(M,B,P,I,sigma,tau,buckets,P,t)
    check(out.bits==P and len(out.numerators)==len(I),'estimate_shape_grid')
    for k,i in enumerate(I):
        j=exact_hash(M,B,sigma,i) if M<=256 else ((sigma*i%M+M//B//2)//(M//B))%B
        a,b=buckets[j];z=module._phase(M,P,tau,i,module.Ledger())
        want=(nearest(a*z.real-b*z.imag,1<<z.bits),nearest(a*z.imag+b*z.real,1<<z.bits))
        check(out.numerators[k]==want,'exact_fixed_point_product')
        check(max(w(v) for v in want)<=max(w(a),w(b))+3,'numerator_width_bound')
        if interval:
            re,im=root_bounds(M,tau*i%M,P+30)
            ar=scale(re,F(a,1<<P));bi=scale(im,F(b,1<<P))
            ai=scale(im,F(a,1<<P));br=scale(re,F(b,1<<P))
            rr=(ar[0]-bi[1],ar[1]-bi[0]);ii=(ai[0]+br[0],ai[1]+br[1])
            E=far(F(want[0],1<<P),rr)**2+far(F(want[1],1<<P),ii)**2
            bound=F(abs(a)+abs(b),1<<(2*P))+F(1,1<<P)
            check(E<=bound*bound,'independent_estimate_interval_error')
    K=len(I);kw=P+8+2*(P+9).bit_length()+16
    for name,n in {'bucket_parse':B,'candidate_read':K,'bucket_access':K,'phase_preparation':K,
                   'sine_evaluation':2*K,'atan_term':2*K*(kw+8),'nearest_even':4*K,
                   'numerical_output_integer':2*K+1}.items():
        check(t.operations[name]==n,'estimator_accounting_count')
    check(t.allocated_slots==16*K+2,'estimator_allocations')
    if trace:return out,t
    return out

def check_median(module,M,P,I,values):
    rows=tuple(module.EstimateResult(tuple(row),P) for row in values)
    t=module.Ledger();out=module.cartesian_medians(M,P,I,rows,t)
    n=len(rows);K=len(I)
    expected=tuple((i,tuple(sorted(row[col][k] for row in values)[n//2] for k in (0,1))) for col,i in enumerate(I))
    check(out.pairs==expected and out.bits==P,'independent_cartesian_median')
    for name,v in {'round_parse':n,'estimate_parse':K*n,'median_input_access':K*n,
                  'sort_initial_copy':2*K*n,'sort_copy':2*K*n*(n-1).bit_length(),
                  'nearest_even':0,'numerical_output_integer':3*K+1}.items():
        check(t.operations[name]==v,'median_accounting_count')
    check(t.allocated_slots==6*K*n+6*K+2,'median_allocations')
    return out

def numerical_controls():
    rng=random.Random(0xA16C07)
    for M in (4,8,16,32,64):
        for r in range(M):
            check_phase(c,M,8+(r%3)*11,M-1,(-r)%M)
    for M,P in ((128,41),(256,57),(1<<193,8),(1<<193,47)):
        for r in (1,M//4-1,M//4+1,M//2-1,M-1):check_phase(c,M,P,M-1,(-r)%M)
    for M in (4,8,16,32,64):
        for B in sorted({2,M//4,M//2}-{1}):
            for sigma in (1,M-1):
                for tau in (0,M//4,3*M//4):
                    b=tuple((713*j-211,317-997*j) for j in range(B))
                    out=check_estimate(c,M,B,8,tuple(range(M)),sigma,tau,b)
                    axes=((1,0),(0,-1),(-1,0),(0,1))
                    for i,v in enumerate(out.numerators):
                        a,b0=b[exact_hash(M,B,sigma,i)];u,v0=axes[(4*(tau*i%M)//M)%4]
                        check(v==(a*u-b0*v0,a*v0+b0*u),'exact_axis_hash_product')
    for M in (8,16,32,64,128):
        for P in (8,15,37):
            B=rng.choice((2,M//2));I=tuple(sorted(rng.sample(range(M),4)))
            b=tuple((rng.randrange(-(1<<(P+8)),1<<(P+8)),rng.randrange(-(1<<(P+8)),1<<(P+8))) for _ in range(B))
            check_estimate(c,M,B,P,I,2*rng.randrange(M//2)+1,rng.randrange(M),b)
    # Signed ties on the final product, including both parity choices and signs.
    z=c._phase(8,8,1,1,c.Ledger())
    tied=0
    for a in range(-1024,1025):
        if (a*z.real)%(1<<z.bits)==1<<(z.bits-1):
            check_estimate(c,8,2,8,(1,),1,1,((a,0),(a,0)))
            check_estimate(c,8,2,8,(1,),1,1,((0,a),(0,a)))
            tied+=1
    check(tied>0,'signed_halfway_witnesses')
    for H in (257,4097,17003):
        n=(1<<H)-1
        check_estimate(c,32,2,13,(7,),31,11,((n,-n),(-n,n)))
    for m in (57,97):
        check_estimate(c,1<<m,2,16*m+16,(0,),1,0,((13,-19),(0,0)),interval=False)
    for n in (1,3,5,7):
        for values in itertools.product((-2,0,3),repeat=n):
            check_median(c,8,11,(4,),[[(a,-2*a)] for a in values])
    for n in (9,11,15,17,31,65):
        values=[[(rng.randrange(-10000,10001),rng.randrange(-10000,10001)) for _ in range(4)] for _ in range(n)]
        check_median(c,16,18,(0,3,8,15),values)
    # Quantifier stress: the good rows can differ by candidate, while each
    # candidate has its own strict majority in a complex disk.
    for n in (3,5,9,21):
        I=(1,2,5);centers=((20,-30),(-71,62),(3,9));rows=[]
        for j in range(n):
            row=[]
            for col,(a,b) in enumerate(centers):
                if (j+col)%n<=n//2:
                    u,v=((3,4),(-3,4),(0,-5))[j%3];row.append((a+u,b+v))
                else:row.append(((-1)**j*10**6,(-1)**(j+col)*10**6))
            rows.append(row)
        out=check_median(c,8,8,I,rows)
        for (_,z),(a,b) in zip(out.pairs,centers):
            check((z[0]-a)**2+(z[1]-b)**2<=2*25,'strict_majority_disk_bound')
    # Distinct coordinate-majority sets need not share a strict majority.
    out=check_median(c,4,8,(0,),[[(0,10)],[(10,0)],[(0,0)]])
    check(out.pairs==((0,(0,0)),),'separate_coordinate_majorities')
    for n in (1,3,129,1025):check_median(c,8,8,(),[[]]*n)
    check_estimate(c,256,128,8,(),255,255,((0,0),)*128)
    check_estimate(c,64,8,11,(1,17,63),63,7,((0,0),)*8)

def malformed_controls():
    class Bad:
        def __int__(self):raise AssertionError('coercion')
        def __index__(self):raise AssertionError('index callback')
        def __lt__(self,other):raise AssertionError('comparison callback')
        def __len__(self):raise AssertionError('length callback')
    class Int(int):pass
    class Tup(tuple):pass
    class Est(c.EstimateResult):pass
    base=[16,4,9,(0,5,15),3,7,((1,2),(3,4),(5,6),(7,8)),9]
    bad_fields={0:[False,Int(16),Bad(),-16,0,2,12],1:[False,Int(4),Bad(),-2,0,1,3,32],
      2:[False,Int(9),Bad(),-2,7],3:[[],Tup((0,)),Bad(),tuple(range(17)),(-1,),(16,),
          (0,0),(7,2),(False,),(Int(3),),(Bad(),),(0,1<<32769)],
      4:[False,Int(3),Bad(),-1,0,2,16,1<<8193],5:[False,Int(7),Bad(),-1,16,1<<4097],
      6:[[],Tup(((1,2),)*4),Bad(),(),((1,2),)*3,((1,2),)*5,
          ((1,2),)*3+([3,4],),((1,2),)*3+(Tup((3,4)),),((1,2),)*3+((1,),),
          ((1,2),)*3+((1,2,3),),((1,2),)*3+((False,0),),((1,2),)*3+((0,Bad()),),
          ((1,2),)*3+((1<<32769,Int(1)),)],7:[False,Int(9),Bad(),8,10,-1,1<<65539]}
    traces=[]
    for pos,vals in bad_fields.items():
        for value in vals:
            args=list(base);args[pos]=value;t=reject(c.estimate_round,*args)
            if pos==7 and type(value) is int:check(t.max_parameter_bits>=w(value),'rejected_exponent_width')
            traces.append(t)
    good=c.EstimateResult(((1,2),(3,4)),9)
    cases=[([],), ((),), ((good,good),), ((Bad(),),), ((Est(good.numerators,9),),),
           ((c.EstimateResult(good.numerators,True),),),((c.EstimateResult([],9),),),
           ((c.EstimateResult(Tup(good.numerators),9),),),((c.EstimateResult((),9),),),
           ((c.EstimateResult(good.numerators,1<<4097),),),
           ((c.EstimateResult(((1,2),[3,4]),9),),),
           ((c.EstimateResult(((1,2),(3,)),9),),),
           ((c.EstimateResult(((1,2),(1<<32769,False)),9),),),
           ((c.EstimateResult(((1,2),(Int(3),4)),9),),)]
    for (rows,) in cases:traces.append(reject(c.cartesian_medians,16,9,(0,5),rows))
    for I in ([1],(5,0),(0,0),tuple(range(17)),(False,)):
        traces.append(reject(c.cartesian_medians,16,9,I,(good,)))
    # Empty candidates still parse malformed final bucket and row exponent.
    t=reject(c.estimate_round,16,4,9,(),3,7,((1,2),)*3+((1<<32769,False),),9)
    check(t.max_parameter_bits==32770 and t.operations['bucket_parse']==4,'empty_input_full_bucket_rejection')
    t=reject(c.cartesian_medians,16,9,(),(c.EstimateResult((),9),c.EstimateResult((),1<<32769),c.EstimateResult((),9)))
    check(t.max_parameter_bits==32770 and t.operations['round_parse']==2,'empty_input_row_rejection')
    # Reconstruct selected early/type/shape/late rejection executions, and a
    # cumulative ledger with successful estimates/median then later failure.
    sample=[traces[k] for k in (0,5,10,21,30,45,len(traces)-1)]
    out,t=check_estimate(c,32,8,12,(0,9,31),29,19,tuple((i*41-19,57-13*i) for i in range(8)),trace=True)
    c.cartesian_medians(32,12,(0,9,31),(out,out,out,out,out),t)
    before=t.report()['total_bit_work_upper']
    reject(c.estimate_round,16,4,9,(),3,7,((1,2),)*3+((1<<8193,False),),9,ledger=t)
    check(t.report()['total_bit_work_upper']>before,'cumulative_failed_call_retained')
    sample.append(t);DETAILS['accounting_reconstructions']=[reconstruct(a) for a in sample]

def proof_controls():
    for P in list(range(8,4097))+[2**j-9 for j in (14,18,22)]:
        J=P+8;K=J+2*(J+1).bit_length()+16
        check(64*(K+9)<=(1<<(K-J)),'universal_guard_samples')
        check(F(1,1<<3)+F(1,1<<9)<F(1,4),'normalized_root_round_margin')
    for m in (2,3,7,23,53,99,271,1031):
        M=1<<m
        for P in (8,16*m+16):
            rho=F(1,1<<P);D=24*(m+1)*M*M*rho;A=2*M*M
            check((1+rho)*D+A*rho+rho<=64*(m+1)*M*M*rho,'source_error_constant')
    tree=ast.parse((ROOT/'sources/phase_medians.py').read_text())
    names={n.func.id for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
    check(not names&{'float','complex','eval','exec','sorted','round'},'no_hidden_numeric_primitives')

def mutation_suite(module):
    # Compact but distinctive fresh adversarial test set; no producer smoke.
    check_phase(module,32,11,13,7)
    for tau in (0,1,5,24):
        check_estimate(module,32,8,8,(0,1,2,7,10,11,13,30,31),29,tau,
                       tuple((19+103*j,-257+47*j) for j in range(8)),interval=True)
    for a,b in ((-512,0),(-384,0),(384,0),(-384,384),(-128,128),(128,-128),(384,-384),(0,-513),(513,0)):
        check_estimate(module,8,2,8,(1,),1,1,((a,b),(a,b)))
    check_estimate(module,16,4,8,(),3,1,((0,0),)*4)
    check_median(module,8,8,(0,7),[[(-7,100),(9,-13)],[(3,2),(1,17)],[(4,88),(0,19)],[(99,-4),(-3,20)],[(0,70),(-2,-1)]])
    check_median(module,8,8,(),[[]]*7)
    for args in [(8,2,8,(2,2),1,0,((0,0),)*2,8),
                 (8,2,8,(),1,0,((0,0),)*2,9),
                 (8,2,8,(),1,0,((0,0),(False,0)),8),
                 (8,2,8,(False,),1,0,((0,0),)*2,8)]:reject(module.estimate_round,*args)
    reject(module.cartesian_medians,8,8,(),(module.EstimateResult((),8),)*2)
    reject(module.cartesian_medians,8,8,(0,),(module.EstimateResult(((1,2),),9),))

def mutations():
    source=(ROOT/'sources/phase_medians.py').read_text()
    changes=[
      ('phase_uses_sigma','phase = _phase(M, P, tau, i, L)','phase = _phase(M, P, sigma, i, L)'),
      ('wrong_period','residue = L.mod(L.mul(tau, i), M)','residue = L.mod(L.mul(tau, i), L.div(M, 2))'),
      ('phase_conjugate','scalar.sin_pi(L.mul(-2, residue), M)','scalar.sin_pi(L.mul(2, residue), M)'),
      ('phase_cosine_shift','L.add(M, L.mul(4, residue))','L.add(L.mul(2, M), L.mul(4, residue))'),
      ('hash_affine_shift','residue = L.mod(L.mul(sigma, i), M)','residue = L.mod(L.add(L.mul(sigma, i), tau), M)'),
      ('hash_right_closed','L.add(residue, half)','L.add(residue, L.sub(half, 1))'),
      ('missing_hash_wrap','h = L.mod(L.div(L.add(residue, half), T), B)','h = L.div(L.add(residue, half), T)'),
      ('product_cross_terms','L.mul(imag, phase.imag)','L.mul(imag, phase.real)'),
      ('product_imaginary_sign','L.add(L.mul(real, phase.imag), L.mul(imag, phase.real))','L.sub(L.mul(real, phase.imag), L.mul(imag, phase.real))'),
      ('double_denominator','divisor = L.shift(phase.bits)','divisor = L.shift(L.add(phase.bits, 1))'),
      ('imaginary_round_floor','out_imag = nearest_even(imag_product, divisor, L)','out_imag = L.div(imag_product, divisor)'),
      ('ties_to_positive','out_real = nearest_even(real_product, divisor, L)','out_real = L.div(L.add(real_product, L.div(divisor, 2)), divisor)'),
      ('skip_final_bucket_parse','for pair in numerators:','for pair in numerators[:-1]:'),
      ('allow_equal_candidate','i <= previous','i < previous'),
      ('skip_bucket_grid','if bits != P:','if False:'),
      ('skip_row_grid','if row.bits != P or type(row.numerators) is not tuple:','if type(row.numerators) is not tuple:'),
      ('root_event_undercharge',"L.event('phase_preparation')","L.event('omitted_phase')"),
      ('preparation_round_undercharge',"L.event('phase_scalar_round')","L.event('omitted_phase_round')"),
      ('output_width_undercharge',"L.record('numerical_output_integer', (), out_imag)","L.event('omitted_output')"),
      ('temporary_storage_undercharge','L.allocate(7)','L.allocate(1)'),
      ('wrong_middle','middle = L.div(length, 2)','middle = L.div(L.add(length, 2), 2)'),
      ('median_swap_coordinates','real.append(a)','real.append(b)'),
      ('median_no_initial_copy_charge',"L.event('sort_initial_copy', n)","L.event('omitted_sort_initial_copy')"),
      ('median_even_extension','if length == 0 or L.mod(length, 2) != 1:','if length == 0:'),
      ('skip_last_sort_cell','for out in range(start, end):','for out in range(start, end-1):'),
    ]
    results=[]
    for idx,(name,a,b) in enumerate(changes):
        assert a in source
        mod=types.ModuleType('fresh_reviewer_mutant_'+str(idx));sys.modules[mod.__name__]=mod
        exec(compile(source.replace(a,b),str(ROOT/'sources/phase_medians.py')+'#'+name,'exec'),mod.__dict__)
        try:mutation_suite(mod)
        except (AssertionError,ValueError,ArithmeticError,IndexError,TypeError) as e:
            results.append(dict(name=name,detected=True,exception=type(e).__name__,control=str(e)[:160]))
        else:results.append(dict(name=name,detected=False))
        del sys.modules[mod.__name__]
    if not all(x['detected'] for x in results):
        raise AssertionError('undetected mutants: '+repr([x['name'] for x in results if not x['detected']]))
    check(True,'all_fresh_mutants_detected')
    DETAILS['mutants']=results

if __name__=='__main__':
    numerical_controls();malformed_controls();proof_controls()
    baseline=dict(COUNTS)
    mutations()
    result=dict(status='PASS',baseline_counts=baseline,counts_including_mutants=dict(COUNTS),
                oracle='Exact pi=4(atan(1/2)+atan(1/3)); direct cosine/sine Taylor with rational tails and pi-radius',
                producer_tests_executed=False,historical_programs_executed=False,**DETAILS)
    (ROOT/'evidence/INDEPENDENT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
