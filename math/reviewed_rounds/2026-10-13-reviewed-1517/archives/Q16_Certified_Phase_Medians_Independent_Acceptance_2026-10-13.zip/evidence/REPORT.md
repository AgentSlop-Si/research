# Q16 deterministic inverse-phase estimation and Cartesian medians

13 October 2026. New producer candidate; separate independent review required.

## Result and scope

This implements exactly the deterministic numerical work selected from ALGORITHM.txt steps 6 and 7: compute the half-open frequency hash, prepare the inverse phase with a paid certified finite scalar routine, multiply the supplied bucket by that phase exactly, round each Cartesian component once to the P grid, and take the two coordinate medians over an odd positive number of rounds. It pays to parse all candidates and all B bucket pairs. It never divides by the response G. PROOF.md section 4 expressly specifies an undivided estimate.

The accepted location decoder covers ranking, preimages and membership thresholding only. Its output is a compatible sorted distinct candidate tuple; neither that acceptance nor this candidate authenticates a supplied tuple's origin or grants independent randomness. The accepted BUCKETS payload has exactly the input representation used here. It is inspected as source evidence and is not executed in this packet.

This packet invokes the independently accepted compact-window v2 module only for its unchanged Ledger, Scalar, signed nearest-even primitive and CertificationError. It genuinely performs the Scalar computation for every candidate phase; no cached pi, supplied roots or uncharged preparation receipt is accepted. No historical unapproved program is run.

Not covered: random scheduling or independence, beta-dependent parameter generation, numerical WINDOW or BUCKETS composition, decoder execution, full recovery, the dense fallback, the outer transfer, all-length integration, host totality, physical RAM/time, practical speed and worldwide novelty. The exact recovered E(beta) mathematical premises remain inherited; this is not a fresh audit of all of E(beta) or P05. No Sheet, repository, access permission or publication is changed.

## Exact interfaces

`estimate_round(M, B, P, candidates, sigma, tau, numerators, bits, ledger=None)` returns `EstimateResult(numerators, bits=P)`. Returned numerator pairs are in the same strictly increasing candidate order. The result has no root certificates, accounting integers or wide diagnostics in its numerical payload.

- M is an exact power-of-two integer >=4, P an exact integer >=8.
- B is an exact power of two, 2<=B<=M/2; thus T=M/B is an even positive integer. This reduced domain contains the sparse theorem geometry.
- Sigma is an exact odd residue 1<=sigma<M; tau an exact residue 0<=tau<M. These inputs are not drawn by this module.
- Candidates is an exact immutable tuple of K<=M exact integer indices, strictly increasing and in [0,M). K=0 is supported.
- Numerators is an exact immutable B-tuple of exact two-tuples of signed exact integers. Bits is an exact integer and must equal P. Every pair and both fields are parsed before computation even when K=0. Arbitrary represented numerator widths are allowed and charged.
- No coercions, booleans, integer subclasses, mutable containers, tuple subclasses or scientific callbacks are accepted. All reached fields have their actual widths charged before numeric-domain rejection. Trusted instrumentation objects are not adversarial scientific inputs.

`cartesian_medians(M, P, candidates, rounds, ledger=None)` returns `MedianResult(pairs, bits=P)`, where pairs is a tuple of `(frequency,(real numerator, imaginary numerator))`. Every zero coefficient is retained, which the source explicitly permits. No output index sort is necessary because candidate order was checked.

Rounds is an exact immutable tuple of L>0 exact `EstimateResult` objects; L must be odd. Every row must have exponent P and exactly K pairs; all fields are parsed even for K=0. There is no even-length median extension. Source L=4m+1 is odd, so the unique middle real value and unique middle imaginary value implement step 7 unambiguously. EstimateResult carries no candidate identities. The caller must preserve the same candidate ordering across every row; equal row lengths alone do not establish that binding. Frozen dataclasses contain immutable accepted tuples; deliberate mutation through Python internals is outside this deserialization interface.

The BUCKETS numerical adapter is `estimate_round(M,B,P,I,sigma,tau,b.numerators,b.bits,ledger)` for a genuine accepted b from matching M,B,P,sigma,tau. The caller must preserve upstream work and verify matching parameters; `BucketResult` does not carry M/B/sigma/tau provenance. Likewise a decoder majority tuple provides I, but its support bound K<=2qT remains the decoder/caller's obligation. The broader standalone estimator only imposes K<=M.

A shared ledger retains actual cumulative charges. Reusing it never waives this call's validation or preparation. Supplied in-memory input storage belongs to the caller; input parsing, created auxiliaries and returned numerical encodings are charged here. External file formats and disk/network I/O are not implemented or claimed.

## Phase construction and certification

Set rho=2^-P, Q=P+2, J=P+8 and Kwork=J+2 bit_length(J+1)+16. All parameter arithmetic is exact and recorded. Verify

    64(Kwork+9) <= 2^(Kwork-J).

This holds for every P>=8: bit_length(J+1)<=(J+1)/2 for J>=16, so Kwork+9<=2J+26<=4(J+1), whereas 2^(Kwork-J)>2^16(J+1)^2. This is a proved guard, not a cap or timeout.

For each candidate i prepare a new `Scalar(Kwork,L)`, including its finite alternating Machin pi evaluation. Compute r=(tau*i) mod M using the full exact product. Its real and imaginary phase intervals are

    sin(pi (M+4r)/(2M)),  sin(pi (-2r)/M).

They enclose cos(2pi r/M) and -sin(2pi r/M), hence p=exp(-2pi i tau i/M). Exact rational argument reduction is inside the accepted Scalar. Singular axes use exact sine values. Neither an inverse modular index nor the affine sample shift enters this phase formula.

The accepted Scalar constructs enclosing integer intervals at Kwork bits using Kwork+8 predetermined terms and the proved Taylor/Machin bounds. Each interval has width <=64(Kwork+9)2^-Kwork<=2^-J. Its midpoint is rounded nearest-even to Q bits. Every point in the interval then differs from the rounded value by at most

    2^(-Q-1) + 2^(-J-1) = rho/8 + rho/512 < rho/4.

Thus the complex root error is <rho. The source independently checks the exact squared sum of endpoint-distance bounds against 2^(2(Kwork-P)); no square root or floating comparison is used. Certificates remain temporary, separate from the returned estimates. Preparation performs two scalar evaluations and two preparation roundings for every candidate, including axes and zero buckets; it does not skip their costs based on numerical success.

## Exact hash, multiplication and rounding

For each candidate compute x=(sigma*i) mod M and h=floor((x+T/2)/T) mod B. All products are exact; the final modulo handles the wrap at bucket zero. This is the source's half-open convention. Tau affects phase only.

If the selected bucket is (a+ib)2^-P and the prepared inverse phase is (u+iv)2^-Q, compute integers au-bv and av+bu. Their exact common denominator is 2^(P+Q). Divide only by 2^Q when rounding the numerators nearest-even to the required P grid. This is fixed-point scaling, not response division. Negative inputs use floor quotient plus nonnegative remainder, with exact comparison of twice the remainder to the positive denominator and odd-quotient tie detection. There is no intermediate rounding of the product.

## Every-path forward error

Let p be the exact inverse phase, phat its prepared approximation, bt the supplied numerical bucket and b an ideal bucket. Let |phat-p|<=rho, |bt-b|<=D and |b|<=A. Final coordinate rounding gives complex error <=rho/sqrt(2)<=rho. Therefore for every valid deterministic input,

    |et-pb| <= (1+rho)D + A rho + rho.

For an arbitrary supplied bucket, taking D=0 and b=bt gives the independently testable generic phase-only bound

    |et-pbt| <= (|a|+|b|) rho^2 + rho,

where a,b on the right are its signed P-grid numerators. This bound does not assume the input came from BUCKETS and allows arbitrarily wide data.

For a genuine accepted theorem-parameter BUCKETS result, inherit D=24(m+1)M^2 rho and A=2M^2. As rho<=1,

    (1+rho)D + A rho + rho
      <= [48(m+1)M^2 + 2M^2 + 1] rho
      <= 64(m+1)M^2 rho.

The final inequality holds for m>=2, M>=4. In particular it holds at P=16m+16. This proves exactly the source's section 6 estimate-error bound under its accepted BUCKETS premise. It holds for every permitted sigma,tau and every bounded input, with no successful-recovery amplitude assumption. Arbitrary supplied bucket tuples do not acquire this stronger bound merely by passing parsing.

## Median correctness and deterministic robustness

The explicit signed-integer bottom-up mergesort doubles run length on every pass. Before each pass all runs of that length are ordered; merging takes the smaller available item, advances one pointer, and fills each output position once. Partial final runs are included. After ceil(log2 L) passes the array is ordered. Exact equal integers need no tie-dependent numerical rule.

Separate real and imaginary arrays are formed for each candidate; select index floor(L/2). A common positive P-grid denominator preserves signed comparisons. No numerical rounding is performed in this phase, and the output pairs remain sorted/distinct by their validated indices.

If strictly more than L/2 supplied estimates lie within complex distance e of a target z, then more than L/2 real coordinates lie in [Re z-e, Re z+e], and similarly for imaginary coordinates. Each median must lie in its coordinate interval, so the returned complex value has error <=sqrt(2)e. Taking e=a+eta yields the source's median step when its separate probabilistic majority premise has been proved. This module establishes no such probability, independence or recovery event.

## Widths, finite work and cumulative auxiliary storage

Use the same conservative finite-bit source model as the accepted predecessors. Every primitive records operand and produced integer widths and charges 16(2+sum widths)^2, enough for schoolbook arithmetic, signed division/remainder, shifts, bit lengths and comparisons at those widths. Every reached represented integer field contributes to parameter-width totals. Explicit numerical-output-integer records pay the complete returned numerators, indices where present, and exponent encoding; they are not just output-slot counts.

The report then sets E=sum(all recorded event counts)+256 and Dmax=max observed integer width+bit_length(E)+2. It adds 512 E Dmax^2 for control/index/comparison bookkeeping, and bounds cumulative auxiliary storage by recorded produced-integer bits plus 512 E Dmax. Each nonconstant loop has recorded arithmetic, events or batch allocation. Constant-arity tuple, interval and certificate construction, rejection branches, primitive instrumentation and fixed-arity list access are covered by this envelope. This is a mathematical source-level model; it is not a Python VM instruction certificate or physical peak-memory measurement. Out-of-band repeated instrumentation calls are not part of the scientific API.

Let H be the maximum reached bucket numerator width, m=log2 M, and p=P+1. Kwork=O(p+log p). Per root the Scalar uses O(p) terms/iterations; its largest rational-grid integer, factorial and Machin denominators have O(p log(p+1)) bits. Phase/address products have O(m) bits, including a 2m-bit tau*i product; multiplying by the phase has width O(H+p). Thus valid estimation scratch widths are O(H+m+p log(p+1)), before address/event-counter widths. The bit length of P itself and every other raw field are also recorded. No O(m) bound is asserted for arbitrary standalone H or arbitrary P.

Estimator event count is O(B+K(1+p)), including complete validation for K=0. Its precise successful counts are B bucket parses, K candidate reads, K selected-bucket accesses, K phase preparations, 2K sine evaluations, 2K(Kwork+8) Machin atan terms, 4K nearest-even calls (two root and two estimate), 2K+1 numerical integer outputs and 16K+2 allocated slots. Non-axis Taylor/factorial counts depend only on fixed target precision and exact-axis branches, and are recorded. No length-M array is created by this component.

For L odd median rows and K candidates, successful parsing includes L rows and LK pairs. There are KL coordinate-pair accesses, 2K sorts, 2KL ceil(log2 L) merge output copies, zero numerical roundings, 3K+1 numerical integer output records and 6KL+6K+2 allocated slots. Event count is O(L+K+KL(1+log(L+1))). Integers have width O(H+m+log(L+1)+bit_length(P)); output numerators are selected existing integers. K=0 still pays O(L) row recognition.

Estimate output numerators have at most H+3 bits: each phat Cartesian component has magnitude <=1+rho, so an output component numerator is at most (|a|+|b|)(1+rho)+1/2<2^(H+2) for H>=1. A median never increases a component width. Hence genuine BUCKETS payloads with H=O_d(m) and P=16m+16 yield O_d(m)-bit numerical outputs, while the phase/scratch widths are polynomial in m and are charged in full.

For the theorem caller K<=2qT and L=4m+1, all L estimates plus medians cost O((LB+LK)poly_d(m)) and auxiliary storage O((B+LK)poly_d(m)); retained supplied input storage and already-paid preceding stages are additive caller obligations. The implementation deliberately reparses I and B buckets every round and regenerates pi per candidate; these are included, not optimized away. This fits the intended M^(1/2+beta) polylog M component bound conditional on the accepted parameter/support premises.

Malformed paths retain all reached widths, primitive results, partial loops, allocations and already completed earlier calls in a shared ledger. Type/shape checks occur before arithmetic/coercion on foreign objects. Invalid grids are rejected before allocating a denominator using the mismatched input exponent. Valid paths contain no random rejection, unbounded refinement, retry, numerical cap, capacity timeout or silent overflow. CertificationError denotes a violated proved invariant, not an allowed failure event. Providing the proved finite resources remains an abstract-machine assumption; actual host limits are not hidden or claimed solved.

## Controls and reproducibility

`tests/reference.py` is a fresh exact-Fraction oracle. It uses independently formed alternating rational Machin bounds and an exact rational Taylor polynomial plus explicit remainder and pi-radius error. It does not import production arithmetic. Exact product comparisons use independently implemented nearest-even selection and an equivalent independently written half-open hash. Axis controls require no transcendental oracle. These tests are producer controls awaiting separate independent review.

`tests/run_tests.py` checks root complex-error certificates against rational enclosures, enclosure containment, exact fixed-point outputs, generic phase-only forward error, every-axis hash boundaries, exhaustive signed/tied median tuples, column separation, deterministic median robustness, 65,536-bit fields, source-target precision, zero-candidate recognition and malformed type/shape/width paths. Large target-precision axis controls are reduced deterministic fixtures, not full theorem-scale sparse-recovery runs.

`tests/adversarial_controls.py` independently reconstructs the primitive semantics, binary widths, arithmetic charge, bookkeeping envelope, allocated-slot total, input widths and cumulative storage after both success and later malformed calls. It exercises source mutants for phase sign/argument, hash endpoints/wrap, complex-product signs, fixed-point scaling, signed rounding, candidate/grid recognition, phase/bucket/output/sort charges, tuple allocation, median index/coordinate and odd-round semantics. Frozen production bytes are never modified; mutants are in-memory copies of this new source. Test-only sorting and Fraction arithmetic are not counted as production work.

See results/checks.json and results/adversarial_checks.json for the completed counts and receipts. Verify MANIFEST.json and SEAL.json first using verify_package.py. Then, in a disposable copy preserving the frozen packet, run both test scripts with Python 3.12 and its standard library. Scripts rewrite their result receipts. No network, credentials, third-party numerical package or historical scientific executable is required.

## Frozen source anchors

Production source SHA256: 45c0c6a59cac18912278dcda183fe8e5bea2a19398cb61fc1bf8ec97cac5a788.

- src/phase_medians.py lines 34–36: _field.
- src/phase_medians.py lines 39–45: _geometry.
- src/phase_medians.py lines 48–62: _candidates.
- src/phase_medians.py lines 65–73: _pair.
- src/phase_medians.py lines 76–110: _phase.
- src/phase_medians.py lines 113–164: estimate_round.
- src/phase_medians.py lines 167–200: _sort.
- src/phase_medians.py lines 203–255: cartesian_medians.

Final completed producer controls: 7037 assertions; 20 targeted mutants detected; 6585 primitive records independently reconstructed. Full counts are in the sealed JSON receipts.
