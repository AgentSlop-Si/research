# Independent review: b31 original-tau all-A overlap

13 October 2026 UTC. Family F020. Verdict: **ACCEPT AT THE EXACT STATED SCOPE**.

The sealed candidate is `next_cycle_b31_overlap`. Its manifest SHA-256 is
`9e6a858a106e337232311140edfffb9114f4c522ca0208b378704e386e4ce07c`.
Its archive SHA-256 is
`6564648c025fdbe152bada81360f060798a831f6979fcaff4b0c3032d1c7c880`.

There is no mathematical repair request. This review accepts the fixed-b31 theorem below and its complete lower/middle/tail partition. It does not promote historical novelty, arbitrary-b overlap, general reciprocal support, positive characteristic, or FFT performance. The original author packet and its “review pending” labels remain unchanged; this separate review records acceptance.

## 1. Accepted theorem and outcome

Let K be a characteristic-zero field and q have primitive odd order d>31. Gaussian coefficients are integral polynomials specialized at q. Set

H31(z;q) = sum(j=0..31) Gaussian(31,j;q) z^j,
g = H31′(−1;q),
W = product(r=1..31)(1−q^r) / product(r=1..(d+31)/2)(1−q^(2r)),
tau = d W/g.

For the monic probabilists’ Hermite polynomials, set

J_(A+1)(x;tau) = x He_A(x) − A tau He_(A−1)(x).

Every denominator in these definitions is nonzero, and Disc_x J_(A+1) is nonzero for every integer A>=1. This applies to all primitive embeddings, including composite odd d, and to every such characteristic-zero K.

Coverage is exactly:

- 16 lower odd orders 33..63, using rho=|tau−1|²<=1 at the principal embedding.
- 88 middle odd orders 65..239, using independently verified primitive conjugates with rho>8/3.
- Every odd order >=241, using a proved infinite tail.
- A=1 and A=2 are handled algebraically by nonreality. For A>=3 one arbitrary-index repeated-root annulus suffices.
- No finite-A bridge is needed. No finite scan is used to infer an infinite theorem.

The weakest middle certificate remains d=65,k=14:

2749352/1000000 <= rho <= 2749353/1000000,
2749352/1000000 − 8/3 = 248056/3000000 > 0.

All 88 fresh original-route parameter reconstructions, all saved parameter routes, every saved rho interval, and all 15,268 saved positive norm guards passed exact containment checks. The review reconstructs the full integer derivative, including its degree 240, constant term 16, and negative relation to P15(−2).

## 2. Original tau and nonzero denominators

Write d=2h+1 and b=2m+1 with m=15. Introduce

B_j = product(r=1..j)(1−q^(2r)),
s_j = product(r=1..j)(1−q^(2r−1))/(1−q^(2r)),
S_j = sum(r=0..j)s_r, E=B_h.

The Gaussian degree recurrence, evaluated and differentiated at z=−1, gives

H_(2m)(−1) = product(r=1..m)(1−q^(2r−1)),
g_m = product(r=1..m)(1−q^(2r−1)) + (1−q^(2m))g_(m−1),
g_0=1.

Dividing the last recurrence by B_m yields g_m=B_m S_m. This review obtains the Gaussian polynomials by exact ascending polynomial division of the multiplicative quotient identity. Every division is checked by multiplication back, and every Gaussian degree j(31−j) is checked. Taking the alternating derivative sum gives the same integer polynomial as the differentiated recurrence, with all 241 coefficients checked against both candidate and accepted residual data.

At degree d, every nonboundary Gaussian coefficient is zero: its numerator contains 1−q^d and its denominator has indices below d. Thus H_d=1+z^d, so H_d′(−1)=d and E S_h=d.

The uncancelled W denominator has h+16=(d+31)/2 factors. The final 16 even exponents, reduced modulo d, are precisely 1,3,...,31. Cancelling only these factors from the original formula gives

W=B15/E, tau=d/(E S15)=S_h/S15.

The inequality h+16<d holds already at d=33. Since q and q² have order d, no original root-factor denominator vanishes. No factor at index d is silently admitted.

At the principal embedding let v=pi/d. Each s_j has the form a_j exp(−ijv), where a_j is the positive sine-ratio product. Because hv<pi/2, S15 has positive real part and is nonzero. Also

Im((S_h−S15) conjugate(S15))
= −sum(j=16..h) sum(r=0..15) a_j a_r sin((j−r)v) < 0.

The sum is nonempty even at the first order d=33. All the displayed angles lie strictly between 0 and pi/2. Therefore tau is nonreal. An automorphism of the cyclotomic field commutes with complex conjugation; it preserves nonvanishing of tau−conjugate(tau), so every primitive conjugate is nonreal. This transports nonreality, not a norm bound or the sign of the imaginary part.

Finally H31=(z+1)z^15 P15(z+z^−1) implies g=(−1)^15 P15(−2)=−P15(−2). The sign is rederived, not imported from even m=14. Original W, with its complete denominator, and the freshly reconstructed original derivative are evaluated before using the prefix comparison. Mathematical equality of routes follows from these identities; overlapping numerical enclosures alone are not treated as an identity proof.

## 3. All-A repeated-root obstruction

A=1 gives J=x²−tau, with discriminant 4tau. A=2 gives J=x(x²−1−2tau), with discriminant 4(1+2tau)³. Nonreality excludes both exceptional values. More generally the constant or linear Hermite coefficient shows that a repeated zero root would require tau=0 for odd A, or tau=−1/A for even A; these are real and impossible here.

At a nonzero repeated root x, He_(A−1)(x) cannot vanish. Otherwise J=0 forces He_A(x)=0, and descending the Hermite recurrence would force He_0=0. Differentiating and eliminating gives

y=x² = tau(1+A tau)/(tau−1)
       = A tau+(A+1)+(A+1)/(tau−1).

The exclusions tau=0 and tau=1 are supplied by nonreality. No singular elimination case is dropped.

For A+1=2r+s, s in {0,1}, put P_r^(s)(y)=He_(2r+s)(x)/x^s. The factorial formula for Hermite coefficients gives the monic three-term recurrence with diagonal 4j+2s+1 and squared subdiagonal 2j(2j+2s−1). Equivalently,

J=x^s det(yI−M),
M=M0+A(tau−1)e_r e_r^T,

where M0 is real symmetric irreducible tridiagonal. A last-diagonal change subtracts A(tau−1)P_(r−1)^(s), exactly converting He_(A+1) to the specified J. The final diagonal is A−1+A tau. This derivation is valid at arbitrary r, rather than extrapolated from the accompanying finite controls.

Because x is nonzero, repetition in x implies repetition in y. Irreducible tridiagonality forces a one-dimensional eigenspace and a nonzero last coordinate in an eigenvector u. A repeated eigenvalue therefore supplies a Jordan chain (M−yI)w=u. Complex symmetry gives u^T u=0. Taking absolute values in the last-coordinate identity yields

0 < t=|u_r|²/||u||² <= 1/2.

This step uses a bilinear transpose and a Jordan chain, not a diagonalizability assumption. Separately, the Hermitian inner-product identity gives Im(y)=A Im(tau)t. Taking the imaginary part of the eliminated expression for y then gives

A t = A − (A+1)/rho,
1+1/A < rho <= 2+2/A.

The inner endpoint is strict and the outer endpoint is inclusive. At A>=3 the upper endpoint is at most 8/3. Hence nonreal tau with rho<=1 or rho>8/3 excludes repetition for every A, after the separately established A=1,2 cases.

The inclusive endpoint is genuine. In the exact quadratic field with t²=−(2/3)t−1, the two nonreal parameters t=(−1±2sqrt(2)i)/3 satisfy |t−1|²=8/3. With y=3(1+t)/2, y²=3t, so the A=3 quartic is (x²−y)². Therefore replacing the strict test rho>8/3 by rho>=8/3 would be wrong. The new exact-field controls establish this boundary without relying on a modular surrogate.

For each fixed A the discriminant is in Q[tau]. If it vanished at any primitive embedding of q, a cyclotomic automorphism would make it vanish at the selected certified embedding. Thus one appropriate norm witness per order suffices. For arbitrary K, Q(zeta_d) maps injectively to K by zeta_d↦q. No embedding of all of K into C is required.

## 4. Lower and infinite-tail proof

Reflection of the sine ratios gives s_(h−j)=s_h conjugate(s_j), with |s_h|=1. Consequently

rho=|S_(h−16)|²/|S15|².

The squared norms |S_j|² strictly increase: the increment is a_j² plus positive cosine cross-terms, since every angular separation is below pi/2. For h=16..31, the reflected prefix index h−16 lies in 0..15, proving rho<=1. Equality occurs at d=63 and remains strictly below every inner critical endpoint. Fresh numerical controls enclose equality at d=63 but do not use rounded numbers to prove it.

For the tail take d>=15(m+1)=240. Since d is odd, the first applicable order is 241. For 0<=j<=15, u=(2j+1)pi/d is strictly below 2pi/15, including at the real endpoint d=240. The positive sine identity

sin²(2rv)−sin((2r−1)v)sin((2r+1)v)=sin²(v)

telescopes to a_j²<=sin(v)/sin((2j+1)v). Since pi²<10 and sin(u)>=u−u³/6, one has sin(u)>(131/135)u in this range and sin(v)<v. Thus

a_j²<135/[131(2j+1)].

Strict convexity and the midpoint integral inequality for x^(−1/2), including the improper first interval, give

sum(j=0..15)(2j+1)^(−1/2) < sqrt(32).

It follows that |S15|²<270·16/131. The residues ±2r, 1<=r<=h, partition all nonzero residues modulo any odd d, not only prime d. Therefore |E|²=d and |S_h|²=d, so

|tau|² > 131d/(270·16) >= 131/18.

The exact comparison

(101/18)²−4(131/18)=769/324>0

proves (sqrt(131/18)−1)²>8/3, and the reverse triangle inequality yields rho>8/3. Strictness is retained throughout. This is an infinite proof; the numerical d=241 boundary check is only corroboration.

## 5. Independent middle reconstruction

The reviewer wrote a new standard-library-only checker and imported or executed no candidate, predecessor, or third-party program. The new choices are:

- Closed outward dyadic rectangles at scale 2^2304.
- pi=8 atan(1/3)+4 atan(1/7), with 1000 alternating terms and exact first-omitted-term bounds for each arctangent. The tangent identity is checked rationally; the angle lies in the correct positive quadrant.
- Degree-501 sine and degree-500 cosine, with explicit 4^503/503! and 4^502/502! remainders for reduced angles below 4. Root powers are formed successively.
- Integral Gaussian coefficients by exact polynomial quotient division, rather than candidate Pascal or Euler construction. Their original derivative is evaluated by Horner’s rule.
- Original, uncancelled W products, followed by all saved guards and an independent prefix reconstruction. The fuller S_h calculation also checks E S_h=d and tau=S_h/S15. The derivative route is compared with B15 S15.

All arithmetic decisions use integers or exact fractions. Floating values in the selection file are ignored; only the selected integer d,k pairs are used. All 88 order indices are matched across certificate, coverage and selection data, and their gcd conditions are checked.

Fresh exact enclosures are contained in every saved parameter/rho enclosure and all 15,268 guards. The fresh and saved lower rho bounds both strictly exceed 8/3. Every integer derivative coefficient matches, including the accepted residual’s opposite P15(−2) sign. The completed checker records 1,379,307 assertions, including routine arithmetic invariants; this is an execution count, not a strength-of-theorem measure.

A useful adversarial boundary is d=65 at the principal embedding: its rho lies between 1.068432 and 1.068433, which fails the outer sufficient criterion. The chosen k=14 succeeds. This explicitly demonstrates why a conjugate norm bound must not be claimed invariant under Galois automorphisms. Only the zero/nonzero discriminant conclusion is transported.

## 6. Controls, mutations, cold replay and provenance

The new review passes:

- 1,056 rational containment checks, including nonzero-width interval corners, signs, zero-crossing squares and inverses.
- 60 complex-rectangle corner groups, included in the containment accounting.
- 400 exact factorial-Hermite versus tridiagonal-determinant normalization controls (A=1..100, four exact parameters). These corroborate conventions, not the all-A proof.
- Three exact quadratic-field critical A3 controls and three complex-conjugate controls.
- All 16 lower-order numerical boundary checks, the first odd tail d=241, and the contrasting principal d=65 witness.
- 49 deliberately corrupted or unsafe cases, each rejected by a nonempty AssertionError diagnostic. Generic crashes or missing-key exceptions do not count as rejection.

The 49 cases cover domain endpoints, even and nonprimitive orders, invalid intervals and unsafe inverses, missing/duplicate middle orders, selection binding, method precision metadata, original W length, lost d factor, tau sign, forged tau/rho/prefix intervals, incomplete guards, strict thresholds and margins, A cutoffs, spurious bridges, derivative coefficients and endpoint sign, omitted lower endpoints, tail endpoints, characteristic and excluded scope, and changed/missing/unbound manifest payloads.

Local provenance verification covers all 38 candidate payloads, all 16 copied source bindings against their originals, and all 95 payloads across the three pinned dependency packets. The archive is independently hash-checked, extracted with path safety checks, and its contents reverified against the candidate’s pinned manifest. All originals are rechecked after replay and remain unchanged.

Two fresh temporary-directory replays under Python −I execute only the reviewer’s two mathematical/test programs against the extracted inert candidate. Both reproduce independent_results.json and adversarial_results.json byte for byte, including the full original-tau enclosures. The commands, output hashes and logs are retained.

The author’s distinct 44-mutation receipt and final sealed cold-replay receipt were statically inspected. Their unique diagnosed counts, cited output hashes, archive hash and manifest hash match the sealed bytes. They were not freshly executed in this review. Accordingly the review claims its own two cold replays and 49 freshly executed mutations; it does not relabel the author’s 44 cases or claimed producer replay as new reviewer execution. No floating selection rerun, residual program, predecessor program, package installation, network write or external service action was performed.

This is an independently implemented reviewer reconstruction after inspection of the candidate, not a blind discovery or proof-assistant formalization. Exact interval arithmetic is a shared mathematical technique; the pi identity, implementation and Gaussian evaluation route are fresh. The source-byte checks prove local provenance, not remote repository pins or historical priority.

## 7. Accepted residual dependency and scope integration

The b31 ordinary-residual producer is pinned by manifest
`fad1eba5a18c601305900ee7cb5d8963cc889bf5fe6aa6f54bd1f3e7aa4459e8`.
Its accepted independent review is pinned by
`1719dbf90baa07f6ae48ca14b07f2c171ab5bb357185723aec56fd7c410aa9c6`.
The accepted b29 all-A review is pinned by
`c40da8436683eef46ff3ed3a356a0616341b3e960a02c1ca420202ed5abbef02`.

The accepted residual theorem states nonvanishing of P15(2), P15(−2) and Disc(P15), hence squarefreeness of H31/(z+1), for the same characteristic-zero primitive odd d>31 domain. Its signed derivative normalization and all local payloads are rechecked; its large residual computation is not rerun or counted again. The present proof establishes g≠0 independently by the sector argument, so its overlap conclusion does not circularly assume residual simplicity.

The two accepted results discharge the distinct b31 residual and original-tau overlap obligations at their stated scopes. Neither is substituted for the other, and neither proves the general all-m paired-support or arbitrary-b all-A problem.

## 8. Scoped ranking and remaining gap

The selected b31 all-A construction and the present exact-scope independent review are complete. Each receives the completed-stage cap **15/100** under the retained v1.1 work-priority rubric. The review’s former selected priority 68 is historical task-selection context, not a continuing rank for repeating a completed review.

The separately open, unselected general all-m paired reciprocal-support proof-or-obstruction gate remains **58/100**, with inherited dimensions (information gain, tractability, defensible novelty opportunity, scope/impact, evidence readiness)=(4,2,1,4,4), weighted mean 2.9. Its target remains one genuinely uniform mechanism or a certified high-order common reciprocal obstruction. The two previously audited norm/noncancellation routes stay completed; this review does not restart them, rename them into new tasks, or launch a larger finite grid. It also does not automatically substitute b33 for the finished b31 task.

Historical novelty remains unresolved. The accepted result is an incremental fixed-b extension and a reproducible scope closure, not evidence of standalone publishability or an FFT advance. A broader contribution still requires a uniform theorem or sharp obstruction, careful integration of the distinct obligations, and primary-literature comparison. No live spreadsheet, repository, canonical-discovery count or historical source ranking was changed by this review.
