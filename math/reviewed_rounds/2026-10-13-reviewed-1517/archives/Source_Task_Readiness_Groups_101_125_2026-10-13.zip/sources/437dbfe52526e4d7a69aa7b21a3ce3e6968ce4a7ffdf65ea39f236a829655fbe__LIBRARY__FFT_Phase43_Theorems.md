# Phase 43 — arc-rank obstruction and four-row Green interpolation

**Date:** 2026-10-11. **Status:** A general restricted-architecture impossibility theorem with an elementary, complete proof; exact modular real-Jacobian rank certificates; and two computer-assisted existence certificates for **four Fourier rows** at `N=8` and `N=16`. A four-row solution at `N=32` is numerical only. **No full DFT, uniform Green synthesis, or sub-`N log N` FFT has been obtained.**

## Definitions and scope

For a directed Hamiltonian-cycle weighted shift `W`, assume all edge gains are nonzero and the cyclic product `h` satisfies `h != 1`. Define the Green operator `G_W=(I-W)^{-1}`. A one-layer `q`-cycle sum is `S = sum_{s=1}^q alpha_s G_{W_s}` with arbitrary complex scalar coefficients. Cycles, their orders, and their edge weights may be unrelated. An outer Fourier equivalence permits an arbitrary **row** permutation, an arbitrary **column** permutation, and invertible left/right **diagonal** scalings; it does not permit arbitrary dense left/right transforms.

Let `F_N[k,j]=omega^(k*j)` with `omega=exp(-2*pi*i/N)`. For a matrix `M` whose relevant entries are nonzero, define normalized projective ratios

`R_{r,j}(M)=M[r,j] M[0,0]/(M[0,j] M[r,0])`.

Matching Fourier rows `0,...,m-1` up to external invertible diagonal scalings is equivalent to `R_{r,j}(M)=omega^(r*j)` for `1<=r<m`, `1<=j<N`. Reordering rows and columns first is allowed when explicitly stated.

## Theorem 43.1 — universal arc-rank bound for a sum of `q` Hamiltonian Green resolvents

For every integer `q>=1` and `N>=q+1`, if a one-layer `q`-cycle sum, with any nonzero complex edge gains and any complex coefficients, equals the complete `N`-point Fourier matrix up to outer row/column permutations and invertible diagonal scalings, then

**`N <= q * (q+1)^q`.**

Indeed, the stronger statement holds: whenever a set of `m=q+1` output rows is required to match **any `q+1` consecutive Fourier frequency rows** up to external diagonal scalings and arbitrary input-column permutation, the same bound holds. In particular a **single sum of three weighted Hamiltonian-cycle Green inverses cannot contain four consecutive Fourier rows at `N>=193`**, and cannot equal the full DFT at those lengths, regardless of complex edge amplitudes, cycle permutations, or external monomial equivalence.

**Proof.** Fix one cycle `v_0,...,v_{N-1}`. Write `W e_{v_i} = w_{i+1} e_{v_{i+1}}` with indices cyclic, `h=prod_i w_i`, and set `beta_0=1`, `beta_a=prod_{t=1}^a w_t` for `1<=a<N`. Its exact Green entries are

`G_W[v_a,v_b] = (beta_a/beta_b) * h^[a<b] / (1-h)`, where `[a<b]` is one if `a<b`, zero otherwise.

Choose any `m` distinct output coordinates and sort their positions in this cycle: `a_1<...<a_m`. As source position `b` runs around the cycle, the `m`-component column vector restricted to those outputs, up to one nonzero column-dependent scalar, equals the vector with entries `beta_{a_k} h^[a_k<b]`. Its projective direction changes only on crossing one of the `m` marked output positions. The two extreme patterns (all zero exponents or all unit exponents) differ by the common scalar `h`, hence are projectively identical. Consequently there are **at most `m` projective column directions** for a single Green inverse on those `m` rows. This step needs neither unit-modulus gains nor a genericity condition.

For `q` independently ordered cycles, label an input column by its `q` projective-direction signatures. At most `m^q` joint signature classes are possible. Within one class, all columns of the sum `S` lie in the fixed span of the `q` direction vectors for that class; thus that selected-row submatrix has rank at most `q`, even when scalar coefficients `alpha_s` are arbitrary.

Select `m=q+1` rows that, under the purported output permutation, correspond to `q+1` consecutive Fourier frequencies `r0,...,r0+q`. The Fourier submatrix on these rows is, after invertible diagonal factors, a Vandermonde matrix in the **distinct** nodes `z_j=omega^j` for its input columns. **Every collection of `q+1` distinct input columns is linearly independent** (its determinant is a nonzero product of node differences). Outer row and column permutations and nonsingular diagonal scalings preserve that independence. Therefore no signature class can contain `q+1` columns: each has at most `q`. There are at most `(q+1)^q` such classes. Pigeonhole gives `N<=q(q+1)^q`. QED.

**Asymptotic corollary (restricted architecture only).** Any such exact one-layer representation family for unbounded `N` requires `q=Omega(log N / log log N)`. This is **not a general FFT lower bound**, nor a lower bound for arbitrary products of Green sums. The theorem concerns representation by **one sum**. The known special Phase 41 unit-gain two-cycle `N>8` obstruction can be stronger at small `q`.

**Exact modular sanity checks.** `phase43_arc_rank_theorem.py` independently groups the columns for several finite-field examples. In a 256-point three-cycle example the four-row Green block on four columns of one pattern class has rank `3`, while the Fourier block on the same columns has rank `4`. Additional checks cover `N=8,16,64,512`. These tests illustrate, but are not a substitute for, the universal proof.

## Theorem 43.2 — the missing relative interstage gauge

Every product of two **unit-modulus-edge** three-cycle Green sums can, up to outer unit diagonal scalings, be written in the form `S2 D S1`, where both `S1` and `S2` are individually gauge-fixed using spanning trees and `D` is a **unit-modulus** interstage diagonal. The single irrelevant global scalar in `D` can be removed by requiring `D[0,0]=1`.

**Proof.** For each layer `ell=1,2`, apply a diagonal unitary `T_ell` to gauge-fix `N-1` spanning-tree edges of the union graph, obtaining `S_ell=T_ell S'_ell T_ell^{-1}`. Then

`S2 S1 = T2 S2' (T2^{-1}T1) S1' T1^{-1}`.

The middle diagonal `D=T2^{-1}T1` is a relative gauge, generally not the identity, and cannot be dropped when independent phases are allowed across layers. Its global scalar is projectively irrelevant. QED.

For a sum of three cycles, each gauge-fixed layer has `2N+1` independent real phase parameters (the cycle-holonomy coordinates). Hence the two-stage projective models have

- `4N+2` phase variables with `D=I` (Phase 42 restricted family);
- `5N+1` real phases with **unit** `D` (the full unit-edge two-layer product modulo outer diagonals);
- `6N` real variables when the interstage `D` is allowed to be an arbitrary nonzero **complex** diagonal, represented by `D[0]=1`, `D[k]=exp(a_k+i theta_k)` for `k>=1`.

**Important distinction:** the complex-amplitude `D` is a larger circuit architecture than the product of two original unit-edge sums; it is **not** merely a gauge change. The two-stage executor still takes `O(N)` online arithmetic given all weights and the diagonal.

## Theorem 43.3 — exact four-row local submersion with complex interstage amplitudes

For the explicit graph orders and rational-Gaussian unit-circle gains defined in `phase43_four_row_rank.py` and the inherited Phase 42 source, evaluate the real projective Jacobian for `R_{r,j}(S2 D S1)` with `r=1,2,3`, `j=1,...,N-1`. The target dimension is `6(N-1)` real. Differentiation uses `dG=G(dW)G` and

- first-layer edge: `dM = S2 D G[:,v] G[u,:] * (i w)`;
- second-layer edge: `dM = G[:,v] G[u,:] D S1 * (i w)`;
- interstage phase `theta_k`: `dM = i D[k] S2[:,k] S1[k,:]`;
- interstage log-amplitude `a_k`: `dM = D[k] S2[:,k] S1[k,:]`.

Here the displayed outer products have their natural matrix dimensions.

At the specified unit gains and nonzero interstage amplitudes, the exact rank results are:

| `N` | Target real dimension | Unit-`D` rank / columns | Complex-`D` rank / columns |
|---:|---:|---:|---:|
| 8 | 42 | 41 / 41 | **42 / 48** |
| 16 | 90 | 81 / 81 | **90 / 96** |
| 32 | 186 | 161 / 161 | **186 / 192** |

Every rank independently matches in `F_998244353` and `F_2013265921`. The real Jacobian entries are rational at those Gaussian-rational unit-gain test points, recovered from the two conjugate square roots of `-1` modulo each prime. A nonzero modular minor proves a nonzero rational minor and therefore at least that rank over the real numbers; maximality gives exact rank. The real submersion theorem then implies the image of the **complex-amplitude** model contains an open set of four-row projective targets **near those parameter points**. This is **not** proof that the Fourier target lies in that open set.

File: `phase43_four_row_rank.py`, recorded rank residues and dimensions: `phase43_four_row_rank_audit.json`.

## Theorem 43.4 — computer-assisted exact four-row Fourier interpolation at `N=8` and `N=16`

At **each** of `N=8` and `N=16`, there exists a product of **two sums of three unit-edge Hamiltonian Green resolvents** with an **arbitrary nonzero complex diagonal between the layers** such that its **first four output rows**, after invertible external left/right diagonal calibration, agree **exactly** with rows `0,1,2,3` of the unnormalized DFT.

For `N`, let `f(x)` be the vector of real and imaginary parts of `R_{r,j}(M(x))-omega^(r*j)` with `r=1,2,3` and `j=1,...,N-1`. There are `6(N-1)` real constraints. The JSON certificates specify exact decimal centers `x0`, exactly `6(N-1)` varying coordinates chosen from the `6N` model parameters (six coordinates frozen), and exact-decimal square preconditioners `B` of the corresponding sizes. The standalone verifier uses 55-decimal-digit **outward-enclosing interval arithmetic** for all Green weights, products, Fourier roots, projective ratios, and analytic derivatives. The interval box radius is applied only to the free coordinates. It directly verifies the following **strict rational inequalities** (the binary64 summary bounds are never used for proof decisions):

| N | Eqns/varied | Exact box radius `rho` | `||B f(x0)||_inf` | `sup_box ||I-B Df||_inf` | Diagnostic norm upper bounds |
|---:|---:|---:|---:|---:|---|
| 8 | 42 | `1e-11` | `<1e-12` | `<0.1` | shift `3.669e-15`, contraction `0.02386` |
| 16 | 90 | `5e-13` | `<1e-13` | `<0.1` | shift `1.641e-14`, contraction `0.04103` |

For `N=8`, `1e-12 + 0.1*(1e-11) < 1e-11`. For `N=16`, `1e-13 + 0.1*(5e-13) < 5e-13`. Therefore `T(x)=x-B f(x)` is a strict contraction and maps the corresponding closed box into itself. Banach's fixed-point theorem gives a fixed point in each box; `||I-BDf||<1` forces the square matrix `B` to be invertible, so at that fixed point **`f(x)=0` exactly**. No numerical root-guessing is used inside the certificate verification. All Green denominators and cross-ratio denominators are excluded from zero by successful interval division over the entire box.

The independent fifth-row interval witnesses evaluate the **same** complete boxes and prove failure of the next Fourier output row at `row=4, column=1`, using the direct check `0 not in interval`:

- N=8: defect real part contained in `[1.3058842369, 1.3058845731]`, imaginary part contained in `[-0.4606346550,-0.4606342660]`;
- N=16: defect real part contained in `[-1.1830063059,-1.1830044278]`, imaginary part contained in `[3.1805856212,3.1805882036]`.

**Thus neither certificate gives a full DFT**, although both give a rigorous exact four-row partial factorization. An independently optimized `N=32` example achieved real-component residual `2.86e-14` for four Fourier rows with rank 186, but it has **no interval existence proof** and remains numerical evidence only.

Files: `phase43_four_row_box.json`, `phase43_four_row_box_N16.json`, `phase43_four_row_interval.py`, `phase43_four_row_interval_N16.py`, `phase43_fifth_row_obstruction.py`, `phase43_fifth_row_obstruction_N16.py`. One-time nonlinear optimization (`phase43_four_row_fit.py`) and box preparation (`phase43_prepare_four_row_box*.py`) are explicitly **not** part of the existence proof. The verifiers read saved rational-decimal data and do not refit it.

## Research interpretation and open gate

**What's established:** (a) the one-sum `q`-Green architecture has a universal full-DFT representation obstruction; (b) the two-layer architecture requires retaining a relative interstage gauge; (c) complex interstage amplitudes give full local four-row control at tested N and exact four-row interpolation at N=8,16; (d) the certified solutions definitely fail at row 5.

**What is not established:** a full DFT at any new N, a family of such circuits for unbounded N, efficient phase synthesis from N alone, well-conditioned bit complexity, or an `o(N log N)` all-input FFT. Computing **four** Fourier rows is already `O(N)` by direct dot products, so finite-row exact interpolation by itself does not improve Fourier-transform complexity. The project goal remains simultaneous **all-row** Weyl covariance with complete cost accounting.

**Next Phase 44 gate:** add noncommuting layers *and check all outputs* on N=8,16 while measuring how necessary stage count and parameter-generation cost scale with N. For any promising full-matrix numerical fit, demand an independent interval/exact identity certificate. A dimension/rank result is never sufficient to claim the Fourier target is attainable.

## Literature and originality boundary

The elementary projective arc-pattern observation resembles classical quasiseparable/Green-matrix rank-structure arguments, while the Vandermonde full-spark fact and Banach interval-Newton arguments are classical. Ailon (2013, arXiv:1305.4745) and Morgenstern's bounded-coefficient FFT lower bound concern different circuit models. We did not find an exact match for this specific `q(q+1)^q` Hamiltonian Green-sum formulation in a limited web search; that **does not establish literature novelty or publishability**. Independent prior-art and peer review are still required. References: https://arxiv.org/abs/1305.4745 and https://link.springer.com/article/10.1007/s11075-024-01809-9.
