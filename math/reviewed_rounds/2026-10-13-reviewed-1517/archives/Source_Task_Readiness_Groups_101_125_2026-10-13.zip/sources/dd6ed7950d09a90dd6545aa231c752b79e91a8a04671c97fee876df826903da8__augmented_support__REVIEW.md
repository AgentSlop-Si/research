# Independent review of the ramified augmented content bound

13 October 2026 UTC

## Decision

**Scoped ACCEPT. No mathematical repair is required.** The conditional bound in the frozen candidate is valid with exactly its stated domain and characteristic-zero lower residual guard. The specialization

    p^[27(p−1)/4] divides c_(27p)^+

is accepted for every prime p ≡ 1 (mod 4). This is an intrinsic augmented-content lower bound and an obstruction to naive same-prime iteration. It proves no new target squarefreeness transfer or arbitrary unramified support theorem.

Reviewed theorem SHA-256: `6004667e28c2c58e61b4fa669e4d1a7d91ec0be0e71a4dfa21ee9098a24d7fcb`.

Reviewed candidate manifest SHA-256: `12ee72980b4de414d8edc072bbebfa52effef3fdc0f1a3d06b532c9744521874`.

All 23 manifest entries match their stated sizes and hashes. The independent program does not execute or import candidate or historical mathematical programs. No candidate, original source, external table, or repository file was changed.

## Accepted statement and all guards

Let t ≥ 3, t ≡ 3 (mod 4), let p ≡ 1 (mod 4) be prime with p ∤ t, and let e ≥ 1. Write N=p^e, s=tN, A=(N−1)/2, h=φ(N). At a primitive characteristic-zero t-th root ω require

    Γ_t = Disc_z(U_t) Res_z(z^t+1,U_t) ≠ 0,
    U_t=H_((t−1)/2)/(z+1).

For the canonical integral-coordinate content of Γ_s ι(Γ_s) δ_s in Z[q]/Φ_s(q), put M=tA²+A/2. Then p^floor(M/h) divides c_s^+, with content zero allowed. Every derivative and discriminant is ordinary in z. No unit condition in characteristic p is assumed or inferred from the characteristic-zero guard.

The accepted general odd-guard theorem covers the overlap endpoint d=t=2b+1 for b=(t−1)/2. This endpoint includes t=3, b=1, with the usual discriminant-of-a-constant convention. It also supplies g_t ≠ 0, resonance separation and nonreal τ in every primitive embedding. The ordinary residual discriminant remains an explicit assumption for arbitrary t. Since the relevant quantities are rational integral polynomials in ω, nonvanishing at one primitive embedding transfers by Galois conjugacy.

For t=27 the supplied ordinary theorem covers b=13. Independently, this review reconstructs a short modular witness: over F_109, 3 has exact order 27, and the lower residual discriminant and resonance resultant evaluate to 95 and 81 respectively. Their product is nonzero. Thus neither polynomial is divisible by Φ_27 in characteristic zero, independently certifying the lower guard needed here. This does not re-certify c_27^+ or the previously accepted squarefreeness family.

## Characteristic zero factor audit

The inherited local parameter satisfies q(ε)^t−1=ε². Since p ≡ 1 (mod 4), A is a positive even integer, including when e>1 and A≥p. The shared initial form uses the original τ=tW/g_t and probabilists' Hermite normalization. Its derivative at zero is

    J'_(A+1)(0;τ)=(1+Aτ) He_A(0) ≠ 0.

Nonreality of τ and nonzero He_A(0) establish this in characteristic zero. Differentiating with respect to x and dividing by ε gives ord_(Φ_t) g_s=A/2, because H'_n(−1)=U_s(−1). The change from ε order to Φ_t order is exactly a factor of two.

The accepted overlap discriminant coefficient has nonzero factors under the stated guards and gives ord_(Φ_t) Disc(H_n)=tA(A−1)/2+A. The monic product identity

    Disc((z+1)U_s)=Disc(U_s) U_s(−1)²

then gives ord_(Φ_t) D_s=tA(A−1)/2. There is no omitted sign or leading coefficient in this identity.

The even product in v_s contains A/2 multiples of t; the odd product contains A. Each has a simple characteristic-zero zero. Hence ord_(Φ_t) v_s=3A/2. Since A>0, subtraction from 2g_s cannot cancel its lower term, and ord_(Φ_t) δ_s=A/2.

For each of the t distinct roots α of z^t+1, α is a root of z^s+1 because N is odd. At α≠−1 the separated local coefficient is nonzero by resonance separation and He_A(0)≠0; division by the nonzero constant α+1 is legitimate. At α=−1 the derivative calculation applies. Each contributes order A/2 to R_s. All other root-product factors have nonnegative order, so ord_(Φ_t) R_s≥tA/2. An identically zero factor would only strengthen the divisibility; equality is not required.

Consequently Φ_t^(tA²/2) divides Γ_s in Z[q]. The passage from primitive-root vanishing to rational polynomial divisibility uses irreducibility of Φ_t. Monic polynomial division then preserves integrality. The reciprocal identity Φ_t(q^−1)=q^−φ(t)Φ_t(q), with q a unit, gives the same divisibility for the involuted factor. Thus the intrinsic augmented element belongs to Φ_t^M O_s. All these divisions precede reduction modulo p. No factorial, Hermite coefficient or vanishing residue factor is inverted in characteristic p.

## Ramification and integer coordinate audit

The coprime root decomposition q=ηξ, with η of order t and ξ of order p^e, is integral: both roots are powers of q. Thus O_s⊗Z_p is obtained from the product of unramified DVRs O_t⊗Z_p by adjoining ξ. The polynomial Φ_(p^e)(1+Y) is monic, is Y^h modulo p, and has constant term exactly p. It is Eisenstein over each unramified factor. Therefore π=ξ−1 is a uniformizer and v_π(p)=h=p^(e−1)(p−1), including e>1.

Since Φ_t'(η) is a unit, Taylor expansion gives

    Φ_t(ηξ)=η Φ_t'(η)π+O(π²).

The first term has exact valuation one; higher terms cannot cancel it. This holds at every prime above p, even when Φ_t modulo p has several factors. Hence Φ_t^M has local valuation exactly M in all factors, and the augmented element has valuation at least M in all of them.

It follows that the augmented element is in p^k(O_s⊗Z_p) for k=floor(M/h). Membership is equivalent to divisibility of every canonical power-basis coordinate by p^k in Z_p. Because those coordinates are integers, it is equivalent to ordinary integer divisibility. This is not a norm calculation, an averaged valuation, or an assertion at only one selected prime.

For e=1, M/h=t(p−1)/4+1/4, so the stated integer exponent is exact. For e>1 one must retain h=p^(e−1)(p−1) and the floor. For example at (t,p,e)=(3,5,2), M=438, h=20, k=21; replacing h by p−1 would wrongly demand exponent 109.

A useful boundary clarification is that M/h need not always be nonintegral for higher e. The allowed arithmetic parameters (251,5,4) give M=24,433,500 and h=500, so k=48,867 with zero remainder. This is an arithmetic check only; no lower residual guard at t=251 is claimed certified. The candidate correctly limits its nilpotent-normalization examples to the tested cases, all of which have positive remainders.

## Independent bounded controls

The review's degree recurrence constructs H directly. Exact rational subresultants compute full ordinary discriminants and resonance resultants at x and its actual rational inverse 1/x. This differs from the candidate's modular multiplication matrices, unit-pivot determinant algorithm, q-Pascal construction and finite Euler comparison.

At t=3 the new auxiliary prime is 43 with x=6; at t=7 it is 127 with x=2. In each case Φ_t(x) has exact auxiliary-prime valuation one. The observed local orders are:

| s | D at x and inverse | R at x and inverse | δ at x and inverse | Augmented order |
|---|---:|---:|---:|---:|
| 15 | 3 | 3 | 1 | 13 |
| 35 | 7 | 7 | 1 | 29 |
| 51 | 84 | 12 | 4 | 196 |
| 75 | 198 | 18 | 6 | 438 |

These auxiliary valuations are not intrinsic p-adic content valuations. Independent symbolic q-polynomial resultants at s=15 also verify the exact Φ_3 orders and reconstruct the full intrinsic content c_15^+=3^12·5^9. This is a bounded consistency check, not a new family or a novelty claim.

Eight independent quotient-ring computations use SymPy's integer polynomial multiplication and remainder, modulo p^(k+1). They certify exact coordinate content exponent k for the universal divisor Φ_t^M:

| s | t | p | e | M | h | k |
|---|---:|---:|---:|---:|---:|---:|
| 15 | 3 | 5 | 1 | 13 | 4 | 3 |
| 35 | 7 | 5 | 1 | 29 | 4 | 7 |
| 51 | 3 | 17 | 1 | 196 | 16 | 12 |
| 75 | 3 | 5 | 2 | 438 | 20 | 21 |
| 375 | 3 | 5 | 3 | 11,563 | 100 | 115 |
| 507 | 3 | 13 | 2 | 21,210 | 156 | 135 |
| 195 | 15 | 13 | 1 | 543 | 12 | 45 |
| 675 | 27 | 5 | 2 | 3,894 | 20 | 194 |

The s=195 control includes a composite lower base and multiple reduced components. Five overlapping cases reproduce the candidate's entire raw coordinate-array hashes and normalized residue coordinates. Candidate output was consulted for this comparison only after reconstruction.

All eight normalized universal divisors are nonzero in the full nonreduced quotient but vanish in every reduced component. A separate exact-multiple control Φ_15^12 at s=195 normalizes by 13 to a unit in every component. Thus the test suite checks both sides of the zero-remainder boundary rather than assuming normalization is always nilpotent.

Eight malformed or missing-guard inputs are rejected. Corruption controls reject adding one to a coordinate, replacing the floor by the ceiling in the tested positive-remainder cases, using the unramified index p−1 for e>1, and choosing separate nonzero factors in incompatible direct-product components. A clean-directory rerun must reproduce the independent results byte for byte; its receipt is included in the sealed package.

## Source and inference boundaries

The candidate correctly distinguishes its guarded bound from the earlier unconditional full-nonreduced-algebra obstruction, from the embedded order15-to-order75 pullback, and from the much stronger isolated intrinsic order75 equality. The latter's 5-adic augmented valuation 2146 is different from auxiliary order 438 and universal-divisor content exponent 21.

The accepted c_27^+=3^68 and unramified order27p squarefreeness statements remain frozen premises. Their supplied pins are preserved and neither statement is altered. The underlying order27 certificate archive was not replayed in this review. The new specialization does not need it; the required lower guard was independently certified as above.

The all-composite squarefreeness problem, arbitrary unramified augmented support, exact intrinsic content, and possible extra primes away from s remain unresolved by this lemma. The proof does not show that saturation of every intrinsic augmented element is always nilpotent. It shows that merely removing known integer divisibility does not supply the missing same-component unit argument.

The ramification and Eisenstein mechanisms are classical. The scoped RS-specific composition is justified relative to the supplied materials. No literature-wide priority, publication novelty, or breakthrough claim is made.

## Next action priority

**54/100**, a next-work priority only. This independently agrees with the candidate's recommendation. The accepted obstruction sharpens the problem but leaves a difficult mixed-characteristic step.

The next bounded task should construct one normalized intrinsic invariant for a repeated-prime tower based at t=27, prove its integral relation to the ordinary discriminant with every denominator and residue-component guard, and obtain either a valid same-component unit implication or an exact counterexample to the proposed implication. Stop at one proved implication or one decisive counterexample. A further fixed-base content census, or reuse of an unramified bridge at a prime already dividing the base, would not close the identified gap.
