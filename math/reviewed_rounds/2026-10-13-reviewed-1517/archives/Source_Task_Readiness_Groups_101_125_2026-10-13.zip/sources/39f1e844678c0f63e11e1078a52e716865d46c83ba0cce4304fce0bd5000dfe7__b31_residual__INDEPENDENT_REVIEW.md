# Independent review: b31 ordinary-residual certificate

13 October 2026 UTC. Family F020. Verdict: **ACCEPT AT THE STATED SCOPE**.

Reviewed candidate: next_cycle_b31_residual, with FILE_MANIFEST.json SHA-256
fad1eba5a18c601305900ee7cb5d8963cc889bf5fe6aa6f54bd1f3e7aa4459e8.

## 1. Accepted result and boundary

Let k be a characteristic-zero field and q in k have primitive odd multiplicative order d>31. Gaussian coefficients are the integral polynomials specialized at q. Define

H31(z;q) = sum(j=0..31) [31 choose j]_q z^j,
H31(z;q) = (z+1) U(z;q),
U(z;q) = z^15 P15(z+z^(-1);q).

Then P15 is monic of degree 15 and integral over Z[q], and

P15(2;q) != 0, P15(-2;q) != 0, Disc_t(P15)(q) != 0.

Consequently U is squarefree over an algebraic closure of k. The exact ordinary residual is H31/(z+1). No all-A Hermite-overlap assertion, arbitrary-m theorem, positive-characteristic theorem, lower-order classification, conditioning estimate, FFT improvement or historical-novelty claim is accepted here. No canonical discovery is added.

The decisive independent reconstruction is

G = gcd(F,F*)
  = bar(Phi1)^615 bar(Phi3)^199 bar(Phi5)^75 bar(Phi7)^56
    bar(Phi9)^17 bar(Phi11)^11 bar(Phi13)^13 bar(Phi15)^15

in F2[q], with F = bar(P15(2) Disc(P15)) and F* its actual-degree reversal. Each displayed reduced cyclotomic can be reducible over F2; irreducibility is unnecessary. Its roots all have the exact stated odd order.

There is no mathematical repair request. Historical candidate text saying independent review is pending remains frozen; this review accepts that precisely identified candidate.

## 2. Independent inputs, normalization, and endpoint identities

The reviewer does not import either producer arithmetic program. It independently constructs all Gaussian coefficients over Z[q] with the additive q-Pascal identity

[n choose j]_q = [n-1 choose j-1]_q + q^j [n-1 choose j]_q,

starting from the row [1]. This differs from both the producer's finite Euler product and its orthogonal multiplicative quotient construction. The recurrence gives integral polynomials, including all boundary coefficients. Coefficient reciprocity is verified exactly.

Because H31 is monic reciprocal of odd degree, terms pair at z=-1 and give H31(-1)=0. High-to-low synthetic division by z+1 reconstructs U over Z[q], checks the exact zero remainder, and verifies that U is monic reciprocal of degree 30 with constant coefficient 1.

For S0=2, S1=t, Sj=t S(j-1)-S(j-2), the identity Sj(z+z^-1)=z^j+z^-j follows by induction. Writing

P15(t)=u15 + sum(j=1..15) u(15+j) Sj(t)

therefore supplies an integral trace. The triangular monic degrees of the Sj prove uniqueness and monicity. The reviewer additionally substitutes the resulting P15 using the full binomial expansion of z^15(z+z^-1)^j; every Laurent coefficient returns U exactly. This resubstitution does not reuse the S recurrence.

All 16 integer trace coefficient polynomials equal the saved integer payload. Their reductions equal the candidate's P array. Every H and U coefficient, the shifted Euler payload, A and B coefficient arrays, and all coefficient degrees are separately checked. The degree sequence is 240-j(j+1), j=0..15; it is verified at this fixed m rather than imported from an all-m claim.

The two endpoint identities follow directly from the normalization:

H31(1)=2 U(1)=2 P15(2),
H31'(-1)=U(-1)=(-1)^15 P15(-2)=-P15(-2).

Both are also checked coefficientwise in Z[q]. The saved endpoint polynomials have constant coefficients 16 and -16. Reducing P15(2) and P15(-2) gives the same nonzero E=bar(P15)(0); reducing H31(1) first gives zero. Removing the factor 2 before reduction is essential. The negative derivative sign is essential over Z, even though it disappears modulo 2.

## 3. Resultant identity, independent PRS calculation, and specialization

For p=bar(P15), write

p(t)=A(t^2)+t B(t^2).

Here deg A=deg B=7, B is monic, and lc(A)=q+q^2+...+q^30=0x7ffffffe. The derivative is p'(t)=B(t^2), monic of degree 14. A must not be normalized as monic.

Over an algebraic closure of F2(q), let beta_i be the seven roots of B, counted with multiplicity. The roots of B(t^2) are their unique square roots, each with twice the multiplicity. At those roots, p evaluates to A(beta_i). Thus

Res_t(p,p') = product_i A(beta_i)^2
             = Res_y(B,A)^2
             = Res_y(A,B)^2.

For monic p, Disc(p) equals Res(p,p') modulo 2. Both sides are polynomials in the coefficient ring. This derivation extends to repeated B roots, drops in the degree of A, and A=0; B's monicity is retained. No specialization condition lc(A)(q)!=0 is introduced.

The new reviewer computes Res(A,B) by a primitive pseudo-remainder sequence, rather than a Sylvester determinant or quotient-algebra norm. Its coefficient multiplication uses a four-bit carryless comb, rather than the producer's Karatsuba or the orthogonal checker's integer Kronecker encoding.

For current polynomials a,b of y-degrees m>=n, alpha=lc(b), delta=m-n+1, form the pseudo-remainder r=alpha^delta rem(a,b) by multiplication and subtraction in F2[q][y]. Let c be the gcd of its coefficient polynomials, let r0=r/c have actual degree s, and take r!=0. Over F2(q), the standard root-product definition gives, with signs absent,

Res(a,b)=alpha^(m-s-n delta) c^n Res(b,r0).

This formula is derived by evaluating the division identity at roots of b, accounting for the resultant leading-coefficient power, then accounting for scalar multiplication of the second polynomial. The implementation records every degree and scalar exponent; all content divisions and scalar cancellations have zero remainder. A nonzero constant b terminates with Res(a,b)=b^m. A zero remainder correctly gives resultant zero.

Rational intermediate scalar factors are cancelled in F2(q). The final denominator is checked to be 1. This is a generic exact computation of a polynomial identity, not pointwise division at a specialized q. It introduces no hidden nonvanishing guard on a leading coefficient. Seven PRS steps, with successive remainder degrees 6,5,4,3,2,1,0, give the full R in independent_results.json.

A second new PRS computation directly computes Res_t(p,p'), with actual input degrees 15 and 14. It independently returns R^2. This avoids relying solely on the split-resultant identity or the producer's 29-by-29 Bareiss determinant. The direct PRS degree/polynomial records are also retained.

The new PRS is additionally tested against 100 small literal determinant resultants, including nonmonic random inputs and differing degrees, under fixed seed 31015. All 4,096 six-bit multiplication pairs are tested against an explicit two-index bit convolution. These are implementation controls, not substitutes for the algebraic proof.

## 4. Exact gcd, reversal, factorization, and support

Independent arithmetic reproduces these complete polynomial masks, not only their degrees:

- E: degree 240, q-valuation 1
- R: degree 2240, q-valuation 7
- Disc(p)=R^2: degree 4480, q-valuation 14
- F=E R^2: degree 4720, q-valuation 15
- F*=q^4720 F(1/q): degree 4705, constant coefficient 1
- G=gcd(F,F*): degree 2137, constant coefficient 1
- L=product(j=1,3,...,31) (q^j-1): degree 256

The reviewer reconstructs F, its actual-degree reversal and G. It checks that G divides both F and F* and that the supplied Bezout coefficients satisfy sF+tF*=G exactly. Therefore the candidate G is the actual gcd, rather than merely a common divisor or a guessed annihilator.

Cyclotomic factors are reconstructed anew from q^n-1 by exact divisor removal, including both even and odd indices when needed for controls. The reviewer obtains the displayed multiplicities by repeated exact division of its independently computed G; the profile is not seeded from the producer's claimed numbers. The remainder is 1, and multiplication of every derived power reconstructs G. All order-component layers and metadata then agree with these derived values.

For each odd n<=31, bar(Phi_n) divides q^n-1 and is coprime to q^e-1 for every proper divisor e of n. Hence every root has exact order n. The degree sum is

615 + 199*2 + 75*4 + 56*6 + 17*6 + 11*10 + 13*12 + 15*8 = 2137.

Independently repeating the gcd/division strips by L gives exactly the 40 saved steps and terminal quotient 1. All repeated support is removed. The factorization and the strip certificate are redundant, separate ways of proving the sufficient root-order exclusion.

The four auxiliary reciprocal channels also reproduce their full gcd masks, with degrees 85,85,85,1026, and each strips to 1. Q=ER and K=gcd(Q,Q*) have degrees 2480 and 1111. These are accepted only as fixed-m15 checks, not an arbitrary-m support theorem.

## 5. Characteristic-zero transfer: all required guards

Define C_plus=P15(2) Disc(P15) and C_minus=P15(-2) Disc(P15) in Z[q]. Both reduce to the same nonzero F.

Suppose one of these integral polynomials vanishes at a primitive d-th root q in a characteristic-zero field k. The copy of Q in k is injective, and q has minimal polynomial Phi_d over Q. Thus Phi_d divides the corresponding C in Q[q]. Monic division by Phi_d gives an integer quotient, so reduction modulo 2 yields bar(Phi_d)|F. There is no assumption that k itself embeds into C.

For d>1, Phi_d is monic reciprocal with constant coefficient 1. Reduction preserves these facts. Put h=bar(Phi_d), e=deg h, and write F=hT. Because F is nonzero, N=deg F=e+deg T. Reciprocal symmetry gives

q^N F(1/q)=h(q) q^(N-e) T(1/q),

and the final factor is a polynomial, even if T has a nonzero q-adic valuation. Hence h divides both F and F*, and therefore G. The actual reduced degree N=4720 is used. Neither a characteristic-zero degree, artificial padding, nor removal of q^15 is silently substituted.

For odd d, q^d-1 is squarefree over F2: its derivative is q^(d-1), coprime to q^d-1. Reducing the cyclotomic factorization and inducting over divisors proves that every root of bar(Phi_d) has exact multiplicative order d. Since G has only the exact odd root orders 1,3,5,7,9,11,13,15, h cannot divide G for d>31. This contradiction proves C_plus and C_minus nonzero. As k is a field, both endpoints and Disc(P15) are individually nonzero.

The odd-order premise cannot be discarded. The review checks bar(Phi_74)=bar(Phi_37), exhibiting order collapse under even-order reduction. Complete order-33 and order-37 cyclotomic polynomials survive the L filter, so it is not an indiscriminate annihilator. A single q^31-1 filter is independently shown insufficient. The theorem remains at d>31 even though the recorded support is smaller; no lower-order extension was requested or adopted.

Finally, over an algebraic closure write P15(t)=product_i(t-t_i). Then

U(z)=product_i (z^2-t_i z+1),
Disc(U)=P15(2) P15(-2) Disc(P15)^2.

Each quadratic has discriminant t_i^2-4; each cross-resultant is (t_i-t_j)^2. This proves the displayed discriminant identity and the desired ordinary residual squarefreeness.

## 6. Fresh execution, corruption, and provenance

The reviewer inspected all five candidate Python programs before running them. None invokes external services, shells, package installation or imported predecessor arithmetic. All review work stays in a separate directory; the sealed candidate and historical originals were read only.

Fresh verification established:

1. The pinned source manifest hash matches, and every one of its 34 payload files has the recorded size and hash, with no extra or duplicate payload files.
2. All 15 copied source bindings equal their adjacent originals. All 38 entries in the four historical manifests were independently checked against original bytes. This verifies local provenance, not remote commits or publication priority.
3. The copied candidate's cold program ran in a fresh empty temporary directory under Python -I, using only its two arithmetic programs. It reproduced residual_certificate.json, G_factorization.json and orthogonal_checks.json byte for byte.
4. The freshly executed author checker recorded 14,181 assertion labels and 30 true controls. Its direct 29-by-29 discriminant recomputation included 7,714 exact polynomial divisions. These counts were read from fresh output, not accepted from the summary.
5. The fresh producer corruption suite rejected all 27 advertised mutations with assertion diagnostics.
6. The new independent reviewer passed 7,932 assertions, including the independent direct discriminant PRS. This is an execution count only.
7. Two new reviewer runs in fresh isolated subprocesses agreed exactly with each other and the ordinary run on every substantive result. Timing alone is excluded from the canonical comparison; canonical SHA-256 values are in the receipt.
8. A separate set of 49 semantic corruptions was rejected by the new checker, with exact failing assertion labels retained. These include altered full polynomial masks, coordinated false A/B monicity, joint padded reversal, deletion of the q-adic factor, endpoint sign/factor changes, loss of primitive/odd/domain guards, strip corruption, false factor orders and multiplicities, duplicate factors, missing layers, and even changes to the saved integer trace that are invisible modulo 2.

The 49 semantic tests are not an assertion that every JSON string is part of the mathematical checker contract. Descriptive metadata and all program/document bytes are covered by the pinned manifest. The exact input trace, resultant, support certificate and transfer guards are covered semantically.

Independent code uses only the Python standard library. It imports no candidate or historical program. It was written after inspection of the candidate, so this is an independent reviewer reconstruction, not a blind author-independent discovery or a formal proof-assistant certification. Standard trace identities necessarily overlap; the Gaussian construction, main resultant algorithm and coefficient multiplication route are distinct.

## 7. Remaining work and ranking

The named b31 ordinary-residual construction and this independent review are complete and each receives the completed-stage cap 15/100. Retrying this same accepted certificate is not the next research task.

The next ready bounded fixed-b construction is **construct b31 all-A overlap certificates**, priority 57/100 under the retained v1.1 rubric: information gain 4, tractability 3, defensible novelty opportunity 1, scope/impact 3, evidence readiness 3. Weighted mean 2.85 gives 1+round(99*2.85/5)=57. This is a work-priority judgment, not a correctness or breakthrough probability.

Its separate inherited contract uses the original b31 tau, lower odd orders 33..63, the infinite odd tail 241+, and 88 middle odd orders 65..239, with fresh primitive-conjugate witnesses and all necessary finite-A bridges. No such computation was performed here. A valid completion must cover every relevant A rather than extrapolate from a finite A scan; an unresolved certified interval or missing bridge is a precise blocker, not an implied theorem.

For the stated goal of a useful publishable contribution, the higher-value next obligation is the **general reciprocal-support proof-or-obstruction gate**, retained at 58/100, ahead of the incremental all-A b31 extension at 57/100. These near scores are one priority band, not a precise quantitative comparison. The exact target is one m-uniform identity showing that the localized ideal (Q_m,Q_m*) becomes the unit ideal after inverting L_(2m+1), or one certified high-order factor occurring on both reciprocal sides. Equivalently, with D_m=deg Q_m=m(m+1)(2m+1)/3, seek polynomial witnesses a_m Q_m+c_m Q_m*=L_(2m+1)^D_m. A proof must cover all four endpoint/collision channels and both self-reciprocal and paired distinct Frobenius orbits. A counterexample must specify m, an irreducible factor, its exact root order greater than 2m+1, and both divisibilities. Bound the next deliverable by one uniform lemma, one certified obstruction, or a precise unresolved algebraic step; do not substitute a larger finite grid. The priority dimensions remain (4,2,1,4,4), weighted mean 2.9, score 58. This gate is not solved by the accepted b31 instance, and no higher-m sweep was initiated. The proposed complex-recurrence phase lead was neither used nor researched in this review; positive real parts alone do not establish the needed simplicity statement. No literature-exhaustion or novelty claim is made.

The source snapshot records historical F020 priority 67; that is not the current live priority. The parent reports an exact-ID live lookup at 2026-10-13 01:41 UTC showing F020=60 before this review. The proposed next-task priority is 58; this reviewer did not verify or change the live Sheet. Historical source bytes remain unchanged. This review changed no spreadsheet, GitHub repository, remote service or sharing permission.

## Publication interpretation

This review converts one previously produced fixed-degree certificate into an independently accepted result. That is useful reproducibility and scope closure, but the mathematical extension from b29 to b31 is incremental. On the supplied evidence alone it does not establish a standalone publishable advance. A stronger manuscript needs a general mechanistic theorem or a sharply characterized obstruction, an appropriately scoped statement integrating the already accepted results, and a dedicated primary-literature comparison before any novelty claim. A successful uniform modular support lemma would address ordinary residual squarefreeness; all-A overlap remains a separate theorem obligation even then.
