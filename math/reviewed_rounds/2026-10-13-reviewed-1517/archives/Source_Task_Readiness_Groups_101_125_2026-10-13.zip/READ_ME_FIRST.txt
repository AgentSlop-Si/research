Source/task readiness, groups 101–125
13 October 2026

Exactly 25 groups, 32 stable IDs: READY=0, NEEDS_SCOPE_SELECTION=11, SOURCE_BLOCKED=14.

The first 25 of the remaining 125 were selected after exact prior 100 exclusions, keeping priorities unchanged and sorting canonical group IDs. The independent peer roster agrees and its next 25 are disjoint. This packet alone brings source/task coverage to 125 of the original 225, leaving 100; if the peer batch completes, combined coverage is 150 and 75 remain. These are coverage arithmetic, not a live dispatch census. Structural 249 open groups and 331 stable records are unchanged; historical 244 is not rederived.

No immediate mathematical dispatch is justified. 11 rows need a distinct scope/comparator; 14 need exact current bodies. Existing scoped proofs remain accepted. Missing sources are evidence-access gaps, not mathematical failures.

Key corrections: Q08 b31 residual and all-A overlap are already complete, as are the restricted balanced-endpoint/full-spectrum structural results. NF09/Q29 already has the fixed order-675 valuation; later uniform transport is a split review with a rejected shared-U sufficient bound and accepted C+1/parity-safe amendment. No repeated b31/675 work or automatic new finite grid.

No historical scientific execution, new proof acceptance, live Sheet/GitHub change, publication or sharing. This is source/task readiness, not a full mathematical audit.
