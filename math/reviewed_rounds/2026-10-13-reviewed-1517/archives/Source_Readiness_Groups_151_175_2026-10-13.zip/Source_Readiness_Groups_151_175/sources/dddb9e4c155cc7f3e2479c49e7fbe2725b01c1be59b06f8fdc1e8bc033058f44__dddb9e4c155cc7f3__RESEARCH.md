# Boolean Fourier orbits: minimal information and expensive single-scalar recovery

**9 October 2026. Status:** a new *restricted-model* theorem/certificate within this research project, with all-power-of-two mathematical proofs, exact-characteristic-zero tiny cases, and an independent modular obstruction certificate. **No new uniform `O(N)` explicit numerical FFT algorithm.**

## 1. Research target and prior-work gate

We want fresh, arbitrarily chosen bit vectors of length `N`, all `N` exact numerical DFT outputs, sequential execution, and fully charged elementary arithmetic. The broader original target also includes arbitrary complex inputs. Previously completed research already obtained an `O(N)` *symbolic* cyclotomic orbit description and showed that expanding the largest orbit uses another FFT. The question here is **not** to repackage that result: it is to test whether the recovered information can cheaply create the other exact complex scalars using only standard arithmetic from one primitive output.

We find a rigorous obstruction to that particular **one-register recovery** architecture; it leaves global multi-output sharing open.

We also give the complete power-of-two criterion for how many primitive-orbit spectral measurements uniquely determine a binary vector. This is information uniqueness, NOT computational recovery.

## 2. Exact output-injectivity theorem for Boolean vectors

Let `N=2^L`, `L>=1`, let `zeta=exp(2*pi*i/N)`, and define `X[k]=sum_j x_j zeta^(jk)` for a binary vector `x in {0,1}^N`. Partition Fourier frequencies by the multiplicative order (conductor) of `zeta^k`. The conductor runs over every divisor `m=1,2,4,...,N`, and the conductor-`m` orbit has `phi(m)` frequencies (for `m=1`, one).

**Theorem 1 (one-per-orbit, necessary and sufficient).** A subset `Q` of ordinary Fourier-bin indices gives an injective map `x -> (X[k])_(k in Q)` on **all** binary vectors if and only if `Q` meets every conductor orbit. The same sufficient condition gives injectivity over **all rational vectors**. Therefore the smallest possible number of such exact Fourier scalar measurements on every binary input is `L+1=log_2 N+1`.

### Sufficiency

For two rational vectors `x,y`, let `P(z)=sum_(j=0)^(N-1)(x_j-y_j) z^j`. If `X_x[k]=X_y[k]`, then `P(zeta^k)=0`. For a `k` of conductor `m`, the cyclotomic polynomial `Phi_m(z)` is the minimal polynomial of `zeta^k` over Q, hence `Phi_m | P` in `Q[z]`. The `Phi_m` for different divisors `m|N` are pairwise coprime and their product is `z^N-1`. If at least one `k` from every conductor is observed, `z^N-1 | P`. Since `deg P<N`, it follows that `P=0`, hence `x=y`.

### Necessity — explicit binary collision family, not a dimension heuristic

If no conductor-`m` bin is observed, for `m>=2` and each bit mask `sigma in {0,1}^{m/2}`, form a **periodic** binary vector of period `m` by

`x_j=sigma_(j mod (m/2))` for `j mod m < m/2`, and

`x_(j+m/2)=1-sigma_j` inside each period.

Changing `sigma_j` affects exactly the difference pattern `(1-z^(m/2))` on one residue pair, periodically repeated; its full `N`-point DFT vanishes at every frequency **outside the conductor-`m` orbit**. Hence all `2^(m/2)` different vectors give identical observations outside that orbit. For `m=1`, zero and all-one vectors differ only at DC. Therefore if Q misses any entire orbit, Q is not injective on binary inputs.

Examples of minimal exact measurement sets:

- `N=8`: `{0,4,2,1}` — four complex values
- `N=16`: `{0,8,4,2,1}` — five
- `N=64`: `{0,32,16,8,4,2,1}` — seven

**Crucial:** a single exact Fourier scalar may implicitly carry an increasing amount of algebraic information. Extracting that information and emitting `N` explicit complex values is not free. The original Galois-orbit research already showed the whole largest orbit reduces to a half-sized FFT. This theorem does **not** resolve that bottleneck.

## 3. Exact lower bounds for recovering one Galois conjugate from one scalar

We now study the **one-register** architecture, with no access to the original input or other Fourier outputs during recovery.

Take `N=2m`, `m=2^t >= 2`, a primitive `N`th root `zeta` over C, and restrict inputs to `(b_0,...,b_(m-1),0,...,0)`, with each `b_j in {0,1}`.

Let

`alpha(b)=X[1]=sum_(j=0)^(m-1) b_j zeta^j`,

`beta(b)=X[u]=sum_(j=0)^(m-1) b_j zeta^(u*j)`,

with `u` odd, `u!=1 (mod N)` (the executable example uses `u=3`).

Since `Phi_N(z)=z^m+1`, the powers `1,zeta,...,zeta^(m-1)` are independent over Q. Consequently `2^m` different bit masks give **distinct** alpha values, and the `2^(m-1)` masks with `b_0=0` also give distinct alpha values.

### Theorem 2: polynomial recovery needs exponential degree

Suppose a polynomial `H in C[t]` satisfies `H(alpha(b))=beta(b)` for **every** such binary mask. Let `d=deg H`.

Toggling `b_0` changes both alpha and beta by exactly 1. Therefore for each of the `2^(m-1)` distinct values `s=sum_(j=1)^(m-1) b_j zeta^j`,

`H(s+1)-H(s)-1=0`.

If `d>=2`, the polynomial `H(t+1)-H(t)-1` has degree at most `d-1`. If `d-1<2^(m-1)`, it has too many roots and must be the zero polynomial. In characteristic zero, the only polynomials with `H(t+1)-H(t)=1` identically are `H(t)=t+c`. The empty input gives `H(0)=0`, so `c=0`. But the singleton at coordinate 1 demands `H(zeta)=zeta^u != zeta`. Contradiction. Degrees `0` and `1` also fail directly.

Hence

**`deg H >= 2^(m-1)+1 = 2^(N/2-1)+1`.**

### Theorem 3: rational recovery also needs exponential numerator/denominator degree

Suppose a rational function `R=P/Q`, `P,Q in C[t]`, is defined at every alpha(b) (`Q(alpha(b)) != 0`) and equals beta(b) there. Let `d=max(deg P,deg Q)`.

The toggling condition gives `R(s+1)-R(s)=1` at `2^(m-1)` distinct s. Multiplying out denominators gives polynomial

`J(t)=P(t+1)Q(t)-P(t)Q(t+1)-Q(t)Q(t+1)`

of degree at most `2d`, vanishing at all these s. If `2d<2^(m-1)`, then `J` is identically zero. Thus `R(t+1)-R(t)=1` as a rational identity. The rational function `R(t)-t` would be periodic of period 1; a rational function with nonzero period is constant (its poles would otherwise have infinitely many translates, and a periodic polynomial is constant). It follows that `R(t)=t`, contradicting `R(zeta)=zeta^u`. Therefore

**`max(deg P,deg Q) >= 2^(m-2)=2^(N/2-2)`.**

Both theorems apply even when arbitrarily complicated *input-independent constants* are freely supplied from C. But they only apply to a function of **one complex scalar alpha** computed with the ordinary holomorphic operations +,-,*,/.

### Corollary: at least linear work for one-scalar arithmetic recovery

A straight-line arithmetic program using `s` ordinary scalar arithmetic gates and only the variable alpha produces a rational function with numerator/denominator degrees at most `2^s`. This follows by induction: a binary +,-,*,/ gate adds the rational degree bounds of its two arguments, so the maximum degree at most doubles per gate. Combining with Theorem 3 gives

**`s >= m-2=N/2-2`**.

This rules out `o(N)`-gate recovery of a nontrivial primitive conjugate from **one already known complex value alone** in that arithmetic model. It is not an `Omega(N log N)` theorem and does not exclude `O(N)` total multi-output computation. It also does not exclude a circuit that accesses the original bits, several Fourier representatives, an explicit coefficient vector, or uses special field-automorphism/complex-conjugation/bit-extraction or branching primitives. Some primitive conjugates are obtainable by direct complex conjugation if that is a priced unit-cost primitive; it is explicitly absent here.

## 4. Complete tiny exact case: N=8, beta=X[3] from alpha=X[1]

There are `m=4` independent binary coordinates, so 16 subset sums in the number field `K=Q(zeta_8)=Q[t]/(t^4+1)`.

- General all-length lower bound: polynomial degree >= 9, rational numerator/denominator degree >= 4.
- Actual **minimum polynomial degree is 11**. The code builds the unique degree-<16 Newton interpolant over K, verifies all 16 values and finds its last nonzero divided difference at degree 11.
- Actual **minimum rational numerator/denominator degree is 8**. Over K, every degree<=7 rational interpolation matrix has full column rank, so no nontrivial `P,Q` exist; the code produces a degree-8 rational function, verifies its denominator is nonzero at all 16 alpha values and checks all identities in K exactly.

Independently, `independent_modular_certificate.py` maps the ring of cyclotomic integers into F_998244353 with zeta_8 -> a primitive eighth root, checks all 16 nodes, and verifies:

- rank of 16x11 polynomial matrix = 11, but rank of its target-augmented matrix = 12. Thus degree <=10 impossible in characteristic zero;
- rank of 16x16 rational interpolation matrix (degrees <=7) = 16. Thus degree <=7 impossible in characteristic zero.

This independent modular rank is a valid **nonexistence certificate** because a nonzero determinant after specialization implies that determinant was nonzero over the original cyclotomic field. Existence at degree 8 is separately proved in characteristic zero by rational arithmetic; it is not inferred merely from modular rank deficiency.

## 5. Why the results don't imply a general faster or slower FFT

1. The minimal measurement count is an information-uniqueness statement. With an unbounded-precision exact scalar, one frequency can encode many bits in its algebraic structure. Ordinary finite-precision numbers cannot be assumed to retain those bits.
2. The degree lower bound concerns one scalar -> one other scalar, with no shared access to input. A global algorithm producing all conjugates together could share work in ways not captured here.
3. High algebraic degree does not imply exponential circuit size: repeated squaring gives a polynomial of degree 2^t with just t multiplications. Our rigorous circuit consequence is only `Omega(N)` gates for one restricted recovery.
4. We do not prove linear-time, sub-`NlogN`, or a new general FFT lower bound; no empirical FFT speedup is claimed.
5. The math is valid over complex numbers and the tiny certificates over a cyclotomic number field. A modular implementation over F_p alone would not establish the characteristic-zero claims, which is why we also supply proofs and exact number-field interpolation.
6. These algebraic observations are not a priority/novelty claim. Basic cyclotomic factorization, Galois conjugacy and interpolation are classical; we did not locate a source with these exact scoped degree inequalities in this search, which is **not** evidence of first discovery.

## 6. Reproduce

No third-party packages required:

```bash
cd fft_boolean_orbit_recovery
python -m unittest discover -s tests -v
python run_audit.py
python independent_modular_certificate.py
```

The tests cover N=2,4,8,16,32,64; exact power-basis DFT for conductor-orbit ambiguity; exhaustive 256-vector binary injectivity at N=8; 16 exact number-field Newton interpolation points; a nonvanishing degree-8 rational map; independent determinant/rank obstructions; exact cyclotomic field division and negative validation. `run_audit.py` writes `audit_results.json`, `independent_modular_certificate.py` writes `modular_certificate.json`.

### Prior work

- Original user-project checkpoint: `FFT_RESEARCH_CANONICAL_CHECKPOINT_2026-10-09.md`.
- Original Galois descriptor: `fft_adaptive_branch_boolean_gate/RESEARCH.md`.
- Previous spectral completion: `fft_boolean_spectral_completion/RESEARCH.md`.
- Background: cyclotomic Fourier / algebraic conjugacy; see https://arxiv.org/abs/2605.20062 (finite-field analogue, a **different** model), and classical algebraic number-field Galois theory.
- Related complexity techniques: https://arxiv.org/abs/1605.04207 (functional circuit lower bounds), not a direct claim of this precise theorem.

## 7. Next fresh-input research gate

The live question remains: can a **single shared circuit with access to the input and all relevant intermediate values** produce all primitive conjugates in asymptotically less than `N log N` elementary work? The one-scalar lower bound doesn't answer this. A candidate must exhibit a concrete multi-output DAG and cost it completely—no implicit conjugation primitive, no huge table and no free algebraic extraction. Any new circuit must be compared to a fair optimized FFT and #130 under a matched arithmetic model.
