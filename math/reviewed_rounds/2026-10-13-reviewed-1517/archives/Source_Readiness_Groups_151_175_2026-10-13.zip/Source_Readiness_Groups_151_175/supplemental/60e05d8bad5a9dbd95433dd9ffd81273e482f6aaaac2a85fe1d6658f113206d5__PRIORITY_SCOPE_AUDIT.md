# Rank 7: packed finite-word Fourier priority comparison

10 October 2026. Literature and model audit only. No new transform construction, no change to the frozen ranking, and no independent revalidation of the external OpenAI proof.

## Decision

The frozen rank-7 assessment survives this more precise comparison: strong packed-FFT antecedents are established, but the inspected literature does not by itself identify the complete current all-length, represented-dyadic, relative-l2 contract as a previously stated theorem. This is an unresolved priority question, not a finding of worldwide novelty.

The OpenAI comparator is real and correctly attributable. Its official preprint states the advertised exact all-length bound in a supplied-root, exact-complex arithmetic model. It cannot be used as a finite-word numerical comparator without an additional precision/stability analysis. Conversely, this project's low-precision word bound is not an exact-complex improvement over that paper.

One wording correction is warranted: the frozen overview's sentence “Unrestricted sub-N log N exact FFT remains unproved” needs an explicit project qualifier. Preserve the frozen artifact and append a clarification; do not read it as a current global status assertion.

## 1. Current project contract, with source lineage

The object audited is family `WORD_FOURIER`, rank 7, lead F132. The current accepted result combines:

1. The earlier all-length interpolation compiler, `INTERPOLATION_PROOF.md`, SHA-256 `c8a775230a824872c23fc48b351e03d63878154bcfb314a8cca689842e31fc8d`.
2. The packed dyadic backend, `DYADIC_PACKED_THEOREM.md`, SHA-256 `bb40decffd28b87a88065880363ff099b0d22071ef976bc67a8195c9b9db6d6f`.
3. `CONDITIONAL_ALL_LENGTH_THEOREM.md`, SHA-256 `71d85d704058bd245d14ce5aad65f747cb1a5b038e69510b21b41d3c8a217927`, whose backend hypothesis is supplied by item 2, together with `ALL_LENGTH_INDEPENDENT_ACCEPTANCE.md`.

These are distinct layers. The old compiler alone states an eventual bound of order N log N / log(log N/(t+log log N)), not the newer O(N(t+log log N)) bound. Its previous general correctness fallback was also more expensive. The new all-length paper supplies a separately charged conventional fallback, making the newer bound uniform over its stated precision domain. Do not silently attribute the stronger runtime to the original F132/Q01 manuscript alone.

Let n=ceil(log2(N+1)). For fixed input-format constant c, the current contract is:

| Axis | Current accepted project statement |
|---|---|
| Length | Every integer N>=2; N=1 is copied exactly |
| Input | Every represented complex dyadic vector in the stated format, with O(cn)-bit component descriptions and polynomial dynamic range; shared or separate exponents |
| Concrete format example | Real component a*2^e, with integer abs(a)<=N^c and abs(e)<=cn; c is fixed |
| Target | Normalized negative-sign DFT U_N, with all N entries explicitly returned |
| Error | Deterministic normwise bound norm(y-U_N x,2)<=2^(-t) norm(x,2), measured against the represented x |
| Precision | Supplied integer 2<=t<=n; parsing or generating t is a separate charge |
| Machine | Address-capable integer RAM, w=C(c)n bits, sufficiently large fixed C(c); +, -, multiplication, integer division, comparisons, shifts, Boolean operations, random access |
| Operand discipline | Online O_c(n)-bit operands use a fixed number of words/instructions; larger rational certification uses charged multiword work |
| Cold cost | O_c(N(t+log2(n+1))) operations, O_c(N) words |
| Setup | Coefficients, total response tables, leading-bit helpers, address work and any abandoned preparation are charged |
| Output cost | Scalar decoding, exponent restoration and N writes cost O(N); output is finite dyadic mantissa/exponent data |

The bound is O(N log log N) for fixed t or t=O(log log N), and o(N log N) for every supplied t=o(log N). At t=Theta(log N), it is only O(N log N). This is not a componentwise relative-error theorem: small or zero individual Fourier coefficients need not have small relative error. It is not a guarantee against an unknown real signal before its representation error.

The low-precision construction does genuine finite-state compression: its complex state uses b=Theta(t+log log N) bits although a decoded common-lattice numerator may need O(log N+t) bits. The exponent field, normalization, underflow bound and first-clipping argument are part of that distinction. Merely comparing the number of mantissa bits with a finite-field modulus loses this information.

The all-length wrapper makes one backend call at T=t+10, with M between 4N and 8N; it checks T<=log2(M)+1. It pays O(N(t+1)) for short interpolation sums and gathers, plus its own preparation, and uses a literal N-step/N-word preparation cap. This avoids treating cold work as amortized across many inputs.

The optional phase-separated refinement changes the rounded numerical program while retaining the theorem's asymptotic cost. Its O(N^(1/8)) preparation claim is for the dyadic backend only, not the all-length wrapper. It offers neither a stronger transform-time exponent nor a practical crossover certificate.

## 2. Chan et al.: the closest inspected packed mechanism

[Chan, Jin, Vassilevska Williams and Xu, v3, 19 December 2024](https://arxiv.org/html/2310.13174v3), Lemma 2.2 and Appendix B:

| Comparison axis | Primary statement |
|---|---|
| Arithmetic | Exact finite fields; Theta(log n)-bit word RAM |
| Whole task | Length-n convolution over F_p, prime p<=n^O(1), deterministic O(n log p) |
| Local DFT | Lemma B.6: t_i transforms over F_(p^L2), length m_i; packed input/output in O(1) words |
| Table condition | t_i=floor(0.1 log n/(m_i L2 log p)); m_i L2 log p<0.1 log n |
| Preprocessing | n^(0.2+o(1)); DFT-only enumeration n^(0.1+o(1)) |
| Precision/norm | No numerical t or Euclidean-error parameter |
| Representation | L2 log p bits per field element; no real dynamic-range parameter |
| Data movement | Lemma B.7 charges compact-array transpositions and reversal |
| Preparation | Field construction, roots, twiddles and tables counted |
| Output | Local guarantee assumes compact output; not N decoded complex dyadics |

Thus packed lookup transforms with charged movement/setup are antecedents. A numerical equivalence still needs precision, norm, range, length and output accounting; Appendix B supplies no such reduction.

### Model-matching judgment

The word-width order is compatible with the project's model; that does not make the mathematical task identical. A residue is not a rounded real number, and a field-extension root does not automatically approximate a complex root. Setting log p=t is therefore not a valid comparison proof.

Nor should the project claim that paying tables and permutations differentiates it categorically from earlier packed methods. The defensible candidate contribution is the particular combined numerical contract. To close priority, one needs either an earlier theorem with that contract or a fully charged reduction from a prior theorem. Neither was established in this audit.

## 3. Other primary comparators

### Fürer 2014: same scale of machine words, different size parameter

[Fürer, How Fast Can We Multiply Large Integers on an Actual Computer?, v1](https://arxiv.org/pdf/1402.1811), Definitions 1-2 and Theorems 1-2, uses O(log B)-bit registers with unit-cost multiplication/division, where B counts input bits. It obtains O(B) integer multiplication, including input/output, through FFT-based algorithms. The complex-FFT account uses Theta(B/log B) coefficient blocks and O(log B)-bit numerical accuracy. Its theorem is exact integer multiplication, not an all-vector relative-l2 DFT interface.

The parameter distinction matters: for N polynomial-size coefficients, B=Theta(N log N), so an O(B) bound becomes O(N log N). It does not imply O(N) work for an N-coordinate Fourier vector. This is a dimensional comparison, not a new reduction or lower bound. The same observation prevents claiming a bit-complexity breakthrough merely from the project's smaller word-operation count.

### Finite-precision all-group DFT precedent

[Cherniavskii, Gribanov, Malyshev and Pardalos, arXiv:2405.17001v5](https://arxiv.org/html/2405.17001v5), Section 1.4 and Theorem 18, supplies a numerical comparator beyond packing. For a finite abelian group of order N and rational-complex input, it gives additive infinity-norm error N^O(1) eta, with eta<N^(-C), using O(N(log N+gamma+log(1/eta))) rational operations on explicitly bounded-size operands; gamma is maximum input encoding size. Section 9 addresses coefficient approximation and error accounting. This is not a stated relative-l2 low-precision sub-NlogN theorem. The general model also allows word sizes larger than fixed Theta(log N), so the theorem's operand-size clause must be used when comparing a particular regime.

A relative numerical comparison would need a scale choice, a norm conversion, and the cost of the resulting eta and operand widths. An additive error statement alone is not enough. In particular, taking eta polynomially small retains a log N contribution in this displayed runtime. This audit inspected the statement, model and selected coefficient-generation discussion, not the complete proof of Section 9.3.

### Remaining older packing lead

Fredriksson and Grabowski's 2009 manuscript, Fast Convolutions and Their Applications in Approximate String Matching, and its later journal extension are relevant earlier word-packing leads. A [primary manuscript locator](https://citeseerx.ist.psu.edu/document?doi=c30b3abbb0106450853236609748fcb87bdf4f0e&repid=rep1&type=pdf) yielded indexed excerpts, but the full direct PDF open failed. No theorem-complete comparison with that source is claimed here.

## 4. Verified OpenAI exact comparator

The official paper is [An explicit power saving for the exact discrete Fourier transform](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-power-saving-for-the-exact-discrete-Fourier-transform-September-25-2026/main.pdf), author OpenAI, manuscript date 25 September 2026. The [official introduction source](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-power-saving-for-the-exact-discrete-Fourier-transform-September-25-2026/build/sections/introduction.tex) and [all-length section](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-power-saving-for-the-exact-discrete-Fourier-transform-September-25-2026/build/sections/all-lengths.tex) were read at the pinned repository commit.

It states a deterministic exact transform of every x in C^N, for every positive N, with

    O(N(log N)^theta(log log N)^(4-theta)),
    theta=log_(10^6)(10^6-6871402692000000/2^71)
         =0.99999999999978935615699598... .

Its stated corollary is O(N(log N)^(1-10^(-13))). This is not the formula of the sharper main theorem; the fixed log-log factor is absorbed into the slightly weaker logarithmic exponent asymptotically.

The model has separate exact complex registers and O(log N)-bit integer/address registers. Complex field operations have unit cost. Input-dependent DFT execution uses additions, subtractions and multiplication by prepared input-independent scalars. Division occurs in scalar preparation with nonzero denominators. One specified root zeta_(D*) is supplied, where D*<1024N^3; equivalently the model permits that root-of-unity call at unit cost. Other scalar preparation, schedule construction, index work and array organization are included. Complex coefficients and intermediate magnitudes are unrestricted. Numerical precision, stability and bit complexity are not claimed.

The output uses the unnormalized positive-sign convention F_N. A sign change is an index permutation, but normalization by 1/sqrt(N) and finite-precision realization should not be silently added to an exact scalar-generation model. The comparison here does not require such a conversion.

### Status and verification limits

The repository labels the document a preprint. Its existence, authorship attribution, statement and computational model are verified from primary source. No peer-review status or independent correctness certification is inferred from publication.

The official [formalization scope note](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/130.md) describes both a subsequential result and a separate uniform all-length formalization. The [comparator configuration](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/ComparatorChallenges/UniformFourier.json) points to the [actual Main.lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/OAI/Computability/FourierTransform/Main.lean), whose top-level proof terms were inspected. The comparator challenge's placeholder goals are not the proof file. No Lean build, dependency audit, axiom check or comparator run was performed here. The supplied formalization is therefore recorded as the repository's claim, not this audit's independent validation.

### Consequence for project language

Recommended appended clarification:

> No result in this project establishes an unrestricted exact sub-N log N DFT algorithm. A separate OpenAI preprint states an all-length bound in an exact-complex, supplied-root model; this audit verifies its statement and model, not independently the proof. The project's accepted rank-7 theorem concerns finite-word approximate evaluation with the represented-input relative-l2 guarantee above.

Neither result should be described as beating the other by comparing only their asymptotic formulas. Their elementary operations, input domains, accuracy requirements and root access differ.

## 5. Disposition and next evidentiary gate

- Keep family rank 7 and its frozen wording/data intact; add this as a supplemental audit.
- Retain the limited novelty status: strong classical mechanisms, exact complete-contract priority unresolved.
- The current theorem's paper-level acceptance remains its existing internal review status, not a production executor or measured performance result.
- A targeted next literature pass would inspect the full Fredriksson-Grabowski development and citations of Chan Appendix B for an earlier low-precision complex all-output theorem. It should stop short of inventing a conversion proof or claiming a missing theorem is absent worldwide.
- Any separate verification of the OpenAI proof or Lean development is a new proof-audit task; it was not required to establish attribution and model mismatch here.

## Access and preservation

Primary sources and exact source pins are recorded in `PRIMARY_SOURCE_ACCESS.json`; input hashes and the preserved ranking baseline are separate. The OpenAI raw PDF route failed, but the official LaTeX body was accessible and was used instead. No external service was modified. No user-source file or frozen ranking file was edited.
