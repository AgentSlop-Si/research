Q16 deterministic location decoder independent review

Verdict: ACCEPT, scoped to the frozen deterministic decoder and membership aggregator with the stated conservative source-level accounting model.

Read REVIEW_REPORT.md for the exact proof, source bindings, tests and exclusions. VERDICT.json records the scoped decision. Evidence files contain fresh independent controls and integrity receipts. Sources include the pinned decoder, exact mathematical specification and accepted interface evidence.

Run the independent controls with Python 3:
  python3 checks/independent_checks.py

Only sources/location_decode.py and its fresh in-memory test mutants are executed. accepted_buckets_source.py.txt is source evidence, never an executable dependency. Historical scientific programs and producer tests are not replayed.

No external records, repository or Sheet were changed. This archive is a private review deliverable. Source-bound BUCKETS composition, random scheduling, estimation, medians and full recovery remain outside scope.

Check the portable review seal with:
  python3 verify_review.py

checks/verify_bindings.py is the original review-time source-binding checker. It requires the three separately pinned input archives and recovered-source tree in the original review layout. Its completed receipts are included. The portable verifier and independent component controls do not require those external archive paths.
