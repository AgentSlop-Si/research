"""Independent exact controls for the frozen deterministic decoder only.

No producer tests, inverse/sort/hash helpers, historical executables, BUCKETS,
or random scheduler are imported. Python sorting, direct residue scans, and
per-round membership predicates are deliberately independent test oracles.
"""
from pathlib import Path
from collections import Counter
from itertools import combinations, product
import ast
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'sources/location_decode.py'
PIN = 'e3b592c40906d860d58c12cf7e21f17c6560cb8c95e7bcde4c161b0d52881c3a'
counts = Counter()

def check(value, message='assertion'):
    counts['assertions'] += 1
    if not value:
        raise AssertionError(message)

def load(name, source):
    module = type(sys)(name)
    sys.modules[name] = module
    exec(compile(source, name, 'exec'), module.__dict__)
    return module

def w(x):
    return max(1, len(bin(abs(x))) - 2)

def rank_ref(payload, q):
    return tuple(sorted(range(len(payload)), key=lambda j: (-(payload[j][0]**2+payload[j][1]**2), j))[:q])

def scan_ref(M, B, q, sigma, payload):
    T = M // B
    selected = rank_ref(payload, q)
    groups = {j: [] for j in selected}
    for i in range(M):
        x = sigma*i % M
        j = ((2*x+T)//(2*T)) % B
        if j in groups:
            # This offset is inverse-free and determines the specified order.
            groups[j].append(((x-j*T+T//2) % M, i))
    return selected, tuple(i for j in selected for _,i in sorted(groups[j]))

def aggregate_ref(M, rounds):
    threshold = -(-len(rounds)//2)
    return tuple(i for i in range(M) if sum(i in r for r in rounds) >= threshold)

def verify_decode(p, M, B, q, sigma, payload, bits=0):
    L = p.Ledger()
    got = p.decode_round(M,B,q,sigma,payload,bits,L)
    expected = scan_ref(M,B,q,sigma,payload)
    check((got.selected_buckets,got.memberships)==expected,'decode/oracle')
    n = q*(M//B)
    check(len(got.memberships)==n and len(set(got.memberships))==n,'decode distinct count')
    check(all(type(i) is int and 0<=i<M for i in got.memberships),'decode domain')
    check(L.operations['bucket_read']==B and L.operations['bucket_score']==B,'bucket charges')
    check(L.operations['bucket_selected']==q and L.operations['membership_output']==n,'output charges')
    check(L.operations['parameter_input']==5+2*B,'parameter charges')
    check(L.allocated_slots==6*B+2*q+2*n,'decode allocation')
    check(L.operations['sort_copy']==B*(B-1).bit_length(),'decode sort copies')
    counts['decoder_calls']+=1
    return got

def verify_aggregate(p,M,B,q,rounds):
    L = p.Ledger()
    got=p.aggregate_memberships(M,B,q,rounds,L)
    check(got==aggregate_ref(M,rounds),'aggregate/oracle')
    n=q*(M//B); N=len(rounds)*n; t=(len(rounds)+1)//2
    check(len(got)<=min(M,N//t),'sharp support')
    check(L.operations['membership_read']==N,'membership reads')
    check(L.operations['complete_membership_copy']==N,'complete copies')
    check(L.operations['round_read']==len(rounds),'all rounds validated')
    check(L.allocated_slots==6*N+len(got),'aggregate allocation')
    check(L.operations['parameter_input']==3+N,'aggregate parameter charge')
    check(L.operations['sort_initial_copy']==2*N,'sort initial copies')
    counts['aggregator_calls']+=1
    return got

def expected_rejection(call,L):
    old=L.report()['total_bit_work_upper']
    try:
        call()
    except ValueError:
        pass
    else:
        raise AssertionError('malformed input accepted')
    check(L.report()['total_bit_work_upper']>old,'retained rejection work')
    counts['rejection_cases']+=1

def exact_matrix(p):
    for m in range(2,8):
        M=2**m
        for b in range(1,m):
            B=2**b
            families=(tuple((0,0) for j in range(B)),
                      tuple(((j%5)-2,(3*j%7)-3) for j in range(B)),
                      tuple(((1,-1,0,0)[j%4],(0,0,1,-1)[j%4]) for j in range(B)))
            # All q for B<=16, additional interior q beyond producer matrix.
            qs=range(B+1) if B<=16 else sorted({0,1,2,3,B//3,B//2,B-3,B-1,B})
            for sigma in range(1,M,2):
                for q in qs:
                    for payload in families:
                        verify_decode(p,M,B,q,sigma,payload)
    # Endpoint membership: enumerate every bucket, odd multiplier and endpoint.
    for M in (4,8,16,32,64,128,256):
        for B in (2**b for b in range(1,M.bit_length()-1)):
            T=M//B
            for sigma in range(1,M,2):
                inv=pow(sigma,-1,M) # oracle library inverse, not production helper
                allgot=p.decode_round(M,B,B,sigma,((0,0),)*B,0)
                for j in range(B):
                    row=allgot.memberships[j*T:(j+1)*T]
                    lo=(inv*(j*T-T//2))%M
                    last=(inv*(j*T+T//2-1))%M
                    right=(inv*(j*T+T//2))%M
                    check(row[0]==lo and row[-1]==last,'half-open endpoints')
                    check(right not in row,'right endpoint excluded')
                    counts['endpoint_cases']+=1

def aggregates(p):
    base=list(combinations(range(4),2))
    for L in range(1,6):
        for seq in product(base,repeat=L):
            verify_aggregate(p,4,2,1,seq)
    for L in range(1,18):
        rows=tuple(tuple(((7*j+3*i)%16) for i in range(4)) for j in range(L))
        verify_aggregate(p,16,4,1,rows)
        check(verify_aggregate(p,16,4,1,tuple(reversed(rows)))==aggregate_ref(16,rows),'round order')
        verify_aggregate(p,16,4,1,((11,2,9,4),)*L)
    # L=2 threshold one includes both disjoint sets. L=3 tight odd bound.
    check(verify_aggregate(p,8,2,1,((0,1,2,3),(4,5,6,7)))==tuple(range(8)),'even tight bound')
    check(verify_aggregate(p,8,2,1,((0,1,2,3),(0,1,4,5),(2,3,4,5)))==tuple(range(6)),'odd tight bound')
    for L in (1,2,3,17,513):
        verify_aggregate(p,8,4,0,((),)*L)

def widths_and_rejections(p):
    for width in (0,1,52,53,54,127,1024,4096,65536):
        z=2**width
        # Signed common-grid exact ties and a one-unit squared-energy gap.
        payload=((-z,0),(z,1),(0,-z),(0,0))
        for bits in (0,1,2**4096+19):
            got=verify_decode(p,8,4,3,5,payload,bits)
            check(got.selected_buckets==(1,0,2),'one-unit energy separation')
            counts['large_width_cases']+=1
    # Widely represented M is usable via q=0 without materializing 2**bits.
    for m in (257,1024,4096):
        M=2**m
        for sigma in (1,3,M//2+1,M-1):
            L=p.Ledger()
            got=p.decode_round(M,2,0,sigma,((1,0),(0,1)),2**(m+3),L)
            check(got.selected_buckets==() and got.memberships==(),'large geometry q0')
            check(L.max_parameter_bits==m+4,'exponent encoding retained')
            counts['large_geometry_cases']+=1
    # Independent modular-inverse checks include worst-case Euclidean-like pairs.
    for m in range(2,12):
        for sigma in range(1,2**m,2):
            L=p.Ledger();u=p._inverse_odd(sigma,2**m,m,L)
            check(u==pow(sigma,-1,2**m),'inverse independent oracle')
            check(L.operations['euclid_step']<=2*m+2,'inverse bound')
            counts['inverse_cases']+=1
    for m in (127,521,2048):
        for sigma in (3,5,2**m-1,(2**m)//3|1,((2**m)*5)//8|1):
            L=p.Ledger();u=p._inverse_odd(sigma,2**m,m,L)
            check(u==pow(sigma,-1,2**m),'large inverse')
            check(L.operations['euclid_step']<=2*m+2,'large inverse bound')
            counts['inverse_cases']+=1
    class Trap:
        def __getattribute__(self,name):
            if name in ('__int__','__index__','__len__','__iter__','__bool__'):
                raise AssertionError('callback reached')
            return object.__getattribute__(self,name)
        def __int__(self): raise AssertionError('int callback')
        def __index__(self): raise AssertionError('index callback')
        def __len__(self): raise AssertionError('length callback')
        def __iter__(self): raise AssertionError('iteration callback')
    class IntSubclass(int): pass
    class TupleSubclass(tuple): pass
    base=dict(M=8,B=4,q=1,sigma=3,numerators=((1,0),)*4,bits=0)
    bad={
      'M':(False,3,0,-8,12,2**65536+1,Trap(),IntSubclass(8)),
      'B':(True,0,1,3,8,2**65536,Trap()),
      'q':(False,-1,5,2**65536,Trap()),
      'sigma':(False,0,2,8,-1,2**65536+1,Trap()),
      'bits':(False,-1,-(2**65536),Trap()),
      'numerators':([],(),((1,0),)*3,((1,0),)*5,TupleSubclass(((1,0),)*4),
         ((1,0), (1,), (1,0),(1,0)), ((1,0),(1,0,2),(1,0),(1,0)),
         ((1,0),[1,0],(1,0),(1,0)),((1,0),(Trap(),0),(1,0),(1,0)),
         ((1,0),(2**65536,False),(1,0),(1,0)))
    }
    L=p.Ledger()
    for field,values in bad.items():
        for value in values:
            args=dict(base);args[field]=value
            expected_rejection(lambda a=args:p.decode_round(**a,ledger=L),L)
    check(L.max_parameter_bits==65537,'bad widths recorded')
    for rounds in ((),[],((0,1),),((0,1,2,3),[0,1,2,3]),((0,1,2,False),),
                   ((0,1,2,8),),((0,1,2,-1),),((0,1,2,2**65536),),
                   ((0,1,2,3),(0,1,2,2)),((0,1,2,3),TupleSubclass((0,1,2,3)))):
        expected_rejection(lambda r=rounds:p.aggregate_memberships(8,2,1,r,L),L)
    # Empty-output requests do not bypass shape, pair, or residue recognition.
    args=dict(base);args['q']=0;args['numerators']=((0,0),(0,0),(0,False),(0,0))
    expected_rejection(lambda:p.decode_round(**args,ledger=L),L)
    expected_rejection(lambda:p.aggregate_memberships(8,4,0,((),(0,)),L),L)
    # A rejection after a previous successful call never resets the ledger.
    p.decode_round(**base,ledger=L)
    before=L.report()
    expected_rejection(lambda:p.aggregate_memberships(8,2,1,((0,1,2,3),(0,1,2,2)),L),L)
    check(L.operations['decode_call']==before['operations']['decode_call'],'ledger kept prior success')
    check(L.operations['complete_membership_copy']>=4,'earlier accepted round charged')
    return L.report()

def accounting(p):
    class Recorder(p.Ledger):
        def __init__(self):
            super().__init__();self.rows=[];self.notices=[];self.reservations=[]
        def record(self,kind,inputs,out):
            self.rows.append((kind,inputs,out))
            return super().record(kind,inputs,out)
        def event(self,kind,count=1):
            self.notices.append((kind,count));super().event(kind,count)
        def allocate(self,count):
            self.reservations.append(count);super().allocate(count)
    L=Recorder(); rounds=[]
    for sigma in (7,11,19,31,63):
        got=p.decode_round(64,16,5,sigma,tuple(((-1)**j*(2**(j+10)+j),3*j-19) for j in range(16)),2**129,L)
        rounds.append(got.memberships)
    p.aggregate_memberships(64,16,5,tuple(rounds),L)
    expected_rejection(lambda:p.aggregate_memberships(8,2,1,((0,1,2,3),(0,1,2,2)),L),L)
    expected_rejection(lambda:p.decode_round(8,4,1,1,((1,0),(2**2048,False),(0,0),(0,0)),0,L),L)
    counts['traced_records']=len(L.rows)
    ops=Counter(); work=0; storage=0; mx=1; inputs_total=0; inputs_mx=1
    semantics={'add':lambda a,b:a+b,'subtract':lambda a,b:a-b,'multiply':lambda a,b:a*b,
               'floor_divide':lambda a,b:a//b,'modulo':lambda a,b:a%b,
               'bit_and':lambda a,b:a&b,'bit_length':lambda a:len(bin(a))-2}
    for kind,ins,out in L.rows:
        if kind in semantics: check(out==semantics[kind](*ins),'primitive semantics '+kind)
        sizes=[w(x) for x in tuple(ins)+(out,)]
        ops[kind]+=1;work+=16*(2+sum(sizes))**2;storage+=sizes[-1]+1;mx=max(mx,*sizes)
        if kind=='parameter_input':inputs_total+=sizes[-1];inputs_mx=max(inputs_mx,sizes[-1])
    for kind,num in L.notices:ops[kind]+=num
    slots=sum(L.reservations);ops['allocated_slots']+=slots;storage+=slots
    E=sum(ops.values())+256;D=mx+w(E)+2
    expected=dict(operations=dict(sorted(ops.items())),arithmetic_bit_work_upper=work,
                  bookkeeping_bit_work_upper=512*E*D**2,total_bit_work_upper=work+512*E*D**2,
                  cumulative_storage_upper_bits=storage+512*E*D,max_observed_integer_bits=mx,
                  allocated_slots=slots,parameter_input_bits=inputs_total,max_parameter_bits=inputs_mx)
    actual=L.report()
    for field,value in expected.items():check(actual[field]==value,'reconstructed '+field)
    return dict(record_count=len(L.rows),event_count=sum(n for _,n in L.notices),report=actual)

def smoke(p):
    verify_decode(p,32,8,3,5,((3,4),(-5,0),(0,-5),(4,4),(0,6),(0,0),(0,1),(1,0)))
    verify_decode(p,8,4,2,3,((0,0),)*4)
    verify_decode(p,8,4,1,3,((2**53,0),(2**53,1),(0,0),(0,0)),2**256)
    verify_aggregate(p,8,2,1,((0,1,2,3),(4,5,6,7)))
    verify_aggregate(p,8,2,1,((0,1,2,3),(0,1,4,5),(2,3,4,5)))
    verify_aggregate(p,8,2,1,((0,1,2,3),(0,1,4,5),(0,2,4,6)))
    verify_aggregate(p,8,2,1,((7,0,1,3),)*3)
    L=p.Ledger();expected_rejection(lambda:p.aggregate_memberships(8,2,1,((0,0,1,2),),L),L)

def mutations(source):
    targets=[
      ('drop_real_energy','L.mul(real, real)','L.mul(0, real)'),
      ('drop_imaginary_energy','L.mul(imag, imag)','L.mul(0, imag)'),
      ('ascending_energy','a[0] > b[0]','a[0] < b[0]'),
      ('reverse_tie_priority','a[1] <= b[1]','a[1] >= b[1]'),
      ('wrong_inverse','inverse = L.mod(old_t, M)','inverse = sigma'),
      ('shift_interval_one','start = L.sub(L.mul(j, T), half)','start = L.add(L.sub(L.mul(j, T), half), 1)'),
      ('skip_last_residue','for offset in range(T):','for offset in range(T-1):'),
      ('skip_final_modulo','index = L.mod(L.mul(inverse, residue), M)','index = L.mul(inverse, residue)'),
      ('floor_threshold','threshold = L.div(L.add(number, 1), 2)','threshold = L.div(number, 2)'),
      ('strict_threshold','if votes >= threshold:','if votes > threshold:'),
      ('skip_distinctness','if ordered[at] == ordered[L.sub(at, 1)]:','if False:'),
      ('drop_bucket_read_charge',"L.event('bucket_read')","L.event('other_read')"),
      ('drop_membership_charge',"L.event('membership_output')","L.event('other_output')"),
      ('drop_exponent_charge','L.parameter(bits)','pass'),
      ('drop_final_tuple_allocation','L.allocate(L.add(q, count))','L.allocate(0)'),
      ('drop_complete_copy_charge',"L.event('complete_membership_copy')","L.event('other_copy')")]
    results=[]
    for name,old,new in targets:
        check(source.count(old)==1,'unique mutation target')
        mod=load('independent_mutant_'+name,source.replace(old,new))
        try:smoke(mod)
        except (AssertionError,ValueError,ArithmeticError,IndexError) as e:
            results.append(dict(name=name,detected=True,signal=type(e).__name__))
        else:raise AssertionError('surviving mutant '+name)
    counts['mutants_detected']=len(results)
    return results

def main():
    raw=SOURCE.read_bytes();check(hashlib.sha256(raw).hexdigest()==PIN,'source pin')
    source=raw.decode(); tree=ast.parse(source)
    check(all(not(isinstance(n,ast.Constant) and isinstance(n.value,float)) for n in ast.walk(tree)),'no float constants')
    imports=[n.names[0].name for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
    check(set(imports)=={'Counter','dataclass'},'stdlib-only source dependencies')
    p=load('independent_frozen_candidate',source)
    exact_matrix(p);aggregates(p)
    rejected=widths_and_rejections(p);trace=accounting(p)
    before_mutation=dict(counts)
    mutants=mutations(source)
    result=dict(status='PASS',source_sha256=PIN,controls_before_mutants=before_mutation,
                total_assertions_including_mutant_detection=counts['assertions'],mutants=mutants,
                accounting=trace,rejected_path_cumulative_ledger=rejected,
                exclusions=['BUCKETS execution','scheduler','randomness claims','estimation','medians','integrated recovery','host totality'],
                historical_code_executed=False,producer_tests_executed=False)
    (ROOT/'evidence/INDEPENDENT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
