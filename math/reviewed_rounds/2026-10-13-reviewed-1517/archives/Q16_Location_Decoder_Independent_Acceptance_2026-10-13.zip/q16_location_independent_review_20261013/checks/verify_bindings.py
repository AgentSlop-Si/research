"""Review-time read-only binding checks; no scientific source execution."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'audit/evidence/BINDINGS.json'
def sha(data):return hashlib.sha256(data).hexdigest()
pins={
 'candidate':(ROOT/'Q16_Exact_Location_Decoder_Candidate_2026-10-13.zip','3e804cfe03d7af5ec94c1e3f6df7502e93e3e33044e1d689b1ed5171b30aa4a3'),
 'buckets':(ROOT/'dependencies/Q16_Certified_BUCKETS_Candidate_2026-10-13.zip','f98a315abe8a19cfedc08b97b13d3d4353b1f2a743aa77281c96c46500d4f9da'),
 'edition_acceptance':(ROOT/'dependencies/Q16_Recovered_Edition_Independent_Acceptance_2026-10-13.zip','dee91201ce36572b432da5267374829b46d1f2a3bbfcfa1b172d787923a19857')}
receipts={}
for name,(path,pin) in pins.items():
 assert sha(path.read_bytes())==pin
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 receipts[name]={'sha256':pin,'crc':'PASS'}
with zipfile.ZipFile(pins['candidate'][0]) as z:
 prefix='q16_location_decode_20261013/'
 manifest=z.read(prefix+'MANIFEST.json');seal=json.loads(z.read(prefix+'SEAL.json'))
 assert sha(manifest)==seal['manifest_sha256']
 items=json.loads(manifest)['files']
 for item in items:
  data=z.read(prefix+item['path']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
 assert sha(z.read(prefix+'src/location_decode.py'))==seal['production_source_sha256']
 assert z.read(prefix+'src/location_decode.py')==(ROOT/'audit/sources/location_decode.py').read_bytes()
 receipts['candidate']['manifest_files']=len(items)
 receipts['candidate']['source_sha256']=seal['production_source_sha256']
with zipfile.ZipFile(pins['buckets'][0]) as z:
 source=z.read('q16_certified_buckets_20261013/src/buckets.py')
 assert sha(source)=='df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1'
 assert source==(ROOT/'audit/sources/accepted_buckets_source.py.txt').read_bytes()
 receipts['buckets']['source_sha256']=sha(source)
for name,pin in [('ALGORITHM.txt','17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1'),('PROOF.md','0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b'),('BUCKETS_ACCEPTANCE.json','e6bd146b7765e5b37a2f4ad1faf6425d254687d28242d6c0983258440db4f804')]:
 data=(ROOT/'audit/sources'/name).read_bytes();assert sha(data)==pin
 receipts[name]={'sha256':pin,'bytes':len(data)}
for name,original in [('ALGORITHM.txt','E_BETA_ALGORITHM_V1.txt'),('PROOF.md','E_BETA_PROOF_V1.md')]:
 original_path=ROOT.parent/'q16_recovered_from_context_20261013/reconstructed'/original
 assert original_path.read_bytes()==(ROOT/'audit/sources'/name).read_bytes()
 receipts[name]['recovered_source_byte_identical']=True
receipts['status']='PASS'
OUT.write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts,indent=2))
