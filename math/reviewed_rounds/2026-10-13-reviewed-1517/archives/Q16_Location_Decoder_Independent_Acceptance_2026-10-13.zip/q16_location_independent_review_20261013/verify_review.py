"""Portable archive integrity validation; does not execute scientific code."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest_bytes=(root/'MANIFEST.json').read_bytes()
seal=json.loads((root/'SEAL.json').read_text())
assert hashlib.sha256(manifest_bytes).hexdigest()==seal['manifest_sha256']
manifest=json.loads(manifest_bytes)
for record in manifest['files']:
 data=(root/record['path']).read_bytes()
 assert len(data)==record['bytes'],record['path']
 assert hashlib.sha256(data).hexdigest()==record['sha256'],record['path']
source=(root/'sources/location_decode.py').read_bytes()
assert hashlib.sha256(source).hexdigest()==seal['reviewed_source_sha256']
verdict=json.loads((root/'VERDICT.json').read_text())
assert verdict['overall']=='ACCEPT' and verdict['required_repairs']==[]
print(json.dumps({'status':'PASS','payload_files':len(manifest['files']), 'reviewed_source_sha256':seal['reviewed_source_sha256']},indent=2))
