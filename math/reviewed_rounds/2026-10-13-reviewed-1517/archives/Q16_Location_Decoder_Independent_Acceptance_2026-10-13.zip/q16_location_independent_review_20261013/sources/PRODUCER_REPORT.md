# Q16 exact location-index decoder and membership aggregation

## Status and selected boundary

This is a newly authored, source-pinned **candidate awaiting independent implementation review**. It realizes the deterministic ranking, inverse-index enumeration, and membership-majority portions of `ALGORITHM.txt` step 5. It does not implement the random round scheduler or call BUCKETS. It consumes the common-grid numerical bucket payload specified by the accepted BUCKETS component.

The exact specification is copied in `sources/ALGORITHM.txt` and `sources/PROOF.md`. Relevant proof locations are sections 3 (half-open hash and inverse images), 5 (exact magnitude ordering with ties), and 7 (explicit membership sorting and support bound). `sources/PRIOR_NEXT_TASKS.json` records the prior recommendation, whose BUCKETS subtask is now independently accepted. That acceptance is copied in `sources/BUCKETS_ACCEPTANCE.json` and pins BUCKETS source SHA256 `df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1`. Its accepted WINDOW dependency has SHA256 `e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59`.

Only the new module and new controls in this packet were executed. No historical or predecessor scientific code was run, copied into the executable dependency path, or modified. The accepted ledger's documented conservative arithmetic model was reused in a fresh, standalone implementation; its use here is a new review obligation, not an inherited acceptance of new source.

## Exact public interfaces

### decode_round(M, B, q, sigma, numerators, bits, ledger=None)

- M and B are exact Python integers, powers of two, M>=4 and 2<=B<=M/2. Thus T=M/B is an even integer >=2. Booleans and integer-coercion callbacks are rejected.
- q is an exact integer with 0<=q<=B. The q=0 case is a reduced component extension; the E(beta) caller has q=512k>0.
- sigma is an odd integer in [1,M). It is supplied, not generated, by this component.
- numerators is an exact immutable tuple of B exact immutable pairs of signed integers. Pair j represents `(a_j + i b_j) 2^(-bits)`. The signed numerators may have any finite represented widths.
- bits is any nonnegative exact integer. The exponent is kept symbolic: **no 2^bits is constructed**, since the common scale cancels from ranking. Its input width is still charged.
- ledger is trusted instrumentation state, not part of the adversarial scientific input. Omitting it constructs the included Ledger. Supplying the same Ledger across calls retains all earlier work, including failures. Test-only Trace subclasses are measurement tools, not a serialization/security interface.

Return `RoundCandidates(selected_buckets, memberships)`, an immutable record of two tuples. `selected_buckets` contains exactly q distinct bin indices in descending squared-magnitude order, ties by increasing bin index. For each selected bucket in that order, `memberships` lists exactly T preimages, in increasing half-open residue-offset order. The qT returned indices are distinct but generally unsorted. Every integer is a valid residue in [0,M). No certificate fields, roots, random bits or numerical coefficients are included in this output.

For a genuine accepted BUCKETS result `r`, the exact numerical adapter is `decode_round(M,B,q,sigma,r.numerators,r.bits,ledger)`. This is an interface correspondence, not a claim that BUCKETS, its parameter preparation, or its probability premises have been executed in this packet. The caller must pay all those operations separately. The decoder cannot authenticate the origin of arbitrary supplied numerical payloads.

### aggregate_memberships(M, B, q, rounds, ledger=None)

M,B,q have the same domain. `rounds` is a nonempty immutable tuple of L immutable tuples. Each tuple contains exactly qT exact integer indices in [0,M), without duplicate indices within that round. Different rounds may be identical and may be in any order. The lists need not arrive sorted. The accumulator pays for recognition and a sort of every round to validate distinctness before sorting the complete membership list.

Return a sorted immutable tuple containing exactly those indices occurring in at least t=ceil(L/2) rounds. L may be any positive represented round count; the source's caller uses L=4m+1. The even-L extension uses the stated threshold, which need not be a strict majority. L=0 is rejected because threshold zero would make an unrestricted “count>=0” definition include all M indices. For q=0, every per-round empty tuple is validated and the result is empty.

Both APIs report malformed scientific inputs with ValueError. All work before rejection is retained in the provided ledger. The two internal arithmetic invariant failures cannot occur on valid inputs under exact arithmetic, by the proofs below. There is no timeout, cap refusal, random rejection, precision refinement or fallback. Ordinary host memory exhaustion for enormous valid output lists remains a deployment gap; this packet proves the finite source model, not totality of a particular host.

## Correctness proof

### Ranking

Squared magnitude of bucket j is `(a_j^2+b_j^2) 2^(-2 bits)`. The positive common factor cancels. Two exact signed multiplications and one addition therefore produce an exact ordering key. No floating conversion, square root, absolute-value comparison, tolerance, rounding or approximate branch preservation is used. The explicit merge comparator orders larger energy first, then lower index first. This is a total ordering because bucket indices are distinct. Bottom-up merging preserves the ordered-prefix invariant; after ceil(log2 B) passes all B entries are in the required order. Taking its first q indices implements the specification including exact energy ties.

This establishes the **ordering step** in the source's robust-location lemma. It does not by itself establish that supplied buckets approximate ideal buckets or that a coordinate is heavy.

### Modular inverse and termination

Since M is a power of two and sigma is odd, gcd(M,sigma)=1. Extended Euclid maintains `r = a M + t sigma` for the current remainder and the analogous identity for the preceding remainder, initially `(M,0)` and `(sigma,1)` for remainder/coefficient pairs. Replacing a pair by `(r_previous - quotient*r, t_previous - quotient*t)` preserves the invariant. Nonzero remainders decrease strictly and every two consecutive divisions decrease the earlier positive remainder by at least a factor of two. Starting below or at 2^m, at most 2m+2 iterations suffice. The implementation uses that explicit upper loop bound and checks termination and gcd=1. Its last coefficient modulo M is the inverse; it also checks the exact modular product.

For a deliberately conservative width bound, each quotient is at most M. If C bounds the absolute values of the two current coefficients, the next has size at most (M+1)C. Starting at C=1 over at most 2m+2 steps gives coefficient bit width O(m^2). Remainders, quotients and the returned modular inverse have O(m) bits. This elementary bound suffices for the claimed polynomial overhead; it does not assume a tighter textbook coefficient bound.

### Unknown-index enumeration and endpoints

Let x be any residue in [0,M), and define

    h(x) = floor((x+T/2)/T) mod B.

On the circle of M=BT residues, the half-open T-point intervals

    S_j = {jT-T/2, ..., jT+T/2-1} mod M

partition the residues. Indeed x in S_j if and only if h(x)=j. Bucket zero's wrapped negative endpoint is included, whereas the right endpoint belongs to the next bucket. Since T is even, no fractional endpoint convention is involved.

Multiplication by the computed inverse u is a permutation of residues. Thus `u S_j mod M` is precisely the preimage set of j under `h_sigma(i)=h(sigma*i mod M)`. For each selected j the implementation forms each signed value `jT-T/2+offset`, reduces it modulo M, and multiplies by u with an exact product and a further modulo. It uses no assumed frequency locations and never scans all M frequencies to discover preimages. Distinct selected intervals are disjoint and multiplication is bijective, so the output has exactly qT distinct valid indices in the declared order, for every input bucket payload and every allowed sigma.

### Aggregation and all-path support bound

The paid per-round validation establishes that occurrences and round memberships are the same counts. The complete explicit list contains N=LqT entries. Sorting and scanning runs of equal indices gives every occurrence count exactly. A value is appended exactly when that count is at least t=ceil(L/2). Since t>=1, absent indices are correctly excluded; no length-M counter array is needed. The resulting list is sorted and distinct.

Every retained index uses at least t of the N list entries, proving the sharp deterministic bound

    |I'| <= min(M, floor(N/t)) <= 2qT.

The program also checks `len(output)*t <= N` exactly. This argument is independent of input correctness events, randomness, numerical accuracy and whether the rounds are identical. Every bad location round's qT candidates is retained in the charged temporary list; no successful-round conditioning is used to reduce costs.

## Complete accounting boundary

There are exactly zero random-bit reads, zero entropy-source calls, zero input-vector queries, zero transcendental evaluations and zero coefficient-preparation operations in these two deterministic interfaces. Sigma and the buckets are read input values. This is **not** a statement that the full algorithm has zero randomness or construction cost: it still owes precisely the source's fresh fair-bit rounds, preparation, BUCKETS calls and the other operations outside this boundary. In particular caller-supplied sigma is not evidence of uniformity or independence.

The public inputs are already represented integer/tuple values, not text, JSON or a file parser. Their retained input storage belongs to the caller; every accessed integer's full width is recorded before its mathematical domain check. Exact tuple recognition performs no user callback. M,B,q,sigma,bits, bucket numerators, outer lengths, pair lengths, round counts, per-round lengths and each membership index are charged. Malformed huge integer fields are recorded before rejection. Unread tails of malformed inputs are not scanned or claimed validated. Parameter-field representation, malformed-path work and q=0 validations are not free.

Every arithmetic primitive records operand and result widths b_i and charges `16 (2+sum b_i)^2` schoolbook units. All exact multiplications, sums, divisions, modular reductions and bitwise geometry tests use these primitives. All computed integers contribute their produced width to cumulative storage. Sorts use explicit bottom-up merging, not Python's opaque comparison-sort implementation. Every sort comparison, copy, pass and merge has an event; every Euclidean iteration, bucket read, score, selected bucket, membership output, round validation, membership read, duplicate comparison and equal-run step has a charge.

Let E=sum(operation event counts)+256 and D=max recorded integer width+bit_length(E)+2. The report adds `512 E D^2` control work and `512 E D` cumulative-storage bits. This deliberately conservative fixed-arity source-model envelope covers type/shape tests, signs and comparisons, branch decisions, loops and address arithmetic, list/tuple records and copies, ledger counters and returned metadata. Explicit allocation events include constructed score arrays, both merge buffers, selected arrays, membership arrays, complete-list storage, aggregate output storage, and immutable tuple copies. Numeric outputs and final candidate serialization into the returned tuples are paid. The model is not a count of Python interpreter instructions, a wall-time claim, physical I/O pricing, or measured resident memory. Any downstream text/file serialization is a separate caller operation.

For one decoder call, write H=max(1, all bucket numerator bit lengths), e=bit_length(bits), m=log2 M, n=qT. There are

    O(B(1+log B) + n + m)

events at widths bounded by O(H+e+m^2), plus event/address-counter widths. Scores have at most 2H+1 bits, all indices and addresses use at most 2m+O(1) bits, and the coarse Euclid coefficient bound is O(m^2). Squared-energy comparison at width H is therefore paid even if H is arbitrarily larger than m. Huge symbolic exponents contribute their encoding width e, not their numeric value as a materialized binary denominator.

For the accumulator, N=LqT and all indices have O(m) bits after validation. Recognition, the paid per-round distinctness sorts, the complete sort and counting use

    O(L + N(1+log(qT+1)+log(N+1)))

events with additional count/address width O(log(L+1)+log(N+1)). The O(L) term is essential when q=0. Input validation failures can involve larger widths, and the ledger charges the actual fields reached before rejection; their cost is not bounded by the valid-domain small-width formula.

With E_0 the event bound and D_0 the relevant integer-width bound just described, the report has conservative bit work O(E_0(D_0+log(E_0+1))^2) and cumulative auxiliary storage O(E_0(D_0+log(E_0+1))). It overcounts live memory and is an all-path finite upper account.

Under the original E(beta) parameter premises, bucket output widths are O_d(m), bits=16m+16, q=512k, L=4m+1 and B,qT<=M. L decoder calls plus aggregation therefore fit

    O((LB + LqT) poly_d(m))

work and cumulative auxiliary storage, a part of the source's full resource shape. This conditional statement does not drop arbitrary supplied H, exponent-encoding width or L from the general-interface account. Computing beta-dependent parameters and proving branch eligibility are upstream obligations; beta is not an input to this component and no beta-width charge is silently transferred here.

## Exact and adversarial evidence

The numerical oracle does not import the production inverse, comparator or sorting function. At small M it enumerates all M frequencies, groups them by the exact hash formula, and independently builds the permutation inverse-image dictionary. That deliberately expensive test-only scan is not production work.

The exhaustive matrix covers M=4 through 256, every allowed power-of-two B, every odd sigma, q choices 0,1,B/2,B (deduplicated), and three bucket families including all-zero ties and signed nonuniform complex values. There are 17,694 decoder calls. Every call checks exact rank, set of hash preimages, declared enumeration order, distinctness/cardinality and charged operation counts. Boundary controls check both endpoints for every bucket with sigma=1 and M-1.

Aggregation is checked against a direct per-round membership-count oracle for all ordered round sequences through L=4 over the six 2-subsets of a 4-element universe, plus all five-round multisets and their reversed orders: 2,058 calls. Additional controls attain the sharp even- and odd-round support bounds, accept identical rounds, and validate 1,025 empty q=0 rounds with a nonzero paid validation cost. These tests use reduced deterministic components, not the full sparse branch.

Large-width controls include 65,537-bit input fields and 131,073-bit energy scores. Exact near-ties differing by one at squared energies around 2^106, 2^200 and 2^8192 select the larger energy correctly, both at zero and enormous symbolic exponent. Malformed geometry, booleans, mutable containers, bad shapes, invalid residues, within-round duplicates, L=0, oversized fields and q=0 shortcuts are checked. An object exposing integer-coercion hooks is rejected without invoking them.

Twelve separate copies of the fresh source are mutated and detected: imaginary-energy omission, reversed index ties, ascending energy order, wrong inverse, shifted half-open interval, a missing preimage, floor majority, strict instead of specified threshold, omitted distinctness recognition, missing bucket-read charge, missing membership-output charge and missing parameter-width charge. Mutants never modify the production file. A separate Trace ledger reconstructs primitive arithmetic costs, output widths, allocation, event counters and cumulative control/storage envelopes from the primitive records, including a malformed-input path after earlier successful calls.

Machine receipts in `results/` provide exact final assertion totals and the final source hash. Tests corroborate the general proof; bounded passing cases do not substitute for it. A pre-freeze recognition hardening explicitly records bucket-pair lengths before rejecting wrong shapes. The final matrix and all mutation/accounting controls were rerun after this change.

## Remaining gates

Independent source-level review of this frozen component is next. It should check domain recognition, symbolic-grid ordering, tie comparator, bounded Euclid invariant, half-open endpoints, within-round versus cross-round distinctness, q=0/L>=1 cases, general width dependencies, and all construction/output/failed-path accounting.

Still open: unbiased finite random-tape scheduling and parameter construction as an integrated caller; composing actual BUCKETS executions with this decoder; inverse-phase preparation and estimation; median coefficient output; dense fallback; full E(beta) recovery; outer transfer and all-length executable conformance. No theorem-parameter-scale numerical run, practical speed result, new worldwide novelty conclusion, complete sparse-recovery theorem, repository update, Sheet edit, public publication or sharing-permission change is claimed here.
