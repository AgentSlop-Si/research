# Independent feedback compiler review

Reviewed on 2026-10-09 by the exact-factorization research agent, independently
of the feedback implementation's author. Scope: `feedback.py`, its executable
audit, the scalar-gate helper, and the README's algebra and cost claims.

**Verdict:** the closed-cycle formula, gain correction, arbitrary-state
restoration, and stated scalar/preparation counts are correct under the
documented finite-field, coordinate-observation, disjoint-bank contract. One
input-validation defect was corrected during review. This is an exact reuse
result after the initial transforms are charged; it is not a faster fresh FFT.

## Algebra and arbitrary states

Writing `s0=e_j^T w_(R-1)` and `beta=e_j^T J^(R-1)u`, the feedback equation is
`s=s0+beta*s`. For `kappa=1-beta !=0`, its unique solution produces
`z_r=w_r+J^r u*s0/kappa`. This works for one injection, several independent
source banks, repeated source banks, and injections away from vertex zero.
The compiler accumulates all their linear functionals before the correction.

The row identity `ell_r=(K^T)^(R-1-r)T^T e_j` follows from `TK=JT`. The needed
row of triangular Toeplitz T is explicitly present in the kernel, so preparation
does not hide an application of T or T^T. This reasoning applies to every
coordinate j, not only the last coordinate used in the original basis audit.

Descending target differences and ascending propagation are inverse maps on
the original target contents. Every inserted source contribution and the
rank-one forcing are propagated, while arbitrary original targets are retained
additively. The unused workspace bank is never addressed. The scalar expansion
temporarily scales source registers but restores them after each shear.

For the rank-one update, the source pivot coefficient is nonzero by construction;
its register value need not be nonzero. Computing the functional into that pivot,
using it on disjoint targets, and reversing the source operations restores all
sources exactly. No inverse of a source value occurs. Zero functionals and zero
output vectors produce no update instructions.

Subtracting the two nonsingular gain formulas gives exactly
`(gamma-eta)c_r*s0/((1-gamma*beta)(1-eta*beta))`. Consequently the update uses
the original sources without another T call, preserves arbitrary unrelated
target content, and converts an already accumulated old-gain solution to the
new-gain solution. Equal gains give the empty update. Singular old or new gains
are correctly rejected.

## Cost review

The rank-one word has two pivot scalings, `2(m-1)` source shears and k target
shears. Scalar expansion therefore has exactly `6m+3k-4` instructions, unless
the update is zero. The initial graph uses one ADD_T per supplied injection;
the dense triangular implementation charges `3N(N+1)/2` instructions each.
Every J edge uses `2N-1` nonzero shears, giving the stated
`2(R-1)(6N-3)` descending/ascending cost.

The feedback row preparation counts are correct:

- multiplications: `(R-1)(3N-1)+2N`;
- additions: `(R-1)(2N-1)+N-1`;
- one subtraction and one constant inversion.

The gain preparation counts are also correct:
`(3R-2)N+4` multiplications, `(R-1)N` additions, four subtractions and one
constant inversion. Both compilers separately report one N-entry source-row
accumulation per injection. The README explicitly charges scalar expansion,
reciprocal preparation and materialized circuit storage in addition to these
graph-coefficient ledgers. They must not be described as free preprocessing.

## Correction and focused verification

`gain_update_word` originally omitted the injection validation already present
in `feedback_word`. A negative source-bank index could emit negative register
IDs; Python execution would interpret them as aliases to registers at the end
of the array, undermining the intended source/target separation. The gain
compiler now rejects empty injections, invalid vertices and negative sources
before producing coefficients or gates. This does not change valid-input
algebra or instruction counts.

After that narrow fix, `python run_audit.py` passes:

- the existing 36 cases, 840 full-register basis vectors for each map, 144 mixed
  states and 18 singular-feedback rejections;
- eight invalid-injection rejections across both compilers;
- two singular gain-endpoint rejections;
- five focused valid edge-case groups covering observation coordinate zero,
  repeated sources, non-root injections, zero feedback, zero/equal gains,
  zero-valued source pivots and zero rank-one updates.

Only the related feedback audit was rerun. These checks certify finite
implementation cases; the displayed algebra supplies the general guarantee.

## Reviewed file hashes

SHA-256 values after the validation fix and successful audit:

| File | SHA-256 |
|---|---|
| `feedback.py` | `485af87abd19b40a78ce0a8a888e97d45847e535fa0614764ec84adc7998663a` |
| `run_audit.py` | `7ad09e44a227f197c2afda359ac2672c06ecc5979546b0eb38b372885fc7451c` |
| `README.md` | `65eaef1e9c9049a58fb028c891c0bd5e40e7e3ec693b71d9e28f17c5a500187c` |
| `results.json` | `3336399fdf9ddf3f1d900a8130660f0cb3b9712484d14f26d70d965f580e255c` |
| `prior_affine_reuse.py` | `e606245885ac79e657e2ee6771b17054ded3af9232a557402eb0b5da1bd80e5d` |
