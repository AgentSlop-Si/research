# Bounded extensions and legitimate fusion

These are independently derived consequences, not claims that the supplied archive already implements them. No publication novelty is asserted.

## A. Uniform growing-rank tensor and fiber fast paths

For one selected CRT split N=AB with gcd(A,B)=1 and A²+B²<=C_T N, raw rank-<=r_T recognition plus accepted full-output DFT takes O((1+r_T)N) arithmetic, O(r_T) scalar inversions and O(N) space, after capping the rank bound at min(A,B).

For one selected Q|N with Q²<=C_F N, write M=N/Q. Raw <=r_F-mode-per-fiber recognition plus accepted full-output DFT takes O((1+min(r_F,M))N) arithmetic, O(Q min(r_F,M)) scalar inversions and O(N) space. Proof: use O(r_F N+Q r_F²) for M>=3r_F, O(QM²)<O(r_F N) otherwise, and O(N+r_F Q²) output. All root preparation, raw reads, rejection, amplitude recovery, exact verification and output writes are included.

Thus r_T,r_F=o(log N) give o(N log N) arithmetic for recognition on every raw input and full DFT on accepted structured inputs. Under the polynomial-size field/word model, the inversion charges are also absorbed. The supported families remain proper structured subsets; increasing r slowly does not cover arbitrary vectors.

This stronger permitted rank schedule is not a direct improvement to unknown common-quadratic-chirp recognition: the families differ, and the chirp phase search has its own r-dependent cost.

## B. One bounded separately budgeted dispatcher

Fix one public balanced CRT split (or skip when absent), one public fiber divisor Q satisfying the fixed ratio guard, and the maximal support-coset branch. Alternatively, fix a constant-size public list of such splits; charge every attempt. Use separate budgets r_T, r_F, r_C. In the coset/common-chirp branch replace the shipped permutation eliminant by the previously proved polynomial Toeplitz construction, retaining the same eliminant, all canonical candidates, recurrence checks and full-input verification. Sequential execution accepts the first validated output and otherwise returns nonmembership in the selected union.

The complete arithmetic ledger is

    O(N(1+r_T+r_F+r_C^4) + r_C^(2+3 log_2 3)).

The common-chirp contribution follows from D=O(r_C³), at most D verified candidates, O(M r_C+r_C³) candidate work at reduced length M<=N, and Toeplitz setup O(r_C^(2+3 log_2 3)). All-zero and small-coset branches remain explicit. A root table gives O(M²) direct work for M<3r_C; even the literal O(M² log M) source loop is absorbed by the displayed conservative bound. Only a constant number of complete raw scans and parameter-dependent polynomial constructions are used.

A conservative scalar-inversion ledger is

    O(r_T + Q r_F + 1 + r_C^4),

plus integer gcd/inverse and public factor-selection work. The field/root generation premise is unchanged. Storage is O(N+r_C^4) with sequential candidates and the prior Toeplitz route. The fiber and tensor certificates can be discarded before the next unsuccessful branch; no candidate-by-input array is free.

For r_T,r_F=o(log N) and r_C=o((log N)^(1/4)), every-input recognition plus any accepted full-output DFT is o(N log N), with the same supplied-field/root and arithmetic contracts. This is a union of specified structured families. The rejected vector has not been transformed. A generic exact fallback, if separately available in the same field/length model, retains its own worst-case bound.

**Implementation boundary:** the shipped fused_fft.transform_if_supported takes a single r and calls the factorial-eliminant coset engine. It does not implement this separately budgeted polynomial-cost dispatcher. Integrating the independently audited Toeplitz subroutine and separate arguments is an explicit next implementation step, not a result silently credited to uploaded code.

## C. Degree-independent near-square polynomial-phase corollary

Let N=QM and put

    L=N/gcd(N,Q²)=M/gcd(M,Q).

For any integer polynomial P and every t, integer binomial expansion gives

    P(t+Qu)=P(t)+Q P'(t)u+Q² R_t(u),

where R_t is an integer polynomial (no division by a factorial in a residue ring is needed). The last exponential factor omega^{Q² R_t(u)} has period dividing L, because omega^{Q²} has exact order L and R_t(u+L)=R_t(u) mod L. Since L divides M, a period-L function on Z_M has Fourier support contained in the L multiples of M/L. Multiplying it by eta^{P'(t)u} shifts that support. Therefore every polynomial-phase fiber has at most L modes, irrespective of polynomial degree.

Consequently, for fixed L and Q²=O(N), a raw polynomial-phase input is recognized and transformed in O_L(N), without learning P. A sum of k independent polynomial phases has at most kL modes per fiber and the corresponding uniform O(kL N) branch bound when applicable.

In particular N=d s² with Q=s gives L=d exactly. For every fixed positive integer d, including composite d, all integer-polynomial phases at these lengths have a <=d-mode fiber representation and an exact O_d(N) raw-input fast path. Q²=N/d<=N. This generalizes the square and fixed-prime odd-exponent examples by the same elementary algebra. It uses the specified Q=s; the archive’s largest-divisor default must not be assumed to choose it. For a fixed D one may check the constant list d=1..D for square N/d, charging the checks, and retain the resulting constant number of public fiber alternatives.

At N=s² the formula reduces to the familiar stationary-phase identity

    X[k]=s sum_{0<=t<s, P'(t)=k mod s} omega^{P(t)-kt}.

This explains the connection to classical finite-ring/p-adic stationary phase. It does not establish novelty, does not handle arbitrary inputs by polynomial metadata, and does not claim a low-degree polynomial representation for arbitrary raw vectors. The independent checker validates 160 cases with d=1..8, s=2..5 and degrees 2,3,4,7,13, using direct per-fiber spectra and all-N direct DFTs.
