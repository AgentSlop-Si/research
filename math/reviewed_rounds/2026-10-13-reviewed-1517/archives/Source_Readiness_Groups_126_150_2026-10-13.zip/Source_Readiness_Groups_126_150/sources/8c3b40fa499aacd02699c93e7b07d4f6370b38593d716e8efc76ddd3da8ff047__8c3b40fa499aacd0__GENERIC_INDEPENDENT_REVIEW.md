# Independent review of nested-state tail fusion

Reviewed on 2026-10-09 by the exact-factorization research agent, independently
of the implementation author. Main scope: `fused_modulated.py`, its audit,
the dependent rectangular-tail backend and the final README. The separate
cost reviewer covers the stronger rank-one orbit and Fourier-description path.

**Verdict:** the generic nested-state evaluator computes its stated aggregate
exactly, retains the noncommuting order, and has the stated preparation, online
and storage costs. No correction to this generic implementation was required.
Its common-state compression applies to one shared arbitrary input; it does
not turn independent inputs or the complete H_q(C) into the same small problem.

## Operator order and the shared state

The identities `C=T B T^-1` and `Q T=T D`, with `D=(I-A)Q`, imply

    Q^j C^(N-r) p_j(C) Q^j
      = T D^j B^(N-r) p_j(B) D^j T^-1.

Both occurrences are D^j, in the positions shown. No inverse modulation is
introduced and no D is commuted through the B-polynomial. The code respects
this order: its right shrinking suffix generates the inputs to the individual
head maps, and its left reverse Horner generates their output modulations.

For the weighted upper shift, `B=G^-1 A_upper G`, where the diagonal entries
are the prepared g_i. Thus `B^(N-r)p_j(B)` reads only the last r entries,
scales by their g_i, applies the r-by-r upper Toeplitz p_j kernel, and writes
the first r entries scaled by g_i^-1. The slices used by the implementation
select exactly those coefficients from the larger window plan.

Let ell=r+s-1. The last r entries of `D^j T^-1 x` require only the last r+j
entries of T^-1 x. At every shrinking-suffix step, the discarded coordinate
is the only one whose predecessor is unavailable. Every retained coordinate
has the required predecessor, so no missing dependence is treated as zero.

Likewise a D action grows head support by at most one. Reverse Horner produces
`sum_j D^j head_j` with support contained in the first ell coordinates. The
aggregate therefore factors through an ell-dimensional input projection and
ell-dimensional output embedding; its rank is at most ell. Rounding the FFT
window to m does not enlarge the actual mathematical dependence or justify
discarding any data. A separate independent x_j per term would not satisfy
this common-input argument.

## Full cost check

I checked the exact ledgers independently. Put

    h=log2(2m), l=log2(2r),
    V=2(N+m)h+2sr*l,
    I=(s-1)(m-1)-(s-1)(s-2)/2,
    O=(s-1)r+(s-1)(s-2)/2.

Projection and decoding use N/m+1 forward and N/m+1 inverse transforms of
length 2m in total. The s middle kernels each use one forward and one inverse
transform of length 2r. This gives V butterfly multiplications, additions
and subtractions. The remaining contributions include all pointwise products,
inverse normalizations, small g scalings and sums of projected spectra.

The right shrinking suffix makes I two-multiply/one-subtract updates. The
left Horner steps act on O state coordinates, including one signed boundary
append per step. Their exact totals lead to

    mul = V+6N+2m+6sr+2(I+O)
    add = V+2N-2m+(s-1)r
    sub = V+I+O-(s-1)
    neg = s-1.

Preparation correctly includes the previous window-m tail plan, including its
unused zero-polynomial spectrum. The extra root table, adjusted inverse FFT
normalization and s smaller spectra add `N+sr*l` multiplications,
`log2(m/r)+sr*l` additions and `sr*l` subtractions. No extra field inversion
or input-dependent division is hidden.

These counts support the README's bounds:

- online: `O(N log(m+1)+s[m+r log(r+1)])`;
- cold preparation: `O(N log(m+1)+sr log(r+1))`;
- storage: `O(N+sr)`, including all s heads and all prepared middle spectra.

The independent comparator computes exactly the same aggregate, shares its
constant banks, and charges every complete output, modulation and final sum.
Its preparation and online formulas also match the code. A win over that
comparator is a valid reuse improvement, not a general FFT speed claim.

## Verification and limitations

The captured generic audit passes 76 configurations, 2,134 full basis vectors
and 76 mixed inputs over two prime fields and exact small cyclotomic fields.
It compares against both actual sparse-C Horner and the separate full-output
tail evaluator, while asserting every preparation and online formula.

I added no broad rerun. A focused review check at N=16,r=4,s=3 used short and
zero polynomials and verified three additional edge properties:

1. Inputs with zero final ell coordinates in T^-1 x produce zero output,
   even when the rounded m-window contains other nonzero coordinates.
2. Applying T^-1 to a general result leaves zero entries after the first ell.
3. All-zero polynomials give the zero map, and mixed short polynomials agree
   with the same-target independent evaluator.

The supplied primitive-root contract, dyadic dimensions and `2m<=N` restriction
are explicit. All N outputs are returned. The first projected inverse
convolution is fully charged; it is not a cached first transform. The README
correctly separates this rank-limited family from the stronger rank-one orbit
sum, whose rank can reach N, and from the unresolved complete H_q(C) problem.

The rank-one path's same-sign Fourier/transpose convention, weighted-permutation
identity and complete-H closure argument are also consistent on inspection;
their dedicated independent review should be used for the detailed audit.

## Reviewed hashes

| File | SHA-256 |
|---|---|
| `fused_modulated.py` | `272eb4fbbe68950926e67a761e8bd1d3c4472c7893723b1354deb0c0d8eda383` |
| `run_audit.py` | `7af063ded73b34d4475fc5658f85b4b4edf1b28e6abf5304849fc153a7693878` |
| `README.md` | `b743e1f2bedbd0ea0a50a928c59fa189e85b594cdeec1ed21a9330e0ded368b5` |
| `results/fusion_audit.json` | `7bdd6aa6b11481a663383ba10ff6f7415bd1731f9db76fb651455b292ea2053e` |
| `../fft_resolvent_aggregate_research/tail_blocks.py` | `882feab0cee6bcd1416d8a18cf0d5417d1016e7e2784224064a19f027f00c133` |
