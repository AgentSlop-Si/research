#!/usr/bin/env python3
"""Read-only verification of this inventory, not of its historical mathematics."""
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text())
manifest=read('MANIFEST.json');bad=[]
for e in manifest['entries']:
 p=P/e['file']
 if not p.is_file() or p.stat().st_size!=e['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:bad.append(e['file'])
actual={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()};expected={x['file'] for x in manifest['entries']}|{'MANIFEST.json'}
assert not bad and actual==expected,(bad,actual^expected)
selected=read('SELECTED_BASE_GROUPS.json');remaining=read('REMAINING_125_ROSTER.json');controls=read('DISTINCT_GROUP_CONTROLS.json');result=read('SOURCE_READINESS_25_GROUPS.json');groups=result['groups']
assert selected==remaining[75:100] and len(selected)==len(groups)==25
assert len({g['obligation_group'] for g in selected})==25
assert not controls['prior100_intersection'] and all(not p['intersection'] for p in controls['peer_batches'].values())
assert all(s['bound_hash_match'] for g in groups for s in g['source_bindings'])
assert all(v['all_values_match'] and v['identity_matches'] for v in read('LIVE_SELECTED_OVERVIEW_BINDINGS.json'))
assert sum(g['source_readiness']=='NEEDS_SCOPE_SELECTION' for g in groups)==23
assert sum(g['source_readiness']=='SOURCE_BLOCKED' for g in groups)==2
assert not any(g['ready_for_selected_next_test'] or g['new_completed_mathematical_review'] for g in groups)
print(json.dumps({'manifest_payloads_verified':len(manifest['entries']),'exact_groups':25,'all_checks_pass':True,'scope':'Inventory and source/task readiness only; no historical research programs executed.'},indent=2))
