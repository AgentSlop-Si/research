"""Independent exact controls for the paid source bridge, 2026-10-13.

No candidate, accepted, or historical program is imported or executed.
The alternate bridge uses integer square root to locate the scale and
Fraction's nearest-even operation. A separate integer bit-window oracle
checks every returned coordinate. Research source snapshots are inert text.
"""
from fractions import Fraction as Q
from math import isqrt, gcd, comb
from itertools import product
from collections import Counter
from pathlib import Path
import json
import random

ROOT = Path(__file__).resolve().parent
counts = Counter()


def check(pred, category):
    assert pred, category
    counts[category] += 1


def alternate_bridge(values, exponent, fractional):
    if type(values) is not tuple or any(type(x) is not tuple or len(x) != 2 for x in values):
        raise ValueError('immutable exact Cartesian source')
    if type(exponent) is not int or type(fractional) is not int:
        raise ValueError('integer metadata')
    if any(type(x) is not int for p in values for x in p):
        raise ValueError('integer components')
    M = len(values)
    if M < 4 or M & (M-1) or fractional < (M.bit_length()-1)+3:
        raise ValueError('bridge domain')
    S = sum(x*x for p in values for x in p)
    if not S:
        return None
    ceil_root = isqrt(S)
    if ceil_root*ceil_root < S:
        ceil_root += 1
    L = (ceil_root-1).bit_length()
    unit = 1 << fractional
    rounded = tuple(tuple(round(Q(x*unit,1 << L)) for x in p) for p in values)
    lower = sum(x*x for p in rounded for x in p)
    double = lower <= unit*unit//4
    d = 2 if double else 1
    output = tuple(tuple(d*x for x in p) for p in rounded)
    return output, exponent+L-int(double), L, d


def integer_round_oracle(n, shift):
    if shift <= 0:
        return n << -shift
    # Signed floor and low-bit parity, unlike Fraction rounding above.
    floor = n >> shift
    remainder = n-(floor << shift)
    halfway = 1 << (shift-1)
    return floor + int(remainder > halfway or remainder == halfway and floor % 2)


def verify_vector(z, exponent, F):
    answer = alternate_bridge(z, exponent, F)
    S = sum(x*x for p in z for x in p)
    if not S:
        check(answer is None, 'zero_status')
        return
    values, alpha_exponent, L, d = answer
    unit = 1 << F
    check(L == ((S-1).bit_length()+1)//2, 'scale_matches_candidate_formula')
    check(S <= 1 << (2*L) and (L == 0 or S > 1 << (2*L-2)), 'minimal_power_four')
    check(alpha_exponent == exponent+L-(d//2), 'scale_sign_and_doubling')
    check(4*sum(x*x for p in values for x in p) > unit*unit, 'strict_norm')
    check(all(abs(x) <= unit and abs(x).bit_length() <= F+1 for p in values for x in p), 'magnitude_and_source_width')
    for original, returned in zip(z, values):
        check(returned == tuple(d*integer_round_oracle(x,L-F) for x in original), 'independent_nearest_even')
        errors = [Q(u,unit)-Q(d*x,1 << L) for x,u in zip(original,returned)]
        check(sum(e*e for e in errors) <= Q(d*d,2*unit*unit), 'complex_error_squared')
        check(sum(e*e for e in errors) <= Q(4,unit*unit), 'advertised_bridge_error_squared')
    counts['valid_vectors'] += 1
    counts['doubling_vectors' if d == 2 else 'ordinary_vectors'] += 1


for flat in product((-1,0,1),repeat=8):
    verify_vector(tuple(zip(flat[::2],flat[1::2])),0,5)

rng = random.Random(1412)
for m in range(2,11):
    M = 1 << m
    for trial in range(20):
        width = (1,2,3,7,31,127,257,1025)[trial % 8]
        z = tuple((rng.randrange(-(1 << width),1 << width),rng.randrange(-(1 << width),1 << width)) for _ in range(M))
        verify_vector(z,(-1 if trial % 2 else 1)*(1 << 200),m+3+trial % 5)

# Both signs, real/imaginary axes and minimum/theorem precision.
for m in (2,3,6,9):
    for F in (m+3,16*m+17):
        for K in (F+2,F+31,F+1000):
            for sign in (-1,1):
                for axis in (0,1):
                    p = [0,0]; p[axis] = sign*((1 << K)+1)
                    z = (tuple(p),)+((0,0),)*((1 << m)-1)
                    verify_vector(z,1 << 200,F)
                    out,ae,L,d = alternate_bridge(z,1 << 200,F)
                    check(d == 2, 'boundary_doubling_needed')
                    before = tuple(tuple(x//2 for x in p) for p in out)
                    check(4*sum(x*x for p in before for x in p) == 1 << (2*F), 'omit_double_mutation_detected')
                    # If d is ignored in alpha, the returned impulse is wrong by ~1/2.
                    wrong_errors = [Q(u,1 << F)-Q(x,1 << L) for p,q in zip(z,out) for x,u in zip(p,q)]
                    check(max(abs(e) for e in wrong_errors) > Q(2,1 << F), 'wrong_scale_mutation_detected')

for shift in range(1,15):
    for n in range(-2050,2051):
        check(integer_round_oracle(n,shift) == round(Q(n,1 << shift)), 'signed_rounding_ties')

for invalid in [((),0,5),(((0,0),)*3,0,5),(((0,0),)*4,0,4),(((0,0),)*4,True,5),(((0,0),)*4,0,True),(((True,0),)+((0,0),)*3,0,5),([(0,0)]*4,0,5)]:
    try:
        alternate_bridge(*invalid)
    except ValueError:
        counts['independent_wrapper_invalid_controls'] += 1
    else:
        raise AssertionError('invalid independent wrapper case')

# Certificate threshold without expanding a huge absolute exponent.
# Delta=C*2^(e-p), alpha=2^(e-p+L-log2(d)); e-p cancels exactly.
def budget_guard(C,L,d,P):
    return (C*d).bit_length()-1 <= L-P and (C*d <= (1 << (L-P)) if L-P >= 0 else False)

for m in range(2,17):
    N = 1 << m
    for BA in sorted({3,4,min(N,7),N//2,N}):
        H = min(comb(N+BA-1,BA),1 << (N-BA))
        C = 64*H*BA*(1 << BA)*N*N
        P = 16*m+16
        for d in (1,2):
            threshold = (C*d-1).bit_length()+P
            for L in (threshold-1,threshold,threshold+1):
                check(budget_guard(C,L,d,P) == (Q(C*d,1 << L) <= Q(1,1 << P)), 'exact_delta_alpha_guard')
            check(not budget_guard(C,threshold-1,d,P) and budget_guard(C,threshold,d,P), 'guard_boundary_mutation')
for P in (8,48,112):
    check(budget_guard(1,P,1,P), 'guard_equality_accepted')
    check(not budget_guard(1,P,2,P), 'forgot_double_in_guard_detected')

# Independent exact universal-expression checks at worst W and every b.
for m in list(range(2,61)) + [64,96,128,256]:
    M = 1 << m
    P = 16*m+16
    rho = Q(1,1 << P)
    for b in range(1,m+1):
        E = (2*M*M+2*(M-1)*rho)*(1+rho)**(b+1)-2*M*M+rho
        check(E <= (16*b+7)*M*M*rho, 'accepted_intermediate_constant')
        check(E+2*M*M*rho <= (16*b+9)*M*M*rho, 'guarded_composition_budget')
        check((16*b+9) <= 24*(m+1), 'published_budget_slack')

# Reconstruct the accepted component/theorem parameter domain independently.
def window_domain(M,B,r,P,beta=None):
    if any(type(x) is not int for x in (M,B,r,P)):
        return False
    if M < 16 or M & (M-1) or B < 4 or B & (B-1) or r < 1 or P < 8:
        return False
    if M % B or M//B < 4 or 2*r*(8*B-1)+1 >= M:
        return False
    if beta is not None:
        if type(beta) is not Q or not 0 < beta < Q(1,2):
            return False
        m = M.bit_length()-1
        ceil = lambda x: -((-x.numerator)//x.denominator)
        k = 1 << ceil(2*beta*m)
        return B == 1 << ceil((Q(1,2)+beta)*m) and r == 2*m+1 and P == 16*m+16 and B >= 4096*k
    return True

check(window_domain(64,4,1,8), 'valid_reduced_window')
for values in [(16,4,1,8),(32,4,1,8),(64,4,1,7),(64,2,1,8),(64,4,0,8),(64,8,1,8),(64,4,2,8),(63,4,1,8),(64,True,1,8)]:
    check(not window_domain(*values), 'invalid_window_parameters')
theorem_first = []
for m in range(1,61):
    beta = Q(1,4)
    B = 1 << ((3*m+3)//4)
    valid = window_domain(1 << m,B,2*m+1,16*m+16,beta)
    if valid:
        theorem_first.append(m)
check(min(theorem_first) == 46, 'theorem_crossover_parameter_only')
check(not window_domain(64,4,1,112,Q(1,4)), 'reduced_fixture_not_theorem')

# Cyclotomic ring Q[zeta]/(zeta^32+1); integer numerators suffice throughout.
def mono(e,c=1):
    v = [0]*32
    e %= 64
    v[e % 32] = c if e < 32 else -c
    return v

def padd(a,b):
    return [x+y for x,y in zip(a,b)]

def phase(a,e):
    o = [0]*32
    for i,c in enumerate(a):
        k = (i+e) % 64
        o[k % 32] += c if k < 32 else -c
    return o

def conjugate(a):
    o = [0]*32
    for i,c in enumerate(a):
        o = padd(o,mono(-i,c))
    return o

def pmul(a,b):
    o = [0]*32
    for i,c in enumerate(b):
        if c:
            o = padd(o,[c*x for x in phase(a,i)])
    return o

def dft_unscaled(v):
    return [sum_poly(phase(v[t],-j*t) for t in range(64)) for j in range(64)]

def sum_poly(values):
    o = [0]*32
    for v in values:
        o = padd(o,v)
    return o

N=64; BA=3; a=1; beta=0
lengths=[N//BA+int(b < N%BA) for b in range(BA)]
starts=[sum(lengths[:b]) for b in range(BA)]
check(lengths == [22,21,21] and starts == [0,22,43] and gcd(a,N) == 1, 'actual_alg034_partition_and_state')
def alg_phase(b,t):
    return a*t*(t-1)//2+(a*starts[b]+beta)*t

def projected_integer_input(x):
    result = []
    summaries = []
    for b,length in enumerate(lengths):
        summary = sum_poly(mono(alg_phase(b,t),x[starts[b]+t]) for t in range(length))
        summaries.append(summary)
        result.extend(phase(summary,-alg_phase(b,t)) for t in range(length))
    return result,summaries

kernel,summaries = projected_integer_input([1,-1]+[0]*62)
check(all(p == [0]*32 for p in summaries+kernel), 'actual_exact_kernel_polynomial')
check(all(p == [0]*32 for p in dft_unscaled(kernel)), 'actual_exact_kernel_fourier')
near_results=[]
for K in (1,2,3,7,16,64,127,512,1024):
    numerators=[1 << K,1-(1 << K)]+[0]*62
    px,ds = projected_integer_input(numerators)
    check(ds == [mono(0),[0]*32,[0]*32], 'actual_near_kernel_summaries')
    check(px == [mono(-alg_phase(0,t)) for t in range(22)]+[[0]*32]*42, 'actual_near_kernel_projection')
    ynums = dft_unscaled(px)
    norm = sum_poly(pmul(v,conjugate(v)) for v in ynums)
    check(norm == mono(0,64*22), 'actual_near_kernel_fourier_energy')
    twice = dft_unscaled(ynums)
    check(twice == [[64*x for x in px[-j % 64]] for j in range(64)], 'actual_projected_target_reflection')
    ratio=Q(22,(1 << (2*K))+((1 << K)-1)**2)
    check(ratio <= Q(22,1 << (2*K)), 'near_kernel_ratio_decay')
    near_results.append({'K':K,'squared_ratio':str(ratio)})

# Fourth-root synthetic tap operator, all allowed odd affine pairs.
# This is independent algebra, not a compact-window numerical execution.
roots=[(1,0),(0,-1),(-1,0),(0,1)]
taps=[(t,Q((-1)**(t % 2)*(33-abs(t)),32)) for t in range(-31,32)]
l1=sum(abs(w) for t,w in taps)
eps=Q(1,1 << 9)
for sigma in range(1,64,2):
    for tau in range(64):
        addresses=[(sigma*t+tau)%64 for t,w in taps]
        check(len(set(addresses)) == len(taps), 'distinct_affine_addresses')
        v=[Q(0)]*64
        for (t,w),index in zip(taps,addresses):
            v[index]=eps if w > 0 else -eps
        outputs=[]
        for j in range(4):
            re=im=Q(0)
            for t,w in taps:
                rr,ri=roots[(j*t)%4]
                amplitude=w*v[(sigma*t+tau)%64]/8
                re += rr*amplitude; im += ri*amplitude
            check(re*re+im*im <= (l1*eps/8)**2, 'complex_bucket_l1_bound')
            outputs.append((re,im))
        check(outputs[0] == (l1*eps/8,0), 'exact_l1_attainment')
        check(outputs[0][0]*8 > l1*eps/8, 'missing_bucket_scale_mutation')

summary={'status':'PASS','assertions':sum(counts.values())-counts['valid_vectors']-counts['doubling_vectors']-counts['ordinary_vectors'],
         'counts':dict(sorted(counts.items())), 'near_kernel':near_results,
         'source_imports':'Python standard library only',
         'candidate_or_accepted_program_executed':False,
         'numeric_full_theorem_instance_executed':False,
         'notes':['Controls corroborate the universal proof.','Independent wrapper validation does not certify the candidate parser.','All bucket transfer computations use synthetic signed rational taps.']}
(ROOT/'results/INDEPENDENT_RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k != 'near_kernel'},indent=2))
