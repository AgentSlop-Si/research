Read REVIEW.txt for the independent verdict and scope.
Run python3 independent_checks.py for the reviewer-authored exact controls.
The controls write results/INDEPENDENT_RESULTS.json; preserve this sealed archive before rerunning.
All files under sources are inert text and were not executed. No historical or candidate research module is imported.
No Sheet, GitHub, public publication or permission changes were made.
