#!/usr/bin/env python3
"""Independent reconstruction of Q2 claims from mathematical definitions.
Written 2026-10-13 for this audit. No archived program read, imported, or executed.
All modular scalar arithmetic uses Python integer arithmetic. Dense oracles are
verification only, never the claimed executor. Run from any working directory.
"""
import json, hashlib, time
from pathlib import Path
OUT=Path(__file__).resolve().parent

def eye(n):return [[int(i==j) for j in range(n)] for i in range(n)]
def invmat(a,p):
    n=len(a); b=[[(v%p) for v in row]+e for row,e in zip(a,eye(n))]
    for k in range(n):
        j=next((i for i in range(k,n) if b[i][k]),None)
        if j is None:raise ValueError('singular')
        b[k],b[j]=b[j],b[k]; d=pow(b[k][k],-1,p)
        b[k]=[(v*d)%p for v in b[k]]; r=b[k]
        for i in range(n):
            if i!=k and b[i][k]:
                t=b[i][k]; b[i]=[(x-t*y)%p for x,y in zip(b[i],r)]
    assert [r[:n] for r in b]==eye(n)
    return [r[n:] for r in b]
def rank(a,p):
    b=[r[:] for r in a]; n=len(b); k=0
    for col in range(len(b[0])):
        j=next((i for i in range(k,n) if b[i][col]),None)
        if j is None:continue
        b[k],b[j]=b[j],b[k]; d=pow(b[k][col],-1,p)
        b[k]=[(x*d)%p for x in b[k]]
        for i in range(k+1,n):
            t=b[i][col]
            if t:b[i]=[(x-t*y)%p for x,y in zip(b[i],b[k])]
        k+=1
        if k==n:break
    return k

def isprime(p):
    return p>1 and all(p%d for d in range(2,int(p**.5)+1))
def primitive(w,n,p):
    return pow(w,n,p)==1 and all(pow(w,k,p)!=1 for k in range(1,n))

def torus_denominator(m,q,alpha,beta,p):
    n=m*m; L=eye(n)
    for a in range(m):
        for c in range(m):
            r=a*m+c
            L[r][((a-1)%m)*m+c]=(L[r][((a-1)%m)*m+c]-alpha)%p
            L[r][a*m+(c-1)%m]=(L[r][a*m+(c-1)%m]-beta*pow(q,a,p))%p
    return L

def setup(m,q,alpha,beta,p):
    if not primitive(q,m,p):raise ValueError('nonprimitive q')
    drow=(1-pow(beta,m,p))%p
    if not drow:raise ValueError('row_guard: beta^m = 1')
    d=(drow-pow(alpha,m,p))%p
    if not d:raise ValueError('full_guard: alpha^m + beta^m = 1')
    return [beta*pow(q,a,p)%p for a in range(m)],pow(drow,-1,p),drow*pow(d,-1,p)%p

def rowsolve(f,t,dinv,p):
    h=0
    for v in f:h=(v+t*h)%p
    h=h*dinv%p
    y=[]
    for v in f:
        h=(v+t*h)%p;y.append(h)
    return y

def solve(f,m,alpha,p,prepared):
    ts,dinv,boundary=prepared
    def sweep(prev):
        result=[]
        for a,t in enumerate(ts):
            rhs=[(f[a*m+c]+alpha*prev[c])%p for c in range(m)]
            prev=rowsolve(rhs,t,dinv,p);result.extend(prev)
        return result,prev
    _,tail=sweep([0]*m)
    result,_=sweep([boundary*v%p for v in tail])
    return result

def phi_indices(m):
    return [((-c)%m)*m+(a+c)%m for a in range(m) for c in range(m)]

def s_apply(f,m,alpha,lam,p,prepared):
    ids=phi_indices(m); pf=[0]*len(f)
    for j,k in enumerate(ids):pf[k]=f[j]
    g=solve(f,m,alpha,p,prepared); pg=solve(pf,m,alpha,p,prepared)
    return [(g[j]+lam*pg[ids[j]])%p for j in range(len(f))]

def sparse_residual(L,G,p):
    n=len(L); nonzero=[[(k,x) for k,x in enumerate(row) if x] for row in L]
    return sum((sum(v*G[k][j] for k,v in row)-int(i==j))%p!=0
               for i,row in enumerate(nonzero) for j in range(n))

def formula_G(m,q,alpha,beta,p):
    # Independent Gaussian q-binomial kernel; phase follows A^u B^v e_(a',c').
    n=m*m; den=pow((1-pow(alpha,m,p)-pow(beta,m,p))%p,-1,p)
    kernel={}
    for u in range(m):
        for v in range(m-u):
            r=u+v; b=1
            for j in range(1,u+1):
                b=b*(1-pow(q,r-u+j,p))*pow((1-pow(q,j,p))%p,-1,p)%p
            kernel[u,v]=b*pow(alpha,u,p)*pow(beta,v,p)*den%p
    return [[kernel.get(((a-ap)%m,(c-cp)%m),0)*pow(q,ap*((c-cp)%m),p)%p
             for ap in range(m) for cp in range(m)] for a in range(m) for c in range(m)]

def audit_torus(m,p,alpha,beta,lam,Lexp=None):
    n=m*m; q=pow(3,(p-1)//m,p); omega=pow(3,(p-1)//n,p)
    assert primitive(q,m,p) and primitive(omega,n,p) and pow(omega,m,p)==q
    prepared=setup(m,q,alpha,beta,p); cols=[]; scols=[]
    for e in eye(n):
        cols.append(solve(e,m,alpha,p,prepared))
        scols.append(s_apply(e,m,alpha,lam,p,prepared))
    G=list(map(list,zip(*cols))); S=list(map(list,zip(*scols)))
    L=torus_denominator(m,q,alpha,beta,p)
    oracle=invmat(L,p); closed=formula_G(m,q,alpha,beta,p)
    assert G==oracle==closed
    assert sparse_residual(L,G,p)==0
    ids=phi_indices(m); assert sorted(ids)==list(range(n))
    assert S==[[(G[i][j]+lam*G[ids[i]][ids[j]])%p for j in range(n)] for i in range(n)]
    expected_support=[[((i//m-j//m)%m+(i%m-j%m)%m)<m for j in range(n)]for i in range(n)]
    assert all(bool(G[i][j])==expected_support[i][j] for i in range(n) for j in range(n))
    Sinv=invmat(S,p)
    zeros=sum(v==0 for row in S for v in row); izeros=sum(v==0 for row in Sinv for v in row)
    assert zeros==izeros==0
    # SX-ZS under positive DFT convention X e_j=e_(j+1), Z_ii=omega^i.
    defect=[[(S[i][(j+1)%n]-pow(omega,i,p)*S[i][j])%p for j in range(n)]for i in range(n)]
    rnk=rank(defect,p)
    cross=S[0][0]*S[1][1]*pow(S[0][1]*S[1][0]%p,-1,p)%p
    result={'m':m,'N':n,'p':p,'q':q,'omega_N':omega,'alpha':alpha,'beta':beta,'lambda':lam,
            'lambda_denominator_power_of_2':Lexp,'all_G_basis_residuals_zero':True,
            'G_equals_independent_gaussian_inverse':True,'G_equals_q_binomial_phase_formula':True,
            'S_executor_equals_permutation_conjugate_formula':True,
            'G_nonzeros_per_row':m*(m+1)//2,'S_zeros':zeros,'S_inverse_zeros':izeros,
            'weyl_defect_rank':rnk,'cross_ratio_indices':[0,1,0,1],'cross_ratio':cross,'cross_ratio_power_N':pow(cross,n,p),
            'matrix_sha256':hashlib.sha256(json.dumps(S,separators=(',',':')).encode()).hexdigest()}
    print('torus',p,m,'done',flush=True)
    return result

def guard_controls(m):
    p=65537;q=pow(3,(p-1)//m,p)
    # Full inverse exists although every attempted row inverse is singular.
    L=torus_denominator(m,q,7,1,p); inverse=invmat(L,p)
    assert sparse_residual(L,inverse,p)==0
    try: setup(m,q,7,1,p);raise AssertionError('accepted invalid row domain')
    except ValueError as e:assert str(e).startswith('row_guard')
    # beta=0, alpha=1 yields I-A, singular while row denominator is a unit.
    L=torus_denominator(m,q,1,0,p); r=rank(L,p)
    assert r==m*(m-1)
    try:setup(m,q,1,0,p);raise AssertionError('accepted singular full denominator')
    except ValueError as e:assert str(e).startswith('full_guard')
    return {'m':m,'p':p,'row_refusal':{'alpha':7,'beta':1,'full_denominator':(-pow(7,m,p))%p,'full_inverse_verified':True},
            'full_refusal':{'alpha':1,'beta':0,'row_denominator':1,'rank':r,'dimension':m*m}}

def qapply(v,roots,p):
    n=len(v); out=[0]*n
    for r in range(n//2):
        out[2*r]=(v[r]+v[r+n//2])%p
        out[2*r+1]=roots[r]*(v[r]-v[r+n//2])%p
    return out

def bm(s,p):
    C=[1];B=[1];L=0;shift=1;b=1
    for k in range(len(s)):
        d=sum(C[i]*s[k-i] for i in range(len(C)))%p
        if d==0:shift+=1;continue
        old=C[:]; factor=d*pow(b,-1,p)%p
        if len(C)<len(B)+shift:C.extend([0]*(len(B)+shift-len(C)))
        for i,t in enumerate(B):C[i+shift]=(C[i+shift]-factor*t)%p
        if 2*L<=k:L=k+1-L;B=old;b=d;shift=1
        else:shift+=1
    return L,C[:L+1]

def trim(a):
    while len(a)>1 and a[-1]==0:a.pop()
    return a

def polyrem(a,b,p):
    a=trim(a[:]);b=trim(b[:]); inv=pow(b[-1],-1,p)
    while len(a)>=len(b) and any(a):
        t=a[-1]*inv%p; d=len(a)-len(b)
        for j,v in enumerate(b):a[j+d]=(a[j+d]-t*v)%p
        trim(a)
    return a

def gcdpoly(a,b,p):
    while any(b):a,b=b,polyrem(a,b,p)
    return [x*pow(a[-1],-1,p)%p for x in a]

def station(n):
    p=65537;w=pow(3,(p-1)//n,p);assert primitive(w,n,p)
    roots=[pow(w,j,p) for j in range(n)];v=[1]+[0]*(n-1);seq=[];krylov=[]
    for t in range(3*n):
        seq.append(v[0])
        if t<=n:krylov.append(v[:])
        v=qapply(v,roots,p)
    degree,rec=bm(seq[:2*n],p);assert degree==n
    residuals=[sum(rec[j]*seq[t-j] for j in range(n+1))%p for t in range(n,3*n)]
    assert not any(residuals)
    poly=rec[::-1]
    # Direct vector annihilation. BM degree N proves e0 cyclic, hence p(Q)=0.
    vector_residual=[sum(poly[j]*krylov[j][i] for j in range(n+1))%p for i in range(n)]
    assert not any(vector_residual)
    derivative=[j*poly[j]%p for j in range(1,len(poly))]
    gcd=gcdpoly(poly,derivative,p);assert gcd==[1]
    checked=0;neg_missing_phase=0
    if n<=64:
        bits=n.bit_length()-1
        ph=[0]*n
        for r in range(1,n):ph[r]=ph[r//2]+(r//2 if r%2 else 0)
        rev=[int(f'{r:0{bits}b}'[::-1],2) for r in range(n)]
        for j,e in enumerate(eye(n)):
            v=e
            for _ in range(bits):v=qapply(v,roots,p)
            for k in range(n):
                observed=roots[(-ph[rev[k]])%n]*v[rev[k]]%p
                assert observed==roots[(k*j)%n]
                neg_missing_phase+=(v[rev[k]]!=roots[(k*j)%n])
                checked+=1
    recfile='stationary_N'+str(n)+'_polynomial.json'
    (OUT/'certificates'/recfile).write_text(json.dumps({'p':p,'N':n,'primitive_root':w,'ascending_annihilator_coefficients':poly,'sequence_first_3N':seq},indent=2)+'\n')
    print('stationary',n,'done',flush=True)
    return {'N':n,'p':p,'omega':w,'bm_prefix_length':2*n,'bm_degree':degree,'checked_extra_sequence_values':n,
            'vector_annihilation_of_e0':True,'squarefree_gcd':[1],'all_fourier_basis_outputs_checked':checked,
            'uncorrected_phase_wrong_outputs':neg_missing_phase,'certificate_file':'certificates/'+recfile}

def main():
    t=time.time();(OUT/'certificates').mkdir(exist_ok=True)
    assert isprime(65537) and isprime(998244353)
    # Root field prerequisite and orientation-cover controls beyond dyadic samples.
    covers=[]
    for m in range(2,129):
        missing=[(u,v) for u in range(m) for v in range(m) if not(u+v<m or (-v)%m+(u+v)%m<m)]
        assert not missing;covers.append(m)
    historical=[];schedule=[];guards=[]
    for m in [2,4,8,16]:
        historical.append(audit_torus(m,65537,7,11,2))
        p=998244353;exp=4+m*((2*m-1).bit_length())
        schedule.append(audit_torus(m,p,pow(4,-1,p),pow(4,-1,p),pow(pow(2,exp,p),-1,p),exp))
        guards.append(guard_controls(m))
    stationary=[station(2**k) for k in range(1,11)]
    result={'status':'PASS','arithmetic':'exact modular integer arithmetic','historical_program_execution':False,
            'torus_65537':historical,'fixed_schedule_998244353':schedule,'guard_controls':guards,
            'support_cover_extra_integer_controls':covers,'stationary_Q':stationary,'elapsed_seconds':time.time()-t}
    (OUT/'FRESH_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','elapsed_seconds':result['elapsed_seconds']}),flush=True)
if __name__=='__main__':main()
