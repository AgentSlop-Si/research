# Quantum-Torus Green Fusion (QTGF)
## A candidate exact O(N) Fourier theory with a proved O(N) high-treewidth q-Green solver

Date: 2026-10-11

STATUS
------
This package contains:

1. a new exact linear-time solver theorem for a 2D root-of-unity
   q-commuting Green denominator;
2. a concrete Fourier factorization conjecture built from a constant number
   of transverse copies of that solver;
3. a fully charged conditional O(N) DFT theorem.

The q-torus solver is proved and independently executable.
The Fourier fusion identity is NOT proved.

Therefore this package DOES NOT claim that an O(N) FFT has already been found.

===============================================================================
1. MOTIVATION FROM THE LATEST PROJECT RESULTS
===============================================================================

The newest project results change the constructive landscape.

Phase 44:
- certifies an exact FULL F_8 using four multi-Green stages;
- shows that complete Fourier matrices really can occur in nontrivial
  Green architectures.

Phase 45:
- gives an explicit all-length power-of-two Green representation of every
  ordinary radix-2 butterfly;
- but still needs log_2 N stages, so it is exactly O(N log N).

Phase 46:
- constructs dense, invertible and even orthogonal transforms with exact
  O(N) Green/prefix executors;
- but these transforms are not Fourier;
- bounded/stable versions still need logarithmic depth in the stated model.

Older project gates say that a successful new stage should be:
- globally mixing;
- outside one cyclic/rational order;
- outside low-rank near-circulant rewiring;
- high enough in separator complexity;
- exactly solvable in O(N) by special algebra rather than generic sparse
  elimination.

QTGF constructs exactly such a stage.

===============================================================================
2. THE QUANTUM-TORUS STATE SPACE
===============================================================================

Let m >= 2 and

    N = m^2.

Work over a field K containing a primitive m-th root q.

Index vectors by

    (a,c) in Z_m x Z_m.

Let X_1 shift the first coordinate:

    (X_1 y)[a,c] = y[a-1,c].

Let X_2 shift the second coordinate:

    (X_2 y)[a,c] = y[a,c-1].

Let Z_1 be first-coordinate modulation:

    (Z_1 y)[a,c] = q^a y[a,c].

Define

    A = X_1,
    B = Z_1 X_2.

Then

    B A = q A B,

and

    A^m = B^m = I.

Thus A,B form an exact finite quantum-torus / q-Weyl pair.

===============================================================================
3. QUANTUM-TORUS GREEN DENOMINATOR
===============================================================================

Allow nonzero row coupling parameters

    alpha_0,...,alpha_(m-1)

and one scalar beta.

Define L by

    (L y)[a,c]
      =
      y[a,c]
      - alpha_a y[a-1,c]
      - beta q^a y[a,c-1],

with both coordinates cyclic modulo m.

For constant alpha_a=alpha this is

    L = I - alpha A - beta B.

The graph has:
- N=m^2 states;
- two directed nontrivial incoming edges per state;
- O(N) sparse coefficients;
- an undirected support containing an m x m toroidal grid.

So its separator/treewidth scale grows as Theta(m)=Theta(sqrt(N)).
It is not a one-dimensional Green recurrence.

===============================================================================
4. THEOREM: EXACT O(N) SOLVE
===============================================================================

Define the cyclic shift S on one row by

    (S v)[c]=v[c-1].

For each row a put

    G_a = (I - beta q^a S)^(-1).

Assume

    beta^m != 1

and

    prod_a alpha_a != 1-beta^m.

Then L is invertible and L y=f can be solved in O(N) exact field operations.

### Proof

The a-th row equation is

    (I-beta q^a S)y_a
      =
    f_a + alpha_a y_(a-1),

so

    y_a = G_a f_a + alpha_a G_a y_(a-1).

Each G_a is a first-order cyclic Green solve of length m and costs O(m).

The key root-of-unity identity is

    product_(a=0)^(m-1) (I-beta q^a S)
      =
    I - (beta S)^m
      =
    (1-beta^m) I,

because q runs through all m-th roots and S^m=I.

Therefore

    G_(m-1)...G_1 G_0
      =
    (1-beta^m)^(-1) I.

Unrolling once around the first coordinate gives

    y_(m-1)
      =
    p
      +
    [prod_a alpha_a /(1-beta^m)] y_(m-1),

where p is obtained by one forward row sweep with zero initial boundary.

Hence

    y_(m-1)
      =
    (1-beta^m)
    /
    (1-beta^m-prod_a alpha_a)
    * p.

After this scalar boundary correction, a second row sweep reconstructs all
rows.

There are m row Green solves in each sweep.
Each costs O(m).
Total arithmetic is therefore

    O(m^2)=O(N).

No Fourier transform, dense inversion, Krylov iteration or separator
factorization is invoked.

QED.

===============================================================================
5. CONSTANT-ALPHA q-BINOMIAL FORM
===============================================================================

For alpha_a=alpha, put

    C = alpha A + beta B.

Because

    BA=qAB

and q is primitive of order m, the root-of-unity q-binomial theorem gives

    C^m
      =
    alpha^m A^m + beta^m B^m
      =
    (alpha^m+beta^m) I.

Therefore, whenever

    alpha^m+beta^m != 1,

we also have the exact inverse identity

    (I-C)^(-1)
      =
    [1/(1-alpha^m-beta^m)]
    sum_(r=0)^(m-1) C^r.

This formula proves invertibility algebraically.

Evaluating the displayed polynomial literally would cost too much.
The previous section's row recurrence is the actual O(N) executor.

This distinction is important:
the speedup comes from the q-cyclotomic boundary collapse, not from treating
a length-m polynomial as one operation.

===============================================================================
6. DENSITY AND WHY ONE FACTOR IS NOT FOURIER
===============================================================================

For generic constant alpha,beta, C^r connects displacements whose canonical
nonnegative coordinate increments have total degree r.

Since only r=0,...,m-1 occur, one inverse factor has a simplex-shaped
support in the m x m displacement torus.

Generically each row has

    m(m+1)/2

nonzero entries, approximately one half of all N entries.

Thus one QTGF inverse is already globally mixing, but it still contains
zeros and cannot itself be a Fourier matrix.

This is useful:
- the stage is much denser than a triangular/local Green solve;
- it is still exactly O(N);
- a transverse/opposite stage can fill the complementary support.

===============================================================================
7. TRANSVERSE QUANTUM-TORUS FACTORS
===============================================================================

Define a second q-Weyl pair using the opposite coordinate orientation.

One convenient prototype is obtained from coordinate swap/reversal and
q -> q^(-1).

Let

    L_+ = I - alpha A - beta B,

and let

    L_-

be the same construction after an invertible permutation/gauge that maps the
simplex support to a transverse/complementary orientation.

Both L_+^(-1) and L_-^(-1) retain exact O(N) solvers.

Their product is generically dense.

The candidate Fourier architecture is

    M_N
      =
    D_0
    L_-^(-1)
    D_1
    L_+^(-1)
    D_2,

or, if two factors are insufficient,

    M_N
      =
    D_0
    L_4^(-1)
    D_1
    L_3^(-1)
    D_2
    L_2^(-1)
    D_3
    L_1^(-1)
    D_4.

The second form is motivated by Phase 44, where four Green stages are enough
for an exact full F_8.

Every D_i is diagonal/permutation data generated from the primitive N-th
Fourier root.

===============================================================================
8. QUANTUM-TORUS FOURIER FUSION CONJECTURE
===============================================================================

For every m=2^r there exists a constant d, independent of m, and explicit
parameters for d transverse quantum-torus Green denominators such that

    F_(m^2)
      =
    P_out
    D_0
    L_d^(-1)
    D_1
    ...
    D_(d-1)
    L_1^(-1)
    D_d
    P_in.

Requirements:

1. d=O(1).
2. Every L_j has the q-torus form of Section 3, up to coordinate
   permutations/reversals and diagonal gauges.
3. Each L_j^(-1) is evaluated by the proved O(N) q-cyclotomic solver.
4. All D_j entries and all alpha/beta parameters are generated in O(N)
   total work from a supplied primitive N-th root.
5. No hidden FFT or dense parameter table is used.
6. Exact Weyl identities hold:

       M_N e_0 = ones,
       M_N S = Delta M_N.

This is the only major unproved step.

===============================================================================
9. WHY q-VANDERMONDE / ROGERS-SZEGO MAY SUPPLY THE FUSION IDENTITY
===============================================================================

Entrywise expansion of one q-torus Green inverse produces q-binomial /
q-multinomial coefficients because

    (alpha A+beta B)^r

expands by the q-binomial theorem.

The project already has substantial q-binomial and Rogers-Szego algebra,
including root-of-unity factorization phenomena.

Products of opposite q-torus inverse kernels therefore lead to terminating
q-hypergeometric sums.

The hoped-for exact Fourier identity is:

    q-binomial kernel
      * cyclotomic diagonal chirp
      * opposite q-binomial kernel

        = pure Fourier phase.

A successful proof should reduce the matrix identity to a finite
q-Vandermonde / cyclic-dilogarithm identity rather than a numerical
N^2-equation fit.

Known q-binomial and cyclic quantum-dilogarithm identities themselves are
classical and must be credited.
Their use as this exact Fourier factorization is the proposed new step.

===============================================================================
10. CONDITIONAL O(N) THEOREM
===============================================================================

Assume the Quantum-Torus Fourier Fusion Conjecture with constant d.

For N=m^2:

- coefficient/root preparation: O(N);
- each q-torus inverse: O(N);
- d inverse stages: O(dN)=O(N);
- diagonals/permutations: O(N);
- explicit output writes: O(N).

Therefore

    T(N)=O(N).

This meets the unavoidable input/output floor.

===============================================================================
11. ALL POWERS OF TWO
===============================================================================

If

    N=2^(2r),

use m=2^r directly.

If

    N=2^(2r+1)=2m^2,

handle the extra factor 2 with one exact radix-2 butterfly layer before or
after the m^2 transform.

That adds only O(N) work.

Thus the conjecture for square dyadic sizes implies

    O(N)

for every power-of-two length.

===============================================================================
12. ARBITRARY LENGTHS
===============================================================================

For arbitrary transform length n, use an exactly charged Bluestein/Rader-type
reduction to a power-of-two convolution size

    L < 4n

when the coefficient/root model supplies the required roots.

A constant number of O(L) dyadic transforms plus O(n) chirp work then gives

    O(n).

The exact root-interface and extension-field costs must be stated
explicitly before claiming the all-length theorem.

===============================================================================
13. WHY THIS SURVIVES THE PROJECT'S EXISTING GATES
===============================================================================

ONE-ORDER RATIONAL SCAN:
    QTGF has two noncommuting q-Weyl directions.

LOW TREEWIDTH:
    the q-torus denominator has grid-scale treewidth Theta(sqrt(N)), not
    bounded treewidth.

NEAR-CIRCULANT REWIRING:
    the denominator is a sum of two independent permutation directions and
    differs by Omega(N) structural rank from any one short cyclic reference
    in the intended orientations.

PHASE-DEFECT RANK:
    q^a modulation creates complex phase frustration on Theta(N) edges.

ONE GREEN-SUM ARC SIGNATURE:
    QTGF is an inverse of a multi-edge denominator, not a sum of a constant
    number of Hamiltonian Green inverses.

METAPLECTIC WORD RIGIDITY:
    QTGF resolvents are not finite Weil/metaplectic words.

BOUNDED-COEFFICIENT FFT LOWER BOUNDS:
    a true sub-NlogN construction in the exact arithmetic model cannot rely
    on the uniformly bounded Phase45 realization.
    QTGF therefore does NOT assume coefficients or conditioning stay
    uniformly bounded with N. Any growth must be explicitly reported and
    charged in the chosen arithmetic/bit model.

===============================================================================
14. RELATION TO PHASE 25
===============================================================================

Phase25 already found a q-commuting sum W=A+C satisfying

    W^N=(1+r^N)I

and a sparse Fourier conjugacy.

But that result warns that solving the conjugate time-side bidiagonal
system does not remove the Fourier basis conversion.

QTGF is different:

- the q-commuting pair lives directly on N=m^2 physical states;
- its inverse is applied directly to the user's vector in the physical
  coordinate basis;
- no F D^(-1) F^(-1) conversion is used in the solver;
- the speed theorem is an explicit two-dimensional recurrence.

So the new O(N) solver is not a hidden FFT.

===============================================================================
15. FIRST DECISIVE EXPERIMENTS
===============================================================================

A. VERIFY THE SOLVER
   For m=2,3,4,8 in exact finite fields:
   - construct L densely;
   - solve random right-hand sides using the two-pass q-torus solver;
   - check L y=f exactly.

B. SUPPORT GEOMETRY
   Build L^(-1) from basis solves for small m and confirm the predicted
   simplex support.

C. TWO-FACTOR FOURIER TEST
   At N=4,9,16:
   search exact/projective solutions for

       F_N = D0 L_-^(-1) D1 L_+^(-1) D2.

   Do not infer an all-length theorem from a fit.

D. FOUR-FACTOR TEST
   If two factors fail, use the Phase44-inspired four-factor model.

E. SYMBOLIC IDENTITY
   For any positive fit, derive a q-Vandermonde identity that proves it for
   symbolic m, not just finite sizes.

===============================================================================
16. FAST FALSIFIERS
===============================================================================

Reject QTGF if one can prove any of:

1. Every constant product of transverse q-torus Green inverses has a
   projective polynomial invariant violated by Fourier.

2. A constant product always preserves an m-dimensional invariant
   decomposition incompatible with cyclic F_(m^2).

3. Exact Fourier equality forces d=Omega(log m).

4. Coefficient preparation or required extension-field degree costs
   Omega(N log N) even though online q-torus solves are O(N).

5. A relevant existing lower-bound theorem applies after checking all of its
   hypotheses, including coefficient magnitude/conditioning assumptions.

===============================================================================
17. PROVED CORE VERSUS CONJECTURAL CORE
===============================================================================

PROVED HERE:
- exact q-Weyl relation BA=qAB;
- root-of-unity product identity;
- exact invertibility condition for the q-torus denominator;
- exact two-pass O(N) solver;
- no FFT call in that solver.

INHERITED PROJECT FACTS:
- full exact F_8 exists in a multi-Green architecture (Phase44);
- explicit all-length Green butterfly factorization exists but costs
  O(N log N) (Phase45);
- dense O(N) Green/Cayley transforms exist but are not Fourier (Phase46).

UNPROVED:
- a constant-factor quantum-torus Green product equals F_(m^2) for all m.

That unproved fusion identity is the only place where the claimed O(N)
Fourier result can fail.

===============================================================================
18. PRIOR-ART BOUNDARY
===============================================================================

Classical/known ingredients include:
- q-commuting variables and q-binomial theorem;
- root-of-unity quantum torus representations;
- cyclic quantum dilogarithm and pentagon identities;
- Harper/Hofstadter-type rational-flux operators;
- Green/resolvent recurrences;
- Cooley-Tukey and q-Vandermonde identities.

Recent cyclic quantum-dilogarithm literature explicitly studies finite
root-of-unity q-commuting operators and pentagon identities.

The proposed project-specific synthesis is:

    exact O(N) physical-basis solve for the 2D cyclic q-Green denominator
    +
    constant transverse quantum-torus Green fusion into the cyclic DFT.

A targeted search did not locate this complete FFT construction.
That is NOT a worldwide novelty proof.

===============================================================================
19. CURRENT EXTERNAL COMPARATOR
===============================================================================

OpenAI Math result 130 reports an exact all-length DFT bound

    O(N (log N)^(1-10^-13))

in an exact-complex supplied-root arithmetic model.

QTGF would be asymptotically stronger if the fusion conjecture is proved.

The external result is a theorem/formalized result.
QTGF is currently a conjectural Fourier factorization built on a proved
new solver mechanism.

===============================================================================
20. BOTTOM LINE
===============================================================================

The new exact research question is:

Can Fourier be factored into a CONSTANT number of transverse
root-of-unity q-torus Green inverses whose individual arbitrary-RHS solves
already cost only O(N)?

We no longer need to invent the fast stage.
The fast high-treewidth noncommuting stage now exists.

Only Fourier compatibility remains.

If the answer is YES:

    exact arbitrary-input DFT = O(N).

If the answer is NO:

the obstruction should produce a new lower bound for constant products of
integrable quantum-torus Green solvers, a model not closed by the project's
existing one-dimensional Green, separator, Weyl-line, or metaplectic gates.
