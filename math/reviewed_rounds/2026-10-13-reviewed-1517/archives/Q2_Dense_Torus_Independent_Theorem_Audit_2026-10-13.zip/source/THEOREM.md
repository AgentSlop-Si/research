# Recovered FFT Research — Phase Q2 (2026-10-13)
## Two-orientation quantum-torus fusion, exact all-size density, and stationary-Q obstruction

**Objective:** exact, full-output DFT on every fresh dense input in sequential `O(N)` or `o(N log log N)` charged work.  **Status:** Objective **not solved**. This checkpoint establishes a genuine, fully specified, exact `O(N)` *non-Fourier* global transform, and recovers a finite exact obstruction to a particular stationary-graph compression.

## 1. Precise recovered lineage

* The **stationary marked-cycle** identity is `F_(2^n)=R C Q^n`, with `Q` an explicitly weighted binary de Bruijn register operator; literal application is `Theta(N log N)`.
* **QTGF** gives a noncommuting 2D quantum-torus `O(N)` exact linear solver with growing sparse-graph treewidth, outside the single-Hamiltonian Green grammar.
* The last interrupted checkpoint reported a **three-orientation** full-support q-torus scan family; the present checkpoint improves it to **two orientations** and supplies an explicit all-size coefficient schedule and condition bound.
* Earlier **Green full-spark**, **Hall/arc transfer**, **Weyl completion**, **CWFS**, **tensor saving**, and **sparse residual** results do not provide a uniform exact `O(N)` Fourier phase lift. In particular the WDRR almost-all-correct-rows hypothesis is circular and generic input-adaptive sparse filtering fails the necessary support gate.

## 2. Quantum torus

Fix an integer `m>=2`, let `N=m^2`, and let `q` be a primitive complex `m`-th root. Work on the grid `Z_m^2`, with

\[
 (A y)_{a,c}=y_{a-1,c},\qquad
 (B y)_{a,c}=q^a y_{a,c-1}.
\]

Then `BA=q AB`, `A^m=B^m=I`, and both `A,B` are unitary. Define

\[
 G_{\alpha,\beta}=(I-\alpha A-\beta B)^{-1}.
\]

By the root-of-unity q-binomial identity,

\[
 (\alpha A+\beta B)^m=(\alpha^m+\beta^m)I,
\]

so for `alpha^m+beta^m !=1`,

\[
 G_{\alpha,\beta}=
 \frac{\sum_{r=0}^{m-1}(\alpha A+\beta B)^r}
 {1-\alpha^m-\beta^m}.
\]

**Exact solver, previously proved in QTGF.** For each row `a`, let `S` be a length-`m` cyclic shift and `G_a=(I-beta q^a S)^(-1)`. The row equation is

\[
 y_a=G_a(f_a+\alpha y_{a-1}).
\]

Since

\[
 \prod_{a=0}^{m-1}(I-\beta q^a S)=(1-\beta^m)I,
\]

the cyclic boundary correction is a **scalar**. Two passes through the `m` row scans compute any `y=G f` using `O(m^2)=O(N)` exact scalar operations and `O(N)` storage. The included verifier checks *every* input basis vector at `N=4,16,64,256` against direct multiplication by `I-alpha A-beta B`.

## 3. Support triangle — exact all-m theorem

Let `u=(a-a') mod m` and `v=(c-c') mod m`, represented in `{0,...,m-1}`. Then:

\[
 \boxed{G_{\alpha,\beta}[(a,c),(a',c')]\ne0
 \iff u+v<m}
\]

provided `alpha,beta !=0` and `alpha^m+beta^m !=1` over the complex numbers.

**Proof.** The `q`-binomial expansion of `(alpha A+beta B)^r`, `r<m`, has the term

\[
 {r\brack u}_q\alpha^u\beta^v A^u B^v,
 \qquad u+v=r.
\]

All Gaussian binomial factors are nonzero because their product formula contains only terms `1-q^j` with `1<=j<m`, none of which vanish. Each `(u,v)` with `u+v<m` occurs exactly once in the displayed polynomial, and no other displacement occurs. The phase from `A^uB^v` has modulus one. QED.

A *single* such resolver has only

\[
 \boxed{|T|=m(m+1)/2<m^2=N}
\]

nonzero displacement classes, so it cannot have a fully dense transfer matrix for any `m>=2`.

## 4. NEW: two orientations cover all matrix entries

Define the linear bijection

\[
 \boxed{\phi(a,c)=(-c,\ a+c)\pmod m.}
\]

Its determinant is 1, so it is a valid coordinate permutation `P_phi`. Put

\[
 H=P_\phi^{-1}GP_\phi.
\]

Then the support condition for `H` is

\[
 (-v\bmod m)+(u+v\bmod m)<m.
\]

**Theorem 4.1 — exact two-orientation coverage.** Every pair of grid coordinates belongs to the support of **at least one of** `G` or `H`.

**Proof.** If `u+v<m`, the pair is in the support of `G`. Otherwise `u+v>=m` forces `v>0`, and

\[
 (-v\bmod m)+(u+v\bmod m)
 =(m-v)+(u+v-m)=u<m.
\]

Thus the pair is in the support of `H`. QED.

Consequently `S(lambda)=G+lambda H` has **all entries nonzero for every scalar `lambda` outside a finite exceptional set**, because each entry is a nonzero affine polynomial in `lambda`. It is generically invertible since its determinant at `lambda=0` equals `det G !=0`.

**Optimality within this particular support grammar:** one triangle resolver never has full support; **two suffice**. This does not say two arbitrary Green terms can compute Fourier.

## 5. NEW: explicit well-conditioned all-m schedule with O(N) preparation

There is no need to search for a generic `lambda`. Choose

\[
 \boxed{\alpha=\beta=\tfrac14,\qquad
 \lambda_m=2^{-L_m},\qquad
 L_m=4+m\left\lceil\log_2(2m)\right\rceil.}
\]

Define `G_m=(I-A/4-B/4)^(-1)` and `S_m=G_m+lambda_m P_phi^{-1}G_mP_phi`.

**Theorem 5.1 — fully explicit all-length dense fast transform.** For every `m>=2`, over the complex numbers:

1. `S_m` is entrywise nonzero (globally dense).
2. `S_m` is invertible.
3. `kappa_2(S_m)<4`, uniformly in `m`.
4. The parameters and routing are generated in `O(m^2)=O(N)` arithmetic/word work given a primitive `N=m^2` root, and each fresh vector can be transformed in `O(N)` arithmetic and `O(N)` storage.

**Proof of density.** For primitive `q`, each nonzero `q`-binomial coefficient with `r<m` satisfies

\[
 \left|{r\brack u}_q\right|
 =\prod_{j=1}^u
 \frac{|1-q^{r-u+j}|}{|1-q^j|}
 \ge(2/m)^u,
\]

because `|1-q^k|>=2 sin(pi/m)>=4/m` for `1<=k<m`, and denominators are at most 2. As `alpha=beta=1/4`, each nonzero entry of `G_m` therefore satisfies

\[
 |(G_m)_{ij}|\ge 4^{-(m-1)}(2/m)^m
 =\boxed{4/(2m)^m}.
\]

The denominator `1-2*4^(-m)` lies between zero and one, so its reciprocal does not reduce this bound. Since `A,B` are unitary,

\[
 \|G_m\|_2\le\frac1{1-1/2}=2,
\]

and `H` is a permutation conjugate, so `|H_ij|<=2`.

By the definition of `L_m`,

\[
 0<\lambda_m\le 1/[16(2m)^m].
\]

On the support of `G`,

\[
 |(S_m)_{ij}|\ge 4/(2m)^m-2\lambda_m>0.
\]

Outside that support, `H_ij!=0` by Theorem 4.1, and `S_ij=lambda_m H_ij!=0`.

**Proof of invertibility/conditioning.** `G_m^-1=I-A/4-B/4` has `||G_m^-1||_2<=3/2`. Hence

\[
 \|\lambda_mG_m^{-1}H\|_2\le3\lambda_m<1.
\]

Now `S_m=G_m(I+lambda_mG_m^-1H)` is invertible, and

\[
 \kappa_2(S_m)
 \le\frac{(2+2\lambda_m)(3/2)}{1-3\lambda_m}<4.
\]

Finally `q=omega_N^m`; table of `q^a`, `P_phi`, and `lambda_m` requires at most `O(N)` charged scalar/word operations (`lambda_m` can be formed by repeated halvings). The two-pass cyclic Green solve applies each copy of `G_m` in `O(N)`, so `S_m` applies in `O(N)`.

**Important scope:** This is a new *fast dense transform*, **not** a Fourier transform. Its very small off-triangle entries may require growing precision for *entrywise relative-error* guarantees; bounded spectral condition number is not a bit-complexity theorem.

## 6. Independent exact finite-field certificate — the matrices are NOT Fourier

The included standard-library verifier uses exact finite-field arithmetic, independent dense Gaussian elimination, and the proper primitive Fourier roots.

For `m=2,4,8,16`, with `N=m^2`, over `GF(65537)` it sets `alpha=7`, `beta=11`, `lambda=2`. Results:

| N | zeros in S | zeros in S^-1 | rank(SX-ZS) | (chosen Fourier cross-ratio)^N=1? |
|--:|--:|--:|--:|:--:|
| 4 | 0 | 0 | 4 | No |
| 16 | 0 | 0 | 16 | No |
| 64 | 0 | 0 | 64 | No |
| 256 | 0 | 0 | 256 | No |

In particular, **these specific parameter choices are not even monomially equivalent to an `N`-DFT**: every Fourier `2x2` cross ratio is an `N`th root of unity and remains so under arbitrary invertible input/output diagonals and permutations, whereas the stored ratio's `N`th power is different from 1.

Separate good-prime exact checks at `GF(998244353)` verify the *explicit small-coefficient* schedule of Theorem 5.1 at the same four sizes; all entries and all inverse entries are nonzero. The all-m result follows from the proof, **not** finite-field extrapolation. Bad-prime reductions may fail to preserve invertibility (e.g. `1/4` at a dyadic size dividing its multiplicative order), so the good-prime check is a sanity test, not the analytic proof.

These finite-field nonzero observations also establish corresponding characteristic-zero nonvanishing for the specified cyclotomic rational parameter families because the reductions are well-defined and all displayed denominators remain units.

## 7. Recovered stationary Fourier Q — exact finite obstruction

For `N=2^n`, let `omega` be a primitive `N`th root, and define

\[
 (Qx)_{2r}=x_r+x_{r+N/2},\quad
 (Qx)_{2r+1}=\omega^r(x_r-x_{r+N/2}).
\]

The archived exact identity is

\[
 \boxed{F_N=R\,C\,Q^n}
\]

with a bit reversal `R` and the explicit digital-phase diagonal `C`. Its literal evaluation costs `Theta(N log N)`.

**Recovered exact test.** In `GF(65537)` for every dyadic `2<=N<=1024`, let

\[
 s_t=e_0^TQ^te_0,\qquad 0<=t<2N.
\]

Berlekamp–Massey finds exact scalar recurrence order **N**. The resulting degree-N annihilator is also **squarefree** modulo 65537 in each case, verified by polynomial Euclidean gcd with its derivative. All basis columns of `R C Q^n=F_N` were independently verified for `N<=64`.

This is an exact finite-size certificate for the **absence of a lower-degree polynomial annihilator**, not a lower bound against all noncommuting sparse graph fusion. It cannot be promoted to an all-N statement without a new all-length proof.

## 8. What to do next (not another conditional 'algorithm')

The closest unfinished research target is *Fourier phase compatibility* of **noncommuting, jointly executed, linear-work operators**. The two-orientation theorem closes the full-support and conditioning requirements, so do not waste more effort optimizing mere density/full spark.

At `N=16,64` the next hard gate should be the exact `2x2` Fourier cross-ratio identities and the Phase-49 Weyl relation with vertex-dependent gauges, followed by an explicit all-input coefficient-generation rule. Discard a candidate immediately if its Weyl defect has full rank or one cross ratio is not an `N`th root. Distinguish a finite fitted point from a uniform all-N formula.

Only the following is accepted as the requested breakthrough: an exact, fully expanded, uniform scalar circuit for **every** fresh input, whose *proved* online **and setup** work is `O(N)` or `o(N log log N)`. No such circuit has been found in the recovered archive or this checkpoint.

## 9. Research credit and novelty boundary

The q-binomial theorem, Weyl pairs, cyclic Green solves, and 2-adic de Bruijn FFT identity have classical components. The **two-orientation torus coverage / explicit well-conditioned dense-solver combination** is new **within the present recovered project chain**, improving the previously reported three orientations. External publication priority has **not** been established. Density is an important construction result but is not Fourier-phase synthesis.
