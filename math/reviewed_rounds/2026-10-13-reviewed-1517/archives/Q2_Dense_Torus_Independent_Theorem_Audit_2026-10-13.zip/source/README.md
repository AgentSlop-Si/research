# FFT chain recovery — 2026-10-13

**Goal preserved:** exact full-output DFT on *arbitrary fresh input* in `O(N)` or `o(N log log N)` charged sequential work. **Goal unsolved.** This is not a faster implementation of radix-2.

## Main research progress

- Recovered QTGF's exact two-pass, `O(N)` noncommuting torus Green solver.
- **Improved three global orientations to two**: `phi(a,c)=(-c,a+c) mod m` gives an all-`m` triangular-support cover.
- Proved an **explicit, uniform, bounded-condition** `O(N)` completely dense *non-Fourier* transform on every `N=m^2`, with coefficients prepared in `O(N)` work in the exact-scalar model.
- Exact samples at `N=4,16,64,256` have dense inverses, but full Weyl defect and forbidden Fourier cross ratios.
- Reproduced the stationary `Q_N` minimal-polynomial test over `GF(65537)` through `N=1024`, all of full degree `N`, plus squarefreeness. Does not exclude other algorithms.

## Reproduce

Requires Python 3 standard library only:

```sh
python3 verify_recovery.py
```

Output: `RESULTS.json` including all exact modular certificates. The source reconstructs every test matrix from its `O(N)` executor and checks all basis vectors for the underlying solve. It does not silently use an FFT or dense matrix multiplication as the executor.

`THEOREM.md` contains full mathematical proofs, the explicit parameter schedule and precise barriers. `PRIOR_QTGF.md` and `PRIOR_MARKED_CYCLE.md` preserve matching original theory files from the research archive.

**Warning:** High-density matrices and dense inverses are not Fourier matrices. These results do not prove a new sub-`N log log N` general DFT algorithm, nor an unrestricted FFT lower bound.
