# Arc-Entropy Saturated Green Radix (AESGR)
## Candidate exact O(N log N / log log N) Fourier theory

Date: 2026-10-11

Status:
- New project synthesis based on the latest Phase 43 arc-rank theorem,
  Green-product interpolation results, rewiring-rank barriers, and earlier
  exact Green executors.
- Exact arbitrary-input/full-output target.
- Proposed complexity:
      O(N log N / log log N).
- The Green macro-DFT existence conjecture is NOT proved.
- This document does not claim that a new faster FFT has already been established.

===============================================================================
1. WHY THIS TARGET IS DIFFERENT
===============================================================================

Previous project theories often aimed directly at O(N) or O(N log log N)
without having a concrete asymptotic construction scale.

Phase 43 supplies a new quantitative clue.

For a one-layer sum of q arbitrary weighted Hamiltonian Green resolvents,
an exact N-point Fourier representation requires

    N <= q (q+1)^q.

Therefore an unbounded one-layer exact family necessarily has

    q = Omega(log N / log log N).

This is a restricted representation lower bound, not a general FFT lower bound.

But direct application of q Hamiltonian Green inverses costs only

    O(q N)

arithmetic once their weights are prepared.

Thus the Phase 43 obstruction itself identifies a natural attainable-looking
sub-FFT target:

    q ~ log N / log log N

would give

    O(N log N / log log N),

provided a matching Green representation can actually be constructed.

AESGR is the theory of trying to SATURATE this arc-capacity bound.

===============================================================================
2. HAMILTONIAN GREEN PRIMITIVE
===============================================================================

Let W be a weighted Hamiltonian-cycle shift on B coordinates:

    W e_(v_i) = w_(i+1) e_(v_(i+1)),

with nonzero edge weights and holonomy

    h = product_i w_i != 1.

Then

    G_W = (I-W)^(-1)

has the exact finite formula

    G_W = (I+W+...+W^(B-1))/(1-h).

It can be applied to a fresh vector in O(B) exact scalar arithmetic by one
cyclic first-order recurrence.

Let

    S_q = sum_(s=1)^q alpha_s G_(W_s)

be a q-cycle Green sum.

Applying S_q costs

    O(q B).

A product of any fixed number ell of such sums, separated by diagonal or
permutation maps, also costs

    O(ell q B) = O(q B).

===============================================================================
3. ARC ENTROPY
===============================================================================

Choose m output rows.

For one Green cycle, as an input column moves around the cycle, its
projective direction on those m selected rows changes only when it crosses
one of the marked rows.

Hence one cycle produces at most m projective arc signatures.

For q independently ordered cycles, the joint signature alphabet has at most

    m^q

classes.

Phase 43 chooses

    m=q+1

and proves that every joint class has rank at most q for a one-layer q-cycle
sum.

A Fourier Vandermonde block on q+1 consecutive frequency rows has every
q+1 distinct columns independent.

Therefore each signature class contains at most q Fourier columns, giving

    B <= q(q+1)^q.

The logarithm of the maximum permitted macro size is thus

    log B = O(q log q).

This is the ARC-ENTROPY scale.

AESGR conjectures that this upper capacity is achievable to constant factors
once a fixed number of noncommuting Green layers and interstage diagonals
are allowed.

===============================================================================
4. ARC CODE
===============================================================================

Let

    m=q+1.

For a macro size

    B <= m^q,

assign every coordinate j a distinct code

    c(j)=(c_1(j),...,c_q(j)) in {0,...,q}^q.

For cycle s:

1. order the B coordinates primarily by digit c_s(j);
2. place the q+1 distinguished arc separators between digit groups;
3. choose an independent permutation inside each digit group;
4. use freely varying nonzero edge gains.

Then the joint arc signature of coordinate j is exactly its code c(j).

Thus q Hamiltonian cycles can distinguish

    (q+1)^q

coordinate classes using only q linear-time recurrences.

This is the combinatorial skeleton of the macro transform.

The orders are globally non-affine and differ by Theta(B) rewiring rank from
short-stride circulant references, deliberately escaping the project's new
near-circulant rewiring-rank theorem.

===============================================================================
5. WHY ONE LAYER IS NOT REQUIRED
===============================================================================

Phase 43's theorem is a one-SUM obstruction.

AESGR uses a fixed product depth ell >= 2:

    M_q
      =
      D_out
      S_q^(ell)
      D_(ell-1)
      S_q^(ell-1)
      ...
      D_1
      S_q^(1)
      D_in.

Each S_q^(r) is a sum of q independently ordered Hamiltonian Green inverses.

Each D_r is an explicitly prepared nonzero diagonal.

The online work remains

    O(ell q B)=O(qB)

for fixed ell.

This is strongly motivated by the newest positive experiments:

- Phase 42 proves full local three-row control for a product of two
  three-cycle sums.
- Phase 42 gives an exact certified three-row F_8 interpolation.
- Phase 43 adds the missing relative interstage diagonal.
- Phase 43 proves full four-row local Jacobian rank at N=8,16,32 in the
  two-layer complex-diagonal architecture.
- Phase 43 gives exact certified four-row Fourier interpolation at N=8
  and N=16.
- Those certificates fail at row five, so they are not full DFTs.

AESGR does not interpret those results as a speedup.

It interprets them as evidence that PRODUCTS escape the one-layer arc-rank
rigidity and that interstage complex amplitudes supply genuine additional
Fourier phase freedom.

===============================================================================
6. GREEN MACRO-DFT CONJECTURE
===============================================================================

There exist constants

    ell >= 2,
    c1>0,
    c2>0,
    C>0

and a uniformly constructible family indexed by q such that:

1. B_q is a power of two.

2. Macro size satisfies

       exp(c1 q log q)
       <= B_q
       <= exp(c2 q log q).

3. The exact unnormalized B_q-point DFT admits

       F_(B_q)
         =
         D_out
         S_q^(ell)
         D_(ell-1)
         ...
         D_1
         S_q^(1)
         D_in,

   where each S_q^(r) is a sum of q weighted Hamiltonian Green inverses.

4. All cycle orders, edge weights and diagonal constants can be generated
   from the supplied B_q-th Fourier root using

       O(q B_q)

   exact scalar/word work.

5. Every Green denominator is certified nonzero.

6. No internal operation invokes an FFT, dense matrix product, or uncharged
   nonlinear solver.

Call such an object an ARC-ENTROPY SATURATED GREEN MACRO.

The existence of these macros is the single central conjecture.

===============================================================================
7. WHY B_q = exp(Theta(q log q)) IS THE RIGHT SCALE
===============================================================================

The Phase 43 one-layer theorem proves that q Green cycles cannot directly
carry Fourier size larger than approximately

    exp(q log q).

Therefore asking for

    B_q = exp(Theta(q log q))

is not an arbitrary number.

It attempts to match the newly proved arc-signature information capacity.

If only

    B_q = exp(O(q))

were achievable, recursive cost would remain Theta(N log N).

The q log q exponent is exactly what produces a log log N saving.

===============================================================================
8. RECURSIVE MACRO FFT
===============================================================================

Assume the macro conjecture.

Let N=2^t.

At a recursive transform length n, choose q so that

    B_q <= sqrt(n)

is maximal.

Because

    log B_q = Theta(q log q),

we have

    q = Theta(log n / log log n).

Use Cooley-Tukey with

    n = B_q * M.

The transform decomposes into:

- M transforms of size B_q;
- O(n) twiddle/routing work;
- B_q transforms of size M.

Every B_q transform uses the Green macro in

    O(q B_q).

Across the M copies, macro work is

    O(q n).

Let T(n) be total charged arithmetic and define

    A(n)=T(n)/n.

Then

    T(n)
      <=
      C q n
      + B_q T(M)
      + C n,

so

    A(n)
      <=
      A(M)+Cq+C.

Since B_q is chosen near sqrt(n),

    M <= n^(1-theta)

for some fixed theta>0 after adjusting constants, and in the ideal balanced
choice M=Theta(sqrt(n)).

Therefore recursive logarithms shrink geometrically.

At successive levels,

    q_0
      = Theta(log N/log log N),

    q_1
      = Theta(log sqrt(N)/log log sqrt(N)),

    q_2
      = Theta(log N^(1/4)/log log N^(1/4)),

and so on.

Their sum is

    O(log N / log log N).

Hence

    A(N)=O(log N/log log N),

and

    T(N)=O(N log N/log log N).

===============================================================================
9. CONDITIONAL MAIN THEOREM
===============================================================================

If Arc-Entropy Saturated Green Macros exist with

    B_q = exp(Theta(q log q))
    and
    cost O(q B_q),

then every power-of-two exact DFT can be computed in

    O(N log N / log log N)

fully charged sequential exact arithmetic.

The algorithm supports every fresh dense input and emits all N explicit
outputs.

This is genuinely

    o(N log N).

===============================================================================
10. ALL LENGTHS
===============================================================================

For arbitrary N, use an exact chirp/convolution reduction to a power-of-two
length

    L < 4N

(or another explicitly charged all-length reduction).

A constant number of L-point transforms plus O(N) chirp work gives

    O(L log L/log log L)
      =
    O(N log N/log log N).

Root/chirp generation must remain charged.

No all-length statement is claimed until the exact root interface is
specified.

===============================================================================
11. A MORE CONCRETE MACRO SEARCH ANSATZ
===============================================================================

For q fixed:

1. Set
       B = 2^floor(c q log_2(q+1))
   for a conservative constant c.

2. Assign B coordinates distinct q-digit arc codes.

3. For each Green layer r and cycle s:
   - order vertices by digit s using an independent within-digit permutation;
   - assign edge prefix variables beta_(r,s,v);
   - use the exact Green entry formula

         G[v_a,v_b]
           =
         (beta_a/beta_b)
         h^[a<b]/(1-h).

4. Include a full complex interstage diagonal, as required by Phase 43.

5. Gauge-normalize spanning-tree edge phases.

6. Solve the Fourier equations in PROJECTIVE/Weyl form, not raw N^2
   coefficient form:

       M e_0 = 1,
       M S = D M.

7. Seek a recursive formula in q for:
   - cycle orders,
   - holonomies,
   - beta-prefix values,
   - interstage diagonal entries.

The goal is not one finite numerical fit.

The goal is an explicit q -> q+1 construction.

===============================================================================
12. TRIANGULAR ARC INTERPOLATION LEMMA TO PROVE
===============================================================================

A useful intermediate theorem would be:

For one block of q selected output rows, suppose the q Green direction
vectors associated with a joint arc signature sigma form an invertible
q-by-q matrix D_sigma.

Then every target q-vector for a source column of signature sigma can be
matched uniquely by the q source scalars multiplying those Green directions.

In a weighted Hamiltonian cycle those source scalars are reciprocals of
prefix products beta_b and can be assigned through local edge ratios.

This lemma is elementary for one selected block.

The nontrivial global task is to choose the arc codes and shared beta
prefixes so the resulting block interpolations are simultaneously
consistent for every Fourier row block.

That is the exact algebraic heart of AESGR.

===============================================================================
13. CARRY-COMPATIBILITY TARGET
===============================================================================

Let m=q+1 and encode a macro index in base m:

    j = sum_(a=0)^(q-1) j_a m^a.

Then

    i*j
      =
      sum_(d=0)^(2q-2)
        m^d
        sum_(a+b=d) i_a j_b.

Modulo m^q, only d<q matters.

Thus the Fourier exponent is organized into q digit-convolution diagonals.

This supplies a concrete target for q Green arc families:

    cycle s should aggregate the d=s digit-convolution contribution,
    while interstage diagonals carry the required cumulative phases.

This is not yet a proved Green identity.

It is a much more structured search grammar than arbitrary complex fitting.

===============================================================================
14. WHY THIS DOES NOT COLLAPSE TO THE KNOWN TENSOR FFT AUTOMATICALLY
===============================================================================

The project already proved that replacing cyclic Z/(p^r) Fourier by the
character table of a product group loses primitive cyclic phase depth.

AESGR does NOT identify the cyclic DFT with a tensor product.

The base-m digits are only an INDEXING DEVICE for cycle orders.

The edge weights and interstage diagonals live in the full primitive
B_q-th cyclotomic field and must reproduce the cyclic phase

    zeta_(B_q)^(ij)

exactly.

Any construction whose phases reduce to only m-th roots fails the cyclic
phase-order test and must be rejected.

===============================================================================
15. EXISTING BARRIERS AESGR MUST PASS
===============================================================================

Every macro candidate must pass:

1. Phase 43 arc-rank constraints.
2. New Laurent-bandwidth / rewiring-rank filter:
   cycles must have Omega(B) global rewiring from short circulant references.
3. Phase-defect rank:
   complex phase frustration cannot be o(B).
4. Green two-sided separator/rank gates.
5. Cyclotomic valuation and tropical cancellation checks.
6. Exact Weyl covariance:
       M S = D M.
7. First-column seed:
       M e_0 = 1.
8. Fully charged coefficient generation.

Thus AESGR deliberately lives in the surviving high-complexity Green region.

===============================================================================
16. FIRST EXPERIMENTS
===============================================================================

Do not start at huge q.

q=2:
- test macro sizes B=4,8;
- all exact branches, arbitrary complex diagonal;
- determine whether any fixed product depth ell gives full F_B.

q=3:
- Phase 43 already gives exact FOUR-ROW solutions at B=8,16.
- Continue those exact architectures to full F_8 and F_16.
- If impossible, add one noncommuting Green layer and certify all outputs.

q=4,5:
- search B around powers of two below (q+1)^q;
- record maximum exact macro size;
- compare log B / (q log q).

The decisive empirical quantity is

    c_q = log B_max(q) / (q log q).

AESGR needs

    liminf c_q > 0.

If c_q -> 0, the theory dies.

===============================================================================
17. COEFFICIENT PREPARATION
===============================================================================

A finite existence proof is not enough.

For every q, macro coefficients must come from an O(qB_q)-work generator.

Acceptable forms include:

- short recurrences in vertex index;
- digit-code formulas;
- root-power streams;
- bounded-degree rational functions of prepared root powers;
- exact algebraic recurrences whose extension degree and arithmetic are charged.

Unacceptable:

- solving B_q^2 equations by Gaussian elimination;
- storing an arbitrary B_q^2 table;
- numerical optimization treated as setup;
- an oracle containing the Fourier matrix.

===============================================================================
18. WHY THIS IS MORE MODEST THAN SRCR/CMLGC
===============================================================================

SRCR and CMLGC aimed for O(N log log N) through much stronger new identities.

AESGR asks only for a factor log log N improvement:

    O(N log N/log log N).

The required local macro complexity O(qB) and the macro size
exp(Theta(q log q)) are now directly suggested by a proved Phase 43
capacity theorem.

So AESGR has a clearer asymptotic target/falsifier pair:

    lower capacity: log B = O(q log q);
    desired construction: log B = Omega(q log q).

Match them, and the speedup follows.

===============================================================================
19. STRONGER POSSIBILITIES
===============================================================================

If a macro family achieved

    log B_q = Theta(q^(1+epsilon))

with cost O(qB_q),

then recursive work would be

    O(N (log N)^(1/(1+epsilon)))

up to secondary logarithms.

If B_q were doubly exponential in a much smaller state parameter while
keeping O(qB) work, still stronger bounds could follow.

But no such claim is supported now.

AESGR intentionally targets only the q log q scale that Phase 43 itself
exposes.

===============================================================================
20. CURRENT EXTERNAL COMPARATOR
===============================================================================

A separate current OpenAI result reports an exact all-length DFT algorithm
with

    O(N (log N)^(1-10^-13))

work in an exact-complex supplied-root model.

AESGR would give a much larger asymptotic saving if proved:

    O(N log N/log log N).

But the external result is a theorem/formalized result.
AESGR is currently a conjectural research program.

===============================================================================
21. NOVELTY BOUNDARY
===============================================================================

Known ingredients include:

- Hamiltonian Green resolvents;
- Cooley-Tukey macro-radix recursion;
- projective/Vandermonde rank;
- perfect-hash and digit coding ideas;
- cycle gauges and complex diagonal interlayers.

The project-specific new synthesis is:

    Phase43 arc-capacity q(q+1)^q
    -> target Green macro size exp(Theta(q log q))
    -> direct O(qB) macro executor
    -> recursive macro-radix exact DFT
    -> O(N log N/log log N).

A targeted web search did not locate this exact Green-radix construction.
That is NOT a historical priority proof.

===============================================================================
22. MAIN RESEARCH QUESTION
===============================================================================

Can a fixed-depth product of q Hamiltonian Green sums and interstage
diagonals realize a cyclic Fourier macro of size

    B_q = q^(Theta(q))

with coefficients uniformly generated in O(qB_q) work?

If YES:

    exact DFT = O(N log N/log log N).

If NO:

prove that every exact Green macro has

    log B_q = o(q log q)

or otherwise quantify the gap.

Either direction would turn the new Phase 43 arc-rank theorem into a genuine
asymptotic Fourier result.
