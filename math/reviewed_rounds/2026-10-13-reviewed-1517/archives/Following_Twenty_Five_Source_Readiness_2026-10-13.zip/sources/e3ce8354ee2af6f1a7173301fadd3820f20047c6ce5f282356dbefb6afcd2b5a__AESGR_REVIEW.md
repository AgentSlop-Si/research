# AESGR conditional Green macro review

Reviewed 10 October 2026 UTC. The source labels itself 11 October 2026.

## Disposition

AESGR remains an explicitly conjectural Fourier-macro program. Its conditional power-of-two complexity implication is sound in a specified unit-cost exact-scalar and word model, with uniform preparation, indexing, routing, valid denominators and fixed product depth included. This review supplies a precise radix-selection argument for that implication. It does not supply the missing macro family.

Two claims need definite correction: the digit truncation in section 13 cannot in general be transferred from modulus `(q+1)^q` to the required power-of-two Fourier modulus, and section 20 reverses the asymptotic comparison with a fixed positive power saving. Several additional statements need narrower scope, particularly the claimed transfer of one-layer capacity intuition to products and the admissibility of arbitrary local interpolation coefficients.

No Fourier acceleration, macro construction, novelty, numerical stability or bit-complexity result is accepted here. No new synthesis or fusion experiment was performed.

## Sources and duplicate identity

Both complete source files were read and independently materialized. Direct byte comparison, UTF-8 text comparison and SHA-256 agree:

- `AESGR_Fourier_Theory_2026-10-11.md`.
- `AESGR_Fourier_Theory_2026-10-11(1).md`.
- Each has 19,421 bytes and 733 newline-terminated lines. SHA-256 for both: `9a723a072a427aa6c1633981ba0efaf711fd5cc0e5bda8c69da188fab2490daf`.
- They are two uploaded files for one byte-identical research candidate. They should not be counted as two source families or two results.

Line citations below refer to either identical source. The source's initial qualification at lines 13–14 correctly says that macro existence is unproved and that no faster FFT has been established.

## Accepted mathematics and its scope

### The Green executor

Lines 59–91 are valid for a weighted Hamiltonian cycle with nonzero edge weights and holonomy `h != 1`. Since `W^B = h I`, multiplication gives

`(I-W)(I+W+...+W^(B-1)) = (1-h) I`.

Thus the displayed inverse is exact. In cycle order, solve `y_i - w_i y_(i-1) = x_i`. Propagating once around the cycle expresses the last unknown as `h` times itself plus a scalar accumulated from the input. Division by `1-h` closes the recurrence; another pass recovers all coordinates. Computing the holonomy, input recurrence, normalization, and reads/writes is O(B) unit-cost scalar/word work. One need not form the dense inverse or all powers of W.

A sum of q such actions costs O(qB), including accumulation and gather/scatter in explicit cycle-order arrays. A product of ell sums with diagonal/permutation interfaces costs O(ell qB). Reducing this to O(qB) requires one constant ell independent of q, B and N. A successful small example at an increasing depth is not enough.

### The one-layer arc obstruction

The argument at lines 97–127 is valid for the stated one-layer sum. Restrict a cycle inverse to m selected rows. Its columns fall into at most m cyclic arc classes, each with a fixed projective direction. The apparent two linear intervals at the chosen cut are the same projective class after multiplication by h. With q cycles, joint arc classes number at most m^q. In a fixed class, the summed columns lie in the span of at most q direction vectors and have rank at most q.

For m=q+1 consecutive Fourier rows and a primitive B-th root in the working field, any q+1 distinct columns are a Vandermonde system with nonzero column factors, so they are independent. Each joint class has at most q columns, hence `B <= q(q+1)^q`. If B<q+1 the bound is already trivial. The logarithmic inversion gives the stated necessary `q = Omega(log B/log log B)` along an unbounded one-layer family.

This is a representation bound. It is neither a general Fourier circuit lower bound nor an existence theorem near the ceiling. The live Incoming queue row 22 already records that Phase43.1 is a specialization of the previously accepted M-ROUTED-FIELD argument, so it must not be counted again as a new project theorem. The present review verifies the elementary implication, not a new historical-priority claim.

### The exact Weyl certificate

Lines 458–462 give a sufficient and necessary full-matrix certificate once conventions are fixed: use `S e_j = e_((j+1) mod B)` and `D = diag(1,zeta,...,zeta^(B-1))`. From `M e_0 = 1` and `M S = D M`, induction yields `M e_j = D^j 1`, which is the positive-sign Fourier column. Changing the Fourier sign requires changing D accordingly.

This is a correctness certificate. Writing those equations does not create a fast coefficient compiler, cheap verifier or solution. Checking only some rows is insufficient.

## A corrected fully charged conditional implication

Assume that for every sufficiently large integer q a deterministic uniform generator supplies a power-of-two length B_q and a legal exact Fourier macro, with constants `0<c1<=c2` and constant ell such that

`c1 q log q <= log B_q <= c2 q log q`.

Assume its entire scalar and word preparation, including cycle orders, inverse order maps, weights, sum coefficients alpha, diagonal entries, holonomies and denominator guards, costs O(qB_q). Its online application costs O(qB_q), and the generator is a specified algorithm rather than a precomputed infinite family or nonlinear-solver oracle. Operations on the prescribed scalar field are unit cost; indices and addresses occupy O(log N)-bit words. Exact primitive roots and the allowed constant/extension operations are part of the interface. These assumptions clarify lines 230–268; none is constructed by this packet.

For current power-of-two length n, put `L=log n`. Choose the largest integer q with

`c2 q log q <= L/2`.

For all sufficiently large n, the maximality and `(q+1)log(q+1)/(q log q) -> 1` imply

`q log q > L/(4c2)`.

Consequently

`n^theta < B_q <= sqrt(n)`, where `theta=c1/(4c2)>0`.

Thus B_q divides n, `M=n/B_q` is again a power of two, and

`sqrt(n) <= M < n^(1-theta)`.

The selection can be implemented with integer bit lengths and a fixed integer upper-bound constant in place of real logarithm comparisons; O(log n) trial indices or a binary search fits inside the stated O(n) word budget. It requires no real-logarithm oracle. This explicit conservative selection avoids assuming that B_q is monotone, that every nearby length occurs, or that the chosen B_q is Theta(sqrt(n)). The ideal balanced-radix language in lines 353–372 is unnecessary. A constant-factor contraction of the logarithm is enough.

The n-point Cooley–Tukey decomposition uses M copies of the B_q macro, B_q transforms of size M, and O(n) exact twiddle/routing work. Macro coefficients may be shared across identical copies, but even separately charged preparation in every copy is at most `M*O(qB_q)=O(qn)`. Preparing n-th-root powers costs O(n), and compatible subroots are powers of the supplied root. Inverses use the inverse root and an explicit normalization. Summation, diagonal application, routing, input reads, and all n output writes remain within O(qn+n).

With a fixed finite base case, the recurrence is therefore

`T(n) <= B_q T(n/B_q) + C q n + C n`.

Normalize `A(n)=T(n)/n`. At successive sizes n_k, `L_k=log n_k` decreases at least geometrically by the factor `rho=1-theta<1`, and `q_k=O(L_k/log L_k)`. Hence

`A(N) <= O(1) + C sum_k (q_k+1) = O(log N/log log N)`.

One rigorous summation splits at `L_k=sqrt(log N)`: above the split the denominator is at least one-half log log N and the numerators sum geometrically; below it, monotonicity bounds the remaining O(log log N) terms by O(sqrt(log N)/log log N), for a total O(sqrt(log N)), which is smaller than the desired leading bound. The constant base case absorbs small logarithms.

The conclusion is the conditional O(N log N/log log N) count for every power-of-two N, fresh arbitrary input and all outputs. It remains conditional on exactly the missing macro/compiler contract. It does not require or follow from section 13's digit proposal.

### What fully charged does and does not mean

- Uniformity: an existence proof or a finite fitted table does not establish the generator. A q-dependent search, elimination, branch enumeration, field extension, denominator test or sorting step must appear in its cost.
- Orders and routing: arbitrary cycle permutations need explicit O(B)-sized order/inverse arrays or a comparably cheap rule. Free access to an arbitrary permutation is not a uniform construction. Digit grouping can be bucketed, but unspecified within-group permutations are still missing data.
- Scalar precision: unit-cost exact field/complex operations do not give a bit bound. The manuscript supplies no coefficient-height, extension-representation, separation-from-poles, intermediate-growth or condition-number control. Exact division by a nonzero but tiny `1-h` is legal in the stated algebraic model and can be numerically dangerous.
- Denominators: source nonvanishing must hold exactly for every generated instance. A floating-point residual, fitted root or arbitrary precision threshold is not a certificate.
- Every input and output: correctness must be a full linear identity, not a fit on selected input vectors or four Fourier rows.
- All lengths: a power-of-two convolution reduction of length L with `2N-1 <= L < 4N` is possible, but requires a compatible exact chirp interface, such as a supplied primitive 2N-th root whose square is the required N-th root, plus a primitive L-th root. A supplied N-th root alone does not generally permit obtaining those extra roots by field operations. The source appropriately withholds the all-length statement at lines 427–430. No all-length theorem is promoted here.

## The digit truncation defect

Lines 502–514 correctly expand integer multiplication in base m=q+1. The claim that only d<q matters is correct modulo m^q. Lines 516–521 then use that truncation as the B_q-point Fourier exponent target, although B_q is required to be a power of two, not m^q. These are different moduli.

The requested counterexample satisfies the manuscript's own stated domain:

- q=2 and m=3.
- B=8 is a power of two, satisfies B<=m^q=9, and is explicitly requested as a first experiment at lines 575–578.
- i=j=3 are valid indices 0 through 7, with two base-three digits `(0,1)` in low-to-high order.
- The entire product is the degree-two term `i_1 j_1 m^2 = 9`.
- Dropping d>=q leaves zero.
- The full Fourier exponent is `9 mod 8 = 1`; the truncated exponent is zero. For a primitive eighth root zeta, the correct entry is zeta, not 1.
- Modulo 9 both are zero, so the counterexample does not dispute the actual modular identity in line 514. It disputes its use for the Fourier modulus.

A fresh exact finite-field witness uses zeta=2 in F_17, which has exact order eight. The correct phase is `2^9 mod 17=2`; the truncated phase is `2^0=1`. The same i=j=3 defect also occurs at the proposed B=4 size.

A safe replacement is: retain every digit-product term d=0 through 2q-2 and reduce its weight modulo B_q; remove terms only after proving their coefficients vanish modulo B_q. The sufficient condition `B_q | m^q` permits the displayed truncation, but is not part of the current conjecture and often fails. It is not asserted to be necessary for every restricted small index range. Restricting to compatible lengths or introducing a separately proved correction requires a new proof; it is not supplied here. Retaining the terms repairs the integer identity but does not produce a Green macro. There are still only 2q-1 digit-convolution diagonals, which is O(q); this observation does not establish that any Green cycle computes one. The defect invalidates the proposed truncation argument, not the independent macro-existence conjecture or its conditional recursion.

## Other claims requiring correction or qualification

### One-layer capacity does not become a product capacity

The valid class-rank proof is applied directly to one sum on the selected output rows. After multiplication by another dense sum, a column is mixed through all intermediate coordinates, and the original joint-class argument no longer applies as stated. Sections 5 and 6 properly label a product construction as conjectural, but sections 3, 7 and 18 must not treat the one-layer upper ceiling as a proved matching upper bound for that larger architecture.

A fixed-depth product may have a different capacity scale. No general product ceiling or saturation theorem is proved. The current queue's four-row N=8/16 certificates are bounded partial-row existence results; N=32 target interpolation is numerical only. Their Jacobian ranks and exact four-row certificates do not establish a full Fourier macro or a uniform family. These existing certificate checks were not replayed in this review.

### Arc coding and rewiring remain obligations

An abstract injective code in an alphabet of size m^q does not alone specify Hamiltonian cycles with the required common selected row separators and their correct self-column/boundary memberships. The source must give legal coordinate permutations and specify which existing vertices act as separators; it cannot silently add m extra vertices. This review does not prove that such a compatible coding is impossible, but the asserted exact realization needs an explicit construction.

The assertion of Theta(B) rewiring rank at lines 168–170 also needs an actual family and a rank proof against the defined short-stride reference class. Describing within-group permutations as independent or non-affine supplies neither an exact rank lower bound nor a deterministic O(qB) generator. The imported Laurent-bandwidth, phase-defect and separator barriers must retain their own architecture hypotheses, rather than automatically applying to every product factor separately. No new pass through those barriers is certified here.

### Local interpolation has a nonzero coefficient constraint

The linear algebra at lines 480–485 is correct: if D_sigma is invertible, the unrestricted scalar solution is unique. However, the following realization claim must retain admissibility. A source coefficient of the form `alpha_s/beta_(s,j)`, with nonzero beta and a fixed nonzero alpha_s, cannot be zero.

For example, take direction columns `(1,1)` and `(1,2)`, so `D=[[1,1],[1,2]]`, and target `(1,1)`. The unique solution is `(1,0)`. Both direction columns have nonzero entries and are possible Green directions on a two-row arc, but the second source scalar cannot be realized by a finite nonzero prefix with alpha_2 nonzero. Setting alpha_2=0 disables that entire summand, not just this source column. Therefore invertibility alone does not prove that every target is realizable in the nonzero-weight grammar. When all required coefficients are nonzero and the selected row prefixes/holonomies remain compatible, local edge ratios can assign them; global consistency is still unproved.

### Search success and failure are not asymptotic theorems

A finite full-DFT macro certificate would be a useful finite result, but would still not prove fixed-depth uniform construction for all q. Conversely, `B_max(q)` in section 16 must denote a proved maximum over the prescribed legal, fixed-depth, charged class, not the largest size found by a search. A failed search cannot show its ratio tends to zero or kill the conjecture. A different choice of constant depth can also change the class.

The assertion at lines 287–291 about Theta(N log N) when only exponential-in-q macros are available is a statement about a particular charged recurrence, not an unrestricted lower bound. Upper bounds on macro size and application cost alone should not be presented as a matching runtime lower bound.

### The external asymptotic comparison is reversed

The official OpenAI repository documentation states a uniform all-length exact supplied-root result of O(N(log N)^(1-epsilon)) for epsilon=10^(-13), including root-order selection and scalar preparation. The statement and its stated model were source-verified at https://raw.githubusercontent.com/openai/math/main/lean/docs/130.md ; the paper and Lean proof were not independently checked in this review. The live repository is the source, not a pinned proof revision.

Independently of that proof, the comparison in lines 679–681 is mathematically wrong for any fixed epsilon>0:

`[N log N/log log N] / [N(log N)^(1-epsilon)] = (log N)^epsilon / log log N -> infinity`.

Thus the cited positive-power-saving asymptotic bound is stronger than AESGR's stated log-log-saving bound, even when epsilon is extremely small. This compares growth of upper-bound expressions, not practical timings, unknown constants or lower bounds on either algorithm. A useful alternative construction would still be possible, but the claim of a larger asymptotic saving must be removed.

## Fresh controls and evidentiary limits

`exact_controls.py` was authored for this review and executed without importing or running uploaded programs. It checks byte/text identity, exact digit products and 10 bounded sweeps totaling 10,192 index pairs, the eighth-root finite-field witness, a rational cyclic Green recurrence with zero exact residual, and the zero-coefficient local interpolation example. The q=2 sweeps fail in 1 of 16 B=4 pairs and 25 of 64 B=8 pairs. Passing small sweeps where high terms vanish do not prove the general proposal.

`exact_control_results.json` contains the full results. The conditional theorem and asymptotic comparison are proved algebraically above; the finite controls are sanity checks and counterexamples, not substitutes for those proofs. No full macro solve, nonlinear search, coefficient synthesis, uploaded program execution or new fusion was performed.

## Recorded queue disposition

This candidate is recorded once as AESGR-20261011 in the existing Incoming queue, row 29. Both identical uploads are retained as one candidate. Its status is independently reviewed conditional proposal with corrections; macro existence remains open. The accepted Green executor, one-layer bound and conditional power-of-two implication remain separate from the invalid Fourier-modulus truncation and reversed comparator. Uniform legal full-output construction, preparation, denominator and precision obligations remain open. Catalogue and novelty counts and ranks were not changed.
