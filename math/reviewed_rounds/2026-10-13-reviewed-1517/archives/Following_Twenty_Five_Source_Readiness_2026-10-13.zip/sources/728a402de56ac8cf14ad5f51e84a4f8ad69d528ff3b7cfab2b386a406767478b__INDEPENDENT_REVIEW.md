# Independent review: deterministic paid CHIRP root preparation

13 October 2026 UTC. Separate-agent internal project review, with fresh reviewer-authored checks. This is not an external peer review or historical-priority finding.

## Verdict

**ACCEPT at the exact bounded, optional primitive-N-root preparation and named-event integration scope.** No correction to the pinned candidate source or contract is required.

- Candidate archive SHA256: `70916a47125cd103612de4d62550d9dec0d2e3d721d72a05f308767776894c93`.
- Preparation source SHA256: `a655303588a286f3c6a355ff3a4c64c877370ce69065e675c5cfa7983836c2e3`.
- Unchanged supplied-root source SHA256: `efc0b42360c1433fd1bf5da8f61f795a5d80ebedd592f3cba877dd9eca0690a8`.
- Preparation contract SHA256: `9762fc11462e8d30de503b1e89b7b4c01828c856a08b740d15236566d04a9983`.
- Reviewed API: `execute_prepared({N,p,x}, budget=20_000_000, trace=False)`; exact resident built-in inputs, `3 <= N <= 512`, prime `5 <= p <= 65537`, `N | p-1`, and N canonical residues. Python host failures and concurrent mutation remain outside the contract.
- Existing review priority 55 applies until this review is accepted. The now-completed named root-preparation stage merits the specified completed-stage cap **15/100**, a work-priority judgment rather than a correctness or novelty probability.

This accepts deterministic paid preparation of a primitive Nth root and complete transport into the already accepted bounded rank-at-most-two common-chirp executor. It does not close the full C06, ALG-CHIRP-ELIM, Q13 or STR-Q2 overview rows. It does not integrate an actual legacy caller, enlarge the domain, switch to the primitive-2N-root family, prove a new general-rank/min(B,H) result, or establish all-N asymptotics, practical performance, bit complexity, numerical stability, FFT advantage or novelty.

## Pinned materials and preservation

The entire `prepare_executor.py` and `supplied_root_executor.py`, both contracts, producer report, completion-bound certificate, review request, all producer checker source, result files and source bindings were inspected. Every one of the candidate's 19 manifest entries matches its declared size and SHA256; all 20 archive members match the local candidate bytes. All six historical source bindings were checked against available originals. The accepted supplied-root file is byte-identical to its original implementation and its accepted review pin.

Review work is additive in this separate directory. Original candidate, original research records, accepted executor, and live overview tables were not changed. No external code or third-party package was executed. The candidate's own research sources were inspected before execution; independent checker and in-memory fault variants were authored for this review. Only standard-library modules and the pinned candidate modules are required.

## Deterministic preparation proof

The source validates and copies all raw coordinates before primality or root preparation. Zero inputs cannot bypass this work. Exact type checks reject booleans and subclasses, range guards precede the bounded arithmetic, and unsupported inputs produce a detected INVALID only when the relevant paid guard is reached. Lower allowances may instead yield LIMIT.

Trial primality tests every integer from 2 through the square-root threshold, with its final loop guard. Factorization scans all divisors 2 through N, divides out every multiplicity, and retains every failed final repeated-divisibility check. A recorded divisor is prime because all smaller factors have already been removed. Factoring p-1, supplying a field root or calling an external order oracle is unnecessary.

For H=(p-1)/N and every h from 1 through p-1, explicit paid binary powering forms w=h^H. Fermat's theorem gives w^N=1. The source checks that equality anyway and, for every distinct prime q dividing N, checks w^(N/q) != 1. All checks run even after one fails. If the order d properly divides N, some such q has d | N/q, so the criterion is equivalent to exact order N.

The multiplicative group of a finite prime field is cyclic. A generator g has g^H of order N, so enumerating every nonzero integer residue necessarily reaches success. This uses no bound on the least primitive root or least successful base beyond h <= p-1. The first successful base defines the root policy; it need not yield the numerically least primitive root. The defensive exhausted-search REFUSED arm is unreachable for an unmodified program and valid input, but is correctly distinguished from NONMEMBER.

The selected root is passed to the unchanged supplied-root `_run` under the identical meter. That program again validates/copies x, proves primality and checks its complete root table. The earlier accepted recognition/output proof therefore transports with no change to the family. This dependency is explicitly inherited, not presented as a new theorem proved by the preparation packet.

## Root convention and mathematical outputs

Every MEMBER contains its selected omega and all N coordinates of the positive-sign, unnormalized DFT. For v=omega^u with gcd(u,N)=1, X_v[k]=X_omega[uk mod N]. Multiplication by u permutes the phase/frequency exponents, with the established even-N phase alias, so the input family stays invariant while Fourier indexing can change.

Fresh reviewer tests use an alternative mathematical oracle: exhaustively construct the union of every zero-, one- and two-mode common-chirp signal for small grids, then compare source decisions to set membership. This avoids the producer's quartic, Prony and Fourier-support recognition helpers. Returned witnesses are reconstructed independently, and direct DFT sums use a separate repeated-multiplication routine. Tests also compare entire family sets after every primitive-root change on three grids, and independently check Fourier permutations.

## Exact accounting and atomicity

The contract's model is the source-stated named-event model, not a primitive machine-operation census. One index event admits one stated thunked integer expression; built-in predicate evaluation, scalar binding, loop machinery, allocation headers, telemetry and exception unwinding remain excluded as disclosed. Those exclusions are essential to interpreting the bound.

A positive exponent e incurs P(e)=1+3 bit_length(e)+popcount(e). This accounts for the initial bit-length event and each bit visit, square, selection and conditional multiply. No free powering or inversion is hidden in the executor.

Independently re-deriving the stage totals gives:

- Validation: 23+5N.
- Prime trial: 6(floor(sqrt(p))-1)+2.
- N-factorization: 3N-2+4k+4E, with k distinct factors and E total multiplicity.
- Setup and bridge writes: 1 and 4.
- Projection: t(1+P(H)).
- Order tests and verdicts: t(P(N)+2+sum_q(5+P(N/q))).

Thus the full charge is R+B, where B includes every event in the repeated supplied-root validation and subsequent complete route. Failed root candidates, failed filtered phases, full raw verification after the first mismatch, inverse internals, every DFT coordinate copy, and final publication are retained. It is neither B alone nor max(R,B).

The meter admits field operations, indexed reads/writes and index thunks before executing them. The source does not replace the shared meter at the bridge. A denied event raises LIMIT and discards the entire mathematical result, even after a private root or output buffer exists. Only status and label/count telemetry remain. INVALID uses its paid failed guard; REFUSED uses its own paid refusal event. No Fourier fallback or uncharged root publication exists.

Fresh checks reproduce full preparation event categories and the exact supplied-root count suffix on every completed reviewer case. Every-unit cutoffs check exact admitted prefixes, next denied labels, exhausted allowances and absent mathematical payload. Wrapped successful field calls independently equal charged arithmetic counts on completed and interrupted runs.

## Finite default-completion bound

The proof is valid for every supported resident input, without enumerating all possible signals. The following deliberately loose bounds all hold over the declared finite domain:

- t <= 65536, k <= 4, E <= 9.
- P(H) <= 61, P(N) <= 41, P(N/q) <= 37.
- Each root candidate costs at most 273 named events; nonsearch preparation costs at most 5706.

For a nonzero input the quartic has nonzero constant term, and its canonical phase arguments are distinct. Hence there are at most four attempted supplied-root phases. Each attempt costs at most 12494 including selection, moments, the longest solve/grid/amplitude route, inverse internals and all-coordinate verification. The following independent stage bounds reproduce the certificate:

validation 3102; primality 1532; root table 2048; quartic 46; full phase scan 8708; all candidate routes 49976; Gauss row 7168; mixture 5632; materialization 1549; publication 1.

Their sum is 79762 < 100000. The Gauss bound even allows 513 Euclidean divisions, which is far looser than needed but valid because its successive nonnegative remainders strictly decrease after the first step. The zero path is smaller.

Consequently the integrated bound is 65536*273+5706+100000 = **17,997,034 < 18,000,000 < 20,000,000**. The default returns MEMBER or NONMEMBER on every valid input under the stated host assumptions. Smaller budgets remain genuinely indeterminate. This finite named-work proof is independent of the observed maximum successful base and is not a CPU, memory, bit or unbounded-size complexity guarantee.

## Fresh independent evidence

`independent_check.py` / `INDEPENDENT_RESULTS.json` establish:

- All 64,899 admissible parameter pairs, independently discovered by trial primality and divisor-pair enumeration. Every first successful base is selected by repeated multiplicative-order computation, not the source's prime-divisor test.
- Exact match of all parameter rows through SHA256 `d86f491c0ab89b582ddfc8c7034a5d582d769c6b3f41747dcde25f297515be75`.
- Maximum first base 38 at N330/F55441, root6683; maximum preparation 12,347 events at N510/F36721, first base37, root19433.
- 3,974 complete decisions: 2,209 MEMBER and 1,765 NONMEMBER; 3,974 independent preparation-category and exact shared-ledger transport checks.
- All 3,165 raw vectors at N3/F7, N4/F5 and N3/F13 against independently enumerated family sets; 240 additional random set-membership oracles.
- 153,104 directly recomputed DFT coordinates; all 510 lengths; 59 long-search/max-parameter rank-two cancellation cases; ten complete-family root-change checks and 38 DFT permutation checks.
- 4,396 cutoff calls, including every final materialization event at N512/F65537 and failed-candidate boundaries at the maximum first-base pair; eight exact-budget completions.
- 839 successful arithmetic-call reconciliations; 24 malformed-record controls and seven invalid execution-option controls.

These parameter checks are not 64,899 full rank-two executions. The 3,974 complete executions and 64,899 parameter calculations are distinct evidence sets. Producer counts are separately replayed and never relabeled as fresh reviewer counts.

`independent_mutations.py` / `INDEPENDENT_MUTATION_RESULTS.json` test deliberate shared-meter reset, free failed-candidate charge, omitted factor-scan charge, free power, wrong projection, missing exact-order rejection, leaked root on LIMIT and corrupted final DFT coordinate. Each fault must be detected. A forced-exhaustion variant checks six failed candidates, defensive REFUSED, every one of its 243 cutoff prefixes, and exact-budget refusal. Fault variants exist only in memory; reviewed sources remain untouched.

`REPLAY_VERIFICATION.json` records the fresh isolated-interpreter replay of all three inspected producer suites and byte comparisons to their original JSON results. These replay numbers remain producer-suite reproducibility evidence rather than new independent mathematical coverage.

## Classical attribution and remaining gate

The author-hosted Handbook of Applied Cryptography was directly checked: [Chapter 2, Fact 2.213](https://cacr.uwaterloo.ca/hac/about/chap2.pdf), printed p.81/PDF p.34, supplies finite-field multiplicative cyclicity; [Chapter 4, Algorithm 4.80 and Note 4.81](https://cacr.uwaterloo.ca/hac/about/chap4.pdf), printed p.163/PDF p.32, supplies classical order tests and prescribed-order projection. Algorithm 4.80 is randomized; its expected cost is not claimed for this deterministic exhaustive search. No copyrighted source PDFs are republished in this review.

The next distinct implementation gate is a source-pinned actual caller/dispatcher integration with explicit optional-preparation selection, returned-root ordering and budget transport. That gate requires an actual caller source and acceptance scope; it is not inferred complete here. The completed bounded preparation component should not be repeatedly reopened absent contradictory evidence.
