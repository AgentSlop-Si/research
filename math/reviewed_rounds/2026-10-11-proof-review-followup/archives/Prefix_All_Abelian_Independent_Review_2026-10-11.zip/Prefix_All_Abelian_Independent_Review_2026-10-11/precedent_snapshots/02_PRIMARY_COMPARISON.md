# Prefix-stabilizer priority follow-up

10 October 2026 (UTC). Separate addendum to the frozen novelty ranking.

## Conclusion

The complete prefix-stabilizer extremum/equality package remains a focused novelty candidate with **historical priority unresolved**. This pass does not justify promoting it to a worldwide-first result or changing the published family ranking.

Two additional antecedents sharpen the claim:

- Maximal-subgroup recursion for counting subgroup chains is already explicit in Ștefănescu–Tărnăuceanu (2009).
- Factorial times independent-subtree-product counting is classical; a precise modern account is Matsen–Billey–Kas–Konvalinka, Theorem 5 and Example 6.

Consequently, the strongest candidate contribution is **proving that every maximizing element ordering is exactly a recursive coset hierarchy, with its top subgroup recoverable uniquely from the proper-prefix stabilizers**. Once that characterization and uniqueness are established, the displayed counting recurrence uses a standard sum/product principle. It is a useful exact consequence, rather than evidence of a new enumeration method by itself.

The full Erdős–Faigle–Kern (EFK) mathematical body was **not recovered**. Both public primary PDFs expose twelve pages but no readable body through the available PDF reader. Indexed excerpts and the earlier corrected empty-minimum comparison remain partial evidence. EFK has not been excluded as a whole-paper antecedent.

## 1. Fixed target and four distinct claims

The inspected target is the already accepted theorem for the left regular action of a finite group G, of order m. For an ordering x₁,…,xₘ, put Tⱼ={x₁,…,xⱼ}, Hⱼ=Stab_G(Tⱼ), Z=Σⱼ(|Hⱼ|−1), and W(m)=Σ_p v_p(m)(1−1/p).

The two accepted classes are **finite quasihamiltonian groups**, meaning every two subgroups permute, and, separately, **all finite p-groups**. Finite abelian groups are included. For nontrivial G:

1. **Exact maximum:** max Z=mW(m).
2. **Every optimizer:** precisely the orders obtained by consecutive right-coset blocks of a maximal subgroup K, with independently chosen optimizing orders inside every block, recursively.
3. **Unique top:** K=⟨H₁,…,Hₘ₋₁⟩, so one order cannot be counted under different top subgroups.
4. **Labeled count:** A(1)=1 and A(G)=Σ_(K maximal)[G:K]! A(K)^[G:K]. Labels are retained; there is no quotient by translations or automorphisms.

For p-groups the accepted pointwise equality criterion is |Hⱼ|=gcd(j,m) for every j. The value alone has an elementary free-action divisibility bound and a standard normal index-p attainment construction. The necessity and uniqueness arguments are separate mathematical content.

The S₃ example remains a boundary: maximum 7, 360 labeled optimizers, 144 nonhierarchical; the out-of-scope recurrence gives 216. No upper bound for all finite groups, all solvable groups, or mixed-order nilpotent groups is added. The fixed-family Fourier application remains quadratic-size work. Correctness is attributed to the saved independent reviews, not newly certified here.

## 2. Claim-level assessment

| Claim | Closest verified mechanisms | What still needs a matching antecedent | Assessment |
|---|---|---|---|
| Maximum mW(m) | Regular-action divisibility; normal prime-index subgroup construction [GVS2003]; reciprocal orbit weights in partial EFK | Optimization over all saturated element orders, especially incompatible periods at mixed-prime sizes | Candidate exact realization; the p-group numerical component alone is modest |
| Complete optimizer hierarchy | Fixed-chain transversals [GVS2003]; individual-permutation interval decompositions [Stanley2005, Callan2003] | Necessity of consecutive coset blocks and independent internal choices across all optimizing regular-group labelings | Strongest candidate structural component |
| Unique top subgroup | Unique terminal choice for one maximal subgroup chain [ST2009]; canonical interval components of one permutation [Callan2003] | Recovery of a common maximal subgroup from all proper-prefix stabilizers of an arbitrary optimum | Distinct objective-specific statement; no matching antecedent established |
| Exact labeled recurrence | Sum over maximal subgroups [ST2009]; factorial/product recursion for rooted symmetries [Matsen2018] | Proof that this recursively counted class is exactly the optimizer set, with no overlap between top choices | Valuable theorem consequence; counting mechanism itself should receive standard attribution |

These are comparisons, not proofs that the missing statements are absent from the literature. Different objects having similar recurrences do not imply theorem equivalence, and a construction is not an all-optimizer classification.

## 3. Primary-source comparisons

### EFK1992: weighted orbit/antichain framework

[Erdős–Faigle–Kern, *A Group-Theoretic Setting for Some Intersecting Sperner Families*](https://doi.org/10.1017/S0963548300000377), 1992, pp.323–334. Current indexed text on p.327 identifies Theorem 3.1 with an antichain inequality from a regular chain cover. Current p.331 text gives Theorem 5.1 for intersecting families of maximal chains in a chain-transitive poset. The earlier p.326 excerpt explicitly allows an empty minimum. Full statements and proofs of the missing general results remain unread.

The retained comparison is exact: for the orbit of a prefix, |Orb(Tⱼ)|=m/|Hⱼ|, so reciprocal orbit size is |Hⱼ|/m. But the complete prefix family is a chain, not an antichain. Substituting one object from every prefix rank into that antichain inequality is invalid. The previous C₄ witness 0,2,1,3 gives the impossible substitution 2≤1 and isolates that error. This rules out that direct substitution only. The singleton regularity argument does not eliminate the empty-minimum case, and no full-paper exclusion follows.

### GVS2003: fixed-chain constructions

[González Vasco–Rötteler–Steinwandt, *On Minimal Length Factorizations of Finite Groups*](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/11/On-Minimal-Length-Factorizations-of-Finite-Groups.pdf), Definition 2.1 and ensuing construction, PDF p.2; Remark 2.2; Proposition 3.1, p.3. A logarithmic signature supplies unique products from ordered factor blocks. Subgroup transversals construct such signatures; a prime-index composition series gives minimum length for solvable groups. Its objective is the sum of factor-block sizes.

The target instead optimizes stabilizers of all element prefixes. A fixed subgroup-chain construction supplies a special hierarchy; it neither forces all arbitrary optimizers into that form nor permits all independently chosen local hierarchies. The source explicitly distinguishes ordered and unordered factor blocks but then ignores that distinction for its length objective. It does not thereby count the target's labeled optimizing permutations.

### Stanley2005 and BHZ2006: exact statistic, different optimization domain

[Stanley, *The Descent Set and Connectivity Set of a Permutation*](https://math.mit.edu/~rstan/papers/decset.pdf), equation (1), Proposition 1.1 and Theorems 1.2/1.4, defines invariant-prefix cuts and enumerates their joint distribution with descents. [Bergeron–Hohlweg–Zabrocki](https://arxiv.org/pdf/math/0509271), equation (3), Definition 1 and Theorem 2, identifies connectivity with the complement of Coxeter support and studies a related graded poset. The definitions and stated results were rechecked, not every proof in both papers.

The already recorded identity Z=Σ_(g∈G)|C(g)| is a double count valid for every regular group. Thus the target optimizes average connectivity over simultaneous conjugates of the entire regular group. Single-permutation distributions and a poset on individual Coxeter elements do not impose that joint multiplication constraint. Coxeter support here means reduced-word simple-generator support, not moved-point support. No separate novelty is claimed for the statistic or the reformulation.

### Callan2003/2004: recursive interval decomposition

[Callan, *Counting Stabilized-Interval-Free Permutations*](https://arxiv.org/pdf/math/0310157), 2003 preprint, pp.1–3 and 5–6; [2004 journal record](https://cs.uwaterloo.ca/journals/JIS/VOL7/Callan/callan91.html). It describes the finest consecutive invariant-interval decomposition of an individual permutation and a further decomposition into stabilized-interval-free pieces, with enumeration formulas.

This is a concrete earlier example of canonical recursive decomposition and resulting exact counting. Its pieces are intervals invariant under one permutation. The target's pieces are cosets of a subgroup recovered from the whole regular action under an extremality condition. Neither a common maximal subgroup nor the target objective is supplied by that individual-permutation decomposition. The preprint was inspected as a preprint; the journal's body was not substituted silently.

### ST2009: maximal subgroup-chain enumeration

[Ștefănescu–Tărnăuceanu, *Counting maximal chains of subgroups of finite nilpotent groups*](https://www.carpathian.cunbm.utcluj.ro/wp-content/uploads/2009-vol-25-1/carpathian_2009_25_1_119_127.pdf), Theorem 2.1, Corollary 2.1, opening of §3 and Proposition 3.1. The paper reduces maximal-chain counts through Sylow factors and recursively chooses a unique maximal subgroup. For elementary abelian groups, c(C_p^d)=((p^d−1)/(p−1))c(C_p^(d−1)).

The counted object is one subgroup chain. The target count chooses an ordering of every coset and a separate recursive order inside each coset, so its recurrence has factorials and powers absent from chain counting. Already C₄ has one maximal subgroup chain but eight target optimizers. The new citation establishes the older subgroup-recursion mechanism; it does not establish equivalence of the counting problems.

Access caution: the journal URL and masthead say 119–127, but the reader exposes six PDF pages ending with references on printed p.124. Only the exposed body and precisely identified passages support this comparison; no inspection of putative pp.125–127 is claimed.

### Matsen2018: factorial/product recursion

[Matsen–Billey–Kas–Konvalinka, *Tanglegrams: A Reduction Tool for Mathematical Phylogenetics*](https://matsen.fredhutch.org/papers/Matsen2018-bg.pdf), §2.2, Theorem 5 and Example 6, printed pp.344–345, presents rooted-tree automorphism groups through direct and wreath products. The authors identify this material as classical and attribute Theorem 5 to Jordan. Jordan's original paper was not independently inspected.

This supports the standard mechanism behind a factor q! times q independent child choices. It does not identify general prefix optimizers with automorphisms of a fixed tree. In the target, local subgroup choices may differ between cosets and the sum ranges over maximal subgroups of G. The substantial burden is first proving the exact optimizer/hierarchy correspondence and unique top. Similar product formulas alone discharge neither burden.

### BrunoSalizzoni2020: terminology and permutability

[Giordano Bruno–Salizzoni, *Additivity of the algebraic entropy for locally finite groups with permutable finite subgroups*](https://arxiv.org/pdf/2001.02419), definitions p.2, Theorem 1.4 p.3, Example 2.1 p.4 and Lemma 2.4 p.5, supplies the group terminology, Q₈/S₃ contrast and closure of permutable products. Its objective is algebraic entropy, not prefix optimization.

Important scope warning: **quasihamiltonian** and **finitely quasihamiltonian** are different conditions in this source. Its larger class includes finite groups such as S₃. The prefix theorem requires pairwise permutability of all subgroups (or the separate p-group theorem). The entropy paper's broader hypothesis cannot be imported into the prefix claim.

## 4. Access and search boundary

The EFK source-access log is in `SOURCE_ACCESS.json`. The institutional and author-linked PDFs both returned twelve-page metadata with zero extracted lines. Screenshot calls returned references but no usable image payload. A local download returned HTTP 403 with an explicit URL-access denial; that route was stopped rather than retried or worked around. The author publication list confirms its public PDF link. The University of Twente record confirms a sixteen-page 1992 Memorandum 1060 but exposes no full-text download. Publisher metadata/references were accessible; the full publisher body was not.

Current indexed EFK excerpts add introductory p.324 material and re-expose parts of pp.327 and 331. They do **not** close the remaining general-lemma/theorem gaps: Lemma 2.1, Theorem 2.1, the rest of §4, Proposition 5.1, Corollary 6.1 and complete proof coverage.

Searches used the exact EFK title and memorandum number, weighted subgroup-chain/stabilizer terms, regular-group connectivity/Coxeter-support formulations, subgroup-chain counts, and rooted-tree enumeration. One SciSpace semantic discovery search primarily returned base-size and unrelated stabilizer questions; those abstracts were not used as priority evidence. This is a bounded pass, not exhaustive review-index coverage.

## 5. Positioning and next evidence needed

Keep the existing ranking frozen. For an eventual paper, emphasize the exact maximum together with **necessity, unique subgroup recovery and independently branching coset structure**. Present the labeled recurrence as the transparent enumeration consequence of that theorem. Attribute connectivity terminology, fixed-chain constructions, subgroup recursion and the factorial/product method.

Use “we prove” followed by the exact classes and statements. Neither “first,” “new general subgroup-tree enumeration,” nor “FFT breakthrough” is supported. The next decisive source step is a readable authorized copy of the full EFK article, followed by statement-level comparison of its missing general lemmas; further unsuccessful keyword queries would not close that gap. Any eventual specialist contact remains a separate action.

## 6. Local evidence and preservation

The reviewed local theorem/proof sources and the complete frozen ranking directory are fingerprinted in `INPUT_SNAPSHOT.json`. `SOURCE_UNCHANGED.json` checks them again after this report. No preexisting file was edited, no inherited research executable was run, no new theorem was developed, and no Sheet, repository or other external destination was changed. This deliverable is a bibliography/comparison addendum only.
