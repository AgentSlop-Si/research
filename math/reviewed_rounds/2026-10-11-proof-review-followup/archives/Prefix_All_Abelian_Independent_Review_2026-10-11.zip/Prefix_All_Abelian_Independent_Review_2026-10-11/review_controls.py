"""Independent reviewer controls. Does not execute or import candidate code."""
import csv
import hashlib
import itertools
import json
import math
import time
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'prefix_three_prime_2009'


def cyclic_certificate(n=30):
    begin = time.monotonic()
    allbits = (1 << n) - 1
    divisors = [d for d in range(1, n + 1) if n % d == 0]
    primes = [d for d in divisors if d > 1 and all(d % q for q in range(2, d))]
    orbit_families = [[sum(1 << x for x in range(r, n, n // p))
                       for r in range(n // p)] for p in primes]

    def unions(orbits):
        result = [0]
        for orbit in orbits:
            result += [mask | orbit for mask in result]
        return result

    masks = sorted(set().union(*(unions(os) for os in orbit_families)),
                   key=lambda mask: (mask.bit_count(), mask))
    score = {0: 0}
    counts = {0: {1: 1}}
    chain = {0: {1: 0}}
    stabilizers = {0: n}
    pairs = edges = 0
    fac = [math.factorial(k) for k in range(n + 1)]
    for mask in masks[1:]:
        stab = sum((((mask << k) | (mask >> (n - k))) & allbits) == mask
                   for k in range(n))
        stabilizers[mask] = stab
        assert stab > 1
        predecessors = set().union(*(unions([o for o in os if o & mask == o])
                                      for os in orbit_families))
        predecessors.remove(mask)
        pairs += len(predecessors)
        predecessor_score = max(score[t] for t in predecessors)
        score[mask] = predecessor_score + stab - 1
        actual_counts = {}
        actual_chain = {}
        for t in predecessors:
            for b, value in chain[t].items():
                joined = b if mask == allbits else math.lcm(b, stab)
                actual_chain[joined] = max(actual_chain.get(joined, -1), value + stab - 1)
            if score[t] == predecessor_score:
                edges += 1
                choices = fac[mask.bit_count() - t.bit_count()]
                for b, amount in counts[t].items():
                    joined = b if mask == allbits else math.lcm(b, stab)
                    actual_counts[joined] = actual_counts.get(joined, 0) + amount * choices
        counts[mask] = actual_counts
        chain[mask] = actual_chain
    # Candidate certificate data is read only after the independent computation.
    with (SOURCE / 'PERIODIC_DP_C30.csv').open() as file:
        rows = list(csv.DictReader(file))
    assert [int(row['mask']) for row in rows] == masks
    for row in rows:
        mask = int(row['mask'])
        assert int(row['size']) == mask.bit_count()
        assert int(row['stabilizer_order']) == stabilizers[mask]
        assert int(row['maximum']) == score[mask]
        for b in divisors:
            assert int(row[f'count_B_{b}']) == counts[mask].get(b, 0)
    with (SOURCE / 'CHAIN_B_DP_C30.csv').open() as file:
        chain_rows = list(csv.DictReader(file))
    assert [int(row['mask']) for row in chain_rows] == masks
    for row in chain_rows:
        mask = int(row['mask'])
        for b in divisors:
            assert int(row[f'best_chain_B_{b}']) == chain[mask].get(b, -1)
    return {'group': 'C30', 'states': len(masks), 'predecessor_pairs': pairs,
            'optimal_edges': edges, 'maximum': score[allbits],
            'count': sum(counts[allbits].values()), 'counts_by_B_order': counts[allbits],
            'escape_chain_reachable': n in chain[allbits],
            'every_periodic_certificate_row_equal': True,
            'every_chain_certificate_row_equal': True,
            'seconds': round(time.monotonic() - begin, 3)}


def group_table(moduli):
    elements = list(itertools.product(*(range(k) for k in moduli)))
    indices = {x: i for i, x in enumerate(elements)}
    return [[indices[tuple((a + b) % k for a, b, k in zip(x, y, moduli))]
             for y in elements] for x in elements]


def subset_maximum(table):
    n = len(table)
    end = (1 << n) - 1
    stab = [0] * (end + 1)
    for g in range(n):
        shifted = [0] * (end + 1)
        for mask in range(1, end + 1):
            bit = mask & -mask
            shifted[mask] = shifted[mask ^ bit] | (1 << table[g][bit.bit_length() - 1])
            if shifted[mask] == mask:
                stab[mask] |= 1 << g
    best = [0] * (end + 1)
    ways = [0] * (end + 1)
    ways[0] = 1
    for mask in range(1, end + 1):
        bits = mask
        val = -1
        count = 0
        while bits:
            bit = bits & -bits
            bits ^= bit
            prior = mask ^ bit
            if best[prior] > val:
                val, count = best[prior], ways[prior]
            elif best[prior] == val:
                count += ways[prior]
        best[mask] = val + stab[mask].bit_count() - 1
        ways[mask] = count
    return best[end], ways[end], stab


def exact_closure(table, seed):
    current = {0} | set(seed)
    while True:
        enlarged = current | {table[a][b] for a in current for b in current}
        if enlarged == current:
            return frozenset(current)
        current = enlarged


def subgroup_recursion(table):
    n = len(table)
    todo = [frozenset({0})]
    subgroups = set(todo)
    for h in todo:
        for g in range(n):
            k = exact_closure(table, h | {g})
            if k not in subgroups:
                todo.append(k)
                subgroups.add(k)

    @lru_cache(None)
    def count(k):
        if len(k) == 1:
            return 1
        proper = [j for j in subgroups if j < k]
        maximal = [j for j in proper if not any(j < u for u in proper)]
        return sum(math.factorial(len(k) // len(j)) * count(j) ** (len(k) // len(j))
                   for j in maximal)
    return count(frozenset(range(n))), subgroups


def value(n):
    ans, left = 0, n
    for p in range(2, n + 1):
        while left % p == 0:
            ans += (n // p) * (p - 1)
            left //= p
    return ans


def small_groups():
    # Includes the singleton explicitly and all 24 nontrivial isomorphism types <=16.
    specs = [(), (2,), (3,), (4,), (2, 2), (5,), (6,), (7,), (8,), (4, 2),
             (2, 2, 2), (9,), (3, 3), (10,), (11,), (12,), (6, 2), (13,),
             (14,), (15,), (16,), (8, 2), (4, 4), (4, 2, 2), (2, 2, 2, 2)]
    output = []
    for spec in specs:
        table = group_table(spec)
        best, count, stab = subset_maximum(table)
        predicted, subgroups = subgroup_recursion(table)
        n = len(table)
        assert best == value(n)
        assert count == predicted
        # Audit the actual group operation, not merely orders, in the orbit induction step.
        orbit_checks = 0
        for mask in range(1, 1 << n):
            stabilizer = [g for g in range(n) if (stab[mask] >> g) & 1]
            for k in subgroups:
                if all((mask >> h) & 1 for h in k):
                    generated = {table[g][h] for g in stabilizer for h in k}
                    assert all((mask >> h) & 1 for h in generated)
                    orbit_checks += 1
        result = {'moduli': spec, 'order': n, 'subsets': 1 << n,
                  'maximum': best, 'count': count, 'subgroups': len(subgroups),
                  'orbit_checks': orbit_checks}
        output.append(result)
        print(json.dumps(result), flush=True)
    return output


def nonabelian_boundary():
    table = [[2 * ((i + (-1) ** j * k) % 4) + (j + ell) % 2
              for k in range(4) for ell in range(2)] for i in range(4) for j in range(2)]
    seq = [0, 1, 2, 3, 5, 6, 4, 7]
    subset, generated, stabilizers = set(), frozenset({0}), []
    for index, x in enumerate(seq):
        subset.add(x)
        stabilizer = {g for g in range(8) if {table[g][h] for h in subset} == subset}
        stabilizers.append(sorted(stabilizer))
        if index < 7:
            generated = exact_closure(table, generated | stabilizer)
    best, count, _ = subset_maximum(table)
    assert len(generated) == 8
    assert stabilizers[:-1] == [[0], [0, 1], [0], [0, 3], [0], [0, 3], [0]]
    assert sum(len(s) - 1 for s in stabilizers) == 10
    assert best == 12
    return {'group': 'D8', 'sequence': seq, 'stabilizers': stabilizers,
            'generated_B': sorted(generated), 'score': 10,
            'independent_full_subset_maximum': best, 'maximizer_count': count}


if __name__ == '__main__':
    result = {'reviewer_authored': True, 'candidate_code_executed': False}
    result['C30'] = cyclic_certificate()
    print(json.dumps(result['C30']), flush=True)
    result['small_groups'] = small_groups()
    result['D8'] = nonabelian_boundary()
    result['mixed_base_envelope'] = 5 * sum(math.gcd(k, 6) for k in range(1, 7)) - 6
    assert result['mixed_base_envelope'] == 69
    result['status'] = 'PASS'
    (ROOT / 'INDEPENDENT_CONTROLS.json').write_text(json.dumps(result, indent=2) + '\n')
    print('ALL INDEPENDENT CONTROLS PASS', flush=True)
