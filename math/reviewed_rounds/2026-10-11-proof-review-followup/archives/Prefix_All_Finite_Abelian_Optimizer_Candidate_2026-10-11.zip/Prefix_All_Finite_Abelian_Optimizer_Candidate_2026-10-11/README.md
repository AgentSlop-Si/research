# Prefix: all finite abelian groups, author candidate

## Result

For every finite abelian group G, all proper-prefix stabilizers generate a
proper subgroup for every ordering. This accumulated-orbit lemma lets the
accepted local-coset mechanism prove the complete maximum, optimizer
classification, unique top, and labeled counting recurrence for every finite
abelian group, with any number of prime factors.

This is a candidate awaiting separate adversarial review. It does not establish
the corresponding arbitrary nonabelian three-Sylow/nilpotent extension or
historical priority. No Sheet or GitHub mutation was made.

## Main files

- ABELIAN_EXTENSION_PROOF.md: full symbolic theorem and proof; exact mixed-base
  numerical obstruction; explicit nonabelian boundary.
- PERIODIC_CERTIFICATE_METHOD.md: proofs of the finite recurrences and their
  exact enumeration/counting semantics.
- exact_periodic_dp.cpp: fresh complete positive-weight periodic-poset DP.
- PERIODIC_DP_C30.csv: all C30 state values and optimal counts by B order.
- CHAIN_B_DP_C30.csv: all C30 chain-state values by generated subgroup order.
- CONTROL_C30.txt: exact run summary, maximum 59 and count 467058592972800.
- fresh_abelian_controls.py, FRESH_CONTROLS.json, FRESH_CONTROL_RUN.txt: fresh
  complete-subset controls for all 24 nontrivial abelian groups of order <=16.
- SOURCE_BINDINGS.json and source_snapshots/: unchanged accepted source text.
- SHEET_SNAPSHOT.json: bounded read-only live gate snapshot.

## Reproduce

From this directory:

    g++ -O3 -std=c++20 exact_periodic_dp.cpp -o /tmp/prefix_abelian_dp
    /tmp/prefix_abelian_dp 30
    python fresh_abelian_controls.py

The first command needs a standard C++20 compiler; no external C++ libraries
are used. The Python command uses only the standard library. Run in a copy if
preserving the exact byte seal: output CSV/JSON/log files are regenerated and
the Python records include wall-clock timings. The mathematical results are
deterministic. Originals and accepted control scripts remain inert.

## Expected headline results

- C30: 33814 states, 14587235 predecessor pairs, maximum 59,
  467058592972800 labeled optimizers; full-escape chain state unreachable.
- Fresh exhaustive subset controls: PASS, 24 groups, 398348 subsets,
  931990 local orbit-containment checks.
- Mixed-base substitution obstruction: dense gcd envelope 69 versus optimum
  59 at C30; excess 10.
- D8 boundary: one explicit order has B=D8 and score 10, illustrating why
  abelian orbit-product closure cannot simply be assumed for nonabelian groups.

## Next gate

Review the accumulated-orbit lemma and the enlarged induction. If accepted,
the arbitrary nonabelian three-Sylow gate remains open; the abelian many-prime
case may be marked closed at exactly the proven scope. No novelty rank or
historical-priority change is proposed.
