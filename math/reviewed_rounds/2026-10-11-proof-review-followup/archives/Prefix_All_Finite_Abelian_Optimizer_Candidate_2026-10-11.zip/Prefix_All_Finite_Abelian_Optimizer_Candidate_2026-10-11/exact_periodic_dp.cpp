#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <unordered_map>
#include <vector>
using namespace std;
using cpp_int=__uint128_t;
ostream& operator<<(ostream& out,cpp_int n){string s;do{s.push_back('0'+n%10);n/=10;}while(n);reverse(s.begin(),s.end());return out<<s;}
struct State { uint64_t mask; int size, stab, best; array<cpp_int,8> counts{}; array<int,8> exact_b{}, parent_state{}, parent_b{}; };
int main(int argc,char **argv) {
  const int n=argc>1?stoi(argv[1]):30;
  assert(n<=30); const uint64_t full=(uint64_t(1)<<n)-1;
  vector<int> primes, divs;
  for(int d=1;d<=n;d++) if(n%d==0) divs.push_back(d);
  assert(divs.size()<=8);
  for(int d=2;d<=n;d++) if(n%d==0) { bool prime=true; for(int e=2;e<d;e++)if(d%e==0)prime=false; if(prime)primes.push_back(d); }
  vector<vector<uint64_t>> orbits;
  vector<uint64_t> masks{0};
  for(int d:primes) {
    vector<uint64_t> os;
    for(int r=0;r<n/d;r++) {uint64_t m=0;for(int k=0;k<d;k++)m|=uint64_t(1)<<(r+k*n/d);os.push_back(m);}
    orbits.push_back(os);
    vector<uint64_t> unions{0};for(auto m:os){size_t c=unions.size();for(size_t j=0;j<c;j++)unions.push_back(unions[j]|m);}
    masks.insert(masks.end(),unions.begin(),unions.end());
  }
  sort(masks.begin(),masks.end());masks.erase(unique(masks.begin(),masks.end()),masks.end());
  sort(masks.begin(),masks.end(),[](auto a,auto b){return pair(popcount(a),a)<pair(popcount(b),b);});
  vector<State> st; unordered_map<uint64_t,int> idx;
  for(uint64_t m:masks){int stab=0;for(int k=0;k<n;k++){uint64_t rot=k?((m<<k)|(m>>(n-k)))&full:m;if(rot==m)stab++;}idx[m]=st.size();st.push_back({m,popcount(m),stab,-1,{}});st.back().exact_b.fill(-1);st.back().parent_state.fill(-1);st.back().parent_b.fill(-1);}
  vector<cpp_int> fac(n+1);fac[0]=1;for(int j=1;j<=n;j++)fac[j]=fac[j-1]*j;
  st[0].best=0;st[0].counts[0]=1;st[0].exact_b[0]=0;
  vector<int> seen(st.size(),-1);uint64_t examined=0,optimal_edges=0;
  for(int si=1;si<(int)st.size();si++) {
    auto &s=st[si];vector<int> predecessors{0};seen[0]=si;
    for(const auto &os:orbits){
      vector<uint64_t> unions{0};
      for(auto m:os)if((m&s.mask)==m){size_t c=unions.size();for(size_t j=0;j<c;j++)unions.push_back(unions[j]|m);}
      for(auto m:unions)if(m!=s.mask){int ti=idx.at(m);if(seen[ti]!=si){seen[ti]=si;predecessors.push_back(ti);}}
    }
    int predecessor_best=-1;
    for(int ti:predecessors){
      examined++;predecessor_best=max(predecessor_best,st[ti].best);
      for(size_t bi=0;bi<divs.size();bi++)if(st[ti].exact_b[bi]>=0){
        int b=s.mask==full?divs[bi]:lcm(divs[bi],s.stab);
        int bj=find(divs.begin(),divs.end(),b)-divs.begin();
        int val=st[ti].exact_b[bi]+s.stab-1;
        if(val>s.exact_b[bj]){s.exact_b[bj]=val;s.parent_state[bj]=ti;s.parent_b[bj]=bi;}
      }
    }
    s.best=predecessor_best+s.stab-1;
    for(int ti:predecessors)if(st[ti].best==predecessor_best){
      optimal_edges++;
      const auto &t=st[ti];
      for(size_t bi=0;bi<divs.size();bi++)if(t.counts[bi]!=0){
        int b=s.mask==full?divs[bi]:lcm(divs[bi],s.stab);
        int bj=find(divs.begin(),divs.end(),b)-divs.begin();
        s.counts[bj]+=t.counts[bi]*fac[s.size-t.size];
      }
    }
  }
  const State &last=st.back();assert(last.mask==full);
  cpp_int total=0;for(const auto&c:last.counts)total+=c;
  cout<<"n="<<n<<" states="<<st.size()<<" predecessor_pairs="<<examined<<" optimal_edges="<<optimal_edges<<" maximum="<<last.best<<" optimizer_count="<<total<<"\n";
  for(size_t i=0;i<divs.size();i++)cout<<"B="<<divs[i]<<" count="<<last.counts[i]<<"\n";
  ofstream cert("PERIODIC_DP_C"+to_string(n)+".csv");
  cert<<"mask,size,stabilizer_order,maximum";for(int d:divs)cert<<",count_B_"<<d;cert<<"\n";
  for(const auto&s:st){cert<<s.mask<<","<<s.size<<","<<s.stab<<","<<s.best;for(size_t i=0;i<divs.size();i++)cert<<","<<s.counts[i];cert<<"\n";}
  ofstream esc("CHAIN_B_DP_C"+to_string(n)+".csv");
  esc<<"mask";for(int d:divs)esc<<",best_chain_B_"<<d;esc<<"\n";
  for(const auto&s:st){esc<<s.mask;for(size_t i=0;i<divs.size();i++)esc<<","<<s.exact_b[i];esc<<"\n";}
  int bi=divs.size()-1;
  cout<<"full_escape_maximum="<<last.exact_b[bi]<<"\n";
  if(last.exact_b[bi]>=0){
    vector<int> path;int si=st.size()-1;
    while(si!=0){path.push_back(si);int ns=st[si].parent_state[bi],nb=st[si].parent_b[bi];si=ns;bi=nb;assert(si>=0);}
    reverse(path.begin(),path.end());uint64_t prev=0;vector<int> seq;
    cout<<"escape_chain_masks=0";for(int i:path){cout<<","<<st[i].mask;uint64_t delta=st[i].mask^prev;for(int x=0;x<n;x++)if(delta&(uint64_t(1)<<x))seq.push_back(x);prev=st[i].mask;}cout<<"\n";
    cout<<"escape_witness=";for(size_t i=0;i<seq.size();i++)cout<<(i?",":"")<<seq[i];cout<<"\n";
    uint64_t prefix=0;int z=0,b=1;
    for(size_t i=0;i<seq.size();i++){prefix|=uint64_t(1)<<seq[i];int d=0;for(int k=0;k<n;k++){uint64_t rot=k?((prefix<<k)|(prefix>>(n-k)))&full:prefix;if(rot==prefix)d++;}z+=d-1;if(i+1<seq.size())b=lcm(b,d);}
    assert(z==last.exact_b[divs.size()-1]&&b==n);cout<<"escape_witness_verified_score="<<z<<" B="<<b<<"\n";
  }
}
