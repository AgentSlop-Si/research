"""Fresh exact controls; no accepted/uploaded mathematical code is imported or run."""
from itertools import product, permutations
from math import factorial
from functools import lru_cache
from pathlib import Path
import json, time

ROOT=Path(__file__).resolve().parent

def value(n):
    answer=0; remain=n;p=2
    while p<=remain:
        a=0
        while remain%p==0:remain//=p;a+=1
        answer+=a*(n//p)*(p-1)
        p+=1
    return answer

def group(moduli):
    xs=list(product(*(range(m) for m in moduli)));n=len(xs);index={x:i for i,x in enumerate(xs)}
    tab=[[index[tuple((a+b)%m for a,b,m in zip(x,y,moduli))] for y in xs] for x in xs]
    return tab

def test(moduli):
    started=time.time();tab=group(moduli);n=len(tab);lim=1<<n;full=lim-1
    stabilizers=[0]*lim
    # A separate exact subset computation uses every subset, not the periodic poset.
    for g in range(n):
        translated=[0]*lim
        for mask in range(1,lim):
            bit=mask&-mask;v=bit.bit_length()-1
            translated[mask]=translated[mask^bit]|(1<<tab[g][v])
            if translated[mask]==mask:stabilizers[mask]|=1<<g
    scores=[0]*lim;counts=[0]*lim;counts[0]=1
    for mask in range(1,lim):
        best=-1;count=0;bits=mask
        while bits:
            bit=bits&-bits;bits^=bit;prior=mask^bit
            if scores[prior]>best:best=scores[prior];count=counts[prior]
            elif scores[prior]==best:count+=counts[prior]
        scores[mask]=best+stabilizers[mask].bit_count()-1;counts[mask]=count
    @lru_cache(None)
    def cyclic(x):
        out=1;v=x
        while v:out|=1<<v;v=tab[v][x]
        return out
    @lru_cache(None)
    def join(a,b):
        out=0
        for x in range(n):
            if a>>x&1:
                for y in range(n):
                    if b>>y&1:out|=1<<tab[x][y]
        return out
    subgroups={1};todo=[1]
    for k in todo:
        for x in range(n):
            u=join(k,cyclic(x))
            if u not in subgroups:subgroups.add(u);todo.append(u)
    @lru_cache(None)
    def recursive_count(k):
        if k==1:return 1
        proper=[j for j in subgroups if j!=k and j&k==j]
        maximal=[j for j in proper if not any(j!=u and j&u==j for u in proper)]
        answer=0
        for j in maximal:
            index=k.bit_count()//j.bit_count()
            answer+=factorial(index)*recursive_count(j)**index
        return answer
    predicted=recursive_count(full)
    assert scores[full]==value(n),(moduli,scores[full],value(n))
    assert counts[full]==predicted,(moduli,counts[full],predicted)
    # Independently check the orbit-containment induction step for all nonempty
    # subsets T, each x in T, and each subgroup K with K+x contained in T.
    # S=stab(T); since K+x <=T, (S+K)+x must also lie inside T.
    orbit_checks=0
    for mask in range(1,lim):
        s=stabilizers[mask]
        for k in subgroups:
            # Checking x=0 suffices for this local equivariant statement; every
            # translated subset occurs among the exhaustive mask population.
            if k&mask==k:
                joined=join(s,k)
                assert joined&mask==joined
                if mask!=full:assert joined!=full
                orbit_checks+=1
    return dict(moduli=moduli,order=n,subsets=lim,subgroups=len(subgroups),maximum=scores[full],
                optimizer_count=str(counts[full]),recursive_count=str(predicted),
                orbit_containment_checks=orbit_checks,seconds=round(time.time()-started,4))

def main():
    specs=[(2,),(3,),(4,),(2,2),(5,),(6,),(7,),(8,),(4,2),(2,2,2),(9,),(3,3),
           (10,),(11,),(12,),(6,2),(13,),(14,),(15,),(16,),(8,2),(4,4),(4,2,2),(2,2,2,2)]
    records=[]
    for spec in specs:
        rec=test(spec);records.append(rec);print(json.dumps(rec),flush=True)
    n=30;s=sum(__import__('math').gcd(j,6) for j in range(1,7))
    obstruction=dict(group='C30',base_order=6,third_prime=5,gcd_sum=s,
                     relaxed_dense_bound=5*s-6,actual_maximum=value(30),
                     spurious_gap=5*s-6-value(30))
    assert obstruction['relaxed_dense_bound']==69 and obstruction['spurious_gap']==10
    # Fresh direct nonabelian boundary witness. Labels are 2*i+j for r^i s^j.
    tab=[[2*((i+(-1)**j*k)%4)+(j+l)%2 for k in range(4) for l in range(2)]
         for i in range(4) for j in range(2)]
    seq=[0,1,2,3,5,6,4,7];T=set();B={0};st=[]
    for x in seq:
        T.add(x);S={g for g in range(8) if {tab[g][y] for y in T}==T};st.append(sorted(S))
        if len(T)<8:
            seeds=B|S
            while True:
                enlarged=seeds|{tab[a][b] for a in seeds for b in seeds}
                if enlarged==seeds:break
                seeds=enlarged
            B=seeds
    witness=dict(group='D8',label='2*i+j means r^i s^j',order=seq,stabilizers=st,
                 B=sorted(B),score=sum(len(s)-1 for s in st),known_prime_power_maximum=12)
    assert witness['score']==10 and len(B)==8
    result=dict(status='PASS',groups=len(records),subsets=sum(x['subsets'] for x in records),
                orbit_containment_checks=sum(x['orbit_containment_checks'] for x in records),
                records=records,arithmetic_obstruction=obstruction,nonabelian_boundary=witness)
    (ROOT/'FRESH_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS',result['groups'],result['subsets'],result['orbit_containment_checks'])

if __name__=='__main__':main()
