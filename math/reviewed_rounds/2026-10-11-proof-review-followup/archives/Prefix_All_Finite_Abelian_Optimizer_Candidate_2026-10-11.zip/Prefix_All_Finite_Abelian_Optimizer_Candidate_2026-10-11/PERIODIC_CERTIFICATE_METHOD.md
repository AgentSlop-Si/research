# Exact finite certificate method

This is freshly authored corroborating code. It neither imports nor executes
the accepted source files. The mathematical theorem is proved symbolically in
ABELIAN_EXTENSION_PROOF.md.

## Weighted periodic-prefix poset

For the cyclic group C_n, let P consist of the empty subset and all nonempty
subsets whose translation stabilizer has order greater than one. The full group
is included. Assign w(S)=|Stab(S)|-1 to nonempty members, and w(empty)=0.

Every element order gives an inclusion chain in P by retaining exactly its
positive-weight prefixes, and its score equals that chain's weight. Conversely
every chain in P extends to an element order by filling its successive set
differences. Extra periodic prefixes only increase the score. Therefore the
maximum element-order score is exactly the maximum weighted-chain score.

For nonempty S in P define

    F(S)=w(S)+max_(T in P, T proper subset of S) F(T),
    F(empty)=0.

The recurrence is evaluated by increasing subset size. Its maximum at the
full group is exact. It is not a heuristic search over sampled orders.

## Counting all optimizing orders

If T achieves the predecessor maximum for S, there can be no U in P with
T proper subset U proper subset S. Otherwise F(U)>=F(T)+w(U)>F(T), contradicting
maximality. Thus every optimal predecessor edge is a cover in the positive-
weight periodic poset. All (|S|-|T|)! fillings of the set difference have no
additional positive-weight intermediate prefix. Distinct optimal chains yield
disjoint sets of element orders, because every element order has a unique
complete list of positive-weight prefixes. Consequently

    C(S)=sum_(T: F(T)+w(S)=F(S)) C(T)(|S|-|T|)!,
    C(empty)=1

counts every optimizer exactly once.

For C_n, subgroups are uniquely determined by their orders. The generated
subgroup order of stabilizers is their least common multiple. The code therefore
splits C(S) into counts by this lcm. For proper S its own stabilizer is included;
for the full group it is deliberately excluded. The empty-state class is 1,
and the empty subset's actual stabilizer is not used.

## Exact state and predecessor enumeration

A nontrivial stabilizer in C_n contains a subgroup of prime order d dividing n.
Such a subset is a union of the orbits of that order-d subgroup. The program
enumerates every union for every prime divisor d, merges duplicates, and adds
the empty state. Thus every positive-weight periodic subset is present.

For a target S and a prime d, an order-d invariant subset T contained in S is
exactly a union of those order-d orbits lying wholly inside S. Enumerating these
unions over every prime divisor lists all nonempty periodic predecessors.
The code removes duplicates by a per-target integer stamp and includes the
empty predecessor once. It evaluates the recurrence above, including every
proper predecessor and no non-subset predecessor.

Stabilizers are computed independently of the orbit enumeration by trying all
n rotations of each bitmask. Cyclic indices are residues 0,...,n-1. Arithmetic
scores are integers. Counts use unsigned 128-bit integers. For n<=30, every
counted optimizer is an order of a subset of at most 30 elements, so each count
and every nonnegative partial sum is at most 30!<2^128. No overflow is possible
in the counted recurrence under its stated input bound. The program refuses
n>30 and cases with more than eight divisors (its fixed state-array width).

For C30 there are 33814 states including the empty and full subsets; exactly
14587235 distinct predecessor pairs are examined.

## Augmented lcm chain reachability and the empty escape class

The program also records H(S,b), the maximum weight of a periodic chain ending
at S with generated stabilizer order exactly b, again excluding the full set's
stabilizer. It propagates from each proper predecessor and updates b by lcm;
unreachable states are marked -1. This is a chain-state recurrence, not a claim
that every partial exact-b chain state counts actual orders with that exact B.

If H(G,|G|) is reachable, its value does equal the maximum score among full-
escape orders: every actual full-escape order supplies such a chain, while an
extension of a chain whose stabilizers already generate G remains full escape,
and extra periodic prefixes can only increase its weight. However at C30 the
full-escape state is unreachable. This is consistent with, and follows
symbolically from, the abelian orbit-containment theorem.

The file CHAIN_B_DP_C30.csv records chain-state scores only. No optimizer count
or exact non-full-B order optimum is inferred from those scores.

## Separate exhaustive subset controls

fresh_abelian_controls.py computes the maximum and labeled count using the
different recurrence on every subset M of each test group:

    D(M)=|Stab(M)|-1+max_(x in M) D(M minus {x}).

Counts add over maximizing last-element choices. This is the ordinary complete
subset dynamic program, with no periodic-state compression or factorial-gap
counting. It compares to the theorem value and a separately computed recursive
count over the actual subgroup lattice.

The test set contains all 24 isomorphism types of finite abelian groups with
orders 2 through 16. It checks 398348 subsets and 931990 orbit-containment local
instances. For the local orbit test, the distinguished point is the identity;
all translated subsets are present, so this suffices by equivariance. The
singleton is the explicit recurrence base, rather than another test record.

The script also recomputes the C30 mixed-gcd envelope obstruction 69>59 and the
D8 boundary witness with B=D8 and score 10<12. These are exact integer checks.

No finite computation is presented as independent acceptance of the universal
proof, formal proof-assistant verification, or historical novelty evidence.
