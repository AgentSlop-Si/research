# Complete two-Sylow prefix theorem: bounded prior-work audit

11 October 2026 UTC. Historical comparison of the accepted theorem, not another proof review or an external priority certification.

## Result

No theorem-level equivalent or complete classical derivation was established in this bounded pass. The defensible contribution remains the objective-specific maximum and the necessity of the recursive coset hierarchy for **every** optimizer on the direct product of two arbitrary finite prime-power groups of distinct primes. The new scope allows either or both Sylow factors to be nonabelian, including nonpermutable subgroup lattices.

Two additional factorization antecedents materially narrow the wording: Corrádi–Hermann–Szabó already obtained subgroup-chain partial products after suitably ordering certain nonabelian-group factorization blocks; Sands already proved a unique complementary subgroup theorem under special prime-index factorization hypotheses. Neither is the accepted prefix optimization theorem. The existing C24 countercontrol directly separates their relevant conclusions from optimization of the fixed flattened element order.

The entropy search also has a definite result: the inspected nilpotent-group entropy theorem has a nilpotency-class restriction, and the 2025 Ingleton paper explicitly leaves the general nilpotent case unsettled. It supplies no all-prefix score or optimizer equality theorem.

Do not promote independent branching, construction by subgroup transversals, unique-decomposition terminology, or factorial/product enumeration to separate discoveries. Do not change the current family rank or discovery count on this audit alone. The EFK whole-paper comparison remains incomplete.

## 1. Exact accepted target

The acceptance archive is Library `libfile_3078be458c2c8191a0bbd4f2de5ebaa5`, version 0, 576,801 bytes, SHA-256 `d451f18b89a95b69bcfb199e0f60106275c09fe1c4c9135a4aea5d084c1a2517`. The local archive was hashed in this pass. Its accepted-statement member is byte-identical to the supplied local statement, SHA-256 `2b2c3af6ba0e8d04bd30d5b3f694d83ff5e3de3750eb64f30e0d222b7574cf3b`. The earlier successful Library round trip is recorded in the input pins; no claim of a fresh target download is made.

Let |H|=q^a, |P|=p^b, p≠q prime, a,b≥0, and G=H×P, N=|G|. An ordering contains every labeled element exactly once. For its prefixes T_j, let S_j={g:gT_j=T_j}, using left translation. Score all nonempty prefixes, including G itself:

    Z(x)=Σ_(j=1)^N (|S_j|−1).
    B(x)=⟨S_j:1≤j<N⟩.
    V(a,b)=N[a(1−1/q)+b(1−1/p)].

The accepted package states:

1. max Z=V(a,b).
2. The maximizing orders are exactly recursive consecutive right-coset blocks of maximal subgroups, with independent optimal local orders in the different cosets.
3. For nontrivial G, B(x) uniquely identifies the top subgroup of an optimizer.
4. With A(1)=1, labeled optimizers satisfy, for nontrivial H×P,

       A(H×P)=p! Σ_(R maximal in P) A(H×R)^p
                      +q! Σ_(M maximal in H) A(M×P)^q.

   A trivial factor contributes an empty sum. Actual subgroups are summed, not conjugacy classes; no translation, automorphism, or representative quotient is taken.
5. If a,b≥1 and B(x)=G, a sufficient loss is δ_p(1)=p−1 and δ_p(b)=p^(b−2)(p−1) for b≥2. A full-P-projection proper-prefix stabilizer gives the stronger sufficient loss p^(b−1)(p−1).

No sharp escaping maximum, three-prime theorem, or all-nilpotent theorem is asserted. The singleton has score 0 and one ordering, with no top subgroup. Acceptance is an independent project mathematical review, not external peer review or formal verification.

## 2. What is and is not matched

| Target component | Closest verified antecedent | Precise missing conclusion |
|---|---|---|
| Maximum over every labeled order | Classical connectivity statistic; divisor/orbit incidence; minimum-length signatures | The simultaneous regular-action upper bound with compatible mixed-prime prefixes |
| Complete equality classification | Transversal signatures; Rédei-type periodic factors; CHS01 chain partial products | Necessity of the hierarchy in the original fixed element order from equality in Z |
| Independent local choices | BDW11 coset-dependent signature construction | Identification of all independent choices with this objective's optimizers |
| Unique top B(x) | Classical unique factorization; Sands' unique prime-size complement | Recovery of the maximal top subgroup from all proper-prefix stabilizers |
| Labeled recurrence | Maximal-subgroup recursion; factorial/product and rooted-tree counts | Proof that the recursively counted objects are exactly all optimizers and top choices are disjoint |
| Sufficient escape deficit | No matched external statement found | The specific quantitative loss in the accepted model; no sharpness claim |

The last-column statements are comparisons of the identified results and tested reductions. They are not assertions that no other deduction from an entire subject could exist.

## 3. Reused comparisons that survive the enlarged scope

The two earlier reports were read and retained. Their mathematical controls were not rerun.

### Weighted incidence

The prior divisor-weighted encoding yields the cap N(A+B+AB), where A=a(1−1/q), B=b(1−1/p), rather than N(A+B). Its missing compatibility loss is NAB. Removing cyclicity from the second Sylow factor does not fix this proposed shortcut: the earlier cyclic-factor orders remain a subclass of the present domain. Thus any universal implication for the full theorem must already overcome that established obstruction. This statement does not silently assume the unique nested subgroups of a cyclic P exist in arbitrary P.

The extra inequality is not an EFK theorem established by that report. EFK Theorem 2.1's conditional incidence budget does not independently verify the missing prefix-family hypothesis. An equality theorem would still be needed after a numerical upper bound.

### Minimum-length signatures and the C24 control

The inherited test works in C24=C3×C8. With the last factor varying fastest, the two signatures

    Bad:  ([0,8,16], [0,4], [0,2], [0,1]),
    Good: ([0,1,2], [0,3], [0,6], [0,12])

both have type (3,2,2,2) and minimum length 9, but their flattened orders have scores 23 and 52. Bad is the natural order. The old report proves every nonempty proper prefix of Bad has trivial translation stabilizer. These facts are inherited, not new numerical experiments.

Consequently, minimum signature length, the same ordered block sizes, and amalgamated-transversal membership do not characterize this optimization. The larger two-Sylow family still contains that witness. This excludes those specific decoders, not arbitrary encodings retaining additional prefix information.

### Other retained source matches

The earlier report inspected Stanley's connectivity statistic, Bergeron–Hohlweg–Zabrocki's Coxeter extension, González Vasco–Rötteler–Steinwandt's Definition 2.1/Proposition 3.1 on minimum-length signatures, Lempken–van Trung's Theorem 4.1, Ștefănescu–Tărnăuceanu's maximal-chain counts, rooted-tree automorphism recursions, and Hulpke–Linton's subgroup/coset ordering algorithms. The fixed-group simultaneous relabeling objective is absent from the identified statements. These are inherited body comparisons in this pass, not fresh complete readings.

In particular, enlarging the group family does not make the construction or counting mechanism newly original. The project increment is the accepted objective-specific upper bound and all-optimizer necessity over the enlarged family.

## 4. Newly tested factorization implications

### CHS01: a genuine subgroup-chain antecedent, including nonabelian groups

[Corrádi–Hermann–Szabó, On factorizations of nonabelian groups](https://acta.hu/download.phtml?id=2624), Theorem 1, printed pp. 532–533, assumes a factorization into normalized normal subsets. Each factor must have prime size or satisfy a specified F-simulation condition. Under the stronger simulation condition, some ordering of the factor blocks makes successive products normal subgroups. The definition is on p. 530; Lemma 3 on p. 531 shows that an all-prime-size normalized normal factorization forces the group to be abelian.

This is a structural theorem, not merely a construction. Its conclusion may reorder factor blocks and does not optimize the original flattened element order or score every prefix. The target accepts arbitrary nonabelian Sylow factors and does not assume conjugation-invariant signature blocks.

**Specific implication test:** Both inherited C24 signatures consist of normalized prime-size subsets; in an abelian group they are normal subsets. Hence they satisfy CHS01's hypotheses, while their fixed flattenings have different scores. The theorem's block-reordering conclusion therefore cannot itself imply that every such fixed flattening is prefix-optimal. This inference uses the inherited witness, without a proof or code rerun.

### Rédei's theorem: periodic factors precede the present work

[Corrádi–Szabó–Hermann, A character free proof for Rédei's theorem](https://mathematica-pannonica.ttk.pte.hu/articles/mp20-1/mpcoszh.pdf), Theorem 1 in §7, says that a normalized prime-size factorization of a finite abelian group has a subgroup factor. Section 6 explicitly identifies subset periods with translation stabilizers and proves that a periodic normalized prime-size subset is a subgroup. Relevant locators are PDF pp. 11–13. This is a later primary proof of the 1965 theorem, not a 2009 priority claim for the underlying result.

The statement concerns a factor subset, not all element prefixes. Both C24 controls satisfy its factorization premise. Choosing/reordering a periodic factor is therefore not the target's necessity theorem for a given maximizing element order. Nor does this abelian result cover arbitrary nonabelian H and P.

### Sands08: even unique subgroup recovery is an established nearby phenomenon

[Sands, A Generalization of Hajós' Theorem](https://ieja.net/files/papers/volume-3/Volume-3--2008/5-V3-2008.pdf), Theorem 1, printed pp. 86–87, assumes a direct product of cyclic or simulated nonsubgroup subsets is a direct factor of prime index in a finite abelian group. It gives a unique normalized complementary factor, which is a prime-size subgroup generated by a successor/distortion element. Section 2, pp. 84–85, discusses periods and repeated quotient factorization.

**Specific model check:** In the inherited Bad C24 signature, A=[0,4]+[0,2]+[0,1]=[0,…,7]. These three two-element sets are cyclic nonsubgroup subsets, and A has prime index 3. Sands' complement is [0,8,16]. Yet the inherited natural element order has B(x)={0} and score 23. This complement has order 3; the target's top subgroup is recovered from proper-prefix stabilizers only for optimizers. The two uniqueness statements concern different objects. This does not refute Sands' theorem or the accepted theorem.

### BDW11: retain its full attribution

[Baumeister–de Wiljes, Aperiodic logarithmic signatures](https://arxiv.org/pdf/1104.4503), Algorithm 5.2 and Theorem 5.4, PDF p. 6, already combine compatible coset-indexed local signatures in abelian groups. Remark 5.5 includes every signature via a degenerate choice. Theorems 5.11 and 5.15, PDF pp. 8–9, give factor-period equivalences under subgroup or nontranslate hypotheses. These selected bodies were freshly confirmed; the wider comparison is inherited.

An exact period criterion for each constructed factor is not a maximum/equality theorem for every nested prefix of every ordering. Independent branching remains an antecedent, not a standalone novelty claim.

## 5. Entropy and invariant-partition alternatives

### The actual nilpotent entropy theorem is class-restricted

[Paajanen, arXiv:1308.2069v1](https://arxiv.org/pdf/1308.2069), Definition 1.1, uses logarithms of indices of intersections of a selected family of subgroups. Theorem 2.9, printed pp. 6–7, transfers these vectors to an abelian group when a p-group has nilpotency class c<p. Proposition 3.3 and Corollaries 3.4–3.7, printed p. 9, give Sylow-product and class-bounded nilpotent conclusions. The introduction itself warns that the unrestricted nilpotent argument in earlier literature has a gap.

The source does not provide an equivariant identification preserving stabilizers of arbitrary nested subsets under left translation. Preserving subgroup intersection indices alone does not assert preservation of which subgroup families can occur as prefix stabilizers. It also has no sum-of-orders equality classification or labeled-order recurrence. The accepted theorem has no nilpotency-class restriction on H or P. Thus no reduction to the target is established, even where the class hypothesis holds.

[Craven, arXiv:2505.22565v1](https://arxiv.org/pdf/2505.22565), Introduction and Theorems 1.1–1.4, printed pp. 1–2, proves the metacyclic Ingleton result and supplies supersoluble violators, while explicitly not resolving all nilpotent groups. Lemma 2.8, pp. 5–6, gives sufficient criteria involving four subgroups. This reinforces the need to read the actual hypotheses, rather than infer an unrestricted nilpotent entropy theorem from an abstract. It does not settle prefix optimization.

### Regular-group block structures are also classical objects

[Anagnostopoulou-Merkouri–Bailey–Cameron, Permutation groups, partition lattices and block structures](https://www.cambridge.org/core/journals/forum-of-mathematics-sigma/article/permutation-groups-partition-lattices-and-block-structures/BC2A06A57E3922ED73AE62B4DF428BC7), Theorem 4.1 and §4.2.3, identify commuting invariant partitions in a regular action with permuting subgroups. Theorem 4.14 treats the corresponding quasi-hamiltonian Sylow decomposition. Theorems 4.17 and 4.21 describe generalized wreath products and embeddings for prescribed block structures.

These statements match the coset/partition vocabulary and clarify the smaller permutable-subgroup setting. They do not say that an arbitrary labeled order maximizing the prefix score must supply such a recursive block structure, nor give its extremal value. The accepted arbitrary Sylow factors need not have the OB property discussed there. A group embedding or description of a prescribed block structure is therefore not the missing optimizer necessity statement.

## 6. Explicit access and priority limits

EFK is **Erdős–Faigle–Kern (1992)**, Combinatorics, Probability and Computing 1, 323–334, DOI [10.1017/S0963548300000377](https://doi.org/10.1017/S0963548300000377). This publication year is confirmed by the journal volume contents and the authors' bibliography. A later online date should not replace it.

The earlier recovery of Theorem 2.1 and its principal incidence count remains credited. The remaining gap is unchanged: full definitions/Lemma 2.1; most of §4; Proposition 5.1's proof; the complete Corollary 6.1/§6 ending; and full page-render verification. No whole-paper exclusion is justified. The denied direct-download route was not retried, proxied or bypassed. A DOI-page metadata open in this pass failed; the journal-content and author-bibliography searches verified the year without obtaining the missing body.

A separate DeVos–Goddyn–Mohar sumset candidate surfaced through an indexed passage about nested subsets and decreasing stabilizers. The CiteSeer body open failed with a 502; publisher abstract and conference material concern lower bounds for subsequence-sum sets in abelian groups. The full theorem/equality comparison was not completed and is not counted as an exclusion.

New primary PDF text was readable for the factorization and entropy comparisons. Screenshot attempts were unavailable in this runtime, so visual page-render verification is not claimed. Source pins use the text's printed/PDF locators. No third-party full text is republished in this package.

Exact-name, alternative-terminology, and broader searches included prefix periods, setwise stabilizers of initial segments, invariant subset chains, regular permutation connectivity, sum-indecomposable permutations, logarithmic signatures, factorization periods, entropy vectors, and invariant partitions. Failure to find a same-named result is not evidence of novelty. The positive result is the claim-level comparison and the explicitly tested missing implications above.

## 7. Safe publication and register wording

### Contribution paragraph

For G=H×P, where H and P are arbitrary finite groups of orders q^a and p^b for distinct primes, we determine the maximum of the sum of nonidentity left-translation stabilizers over all nonempty prefixes of a labeled element order. We characterize all maximizing orders as recursive maximal-subgroup right-coset orderings with independent optimal local choices. The top subgroup is recovered from the proper-prefix stabilizers, giving an exact labeled enumeration recurrence. The result includes nonabelian Sylow factors without a nilpotency-class restriction.

### Related-work paragraph

The construction is related to transversal logarithmic signatures, classical periodic-factor and subgroup-chain results, and coset-dependent signature constructions. The counting uses standard recursive sum/product enumeration. The cited results, in the forms compared here, do not establish the present fixed-order prefix objective and its complete equality classification. We claim neither the general idea of branching factorization nor the counting mechanism as new. This bounded comparison does not establish worldwide historical priority; the stated EFK source gap remains.

### Existing-row proposal only

Update the existing PREFIX/NEW-16 row's scope and novelty-evidence text after review; retain the existing rank, band, family grouping, and discovery-count fields. Suggested assessment: “Accepted objective-specific maximum and complete optimizer characterization for H×P with arbitrary finite q-group H and p-group P, p≠q. No exact classical implication established in this bounded comparison. CHS01 subgroup-chain factorization and Sands08 unique-complement theorems are additional structural antecedents; the inherited C24 witness separates their conclusions from fixed-order prefix optimality. Independent branching and factorial/product counting are attributed antecedents. EFK whole-paper gap and worldwide-priority uncertainty remain.”

No Sheet, GitHub, ranking, theorem, or source-file mutation was performed. No mathematical control code or candidate proof was rerun.
