"""Fresh independent controls. Never executes or imports any audited program.

Norms use multiplication matrices and tau uses complementary odd factors.
Order-15 discriminants use the parity-composition discriminant identities.
"""
import json, platform, sys, time, zipfile, hashlib
from pathlib import Path
import sympy as s

ROOT = Path(__file__).resolve().parent
q,z,x,T,r,y=s.symbols('q z x T r y')
checks=[]; norm_rows=[]; finite_rows=[]
def check(name, ok, detail=None):
    good=bool(ok)
    checks.append({'name':name,'passed':good,'detail':detail})
    if not good: raise AssertionError(name)
    print('PASS',name,flush=True)
def eq(a,b): return s.expand(a-b)==0
def reverse(P):
    p=s.Poly(P,q); return s.Poly.from_list(list(reversed(p.all_coeffs())),q).as_expr()
def pp(expr,var):
    p=s.Poly(expr,var,domain=s.QQ)
    _,p=p.clear_denoms(); _,p=p.primitive()
    return p if p.LC()>0 else -p

# Definitions, not candidate code.
C={(0,0):s.Integer(1)}
for n in range(1,6):
    for k in range(n+1): C[n,k]=s.expand(C.get((n-1,k),0)+q**(n-k)*C.get((n-1,k-1),0))
H5=sum(C[5,k]*z**k for k in range(6))
U,rem=s.div(H5,z+1,z)
check('Gaussian expansion divisible by z+1',rem==0)
p=q+q**2+q**3+q**4; v=1+q**2+q**3+q**4+q**5+q**6
check('residual coefficient identity',eq(U,z**4+p*z**3+v*z**2+p*z+1))
g=s.expand(U.subs(z,-1))
K=q**4+3*q**3+4*q**2+4*q+3
L=q**5+3*q**4+3*q**3+5*q**2+4*q+4
M=q**6+q**5+3*q**4+3*q**3+3*q**2+2*q+3
N=(q+1)**2*(q*q+1)
check('residual value g',eq(g,(q-1)**2*K))
discU=s.discriminant(U,z)
check('ordinary residual discriminant',eq(discU,(q-1)**6*(q+1)**2*K*L**2*M))
reverse_rows=[]
for name,P,expected in [('K',K,375),('L',L,-32000),('M',M,4096)]:
    R=reverse(P); value=s.resultant(P,R,q)
    check(name+' reciprocal resultant',value==expected)
    a,b,h=s.gcdex(P,R,q)
    check(name+' independent Bezout identity',eq(a*P+b*R,1))
    reverse_rows.append({'name':name,'resultant':str(value),'a':str(a),'b':str(b)})
V=s.expand(q**6*U.subs(q,1/q))
unitR=s.resultant(U,V,z)
expected=(q-1)**8*(q+1)**4*(q*q+1)**4*(q*q+q+1)**2*(q**4+q**3+q*q+q+1)**6
check('unit-circle reciprocal-conjugate resultant',eq(unitR,expected))

B=81*q**10+350*q**9+853*q**8+1547*q**7+2160*q**6+2393*q**5+2160*q**4+1547*q**3+853*q*q+350*q+81
check('nonreality obstruction factorization',eq(K**4-q*reverse(K)**4,-(q-1)*(q*q+q+1)*(q**4+q**3+q*q+q+1)*B))
reality_rows=[]
for d in [7,9,11,15]:
    R=s.rem(B,s.cyclotomic_poly(d,q),q)
    check('Phi_'+str(d)+' does not divide B',R!=0)
    reality_rows.append({'d':d,'remainder':str(R)})
# Exhaustiveness follows from prime factors 3,5,7,11, not this finite list check.
orders=[]
for a in range(4):
 for b in range(3):
  for c in range(2):
   for e in range(2):
    d=3**a*5**b*7**c*11**e
    if s.totient(d)<=10:orders.append(d)
check('finite exponent classification phi(d)<=10',sorted(orders)==[1,3,5,7,9,11,15])

def field(d):
    phi=s.Poly(s.cyclotomic_poly(d,q),q,domain=s.QQ); n=phi.degree()
    def red(a):return s.Poly(a,q,domain=s.QQ).rem(phi).as_expr()
    def mul(a,b):return red(a*b)
    def prod(exponents):
        a=s.Integer(1)
        for e in exponents:a=mul(a,1-q**(e%d))
        return a
    def conj(a):
        return red(sum(c*q**((-j)%d) for (j,),c in s.Poly(a,q).terms()))
    def characteristic(a,var):
        columns=[]
        for j in range(n):
            ap=s.Poly(red(a*q**j),q)
            columns.append([ap.nth(k) for k in range(n)])
        mat=s.Matrix(n,n,lambda i,j:columns[j][i])
        return mat.charpoly(var).as_expr()
    return phi,n,red,mul,prod,conj,characteristic

source_zip=ROOT/'sources'/'RS_Overlap_Simplicity_b5_Candidate_2026-10-11.zip'
check('audited candidate immutable ZIP hash',hashlib.sha256(source_zip.read_bytes()).hexdigest()=='fd996db3f32011ce31880f58d24de0bc21978b616b751dc0aa3add9e566619ad')
with zipfile.ZipFile(source_zip) as archive:
    candidate=json.loads(archive.read('EXACT_CONTROLS.json'))
candidate_norms={row['d']:row for row in candidate['norm_certificates']}
signs={7:{0:-1,1:49},9:{0:-19,1:27},17:{0:12030226801,1:-5595907},19:{0:-127155174287,1:1131577243},21:{s.Rational(7,2):-s.Rational(215889197,64)},23:{8:-5417213723995013},25:{4:-407090701},27:{4:-15682804227},13:{1:2197,s.Rational(5,4):-s.Rational(153529,4096),s.Rational(5,2):-s.Rational(121211,64),s.Rational(8,3):s.Rational(35960963,729)},15:{s.Rational(17,8):-s.Rational(2349,256)}}
for d in range(7,28,2):
    phi,n,red,mul,prod,conj,norm=field(d); h=(d-1)//2
    O=prod(range(1,d,2)); E=prod(range(2,d,2))
    check(f'd={d} complementary product E O=d',mul(E,O)==d)
    check(f'd={d} complex conjugate E equals O',eq(conj(E),O))
    check(f'd={d} phase identity',eq(mul(E,E),red((-1)**h*d*q**(h*(h+1)))))
    tau=mul(mul(O,N),s.invert(K,phi.as_expr(),q))
    denom=prod(range(2,d+6,2)); num=prod(range(1,6))
    original_tau=mul(d*num,s.invert(mul(denom,g),phi.as_expr(),q))
    check(f'd={d} direct original W/g normalization',eq(tau,original_tau))
    check(f'd={d} tau nonreal in field',red(tau-conj(tau))!=0)
    rho=mul(tau-1,conj(tau)-1)
    check(f'd={d} rho fixed by conjugation',eq(rho,conj(rho)))
    norm_rho=norm(rho,r)
    P=pp(s.prod(factor for factor,multiplicity in s.factor_list(norm_rho,r)[1]),r)
    expected_multiplicity=10 if d==11 else 2
    check(f'd={d} multiplication-matrix norm identity',eq(norm_rho,(P.as_expr()/P.LC())**expected_multiplicity))
    claimed=s.Poly.from_list([s.Integer(a) for a in candidate_norms[d]['coefficients_descending']],r)
    check(f'd={d} source coefficients match independently computed norm',eq(P.as_expr(),claimed.as_expr()),str(P.as_expr()))
    values={}
    for point,value in signs.get(d,{}).items():
        actual=P.eval(point);check(f'd={d} norm sign at {point}',actual==value); values[str(point)]=str(actual)
    if d==11:check('d=11 rho exactly one',rho==1)
    norm_rows.append({'d':d,'odd_product':str(O),'tau':str(tau),'rho':str(rho),'P':str(P.as_expr()),'coefficients_descending':[str(c) for c in P.all_coeffs()],'multiplicity':expected_multiplicity,'norm_method':'characteristic polynomial of multiplication by rho','values':values})
    if d==15:
        norm_tau=norm(tau,T); Ct=pp(norm_tau,T)
        Cexpected=10096*T**8-82080*T**7+304680*T**6-641250*T**5+791775*T**4-475875*T**3-23625*T*T+151875*T+50625
        check('d=15 tau characteristic polynomial equals claimed norm',eq(norm_tau,Cexpected/10096))

He=[s.Integer(1),x]
for n in range(1,24):He.append(s.expand(x*He[n]-n*He[n-1]))
for A in range(1,24):
    J=s.expand(x*He[A]-A*T*He[A-1]); m=(A+1)//2; parity=(A+1)%2; alpha=s.Rational(2*parity-1,2)
    check(f'A={A} Hermite normalizations equivalent',eq(J,He[A+1]+A*(1-T)*He[A-1]))
    check(f'A={A} derivative elimination identity',eq(s.diff(J,x),(1+A*T)*He[A]+A*x*(1-T)*He[A-1]))
    # y=x^2 unscaled Jacobi continuant, independent of candidate's half scaling.
    f0=s.Integer(1); f1=y-(2*alpha+2)
    if m==1:f1-=A*(T-1)
    for j in range(1,m):
        diag=4*j+2*alpha+2+(A*(T-1) if j==m-1 else 0)
        f0,f1=f1,s.expand((y-diag)*f1-4*j*(j+alpha)*f0)
    check(f'A={A} unscaled Jacobi characteristic identity',eq(J,x**parity*f1.subs(y,x*x)))
    if A<=15:
        # Composition formulas compute the ordinary x-discriminant from degree-m data.
        Q=s.Poly(f1,y); D=s.expand((-1)**m*4**m*Q.eval(0)**(1+2*parity)*s.discriminant(Q.as_expr(),y)**2)
        source=s.sympify(candidate['d15_gcd_certificates'][A-1]['disc'],locals={'T':T})
        check(f'A={A} parity discriminant matches source exact polynomial',eq(D,source))
        if A<=8:check(f'A={A} direct ordinary discriminant cross-check',eq(D,s.discriminant(J,x)))
        G=s.gcd(s.Poly(D,T,domain=s.QQ),s.Poly(Cexpected,T,domain=s.QQ))
        check(f'A={A} exact rational coprimality',G.degree()==0)
        Dmod=s.Poly(D,T,modulus=101); Cmod=s.Poly(Cexpected,T,modulus=101)
        check(f'A={A} reduction preserves both degrees',Dmod.degree()==s.degree(D,T) and Cmod.degree()==8)
        gm=s.gcd(Dmod,Cmod)
        check(f'A={A} modulo 101 coprimality',gm.degree()==0)
        finite_rows.append({'A':A,'ordinary_discriminant':str(D),'method':'parity composition formula','gcd_Q':str(G.as_expr()),'disc_mod101':str(Dmod.as_expr()),'gcd_mod101':str(gm.as_expr())})

check('d>=29 angle upper bound',s.Rational(22,203)<s.Rational(1,9))
check('cosine product lower bound',s.Rational(80,81)*s.Rational(79,81)>s.Rational(15,16))
check('large-order final strict inequality',s.Integer(29)<s.Rational(67,12)**2)
check('d13 A=3 inner exclusion',s.Rational(5,4)<s.Rational(4,3))
check('d13 A>=4 outer cutoff',2+s.Rational(2,4)==s.Rational(5,2))
check('d15 A>=16 outer cutoff',2+s.Rational(2,16)==s.Rational(17,8))
result={'status':'PASS','check_count':len(checks),'checks':checks,'residual_reverse_certificates':reverse_rows,'reality_remainders':reality_rows,'small_order_norms':norm_rows,'d15_tau_norm':str(Cexpected),'d15_discriminant_certificates':finite_rows,'environment':{'python':sys.version,'sympy':s.__version__,'platform':platform.platform()},'independence':'Fresh controls only; candidate JSON is inert comparison data. Complementary odd product, multiplication-matrix norms, and parity composition discriminants were recomputed independently. No source program executed.'}
(ROOT/'INDEPENDENT_EXACT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print('ALL',len(checks),'EXACT CHECKS PASS',flush=True)
