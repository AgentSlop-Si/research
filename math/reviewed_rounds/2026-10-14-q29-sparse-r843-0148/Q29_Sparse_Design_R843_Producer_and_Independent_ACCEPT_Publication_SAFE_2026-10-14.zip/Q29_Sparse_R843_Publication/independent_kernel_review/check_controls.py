#!/usr/bin/env python3
"""Fresh independent finite controls; no producer modules imported."""
from pathlib import Path
from math import comb
import hashlib,json,resource,signal,time
H=Path(__file__).resolve().parent; A=H.parent/'sparse_r843_producer'
t0=time.monotonic();c0=time.process_time()
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(110,110))
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('audit cap')));signal.alarm(170)
PHI={0:1,225:-1,675:1,900:-1,1125:1,1575:-1}
def monic_rem(poly,t=1):
 top=max(poly,default=0)*t
 v=[0]*(max(1800,top+1))
 for exponent,c in poly.items():v[exponent*t]=c%25
 for i in range(top,1799,-1):
  c=v[i]%25
  if c:
   for e,s in PHI.items():v[i-1800+e]-=c*s
 return bytes(x%25 for x in v[:1800])
def add(a,b,sign=1):
 out=dict(a)
 for e,c in b.items():out[e]=out.get(e,0)+sign*c
 return {e:c for e,c in out.items() if c}
def gaussian_subset_row(n):
 # Coefficient of t^k in product_{j=0}^{n-1}(1+t q^j), then remove
 # q^{k(k-1)/2}. This differs from the producer's q-Pascal recurrence.
 rows=[{} for _ in range(n+1)];rows[0]={0:1}
 for j in range(n):
  for k in range(j+1,0,-1):
   rows[k]=add(rows[k],{e+j:c for e,c in rows[k-1].items()})
 return [{e-k*(k-1)//2:c for e,c in row.items()} for k,row in enumerate(rows)]
results=[]
for m in range(9):
 row=gaussian_subset_row(2*m+1)
 quotient=[]
 for k in range(2*m+1):quotient.append(add(row[k],quotient[k-1] if k else {},-1))
 assert quotient[-1]==row[-1]
 for t in [1,1001]:
  raw=(A/f'control_m{m}_w{m+1}_q{t}.bin').read_bytes()
  R=[raw[k*1800:(k+1)*1800] for k in range(m+1)]
  U=[[0]*1800 for _ in range(2*m+1)]
  for k,coeffs in enumerate(R):
   for j in range(2*k+1):
    f=comb(2*k,j);x=m-k+j
    for i,c in enumerate(coeffs):U[x][i]+=f*c
  expected=[monic_rem(p,t) for p in quotient]
  assert [bytes(c%25 for c in u) for u in U]==expected,(m,t)
  trunc=[]
  for width in sorted({1,min(2,m+1),min(4,m+1)}):
   b=(A/f'control_m{m}_w{m+1}_q{t}_trunc{width}.bin').read_bytes()
   assert b==raw[:width*1800];trunc.append(width)
  results.append(dict(m=m,q_exponent=t,gaussian_subset_product_match=True,truncations=trunc))
# Exact integer Phi15 monomial images; check period and reciprocal coefficient bounds.
phi15=[1,-1,0,1,-1,1,0,-1,1]
rows=[]
for e in range(30):
 v=[0]*30;v[e]=1
 for i in range(29,7,-1):
  c=v[i]
  for j in range(9):v[i-8+j]-=c*phi15[j]
 rows.append(v[:8])
assert all(rows[i]==rows[i+15] for i in range(15))
assert all(c in [-1,0,1] for row in rows for c in row)
max_image_l1=max(sum(abs(x) for x in row) for row in rows)
max_output_l1=0
for shift in range(15):
 for d in range(8):max_output_l1=max(max_output_l1,sum(abs(rows[(b+shift)%15][d]) for b in range(8)))
assert max_output_l1<=6
assert monic_rem({3375:1,0:-1})==bytes(1800)
# Reproduce the exact signed update counts from the eight-dimensional maps,
# including the different carry slices of every exponent used.
def signed_per_shift(t):
 q,r=divmod(t%3375,225)
 return sum((225-r)*sum(abs(c) for c in rows[(b+q)%15])+r*sum(abs(c) for c in rows[(b+q+1)%15]) for b in range(8))
signed=sum(min(m-1,100)*signed_per_shift(2*m-2)+min(m,100)*(signed_per_shift(1)+signed_per_shift(2*m-1)) for m in range(1,844))
dense=sum(1800*4*min(m,100) for m in range(1,844))
modular=sum(1800*(min(m-1,100)+min(m,100)+min(m+1,100)) for m in range(1,844))
assert [signed,dense,modular]==[849703500,571320000,428488200]
manifest=json.loads((A/'MANIFEST.json').read_text()); seal=json.loads((A/'SEAL.json').read_text())
for path,entry in manifest.items():
 data=(A/path).read_bytes()
 assert hashlib.sha256(data).hexdigest()==entry['sha256'] and len(data)==entry['bytes'],path
assert hashlib.sha256((A/'MANIFEST.json').read_bytes()).hexdigest()==seal['manifest_sha256']
source_pins={p:hashlib.sha256((A/p).read_bytes()).hexdigest() for p in ['MANIFEST.json','SEAL.json','REPORT.md','sparse_q29.cpp','cyclic_expanded_control.cpp','verify_and_benchmark.py','verify_full_independent.py','R843_w100_mod25_zbasis.bin','cyclic_R843_w100.bin','EXECUTION_RECEIPT.json','CONTROLS.json','FULL_RESULT.json','FULL_RUN_GATE.json','INDEPENDENT_FULL_CONTROL.json']}
result=dict(status='PASS_INDEPENDENT_GAUSSIAN_AND_SEAL_AUDIT',controls=results,phi15_max_image_l1=max_image_l1,phi15_max_output_l1=max_output_l1,period_relation=True,operation_counts=dict(signed_scatter_updates=signed,dense_arithmetic_updates=dense,modular_reductions=modular),manifest_file_count=len(manifest),producer_seal=seal,source_pins=source_pins,wall_seconds=time.monotonic()-t0,cpu_seconds=time.process_time()-c0,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,historical_programs_executed=False,networking=False,external_writes=False)
(H/'CONTROL_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['controls','source_pins']},indent=2))
