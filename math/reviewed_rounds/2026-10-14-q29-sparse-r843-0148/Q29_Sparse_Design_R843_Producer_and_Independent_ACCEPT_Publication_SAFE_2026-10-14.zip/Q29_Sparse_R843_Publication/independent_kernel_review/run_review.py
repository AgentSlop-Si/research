#!/usr/bin/env python3
"""Fresh reviewer harness: cumulative wall/CPU and address-space limits."""
import hashlib,json,os,resource,signal,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
AUTHOR=HERE.parent/'sparse_r843_producer'
START=time.monotonic()
CPU0=resource.getrusage(resource.RUSAGE_SELF)
MAXCPU=120;MAXWALL=180;MAXMEM=512*1024**2
resource.setrlimit(resource.RLIMIT_AS,(MAXMEM,MAXMEM))
resource.setrlimit(resource.RLIMIT_CPU,(MAXCPU,MAXCPU))
def alarm(*args):raise TimeoutError('Total review execution wall cap exceeded')
signal.signal(signal.SIGALRM,alarm);signal.alarm(MAXWALL)
records=[]
def cpu():
 s=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN)
 return s.ru_utime+s.ru_stime-CPU0.ru_utime-CPU0.ru_stime+c.ru_utime+c.ru_stime

def run(args,label):
 left=MAXCPU-cpu(); wall=MAXWALL-(time.monotonic()-START)
 assert left>1 and wall>1
 def limits():
  resource.setrlimit(resource.RLIMIT_AS,(MAXMEM,MAXMEM))
  resource.setrlimit(resource.RLIMIT_CPU,(int(left),int(left)))
  resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
 t=time.monotonic();c=cpu()
 p=subprocess.run(args,cwd=HERE,text=True,capture_output=True,timeout=wall,preexec_fn=limits)
 (HERE/(label+'.stdout')).write_text(p.stdout);(HERE/(label+'.stderr')).write_text(p.stderr)
 records.append(dict(command=args,label=label,returncode=p.returncode,wall_seconds=time.monotonic()-t,cpu_seconds=cpu()-c))
 assert p.returncode==0,(args,p.stderr)
 return p.stdout
status='FAIL';checks={}
try:
 run(['g++','-O3','-std=c++17','-Wall','-Wextra','-Werror','direct_monic_checker.cpp','-o','direct_monic_checker'],'compile_direct')
 for m in [0,1,2,3,4,5,6,7,8]:
  width=m+1
  run(['./direct_monic_checker',str(m),str(width),f'small_m{m}.bin'],f'small_m{m}')
  a=(HERE/f'small_m{m}.bin').read_bytes();b=(AUTHOR/f'control_m{m}_w{width}_q1.bin').read_bytes()
  assert a==b
 checks['fresh_direct_monic_small_matches'] = list(range(9))
 full=json.loads(run(['./direct_monic_checker','843','100','review_R843_w100.bin'],'direct_full'))
 a=(HERE/'review_R843_w100.bin').read_bytes();b=(AUTHOR/'R843_w100_mod25_zbasis.bin').read_bytes();c=(AUTHOR/'cyclic_R843_w100.bin').read_bytes()
 assert len(a)==180000 and min(a)==0 and max(a)==24 and a==b==c
 checks['full_direct_monic_180000_residues_match_both_author_implementations']=True
 checks['full_output_sha256']=hashlib.sha256(a).hexdigest();checks['full_nonzero_coordinates']=sum(x!=0 for x in a);checks['fresh_direct_timing']=full
 # Compile fresh author code into reviewer-owned executable, rerun full case once.
 run(['g++','-O3','-std=c++17','-Wall','-Wextra','-Werror',str(AUTHOR/'sparse_q29.cpp'),'-o','author_fresh_rebuild'],'compile_author')
 rebuilt=json.loads(run(['./author_fresh_rebuild','843','100','1','rebuilt_R843_w100.bin'],'author_full_rerun'))
 assert (HERE/'rebuilt_R843_w100.bin').read_bytes()==a
 checks['author_full_rebuild_match']=True;checks['author_full_rerun_timing']=rebuilt
 status='PASS_INDEPENDENT_FULL_DIRECT_MONIC_REPRODUCTION'
finally:
 receipt=dict(status=status,checks=checks,commands=records,total_wall_seconds=time.monotonic()-START,total_charged_cpu_seconds=cpu(),maximum_child_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,limits=dict(wall_seconds=MAXWALL,cpu_seconds=MAXCPU,address_space_bytes=MAXMEM),historical_programs_executed=False,external_writes=False,networking=False)
 (HERE/'REPRODUCTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
