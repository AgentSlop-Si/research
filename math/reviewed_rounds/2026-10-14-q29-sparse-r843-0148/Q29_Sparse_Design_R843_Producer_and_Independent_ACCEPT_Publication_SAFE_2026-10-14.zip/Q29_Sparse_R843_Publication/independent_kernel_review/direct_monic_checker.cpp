// Independently authored checker, 2026-10-14.
// Uses no packed Phi15 map, no cyclic ring, and no author source imports.
// Main full case performs direct polynomial arithmetic and descending division.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
constexpr int D=1800;
int canon(int a) { a%=25; return a<0?a+25:a; }
int main(int argc,char **argv) {
 try {
  if(argc!=4) throw std::runtime_error("usage: checker m w output");
  const int M=std::stoi(argv[1]), W=std::stoi(argv[2]);
  if(M<0||M>843||W<1||W>100) throw std::runtime_error("bound violation");
  std::vector<int> current(W*D), previous(W*D), next(W*D);
  std::vector<int> scratch(D+std::max(2,4*M-3));
  current[0]=1;
  const int offsets[]={0,225,675,900,1125,1575};
  const int coefficients[]={1,-1,1,-1,1,-1};
  auto start=std::chrono::steady_clock::now();
  for(int m=1;m<=M;++m) {
   int aw=std::min(m,W), bw=std::min(m-1,W), cw=std::min(m+1,W);
   int top=D+std::max(2*m,4*m-3)-1;
   for(int k=0;k<cw;++k) {
    std::fill(scratch.begin(),scratch.begin()+top+1,0);
    for(int j=0;j<D;++j) {
     const int p=k<aw?current[k*D+j]:0;
     const int q=k<bw?previous[k*D+j]:0;
     scratch[j]+=(k?current[(k-1)*D+j]:0)-2*p-q;
     scratch[j+2*m]+=p;
     scratch[j+2*m-1]+=p+q;
     scratch[j+2*m-2]+=q;
     scratch[j+4*m-3]-=q;
    }
    for(int degree=top;degree>=D;--degree) {
     int leading=canon(scratch[degree]);
     if(leading) for(int i=0;i<6;++i) scratch[degree-D+offsets[i]]-=leading*coefficients[i];
    }
    for(int j=0;j<D;++j) next[k*D+j]=canon(scratch[j]);
   }
   previous.swap(current);current.swap(next);
  }
  auto end=std::chrono::steady_clock::now();
  std::ofstream output(argv[3],std::ios::binary);
  for(int x:current) output.put(static_cast<char>(x));
  output.close(); if(!output) throw std::runtime_error("output failed");
  std::cout << "{\"m\":" << M << ",\"w_limit\":" << W << ",\"kernel_wall_seconds\":" << std::chrono::duration<double>(end-start).count() << ",\"output_bytes\":" << current.size() << "}\n";
 } catch(const std::exception &e) {std::cerr<<e.what()<<'\n';return 1;}
}
