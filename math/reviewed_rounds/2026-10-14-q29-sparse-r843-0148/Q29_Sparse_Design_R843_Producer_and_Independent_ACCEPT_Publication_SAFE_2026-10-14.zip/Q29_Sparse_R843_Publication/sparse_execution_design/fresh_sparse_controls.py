#!/usr/bin/env python3
"""Fresh bounded controls only. Does not import or execute predecessor programs."""
from pathlib import Path
from math import comb
import hashlib, json, random, time

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
START=time.monotonic()
MOD=25
D=1800
ORDER=3375
PHI15={0:1,1:-1,3:1,4:-1,5:1,7:-1,8:1}
PHI={225*i:c for i,c in PHI15.items()}

def clean(a):
    return {i:c%MOD for i,c in a.items() if c%MOD}

def add(*args):
    out={}
    for a in args:
        for i,c in a.items(): out[i]=out.get(i,0)+c
    return clean(out)

def scale(a,c): return clean({i:v*c for i,v in a.items()})

# Exact integer remainders of the fifteen powers y^0,...,y^14.
ROWS=[]
for n in range(15):
    p={n:1}
    for j in range(n,7,-1):
        c=p.pop(j,0)
        for k,v in PHI15.items():
            if k<8:p[j-8+k]=p.get(j-8+k,0)-c*v
    ROWS.append({k:c for k,c in p.items() if c})

def shift(a,t):
    """Sparse reference, not the proposed packed block-slice production kernel."""
    out={}
    for e,c in a.items():
        b,r=divmod((e+t)%ORDER,225)
        for k,sgn in ROWS[b].items():
            at=225*k+r
            out[at]=out.get(at,0)+sgn*c
    return clean(out)

ONE={0:1}

def long_rem(a):
    """Independent descending monic reduction, never uses ROWS or exponent wrap."""
    p=clean(a)
    for j in range(max(p,default=0),D-1,-1):
        c=p.pop(j,0)
        if c:
            for k,v in PHI.items():
                if k<D:p[j-D+k]=(p.get(j-D+k,0)-c*v)%MOD
    return clean(p)

def general_product(a,b):
    p={}
    for i,c in a.items():
        for j,d in b.items():p[i+j]=p.get(i+j,0)+c*d
    return long_rem(p)

# Exact integer basis maps between z and alpha^a beta^b, a<18,b<100.
def z_to_ab(a,mod=None):
    out={}
    for e,c in a.items():
        aa,bb=e%27,e%125
        ar={aa:1} if aa<18 else {aa-18:-1,aa-9:-1}
        br={bb:1} if bb<100 else {bb-100:-1,bb-75:-1,bb-50:-1,bb-25:-1}
        for i,ci in ar.items():
            for j,cj in br.items():out[i,j]=out.get((i,j),0)+c*ci*cj
    return {ij:c if mod is None else c%mod for ij,c in out.items() if (c if mod is None else c%mod)}

def ab_to_z(a,mod=None):
    out={}
    for (i,j),c in a.items():
        b,r=divmod((1000*i+2376*j)%ORDER,225)
        for k,s in ROWS[b].items():out[225*k+r]=out.get(225*k+r,0)+c*s
    return {e:c if mod is None else c%mod for e,c in out.items() if (c if mod is None else c%mod)}

def z_to_api(a):
    ab=z_to_ab(a,MOD)
    out={}
    for (i,b),c in ab.items():
        for j in range(b+1):out[i,j]=out.get((i,j),0)+c*comb(b,j)
    return {ij:c%MOD for ij,c in out.items() if c%MOD}

def api_to_z(a):
    ab={}
    for (i,j),c in a.items():
        for b in range(j+1):ab[i,b]=ab.get((i,b),0)+c*comb(j,b)*(-1)**(j-b)
    return ab_to_z(ab,MOD)

def val_api(a):
    def v5(c):
        s=0
        while c%5==0:c//=5;s+=1
        return s
    return min((j+100*v5(c) for (i,j),c in a.items()),default=200)

assert [(1000%27),(1000%125),(2376%27),(2376%125),(3376%3375)]==[1,0,0,1,1]
assert long_rem({3375:1,0:-1})=={}
for e in range(3375):assert shift(ONE,e)==long_rem({e:1})
# Entire exact integer basis identities: stronger than random mod-25 round trips.
for e in range(D):assert ab_to_z(z_to_ab({e:1}))=={e:1}
for i in range(18):
    for j in range(100):assert z_to_ab(ab_to_z({(i,j):1}))=={(i,j):1}

rng=random.Random(291433)
shifts=[0,1,224,225,226,899,1000,1575,1799,1800,2376,3150,3374,3375,6749]
for _ in range(10):
    a={i:rng.randrange(25) for i in range(D)}
    a=clean(a)
    assert api_to_z(z_to_api(a))==a
    t=shifts[_]
    assert shift(a,t)==long_rem({e+t:c for e,c in a.items()})
for t in shifts:
    a=clean({rng.randrange(D):rng.randrange(25) for _ in range(70)})
    assert shift(a,t)==long_rem({e+t:c for e,c in a.items()})
for _ in range(16):
    a=clean({rng.randrange(D):rng.randrange(25) for _ in range(12)})
    b=clean({rng.randrange(D):rng.randrange(25) for _ in range(12)})
    predicted={}
    for e,c in b.items():predicted=add(predicted,scale(shift(a,e),c))
    assert predicted==general_product(a,b)
    s,t=rng.randrange(ORDER),rng.randrange(ORDER)
    assert shift(shift(a,s),t)==shift(a,s+t)

alpha=shift(ONE,1000);beta=shift(ONE,2376)
assert add(ONE,shift(ONE,9000),shift(ONE,18000))=={}
assert add(*(shift(ONE,2376*25*r) for r in range(5)))=={}
assert shift(alpha,2376)==shift(ONE,1)
assert shift(ONE,3375)==ONE and shift(ONE,1125)!=ONE and shift(ONE,675)!=ONE
assert shift(ONE,1000*27)==ONE and shift(ONE,1000*9)!=ONE
assert shift(ONE,2376*125)==ONE and shift(ONE,2376*25)!=ONE
# Only monomial shifts and subtraction, in the new ring, for pi powers.
pipowers=[ONE]
for _ in range(200):pipowers.append(add(shift(pipowers[-1],2376),scale(pipowers[-1],-1)))
assert pipowers[200]=={} and val_api(z_to_api(pipowers[199]))==199
assert val_api(z_to_api(scale(ONE,5)))==100
carry=add(scale(ONE,5),pipowers[100])
frob=add(shift(ONE,5*2376),scale(ONE,-1),scale(pipowers[5],-1))
assert val_api(z_to_api(carry))==125
assert val_api(z_to_api(frob))==101

# Polynomials with ascending variable degree and canonical coefficient dictionaries.
def trim(P):
    while len(P)>1 and not P[-1]:P.pop()
    return P

def pa(*args,K=None):
    n=max(map(len,args));n=n if K is None else min(n,K)
    return trim([add(*(P[k] for P in args if k<len(P))) for k in range(n)])

def ps(P,c):return [scale(a,c) for a in P]
def pq(P,t):return [shift(a,t) for a in P]
def pv(P,k=1):return [{} for _ in range(k)]+P

def substitute_minus_one_v(P,K):
    out=[{} for _ in range(min(K,len(P)))]
    for n,c in enumerate(P):
        for k in range(min(n+1,K)):
            out[k]=add(out[k],scale(c,(-1)**n*comb(n,k)))
    return trim(out)

def gaussian_H(n,t):
    coeff=[ONE]
    for nn in range(1,n+1):
        coeff=[add(coeff[k] if k<nn else {},shift(coeff[k-1],t*(nn-k)) if k else {}) for k in range(nn+1)]
    return coeff

def monic_odd_quotient(H):
    U=[]
    for k in range(len(H)-1):U.append(add(H[k],scale(U[-1],-1) if U else {}))
    assert U[-1]==H[-1]
    assert pa(U,pv(U))==H
    return U

def paired(m,t,K):
    E=O=[ONE]
    for j in range(1,m+1):
        DE=pa(E,ps(pq(E,t*(2*j-1)),-1),K=K)
        DO=pa(O,ps(pq(O,t*(2*j)),-1),K=K)
        En=pa(pv(O,2),DE,pv(DE),K=K)
        On=pa(En,DO,pv(DO),K=K)
        E,O=En,On
    return E,O

def R_fused(m,t,L):
    Q,P=[{}],[ONE]
    for j in range(1,m+1):
        DD=pa(Q,ps(pq(Q,t*(2*j-2)),-1),K=L)
        TT=pa(P,pq(P,t),DD,K=L)
        N=pa(pv(P),ps(P,-2),ps(DD,-1),pq(TT,t*(2*j-1)),K=L)
        # Independent expanded original recurrence, with its five q-power terms.
        expanded=pa(pv(P),ps(P,-2),pq(P,t*2*j),pq(P,t*(2*j-1)),ps(Q,-1),
                    pq(Q,t*(2*j-1)),pq(Q,t*(2*j-2)),ps(pq(Q,t*(4*j-3)),-1),K=L)
        assert N==expanded
        Q,P=P,N
    return P

def R_to_U(R,m,K):
    U=[{} for _ in range(min(K,2*m+1))]
    for k,r in enumerate(R):
        for j in range(min(m-k+1,K-2*k)):
            U[2*k+j]=add(U[2*k+j],scale(r,(-1)**(m+k)*comb(m-k,j)))
    return trim(U)

cases=[]
for t in [1,1001]:
    for m in range(1,9):
        H=gaussian_H(2*m+1,t)
        Ux=monic_odd_quotient(H)
        fullU=substitute_minus_one_v(Ux,2*m+1)
        Hv=substitute_minus_one_v(H,2*m+2)
        assert not Hv[0] and ps(Hv[1:],-1)==fullU
        E,O=paired(m,t,2*m+1)
        assert O==fullU and E==substitute_minus_one_v(gaussian_H(2*m,t),2*m+1)
        assert R_to_U(R_fused(m,t,m+1),m,2*m+1)==fullU
        for K in [1,2,3,4,7,12]:
            target=trim(fullU[:K])
            assert paired(m,t,K)[1]==target
            assert R_to_U(R_fused(m,t,(K+1)//2),m,K)==target
        cases.append({'q_exponent':t,'m':m,'H_degree':2*m+1,'full_and_truncated_agreement':True})

# Budget enumeration, no R843 or H1687 coefficient computation.
def C(t):
    b,s=divmod(t%3375,225)
    return sum((225-s)*len(ROWS[(a+b)%15])+s*len(ROWS[(a+b+1)%15]) for a in range(8))
assert C(1)==1805 and max(C(t) for t in range(3375))==6525
row_l1=max(sum(abs(ROWS[(a+b)%15].get(k,0)) for a in range(8)) for b in range(15) for k in range(8))
assert row_l1==6
A=sum(min(m,100) for m in range(1,844))
B=sum(min(m-1,100) for m in range(1,844))
O=sum(min(m+1,100) for m in range(1,844))
ca=sum(min(m,100)*C(2*m-1) for m in range(1,844))
cb=sum(min(m-1,100)*C(2*m-2) for m in range(1,844))
budget={'A_coefficients':A,'B_coefficients':B,'output_coefficients':O,
 'shift_by_one_signed_scatter_updates':A*C(1),
 'odd_variable_shift_signed_scatter_updates':ca,
 'even_variable_shift_signed_scatter_updates':cb,
 'all_shift_signed_scatter_updates':ca+cb+A*C(1),
 'additional_dense_add_sub_upper_bound':1800*(B+2*A+3*O),
 'additional_scalar_doublings_upper_bound':1800*A,
 'combined_arithmetic_update_upper_bound':ca+cb+A*C(1)+1800*(B+2*A+3*O)+1800*A,
 'stagewise_modular_reductions_upper_bound':1800*(3*A+2*B+O),
 'max_shift_output_row_l1':row_l1,
 'z_to_alpha_beta_signed_scatter_updates_per_coefficient':sum((1 if e%27<18 else 2)*(1 if e%125<100 else 4) for e in range(1800)),
 'alpha_beta_to_alpha_pi_MAC_per_coefficient_upper_bound':18*100*101//2,
 'R_to_raw_U_coordinate_MAC_upper_bound':10100*1800,
 'no_wall_time_prediction':True}
source_paths=['q29_precision_contract/PRECISION_CONTRACT.md',
 'q29_precision_review/REVIEW.md',
 'q29_precision_contract/fresh_exact_controls.py']
result={'status':'PASS: bounded sparse implementation design; no full experiment',
 'exact_integer_forward_and_inverse_basis_unit_vectors_tested':3600,
 'canonical_monomial_reductions_tested':3375,
 'dense_pi_basis_round_trips':10,
 'independent_monic_shift_comparisons':25,
 'generic_product_comparisons':16,
 'carry_valuations':[100,125,101],
 'pi_nilpotence_index_mod25':200,
 'small_recurrence_cases':cases,'truncated_K_tested':[1,2,3,4,7,12],
 'phi15_power_reduction_rows':ROWS,'budget':budget,
 'historical_code_executed':False,'H1687_executed':False,'R843_executed':False,
 'external_writes':False,'elapsed_seconds':round(time.monotonic()-START,6),
 'input_sources':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in source_paths]}
(BASE/'CONTROL_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
