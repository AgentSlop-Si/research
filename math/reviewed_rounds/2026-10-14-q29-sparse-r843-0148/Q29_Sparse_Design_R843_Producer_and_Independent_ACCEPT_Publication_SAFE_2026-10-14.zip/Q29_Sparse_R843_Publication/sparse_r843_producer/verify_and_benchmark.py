#!/usr/bin/env python3
"""Fresh independent controls and bounded benchmark driver; standard library only."""
from pathlib import Path
from math import comb, ceil
import hashlib, json, os, platform, random, resource, subprocess, sys, time
HERE=Path(__file__).resolve().parent
START=time.monotonic(); CPU0=time.process_time(); MAXWALL=180; MAXCPU=120; MAXMEM=512*1024*1024
records=[]
def cpu_used():
    c=resource.getrusage(resource.RUSAGE_CHILDREN)
    return time.process_time()-CPU0+c.ru_utime+c.ru_stime

def run(args,label):
    remaining_wall=MAXWALL-(time.monotonic()-START)
    remaining_cpu=MAXCPU-cpu_used()
    if remaining_wall<2 or remaining_cpu<2: raise RuntimeError('Global execution budget exhausted')
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(MAXMEM,MAXMEM))
        resource.setrlimit(resource.RLIMIT_CPU,(max(1,int(remaining_cpu)),max(1,int(remaining_cpu))))
        resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024*1024,16*1024*1024))
    before=time.monotonic(); c0=cpu_used()
    p=subprocess.run(args,cwd=HERE,text=True,capture_output=True,timeout=remaining_wall,preexec_fn=limits)
    (HERE/(label+'.stdout')).write_text(p.stdout);(HERE/(label+'.stderr')).write_text(p.stderr)
    rec={'label':label,'command':args,'returncode':p.returncode,'process_wall_seconds':time.monotonic()-before,'process_cpu_seconds':cpu_used()-c0}
    records.append(rec)
    if p.returncode: raise RuntimeError(f'{label} failed: {p.stderr}')
    return p.stdout

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(obj,name): (HERE/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

# Independent polynomial quotient: coefficient lists, descending monic division.
# Does not use the production block rows, sparse-shift implementation or period wrap.
PHI={0:1,225:-1,675:1,900:-1,1125:1,1575:-1,1800:1}
def remainder(p):
    p={e:v%25 for e,v in p.items() if v%25}
    for degree in range(max(p,default=0),1799,-1):
        leading=p.pop(degree,0)
        if leading:
            for exponent,c in PHI.items():
                if exponent<1800:
                    at=degree-1800+exponent;p[at]=(p.get(at,0)-leading*c)%25
    return {e:v for e,v in p.items() if v}

def add_q(a,b,shift=0,sign=1):
    p=dict(a)
    for e,v in b.items(): p[e+shift]=p.get(e+shift,0)+sign*v
    return {e:v for e,v in p.items() if v}

def gaussian_quotient(m,t):
    # Unreduced integer q-polynomials form Gaussian binomial coefficients.
    row=[{0:1}]
    for n in range(1,2*m+2):
        row=[add_q(row[k] if k<len(row) else {}, row[k-1] if k else {},n-k) for k in range(n+1)]
    quotient=[]
    for k in range(2*m+1):quotient.append(add_q(row[k],quotient[-1] if k else {},sign=-1))
    assert quotient[-1]==row[-1]
    return [remainder({e*t:v for e,v in p.items()}) for p in quotient]

def read_bin(path,L):
    b=Path(path).read_bytes();assert len(b)==1800*L and max(b)<25
    return [{j:v for j,v in enumerate(b[1800*k:1800*(k+1)]) if v} for k in range(L)]

def expand_reciprocal(R,m):
    # U(x)=x^m R(x+x^-1+2), with no recurrence calls.
    U=[{} for _ in range(2*m+1)]
    for k,r in enumerate(R):
        for j in range(2*k+1):
            factor=comb(2*k,j);target=m-k+j
            for e,v in r.items():U[target][e]=(U[target].get(e,0)+factor*v)%25
    return [{e:v for e,v in p.items() if v} for p in U]

controls=[];measures=[]
try:
    compile_output=run(['g++','-O3','-std=c++17','-Wall','-Wextra','-Werror','sparse_q29.cpp','-o','sparse_q29'],'compile')
    # Independent symbolic distributivity check, formal q/w/P/Q monomials.
    # tuple = (q exponent, w exponent, P exponent, Q exponent)
    def polyadd(*terms):
        out={}
        for p in terms:
            for e,v in p.items():out[e]=out.get(e,0)+v
        return {e:v for e,v in out.items() if v}
    def polyscale(p,c,shift=0):return {(e[0]+shift,*e[1:]):c*v for e,v in p.items()}
    P={(0,0,1,0):1};Q={(0,0,0,1):1};wP={(0,1,1,0):1}
    for m in [1,2,3,17,843]:
        D=polyadd(Q,polyscale(Q,-1,2*m-2));T=polyadd(P,polyscale(P,1,1),D)
        fused=polyadd(wP,polyscale(P,-2),polyscale(D,-1),polyscale(T,1,2*m-1))
        expanded=polyadd(wP,polyscale(P,-2),polyscale(P,1,2*m-1),polyscale(P,1,2*m),polyscale(Q,-1),polyscale(Q,1,2*m-2),polyscale(Q,1,2*m-1),polyscale(Q,-1,4*m-3))
        assert fused==expanded
    assert remainder({3375:1,0:-1})=={}
    for t in [1,1001]:
        for m in range(0,9):
            L=m+1;stem=f'control_m{m}_w{L}_q{t}';path=HERE/(stem+'.bin')
            info=json.loads(run(['./sparse_q29',str(m),str(L),str(t),path.name],stem))
            R=read_bin(path,L);expected=gaussian_quotient(m,t)
            assert expand_reciprocal(R,m)==expected, (m,t,'Gaussian mismatch')
            for truncated in sorted(set([1,min(2,L),min(4,L)])):
                s=f'{stem}_trunc{truncated}';smallpath=HERE/(s+'.bin')
                run(['./sparse_q29',str(m),str(truncated),str(t),smallpath.name],s)
                assert read_bin(smallpath,truncated)==R[:truncated]
            controls.append({'m':m,'q_exponent':t,'gaussian_binomial_reconstruction':True,'truncations':sorted(set([1,min(2,L),min(4,L)]))})
    save({'passed':True,'controls':controls,'fused_symbolic_m':[1,2,3,17,843],'independent_monic_period_relation':True},'CONTROLS.json')
    print('PASS independent Gaussian controls; beginning small timing cases.',flush=True)
    # Three repeat timings per size retain separate preparation/kernel/write charges.
    for m,L in [(32,8),(64,16),(128,32),(192,48)]:
        for repeat in range(3):
            name=f'bench_m{m}_w{L}_r{repeat}'
            info=json.loads(run(['./sparse_q29',str(m),str(L),'1',name+'.bin'],name));info['output_file']=name+'.bin';info['repeat']=repeat
            measures.append(info)
    save(measures,'SMALL_BENCHMARKS.json')
    # Full exact operation count, independent of the kernel's counter.
    rows=[]
    for e in range(3375):rows.append(remainder({e:1}))
    def update_count(t):return sum(len(rows[(e+t)%3375]) for e in range(1800))
    shifts={t:update_count(t) for t in range(1686)}
    full_scatter=sum(min(m-1,100)*shifts[2*m-2]+min(m,100)*(shifts[1]+shifts[2*m-1]) for m in range(1,844))
    full_dense=sum(1800*4*min(m,100) for m in range(1,844))
    full_mod=sum(1800*(min(m-1,100)+min(m,100)+min(m+1,100)) for m in range(1,844))
    full_ops=full_scatter+full_dense+full_mod
    # Use worst measured time/update from all nontrivial sizes, times eight,
    # with a five-second startup/write reserve. This is an empirical gate,
    # not an asymptotic theorem or guaranteed runtime bound.
    rates=[r['kernel_wall_seconds']/(r['signed_scatter_updates']+r['dense_arithmetic_updates']+r['modular_reductions']) for r in measures]
    cpu_rates=[r['kernel_cpu_seconds']/(r['signed_scatter_updates']+r['dense_arithmetic_updates']+r['modular_reductions']) for r in measures]
    estimate_wall=8*max(rates)*full_ops+5;estimate_cpu=8*max(cpu_rates)*full_ops+5
    gate={'full_signed_scatter_updates':full_scatter,'full_dense_arithmetic_updates':full_dense,'full_modular_reductions':full_mod,'safety_factor':8,'startup_write_reserve_seconds':5,'conservative_estimated_wall_seconds':estimate_wall,'conservative_estimated_cpu_seconds':estimate_cpu,'wall_remaining_seconds':MAXWALL-(time.monotonic()-START),'cpu_remaining_seconds':MAXCPU-cpu_used(),'memory_limit_bytes':MAXMEM,'largest_retained_checkpoint':'bench_m192_w48_r2.bin'}
    gate['admitted']=estimate_wall<gate['wall_remaining_seconds'] and estimate_cpu<gate['cpu_remaining_seconds'] and estimate_wall<180 and estimate_cpu<120
    save(gate,'FULL_RUN_GATE.json');print(json.dumps(gate),flush=True)
    if gate['admitted']:
        name='R843_w100_mod25_zbasis'
        full=json.loads(run(['./sparse_q29','843','100','1',name+'.bin'],name))
        assert full['signed_scatter_updates']==full_scatter
        assert full['dense_arithmetic_updates']==full_dense
        assert full['modular_reductions']==full_mod
        read_bin(HERE/(name+'.bin'),100)
        full['sha256']=sha(HERE/(name+'.bin'));save(full,'FULL_RESULT.json')
        print('FULL RESULT '+json.dumps(full),flush=True)
        status='PASS_FULL_R843_W100_ZBASIS'
    else: status='PASS_CONTROLS_STOPPED_AT_BUDGET_GATE'
except BaseException as exc:
    status='FAIL';save({'error':repr(exc)},'ERROR.json');raise
finally:
    receipt={'status':status,'commands':records,'elapsed_wall_seconds':time.monotonic()-START,'total_charged_cpu_seconds':cpu_used(),'maximum_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'limits':{'wall_seconds':MAXWALL,'cpu_seconds':MAXCPU,'address_space_bytes':MAXMEM},'platform':platform.platform(),'python':sys.version,'historical_programs_executed':False,'networking':False,'external_writes':False,'basis':'z^0,...,z^1799 in (Z/25Z)[z]/Phi3375(z)','coefficient_encoding':'ascending w degree, then ascending z degree; one byte per canonical residue 0..24','conversion_performed':False}
    save(receipt,'EXECUTION_RECEIPT.json')
    manifest={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ['MANIFEST.json','driver.stdout','driver.stderr']}
    save(manifest,'MANIFEST.json')
