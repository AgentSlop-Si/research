// Independent full control: expanded recurrence modulo z^3375-1.
// No Phi15 reduction rows or fused intermediates are used.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <ctime>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
constexpr int N=3375, D=1800;
using Buffer=std::vector<int16_t>;
static int canon(int x){x%=25;return x<0?x+25:x;}
static void rotate_add(Buffer& dest,const Buffer& source,int width,int exponent,int sign){
 exponent%=N;
 for(int k=0;k<width;k++){
  const int16_t *s=source.data()+k*N;int16_t *d=dest.data()+k*N;
  if(sign==1){for(int j=0;j<N-exponent;j++)d[j+exponent]+=s[j];for(int j=N-exponent;j<N;j++)d[j+exponent-N]+=s[j];}
  else{for(int j=0;j<N-exponent;j++)d[j+exponent]-=s[j];for(int j=N-exponent;j<N;j++)d[j+exponent-N]-=s[j];}
 }
}
int main(int argc,char**argv){try{
 if(argc!=4)throw std::runtime_error("Usage: cyclic_expanded_control m w output");
 int M=std::stoi(argv[1]),L=std::stoi(argv[2]);if(M<0||M>843||L<1||L>100)throw std::runtime_error("Bound exceeded");
 auto start=std::chrono::steady_clock::now();std::clock_t c0=std::clock();
 Buffer P(L*N),Q(L*N),R(L*N);P[0]=1;
 auto prepared=std::chrono::steady_clock::now();
 for(int m=1;m<=M;m++){
  int pwidth=std::min(m,L),qwidth=std::min(m-1,L),outwidth=std::min(m+1,L);
  for(int k=0;k<outwidth;k++)for(int j=0;j<N;j++)R[k*N+j]=(k?P[(k-1)*N+j]:0)-(k<pwidth?2*P[k*N+j]:0)-(k<qwidth?Q[k*N+j]:0);
  rotate_add(R,P,pwidth,2*m,1);rotate_add(R,P,pwidth,2*m-1,1);
  rotate_add(R,Q,qwidth,2*m-1,1);rotate_add(R,Q,qwidth,2*m-2,1);rotate_add(R,Q,qwidth,4*m-3,-1);
  for(int j=0;j<outwidth*N;j++)R[j]=canon(R[j]);
  Q.swap(P);P.swap(R);
 }
 auto kernel_end=std::chrono::steady_clock::now();std::clock_t c1=std::clock();
 // Independent descending monic reduction by the seven-term Phi3375.
 const int powers[6]={0,225,675,900,1125,1575};const int coefficients[6]={1,-1,1,-1,1,-1};
 for(int k=0;k<L;k++){
  int16_t *p=P.data()+k*N;
  for(int degree=N-1;degree>=D;degree--){int c=canon(p[degree]);p[degree]=0;for(int j=0;j<6;j++){int index=degree-D+powers[j];p[index]=canon(p[index]-c*coefficients[j]);}}
 }
 auto reduced=std::chrono::steady_clock::now();std::clock_t c2=std::clock();
 std::ofstream out(argv[3],std::ios::binary);if(!out)throw std::runtime_error("Open failed");
 for(int k=0;k<L;k++) {for(int j=0;j<D;j++) {out.put(char(canon(P[k*N+j])));}}
 out.close();if(!out)throw std::runtime_error("Write failed");
 auto finished=std::chrono::steady_clock::now();
 auto seconds=[](auto a,auto b){return std::chrono::duration<double>(b-a).count();};
 std::cout.precision(12);
 std::cout<<"{\"m\":"<<M<<",\"w_limit\":"<<L<<",\"preparation_wall_seconds\":"<<seconds(start,prepared)<<",\"kernel_wall_seconds\":"<<seconds(prepared,kernel_end)<<",\"monic_reduction_wall_seconds\":"<<seconds(kernel_end,reduced)<<",\"write_wall_seconds\":"<<seconds(reduced,finished)<<",\"preparation_and_kernel_cpu_seconds\":"<<double(c1-c0)/CLOCKS_PER_SEC<<",\"monic_reduction_cpu_seconds\":"<<double(c2-c1)/CLOCKS_PER_SEC<<"}\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
