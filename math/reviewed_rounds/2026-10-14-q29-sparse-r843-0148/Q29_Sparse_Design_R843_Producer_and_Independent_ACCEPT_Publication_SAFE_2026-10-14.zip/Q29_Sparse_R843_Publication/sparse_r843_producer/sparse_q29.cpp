// Fresh Q29 packed reciprocal kernel, 2026-10-14.
// No code from predecessor programs is imported or executed.
#include <array>
#include <chrono>
#include <cstdint>
#include <ctime>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using Clock=std::chrono::steady_clock;
constexpr int DEG=1800, ORDER=3375, BLOCK=225, MOD=25;
struct Segment {int src,dst,n,sign;};
using Plan=std::vector<Segment>;
using Buffer=std::vector<int16_t>;
static std::array<std::array<int,8>,15> rows;
static int canonical(int x) {int r=x%MOD; return r<0?r+MOD:r;}
static void init_rows() {
  // Descending exact reduction by Phi15(y)=y^8-y^7+y^5-y^4+y^3-y+1.
  const std::array<int,9> phi={1,-1,0,1,-1,1,0,-1,1};
  for(int n=0;n<15;n++) {
    std::array<int,15> a{}; a[n]=1;
    for(int j=14;j>=8;j--) {int c=a[j]; a[j]=0; for(int k=0;k<8;k++) a[j-8+k]-=c*phi[k];}
    for(int k=0;k<8;k++) rows[n][k]=a[k];
  }
}
static Plan make_plan(int exponent) {
  exponent%=ORDER; if(exponent<0) exponent+=ORDER;
  int quotient=exponent/BLOCK, rem=exponent%BLOCK; Plan plan;
  for(int b=0;b<8;b++) {
    for(int carry=0;carry<=1;carry++) {
      int begin=carry?BLOCK-rem:0, len=carry?rem:BLOCK-rem;
      if(!len) continue;
      int target_residue=carry?0:rem;
      for(int d=0;d<8;d++) {
        int sign=rows[(b+quotient+carry)%15][d];
        if(sign) plan.push_back({b*BLOCK+begin,d*BLOCK+target_residue,len,sign});
      }
    }
  }
  return plan;
}
static void shift_add(Buffer& dst,const Buffer& src,int count,const Plan& plan,int multiplier) {
  for(int k=0;k<count;k++) {
    const int16_t *s=src.data()+k*DEG; int16_t *d=dst.data()+k*DEG;
    for(const Segment& segment:plan) {
      const int16_t *in=s+segment.src; int16_t *out=d+segment.dst;
      if(segment.sign*multiplier==1) for(int j=0;j<segment.n;j++) out[j]+=in[j];
      else if(segment.sign*multiplier==-1) for(int j=0;j<segment.n;j++) out[j]-=in[j];
      else throw std::runtime_error("Unexpected monomial-map coefficient");
    }
  }
}
static void normalize(Buffer& a,int count) {for(int j=0;j<count*DEG;j++) a[j]=canonical(a[j]);}
static uint64_t plan_updates(const Plan& p) {uint64_t n=0; for(auto s:p)n+=s.n;return n;}
int main(int argc,char** argv) {
 try {
  if(argc!=5) throw std::runtime_error("Usage: sparse_q29 m w q_exponent output.bin");
  int M=std::stoi(argv[1]),L=std::stoi(argv[2]),qexp=std::stoi(argv[3]);
  if(M<0||M>843||L<1||L>100||qexp<0||qexp>=ORDER)throw std::runtime_error("Parameter outside bounded contract");
  auto start=Clock::now(); std::clock_t c0=std::clock(); init_rows();
  Plan one=make_plan(qexp); std::vector<Plan> even,odd;even.reserve(M);odd.reserve(M);
  for(int m=1;m<=M;m++) {even.push_back(make_plan(qexp*(2*m-2)));odd.push_back(make_plan(qexp*(2*m-1)));}
  Buffer P(L*DEG),Q(L*DEG),D(L*DEG),T(L*DEG),N(L*DEG);P[0]=1;
  auto prep_end=Clock::now();std::clock_t c1=std::clock();
  uint64_t signed_updates=0,dense_arithmetic=0,modular_reductions=0;
  for(int m=1;m<=M;m++) {
    int a=std::min(m,L), b=std::min(m-1,L), n=std::min(m+1,L);
    // D=(1-q^(2m-2))*Q; T=P+q*P+D.
    std::fill(D.begin(),D.begin()+a*DEG,0);
    std::copy(Q.begin(),Q.begin()+b*DEG,D.begin());
    shift_add(D,Q,b,even[m-1],-1);normalize(D,b);
    for(int j=0;j<a*DEG;j++)T[j]=P[j]+D[j];
    shift_add(T,P,a,one,1);normalize(T,a);
    // N=w*P-2*P-D+q^(2m-1)*T, using zero beyond live input degrees.
    for(int k=0;k<n;k++)for(int j=0;j<DEG;j++) {
      int v=k?P[(k-1)*DEG+j]:0;
      if(k<a)v-=2*P[k*DEG+j]+D[k*DEG+j];
      N[k*DEG+j]=v;
    }
    shift_add(N,T,a,odd[m-1],1);normalize(N,n);
    Q.swap(P);P.swap(N);
    signed_updates+=b*plan_updates(even[m-1])+a*(plan_updates(one)+plan_updates(odd[m-1]));
    dense_arithmetic+=uint64_t(DEG)*(4*a); // T addition; N doubling and two subtractions.
    modular_reductions+=uint64_t(DEG)*(b+a+n);
  }
  auto kernel_end=Clock::now();std::clock_t c2=std::clock();
  std::ofstream out(argv[4],std::ios::binary);if(!out)throw std::runtime_error("Cannot open output");
  uint64_t checksum=1469598103934665603ULL; uint64_t nonzero=0;
  for(int16_t value:P){char byte=char(value);out.write(&byte,1);checksum^=uint8_t(value);checksum*=1099511628211ULL;nonzero+=value!=0;}
  out.close();if(!out)throw std::runtime_error("Output write failed");
  auto finish=Clock::now();std::clock_t c3=std::clock();
  auto elapsed=[](auto a,auto b){return std::chrono::duration<double>(b-a).count();};
  std::cout.precision(12);
  std::cout<<"{\"m\":"<<M<<",\"w_limit\":"<<L<<",\"q_exponent\":"<<qexp
   <<",\"preparation_wall_seconds\":"<<elapsed(start,prep_end)<<",\"kernel_wall_seconds\":"<<elapsed(prep_end,kernel_end)
   <<",\"write_wall_seconds\":"<<elapsed(kernel_end,finish)<<",\"preparation_cpu_seconds\":"<<double(c1-c0)/CLOCKS_PER_SEC
   <<",\"kernel_cpu_seconds\":"<<double(c2-c1)/CLOCKS_PER_SEC<<",\"write_cpu_seconds\":"<<double(c3-c2)/CLOCKS_PER_SEC
   <<",\"signed_scatter_updates\":"<<signed_updates<<",\"dense_arithmetic_updates\":"<<dense_arithmetic
   <<",\"modular_reductions\":"<<modular_reductions<<",\"output_bytes\":"<<P.size()
   <<",\"nonzero_coordinates\":"<<nonzero<<",\"fnv1a64\":\""<<checksum<<"\",\"basis_conversion_performed\":false}\n";
 }catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
}
