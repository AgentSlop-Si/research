#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,resource,subprocess,time
HERE=Path(__file__).resolve().parent
start=time.monotonic();entries=[]
def run(args,stem):
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
        resource.setrlimit(resource.RLIMIT_CPU,(30,30))
    then=time.monotonic();p=subprocess.run(args,cwd=HERE,text=True,capture_output=True,timeout=max(1,60-(time.monotonic()-start)),preexec_fn=limits)
    (HERE/(stem+'.stdout')).write_text(p.stdout);(HERE/(stem+'.stderr')).write_text(p.stderr)
    entries.append({'command':args,'wall_seconds':time.monotonic()-then,'returncode':p.returncode})
    assert p.returncode==0,p.stderr
    return p.stdout
run(['g++','-O3','-std=c++17','-Wall','-Wextra','-Werror','cyclic_expanded_control.cpp','-o','cyclic_expanded_control'],'cyclic_compile')
small=json.loads(run(['./cyclic_expanded_control','8','9','cyclic_small.bin'],'cyclic_small'))
assert (HERE/'cyclic_small.bin').read_bytes()==(HERE/'control_m8_w9_q1.bin').read_bytes()
# Count active cyclic coefficients (the expanded kernel has constant work/entry).
count=lambda m,w:sum(min(j+1,w) for j in range(1,m+1))
estimate=8*small['kernel_wall_seconds']*count(843,100)/count(8,9)+5
assert estimate<min(60-(time.monotonic()-start),30)
full=json.loads(run(['./cyclic_expanded_control','843','100','cyclic_R843_w100.bin'],'cyclic_full'))
a=(HERE/'cyclic_R843_w100.bin').read_bytes();b=(HERE/'R843_w100_mod25_zbasis.bin').read_bytes()
assert a==b
result={'status':'PASS_ALL_180000_COORDINATES','small':small,'conservative_full_estimate_seconds':estimate,'full':full,'output_sha256':hashlib.sha256(a).hexdigest(),'commands':entries,'total_wall_seconds':time.monotonic()-start,'child_cpu_seconds':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,'maximum_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'historical_programs_executed':False}
(HERE/'INDEPENDENT_FULL_CONTROL.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
