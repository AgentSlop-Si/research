#!/usr/bin/env python3
"""Fresh, bounded integer arithmetic controls. No imports of predecessor code."""
from math import comb
from pathlib import Path
import hashlib, json, time, zipfile
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
START=time.monotonic()
F=[sum(comb(25*r,j) if j<=25*r else 0 for r in range(5)) for j in range(101)]
assert F[100]==1 and F[0]==5 and all(c%5==0 for c in F[:100])

def poly_mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c
lhs=poly_mul([comb(25,j)-(1 if j==0 else 0) for j in range(26)],F)
rhs=[comb(125,j)-(1 if j==0 else 0) for j in range(126)]
assert lhs==rhs

# Independent finite-field Rabin irreducibility test for Phi27.
G=[1]+[0]*8+[1]+[0]*8+[1]
def trim(a):
    while len(a)>1 and a[-1]==0: a.pop()
    return a

def rem(a,b,p=5):
    a=[x%p for x in a]; b=trim([x%p for x in b]); a=trim(a)
    while len(a)>=len(b) and a!=[0]:
        u=a[-1]*pow(b[-1],-1,p)%p; d=len(a)-len(b)
        for j,x in enumerate(b): a[d+j]=(a[d+j]-u*x)%p
        trim(a)
    return a

def gcd(a,b):
    while b!=[0]: a,b=b,rem(a,b)
    u=pow(a[-1],-1,5)
    return [(v*u)%5 for v in a]

def pwp(a,e):
    z=[1]
    while e:
        if e&1: z=rem(poly_mul(z,a),G)
        a=rem(poly_mul(a,a),G); e//=2
    return z

def minus_x(a):
    a=a+[0]*max(0,2-len(a)); a[1]=(a[1]-1)%5
    return trim(a)
assert pwp([0,1],5**18)==[0,1]
assert gcd(G,minus_x(pwp([0,1],5**9)))==[1]
assert gcd(G,minus_x(pwp([0,1],5**6)))==[1]

class Ring:
    """Sparse canonical basis a^i*pi^j, i<18, j<100 over Z/5^M."""
    def __init__(self,M):
        self.M=M; self.mod=5**M
        self.f=[(j,c%self.mod) for j,c in enumerate(F[:100]) if c%self.mod]
        self.one={(0,0):1}; self.pi={(0,1):1}; self.a={(1,0):1}
    def clean(self,d): return {k:v%self.mod for k,v in d.items() if v%self.mod}
    def scalar(self,n): return self.clean({(0,0):n})
    def add(self,a,b):
        c=dict(a)
        for k,v in b.items(): c[k]=c.get(k,0)+v
        return self.clean(c)
    def scale(self,a,n): return self.clean({k:v*n for k,v in a.items()})
    def sub(self,a,b): return self.add(a,self.scale(b,-1))
    def normalize(self,c):
        # Relations are monic and in distinct variables; order is deterministic.
        c=self.clean(c)
        for i in range(max((i for i,j in c),default=0),17,-1):
            for (ii,j),u in list(c.items()):
                if ii==i:
                    del c[(ii,j)]
                    for k in [(i-18,j),(i-9,j)]: c[k]=(c.get(k,0)-u)%self.mod
        for j in range(max((j for i,j in c),default=0),99,-1):
            for (i,jj),u in list(c.items()):
                if jj==j:
                    del c[(i,jj)]
                    for k,fk in self.f:
                        at=(i,j-100+k); c[at]=(c.get(at,0)-u*fk)%self.mod
        return self.clean(c)
    def mul(self,a,b):
        c={}
        for (i,j),u in a.items():
            for (k,l),v in b.items():
                at=(i+k,j+l); c[at]=(c.get(at,0)+u*v)%self.mod
        return self.normalize(c)
    def power(self,a,e):
        z=self.one
        while e:
            if e&1: z=self.mul(z,a)
            a=self.mul(a,a); e//=2
        return z
    def val(self,a):
        def v5(x):
            z=0
            while x%5==0: x//=5; z+=1
            return z
        return min((j+100*v5(u) for (i,j),u in a.items()),default=100*self.M)
    def eqprec(self,a,b,P): return self.val(self.sub(a,b))>=P
    def truncate(self,a,N):
        assert 1<=N<=100*self.M
        out={}
        for (i,j),v in a.items():
            exponent=max(0,(N-j+99)//100)
            u=v%(5**exponent)
            if u: out[(i,j)]=u
        return out
    def div_pi(self,x):
        c0=[x.get((i,0),0) for i in range(18)]
        if any(c%5 for c in c0): raise ValueError('Input is not divisible by pi')
        d99=[-(c//5) for c in c0]
        out={(i,99):d99[i] for i in range(18)}
        for j in range(1,100):
            for i in range(18): out[(i,j-1)]=x.get((i,j),0)+F[j]*d99[i]
        out=self.clean(out)
        assert self.mul(self.pi,out)==x
        return out
    def divide(self,x,h,P):
        assert 0<=h<P<=100*self.M
        for _ in range(h): x=self.div_pi(x)
        return x,P-h
    def encode(self,a): return [[i,j,u] for (i,j),u in sorted(a.items())]

checks={}
for M in [1,2,3]:
    B=Ring(M); xi=B.add(B.one,B.pi); q=B.mul(B.a,xi)
    assert B.power(B.a,27)==B.one and B.power(B.a,9)!=B.one
    assert B.power(B.a,5**18)==B.a
    assert B.power(xi,125)==B.one
    assert B.power(q,3375)==B.one
    assert B.power(q,1000)==B.a and B.power(q,2376)==xi
    assert B.power(q,1125)!=B.one and B.power(q,675)!=B.one
    assert B.val(B.sub(B.power(xi,5),B.one))==5
    assert B.val(B.sub(B.power(xi,25),B.one))==25
    assert B.power(B.pi,100*M)=={}
    assert B.val(B.power(B.pi,100*M-1))==100*M-1
    # Identity Phi125(1+pi)=0, exact integer coefficients.
    acc={}
    for j,c in enumerate(F): acc=B.add(acc,B.scale(B.power(B.pi,j),c))
    assert acc=={}
    vv=B.val(B.scalar(5))
    if M>=2: assert vv==100
    else: assert vv==100 and B.scalar(5)=={}
    checks[f'mod_5^{M}']={'precision':100*M,'primitive3375_order_guards':True,
      'teichmuller_alpha_guard':True,'cyclotomic_relation':True,'nilpotence_exact_index':100*M,
      'valuation_5_or_zero_lower_bound':vv}

B=Ring(2); xi=B.add(B.one,B.pi)
V=B.normalize({(0,j):F[j]//5 for j in range(100)})
assert B.add(B.power(B.pi,100),B.scale(V,5))=={}
carry=B.add(B.scalar(5),B.power(B.pi,100))
assert B.val(carry)==125
frobenius_defect=B.sub(B.sub(B.power(xi,5),B.one),B.power(B.pi,5))
assert B.val(frobenius_defect)==101
norm_defect,P=B.divide(frobenius_defect,101,200)
assert norm_defect.get((0,0),0)%5==4
assert B.eqprec(B.scalar(5),{},100) and not B.eqprec(B.scalar(5),{},101)
assert B.eqprec(carry,{},125) and not B.eqprec(carry,{},126)
assert B.eqprec(frobenius_defect,{},101) and not B.eqprec(frobenius_defect,{},102)

# Normalization with explicit, genuine lost precision.
y=B.add(B.add(B.scalar(5),B.a),B.add(B.pi,B.mul(B.power(B.a,2),B.power(B.pi,99))))
x=B.mul(B.power(B.pi,60),y)
z,P=B.divide(x,60,200)
assert P==140 and B.eqprec(z,y,P)
edge=B.power(B.pi,199); unit,Pedge=B.divide(edge,199,200)
assert Pedge==1 and B.eqprec(unit,B.one,1)
try:
    B.div_pi(B.one)
    raise AssertionError('nondivisible input was accepted')
except ValueError:
    pass

# Non-multiple-of-100 quotients use staggered coefficient moduli.
truncation_checks=[]
for N in [1,99,100,101,125,126,199,200]:
    perturbation=B.mul(B.power(B.pi,N),B.add(y,B.scalar(3)))
    altered=B.add(y,perturbation)
    assert B.truncate(y,N)==B.truncate(altered,N)
    assert B.truncate(B.mul(y,y),N)==B.truncate(B.mul(altered,y),N)
    assert B.eqprec(y,B.truncate(y,N),N)
    truncation_checks.append(N)

# Ordinary integer branch-center lifts versus Teichmuller representatives mod25.
teich=[]
for c in range(5):
    ts=[n for n in range(c,25,5) if (pow(n,5,25)-n)%25==0]
    assert len(ts)==1
    teich.append(ts[0])
assert teich==[0,1,7,18,24]
assert B.val(B.sub(B.power(B.scalar(2),4),B.one))==100
assert B.power(B.scalar(7),4)==B.one

# Fresh small Rogers--Szego / reciprocal recurrence agreement, fully modulo25.
# Polynomial coefficients are B-elements, ordered in ascending z or w degree.
def padd(a,b):
    out=[{} for _ in range(max(len(a),len(b)))]
    for i,x in enumerate(a): out[i]=B.add(out[i],x)
    for i,x in enumerate(b): out[i]=B.add(out[i],x)
    while len(out)>1 and not out[-1]: out.pop()
    return out

def pscale(a,c): return [B.mul(x,c) for x in a]
def pshift(a): return [{}]+a
q=B.mul(B.a,xi)
qp=[B.one]
for _ in range(13): qp.append(B.mul(qp[-1],q))
Hs=[[B.one],[B.one,B.one]]
for n in range(2,14):
    Hs.append(padd(padd(Hs[-1],pshift(Hs[-1])),pscale(pshift(Hs[-2]),B.sub(qp[n-1],B.one))))
Rs=[[B.one]]
Rm2=[{}]
small=[]
for m in range(1,7):
    coeff=B.add(B.scalar(-2),B.add(qp[2*m],qp[2*m-1]))
    prod=B.mul(B.sub(B.one,qp[2*m-1]),B.sub(B.one,qp[2*m-2]))
    R=padd(padd(pshift(Rs[-1]),pscale(Rs[-1],coeff)),pscale(Rm2,B.scale(prod,-1)))
    Rm2=Rs[-1]; Rs.append(R)
    U=[{} for _ in range(2*m+1)]
    for k,rk in enumerate(R):
        for j in range(2*k+1):
            U[m-k+j]=B.add(U[m-k+j],B.scale(rk,comb(2*k,j)))
    Hpred=padd(U,pshift(U))
    assert Hpred==Hs[2*m+1]
    small.append({'m':m,'H_degree':2*m+1,'agreement':True})

# Source archive and manifest read as inert bytes only.
archive=ROOT/'Q29_Higher_Layer_Bounded_Normalization_and_Discriminant_Gap_2026-10-14.zip'
source_paths=[archive,ROOT/'q29_bounded_source/REPORT.md',
 ROOT/'q29_bounded_source/RESULT.json',
 ROOT/'q29_bounded_source/SOURCE_BINDINGS.json',
 ROOT/'q29_bounded_source/sources/precision_note.md',
 ROOT/'q29_bounded_source/AUDIT_RECEIPT.json',
 ROOT/'q29_bounded_source/MANIFEST.json']
source_hashes=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,
 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in source_paths]
with zipfile.ZipFile(archive) as zf:
    assert zf.testzip() is None
    matches=[]
    for p in source_paths[1:]:
        member=str(p.relative_to(ROOT/'q29_bounded_source'))
        assert zf.read(member)==p.read_bytes()
        matches.append(member)
    manifest=json.loads(zf.read('MANIFEST.json'))
    assert manifest['hash_algorithm']=='SHA-256'
    for row in manifest['files']:
        data=zf.read(row['path'])
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    manifest_count=len(manifest['files'])

result={'status':'PASS: bounded precision-ring contract controls; full Q29 remains open',
 'source_hashes':source_hashes,
 'archive_crc':'PASS','archive_all_manifest_hashes':'PASS','archive_manifest_member_count':manifest_count,
 'archive_selected_source_members_equal_local':matches,
 'phi27_rabin_irreducibility':{'x_5^18_mod_g_equals_x':True,'gcd_5^9_minus_x':1,'gcd_5^6_minus_x':1},
 'phi125_shifted_exact_coefficients':F,
 'eisenstein':True,'integer_cyclotomic_product_identity':True,
 'ring_controls':checks,
 'first_carry':{'v_pi_5':100,'pi100_equals_minus5_mod_pi125':True,'v_pi_5_plus_pi100':125,
   'pi100_mod25':B.encode(B.power(B.pi,100)),
   'v_pi_xi5_minus1_minuspi5':101,'normalized_frobenius_defect_residue':4},
 'division':{'pi60_division_remaining_precision':P,'pi199_division_remaining_precision':Pedge,
   'nondivisible_rejection':True},
 'staggered_precision_quotient_controls':truncation_checks,
 'teichmuller_integer_residues_mod25':teich,
 'small_full_H_reciprocal_controls_mod25':small,
 'historical_code_executed':False,'external_writes':False,
 'elapsed_seconds':round(time.monotonic()-START,3),
 'scientific_scope':'No H1687 lift, no R843 discriminant, no full center coverage computed.'}
(BASE/'CONTROL_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['phi125_shifted_exact_coefficients','source_hashes']},indent=2))
