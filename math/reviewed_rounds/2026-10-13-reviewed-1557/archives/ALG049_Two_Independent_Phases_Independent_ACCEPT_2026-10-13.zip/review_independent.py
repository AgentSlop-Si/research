#!/usr/bin/env python3
"""Fresh ALG049 audit. Never imports or executes any candidate/source program.
Input is the pinned zip; scalar expression strings are treated as data via a
small AST evaluator limited to rational operations and the symbol z.
"""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import resource
import sys
import time
import zipfile
from collections import Counter, defaultdict

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
resource.setrlimit(resource.RLIMIT_CPU, (240, 240))
resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
import sympy as S

START = time.perf_counter()
BASE = Path(__file__).resolve().parent
INPUT = BASE / 'ALG049_Two_Independent_Phases_Candidate_2026-10-13.zip'
SHA = 'c2da4079af2816e5e99bb683e053a1e9a7699bb5e794a33fabc7ed8df1c46517'
COUNTS = Counter()

def check(ok, family, label):
    if not ok:
        raise AssertionError(f'{family}: {label}')
    COUNTS[family] += 1

raw = INPUT.read_bytes()
check(len(raw) == 127154, 'input_integrity', 'archive size')
check(hashlib.sha256(raw).hexdigest() == SHA, 'input_integrity', 'archive sha256')
zipin = zipfile.ZipFile(io.BytesIO(raw))
manifest = json.loads(zipin.read('MANIFEST.json'))
for item in manifest['files']:
    blob = zipin.read(item['path'])
    check(len(blob) == item['bytes'], 'input_integrity', item['path'] + ' size')
    check(hashlib.sha256(blob).hexdigest() == item['sha256'], 'input_integrity', item['path'] + ' hash')
for item in json.loads(zipin.read('SOURCE_PINS.json'))['files']:
    blob = zipin.read(item['path'])
    check(len(blob) == item['bytes'], 'source_integrity', item['path'] + ' size')
    check(hashlib.sha256(blob).hexdigest() == item['sha256'], 'source_integrity', item['path'] + ' hash')
data = json.loads(zipin.read('CANDIDATE_EQUATIONS.json'))

z, v, t, X = S.symbols('z v t X')
I8 = S.eye(8)
ORDERS = [(0,1,2,3,4,5,6,7), (0,1,3,4,5,6,2,7), (0,1,4,5,6,7,3,2)]
WORDS = ['--+', '-+-', '-++', '+--', '+-+', '++-']
WEIGHTS = [['1']*7+['-1'], ['z','1','1','1','1','1','z^-1','-1'], ['1','1','v^2','1','1','v^-2','1','-1']]
check(data['scope']['dimension'] == 8, 'scope', 'dimension')
check(data['scope']['orders'] == [list(o) for o in ORDERS], 'scope', 'orders')
check(data['scope']['edge_weights'] == WEIGHTS, 'scope', 'literal weights')
check(data['scope']['phase_parameters'] == ['w1 inert','z=w2','v=w3'], 'scope', 'parameters')
check(data['scope']['words'] == WORDS and list(data['words']) == WORDS, 'scope', 'words')
check(data['scope']['separators'] == 'identity', 'scope', 'separators')
check(data['scope']['chart_coordinates'] == ['t2','t3'], 'scope', 'chart coordinates')
check(data['nominal_three_parameter_chart_map'] == {a+b+c:b+c for a in 'FI' for b in 'FI' for c in 'FI'}, 'scope', 'eight nominal charts')

# Independent direct construction and rational-function inversions.
def source_cycles(zz, vv):
    weights = [(1,1,1,1,1,1,1,-1), (zz,1,1,1,1,1,1/zz,-1), (1,1,vv**2,1,1,vv**-2,1,-1)]
    result = []
    for order, wt in zip(ORDERS, weights):
        M = S.zeros(8)
        for j, src in enumerate(order):
            M[order[(j+1)%8], src] = wt[j]
        result.append(M)
    return result

def norm(M):
    return M.applyfunc(S.cancel)

def source_factors(zz, vv):
    out = []
    for M in source_cycles(zz, vv):
        out.append({'+': norm((2*I8-M)*(I8-M).inv(method='DM')), '-': norm((I8-M)*(2*I8-M).inv(method='DM'))})
    return out

def adjoint(M):
    return M.T.applyfunc(lambda a: a.xreplace({z:1/z, v:1/v}))

Ms = source_cycles(z, v)
Fs = source_factors(z, v)
for k, (M, F) in enumerate(zip(Ms, Fs)):
    check(norm(M**8) == -I8, 'factor_identities', f'M{k+1}^8')
    check(norm(adjoint(M)*M) == I8, 'factor_identities', f'M{k+1} unitary involution')
    check(S.expand(M.charpoly(X).as_expr()) == X**8+1, 'factor_identities', f'M{k+1} charpoly')
    check(S.cancel((I8-M).det()) == 2, 'factor_identities', f'I-M{k+1} det')
    check(S.cancel((2*I8-M).det()) == 257, 'factor_identities', f'2I-M{k+1} det')
    check(S.cancel(F['+'].det()) == S.Rational(257,2), 'factor_identities', f'K{k+1} det')
    check(norm(F['+']*F['-']) == I8 and norm(F['-']*F['+']) == I8, 'factor_identities', f'K{k+1} inverse')
    powers = [I8] + [M**j for j in range(1,8)]
    polyplus = sum(powers[1:], 3*I8)/2
    polyminus = (129*I8-sum([2**(7-j)*powers[j] for j in range(1,8)],S.zeros(8)))/257
    check(norm(F['+']-polyplus) == S.zeros(8), 'factor_identities', f'K{k+1} geometric formula')
    check(norm(F['-']-polyminus) == S.zeros(8), 'factor_identities', f'K{k+1} inverse geometric formula')
    for sign, q in [('+',S.Integer(4)), ('-',S.Rational(86,257))]:
        G = norm(adjoint(F[sign])*F[sign])
        check(all(G[a,a] == q for a in range(8)), 'constant_diagonals', f'{k+1}{sign}')
print('PASS: literal cycles, direct inversions, determinants, and both constant-diagonal identities.', flush=True)

# Exact rational-expression parser. This does not evaluate Python code or
# use sympify/parse_expr on author-controlled text.
def read_expr(src):
    def visit(node):
        if isinstance(node, ast.Expression): return visit(node.body)
        if isinstance(node, ast.Constant) and type(node.value) is int: return S.Integer(node.value)
        if isinstance(node, ast.Name) and node.id == 'z': return z
        if isinstance(node, ast.UnaryOp):
            a = visit(node.operand)
            if isinstance(node.op, ast.USub): return -a
            if isinstance(node.op, ast.UAdd): return a
        if isinstance(node, ast.BinOp):
            a,b = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Add): return a+b
            if isinstance(node.op, ast.Sub): return a-b
            if isinstance(node.op, ast.Mult): return a*b
            if isinstance(node.op, ast.Div): return a/b
            if isinstance(node.op, ast.Pow) and b.is_Integer and abs(b) < 20: return a**b
        raise ValueError('Unsupported expression data')
    return visit(ast.parse(src, mode='eval'))

expected = {'--':(443686,-377300,16974593), '-+':(-57,15,257), '+-':(-35657,28474,66049), '++':(4,-1,1)}
certificates = {}
Ls = {}
for pair, (a,b,d) in expected.items():
    T = Fs[0][pair[0]]*Fs[1][pair[1]]
    L = norm(adjoint(T)*T)
    Ls[pair] = L
    delta = S.factor(L[3,3]-L[0,0])
    claim = data['diagonal_certificates'][pair]
    check(S.cancel(delta-(a+b*(z+1/z)/2)/d) == 0, 'sign_certificates', pair+' direct delta')
    check(S.cancel(delta-read_expr(claim['laurent_difference'])) == 0, 'sign_certificates', pair+' candidate expression')
    check(claim['linear_re_z_numerator'] == [a,b] and claim['denominator'] == d, 'sign_certificates', pair+' coefficients')
    for j in range(8):
        check(S.cancel(L[j,j]-read_expr(claim['left_diagonals'][j])) == 0, 'left_diagonals', pair+str(j))
    finite = S.cancel(delta.subs(z,(1+S.I*t)/(1-S.I*t))*d*(1+t*t))
    check(S.expand(finite) == (a+b)+(a-b)*t*t, 'sign_certificates', pair+' finite chart')
    check(claim['finite_t2_numerator'] == [a+b,0,a-b], 'sign_certificates', pair+' finite coefficients')
    check((a+b)*(a-b)>0 and d>0, 'sign_certificates', pair+' strict same sign')
    endpoint = S.Rational(a-b,d)
    check(S.cancel(delta.subs(z,-1)) == endpoint, 'sign_certificates', pair+' infinity direct substitution')
    check(read_expr(claim['t2_infinity_difference']) == endpoint, 'sign_certificates', pair+' stored infinity')
    margin = min(abs(S.Rational(a+b,d)),abs(endpoint))
    check(read_expr(claim['lower_absolute_bound']) == margin and margin>0, 'sign_certificates', pair+' strict bound')
    certificates[pair] = {'delta_laurent':str(delta), 'constant':a, 'coefficient_of_Re_z':b, 'denominator':d, 'finite_polynomial':[a+b,0,a-b], 'value_at_z_minus_one':str(endpoint), 'absolute_margin':str(margin)}
check(S.cancel(Ls['-+'][1,1]-Ls['-+'][0,0]-73*(z-1)**2/(514*z)) == 0, 'additional_identities', '-+ first difference')
check(S.cancel(Ls['-+'][2,2]-Ls['-+'][0,0]-35*(z+1)**2/(257*z)) == 0, 'additional_identities', '-+ second difference')
print('PASS: all four independently derived strict-sign certificates and 32 recorded left diagonals.', flush=True)

# Sparse exact Laurent arithmetic over Z, entered ONLY from direct inverses.
# The candidate Laurent rows enter only on the comparison side.
def clean(p): return {k:c for k,c in p.items() if c}
def ladd(p,q):
    r = dict(p)
    for e,c in q.items(): r[e] = r.get(e,0)+c
    return clean(r)
def lscale(p,c): return clean({e:a*c for e,a in p.items()})
def lmul(p,q):
    r = defaultdict(int)
    for (a,b),c in p.items():
        for (d,e),f in q.items(): r[(a+d,b+e)] += c*f
    return clean(r)
def lstar(p): return {(-a,-b):c for (a,b),c in p.items()}
def lmatrix(M):
    out = []
    for row in M.tolist():
        rr=[]
        for e in row:
            p={}
            for term in S.Add.make_args(S.expand(e)):
                powers=term.as_powers_dict(); a=powers.get(z,S.Integer(0)); b=powers.get(v,S.Integer(0))
                c=S.cancel(term/(z**a*v**b))
                if not (a.is_Integer and b.is_Integer and c.is_Integer): raise ValueError('Not integer Laurent')
                if c: p[(int(a),int(b))]=int(c)
            rr.append(p)
        out.append(rr)
    return out

def mm(A,B):
    C=[[{} for j in range(8)] for i in range(8)]
    for i in range(8):
        for k in range(8):
            if not A[i][k]: continue
            for j in range(8):
                C[i][j] = ladd(C[i][j],lmul(A[i][k],B[k][j]))
    return C

def ms(A,c): return [[lscale(p,c) for p in row] for row in A]
def dagger(A): return [[lstar(A[j][i]) for j in range(8)] for i in range(8)]
def specialize(A,tag):
    result=[]
    for row in A:
        rr=[]
        for p in row:
            q=defaultdict(int)
            for (a,b),c in p.items():
                q[(a if tag[0]=='F' else 0,b if tag[1]=='F' else 0)] += c * (-1 if tag[0]=='I' and a%2 else 1) * (-1 if tag[1]=='I' and b%2 else 1)
            rr.append(clean(q))
        result.append(rr)
    return result

def read_terms(rows):
    result={}
    for row in rows:
        if len(row)!=3 or any(type(i) is not int for i in row): raise ValueError('Malformed integer row')
        a,b,c=row
        if (a,b) in result or c==0: raise ValueError('Duplicate or zero coefficient')
        result[(a,b)]=c
    return result

def factor_ints(F):
    return [{'+':lmatrix(2*f['+']), '-':lmatrix(257*f['-'])} for f in F]
Ns=factor_ints(Fs)
Hs={}
for word in WORDS:
    D=2**word.count('+')*257**word.count('-')
    sigma=word.count('+')-word.count('-')
    record=data['words'][word]
    check(record['D']==D and record['sigma']==sigma, 'word_metadata', word)
    A=mm(mm(Ns[0][word[0]],Ns[1][word[1]]),Ns[2][word[2]])
    H=mm(dagger(A),A); Hs[word]=H
    check(H==dagger(H), 'gram_hermiticity', word)
    for i in range(8):
        for j in range(8):
            check(H[i][j]==read_terms(record['gram_integer_laurent'][i][j]), 'full_laurent_entries', f'{word}:{i},{j}')
            check(all(-2<=a<=2 and -4<=b<=4 for a,b in H[i][j]), 'laurent_exponent_bounds', f'{word}:{i},{j}')
    # Algebraically check stripping at full matrix level, for BOTH final signs.
    opposite='-' if word[2]=='+' else '+'
    stripped=mm(mm(dagger(Ns[2][opposite]),H),Ns[2][opposite])
    prefix=mm(Ns[0][word[0]],Ns[1][word[1]])
    prefix_gram=mm(dagger(prefix),prefix)
    check(stripped==ms(prefix_gram,(2*257)**2), 'full_stripping_identity', word)
print('PASS: 384 complete Laurent Gram entries, support bounds, and six exact stripping identities.', flush=True)

# A distinct denominator-clearing identity: for -m<=a<=m,
# (1+t^2)^m ((1+it)/(1-it))^a = (1+it)^(m+a)(1-it)^(m-a).
# Build these univariate Gaussian-integer polynomials independently in SymPy.
bases={}
for bound in (2,4):
    for exponent in range(-bound,bound+1):
        poly=S.Poly(S.expand((1+S.I*t)**(bound+exponent)*(1-S.I*t)**(bound-exponent)),t)
        co={}
        for (deg,),c in poly.terms():
            re,im=c.as_real_imag()
            if not (re.is_Integer and im.is_Integer): raise ValueError('Gaussian integrality')
            co[deg]=(int(re),int(im))
        bases[(bound,exponent,'F')]=co
        bases[(bound,exponent,'I')]={0:((-1 if exponent%2 else 1),0)}

def chart_poly(p,tag):
    re=defaultdict(int); im=defaultdict(int)
    for (a,b),c in p.items():
        for i,(ar,ai) in bases[(2,a,tag[0])].items():
            for j,(br,bi) in bases[(4,b,tag[1])].items():
                re[(i,j)]+=c*(ar*br-ai*bi)
                im[(i,j)]+=c*(ar*bi+ai*br)
    return clean(re),clean(im)

for tag in ('FF','FI','IF','II'):
    # Substitute infinity into the ORIGINAL WEIGHTED MATRICES before inversion.
    chart_sources=factor_ints(source_factors(z if tag[0]=='F' else S.Integer(-1),v if tag[1]=='F' else S.Integer(-1)))
    for word in WORDS:
        A=mm(mm(chart_sources[0][word[0]],chart_sources[1][word[1]]),chart_sources[2][word[2]])
        direct=mm(dagger(A),A)
        specialized=specialize(Hs[word],tag)
        for i in range(8):
            for j in range(8):
                check(direct[i][j]==specialized[i][j], 'source_chart_gram_entries', f'{word}:{tag}:{i},{j}')
        chart=data['words'][word]['charts'][tag]
        D=data['words'][word]['D']
        check(chart['positive_denominator']=={'D_squared':D*D,'u2_power':2 if tag[0]=='F' else 0,'u3_power':4 if tag[1]=='F' else 0}, 'chart_metadata', word+tag+' denominator')
        check(chart['infinity_variables']==[i+2 for i,c in enumerate(tag) if c=='I'], 'chart_metadata', word+tag+' infinity')
        computed=[[chart_poly(Hs[word][i][j],tag) for j in range(8)] for i in range(8)]
        for i in range(8):
            check(computed[i][i][1]=={}, 'chart_diagonal_reality', word+tag+str(i))
        check(read_terms(chart['P00'])==computed[0][0][0], 'chart_P00', word+tag)
        equations=[]
        for i in range(8):
            for j in range(i+1,8):
                for kind,index in [('re',0),('im',1)]: equations.append((kind,[i,j],computed[i][j][index]))
        for i in range(1,8): equations.append(('diagonal_difference',[i,i],ladd(computed[i][i][0],lscale(computed[0][0][0],-1))))
        check(len(chart['scalar_gram_equations'])==63, 'chart_metadata', word+tag+' count')
        for eq,(kind,ij,terms) in zip(chart['scalar_gram_equations'],equations):
            check(eq['kind']==kind and eq['entry']==ij and read_terms(eq['terms'])==terms, 'full_chart_equations', word+tag+kind+str(ij))
        # All coefficient indices must obey declared active degrees.
        check(all(0<=a<=(4 if tag[0]=='F' else 0) and 0<=b<=(8 if tag[1]=='F' else 0) for row in computed for parts in row for p in parts for a,b in p), 'chart_degree_bounds', word+tag)
print('PASS: all 1,512 real chart equations, 24 P00 polynomials, and direct source infinity charts.', flush=True)

# Fresh Gaussian-rational controls, including unequal active phases.
# These controls do not prove the continuum exclusion; the strict bounds do.
def eval_laurent(p,zz,vv):
    return S.cancel(sum(c*zz**a*vv**b for (a,b),c in p.items()))
def eval_poly(p,tt,ss):
    return sum(S.Integer(c)*tt**a*ss**b for (a,b),c in p.items())
controls=[(S.Rational(2,3),S.Rational(-4,5)),(S.Rational(-5,7),S.Rational(3,2)),(S.Integer(0),S.Integer(1))]
for tt,ss in controls:
    zz=S.cancel((1+S.I*tt)/(1-S.I*tt)); vv=S.cancel((1+S.I*ss)/(1-S.I*ss))
    numeric=source_factors(zz,vv)
    for word in WORDS:
        B=norm(numeric[0][word[0]]*numeric[1][word[1]]*numeric[2][word[2]])
        G=norm(B.conjugate().T*B)
        D=data['words'][word]['D']
        for i in range(8):
            for j in range(8):
                check(S.cancel(G[i,j]*D*D-eval_laurent(Hs[word][i][j],zz,vv))==0, 'rational_control_entries', word+str((tt,ss,i,j)))
        P=data['words'][word]['charts']['FF']['P00']
        check(S.cancel(G[0,0]*D*D*(1+tt*tt)**2*(1+ss*ss)**4-eval_poly(read_terms(P),tt,ss))==0, 'rational_chart_controls', word+str((tt,ss)))
print('PASS: 18 full-matrix Gaussian-rational controls with independent phase values.', flush=True)

# Candidate authored check count is provenance, not an independently reproduced
# counting convention. Coverage is verified by the audit's own counters.
check(COUNTS['full_laurent_entries']==384, 'coverage', 'Laurent count')
check(COUNTS['full_chart_equations']==1512, 'coverage', 'chart equation count')
check(COUNTS['source_chart_gram_entries']==1536, 'coverage', 'all source chart entries')
check(COUNTS['rational_control_entries']==1152, 'coverage', 'full rational controls')
result={
 'status':'ACCEPT within pinned two-active-independent-unit-phase family; no repair required',
 'input_archive':INPUT.name, 'input_bytes':len(raw), 'input_sha256':SHA,
 'word_count':6, 'active_unit_phases':2, 'nominal_inert_phase':'w1',
 'certificates':certificates, 'check_counts':dict(sorted(COUNTS.items())),
 'total_checks':sum(COUNTS.values()),
 'producer_or_historical_programs_executed':False,
 'fresh_method':'Direct exact rational-function inversions from literal weighted cycles; independent Laurent multiplication; Gaussian polynomial denominator clearing; direct source infinity substitutions; full Gaussian-rational controls.',
 'python':sys.version, 'sympy':S.__version__, 'platform':platform.platform(),
 'wall_seconds':time.perf_counter()-START,
 'user_cpu_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime,
 'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 'cpu_limit_seconds':240,'address_space_limit_bytes':2*1024**3,
 'external_wall_limit_seconds':300,
 'randomness':False,'floating_point_comparisons':False,'network_calls':False,
 'sheet_or_github_writes':False,
 'boundary':'Only the six fixed words, three literal cycles/weights and identity effective separators. No arbitrary-phase classification, new phase on M1, novelty, Fourier/FFT or runtime theorem.'
}
(BASE/'INDEPENDENT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
