"""Fresh malformed-field, closed-graph binding, and source-mutation controls."""
from review import *

def reject(fn,label,huge_width=None,before_preparation=False):
    count=len(TraceLedger.instances)
    old=P.CompositionLedger; P.CompositionLedger=TraceLedger
    try:
        try: fn()
        except (ValueError,TypeError) as error: check(True,'rejected_'+label)
        else: raise AssertionError('Not rejected: '+label)
    finally: P.CompositionLedger=old
    if len(TraceLedger.instances)>count:
        ledger=TraceLedger.instances[-1]; ledger.reconstruct()
        if huge_width is not None: check(ledger.max_integer_bits>=huge_width,'actual_malformed_width')
        if before_preparation: check(ledger.operations.get('bucket_engine_constructor',0)==0,'early_rejection_no_preparation')

def malformed_suite():
    spec=WindowSpec(64,4,1,8); source=source_case(64,'zero'); loc=((1,0),); est=((3,7),)
    default=dict(spec=spec,source=source,q=1,location_schedule=loc,estimation_schedule=est)
    tests=[]
    class IntChild(int): pass
    class TupleChild(tuple): pass
    class SpecChild(WindowSpec): pass
    class SourceChild(DyadicSource): pass
    fields=[('spec',None),('spec',SpecChild(64,4,1,8)),('spec',replace(spec,M=True)),
      ('spec',replace(spec,B=IntChild(4))),('spec',replace(spec,M=63)),('spec',replace(spec,B=8)),
      ('spec',replace(spec,r=0)),('spec',replace(spec,P=7)),('spec',replace(spec,beta=0.2)),
      ('source',None),('source',SourceChild(source.values,0)),('source',DyadicSource(list(source.values),0)),
      ('source',DyadicSource(source.values[:-1],0)),('source',DyadicSource(source.values,True)),
      ('source',DyadicSource(source.values,-1)),('q',True),('q',IntChild(1)),('q',-1),('q',5),
      ('location_schedule',[]),('location_schedule',()),('location_schedule',TupleChild(loc)),
      ('location_schedule',((1,),)),('location_schedule',([1,0],)),('location_schedule',((1,0,2),)),
      ('location_schedule',((0,0),)),('location_schedule',((2,0),)),('location_schedule',((65,0),)),
      ('location_schedule',((1,-1),)),('location_schedule',((1,64),)),('location_schedule',((True,0),)),
      ('location_schedule',((1,False),)),('estimation_schedule',[]),('estimation_schedule',()),
      ('estimation_schedule',((1,0),(3,2))),('estimation_schedule',((3,7),(1,0),(5,'x')))]
    for n,(key,val) in enumerate(fields):
        args={**default,key:val}; reject(lambda args=args:P.run_pipeline(**args),str(n)+'_'+key,before_preparation=True)
    H=1<<16384
    for key,val in [('q',H),('spec',replace(spec,P=-H)),('spec',replace(spec,beta=F(1,H+1))),('source',DyadicSource(source.values,-H)),
      ('location_schedule',((1,0),(H,0))),('estimation_schedule',((3,H),))]:
        args={**default,key:val}; reject(lambda args=args:P.run_pipeline(**args),'wide_'+key,16385,True)
    for n,sample in enumerate([[],((0,0),),([0,0],(0,0)),((True,0),(0,0)),((0,True),(0,0)),
      ((0,-1),(0,0)),((0,1),(0,0)),((2,0),(0,0)),((H,0),(0,0)),((0,H),(0,0))]):
        values=list(source.values); values[33]=sample
        args={**default,'source':DyadicSource(tuple(values),0)}
        reject(lambda args=args:P.run_pipeline(**args),'sample_'+str(n),16385 if n>=8 else None)
    values=list(source.values); values[31]=((0,0),(-H,0))
    reject(lambda:P.run_pipeline(spec,DyadicSource(tuple(values),0),1,loc,est),'last_sample_second_coordinate',16385)
    check(TraceLedger.instances[-1].operations['source_query']==spec.W,'late_rejection_complete_query_prefix')
    for key in ['ledger','engine','candidates','bucket_rows','estimate_rows','prepared','callback']:
        reject(lambda key=key:P.run_pipeline(**default,**{key:None}),'public_'+key)
    # Unsampled data is deliberately outside the validated representation
    # contract, rather than a secretly claimed dense validation pass.
    vals=list(source.values); vals[32]=['invalid-unsampled']
    out=P.run_pipeline(spec,DyadicSource(tuple(vals),0),0,((1,0),),((1,0),))
    check(out.output.pairs==(),'unsampled_domain_boundary')
    return len(fields)+6+10+1+7

def gate_suite():
    spec=WindowSpec(64,4,1,8); source=source_case(64,'mixed')
    saved=[]; saved_est=[]; real_produce=P._produce; real_read=P._read_estimates
    def capture(*args):
        bound=real_produce(*args); saved.append(bound); return bound
    def capture_est(*args): saved_est.append(args[1]); return real_read(*args)
    P._produce=capture; P._read_estimates=capture_est
    try: run=P.run_pipeline(spec,source,1,((1,0),(3,7)),((5,9),(17,4),(1,0)))
    finally: P._produce=real_produce;P._read_estimates=real_read
    context=saved[0].context; bound=saved[0]; L=TraceLedger()
    check(P._read_buckets(context,bound,0,0,L) is bound.result,'actual_bucket_object_forward')
    alternates=[replace(bound,context=replace(context)),replace(bound,capability=object()),
      replace(bound,spec=replace(spec)),replace(bound,source=replace(source)),
      replace(bound,affine=tuple(list(bound.affine))),replace(bound,role=1),replace(bound,ordinal=1),
      replace(bound,result=()),replace(bound,result=replace(bound.result,bits=spec.P+1)),
      replace(bound,result=replace(bound.result,bits=True)),replace(bound,role=True),replace(bound,ordinal=False)]
    for n,bad in enumerate(alternates): reject(lambda bad=bad:P._read_buckets(context,bad,0,0,L),'bucket_gate_'+str(n))
    for role,ordinal in [(2,0),(0,-1),(0,2),(True,0),(0,False),(0,1<<16384)]:
        reject(lambda role=role,ordinal=ordinal:P._read_buckets(context,bound,role,ordinal,L),'request_gate_'+str(role)+'_'+str(type(ordinal)))
    eb=saved_est[0]
    check(P._read_estimates(context,eb,0,run.candidates,L) is eb.result,'actual_estimate_object_forward')
    alts=[replace(eb,context=replace(context)),replace(eb,capability=object()),
      replace(eb,candidates=tuple(list(run.candidates))),replace(eb,candidates=tuple(reversed(run.candidates))),
      replace(eb,ordinal=1),replace(eb,ordinal=True),replace(eb,buckets=saved[0]),
      replace(eb,result=()),replace(eb,result=replace(eb.result,bits=spec.P+1)),
      replace(eb,result=replace(eb.result,bits=False))]
    for n,bad in enumerate(alts): reject(lambda bad=bad:P._read_estimates(context,bad,0,run.candidates,L),'estimate_gate_'+str(n))
    L.reconstruct()
    return len(alternates)+6+len(alts)

def load_mutant(old,new,name):
    text=(CAND/'src/pipeline.py').read_text(); check(text.count(old)==1,'mutation_unique_anchor')
    text=text.replace(old,new)
    mod=types.ModuleType('independent_mutant_'+name); mod.__file__=name+'_pipeline.py'; sys.modules[mod.__name__]=mod
    exec(compile(text,mod.__file__,'exec'),mod.__dict__)
    return mod

def mutation_suite():
    # Scientific mutations run on a mixed full-support fixture, except decode,
    # which uses partial support. An independently computed exact pipeline
    # output is used, not a producer expected-output receipt.
    spec=WindowSpec(64,4,1,12); src=source_case(64,'mixed')
    loc=((3,5),(17,29),(63,63)); est=((5,11),(21,33),(45,17))
    baselines={q:oracle_pipeline(spec,src,q,loc,est) for q in (1,4)}
    mutations=[
      ('bucket_sigma','actual = engine.run(context.source, sigma, tau)','actual = engine.run(context.source, 1, tau)',4),
      ('bucket_tau','actual = engine.run(context.source, sigma, tau)','actual = engine.run(context.source, sigma, 0)',4),
      ('location_sigma','decoded = decode_round(spec.M, spec.B, q, sigma,','decoded = decode_round(spec.M, spec.B, q, 1,',1),
      ('estimate_sigma','estimated = estimate_round(spec.M, spec.B, spec.P, candidates, sigma, tau,','estimated = estimate_round(spec.M, spec.B, spec.P, candidates, 1, tau,',4),
      ('estimate_tau','estimated = estimate_round(spec.M, spec.B, spec.P, candidates, sigma, tau,','estimated = estimate_round(spec.M, spec.B, spec.P, candidates, sigma, 0,',4),
      ('candidate_column','row = bound.result','row = EstimateResult(tuple(reversed(bound.result.numerators)), bound.result.bits)',4),
      ('preparation_ledger','engine = BucketEngine(spec, L)','engine = BucketEngine(spec)',1),
      ('location_ledger','buckets.numerators, buckets.bits, L)\n        memberships','buckets.numerators, buckets.bits)\n        memberships',1),
      ('estimate_ledger','buckets.numerators, buckets.bits, L)\n        bound_estimate','buckets.numerators, buckets.bits)\n        bound_estimate',1),
      ('median_ledger','output = cartesian_medians(spec.M, spec.P, candidates, tuple(rows), L)','output = cartesian_medians(spec.M, spec.P, candidates, tuple(rows))',1),
      ('membership_copy','L.event(\'membership_tuple_copy\', nl)','L.event(\'membership_tuple_copy\', 0)',1),
      ('estimate_copy','L.event(\'estimate_tuple_copy\', ne)','L.event(\'estimate_tuple_copy\', 0)',1),
      ('trace_copy','L.event(\'trace_tuple_copy\', L.add(nl, ne))','L.event(\'trace_tuple_copy\', 0)',1),
      ('glue_allocation','L.allocate(9)','L.allocate(0)',1)]
    caught=[]
    for name,old,new,q in mutations:
        mod=load_mutant(old,new,name)
        try: verify_fixture('mutant_'+name,spec,src,q,loc,est,mod,True)
        except AssertionError as e: caught.append(dict(name=name,detected_by=str(e)))
        else: raise AssertionError('Surviving mutant: '+name)
    # Tamper each internal binding check and demonstrate the previously
    # rejected mismatched binding is accepted. This measures test sensitivity,
    # not a security contract for private object mutation.
    gates=[('source_gate','or bound.source is not context.source','or False','source'),
      ('spec_gate','or bound.spec is not context.spec','or False','spec'),
      ('affine_gate','or bound.affine is not schedule[ordinal]','or False','affine'),
      ('candidate_gate','or bound.candidates is not candidates','or False','candidates')]
    for name,old,new,field in gates:
        mod=load_mutant(old,new,name); s=WindowSpec(64,4,1,8); source=source_case(64,'zero')
        context=mod._Context(s,source,((1,0),),((3,7),),object()); affine=context.location[0]
        bucket=BucketResult(tuple((0,0) for _ in range(4)),8)
        if field=='candidates':
            cc=(0,1); bb=mod._BoundBuckets(context,context.capability,1,0,context.estimation[0],s,source,bucket)
            row=EstimateResult(((0,0),(0,0)),8); be=mod._BoundEstimates(context,context.capability,0,tuple(reversed(cc)),bb,row)
            check(mod._read_estimates(context,be,0,cc,TraceLedger()) is row,'disabled_gate_witness')
        else:
            bb=mod._BoundBuckets(context,context.capability,0,0,affine,s,source,bucket)
            replacement={'source':replace(source),'spec':replace(s),'affine':tuple(list(affine))}[field]
            check(mod._read_buckets(context,replace(bb,**{field:replacement}),0,0,TraceLedger()) is bucket,'disabled_gate_witness')
        caught.append(dict(name=name,detected_by='Previously rejected binding accepted after disabling its check'))
    return caught

if __name__=='__main__':
    rejected=malformed_suite(); print('PASS malformed',rejected,flush=True)
    gates=gate_suite(); print('PASS gates',gates,flush=True)
    mutations=mutation_suite(); print('PASS mutants',len(mutations),flush=True)
    for ledger in TraceLedger.instances: ledger.reconstruct()
    result=dict(malformed_rejections=rejected,gate_rejections=gates,mutants=mutations,counts=COUNTS,
      ledger_instances=len(TraceLedger.instances),primitive_records=sum(len(x.rows) for x in TraceLedger.instances),
      report_snapshots=sum(x.reports for x in TraceLedger.instances))
    (OUT/'adversarial_summary.json').write_text(json.dumps(result,indent=2))
