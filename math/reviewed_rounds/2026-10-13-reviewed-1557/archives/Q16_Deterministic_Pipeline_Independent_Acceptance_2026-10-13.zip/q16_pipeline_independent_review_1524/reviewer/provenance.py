"""Read-only independent seal/source/evidence checks; no scientific imports."""
from pathlib import Path
import hashlib,json,zipfile,ast
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'evidence'
CAND=ROOT/'candidate/q16_deterministic_pipeline_20261013'
def sha(b):return hashlib.sha256(b).hexdigest()
archive=WORK/'Q16_Deterministic_Pipeline_Integration_Candidate_2026-10-13.zip'
assert sha(archive.read_bytes())=='ffc70c8d7896057b8241e0b7d3cd99affc78c4a8ac514c5da9110638ec85b596'
items=[
('Q16_Certified_Compact_Window_v2_Independent_Acceptance_2026-10-13.zip','q16_window_v2_independent_audit_20261013/REVIEW_VERDICT.json','WINDOW','compact_window.py'),
('Q16_Certified_BUCKETS_Independent_Acceptance_2026-10-13.zip','q16_buckets_independent_audit_20261013/VERDICT.json','BUCKETS','buckets.py'),
('q16_review/Q16_Location_Decoder_Independent_Acceptance_2026-10-13.zip','q16_location_independent_review_20261013/VERDICT.json','LOCATION','location_decode.py'),
('Q16_Certified_Phase_Medians_Independent_Acceptance_2026-10-13.zip','VERDICT.json','PHASE_MEDIANS','phase_medians.py')]
rows=[]
for name,entry,label,module in items:
    p=WORK/name
    with zipfile.ZipFile(p) as z:
        raw=z.read(entry);v=json.loads(raw)
        assert raw==(CAND/'sources'/f'{label}_VERDICT.json').read_bytes()
        assert v['overall']=='ACCEPT'
        sourcehash=sha((CAND/'src'/module).read_bytes())
        assert v['production_source_sha256']==sourcehash
        matches=[x for x in z.namelist() if x.endswith('/'+module)]
        for x in matches: assert sha(z.read(x))==sourcehash
        rows.append(dict(archive=name,archive_sha256=sha(p.read_bytes()),verdict_entry=entry,
          verdict_sha256=sha(raw),module=module,module_sha256=sourcehash,matching_embedded_source_count=len(matches)))
assert rows[-1]['archive_sha256']=='8a1719a2c1f187a9aa31aa0f84584f9cde1f368ddd7697a7704f43a3e1f1ab5a'
source=(CAND/'src/pipeline.py').read_text(); tree=ast.parse(source)
calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call)]
names=[n.func.id for n in calls if isinstance(n.func,ast.Name)]
for forbidden in ['eval','exec','open','compile','input','__import__']: assert forbidden not in names
imports=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
assert imports==['dataclasses','compact_window','buckets','location_decode','phase_medians']
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_pipeline')
assert [x.arg for x in run.args.args]==['spec','source','q','location_schedule','estimation_schedule']
assert run.args.vararg is None and run.args.kwarg is None and not run.args.kwonlyargs
assert names.count('CompositionLedger')==1 and names.count('BucketEngine')==1
result=dict(candidate_archive_sha256=sha(archive.read_bytes()),dependencies=rows,
  public_arguments=[x.arg for x in run.args.args],imports=imports,
  no_dynamic_execution_io_or_random_import=True,one_closed_ledger_and_constructor=True,
  historical_sources_used_as_inert_text_only=True,producer_tests_executed=False)
(ROOT/'results/provenance.json').write_text(json.dumps(result,indent=2))
print('PASS sealed candidate, four external accepted-review bindings, closed API static audit')
