"""Fresh independent review of the sealed bounded Q16 integration.

Runs no producer tests and no historical scientific executable. Standard library.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from functools import lru_cache
from math import factorial, isqrt
from dataclasses import replace
import hashlib, json, sys, types, inspect, zipfile

ROOT = Path(__file__).resolve().parents[1]
CAND = ROOT / 'candidate/q16_deterministic_pipeline_20261013'
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
COUNTS = Counter()
def check(condition, label):
    COUNTS[label] += 1
    if not condition:
        raise AssertionError(label)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def verify_bytes():
    seal = json.loads((CAND/'SEAL.json').read_text())
    check(digest(CAND/'MANIFEST.json') == seal['manifest_sha256'], 'manifest_seal')
    manifest = json.loads((CAND/'MANIFEST.json').read_text())
    for row in manifest['files']:
        p = CAND / row['path']
        check(p.stat().st_size == row['bytes'] and digest(p) == row['sha256'], 'sealed_file')
    for module, expected in manifest['accepted_source_pins'].items():
        check(digest(CAND/'src'/module) == expected, 'dependency_source_pin')
    check(digest(CAND/'src/pipeline.py') == 'c3a2da5a11ceba2cfa0df7bbb346525013e740e7bc170b3d27dfadc3f2be4d3b', 'pipeline_pin')
    check('n_l[m+' in (CAND/'RESOURCE_LEDGER.md').read_text(), 'corrected_euclid_term')
    check('2(n_l+n_e)' in (CAND/'RESOURCE_LEDGER.md').read_text(), 'corrected_tuple_term')
verify_bytes()
sys.path.insert(0, str(CAND/'src'))
import pipeline as P
from compact_window import WindowSpec, Ledger
from buckets import DyadicSource, BucketResult
from phase_medians import EstimateResult

# Bounded rational interval arithmetic, deliberately independent of the
# production fixed-point interval algorithms. All interval operations round
# outwards to a 144-bit dyadic grid; exact point input remains rational.
D = 1 << 144
def floor(x): return x.numerator // x.denominator
def ceil(x): return -((-x.numerator) // x.denominator)
def iv(a, b=None):
    a, b = F(a), F(a if b is None else b)
    return (F(floor(a*D), D), F(ceil(b*D), D))
def plus(a,b): return iv(a[0]+b[0], a[1]+b[1])
def minus(a,b): return iv(a[0]-b[1], a[1]-b[0])
def times(a,b):
    vals=[x*y for x in a for y in b]
    return iv(min(vals), max(vals))
def over(a,b):
    assert not b[0] <= 0 <= b[1]
    return times(a, iv(1/b[1], 1/b[0]))
def cxplus(a,b): return plus(a[0],b[0]), plus(a[1],b[1])
def cxtimes(a,b): return minus(times(a[0],b[0]),times(a[1],b[1])), plus(times(a[0],b[1]),times(a[1],b[0]))
ZERO = (iv(0),iv(0))
def cpoint(a,b=0): return iv(a),iv(b)

def atan_bounds(q, n=240):
    s=sum((F((-1)**k, (2*k+1)*q**(2*k+1)) for k in range(n)), F())
    t=F((-1)**n, (2*n+1)*q**(2*n+1))
    return min(s,s+t), max(s,s+t)
a,b=atan_bounds(2),atan_bounds(3)
PI=iv(4*(a[0]+b[0]),4*(a[1]+b[1]))  # atan(1/2)+atan(1/3)=pi/4.
check(PI[1]-PI[0] <= F(2,D), 'independent_pi_width')

@lru_cache(None)
def root(n,modulus):
    n %= modulus
    if 4*n % modulus == 0:
        k=(4*n//modulus)%4
        return cpoint((1,0,-1,0)[k],(0,1,0,-1)[k])
    if n*2 > modulus: n -= modulus
    angle=times(PI,iv(F(2*n,modulus)))
    x=(angle[0]+angle[1])/2
    uncertainty=(angle[1]-angle[0])/2
    N=88
    # Each exact rational Taylor monomial is independently rounded outward.
    # This avoids an enormous common rational denominator in the sum, while
    # retaining every rounding interval rather than assuming numerical floats.
    sin=iv(0); cos=iv(0)
    for k in range(N):
        sin=plus(sin,iv((-1)**k*x**(2*k+1)/factorial(2*k+1)))
        cos=plus(cos,iv((-1)**k*x**(2*k)/factorial(2*k)))
    se=abs(x)**(2*N+1)/factorial(2*N+1)+uncertainty
    ce=abs(x)**(2*N)/factorial(2*N)+uncertainty
    return iv(cos[0]-ce,cos[1]+ce),iv(sin[0]-se,sin[1]+se)

def nearest(x):
    a=floor(x); r=x-a
    return a if r<F(1,2) or (r==F(1,2) and a%2==0) else a+1
def unique_round(a,bits):
    r=nearest(a[0]*(1<<bits))
    check(r==nearest(a[1]*(1<<bits)), 'unambiguous_oracle_rounding')
    return r
def exact_cmul(a,b): return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def exact_cadd(a,b): return a[0]+b[0],a[1]+b[1]

@lru_cache(None)
def window_oracle(M,B,r,Pbits):
    ell=8*B; radius=r*(ell-1); T=M//B; H=3*T//4; g=T//4
    coeff=[1]
    for _ in range(2*r):
        new=[0]*(len(coeff)+ell-1)
        for j,x in enumerate(coeff):
            for k in range(ell): new[j+k]+=x
        coeff=new
    coeff=tuple(F(c,ell**(2*r)) for c in coeff)
    # Spectral polynomial evaluation, instead of a sine quotient.
    C=iv(0)
    for j in range(-g,g+1):
        value=iv(0)
        for t in range(-radius,radius+1):
            value=plus(value,times(iv(coeff[t+radius]),root(j*t,M)[0]))
        C=plus(C,value)
    check(C[0]>0,'normalizer_positive')
    taps=[]; ideal=[]
    for t in range(-radius,radius+1):
        dh=iv(0)
        for j in range(-H,H+1): dh=plus(dh,root(j*t,M)[0])
        w=over(times(iv(M*coeff[t+radius]),dh),C)
        ideal.append((t,w)); taps.append((t,F(unique_round(w,Pbits),1<<Pbits)))
    s=isqrt((D*D)//M)
    scale=iv(F(s,D),F(s if s*s*M==D*D else s+1,D))
    scale_q=F(unique_round(scale,Pbits+2),1<<(Pbits+2))
    return taps,ideal,scale,scale_q,C

def fft_recursive(values,root_grid):
    n=len(values)
    if n==1: return values
    evens=fft_recursive(values[::2],root_grid)
    odds=fft_recursive(values[1::2],root_grid)
    result=[None]*n
    for j in range(n//2):
        z=exact_cmul(odds[j],root_grid(j,n))
        result[j]=exact_cadd(evens[j],z)
        result[j+n//2]=(evens[j][0]-z[0],evens[j][1]-z[1])
    return result

def bucket_oracle(spec, source, sigma,tau):
    M,B,r,p=spec.M,spec.B,spec.r,spec.P
    taps,ideal,scale,scale_q,C=window_oracle(M,B,r,p)
    signal=[(F(a,1<<ae),F(b,1<<be)) for (a,ae),(b,be) in source.values]
    folded=[(F(),F()) for _ in range(B)]
    for t,w in taps:
        v=signal[(sigma*t+tau)%M]
        folded[t%B]=exact_cadd(folded[t%B],(v[0]*w,v[1]*w))
    def rg(j,n): return tuple(F(unique_round(c,p+2),1<<(p+2)) for c in root(-j,n))
    transformed=fft_recursive(folded,rg)
    actual=tuple((nearest(a*scale_q*(1<<p)),nearest(b*scale_q*(1<<p))) for a,b in transformed)
    # Independent direct Fourier sum of the exact supported mathematical window.
    direct=[]
    for j in range(B):
        z=ZERO
        for t,w in ideal:
            a,b=signal[(sigma*t+tau)%M]
            term=cxtimes((times(iv(a),w),times(iv(b),w)),root(-j*t,B))
            z=cxplus(z,term)
        direct.append((times(z[0],scale),times(z[1],scale)))
    return actual,tuple(direct)

def error_upper_squared(pair, expected, p):
    return sum(max(abs(F(x,1<<p)-lo),abs(F(x,1<<p)-hi))**2 for x,(lo,hi) in zip(pair,expected))

def oracle_pipeline(spec,source,q,locations,estimates):
    M,B,p=spec.M,spec.B,spec.P; T=M//B
    selected=[]; members=[]; buckets=[]; exact_buckets=[]
    for sigma,tau in locations:
        vals,ideal=bucket_oracle(spec,source,sigma,tau)
        ranking=sorted(range(B),key=lambda j:(-sum(x*x for x in vals[j]),j))[:q]
        # Exhaustive exact inverse relation, no Euclidean routine or aggregation sort.
        member=tuple(next(i for i in range(M) if sigma*i%M==(j*T-T//2+k)%M) for j in ranking for k in range(T))
        selected.append(tuple(ranking)); members.append(member); buckets.append(vals); exact_buckets.append(ideal)
    threshold=(len(locations)+1)//2
    candidates=tuple(i for i in range(M) if sum(i in ms for ms in members)>=threshold)
    rows=[]; ideal_rows=[]
    for sigma,tau in estimates:
        vals,ideal=bucket_oracle(spec,source,sigma,tau); buckets.append(vals); exact_buckets.append(ideal)
        row=[]; ideal_row=[]
        for i in candidates:
            h=((sigma*i%M+T//2)//T)%B
            phase=root(-tau*i,M)
            phase_q=tuple(F(unique_round(z,p+2),1<<(p+2)) for z in phase)
            prod=exact_cmul(vals[h],phase_q)
            row.append(tuple(nearest(x) for x in prod))
            ideal_row.append(cxtimes(ideal[h],phase))
        rows.append(tuple(row)); ideal_rows.append(tuple(ideal_row))
    midpoint=len(estimates)//2
    output=tuple((i,tuple(sorted(row[col][d] for row in rows)[midpoint] for d in (0,1))) for col,i in enumerate(candidates))
    ideal_median=[]
    for col in range(len(candidates)):
        ideal_median.append(tuple(iv(sorted(row[col][d][0] for row in ideal_rows)[midpoint],sorted(row[col][d][1] for row in ideal_rows)[midpoint]) for d in (0,1)))
    return dict(candidates=candidates,selected=tuple(selected),members=tuple(members),buckets=tuple(buckets),rows=tuple(rows),output=output,ideal_buckets=tuple(exact_buckets),ideal_rows=tuple(ideal_rows),ideal_median=tuple(ideal_median))

def source_case(M,kind):
    if kind=='zero': vals=tuple(((0,0),(0,0)) for _ in range(M)); f=0
    elif kind=='impulse': vals=tuple(((int(i==7),0),(0,0)) for i in range(M)); f=0
    elif kind=='tone': vals=tuple((((1,0,-1,0)[i%4],0),((0,1,0,-1)[i%4],0)) for i in range(M)); f=0
    else:
        f=5
        vals=tuple((((i*i+7*i+3)%65-32,5),((11*i*i+5*i+2)%33-16,4)) for i in range(M))
    return DyadicSource(vals,f)

class TraceLedger(P.CompositionLedger):
    instances=[]
    def __init__(self):
        super().__init__(); self.rows=[]; self.events=Counter(); self.slots=0; self.glue_slots=0; self.params=[]; self.reports=0; self.allocation_calls=0
        self.instances.append(self)
    def record(self,kind,inputs,output):
        self.rows.append((kind,tuple(inputs),output)); return super().record(kind,inputs,output)
    def parameter(self,value):
        if type(value) is int: self.params.append(value)
        return super().parameter(value)
    def event(self,name,count=1): self.events[name]+=count; return super().event(name,count)
    def allocate(self,n):
        self.allocation_calls+=1
        self.slots+=n
        if inspect.currentframe().f_back.f_code.co_filename.endswith('pipeline.py'): self.glue_slots+=n
        return super().allocate(n)
    def report(self):
        r=super().report(); self.reconstruct(r); self.reports+=1; return r
    def reconstruct(self,r=None):
        if r is None: r=super().report()
        counts=self.events.copy(); widths=[]; cost=0; produced=self.slots
        def wid(x): return max(1,len(bin(abs(x)))-2)
        for kind,inputs,out in self.rows:
            if kind=='add': expected=inputs[0]+inputs[1]
            elif kind=='subtract': expected=inputs[0]-inputs[1]
            elif kind=='multiply': expected=inputs[0]*inputs[1]
            elif kind=='floor_divide': expected=inputs[0]//inputs[1]
            elif kind=='modulo': expected=inputs[0]%inputs[1]
            elif kind=='binary_power': expected=2**inputs[0]
            elif kind=='bit_and': expected=inputs[0]&inputs[1]
            elif kind=='bit_length': expected=len(bin(inputs[0]))-2 if inputs[0] else 0
            elif kind=='power_input': expected=1
            else: expected=out
            check(expected==out,'primitive_semantics')
            ws=[wid(x) for x in (*inputs,out)]; widths+=ws
            cost+=16*(2+sum(ws))**2; produced+=ws[-1]+1; counts[kind]+=1
        if self.allocation_calls: counts['allocated_slots']+=self.slots
        E=sum(counts.values())+256; H=max([1]+widths)+len(bin(E))-2+2
        expected=dict(operations=dict(sorted(counts.items())),arithmetic_bit_work_upper=cost,
          bookkeeping_bit_work_upper=512*E*H**2,total_bit_work_upper=cost+512*E*H**2,
          cumulative_storage_upper_bits=produced+512*E*H,max_observed_integer_bits=max([1]+widths),allocated_slots=self.slots,
          parameter_input_bits=sum(wid(x) for x in self.params),max_parameter_bits=max([1]+[wid(x) for x in self.params]))
        for key,val in expected.items(): check(r[key]==val,'ledger_'+key)
        return r

def verify_fixture(name,spec,source,q,loc,est,module=P,traced=True):
    expected=oracle_pipeline(spec,source,q,loc,est)
    original=module.CompositionLedger
    if traced: module.CompositionLedger=TraceLedger
    try: actual=module.run_pipeline(spec,source,q,loc,est)
    finally: module.CompositionLedger=original
    check(actual.candidates==expected['candidates'],'candidate_exact')
    check(actual.output.pairs==expected['output'] and actual.output.bits==spec.P,'output_exact')
    check(tuple(x.selected_buckets for x in actual.location_trace)==expected['selected'],'selected_exact')
    check(tuple(x.memberships for x in actual.location_trace)==expected['members'],'members_exact')
    traces=actual.location_trace+actual.estimation_trace
    check(tuple(x.buckets.numerators for x in traces)==expected['buckets'],'buckets_exact')
    check(tuple(x.estimates.numerators for x in actual.estimation_trace)==expected['rows'],'phase_rows_exact')
    check(all(x.candidates is actual.candidates for x in actual.estimation_trace),'candidate_identity')
    for entries,schedule in ((actual.location_trace,loc),(actual.estimation_trace,est)):
        check(all(row.affine is schedule[j] for j,row in enumerate(entries)),'affine_identity')
    n_l,n_e=len(loc),len(est); K=len(actual.candidates); W=spec.W
    ops=actual.ledger['operations']
    inventory={'bucket_engine_constructor':1,'window_validation_call':n_l+n_e+2,'buckets_call':n_l+n_e,
      'source_query':(n_l+n_e)*W,'sample_alignment':2*(n_l+n_e)*W,'decode_call':n_l,'membership_output':n_l*q*spec.T,
      'aggregation_call':1,'estimate_call':n_e,'phase_preparation':n_e*K,'median_call':1,
      'membership_tuple_copy':n_l,'estimate_tuple_copy':n_e,'trace_tuple_copy':n_l+n_e,
      'bucket_binding_validation':n_l+2*n_e,'estimate_binding_validation':n_e,'fft_root_preparation':spec.B//2,'scale_preparation':1}
    for key,val in inventory.items(): check(ops.get(key,0)==val,'execution_'+key)
    check(K<=min(spec.M,(n_l*q*spec.T)//((n_l+1)//2)),'support_bound')
    if traced:
        tracer=TraceLedger.instances[-1]
        check(tracer.glue_slots==17+18*n_l+25*n_e,'glue_allocation_formula')
        check(tracer.reports==2,'shared_two_report_snapshots')
        check(tracer.reconstruct()==actual.ledger,'cumulative_final_snapshot')
    rho=F(1,1<<spec.P); A=2*spec.M**2; b=spec.B.bit_length()-1
    E=(A+2*W*rho)*(1+rho)**(b+1)-A+rho
    check(F(actual.bucket_error[0],1<<actual.bucket_error[1])==E,'bucket_error_formula')
    eta=(1+rho)*E+A*rho+rho
    for tr,ideal in zip(traces,expected['ideal_buckets']):
        for vals,target in zip(tr.buckets.numerators,ideal): check(error_upper_squared(vals,target,spec.P)<=E*E,'ideal_bucket_error')
    for tr,ideal in zip(actual.estimation_trace,expected['ideal_rows']):
        for vals,target in zip(tr.estimates.numerators,ideal): check(error_upper_squared(vals,target,spec.P)<=eta*eta,'ideal_estimate_error')
    for (_,vals),target in zip(actual.output.pairs,expected['ideal_median']): check(error_upper_squared(vals,target,spec.P)<=2*eta*eta,'ideal_median_error')
    print('PASS fixture',name,'M',spec.M,'B',spec.B,'r',spec.r,'q',q,'K',K,flush=True)
    return dict(name=name,M=spec.M,B=spec.B,r=spec.r,P=spec.P,q=q,n_l=n_l,n_e=n_e,K=K,ledger=actual.ledger), actual, expected

def numerical_suite():
    cases=[('zero_even',64,4,1,8,'zero',1,((1,0),(3,7)),((5,4),)),
      ('mixed_all',64,4,1,12,'mixed',4,((3,5),(17,29),(63,63)),((5,11),(21,33),(45,17))),
      ('mixed_empty',64,4,1,8,'mixed',0,((13,31),),((3,5),(17,7),(29,11),(31,13),(63,63))),
      ('impulse_r2',128,4,2,16,'impulse',2,((3,5),(41,117)),((7,31),(33,9),(127,63))),
      ('mixed_B8',128,8,1,12,'mixed',2,((3,5),(31,67),(65,127)),((5,19),(33,25),(127,93))),
      ('tone_B16',256,16,1,16,'tone',1,((3,5),(127,93)),((5,29),(17,31),(255,253)))]
    result=[]
    for name,M,B,r,p,kind,q,loc,est in cases:
        rec,_,_=verify_fixture(name,WindowSpec(M,B,r,p),source_case(M,kind),q,loc,est)
        result.append(rec)
        (OUT/'fixtures.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    result=numerical_suite()
    (OUT/'numerical_summary.json').write_text(json.dumps(dict(fixtures=result,counts=COUNTS,
      ledger_instances=len(TraceLedger.instances),primitive_records=sum(len(x.rows) for x in TraceLedger.instances),
      report_snapshots=sum(x.reports for x in TraceLedger.instances)),indent=2))
