# Q16 deterministic pipeline independent acceptance

Decision: ACCEPT within the exact bounded deterministic scope in REVIEW.md.
The source integration hash is
c3a2da5a11ceba2cfa0df7bbb346525013e740e7bc170b3d27dfadc3f2be4d3b.

## Contents

- REVIEW.md: independent decision, proof, accounting and limits
- VERDICT.json: source bindings and completed independent totals
- reviewer/: newly authored standard-library review programs
- results/: completed final execution receipts
- candidate/: byte-identical extracted candidate, including its inert evidence
- evidence/: original candidate and four accepted-review archives, used only as data
- MANIFEST.json and SEAL.json: this review's file seal
- verify_review.py: this review's simple read-only seal verifier

## Reproduction

Use Python 3.12 or later and its standard library. No external numerical
package, browser, network, credentials or producer test runner is needed.
In an unpacked review directory:

    python verify_review.py

Run the scientific checks from a disposable copy, because their result
receipts are overwritten by the reproduction:

    PYTHONDONTWRITEBYTECODE=1 python reviewer/provenance.py
    PYTHONDONTWRITEBYTECODE=1 python reviewer/review.py
    PYTHONDONTWRITEBYTECODE=1 python reviewer/adversarial.py

The reviewer programs execute only the five inspected current modules in the
extracted candidate and fresh reviewer code. The adversarial suite also
executes temporary in-memory mutations of the new integration source.
It never alters the candidate source. Do not run the producer's test scripts
or any executable inside the evidence archives as part of this reproduction.

The rational oracle intentionally prioritizes exact checks over speed. It
does not measure production wall time. The completed fixtures cover only
the reduced deterministic component domain; the package makes no full
E(beta), random-success, dense-fallback or all-length executable claim.

All newly authored review programs and the archived results were inspected
after the final completed run. The reviewer made no Sheet or GitHub changes.
