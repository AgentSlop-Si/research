"""Fresh finite mutations of the integration glue; dependencies are unchanged."""
import importlib.util
import json
from dataclasses import replace
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
import pipeline as p
from compact_window import WindowSpec
from buckets import DyadicSource


def load_mutant(name, old, new):
    text = (ROOT/'src/pipeline.py').read_text()
    assert text.count(old) == 1, (name,text.count(old))
    m = types.ModuleType('q16_mutant_'+name)
    sys.modules[m.__name__] = m
    exec(compile(text.replace(old,new), '<fresh integration mutant '+name+'>','exec'),m.__dict__)
    return m


def numeric(run):
    return (run.output,run.candidates,
            tuple((r.affine,r.buckets,r.selected_buckets,r.memberships) for r in run.location_trace),
            tuple((r.affine,r.buckets,r.candidates,r.estimates) for r in run.estimation_trace))


def main():
    s = WindowSpec(64,4,1,12)
    v = DyadicSource(tuple((((i%5)-2,2),((i%3)-1,1)) for i in range(64)),2)
    loc=((1,0),(3,7),(63,63))
    est=((5,9),(17,4),(1,0))
    args=(s,v,1,loc,est)
    baseline=p.run_pipeline(*args)
    mutations=[
      ('bucket_tau_detached','actual = engine.run(context.source, sigma, tau)',
       'actual = engine.run(context.source, sigma, 0)'),
      ('bucket_sigma_detached','actual = engine.run(context.source, sigma, tau)',
       'actual = engine.run(context.source, 1, tau)'),
      ('location_sigma_detached','q, sigma,\n                               buckets.numerators',
       'q, 1,\n                               buckets.numerators'),
      ('estimation_tau_detached','candidates, sigma, tau,\n                                   buckets.numerators',
       'candidates, sigma, 0,\n                                   buckets.numerators'),
      ('estimation_sigma_detached','candidates, sigma, tau,\n                                   buckets.numerators',
       'candidates, 1, tau,\n                                   buckets.numerators'),
      ('candidate_columns_reordered','rows.append(_read_estimates(context, bound_estimate, ordinal, candidates, L))',
       'rows.append(EstimateResult(tuple(reversed(estimated.numerators)), estimated.bits))'),
      ('preparation_cost_detached','engine = BucketEngine(spec, L)',
       'engine = BucketEngine(spec)'),
      ('location_cost_detached','buckets.numerators, buckets.bits, L)\n        memberships',
       'buckets.numerators, buckets.bits)\n        memberships'),
      ('estimation_cost_detached','buckets.numerators, buckets.bits, L)\n        bound_estimate',
       'buckets.numerators, buckets.bits)\n        bound_estimate'),
      ('median_cost_detached','candidates, tuple(rows), L)',
       'candidates, tuple(rows))'),
      ('tuple_movement_uncharged',"L.event('trace_tuple_copy', L.add(nl, ne))",
       "L.event('omitted_trace_copy')"),
    ]
    results=[]
    for name, old, new in mutations:
        m=load_mutant(name,old,new)
        r=m.run_pipeline(*args)
        caught_numeric=numeric(r)!=numeric(baseline)
        caught_account=r.ledger['operations']!=baseline.ledger['operations']
        assert caught_numeric or caught_account, name
        # Numerical mutations must actually change scientific results, rather
        # than being counted as caught only because a ledger counter changed.
        if name in [x[0] for x in mutations[:6]]:
            assert caught_numeric,name
        results.append({'name':name,'detected_by':'scientific comparison' if caught_numeric else 'event/accounting comparison'})
    # Provenance checks have direct negative controls independent of numerics.
    m=load_mutant('skip_candidate_identity','or bound.candidates is not candidates','or False')
    ctx=m._Context(s,v,loc,est,object())
    b=m._BoundBuckets(ctx,ctx.capability,1,0,est[0],s,v,baseline.estimation_trace[0].buckets)
    row=m._BoundEstimates(ctx,ctx.capability,0,tuple(reversed(baseline.candidates)),b,
                          baseline.estimation_trace[0].estimates)
    # A gate incorrectly accepting this wrong-order row is the mutation witness.
    assert m._read_estimates(ctx,row,0,baseline.candidates,m.CompositionLedger()) is row.result
    results.append({'name':'skip_candidate_identity','detected_by':'negative provenance gate expectation'})
    for name,old,new,field,value in [
      ('skip_source_identity','or bound.source is not context.source','or False','source',DyadicSource(v.values,2)),
      ('skip_spec_identity','or bound.spec is not context.spec','or False','spec',WindowSpec(64,4,1,12)),
      ('skip_schedule_identity','or bound.affine is not schedule[ordinal]','or False','affine',tuple([1,0])),
    ]:
        m=load_mutant(name,old,new)
        ctx=m._Context(s,v,loc,est,object())
        b=m._BoundBuckets(ctx,ctx.capability,0,0,loc[0],s,v,baseline.location_trace[0].buckets)
        bad=replace(b,**{field:value})
        assert m._read_buckets(ctx,bad,0,0,m.CompositionLedger()) is bad.result
        results.append({'name':name,'detected_by':'negative provenance gate expectation'})
    record={'status':'PASS','mutants_detected':len(results),'mutations':results,
            'frozen_sources_modified':False,'inherited_test_code_executed':False,
            'scope':'Only freshly authored integration glue mutated in memory; no dependency mutant or historic code.'}
    (ROOT/'results/mutation_controls.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    main()
