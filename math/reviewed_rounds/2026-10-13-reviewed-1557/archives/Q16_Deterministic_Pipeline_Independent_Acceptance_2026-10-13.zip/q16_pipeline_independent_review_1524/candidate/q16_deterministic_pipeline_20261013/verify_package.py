"""Verify this portable candidate's seal without executing scientific code."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest_bytes = (ROOT/'MANIFEST.json').read_bytes()
manifest = json.loads(manifest_bytes)
seal = json.loads((ROOT/'SEAL.json').read_text())
assert hashlib.sha256(manifest_bytes).hexdigest() == seal['manifest_sha256']
seen = set()
for item in manifest['files']:
    relative = item['path']
    assert relative not in seen
    seen.add(relative)
    path = Path(relative)
    assert not path.is_absolute() and '..' not in path.parts
    body = (ROOT/path).read_bytes()
    assert len(body) == item['bytes'], relative
    assert hashlib.sha256(body).hexdigest() == item['sha256'], relative
for name, digest in manifest['accepted_source_pins'].items():
    assert hashlib.sha256((ROOT/'src'/name).read_bytes()).hexdigest() == digest
for receipt in ('composition_controls.json','mutation_controls.json','oracle_results.json'):
    assert json.loads((ROOT/'results'/receipt).read_text())['status'] == 'PASS'
assert json.loads((ROOT/'PROOF_LEDGER.json').read_text())['status'] == 'CANDIDATE_AWAITING_INDEPENDENT_REVIEW'
print(json.dumps({'status':'PASS','verified_files':len(seen),
                  'manifest_sha256':seal['manifest_sha256'],
                  'scope':seal['scope']},indent=2))
