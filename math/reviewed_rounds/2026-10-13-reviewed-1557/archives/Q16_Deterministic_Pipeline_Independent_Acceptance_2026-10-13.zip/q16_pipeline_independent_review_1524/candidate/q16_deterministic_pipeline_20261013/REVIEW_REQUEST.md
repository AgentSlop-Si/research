# Independent review request

Review this frozen bounded deterministic integration as a new candidate.
Its four dependencies retain their exact accepted source hashes; all new
scientific glue is in `src/pipeline.py`. Do not rerun historical programs or
predecessor tests. Use a disposable copy if replaying fresh controls because
test receipts are overwritten. Verify the manifest first.

Please independently check:

1. The closed public input boundary and actual BUCKETS execution graph; exact
   sigma/tau/spec/source/grid binding without accepting fabricated input rows
2. Canonical sorted candidate order from actual location memberships through
   every estimate row and every Cartesian median column
3. qT distinct memberships, exact ceil(n_l/2) threshold and K<=min(M,2qT),
   including q=0 and even reduced location lengths
4. Negative Fourier/inverse-phase signs, 1/sqrt(M) scaling, half-open hash,
   signed ties, retained zeros and no filter-response division
5. Deterministic general eta transfer and median stability, without claiming
   ideal-location stability or any random-success event
6. The shared ledger, all revalidation/parameter widths, actual preparation,
   composition references/copies, diagnostic retention and exact glue allocation
7. Explicit prior source-validation/immutability/normalization obligations and
   additive source representation/storage/I/O costs, without a hidden dense scan
8. Portable bindings, fresh reduced rational/direct-DFT controls, malformed and
   mismatched-provenance controls, and the 15 fresh integration mutants

The requested verdict concerns only this finite deterministic composition and
its source-model resource account. It must not silently accept randomness,
full E(beta), dense fallback, outer transfer, all-length execution, practical
speed, novelty, host totality or external-row cryptographic authentication.
