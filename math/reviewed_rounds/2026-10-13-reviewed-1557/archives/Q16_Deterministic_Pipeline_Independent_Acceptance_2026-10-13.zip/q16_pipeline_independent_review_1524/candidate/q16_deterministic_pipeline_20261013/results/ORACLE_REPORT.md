# Fresh bounded Q16 composition oracle

Status: PASS, candidate-supporting controls. This is not independent final acceptance of an unseen proof, an all-parameter theorem check, or a sparse-recovery probability experiment.

## Executed scope

The inspected current `pipeline.py` had SHA-256:

`c3a2da5a11ceba2cfa0df7bbb346525013e740e7bc170b3d27dfadc3f2be4d3b`

The four accepted component copies are byte-pinned in the test script. Their source and `ALGORITHM.txt` were inspected as inert text before any execution. Only these accepted modules, the fresh current pipeline, and the two freshly authored oracle/test files execute. No historical harness, prior test script, downloaded executable, Library, Sheets, or GitHub operation is used.

All fixtures use the legal reduced geometry `M=64, B=4, r=1`, with `P` equal to 8, 12, or 16. They do not satisfy or purport to test the outer theorem's parameter/probability conditions. Zero data and `q=0` are intentionally reduced-interface controls, not positive-norm theorem inputs.

## Independent construction

`fresh_oracle.py` imports only the standard library. Its numerical assertions use exact integers and `fractions.Fraction`, with explicit rational intervals. Display-only error decimals in JSON are not used for acceptance.

1. Pi is enclosed by `4(atan(1/2)+atan(1/3))`, using 200-term exact rational alternating series and their signed next-term remainders. Tangent addition and first-quadrant signs give the identity. This differs from production's Machin `16 atan(1/5)-4 atan(1/239)` construction.
2. Reduced sine arguments use a 64-term rational Taylor polynomial at a rational midpoint. The interval includes the angle radius via the 1-Lipschitz sine bound and a fixed `2^129/129!` Taylor remainder. The resulting outward grid has 112 bits; exact axes are handled exactly.
3. The box-power coefficients come from ordinary nested polynomial multiplication, not production's sliding convolution. `Phi_j` is then formed as a direct Fourier sum of those centered coefficients. The normalizer is the finite sum of these independent `Phi_j` values. `D_H(t)` is a direct sum of cosine roots, not a sine quotient.
4. These rational intervals reconstruct every prepared rounded tap for each tested `P`, including production's `P+4` enclosure/midpoint rounding convention. Separately, each production enclosure contains the independent narrow ideal interval and each tap's actual error is at most `2^-P`.
5. Four-point DFT roots and the `M=64` scale `1/8` are exact rationals. Each BUCKETS result is reconstructed by a direct sum over all supported taps, with negative Fourier sign, exact source dyadics, exact prepared tap values, and a single signed nearest-even Cartesian rounding. The oracle does not execute or reproduce the production FFT butterfly graph.
6. A second direct sum uses ideal rational-enclosed taps. The Cartesian rectangle enclosing each ideal output proves its squared distance from the actual dyadic output is at most the squared general BUCKETS bound. The bound itself is rederived independently as `(2M^2+2W rho)(1+rho)^(log2(B)+1)-2M^2+rho`.
7. Location ranking uses exact squared magnitudes and lower-bin tie priority. Memberships are obtained by exhaustive frequency matching to ordered residues, not the production inverse or merge-sort code. Majority membership is independently counted by frequency.
8. Estimation phases use the independent root enclosures and isolate their rounded `P+2` dyadics. Bucket selection, phase multiplication, final rounding, and odd Cartesian medians are recomputed without calling the production decoder, phase routine, or median routine.

## Fixtures and exact totals

| Fixture | P | q | Location rounds | Estimation rounds | Candidates |
|---|---:|---:|---:|---:|---:|
| Mixed nonzero/zero dyadics | 8 | 2 | 3 | 3 | 32 |
| All-zero ties, even location length | 12 | 1 | 2 | 1 | 27 |
| Mixed input, empty support | 8 | 0 | 1 | 5 | 0 |
| Complex pulse, full support | 12 | 4 | 2 | 3 | 64 |
| Dyadic quarter-frequency tone | 16 | 1 | 3 | 3 | 5 |

The explicit schedules include `sigma=1,3,5,7,9,11,17,31,61,63` as applicable and zero, interior, and wraparound shifts. Estimation lengths are 1, 3, and 5. Location length 2 verifies the specified `ceil(L/2)` threshold, which is one at `L=2`.

Totals:

- 189 independently reconstructed window taps across three precisions
- 6 prepared complex FFT roots and 3 prepared scales checked exactly
- 26 composed BUCKETS calls and 104 complex bucket outputs checked exactly
- 208 Cartesian bucket components independently enclosed against ideal DFT outputs
- 304 ordered location membership entries checked
- 330 phase-corrected complex estimates checked exactly
- 128 output median pairs checked exactly
- 4 observational rival-computation controls distinguished: positive DFT sign, missing `1/sqrt(M)` normalization, positive phase sign, and division by the window frequency response

The largest observed rational-enclosed L1 bucket-error upper bounds were approximately 0.004049 for mixed `P=8`, 0 for zero data, 0.003081 for empty-support mixed `P=8`, 0.000178 for the `P=12` pulse, and 0.000008301 for the `P=16` tone. The exact rational bounds and source hashes are in `oracle_results.json`.

The quarter-tone fixture deliberately illustrates the scope limit: it returns five reduced-fixture candidates, and frequency 16 has numerator 271567 on the `2^-16` grid, rather than the unwindowed Fourier numerator 262144. These are expected consequences of the reduced window and no-response-division contract, not evidence for exact spectral recovery. No division or post-hoc correction was inserted to make that output look exact.

## Reproduction

Python 3.10 or newer, standard library only. From the parent workspace:

```
python q16_deterministic_pipeline_oracle_20261013/test_pipeline_oracle.py --candidate-root q16_deterministic_pipeline_20261013
```

For a portable packet, copy `test_pipeline_oracle.py` as `tests/independent_oracle.py` and copy `fresh_oracle.py` beside it. The test automatically uses `../src` when present:

```
python tests/independent_oracle.py
```

Alternatively pass `--candidate-root /path/to/candidate`. No scratch-directory prefix is hardcoded. Reproduction writes `oracle_results.json` beside the test script. The original accepted folders are not required: fixed accepted source hashes are always checked, and original-byte comparisons are additionally checked only if the original folders are available.

Both invocation routes were executed successfully. In particular, a newly copied standalone `src/` plus `tests/independent_oracle.py` and `tests/fresh_oracle.py` layout passed all five fixtures without access to any sibling accepted-source folders.

## Remaining boundaries

The fixtures do not establish all-parameter scalar budgets, resource asymptotics, source normalization, actual fair-bit generation or independence, the outer sparse/dense dispatcher, or the all-length recovery theorem. Provenance and malformed-input attacks are separate controls handled by the composition author. Passing the numerical oracle is one bounded piece of candidate evidence and is not a substitute for a separate final source/proof review.
