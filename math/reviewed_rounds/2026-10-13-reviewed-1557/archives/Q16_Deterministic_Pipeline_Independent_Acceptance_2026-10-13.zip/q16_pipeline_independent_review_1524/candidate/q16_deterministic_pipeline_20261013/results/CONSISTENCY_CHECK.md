# Producer-side composition consistency check

The independently authored oracle was followed by a source/report consistency
pass. This is candidate preparation, not a final independent acceptance.

The pass confirmed:

- Closed-graph provenance is limited to trusted execution; arbitrary external
  bindings and Python private-memory tampering are expressly excluded.
- The glue-only cumulative allocation is
  7+10+(2+9+5+1+1)n_l+(2+9+7+5+1+1)n_e
  =17+18n_l+25n_e slots.
- eta=(1+rho)E_B+2M^2*rho+rho transfers the matching BUCKETS and phase
  contracts correctly.
- Coordinatewise median stability gives the stated sqrt(2)*eta complex
  bound; the conditional majority argument allows candidate-specific good sets.

Two documentation corrections were made before sealing:

1. The general execution-event bound now explicitly includes n_l*m for the
   decoder's bounded Euclidean inverse, including q=0.
2. Membership, estimate-row and final trace tuple copies together contribute
   2(n_l+n_e) copy events; their slot charges were already correct.

Neither correction changed scientific source or measured ledger values.
The source tested by both the oracle and controls retains SHA-256
c3a2da5a11ceba2cfa0df7bbb346525013e740e7bc170b3d27dfadc3f2be4d3b.
