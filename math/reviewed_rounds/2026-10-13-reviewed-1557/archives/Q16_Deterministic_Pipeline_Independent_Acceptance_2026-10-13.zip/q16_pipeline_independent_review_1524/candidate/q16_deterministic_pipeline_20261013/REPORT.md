# Bounded deterministic Q16 integration: composition candidate

13 October 2026. Fresh integration candidate, supported by independently
authored rational controls. Separate final integration acceptance is still
required. The four predecessor component acceptances are inherited only at
their stated deterministic boundaries.

## 1. Exact result and mathematical domain

`run_pipeline(spec, source, q, location_schedule, estimation_schedule)` closes
the previous executable caller/provenance gap between WINDOW, BUCKETS,
location decoding, phase estimates and medians. The public API receives no
prepared window, roots, bucket rows, candidate list or estimate rows. It
actually creates one BUCKETS engine, invokes it for every supplied round,
passes those actual outputs through the accepted location and estimate
routines, and passes the actual estimates for the same exact candidate tuple
to medians. All work shares one cumulative resource ledger.

The reduced mathematical domain is:

- Exact `WindowSpec`: M and B powers of two; M>=16, B>=4, T=M/B>=4;
  r>=1, P>=8, ell=8B and W=2r(ell-1)+1<M. This last condition forces the
  smallest executable fixture with B=4,r=1 to have M>=64.
- Exact integer q with 0<=q<=B.
- An already represented `DyadicSource` of exactly M samples, with a
  nonnegative exact fractional-bit bound F. Each sample is an exact tuple of
  two exact Cartesian dyadics (n,e), 0<=e<=F and |n|<=2^e. All scientific
  input containers are deeply immutable and no mutation through language
  internals or concurrent adversarial instrumentation occurs.
- A nonempty exact tuple of location affine pairs and a positive odd-length
  exact tuple of estimation affine pairs. Every pair is an exact two-tuple,
  sigma an odd exact integer in [1,M-1], tau an exact integer in [0,M-1].

Let n_l and n_e denote the respective schedule lengths. Location permits
even lengths because its independently accepted aggregation rule is
ceil(n_l/2). Estimation requires odd n_e for its unique middle coordinate.
These are deliberately broader reduced schedules than the source algorithm.
When the caller supplies q=512k and both lengths L=4m+1, the deterministic
round structure agrees with the source steps. The integration does not create
those schedules, call them random, or infer the theorem parameters.

A beta-bearing WindowSpec inherits the accepted exact beta-field validation
and its sparse front-end parameter checks. This is not the outer all-length
dispatcher and does not establish additional outer guards, including
beta*m>=2 or the source's outer t<M.

The source's whole-input validation, initial representation, original input
storage and normalization are explicit caller obligations with additive
costs. The pipeline validates the source header; unchanged BUCKETS validates
every reached sample field at its actual width. Unsampled entries are not
scanned or certified, and no global norm is queried. The deep immutability
precondition is about the supplied representation, not a newly implemented
dense validator. Malformed schedules are fully rejected before preparation;
malformed reached samples are rejected where read. Unreached malformed
samples lie outside the mathematical input contract and need not be detected.

## 2. Byte bindings and execution discipline

All four dependencies were read as source before use and copied unchanged:

- WINDOW v2, `compact_window.py`:
  e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59
- BUCKETS, `buckets.py`:
  df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1
- Location, `location_decode.py`:
  e3b592c40906d860d58c12cf7e21f17c6560cb8c95e7bcde4c161b0d52881c3a
- Phase/medians, `phase_medians.py`:
  45c0c6a59cac18912278dcda183fe8e5bea2a19398cb61fc1bf8ec97cac5a788

The phase/median independent-acceptance archive was also checked against
8a1719a2c1f187a9aa31aa0f84584f9cde1f368ddd7697a7704f43a3e1f1ab5a.
The source algorithm and proof retain their hashes
17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1 and
0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b.

No predecessor tests or historic scientific programs were executed. The
only scientific modules executed are these inspected current accepted
components and freshly authored integration/oracle/control code. The
manifest records the new integration hash and all retained evidence.

## 3. Closed execution graph and provenance

After validation, the pipeline creates a fresh run context holding the exact
spec, source, schedule objects and a fresh identity token. There is no user
callback, caller-supplied ledger, mutable prepared-state input or cache.
BucketEngine(spec,L) actually runs paid WINDOW preparation, certified roots,
scale and its error bound exactly once.

For each scheduled round, `_produce` reads that round's exact affine pair,
calls the actual engine with the context source and those two integers, and
privately binds the result to context, token, role, ordinal, affine object,
source object and spec object. The consuming gate checks those identities,
role/ordinal and the P grid before forwarding the same BucketResult object.
It neither regenerates a claimed receipt nor substitutes a reencoded row.
The accepted consumer then validates all B numerical pairs itself, including
empty-candidate estimation.

Location passes the sigma from that same immutable scheduled entry to the
accepted decoder. Tau is used in BUCKETS and need not enter the inverse
frequency permutation. Aggregation receives exactly the memberships from
those decoded actual buckets, preserving their round multiplicities. Its
returned tuple is already increasing and distinct.

Every estimation call receives that one exact candidate tuple object, the
actual matching estimation-round buckets, and the matching sigma/tau. A
second private binding holds the estimate together with the candidate tuple,
round ordinal, context/token and originating bound buckets. Before a row is
appended to the median input, the gate rechecks its origin, candidate-tuple
identity and P grid. Medians receives those rows in a tuple and the same
candidate object. Therefore column j in every row denotes precisely
candidates[j], not merely an equal-length anonymous column.

This is an executable data-flow proof in a closed trusted source-level
program. The private gates detect accidental/mismatched bindings and the
public API rejects intermediate injection. It is not a cryptographic
authentication service for arbitrary externally serialized rows. Someone
who can replace private objects, forge bindings with an obtained context,
monkeypatch dependencies or mutate Python memory is outside the contract.
No impossible security claim against such code execution is made.

Traces retain actual immutable scientific outputs by reference. The final
numerical object is unchanged MedianResult: sorted frequency/pair records
on grid 2^-P. Certificates, large error numerators and the ledger are
separate diagnostic fields. Retained zero coefficients are allowed.

## 4. Exact location semantics and support

All bucket components share a positive denominator 2^P. Ranking the exact
integer squared magnitudes a_j^2+b_j^2 therefore ranks their represented
dyadic magnitudes exactly. Lower bucket index breaks all ties. The accepted
decoder selects q bins and, for each selected j, enumerates exactly T
residues jT-T/2,...,jT+T/2-1 modulo M, then applies the exact inverse of
the same odd sigma modulo M.

T is even. These B half-open cells partition the M residues; multiplication
by odd sigma is a permutation modulo power-of-two M. Each location round
thus contributes exactly qT distinct memberships. Let h=ceil(n_l/2).
Aggregation retains an index iff it appears at least h times and sorts
the retained set. With K candidates, Kh<=n_l*qT, so

    K <= floor(n_l*qT/h) <= 2qT, and K <= M.

This bound now follows from the actual executed decoder rounds, rather than
being a promise attached to unrelated supplied memberships. It holds for
every legal deterministic schedule and includes q=0. No ideal-bucket rank
stability is asserted: rounding can alter a near tie, and all location
semantics here are those of the actual certified numerical buckets.

## 5. Source sign, scale, response and numerical error

The unchanged BUCKETS path queries v[(sigma*t+tau) mod M], folds into t mod B,
uses the negative-sign unnormalized B-point FFT, and multiplies by the
certified approximation to 1/sqrt(M). There is no hidden 1/B or 1/M FFT
normalization. Window normalization C remains exactly the source definition.

For candidate i, the estimator uses

    h = floor(((sigma*i mod M)+T/2)/T) mod B,
    p = exp(-2*pi*sqrt(-1)*tau*i/M).

It multiplies the actual bucket h by the certified approximation of p and
rounds once to the P grid. There is no division by the filter response G.
Division by the dyadic phase denominator is fixed-point rescaling; it is
not response correction. The independently authored controls explicitly
distinguish these conventions from wrong sign, missing scale and response
division rivals.

Put rho=2^-P, b=log2 B, A=2M^2, D=2W*rho. The executed BUCKETS constructor
computes the inherited exact general error bound

    E_B = (A+D)(1+rho)^(b+1) - A + rho.

For each actual round j and actual candidate i let z_{j,i} be the exact
ideal supported-window bucket at h times the exact inverse phase above.
The accepted BUCKETS and phase contracts now apply to the same source,
spec, schedule and candidate without an external provenance premise. The
complex estimate error is at most

    eta = (1+rho)*E_B + A*rho + rho.

This follows from phat*bhat-p*b = phat*(bhat-b)+(phat-p)*b,
|phat|<=1+rho and |b|<=A, plus the final complex rounding bound rho.
It is unconditional on recovery success and holds for every legal schedule.

Define Z_i as the coordinatewise median of the n_e ideal values z_{j,i}
for the pipeline's actual candidate i. Coordinatewise errors are <=eta.
An order statistic is 1-Lipschitz under uniform coordinate perturbation:
if a_j<=b_j+eta for all j, the corresponding middle order statistic obeys
the same inequality, and conversely. Therefore the returned complex
coefficient obeys |output_i-Z_i|<=sqrt(2)*eta.

Alternatively, if for a fixed candidate a strict majority of ideal
estimates are within a of some target x_i, then a strict majority of
computed estimates are within a+eta and the coordinatewise median is
within sqrt(2)*(a+eta). The good majority can differ by candidate. This is
only a deterministic conditional statement; no such event is established
by an arbitrary caller schedule.

For accepted front-end precision P=16m+16, inherited E_B<=24(m+1)M^2*rho
implies eta<=64(m+1)M^2*rho. This numerical transfer does not promote reduced
fixtures into a theorem-scale test or establish a sparse-recovery theorem.

## 6. Termination, cost and boundary validation

Every schedule is a finite exact tuple and is fully checked before
preparation, with actual integer encoding widths charged. The accepted
components have finite predetermined scalar loops, finite FFT stages,
bounded Euclid, explicit finite merges and exact integer arithmetic. The
new loops run precisely n_l or n_e times. There is no random rejection,
retry, tolerance refinement, timeout, host-width cap or success-dependent
early exit. On the mathematical valid domain, certification guards inherit
the proved component invariants.

`CompositionLedger` adds the location ledger's bitwise-and and bit-length
primitives to the accepted WINDOW ledger, without overriding its numerical
operations or report. One instance is passed through all preparations and
all consumers. Tuple copies, wrapper records, references and validations
have explicit events/allocations. No component receives a silently fresh
ledger. Detailed accounting, including additive caller costs and diagnostic
trace storage, is in RESOURCE_LEDGER.md.

This remains the accepted conservative source-level schoolbook-bit model,
not a proof about Python bytecode, filesystem I/O, physical RAM, wall time
or success on finite host resources. Artifact packaging and oracle cost
are outside the mathematical API and are disclosed as such.

## 7. Fresh controls and limits of the evidence

The independently authored rational oracle uses a distinct pi identity,
direct root sums, direct polynomial multiplication and a direct four-point
DFT. Five reduced M=64,B=4,r=1 cases cover P=8/12/16, mixed data, zero ties,
even location counts, q=0 with five estimation rounds, q=B full support,
impulse and quarter-tone sources. Its exact scope and completed totals are
in `results/ORACLE_REPORT.md` and `results/oracle_results.json`. Wider-B FFT
behavior is inherited from BUCKETS acceptance, not newly claimed from this
four-point integration oracle.

Fresh composition controls reject 28 malformed inputs/public intermediate
injections and 18 wrong source/spec/schedule/grid/context/candidate-order
bindings. They reconstruct 309,509 primitive records and 31 reports across
29 ledger instances, including 40,001-bit malformed parameters and reached
source numerators. Exact event checks establish one actual preparation,
all six scheduled BUCKETS executions and all downstream costs in the
nonzero three-plus-three-round fixture.

Fifteen in-memory mutations of only the fresh glue are detected. Six alter
scientific outputs by detaching BUCKETS sigma/tau, location sigma,
estimation sigma/tau or candidate columns. Five detach preparation,
location, estimation, median or tuple-movement accounting; four disable
source/spec/schedule/candidate-order binding. Frozen files are never mutated.
These are corroborating finite controls, not universal proofs or a final
independent acceptance decision.

## 8. Precisely what remains open

- Final independent acceptance of this new integration and its complete ledger
- Caller input representation, full validation, source storage and normalization
- Generation of fair random schedules and any independence/success analysis
- Proof or execution of sparse recovery on theorem-scale E(beta) inputs
- Exceptional dense branch, outer transfer, all-length dispatch and host totality
- Physical I/O/RAM, practical speed, crossovers and novelty

The accepted component interfaces were sufficient for this bounded glue;
no interface repair or hidden fallback was needed. There was no Sheet write,
GitHub write, publication or access-permission change.
