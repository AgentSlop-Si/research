"""Fresh bounded differential controls, written 2026-10-13.

Only the inspected current pipeline and byte-pinned accepted components execute.
Historical harnesses, packet scripts, and external services are not invoked.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
from fractions import Fraction as F

from fresh_oracle import (R, ideal_window, direct_buckets, decode, aggregate,
                          estimate, medians, round_even_fraction, root,
                          uniquely_rounded, pair_mul)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate-root', type=Path, help='Candidate folder containing src/pipeline.py')
arguments, _unknown = parser.parse_known_args()
if arguments.candidate_root is not None:
    CANDIDATE = arguments.candidate_root.resolve()
elif (ROOT / 'src/pipeline.py').is_file():
    CANDIDATE = ROOT
else:
    CANDIDATE = ROOT / 'q16_deterministic_pipeline_20261013'
CURRENT = CANDIDATE / 'src'
ACCEPTED = {
    'compact_window.py': ROOT / 'q16_certified_window_v2_20261013/src/compact_window.py',
    'buckets.py': ROOT / 'q16_certified_buckets_20261013/src/buckets.py',
    'location_decode.py': ROOT / 'q16_location_decode_20261013/src/location_decode.py',
    'phase_medians.py': ROOT / 'q16_phase_medians_20261013/src/phase_medians.py',
}
PINS = {
    'compact_window.py': 'e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59',
    'buckets.py': 'df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1',
    'location_decode.py': 'e3b592c40906d860d58c12cf7e21f17c6560cb8c95e7bcde4c161b0d52881c3a',
    'phase_medians.py': '45c0c6a59cac18912278dcda183fe8e5bea2a19398cb61fc1bf8ec97cac5a788',
}
for name, accepted in ACCEPTED.items():
    # The portable candidate packet need not include the original folders.
    # Pins always check; optional inert original-byte checks run when available.
    assert hashlib.sha256((CURRENT / name).read_bytes()).hexdigest() == PINS[name]
    if accepted.is_file():
        assert (CURRENT / name).read_bytes() == accepted.read_bytes()
sys.path.insert(0, str(CURRENT))
from pipeline import run_pipeline, WindowSpec, DyadicSource
from buckets import BucketEngine


def pair(a=0, b=0, ea=0, eb=0):
    return ((a, ea), (b, eb))


ZERO = tuple(pair() for _ in range(64))
MIXED = tuple(pair(((11*t+3) % 17)-8, ((7*t+5) % 15)-7, 4, 3)
              if t % 7 else pair() for t in range(64))
PULSE = tuple(pair(1, -1, 1, 2) if t == 5 else pair() for t in range(64))
TONE16 = tuple((pair(1, 0, 1, 0), pair(0, 1, 0, 1),
                pair(-1, 0, 1, 0), pair(0, -1, 0, 1))[t % 4] for t in range(64))
CASES = (
    ('mixed_three_rounds', 8, 2, MIXED, 4,
     ((1, 0), (3, 5), (63, 17)), ((5, 1), (7, 9), (61, 63))),
    ('zero_ties_even_location', 12, 1, ZERO, 0,
     ((1, 0), (3, 5)), ((63, 16),)),
    ('mixed_empty_candidates', 8, 0, MIXED, 4,
     ((63, 63),), ((1, 0), (5, 31), (17, 32), (31, 7), (63, 63))),
    ('pulse_full_support', 12, 4, PULSE, 2,
     ((5, 17), (11, 63)), ((3, 1), (9, 5), (63, 17))),
    ('quarter_tone', 16, 1, TONE16, 1,
     ((1, 0), (3, 1), (5, 3)), ((1, 1), (3, 3), (63, 63))),
)


def canonical_taps(P):
    coefficients, normalizer, taps = ideal_window(64, 4, 1)
    rounded = []
    for t, enclosure in taps:
        # The bounded fixtures isolate the same P+4-grid enclosure as the
        # production interval construction, proved explicitly in check_scalars.
        outward = enclosure.grid(P+4)
        rounded.append((t, F(round_even_fraction((outward.lo+outward.hi)/2 * (1 << P)), 1 << P)))
    return tuple(rounded)


def check_scalars(P):
    engine = BucketEngine(WindowSpec(64, 4, 1, P))
    coefficients, normalizer, ideal = ideal_window(64, 4, 1)
    assert engine._window.coefficients.numerators == coefficients
    assert engine._window.coefficients.denominator == 32**2
    assert engine._window.C.as_fractions()[0] <= normalizer.lo <= normalizer.hi <= engine._window.C.as_fractions()[1]
    expected = canonical_taps(P)
    assert tuple((t.t, F(t.numerator, 1 << t.bits)) for t in engine._window.taps) == expected
    for actual, (_, bounded) in zip(engine._window.taps, ideal):
        low, high = actual.enclosure.as_fractions()
        assert low <= bounded.lo <= bounded.hi <= high
        assert (bounded - F(actual.numerator, 1 << P)).abs_bound() <= F(1, 1 << P)
    assert F(engine._scale.numerator, 1 << engine._scale.bits) == F(1, 8)
    for j, value in enumerate(engine._roots):
        expected_root = root(4, -j)
        assert F(value.real.numerator, 1 << value.real.bits) == expected_root[0].lo == expected_root[0].hi
        assert F(value.imag.numerator, 1 << value.imag.bits) == expected_root[1].lo == expected_root[1].hi
    return {'P': P, 'taps': len(expected), 'normalizer_enclosed': True,
            'rounded_taps_independently_reconstructed': True, 'roots_and_scale_exact': True}


def run_case(case):
    name, P, q, values, Fbound, location, estimation = case
    spec = WindowSpec(64, 4, 1, P)
    run = run_pipeline(spec, DyadicSource(values, Fbound), q, location, estimation)
    taps = canonical_taps(P)
    ideal_taps = ideal_window(64, 4, 1)[2]
    memberships, rows = [], []
    max_l1 = F(0)
    bucket_checks = 0
    error = F(run.bucket_error[0], 1 << run.bucket_error[1])
    rho = F(1, 1 << P)
    # Independently rederive the published general finite BUCKETS error formula.
    A, W, b = 2*64**2, 63, 2
    assert error == (A+2*W*rho)*(1+rho)**(b+1)-A+rho
    for role, schedule, traces in (('location', location, run.location_trace),
                                    ('estimation', estimation, run.estimation_trace)):
        assert len(schedule) == len(traces)
        for affine, trace in zip(schedule, traces):
            sigma, tau = affine
            assert trace.affine == affine
            expected = direct_buckets(values, 64, 4, P, sigma, tau, taps)
            assert trace.buckets.numerators == expected
            assert trace.buckets.bits == P
            ideal = direct_buckets(values, 64, 4, P, sigma, tau, ideal_taps, ideal=True)
            for actual, certified in zip(expected, ideal):
                dr = (certified[0]-F(actual[0], 1 << P)).abs_bound()
                di = (certified[1]-F(actual[1], 1 << P)).abs_bound()
                assert dr*dr+di*di <= error*error
                max_l1 = max(max_l1, dr+di)
                bucket_checks += 1
            if role == 'location':
                selected, members = decode(64, 4, q, sigma, expected)
                assert trace.selected_buckets == selected
                assert trace.memberships == members
                assert len(members) == len(set(members)) == q*16
                memberships.append(members)
            else:
                assert trace.candidates is run.candidates
                row = estimate(64, 4, P, run.candidates, sigma, tau, expected)
                assert trace.estimates.numerators == row
                assert trace.estimates.bits == P
                rows.append(row)
    assert run.candidates == aggregate(64, memberships)
    assert run.output.pairs == medians(run.candidates, rows)
    assert run.output.bits == P
    assert len(run.candidates) <= 2*q*16
    if q == 0:
        assert run.output.pairs == () and run.candidates == ()
        assert len(run.estimation_trace) == len(estimation)
    if q == 4:
        assert run.candidates == tuple(range(64))
    if values == ZERO:
        assert all(c == (0, 0) for _, c in run.output.pairs)
        assert len(run.output.pairs) > 0  # Zero coefficients are retained.
        assert all(t.selected_buckets == (0,) for t in run.location_trace)
    return run, {'name': name, 'P': P, 'q': q, 'location_rounds': len(location),
                 'estimation_rounds': len(estimation), 'candidates': len(run.candidates),
                 'complex_buckets_compared': bucket_checks,
                 'bucket_components_certified': 2*bucket_checks,
                 'phase_corrected_estimates_compared': len(run.candidates)*len(estimation),
                 'membership_entries_compared': q*16*len(location),
                 'median_pairs_compared': len(run.candidates),
                 'exact_rounded_buckets_match': True, 'exact_decode_and_medians_match': True,
                 'ideal_error_bound_verified': True,
                 'observed_error_l1_upper_fraction': str(max_l1),
                 'observed_error_l1_upper_decimal_for_display_only': float(max_l1),
                 'general_bucket_error_bound': str(error)}


def distinguish_mutations(run):
    # All are observational rival computations: never patch production code.
    trace = run.estimation_trace[0]
    P = run.output.bits
    sigma, tau = trace.affine
    expected = trace.buckets.numerators
    # The positive-sign DFT swaps bins 1 and 3 for B=4.
    assert expected != (expected[0], expected[3], expected[2], expected[1])
    assert any(a or b for a, b in expected)
    assert expected != tuple((8*a, 8*b) for a, b in expected)
    wrong_sign = estimate(64, 4, P, run.candidates, sigma, (-tau) % 64, expected)
    assert wrong_sign != trace.estimates.numerators
    # Step 6 does not divide by the frequency response at a candidate's offset.
    # Exhibit an actual candidate for which that rival operation changes output.
    ideal_taps = ideal_window(64, 4, 1)[2]
    changed = []
    for at, i in enumerate(run.candidates):
        residue = sigma*i % 64
        h = ((residue+8)//16) % 4
        offset = residue-h*16
        response = sum((w*root(64, offset*t)[0]/64 for t, w in ideal_taps), R(0, 0))
        if response.lo <= 0 <= response.hi:
            continue
        phase = tuple(F(uniquely_rounded(a, P+2), 1 << (P+2)) for a in root(64, -tau*i))
        unrounded = pair_mul(expected[h], phase)
        divided = tuple(uniquely_rounded(R(a, a)/response, 0) for a in unrounded)
        if divided != trace.estimates.numerators[at]:
            changed.append(i)
    assert changed
    return {'positive_dft_sign_distinguished': True, 'missing_normalization_distinguished': True,
            'positive_phase_sign_distinguished': True, 'response_division_distinguished_at': changed}


def main():
    scalars = [check_scalars(P) for P in (8, 12, 16)]
    reports, runs = [], []
    for case in CASES:
        run, report = run_case(case)
        runs.append(run)
        reports.append(report)
        print('PASS', report['name'], report['candidates'], flush=True)
    mutations = distinguish_mutations(runs[0])
    output = {'status': 'PASS', 'scope': 'fresh reduced-fixture candidate-supporting controls, not independent final acceptance',
              'scalar_controls': scalars, 'cases': reports, 'mutation_controls': mutations,
              'totals': {'window_taps_compared': sum(a['taps'] for a in scalars),
                         'prepared_complex_roots_compared': 2*len(scalars),
                         'prepared_scales_compared': len(scalars),
                         'bucket_calls_compared': sum(a['location_rounds']+a['estimation_rounds'] for a in reports),
                         'complex_buckets_compared': sum(a['complex_buckets_compared'] for a in reports),
                         'cartesian_bucket_components_compared': sum(a['bucket_components_certified'] for a in reports),
                         'phase_corrected_estimates_compared': sum(a['phase_corrected_estimates_compared'] for a in reports),
                         'membership_entries_compared': sum(a['membership_entries_compared'] for a in reports),
                         'median_pairs_compared': sum(a['median_pairs_compared'] for a in reports),
                         'rival_computation_controls': 4},
              'executed_current_source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                                 for p in CURRENT.glob('*.py')}}
    destination = HERE / 'oracle_results.json'
    destination.write_text(json.dumps(output, indent=2)+'\n')
    print('PASS all controls:', destination, flush=True)


if __name__ == '__main__':
    main()
