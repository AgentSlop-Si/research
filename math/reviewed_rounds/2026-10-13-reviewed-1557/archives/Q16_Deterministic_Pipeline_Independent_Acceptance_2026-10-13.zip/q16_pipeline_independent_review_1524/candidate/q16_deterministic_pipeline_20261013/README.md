# Q16 deterministic pipeline integration candidate

13 October 2026. Candidate for independent review; not an accepted full recovery engine.

`src/pipeline.py` composes the four independently accepted current components,
unchanged, on one cumulative ledger. The public API owns every preparation,
BUCKETS execution, decode, candidate aggregation, inverse-phase estimate and
Cartesian median. It accepts no caller-supplied intermediate numerical rows.

The output is the accepted `MedianResult` interface inside a diagnostic
`PipelineRun`. Actual bucket and estimate objects are retained in an immutable
scientific trace; the accounting dictionary is separate diagnostic metadata.

```python
from compact_window import WindowSpec
from buckets import DyadicSource
from pipeline import run_pipeline

spec = WindowSpec(64, 4, 1, 12)
source = DyadicSource(tuple(((0, 0), (0, 0)) for _ in range(64)), 0)
result = run_pipeline(spec, source, 1,
                      ((1, 0), (3, 7), (63, 63)),
                      ((5, 9), (17, 4), (1, 0)))
print(result.output.pairs, result.output.bits)
```

This example is a reduced fixture. It does not satisfy or establish the source
algorithm's global norm promise or theorem-scale parameter choices.

## Contents

- `REPORT.md`: precise scope, composition proof and conditional error transfer
- `RESOURCE_LEDGER.md`: complete charged preparation, validation and data movement
- `PROOF_LEDGER.json`: machine-readable proved/conditional/excluded obligations
- `src/`: fresh integration plus four byte-identical accepted modules
- `tests/`: fresh rational/direct-DFT oracle, malformed/provenance/accounting and
  integration-mutation controls
- `results/`: completed fresh run receipts
- `sources/`: accepted mathematical source and component review evidence, inert
- `MANIFEST.json`, `SEAL.json`, `verify_package.py`: portable byte seal

## Reproduction

Use Python 3.12+ and its standard library. No network, credentials or external
numerical package is needed. From the unpacked candidate root, first run
`python verify_package.py`. To rerun tests, use a disposable copy, since the
fresh controls overwrite their result receipts:

```
python tests/composition_controls.py
python tests/mutation_controls.py
python tests/independent_oracle.py
```

Read the oracle's report for its exact reproducible command if an optional
output argument is desired. These commands execute only the current accepted
modules, newly authored glue and newly authored controls. No predecessor test
runner or historical scientific executable is included as an executable test.

## Boundary

The source must already be represented as the documented deeply immutable
dyadic tuple. Only queried entries are checked here. Prior representation,
whole-input validation, normalization, storage and physical I/O are additional
caller costs. Schedules are deterministic data, with no asserted independence.
No random sampler, success theorem, dense fallback, complete E(beta), outer
transfer, all-length executable, host-totality or speed claim is supplied.
No Sheet or GitHub write is part of this task. The package is preserved privately.
