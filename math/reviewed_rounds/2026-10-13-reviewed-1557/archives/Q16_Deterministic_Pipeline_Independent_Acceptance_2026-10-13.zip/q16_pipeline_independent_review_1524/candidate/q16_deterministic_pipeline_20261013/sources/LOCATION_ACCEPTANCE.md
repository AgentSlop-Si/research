# Q16 deterministic location decoder independent review

## Verdict and scope

ACCEPT the frozen deterministic rank/decode and membership-aggregation component, with its conservative source-level finite-bit work and cumulative auxiliary-storage account. No required repair was found.

This verdict applies only to source `sources/location_decode.py`, SHA256 `e3b592c40906d860d58c12cf7e21f17c6560cb8c95e7bcde4c161b0d52881c3a`. The producer archive is `Q16_Exact_Location_Decoder_Candidate_2026-10-13.zip`, SHA256 `3e804cfe03d7af5ec94c1e3f6df7502e93e3e33044e1d689b1ed5171b30aa4a3`, private Library ID `libfile_d21a1bfef8a88191a310372ff380a4ce`, version 0.

The accepted outcome is exact ranking and deterministic decoding of supplied common-grid integer bucket payloads, followed by exact threshold aggregation of valid per-round membership lists. This does not establish that arbitrary payloads came from BUCKETS, certify independence of rounds, or establish recovery accuracy. Random scheduling, parameter construction, BUCKETS executable composition, inverse-phase preparation, estimation, medians, dense fallback, outer transfer, full recovery and all-length executable conformance are outside this review.

All numerical executions below are reduced deterministic component controls. No theorem-scale sparse-recovery execution, physical resource totality, practical speed or novelty conclusion is claimed. No external record, repository, Sheet, publication or sharing permission was changed.

## Evidence identity and inherited premises

The candidate ZIP checksum, CRC, all 21 manifest payload size/hash entries, manifest-to-seal link and production source hash were checked before scientific execution. The exact source was copied into this review; the producer package was not edited and its test suite was not used as the independent oracle.

The copied ALGORITHM.txt is 4,708 bytes with SHA256 `17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1`. The copied PROOF.md is 19,198 bytes with SHA256 `0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b`. Both are byte-identical to the recovered E(beta) source bodies. The recovered-edition acceptance archive, private Library `libfile_81fde655801481919d0cb56be92f9c6c`, was checked at SHA256 `dee91201ce36572b432da5267374829b46d1f2a3bbfcfa1b172d787923a19857`; its acceptance expressly preserves inherited mathematical premises and is not a fresh full E(beta)/P05 audit. This review preserves that limitation. Missing original top-level historical frontend/checker archive bytes were not reconstructed or executed here.

The accepted BUCKETS candidate archive, private Library `libfile_fce0f64919b48191ba63a392b4e2da7f`, was checked at SHA256 `f98a315abe8a19cfedc08b97b13d3d4353b1f2a743aa77281c96c46500d4f9da`. Its source equals accepted SHA256 `df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1`. Its accepted WINDOW dependency remains SHA256 `e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59`. BUCKETS was inspected as source evidence only, never imported or executed. The copied BUCKETS acceptance has SHA256 `e6bd146b7765e5b37a2f4ad1faf6425d254687d28242d6c0983258440db4f804`.

## Exact input recognition

`_geometry` (source lines 76–87) records M, B and q as exact Python integers before mathematical checks. It rejects booleans, integer subclasses and coercion objects. Positive power-of-two tests and B<=M/2 imply M=2^m, B=2^b, 1<=b<m and T=M/B=2^(m-b), an even integer at least two. It checks 0<=q<=B before computing n=qT, hence 0<=n<=M.

The decoder records sigma and bits before their domain checks. Odd sigma in [1,M) is invertible modulo M. Every bucket container and pair must be an exact tuple; every reached pair length is recorded before the pair-shape check. Both signed Cartesian components must be exact integers and their full widths are recorded. There is no integer coercion, mutable-container traversal or scientific-input callback.

The aggregator similarly requires a nonempty exact tuple of exact tuples of length n. It records every reached index before testing 0<=index<M. It sorts each round and rejects equal neighbors before contributing that round to the complete list. L=0 is rejected; that avoids the undefined practical interpretation of a threshold-zero list over all absent positions. q=0 remains fully validated and has a nonzero O(L) recognition cost. Trusted instrumentation state is explicitly outside the adversarial input interface; a caller-supplied hostile Ledger subclass is not an accepted input.

## Ranking proof including ties

For bucket j the represented complex value is (a_j+i b_j)2^(-bits). Its squared modulus is (a_j^2+b_j^2)2^(-2 bits). The common factor is positive even for an arbitrarily large symbolic nonnegative exponent, so ranking by s_j=a_j^2+b_j^2 is exactly equivalent. Source line 184 forms both integer squares and their sum without rounding, floating point, square roots or a denominator allocation.

The comparator on lines 111–115 selects the larger s first, and for equal s selects the lower j. Each j occurs once, so this is a total order on the B entries. In `_merge_sort`, before a width-w pass, all consecutive runs of length at most w are ordered. Merging neighboring runs writes exactly their combined entries in order, including partial terminal runs; each iteration advances exactly one input pointer. Every output position is written once per pass. Thus after ceil(log2 B) passes the full array is ordered. Taking the first q entries gives exactly the specified distinct bins, including zero buckets, signs and exact energy ties.

This is the exact ordering obligation in ALGORITHM step 5 and PROOF section 5. It does not independently assert the numerical approximation hypothesis of the robust-location lemma or turn ranking into a heavy-coordinate certificate.

## Inverse proof and the role of tau

`_inverse_odd` (lines 130–148) is extended Euclid. At every step, each stored remainder is congruent to its associated t coefficient times sigma modulo M; equivalently it has an exact integer representation aM+t sigma. Replacing (old_r,r) by (r,old_r-floor(old_r/r)r) and (old_t,t) analogously preserves this invariant. Nonzero remainders strictly decrease. Over any two consecutive divisions, the earlier positive remainder drops by at least a factor of two: either the next divisor is already at most half, or the following remainder is smaller than half. Starting at M=2^m, 2m+2 iterations are sufficient to reach zero. Odd sigma and power-of-two M give gcd=1, so the final old_t obeys old_t sigma = 1 mod M. Reduction modulo M produces the unique inverse u in [0,M), and the source checks the exact modular product.

A coarse all-path width bound is enough: each quotient is at most M, and if both coefficient magnitudes are at most C, the next coefficient magnitude is at most (M+1)C. Starting at one, at most 2m+2 steps give coefficient width at most 1+(2m+2)ceil(log2(M+1)), hence O(m^2). Remainders and final inverse have O(m) bits. There is no data-dependent precision refinement or random retry.

Although BUCKETS reads the affine time address sigma*t+tau, the frequency-index map to decode is multiplication by sigma, without a tau translation. PROOF section 3 equation (4) is b_j=sum_i z_i omega^(tau*i) G_(jT-sigma*i). Tau changes a spectral phase, not the hash location. Therefore the correct location inverse here is u= sigma^(-1) mod M. Subtracting tau in the frequency decoder would be wrong. Inverse-phase handling belongs to the later estimation stage and was not exercised.

## Half-open preimages and distinctness proof

For a residue x let h(x)=floor((x+T/2)/T) mod B. For each j define the circular interval

    S_j = {jT-T/2, jT-T/2+1, ..., jT+T/2-1} mod M.

These B sets partition all M residues. To prove the equivalence exactly, choose an integer lift x'=x+zM. The inequality jT-T/2<=x'<jT+T/2 is equivalent to floor((x'+T/2)/T)=j. Changing the lift changes that quotient by zB, hence preserves its residue modulo B. Each interval contains T integers, its left endpoint belongs to it, and its excluded right endpoint is the next interval's left endpoint. Bucket zero wraps through M-1 without a gap or duplicate.

Multiplication by u is a permutation of Z/MZ. Consequently u*S_j is precisely the set of i with h_sigma(i)=h(sigma*i mod M)=j. Lines 199–202 enumerate the exact signed interval, reduce modulo M, and multiply by u with a second modular reduction. They produce exactly T valid indices per selected j, in increasing interval-offset order. Since selected buckets are distinct and the S_j are disjoint, all n=qT returned indices are distinct. The decoder uses no known frequency locations and no M-position scan; direct M-position scans are confined to the independent test oracle.

## Membership proof and support bound

Per-round validation makes occurrence count equal to the number of rounds containing an index. It forbids duplicate votes within one round but does not forbid identical lists in different rounds. Repeated identical rounds correctly give L votes to each of their n members, regardless of any unestablished randomness premise.

The complete list contains N=Ln entries. After its exact integer sort, equal values occupy contiguous runs. The scan on lines 252–263 visits each run once, computes its exact length, and emits its value if and only if its length is at least t=floor((L+1)/2)=ceil(L/2). The output is sorted and distinct. Since L>=1, t>=1, so absent indices are correctly excluded. For even L this rule is not a strict majority; the component deliberately preserves the specified threshold. The E(beta) caller uses odd L=4m+1.

Each emitted index consumes at least t of the N memberships. Therefore

    |I'| <= min(M, floor(N/t)) <= 2qT.

The final arithmetic invariant check agrees with this counting proof. The bound holds for every valid tuple of rounds, including wholly unsuccessful location rounds and repeated identical rounds. It is not conditioned on a correctness event. All N temporary memberships are charged; no M-entry counter array is created.

## Resource and rejection-path audit

The accepted resource model is the finite-bit source model stated in the producer report, not Python interpreter instruction counts, measured resident memory or wall time. Every explicit primitive records operand and result widths and charges 16(2+sum widths)^2. Schoolbook multiplication/division, additions, modular reductions, bit tests and width operations fit this conservative arithmetic envelope. All reached input integer widths contribute before a numeric-domain rejection; symbolic bits contributes its encoding width but never a materialized 2^bits denominator.

Source inspection accounts for recognition branches, direct comparisons, loop indices, tuple/list construction, record copies and Ledger bookkeeping through the conservative 512 E D^2 work and 512 E D cumulative-storage envelope, where E=sum(events)+256 and D=max observed integer width+bit_length(E)+2. The event stream includes every nonconstant-length iteration or batch allocation; fixed-arity source control between charged points is bounded. This is the declared conservative accounting model. It does not independently define or certify every host runtime or repeated out-of-band calls to instrumentation methods.

Direct numerical primitives include their produced width; all array reservations and final tuple copies are charged. Useful exact cross-checks derived directly from construction are:

- Successful decoder allocated-slot total: 6B+2q+2n. It records B bucket reads and scores, q bin selections, n memberships, 5+2B parameter fields and B*ceil(log2 B) merge-output copies.
- Successful aggregator allocated-slot total: 6N+K for K returned indices. It records L rounds, N index reads, N copies into the complete list, 3+N parameter fields and 2N initial sort copies. This includes the extra per-round validation sorts as well as the full sort.

For duplicate rejection specifically, the `distinctness_compare` event occurs only after a successful comparison. The rejecting comparison is still paid: its preceding `L.sub(at,1)` is recorded and the branch/comparison is included in the control envelope. We do not interpret this counter as a literal count of all attempted equality comparisons. Early type/shape/domain rejection similarly retains the already charged input prefix and loop work. Unread tails are neither scanned nor claimed validated. Failed-path costs must use the reached actual widths, not the smaller valid-domain bounds.

For one decoder call, let H=max(1, numerator widths), e=bit_length(bits), m=log2 M and n=qT. Event count is O(B(1+log B)+n+m), including q=0 validation and inversion. Widths are O(H+e+m^2), plus event/address counter widths. Scores have at most 2H+1 bits. For aggregation, N=Ln and event count is O(L+N(1+log(n+1)+log(N+1))); valid indices have O(m) bits and addresses/counts add O(log(L+1)+log(N+1)). Work is O(E0(D0+log(E0+1))^2), cumulative auxiliary storage O(E0(D0+log(E0+1))). Huge represented malformed fields can have larger width and are separately charged.

Under the inherited source parameters H=O_d(m), bits=16m+16, q=512k and L=4m+1, L decoder calls and aggregation fit O((LB+LqT) poly_d(m)). This is a conditional deterministic subcomponent bound only. Beta-dependent parameter work, source access, preparation, BUCKETS, fresh fair-bit generation, output file serialization and all later stages remain owed by their own callers.

Valid mathematical inputs have finite loops and no algorithmic timeout, random rejection, cap refusal or precision fallback. Concrete host memory/size limits for huge valid lists remain an explicitly open deployment question. We do not promote abstract finite-source termination to host totality.

## Independent controls

The fresh controls in `checks/independent_checks.py` import only the pinned new candidate. They do not import producer inverse, sort or hash routines for their oracles, producer tests, accepted BUCKETS/WINDOW executables, or historical scientific programs. Ranking is checked with a separately formed integer key and Python's test-only sort. Decoding is checked by scanning all small-domain indices, computing the hash independently as floor((2x+T)/(2T)) mod B, and recovering the required order by circular residue offsets without a modular inverse. Endpoint tests separately use Python's modular-inverse oracle. Aggregation is checked by direct per-round membership predicates for every index, not a pooled production count.

Final fresh results:

- 299,396 assertions before mutation tests; 299,591 including mutation detection.
- 16,293 independently checked decoder calls. M ranges from 4 through 128, all allowed B and odd sigma, all q for B<=16 and additional boundary/interior q otherwise, plus 27 wide-payload controls.
- 43,180 interval endpoint cases, including every bucket, allowed B and odd sigma through M=256.
- 9,388 aggregator calls, including all 9,330 ordered sequences of 2-subsets of a 4-element universe for L=1 through 5, reordered larger cases, 17 repeated-identical-round lengths, tight odd/even support examples and q=0 cases through L=513.
- 2,061 independent modular-inverse checks, exhaustive odd residues through M=2048 and selected multipliers at 127, 521 and 2048 bits.
- 12 public q=0 controls at m=257, 1024 and 4096, testing large represented geometry without allocating a huge membership list.
- Exact energy differences of one through numerator magnitude 2^65536, including signed ties; maximum numerator width 65,537 bits and energy width 131,073 bits. Common exponents include 2^4096+19 without constructing their denominator.
- 56 malformed-path controls before mutants, covering exact-type rejection, callback traps, all numeric fields, mutable/subclass containers, lengths, q=0, empty rounds, invalid residues, within-round duplicates and large widths, including failures after earlier successful calls using the same Ledger.
- 3,743 primitive records were independently reconstructed with binary-string widths and independent primitive semantics. Operation counts, parameter totals, allocation, arithmetic work, control work and cumulative storage all match the candidate's report. The trace includes five successful decoder calls, aggregation, a later duplicate-round rejection and a wide-field/bool rejection. Its exact arithmetic charge is 96,604,624 and total model work is 20,217,299,036,624 units; these are source-model charges, not measured time.
- All 16 targeted source mutants were detected: either square removed, energy direction reversed, tie priority reversed, wrong inverse, shifted half-open endpoint, omitted residue, missing final modulo, floor threshold, strict threshold, skipped within-round distinctness, missing bucket/membership/exponent charges, omitted final tuple allocation and missing complete-list copy charge. Mutants were in-memory copies; the frozen source was not changed.

The mutation smoke suite was strengthened before its final passing run to include an odd-round case with both singleton and repeated memberships. The mathematical exhaustive aggregation controls already covered that distinction. The final artifacts contain the strengthened suite and its complete passing receipt.

These finite controls support the independent proofs above; they do not prove the universal claims by themselves.

## Accepted BUCKETS boundary

Accepted BUCKETS source defines `BucketResult(numerators: tuple, bits: int)` and returns `BucketResult(tuple(output), spec.P)` after forming each output item as `(real, imag)` with exact integer rounding. Therefore `decode_round(M,B,q,sigma,r.numerators,r.bits,ledger)` is a valid numerical adapter when r is the genuine accepted BUCKETS result for the same M, B and sigma. The decoder's broader geometry includes all genuine sparse-branch geometry.

The interface carries no origin/authenticity tag and no sigma, tau, M or B metadata. A caller must supply matching parameters and separately retain the prior preparation/BUCKETS charges. This review checked the representation and mathematical map, not executable composition or provenance authentication. Even a type-correct fabricated tuple is simply a deterministic input, with no numerical-accuracy guarantee.

The component reads zero random bits and makes zero vector-source queries, root evaluations or coefficient-preparation calls. That fact pertains only to these two APIs; it does not make any of those upstream operations free. Repeated identical rounds are valid deterministic data and are not evidence of independent sampling. Full recovery remains outside the accepted scope.
