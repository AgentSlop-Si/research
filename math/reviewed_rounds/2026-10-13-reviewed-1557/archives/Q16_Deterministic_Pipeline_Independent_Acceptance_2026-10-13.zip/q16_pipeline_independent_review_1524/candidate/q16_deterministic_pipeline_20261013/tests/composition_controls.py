"""Fresh integration, rejection, provenance, width and accounting controls.

No predecessor test runner is imported. This test instrumenter is outside the
public pipeline interface and is never a scientific input to production.
"""
import hashlib
import json
from collections import Counter
from dataclasses import replace
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import pipeline as p
from compact_window import WindowSpec
from buckets import DyadicSource, BucketResult
from phase_medians import EstimateResult


class TraceLedger(p.CompositionLedger):
    instances = []

    def __init__(self):
        super().__init__()
        self.expected = Counter()
        self.work = self.storage = self.slots = self.params = 0
        self.maximum = self.param_max = 1
        self.records = self.reports = 0
        self.instances.append(self)

    def record(self, kind, inputs, output):
        fs = {'add': lambda a,b:a+b, 'subtract':lambda a,b:a-b,
              'multiply':lambda a,b:a*b, 'floor_divide':lambda a,b:a//b,
              'modulo':lambda a,b:a%b, 'binary_power':lambda n:2**n,
              'bit_and':lambda a,b:a&b, 'bit_length':lambda a:len(bin(a))-2}
        if kind in fs:
            assert fs[kind](*inputs) == output, kind
        widths = [max(1, len(bin(abs(v))) - 2) for v in (*inputs, output)]
        self.expected[kind] += 1
        self.work += 16 * (2 + sum(widths)) ** 2
        self.storage += widths[-1] + 1
        self.maximum = max(self.maximum, *widths)
        self.records += 1
        return super().record(kind, inputs, output)

    def parameter(self, value):
        if type(value) is int:
            width = max(1, len(bin(abs(value))) - 2)
            self.params += width
            self.param_max = max(self.param_max, width)
        return super().parameter(value)

    def event(self, name, count=1):
        self.expected[name] += count
        super().event(name, count)

    def allocate(self, count):
        assert type(count) is int and count >= 0
        self.expected['allocated_slots'] += count
        self.slots += count
        self.storage += count
        super().allocate(count)

    def report(self):
        result = super().report()
        events = sum(self.expected.values()) + 256
        width = self.maximum + len(bin(events)) - 2 + 2
        assert result['operations'] == dict(sorted(self.expected.items()))
        assert result['arithmetic_bit_work_upper'] == self.work
        assert result['bookkeeping_bit_work_upper'] == 512*events*width**2
        assert result['total_bit_work_upper'] == self.work + 512*events*width**2
        assert result['cumulative_storage_upper_bits'] == self.storage + 512*events*width
        assert result['max_observed_integer_bits'] == self.maximum
        assert result['allocated_slots'] == self.slots
        assert result['parameter_input_bits'] == self.params
        assert result['max_parameter_bits'] == self.param_max
        self.reports += 1
        return result


class TupleSubclass(tuple):
    pass


def main():
    spec = WindowSpec(64, 4, 1, 12)
    source = DyadicSource(tuple((((i % 5)-2, 2), ((i % 3)-1, 1)) for i in range(64)), 2)
    locations = ((1, 0), (3, 7), (63, 63))
    estimates = ((5, 9), (17, 4), (1, 0))
    p.CompositionLedger = TraceLedger
    result = p.run_pipeline(spec, source, 1, locations, estimates)
    ops = result.ledger['operations']
    K = len(result.candidates)
    expected_events = {
        'bucket_engine_constructor': 1, 'buckets_call': 6,
        'window_validation_call': 8, 'source_query': 6*spec.W,
        'decode_call': 3, 'aggregation_call': 1, 'estimate_call': 3,
        'median_call': 1, 'phase_preparation': 3*K,
        'membership_output': 3*spec.T,
        'bucket_binding_validation': 9, 'bound_bucket_production': 6,
        'estimate_binding_validation': 3, 'canonical_candidate_binding': 1,
        'location_composition': 3, 'estimation_composition': 3,
        'membership_tuple_copy': 3, 'estimate_tuple_copy': 3,
        'trace_tuple_copy': 6}
    for name, count in expected_events.items():
        assert ops.get(name, 0) == count, (name, ops.get(name), count)
    assert K <= 2*spec.T
    assert tuple(i for i, _ in result.output.pairs) == result.candidates
    assert all(row.candidates is result.candidates for row in result.estimation_trace)
    assert all(row.affine is locations[i] for i,row in enumerate(result.location_trace))
    assert all(row.affine is estimates[i] for i,row in enumerate(result.estimation_trace))
    assert result.output.bits == spec.P

    malformed = []
    base = [spec, source, 1, locations, estimates]
    def reject(name, args, wanted=ValueError):
        try:
            p.run_pipeline(*args)
        except wanted:
            malformed.append(name)
            TraceLedger.instances[-1].report()
        else:
            raise AssertionError('accepted malformed ' + name)
    def with_arg(at, value):
        args = base[:]
        args[at] = value
        return args
    for name, at, value in [
        ('spec_type',0,object()), ('q_bool',2,True), ('q_negative',2,-1), ('q_large',2,5),
        ('location_list',3,list(locations)), ('location_empty',3,()),
        ('location_subclass',3,TupleSubclass(locations)), ('entry_list',3,([1,0],)),
        ('entry_short',3,((1,),)), ('entry_long',3,((1,0,2),)),
        ('sigma_even',3,((2,0),)), ('sigma_bool',3,((True,0),)),
        ('sigma_zero',3,((0,0),)), ('sigma_modulus',3,((65,0),)),
        ('tau_negative',3,((1,-1),)), ('tau_modulus',3,((1,64),)),
        ('tau_float',3,((1,0.0),)), ('estimate_empty',4,()),
        ('estimate_even',4,((1,0),(3,1))), ('estimate_list',4,list(estimates)),
        ('source_type',1,object()), ('source_list',1,DyadicSource(list(source.values),2)),
        ('source_length',1,DyadicSource(source.values[:-1],2)),
        ('source_F_negative',1,DyadicSource(source.values,-1)),
        ('source_F_bool',1,DyadicSource(source.values,True)),
        ('wide_sigma',3,((2**40000+1,0),))]:
        reject(name, with_arg(at,value))
    assert TraceLedger.instances[-1].max_parameter_bits == 40001
    assert TraceLedger.instances[-1].operations['bucket_engine_constructor'] == 0
    invalid = list(source.values)
    invalid[33] = ((2**40000,0),(0,0))  # First queried t=-31 -> index 33.
    reject('reached_wide_source',with_arg(1,DyadicSource(tuple(invalid),2)))
    assert TraceLedger.instances[-1].max_integer_bits >= 40001
    assert TraceLedger.instances[-1].operations['source_query'] == 1

    # There is no public intermediary argument, even a correctly shaped one.
    try:
        p.run_pipeline(*base, numerators=((0,0),)*4)
    except TypeError:
        malformed.append('public_bucket_injection')
    else:
        raise AssertionError('public intermediary accepted')

    # Gate controls use privately manufactured diagnostic objects solely to
    # exercise rejection paths. This is not an external serialization contract.
    ledger = TraceLedger()
    context = p._Context(spec,source,locations,estimates,object())
    actual = result.location_trace[0].buckets
    good = p._BoundBuckets(context,context.capability,0,0,locations[0],spec,source,actual)
    assert p._read_buckets(context,good,0,0,ledger) is actual
    provenance = []
    altered_context = p._Context(spec,source,locations,estimates,object())
    wrongs = {
        'foreign_context': replace(good,context=altered_context),
        'foreign_capability': replace(good,capability=object()),
        'same_value_foreign_spec': replace(good,spec=WindowSpec(64,4,1,12)),
        'same_value_foreign_source': replace(good,source=DyadicSource(source.values,2)),
        'wrong_schedule_entry': replace(good,affine=locations[1]),
        'same_value_foreign_entry': replace(good,affine=tuple([1,0])),
        'wrong_role': replace(good,role=1), 'wrong_ordinal': replace(good,ordinal=1),
        'bucket_grid': replace(good,result=BucketResult(actual.numerators,13)),
        'bucket_type': replace(good,result=object()),
    }
    for name, bound in wrongs.items():
        try:
            p._read_buckets(context,bound,0,0,ledger)
        except ValueError:
            provenance.append(name)
        else:
            raise AssertionError('missed provenance ' + name)
    b = p._BoundBuckets(context,context.capability,1,0,estimates[0],spec,source,
                         result.estimation_trace[0].buckets)
    e = p._BoundEstimates(context,context.capability,0,result.candidates,b,
                           result.estimation_trace[0].estimates)
    assert p._read_estimates(context,e,0,result.candidates,ledger) is e.result
    for name, changed in [
        ('candidate_order',replace(e,candidates=tuple(reversed(result.candidates)))),
        ('same_value_candidate_copy',replace(e,candidates=tuple(list(result.candidates)))),
        ('estimate_foreign_context',replace(e,context=altered_context)),
        ('estimate_foreign_capability',replace(e,capability=object())),
        ('estimate_ordinal',replace(e,ordinal=1)),
        ('estimate_grid',replace(e,result=EstimateResult(e.result.numerators,13))),
        ('estimate_type',replace(e,result=object())),
        ('estimate_foreign_bucket',replace(e,buckets=good))]:
        try:
            p._read_estimates(context,changed,0,result.candidates,ledger)
        except ValueError:
            provenance.append(name)
        else:
            raise AssertionError('missed provenance ' + name)
    ledger.report()
    p.CompositionLedger = TraceLedger.__bases__[0]
    record = {
        'status':'PASS', 'source_sha256':hashlib.sha256((ROOT/'src/pipeline.py').read_bytes()).hexdigest(),
        'case':{'M':64,'B':4,'r':1,'P':12,'q':1,'location':locations,'estimation':estimates,
                'candidates':result.candidates,'pairs':result.output.pairs},
        'exact_event_checks':expected_events, 'full_pipeline_ledger':result.ledger,
        'malformed_rejections':malformed,'provenance_rejections':provenance,
        'accounting_instances':len(TraceLedger.instances),
        'reconstructed_primitive_records':sum(x.records for x in TraceLedger.instances),
        'reconstructed_reports':sum(x.reports for x in TraceLedger.instances),
        'wide_parameter_bits':40001, 'wide_reached_source_bits':40001,
        'executed_predecessor_tests':False,
        'limits':['No external bucket-origin deserializer. Private memory tampering is out of scope.',
                  'Full source immutability and unsampled validity are caller preconditions.']}
    (ROOT/'results/composition_controls.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ['status','accounting_instances',
        'reconstructed_primitive_records','reconstructed_reports']},indent=2))


if __name__ == '__main__':
    main()
