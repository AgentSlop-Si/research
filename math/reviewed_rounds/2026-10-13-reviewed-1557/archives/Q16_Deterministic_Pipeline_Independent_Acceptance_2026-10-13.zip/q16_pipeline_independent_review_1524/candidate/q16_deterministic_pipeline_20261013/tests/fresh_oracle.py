"""Fresh rational controls: no production calls, floats, Machin 1/5 formula or FFT.

This is a bounded fixture oracle, not an all-parameter proof or cost model.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from math import factorial, isqrt


@dataclass(frozen=True)
class R:
    lo: F
    hi: F

    def __post_init__(self):
        object.__setattr__(self, 'lo', F(self.lo))
        object.__setattr__(self, 'hi', F(self.hi))
        assert self.lo <= self.hi

    def __add__(self, other):
        b = as_r(other)
        return R(self.lo + b.lo, self.hi + b.hi)

    __radd__ = __add__

    def __neg__(self):
        return R(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + -as_r(other)

    def __mul__(self, other):
        b = as_r(other)
        values = [a * c for a in (self.lo, self.hi) for c in (b.lo, b.hi)]
        return R(min(values), max(values))

    __rmul__ = __mul__

    def __truediv__(self, other):
        b = as_r(other)
        assert not b.lo <= 0 <= b.hi
        return self * R(1 / b.hi, 1 / b.lo)

    def grid(self, bits):
        scale = 1 << bits
        lo = self.lo * scale
        hi = self.hi * scale
        return R(F(lo.numerator // lo.denominator, scale),
                 F(-((-hi.numerator) // hi.denominator), scale))

    def abs_bound(self):
        return max(abs(self.lo), abs(self.hi))


def as_r(x):
    return x if isinstance(x, R) else R(x, x)


def atan_reciprocal(q, terms=200):
    # Alternating-series sum with the signed next-term remainder.
    total = sum((F((-1) ** k, (2*k+1) * q ** (2*k+1))
                 for k in range(terms)), F(0))
    tail = F((-1) ** terms, (2*terms+1) * q ** (2*terms+1))
    return R(min(total, total + tail), max(total, total + tail))


@lru_cache(None)
def pi_interval():
    # atan(1/2)+atan(1/3)=pi/4 by tangent addition and first-quadrant signs.
    # Deliberately unrelated to production's 16 atan(1/5)-4 atan(1/239).
    return (4 * (atan_reciprocal(2) + atan_reciprocal(3))).grid(192)


@lru_cache(None)
def sine_pi(p, q):
    a = F(p, q) % 2
    sign = 1
    if a > 1:
        a = 2 - a
        sign = -1
    if a > F(1, 2):
        a = 1 - a
    if a == 0:
        return R(0, 0)
    if a == F(1, 2):
        return R(sign, sign)
    angle = pi_interval() * a
    midpoint = (angle.lo + angle.hi) / 2
    radius = (angle.hi - angle.lo) / 2
    terms = 64
    term = midpoint
    total = term
    for k in range(1, terms):
        term *= -midpoint * midpoint / ((2*k) * (2*k+1))
        total += term
    # All reduced midpoints lie in [0,2]. Taylor remainder and |sin'|<=1.
    tail = F(2 ** (2*terms+1), factorial(2*terms+1))
    enclosure = R(total - radius - tail, total + radius + tail).grid(112)
    return sign * enclosure


@lru_cache(None)
def root(M, k):
    k %= M
    return sine_pi(M + 4*k, 2*M), sine_pi(2*k, M)


def pair_add(a, b):
    return a[0] + b[0], a[1] + b[1]


def pair_mul(a, b):
    return a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0]


def round_even_fraction(x):
    x = F(x)
    base, rem = divmod(x.numerator, x.denominator)
    return base + int(2*rem > x.denominator or
                      (2*rem == x.denominator and base % 2 == 1))


def uniquely_rounded(a, bits):
    scale = 1 << bits
    low, high = round_even_fraction(a.lo * scale), round_even_fraction(a.hi * scale)
    assert low == high, ('oracle precision did not isolate rounding', bits, a)
    return low


def polynomial_coefficients(ell, r):
    # Deliberate quadratic nested multiplication, not production sliding sums.
    coeff = [1]
    for _ in range(2*r):
        product = [0] * (len(coeff)+ell-1)
        for a, value in enumerate(coeff):
            for b in range(ell):
                product[a+b] += value
        coeff = product
    return tuple(coeff)


@lru_cache(None)
def ideal_window(M, B, r):
    ell, T = 8*B, M//B
    radius, H, g = r*(ell-1), 3*T//4, T//4
    coefficients = polynomial_coefficients(ell, r)
    den = ell ** (2*r)
    # Phi is the direct DFT of the centered exact polynomial coefficients.
    normalizer = R(0, 0)
    for j in range(-g, g+1):
        phi = R(0, 0)
        for index, value in enumerate(coefficients):
            phi += root(M, j*(index-radius))[0] * F(value, den)
        normalizer += phi
    assert normalizer.lo > 0
    taps = []
    for index, value in enumerate(coefficients):
        t = index-radius
        # D_H is independently a finite cosine sum, including its t=0 limit.
        dirichlet = sum((root(M, j*t)[0] for j in range(-H, H+1)), R(0, 0))
        taps.append((t, dirichlet * F(M*value, den) / normalizer))
    return coefficients, normalizer, tuple(taps)


def direct_buckets(values, M, B, P, sigma, tau, taps, ideal=False):
    """Direct time-domain DFT. B=4 roots and M=64 scale are exact rationals.

    `taps` may be independent ideal intervals or certified rounded scalar data.
    The exact rounded branch has no production butterfly graph dependency.
    """
    assert M == 64 and B == 4
    scale = F(1, isqrt(M))
    output = []
    for j in range(B):
        total = (R(0, 0), R(0, 0)) if ideal else (F(0), F(0))
        for t, w in taps:
            sample = values[(sigma*t+tau) % M]
            z = F(sample[0][0], 1 << sample[0][1]), F(sample[1][0], 1 << sample[1][1])
            phase = root(B, -j*t)
            assert phase[0].lo == phase[0].hi and phase[1].lo == phase[1].hi
            phase = phase[0].lo, phase[1].lo
            product = pair_mul(z, phase)
            total = pair_add(total, (product[0]*w, product[1]*w))
        total = total[0]*scale, total[1]*scale
        output.append(total if ideal else tuple(round_even_fraction(a * (1 << P)) for a in total))
    return tuple(output)


def decode(M, B, q, sigma, numerators):
    selected = tuple(sorted(range(B), key=lambda j: (-sum(a*a for a in numerators[j]), j))[:q])
    T = M//B
    # Deliberately enumerate i directly, then order by residue offset, without
    # a modular-inverse algorithm or using the production decoder.
    members = []
    for j in selected:
        for residue in ((j*T-T//2+k) % M for k in range(T)):
            matches = [i for i in range(M) if sigma*i % M == residue]
            assert len(matches) == 1
            members.extend(matches)
    return selected, tuple(members)


def aggregate(M, memberships):
    threshold = (len(memberships)+1)//2
    return tuple(i for i in range(M) if sum(i in row for row in memberships) >= threshold)


def estimate(M, B, P, candidates, sigma, tau, buckets):
    T = M//B
    output = []
    for i in candidates:
        h = ((sigma*i % M + T//2)//T) % B
        phase = root(M, -tau*i)
        rounded_phase = tuple(F(uniquely_rounded(a, P+2), 1 << (P+2)) for a in phase)
        # Buckets remain numerators; cancellation of input/output P-grid occurs.
        product = pair_mul(buckets[h], rounded_phase)
        output.append(tuple(round_even_fraction(a) for a in product))
    return tuple(output)


def medians(candidates, rows):
    assert rows and len(rows) % 2 == 1
    middle = len(rows)//2
    return tuple((i, (sorted(row[j][0] for row in rows)[middle],
                      sorted(row[j][1] for row in rows)[middle]))
                 for j, i in enumerate(candidates))
