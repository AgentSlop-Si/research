"""Verify this report seal without importing any scientific module."""
from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
m=p/'MANIFEST.json';seal=json.loads((p/'SEAL.json').read_text())
assert sha(m.read_bytes())==seal['manifest_sha256']
manifest=json.loads(m.read_text())
for row in manifest['files']:
    f=p/row['path']
    assert f.is_file() and f.stat().st_size==row['bytes']
    assert sha(f.read_bytes())==row['sha256'],row['path']
assert len(manifest['files'])==seal['files']
print('PASS',len(manifest['files']),'review files and manifest seal')
