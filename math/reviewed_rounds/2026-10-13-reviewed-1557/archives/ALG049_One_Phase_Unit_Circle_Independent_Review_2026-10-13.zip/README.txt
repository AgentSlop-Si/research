ALG049 one-common-phase unit-circle exclusion: independent ACCEPT.

Start with REVIEW.txt for the theorem boundary, audit, and shorter proof.
INDEPENDENT_RESULTS.json records the full fresh exact reconstruction.
SHORT_PROOF_CHECKS.json records the two small modulo-7 certificates.
SMALL_CERTIFICATES.json additionally supplies direct rational Bezout proofs
for the reduced core polynomials in x=t^2.

Reproduce with Python 3 and SymPy 1.14.0:
  python3 review_independent.py
  python3 check_short_proof.py
No package installation is needed in the review environment.

No author or historical program is executed or imported. Frozen source
programs are included only as inert provenance in reviewed_author and in
the two source_archives. The candidate archive is preserved byte-for-byte.

Accepted scope: exactly the three pinned cycles, prescribed common phase
and compensating placements, identity effective separators, and six mixed
sign patterns, for all |w|=1. Broader arbitrary-phase questions remain open.
No Sheet/GitHub edit or novelty claim accompanies this review.
