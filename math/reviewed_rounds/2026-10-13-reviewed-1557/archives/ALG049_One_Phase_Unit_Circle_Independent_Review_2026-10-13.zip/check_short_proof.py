#!/usr/bin/env python3
"""Fresh exact reviewer control for the small modulo-7 proof."""
import json
from pathlib import Path
import sympy as S
x=S.Symbol('x')
checks=[
 ('--+',2515227*x**4+7084952*x**3-309638*x**2-3373592*x-1387029,
  1194611*x**3-3359059*x**2-6637503*x-2119993,
  -x**2-3*x-3,3*x**3+3*x**2-x-1),
 ('-++',1151*x**3-2384*x**2+603*x+1450,265*x**2-2706*x+341,
  x,3*x**2-2*x+3)]
records=[]
for label,a,b,u,v in checks:
 am,bm=S.Poly(a,x,modulus=7),S.Poly(b,x,modulus=7)
 if am.degree()!=S.degree(a,x) or bm.degree()!=S.degree(b,x):raise ValueError('Degree dropped')
 if not S.Poly(u*a+v*b-1,x,modulus=7).is_zero:raise ValueError('Invalid identity')
 resultant=S.resultant(a,b,x)
 if resultant%7==0:raise ValueError('Resultant unexpectedly vanishes')
 if a.subs(x,0)==0:raise ValueError('Zero t was not excluded')
 records.append({'signs':label,'prime':7,'A_mod7':str(am.as_expr()),'B_mod7':str(bm.as_expr()),
 'U':str(u),'V':str(v),'identity':'U*A+V*B=1 in F_7[x]','degrees_preserved':True,'resultant_mod7':str(resultant%7),'A_at_zero':str(a.subs(x,0))})
out={'status':'PASS','logic':'Both degrees survive reduction; the displayed Bezout identity makes the resultant nonzero modulo 7, so its integer value is nonzero and the two integer polynomials have no common complex root.','records':records}
Path(__file__).with_name('SHORT_PROOF_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
