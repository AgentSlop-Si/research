ALG049 fixed one-phase unit-circle exclusion: CANDIDATE

This packet extends precisely the accepted six radical words to one shared
unit phase w(t)=(1+it)/(1-it), real t, plus w=-1 at infinity.
Candidate conclusion: all six fixed patterns have no scalar-unitary solution.
The original radical amplitude remains fixed; t=s reproduces accepted words.

Start with PROOF.md. All full equations and exact integer Bezout certificates
are in CANDIDATE_EQUATIONS.json. Run python3 verify_certificate.py to check
with the standard library only. Assertions must be enabled. This is an author
certificate check, not independent acceptance. Independent review is pending.

Optional full regeneration uses python3 derive_candidate.py with SymPy 1.14.0.
No historical checker is imported or run. Only inert source texts/JSON are
included under pinned_sources. SOURCE_PINS.json freezes their provenance.

No Sheet or GitHub changes. No arbitrary-independent-phase exclusion,
Fourier result, general FFT lower bound, speed result or novelty claim.
