# ALG049: candidate exclusion for the complete pinned one-phase circle

Date: 13 October 2026 UTC. Status: CANDIDATE, pending independent review.
The accepted Q(i) theorem and the separately accepted six radical words remain unchanged. Parent status remains TO RESEARCH, priority 42. No Sheet or GitHub changes.

## Theorem, with its exact boundary

Keep precisely these directed cycle orders:

1. (0,1,2,3,4,5,6,7)
2. (0,1,3,4,5,6,2,7)
3. (0,1,4,5,6,7,3,2)

The convention is M e_order[j] = weight[j] e_order[(j+1) mod 8]. For a common unit complex number w, the first cycle has seven weights 1 and a final weight -1. The second has weight[0]=w, weight[6]=conjugate(w), weight[7]=-1, all others 1. The third has weight[2]=w², weight[5]=conjugate(w)², weight[7]=-1, all others 1.

Let K(M)=(2I-M)(I-M)^(-1), use identity effective separators, and let
B_e(w)=K(M1)^e1 K(M2(w))^e2 K(M3(w))^e3
for exactly e in {--+, -+-, -++, +--, +-+, ++-}.

Candidate theorem: for every |w|=1 and every one of these six patterns, B_e(w) is not scalar-unitary. In fact, its (0,1) Gram entry is nonzero everywhere on the unit circle.

This theorem concerns one shared phase, with exactly the prescribed powers, compensating placements, factor order, and graph orders. It does not address independently assigned phases, other cycle orders, arbitrary separators that change these effective cycles, other sign patterns, or longer words. It does not prove Fourier equality/impossibility, a general FFT bound, novelty, or practical speed.

## 1. Domain and fixed radical scalar

For t in R, set w(t)=(1+it)/(1-it). Its denominator is nonzero and |w(t)|=1. Put u=1+t²>0. Equivalently w=(1+it)²/u and conjugate(w)=(1-it)²/u. Every unit phase except -1 has this form: if w=x+iy with x²+y²=1 and x!=-1, then t=y/(1+x). Add the separate point t=infinity, defined to mean w=-1. This is a complete parameterization of the circle, not a limit-based root test.

All cycles are full 8-cycles, all their weights have modulus one, and each total weight is -1. Their characteristic polynomial is X^8+1, so I-M and 2I-M are invertible, and det K=257/2. Their undirected supports are pairwise different. Their pairwise composed permutation supports are different, which proves noncommutation for every phase, rather than only for generic t.

Retain the original fixed positive radical s, satisfying 2s^8=257. It is a constant, not a new free amplitude. If B*B=cI, invertibility forces c>0. Writing sigma=e1+e2+e3 in {+1,-1}, determinants force c^4=(257/2)^sigma. Therefore the unique allowed positive scalar is c=s² for sigma=+1 and c=(2/257)s^6=1/s² for sigma=-1. The original six accepted radical words are exactly t=s. The new parameter t does not change these determinant-required scalars.

For rational t, w(t) belongs to Q(i), and w=-1 does too; these cases were already excluded by the accepted Q(i) theorem. The new content is exclusion for every real irrational t within this same one-phase family. No field-wide radical exclusion is asserted.

## 2. Exact factor construction and complete equations

For each signed real cycle of the given order, write Cj for its matrix with all non-wrap weights 1 and wrap weight -1. Define coordinate-indexed gauge exponents

- h1=(0,0,0,0,0,0,0,0)
- h2=(0,1,1,1,1,1,1,0)
- h3=(0,0,0,0,0,2,2,2)

With Qj=diag(w^hj[k]), the prescribed weighted cycle is Qj Cj Qj*. The derivation constructs (2I-Cj)(I-Cj)^(-1) by exact rational inversion and conjugates its entries using these gauge differences. It similarly inverts K(Cj) exactly. The factor denominators are 2 for a forward factor and 257 for an inverse factor.

A separately written author verifier constructs the weighted cycles directly from the edge lists, without this gauge construction, and uses the identities

K(M) = (3I + M + M² + ... + M^7)/2,
K(M)^(-1) = (129I - 64M - 32M² - 16M³ - 8M^4 - 4M^5 - 2M^6 - M^7)/257.

It verifies M^8=-I, both inverse products, and (I-M)K=2I-M exactly as Laurent-polynomial matrix identities. These are newly authored derivation and verification programs, not an independent human review.

For a pattern let D=2^(number of + signs) 257^(number of - signs). Thus D=132098 for net -1 and D=1028 for net +1. Set A=D B, and H=A* A. H has integer Laurent coefficients in w with exponents between -6 and 6. Complex conjugation on these coefficients sends w^k to w^(-k).

For H_ab(w)=sum(k=-6..6) h_ab,k w^k, define the exact complex polynomial

P_ab(t)=sum(k=-6..6) h_ab,k (1+i sign(k)t)^(2|k|) u^(6-|k|),

using 1 for the k=0 power. Then (B*B)_ab=P_ab(t)/(D²u^6). Its real and imaginary coefficients are integers of degree at most 12. Because the common denominator is strictly positive, the following 63 polynomial equations are necessary and sufficient for scalar unitarity:

- Re P_ab=0 and Im P_ab=0 for every 0<=a<b<8: 56 equations
- P_aa-P_00=0 for 1<=a<8: 7 real equations

Hermitian symmetry supplies the lower triangle, and diagonal imaginary parts are identically zero. With B invertible, these equations force a positive scalar. They neither discard nor introduce any real t through denominator clearing.

For an explicit fixed-scalar system, add the 64th equation:

- P_00 - D²u^6 s² = 0 when sigma=+1
- 257 P_00 - 2D²u^6 s^6 = 0 when sigma=-1

with the domain guard s>0, 2s^8=257, t real. The 63-equation system and this 64-equation system have the same real solutions by the determinant argument above.

CANDIDATE_EQUATIONS.json serializes every one of these equations for all six patterns, all 64 Laurent Gram entries, and the explicit fixed-scalar equation. Ordinary polynomial arrays are ascending degree: [a0,a1,...] means sum aj t^j. Laurent exponent maps use integer exponent keys. Each fixed-scalar record represents A(t)+s^k B(t)=0. No unstated numerical solver is used.

## 3. Exact certificate excluding every finite real t

It is enough to consider P_01. The complete factorizations from the fresh derivation are below. Put x=t² and u=1+t².

For --+:

Re P_01 = 1028u²(2515227x^4+7084952x³-309638x²-3373592x-1387029)
Im P_01 = -2056tu²(1194611x³-3359059x²-6637503x-2119993)

For -+-:

Re P_01 = -1028u³(2008449x³+7728707x²+4442003x+1140433)
Im P_01 = -528392tu³(5787x²+686x+6035)

For -++:

Re P_01 = 2056u³(1151x³-2384x²+603x+1450)
Im P_01 = 2056tu³(265x²-2706x+341)

For +--:

Re P_01 = 4u²(124487276x^4-484078183x³-1335802957x²-1108863861x-349431803)
Im P_01 = 3084tu²(633561x³+1467675x²+953835x+136105)

For +-+:

Re P_01 = 8u²(111607x^4+1903312x³+4464894x²+2379816x+198147)
Im P_01 = 16tu²(192727x³+438457x²+423293x+171419)

For ++-:

Re P_01 = -8u³(487699x³+1302771x²+869501x-334691)
Im P_01 = -16448tu³(395x²+588x+97)

For each pattern, the machine-readable certificate supplies integer polynomials U(t),V(t), a strictly positive integer C, and m=2 or 3 with the exact coefficient identity

U(t) Re P_01(t) + V(t) Im P_01(t) = C(1+t²)^m.

The powers m in the stated pattern order are 2,3,3,2,2,3. The standard-library verifier multiplies the stored integer polynomials and checks every coefficient of this identity. Thus the proof does not rely on trusting a gcd label, root isolation heuristic, floating-point tolerance, or an unverified symbolic-solver verdict. Since the right side is strictly positive for all real t, the two Gram components never vanish simultaneously. No real t solves even these two of the complete equations.

Several cases also have immediate sign proofs: the real component for -+- is strictly negative, and that for +-+ is strictly positive. The imaginary components for +-- and ++- can vanish only at t=0, where their real components are nonzero. The uniform integer identities cover all six patterns, including --+ and -++.

## 4. Infinity handled separately

At t=infinity, use w=-1 directly in each Laurent Gram entry. No denominator manipulation or leading-coefficient assumption is needed. The exact (0,1) Gram entries are:

- --+: 2515227/16974593
- -+-: -2008449/16974593
- -++: 1151/514
- +--: 124487276/4362470401
- +-+: 111607/132098
- ++-: -487699/132098

Every entry is nonzero. Thus infinity supplies no solution. Together with the finite-real proof, this excludes the complete pinned one-phase circle for all six patterns.

## 5. Source and reproduction controls

SOURCE_PINS.json records ten frozen source bodies, their exact hashes and sizes, and the combined author archive's hash. The combined archive's proof, radical addendum, radical results, review-status overlay and unresolved-scope text were read as inert input and verified to match the local source bodies. Existing review reports remain untouched. No historical source program was executed, imported or evaluated.

The new verifier additionally specializes its own symbolic Gram entries at t=s in Q(i,s), with exact Fraction coefficients reduced using s^8=257/2. All six complete (0,1) obstruction coefficient vectors match the separately accepted RADICAL_RESULTS.json. This checks that the extension contains exactly the original sample, rather than a similar but altered placement or orientation.

Reproduce the stored-certificate check with Python 3 and no third-party package:

python3 verify_certificate.py

This reconstructs the full Laurent matrices, all 384 fixed-scalar-system equations, every integer Bezout identity, all six infinity entries, the original radical specializations and all source-file hashes. It writes VERIFIED.json. Assertions must remain enabled; do not use Python's -O option.

To regenerate the equations and Bezout coefficients, run:

python3 derive_candidate.py
python3 verify_certificate.py

Derivation uses SymPy 1.14.0 exact rational/polynomial operations. Verification uses only the Python standard library. No dependency installation is needed for the stored-certificate check. Re-running an author's programs is reproducibility, not independent review. Both programs were authored anew for this candidate; no existing research checker was run.

This is a bounded exact verification calculation, with no claimed general algorithmic or bit-complexity improvement. Integer sizes, polynomial products, preparation, serialization and data movement are real verification work. Nothing here supplies free arbitrary-phase synthesis or an FFT implementation.

## 6. Remaining gate

An independent reviewer should rebuild the weighted cycles from the pinned convention; verify the complete Gram polynomials, phase coverage and denominator guards; replay the integer identities with separately written arithmetic; and check the separate infinity and t=s controls. Until that review accepts the exact scope, this result remains CANDIDATE.

The unrestricted arbitrary-phase three-stage N=8 question remains open. In particular, the other two cycles' independently chosen weights, other graph orders, and broader changing-cycle word families have not been classified. Accepted Q(i), finite root-of-unity and six-radical-word results keep their prior scopes and acceptance statuses.
