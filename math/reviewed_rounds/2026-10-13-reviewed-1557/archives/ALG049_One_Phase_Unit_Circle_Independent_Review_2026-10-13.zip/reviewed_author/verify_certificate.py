#!/usr/bin/env python3
"""Fresh standard-library certificate verifier for ALG049 fixed one-phase family.
This verifier does not import SymPy, author derivation code, or historical code.
All decisions use exact integer or Fraction arithmetic. Outputs VERIFIED.json.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product, combinations
from math import comb
import hashlib, json
ROOT=Path(__file__).resolve().parent
N=8
ORDERS=((0,1,2,3,4,5,6,7),(0,1,3,4,5,6,2,7),(0,1,4,5,6,7,3,2))
WEIGHT_EXPONENTS=((0,0,0,0,0,0,0,0),(1,0,0,0,0,0,-1,0),(0,0,2,0,0,-2,0,0))
# Univariate/Laurent integer polynomial arithmetic, indexed by exact exponent.
def plus(a,b):
 ans=dict(a)
 for k,v in b.items(): ans[k]=ans.get(k,0)+v
 return {k:v for k,v in ans.items() if v}
def times(a,b):
 ans={}
 for k,v in a.items():
  for h,u in b.items(): ans[k+h]=ans.get(k+h,0)+v*u
 return {k:v for k,v in ans.items() if v}
def scalar(a,v): return {k:v*x for k,x in a.items() if v*x}
def conjugate(a): return {-k:v for k,v in a.items()}
def zero(): return [[{} for _ in range(N)] for _ in range(N)]
def eye(): return [[{0:1} if i==j else {} for j in range(N)] for i in range(N)]
def matmul(a,b):
 ans=zero()
 for i,j,k in product(range(N),repeat=3): ans[i][j]=plus(ans[i][j],times(a[i][k],b[k][j]))
 return ans
def matadd(a,b): return [[plus(a[i][j],b[i][j]) for j in range(N)] for i in range(N)]
def matscale(a,v): return [[scalar(p,v) for p in row] for row in a]
def star(a): return [[conjugate(a[j][i]) for j in range(N)] for i in range(N)]
def fromcoeffs(c): return {k:int(x) for k,x in enumerate(c) if int(x)}
def unitpow(m): return {2*k:comb(m,k) for k in range(m+1)}
def clear_denominator(p):
 # w^k = (1+it)^(2k)/(1+t²)^k for k>=0; conjugate for k<0.
 # Six powers cover every Gram Laurent exponent in this family.
 rr={}; ii={}
 for k,v in p.items():
  assert abs(k)<=6
  base={2*j:comb(6-abs(k),j) for j in range(7-abs(k))}
  real={j:comb(2*abs(k),j)*((-1)**(j//2)) for j in range(0,2*abs(k)+1,2)}
  imag={j:comb(2*abs(k),j)*((-1)**((j-1)//2))*(1 if k>=0 else -1) for j in range(1,2*abs(k)+1,2)}
  rr=plus(rr,scalar(times(real,base),v)); ii=plus(ii,scalar(times(imag,base),v))
 return rr,ii
def cycle(order,exponents):
 ans=zero()
 for j,x in enumerate(order): ans[order[(j+1)%N]][x]={exponents[j]:1 if j<7 else -1}
 return ans
I=eye()
cycles=[cycle(order,exp) for order,exp in zip(ORDERS,WEIGHT_EXPONENTS)]
factors=[]
for order,exponents,m in zip(ORDERS,WEIGHT_EXPONENTS,cycles):
 assert sorted(order)==list(range(N)) and sum(exponents)==0
 # Every weight is +/-w^k, hence unit when |w|=1; total product -1.
 powers=[I]
 for k in range(1,N+1): powers.append(matmul(powers[-1],m))
 assert powers[8]==matscale(I,-1)
 # Geometric numerators independently constructed directly from weighted cycles.
 kp=matscale(I,3); km=matscale(I,129)
 for k in range(1,N):
  kp=matadd(kp,powers[k]); km=matadd(km,matscale(powers[k],-2**(7-k)))
 assert matmul(kp,km)==matscale(I,514)==matmul(km,kp)
 assert matmul(matadd(I,matscale(m,-1)),kp)==matscale(matadd(matscale(I,2),matscale(m,-1)),2)
 factors.append({1:kp,-1:km})
supports=[{frozenset((o[j],o[(j+1)%N])) for j in range(N)} for o in ORDERS]
for a,b in combinations(range(3),2):
 assert supports[a]!=supports[b]
 # Different composed permutation supports certify noncommutation for EVERY phase.
 left=matmul(cycles[a],cycles[b]); right=matmul(cycles[b],cycles[a])
 assert [[bool(p) for p in row] for row in left]!=[[bool(p) for p in row] for row in right]
packet=json.loads((ROOT/'CANDIDATE_EQUATIONS.json').read_text())
assert packet['orders']==[list(o) for o in ORDERS]
assert len(packet['results'])==6
records=[]
expected_patterns=['--+','-+-','-++','+--','+-+','++-']
assert [r['signs'] for r in packet['results']]==expected_patterns
for row in packet['results']:
 signs=tuple(1 if c=='+' else -1 for c in row['signs'])
 D=2**signs.count(1)*257**signs.count(-1)
 assert D==row['denominator_D']
 A=matmul(matmul(factors[0][signs[0]],factors[1][signs[1]]),factors[2][signs[2]])
 G=matmul(star(A),A)
 stored=[[{int(k):int(v) for k,v in entry.items()} for entry in r] for r in row['Gram_Laurent_numerator']]
 assert G==stored
 equations=[]
 for i in range(N):
  for j in range(i+1,N):
   for part,p in zip(('real','imag'),clear_denominator(G[i][j])):
    equations.append(({'type':'offdiag','row':i,'col':j,'part':part},p))
 for i in range(1,N):
  real,imag=clear_denominator(plus(G[i][i],scalar(G[0][0],-1)))
  assert not imag
  equations.append(({'type':'diagonal_difference','row':i,'col':0,'part':'real'},real))
 assert len(row['equations'])==len(equations)==63
 for saved,(descriptor,poly) in zip(row['equations'],equations):
  assert {k:v for k,v in saved.items() if k!='coefficients'}==descriptor
  assert fromcoeffs(saved['coefficients'])==poly
 q00,zero_imag=clear_denominator(G[0][0]); assert not zero_imag
 assert fromcoeffs(row['G00_numerator_coefficients'])==q00
 fixed=row['fixed_scalar_equation']; sigma=sum(signs)
 assert fixed['net_sign']==sigma
 assert fromcoeffs(fixed['constant_in_s_coefficients'])==scalar(q00,257 if sigma<0 else 1)
 assert fixed['nonconstant_s_power']==(6 if sigma<0 else 2)
 assert fromcoeffs(fixed['nonconstant_in_s_coefficients'])==scalar(unitpow(6),-D*D*(2 if sigma<0 else 1))
 cert=row['G01_integer_Bezout_certificate']; aa=fromcoeffs(cert['A_coefficients']); bb=fromcoeffs(cert['B_coefficients'])
 C=int(cert['positive_integer_multiplier']); power=cert['power_of_1_plus_t_squared']
 assert C>0 and power in (2,3)
 assert plus(times(aa,equations[0][1]),times(bb,equations[1][1]))==scalar(unitpow(power),C)
 # For every real t, C*(1+t²)^power > 0. Both G01 components cannot vanish.
 infinity=[[sum(v*(-1 if k%2 else 1) for k,v in p.items()) for p in r] for r in G]
 assert infinity==row['infinity_Gram_numerator']
 assert infinity[0][1]!=0
 records.append({'signs':row['signs'],'verified_equations':64,'positive_Bezout_multiplier':str(C),
 'positive_Bezout_power':power,'finite_real_t_solutions':0,'infinity_G01':str(F(infinity[0][1],D*D)),
 'infinity_solutions':0})
# Exact specialization t=s into the original radical field, using a fresh
# complex-pair power basis with s^8=257/2. Historical JSON is inert input only.
def realadd(a,b): return tuple(x+y for x,y in zip(a,b))
def realneg(a): return tuple(-x for x in a)
def realmul(a,b):
 c=[F(0)]*8
 for j,x in enumerate(a):
  for k,y in enumerate(b): c[(j+k)%8]+=x*y*(F(257,2) if j+k>=8 else 1)
 return tuple(c)
rz=(F(0),)*8; ro=(F(1),)+(F(0),)*7
cz=(rz,rz); co=(ro,rz)
def cadd(a,b): return (realadd(a[0],b[0]),realadd(a[1],b[1]))
def cmul(a,b): return (realadd(realmul(a[0],b[0]),realneg(realmul(a[1],b[1]))),realadd(realmul(a[0],b[1]),realmul(a[1],b[0])))
def cscalar(a,q): return tuple(tuple(q*x for x in p) for p in a)
w=(tuple(F(x,255) for x in (-259,0,4,0,-4,0,4,0)),tuple(F(x,255) for x in (0,-4,0,4,0,-4,0,4)))
wb=(w[0],realneg(w[1])); assert cmul(w,wb)==co
ss=(tuple(F(1 if j==1 else 0) for j in range(8)),rz)
is_=(rz,ss[0]); assert cmul(w,cadd(co,cscalar(is_,-1)))==cadd(co,is_)
powers={0:co}
for j in range(1,7): powers[j]=cmul(powers[j-1],w); powers[-j]=cmul(powers[-j+1],wb)
radical=json.loads((ROOT/'pinned_sources'/'RADICAL_RESULTS.json').read_text())
for current,old in zip(packet['results'],radical['results']):
 assert current['signs']==old['signs']
 obs=old['first_exact_obstruction']; assert (obs['row'],obs['column'])==(0,1)
 val=cz
 for k,v in current['Gram_Laurent_numerator'][0][1].items(): val=cadd(val,cscalar(powers[int(k)],F(v)))
 val=cscalar(val,F(1,current['denominator_D']**2))
 target=tuple(tuple(F(v) for v in p) for p in obs['real_and_imaginary_coefficients_degrees_0_to_7'])
 assert val==target
# Check frozen source bytes without executing any source program.
pins=json.loads((ROOT/'SOURCE_PINS.json').read_text())
for p in pins['files']:
 data=(ROOT/p['stored_path']).read_bytes()
 assert len(data)==p['bytes'] and hashlib.sha256(data).hexdigest()==p['sha256']
result={'status':'AUTHOR_CERTIFICATE_VERIFIED; INDEPENDENT_REVIEW_PENDING',
 'arithmetic':'Exact integers and fractions only; Python standard library',
 'scope':'Exactly three pinned cycle orders, weight placements, identity effective separators, six mixed sign patterns, one common unit phase.',
 'complete_equations_checked':384,'finite_real_t_solutions':0,'infinity_solutions':0,
 'original_radical_G01_specializations_matched':6,'pairwise_noncommutation_for_all_phases':True,
 'historical_programs_executed':False,'source_hashes_verified':len(pins['files']),
 'results':records}
(ROOT/'VERIFIED.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
