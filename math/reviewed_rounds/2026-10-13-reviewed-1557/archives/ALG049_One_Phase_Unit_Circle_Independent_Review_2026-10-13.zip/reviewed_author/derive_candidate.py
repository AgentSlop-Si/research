#!/usr/bin/env python3
"""Fresh ALG049 exact one-phase derivation; never imports historical research code."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import sympy as S
N=8
ORDERS=((0,1,2,3,4,5,6,7),(0,1,3,4,5,6,2,7),(0,1,4,5,6,7,3,2))
GAUGES=((0,)*8,(0,1,1,1,1,1,1,0),(0,0,0,0,0,2,2,2))
# Laurent polynomials with integer coefficients; conjugation reverses exponent.
def add(a,b):
 c=a.copy()
 for k,v in b.items():
  c[k]=c.get(k,0)+v
  if not c[k]: del c[k]
 return c
def scale(a,v): return {k:x*v for k,x in a.items() if x*v}
def mul(a,b):
 c={}
 for k,v in a.items():
  for l,u in b.items(): c[k+l]=c.get(k+l,0)+v*u
 return {k:v for k,v in c.items() if v}
def conj(a): return {-k:v for k,v in a.items()}
def mm(a,b):
 c=[[{} for j in range(N)] for i in range(N)]
 for i in range(N):
  for j in range(N):
   for k in range(N): c[i][j]=add(c[i][j],mul(a[i][k],b[k][j]))
 return c
def adj(a): return [[conj(a[j][i]) for j in range(N)] for i in range(N)]
def coeffs(p):
 p=S.Poly(p,t,domain=S.QQ)
 return [str(p.nth(i)) for i in range(p.degree()+1)] if p else ['0']
def laurent_json(a): return {str(k):str(v) for k,v in sorted(a.items())}
t=S.Symbol('t',real=True)
u=1+t*t
# Re/Im of (1+it)^(2k) * (1+t²)^(6-k) for k>=0.
complex_powers={k:S.Poly(S.expand((1+S.I*t)**(2*k)*u**(6-k)),t) for k in range(7)}
def clear_laurent(p):
 z=sum(v*(complex_powers[k].as_expr() if k>=0 else S.conjugate(complex_powers[-k].as_expr())) for k,v in p.items())
 return tuple(S.Poly(S.expand(q),t,domain=S.QQ) for q in S.expand_complex(z).as_real_imag())
factors=[]
for order,gauge in zip(ORDERS,GAUGES):
 c=S.zeros(N)
 for j,x in enumerate(order): c[order[(j+1)%N],x]=1 if j<7 else -1
 k=(2*S.eye(N)-c)*(S.eye(N)-c).inv()
 h=k.inv()
 assert k*h==S.eye(N)
 assert c**8==-S.eye(N)
 assert k.det()==S.Rational(257,2)
 ff={}
 for sign,b,d in ((1,k,2),(-1,h,257)):
  nn=b*d
  assert all(x.q==1 for x in nn)
  ff[sign]=[[({gauge[i]-gauge[j]:int(nn[i,j])} if nn[i,j] else {}) for j in range(N)] for i in range(N)]
 factors.append(ff)
rows=[]
for signs in product((-1,1),repeat=3):
 if len(set(signs))<2: continue
 label=''.join('+' if x==1 else '-' for x in signs)
 d=2**signs.count(1)*257**signs.count(-1)
 a=mm(mm(factors[0][signs[0]],factors[1][signs[1]]),factors[2][signs[2]])
 g=mm(adj(a),a)
 assert all(g[i][j]==conj(g[j][i]) for i in range(N) for j in range(N))
 equations=[]
 for i in range(N):
  for j in range(i+1,N):
   for part,p in zip(('real','imag'),clear_laurent(g[i][j])):
    equations.append({'type':'offdiag','row':i,'col':j,'part':part,'coefficients':coeffs(p)})
 for i in range(1,N):
  pp=clear_laurent(add(g[i][i],scale(g[0][0],-1)))
  assert pp[1].is_zero
  equations.append({'type':'diagonal_difference','row':i,'col':0,'part':'real','coefficients':coeffs(pp[0])})
 polys=[S.Poly(sum(S.Rational(c)*t**k for k,c in enumerate(eq['coefficients'])),t) for eq in equations]
 first_re,first_im=polys[:2]
 gcd=S.gcd(first_re,first_im)
 bezout_a,bezout_b,bezout_g=S.gcdex(first_re,first_im)
 assert bezout_a*first_re+bezout_b*first_im==bezout_g
 m=2 if label in ('--+','+--','+-+') else 3
 assert bezout_g.as_expr()==S.expand(u**m)
 lcm=S.ilcm(*[q.q for pp in (bezout_a,bezout_b,bezout_g) for q in pp.all_coeffs()])
 integer_bezout={'A_coefficients':coeffs(bezout_a*lcm),'B_coefficients':coeffs(bezout_b*lcm),
 'positive_integer_multiplier':str(lcm),'power_of_1_plus_t_squared':m,
 'identity':'A*ReNumerator(G01)+B*ImNumerator(G01)=positive_integer_multiplier*(1+t^2)^power'}
 allgcd=polys[0]
 for p in polys[1:]: allgcd=S.gcd(allgcd,p)
 print(label,'d=',d,'G01 real=',S.factor(first_re.as_expr()),'imag=',S.factor(first_im.as_expr()),'gcd=',S.factor(gcd.as_expr()),'allgcd=',S.factor(allgcd.as_expr()),flush=True)
 infinity=[[sum(g[i][j].get(k,0)*(-1 if k%2 else 1) for k in g[i][j]) for j in range(N)] for i in range(N)]
 print(' infinity G01=',infinity[0][1],flush=True)
 rows.append({'signs':label,'denominator_D':d,'Gram_Laurent_numerator':[[laurent_json(x) for x in row] for row in g],
 'finite_t_Gram_denominator':'D^2*(1+t^2)^6','equations':equations,
 'G00_numerator_coefficients':coeffs(clear_laurent(g[0][0])[0]),
 'fixed_scalar_equation':{'net_sign':sum(signs),'constant_in_s_coefficients':coeffs(clear_laurent(g[0][0])[0]*(257 if sum(signs)<0 else 1)),
 'nonconstant_s_power':6 if sum(signs)<0 else 2,'nonconstant_in_s_coefficients':coeffs(-d*d*u**6*(2 if sum(signs)<0 else 1)),
 'domain':'s>0 and 2*s^8=257; t real'},
 'G01_integer_Bezout_certificate':integer_bezout,'G01_gcd':coeffs(gcd),'all_equations_gcd':coeffs(allgcd),
 'infinity_Gram_numerator':infinity})
Path(__file__).with_name('CANDIDATE_EQUATIONS.json').write_text(json.dumps({'orders':ORDERS,'gauge_exponents_by_coordinate':GAUGES,'results':rows},indent=2)+'\n')
