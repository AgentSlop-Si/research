#!/usr/bin/env python3
"""Independent ALG049 audit, authored 2026-10-13. Imports no author code.
Reconstructs factors by rational-function matrix inversions, rather than
using either candidate gauge matrices or candidate geometric numerators.
"""
from pathlib import Path
import hashlib,json,zipfile,time
import sympy as S
from sympy.polys.matrices import DomainMatrix
BASE=Path(__file__).resolve().parent
SRC=BASE/'reviewed_author'
ARCH=BASE/'source_archives'/'ALG049_One_Phase_Unit_Circle_Candidate_2026-10-13.zip'
EXPECTED='c992b2d89dc39e64bdeb0e5d4db34844b4c725547ff6c16601a30d3efec7eebe'
checks=0

def check(b,label):
 global checks
 if not b: raise RuntimeError('FAILED: '+label)
 checks+=1

def sha(b):return hashlib.sha256(b).hexdigest()
b=ARCH.read_bytes();check(len(b)==78353 and sha(b)==EXPECTED,'exact archive pin')
with zipfile.ZipFile(ARCH) as z:
 for n in z.namelist():
  check(not n.startswith('/') and '..' not in Path(n).parts,'safe member '+n)
  check(z.read(n)==(SRC/n).read_bytes(),'archive matches inspected '+n)
manifest=json.loads((SRC/'MANIFEST.json').read_text())
for f in manifest['files']:
 b=(SRC/f['path']).read_bytes();check(len(b)==f['bytes'] and sha(b)==f['sha256'],'manifest '+f['path'])
pins=json.loads((SRC/'SOURCE_PINS.json').read_text())
for f in pins['files']:
 b=(SRC/f['stored_path']).read_bytes();check(len(b)==f['bytes'] and sha(b)==f['sha256'],'source pin '+f['stored_path'])
combined=BASE/'source_archives'/pins['combined_archive']['path']; b=combined.read_bytes()
check(len(b)==pins['combined_archive']['bytes'] and sha(b)==pins['combined_archive']['sha256'],'combined archive pin')
with zipfile.ZipFile(combined) as z:
 for f in pins['files']:
  if '::' in f['source_path']:
   check(z.read(f['source_path'].split('::')[1])==(SRC/f['stored_path']).read_bytes(),'combined source equality')

w,t,x=S.symbols('w t x',real=True)
F=S.QQ.frac_field(w)
I=DomainMatrix.from_Matrix(S.eye(8)).convert_to(F)
orders=((0,1,2,3,4,5,6,7),(0,1,3,4,5,6,2,7),(0,1,4,5,6,7,3,2))
weights=((1,1,1,1,1,1,1,-1),(w,1,1,1,1,1,1/w,-1),(1,1,w*w,1,1,w**-2,1,-1))
matrices=[]; factors=[]
for k,(order,wt) in enumerate(zip(orders,weights)):
 m=S.zeros(8)
 for j in range(8):m[order[(j+1)%8],order[j]]=wt[j]
 check(S.prod(wt)==-1,'cycle product')
 md=DomainMatrix.from_Matrix(m).convert_to(F)
 check(md**8 == -I,'M eighth power')
 check(m.charpoly().all_coeffs()==[1,0,0,0,0,0,0,0,1],'characteristic polynomial')
 kp=(2*I-md)*(I-md).inv()
 km=(I-md)*(2*I-md).inv()
 check(kp*km==I and km*kp==I,'independent inverse products')
 check((I-md)*kp==2*I-md,'defining K equation')
 check(kp.det()==F.from_sympy(S.Rational(257,2)),'determinant')
 # Independently check the identities printed in the proof against actual inversion.
 geo=3*I
 invgeo=129*I
 for p in range(1,8):
  geo+=md**p
  invgeo-=(2**(7-p))*(md**p)
 check(2*kp==geo and 257*km==invgeo,'printed geometric identities')
 matrices.append(m);factors.append({'+':kp,'-':km})
for a in range(3):
 for c in range(a+1,3):
  support=lambda m:{(i,j) for i in range(8) for j in range(8) if m[i,j]!=0}
  undirected=lambda m:{tuple(sorted(p)) for p in support(m)}
  check(undirected(matrices[a])!=undirected(matrices[c]),'distinct undirected supports')
  check(support(matrices[a]*matrices[c])!=support(matrices[c]*matrices[a]),'all-phase noncommutation support')

packet=json.loads((SRC/'CANDIDATE_EQUATIONS.json').read_text())
check(packet['orders']==[list(o) for o in orders],'pinned orders')
patterns=['--+','-+-','-++','+--','+-+','++-']
check([r['signs'] for r in packet['results']]==patterns,'exact six patterns')
u=S.Poly(1+t*t,t,domain=S.QQ)
# Gaussian rational-function substitution avoids the candidate binomial expansion.
GF=S.QQ_I.frac_field(t); T=GF.gens[0]; W=(GF.one+GF.from_sympy(S.I)*T)/(GF.one-GF.from_sympy(S.I)*T)
wp={k:W**k for k in range(-6,7)}
poly=lambda v:S.Poly.from_list([S.Rational(q) for q in reversed(v)],t,domain=S.QQ)
radical=json.loads((SRC/'pinned_sources/RADICAL_RESULTS.json').read_text())
minimal=S.Poly(2*t**8-257,t,domain=S.QQ)
check(minimal.is_irreducible,'radical minimal polynomial irreducibility')
radical_inv=S.invert(u**6,minimal)
results=[]; small=[]
for r,rr in zip(packet['results'],radical['results']):
 label=r['signs'];print('Rebuilding',label,flush=True)
 D=2**label.count('+')*257**label.count('-');check(r['denominator_D']==D,'factor denominator')
 B=factors[0][label[0]]*factors[1][label[1]]*factors[2][label[2]]
 # Coefficients are rational and w on the circle: adjoint substitutes w->1/w.
 adj=DomainMatrix.from_Matrix(B.to_Matrix().T.subs(w,1/w)).convert_to(F)
 gram=adj*B
 gm=gram.to_Matrix(); polys={}; laurents={}
 for a in range(8):
  for c in range(8):
   z=S.cancel(gm[a,c]*D**2*w**6)
   z=S.Poly(z,w,domain=S.ZZ)
   lm={p[0]-6:int(v) for p,v in z.terms() if v}
   check(all(-6<=k<=6 for k in lm),'Laurent degree guard')
   target={int(k):int(v) for k,v in r['Gram_Laurent_numerator'][a][c].items()}
   check(lm==target,'full Laurent Gram entry')
   laurents[a,c]=lm
   substituted=sum((GF.from_sympy(v)*wp[k] for k,v in lm.items()),GF.zero)*(1+T*T)**6
   cleared=S.Poly(GF.to_sympy(substituted),t,domain=S.QQ_I)
   re=S.Poly(sum(S.re(v)*t**p[0] for p,v in cleared.terms()),t,domain=S.ZZ)
   im=S.Poly(sum(S.im(v)*t**p[0] for p,v in cleared.terms()),t,domain=S.ZZ)
   check(re.degree()<=12 and im.degree()<=12,'degree at most twelve')
   re=re.set_domain(S.QQ);im=im.set_domain(S.QQ)
   polys[a,c]=(re,im)
   if a==c:check(im.is_zero,'diagonal reality')
 expected=[]
 for a in range(8):
  for c in range(a+1,8):
   for part,p in zip(('real','imag'),polys[a,c]):expected.append(({'type':'offdiag','row':a,'col':c,'part':part},p))
 for a in range(1,8):expected.append(({'type':'diagonal_difference','row':a,'col':0,'part':'real'},polys[a,a][0]-polys[0,0][0]))
 check(len(expected)==len(r['equations'])==63,'equation count')
 for (meta,p),stored in zip(expected,r['equations']):
  check({k:v for k,v in stored.items() if k!='coefficients'}==meta,'equation identity')
  check(poly(stored['coefficients'])==p,'equation coefficients')
 check(poly(r['G00_numerator_coefficients'])==polys[0,0][0],'G00 numerator')
 sigma=label.count('+')-label.count('-'); eq=r['fixed_scalar_equation']
 check(eq['net_sign']==sigma and eq['nonconstant_s_power']==(2 if sigma==1 else 6),'scalar exponent')
 check(poly(eq['constant_in_s_coefficients'])==polys[0,0][0]*(1 if sigma==1 else 257),'fixed scalar constant term')
 check(poly(eq['nonconstant_in_s_coefficients'])==-D*D*(u**6)*(1 if sigma==1 else 2),'fixed scalar radical term')
 pr,pi=polys[0,1]
 cert=r['G01_integer_Bezout_certificate'];C=int(cert['positive_integer_multiplier']);m=cert['power_of_1_plus_t_squared']
 check(C>0 and m in (2,3),'positive certificate right side')
 check(poly(cert['A_coefficients'])*pr+poly(cert['B_coefficients'])*pi==C*u**m,'integer Bezout identity')
 check(poly(r['G01_gcd'])==S.gcd(pr.set_domain(S.ZZ),pi.set_domain(S.ZZ)).set_domain(S.QQ),'G01 gcd')
 allgcd=expected[0][1].set_domain(S.ZZ)
 for _,p in expected[1:]:allgcd=S.gcd(allgcd,p.set_domain(S.ZZ))
 check(poly(r['all_equations_gcd'])==allgcd.set_domain(S.QQ),'all equation gcd')
 # Infinity is a separately constructed ordinary rational matrix problem.
 inst=[]
 for m0,sig in zip(matrices,label):
  mm=m0.subs(w,-1); k=(2*S.eye(8)-mm)*(S.eye(8)-mm).inv()
  inst.append(k if sig=='+' else k.inv())
 binf=inst[0]*inst[1]*inst[2];ginf=binf.T*binf
 check(ginf[0,1]!=0,'infinity obstruction nonzero')
 check((D*D*ginf).tolist()==r['infinity_Gram_numerator'],'full separately reconstructed infinity matrix')
 # Two exact rational sample controls, independently inverting numeric Cayley matrices.
 for tt in (S.Rational(-3,2),S.Rational(2,3)):
  ww=(1+S.I*tt)/(1-S.I*tt); direct=[]
  for mm,sig in zip(matrices,label):
   mm=DomainMatrix.from_Matrix(mm.subs(w,ww).applyfunc(S.expand_complex)).convert_to(S.QQ_I);ii=DomainMatrix.from_Matrix(S.eye(8)).convert_to(S.QQ_I)
   kk=(2*ii-mm)*(ii-mm).inv()
   direct.append(kk if sig=='+' else kk.inv())
  directB=(direct[0]*direct[1]*direct[2]).to_Matrix()
  directG=sum(S.conjugate(directB[k,0])*directB[k,1] for k in range(8))
  predicted=(pr.eval(tt)+S.I*pi.eval(tt))/(D*D*(1+tt*tt)**6)
  check(S.cancel(directG-predicted)==0,'independent rational sample G01')
 check(rr['signs']==label,'radical sign mapping')
 obs=rr['first_exact_obstruction'];check((obs['row'],obs['column'])==(0,1),'radical entry mapping')
 for p,target in zip((pr,pi),obs['real_and_imaginary_coefficients_degrees_0_to_7']):
  spec=(p*radical_inv).mul_ground(S.Rational(1,D**2)).rem(minimal)
  check([str(spec.nth(j)) for j in range(8)]==target,'radical exact field vector')
 # Smaller independent certificates operate in x=t^2 after removing real-positive factors.
 rp=S.div(pr,u**m)[0].primitive()[1]
 ip=S.div(pi,u**m)[0]
 ip=S.div(ip,S.Poly(t,t))[0].primitive()[1]
 ax=S.Poly(sum(v*x**(p[0]//2) for p,v in rp.terms()),x,domain=S.QQ)
 bx=S.Poly(sum(v*x**(p[0]//2) for p,v in ip.terms()),x,domain=S.QQ)
 check(S.expand(ax.as_expr().subs(x,t*t))==rp.as_expr(),'even real core')
 check(S.expand(bx.as_expr().subs(x,t*t))==ip.as_expr(),'even imaginary core')
 check(ax.eval(0)!=0,'t zero control')
 aa,bb,gg=S.gcdex(ax,bx);check(gg.is_one and aa*ax+bb*bx==gg,'independent reduced-variable certificate')
 den=S.ilcm(*[v.q for v in aa.all_coeffs()+bb.all_coeffs()]); ai=aa*den;bi=bb*den
 small.append({'signs':label,'real_core_A_in_x':str(ax.as_expr()),'imaginary_core_B_in_x':str(bx.as_expr()),'U':str(ai.as_expr()),'V':str(bi.as_expr()),'C':str(den),'identity':'U*A+V*B=C>0; x=t^2, and A(0)!=0'})
 results.append({'signs':label,'equations_checked':64,'Laurent_entries_checked':64,'integer_Bezout_verified':True,'infinity_G01':str(ginf[0,1]),'radical_specialization_verified':True,'rational_sample_controls':2,'Re_P01_factor':str(S.factor(pr.as_expr())),'Im_P01_factor':str(S.factor(pi.as_expr()))})
 print('PASS',label,'infinity',ginf[0,1],flush=True)

out={'verdict':'ACCEPT','scope':'Exactly the pinned three cycles, prescribed shared phase and six mixed sign words. Every unit w; no broader classification.','archive_sha256':EXPECTED,'assertions_checked':checks,'author_programs_executed':False,'historical_programs_executed':False,'method':'Fresh rational-function matrix inversion over Q(w), exact Gaussian Cayley substitution, independent polynomial checks and exact field remainder specialization.','sympy_version':S.__version__,'results':results}
(BASE/'INDEPENDENT_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
(BASE/'SMALL_CERTIFICATES.json').write_text(json.dumps(small,indent=2)+'\n')
print(json.dumps(out,indent=2))
