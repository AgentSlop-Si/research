# Q16 deterministic pipeline independent review

13 October 2026

## Decision and scope

ACCEPT the frozen deterministic integration candidate at the boundary stated
below. No source or documentation repair is required. This decision concerns
the new composition and its conservative source-level finite-bit work and
cumulative auxiliary-storage account. It does not change the scope of the
four component acceptances or accept the full sparse-recovery theorem.

The reviewed archive is
`Q16_Deterministic_Pipeline_Integration_Candidate_2026-10-13.zip`, SHA-256
`ffc70c8d7896057b8241e0b7d3cd99affc78c4a8ac514c5da9110638ec85b596`.
The integration source is `src/pipeline.py`, SHA-256
`c3a2da5a11ceba2cfa0df7bbb346525013e740e7bc170b3d27dfadc3f2be4d3b`.
Its original Library identity is `libfile_8b295ba85708819187bc35d47b5dc7d2`.

The accepted input consists of the exact WindowSpec reduced domain, an already
represented and previously valid deeply immutable DyadicSource, an exact
integer q in [0,B], a nonempty exact immutable location schedule, and a
positive odd-length exact immutable estimation schedule. Each affine entry
is an exact pair of an odd residue sigma and a residue tau. No independence,
distribution, global normalization, input-construction history or norm promise
is inferred from these values. The actual candidates and the ideal target
defined below are conditional on this supplied deterministic schedule.

## Sealed evidence and execution discipline

The reviewer independently checked the archive hash, the candidate manifest
seal and all 36 manifest entries before importing scientific code. Each of
the four dependency hashes matches its copied acceptance verdict. In addition,
the copied verdict bytes were compared against the actual, separately retained
accepted-review archives for WINDOW v2, BUCKETS, location and phase/medians.
Every available embedded component source in those archives was also compared.
The phase/median acceptance archive hash is the supplied
`8a1719a2c1f187a9aa31aa0f84584f9cde1f368ddd7697a7704f43a3e1f1ab5a`.
The complete archive and verdict bindings are in `results/provenance.json`.

All five current scientific source modules were read before execution.
The old algorithm and proof were inspected only as mathematical text. No
historical scientific program, predecessor test runner, producer test runner,
or candidate package verifier was executed. The only scientific execution was
the byte-bound current components, this integration, newly authored reviewer
programs, and explicitly identified in-memory mutations of the new glue.
No frozen scientific source or candidate evidence file was edited.

The independent oracle was designed from the formulas and component interfaces,
without importing or running any of the candidate's oracle or control scripts.
The candidate's reported test totals are not counted as independent tests.

## Closed execution and provenance

The public function has precisely five scientific inputs. There is no public
ledger, prepared window, engine, root table, bucket row, candidate tuple,
estimate row, callback, cache or deserialization parameter. Static inspection
finds one ledger constructor and one BucketEngine constructor. Its imports
are limited to dataclasses and the four pinned components; there is no random
sampler, dynamic execution, source file I/O or hidden backend in the glue.

The run first validates the complete schedules, then constructs a fresh context
and a fresh identity token. It creates an actual BucketEngine with the same
ledger used throughout. That constructor performs WINDOW preparation, certified
root preparation, reciprocal-square-root preparation and the general error
bound calculation. There is no supplied preparation receipt in place of work.

For each location and estimation entry, `_produce` reads that exact entry and
calls this engine on the context source with its sigma and tau. It binds the
returned BucketResult to the context, token, role, ordinal, affine tuple,
source and spec. The gate checks identity, role, ordinal and P grid and returns
the same BucketResult object. Numerical fields are fully parsed by the actual
downstream consumer. No reencoding or replacement row occurs in between.

Location reads sigma from the same immutable schedule entry. Tau belongs in
source querying and spectral phase, not in the inverse frequency permutation.
The only aggregated membership lists are those returned by these executions.
Aggregation creates one increasing, distinct candidate tuple. Every estimate
receives that identical tuple and the matching affine and BucketResult. The
estimate gate binds the returned row to the same context, token, ordinal,
originating bucket binding and candidate identity, and forwards that exact row.
Medians receives those rows and that same canonical candidate tuple.

Consequently a median column has an executed frequency meaning; it is not an
unrelated supplied column whose provenance is assumed. The current candidate
closes that prior composition obligation. The gates are checked defensive
invariants within a trusted program, not cryptographic authentication of
arbitrary external objects. Private-context forgery, monkeypatching, Python
memory tampering and concurrent mutation remain outside the contract. The
review's deliberate monkeypatching is a test instrument, not an accepted
production input path.

## Parsing and exact integer widths

The top-level spec, source and schedule types are exact; mutable or subclass
containers do not enter the scientific interface. Exact integer checks reject
booleans and integer subclasses. Every supplied schedule is completely checked
before numerical preparation. All reached parameter integer widths are read
and charged before numeric-domain rejection, including beta numerator and
denominator, q, F and each affine field.

The pipeline checks the source header and length. BUCKETS checks each queried
complex sample, each queried dyadic pair, its exact integer fields, exponent
range and Cartesian amplitude. It charges the actual reached integer widths
before rejection. The independent suite includes 16,385-bit malformed fields,
a beta denominator of that width, and a last-tap, second-coordinate rejection
after the complete 63-query prefix. None is silently replaced with a machine
word width.

The prior validity and deep immutability of unsampled source entries remain a
caller premise. A specific fixture changes the one unsampled location into an
invalid mutable value and confirms that this reduced call does not scan it.
That successful call is intentionally outside the mathematical input domain;
it documents the validation boundary, not an additional valid-domain claim.
Representation, dense input validation, normalization, original source storage
and any physical random-access cost must be added by a caller that incurs them.

## Location and support proof

All numerical bucket coordinates are integers on the same grid 2^-P. The
decoder's integer squared-energy ordering therefore gives the exact order of
the represented magnitudes, with the documented lower-index tie rule.

For even T, the B half-open cells jT-T/2 through jT+T/2-1 partition the M
residues. An odd sigma is invertible modulo the power-of-two M. A location
round therefore has exactly qT distinct memberships. With h=ceil(n_l/2),
aggregation uses exactly those memberships and retains a frequency at h votes.
If K candidates survive, K*h <= n_l*qT. Thus

    K <= min(M, floor(n_l*qT / ceil(n_l/2))) <= min(M, 2qT).

The even-location extension really uses a non-strict half threshold; it is not
silently changed into a strict majority. Estimation length remains positive
and odd. These facts hold for q=0, q=B, repeated schedules and exact ties.
No ideal-bucket ranking stability or recovery-success event is inferred.

## Sign scale window and the numerical target

Let w_t be the exact supported compact window from the accepted construction,
with the source normalizer C. For a round (sigma,tau), the ideal bucket is

    b_j = M^(-1/2) sum_t w_t v[(sigma*t+tau) mod M]
                       exp(-2*pi*sqrt(-1)*j*t/B).

This is the ordinary negative-sign unnormalized B-point DFT after folding,
followed by the scale 1/sqrt(M). The oracle reconstructs it by a direct sum.
There is no additional 1/B or 1/M DFT factor. Window normalization C is retained.

For an actual pipeline candidate i, define

    h = floor(((sigma*i mod M)+T/2)/T) mod B,
    z = b_h exp(-2*pi*sqrt(-1)*tau*i/M).

The estimator is the certified numerical version of this value. Fixed-point
division by the phase grid is rescaling only; no division by the filter
response occurs. This ideal value generally includes a nontrivial response
and contributions from other frequencies. It is not asserted to equal the
exact unwindowed Fourier coefficient. The independent exact mixed-source
fixtures and the deliberate wrong-sigma, wrong-tau and column mutations
distinguish these conventions.

With rho=2^-P, b=log2(B), W the support size and A=2M^2, the constructor's
returned dyadic error certificate equals exactly

    E_B = (A + 2W*rho)*(1+rho)^(b+1) - A + rho.

Accepted component contracts apply to matching actual objects here. For each
estimate, its complex error relative to z is bounded by

    eta = (1+rho)*E_B + A*rho + rho.

Indeed phat*bhat-p*b = phat*(bhat-b)+(phat-p)*b, with |phat|<=1+rho,
|b|<=A, bucket error <=E_B and phase error <=rho; final complex rounding
contributes at most rho. This does not require a recovery-success event.

Define Z_i as the coordinatewise median of the ideal z values for the actual
candidate i and supplied estimation rounds. If two lists differ pointwise by
at most eta in one coordinate, their middle order statistics differ by at most
eta. The returned complex coefficient is therefore within sqrt(2)*eta of Z_i.
If a strict majority of the ideal estimates is within a of a chosen x_i, the
returned coefficient is within sqrt(2)*(a+eta) of x_i. The majority can depend
on i. This remains conditional; arbitrary schedules do not establish it.
The front-end bound eta<=64(m+1)M^2*rho follows under the inherited precision
premises. It does not validate theorem-scale execution.

## Shared cumulative resource account

One CompositionLedger passes through initial validation, complete preparation,
every BUCKETS call, every decoder, membership aggregation, every estimate,
median extraction and the new binding and trace work. The only extra ledger
primitives needed by the location component are charged bitwise-and and
bit-length operations. The consumers use the supplied ledger without replacing
it or requiring an incompatible exact type.

The independent trace reconstructs each recorded arithmetic result, its input
and output magnitude widths using binary strings, the primitive charge
16*(2+sum widths)^2, produced signed-integer bits, parameter-width totals,
allocation slots and event counts. It separately reconstructs N, H and the
final 512*N*H^2 work and 512*N*H storage envelopes. It checks both the partial
WINDOW snapshot and final pipeline snapshot; the latter includes prior work.

The glue's actual allocation calls sum to exactly

    17 + 18*n_l + 25*n_e slots.

The supplied schedules and source remain input storage; retained references
are paid. Numerical tuples are shared by reference rather than copied anew.
Explicit membership, estimate-row and trace tuple-copy events total
2*(n_l+n_e). Candidate parsing and downstream coordinate copies are charged
inside the accepted consumers. Actual inventories also check one constructor,
n_l+n_e+2 spec validations, n_l+n_e BUCKETS calls, (n_l+n_e)*W source queries,
twice that many Cartesian alignments, n_l*qT memberships, n_e*K phases, one
aggregation, one median call and n_l+2*n_e bucket-binding checks.

The two producer-side documentation corrections are present in the sealed
RESOURCE_LEDGER: the general event bound contains n_l*m for bounded Euclid,
including q=0; tuple-copy events are 2*(n_l+n_e). There is no residual conflict
with the unchanged scientific source or measured allocations.

Full schedule-counter widths, beta encoding widths, source precision F,
working precision P, window r, intermediate integer widths and failed reached
encodings are retained in the source-level account. The accepted preparation
cost is additional to the listed execution term, not omitted. At the separately
assumed source regime, the conditional form remains
O((B+T+qT)*poly_d(m+h)), including beta-field width h when not fixed.

Storage is cumulative allocation plus produced integer bits and a conservative
bookkeeping envelope. It upper-bounds source-model peak auxiliary storage;
it is not a resident-memory measurement. In particular, diagnostic traces
retain all scheduled bucket arrays, all location membership arrays and all
estimation rows. No one-row streaming peak claim is made. Source serialization,
artifact hashing, packaging, this review, external I/O, Python interpreter
details and practical wall time are outside the numerical ledger.

All new loops have finite supplied-tuple bounds. Accepted components retain
fixed finite scalar loops, bounded Euclid, finite FFT stages and finite exact
sorts. No adaptive tolerance loop, random retry, hidden cap refusal or dense
fallback is introduced. This is mathematical finite-bit source-model
termination; physical host-totality is not asserted.

## New independent controls

The detailed completed totals are in `VERDICT.json`,
`results/numerical_summary.json` and `results/adversarial_summary.json`.

The exact/rational oracle uses pi/4=atan(1/2)+atan(1/3), distinct from the
production Machin identity. It bounds each alternating arctangent tail,
evaluates exact rational Taylor monomials with outward 144-bit dyadic rounding,
and includes both finite Taylor remainder and pi-argument uncertainty. It uses
direct polynomial convolution and spectral polynomial evaluation of Phi to
construct C, and a finite root sum to construct the Dirichlet factor. These
avoid the production sliding convolution and sine-quotient evaluation route.

It independently rounds uniquely determined taps, roots and scales, performs
a recursive even/odd FFT over exact Fractions, and rounds only the prescribed
final fixed-point values. The production implementation instead uses iterative
bit reversal and staged integer butterflies. Separate direct ideal Fourier
sums check bucket and phase error; separate interval middle-order statistics
check the ideal-median target. Candidate membership is derived by exhaustive
finite inverse relations and direct vote counting, without the production
Euclidean inverse or aggregation sort.

Six complete pipeline fixtures cover M=64,128,256; B=4,8,16; r=1,2;
P=8,12,16; mixed Cartesian dyadics, zero ties, an off-origin impulse and a
quarter tone; even and odd location schedules; q=0, q=B and partial support;
odd estimation lengths 1,3,5; and both exact and irrational reciprocal-square
roots. Their candidate counts are respectively 27,64,0,97,20,29. Every actual
bucket, selected-bin tuple, ordered membership tuple, candidate tuple,
estimate row and final numerical pair is checked exactly. Direct ideal-target
error checks supplement these exact fixed-point comparisons.

Sixty malformed public calls cover header, exact-type, shape, range, exponent,
amplitude, schedule parity, very-wide values and forbidden public-intermediate
arguments. Twenty-eight direct binding mismatches cover context, capability,
source, spec, affine identity, role, ordinal, output type, grid and candidate
identity/order. Fourteen scientific/accounting glue mutants are detected by
exact outputs or independent call/allocation inventories. Four additional
gate-disabling mutants are detected by the previously rejected wrong binding
being accepted. Mutation failures are expected controls, not candidate defects.
No mutant is written into the frozen candidate.

These finite tests corroborate the source proof and inherited component
contracts. They do not constitute an all-input experimental proof, a new audit
of all historical theorem premises, or evidence of practical theorem-scale
performance. The acceptance does not rely on the candidate's own test receipts.

## Remaining boundaries

The accepted improvement is a real closed deterministic execution with bound
provenance and cumulative accounting. Remaining external obligations are prior
valid input representation and normalization, generation of fair independent
schedules, the probabilistic success argument, full E(beta) sparse recovery,
the exceptional dense branch, outer transfer and all-length dispatch. Exact
unwindowed-spectrum recovery, host totality, physical RAM/I/O performance,
optimized exponents, practical speed and novelty are not accepted here.

No Sheet, GitHub, publication or access-permission changes were made during
this review. The reproducible report is preserved privately.
