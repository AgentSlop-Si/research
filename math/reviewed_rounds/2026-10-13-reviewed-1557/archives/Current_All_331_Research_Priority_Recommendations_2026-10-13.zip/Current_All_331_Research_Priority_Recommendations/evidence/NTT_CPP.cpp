#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using u32=uint32_t; using u64=uint64_t;
static constexpr u32 MOD=998244353u, PRIMITIVE=3u;
static inline u32 plusm(u32 a,u32 b){u32 c=a+b; return (c>=MOD)?c-MOD:c;}
static inline u32 minusm(u32 a,u32 b){return (a>=b)?a-b:a+MOD-b;}
static inline u32 mulm(u32 a,u32 b){return (u64)a*b%MOD;}
static u32 powm(u32 a,u32 b){u32 res=1;while(b){if(b&1)res=mulm(res,a);a=mulm(a,a);b>>=1;}return res;}

struct Plan {
  int n,lg;
  vector<u32> roots;
  vector<int> rev;
  vector<int> dif4_map;
  u32 imag;
  explicit Plan(int n_):n(n_){
    if(n<2 || (n&(n-1)) || n>(1<<23))throw runtime_error("n must be power of 2 between 2 and 2^23");
    lg=__builtin_ctz((unsigned)n);
    rev.resize(n);roots.resize(n);dif4_map.resize(n);
    // Natural output index for the mixed-radix (4,4,...,2) DIF schedule.
    auto make_dif4_map=[&](auto&&self,int size)->vector<int>{
      if(size==1)return {0};
      if(size==2)return {0,1};
      int q=size/4;auto child=self(self,q);vector<int>out;out.reserve(size);
      for(int c=0;c<4;++c)for(int v:child)out.push_back(4*v+c);
      return out;
    };
    dif4_map=make_dif4_map(make_dif4_map,n);
    for(int i=0;i<n;++i)rev[i]=i?((rev[i>>1]>>1)|((i&1)<<(lg-1))):0;
    u32 w=powm(PRIMITIVE,(MOD-1)/n); roots[0]=1;
    for(int i=1;i<n;++i)roots[i]=mulm(roots[i-1],w);
    imag=roots[n/4]; // n>=4 when used
  }
  vector<u32> bitrev_copy(const vector<u32>& x) const {
    vector<u32> a(n);
    for(int i=0;i<n;++i)a[rev[i]]=x[i];
    return a;
  }
  vector<u32> unbitrev_copy(const vector<u32>& x) const {
    vector<u32> a(n);
    for(int i=0;i<n;++i)a[rev[i]]=x[i];
    return a;
  }

  vector<u32> radix2(const vector<u32>& x) const {
    auto a=bitrev_copy(x);
    for(int len=2;len<=n;len<<=1){
      int half=len>>1, step=n/len;
      for(int base=0;base<n;base+=len){
        for(int j=0;j<half;++j){
          u32 u=a[base+j], r=a[base+j+half];
          u32 v=j?mulm(r,roots[j*step]):r;
          a[base+j]=plusm(u,v);
          a[base+j+half]=minusm(u,v);
        }
      }
    }
    return a;
  }

  vector<u32> fused_radix4(const vector<u32>& x) const {
    auto a=bitrev_copy(x);
    int m=1;
    if(lg&1){
      for(int j=0;j<n;j+=2){
        u32 v0=a[j],v1=a[j+1];
        a[j]=plusm(v0,v1);a[j+1]=minusm(v0,v1);
      }
      m=2;
    }
    u32 iunit=(n>=4)?imag:1;
    while(m<n){
      int len=4*m, step=n/len;
      for(int base=0;base<n;base+=len){
        for(int j=0;j<m;++j){
          u32 A=a[base+j];
          u32 B=a[base+j+m];
          u32 C=a[base+j+2*m];
          u32 D=a[base+j+3*m];
          if(j){
            B=mulm(B,roots[2*j*step]);
            C=mulm(C,roots[j*step]);
            D=mulm(D,roots[3*j*step]);
          }
          u32 p=plusm(A,B),q=minusm(A,B);
          u32 r=plusm(C,D),s=mulm(minusm(C,D),iunit);
          a[base+j]=plusm(p,r);
          a[base+j+m]=plusm(q,s);
          a[base+j+2*m]=minusm(p,r);
          a[base+j+3*m]=minusm(q,s);
        }
      }
      m=len;
    }
    return a;
  }

  vector<u32> dif_radix4(const vector<u32>&x) const {
    vector<u32>a=x;
    int L=n;
    while(L>=4){
      int q=L/4,step=n/L;
      for(int base=0;base<n;base+=L){
        for(int j=0;j<q;++j){
          u32 x0=a[base+j],x1=a[base+j+q],x2=a[base+j+2*q],x3=a[base+j+3*q];
          u32 A=plusm(x0,x2),B=minusm(x0,x2);
          u32 C=plusm(x1,x3),D=mulm(minusm(x1,x3),imag);
          u32 y0=plusm(A,C), y1=plusm(B,D),y2=minusm(A,C),y3=minusm(B,D);
          if(j){y1=mulm(y1,roots[j*step]);y2=mulm(y2,roots[2*j*step]);y3=mulm(y3,roots[3*j*step]);}
          a[base+j]=y0;a[base+j+q]=y1;a[base+j+2*q]=y2;a[base+j+3*q]=y3;
        }
      }
      L/=4;
    }
    if(L==2){
      for(int j=0;j<n;j+=2){u32 x0=a[j],x1=a[j+1];a[j]=plusm(x0,x1);a[j+1]=minusm(x0,x1);}
    }
    vector<u32>out(n);
    for(int j=0;j<n;++j)out[dif4_map[j]]=a[j];
    return out;
  }

  void split_rec(u32* a,int len) const{
    if(len==1)return;
    if(len==2){u32 x=a[0],y=a[1];a[0]=plusm(x,y);a[1]=minusm(x,y);return;}
    int q=len/4,half=len/2, step=n/len;
    for(int j=0;j<q;++j){
      u32 x0=a[j],x1=a[j+q],x2=a[j+half],x3=a[j+3*q];
      u32 e0=plusm(x0,x2),e1=plusm(x1,x3);
      u32 o0=minusm(x0,x2),o1=mulm(minusm(x1,x3),imag);
      a[j]=e0;
      a[j+q]=e1;
      u32 t1=plusm(o0,o1),t3=minusm(o0,o1);
      if(j){t1=mulm(t1,roots[j*step]);t3=mulm(t3,roots[3*j*step]);}
      a[j+half]=t1; a[j+3*q]=t3;
    }
    split_rec(a,half);
    split_rec(a+half,q);
    split_rec(a+3*q,q);
  }
  vector<u32> splitradix(const vector<u32>& x) const {
    vector<u32> a=x;
    split_rec(a.data(),n);
    return unbitrev_copy(a);
  }

  vector<u32> forward_auto(const vector<u32>& x) const {
    if(n<=4096)return radix2(x);
    return dif_radix4(x);
  }
  vector<u32> inverse_by_radix2(const vector<u32>& x) const {
    vector<u32> reversed=x;
    reverse(reversed.begin()+1,reversed.end());
    auto ans=radix2(reversed);
    u32 ni=powm(n,MOD-2);
    for(auto& v:ans)v=mulm(v,ni);
    return ans;
  }
};

// Bluestein fallback for any n dividing MOD-1 (and padded length <=2^23).
// Identity: jk = C(j,2) + C(k,2) + j - C(k-j,2).
// This avoids a primitive 2n-th root (important at even supported lengths).
struct Bluestein {
  int n,m;
  Plan plan;
  vector<u32> chirp, inputphase, outputphase, kernel_fft;
  static int get_m(int n){
    if(n<=0 || (MOD-1)%n)throw runtime_error("Bluestein length must divide MOD-1");
    long long m=1;while(m<2LL*n-1)m<<=1;
    if(m>(1<<23))throw runtime_error("Bluestein padded size exceeds 2^23");
    return (int)m;
  }
  explicit Bluestein(int n_):n(n_),m(get_m(n_)),plan(m) {
    u32 w=powm(PRIMITIVE,(MOD-1)/n);
    chirp.resize(n);inputphase.resize(n);outputphase.resize(n);
    u32 pw=1,prev=1;
    chirp[0]=1;
    for(int j=1;j<n;++j){chirp[j]=mulm(chirp[j-1],prev);prev=mulm(prev,w);}
    pw=1;
    for(int k=0;k<n;++k){inputphase[k]=mulm(chirp[k],pw);outputphase[k]=chirp[k];pw=mulm(pw,w);}
    vector<u32> kernel(m);kernel[0]=1;
    // kernel at displacement t = omega^{-t(t-1)/2}, for signed integer t.
    for(int t=1;t<n;++t){
      u32 ep=((u64)t*(t-1)/2)%n;
      u32 en=((u64)t*(t+1)/2)%n;
      kernel[t]=powm(w,(n-ep)%n);
      kernel[m-t]=powm(w,(n-en)%n);
    }
    kernel_fft=plan.forward_auto(kernel);
  }
  vector<u32> forward(const vector<u32>& x) const {
    if((int)x.size()!=n)throw runtime_error("Bluestein input size mismatch");
    vector<u32> a(m);
    for(int j=0;j<n;++j)a[j]=mulm(x[j],inputphase[j]);
    a=plan.forward_auto(a);
    for(int i=0;i<m;++i)a[i]=mulm(a[i],kernel_fft[i]);
    // F_+^{-1}: reversing the frequency array before another F_+ and divide m.
    reverse(a.begin()+1,a.end());
    a=plan.forward_auto(a);
    u32 mi=powm(m,MOD-2);
    vector<u32> out(n);
    for(int k=0;k<n;++k)out[k]=mulm(mulm(a[k],mi),outputphase[k]);
    return out;
  }
  vector<u32> inverse(const vector<u32>& y)const{
    vector<u32> v=y;
    reverse(v.begin()+1,v.end());
    auto out=forward(v);
    u32 ni=powm(n,MOD-2);
    for(auto& t:out)t=mulm(t,ni);
    return out;
  }
};

static vector<u32> direct(const vector<u32>& a){
  int n=a.size();u32 w=powm(PRIMITIVE,(MOD-1)/n);
  vector<u32> ans(n);
  for(int k=0;k<n;++k){u32 wk=powm(w,k),cur=1,t=0;for(int j=0;j<n;++j){t=plusm(t,mulm(a[j],cur));cur=mulm(cur,wk);}ans[k]=t;}
  return ans;
}
static string label_algo(int a){return a==0?"radix2":(a==1?"fused4":a==2?"splitradix":"dif4");}
static vector<u32> run_algo(const Plan& p,const vector<u32>& x,int a){
  if(a==0)return p.radix2(x);
  if(a==1)return p.fused_radix4(x);
  return a==2?p.splitradix(x):p.dif_radix4(x);
}
static uint64_t clock_us(){return chrono::duration_cast<chrono::microseconds>(chrono::steady_clock::now().time_since_epoch()).count();}
struct Counts {uint64_t add=0,mul=0;};
static Counts count_radix2(int n){Counts s; for(int L=2;L<=n;L<<=1){s.add+=n;s.mul+=(u64)(n/L)*(L/2-1);}return s;}
static Counts count_fused4(int n){Counts s;int lg=__builtin_ctz((unsigned)n);int m=1;if(lg&1){s.add+=n;m=2;}for(;m<n;m*=4){int L=4*m;s.add+=2ULL*n;s.mul+=(u64)(n/L)*(m+3*(m-1));}return s;}
static Counts count_split(int n){Counts s;if(n==1)return s;if(n==2){s.add=2;return s;} Counts a=count_split(n/2),b=count_split(n/4);s.add=(3ULL*n)/2+a.add+2*b.add;s.mul=(u64)(n/4)+2ULL*(n/4-1)+a.mul+2*b.mul;return s;}

static int selftest(){
  mt19937 rng(20261012);
  uint64_t total=0;
  for(int n=2;n<=4096;n*=2){
    Plan p(n);
    for(int caseid=0;caseid<(n<=64?16:5);++caseid){
      vector<u32> x(n);
      for(int j=0;j<n;++j) x[j]=(caseid==0)?u32(j==0):u32(rng()%MOD);
      auto gold=p.radix2(x);
      if(n<=128){auto d=direct(x);if(gold!=d){cerr<<"radix2 vs direct mismatch n="<<n<<"\n";return 1;}}
      for(int a=1;a<=3;++a){
        auto v=run_algo(p,x,a);
        if(v!=gold){int k=0;for(;k<n&&v[k]==gold[k];++k){}cerr<<label_algo(a)<<" n="<<n<<" case="<<caseid<<" failed at "<<k<<" got="<<(k<n?v[k]:0)<<" gold="<<(k<n?gold[k]:0)<<"\n";return 1;}
      }
      auto inv=p.inverse_by_radix2(gold);
      if(inv!=x){cerr<<"inverse fails at n="<<n<<"\n";return 1;}
      ++total;
    }
    cout<<"PASS n="<<n<<" cases="<<(n<=64?16:5)<<"\n";
  }
  cout<<"ALL POWER-OF-TWO EXACT TESTS PASS vectors="<<total<<"\n";
  // Additional Bluestein lengths from factors 7 and 17 of MOD-1.
  for(int n: {3,7,14,17,28,34,56,68,112,119,238,476,952}) {
    if((MOD-1)%n)continue;
    Bluestein b(n);
    for(int id=0;id<3;++id){
      vector<u32>x(n);
      for(auto&v:x)v=rng()%MOD;
      auto y=b.forward(x),z=direct(x);
      if(y!=z){cerr<<"Bluestein mismatch n="<<n<<"\n";return 1;}
      if(b.inverse(y)!=x){cerr<<"Bluestein inverse mismatch n="<<n<<"\n";return 1;}
      ++total;
    }
    cout<<"PASS Bluestein n="<<n<<"\n";
  }
  cout<<"ALL EXACT TESTS PASS vectors="<<total<<"\n";
  return 0;
}

static int benchmark(int maxlog,int repeats){
  mt19937 rng(20261012);
  cout<<"n,algo,median_us,cold_plan_us,adds_per_input,muls_per_input\n";
  for(int lg=6;lg<=maxlog;++lg){
    int n=1<<lg;
    uint64_t p0=clock_us();Plan p(n);uint64_t p1=clock_us();
    vector<u32> x(n);for(auto& v:x)v=rng()%MOD;
    auto baseline=p.radix2(x);
    for(int a=0;a<3;++a){
      auto v=run_algo(p,x,a);
      if(v!=baseline){cerr<<"benchmark correctness failure";return 1;}
      vector<uint64_t> times;
      times.reserve(repeats);
      uint64_t checksum=0;
      for(int run=0;run<repeats+2;++run){
        auto t0=clock_us();auto result=run_algo(p,x,a);auto t1=clock_us();
        checksum+=result[(run*13)%n];
        if(run>=2)times.push_back(t1-t0);
      }
      sort(times.begin(),times.end());
      Counts c=a==0?count_radix2(n):(a==1?count_fused4(n):count_split(n));
      cout<<n<<","<<label_algo(a)<<","<<times[times.size()/2]<<","<<(p1-p0)<<","<<c.add<<","<<c.mul<<"\n";
      if(checksum==0xdeadbeefULL)cerr<<"unlikely";
    }
  }
  return 0;
}
static int test_heavy(){
  mt19937 rng(20261012);
  for(int lg=13;lg<=18;++lg){
    int n=1<<lg;Plan p(n);
    vector<u32>x(n);
    // All-ones spectrum: y[0]=n, y[k>0]=0.
    fill(x.begin(),x.end(),1);
    for(int mode=0;mode<4;++mode){
      auto y=run_algo(p,x,mode);
      if(y[0]!=(u32)n){cerr<<"ones DC failed";return 1;}
      for(int k=1;k<n;++k)if(y[k]!=0){cerr<<"ones non-DC failed";return 1;}
    }
    // Impulse at nonzero j, every output checked against recurrence.
    int j=n/3;fill(x.begin(),x.end(),0);x[j]=1;
    u32 one_step=p.roots[j];u32 value=1;
    auto y=p.forward_auto(x);
    for(int k=0;k<n;++k){if(y[k]!=value){cerr<<"impulse exact spectrum failed n="<<n<<" k="<<k<<"\n";return 1;}value=mulm(value,one_step);}
    // Adversarial random full-density, three independent algorithm equality and inverse.
    for(auto&v:x)v=rng()%MOD;
    auto a=p.radix2(x),b=p.fused_radix4(x),c=p.splitradix(x),e=p.dif_radix4(x);
    if(a!=b || a!=c || a!=e || p.inverse_by_radix2(a)!=x){cerr<<"large crosscheck failed n="<<n<<"\n";return 1;}
    // Every Fourier output summed -> N*x[0], another independent identity.
    u32 sum=0;for(u32 v:a)sum=plusm(sum,v);
    if(sum!=mulm(n,x[0])){cerr<<"summation identity failed";return 1;}
    cout<<"PASS heavy n="<<n<<" (all-ones, impulse, dense, inverse, sum rule)\n";
  }
  return 0;
}

static int benchmark_fair(int maxlog,int repeats){
  mt19937 rng(20261012);
  cout<<"n,algo,median_us,cold_plan_us,adds,muls\n";
  for(int lg=10;lg<=maxlog;++lg){
    int n=1<<lg;
    auto t0=chrono::steady_clock::now();Plan p(n);auto t1=chrono::steady_clock::now();
    auto ptime=chrono::duration_cast<chrono::nanoseconds>(t1-t0).count();
    vector<u32>x(n);for(auto&v:x)v=rng()%MOD;
    vector<vector<long long>>times(4);
    vector<int>order{0,1,2,3};
    u64 checksum=0;
    for(int run=0;run<repeats+4;++run){
      shuffle(order.begin(),order.end(),rng);
      for(int a:order){
        auto b=chrono::steady_clock::now();
        auto v=run_algo(p,x,a);
        auto e=chrono::steady_clock::now();
        if(run>=4)times[a].push_back(chrono::duration_cast<chrono::nanoseconds>(e-b).count());
        checksum+=(u64)v[(run*13+a*7)%n];
      }
    }
    if(checksum==0xFFFFu)cerr<<"unlikely";
    for(int a=0;a<4;++a){
      auto&v=times[a];sort(v.begin(),v.end());
      auto c=a==0?count_radix2(n):a==2?count_split(n):count_fused4(n);
      cout<<n<<","<<label_algo(a)<<","<<fixed<<setprecision(3)<<v[v.size()/2]/1000.0<<","<<ptime/1000.0<<","<<c.add<<","<<c.mul<<"\n";
    }
  }
  return 0;
}

static int run_stdin(int n,const string& method) {
  vector<u32>x(n);for(int i=0;i<n;++i){u64 z;if(!(cin>>z))throw runtime_error("expected n integer input values");x[i]=z%MOD;}
  vector<u32>y;
  if(n>1 && (n&(n-1))==0) {
    Plan p(n);
    if(method=="auto")y=p.forward_auto(x);
    else if(method=="radix2")y=p.radix2(x);
    else if(method=="fused4")y=p.fused_radix4(x);
    else if(method=="splitradix")y=p.splitradix(x);
    else if(method=="dif4")y=p.dif_radix4(x);
    else throw runtime_error("unknown power-of-two method");
  }
  else if(n==1)y=x;
  else {
    if(method!="auto" && method!="bluestein")throw runtime_error("nonpower length requires auto or bluestein");
    Bluestein b(n);y=b.forward(x);
  }
  for(int i=0;i<n;++i)cout<<y[i]<<(i+1==n?'\n':' ');
  return 0;
}
int main(int argc,char** argv){
  try{
    string mode=(argc>1)?argv[1]:"test";
    if(mode=="test")return selftest();
    if(mode=="testheavy")return test_heavy();
    if(mode=="benchfair")return benchmark_fair(argc>2?stoi(argv[2]):18,argc>3?stoi(argv[3]):13);
    if(mode=="bench")return benchmark(argc>2?stoi(argv[2]):18,argc>3?stoi(argv[3]):9);
    if(mode=="run")return run_stdin(argc>2?stoi(argv[2]):0,argc>3?argv[3]:"auto");
    cerr<<"usage: fft_engine test | testheavy | benchfair [max_log2_n] [repeats] | run n [auto|radix2|fused4|splitradix|dif4|bluestein] < input.txt\n";return 2;
  }catch(const exception&e){cerr<<"ERROR: "<<e.what()<<"\n";return 2;}
}
