"""Fresh independent data-integrity checks; never executes research sources."""
import collections,csv,hashlib,json,pathlib,shutil,zipfile
P=pathlib.Path(__file__).resolve().parent; O=P/'packet'
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=j(O/'ALL_331_BASELINE_AND_RECOMMENDATIONS.json')
bindings=j(O/'evidence/BASELINE_BINDINGS.json')
base={r['record_id']:r for r in bindings}
assert len(records)==len(base)==331
assert {x['record_id'] for x in records}==set(base)
by={x['record_id']:x for x in records}
for rid,r in by.items():
 b=base[rid];x=r['baseline'];q=r['recommendation']
 assert x['priority']==b['baseline_priority']==q['research_priority_1_to_100']
 assert x['status']==b['baseline_status'] and x['obligation_group']==b['obligation_group']
 assert x['view_bindings']==b['views']
 assert q['delta_from_accepted_baseline']==0 and q['numeric_change_proposed'] is False
 assert q['scientific_status_change_proposed'] is False and q['applied_to_live_tracker'] is False
 assert isinstance(x['priority'],int) and 1<=x['priority']<=100
 assert r['assessment_depth']['new_independent_mathematical_audit'] is False
assert sum(len(r['baseline']['view_bindings']) for r in records)==916
assert len(list(csv.DictReader((O/'ALL_331_PRIORITY_OVERLAY.csv').open())))==331
gs=j(O/'ALL_249_GROUP_SCORE_VIEW.json')['groups'];assert len(gs)==249
for g in gs:
 assert g['priority']==max(by[r]['baseline']['priority'] for r in g['record_ids'])
 assert all(g['member_scores'][r]==by[r]['baseline']['priority'] for r in g['record_ids'])
 assert g['derived_score_competition_rank']==1+sum(h['priority']>g['priority'] for h in gs)
ts=j(O/'NEXT_CYCLE_TASKS.json');assert collections.Counter(t['category'] for t in ts)=={'top_three':3,'breadth':2,'fusion':1}
assert sum(t['assignment_state'].startswith('ACTIVE') for t in ts)==3
assert not any('Q30' in t['record_ids'] for t in ts)
assert by['ALG-068']['superseded_priority_overlay']['recommended_score']==56
assert by['ALG-068']['recommendation']['research_priority_1_to_100']==48
assert 'TWO_ACTIVE_PHASE_FAMILIES_ACCEPTED' in by['ALG-049']['recommendation']['operational_state']
assert 'Q16_PIPELINE_VERDICT' in by['Q16']['recommendation']['recent_evidence_ids']
q30=j(O/'SOURCE_BLOCKERS.json')['current_Q30'];assert sum(x['status']=='EXACT_BYTES_RECOVERED' for x in q30['entries'])==1
method=j(O/'EVIDENCE_AND_METHOD.json')
for s in method['source_evidence']:
 p=O/s['packet_path'];assert p.stat().st_size==s['bytes'] and sha(p)==s['sha256']
for source,root in [('ALG049_TWO_PHASES_MANIFEST.json','alg049_two_phases_independent_review_1538'),('ALG049_COMMON_PHASE_MANIFEST.json','alg049_unit_circle_independent_review_1509')]:
 for x in j(O/'evidence'/source)['files']:
  p=P.parent/root/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
text=(O/'REPORT.txt').read_text()
assert 'review-pending' not in text and 'candidate is excluded pending' not in text
assert '53 SOURCE_BLOCKED' in text and '168 NEEDS_SCOPE_SELECTION' in text
receipt={'status':'PASS','stable_ids':331,'bindings':916,'groups':249,'unchanged_native_member_scores':331,'numeric_deltas':0,'active_selected_tasks':3,'top_tasks':3,'breadth_tasks':2,'fusion_targets':1,'recent_source_files_rehashed':len(method['source_evidence']),'new_scientific_execution':False,'external_writes':False}
(O/'FINAL_DATA_QA.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.copyfile(__file__,O/'validate_and_seal.py')
shutil.copyfile(P/'build_packet.py',O/'build_packet.py')
entries=[{'file':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name!='MANIFEST.json']
(O/'MANIFEST.json').write_text(json.dumps({'format':'SHA256; manifest excludes itself','files':entries},indent=2)+'\n')
archive=P/'Current_All_331_Research_Priority_Recommendations_2026-10-13.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(O.rglob('*')):
  if p.is_file():z.write(p,'Current_All_331_Research_Priority_Recommendations/'+str(p.relative_to(O)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
seal={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'manifest_sha256':sha(O/'MANIFEST.json'),'files':len(entries),'status':'SEALED_RECOMMENDATION_ONLY; NO_SCIENTIFIC_REVIEW_CLAIM'}
(P/'SEAL.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps(seal,indent=2))
