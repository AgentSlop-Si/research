"""Fresh read-only research-priority bookkeeping; no scientific program imports."""
import collections, csv, hashlib, json, pathlib, shutil, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = pathlib.Path(__file__).resolve().parent / 'packet'
OUT.mkdir(exist_ok=True)
def read(p): return json.loads((ROOT/p).read_text())
def write(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def unpack(p):
    d=read(p); nodes=[]
    assert d['format']=='lossless-json-dag-v1'
    for tag,v in d['nodes']:
        assert tag in (0,1,2)
        nodes.append(v if tag==0 else [nodes[i] for i in v] if tag==1 else {k:nodes[i] for k,i in v})
    return nodes[d['root']]
def col(s):
    v=0
    for c in s:v=26*v+ord(c)-64
    return v
def value(c): return next(iter(c.get('userEnteredValue',{}).values()),'')
def leading(v): return str(v).split('\n\nEarlier dated history (preserved verbatim):\n')[0]

basepath='current_review_table_independent_1426/post_execution/FINAL_NATIVE_PACKED.json'
basecheck=read('current_review_table_independent_1426/post_execution/FINAL_VERIFICATION.json')
assert digest(ROOT/basepath)==basecheck['final_native_sha256']
assert basecheck['status']=='PASS_EXACT_APPLIED_129_VALUES_ONE_HEIGHT'
native=unpack(basepath); cells={}
for rd in native['reads']:
    for sh in rd['data']['sheets']:
        for block in sh.get('data',[]):
            for ri,row in enumerate(block.get('rowData',[])):
                for ci,c in enumerate(row.get('values',[])):
                    k=(sh['properties']['title'],block.get('startRow',0)+ri+1,block.get('startColumn',0)+ci+1)
                    assert k not in cells or cells[k]==c
                    cells[k]=c
bindings=read('current_review_table_independent_1426/sealed_review/frozen_proposal/ALL_331_ID_VIEW_BINDINGS.json')
coverage=read('complete_source_coverage_1453/packet/CANONICAL_225_COVERAGE.json')
counts=read('complete_source_coverage_1453/packet/COUNTS_AND_SEMANTICS.json')
old=read('rank_latest_accepted_1251/packet/ALL_331_PRIORITY_AND_DISPATCH_OVERLAY.json')
oldby={x['record_id']:x for x in old}
covby={rid:x for x in coverage for rid in x['record_ids']}
assert len(bindings)==331 and len({x['record_id'] for x in bindings})==331
assert len(coverage)==225 and len(covby)==239

source_paths={
 'BASELINE_NATIVE':basepath,
 'BASELINE_VERIFICATION':'current_review_table_independent_1426/post_execution/FINAL_VERIFICATION.json',
 'BASELINE_BINDINGS':'current_review_table_independent_1426/sealed_review/frozen_proposal/ALL_331_ID_VIEW_BINDINGS.json',
 'COVERAGE':'complete_source_coverage_1453/packet/CANONICAL_225_COVERAGE.json',
 'COVERAGE_COUNTS':'complete_source_coverage_1453/packet/COUNTS_AND_SEMANTICS.json',
 'COVERAGE_VALIDATION':'complete_source_coverage_1453/packet/VALIDATION.json',
 'COVERAGE_PACKET_INDEX':'complete_source_coverage_1453/packet/PACKET_INDEX.json',
 'COVERAGE_PRIOR_TASKS':'complete_source_coverage_1453/packet/PRIORITIZED_NEXT_TASKS.json',
 'Q16_PIPELINE':'q16_pipeline_independent_review_1524/REVIEW.md',
 'Q16_PIPELINE_VERDICT':'q16_pipeline_independent_review_1524/VERDICT.json',
 'Q16_PIPELINE_SEAL':'q16_pipeline_independent_review_1524/SEAL.json',
 'Q16_PIPELINE_MANIFEST':'q16_pipeline_independent_review_1524/MANIFEST.json',
 'Q16_PHASE_MEDIANS':'q16_phase_medians_independent_20261013/REVIEW_REPORT.md',
 'Q16_SPEC':'q16_deterministic_pipeline_20261013/sources/ALGORITHM.txt',
 'Q16_PROOF_SPEC':'q16_deterministic_pipeline_20261013/sources/PROOF.md',
 'Q16_RECOVERED_EDITION':'q16_independent_edition_review_1056/REVIEW_REPORT.txt',
 'Q16_RECOVERED_VERDICT':'q16_independent_edition_review_1056/VERDICT.json',
 'MARKER_COMPLETE':'current_review_table_independent_1426/sources/MARKER-SMALL/REVIEW.txt',
 'ALG034_PRECISION':'current_review_table_independent_1426/sources/ALG034-PRECISION/INDEPENDENT_REVIEW.txt',
 'ALG034_Q16_BRIDGE':'current_review_table_independent_1426/sources/Q16-BRIDGE/REVIEW.txt',
 'ALG049_COMMON_PHASE':'alg049_unit_circle_independent_review_1509/REVIEW.txt',
 'ALG049_COMMON_PHASE_MANIFEST':'alg049_unit_circle_independent_review_1509/MANIFEST.json',
 'ALG049_COMMON_PHASE_SEAL':'alg049_unit_circle_independent_review_1509/SEAL.json',
 'ALG049_TWO_PHASES':'alg049_two_phases_independent_review_1538/INDEPENDENT_REVIEW.txt',
 'ALG049_TWO_PHASES_MANIFEST':'alg049_two_phases_independent_review_1538/REVIEW_MANIFEST.json',
 'LATER_44_CELL_CHECKPOINT':'final_coverage_independent_1523/post_execution/FINAL_VERIFICATION.json',
 'LATER_44_CELL_TEXT_DIFF':'final_coverage_supplement_1512/packet/PROPOSED_CELL_DIFF.json',
 'Q27_STAGE2':'q27_stage2_independent_review_1405/packet/REVIEW.txt',
 'Q27_COVERAGE':'q27_stage2_independent_review_1405/packet/COVERAGE_192.json',
 'Q30_CURRENT_SOURCE_INDEX':'q30_backend_recovery_1519/SOURCE_INDEX.json',
 'Q30_CURRENT_RECOVERY_REPORT':'q30_backend_recovery_1519/REPORT.txt',
 'ALG006_025_026_READINESS':'next_unknown_sources_1207/packet/SOURCE_READINESS_10_GROUPS.json',
 'NTT_READINESS':'top_unknown_sources_1148/packet/SOURCE_READINESS_10_GROUPS.json',
 'NTT_CPP':'top_unknown_sources_1148/downloads/FFT/fft_engine.cpp',
 'NTT_CSV':'top_unknown_sources_1148/downloads/FFT/benchmark_final_ntt.csv',
 'ACTION_ALIGNMENT':'complete_source_coverage_1453/packet/SEPARATE_ACTION_ALIGNMENT_REGISTER.json',
 'ALG017_CORRECTION':'complete_source_coverage_1453/packet/corrections/ALG017_DISPATCH_SCOPE_CORRECTION.json',
 'ALG056_CORRECTION':'complete_source_coverage_1453/packet/corrections/ALG056_SCOPE_RECONCILIATION.json',
 'ALG078_CORRECTION':'complete_source_coverage_1453/packet/corrections/ALG078_DISPATCH_SCOPE_CORRECTION.json',
 'ALG055_CORRECTION':'complete_source_coverage_1453/packet/corrections/ALG055_ACTION_SCOPE_CLARIFICATION.json',
 'STALE_PRIORITY_OVERLAY':'rank_latest_accepted_1251/packet/ALL_331_PRIORITY_AND_DISPATCH_OVERLAY.json',
}
sources=[]
for key,p in source_paths.items():
    p=ROOT/p
    dst='evidence/'+key+p.suffix
    shutil.copyfile(p,OUT/dst)
    sources.append({'source_id':key,'original_path':str(p.relative_to(ROOT)),'packet_path':dst,'bytes':p.stat().st_size,'sha256':digest(p)})
sourceby={x['source_id']:x for x in sources}
pipeline=read(source_paths['Q16_PIPELINE_VERDICT']); seal=read(source_paths['Q16_PIPELINE_SEAL'])
assert pipeline['overall']=='ACCEPT' and not pipeline['required_repairs']
assert digest(ROOT/source_paths['Q16_PIPELINE_MANIFEST'])==seal['manifest_sha256']
manifest=read(source_paths['Q16_PIPELINE_MANIFEST'])
pipeline_checked=[]
for e in manifest['files']:
    p=ROOT/'q16_pipeline_independent_review_1524'/e['path']
    assert p.stat().st_size==e['bytes'] and digest(p)==e['sha256']
    pipeline_checked.append(e['path'])
archive=ROOT/'Q16_Deterministic_Pipeline_Independent_Acceptance_2026-10-13.zip'
assert digest(archive)=='e7175180014ca6de6bd085579d139b8a3218a476e826a4e261024e5892f2b573'
two_phase_archive=ROOT/'ALG049_Two_Independent_Phases_Independent_ACCEPT_2026-10-13.zip'
assert digest(two_phase_archive)=='06466cfce5d6c24e85025d73b716d8f810da435cc51c5a2a70795a17976f2a78'
with zipfile.ZipFile(two_phase_archive) as z:
    matches=[n for n in z.namelist() if n.endswith('/INDEPENDENT_REVIEW.txt') or n=='INDEPENDENT_REVIEW.txt']
    assert len(matches)==1 and z.read(matches[0])==(ROOT/source_paths['ALG049_TWO_PHASES']).read_bytes()
q30=read(source_paths['Q30_CURRENT_SOURCE_INDEX'])
assert sum(x['status']=='EXACT_BYTES_RECOVERED' for x in q30['entries'])==1
for e in q30['entries']:
    if e['status']=='EXACT_BYTES_RECOVERED':
        p=pathlib.Path(e['local_path']);assert digest(p)==e['required_sha256']
        shutil.copyfile(p,OUT/'evidence/Q30_RECOVERED_REVIEW.md')
        sources.append({'source_id':'Q30_RECOVERED_REVIEW','original_path':str(p.relative_to(ROOT)),'packet_path':'evidence/Q30_RECOVERED_REVIEW.md','bytes':p.stat().st_size,'sha256':digest(p)})

tasks=[
 {'task_id':'TOP-1','category':'top_three','order':1,'groups':['Q16-root-phase-totality'],'record_ids':['Q16','STR-Q1','FUS-09','F016'],'parent_priorities':[60],
  'title':'Bind fair tapes to the accepted deterministic pipeline',
  'why_now':'The sealed deterministic integration closes the former provenance/composition gate. A small exact schedule adapter is now a distinct executable obligation with fixed loops and an existing mathematical specification.',
  'action':'First bind the inherited accepted E(beta) success statement and its exact parameter/normalization guards to the current specification. Then write a fresh adapter from a fixed immutable bit tape: m-1 bits for A, sigma=2A+1, m bits for tau, disjoint blocks for L=4m+1 location and L estimation rounds. Charge all exact parsing, parameter generation, tape and schedule storage, and consume exactly 2L(2m-1) bits. Feed the resulting exact immutable schedules to the sealed pipeline and verify identity, order, and all-tape resource accounting.',
  'inputs':['Q16_PIPELINE','Q16_PIPELINE_VERDICT','Q16_SPEC','Q16_PROOF_SPEC','Q16_RECOVERED_EDITION','Q16_RECOVERED_VERDICT'],
  'source_gate':'AVAILABLE_FOR_ADAPTER; exact historical success-premise linkage must be checked before claiming inherited success for the new executable.',
  'stop':'A source-pinned adapter, finite exact controls and independent interface/accounting verdict, or one precise mismatch between the executable and inherited theorem premises.',
  'uncertainty':'IID fairness is a premise of the supplied tape distribution, not established by deterministic parsing or finite tests. An arbitrary or pseudorandom tape does not receive the probability guarantee.',
  'exclude':'No physical-entropy certification, retry loop, theorem-scale allocation, dense fallback, outer transfer or all-length executable claim. F016 is a separate Gaussian/Green route sharing a dependency, not the same theorem.'},
 {'task_id':'TOP-2','category':'top_three','order':2,'groups':['Q27'],'record_ids':['Q27'],'parent_priorities':[50],
  'title':'Test one single-gap stage-2 certificate',
  'why_now':'The eight stage-2 cyclic-consecutive labels are independently accepted. The nearest genuinely new geometric change retains two adjacent moving edges but separates the third: the single-gap triple (2;8,9,11). It tests transferability of the existing affine-multiplier mechanism without an arbitrary large census.',
  'action':'Freeze exactly (stage 2; edges 8,9,11) in branch 1, the same N=8 chart and M=S2*S1, all other gains fixed. Reconstruct all six inverse guards and all 49 original anchored modulus defects. Try the explicit constant-plus-z multiplier grammar from the accepted stage-2 construction, with the third variable attached to edge 11. Validate a literal guarded ideal identity by full coefficient multiplication, or return the exact linear-system residual proving only that this certificate ansatz fails.',
  'inputs':['Q27_STAGE2','Q27_COVERAGE'],
  'source_gate':'AVAILABLE: chart/certificate antecedents are pinned by the accepted stage-2 packet; pin the original CHART bytes before derivation.',
  'stop':'One independently checked exact exclusion certificate, or a precise ansatz-level obstruction for this one label. A failed ansatz does not establish feasibility.',
  'uncertainty':'There is no proved stage/cycle permutation symmetry for the frozen gains. No certificate or rank claim for this new label has been calculated in this ranking.',
  'exclude':'Do not replay the accepted eight, infer the other 47 nonconsecutive triples, raise N, free further gains, introduce an interstage diagonal, or update the accepted 192 count before independent acceptance.'},
 {'task_id':'TOP-3','category':'top_three','order':3,'groups':['ENGINEERING-NTT-BASELINE-20261012'],'record_ids':['ENGINEERING-NTT-BASELINE-20261012'],'parent_priorities':[43],
  'title':'Freeze a fair cold and warm NTT protocol',
  'why_now':'Recovered CPP/CSV bytes support a bounded protocol even though the later review body remains missing. The stored warm ratio excludes shared plan construction and cannot answer the end-to-end question.',
  'action':'Specify one input corpus, legal modulus/root/length checks, exact-output comparator, separate plan ownership for each schedule, cold preparation inclusion, warm reuse conditions, repetition/order policy, and all output and memory checks. Read the recovered source as text. Record hardware/compiler/flags as unresolved configuration fields unless verified from the source.',
  'inputs':['NTT_READINESS','NTT_CPP','NTT_CSV'],
  'source_gate':'AVAILABLE_FOR_PROTOCOL_ONLY; later review hash 32b9e8e7c33b69633e1616188b59e0f9ad643677680bbb5b6175ee5900ddf4d8 remains unrecovered.',
  'stop':'One reviewable comparison protocol and charged preparation checklist. No benchmark or source execution in this task.',
  'uncertainty':'A protocol is useful engineering preparation, not evidence of a new speedup or repaired production implementation.',
  'exclude':'Do not treat the historical 2.3674986456 warm ratio as independent performance verification, or compile/run inherited software without its separately authorized task.'},
 {'task_id':'BREADTH-1','category':'breadth','order':1,'groups':['ALG-006'],'record_ids':['ALG-006'],'parent_priorities':[42],
  'title':'Map one fixed-order confluent Prony theorem',
  'why_now':'The three own claim/proof/audit bodies are available; a precise primary comparison is the remaining bounded task, distinct from the main pipeline and finite Green exclusions.',
  'action':'Select only the fixed-total-order-D confluent branch and one full primary repeated-pole/generalized-Prony theorem. Compare multiplicity knowledge, clean nondegenerate 2D-row pilot, p>D, root supply, exact-g versus at-most-g, raw all-coordinate rejection, complete outputs, and all D-dependent costs.',
  'inputs':['ALG006_025_026_READINESS','COVERAGE'],
  'source_gate':'OWN_BODIES_AVAILABLE; external theorem/edition must be selected and read before comparison.',
  'stop':'One sourced hypothesis/formula/cost map or qualified nonmatch, or exact current full-body access blocker.',
  'uncertainty':'No primary theorem has been newly read for this ranking; no novelty claim follows from source availability.',
  'exclude':'No rerun of completed confluence controls, wholesale dispatcher rewrite, growing-D asymptotic claim, or broad survey.'},
 {'task_id':'BREADTH-2','category':'breadth','order':2,'groups':['ALG-025','ALG-026'],'record_ids':['ALG-025','ALG-026'],'parent_priorities':[42,42],
  'title':'Resolve the exact Reif full-paper comparison',
  'why_now':'Both own contracts are available and the saved comparison stopped at abstract/indexed material. One named full primary paper can settle a concrete unresolved comparison across two distinct error regimes.',
  'action':'Retrieve Reif, Approximate Complex Polynomial Evaluation in Near Constant Work Per Point, SICOMP 28(6), 2059–2089 (1999), DOI 10.1137/S0097539797324291. Select one theorem applicable or inapplicable to N coefficients and N Fourier points. Map coefficient-l1 error, evaluation count, bounded common-scale representation, precision, root/point preparation, and cold setup. Produce separate fixed-error ALG025 and shrinking-error ALG026 clause maps.',
  'primary_retrieval_leads':['https://epubs.siam.org/doi/abs/10.1137/S0097539797324291','https://users.cs.duke.edu/~reif/paper/Eval.pdf'],
  'inputs':['ALG006_025_026_READINESS','COVERAGE_PRIOR_TASKS'],
  'source_gate':'OWN_BODIES_AVAILABLE; exact full external paper not recovered in the dated audit, and not tested anew here.',
  'stop':'A full-body theorem-level comparison for the two distinct IDs, or a precise current retrieval blocker.',
  'uncertainty':'The URLs are sourced retrieval leads, not a claim of current successful access. Failure to retrieve is not evidence of novelty.',
  'exclude':'No silent padding, relative-l2/exact-output upgrade, merged IDs, or repeat of the broad Mailman/Four-Russians/sampling survey.'},
 {'task_id':'FUSION-1','category':'fusion','order':1,'groups':['ALG-034','Q16-root-phase-totality'],'record_ids':['ALG-034','Q16','STR-Q1','FUS-09'],'parent_priorities':[48,60],
  'title':'Implement the guarded immutable source bridge',
  'why_now':'The accepted ALG034 precision contract and conditional paid normalization/requantization bridge now meet an independently accepted deterministic Q16 consumer. The excluded immutable production wrapper is a concrete joining task.',
  'action':'Write a fresh validated immutable tuple adapter for the accepted producer output and Delta certificate, preserving exact type, shape, frequency order, source sign, numerator/exponent widths, the strict norm-doubling boundary, and alpha. Require Delta/alpha<=rho to advertise the published composed bucket budget. Bind the new source to the sealed deterministic pipeline under supplied schedules, with all dense construction/validation/storage and upstream producer work charged. Treat ZERO_APPROXIMATION separately from exact-zero input and fail the sufficient-budget status without inventing an adaptive precision success guarantee.',
  'inputs':['ALG034_PRECISION','ALG034_Q16_BRIDGE','Q16_PIPELINE','Q16_PIPELINE_VERDICT'],
  'source_gate':'AVAILABLE_FOR_CONDITIONAL_WRAPPER; full source and producer certificates must be bound before calling the pipeline.',
  'stop':'An independently reviewed wrapper/interface and paid composition contract, with exact boundary and failure controls. Keep success conditional on the accepted producer and budget guards.',
  'uncertainty':'The bridge sees Y=U P x; the next Fourier stage has target R P x/alpha, not Ux. Kernel/near-kernel inputs defeat any unproved signal floor, and the new fusion is not yet accepted.',
  'exclude':'No projected-signal lower bound, free normalization, free random access/storage, automatic retry termination, faster backend, general FFT improvement, full recovery or all-length claim.'},
]
for t in tasks:
    t['assignment_state']='ACTIVE_ALREADY_ASSIGNED; DO_NOT_DUPLICATE' if t['task_id'] in ['TOP-1','TOP-3','BREADTH-1'] else 'RECOMMENDATION_ONLY_NOT_ASSIGNED_BY_THIS_PACKET'
write('NEXT_CYCLE_TASKS.json',tasks)

recent={
 'Q16-root-phase-totality':{
  'state':'DETERMINISTIC_PIPELINE_ACCEPTED; FAIR_TAPE_ADAPTER_RECOMMENDED',
  'evidence':['Q16_PIPELINE','Q16_PIPELINE_VERDICT','Q16_PHASE_MEDIANS','Q16_RECOVERED_EDITION'],
  'accepted_scope':'WINDOW v2, BUCKETS, exact location, phase/medians and provenance-bound deterministic pipeline are accepted at their pinned boundaries. The new pipeline returns numerically bounded ideal-window median estimates for actual candidates and supplied schedules.',
  'rationale':'Keep 60. Removal of the deterministic composition gate makes the next implementation step actionable, but fair schedule distribution, normalization, success-interface conformance, dense fallback and outer/all-length execution remain outside the new acceptance. Existing mathematical existence is not an executable certificate.',
  'uncertainty':'Do not call the accepted ideal-window median exact unwindowed-spectrum recovery. Enormous theorem crossover remains. F016 preserves its separate Gaussian/Green theorem.'},
 'ALG-068':{
  'state':'COMPLETE_SMALL_MARKER_SCHEDULE_ACCEPTED; NEW_SHARING_MECHANISM_UNSELECTED',
  'evidence':['MARKER_COMPLETE'],
  'accepted_scope':'Complete arbitrary-source to N-selected-output small-marker schedule is Theta(Nn). Source and fused inverse visits satisfy W+V=(n+1)|F|; the scoped rank-b local-summary restriction is separate.',
  'rationale':'Keep baseline 48; withdraw the old unapplied 56. A fully paid schedule exists, but matches the benchmark rather than delivering a faster Fourier transform. The previously rewarded source-ready schedule subgate is now completed and does not justify the stale +8.',
  'uncertainty':'Theta(Nn) is the cost of this prescribed schedule, not a lower bound for all algorithms. New sharing representation is not selected; no automatic task redispatch.'},
 'ALG-034':{
  'state':'PRECISION_AND_CONDITIONAL_BRIDGE_ACCEPTED; IMMUTABLE_WRAPPER_RECOMMENDED',
  'evidence':['ALG034_PRECISION','ALG034_Q16_BRIDGE'],
  'accepted_scope':'Specified serial producer precision/range/cost and conditional paid source bridge are accepted. The sufficient composed budget requires Delta/alpha<=rho.',
  'rationale':'Keep 48. A reusable conditional numerical interface is established, but no fast backend, uniform projected-signal floor, successful precision policy or full-Fourier error guarantee follows.',
  'uncertainty':'Arbitrary-local-defect amplification is not a realized-roundoff lower bound. Input/storage costs and reflected projected target remain essential.'},
 'Q27':{
  'state':'192_LABELS_ACCEPTED; ONE_SINGLE_GAP_LABEL_RECOMMENDED',
  'evidence':['Q27_STAGE2','Q27_COVERAGE'],
  'accepted_scope':'192 of 5,984 coordinate-triple labels accepted, including eight stage-2 branch-1 cyclic-consecutive labels; 5,792 unclassified. All original inverse guards remain.',
  'rationale':'Keep 50. Exact finite coverage increased, but no full 34-phase-fiber exclusion, synthesis or acceleration is established. One new source-bound structural test is selected rather than a broad count-driven campaign.',
  'uncertainty':'Coordinate-label sets are distinct; geometric slices intersect. Failure of a certificate ansatz is not a feasible Fourier witness.'},
 'ALG-049':{
  'state':'COMMON_AND_TWO_ACTIVE_PHASE_FAMILIES_ACCEPTED; NEW_SUCCESSOR_UNSELECTED',
  'evidence':['ALG049_COMMON_PHASE','ALG049_COMMON_PHASE_SEAL','ALG049_TWO_PHASES','ALG049_TWO_PHASES_MANIFEST'],
  'accepted_scope':'The pinned six mixed words are excluded for two independent active unit phases z,v, fixed cycle orders/placements and identity effective separators. A strict diagonal-Gram gap after stripping the final factor is the essential accepted obstruction. M1 has no phase-bearing edge; a nominal first phase is inert. The earlier shared-phase result remains a separate accepted slice.',
  'rationale':'Keep 42. The exact two-active-phase family is broader than the shared-phase slice, but does not establish unrestricted phase-placement or separator classification. Retire both selected family tasks and require a genuinely new source-bound successor before dispatch.',
  'uncertainty':'No arbitrary cycles/phases/separators classification, Fourier impossibility, speed theorem or historical novelty conclusion. The two-phase theorem does not assert a uniformly nonzero entry of the original three-factor Gram. Do not redispatch either accepted family.'},
 'Q30':{
  'state':'CURRENT_REVIEW_BODY_RECOVERED; THREE_EXACT_SOURCE_PINS_MISSING',
  'evidence':['Q30_CURRENT_SOURCE_INDEX','Q30_CURRENT_RECOVERY_REPORT','Q30_RECOVERED_REVIEW'],
  'accepted_scope':'One of four exact pins, independent report df9ff2df..., is recovered. The independent archive 56f1834e..., executor cffa7d8a... and author report a127d512... remain missing after the bounded current search.',
  'rationale':'Keep 53. Better provenance does not create a new acceleration theorem or runnable exact-source target. The just-completed recovery search is not proposed again as a fresh top task.',
  'uncertainty':'Missing bytes are a source-identity gap, not permission denial or proof failure. A new original archive/locator is needed before repeating the same retrieval routes.'},
}

offsets={'Catalogue':27,'novelity breakthough':21,'Research overview':12,'Next cycle':7,'Incoming queue':7}
later_diffs=read(source_paths['LATER_44_CELL_TEXT_DIFF'])
overlay=[];allviews=[]
for b in bindings:
    rid=b['record_id']; views=b['views']; group=b['obligation_group']; cov=covby.get(rid); last=oldby[rid]
    base={'record_id':rid,'title':next((v['title'] for v in views if v['sheet']=='Research overview'),views[0]['title']),
          'priority':b['baseline_priority'],'status':b['baseline_status'],'obligation_group':group,
          'view_bindings':views,'native_view_fields':[]}
    for v in views:
        sh,row=v['sheet'],v['row']; assert value(cells[sh,row,col(v['id_column'])])==rid
        allviews.append((sh,row,v['id_column']))
        if sh in offsets:
            off=offsets[sh];vals=[value(cells.get((sh,row,i),{})) for i in range(off,off+6)]
            assert int(vals[0])==b['baseline_priority'],(rid,sh,vals[0])
            base['native_view_fields'].append({'sheet':sh,'row':row,'priority_cell_column_number':off,'six_fields_verbatim':vals})
        if sh=='Research overview':
            base['overview_cells_A_to_Q_verbatim']=[value(cells.get((sh,row,i),{})) for i in range(1,18)]
            assert base['overview_cells_A_to_Q_verbatim'][4]==b['baseline_status']
    existing=next((x['six_fields_verbatim'] for x in base['native_view_fields'] if x['sheet']=='Research overview'),base['native_view_fields'][0]['six_fields_verbatim'])
    closed=b['baseline_status']=='CLOSED';alias=b['baseline_status'] is None
    state='CLOSED_NAMED_SCOPE_PRESERVED' if closed else 'INTAKE_ALIAS_PRESERVED' if alias else 'BASELINE_ACTION_RETAINED_NO_NEW_SCORE_EVIDENCE'
    source_flag='NOT_REASSESSED_HERE'
    if cov:
        # Cohort priorities are group-level maxima, not replacement scores for each distinct member.
        state={'SOURCE_BLOCKED':'DATED_SOURCE_BLOCKED; CURRENT_ACCESS_NOT_RETESTED','NEEDS_SCOPE_SELECTION':'BOUNDED_SCOPE_SELECTION_REQUIRED','READY':'HISTORICALLY_READY; CHECK_COMPLETION_BEFORE_DISPATCH'}[cov['frozen_readiness']]
        source_flag='DATED_ESSENTIAL_SOURCE_GAP' if cov['frozen_readiness']=='SOURCE_BLOCKED' else 'SEE_EXACT_SCOPE_AND_SOURCE_LIMITS; NOT_A_GLOBAL_SOURCE_CLEARANCE'
    if closed or alias: source_flag='NOT_APPLICABLE_TO_COMPLETED_OR_ALIAS_SCOPE'
    rationale='Preserve the existing ordinal score. No additional accepted score-changing evidence is assessed for this ID in this overlay; this is not a fresh proof or novelty judgment.'
    uncertainty='Existing limitations and source/task-readiness evidence are retained verbatim. The ranking does not independently inspect every historical proof.'
    accepted=None; ev=[]
    if group in recent:
        r=recent[group];state=r['state'];rationale=r['rationale'];uncertainty=r['uncertainty'];accepted=r['accepted_scope'];ev=r['evidence']
        source_flag='CURRENT_SELECTED_SCOPED_REVIEW_BODIES_AVAILABLE' if group!='Q30' else 'CURRENT_THREE_EXACT_SOURCE_PINS_MISSING'
    if group in ['ALG-029','M-CRT-TRANSFER','Q2-DENSE-TORUS-20261013']:
        state='LAST_SELECTED_SCOPED_REVIEW_COMPLETED; NEW_SUCCESSOR_UNSELECTED'
    if group=='ALG-017':state='SOURCE_ALIGNMENT_ALREADY_APPLIED_IN_BASELINE; NO_DUPLICATE_REPAIR'
    if group in ['ALG-055','ALG-056','ALG-078']:
        state='SOURCE_ALIGNMENT_APPLIED_IN_LATER_ACCEPTED_44_CELL_CHECKPOINT; DO_NOT_REAPPLY'
        ev+=['LATER_44_CELL_CHECKPOINT','LATER_44_CELL_TEXT_DIFF']
    if group=='STRUCTURED-RESIDUAL-EXECUTOR-20261012':
        state='EXACT_HISTORICAL_EXECUTION_AUTHORIZATION_GATE_PRESERVED'
        source_flag='DO_NOT_CONFUSE_EXECUTION_AUTHORIZATION_WITH_SOURCE_AVAILABILITY'
    memberships=[t['task_id'] for t in tasks if rid in t['record_ids']]
    row={'record_id':rid,'baseline':base,
         'recommendation':{'research_priority_1_to_100':b['baseline_priority'],'delta_from_accepted_baseline':0,'numeric_change_proposed':False,
                           'scientific_status_change_proposed':False,'applied_to_live_tracker':False,'operational_state':state,
                           'task_memberships':memberships,'score_rationale':rationale,'uncertainty_and_limits':uncertainty,
                           'scoped_accepted_update':accepted,'recent_evidence_ids':ev,
                           'later_accepted_textual_checkpoint':[d for d in later_diffs if d.get('record_id')==rid],
                           'prior_task_text_leading':leading(existing[4]),'prior_stop_text_leading':leading(existing[5])},
         'source_readiness':{'current_flag':source_flag,'frozen_225_cohort_record':cov,
                            'source_blocked_at_frozen_cohort_audit':cov['frozen_readiness']=='SOURCE_BLOCKED' if cov else None,
                            'outside_original_225_cohort':cov is None},
         'assessment_depth':{'all_record_identity_and_score_checked':True,'source_task_triage_record_carried':cov is not None,
                             'selected_recent_review_texts_read':bool(ev),'new_independent_mathematical_audit':False},
         'superseded_priority_overlay':{'dated_cutoff':last['latest_overlay_cutoff_utc'],'recommended_score':last['recommended_parent_priority'],
                                      'difference_to_current_recommendation':b['baseline_priority']-last['recommended_parent_priority'],
                                      'old_dispatch_not_used_as_current_truth':True}}
    overlay.append(row)
assert len(allviews)==916 and len(set(allviews))==916
assert sum(x['baseline']['status']=='TO RESEARCH' for x in overlay)==282
assert sum(x['baseline']['status']=='CLOSED' for x in overlay)==45
assert len({x['baseline']['obligation_group'] for x in overlay if x['baseline']['status']=='TO RESEARCH'})==249
write('ALL_331_BASELINE_AND_RECOMMENDATIONS.json',overlay)

# A flat data export is supplied for filtering; the lossless JSON above remains authoritative.
fields=['record_id','title','group','baseline_status','baseline_priority','recommended_priority','delta','operational_state','task_memberships','source_flag','frozen_readiness','score_rationale','uncertainty']
with (OUT/'ALL_331_PRIORITY_OVERLAY.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for x in overlay:
        b=x['baseline'];r=x['recommendation'];s=x['source_readiness']
        w.writerow(dict(record_id=x['record_id'],title=b['title'],group=b['obligation_group'],baseline_status=b['status'],baseline_priority=b['priority'],recommended_priority=r['research_priority_1_to_100'],delta=0,operational_state=r['operational_state'],task_memberships='; '.join(r['task_memberships']),source_flag=s['current_flag'],frozen_readiness=(s['frozen_225_cohort_record'] or {}).get('frozen_readiness','OUTSIDE_COHORT'),score_rationale=r['score_rationale'],uncertainty=r['uncertainty_and_limits']))

groupmap={}
for x in overlay:
    if x['baseline']['status']!='TO RESEARCH':continue
    b=x['baseline'];g=groupmap.setdefault(b['obligation_group'],{'group':b['obligation_group'],'priority':b['priority'],'priority_semantics':'Maximum native member score, not a score assigned to every member','member_scores':{},'record_ids':[],'operational_states':[],'task_ids':[]})
    g['priority']=max(g['priority'],b['priority']);g['member_scores'][x['record_id']]=b['priority']
    g['record_ids'].append(x['record_id'])
    g['operational_states']=sorted(set(g['operational_states']+[x['recommendation']['operational_state']]))
    g['task_ids']=sorted(set(g['task_ids']+x['recommendation']['task_memberships']))
groups=sorted(groupmap.values(),key=lambda g:(-g['priority'],g['group']))
for g in groups:g['derived_score_competition_rank']=1+sum(h['priority']>g['priority'] for h in groups)
write('ALL_249_GROUP_SCORE_VIEW.json',{'semantics':'Derived priority-only ordering, de-duplicated by exact obligation group. Ties are neutral; group name is display order only. This is not operational dispatch order or a native rank update. Closed named scopes and aliases remain in the 331-record ledger.','groups':groups})

blocked=[{'group':x['obligation_group'],'record_ids':x['record_ids'],'frozen_priority':x['priority_unchanged'],'frozen_source_limits':x['selection_or_source_limit'],'packet_id':x['packet_id']} for x in coverage if x['frozen_readiness']=='SOURCE_BLOCKED']
write('SOURCE_BLOCKERS.json',{'dated_essentially_blocked_groups':blocked,'dated_group_count':53,'not_live_count':True,
 'current_Q30':q30,'execution_gate_distinct_from_source_gap':'STRUCTURED-RESIDUAL-EXECUTOR-20261012 retains its exact historical-source execution permission gate; no permission is inferred here.',
 'scope_selection_is_not_permanent_blockage':True,'other_source_gaps':'168 NEEDS_SCOPE_SELECTION entries retain their full source limits; that label does not certify every source body is available. Newly proposed external primary comparisons require retrieving their full theorem bodies.'})

write('EVIDENCE_AND_METHOD.json',{'accepted_table_cutoff_utc':basecheck['scientific_cutoff_utc'],'accepted_native_read_end_utc':basecheck['final_native_reads_finished_at'],
 'recommendation_cutoff_utc':'2026-10-13T15:50:00Z','source_evidence':sources,
 'Q16_pipeline_archive':{'name':archive.name,'sha256':digest(archive),'library_file_id':'libfile_990fdea061408191b4ce635c6d8f96a1','version':0,'manifest_entries_rehashed_here':len(pipeline_checked)},
 'rubric':'Five existing questions: value, evidence readiness, distinctness from completed work, bounded tractability/cost, breadth of benefit. No numerical formula or empirical calibration is asserted.',
 'bands':{'1-15':'completed/inactive','16-34':'low-leverage optional','35-49':'supporting','50-64':'consequential uncertain parent gates','65-79':'unusually tractable high-leverage gates','80-100':'decisive time-critical opportunities'},
 'numeric_decision':'All 331 accepted baseline scores are retained. Recent scoped acceptances justify new task definitions and retirement of completed subgates, not an evidence-calibrated integer increment. ALG068 old unapplied 56 is withdrawn to baseline 48.',
 'semantic_boundary':'Scores are ordinal research-priority values, never chance of novelty/success/correctness or publication merit. No new theorem or exhaustive novelty verdict is created.',
 'coverage_boundary':counts,
 'ALG049_two_phase_acceptance':{'name':two_phase_archive.name,'sha256':digest(two_phase_archive),'state':'Sealed scoped ACCEPT. Review body independently matched to the exact archive here.'},
 'later_textual_checkpoint':{'source':'LATER_44_CELL_CHECKPOINT','status':'Independently accepted 44-cell supplement; no score/rank/ID changes. The requested older 331-record baseline is intentionally retained verbatim.','library_file_id':'libfile_23ca80bd4db88191819056de2daa789c','final_export_sha256':'64f1fc5229d7532e675b58de9c24c42ffe8b30a705c05e3de0e2e21573166a39'},
 'active_assignments_at_cutoff':['Q16 fair-tape adapter','ALG006 fixed-order Prony comparison','NTT cold/warm protocol'],
 'unaccepted_new_work_excluded':'The newly started fair-tape adapter and active Prony/NTT work have no accepted scientific result in this snapshot.',
 'read_depth':'All IDs/scores/view bindings and complete 225-group source/task register are reconciled mechanically. Selected recent acceptance reports are read for recommendation scope. This is not a new mathematical audit of all 331 records or 225 proofs.',
 'actions':'Read-only inputs, safe archive/hash inspection and fresh bookkeeping only. No historical scientific program execution, Sheet/GitHub writes, publication, sharing or access changes.'})

write('VALIDATION.json',{'status':'PASS','stable_ids':331,'exact_view_bindings':916,'overview_records':327,'open_records':282,'closed_named_scopes':45,'intake_aliases':4,'open_groups':249,'original_cohort_groups':225,'original_cohort_record_ids':239,'frozen_source_flag_counts':dict(collections.Counter(x['frozen_readiness'] for x in coverage)),
 'shared_group_member_score_differences_preserved':[{'record_id':b['record_id'],'native_member_score':b['baseline_priority'],'frozen_group_maximum':covby[b['record_id']]['priority_unchanged']} for b in bindings if b['record_id'] in covby and b['baseline_priority']!=covby[b['record_id']]['priority_unchanged']],
 'score_changes_from_accepted_baseline':0,'stale_recommendations_withdrawn':[{'record_id':'ALG-068','old_unapplied_recommendation':56,'accepted_baseline':48,'current_recommendation':48}],
 'task_counts':dict(collections.Counter(t['category'] for t in tasks)),
 'all_ids_exact_and_unique':True,'all_scores_match_native_cells':True,'all_baseline_six_field_strings_preserved':True,'all_task_ids_exist_in_baseline':all(rid in {b['record_id'] for b in bindings} for t in tasks for rid in t['record_ids']),
 'Q16_sealed_ACCEPT_checked':True,'pipeline_manifest_payloads_rehashed':len(pipeline_checked),'Q30_exact_recovered_reports_rehashed':1,'Q30_current_missing_pins':3,'new_scientific_proof_reviews':0,'external_tracker_writes':0})

report='''CURRENT NEXT-CYCLE RESEARCH PRIORITIES
13 October 2026 | private recommendation overlay

DECISION
Keep all 331 accepted baseline scores. Q16 stays 60; Q27 50; ALG034 and ALG068 48; NTT engineering 43; ALG049, ALG006 and ALG025/026 42. The old unapplied ALG068 56 recommendation is withdrawn: the independently accepted complete schedule is Theta(Nn), with no full-FFT gain. Its old schedule-design task is completed.

The operational shortlist is deliberately different from sorting the score column. A high parent score does not create an available, distinct, source-bound experiment. Publication weight, novelty and probability of success are not being scored.

ASSIGNMENT CHECKPOINT, 15:50 UTC
The Q16 fair-tape adapter, ALG006 Prony comparison and NTT protocol have already been assigned. Continue those tasks without duplicate dispatch. Their new results are not accepted or scored in this snapshot. The Q27 probe, Reif comparison and conditional fusion wrapper remain recommendations only.

TOP THREE BOUNDED TASKS
1. Q16: bind a fixed fair-bit-tape adapter to the accepted deterministic pipeline. Exact schedule construction consumes 2L(2m-1) bits with L=4m+1, separates location/estimation blocks, and pays parsing/storage and all current parameter guards. First reconcile the exact inherited success theorem to this interface. Stop at an independently reviewed adapter/interface or precise mismatch. IID fairness is a distribution premise, not a property finite tests can certify. No dense branch, outer transfer or all-length executable is included.
2. Q27: one new single-gap stage-2 branch-1 triple (2;8,9,11). It changes the separation geometry while retaining two adjacent edges, using the accepted stage-2 construction as a precise source. Reconstruct all original guards and 49 anchored defects; seek a constant-plus-third-variable certificate or exact ansatz residual. Stop at one independently checked result. This ranking has not computed it. No rotational symmetry, remaining-label feasibility or full-fiber conclusion is assumed.
3. NTT engineering: freeze one exact-output, cold/warm comparison protocol using the recovered CPP/CSV. Charge separate plans and preparation, state hardware/compiler settings only when known, and record the missing later review body. Stop at the reviewable protocol. Do not run the inherited code or call the stored warm ratio a new measured gain.

TWO BREADTH TASKS
ALG006: one fixed-total-order-D confluent Prony comparison. Own bodies are available; select and read one full primary theorem, then map pilot/nondegeneracy, multiplicities, p>D, roots, exact-g, rejection, all outputs and all D-dependent costs. Stop at one exact match/nonmatch or current access blocker.
ALG025 and ALG026: retrieve the exact Reif 1999 full paper and make two separate fixed-error/shrinking-error clause maps for N coefficients and N Fourier points. Compare representation, error scale and all cold setup. Earlier abstract-only access is not a current universal access failure or evidence of novelty.

ONE FUSION TARGET
ALG034 to Q16: a validated immutable source wrapper joining the accepted serial producer/conditional paid bridge to the accepted deterministic pipeline. Preserve the strict normalization/doubling boundary, exact scale alpha, Delta provenance, Delta/alpha<=rho budget, and all input/storage work. The next Fourier target is reflected projected data R P x/alpha, not automatically Ux. Zero approximation, kernel and near-kernel cases preclude an unproved terminating precision policy. Stop at a reviewed conditional wrapper contract; no fast backend or end-to-end improvement is claimed.

WHY SCORES DO NOT RISE
Q16's component and deterministic composition acceptances are substantial executable progress, but its new accepted output is an ideal-window median on actual candidates and supplied schedules. It is not arbitrary-schedule recovery of the exact unwindowed spectrum. Fair schedule/success conformance, normalization, dense dispatch and outer transfer are distinct outstanding gates.
ALG034's precision and conditional source bridge are accepted; source width, conditioning, the sufficient residual budget and the projected target remain. Q27 has 192/5,984 accepted coordinate-triple labels and 5,792 unclassified; finite exact exclusions do not settle the full 34-phase fiber. ALG049 now has both the accepted common-phase slice and the sealed two-active-independent-phase theorem for the same pinned cycles/placements and six signs. The first cycle has no phase-bearing edge, so a nominal third phase is inert. The new strict diagonal-Gram gap excludes that exact two-phase family, with identity effective separators. Do not repeat either accepted family. Arbitrary placements/cycles/separators, novelty, Fourier and FFT claims remain outside the result. Its parent stays 42, with no new successor selected.

HIGHER-SCORED HOLDS
F020 stays 58 without a selected new actual-family mechanism. The signed-bank group stays 56 without a new size/field target. Q29 stays 54 with its specific source/reconciliation gate retained; the exact historical structured-residual executor retains its separate execution-authority gate. ALG022, F021 and sparse-prefix remain at their baseline values and exact source/target/mechanism gates. Their scores are preserved, not presented as fresh readiness certifications.
Q30 stays 53. Its just-completed recovery obtained the exact independent review body, one of four old pins. Three original byte bodies remain missing: independent archive 56f1834e..., executor cffa7d8a..., author report a127d512.... The dated four-pin gap remains as history; the current three-pin gap is recorded separately. Do not repeat the completed bounded search as a new top task without a new byte-bearing archive or locator.

COVERAGE AND AUDIT DEPTH
All 331 stable IDs, 916 exact view bindings, every stored score and every baseline six-field string are preserved. The accepted native baseline was independently verified after its 129 textual changes, with reads ending 15:10:08.187 UTC and scientific cutoff 14:29:35 UTC. This overlay changes no live cell, score, rank or scientific status.
The separately accepted later 44-cell textual supplement finished native reads at 15:41:03.092 UTC and preserved every score/rank/ID. Its receipt is included as a later checkpoint; this packet intentionally retains the requested older baseline verbatim rather than silently replacing it.
The original 225 unknown groups are all covered in the source/task register, representing 239 distinct records. Frozen flags are 53 SOURCE_BLOCKED, 168 NEEDS_SCOPE_SELECTION and 4 READY-at-the-time. The four old selected tasks have since progressed: ALG029, CRT112 and guarded Q2 are complete; ALG049's common-phase and two-active-phase successors are both complete. These are not four currently idle jobs. The other 24 open structural groups are outside that original cohort; the total remains 249 open groups, 282 open records, 45 closed named scopes and 4 aliases. Historical 244 eligibility is not rederived.
Seven records have lower native scores than the displayed maximum of their shared group: C01, NEW-04, NEW-06, NEW-07, NF-07, Q24 and STR-Q3. Each native score is preserved. The group view explicitly uses the maximum member score only for ordering, never to overwrite individual records or merge their scientific identities.
ALG055/056/078 source-alignment corrections are already applied in the later 44-cell checkpoint. Their older baseline wording is retained as history, and their recommendation states forbid reapplying the correction. The later per-ID text changes are included beside each affected record.
Full record coverage is not a full mathematical audit. The ledger marks mechanical identity/score checks, carried source/task triage and selected recent report reading separately. No historical scientific program was executed, and no new proof or worldwide novelty judgment was made here.

READING THE FILES
ALL_331_BASELINE_AND_RECOMMENDATIONS.json is the lossless record-level overlay. It includes exact baseline values/view bindings, recommendations, rationale, uncertainty, frozen source limits and source-block flags. The CSV is a filterable flat export. ALL_249_GROUP_SCORE_VIEW.json removes shared-group double counting and supplies a derived score-only view, not an operational dispatch order or native rank change. NEXT_CYCLE_TASKS.json gives full finite input, stop and exclusion contracts. SOURCE_BLOCKERS.json preserves all 53 dated essential source gaps plus current Q30 recovery. EVIDENCE_AND_METHOD.json and evidence/ supply exact source pins and copied text. VALIDATION.json records completed bookkeeping checks.
'''
(OUT/'REPORT.txt').write_text(report)
print(json.dumps({'packet':str(OUT),'records':len(overlay),'groups':len(groups),'tasks':len(tasks),'source_files':len(sources)},indent=2))
