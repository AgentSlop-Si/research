# Nine surviving N11/F23 recurrence gates: exact base-field obstruction

Date: 13 October 2026. Status: **candidate ready for independent review**.

## Result and frozen scope

All nine rank-five pairs left by the accepted 220-matrix census are excluded when the original bank nodes and parameters lie in F23. Each pair has exactly one monic degree-five common recurrence polynomial. None has five distinct nonzero roots in F23. This is an exact additional ordinary-node obstruction, rather than a failed search for phase weights.

Combining this candidate with the already accepted 211 nonsingular cases gives the following bounded statement: for every primitive eleventh root q in F23 and every nonzero y in F23, a legal representation with exactly one effective minus-plus node y requires at least six effective plus-plus nodes when all bank parameters are in F23. Negative-delta banks are unrestricted in number. Simultaneous reflection gives the analogous bound for minus-minus. Therefore the architecture with one effective cross-sign singleton in each orientation needs at least fourteen banks in this base-field domain. Attainment is not established.

The `CONTRACT.md` file was written before the new computation. This packet makes no new assertion for extension-valued same-sign nodes, extension-valued singleton nodes, characteristic zero, unrestricted orientation allocations, or arithmetic speed. The accepted 211 exclusions continue to have their original stronger extension-node scope; restricting this successor task does not weaken them. The accepted q=2 mirrored sextic nonsplitting result and all other-field gaps remain unchanged.

## Original legal grammar and reduction

Keep N=11, S e_i=e_(i+1), T e_i=q^i e_i, TS=qST, and the target F[k,t]=q^(-kt). A legal bank is

    B_(epsilon,delta)(alpha,beta;w)
      = (1/11) sum_(j=0)^10 w_j
        (I-alpha S^epsilon-beta q^(epsilon delta j)T^delta)^(-1),
    Delta = 1-alpha^11-beta^11 != 0.

No generator, gauge, pre/post map, product, derivative atom, or confluent bank is added. Put r=[epsilon a]_11 and ell=[delta b]_11. Direct word expansion gives the bank's Weyl coefficient

    alpha^r G_(epsilon,delta)(a,b)
       * beta^ell/(11 Delta) * sum_j w_j q^(epsilon delta j ell),

where G is zero if r+ell>10 and otherwise is the Gaussian coefficient for r copies of S and ell copies of T at q^(epsilon delta). Indeed X_j^11=(alpha^11+beta^11)I, and the finite geometric sum divided by Delta is the original inverse on both sides. The bracketed factor, divided by C below, is a sector amplitude. Arbitrary legal beta therefore cannot evade a necessary common-alpha moment condition. This statement also includes beta=0, without an inverse beta.

Direct Weyl extraction from the target gives C f(a,b), where

    C = (1/11) sum_t q^(-t^2) != 0,
    f(a,b) = q^(3(a+b)^2).

The fresh checker derives G by enumerating all binary words and counts every earlier T/later S commutation. It independently compares the result against the product formula. It also compares all 121 target coefficients per tested pair with the direct finite sum.

For a minus-plus singleton node y, the coordinate (a,b)=(11-b,b), b=1,2, has only minus-plus support and normalized target coefficient one. Hence its sector amplitude must be

    T_b = 1 / (y^b G_-+(11-b,b)).

The zero singleton node is impossible at (10,1). A beta=0 cross-sign singleton is impossible there as well. On the intervals a=1,...,9 for b=1 and a=2,...,8 for b=2, both negative-delta orientations vanish and G_++ is nonzero. Thus the plus-plus moments are forced:

    v_b(a) = [f(a,b)-T_b y^(11-a)G_-+(a,b)] / G_++(a,b).

Four consecutive six-term windows from v_1 and two from v_2 form a 6-by-6 matrix M. Every support statement and denominator is checked for each pair. `NINE_CASES.json` gives the sequences, forced amplitudes, matrices, and guards in full.

## Why the additional obstruction is necessary for legal banks

Suppose at most five effective plus-plus nodes represent these moments. Merge repeated ordinary nodes by adding their amplitudes in each sector. This does not produce derivative atoms. A zero plus-plus node contributes zero on both positive-exponent intervals and may be discarded for this argument.

Let X be the remaining set of distinct nonzero nodes. Under the frozen contract X is a subset of F23* with at most five elements. Extend X to a five-element subset X' of F23*: there are 22 available values. The polynomial

    g_(X')(t) = product_(x in X') (t-x)

is monic of degree five, squarefree, has nonzero constant term, and splits completely over F23. Every selected window satisfies its recurrence because each summand is A_(b,x) x^a and g_(X')(x)=0. Therefore M times the ascending coefficient vector of g_(X') is zero.

This padded-node argument covers fewer than five effective nodes, repeated original bank nodes, and alpha=0 banks without requiring a squarefree polynomial obtained by padding with powers of t. It does not assume the recurrence is sufficient for the full Fourier target.

For each of the nine pairs, a nonzero 5-by-5 minor and a nonzero kernel vector prove rank exactly five. The minor uses the first five rows and first five columns. Thus the kernel is one-dimensional, and its degree-five leading coordinate is nonzero. Every admissible monic annihilator must equal the unique polynomial displayed next. Direct evaluation at all 23 field elements proves that none has five distinct nonzero roots. That contradiction occurs before any choice of beta or branch weights can help, so original legal-bank reconstruction is impossible in the declared domain.

## Exact recurrence solutions

All coefficient vectors are ascending: (c_0,c_1,c_2,c_3,c_4,c_5) means sum c_k t^k. Every displayed vector has zero residual in all six original recurrence equations. The numbers in the minor column are exact residues modulo 23.

| q | y | Unique monic kernel vector | Nonzero F23 roots | gcd(g,g') | 5-by-5 minor |
|---|---|---|---|---|---|
| 3 | 4 | (13,3,1,22,12,1) | 3,22 | 1 | 8 |
| 4 | 10 | (15,12,6,14,6,1) | 22 | t+1 | 5 |
| 9 | 14 | (2,17,11,13,6,1) | 6,11 | 1 | 13 |
| 12 | 7 | (2,5,7,22,10,1) | 20 | 1 | 17 |
| 13 | 4 | (6,4,18,1,8,1) | none | 1 | 3 |
| 13 | 15 | (14,1,14,17,12,1) | 3,21 | 1 | 8 |
| 16 | 11 | (5,15,22,10,10,1) | none | 1 | 17 |
| 18 | 2 | (21,19,1,20,19,1) | 5 | 1 | 18 |
| 18 | 10 | (22,12,0,4,19,1) | 2 | 1 | 15 |

Eight are squarefree but do not split over the base field. At (4,10), the polynomial is (t+1)^2(t^3+4t^2+5t+15), so it also fails the ordinary-node squarefree guard. All nine have nonzero constant term. The packet does not promote these observations to an extension-field bank theorem.

The complete reduced row-echelon form has the first five columns equal to the first five identity columns, its sixth column equal to -(c_0,...,c_4,0)^t, and a zero last row. Hence the full set of recurrence coefficient vectors is exactly {s g : s in F23}; the displayed monic choice is unique.

## Exhaustive independent node-set crosscheck

A second arithmetic route does not use a nullspace or any of the nine computed polynomials. For every one of the 26,334 five-element subsets X of F23*, it directly multiplies product_(x in X)(t-x) and evaluates all six recurrence residuals against each fresh original-grammar matrix. This is 237,006 pair/subset tests.

Successive numbers of node sets surviving the first one, two, ..., six equations are:

| Pair | Successive survivors |
|---|---|
| (3,4) | 1144,45,3,0,0,0 |
| (4,10) | 1127,58,2,2,0,0 |
| (9,14) | 1148,55,1,0,0,0 |
| (12,7) | 1141,42,2,0,0,0 |
| (13,4) | 1138,47,0,0,0,0 |
| (13,15) | 1163,39,1,0,0,0 |
| (16,11) | 1153,55,2,0,0,0 |
| (18,2) | 1090,46,1,0,0,0 |
| (18,10) | 1126,58,2,0,0,0 |

`ALL_FIVE_NODE_SUBSETS.csv.gz` records all 26,334 subsets, all six polynomial coefficients, and all six residuals for each of the nine pairs. It uses deterministic gzip timestamps. This is an exhaustive obstruction within the finite field, not evidence about roots outside that field.

Positive synthetic controls recover a valid split five-node annihilator. Separate controls show that fewer nodes, repeated nodes, and a zero node are accepted by the padded distinct-node necessity rather than incorrectly rejected. These are listed in `SYNTHETIC_GUARD_CONTROLS.json`.

## Preservation, validation, and paid scope

- Historical scientific programs were never executed, imported, compiled, or evaluated. Only newly written `fresh_resolve_nine.py` was executed. Historical source and output snapshots are inert inputs.
- All fresh arithmetic is completed before historical `ALL_220_MATRICES.json` is opened for equality comparison. All nine newly derived matrices, both moment sequences, forced amplitudes, ranks, and singularity classifications agree with the accepted census.
- There are 4,356 word/product Gaussian agreements and 1,089 direct target-coefficient checks across nine pairs. Repeated q values are intentionally rederived per pair.
- Each rank certificate includes a 120-term permutation determinant of a 5-by-5 minor plus an independently computed zero kernel residual. The monic kernel is found by modular elimination; the minor determinant does not use elimination.
- There are nine polynomial derivative/gcd checks and 207 root evaluations, together with the exhaustive 237,006 pair/subset tests.
- The already accepted 211 exclusions are inherited from the pinned review, not re-proved here. Their extension-node scope is preserved. The earlier q=2 sextic/subset obstruction is not rerun or strengthened.
- These are finite checker workloads, not bank evaluation costs. An original bank still contains eleven branch inverses and eleven raw phase weights. No bank realization or full 121-entry bank equality is asserted for any of the nine excluded cases; the necessity contradiction is decisive before reconstruction.
- No Sheet, GitHub, or other external-service writes were made, and no historical file was modified.

## Replay and independent-review target

From this folder, run `python fresh_resolve_nine.py`. The script uses Python's standard library only and writes its deterministic JSON and compressed CSV beside itself. Its final printed status is PASS. Wall time in `RUN.log` is informational and excluded from deterministic replay comparisons.

The reviewer should independently derive the forced moments from the original branch grammar, prove the squarefree distinct-node padding necessity, verify all nine unique kernel polynomials and all 23 evaluations per polynomial, and replay or replace the exhaustive subset test. It should preserve the distinction between this all-F23 contract, the 211 accepted extension-node exclusions, and unresolved other-field cases.

The stopping condition is met: each declared pair has an exact additional base-field obstruction. This is ready for review, not self-certified independent acceptance.
