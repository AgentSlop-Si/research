#!/usr/bin/env python3
"""New exact finite F23 singleton gate and original-bank construction."""
import argparse, datetime, hashlib, itertools, json, pathlib, time
P=23; N=11; Q=13
ORIENT=((1,1),(-1,1),(1,-1),(-1,-1))

def solve(A,b):
    m=len(A); n=len(A[0]); R=[[v%P for v in row]+[b[i]%P] for i,row in enumerate(A)]
    piv=[]; r=0
    for c in range(n):
        k=next((i for i in range(r,m) if R[i][c]),None)
        if k is None: continue
        R[r],R[k]=R[k],R[r]; t=pow(R[r][c],-1,P); R[r]=[x*t%P for x in R[r]]
        for i in range(m):
            if i!=r and R[i][c]:
                t=R[i][c]; R[i]=[(x-t*y)%P for x,y in zip(R[i],R[r])]
        piv.append(c); r+=1
        if r==m: break
    if any(not any(row[:n]) and row[n] for row in R):return None,[],piv,R
    x=[0]*n
    for i,c in enumerate(piv):x[c]=R[i][n]
    basis=[]
    for c in range(n):
        if c not in piv:
            v=[0]*n;v[c]=1
            for i,j in enumerate(piv):v[j]=-R[i][c]%P
            basis.append(v)
    return x,basis,piv,R

def gaussian(w,r,l):
    v=1
    for k in range(1,r+1):v=v*(1-pow(w,l+k,P))*pow((1-pow(w,k,P))%P,-1,P)%P
    return v

def G(e,d,a,b):
    r=e*a%N;l=d*b%N
    return gaussian(pow(Q,e*d%N,P),r,l) if r+l<N else 0

def f(a,b):return pow(Q,3*(a+b)**2%N,P)
def val(c,x):
    v=0
    for k in c[::-1]:v=(v*x+k)%P
    return v

def mm(A,B):return [[sum(x*y for x,y in zip(row,col))%P for col in zip(*B)] for row in A]
def inverse(A):
    R=[row[:]+[int(i==j) for j in range(N)] for i,row in enumerate(A)]
    for c in range(N):
        k=next(i for i in range(c,N) if R[i][c]);R[c],R[k]=R[k],R[c]
        t=pow(R[c][c],-1,P);R[c]=[x*t%P for x in R[c]]
        for i in range(N):
            if i!=c:
                t=R[i][c];R[i]=[(x-t*y)%P for x,y in zip(R[i],R[c])]
    return [row[N:] for row in R]

def dump(out,name,v):
    (out/name).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')

def main(out):
    start=time.perf_counter(); utc=datetime.datetime.now(datetime.timezone.utc).isoformat();out.mkdir(parents=True,exist_ok=True)
    I=[[int(i==j) for j in range(N)] for i in range(N)]
    F=[[pow(Q,-k*t%N,P) for t in range(N)] for k in range(N)]
    C=sum(pow(Q,-t*t%N,P) for t in range(N))*pow(N,-1,P)%P
    assert C==18 and pow(Q,N,P)==1 and Q!=1
    # Independent extraction from literal target.
    for a,b in itertools.product(range(N),repeat=2):
        got=sum(F[(t+a)%N][t]*pow(Q,-b*t%N,P) for t in range(N))*pow(N,-1,P)%P
        assert got==C*f(a,b)%P
    # Product coefficients checked with an independently evaluated recurrence.
    for e,d in ORIENT:
        w=pow(Q,e*d%N,P);D={(0,0):1}
        for total in range(1,N+1):
            for r in range(total+1):
                l=total-r
                D[r,l]=(pow(w,l,P)*D.get((r-1,l),0)+D.get((r,l-1),0))%P
                if total<N:assert D[r,l]==gaussian(w,r,l)
                elif r and l:assert D[r,l]==0
    census=[]; eligible=[]
    for y in range(1,P):
        moments={}; Ts={}
        for b in range(1,6):
            a=N-b
            assert G(-1,1,a,b)!=0 and all(G(e,d,a,b)==0 for e,d in ORIENT if (e,d)!=(-1,1))
            T=pow(pow(y,b,P)*G(-1,1,a,b)%P,-1,P);Ts[str(b)]=T
            v=[]
            for a in range(b,N-b):
                assert G(1,1,a,b) and G(1,-1,a,b)==G(-1,-1,a,b)==0
                v.append((f(a,b)-T*pow(y,N-a,P)*G(-1,1,a,b))*pow(G(1,1,a,b),-1,P)%P)
            moments[str(b)]=v
        rec={'y':y,'T':Ts,'moments':moments,'degrees':{}}
        for deg in (5,6):
            H=[v[i:i+deg+1] for v in moments.values() for i in range(len(v)-deg)]
            x,basis,piv,rref=solve([row[:deg] for row in H],[-row[deg]%P for row in H])
            assert len(basis)<=3
            polynomials=[]; histogram=[0]*(deg+1)
            if x is not None:
                for pars in itertools.product(range(P),repeat=len(basis)):
                    c=[(x[i]+sum(t*v[i] for t,v in zip(pars,basis)))%P for i in range(deg)]+[1]
                    assert all(sum(k*v for k,v in zip(c,row))%P==0 for row in H)
                    roots=[z for z in range(1,P) if val(c,z)==0];histogram[len(roots)]+=1
                    polynomials.append({'coefficients':c,'roots':roots})
                    if deg==6 and len(roots)==6:eligible.append({'y':y,'support':roots,'annihilator':c})
            rec['degrees'][str(deg)]={'matrix':H,'rank_coefficient':len(piv),'rref_augmented':rref,'affine_dimension':None if x is None else len(basis),'count':len(polynomials),'root_histogram':histogram,'polynomials':polynomials}
        census.append(rec)
    assert all(r['degrees']['5']['root_histogram'][5]==0 for r in census)
    assert next(r for r in census if r['y']==4)['degrees']['6']['root_histogram'][6]==0
    dump(out,'MOMENT_CENSUS.json',census);dump(out,'ELIGIBLE_SEXTICS.json',eligible)
    total=len(eligible)**2; tested=[]; found=None
    order=itertools.chain(((i,i) for i in range(len(eligible))),((i,j) for i in range(len(eligible)) for j in range(len(eligible)) if i!=j))
    for i,j in order:
        left,right=eligible[i],eligible[j]
        params=[(1,1,x) for x in left['support']]+[(-1,1,left['y']),(1,-1,right['y'])]+[(-1,-1,x) for x in right['support']]
        amplitudes=[];ranks=[]; systems=[]
        for b in range(N):
            A=[[pow(x,e*a%N,P)*G(e,d,a,b)%P for e,d,x in params] for a in range(N)]
            rhs=[f(a,b) for a in range(N)];x,basis,piv,rref=solve(A,rhs)
            ranks.append(len(piv))
            if x is None:break
            assert all(sum(k*v for k,v in zip(row,x))%P==r for row,r in zip(A,rhs))
            amplitudes.append(x);systems.append({'sector':b,'matrix':A,'rhs':rhs,'solution':x,'pivots':piv})
        tested.append({'left_index':i,'right_index':j,'all_sectors_solved':len(amplitudes)==N,'ranks':ranks})
        if len(amplitudes)==N:
            found=(params,amplitudes,systems);break
    dump(out,'FULL_PAIR_TESTS.json',{'candidate_pair_count':total,'tested':tested})
    if found:
        params,amplitudes,systems=found;banks=[];branches=[];aggregate=[[0]*N for _ in range(N)]
        for k,(e,d,alpha) in enumerate(params):
            delta=-pow(alpha,N,P)%P;assert delta
            amp=[amplitudes[b][k] for b in range(N)]
            weights=[delta*C*sum(amp[b]*pow(Q,-e*b*j%N,P) for b in range(N))%P for j in range(N)]
            for b in range(N):assert sum(weights[j]*pow(Q,e*b*j%N,P) for j in range(N))*pow(N*delta*C%P,-1,P)%P==amp[b]
            bank=[[0]*N for _ in range(N)]
            for j in range(N):
                A=[[int(r==t) for t in range(N)] for r in range(N)]
                for t in range(N):
                    A[(t+e)%N][t]=(A[(t+e)%N][t]-alpha)%P
                    A[t][t]=(A[t][t]-pow(Q,e*d*j+d*t%N,P))%P
                inv=inverse(A);assert mm(A,inv)==I and mm(inv,A)==I
                for r,t in itertools.product(range(N),repeat=2):bank[r][t]=(bank[r][t]+pow(N,-1,P)*weights[j]*inv[r][t])%P
                branches.append({'bank_index':k,'phase':j,'matrix':A,'inverse':inv})
            assert any(v for row in bank for v in row)
            for a,b in itertools.product(range(N),repeat=2):
                got=sum(bank[(t+a)%N][t]*pow(Q,-b*t%N,P) for t in range(N))*pow(N,-1,P)%P
                assert got==C*amp[b]*pow(alpha,e*a%N,P)*G(e,d,a,b)%P
            for r,t in itertools.product(range(N),repeat=2):aggregate[r][t]=(aggregate[r][t]+bank[r][t])%P
            banks.append({'epsilon':e,'delta':d,'alpha':alpha,'beta':1,'Delta':delta,'raw_weights':weights,'amplitudes_by_b':amp,'matrix':bank})
        assert aggregate==F
        dump(out,'WITNESS.json',{'field':P,'N':N,'q':Q,'banks':banks,'sector_systems':systems,'target':F,'aggregate':aggregate})
        dump(out,'BRANCHES.json',branches)
    summary={'C':C,'singleton_nodes_tested':22,'quintic_count':sum(r['degrees']['5']['count'] for r in census),'sextic_count':sum(r['degrees']['6']['count'] for r in census),'eligible_sextics':len(eligible),'eligible_by_y':{str(y):sum(r['y']==y for r in eligible) for y in range(1,P)},'degree_five_lower_bound':True,'full_pairs_tested':len(tested),'pair_budget':total,'witness_banks':len(found[0]) if found else None,'full_121_equal':bool(found),'branch_inverse_count':len(branches) if found else 0,'inverse_product_checks':2*len(branches) if found else 0,'new_code_only':True}
    dump(out,'RESULTS.json',summary)
    dump(out,'TIMING.json',{'start_utc_system':utc,'end_utc_system':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-start,'errors':[],'model_token_usage':'unavailable'})
    print(json.dumps(summary,sort_keys=True))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=pathlib.Path,required=True);main(parser.parse_args().out)
