# Unpinned singleton F23 gate

The candidate equality is 14 original banks at N=11,q=13 over F23, retaining one effective cross-sign node in each orientation while allowing their alphas to vary independently. Both witness cross nodes are 7; same-sign supports are {6,7,12,13,17,19}. See REPORT.md for full proof and scope.

Only fresh_gate.py was newly executed. Reproduce with:

    python 3 -I fresh_gate.py --out replay

The standalone raw certificate is outputs/WITNESS.json. No historical code is required. The exact lower-bound premise is the all 22-y degree-five portion of outputs/MOMENT_CENSUS.json. The declared full witness search stopped on the first of 9 candidate support pairs.

Status: candidate, awaiting independent review. No claim is made about unrestricted-orientation optimality or historical novelty.
