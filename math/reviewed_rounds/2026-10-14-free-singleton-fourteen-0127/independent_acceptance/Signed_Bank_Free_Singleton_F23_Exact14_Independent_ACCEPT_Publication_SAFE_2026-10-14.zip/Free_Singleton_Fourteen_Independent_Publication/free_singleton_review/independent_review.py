"""Fresh independent verifier: literal linear algebra and word enumeration.
Does not import, execute, or compile any candidate/historical program.
"""
import itertools, json, hashlib, time, datetime, pathlib, copy, math
P=23; N=11; Q=13; NI=pow(N,-1,P)
HERE=pathlib.Path(__file__).resolve().parent
SRC=HERE.parent/'free_singleton_candidate'
START=time.perf_counter()
START_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(name): return json.loads((SRC/'outputs'/name).read_text())
def save(name,data): (HERE/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def require(v,why):
    if not v: raise AssertionError(why)
def mm(A,B):
    return [[sum(x*y for x,y in zip(row,col))%P for col in zip(*B)] for row in A]
def eye(n): return [[int(i==j) for j in range(n)] for i in range(n)]
def zero(n=N): return [[0]*n for _ in range(n)]
def add_scaled(A,B,c):
    for r in range(len(A)):
        for s in range(len(A[r])): A[r][s]=(A[r][s]+c*B[r][s])%P

def row_reduce(A,nvars):
    A=[[v%P for v in row] for row in A]; piv=[]; row=0
    for col in range(nvars):
        pivot=next((r for r in range(row,len(A)) if A[r][col]),None)
        if pivot is None: continue
        A[row],A[pivot]=A[pivot],A[row]
        z=pow(A[row][col],-1,P); A[row]=[(z*v)%P for v in A[row]]
        for r in range(len(A)):
            if r!=row:
                z=A[r][col]
                A[r]=[(a-z*b)%P for a,b in zip(A[r],A[row])]
        piv.append(col); row+=1
        if row==len(A): break
    return A,piv

def inv(A):
    n=len(A); R,piv=row_reduce([row+unit for row,unit in zip(A,eye(n))],n)
    require(len(piv)==n,'singular literal branch')
    return [row[n:] for row in R]

def affine(A,b,nvars):
    R,piv=row_reduce([a+[z] for a,z in zip(A,b)],nvars)
    if any(not any(row[:nvars]) and row[nvars] for row in R):
        return {'rank':len(piv),'dimension':None,'solutions':[],'rref':R}
    free=[c for c in range(nvars) if c not in piv]
    require(len(free)<=3,'unexpectedly large affine family')
    solutions=[]
    for vals in itertools.product(range(P),repeat=len(free)):
        x=[0]*nvars
        for c,v in zip(free,vals): x[c]=v
        for r,c in enumerate(piv): x[c]=(R[r][-1]-sum(R[r][f]*x[f] for f in free))%P
        require(all(sum(u*v for u,v in zip(row,x))%P==z%P for row,z in zip(A,b)),'bad affine reconstruction')
        solutions.append(x)
    return {'rank':len(piv),'dimension':len(free),'solutions':solutions,'rref':R}

def poly(nodes):
    out=[1]
    for x in nodes:
        nxt=[0]*(len(out)+1)
        for k,c in enumerate(out): nxt[k]=(nxt[k]-x*c)%P; nxt[k+1]=(nxt[k+1]+c)%P
        out=nxt
    return out

def evaluate(p,x):
    z=0
    for c in reversed(p): z=(z*x+c)%P
    return z

def branch(bank,j,phase_sign=1):
    e,d,alpha,beta=[bank[k] for k in ('epsilon','delta','alpha','beta')]
    A=eye(N)
    for t in range(N):
        A[(t+e)%N][t]=(A[(t+e)%N][t]-alpha)%P
        A[t][t]=(A[t][t]-beta*pow(Q,(phase_sign*e*d*j+d*t)%N,P))%P
    return A

F=[[pow(Q,(-k*t)%N,P) for t in range(N)] for k in range(N)]
require(pow(Q,N,P)==1 and Q!=1,'root order')
# Extract coefficient of S^a T^b directly from the literal target's shifted diagonal.
coef=[[NI*sum(F[(t+a)%N][t]*pow(Q,(-b*t)%N,P) for t in range(N))%P for b in range(N)] for a in range(N)]
C=coef[0][0]; require(C==18,'target scalar')
normalized=[[v*pow(C,-1,P)%P for v in row] for row in coef]
require(all(normalized[a][b]==pow(Q,3*(a+b)**2%N,P) for a in range(N) for b in range(N)),'target quadratic formula')
# Count every word in S^e,T^d of length <=10. Each T preceding an S produces q^(ed).
G={}
for e,d in itertools.product((1,-1),repeat=2):
    factors=zero()
    for length in range(N):
        for word in itertools.product((0,1),repeat=length): # 0=S; 1=T
            seen_t=0; inversions=0; r=0
            for letter in word:
                if letter: seen_t+=1
                else: r+=1; inversions+=seen_t
            a=e*r%N; b=d*seen_t%N
            factors[a][b]=(factors[a][b]+pow(Q,e*d*inversions%N,P))%P
    G[(e,d)]=factors
mixed_degree_eleven={}
for e,d in itertools.product((1,-1),repeat=2):
    coeff=[0]*(N+1)
    for word in itertools.product((0,1),repeat=N):
        ts=0; inversion_count=0; ss=0
        for letter in word:
            if letter: ts+=1
            else: ss+=1; inversion_count+=ts
        coeff[ss]=(coeff[ss]+pow(Q,e*d*inversion_count%N,P))%P
    require(coeff==[1]+[0]*(N-1)+[1],'mixed eleventh-power coefficient')
    mixed_degree_eleven[str((e,d))]=coeff
require(all(G[(e,d)][10][1]==0 for e,d in ((1,1),(1,-1),(-1,-1))),'sole-support gate')
require(G[(-1,1)][10][1]!=0 and normalized[10][1]!=0,'nonzero sole support')
require(all(F[-k%N][-t%N]==F[k][t] for k in range(N) for t in range(N)),'reflection target invariant')
save('DERIVED_TARGET_AND_WORD_FACTORS.json',{'C':C,'coefficient':coef,'normalized':normalized,'G':{str(k):v for k,v in G.items()},'words_per_orientation':2**N-1,'degree_eleven_coefficients':mixed_degree_eleven})

witness=read('WITNESS.json'); old_branches=read('BRANCHES.json'); input_banks=witness['banks']
require((witness['field'],witness['N'],witness['q'])==(P,N,Q),'witness parameter mismatch')
require(len(input_banks)==14,'wrong bank count')
require(witness['target']==F,'claimed target mismatch')
branch_index={(x['bank_index'],x.get('phase',x.get('j'))):x for x in old_branches}
print('branch record keys',old_branches[0].keys(),flush=True)
invdata=[]; matrices=[]; aggregate=zero(); counts={}; effective={}; raw_recovered=[]
for bank_id,bank in enumerate(input_banks):
    e,d,alpha,beta=[bank[k] for k in ('epsilon','delta','alpha','beta')]
    key=(e,d); counts[str(key)]=counts.get(str(key),0)+1
    require(e in (-1,1) and d in (-1,1),'illegal orientation')
    require(all(isinstance(v,int) and 0<=v<P for v in [alpha,beta]+bank['raw_weights']),'noncanonical field entry')
    Delta=(1-pow(alpha,N,P)-pow(beta,N,P))%P
    require(Delta!=0 and Delta==bank['Delta'],'Delta mismatch/illegal')
    A_by_b=bank['amplitudes_by_b']; require(len(A_by_b)==N,'amplitude count')
    # Recover raw weights by solving the character system, rather than trusting stored weights.
    char=[[NI*pow(Q,e*b*j%N,P)%P for j in range(N)] for b in range(N)]
    rhs=[C*Delta*A_by_b[b]*pow(pow(beta,d*b%N,P),-1,P)%P for b in range(N)]
    solution=affine(char,rhs,N)
    require(solution['dimension']==0,'character transform not invertible')
    recovered=solution['solutions'][0]
    require(recovered==bank['raw_weights'],'raw weight reconstruction mismatch')
    raw_recovered.append(recovered)
    group=effective.setdefault(key,{})
    if alpha not in group: group[alpha]=[0]*N
    for b in range(N): group[alpha][b]=(group[alpha][b]+A_by_b[b])%P
    B=zero()
    for j,w in enumerate(recovered):
        L=branch(bank,j); R=inv(L)
        require(mm(L,R)==eye(N) and mm(R,L)==eye(N),'inverse identity fail')
        old=branch_index[(bank_id,j)]
        require(old['matrix']==L and old['inverse']==R,'candidate branch mismatch')
        add_scaled(B,R,NI*w%P)
        invdata.append({'bank_index':bank_id,'j':j,'matrix':L,'inverse':R})
    require(any(v for row in B for v in row),'zero bank')
    require(B==bank['matrix'],'candidate bank matrix mismatch')
    # Completely separate coefficient reconstruction as another cross-check.
    projected=zero()
    for a in range(N):
        for b in range(N):
            c=C*A_by_b[b]*pow(alpha,e*a%N,P)*G[key][a][b]%P
            for t in range(N): projected[(t+a)%N][t]=(projected[(t+a)%N][t]+c*pow(Q,b*t%N,P))%P
    require(projected==B,'literal versus word-coefficient bank mismatch')
    matrices.append(B); add_scaled(aggregate,B,1)
require(aggregate==F==witness['aggregate'],'literal full target mismatch')
effective={str(key):sorted(a for a,v in nodes.items() if any(v)) for key,nodes in effective.items()}
require(effective[str((1,1))]==effective[str((-1,-1))]==[6,7,12,13,17,19],'same-sign support mismatch')
require(effective[str((-1,1))]==[7] and effective[str((1,-1))]==[7],'singleton architecture mismatch')
require([counts[str(k)] for k in [(1,1),(-1,1),(1,-1),(-1,-1)]]==[6,1,1,6],'orientation allocation mismatch')
sector_ranks=[]
for sector in witness['sector_systems']:
    b=sector['sector']
    expected=[[G[(bank['epsilon'],bank['delta'])][a][b]*pow(bank['alpha'],bank['epsilon']*a%N,P)%P for bank in input_banks] for a in range(N)]
    require(sector['matrix']==expected,'sector matrix mismatch')
    _,piv=row_reduce(expected,len(input_banks)); sector_ranks.append(len(piv))
    require(sector['rhs']==[normalized[a][b] for a in range(N)],'sector RHS mismatch')
    require(sector['solution']==[bank['amplitudes_by_b'][b] for bank in input_banks],'sector solution mismatch')
    require(all(sum(x*y for x,y in zip(row,sector['solution']))%P==rhs for row,rhs in zip(expected,sector['rhs'])),'sector equation fail')
require(sector_ranks==[11,8,10,11,11,11,11,11,11,10,8],'sector rank mismatch')
pair_record=read('FULL_PAIR_TESTS.json')
require(pair_record=={'candidate_pair_count':9,'tested':[{'all_sectors_solved':True,'left_index':0,'right_index':0,'ranks':sector_ranks}]},'candidate pair record mismatch')
save('LITERAL_BRANCHES.json',invdata)
save('LITERAL_WITNESS_CHECK.json',{'branch_inversions':len(invdata),'inverse_product_identities':2*len(invdata),'raw_weights':raw_recovered,'bank_matrices':matrices,'aggregate':aggregate,'effective_nodes':effective,'orientation_counts':counts,'sector_ranks':sector_ranks})
print('Literal 154 inverses, 154 raw weights, 14 banks, 121 target entries verified',flush=True)

candidate_census=read('MOMENT_CENSUS.json'); fresh_census=[]; eligible=[]; gate_rows={5:{},6:{}}
for y in range(1,P):
    moments={}; Tb={}
    for b in range(1,6):
        forced=normalized[N-b][b]*pow(pow(y,b,P)*G[(-1,1)][N-b][b]%P,-1,P)%P
        Tb[str(b)]=forced
        v=[]
        for a in range(b,N-b):
            require(all(G[k][a][b]==0 for k in ((1,-1),(-1,-1))),'negative delta in central window')
            residual=(normalized[a][b]-forced*pow(y,N-a,P)*G[(-1,1)][a][b])%P
            v.append(residual*pow(G[(1,1)][a][b],-1,P)%P)
        moments[str(b)]=v
    old=candidate_census[y-1]; require(old['y']==y and old['moments']==moments and old['T']==Tb,'candidate moment mismatch')
    record={'y':y,'T':Tb,'moments':moments,'degrees':{}}
    for degree in (5,6):
        rows=[v[offset:offset+degree+1] for b in (1,2) for v in [moments[str(b)]] for offset in range(len(v)-degree)]
        gate_rows[degree][y]=rows
        sol=affine([row[:-1] for row in rows],[-row[-1]%P for row in rows],degree)
        polys=[]; hist=[0]*(degree+1)
        for prefix in sol['solutions']:
            p=prefix+[1]; roots=[x for x in range(1,P) if evaluate(p,x)==0]
            polys.append({'coefficients':p,'roots':roots}); hist[len(roots)]+=1
            if degree==5:
                # Padding by t^(5-m) would require enough nonzero roots after removing initial zero coefficients.
                zero_mult=next((k for k,c in enumerate(p) if c),degree+1)
                require(len(roots)<degree-zero_mult,'admissible padded quintic')
            elif len(roots)==6: eligible.append({'y':y,'support':roots,'annihilator':p})
        before=old['degrees'][str(degree)]
        require(before['rref_augmented']==sol['rref'],'candidate row-reduction mismatch')
        require(before['rank_coefficient']==sol['rank'] and before['affine_dimension']==sol['dimension'],'candidate census rank/dimension mismatch')
        require(sorted((tuple(x['coefficients']),tuple(x['roots'])) for x in polys)==sorted((tuple(x['coefficients']),tuple(x['roots'])) for x in before['polynomials']),'candidate polynomial/roots mismatch')
        require(before['count']==len(polys) and before['root_histogram']==hist and before['matrix']==rows,'candidate census detail mismatch')
        record['degrees'][str(degree)]={'rank':sol['rank'],'dimension':sol['dimension'],'polynomials':polys,'root_histogram':hist,'matrix':rows,'rref':sol['rref']}
    fresh_census.append(record)
require(eligible==read('ELIGIBLE_SEXTICS.json'),'sextic eligibility mismatch')
save('INDEPENDENT_MOMENT_CENSUS.json',fresh_census)
save('INDEPENDENT_ELIGIBLE_SEXTICS.json',eligible)
print('All 22 affine quintic/sextic censuses match; sextic survivors at y=7,10,12',flush=True)

# A second exact method: enumerate all subsets, build ordinary annihilators, test all 22 gates.
# Degree-five subset padding is safe because 22 available nodes exceed every support size <=5.
node_census={}
for degree in (5,6):
    survivors=[]; tested=0; all_y=list(gate_rows[degree].items()); census_start=time.perf_counter()
    for nodes in itertools.combinations(range(1,P),degree):
        p=poly(nodes); tested+=1
        for y,rows in all_y:
            if all(sum(c*v for c,v in zip(p,row))%P==0 for row in rows):
                survivors.append({'y':y,'support':list(nodes),'annihilator':p})
    if degree==5: require(not survivors,'five-node set survived independent subset census')
    else: require(sorted(survivors,key=lambda z:z['y'])==eligible,'subset/affine sextic census mismatch')
    node_census[str(degree)]={'ordinary_sets_tested':tested,'y_values_per_set':22,'gate_tests':tested*22,'survivors':survivors,'wall_seconds':time.perf_counter()-census_start}
    print('Independent ordinary-node census degree',degree,'sets',tested,'survivors',len(survivors),flush=True)
save('INDEPENDENT_SUBSET_CENSUS.json',node_census)

# Adversarial controls use already rebuilt literal inverses where possible.
controls=[]
def reject(label,observed):
    require(observed,label+' was not rejected'); controls.append({'mutation':label,'rejected':True})
B0=input_banks[0]; altered=copy.deepcopy(aggregate); add_scaled(altered,invdata[0]['inverse'],NI)
reject('Increment one raw phase weight modulo 23',altered!=F)
reject('Drop 1/11 bank normalization',[[N*v%P for v in row] for row in aggregate]!=F)
reject('Reverse target Fourier exponent',F!=[[pow(Q,k*t%N,P) for t in range(N)] for k in range(N)])
for i,B in enumerate(matrices):
    altered=copy.deepcopy(aggregate); add_scaled(altered,B,-1)
    reject('Delete actual bank '+str(i),altered!=F)
# Reversing the j character sign preserves legal inverses but usually destroys the target.
wrong_phase=zero()
for i,bank in enumerate(input_banks):
    for j,w in enumerate(bank['raw_weights']): add_scaled(wrong_phase,invdata[i*N+((-j)%N)]['inverse'],NI*w%P)
reject('Reverse every branch phase sign with weights unchanged',wrong_phase!=F)
# An explicit illegal denominator is independently singular in the literal branch.
try:
    inv(branch({'epsilon':1,'delta':1,'alpha':0,'beta':1},0)); singular=False
except AssertionError: singular=True
reject('Allow alpha=0 beta=1 despite Delta=0',singular)
reject('Permit zero cross alpha at sole-support coordinate (10,1)',pow(0,1,P)*G[(-1,1)][10][1]==0 and normalized[10][1]!=0)
reject('Treat y=4 as passing degree-six support gate',not any(e['y']==4 for e in eligible))
# Alter one root of the y7 necessary support.
wrong_support=sorted([1]+eligible[0]['support'][1:]); badpoly=poly(wrong_support)
reject('Replace support root 6 by 1 in y=7 sextic',any(sum(c*v for c,v in zip(badpoly,row))%P for row in gate_rows[6][7]))
altered_banks=copy.deepcopy(input_banks)
altered_banks[0]['epsilon']=-1
mutated_effective={}
for bank in altered_banks:
    e,d,alpha,beta=[bank[k] for k in ('epsilon','delta','alpha','beta')]
    Delta=(1-pow(alpha,N,P)-pow(beta,N,P))%P
    vec=[pow(C*Delta%P,-1,P)*pow(beta,d*b%N,P)*NI*sum(w*pow(Q,e*b*j%N,P) for j,w in enumerate(bank['raw_weights']))%P for b in range(N)]
    key=(e,d,alpha)
    if key not in mutated_effective: mutated_effective[key]=[0]*N
    mutated_effective[key]=[(x+y)%P for x,y in zip(mutated_effective[key],vec)]
extra_nodes=[a for (e,d,a),v in mutated_effective.items() if (e,d)==(-1,1) and any(v)]
reject('Change bank 0 orientation from ++ to -+, creating second effective cross node',len(extra_nodes)>1)
corrupt_inverse=copy.deepcopy(invdata[0]['inverse']); corrupt_inverse[0][0]=(corrupt_inverse[0][0]+1)%P
reject('Increment one entry of a stored branch inverse',mm(invdata[0]['matrix'],corrupt_inverse)!=eye(N))
save('MUTATION_CONTROLS.json',controls)

summary={'verdict':'ACCEPT within unpinned singleton architecture','field':P,'N':N,'q':Q,'C':C,'minimum_actual_banks':14,'orientation_counts':[6,1,1,6],'cross_alphas':[7,7],'same_sign_support':[6,7,12,13,17,19],'literal_inverse_count':154,'inverse_identity_count':308,'verified_raw_weights':154,'verified_target_entries':121,'all_banks_nonzero':True,'lower_bound_cross_nodes_independent':True,'lower_bound_beta_arbitrary':True,'exactly_one_effective_cross_node_per_orientation_retained':True,'quintic_consistent_y':[r['y'] for r in fresh_census if r['degrees']['5']['polynomials']],'quintic_total':sum(len(r['degrees']['5']['polynomials']) for r in fresh_census),'sextic_total':sum(len(r['degrees']['6']['polynomials']) for r in fresh_census),'sextic_surviving_y':[e['y'] for e in eligible],'candidate_data_all_matched':True,'mutation_controls':len(controls),'unrestricted_orientation_count_optimum_claim':False,'novelty_claim':False,'fft_speed_claim':False,'executed_code':'only this newly authored independent_review.py','errors':[]}
save('RESULTS.json',summary)
save('TIMING.json',{'start_utc':START_UTC,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-START,'model_token_usage':'unavailable','errors':[]})
sources=[SRC/'CONTRACT.md',SRC/'REPORT.md',SRC/'fresh_gate.py']+sorted((SRC/'outputs').glob('*.json'))
save('SOURCE_HASHES.json',{str(p.relative_to(HERE.parent)):digest(p) for p in sources})
save('FILE_HASHES.json',{p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ('FILE_HASHES.json','RUN.log')})
print(json.dumps(summary,indent=2),flush=True)
