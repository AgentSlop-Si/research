"""New read-only source/receipt inspector; never imports inspected code."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path(__file__).resolve().parent.parent;OUT=Path(__file__).resolve().parent
base=ROOT/'observer_v2_candidate'
contract=json.loads((base/'CONTRACT.json').read_text())
files=[]
for spec in contract['files']:
 p=base/spec['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==spec['sha256'] and len(b)==spec['bytes']
 tree=ast.parse(b)
 definitions=[]
 for n in tree.body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
   d={'name':n.name,'kind':type(n).__name__,'line':n.lineno}
   if isinstance(n,ast.FunctionDef):d['arguments']=[x.arg for x in n.args.args]
   else:d['fields']=[x.target.id for x in n.body if isinstance(x,ast.AnnAssign) and isinstance(x.target,ast.Name)]
   definitions.append(d)
 files.append({'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'definitions':definitions})
source_paths=[
 'observer_v2_candidate/CONTRACT.json',
 'observer_v2_candidate/integration_harness.py',
 'observer_v2_accepted_review/FINAL_REVIEW.md',
 'observer_v2_execution/results/EXECUTION_RESULT.json',
 'outer_contract_recovered/CONTRACT.md',
 'outer_contract_recovered/MISSING_TEST.md',
 'outer_contract_static_acceptance/MANIFEST.json',
 'bounded_reference_regression/MANIFEST.json',
 'bounded_reference_regression/SEAL.json',
 'bounded_reference_regression/regression.py',
 'bounded_reference_regression/RESULTS.json']
for rel in source_paths:
 b=(ROOT/rel).read_bytes();files.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
r=json.loads((ROOT/'observer_v2_execution/results/EXECUTION_RESULT.json').read_text())
actual_inventory={x['module']:x for x in r['source_inventory']}
for spec in contract['files']:assert actual_inventory[spec['module']]['sha256']==spec['sha256']
fixtures=[]
for c in contract['cases']:
 N=c['N'];m=(4*N-1).bit_length();M=1<<m;t=160*m+4
 fixtures.append({'id':c['id'],'N':N,'M':M,'m':m,'D':5,'outer_t':t,'outer_sparse_guard_t_lt_M':t<M,'consumer_run':c['pipeline']})
assert not any(x['outer_sparse_guard_t_lt_M'] for x in fixtures)
# Restrict absence evidence to the actual chain and its two contract directories.
bounded_files=[]
for rel in ['observer_v2_candidate/source_bytes','outer_contract_initial_candidate','outer_contract_recovered']:
 for p in sorted((ROOT/rel).glob('*.py')):
  tree=ast.parse(p.read_bytes())
  bounded_files.append({'path':str(p.relative_to(ROOT)),'top_level_definitions':[n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]})
report={'verdict':'MISSING_PRODUCTION_OUTER_WRAPPER_AND_PROVENANCE_ADAPTER_IN_INSPECTED_CHAIN',
 'scope':'Six pinned accepted modules, observer contract/result, and original/recovered outer contract directories; no broad repository or external search.',
 'source_pins':files,'bounded_source_inventory':bounded_files,'existing_fixture_guard_checks':fixtures,
 'historical_code_executed':False,'source_mutations':False,'regression_preserved_unchanged':True}
(OUT/'SOURCE_INTERFACE_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'source_pins':len(files),'bounded_python_files':len(bounded_files),'accepted_fixture_outer_sparse_guard_passes':0},indent=2))
