# Independent parameter and cubic obstruction review

Start with REVIEW.md. RESULTS.json contains the fresh exact certificates, and SOURCE_HASHES.json binds the inert input evidence.

Run the new standard-library checker from the task workspace:

    python -I independent_lower_bound/independent_verify.py

Or supply --out followed by a new output directory. No candidate or historical program is imported or run. Source reports and JSON records must remain present at their hashed relative paths.

Accepted result: no at-most-twelve-bank original representation over F23^3 with N=11, q=13, literal Fourier target and exactly one effective alpha node in each cross orientation. Arbitrary legal beta and physical-bank counting are retained. No exact minimum is asserted here.
