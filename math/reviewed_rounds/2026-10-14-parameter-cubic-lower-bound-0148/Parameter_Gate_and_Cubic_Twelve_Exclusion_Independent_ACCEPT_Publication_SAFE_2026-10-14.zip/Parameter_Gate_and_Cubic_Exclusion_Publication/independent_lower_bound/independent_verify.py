"""Independent exact review. Imports no candidate or historical program.
Arithmetic is standard-library only; input JSON is inert evidence.
"""
import json, hashlib, itertools, time, argparse
from pathlib import Path
from functools import lru_cache
P=23; Q=13; N=11
ROOT=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
OUT=parser.parse_args().out.resolve();OUT.mkdir(parents=True,exist_ok=True)
started=time.monotonic()
def trim(a):
 a=list(a)
 while a and a[-1]%P==0:a.pop()
 return tuple(x%P for x in a)
Z=(); O=(1,); Y=(0,1)
def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def neg(a):return trim([-v for v in a])
def sub(a,b):return add(a,neg(b))
def scale(a,c):return trim([x*c for x in a])
def mul(a,b):
 if not a or not b:return Z
 out=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return trim(out)
def divrem(a,b):
 assert b
 a=list(a);out=[0]*max(0,len(a)-len(b)+1);iv=pow(b[-1],-1,P)
 while len(a)>=len(b):
  k=len(a)-len(b);v=a[-1]*iv%P;out[k]=v
  for j,w in enumerate(b):a[k+j]=(a[k+j]-v*w)%P
  while a and a[-1]==0:a.pop()
 return trim(out),trim(a)
def mod(a,b):return divrem(a,b)[1]
def xgcd(a,b):
 aa,bb=a,b;s,t=O,Z;u,v=Z,O
 while bb:
  q,r=divrem(aa,bb);aa,bb=bb,r;s,u=u,sub(s,mul(q,u));t,v=v,sub(t,mul(q,v))
 c=pow(aa[-1],-1,P);return scale(aa,c),scale(s,c),scale(t,c)
def gcd(a,b):return xgcd(a,b)[0]
def powmod(a,n,m):
 o=O
 while n:
  if n&1:o=mod(mul(o,a),m)
  n//=2;a=mod(mul(a,a),m)
 return o
def evaluate(a,y):
 v=0
 for c in a[::-1]:v=(v*y+c)%P
 return v
def derivative(a):return trim([i*a[i] for i in range(1,len(a))])
def coeff(a):return list(a) or [0]
def det(M):
 n=len(M)
 @lru_cache(None)
 def recurse(cols):
  row=n-len(cols)
  if not cols:return O
  out=Z
  for j,col in enumerate(cols):
   term=mul(M[row][col],recurse(cols[:j]+cols[j+1:]))
   out=add(out,term) if j%2==0 else sub(out,term)
  return out
 return recurse(tuple(range(n)))
def irred(f):
 n=len(f)-1;assert n>=1
 current=mod(Y,f);steps=[current]
 for _ in range(n):current=powmod(current,P,f);steps.append(current)
 assert current==mod(Y,f)
 primes=[];k=n;r=2
 while r*r<=k:
  if k%r==0:
   primes.append(r)
   while k%r==0:k//=r
  r+=1
 if k>1:primes.append(k)
 checks=[]
 for r in primes:
  g,s,t=xgcd(f,sub(steps[n//r],Y));assert g==O
  assert add(mul(s,f),mul(t,sub(steps[n//r],Y)))==O
  checks.append({'prime_divisor':r,'gcd':coeff(g),'bezout_f':coeff(s),'bezout_frobenius_minus_y':coeff(t)})
 return {'degree':n,'frobenius_iterates':[coeff(z) for z in steps],'checks':checks,'irreducible':True}
def load(path):return json.loads((ROOT/path).read_text())
source_names=['parameter_gate_candidate/REPORT.md','parameter_gate_candidate/outputs/RESULTS.json','parameter_gate_candidate/outputs/ROOT_CERTIFICATES.json','free_singleton_candidate/REPORT.md','free_singleton_candidate/outputs/MOMENT_CENSUS.json','free_singleton_review/INDEPENDENT_MOMENT_CENSUS.json','cubic_twelve_failure_candidate/outputs/RESULTS.json','cubic_twelve_failure_candidate/outputs/FAILURE.json','cubic_twelve_failure_candidate/outputs/BRANCHES.json','cubic_twelve_failure_candidate/outputs/MUTATION_CONTROLS.json','cubic_twelve_failure_candidate/REPORT.md']
sources=[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),'bytes':(ROOT/name).stat().st_size} for name in source_names]
claimed=load(source_names[1]);rootcert=load(source_names[2])
# Rebuild ordered-word coefficients directly from all binary words, without Gaussian-code input.
words={}
for sign in (-1,1):
 omega=pow(Q,sign%N,P)
 for length in range(N+1):
  sums=[0]*(length+1)
  for bits in itertools.product((0,1),repeat=length):
   r=l=inv=0
   for bit in bits:
    if bit==0:r+=1;inv+=l
    else:l+=1
   sums[r]=(sums[r]+pow(omega,inv,P))%P
  if length==N:assert sums==[1]+[0]*10+[1]
  for r,val in enumerate(sums):words[sign,r,length-r]=val

def G(e,d,a,b):
 r=e*a%N;l=d*b%N
 return words[e*d,r,l] if r+l<N else 0
F=[[pow(Q,-k*t%N,P) for t in range(N)] for k in range(N)]
C={}
for a in range(N):
 for b in range(N):
  C[a,b]=sum(F[(t+a)%N][t]*pow(Q,-b*t%N,P) for t in range(N))*pow(N,-1,P)%P
  assert C[a,b]==18*pow(Q,3*(a+b)**2%N,P)%P
  assert F[-a%N][-b%N]==F[a][b]
triples={};moments={}
for b in range(1,6):
 rows=[];ss=[]
 for a in range(b,11-b):
  assert G(1,-1,a,b)==G(-1,-1,a,b)==0
  assert G(1,1,a,b)!=0
  u=pow(Q,3*(a+b)**2%N,P)*pow(G(1,1,a,b),-1,P)%P
  d=G(-1,1,a,b)*pow(G(-1,1,11-b,b)*G(1,1,a,b)%P,-1,P)%P
  exponent=11-a-b
  rows.append([u,d,exponent]);poly=[u]+[0]*exponent;poly[exponent]-=d;ss.append(trim(poly))
 triples[str(b)]=rows;moments[str(b)]=ss
 # Check sole-support coordinate from actual grammar.
 assert [G(e,d,11-b,b)!=0 for e,d in [(1,1),(-1,1),(1,-1),(-1,-1)]]==[False,True,False,False]
assert triples==claimed['triples_u_d_exponent']
labels=[(b,j) for b in range(1,6) for j in range(len(moments[str(b)])-5)]
E=[moments[str(b)][j:j+6] for b,j in labels]
assert [[coeff(x) for x in row] for row in E]==claimed['E_rows']
D=det(E);assert coeff(D)==claimed['determinant']
factors=[(19,1),(8,1),(1,4,16,7,3,6,3,1),(11,2,6,11,13,6,20,11,12,18,9,19,9,22,12,16,18,3,1)]
H=O
for f in factors:H=mul(H,f)
assert D==scale(H,15);assert gcd(D,derivative(D))==O;assert evaluate(H,0)!=0
irredcert=[{'factor':coeff(f),'certificate':irred(f)} for f in factors]
A=[row[:5] for row in E]
minors=[det([row for i,row in enumerate(A) if i!=omit]) for omit in range(6)]
assert [coeff(v) for v in minors]==claimed['A_maximal_minors_by_omitted_row']
g,s,t=xgcd(minors[0],minors[1]);assert g==O
assert add(mul(s,minors[0]),mul(t,minors[1]))==O
rankbezout={'M0':coeff(s),'M1':coeff(t),'gcd':coeff(g)}
assert gcd(minors[0],D)==O
nums=[]
for j in range(5):
 M=[row[:5] for row in E[1:]]
 for i in range(5):M[i][j]=neg(E[i+1][5])
 nums.append(det(M))
assert [coeff(v) for v in nums]==claimed['cramer_formula']['numerators_ascending_t']
assert coeff(minors[0])==claimed['cramer_formula']['denominator']
residuals=[]
for row in E:
 r=mul(row[5],minors[0])
 for j in range(5):r=add(r,mul(row[j],nums[j]))
 assert mod(r,D)==Z;residuals.append(r)
assert gcd(nums[0],D)==O
print('PASS symbolic determinant, minors, all-extension rank, Cramer, irreducibility, constant-term gate',flush=True)
# Quotient-field arithmetic; elements are trimmed coefficient tuples.
class Field:
 def __init__(self,m):self.m=m
 def elt(self,v):return mod(trim(v if isinstance(v,(tuple,list)) else [v]),self.m)
 def add(self,a,b):return add(a,b)
 def neg(self,a):return neg(a)
 def sub(self,a,b):return sub(a,b)
 def mul(self,a,b):return mod(mul(a,b),self.m)
 def inv(self,a):
  g,s,t=xgcd(a,self.m);assert g==O;return mod(s,self.m)
 def power(self,a,n):return powmod(a,n,self.m)
 def total(self,vs):
  o=Z
  for v in vs:o=add(o,v)
  return o

def pt(a):
 a=list(a)
 while a and not a[-1]:a.pop()
 return a
def padd(a,b,K):return pt([K.add(a[i] if i<len(a) else Z,b[i] if i<len(b) else Z) for i in range(max(len(a),len(b)))])
def pscale(a,c,K):return pt([K.mul(x,c) for x in a])
def psub(a,b,K):return padd(a,pscale(b,(22,),K),K)
def pmul(a,b,K):
 if not a or not b:return []
 out=[Z]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]=K.add(out[i+j],K.mul(x,y))
 return pt(out)
def pdiv(a,b,K):
 a=a[:];out=[Z]*max(0,len(a)-len(b)+1);iv=K.inv(b[-1])
 while len(a)>=len(b):
  k=len(a)-len(b);v=K.mul(a[-1],iv);out[k]=v
  for j,w in enumerate(b):a[k+j]=K.sub(a[k+j],K.mul(v,w))
  a=pt(a)
 return pt(out),a
def pgcd(a,b,K):
 s,t=[O],[];u,v=[],[O]
 while b:
  q,r=pdiv(a,b,K);a,b=b,r;s,u=u,psub(s,pmul(q,u,K),K);t,v=v,psub(t,pmul(q,v,K),K)
 iv=K.inv(a[-1]);return pscale(a,iv,K),pscale(s,iv,K),pscale(t,iv,K)
quotients=[]
for f in factors:
 K=Field(f);h=[K.mul(K.elt(n),K.inv(K.elt(minors[0]))) for n in nums]+[O]
 hp=[K.mul(h[k],K.elt(k)) for k in range(1,len(h))]
 g,s,t=pgcd(h,hp,K);assert g==[O];assert h[0]
 assert padd(pmul(s,h,K),pmul(t,hp,K),K)==[O]
 for row in E:assert not K.total(K.mul(K.elt(v),w) for v,w in zip(row,h))
 rc=next(c for c in rootcert['factor_quotient_checks'] if trim(c['parameter_factor'])==f)
 assert [coeff(z) for z in h]==rc['quintic_coefficients_in_quotient_field']
 quotients.append({'factor':coeff(f),'h':[coeff(z) for z in h],'gcd':[coeff(z) for z in g],'bezout_h':[coeff(z) for z in s],'bezout_derivative':[coeff(z) for z in t]})
print('PASS all four parameter-orbit quotient fields: separable quintics, recurrences, nonzero constants',flush=True)
# Gaussian reduction retains candidate convention: pivot only the coefficient columns.
def rref(M,K,coefficient_columns):
 R=[[K.elt(x) if isinstance(x,int) else x for x in row] for row in M];piv=[];i=0
 for j in range(coefficient_columns):
  k=next((k for k in range(i,len(R)) if R[k][j]),None)
  if k is None:continue
  R[i],R[k]=R[k],R[i];iv=K.inv(R[i][j]);R[i]=[K.mul(x,iv) for x in R[i]]
  for k in range(len(R)):
   if k!=i and R[k][j]:
    v=R[k][j];R[k]=[K.sub(x,K.mul(v,y)) for x,y in zip(R[k],R[i])]
  piv.append(j);i+=1
  if i==len(R):break
 bad=any(not any(row[:coefficient_columns]) and any(row[coefficient_columns:]) for row in R)
 return R,piv,bad
K0=Field((0,1));census=[]
historical=[load(source_names[4]),load(source_names[5])]
for y in range(23):
 EE=[[evaluate(v,y) for v in row] for row in E]
 aug=[row[:5]+[-row[5]%P] for row in EE]
 rr,piv,bad=rref(aug,K0,5);rr=[[x[0] if x else 0 for x in row] for row in rr]
 assert len(piv)==5
 h=None if bad else [rr[k][5] for k in range(5)]+[1]
 roots=[] if h is None else [x for x in range(23) if evaluate(h,x)==0]
 old=next(x for x in claimed['census'] if x['y']==y)
 assert old['rank']==5 and old['consistent']==(not bad) and old['rref']==rr
 if h is not None:assert old['quintic']==h and old['all_F23_roots']==roots
 if y:
  for history in historical:
   old=next(x for x in history if x['y']==y);deg=old['degrees']['5']
   assert deg['matrix']==EE
   assert deg.get('rank',deg.get('rank_coefficient'))==5
   assert deg.get('rref',deg.get('rref_augmented'))==rr
   assert old['moments']=={b:[evaluate(v,y) for v in vv] for b,vv in moments.items()}
   expect=[] if bad else [{'coefficients':h,'roots':roots}]
   assert deg['polynomials']==expect
 census.append({'y':y,'rank':5,'augmented_rank':6 if bad else 5,'consistent':not bad,'quintic':h,'roots':roots,'rref':rr})
h4=trim(next(c for c in census if c['y']==4)['quintic']);h15=trim(next(c for c in census if c['y']==15)['quintic']);cub=(13,13,13,1)
assert h15==mul(mul((20,1),(2,1)),cub)
base_irred=[irred(h4),irred(cub)]
# Direct field-size certificates, in addition to degree-divisibility reasoning.
cubic_parameter_gcd=gcd(H,sub(powmod(Y,23**3,H),Y))
assert cubic_parameter_gcd==mul((19,1),(8,1))
assert gcd(h4,sub(powmod(Y,23**3,h4),Y))==O
assert powmod(Y,23**3,h15)==mod(Y,h15)
assert [c['y'] for c in census if c['consistent']]==[4,15]
print('PASS all 22 nonzero specializations against both historical censuses; h4 and cubic irreducible',flush=True)
# Full cubic-field coefficient systems built independently.
K=Field(cub);u=Y
X=[(3,),(21,),u,K.power(u,23),K.power(u,23**2)]
assert len(set(X))==5 and all(X)
assert K.power(u,23**3)==u
assert all(not K.total(K.mul(K.elt(c),K.power(x,i)) for i,c in enumerate(h15)) for x in X)
prod=[O]
for x in X:prod=pmul(prod,[K.neg(x),O],K)
assert prod==[K.elt(c) for c in h15]
fail=load(source_names[7]);summary=load(source_names[6]);branches=load(source_names[8])
assert [list(x)+[0]*(3-len(x)) for x in X]==summary['same_sign_support']
banks=[(1,1,x) for x in X]+[(-1,1,(15,)),(1,-1,(15,))]+[(-1,-1,x) for x in X]
lam=[0,1,12,18,8,12,2,12,1,0,0];assert [trim(v) for v in fail['obstruction']['lambda']]==[K.elt(v) for v in lam]
def col(e,d,x,a,b):return K.mul(K.power(x,e*a%N),K.elt(G(e,d,a,b)))
system_out=[]
for b in range(N):
 MM=[[col(e,d,x,a,b) for e,d,x in banks] for a in range(N)]
 target=[K.elt(pow(Q,3*(a+b)**2%N,P)) for a in range(N)]
 R,piv,bad=rref([row+[rhs] for row,rhs in zip(MM,target)],K,len(banks))
 old=fail['systems'][b]
 assert [[trim(v) for v in row] for row in old['matrix']]==MM
 assert old['consistent']==(not bad)
 assert len(piv)==summary['sector_ranks'][b]
 if b==3:
  zero=[K.total(K.mul(K.elt(lam[a]),MM[a][i]) for a in range(N)) for i in range(len(banks))]
  assert zero==[Z]*len(banks)
  assert K.total(K.mul(K.elt(lam[a]),target[a]) for a in range(N))==(11,)
 system_out.append({'b':b,'rank':len(piv),'augmented_rank':len(piv)+int(bad),'consistent':not bad})
assert [v['b'] for v in system_out if not v['consistent']]==[3,8]
print('PASS reconstructed all 11 full sectors; b3,b8 inconsistent, exact lambda certificate',flush=True)
# Symbolic contractions certify arbitrary legal beta and arbitrary -- support/count.
contractions=[]
for e,d in [(1,1),(-1,1),(1,-1),(-1,-1)]:
 a=[0]*11
 for row,w in enumerate(lam):a[e*row%N]=(a[e*row%N]+w*G(e,d,row,3))%P
 contractions.append(trim(a))
assert contractions[0]==mul(h15,(0,9,21))
assert mod(contractions[0],h15)==Z
assert evaluate(contractions[1],15)==0
assert contractions[2]==(0,2,6)
assert contractions[3]==Z
assert evaluate(contractions[2],15)==0
assert evaluate(contractions[2],1)==8
# Literal inverse checks use the sparse original branch, not the sector formula.
def decode(M):return [[trim(v) for v in row] for row in M]
def inverse(M):
 MM=[row+[O if i==j else Z for j in range(N)] for i,row in enumerate(M)]
 R,piv,bad=rref(MM,K,N);assert len(piv)==N and not bad
 return [row[N:] for row in R]
def mmul(A,B):return [[K.total(K.mul(A[i][k],B[k][j]) for k in range(N)) for j in range(N)] for i in range(N)]
I=[[O if i==j else Z for j in range(N)] for i in range(N)]
def functional(M):
 return K.mul(K.elt(pow(N,-1,P)),K.total(K.mul(K.elt(lam[a]*pow(Q,-3*t%N,P)%P),M[(t+a)%N][t]) for a in range(N) for t in range(N)))
assert functional([[K.elt(v) for v in row] for row in F])==(14,)
assert decode(fail['target'])==[[K.elt(v) for v in row] for row in F]
for rec in branches:
 e,d,x=banks[rec['bank_index']];j=rec['phase'];beta=O
 Delta=K.sub(K.sub(O,K.power(x,11)),K.power(beta,11));assert Delta
 assert trim(rec['Delta'])==Delta
 M=[row[:] for row in I]
 for t in range(N):
  M[(t+e)%N][t]=K.sub(M[(t+e)%N][t],x)
  M[t][t]=K.sub(M[t][t],K.elt(pow(Q,(e*d*j+d*t)%N,P)))
 assert M==decode(rec['matrix'])
 inv=inverse(M);assert inv==decode(rec['inverse'])
 assert mmul(M,inv)==I and mmul(inv,M)==I
 assert functional(inv)==Z and trim(rec['functional_value'])==Z
assert len(branches)==132
print('PASS all 132 freshly inverted literal branches, 264 inverse products, LF=14',flush=True)
result={'status':'INDEPENDENT_ACCEPT_BOUNDED','field_characteristic':P,'target':'F[k,t]=13^(-kt), N=11','source_code_policy':'Only this fresh standard-library verifier executed; candidate and historical code neither imported nor executed.','determinant':coeff(D),'H':coeff(H),'factor_certificates':irredcert,'rank5_bezout':rankbezout,'minors':[coeff(v) for v in minors],'Cramer_numerators':[coeff(v) for v in nums],'Cramer_residuals':[coeff(v) for v in residuals],'quotient_field_certificates':quotients,'base_specializations':census,'base_quintic_and_cubic_irreducibility':base_irred,'all_22_base_specializations_match_both_sources':True,'cubic_parameter_gcd':coeff(cubic_parameter_gcd),'h4_has_no_cubic_field_root':True,'h15_splits_in_cubic_field':True,'cubic_systems':system_out,'lambda':lam,'normalized_target_contraction':11,'literal_target_contraction':14,'orientation_contractions_ascending':list(map(coeff,contractions)),'literal_inverses_reconstructed':132,'literal_left_right_checks':264,'literal_branch_functional_zero_checks':132,'forced_12_bank_classification':'All 12-bank representations in the exactly-one-effective-cross-node-each architecture over F23^3 are excluded; arbitrary legal beta, repeated banks, cancellation, and zero-alpha same-sign nodes are covered.','stronger_bounded_obstruction':'With y=z=15 and ++ support contained in the five roots of h15, the b3 certificate excludes a representation regardless of -- support or bank count. Reflection gives the analogous -- statement.','not_claimed':['Unrestricted architecture exclusion','Exclusion of all 13-bank singleton circuits','Minimum 13 or 14 over F23^3','Exclusion over every extension','Novelty']}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(OUT/'SOURCE_HASHES.json').write_text(json.dumps(sources,indent=2,sort_keys=True)+'\n')
(OUT/'TIMING.json').write_text(json.dumps({'elapsed_seconds':time.monotonic()-started},indent=2)+'\n')
print('INDEPENDENT_ACCEPT_BOUNDED',flush=True)
