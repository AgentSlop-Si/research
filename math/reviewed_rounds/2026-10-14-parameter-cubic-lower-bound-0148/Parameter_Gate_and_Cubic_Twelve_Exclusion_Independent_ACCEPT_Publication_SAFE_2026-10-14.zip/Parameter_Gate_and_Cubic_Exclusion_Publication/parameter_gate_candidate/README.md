# One-parameter annihilator gate

Start with REPORT.md. The new symbolic theorem has not yet received independent review.

- The degree-27 determinant factors into degrees 1,1,7,18.
- Rank is five at every extension-field parameter; no hidden exceptional rank case.
- Every compatible quintic is unique, separable, and has nonzero constant term.
- All 22 nonzero F23 specializations match both accepted source censuses.
- y=15 passes the five-node forced-window gate over F_(23^3), and y=4 over F_(23^5).
- No full-bank extension-field attainment is asserted.

Fresh code and exact certificates are local. Run commands and source dependencies appear in REPORT.md. Historical code was not executed, and there were no external writes. Model-token usage is unknown.
