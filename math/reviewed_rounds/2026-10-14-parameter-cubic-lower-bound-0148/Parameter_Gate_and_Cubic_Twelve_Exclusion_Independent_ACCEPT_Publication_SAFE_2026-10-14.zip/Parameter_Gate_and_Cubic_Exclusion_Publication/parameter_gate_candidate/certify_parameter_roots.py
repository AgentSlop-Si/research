#!/usr/bin/env python3
"""Fresh quotient-field certificates, bounded to four parameter factors."""
from pathlib import Path
import sys,json,itertools,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from fresh_parameter_gate import P,norm,add,sub,mul,scale,divmodp,gcd,xgcd,ev,derivative

def mod(a,f): return divmodp(a,f)[1]
def powmodp(a,n,f):
 z=[1]
 while n:
  if n&1: z=mod(mul(z,a),f)
  a=mod(mul(a,a),f); n//=2
 return z

def irreducibility_certificate(f):
 d=len(f)-1; primes=[]; n=d
 for p in range(2,d+1):
  if n%p==0:
   primes.append(p)
   while n%p==0: n//=p
 frob=[[0,1]]
 for j in range(1,d+1): frob.append(powmodp(frob[-1],P,f))
 checks=[]
 for ell in primes:
  exponent=d//ell; g,s,t=xgcd(f,sub(frob[exponent],[0,1])); assert g==[1]
  checks.append({'prime_divisor_degree':ell,'frobenius_index':exponent,'gcd':g,'bezout_f':s,'bezout_frobenius_minus_y':t})
 final=mod(sub(frob[d],[0,1]),f); assert final==[0]
 return {'degree':d,'frobenius_y_23_power_iterates':frob,'checks':checks,'final_y_23d_minus_y_remainder':final,'irreducible':True}

class Field:
 def __init__(self,f): self.f=f
 def red(self,a): return mod(a,self.f)
 def a(self,a,b): return self.red(add(a,b))
 def s(self,a,b): return self.red(sub(a,b))
 def m(self,a,b): return self.red(mul(a,b))
 def inv(self,a):
  g,s,t=xgcd(a,self.f); assert g==[1]; return self.red(s)
 def tp(self,a):
  a=[self.red(x) for x in a]
  while len(a)>1 and a[-1]==[0]: a.pop()
  return a or [[0]]
 def ta(self,a,b): return self.tp([self.a(a[i] if i<len(a) else [0],b[i] if i<len(b) else [0]) for i in range(max(len(a),len(b)))])
 def ts(self,a,b): return self.ta(a,[scale(x,-1) for x in b])
 def tm(self,a,b):
  z=[[0] for _ in range(len(a)+len(b)-1)]
  for i,x in enumerate(a):
   for j,y in enumerate(b): z[i+j]=self.a(z[i+j],self.m(x,y))
  return self.tp(z)
 def tscale(self,a,c): return self.tp([self.m(x,c) for x in a])
 def td(self,a,b):
  a=self.tp(a[:]); b=self.tp(b[:]); assert b!=[[0]]
  q=[[0] for _ in range(max(1,len(a)-len(b)+1))]; inv=self.inv(b[-1])
  while a!=[[0]] and len(a)>=len(b):
   k=len(a)-len(b); c=self.m(a[-1],inv); q[k]=c
   for j,x in enumerate(b): a[k+j]=self.s(a[k+j],self.m(c,x))
   a=self.tp(a)
  return self.tp(q),a
 def txgcd(self,a,b):
  oa,ob=a,b; s0,s1=[[1]],[[0]]; t0,t1=[[0]],[[1]]; chain=[]
  while b!=[[0]]:
   q,r=self.td(a,b); chain.append({'quotient':q,'remainder':r}); a,b=b,r
   s0,s1=s1,self.ts(s0,self.tm(q,s1)); t0,t1=t1,self.ts(t0,self.tm(q,t1))
  inv=self.inv(a[-1]); a=self.tscale(a,inv); s0=self.tscale(s0,inv); t0=self.tscale(t0,inv)
  assert self.ta(self.tm(oa,s0),self.tm(ob,t0))==a
  return a,s0,t0,chain

def main():
 out=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent/'outputs'); start=time.time(); data=json.loads((out/'RESULTS.json').read_text()); H=data['determinant']; cf=data['cramer_formula']; den=cf['denominator']; nums=cf['numerators_ascending_t']
 checks=[]
 for fac in data['determinant_factorization']['factors']:
  f=fac['coefficients_ascending']; irr=irreducibility_certificate(f); K=Field(f); inv=K.inv(den)
  hh=[K.m(a,inv) for a in nums]+[[1]]
  assert hh[0]!=[0]
  for r in data['E_rows']:
   v=[0]
   for a,b in zip(r,hh): v=K.a(v,K.m(a,b))
   assert v==[0]
  dh=K.tp([scale(hh[i],i) for i in range(1,6)]); g,s,t,chain=K.txgcd(hh,dh); assert g==[[1]]
  checks.append({'parameter_factor':f,'irreducibility_certificate':irr,'quintic_coefficients_in_quotient_field':hh,'constant_nonzero':True,'quintic_derivative':dh,'gcd_quintic_derivative':g,'bezout_quintic':s,'bezout_derivative':t,'euclidean_chain':chain,'all_six_recurrences_verified':True})
 g,s,t=xgcd(H,nums[0]); assert g==[1]
 cg={'gcd':g,'bezout_determinant':s,'bezout_constant_numerator':t}
 global_bezout=[]
 for label,a,b in [('first_two_coefficient_minors',data['A_maximal_minors_by_omitted_row'][0],data['A_maximal_minors_by_omitted_row'][1]),('selected_minor_and_determinant',den,H)]:
  gg,aa,bb=xgcd(a,b); assert gg==[1]; global_bezout.append({'label':label,'gcd':gg,'bezout_first':aa,'bezout_second':bb})
 # Compare all base-field matrices, five moment windows, ranks and polynomials
 # directly to both historical JSON sources, treated as inert data only.
 comparisons=[]
 for name,rkey in [('free_singleton_candidate/outputs/MOMENT_CENSUS.json','rank_coefficient'),('free_singleton_review/INDEPENDENT_MOMENT_CENSUS.json','rank')]:
  old=json.loads(Path(name).read_text()); by_y={r['y']:r for r in old}; assert set(by_y)==set(range(1,23))
  for c in data['census'][1:]:
   o=by_y[c['y']]; d=o['degrees']['5']; assert c['moments']==o['moments']; assert c['rank']==d[rkey]
   matrix=[[ev(a,c['y']) for a in r] for r in data['E_rows']] # Sources retain positive final moment, not the negated RHS
   assert matrix==d['matrix']; assert c['rref']==d.get('rref_augmented',d.get('rref'))
   polys=d['polynomials']; assert len(polys)==int(c['consistent'])
   if polys:
    assert polys[0]['coefficients']==c['quintic']; assert polys[0]['roots']==[x for x in c['all_F23_roots'] if x]
  comparisons.append({'source':name,'all_22_moments_matrices_ranks_solutions_roots_match':True})
 base_irreducible=[]
 for c in data['census']:
  if c['quintic_factorization']:
   for f in c['quintic_factorization']['factors']:
    base_irreducible.append({'y':c['y'],'factor':f['coefficients_ascending'],'certificate':irreducibility_certificate(f['coefficients_ascending'])})
 result={'global_rank_and_cramer_bezout_certificates':global_bezout,'factor_quotient_checks':checks,'constant_coefficient_nonvanishing_global_certificate':cg,'all_27_parameter_roots_have_unique_nonzero_constant_separable_quintic':True,'basefield_comparisons':comparisons,'base_quintic_factor_irreducibility_certificates':base_irreducible,'y_zero_determinant':ev(H,0),'no_extensions_enumerated':True,'support_splitting_degrees_for_degree7_and_degree18_parameter_factors':'not computed'}
 (out/'ROOT_CERTIFICATES.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'quotient_factor_degrees':[len(c['parameter_factor'])-1 for c in checks],'all_constants_nonzero':True,'all_quintics_separable':True,'all_basefield_matches':True,'elapsed_seconds':time.time()-start},indent=2))
if __name__=='__main__':main()
