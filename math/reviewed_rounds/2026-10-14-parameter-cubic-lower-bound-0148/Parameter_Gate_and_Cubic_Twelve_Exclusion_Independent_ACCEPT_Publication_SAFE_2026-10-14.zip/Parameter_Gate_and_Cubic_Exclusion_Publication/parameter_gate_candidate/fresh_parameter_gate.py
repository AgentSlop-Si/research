#!/usr/bin/env python3
"""Fresh exact one-parameter finite-field gate; never imports historical code.
Polynomial arithmetic/determinants below are newly authored. SymPy is used only
for finite-field factorization; products and relevant gcds are independently checked.
"""
from pathlib import Path
import json, hashlib, time, itertools, argparse
P=23; N=11; Q=13

def norm(a):
 a=[int(x)%P for x in a]
 while len(a)>1 and not a[-1]: a.pop()
 return a or [0]
def add(a,b): return norm([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def neg(a): return norm([-v for v in a])
def sub(a,b): return add(a,neg(b))
def mul(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b): c[i+j]=(c[i+j]+x*y)%P
 return norm(c)
def scale(a,c): return norm([c*x for x in a])
def divmodp(a,b):
 a=norm(a[:]); b=norm(b[:]); assert b!=[0]
 q=[0]*max(1,len(a)-len(b)+1); bi=pow(b[-1],-1,P)
 while a!=[0] and len(a)>=len(b):
  d=len(a)-len(b); c=a[-1]*bi%P; q[d]=c
  for j,x in enumerate(b): a[d+j]=(a[d+j]-c*x)%P
  a=norm(a)
 return norm(q),a
def gcd(a,b):
 while b!=[0]: a,b=b,divmodp(a,b)[1]
 return scale(a,pow(a[-1],-1,P)) if a!=[0] else a
def xgcd(a,b):
 oa,ob=a,b; s0,s1=[1],[0]; t0,t1=[0],[1]
 while b!=[0]:
  q,r=divmodp(a,b); a,b=b,r; s0,s1=s1,sub(s0,mul(q,s1)); t0,t1=t1,sub(t0,mul(q,t1))
 if a==[0]: return a,s0,t0
 inv=pow(a[-1],-1,P); a,s0,t0=scale(a,inv),scale(s0,inv),scale(t0,inv)
 assert add(mul(s0,oa),mul(t0,ob))==a
 return a,s0,t0
def bezout_many(ps):
 g=[0]; coeff=[]
 for a in ps:
  g,s,t=xgcd(g,a); coeff=[mul(c,s) for c in coeff]+[t]
 check=[0]
 for a,c in zip(ps,coeff): check=add(check,mul(a,c))
 assert check==g
 return g,coeff
def ev(a,x):
 v=0
 for c in reversed(a): v=(v*x+c)%P
 return v
def derivative(a): return norm([i*a[i]%P for i in range(1,len(a))])
def det(a):
 n=len(a); total=[0]
 assert all(len(r)==n for r in a)
 for perm in itertools.permutations(range(n)):
  sign=(-1)**sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n))
  term=[sign]
  for i,j in enumerate(perm): term=mul(term,a[i][j])
  total=add(total,term)
 return total

def fac(a,var='y'):
 import sympy as sp
 x=sp.Symbol(var)
 unit,factors=sp.factor_list(sum(int(c)*x**i for i,c in enumerate(a)), modulus=P)
 fs=[]; product=[int(unit)%P]
 for expr,k in factors:
  pp=sp.Poly(expr,x,modulus=P)
  cs=norm([int(pp.nth(i))%P for i in range(pp.degree()+1)])
  fs.append({'coefficients_ascending':cs,'multiplicity':k,'degree':len(cs)-1})
  for _ in range(k): product=mul(product,cs)
 assert product==a
 return {'unit':int(unit)%P,'factors':fs}
def rref(rows,nvar):
 rows=[[v%P for v in r] for r in rows]; piv=[]; i=0
 for j in range(nvar):
  k=next((k for k in range(i,len(rows)) if rows[k][j]),None)
  if k is None: continue
  rows[i],rows[k]=rows[k],rows[i]; z=pow(rows[i][j],-1,P); rows[i]=[v*z%P for v in rows[i]]
  for k in range(len(rows)):
   if k!=i:
    z=rows[k][j]; rows[k]=[(a-z*b)%P for a,b in zip(rows[k],rows[i])]
  piv.append(j); i+=1
 inconsistent=any(not any(r[:nvar]) and r[nvar] for r in rows)
 return {'rank':len(piv),'augmented_rank':len(piv)+int(inconsistent),'consistent':not inconsistent,'pivots':piv,'rref':rows,'unique_solution':[rows[piv.index(j)][-1] for j in range(nvar)] if len(piv)==nvar and not inconsistent else None}

def derive():
 assert pow(Q,N,P)==1 and Q!=1
 F=[[pow(Q,-k*t,P) for t in range(N)] for k in range(N)]
 invN=pow(N,-1,P)
 C={}
 for a in range(N):
  for b in range(N): C[a,b]=sum(F[(t+a)%N][t]*pow(Q,-b*t,P) for t in range(N))*invN%P
 assert C[0,0]==18
 fn={k:v*pow(18,-1,P)%P for k,v in C.items()}
 assert all(v==pow(Q,3*(a+b)**2,P) for (a,b),v in fn.items())
 # Direct expansion of noncommutative words, independently summed by inversion count.
 D={}
 for eps,delta in itertools.product((1,-1),repeat=2):
  om=pow(Q,eps*delta,P)
  for length in range(N+1):
   vals={}
   for word in itertools.product((0,1),repeat=length):
    r=word.count(0); ell=length-r
    inversions=sum(word[i]==1 and word[j]==0 for i in range(length) for j in range(i+1,length))
    vals[r,ell]=(vals.get((r,ell),0)+pow(om,inversions,P))%P
   for (r,ell),v in vals.items():
    if length<N: D[eps,delta,r,ell]=v
    else: assert v==int(r in (0,N))
 def G(e,d,a,b):
  r=(e*a)%N; ell=(d*b)%N
  return D[e,d,r,ell] if r+ell<N else 0
 moments={}; triples={}
 for b in range(1,6):
  g=G(-1,1,N-b,b); assert g
  assert all(G(e,d,N-b,b)==0 for e,d in [(1,1),(1,-1),(-1,-1)])
  moments[b]=[]; triples[b]=[]
  for a in range(b,N-b):
   den=G(1,1,a,b); assert den and not G(1,-1,a,b) and not G(-1,-1,a,b)
   u=fn[a,b]*pow(den,-1,P)%P
   d=G(-1,1,a,b)*pow(g*den%P,-1,P)%P
   ex=N-a-b; z=[u]+[0]*ex; z[ex]-=d; z=norm(z)
   moments[b].append(z); triples[b].append([u,d,ex])
 return moments,triples

def system(moments,m):
 rows=[]; labels=[]
 for b,ss in moments.items():
  for j in range(len(ss)-m): rows.append(ss[j:j+m+1]); labels.append([b,j])
 return rows,labels

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--out',default='outputs'); args=ap.parse_args(); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
 start=time.time(); moments,triples=derive(); E,labels=system(moments,5); A=[r[:5] for r in E]
 determinant=det(E); minors=[det(A[:i]+A[i+1:]) for i in range(6)]
 gg,bezout=bezout_many(minors); factorization=fac(determinant)
 # Select a nonsingular row subset over every determinant root, if one exists.
 selected=next((i for i,m in enumerate(minors) if gcd(m,determinant)==[1]),None)
 cramer=None
 if selected is not None:
  rows=[r for i,r in enumerate(E) if i!=selected]; M=[r[:5] for r in rows]; rhs=[neg(r[5]) for r in rows]
  nums=[]
  for j in range(5): nums.append(det([[rhs[i] if k==j else M[i][k] for k in range(5)] for i in range(5)]))
  den=minors[selected]
  residuals=[]
  for r in E:
   v=mul(den,r[5])
   for a,num in zip(r[:5],nums): v=add(v,mul(a,num))
   residuals.append(v)
  assert all(divmodp(v,determinant)[1]==[0] for v in residuals)
  cramer={'omitted_row_zero_based':selected,'denominator':den,'numerators_ascending_t':nums,'residuals':residuals,'gcd_denominator_determinant':gcd(den,determinant)}
 census=[]
 for y in range(P):
  ss={b:[ev(a,y) for a in v] for b,v in moments.items()}
  rows=[[ev(v,y) for v in r[:5]]+[-ev(r[5],y)%P] for r in E]
  rr=rref(rows,5); sol=rr['unique_solution']; roots=[]; tfac=None
  if sol is not None:
   hh=sol+[1]; roots=[x for x in range(P) if ev(hh,x)==0]; tfac=fac(hh,'t')
  low=[]
  for m in range(1,5):
   e,_=system(moments,m); low.append({'degree':m,**rref([[ev(a,y) for a in row[:m]]+[-ev(row[m],y)%P] for row in e],m)})
  census.append({'y':y,'determinant_value':ev(determinant,y),**rr,'quintic':None if sol is None else sol+[1],'all_F23_roots':roots,'quintic_factorization':tfac,'lower_degree_systems':low,'moments':ss})
 sources=['free_singleton_candidate/CONTRACT.md','free_singleton_candidate/REPORT.md','free_singleton_candidate/outputs/MOMENT_CENSUS.json','free_singleton_review/REVIEW.md','free_singleton_review/INDEPENDENT_MOMENT_CENSUS.json','free_singleton_review/RESULTS.json']
 sourcehashes=[{'path':str(p),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'bytes':Path(p).stat().st_size} for p in sources]
 result={'field_characteristic':P,'N':N,'q':Q,'triples_u_d_exponent':triples,'moments_polynomial_coefficients_ascending_y':moments,'row_labels_b_j':labels,'E_rows':E,'A_maximal_minors_by_omitted_row':minors,'gcd_maximal_minors':gg,'bezout_coefficients_for_minors':bezout,'determinant':determinant,'determinant_factorization':factorization,'determinant_derivative_gcd':gcd(determinant,derivative(determinant)),'cramer_formula':cramer,'census':census}
 for name,data in [('RESULTS.json',result),('SOURCE_HASHES.json',sourcehashes)]: (out/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
 (out/'TIMING.json').write_text(json.dumps({'elapsed_seconds':time.time()-start,'start_unix':start,'end_unix':time.time(),'model_token_usage':'unknown'},indent=2)+'\n')
 print(json.dumps({'determinant_degree':len(determinant)-1,'determinant':determinant,'factorization':factorization,'gcd_minors':gg,'selected_minor':selected,'basefield_survivors':[{'y':c['y'],'quintic':c['quintic'],'roots':c['all_F23_roots'],'factorization':c['quintic_factorization']} for c in census if c['consistent']]},indent=2))
if __name__=='__main__': main()
