#!/usr/bin/env python3
"""New, self-contained exact cubicfield construction; no research-code imports."""
from pathlib import Path
import argparse, datetime, functools, hashlib, itertools, json, time
P=23; N=11; Q=13
Z=(0,0,0); O=(1,0,0); U=(0,1,0)
def C(a): return (a%P,0,0)
def add(a,b): return tuple((x+y)%P for x,y in zip(a,b))
def neg(a): return tuple(-x%P for x in a)
def sub(a,b): return tuple((x-y)%P for x,y in zip(a,b))
def mul(a,b):
 a0,a1,a2=a; b0,b1,b2=b
 v3=a1*b2+a2*b1; v4=a2*b2
 return ((a0*b0+10*v3+8*v4)%P,(a0*b1+a1*b0+10*v3+18*v4)%P,(a0*b2+a1*b1+a2*b0+10*v3+18*v4)%P)
def scale(a,b): return tuple(x*b%P for x in a)
def power(a,n):
 if n<0: return power(inv(a),-n)
 out=O
 while n:
  if n&1: out=mul(out,a)
  a=mul(a,a);n//=2
 return out
@functools.lru_cache(None)
def inv(a):
 if a==Z: raise ZeroDivisionError('Zero in cubic field')
 b=power(a,P**3-2)
 assert mul(a,b)==O
 return b
def summ(vs):
 out=Z
 for v in vs: out=add(out,v)
 return out
def ev(coeff,a):
 out=Z
 for x in reversed(coeff): out=add(mul(out,a),C(x))
 return out

def eliminate(A,rhs):
 n=len(A[0]); m=len(A); R=[list(row)+[rhs[i]] for i,row in enumerate(A)]; piv=[]; r=0
 for c in range(n):
  k=next((k for k in range(r,m) if R[k][c]!=Z),None)
  if k is None: continue
  R[r],R[k]=R[k],R[r]; z=inv(R[r][c]); R[r]=[mul(x,z) for x in R[r]]
  for k in range(m):
   if k!=r and R[k][c]!=Z:
    z=R[k][c]; R[k]=[sub(x,mul(z,y)) for x,y in zip(R[k],R[r])]
  piv.append(c);r+=1
  if r==m: break
 inconsistent=any(all(x==Z for x in row[:n]) and row[n]!=Z for row in R)
 if inconsistent: return None,piv,R
 sol=[Z]*n
 for k,c in enumerate(piv): sol[c]=R[k][n]
 assert all(summ(mul(x,y) for x,y in zip(row,sol))==v for row,v in zip(A,rhs))
 return sol,piv,R

def matrix_inverse(A):
 n=len(A); R=[row[:]+[O if i==j else Z for j in range(n)] for i,row in enumerate(A)]
 for j in range(n):
  k=next((k for k in range(j,n) if R[k][j]!=Z),None)
  if k is None: raise ValueError('Singular literal branch')
  R[j],R[k]=R[k],R[j]; z=inv(R[j][j]); R[j]=[mul(x,z) for x in R[j]]
  for k in range(n):
   if k!=j and R[k][j]!=Z:
    z=R[k][j]; R[k]=[sub(x,mul(z,y)) for x,y in zip(R[k],R[j])]
 return [r[n:] for r in R]
def mm(A,B):
 return [[summ(mul(x,y) for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def matrix_add(A,B): return [[add(x,y) for x,y in zip(a,b)] for a,b in zip(A,B)]
def matrix_scale(A,x): return [[mul(x,y) for y in row] for row in A]
def zero_matrix(): return [[Z]*N for _ in range(N)]
def branch(e,d,alpha,j):
 A=[[O if r==t else Z for t in range(N)] for r in range(N)]
 for t in range(N):
  A[(t+e)%N][t]=sub(A[(t+e)%N][t],alpha)
  A[t][t]=sub(A[t][t],C(pow(Q,(e*d*j+d*t)%N,P)))
 return A

def dump(out,name,data): (out/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

def failure_gate(out,params,systems,F,gamma,cubic,support,start,utc,G):
 bad=next(s for s in systems if not s['consistent']); b=bad['sector_b']; A=bad['matrix']; rhs=bad['rhs']
 # Nullspace of transpose gives a stand-alone inconsistency certificate.
 zero_sol,piv,R=eliminate(list(map(list,zip(*A))),[Z]*len(A[0])); assert zero_sol is not None
 certs=[]
 for c in range(N):
  if c in piv: continue
  v=[Z]*N;v[c]=O
  for i,j in enumerate(piv): v[j]=neg(R[i][c])
  pairing=summ(mul(x,y) for x,y in zip(v,rhs))
  assert all(summ(mul(v[a],A[a][k]) for a in range(N))==Z for k in range(len(params)))
  if pairing!=Z: certs.append((v,pairing))
 assert certs
 lam,pairing=certs[0]
 print('Failure sector',b,'rank',len(bad['pivots']),'null vector',lam,'pairing',pairing,flush=True)
 def functional(M,lv=lam):
  return summ(mul(lv[a],scale(summ(scale(M[(t+a)%N][t],pow(Q,(-b*t)%N,P)) for t in range(N)),pow(N,-1,P))) for a in range(N))
 target_functional=functional(F); assert target_functional==mul(gamma,pairing) and target_functional!=Z
 # Fresh literal branch inversions independently establish an obstruction on all raw columns.
 I=[[O if i==j else Z for j in range(N)] for i in range(N)]; branches=[]; columns=[]
 for k,(e,d,alpha) in enumerate(params):
  delta=neg(power(alpha,N)); assert delta!=Z
  for j in range(N):
   matrix=branch(e,d,alpha,j); inverse=matrix_inverse(matrix)
   assert mm(matrix,inverse)==I and mm(inverse,matrix)==I
   got=functional(inverse); assert got==Z
   branches.append({'bank_index':k,'epsilon':e,'delta':d,'alpha':alpha,'beta':O,'Delta':delta,'phase':j,'matrix':matrix,'inverse':inverse,'functional_value':got})
  columns.append({'bank_index':k,'epsilon':e,'delta':d,'alpha':alpha,'beta':O,'Delta':delta})
 print('All 132 literal inverses checked: obstruction vanishes on every branch and is nonzero on target.',flush=True)
 # The field law is checked by a separately coded long-reduction product.
 def generic_mul(a,b):
  v=[0]*5
  for i,x in enumerate(a):
   for j,y in enumerate(b): v[i+j]=(v[i+j]+x*y)%P
  for d in (4,3):
   c=v[d]
   for j in range(3): v[d-3+j]=(v[d-3+j]-13*c)%P
   v[d]=0
  return tuple(v[:3])
 sample=set(support+[v for br in branches for row in br['inverse'] for v in row])
 for a in sample:
  assert generic_mul(a,U)==mul(a,U)
  if a!=Z: assert generic_mul(a,inv(a))==O
 controls=[]
 changed=lam[:]; changed[0]=add(changed[0],O)
 vals=[functional(br['inverse'],changed) for br in branches]
 assert any(v!=Z for v in vals)
 controls.append({'mutation':'Perturb null vector first coordinate by one','rejected':True,'branches_with_nonzero_functional':sum(v!=Z for v in vals)})
 assert functional(F,[Z]*N)==Z
 controls.append({'mutation':'Use zero null vector as obstruction','rejected':True,'target_nonzero_requirement_fails':True})
 corrupt=[r[:] for r in branches[0]['inverse']]; corrupt[0][0]=add(corrupt[0][0],O)
 assert mm(branches[0]['matrix'],corrupt)!=I and mm(corrupt,branches[0]['matrix'])!=I
 controls.append({'mutation':'Corrupt one literal inverse entry','rejected':True,'both_inverse_products_fail':True})
 alt=matrix_inverse(branch(1,1,C(1),0)); assert functional(alt)!=Z
 controls.append({'mutation':'Replace support node 3 by 1','rejected':True,'functional_value_on_replacement_branch':functional(alt)})
 try: matrix_inverse(branch(1,1,Z,0))
 except ValueError: controls.append({'mutation':'Allow alpha=0,beta=1','rejected':True,'zero_Delta':True,'literal_branch_singular':True})
 else: raise AssertionError('Singular branch mutation passed')
 assert ev([13,13,13,1],U)==Z and ev([14,13,13,1],U)!=Z
 controls.append({'mutation':'Perturb cubic modulus constant term','rejected':True,'generator_fails_changed_relation':True})
 # The certificate is field-valued but in fact descends entirely to the prime field.
 assert all(v[1:]==(0,0) for v in lam) and pairing[1:]==(0,0)
 normalized_lam=[mul(x,inv(pairing)) for x in lam]
 assert summ(mul(x,y) for x,y in zip(normalized_lam,rhs))==O
 obstruction={'sector_b':b,'rank_coefficient':len(bad['pivots']),'rank_augmented':len(bad['pivots'])+1,'lambda':lam,'normalized_lambda':normalized_lam,'lambda_times_coefficient_columns':[summ(mul(lam[a],A[a][k]) for a in range(N)) for k in range(len(params))],'lambda_times_normalized_target':pairing,'literal_target_functional':target_functional,'functional_formula':'L(M)=(1/11)*sum_{a=0}^{10}lambda[a]*sum_{t=0}^{10}M[(t+a)%11,t]*13^(-b*t)','all_132_literal_inverse_functionals_zero':True}
 orientation_polynomials={}
 for e,d in ((1,1),(-1,1),(1,-1),(-1,-1)):
  co=[0]*N
  for a in range(N): co[e*a%N]=(co[e*a%N]+lam[a][0]*G(e,d,a,b))%P
  while len(co)>1 and not co[-1]:co.pop()
  orientation_polynomials[str((e,d))]=co
 assert orientation_polynomials[str((-1,-1))]==[0]
 assert [a for a in range(N) if G(-1,-1,a,b)]==[0,9,10]
 # Divide the ++ functional polynomial by the forced quintic, with exact remainder.
 work=orientation_polynomials[str((1,1))][:]; h=[14,1,14,17,12,1]; quotient=[0]*max(1,len(work)-5)
 for deg in range(len(work)-1,4,-1):
  c=work[deg];quotient[deg-5]=c
  for k,v in enumerate(h):work[deg-5+k]=(work[deg-5+k]-c*v)%P
 assert not any(work)
 obstruction['orientation_functional_polynomials_ascending_alpha']=orientation_polynomials
 obstruction['plusplus_division_by_forced_quintic']={'quintic':h,'quotient':quotient,'remainder':[0]}
 obstruction['minusminus_supported_a']=[0,9,10]
 obstruction['independent_of_opposite_same_sign_support_and_count']=True
 obstruction['scope_with_arbitrary_beta']='For all legal beta, the scalar beta^[delta*b]/Delta and phase weight multiply the same orientation functional polynomial. Thus arbitrary beta and any number of -- banks cannot remove the b=3 obstruction, provided ++ support stays within the five roots and both cross nodes are 15.'
 result={'status':'CANDIDATE_FIXED_SUPPORT_FAILURE','field_characteristic':P,'field_order':P**3,'field_modulus_ascending':cubic,'basis':'1,u,u^2; all entries are coefficient triples in F23','N':N,'q':Q,'cross_nodes':[C(15),C(15)],'same_sign_support':support,'orientation_allocation':[5,1,1,5],'sector_ranks':[len(s['pivots']) for s in systems],'consistent_sectors':[s['sector_b'] for s in systems if s['consistent']],'inconsistent_sectors':[s['sector_b'] for s in systems if not s['consistent']],'literal_inverse_count':len(branches),'inverse_product_checks':2*len(branches),'literal_inverse_functional_zero_checks':len(branches),'target_functional_nonzero':target_functional,'mutation_controls_passed':len(controls),'extension_arithmetic_samples':len(sample),'scope':'No raw weights exist for this exact support and cross-node pair. No unrestricted twelve-bank or extension-field minimum conclusion is made.','new_code_only':True}
 dump(out,'RESULTS.json',result); dump(out,'FAILURE.json',{'obstruction':obstruction,'systems':systems,'bank_columns':columns,'target':F});dump(out,'BRANCHES.json',branches);dump(out,'MUTATION_CONTROLS.json',controls)
 dump(out,'TIMING.json',{'start_utc_system':utc,'end_utc_system':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-start,'errors':[],'expected_inconsistent_sectors':result['inconsistent_sectors'],'model_token_usage':'unavailable'})
 print(json.dumps(result,sort_keys=True))

def main(out):
 start=time.perf_counter(); utc=datetime.datetime.now(datetime.timezone.utc).isoformat(); out.mkdir(parents=True,exist_ok=True)
 # Irreducible cubic defines a field; its degree-three Frobenius orbit contains all roots.
 cubic=[13,13,13,1]; assert all(sum(c*x**i for i,c in enumerate(cubic))%P for x in range(P))
 roots=[U,power(U,P),power(U,P*P)]; assert len(set(roots))==3 and all(ev(cubic,x)==Z for x in roots) and power(U,P**3)==U
 support=[C(3),C(21)]+roots; assert len(set(support))==5 and Z not in support
 quintic=[14,1,14,17,12,1]; assert all(ev(quintic,x)==Z for x in support)
 # Reconstruct original target and its Weyl coefficient transform from matrix entries.
 assert pow(Q,N,P)==1 and Q!=1
 F=[[C(pow(Q,(-k*t)%N,P)) for t in range(N)] for k in range(N)]
 invN=pow(N,-1,P); cf={}
 for a,b in itertools.product(range(N),repeat=2): cf[a,b]=scale(summ(scale(F[(t+a)%N][t],pow(Q,(-b*t)%N,P)) for t in range(N)),invN)
 gamma=cf[0,0]; assert gamma==C(18)
 f={k:mul(x,inv(gamma)) for k,x in cf.items()}
 assert all(x==C(pow(Q,3*(a+b)**2%N,P)) for (a,b),x in f.items())
 # Direct word counting supplies noncommutative Gaussian coefficients.
 wordf={}
 for e,d in itertools.product((1,-1),repeat=2):
  omega=pow(Q,e*d%N,P)
  for length in range(N+1):
   accum={}
   for word in itertools.product((0,1),repeat=length):
    r=word.count(0); ell=length-r
    inversions=sum(word[i]==1 and word[j]==0 for i in range(length) for j in range(i+1,length))
    accum[r,ell]=(accum.get((r,ell),0)+pow(omega,inversions,P))%P
   if length==N: assert all(v==int(r in (0,N)) for (r,ell),v in accum.items())
   else:
    for (r,ell),v in accum.items(): wordf[e,d,r,ell]=v
 def G(e,d,a,b):
  r=e*a%N; ell=d*b%N
  return wordf[e,d,r,ell] if r+ell<N else 0
 params=[(1,1,x) for x in support]+[(-1,1,C(15)),(1,-1,C(15))]+[(-1,-1,x) for x in support]
 systems=[]; amps=[]
 for b in range(N):
  A=[[scale(power(x,e*a%N),G(e,d,a,b)) for e,d,x in params] for a in range(N)]
  rhs=[f[a,b] for a in range(N)]; sol,piv,R=eliminate(A,rhs)
  systems.append({'sector_b':b,'matrix':A,'rhs':rhs,'pivots':piv,'solution':sol,'rref_augmented':R,'consistent':sol is not None})
  amps.append(sol)
 if any(s is None for s in amps):
  failure_gate(out,params,systems,F,gamma,cubic,support,start,utc,G); return
 print('All eleven full sectors consistent; ranks:',[len(s['pivots']) for s in systems],flush=True)
 banks=[]; branches=[]; aggregate=zero_matrix(); I=[[O if i==j else Z for j in range(N)] for i in range(N)]
 for k,(e,d,alpha) in enumerate(params):
  denominator=neg(power(alpha,N)); assert denominator!=Z
  amp=[amps[b][k] for b in range(N)]
  weights=[mul(mul(denominator,gamma),summ(scale(amp[b],pow(Q,-e*b*j%N,P)) for b in range(N))) for j in range(N)]
  # Separate direct character-system solve confirms inverse-transform weights.
  chars=[[C(pow(Q,e*b*j%N,P)) for j in range(N)] for b in range(N)]
  chars_rhs=[scale(mul(mul(denominator,gamma),amp[b]),N) for b in range(N)]
  check_weights,_,_=eliminate(chars,chars_rhs); assert check_weights==weights
  bank=zero_matrix()
  for j in range(N):
   A=branch(e,d,alpha,j); Ai=matrix_inverse(A); assert mm(A,Ai)==I and mm(Ai,A)==I
   bank=matrix_add(bank,matrix_scale(Ai,scale(weights[j],invN)))
   branches.append({'bank_index':k,'phase':j,'matrix':A,'inverse':Ai})
  assert any(x!=Z for row in bank for x in row)
  # Second bank reconstruction from explicit Weyl matrices, independent of literal inverses.
  weyl=zero_matrix()
  for a,b in itertools.product(range(N),repeat=2):
   coeff=scale(mul(mul(gamma,amp[b]),power(alpha,e*a%N)),G(e,d,a,b))
   for t in range(N): weyl[(t+a)%N][t]=add(weyl[(t+a)%N][t],scale(coeff,pow(Q,b*t%N,P)))
  assert bank==weyl
  aggregate=matrix_add(aggregate,bank)
  banks.append({'index':k,'epsilon':e,'delta':d,'alpha':alpha,'beta':O,'Delta':denominator,'amplitudes_by_b':amp,'raw_weights':weights,'matrix':bank})
 assert aggregate==F
 # Mutation checks use literal matrices, never only the constructed moment windows.
 controls=[]
 def reject(label,bad,details=None):
  mismatch=sum(x!=y for r,s in zip(bad,F) for x,y in zip(r,s)); assert mismatch>0,label
  controls.append({'mutation':label,'rejected':True,'mismatching_target_entries':mismatch,'details':details})
 reject('Perturb first raw weight by one',matrix_add(aggregate,matrix_scale(branches[0]['inverse'],C(invN))))
 reject('Omit normalization 1/11',matrix_scale(aggregate,C(N)))
 Fpos=[[C(pow(Q,k*t%N,P)) for t in range(N)] for k in range(N)]
 assert Fpos!=F; controls.append({'mutation':'Reverse target Fourier sign','rejected':True,'mismatching_target_entries':sum(x!=y for r,s in zip(F,Fpos) for x,y in zip(r,s))})
 for k,b in enumerate(banks): reject('Delete actual bank '+str(k),matrix_add(aggregate,matrix_scale(b['matrix'],C(-1))))
 phasebad=zero_matrix()
 for b in banks:
  for j,w in enumerate(b['raw_weights']): phasebad=matrix_add(phasebad,matrix_scale(branches[b['index']*N+(-j)%N]['inverse'],scale(w,invN)))
 reject('Reverse every branch phase sign with weights unchanged',phasebad)
 corrupt=[r[:] for r in branches[0]['inverse']];corrupt[0][0]=add(corrupt[0][0],O)
 assert mm(branches[0]['matrix'],corrupt)!=I and mm(corrupt,branches[0]['matrix'])!=I
 controls.append({'mutation':'Corrupt first literal inverse entry','rejected':True,'both_inverse_products_fail':True})
 try: matrix_inverse(branch(1,1,Z,0))
 except ValueError: controls.append({'mutation':'Allow alpha=0,beta=1','rejected':True,'zero_Delta':True,'literal_branch_singular':True})
 else: raise AssertionError('Singular branch mutation passed')
 # Change one same-sign root to a legal different node and reconstruct that bank literally.
 badbank=zero_matrix()
 for j,w in enumerate(banks[0]['raw_weights']): badbank=matrix_add(badbank,matrix_scale(matrix_inverse(branch(1,1,C(1),j)),scale(w,invN)))
 reject('Replace same-sign alpha 3 by 1 with raw weights unchanged',matrix_add(matrix_add(aggregate,matrix_scale(banks[0]['matrix'],C(-1))),badbank))
 # Extension arithmetic: independent generic polynomial remainder cross-check on all 121 entry products.
 def generic_mul(a,b):
  v=[0]*5
  for i,x in enumerate(a):
   for j,y in enumerate(b): v[i+j]=(v[i+j]+x*y)%P
  for d in (4,3):
   c=v[d]
   for j in range(3): v[d-3+j]=(v[d-3+j]-13*c)%P
   v[d]=0
  return tuple(v[:3])
 sample=set(support+[v for b in banks for v in b['raw_weights']]+[v for b in banks for row in b['matrix'] for v in row])
 for a in sample:
  assert generic_mul(a,U)==mul(a,U)
  if a!=Z: assert generic_mul(a,inv(a))==O
 result={'status':'CANDIDATE_FULL_TWELVE_BANK_WITNESS','field_characteristic':P,'field_order':P**3,'field_modulus_ascending':cubic,'basis':'1,u,u^2; all entries are coefficient triples in F23','N':N,'q':Q,'cross_nodes':[C(15),C(15)],'same_sign_support':support,'orientation_allocation':[5,1,1,5],'sector_ranks':[len(s['pivots']) for s in systems],'full_121_target_entries_equal':True,'literal_inverse_count':len(branches),'inverse_product_checks':2*len(branches),'raw_weights_recovered_and_checked':sum(len(b['raw_weights']) for b in banks),'nonzero_actual_banks':len(banks),'mutation_controls_passed':len(controls),'extension_arithmetic_samples':len(sample),'scope':'Attainment only. Exact minimum requires separately verified extension-field lower bound and independent full-gate review. No characteristic-zero transfer or unrestricted-allocation claim.','new_code_only':True}
 dump(out,'RESULTS.json',result);dump(out,'WITNESS.json',{'field_modulus_ascending':cubic,'support':support,'banks':banks,'sector_systems':systems,'target':F,'aggregate':aggregate});dump(out,'BRANCHES.json',branches);dump(out,'MUTATION_CONTROLS.json',controls)
 dump(out,'TIMING.json',{'start_utc_system':utc,'end_utc_system':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-start,'errors':[],'model_token_usage':'unavailable'})
 print(json.dumps(result,sort_keys=True))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);main(p.parse_args().out)
