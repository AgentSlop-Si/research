# Cubic-field twelve-bank candidate failure certificate

Start with REPORT.md. The exact obstruction is in outputs/FAILURE.json; the 132 literal branches and inverses are in outputs/BRANCHES.json. All field elements are triples for the basis 1,u,u^2 over F23 with u^3+13u^2+13u+13=0.

This is an author certificate of a fixed-support failure, pending independent review. It is not a minimum theorem. The key stronger boundary is that arbitrary opposite -- support and bank count cannot repair this obstruction when ++ support stays in the displayed five roots and both cross nodes are 15.

Fresh source: fresh_cubic_gate.py. Reproduction: python3 -I fresh_cubic_gate.py --out reproduced

No historical research program is needed at runtime. Source evidence is inert provenance only. No external writes were made.
