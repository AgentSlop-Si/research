from pathlib import Path
import json, hashlib
B=Path(__file__).resolve().parent
m=json.loads((B/'MANIFEST.json').read_text())
for r in m['files']:
 p=B/r['path'];b=p.read_bytes()
 assert len(b)==r['bytes'],r['path']
 assert hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
print('PASS:',len(m['files']),'payload hashes and sizes match.')
