"""Fresh exact finite audit of saved/rebuilt Q29 shared-center jets."""
import json, math, hashlib
from fractions import Fraction as F
from pathlib import Path
B=Path(__file__).resolve().parents[1]
Z=[0]*18

def hull(points):
 out=[]
 for p in sorted(points):
  while len(out)>1 and (out[-1][0]-out[-2][0])*(p[1]-out[-1][1]) <= (out[-1][1]-out[-2][1])*(p[0]-out[-1][0]):out.pop()
  out.append(p)
 return out

def canonical(d):
 d=dict(d);d.pop('elapsed_seconds',None)
 return json.dumps(d,sort_keys=True,separators=(',',':')).encode()

raw=json.loads((B/'fresh/center0_full.json').read_text())
D={(a,b):v for a,b,v in raw['coefficients']}
assert raw['n']==1687 and raw['max_x']==99 and raw['max_raw_v']==100 and raw['center_j']==0
A=D[50,10]
assert any(A)
assert all(a+b>=60 for a,b in D)
face={b:v for (a,b),v in D.items() if a+b==60}
assert face=={10:A,30:[3*x%5 for x in A],50:A}
assert D[75,0]==[4*x%5 for x in A]
# All normalized derivative residues vanish: every exponent is divisible by5.
assert all(b%5==0 for b in face)
# Translate the certified normalized jet. Values outside a+b<100 remain unknown.
T={(a+b-60,b):v for (a,b),v in D.items() if a+b<100}
translations=[]
for c in range(5):
 E={}
 for (a,b),v in T.items():
  for k in range(min(20,b)+1):
   t=math.comb(b,k)*pow(c,b-k,5)%5
   if not t:continue
   w=E.setdefault((a,k),[0]*18)
   for j in range(18):w[j]=(w[j]+t*v[j])%5
 E={k:v for k,v in E.items() if any(v)}
 vals={b:min(a for a,bb in E if bb==b) for b in set(b for a,b in E)}
 lower=hull(vals.items());slope=F(vals[0],10)
 # Endpoints determine all ten roots in this translated residue disk.
 assert vals[10]==0 and all(F(a)+slope*b>=vals[0] for a,b in E)
 ef={b:v for (a,b),v in E.items() if F(a)+slope*b==vals[0]}
 assert all(b%5==0 for b in ef)
 expected={0:4,10:1} if c in (0,1) else ({0:4,5:4,10:1} if c==3 else {0:1,5:3,10:1})
 assert ef=={b:[t*x%5 for x in A] for b,t in expected.items()}
 translations.append({'residue_center':c,'certified_precision_exclusive':40,'constant_valuation':vals[0],
  'first_hull_segment':[[0,vals[0]],[10,0]],'root_valuation_relative_to_Y_center':str(slope),
  'edge_coefficients_by_degree':ef,'edge_divided_by_A':expected,
  'precision_after_face_division_exclusive':40-vals[0],
  'edge_derivative_mod_pi_zero':True})
# Wrong lower-root control: q_lower=eta*(1+pi)^5. Below pi100,
# formal substitution is x->x^5; coefficient v10 has no term of order<100.
correct_v10={a:v for (a,b),v in D.items() if b==10}
wrong_v10={5*a:v for a,v in correct_v10.items() if 5*a<100}
assert min(correct_v10)==50 and not wrong_v10
# Shared-center sign reversal sends nonzero A to -A, which differs in F5.
wrong_sign=[4*x%5 for x in A]
assert wrong_sign!=A
sizes=[10,40,10,2];radii=[F(5,2),F(1),F(9,10),F(1,2)]
within=[d*(d-1)*r for d,r in zip(sizes,radii)]
pairs=[{'i':i,'j':j,'degree_i':sizes[i],'degree_j':sizes[j],
 'twice_resultant_valuation':str(2*sizes[i]*sizes[j]*min(radii[i],radii[j]))} for i in range(4) for j in range(i+1,4)]
cross=sum(F(p['twice_resultant_valuation']) for p in pairs)
assert sum(within)==1867 and cross==1820 and sum(within)+cross==3687
# Split the radius-1 factor into its four residue centers. Their pairwise
# resultants are units; the next certified root-radius contributions are:
extra=sum(90*F(t['root_valuation_relative_to_Y_center']) for t in translations if t['residue_center']!=0)
assert extra==405
out={'scope':'t27,p5,e3,n1687, shared center z=-1 in k=F5[eta]/Phi27',
 'precision':{'raw_exclusive':100,'normalized_exclusive':40,'v_pi_5':100},
 'integral_normalization':'F(Y)=pi^-60*U1687(-1-pi*Y;eta*(1+pi))',
 'residual_polynomial':'A*Y^10*(Y^4-1)^10','A_eta_coordinates':A,
 'residual_derivative_zero':True,'translations':translations,
 'wrong_lower_root_control':{'correct_v10_valuation':50,'wrong_q_lower_v10_valuation_lower_bound':100,'detected':True},
 'shared_sign_control':{'correct_A':A,'wrong_sign_A':wrong_sign,'detected':True},
 'annular_discriminant_accounting':{'degrees':sizes,'pi_root_valuations':list(map(str,radii)),
  'within_scale_terms':list(map(str,within)),'within_scale_sum':str(sum(within)),
  'cross_squared_resultants':pairs,'cross_sum':str(cross),'baseline':3687,
  'radius1_extra_certified_lower_bound':405,'refined_local_lower_bound':4092,
  'exact_expression':'v_pi Disc(W0)=3687+sum_i v_pi Disc(scaled_monic_annular_factor_i)',
  'warning':'Residual-factor discriminants are not evaluated; no equality to baseline or lower bound is claimed.'}}
(B/'controls/NORMALIZATION_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('translations','A_eta_coordinates','shared_sign_control')},indent=2))
