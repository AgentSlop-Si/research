// New exact characteristic-five Hasse-jet reconstruction, 14 October 2026.
// Historical research code is neither imported nor executed.
#include <vector>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <chrono>
using namespace std;
constexpr int C=27;
int main(int argc,char**argv){
 int A=argc>1?atoi(argv[1]):65, B=argc>2?atoi(argv[2]):63;
 int J=argc>3?atoi(argv[3]):0, N=argc>4?atoi(argv[4]):1687;
 const size_t S=(A+1)*(B+1)*C;
 vector<unsigned char> old(S),cur(S),nxt(S); old[0]=1;cur[0]=1;cur[(C-J)%C]=(cur[(C-J)%C]+4)%5;
 // Store eta exponent as positive coordinate; z=-eta^J(1+v).
 fill(cur.begin(),cur.end(),0);cur[0]=1;cur[J%27]=(cur[J%27]+4)%5;cur[(A+1)*C+J%27]=4;
 auto ix=[&](int b,int a,int k){return (size_t(b)*(A+1)+a)*C+k;};
 int bc[125][125]={};bc[0][0]=1;
 for(int n=1;n<125;n++){bc[n][0]=bc[n][n]=1;for(int k=1;k<n;k++)bc[n][k]=(bc[n-1][k]+bc[n-1][k-1])%5;}
 auto start=chrono::steady_clock::now();
 for(int n=2;n<=N;n++){
  fill(nxt.begin(),nxt.end(),0); int r=(n-1)%125,sh=(n-1+J)%27;
  vector<pair<int,int>> terms;for(int h=0;h<=A&&h<=r;h++)if(bc[r][h])terms.push_back({h,bc[r][h]});
  for(int b=0;b<=B;b++)for(int a=0;a<=A;a++){
   for(int k=0;k<C;k++){
    int v=cur[ix(b,a,k)]+4*cur[ix(b,a,(k-J+C)%C)]+old[ix(b,a,(k-J+C)%C)];
    if(b){v+=4*cur[ix(b-1,a,(k-J+C)%C)]+old[ix(b-1,a,(k-J+C)%C)];}
    int w=0;for(auto [h,c]:terms){if(h>a)break;w+=c*old[ix(b,a-h,(k-sh+C)%C)];if(b)w+=c*old[ix(b-1,a-h,(k-sh+C)%C)];}
    nxt[ix(b,a,k)]=(v+5*((w+4)/5)-w)%5;
   }
  }
  old.swap(cur);cur.swap(nxt);
 }
 // Project F5[C27] to F5[eta]/(eta18+eta9+1), after signed shared quotient.
 printf("{\"n\":%d,\"center_j\":%d,\"max_x\":%d,\"max_raw_v\":%d,\"coefficients\":[\n",N,J,A,B);
 bool first=true;
 for(int b=0;b<=B-(J==0);b++)for(int a=0;a<=A;a++){
  array<int,27> q{};for(int k=0;k<27;k++)q[k]=cur[ix(b+(J==0),a,k)]*(J==0?4:1)%5;
  for(int k=26;k>=18;k--){q[k-9]=(q[k-9]+5-q[k])%5;q[k-18]=(q[k-18]+5-q[k])%5;q[k]=0;}
  bool nz=false;for(int k=0;k<18;k++)nz|=q[k]!=0;if(!nz)continue;
  if(!first)printf(",\n");first=false;printf("[%d,%d,[",a,b);for(int k=0;k<18;k++)printf("%s%d",k?",":"",q[k]);printf("]]");
 }
 printf("\n],\"elapsed_seconds\":%.6f}\n",chrono::duration<double>(chrono::steady_clock::now()-start).count());
}
