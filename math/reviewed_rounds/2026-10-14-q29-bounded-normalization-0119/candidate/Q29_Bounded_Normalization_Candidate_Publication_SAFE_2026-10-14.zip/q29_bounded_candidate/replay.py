"""Reproduce only this session's newly authored Q29 exact programs."""
from pathlib import Path
import json, tempfile, subprocess, shutil, hashlib, time
B=Path(__file__).resolve().parent
start=time.monotonic()
def cmd(args,cwd):
 p=subprocess.run(args,cwd=cwd,check=True,capture_output=True,text=True)
 return p

def canon(p):
 d=json.loads(p.read_text());d.pop('elapsed_seconds',None)
 return json.dumps(d,sort_keys=True,separators=(',',':')).encode()
with tempfile.TemporaryDirectory(prefix='q29_clean_replay_') as td:
 T=Path(td);(T/'code').mkdir();(T/'fresh/independent_reciprocal').mkdir(parents=True);(T/'controls').mkdir()
 shutil.copyfile(B/'code/compute_center.cpp',T/'code/compute_center.cpp')
 shutil.copyfile(B/'code/audit_normalization.py',T/'code/audit_normalization.py')
 for name in ['rebuild.cpp','analyze.py']:shutil.copyfile(B/'sources'/name,T/'fresh/independent_reciprocal'/name)
 cmd(['g++','-O2','-std=c++17','code/compute_center.cpp','-o','fresh/compute_center'],T)
 matches=[]
 for j in [0,1]:
  r=cmd(['./fresh/compute_center','99','100',str(j),'1687'],T)
  p=T/f'fresh/center{j}_full.json';p.write_text(r.stdout)
  assert canon(p)==canon(B/f'fresh/center{j}_full.json')
  matches.append({'file':p.name,'canonical_sha256':hashlib.sha256(canon(p)).hexdigest()})
 I=T/'fresh/independent_reciprocal'
 cmd(['g++','-O2','-std=c++17','rebuild.cpp','-o','rebuild'],I)
 cmd(['./rebuild'],I)
 cmd(['python3','analyze.py'],I)
 for name in ['u13.json','u1687_independent.json','verification.json']:
  if name=='verification.json':
   actual=json.loads((I/name).read_text());expected=json.loads((B/'fresh/independent_reciprocal'/name).read_text())
   actual.pop('primary_output_sha256');expected.pop('primary_output_sha256')
   assert actual==expected
   matches.append({'file':name,'semantic_match':True,'excluded_nondeterministic_field':'primary_output_sha256 (hash includes primary elapsed_seconds)'})
  else:
   assert (I/name).read_bytes()==(B/'fresh/independent_reciprocal'/name).read_bytes()
   matches.append({'file':name,'sha256':hashlib.sha256((I/name).read_bytes()).hexdigest()})
 cmd(['python3','code/audit_normalization.py'],T)
 assert (T/'controls/NORMALIZATION_AUDIT.json').read_bytes()==(B/'controls/NORMALIZATION_AUDIT.json').read_bytes()
 receipt={'status':'PASS','clean_temporary_workspace':True,'comparisons':matches,'normalization_and_negative_controls':'PASS','elapsed_seconds':round(time.monotonic()-start,3),'token_usage':'unknown; not exposed','execution_scope':'Only newly authored sources from this session. No historical uploaded program executed.'}
 print(json.dumps(receipt,indent=2))
