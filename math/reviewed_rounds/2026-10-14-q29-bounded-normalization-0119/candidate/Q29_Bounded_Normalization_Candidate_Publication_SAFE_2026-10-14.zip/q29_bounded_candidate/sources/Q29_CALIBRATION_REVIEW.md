# Independent Q29 ramified calibration review

## Verdict: ACCEPT, at the exact finite calibration scope

For a primitive 27th root q, let H13(z;q) be the Gaussian-coefficient Rogers–Szegő polynomial and U13=H13/(z+1). For its ordinary z-discriminant D, the independently reconstructed values are

- vπ(D)=174, where π=q−1 and vπ(3)=18;
- ord(q−1) D(q)=66 for the universal characteristic-zero polynomial;
- vπ(D(q)/(q−1)^66)=108 at the actual primitive 27th root.

D and its normalized element are nonzero. The result is only t=1, p=3, e=3, n=13. It neither resolves the t=27, p=5 higher-layer problem nor resolves the broader Q29 problem. There is no all-layer squarefreeness, global-unit, algorithmic, historical-priority or novelty acceptance.

## Independent reconstruction

The supplied historical and candidate programs were read as inert source text. Only newly written review programs were executed.

`reconstruct_q29.py` constructs H13 in Q[q]/(q^18+q^9+1) using

    Hn=(1+z)H(n−1)−z(1−q^(n−1))H(n−2).

This is different from the candidate's q-Pascal construction. Exact division by z+1 has zero remainder and U13 is monic of degree12. The fresh checker constructs the 12×12 Bezout coefficient matrix

    (U(X)U′(Y)−U(Y)U′(X))/(X−Y)

term by term, checks its symmetry, and takes its determinant with a newly written fraction-free elimination. For monic U this determinant is the discriminant; at degree12 the usual resultant sign is also positive. This does not call the candidate's field-resultant calculation. Every one of the 18 q-basis coordinates and 18 π-basis coordinates agrees exactly with the frozen candidate vector. The full U coefficients, discriminant vectors and weights are saved in `Q29_FRESH_RESULT.json`.

## Intrinsic local valuation

Φ27(1+π)=(1+π)^18+(1+π)^9+1 is Eisenstein at3: all 18 nonleading coefficients are divisible by3, its constant coefficient is3 and its leading coefficient is1. Thus Q3(q) is a totally ramified degree18 extension, with one prime over3, uniformizer π and integral basis 1,π,…,π^17.

Writing D=Σ a_iπ^i, the checker obtains the respective nonzero summand weights

    180,181,200,201,220,185,186,223,188,207,208,191,174,175,194,213,196,215.

The i=12 coefficient has v3(a_12)=9 and weight174. Distinct i have distinct weights modulo18, so the unique minimum cannot cancel. This proves vπ(D)=174 without mistaking the leading ordinary coefficient for the local minimum. The next-smallest weight is175.

## Exact ordinary normalization exponent

A second construction enumerates all8,192 subsets of {0,…,12}. For a k-subset S its contribution q^(ΣS−k(k−1)/2) reconstructs the complete integer Gaussian coefficient. The checker then divides H13 by z+1 by exact coefficient recurrence. No Gaussian quotient denominator or prior resultant is used here.

Set q=1+t² and z=−1+tY. Exact coefficient expansion proves that every t-degree below12 in U13(−1+tY;1+t²) vanishes. After division by t^12, the t=0 polynomial is

    L(Y)=Y^12−78Y^10+2145Y^8−25740Y^6+135135Y^4−270270Y²+135135.

This also equals He13(Y)/Y by an independently formed Hermite recurrence. Its exact nonzero discriminant is

    9104002810500086074413881286957195065170346579346566928138240000000000000.

Let V(Y,t)=t^−12 U13(−1+tY;1+t²). It is monic of degree12 with coefficients integral in t. The exact translation/scaling identity for the discriminant gives

    D(1+t²)=t^132 DiscY(V(Y,t)).

Since Disc(L)≠0, ord_t D(1+t²)=132 and therefore ord_(q−1) D=66 exactly. Universal U and its discriminant belong to Z[q], and division by the monic power (q−1)^66 gives an integral polynomial quotient. Specializing that exact quotient at the actual primitive27 root subtracts66 from the intrinsic valuation, yielding108. This is not a substitution of a lower-layer root.

The initial coefficient has v3=33. The erroneous extrapolation 66+18·33=660 differs from the actual174. Higher ordinary coefficients cannot be discarded in the ramified local valuation.

## Alternate controls and source boundary

`verify_controls.py` computes the norm of the freshly obtained D by an integer polynomial resultant against Φ27, independent of the candidate's multiplication-matrix norm. The entire exact norm matches and v3(norm)=174.

The same checker independently reconstructs H13 by the finite Euler product, removes its triangular q-weights, and divides by z+1 over F109, F163 and F271. All18 primitive27 roots in each field give54 ordinary discriminants matching the fresh field vector and the frozen controls. A unit-coordinate perturbation is detected. These checks corroborate, but do not replace, the exact field reconstruction and local proof.

The accepted source's t=1,p=3,e=3 example concerned the quotient-parity countercontrol. It did not already state the exact ordinary-discriminant valuation proved here. The prior t=27,p=5 obstruction and order675 valuations remain inherited rather than rerun. The source's rejected unrestricted shared-U sufficient inequalities stay rejected; this calibration repairs or promotes none of them.

## Preservation

The source SHA bindings are in the enclosing review's input manifest. The candidate archive is preserved byte-for-byte. No candidate source file, workbook, Sheet or GitHub object was changed. This scoped acceptance adds no stable ID, discovery count, rank or score change.
