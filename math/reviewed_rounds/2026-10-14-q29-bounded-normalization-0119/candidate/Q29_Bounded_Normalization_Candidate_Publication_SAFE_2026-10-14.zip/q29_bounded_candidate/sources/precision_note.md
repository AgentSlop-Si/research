# Independent shared-center reciprocal audit

Fresh exact code is `rebuild.cpp`; `analyze.py` is also fresh. Neither loads any historical executable or source. The primary result was opened only after the independent output had been written.

## Verified computation

In F5[C27][x]/(x^100), the recurrence

R_m=(w-2+q^(2m)+q^(2m-1))R_(m-1) -(1-q^(2m-1))(1-q^(2m-2))R_(m-2)

was evaluated at q=eta(1+x), keeping w-degree <50 through m=843. Its independent signed transformation is

U_1687(-1-v;q)=sum_(k=0)^843 (-1)^(843+k) r_(843,k)(q) v^(2k)(1+v)^(843-k).

Keeping w-degree <50 is exact for all v-degrees <100: the k-th summand starts at v^(2k), and all exponents 843-k are nonnegative. Truncating each recurrence step in w is exact because the recurrence never decreases w-degree. Truncating x is exact because the recurrence only uses polynomial multiplication and addition, never x-division. Multiplication by q^a is implemented via its independent Frobenius factorization eta^a product_j (1+x^(5^j))^(a_j).

The C27 group-algebra result is projected by eta^18=-eta^9-1. This projection is a ring homomorphism; ord_27(5)=18 proves Phi27 is irreducible over F5. Thus the coefficient field is F_(5^18).

Every one of the 10,000 coefficient vectors, each with 18 coordinates, agrees with the separately generated `../center0_full.json`. There are 7,818 nonzero vectors. This includes the exact sign U=-H/v, independently checked against the direct Rogers-Szego H recurrence for m=0,...,6. The shared local Newton hull within the certified low degrees is (0,75),(10,50),(50,10),(60,1),(62,0). All higher v-degrees have nonnegative valuations, so none can lie below its negative-slope segments.

For U13 at q=eta, the degree is 12, gcd(U13,U13')=1, and U13(-eta^j) is nonzero for all j=0,...,26. Exact field-valued guards, hashes and comparisons are in `verification.json`.

## Characteristic-zero transfer and its precise limit

Let O be the unramified extension of Z5 containing an exact primitive 27th root eta, and let pi=zeta_125-1. Then v_pi(5)=100. Reduction gives O[pi]/(pi^100) = F_(5^18)[x]/(x^100), with x the image of pi, since Phi125(1+x) reduces to x^100 modulo 5. Thus the calculated coefficients below x^100 are exact pi-adic data modulo pi^100. No omitted characteristic-zero carry can alter a coefficient of valuation strictly below 100. This statement requires precisely this cyclotomic pi and q=eta(1+pi), or another explicitly justified isomorphic local model.

Write the exact U as the displayed jet J plus error E. In O[pi][v], E belongs to (pi^100,v^100). On substitution v=pi^s Y for integral Y and rational s>0 in a ramified extension, the error has valuation at least min(100,100s). For the shared outer scale v=pi Y, this is at least 100. Thus F(Y)=pi^(-60) U(-1-pi Y;q) is certified modulo pi^40 as a polynomial in integral Y.

The same bound holds after integral translations Y=c+pi^b Z with b>=0; cancellations can increase valuations but cannot reduce that error bound. If the translated expression is divided by an additional pi^h, only precision 40-h remains. A Newton face or residual polynomial inferred from it must use absolute normalized valuations strictly below 40-h. Equality with that ceiling is not certified, and cannot be declared zero from the modulo-5 jet.

Differentiation with respect to Y preserves the pi^40 error bound for F, because every dropped v^j term becomes pi^j Y^j before differentiation. Therefore the adjusted derivative (1+v) F_Y -843 pi F also has error valuation at least 40. If it is subsequently divided by pi^d, only precision 40-d remains. Differentiation with respect to a newly scaled Z can be handled directly, but a conversion back to F_Y must account for the inverse scale pi^(-b). These scale factors cannot be silently discarded.

Accordingly, to turn the bounded jet result into an exact discriminant, one must specify every cluster normalization and derivative normalization, prove every decisive coefficient remains strictly below the corresponding error ceiling, prove the residual factors are squarefree or continue every repeated cluster, and prove the resulting root-distance tree covers the entire degree. The modulo-5 jet alone does not settle a residual branch once its first decisive term is at or above that ceiling. A higher mixed-characteristic lift, with explicit pi^100 carry terms, is required for such a branch. If a sharp bound rather than exact value is desired, omitted tails still must be shown unable to reduce its asserted bound.

## Reciprocal discriminant identity

For any monic separable R of degree m and U(z)=z^m R((1+z)^2/z),

Disc_z(U)=Disc_w(R)^2 Res_w(R,w(w-4)).

The sign is positive. Indeed, if R has roots w_i then U is the product of Q_i=z^2+(2-w_i)z+1. Each Disc(Q_i)=w_i(w_i-4), while Res(Q_i,Q_j)=(w_i-w_j)^2. The discriminant-of-a-product formula gives the stated identity. Since both sides are polynomial identities in the coefficients, the identity also holds without separability assumptions. It is independently checked by exact finite-field resultants for R6 and U13. For monic R, Res(R,w(w-4))=R(0)R(4), regardless of the parity of m, because both individual evaluation signs cancel.

This identity can avoid spurious reciprocal-unit derivative terms. It does not by itself determine the missing ramified R843 root-separation or endpoint valuation data.

## Additional exact endpoint consequence

The fresh direct scalar recurrence for H_n(1;eta) through n=1687 gives a nonzero U1687(1;eta)=H1687(1;eta)/2. Thus R843(4) is a unit. The independent shared jet gives v_pi(R843(0))=v_pi(U1687(-1;q))=75, strictly below the carry ceiling. Consequently v_pi Res(R843,w(w-4))=75 exactly, and

v_pi Disc(U1687) = 2 v_pi Disc(R843) + 75.

This fixes the endpoint contribution and supplies an odd-parity consistency check for any finite proposed global discriminant valuation. It leaves the global R843 discriminant to be determined.

## Safe annular discriminant lower bound

The shared-center degree-62 Weierstrass factor has 10 roots of pi-valuation 5/2, 40 of valuation 1, 10 of valuation 9/10, and 2 of valuation 1/2. For every pair, v_pi(alpha-beta)>=min(v_pi(alpha),v_pi(beta)). Therefore its discriminant valuation is at least 2 sum_(i<j) min(v_i,v_j)=3687. This uses only the certified raw annuli; it is not an equality claim and ignores extra separation forced by repeated residual roots. It is a local-factor bound, not the full U1687 discriminant.
