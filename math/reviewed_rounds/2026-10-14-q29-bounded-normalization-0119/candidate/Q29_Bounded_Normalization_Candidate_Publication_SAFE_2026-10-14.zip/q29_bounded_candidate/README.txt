Q29 higher-layer bounded normalization and ordinary-discriminant gap

Start with REPORT.md and RESULT.json.

This is a locally sealed bounded research artifact, not closure of Q29.
The exact target is the ordinary z-discriminant of U1687=H1687/(z+1),
which has degree1686 at the actual primitive3375 root.

Reproduce: python3 replay.py
Verify payload: python3 verify_manifest.py
Dependencies: Python3 standard library; a C++17 compiler named g++.

The clean replay compiles only newly authored local scientific sources
from the current session. It never executes historical uploaded programs.
Primary JSON output includes nondeterministic elapsed_seconds, so replay
compares its exact canonical mathematical data. The independent checker
records a SHA of that raw primary file; only that derived raw hash is
excluded from semantic comparison. All independent coefficient outputs
are required to match byte-for-byte. The initial overly strict metadata
comparison failure is retained in replay_history and the audit receipt.

sources/ contains immutable snapshots of local source/review inputs.
fresh/ contains the replacement audit's regenerated exact outputs.
controls/ contains normalization, precision, sign, wrong-root and scaling checks.
SOURCE_BINDINGS.json binds the recovered actual local predecessor files.
MANIFEST.json binds all distributed payload bytes. The ZIP seal is external.
