// Fresh independent exact computation, 2026-10-14.
// Reciprocal recurrence only; no primary/historical code is loaded.
#include <array>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <chrono>
#include <stdexcept>
using namespace std;
constexpr int P=5,E=27,N=100,K=50;
using A=vector<unsigned char>;
int ix(int k,int x,int e){return (k*N+x)*E+e;}
unsigned char add5(int a,int b){int c=a+b;return c>=5?c-5:c;}
unsigned char sub5(int a,int b){int c=a-b;return c<0?c+5:c;}
// Multiply by q^a=eta^a*(1+x)^a in F5[C27][x]/x^100.
// (1+x)^a = product_j (1+x^(5^j))^(a_j), exactly in characteristic 5.
A qmul(const A& in,int a,int active){
 A out(in.size()); int r=a%E;
 for(int k=0;k<active;k++)for(int x=0;x<N;x++)for(int e=0;e<E;e++)
  out[ix(k,x,(e+r)%E)]=in[ix(k,x,e)];
 for(int s=1;s<N;s*=5){int d=a%5;a/=5;
  for(int z=0;z<d;z++)for(int k=0;k<active;k++)for(int x=N-1;x>=s;x--)
   for(int e=0;e<E;e++)out[ix(k,x,e)]=add5(out[ix(k,x,e)],out[ix(k,x-s,e)]);
 }
 return out;
}
A reciprocal(int m){
 A last(K*N*E),prev(K*N*E);prev[0]=1;
 for(int j=1;j<=m;j++){
  int active=min(K,j+1);A next(K*N*E);
  A a=qmul(prev,2*j-1,active);A b=qmul(a,1,active);
  A c=qmul(last,2*j-2,active); // c=(1-q^(2j-2))*last, then q^(2j-1)*c.
  for(size_t i=0;i<c.size();i++)c[i]=sub5(last[i],c[i]);
  A d=qmul(c,2*j-1,active);
  for(int k=0;k<active;k++)for(int x=0;x<N;x++)for(int e=0;e<E;e++){
   int i=ix(k,x,e);int n=(a[i]+b[i]+5-2*int(prev[i])%5+5-c[i]+d[i])%5;
   if(k)n=(n+prev[ix(k-1,x,e)])%5;
   next[i]=n;
  }
  last.swap(prev);prev.swap(next);
  if(j%100==0)cerr<<"reciprocal m="<<j<<"\n";
 }
 return prev;
}
int binom5(int a,int b){
 static int C[5][5]={{1,0,0,0,0},{1,1,0,0,0},{1,2,1,0,0},{1,3,3,1,0},{1,4,1,4,1}};
 int v=1;while(a||b){v=v*C[a%5][b%5]%5;a/=5;b/=5;}return v;
}
A transform(const A& r,int m){
 A u(N*N*E);
 for(int k=0;k<K&&k<=m;k++)for(int v=2*k;v<N&&v<=m+k;v++){
  int c=binom5(m-k,v-2*k);if((m+k)%2)c=(5-c)%5;if(!c)continue;
  for(int x=0;x<N;x++)for(int e=0;e<E;e++){
   int i=ix(v,x,e);u[i]=(u[i]+c*r[ix(k,x,e)])%5;
  }
 }
 return u;
}
A project(const A& cyclic,int w){
 A z(w*N*18);
 for(int k=0;k<w;k++)for(int x=0;x<N;x++)for(int e=0;e<18;e++)z[(k*N+x)*18+e]=cyclic[ix(k,x,e)];
 for(int k=0;k<w;k++)for(int x=0;x<N;x++)for(int e=18;e<27;e++){
  int c=cyclic[ix(k,x,e)];
  for(int t:{e-18,e-9}){int i=(k*N+x)*18+t;z[i]=sub5(z[i],c);}
 }
 return z;
}
// Independent direct Rogers-Szego H recurrence used only for small m sanity guard.
A direct_odd(int n){
 // coordinate k denotes v degree. Keep H through degree99, then U through degree98.
 A a(K*N*E),b(K*N*E);a[0]=1;b[ix(1,0,0)]=4;
 for(int j=2;j<=n;j++){
  A q=qmul(a,j-1,K),c(K*N*E);
  for(int v=0;v<K;v++)for(int x=0;x<N;x++)for(int e=0;e<E;e++){
   int i=ix(v,x,e);int t=sub5(a[i],q[i]);
   if(v)t=(t+5-b[ix(v-1,x,e)]+a[ix(v-1,x,e)]+5-q[ix(v-1,x,e)])%5;
   c[i]=t;
  }
  a.swap(b);b.swap(c);
 }
 A u(N*N*E);
 for(int v=0;v<K-1;v++)for(int x=0;x<N;x++)for(int e=0;e<E;e++)u[ix(v,x,e)]=(5-b[ix(v+1,x,e)])%5;
 for(int x=0;x<N;x++)for(int e=0;e<E;e++)if(b[ix(0,x,e)])throw runtime_error("odd H not divisible by v");
 return u;
}
void output(const A& u,const string& file,int m){
 ofstream o(file);o<<"{\"p\":5,\"m\":"<<m<<",\"n\":"<<2*m+1<<",\"eta_modulus\":\"eta^18+eta^9+1\",\"x_exclusive\":100,\"v_exclusive\":100,\"sign\":\"U=-H/v\",\"coefficients_v_x_eta\":[";
 for(int v=0;v<N;v++){if(v)o<<",";o<<"[";for(int x=0;x<N;x++){if(x)o<<",";o<<"[";for(int e=0;e<18;e++){if(e)o<<",";o<<int(u[(v*N+x)*18+e]);}o<<"]";}o<<"]";}o<<"]}\n";
}
int main(){
 for(int m=0;m<=6;m++){
  A u=transform(reciprocal(m),m),h=direct_odd(2*m+1);
  if(u!=h)throw runtime_error("small direct/reciprocal disagreement m="+to_string(m));
  if(m==6)output(project(u,N),"u13.json",m);
 }
 cerr<<"Small exact signed guards m=0..6 pass.\n";
 auto t=chrono::steady_clock::now();A u=project(transform(reciprocal(843),843),N);output(u,"u1687_independent.json",843);
 cerr<<"Finished in "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s.\n";
}
