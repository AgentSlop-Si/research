"""Fresh independent guards and comparison of independently generated exact jets."""
import json, hashlib
from pathlib import Path
P=5;D=18
Z=(0,)*D;ONE=(1,)+(0,)*(D-1)
def add(a,b):return tuple((x+y)%P for x,y in zip(a,b))
def neg(a):return tuple(-x%P for x in a)
def sub(a,b):return add(a,neg(b))
def sc(a,n):return tuple(n*x%P for x in a)
def mul(a,b):
 c=[0]*35
 for i,x in enumerate(a):
  if x:
   for j,y in enumerate(b):
    if y:c[i+j]=(c[i+j]+x*y)%5
 for i in range(34,17,-1):
  if c[i]:
   c[i-9]=(c[i-9]-c[i])%5;c[i-18]=(c[i-18]-c[i])%5
 return tuple(c[:18])
def power(a,n):
 r=ONE
 while n:
  if n&1:r=mul(r,a)
  a=mul(a,a);n//=2
 return r
def inv(a):
 assert a!=Z
 r=power(a,5**18-2)
 assert mul(a,r)==ONE
 return r
def strip(a):
 while a and a[-1]==Z:a.pop()
 return a
def rem(a,b):
 a=list(a);b=list(b);ib=inv(b[-1])
 while len(a)>=len(b):
  c=mul(a[-1],ib);d=len(a)-len(b)
  for j in range(len(b)):a[j+d]=sub(a[j+d],mul(c,b[j]))
  strip(a)
 return a
def gcd(a,b):
 while b:a,b=b,rem(a,b)
 z=inv(a[-1]);return [mul(x,z) for x in a]
def val(a,x):
 r=Z
 for c in reversed(a):r=add(mul(r,x),c)
 return r
def resultant(a,b):
 a,b=list(a),list(b);r=ONE
 while len(b)>1:
  m,n=len(a)-1,len(b)-1
  c=rem(a,b)
  if not c:return Z
  k=len(c)-1
  r=mul(r,power(b[-1],m-k))
  if m*n%2:r=neg(r)
  a,b=b,c
 if not b:return Z
 return mul(r,power(b[0],len(a)-1))
base=Path(__file__).parent
u13=json.load(open(base/'u13.json'))['coefficients_v_x_eta']
f=strip([tuple(row[0]) for row in u13])
fd=[sc(f[i],i) for i in range(1,len(f))]
g=gcd(f,fd)
eta=(0,1)+(0,)*16
assert power(eta,27)==ONE and power(eta,9)!=ONE
# Phi27 is irreducible because ord_27(5)=18.
order=next(k for k in range(1,19) if pow(5,k,27)==1)
assert order==18
points=[]
for j in range(27):
 # z=-eta^j -> v=eta^j-1
 v=sub(power(eta,j),ONE);r=val(f,v)
 assert r!=Z
 points.append({'j':j,'value_U13_at_minus_eta_j':r})
res=resultant(f,fd)
disc=sc(res,-1 if ((len(f)-1)*(len(f)-2)//2)%2 else 1)
disc=mul(disc,inv(f[-1]))
assert len(g)==1 and res!=Z
mine=json.load(open(base/'u1687_independent.json'))['coefficients_v_x_eta']
primary=json.load(open(base.parent/'center0_full.json'))
other={(v,x):tuple(c) for x,v,c in primary['coefficients']}
assert primary['max_x']>=99 and primary['max_raw_v']>=100
matches=sum(tuple(mine[v][x])==other.get((v,x),Z) for v in range(100) for x in range(100))
assert matches==10000
valuations=[]
for v,row in enumerate(mine):
 xs=[x for x,c in enumerate(row) if any(c)]
 valuations.append(min(xs) if xs else None)
pts=[(v,x) for v,x in enumerate(valuations) if x is not None]
hull=[]
for p in pts:
 while len(hull)>=2:
  a,b=hull[-2:]
  if (b[0]-a[0])*(p[1]-b[1])-(b[1]-a[1])*(p[0]-b[0])>0:break
  hull.pop()
 hull.append(p)
report={'independent_generator':'rebuild.cpp','independent_output_sha256':hashlib.sha256((base/'u1687_independent.json').read_bytes()).hexdigest(),'primary_comparison_file':'center0_full.json','primary_output_sha256':hashlib.sha256((base.parent/'center0_full.json').read_bytes()).hexdigest(),'matched_coefficient_vectors':matches,'matched_F5_coordinates':matches*18,'nonzero_vectors':sum(any(c) for row in mine for c in row),'U_sign':'U=-H/v','small_signed_recurrence_checks':'m=0..6 exact equality before projection','x_valuations_by_v':valuations,'lower_newton_hull':hull,'u13_degree':len(f)-1,'u13_squarefree_gcd':g,'u13_discriminant':disc,'field_order':5**18,'ord27_5':order,'u13_nonvanishing_points':points}
json.dump(report,open(base/'verification.json','w'),indent=2)
print(json.dumps({k:v for k,v in report.items() if k not in ('u13_nonvanishing_points','x_valuations_by_v')},indent=2))
# Rebuild R6( w ; eta ) afresh in the field and test exact reciprocal discriminant identity.
def padd(a,b):
 c=[Z]*max(len(a),len(b))
 for i in range(len(c)):c[i]=add(a[i] if i<len(a) else Z,b[i] if i<len(b) else Z)
 return strip(c)
def pscale(a,c):return strip([mul(x,c) for x in a])
def pmul(a,b):
 c=[Z]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]=add(c[i+j],mul(x,y))
 return strip(c)
a=[];b=[ONE]
for m in range(1,7):
 c0=add(sc(ONE,-2),add(power(eta,2*m),power(eta,2*m-1)))
 c1=neg(mul(sub(ONE,power(eta,2*m-1)),sub(ONE,power(eta,2*m-2))))
 c=padd(pmul([c0,ONE],b),pscale(a,c1))
 a,b=b,c
R=b;Rp=[sc(R[i],i) for i in range(1,len(R))]
dr=mul(sc(resultant(R,Rp),-1 if (6*5//2)%2 else 1),inv(R[-1]))
endpoint_res=mul(val(R,Z),val(R,sc(ONE,4))) # degree even; Res(R,w(w-4))=R(0)R(4).
rhs=mul(mul(dr,dr),endpoint_res)
assert rhs==disc
report['u13_reciprocal_discriminant_identity_verified']=True
report['r6_discriminant']=dr
report['r6_endpoint_resultant']=endpoint_res
json.dump(report,open(base/'verification.json','w'),indent=2)
print('Positive-sign reciprocal discriminant identity verified on U13.')
# Direct independent H_n(1;eta) recurrence certifies the other reciprocal endpoint.
etap=[power(eta,j) for j in range(27)]
a,b=ONE,sc(ONE,2)
for n in range(2,1688):
 a,b=b,sub(sc(b,2),mul(sub(ONE,etap[(n-1)%27]),a))
U1=sc(b,3) # divide by 2 in F5
assert U1!=Z
assert U1==sc(val(f,sc(ONE,-2)),pow(2,62,5))
report['u1687_at_z1_mod_pi']=U1
report['r843_at_w4_is_unit']=True
report['r843_at_w0_exact_pi_valuation']=75
report['reciprocal_endpoint_resultant_exact_pi_valuation']=75
report['global_discriminant_identity_valuation']='v_pi(Disc U1687)=2*v_pi(Disc R843)+75 (extended to infinity if zero)'
json.dump(report,open(base/'verification.json','w'),indent=2)
print('R843(4) unit and R843(0) valuation75: endpoint resultant valuation75 exactly.')
from fractions import Fraction
from itertools import combinations
radii=[Fraction(5,2)]*10+[Fraction(1)]*40+[Fraction(9,10)]*10+[Fraction(1,2)]*2
annular_bound=2*sum(min(a,b) for a,b in combinations(radii,2))
assert annular_bound==3687
report['shared_annular_root_counts']=[{'valuation_pi':'5/2','count':10},{'valuation_pi':'1','count':40},{'valuation_pi':'9/10','count':10},{'valuation_pi':'1/2','count':2}]
report['shared_degree62_discriminant_lower_bound_from_annuli_only']=int(annular_bound)
json.dump(report,open(base/'verification.json','w'),indent=2)
