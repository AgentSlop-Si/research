"""Independent reviewer checks: fresh arithmetic only, no imported author programs."""
from pathlib import Path
import json, math, hashlib, datetime, sys
from fractions import Fraction
P=Path(__file__).resolve().parent
SRC=P.parent/'q29_bounded_candidate'
Z=(0,)*18; ONE=(1,)+(0,)*17

def add(a,b):return tuple((x+y)%5 for x,y in zip(a,b))
def scale(a,c):return tuple(x*c%5 for x in a)
def shift(a,n):
 a=list(a)
 for _ in range(n%27):
  lead=a[-1];a=[0]+a[:-1];a[0]=-lead%5;a[9]=(a[9]-lead)%5
 return tuple(a)
def mul(a,b):
 c=[0]*35
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 for i in range(34,17,-1):c[i-9]-=c[i];c[i-18]-=c[i]
 return tuple(x%5 for x in c[:18])
def power(a,n):
 r=ONE
 while n:
  if n&1:r=mul(r,a)
  a=mul(a,a);n>>=1
 return r
def inverse(a):
 assert a!=Z
 return power(a,5**18-2)
def clean(a):
 while a and a[-1]==Z:a.pop()
 return a
def remain(a,b):
 a=a[:]; ib=inverse(b[-1])
 while len(a)>=len(b):
  c=mul(a[-1],ib);off=len(a)-len(b)
  for j,x in enumerate(b):a[off+j]=add(a[off+j],scale(mul(c,x),-1))
  clean(a)
 return a
def pgcd(a,b):
 while b:a,b=b,remain(a,b)
 return [mul(x,inverse(a[-1])) for x in a]
def evaluate(a,x):
 s=Z
 for c in a[::-1]:s=add(mul(s,x),c)
 return s
def readraw(path):
 j=json.loads(path.read_text());return {(a,b):tuple(v) for a,b,v in j['coefficients']}
def lower_hull(points):
 out=[]
 for p in sorted(points):
  while len(out)>1:
   a,b=out[-2:]
   if (b[0]-a[0])*(p[1]-b[1]) > (b[1]-a[1])*(p[0]-b[0]):break
   out.pop()
  out.append(p)
 return out
own=readraw(P/'recomputed.json')
author=readraw(SRC/'fresh/center0_full.json')
assert own==author
assert len(own)==7818
vals={b:min(a for a,bb in own if bb==b) for b in range(100)}
h=lower_hull(vals.items());negative=[p for i,p in enumerate(h) if i==0 or p[1]<h[i-1][1]]
assert negative==[(0,75),(10,50),(50,10),(60,1),(62,0)]
A=own[50,10]
assert own[75,0]==scale(A,-1)
assert min(a+b for a,b in own)==60
face={b:c for (a,b),c in own.items() if a+b==60}
assert face=={10:A,30:scale(A,3),50:A}
# From (Y^4-1)^10=(Y^20-1)^2 over F5.
normalized={(a+b-60,b):c for (a,b),c in own.items() if a+b<100}
translations=[]
for c in range(5):
 translated={}
 for (a,b),v in normalized.items():
  for k in range(b+1):
   factor=math.comb(b,k)*pow(c,b-k,5)%5
   if factor:translated[a,k]=add(translated.get((a,k),Z),scale(v,factor))
 translated={key:v for key,v in translated.items() if v!=Z}
 p0=min(a for (a,b) in translated if b==0)
 slope=Fraction(p0,10)
 assert all(a+b*slope>=p0 for (a,b) in translated)
 edge={b:v for (a,b),v in translated.items() if a+b*slope==p0}
 coeffs={b:mul(v,inverse(A)) for b,v in edge.items()}
 scalars={b:v[0] for b,v in coeffs.items()}
 assert all(v[1:]==(0,)*17 for v in coeffs.values())
 expected={0:4,10:1} if c in (0,1) else ({0:4,5:4,10:1} if c==3 else {0:1,5:3,10:1})
 assert scalars==expected and all(b%5==0 for b in edge)
 translations.append({'c':c,'v_constant':p0,'root_radius':str(slope),'divided_face':scalars,'precision_exclusive':40-p0})
# A different fresh finite-field routine for the endpoint z=1.
a,b=ONE,scale(ONE,2)
for n in range(2,1688):a,b=b,add(scale(b,2),add(scale(a,-1),shift(a,n-1)))
endpoint=scale(b,3)
assert endpoint!=Z
# Exact H13 polynomial; coefficient symmetry certifies the persistent linear factor.
a,b=[ONE],[ONE,ONE]
for n in range(2,14):
 nxt=[Z]*(n+1)
 for i,x in enumerate(b):nxt[i]=add(nxt[i],x);nxt[i+1]=add(nxt[i+1],x)
 for i,x in enumerate(a):nxt[i+1]=add(nxt[i+1],add(scale(x,-1),shift(x,n-1)))
 a,b=b,nxt
assert b==b[::-1]
u=[b[0]]
for c in b[1:-1]:u.append(add(c,scale(u[-1],-1)))
assert b[-1]==u[-1]==ONE
assert len(u)==13
ud=[scale(x,i) for i,x in enumerate(u) if i>0]
assert pgcd(u,ud)==[ONE]
points=[evaluate(u,scale(shift(ONE,j),-1)) for j in range(27)]
assert all(x!=Z for x in points)
assert endpoint==scale(evaluate(u,ONE),pow(2,62,5))
assert next(d for d in range(1,19) if pow(5,d,27)==1)==18
# Pairwise-difference derivation of the local lower bound, not just grouped totals.
radii=[Fraction(5,2)]*10+[Fraction(1)]*40+[Fraction(9,10)]*10+[Fraction(1,2)]*2
baseline=2*sum(min(radii[i],radii[j]) for i in range(62) for j in range(i+1,62))
extra=sum(10*9*Fraction(t['root_radius']) for t in translations[1:])
assert baseline==3687 and extra==405 and baseline+extra==4092
# Exact symbolic controls for signs and standard discriminant normalization.
import sympy as s
z,w,Y,u0,u1=s.symbols('z w Y u0 u1')
Q0=z*z+(2-u0)*z+1;Q1=z*z+(2-u1)*z+1
assert s.factor(s.resultant(Q0,Q1,z))==(u0-u1)**2
assert s.expand(s.discriminant(Q0,z)-u0*(u0-4))==0
R=w**3+2*w**2+3*w+7
U=s.Poly(s.cancel(z**3*R.subs(w,(1+z)**2/z)),z).as_expr()
assert s.discriminant(U,z)==s.discriminant(R,w)**2*R.subs(w,0)*R.subs(w,4)
F=9*U.subs(z,5*Y+2)
assert s.discriminant(F,Y)==9**10*5**30*s.discriminant(U,z)
scaling=1686*1685-60*(2*1686-2)
assert scaling==2638710
out={'verdict':'PASS_BOUNDED_ONLY','fresh_vectors_matched':10000,'fresh_coordinates_matched':180000,'nonzero_vectors':len(own),'negative_newton_vertices':negative,'A':A,'normalization_degree':1686,'residue_degree':50,'normalization_precision_exclusive':40,'translated_faces':translations,'R0_valuation':75,'R4_unit_residue':endpoint,'U13_degree':12,'U13_squarefree':True,'U13_disjoint_from_27_centers':True,'full_discriminant_scaling':scaling,'classical_reciprocal_identity_verified_symbolically':True,'shared_local_baseline':int(baseline),'shared_local_extra_lower_bound':int(extra),'shared_local_lower_bound':int(baseline+extra),'no_full_valuation_or_nonvanishing_claim':True,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(P/'CHECK_RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
