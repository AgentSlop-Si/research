// Independent reviewer implementation, 2026-10-14.
// Direct H recurrence in F5[eta]/Phi27, with q powers as iterated sparse factors.
// No author source is imported or executed.
#include <array>
#include <vector>
#include <fstream>
#include <chrono>
#include <iostream>
using namespace std;
const int X=100,V=101,E=18;
using T=vector<unsigned char>;
int ix(int b,int a,int e){return (b*X+a)*E+e;}
int main(int argc,char**argv){
 auto start=chrono::steady_clock::now();
 int target=argc>1?stoi(argv[1]):1687;
 T h0(V*X*E),h1(V*X*E),tmp(V*X*E),qv(V*X*E);
 h0[0]=1;h1[ix(1,0,0)]=4;
 for(int n=2;n<=target;n++){
  qv=h0;
  // eta multiplication in the degree18 field, avoiding group-algebra projection.
  for(int rep=0;rep<(n-1)%27;rep++)
   for(int b=0;b<V;b++)for(int a=0;a<X;a++){
    int at=ix(b,a,0),last=qv[at+17];
    for(int e=17;e>0;e--)qv[at+e]=qv[at+e-1];
    qv[at]=(5-last)%5;qv[at+9]=(qv[at+9]+5-last)%5;
   }
  int digits=n-1;
  for(int jump=1;jump<X;jump*=5){int d=digits%5;digits/=5;
   for(int rep=0;rep<d;rep++)for(int b=0;b<V;b++)for(int a=X-1;a>=jump;a--)for(int e=0;e<E;e++){
    int p=ix(b,a,e);qv[p]=(qv[p]+qv[p-jump*E])%5;
   }
  }
  for(int b=0;b<V;b++)for(int a=0;a<X;a++)for(int e=0;e<E;e++){
   int p=ix(b,a,e),s=h0[p]-qv[p];
   if(b)s+=h0[p-X*E]-qv[p-X*E]-h1[p-X*E];
   tmp[p]=(s+15)%5;
  }
  h0.swap(h1);h1.swap(tmp);
 }
 // Hodd(-1-v)=-v*Uodd(-1-v), hence coefficient shift and negation.
 cout<<"{\"n\":"<<target<<",\"max_x\":99,\"max_v\":99,\"coefficients\":[";
 bool first=true;
 for(int b=0;b<100;b++)for(int a=0;a<X;a++){
  bool nz=false;for(int e=0;e<E;e++)nz|=h1[ix(b+1,a,e)]!=0;
  if(!nz)continue;if(!first)cout<<",";first=false;
  cout<<"["<<a<<","<<b<<",[";
  for(int e=0;e<E;e++){if(e)cout<<",";cout<<(5-h1[ix(b+1,a,e)])%5;}
  cout<<"]]";
 }
 cout<<"]}\n";
 for(int a=0;a<X;a++)for(int e=0;e<E;e++)if(h1[ix(0,a,e)]!=0)return 2;
 cerr<<"seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
}
