FFT RESEARCH: FINITE REPACKING CANDIDATE WITH NOVELTY CORRECTION
13 October 2026

Correction after reviewing PR624 and PR623
=========================================
The user correctly identified prior work using the same owner-repacking
approach. This package does not establish a novel algorithm or theory.
Its particular placement differs from PR624, but that does not establish
algorithmic novelty. The approach already appears in PR620 and PR624.
ALG-022/F096 was not used to obtain this finite packing improvement.

Native-complex saving b (larger is better for this cost model):
  PR624:          0.001638104468552563164027
  This candidate: 0.001638113483700526508299
  PR623:          0.001638169876460961469484

PR623 therefore has a stronger reported finite complex saving than this
candidate. It uses the same PR622 construction with ck x8 / jp8 x64;
this candidate and PR624 retain ck x7 / jp8 x65. Both PRs report fresh
64-stage upstream replays. This package did not perform that full replay.
The prior comparison against PR622 alone was insufficient to claim that
we had beaten the strongest available comparable result.

These b values are not integer-multiplication kappa values. No unconditional
full FFT runtime or practical speedup follows from this comparison.
The finite arithmetic result below is retained, but the requested novel
full FFT algorithm beating the best comparable bound remains unachieved.

Sources:
  https://github.com/CrocSwap/integer-mult-bounds/pull/624
  commit 036753ed33d4e620932262646e3d02a1927256a6
  https://github.com/CrocSwap/integer-mult-bounds/pull/623
  commit e39a615ca601ce5d62abeb24f3fcdb8644ca1005
PR623_PR624_COMPARISON.json retains the exact source parameters and scope.

Result
======
A locally found helper assignment satisfies the source-bound placement problem
of CrocSwap PR622 and strictly improves its native complex cost moment.
This is a finite placement-and-cost certificate. The complete upstream
admission, fresh finite invoice, and all-size FFT theorem are not established
by this package. Do not describe it as a completed FFT breakthrough.

Baseline source
===============
https://github.com/CrocSwap/integer-mult-bounds/pull/622
Source repository: jeremykothe2/integer-mult-bounds
Commit: f69477f4f6d3c7eb1f740b166881bffed4ffa9f6
Package: research/complex-571-cold14-k492

The 492-helper K-triangle construction, the local providers, their arithmetic,
Clifford identities, and the original owner geometry are other people's work.
Detailed upstream credits and inherited hypotheses are in pr622/NOTICE.md.
The source Git blobs of PLAN, OWNERS, and EXPECTED are checked independently.

Our construction
================
Keep the 65 jp8 and 7 ck calls, call order, every helper's width, and every
local provider unchanged. Repack a bounded neighborhood of 13 owner groups.
An integer pattern/flow problem discovers a proposed arrangement. Expand it
to individual ports and calls. Match port colours to existing ports to retain
placements where possible. Recompute every offset and every unused interval.

The resulting full map has 35,424 helper roles. Relative to the baseline,
752 roles change owner location; 1,377 serialized records change when offset
adjustments are counted. No helper disappears and no width is decreased.

The exact paid-profile change is

    H_new = H_old + e_1 - 4 e_3 + 2 e_16 - e_21,

where e_r means one recursive child of rank r. Rank mass is conserved:

    1 - 4*3 + 2*16 - 21 = 0.

Both profiles have mass 520704, live stock 7168, label dimension 73,
and deficit 73*7168 - 520704 = 2560.

Exact finite theorem
====================
For this source-bound placement problem, the new map obeys every supplied
idle-time window, the capacity and non-overlap constraints, contiguous packed
offsets, and one helper per physical family per complete call. All local
program hashes and width assignments remain equal to the pinned baseline.

Define

    Phi_H(b) = (1/7168) sum_r H[r] * (r/73)^(1-b).

Independent rational arithmetic certifies

    Phi_old(0.001638101302431117748332) < 1,
    Phi_old(0.001638101302431117748333) > 1,

    Phi_new(0.001638113483700526508299) < 1,
    Phi_new(0.001638113483700526508300) > 1.

The old profile also fails at the new accepted saving. These are strict
inequalities, not floating-point comparisons. The saving threshold improves
by approximately 1.218126940875997e-8. This compares exponent savings, not
measured CPU times.

Proof of the numerical assertions: each term is written as
  r*H[r]/(73*7168) * exp(b*log(73/r)).
Reduce logarithms to [1,2] and use
  log(x) = 2 sum_{j>=0} z^(2j+1)/(2j+1), z=(x-1)/(x+1).
The omitted positive tail after m terms is bounded above by
  2*z^(2m+1)/((2m+1)*(1-z^2)).
Outward rational rounding bounds logarithms. A positive Taylor expansion
and geometric tail bound enclose exp. Every comparison is made on Fraction
objects. Decimal report entries are rounded displays only. Phi is strictly
increasing in b because all positive ranks are smaller than 73. Thus the
two endpoint pairs enclose the respective unique moment thresholds.

Verification
============
From this directory, using Python 3 and its standard library:

    python verify_repacking.py pr622

The verifier imports neither the optimizer nor the expander. It checks both
complete maps, source binding, preserved fields, the entire rank ledger,
112 orthogonal port bases, the strict moment endpoints, and nine deliberately
corrupted inputs. All nine corruptions must be rejected. It works with Python
assertions disabled because admission uses explicit checks.

For search reproduction, numpy/scipy are needed. Discovery here used numpy
2.3.5 and scipy 1.17.0. The retained integer solution is sufficient to repeat
literal expansion; discovering it again is unnecessary for verification.

    FFT_OWNER_ROOT="$PWD/pr622" python region_mip.py 40 0
    FFT_OWNER_ROOT="$PWD/pr622" python expand_region.py pr622/region_0.pkl

The model is inspired by PR620's published pattern/flow search. Its port-flow
expansion routine is retained in vendor/expand617.py with upstream credit.
The optimizer's objective is a discovery heuristic; only the independent
literal map and exact moment checks certify the finite result.

Relation to our research
=======================
ALG-022/F096 supplies the classical q-Pascal Fourier factorization. The earlier
borrowed-register compiler candidate supplied an O(log^2 r) local layer bound.
Those are a possible all-length transfer route. They were not needed to prove
this finite repacking gain, and they should not receive credit for the external
E8/K-triangle construction. The delivered result is an explicit repacking
witness and its source-bound finite verification; novelty is not established.

Conditional full-FFT target, not a theorem established here
==========================================================
If the new supplier receives complete admission and an arbitrary-input,
uniform, fully charged tensor implementation with saving b_new, and the
earlier local compiler/transfer are validated in the same model, the proposed
fusion would give

    O(N*(log N)^(1-b_new)*(log log N)^(1+b_new)).

Taking any fixed saving below b_new absorbs the log-log factor. For example,
the target O(N*(log N)^0.99836189) uses saving 0.00163811, which is larger
than the pinned PR622 moment threshold and smaller than this candidate's.
This is a conditional consequence, not the measured or established runtime
of a new complete FFT implementation. Integer multiplication kappa is another
quantity; this package claims no new kappa.

The model is exact arithmetic with unrestricted coefficients. No floating-point
stability, practical speedup, or independently confirmed historical priority
is established.

Outstanding concrete gate
=========================
Starting at pinned PR622, replace the owner map and plan with these candidates;
regenerate the source-bound witness/expected records rather than weakening
admission; generate all actual phase/spectator routes; run the unchanged local
provider construction plus the full controller, fresh invoice, exact moment
engines, and outer assembly. The upstream common-label, whole-call hosting,
all-size compilation and analytic-transfer hypotheses remain separate.

The included verifier does not claim to have run that full pipeline, and its
result deliberately records those limits. A legal map and a better moment do
not alone discharge the missing algorithmic interfaces.

Authorship and novelty
======================
Research direction: the user in this conversation. Search, construction,
proof accounting and scripts: OpenAI Codex assistance. The inherited scalar
circuits, E8 geometry, K-triangle atom and original analytic framework belong
to the upstream authors. Repacking, Hall inequalities, bipartite matching and
rational interval arithmetic are established methods. This is a newly found
explicit candidate relative to a pinned baseline, not a claim that those
methods are new or that worldwide priority has been established. The
correction above supersedes any earlier suggestion of a novel algorithm
or an improvement over the strongest available comparable result.

An earlier two-swap improvement over PR617 was superseded during this session
by PR622. The main result above is computed against PR622, not PR617.
