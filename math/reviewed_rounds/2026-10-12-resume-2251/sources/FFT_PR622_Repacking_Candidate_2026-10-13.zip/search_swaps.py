"""Search legal, mass-preserving owner swaps on the pinned PR617 witness.
Source words are unchanged. This program validates placement only, not their
semantics or an all-size FFT. Only Python's standard library is required.
"""
import copy, gzip, hashlib, json, math, random, sys, time, os
from collections import Counter, defaultdict
from pathlib import Path

ROOT=Path(os.environ.get('FFT_OWNER_ROOT',str(Path(__file__).resolve().parent/'pr622')))
PLAN=json.loads((ROOT/'baseline/PLAN.json').read_text())
ORIGINAL=json.loads(gzip.decompress((ROOT/'baseline/OWNERS.json.gz').read_bytes()))
B=0.0016381  # Discovery score only; exact admission is in verify_repacking.py.

def score(r):
    return r*(73/r)**B if r else 0.0

class State:
    def __init__(self, rows):
        self.rows=copy.deepcopy(rows)
        self.bins={}
        self.where={}
        self.width=defaultdict(list)
        self.fam=defaultdict(set)
        for k,(cap,times) in PLAN['windows'].items():
            rep,child=map(int,k.split(','))
            for port in range(112):
                family=rep*896+(2*PLAN['pairs'][str(child)]+PLAN['sides'][str(child)])*112+port
                self.bins[rep,child,port]={'cap':cap,'win':set(times),'family':family,'items':set(),'load':0}
        for i,x in enumerate(self.rows):
            k=(x['owner_replica'],x['child'],x['port']); b=self.bins[k]
            b['items'].add(i);b['load']+=x['width'];self.where[i]=k
            self.width[x['width']].append(i);self.fam[x['time']].add(b['family'])
        self.moves=[]

    def remaining(self,k):
        b=self.bins[k];return b['cap']-b['load']

    def legal(self,i,j):
        ka,kb=self.where[i],self.where[j]
        if ka==kb:return False
        a,b=self.bins[ka],self.bins[kb]; x,y=self.rows[i],self.rows[j]
        ta,tb=x['time'],y['time'];wa,wb=x['width'],y['width']
        if a['load']-wa+wb>a['cap'] or b['load']-wb+wa>b['cap']:return False
        if tb not in a['win'] or ta not in b['win']:return False
        if ta!=tb and a['family']!=b['family']:
            if a['family'] in self.fam[tb] or b['family'] in self.fam[ta]:return False
        return True

    def swap(self,i,j,record=True):
        ka,kb=self.where[i],self.where[j];a,b=self.bins[ka],self.bins[kb]
        x,y=self.rows[i],self.rows[j];ta,tb=x['time'],y['time'];wa,wb=x['width'],y['width']
        if ta!=tb and a['family']!=b['family']:
            self.fam[ta].remove(a['family']);self.fam[tb].remove(b['family'])
            self.fam[ta].add(b['family']);self.fam[tb].add(a['family'])
        a['items'].remove(i);b['items'].remove(j);a['items'].add(j);b['items'].add(i)
        a['load']+=wb-wa;b['load']+=wa-wb;self.where[i],self.where[j]=kb,ka
        if record:self.moves.append([i,j])

    def remainders(self):
        return Counter(b['cap']-b['load'] for b in self.bins.values() if b['cap']>b['load'])

    def total(self):return sum(score(r)*n for r,n in self.remainders().items())

    def emit(self):
        rows=copy.deepcopy(self.rows)
        for (rep,child,port),b in self.bins.items():
            off=0
            for i in sorted(b['items'],key=lambda i:(rows[i]['time'],rows[i]['helper'])):
                rows[i].update(owner_replica=rep,child=child,port=port,copy=rep*112+port,
                               family=b['family'],offset=off)
                off+=rows[i]['width']
        return sorted(rows,key=lambda x:(x['time'],x['helper']))

def validate(rows):
    expected={(x['time'],h):(x['stage'],x['replica'],w) for x in PLAN['provider_calls']
              for h,w in enumerate(PLAN['provider_registry'][x['provider']]['widths'])}
    seen=set();fam=defaultdict(set);cells=defaultdict(set)
    def need(ok,msg):
        if not ok:raise ValueError(msg)
    for x in rows:
        role=(x['time'],x['helper']);need(role in expected and role not in seen,'role')
        seen.add(role);need(expected[role]==(x['stage'],x['replica'],x['width']),'width/call')
        r,c,p=x['owner_replica'],x['child'],x['port'];need(0<=p<112,'port')
        cap,win=PLAN['windows'][f'{r},{c}'];need(x['time'] in win,'window')
        family=r*896+(2*PLAN['pairs'][str(c)]+PLAN['sides'][str(c)])*112+p
        need(x['family']==family and x['copy']==r*112+p,'physical identity')
        need(family not in fam[x['time']],'one helper per family/call');fam[x['time']].add(family)
        ix=set(range(x['offset'],x['offset']+x['width']))
        need(x['offset']>=0 and x['offset']+x['width']<=cap,'capacity')
        need(not (ix&cells[r,c,p]),'overlap');cells[r,c,p].update(ix)
    need(seen==set(expected),'missing helper')
    rem=Counter()
    for k,(cap,win) in PLAN['windows'].items():
        r,c=map(int,k.split(','))
        for p in range(112):
            used=cells[r,c,p];need(used==set(range(len(used))),'fragmented offsets')
            if len(used)<cap:rem[cap-len(used)]+=1
    prof=Counter()
    for x in PLAN['provider_calls']:
        prof.update({int(k):v for k,v in PLAN['provider_registry'][x['provider']]['actual_paid_profile'].items()})
    prof.update(rem);need(sum(r*n for r,n in prof.items())==520704,'rank mass')
    return rem,prof

def run(seconds,seed):
    rng=random.Random(seed);s=State(ORIGINAL);initial=s.total();best=initial;start=time.monotonic()
    print('baseline',dict(s.remainders()),'score',initial,flush=True)
    bestrows=s.emit();attempt=0
    while time.monotonic()-start<seconds:
        attempt+=1
        partial=[k for k,b in s.bins.items() if 0<s.remaining(k)<b['cap']]
        rng.shuffle(partial);changed=False
        for ka in partial:
            rem=s.remaining(ka)
            if rem>5:continue
            aa=list(s.bins[ka]['items']);rng.shuffle(aa)
            candidates=[]
            for i in aa:
                w=s.rows[i]['width'];js=s.width.get(w+rem,[])
                # Exact same-time swaps first; then timing-compatible swaps.
                for j in js:
                    kb=s.where[j]
                    if kb==ka:continue
                    rb=s.remaining(kb)
                    if not s.legal(i,j):continue
                    if rb>0:
                        delta=score(0)+score(rb+rem)-score(rem)-score(rb)
                        if delta < -1e-10:candidates.append((delta,i,j))
            if candidates:
                _,i,j=min(candidates);s.swap(i,j);changed=True
                value=s.total()
                if value<best-1e-10:
                    best=value;bestrows=s.emit();remains,profile=validate(bestrows)
                    (ROOT/'candidate_rows.json').write_text(json.dumps(bestrows,separators=(',',':')))
                    (ROOT/'candidate_profile.json').write_text(json.dumps(dict(sorted(profile.items()))))
                    (ROOT/'swap_trace.json').write_text(json.dumps(s.moves))
                    print('IMPROVED',attempt,'gain',initial-best,'remainder',dict(remains),'moves',len(s.moves),flush=True)
                break
        if changed:continue
        # Transfer a defect through a full bin at no change in the rank profile.
        neutral=[]
        for ka in partial[:12]:
            rem=s.remaining(ka)
            if rem>5:continue
            for i in s.bins[ka]['items']:
                js=s.width.get(s.rows[i]['width']+rem,[])
                for j in rng.sample(js,min(250,len(js))):
                    if s.remaining(s.where[j])==0 and s.legal(i,j):neutral.append((i,j))
        if not neutral:break
        s.swap(*rng.choice(neutral))
        if attempt%50==0:print('search',attempt,'best_gain',initial-best,'elapsed',round(time.monotonic()-start,1),flush=True)
    print('DONE','seconds',time.monotonic()-start,'attempts',attempt,'gain',initial-best,flush=True)
    return bestrows

if __name__=='__main__':
    validate(ORIGINAL)
    run(float(sys.argv[1]) if len(sys.argv)>1 else 60,int(sys.argv[2]) if len(sys.argv)>2 else 20261013)
