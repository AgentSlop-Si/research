"""Independent literal placement and rational moment verifier for PR622 update.
No optimizer, expander, or search implementation is imported. Baseline local
circuits and physical windows are source-bound premises, not re-proved here.
Run: python verify_repacking.py pr622
"""
import copy,gzip,hashlib,json,sys
from collections import Counter,defaultdict
from fractions import Fraction as Q
from pathlib import Path
from moment_exact import moment_interval,decimal

ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'pr622'
COMMIT='f69477f4f6d3c7eb1f740b166881bffed4ffa9f6'
PLAN_BLOB='cfb370c8492460e69ac458db9eec8e39cfac5ef1'
OWNERS_BLOB='385dc67229c197cc7d3442ccb0cca895b4d240e1'
EXPECTED_BLOB='35a647dff387676e5494f90ef6a23e07e6dd247f'

def need(test,label):
    if not test:raise ValueError(label)
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def read(path):
    raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)

raw_plan=(ROOT/'baseline/PLAN.json').read_bytes()
raw_owners=(ROOT/'baseline/OWNERS.json.gz').read_bytes()
need(blob(raw_plan)==PLAN_BLOB,'baseline PLAN Git blob')
need(blob(raw_owners)==OWNERS_BLOB,'baseline OWNERS Git blob')
need(blob((ROOT/'baseline/EXPECTED.json').read_bytes())==EXPECTED_BLOB,'EXPECTED Git blob')
base=json.loads(raw_plan);old=json.loads(gzip.decompress(raw_owners))
newplan=read(ROOT/'candidate/PLAN.json');new=read(ROOT/'candidate/OWNERS.json.gz')
need(hashlib.sha256(raw_owners).hexdigest()==base['assignment_sha256'],'baseline assignment binding')
need(newplan['assignment_sha256']==hashlib.sha256((ROOT/'candidate/OWNERS.json.gz').read_bytes()).hexdigest(),'candidate assignment binding')
need(newplan['source_plan_sha256']==hashlib.sha256(raw_plan).hexdigest(),'candidate source plan binding')
need(newplan['source_owners_sha256']==hashlib.sha256(raw_owners).hexdigest(),'candidate source owners binding')
for key in ['order','windows','pairs','sides','provider_calls','per_call_widths','provider_registry','live','deficit','M','L','K','T']:
    need(newplan[key]==base[key],'changed protected baseline field '+key)

def validate(rows,plan):
    expected={}
    local=Counter()
    for call in plan['provider_calls']:
        t=call['time'];provider=plan['provider_registry'][call['provider']]
        need(plan['order'][t]==[call['stage'],call['replica']],'call order')
        need(len(provider['widths'])==492,'helper count')
        need(call['local_program_sha256']==provider['orientation_program_sha256'][call['orientation']],'program hash')
        local.update({int(r):n for r,n in provider['actual_paid_profile'].items()})
        for h,w in enumerate(provider['widths']):expected[t,h]=(call['stage'],call['replica'],w)
    need(len(rows)==len(expected)==35424,'literal role count')
    seen=set();families=defaultdict(list);intervals=defaultdict(list)
    for z in rows:
        role=z['time'],z['helper'];need(role in expected and role not in seen,'unique helper role');seen.add(role)
        need((z['stage'],z['replica'],z['width'])==expected[role],'helper width or call')
        r,c,p=z['owner_replica'],z['child'],z['port']
        need(isinstance(p,int) and 0<=p<112,'port')
        cap,window=plan['windows'][f'{r},{c}'];need(z['time'] in window,'idle time window')
        f=r*896+(2*plan['pairs'][str(c)]+plan['sides'][str(c)])*112+p
        need(z['family']==f and z['copy']==r*112+p,'physical family identity')
        need(0<=f<plan['live'],'live family range')
        families[z['time']].append(f)
        start,end=z['offset'],z['offset']+z['width']
        need(isinstance(start,int) and 0<=start<end<=cap,'capacity interval')
        intervals[r,c,p].append((start,end))
    need(seen==set(expected),'complete coverage')
    for t,fs in families.items():need(len(fs)==len(set(fs))==492,'call family exclusivity')
    idle=Counter()
    for key,(cap,window) in plan['windows'].items():
        r,c=map(int,key.split(','))
        for p in range(112):
            endpoint=0
            for start,end in sorted(intervals[r,c,p]):
                need(start==endpoint,'overlap or unpaid gap');endpoint=end
            if endpoint<cap:idle[cap-endpoint]+=1
    total=local+idle
    need(sum(r*n for r,n in total.items())==520704,'rank mass')
    need(73*plan['live']-sum(r*n for r,n in total.items())==2560,'deficit')
    need(dict(total)=={int(r):n for r,n in plan['profile'].items()},'claimed total profile')
    return total,idle

old_profile,old_idle=validate(old,base)
new_profile,new_idle=validate(new,newplan)
delta={r:new_profile[r]-old_profile[r] for r in set(old_profile)|set(new_profile) if new_profile[r]!=old_profile[r]}
need(delta=={1:1,3:-4,16:2,21:-1},'exact claimed improvement')

# Orthogonal-coordinate routing lemma: every permutation of a Gram-I basis
# remains Gram-I, so selecting distinct residual/spectator axes preserves
# orthogonality. The actual phase-recipe serialization is a separate gate.
ports=base['provider_registry']['jp8']['ports'];need(len(ports)==112,'ports')
for q in ports:
    z=next(i for i in range(9) if not(q>>i&1));a=q^(1<<z)
    order=list(range(9));order[z],order[0]=order[0],order[z]
    B=[(1<<i)^(a if a>>i&1 else 0) for i in order]+[1<<i for i in range(9,73)]
    need(len(B)==73 and all(((u&v).bit_count()%2)==int(i==j)
                           for i,u in enumerate(B) for j,v in enumerate(B)),'orthogonal port basis')

endpoints={
 'baseline_lower':'0.001638101302431117748332',
 'baseline_next':'0.001638101302431117748333',
 'candidate_lower':'0.001638113483700526508299',
 'candidate_next':'0.001638113483700526508300',
}
numbers={}
for key,a in endpoints.items():
    profile=new_profile if key.startswith('candidate') else old_profile
    lo,hi=moment_interval(profile,Q(a))
    if key.endswith('lower'):need(hi<1,key+' contraction')
    else:need(lo>1,key+' rejection')
    numbers[key]={'saving':a,'moment_minus_one_lower_rounded':decimal(lo-1),
                  'moment_minus_one_upper_rounded':decimal(hi-1)}
lo,hi=moment_interval(new_profile,Q(endpoints['baseline_lower']))
need(hi<1,'candidate at baseline endpoint')
old_at_new=moment_interval(old_profile,Q(endpoints['candidate_lower']))
need(old_at_new[0]>1,'old profile must fail at the new saving')

rejected=[]
def control(label,mutate_rows=None,mutate_plan=None):
    rs=copy.deepcopy(new);p=copy.deepcopy(newplan)
    if mutate_rows:mutate_rows(rs)
    if mutate_plan:mutate_plan(p)
    try:validate(rs,p)
    except (ValueError,KeyError,IndexError,TypeError):rejected.append(label)
    else:raise ValueError('accepted mutant '+label)
control('missing helper',lambda x:x.pop())
control('duplicate helper identity',lambda x:x.__setitem__(1,copy.deepcopy(x[0])))
control('wrong helper width',lambda x:x[0].__setitem__('width',x[0]['width']-1))
control('invalid port',lambda x:x[0].__setitem__('port',112))
control('wrong family',lambda x:x[0].__setitem__('family',x[0]['family']+1))
control('overflow offset',lambda x:x[0].__setitem__('offset',73))
control('omitted idle cost',mutate_plan=lambda p:p['profile'].__setitem__('16',1))
control('wrong local program',mutate_plan=lambda p:p['provider_calls'][0].__setitem__('local_program_sha256','0'*64))
def outside(x):
    for z in x:
        g=next((k for k,v in newplan['windows'].items() if z['time'] not in v[1]),None)
        if g:
            r,c=map(int,g.split(','));p=z['port'];z.update(owner_replica=r,child=c,copy=r*112+p,
              family=r*896+(2*newplan['pairs'][str(c)]+newplan['sides'][str(c)])*112+p);return
    raise ValueError('no outside-window mutant')
control('outside idle window',outside)

changed=[{'time':a['time'],'helper':a['helper'],'before':a,'after':b} for a,b in zip(old,new) if a!=b]
relocated=sum((a['owner_replica'],a['child'],a['port'])!=(b['owner_replica'],b['child'],b['port']) for a,b in zip(old,new))
report={'status':'PASS_SOURCE_BOUND_PLACEMENT_AND_EXACT_MOMENT_ONLY','source_pr':622,'source_commit':COMMIT,
 'helpers_per_call':492,'calls':72,'literal_roles':35424,'changed_records':len(changed),'relocated_roles':relocated,
 'old_profile':dict(sorted(old_profile.items())),'new_profile':dict(sorted(new_profile.items())),
 'delta':delta,'old_idle':dict(old_idle),'new_idle':dict(new_idle),'rank_mass':520704,'deficit':2560,
 'moments':numbers,'mutation_controls_rejected':rejected,'port_orthobases_checked':112,
 'old_profile_at_new_saving_rejected':True,
 'source_provider_registry_unchanged':True,
 'scope':{'local_source_words_replayed':False,'upstream_full_admission_run':False,
          'new_actual_phase_recipes_serialized':False,'finite_invoice_replayed':False,
          'all_size_fft_theorem':False,'historical_novelty_established':False},
 'conditional_implication':'If unchanged upstream realization and finite-overhead hypotheses cover this legal reassignment, the complex moment supports the strictly larger candidate saving.',
 'candidate_owners_sha256':newplan['assignment_sha256']}
(ROOT/'candidate/INDEPENDENT_CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
