"""Exact rational log/exp bounds from this conversation, for finite cost checks."""
from fractions import Fraction as Q
from functools import lru_cache
from decimal import Decimal, localcontext
import json

M, W = 73, 7168
H = {1: 181848, 2: 24770, 3: 31778, 4: 13728, 5: 5040,
     6: 1008, 7: 2, 8: 576, 48: 2150}
SCALE = 10**70


def require(condition, message):
    if not condition:
        raise ValueError(message)


def log_unit_interval(x, terms=90):
    """Enclose log(x), 1 <= x <= 2, by the positive atanh series."""
    require(Q(1) <= x <= 2, "log argument outside reduction interval")
    z = (x - 1) / (x + 1)
    z2, power, total = z*z, z, Q(0)
    for j in range(terms):
        total += 2*power / (2*j + 1)
        power *= z2
    remainder = 2*power / ((2*terms + 1)*(1-z2))
    return total, total + remainder


@lru_cache(None)
def log_ratio(r):
    x, k = Q(M, r), 0
    while x >= 2:
        x /= 2
        k += 1
    lo, hi = log_unit_interval(x)
    l2, u2 = log_unit_interval(Q(2))
    lo, hi = lo+k*l2, hi+k*u2
    # Outward rounding keeps rational Taylor denominators manageable.
    lower = (lo.numerator*SCALE)//lo.denominator
    upper = -((-hi.numerator*SCALE)//hi.denominator)
    return Q(lower, SCALE), Q(upper, SCALE)


def exp_interval(x, terms=24):
    """Enclose exp(x) for 0 <= x < 1 by Taylor plus a geometric tail."""
    require(Q(0) <= x < 1, "exp argument outside proved interval")
    total, term = Q(1), Q(1)
    for j in range(1, terms+1):
        term *= x/j
        total += term
    first_omitted = term*x/(terms+1)
    upper_tail = first_omitted/(1-x/(terms+2))
    return total, total+upper_tail


def moment_interval(profile, a):
    # Phi(a) = sum H[r] * (r/M)^(1-a) / W
    lo = hi = Q(0)
    for r, count in profile.items():
        require(0 < r < M and isinstance(count, int) and count >= 0,
                "invalid profile entry")
        l, u = log_ratio(r)
        elo, _ = exp_interval(a*l)
        _, ehi = exp_interval(a*u)
        weight = Q(r*count, M*W)
        lo += weight*elo
        hi += weight*ehi
    return lo, hi


def decimal(q):
    with localcontext() as c:
        c.prec = 45
        return str(Decimal(q.numerator)/Decimal(q.denominator))


def check(profile, endpoint, expected):
    a = Q(endpoint)
    lo, hi = moment_interval(profile, a)
    if expected == "accept":
        require(hi < 1, "strict contraction not certified")
    else:
        require(lo > 1, "strict rejection not certified")
    return {"saving": endpoint, "outcome": expected,
            "moment_minus_one_enclosure_rounded": [decimal(lo-1), decimal(hi-1)]}


