"""Bounded neighborhood packing, with literal expansion required separately.
Uses the pattern/flow model of PR620, on selected groups and fixed dispatch.
"""
import json,sys,time,random,itertools,pickle
from collections import Counter,defaultdict
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import coo_matrix
import search_swaps as S

seconds=float(sys.argv[1]);seed=int(sys.argv[2]);rng=random.Random(seed)
s=S.State(S.ORIGINAL);PLAN=S.PLAN;WID=[4,5,7,8,9]
bygroup=defaultdict(list)
for k,b in s.bins.items():bygroup[k[:2]].append(k)
partial=[]
for g,bs in bygroup.items():
    rems=[s.remaining(k) for k in bs]
    if any(0<r<s.bins[bs[0]]['cap'] for r in rems):partial.append(g)
if seed==0:active=partial
else:
    # Add full groups with complementary types and overlapping call windows.
    active=rng.sample(partial,min(5,len(partial)))
    full=[g for g in bygroup if g not in active]
    active+=rng.sample(full,5)
active=set(active)
basepatterns={};baseflows={};demand=Counter()
for g in active:
    pp=Counter();flow=Counter()
    for k in bygroup[g]:
        its=s.bins[k]['items'];pp[tuple(sorted(s.rows[i]['width'] for i in its))]+=1
        for i in its:flow[s.rows[i]['time'],s.rows[i]['width']]+=1
    basepatterns[g]=pp;baseflows[g]=flow;demand.update(flow)

def patterns(cap,L):
    out=[]
    def walk(pre,low,total):
        if cap-total<=3 or total==0:out.append(tuple(pre))
        for j in range(low,len(WID)):
            w=WID[j]
            if total+w<=cap and len(pre)<L:walk(pre+[w],j,total+w)
    walk([],0,0);return out

lo=[];hi=[];cost=[];rows=[];rl=[];rh=[]
def var(c,l,u):
    i=len(cost);cost.append(c);lo.append(l);hi.append(u);return i
def con(row,l,u):rows.append(row);rl.append(l);rh.append(u)
b=.0016381
def V(r):return (r*(73/r)**b-r*(73/48)**b)*1e6 if r else 0
groups={};inv=defaultdict(dict)
for g in sorted(active):
    key=f'{g[0]},{g[1]}';cap,times=PLAN['windows'][key]
    ps=sorted(set(patterns(cap,len(times)))|set(basepatterns[g]));cs=[Counter(q) for q in ps]
    pv=[var(V(cap-sum(q)),max(0,basepatterns[g][q]-4),min(112,basepatterns[g][q]+4)) for q in ps]
    con({i:1 for i in pv},112,112)
    fl={}
    for t in times:
        for w in WID:
            if demand[t,w]==0 or not any(c[w] for c in cs):continue
            old=baseflows[g][t,w];i=var(0,max(0,old-4),min(112,old+4))
            fl[t,w]=i;inv[t,w][i]=1
        # Necessary Hall inequalities retained from upstream discovery model.
        seen=set()
        for mask in range(1,32):
            ws={w for z,w in enumerate(WID) if mask>>z&1}
            ff=tuple(i for (tt,w),i in fl.items() if tt==t and w in ws)
            qq=tuple(i for i,c in zip(pv,cs) if any(c[w] for w in ws))
            if ff and (ff,qq) not in seen:
                row={i:1 for i in ff}
                for i in qq:row[i]=row.get(i,0)-1
                con(row,-np.inf,0);seen.add((ff,qq))
    for w in WID:
        row={i:1 for (t,ww),i in fl.items() if w==ww}
        for i,c in zip(pv,cs):
            if c[w]:row[i]=row.get(i,0)-c[w]
        if row:con(row,0,0)
    groups[key]={'cap':cap,'times':times,'ps':ps,'pv':pv,'fl':fl}
for k,n in demand.items():con(inv[k],n,n)
rr=[];cc=[];vv=[]
for z,row in enumerate(rows):
    for i,v in row.items():rr.append(z);cc.append(i);vv.append(v)
A=coo_matrix((vv,(rr,cc)),shape=(len(rows),len(cost))).tocsr()
print('region',sorted(active),'vars',len(cost),'cons',len(rows),flush=True)
begin=time.monotonic()
res=milp(np.array(cost),integrality=np.ones(len(cost)),bounds=Bounds(lo,hi),
 constraints=LinearConstraint(A,rl,rh),options={'time_limit':seconds,'mip_rel_gap':1e-9})
print('status',res.status,'elapsed',time.monotonic()-begin,'objective',res.fun,flush=True)
if res.x is None:sys.exit(0)
x=np.rint(res.x).astype(int)
if np.max(np.abs(res.x-x))>1e-5:raise ValueError('noninteger')
vals=A@x
if any(vals[i]<rl[i]-1e-7 or vals[i]>rh[i]+1e-7 for i in range(len(rows))):raise ValueError('constraints')
before=Counter();after=Counter()
for key,g in groups.items():
    gg=tuple(map(int,key.split(',')))
    for p,n in basepatterns[gg].items():before[g['cap']-sum(p)]+=n
    for p,i in zip(g['ps'],g['pv']):after[g['cap']-sum(p)]+=int(x[i])
gain=sum(V(r)*n for r,n in before.items())-sum(V(r)*n for r,n in after.items())
print('gain',gain,'before',dict(before),'after',dict(after),flush=True)
if gain>1e-6:
    out=S.ROOT/f'region_{seed}.pkl'
    out.write_bytes(pickle.dumps({'groups':groups,'x':x,'active':active,'gain':gain}))
    print('CANDIDATE',str(out),flush=True)
