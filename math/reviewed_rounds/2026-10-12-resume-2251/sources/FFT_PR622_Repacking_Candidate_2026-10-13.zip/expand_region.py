"""Expand a region candidate, using PR620's published exact-flow routine.
Every literal placement is then independently checked against the full PLAN.
"""
import ast,copy,gzip,hashlib,json,pickle,random,sys
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds,linear_sum_assignment
from scipy.sparse import coo_matrix,csr_matrix
from scipy.sparse.csgraph import maximum_flow
import search_swaps as S

vendor=Path(__file__).resolve().parent/'vendor/expand617.py'
tree=ast.parse(vendor.read_text())
fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='expand')
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(vendor),'exec'),globals())
WID=[4,5,7,8,9]
record=pickle.loads(Path(sys.argv[1]).read_bytes());groups,x=record['groups'],record['x']
active=record['active'];original=S.ORIGINAL;oldbins=defaultdict(list)
for i,r in enumerate(original):oldbins[r['owner_replica'],r['child'],r['port']].append(i)
slots=[]
for gi,(key,g) in enumerate(sorted(groups.items())):
    r,c=map(int,key.split(','))
    pats=[q for q,v in zip(g['ps'],g['pv']) for _ in range(int(x[v]))]
    if len(pats)!=112:raise ValueError('pattern count')
    flows={k:int(x[v]) for k,v in g['fl'].items() if x[v]}
    assigned=expand(pats,flows,gi)
    if Counter(z for a in assigned for z in a)!=Counter(flows):raise ValueError('flow expansion')
    # Rename port colours to retain as many original placements as possible.
    oldsets=[{(original[i]['time'],original[i]['width']) for i in oldbins[r,c,p]} for p in range(112)]
    overlap=np.array([[len(set(a)&b) for b in oldsets] for a in assigned])
    ii,jj=linear_sum_assignment(-overlap)
    renamed={int(i):int(j) for i,j in zip(ii,jj)}
    for p,a in enumerate(assigned):
        if len(set(t for t,w in a))!=len(a):raise ValueError('one call per owner')
        for t,w in a:slots.append((t,w,r,c,renamed[p]))
    print('expanded',key,'roles',sum(map(len,assigned)),flush=True)

rows=copy.deepcopy(original);pools=defaultdict(set);exact={}
for i,z in enumerate(rows):
    if (z['owner_replica'],z['child']) in active:
        pools[z['time'],z['width']].add(i)
        exact[z['time'],z['width'],z['owner_replica'],z['child'],z['port']]=i
chosen=[];remaining=[]
for t,w,r,c,p in slots:
    i=exact.get((t,w,r,c,p))
    if i is not None and i in pools[t,w]:
        chosen.append((i,r,c,p));pools[t,w].remove(i)
    else:remaining.append((t,w,r,c,p))
for t,w,r,c,p in remaining:
    i=min(pools[t,w]);pools[t,w].remove(i);chosen.append((i,r,c,p))
if any(pools.values()):raise ValueError('unassigned roles')
for i,r,c,p in chosen:
    rows[i].update(owner_replica=r,child=c,port=p,copy=r*112+p,
                   family=r*896+(2*S.PLAN['pairs'][str(c)]+S.PLAN['sides'][str(c)])*112+p)
bins=defaultdict(list)
for i,z in enumerate(rows):bins[z['owner_replica'],z['child'],z['port']].append(i)
for k,idx in bins.items():
    offset=0
    for i in sorted(idx,key=lambda j:(rows[j]['time'],rows[j]['helper'])):
        rows[i]['offset']=offset;offset+=rows[i]['width']
rows.sort(key=lambda z:(z['time'],z['helper']))
rem,profile=S.validate(rows)
packed=gzip.compress(json.dumps(rows,sort_keys=True,separators=(',',':')).encode(),mtime=0)
packed=packed[:9]+b'\xff'+packed[10:]
out=S.ROOT/'candidate';out.mkdir(exist_ok=True)
(out/'OWNERS.json.gz').write_bytes(packed)
plan=copy.deepcopy(S.PLAN)
plan.update(status='RESEARCH_CANDIDATE_LITERAL_PLACEMENT_CHECKED_NOT_FULL_PIPELINE_ADMITTED',
            source_plan_sha256=hashlib.sha256((S.ROOT/'baseline/PLAN.json').read_bytes()).hexdigest(),
            source_owners_sha256=hashlib.sha256((S.ROOT/'baseline/OWNERS.json.gz').read_bytes()).hexdigest(),
            assignment_sha256=hashlib.sha256(packed).hexdigest(),profile={str(r):n for r,n in sorted(profile.items())})
(out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
(out/'PROFILE.json').write_text(json.dumps(dict(sorted(profile.items())),indent=2)+'\n')
diff=[]
for a,b in zip(original,rows):
    if a!=b:diff.append({'time':a['time'],'helper':a['helper'],'before':a,'after':b})
(out/'CHANGES.json').write_text(json.dumps(diff,indent=2)+'\n')
print('PLACEMENT_PASS','profile',dict(sorted(profile.items())),'remainders',dict(rem),'changed_records',len(diff),flush=True)
