#!/usr/bin/env python3
"""Self-contained exact finite-field recovery verifier.

Research goal: exact fresh-input O(N) / o(N log log N) DFT.
What is tested here: (1) an O(N) two-orientation globally dense q-torus
operator, NOT a Fourier transform; (2) full-order scalar moment recurrences
for the older stationary de Bruijn Fourier operator Q_N.

Only Python 3 standard library. No floating-point or FFT package.
"""
import json
from pathlib import Path
from math import ceil, log2

P = 65537
GEN = 3


def root_of_order(n):
    assert n > 1 and (P - 1) % n == 0 and n & (n - 1) == 0
    z = pow(GEN, (P - 1) // n, P)
    assert pow(z, n, P) == 1 and pow(z, n // 2, P) != 1
    return z


def inv(x):
    x %= P
    assert x != 0
    return pow(x, P - 2, P)


def qtorus_denominator(y, m, q, alpha, beta):
    return [
        (y[a*m+c] - alpha*y[((a-1)%m)*m+c]
         - beta*pow(q, a, P)*y[a*m+(c-1)%m]) % P
        for a in range(m) for c in range(m)
    ]


def cycle_solve(row, gamma, invden):
    """Solve z_c - gamma z_{c-1} = row[c] with cyclic boundary, O(m)."""
    tmp_end = 0
    for x in row:
        tmp_end = (x + gamma*tmp_end) % P
    boundary = tmp_end*invden % P
    out = []
    prev = boundary
    for x in row:
        prev = (x + gamma*prev) % P
        out.append(prev)
    assert out[-1] == boundary
    return out


def qtorus_solve(rhs, m, q, alpha, beta):
    """Two passes of m cyclic Green scans, O(N=m*m) scalar work."""
    assert len(rhs) == m*m
    Bm = pow(beta, m, P)
    Am = pow(alpha, m, P)
    assert Bm != 1 and (1-Bm-Am) % P != 0
    invden = inv(1-Bm)
    boundary_gain = (1-Bm)*inv(1-Bm-Am) % P
    phases = [pow(q, a, P) for a in range(m)]

    prev = [0]*m
    for a in range(m):
        row = [(rhs[a*m+c] + alpha*prev[c]) % P for c in range(m)]
        prev = cycle_solve(row, beta*phases[a] % P, invden)
    boundary = [x*boundary_gain % P for x in prev]

    prev = boundary
    out = [0]*(m*m)
    for a in range(m):
        row = [(rhs[a*m+c] + alpha*prev[c]) % P for c in range(m)]
        prev = cycle_solve(row, beta*phases[a] % P, invden)
        out[a*m:(a+1)*m] = prev
    assert prev == boundary
    return out


def phi_permutation(m):
    # phi(a,c) = (-c,a+c) modulo m
    return [((-c) % m)*m + (a+c) % m
            for a in range(m) for c in range(m)]


def two_conjugate_apply(x, m, q, alpha=7, beta=11, lam=2):
    n = m*m
    phi = phi_permutation(m)
    first = qtorus_solve(x, m, q, alpha, beta)
    permuted = [0]*n
    for j in range(n):
        permuted[phi[j]] = x[j]
    second = qtorus_solve(permuted, m, q, alpha, beta)
    return [(first[j] + lam*second[phi[j]]) % P for j in range(n)]


def dense_matrix_from_apply(apply, n):
    out = [[0]*n for _ in range(n)]
    for j in range(n):
        e = [0]*n
        e[j] = 1
        y = apply(e)
        for i, val in enumerate(y):
            out[i][j] = val
    return out


def rank_mod(A):
    a = [row[:] for row in A]
    n = len(a)
    m = len(a[0])
    r = 0
    for c in range(m):
        pivot = next((i for i in range(r, n) if a[i][c]), None)
        if pivot is None:
            continue
        a[r],a[pivot] = a[pivot],a[r]
        x = inv(a[r][c])
        row = a[r]
        for j in range(c,m):
            row[j] = row[j]*x % P
        for i in range(r+1,n):
            factor = a[i][c]
            if factor:
                other = a[i]
                for j in range(c,m):
                    other[j] = (other[j]-factor*row[j]) % P
        r += 1
        if r == n:
            break
    return r


def inverse_mod(A):
    n = len(A)
    M = [row[:] + [int(i==j) for j in range(n)]
         for i,row in enumerate(A)]
    for c in range(n):
        pivot = next((i for i in range(c,n) if M[i][c]), None)
        if pivot is None:
            return None
        M[c],M[pivot] = M[pivot],M[c]
        row = M[c]
        z = inv(row[c])
        for j in range(c,2*n):
            row[j] = row[j]*z % P
        for i in range(n):
            if i == c:
                continue
            other = M[i]
            factor = other[c]
            if factor:
                for j in range(c,2*n):
                    other[j] = (other[j]-factor*row[j]) % P
    return [row[n:] for row in M]


def check_support_cover(m):
    tri = lambda a,b: a+b < m
    assert m > 1
    uncovered = []
    for u in range(m):
        for v in range(m):
            in_t = tri(u,v)
            in_phi_t = tri((-v)%m, (u+v)%m)
            if not (in_t or in_phi_t):
                uncovered.append((u,v))
    assert not uncovered
    # One original q-torus Green has exactly m(m+1)/2 nonzero displacements.
    assert sum(u+v < m for u in range(m) for v in range(m)) == m*(m+1)//2
    return m*m


def run_two_resolvents():
    cases = []
    for m in [2,4,8,16]:
        n = m*m
        q = root_of_order(m)
        root_n = root_of_order(n)
        assert pow(root_n, m, P) == q
        check_support_cover(m)
        # Exact arbitrary-RHS solver control, on *every basis vector*.
        for j in range(n):
            e = [0]*n
            e[j] = 1
            y = qtorus_solve(e,m,q,7,11)
            assert qtorus_denominator(y,m,q,7,11) == e

        S = dense_matrix_from_apply(
            lambda x: two_conjugate_apply(x,m,q), n)
        nz = sum(x != 0 for row in S for x in row)
        assert nz == n*n
        Si = inverse_mod(S)
        assert Si is not None
        inverse_zeros = sum(x == 0 for row in Si for x in row)
        assert inverse_zeros == 0

        e = [[(S[i][(j+1)%n] - pow(root_n,i,P)*S[i][j]) % P
              for j in range(n)] for i in range(n)]
        defect_rank = rank_mod(e)
        assert defect_rank == n

        # Necessary for ALL monomially equivalent Fourier matrices:
        # every nonzero 2x2 cross ratio must be an n-th root of unity.
        ratio = S[0][0]*S[1][1]*inv(S[0][1]*S[1][0]) % P
        ratio_n = pow(ratio, n, P)
        assert ratio_n != 1

        # All these modular nonzero witnesses lift to characteristic zero
        # when q is replaced by a primitive complex m-th root, since every
        # entry/denominator is a cyclotomic rational function with good reduction.
        record = {
            'm':m, 'N':n, 'nonzero_transfer_entries':nz,
            'nonzero_inverse_entries':n*n,
            'weyl_defect_rank':defect_rank,
            'cross_ratio_mod_p':ratio,
            'cross_ratio_power_N_mod_p':ratio_n,
            'Fourier_equivalent':False,
        }
        cases.append(record)
        print(f"TWO-RESOLVER PASS N={n}: dense S, dense inverse, "
              f"rank(Weyl defect)={defect_rank}, cross-ratio fails")
    return cases



def run_explicit_bounded_coefficients():
    """Good-prime exact checks for the all-m small rational construction.

    The all-complex-size proof uses Archimedean bounds in THEOREM.md.
    Modular checks are finite corroboration, not a substitute for it.
    """
    global P, GEN
    old_prime,old_gen=P,GEN
    P=998244353
    GEN=3
    records=[]
    try:
        for m in [2,4,8,16]:
            n=m*m
            q=root_of_order(m)
            alpha=beta=inv(4)
            K=(2*m-1).bit_length() # ceil(log2(2m)); for dyadic m exact
            assert 2**K>=2*m
            L=m*K+4
            lam=inv(pow(2,L,P))
            S=dense_matrix_from_apply(
                lambda x:two_conjugate_apply(x,m,q,alpha,beta,lam),n)
            assert all(v for row in S for v in row)
            Si=inverse_mod(S)
            assert Si is not None
            iz=sum(v==0 for row in Si for v in row)
            assert iz==0
            records.append({'N':n,'m':m,'lambda_denominator_power_of_2':L,
                            'all_nonzero_mod_prime':True,
                            'all_inverse_entries_nonzero_mod_prime':True})
            print(f"EXPLICIT-SMALL-COEFF PASS N={n}, lambda=2^-{L}")
    finally:
        P,GEN=old_prime,old_gen
    return records


def Q_apply(x, roots):
    n = len(x)
    half = n//2
    y = [0]*n
    for r in range(half):
        u=x[r];v=x[r+half]
        y[2*r] = (u+v)%P
        y[2*r+1] = roots[r]*(u-v)%P
    return y


def bit_reverse(k,bits):
    out=0
    for _ in range(bits):
        out=(out<<1)|(k&1)
        k>>=1
    return out


def digital_phase(k):
    phase=0
    while k:
        if k&1:
            phase += (k>>1)
        k>>=1
    return phase


def check_stationary_fourier(n):
    # Matrix equality checked on every input basis vector, research-only.
    root=root_of_order(n)
    table=[pow(root,r,P) for r in range(n//2)]
    bits=n.bit_length()-1
    for j in range(n):
        e=[0]*n;e[j]=1
        x=e
        for _ in range(bits):
            x=Q_apply(x,table)
        for k in range(n):
            r=bit_reverse(k,bits)
            val=x[r]*pow(root,(-digital_phase(r))%n,P)%P
            assert val==pow(root,(k*j)%n,P)


def berlekamp_massey(seq):
    C=[1];B=[1];L=0;m=1;b=1
    for t in range(len(seq)):
        d=seq[t]
        for j in range(1,L+1):
            d=(d+C[j]*seq[t-j])%P
        if d==0:
            m+=1
            continue
        old=C[:]
        k=d*inv(b)%P
        if len(C)<len(B)+m:
            C += [0]*(len(B)+m-len(C))
        for j,v in enumerate(B):
            C[j+m]=(C[j+m]-k*v)%P
        if 2*L<=t:
            L=t+1-L
            B=old;b=d;m=1
        else:
            m+=1
    return L,C


def trim(A):
    while A and A[-1]==0:
        A.pop()
    return A


def poly_remainder(A,B):
    A=trim(A[:]);B=trim(B[:])
    assert B
    inv_lead=inv(B[-1])
    while len(A)>=len(B) and A:
        z=A[-1]*inv_lead%P
        off=len(A)-len(B)
        for j,v in enumerate(B):
            A[off+j]=(A[off+j]-z*v)%P
        trim(A)
    return A


def poly_gcd(A,B):
    while B:
        A,B=B,poly_remainder(A,B)
    return A


def Q_moments(n):
    omega=root_of_order(n)
    roots=[pow(omega,r,P) for r in range(n//2)]
    x=[0]*n;x[0]=1
    seq=[]
    for _ in range(2*n):
        seq.append(x[0])
        x=Q_apply(x,roots)
    return seq


def run_Q_spectrum():
    cases=[]
    for n in [2,4,8,16,32,64,128,256,512,1024]:
        if n<=64:
            check_stationary_fourier(n)
        seq=Q_moments(n)
        order,C=berlekamp_massey(seq)
        assert order==n and len(C)==n+1
        for t in range(n,2*n):
            assert sum(C[j]*seq[t-j] for j in range(n+1)) % P==0
        minimal=C[::-1]
        derivative=[j*minimal[j]%P for j in range(1,len(minimal))]
        gcd=poly_gcd(minimal, derivative)
        assert len(gcd)==1  # squarefree characteristic polynomial
        cases.append({'N':n, 'minimal_recurrence_order':order,
                      'minimal_polynomial_squarefree_mod_65537':True,
                      'checked_all_Fourier_basis_vectors':n<=64})
        print(f"STATIONARY-Q PASS N={n}: scalar order=N, squarefree")
    return cases


def main():
    assert pow(GEN,(P-1)//2,P)==P-1
    summary={
        'date':'2026-10-13',
        'modulus':P,
        'primitive_field_generator':GEN,
        'two_orientation':run_two_resolvents(),
        'stationary_Q':run_Q_spectrum(),
        'explicit_complex_stable_construction_mod_998244353':run_explicit_bounded_coefficients(),
        'complexity_conclusion':'No exact unrestricted o(N log log N) DFT found.',
        'boundaries':[
           'Two-resolver density does not imply Fourier membership or sub-FFT runtime.',
           'Stationary-Q full minimal polynomial excludes only low-degree annihilator shortcuts, not general fusion.',
           'Exact finite-field nonvanishing lifts to cyclotomic characteristic-zero examples; no floating-point speed claim.'
        ],
    }
    (Path(__file__).parent/'RESULTS.json').write_text(
        json.dumps(summary,indent=2,sort_keys=True),encoding='utf-8')
    print('ALL RECOVERY CHECKS PASS')

if __name__=='__main__':
    main()
