#!/usr/bin/env python3
"""Exact Galois-conductor bridge test for FFT research, 2026-10-13.
Reuses the independently verified linear-time q-torus solver as a reference
and tests one/two high-conductor diagonal masks. All arithmetic mod 65537.
The theorem's characteristic-zero proof is in RESEARCH.md; these tests
are finite certificates, not an all-size FFT construction.
"""
from pathlib import Path
import sys, json, math
sys.path.insert(0,str(Path(__file__).resolve().parent / 'q2'))
import verify_recovery as base
P=65537

def mul(A,B):
    n=len(A); out=[[0]*n for _ in range(n)]
    for i in range(n):
        row=out[i]
        for k in range(n):
            val=A[i][k]
            if val:
                bk=B[k]
                for j in range(n):
                    row[j]+=val*bk[j]
        out[i]=[v%P for v in row]
    return out

def scale_cols(A,diag):
    return [[v*diag[j]%P for j,v in enumerate(row)] for row in A]

def diagonalize_galois_permutation(m):
    N=m*m; w=base.root_of_order(N); q=base.root_of_order(m)
    u=1+m
    cycles=0; seen=set()
    for j in range(N):
        if j in seen: continue
        t=j
        while t not in seen:
            seen.add(t);t=t*u%N
        assert t==j
        cycles+=1
    rank=N-cycles
    r=m.bit_length()-1
    expected=N-(m + r*m//2)
    assert rank==expected
    # For the standard CT input bank, B_(a,c), (a'+m*b) = delta_(a,a') q^(c*b)
    # B P_u = Lambda B with Lambda_(a,c) = q^(a*c).
    for a in range(m):
      for c in range(m):
        eigen=pow(q,a*c,P)
        for j in range(N):
            a0,b= j%m, j//m
            left = pow(q,c*((b+a0)%m),P) if a==a0 else 0
            right= eigen*pow(q,c*b,P)%P if a==a0 else 0
            assert left==right
    tw=[pow(w,a*c,P) for a in range(m) for c in range(m)]
    sigmatw=[pow(w,(1+m)*a*c,P) for a in range(m) for c in range(m)]
    assert sum(1 for x,y in zip(tw,sigmatw) if x!=y)==rank
    return {'m':m,'N':N,'u':u,'cycles':cycles,'galois_F_difference_rank':rank,'twiddle_changed_entries':rank,'CT_intertwiner':'PASS'}

def q2_matrix(m):
    q=base.root_of_order(m)
    return base.dense_matrix_from_apply(lambda x:base.two_conjugate_apply(x,m,q,7,11,2),m*m)

def first_nonroot_crossratio(T):
    n=len(T)
    if any(v==0 for row in T for v in row):
        return {'fully_dense': False, 'nonzero_count':sum(v!=0 for row in T for v in row)}
    for a in range(1,min(n,8)):
        for b in range(1,min(n,8)):
            ratio=T[a][b]*T[0][0]%P*base.inv(T[a][0])%P*base.inv(T[0][b])%P
            v=pow(ratio,n,P)
            if v!=1:
                return {'fully_dense':True,'witness_rows':[0,a], 'witness_cols':[0,b], 'cross_ratio':ratio, 'cross_ratio_to_N':v}
    return {'fully_dense':True,'first_8x8_ratios_are_N_roots':True}

def twiddle_masks(m):
    N=m*m; w=base.root_of_order(N)
    coords=[(a,c) for a in range(m) for c in range(m)]
    return {
      'ac': [pow(w,a*c,P) for a,c in coords],
      '-ac': [pow(w,(-a*c)%N,P) for a,c in coords],
      'a2c': [pow(w,a*a*c,P) for a,c in coords],
      'ac2': [pow(w,a*c*c,P) for a,c in coords],
      'quadratic': [pow(w,(a+c)**2,P) for a,c in coords],
    }

def run_two_masks(m):
    N=m*m; S=q2_matrix(m)
    assert all(v for row in S for v in row), f'missing density N={N}'
    masks=twiddle_masks(m)
    # One high-conductor diagonal: F = A D B is IMPOSSIBLE when A,B
    # have entries in E=Q(zeta_m) and B e0 dense. This is only tested
    # for phase fingerprints, not by exhaustive search.
    cases=[]
    for name1,name2 in [('ac','-ac'),('ac','ac'),('ac','quadratic'),('a2c','ac2'),('ac2','a2c')]:
        inner=mul(scale_cols(S,masks[name1]),S) # S D1 S
        T=mul(scale_cols(S,masks[name2]),inner) # S D2 S D1 S
        witness=first_nonroot_crossratio(T)
        rank=base.rank_mod([[(T[i][(j+1)%N] - pow(base.root_of_order(N),i,P)*T[i][j])%P for j in range(N)] for i in range(N)])
        cases.append({'mask1':name1,'mask2':name2,'weyl_defect_rank':rank,'phase_test':witness})
    return {'m':m,'N':N,'linear_time_resolvers':3,'internal_high_conductor_masks':2,'results':cases}

def run_phase_lifted_resolvers(m):
    N=m*m
    root=base.root_of_order(N)
    q=base.root_of_order(m)
    trials=[]
    for ea,eb in [(1,0),(0,1),(1,1),(1,-1),(2,1),(1,2)]:
        alpha=7*pow(root,ea%N,P)%P
        beta=11*pow(root,eb%N,P)%P
        if (pow(alpha,m,P)+pow(beta,m,P))%P==1 or pow(beta,m,P)==1:
            trials.append({'exponents':[ea,eb], 'skipped':'singular denominator'})
            continue
        S=base.dense_matrix_from_apply(lambda x:base.two_conjugate_apply(x,m,q,alpha,beta,2),N)
        phase=first_nonroot_crossratio(S)
        defect=base.rank_mod([[(S[i][(j+1)%N]-pow(root,i,P)*S[i][j])%P for j in range(N)] for i in range(N)])
        trials.append({'exponents':[ea,eb], 'fully_dense':phase.get('fully_dense',False),
                       'weyl_defect_rank':defect, 'phase_test':phase})
    return {'N':N,'m':m,'Qtorus_roots_lifted_to_order_N':True,'results':trials}

def main():
    theory=[diagonalize_galois_permutation(m) for m in (2,4,8,16,32)]
    candidates=[run_two_masks(m) for m in (2,4,8)]
    lifted=[run_phase_lifted_resolvers(m) for m in (4,8)]
    data={'status':'NO_O_N_FOURIER_ALGORITHM_FOUND', 'field':P,
          'lifted_resolver_trials':lifted,
          'theorem_tests':theory,'two_mask_candidate_tests':candidates,
          'caveat':'Phase tests exclude only these sampled parameter/mask choices; theorem excludes all one-mask E-linear dense-B factorizations.'}
    path=Path(__file__).resolve().parent/'GAL_BRIDGE_RESULTS.json'
    path.write_text(json.dumps(data,indent=2))
    for item in theory: print('GALOIS PASS N=',item['N'],'rank=',item['galois_F_difference_rank'])
    for item in candidates:
        print('TWO MASK N=',item['N'],'result',[(x['mask1'],x['mask2'],x['weyl_defect_rank'],x['phase_test'].get('cross_ratio_to_N')) for x in item['results']])
    for item in lifted: print('LIFTED ROOT TEST N=',item['N'],'ranks=',[z.get('weyl_defect_rank') for z in item['results']])
    print('ALL FORMAL IDENTITY AND FINITE FIELD CHECKS PASS; no FFT breakthrough')
if __name__=='__main__':main()
