# Exact FFT research checkpoint — October 13, 2026

**Headline:** We have **not** obtained exact arbitrary-input `O(N)` or `o(N log log N)` Fourier transforms. We proved a previously overlooked all-size topological obstruction for a specific two-orientation q-torus solver family, and built an explicit third-orientation remedy for the particular forcing minors. Finite-field checks are included, together with Galois-conductor phase tests.

Start with `RESEARCH.md` for full proofs and scope. The runnable checker requires Python 3.10+ and only the standard library.

Run:

```sh
bash RUN_ALL.sh
```

It checks Galois orbits, 18 independent gain/gauge tests of the connected-minor theorem, 4 all-size explicit third-orientation cases, 15 two-mask and 12 high-root negative controls, and small all-2x2-minor examples.

The prior Q2 exact linear-time cyclic Green solver is preserved unchanged under `q2/verify_recovery.py` (used as an independent checker); no FFT is hidden in that solver.

This is a structural research checkpoint, **not a claimed FFT speedup**. The all-size theorem proofs are mathematical, and the tests validate their algebra rather than replace it.
