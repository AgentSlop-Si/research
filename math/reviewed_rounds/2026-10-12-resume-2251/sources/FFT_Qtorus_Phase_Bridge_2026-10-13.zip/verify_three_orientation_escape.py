#!/usr/bin/env python3
"""Three-orientation, exact finite-field verification of repairing both
connected-zero-minor strip families while retaining O(N) scan execution.
All-N algebraic arguments in RESEARCH.md. The transform is NOT Fourier.
"""
import json, random, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import verify_connected_minor_obstruction as v
v.P=2013265921;v.GEN=31
P=v.P

def inv(x):return pow(x%P,P-2,P)

def psi(j,m):
    a,c=divmod(j,m)
    return ((a+c)%m)*m+a

def cycle_solve(row,gamma):
    m=len(row)
    z=0
    for x in row:z=(x+gamma*z)%P
    boundary=z*inv(1-pow(gamma,m,P))%P
    out=[]; prev=boundary
    for x in row:
        prev=(x+gamma*prev)%P
        out.append(prev)
    assert out[-1]==boundary
    return out

def qtorus_solve(rhs,m,q,alpha,beta):
    assert len(rhs)==m*m
    Bm=pow(beta,m,P); Am=pow(alpha,m,P)
    assert (1-Bm)%P and (1-Am-Bm)%P
    denom=inv(1-Bm)
    gain=(1-Bm)*inv(1-Bm-Am)%P
    phases=[pow(q,a,P) for a in range(m)]
    prev=[0]*m
    for a in range(m):
        row=[(rhs[a*m+c]+alpha*prev[c])%P for c in range(m)]
        prev=cycle_solve(row,beta*phases[a]%P)
    prev=[x*gain%P for x in prev]
    out=[0]*(m*m)
    for a in range(m):
        row=[(rhs[a*m+c]+alpha*prev[c])%P for c in range(m)]
        prev=cycle_solve(row,beta*phases[a]%P)
        out[a*m:(a+1)*m]=prev
    return out

def entry_config(m):
    N=m*m;q=pow(v.GEN,(P-1)//m,P)
    assert pow(q,m,P)==1 and pow(q,m//2,P)!=1
    a=inv(4);b=inv(8)
    g1=v.make_entry(m,q,a,a)
    g2=v.make_entry(m,q,a,a)
    g3=v.make_entry(m,q,b,b)
    ph=[v.phi(j,m) for j in range(N)]
    ps=[psi(j,m) for j in range(N)]
    L=4+m*((2*m-1).bit_length())
    lam=inv(pow(2,L,P)); mu=lam*lam%P
    def entry(i,j):
        return (g1(i,j)+lam*g2(ph[i],ph[j])+mu*g3(ps[i],ps[j]))%P
    def apply(x):
        def conj_solve(perm,al):
            z=[0]*N
            for j,k in enumerate(perm):z[k]=x[j]
            y=qtorus_solve(z,m,q,al,al)
            return [y[perm[j]] for j in range(N)]
        y1=qtorus_solve(x,m,q,a,a)
        y2=conj_solve(ph,a)
        y3=conj_solve(ps,b)
        return [(y1[j]+lam*y2[j]+mu*y3[j])%P for j in range(N)]
    return entry,apply,L,lam,mu

def run_case(m):
    n=m*m
    entry,apply,L,lam,mu=entry_config(m)
    edges=0
    nonzero_strips=0
    for a in range(m):
      for c in range(m):
        def pos(aa,cc):return (aa%m)*m+(cc%m)
        for rows,cols in [
          ((pos(a,c),pos(a,c+1)),(pos(a,c+2),pos(a,c+3))),
          ((pos(a,c),pos(a+1,c-1)),(pos(a+2,c-2),pos(a+3,c-3)))
        ]:
          det=(entry(rows[0],cols[0])*entry(rows[1],cols[1])-
               entry(rows[0],cols[1])*entry(rows[1],cols[0]))%P
          assert det!=0,('strip not repaired',m,a,c,det)
          nonzero_strips+=1
    rng=random.Random(138911+m)
    inputs=[]
    if m<=8:
        inputs=[[int(j==i) for j in range(n)] for i in range(n)]
    else:
        inputs=[[rng.randrange(P) for _ in range(n)] for _ in range(2)]
    verified_bins=0
    for x in inputs:
        y=apply(x)
        rows=range(n) if m<=16 else list(range(0,n,20))
        for i in rows:
            check=sum(entry(i,j)*x[j] for j in range(n))%P
            assert y[i]==check,('executor failed',m,i,y[i],check)
            verified_bins+=1
    # A single non-root cross ratio certifies not monomially Fourier,
    # since every Fourier 2x2 cross ratio is an n-th root of unity.
    witness=None
    for i in range(1,min(n,10)):
        for j in range(1,min(n,10)):
            x00=entry(0,0);xi0=entry(i,0);x0j=entry(0,j);xij=entry(i,j)
            if not (x00 and xi0 and x0j and xij):continue
            ratio=xij*x00%P*inv(xi0)%P*inv(x0j)%P
            if pow(ratio,n,P)!=1:
                witness={'rowpair':[0,i],'colpair':[0,j],'ratio_to_N':pow(ratio,n,P)}
                break
        if witness:break
    assert witness is not None
    return {'m':m,'N':n,'L':L,'lambda_mod_p':lam,'mu_mod_p':mu,
            'repaired_zero_minor_witnesses':nonzero_strips,
            'scan_vs_independent_matrix_bins':verified_bins,
            'not_Fourier_cross_ratio_witness':witness}

def main():
    results=[run_case(m) for m in (4,8,16,32)]
    data={'status':'THREE_ORIENTATION_EXACT_REPAIR_NOT_FOURIER',
          'prime':P,'root_generator':31,'results':results,
          'scope':'Only two formerly forced minor families repaired; no FFT speedup'}
    (Path(__file__).resolve().parent/'THREE_ESCAPE_RESULTS.json').write_text(json.dumps(data,indent=2))
    for x in results:print('PASS N=',x['N'],'repaired=',x['repaired_zero_minor_witnesses'],
                           'independent_bins=',x['scan_vs_independent_matrix_bins'],
                           'Fourier_exclusion=',x['not_Fourier_cross_ratio_witness'])
    print('ALL THREE-ORIENTATION CHECKS PASS -- NOT FOURIER')
if __name__=='__main__':main()
