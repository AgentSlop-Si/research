from pathlib import Path
import sys,itertools,random,time,json
sys.path.insert(0,str(Path(__file__).resolve().parent))
import verify_connected_minor_obstruction as v
v.P=2013265921;v.GEN=31
p=v.P

def psi(index,m):
 a,c=divmod(index,m)
 return ((a+c)%m)*m+a

def build(m,seed):
 rng=random.Random(92817+seed+m)
 n=m*m
 q=pow(v.GEN,(p-1)//m,p)
 G=[]
 for t in range(3):
  alpha,beta=v.draw_coeff(rng,m)
  G.append(v.make_entry(m,q,alpha,beta))
 perms=[list(range(n)),[v.phi(j,m) for j in range(n)],[psi(j,m) for j in range(n)]]
 L=[[rng.randrange(1,p) for j in range(n)] for t in range(3)]
 R=[[rng.randrange(1,p) for j in range(n)] for t in range(3)]
 weights=[1,2,3]
 M=[[0]*n for _ in range(n)]
 for i in range(n):
  for j in range(n):
   M[i][j]=sum(weights[t]*L[t][i]*R[t][j]*G[t](perms[t][i],perms[t][j]) for t in range(3))%p
 return M

def rank_mod(A):
 n=len(A);A=[row[:] for row in A];r=0
 for j in range(n):
  pivot=next((i for i in range(r,n) if A[i][j]),None)
  if pivot is None:continue
  A[r],A[pivot]=A[pivot],A[r]
  z=pow(A[r][j],p-2,p)
  for k in range(j,n):A[r][k]=A[r][k]*z%p
  for i in range(r+1,n):
   f=A[i][j]
   if f:
    for k in range(j,n):A[i][k]=(A[i][k]-f*A[r][k])%p
  r+=1
 return r

def zero_minor_summary(A,limit=None):
 n=len(A)
 zeros=[]
 for i in range(n):
  for k in range(i+1,n):
   ai,ak=A[i],A[k]
   for j in range(n):
    for l in range(j+1,n):
     if (ai[j]*ak[l]-ai[l]*ak[j])%p==0:
      zeros.append(((i,k),(j,l)))
      if limit is not None and len(zeros)>=limit:return zeros
 return zeros

if __name__=='__main__':
 data=[]
 for m,seed in [(4,0),(4,1),(8,0),(8,1)]:
  t=time.perf_counter()
  A=build(m,seed)
  z=zero_minor_summary(A)
  print('m',m,'seed',seed,'N',m*m,'zero_entries',sum(x==0 for row in A for x in row),
    'rank',rank_mod(A),'zero_2x2_minors',len(z),'sample',z[:12],'seconds',round(time.perf_counter()-t,2))
  data.append({'m':m,'seed':seed,'zero_entries':sum(x==0 for row in A for x in row),'rank':rank_mod(A),'zero_2x2_minors':len(z),'samples':z[:20]})
 Path('/mnt/data/current_fft_research/THREE_ORIENTATION_RESULTS.json').write_text(json.dumps(data,indent=2))
