#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 verify_galois_phase_bridge.py
python3 verify_connected_minor_obstruction.py
python3 verify_three_orientation_escape.py
python3 test_three_orientation.py
