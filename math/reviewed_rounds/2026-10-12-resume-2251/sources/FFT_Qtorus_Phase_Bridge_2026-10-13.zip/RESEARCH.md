# FFT research — Galois phase bridge and connected-minor obstruction

**Date:** 13 October 2026  
**Goal:** Exact, all-input, all-output, fully charged `O(N)` or `o(N log log N)` DFT.  
**Verdict:** **Not achieved.** This checkpoint contains a new all-size, all-coefficient *restricted-topology impossibility theorem*, an explicit third-orientation repair of its exact witnesses, and independently tested linear-work executors. We do **not** claim worldwide publication novelty.

## Executive summary

1. **All-size two-orientation no-go.** Let `m>=4` be a prime power, `N=m²`, and let `G_1, G_2` be arbitrary invertible two-direction quantum-torus resolvents of the form `(I-alpha A-beta B)^(-1)` with `BA=qAB`, `q` primitive of order `m`. Form `S=D_1 G_1 E_1 + D_2 P_phi^(-1) G_2 P_phi E_2`, where all four `D_i,E_i` are arbitrary nonzero complex diagonal matrices and `phi(a,c)=(-c,a+c) mod m`. **For every choice of parameters, `S` is not monomially equivalent to `F_N`.** The obstruction consists of `2N` identically vanishing `2x2` minors whose forced-zero row-pair graph is connected. This remains true with arbitrary outer diagonal scalings and row/column permutations.
2. **Explicit repair of the exact obstruction.** Add a *third* `O(N)` resolver in orientation `psi(a,c)=(a+c,a) mod m`. With explicit coefficients `1/4,1/8` and charged tiny couplings, all those `2N` forced minors become **nonzero** for every integer `m>=4`, while the new operator remains globally dense, invertible, uniformly well-conditioned, and exactly `O(N)`-applicable. This is a genuine positive escape from the newly proved topology gate, **not** Fourier phase synthesis.
3. **Exact small test:** with separate gains on all three orientations, a completely nonsingular `N=16` matrix and all **14,400** of its `2x2` minors were nonzero modulo a good splitting prime; this certifies a characteristic-zero 2-full-spark example. At `N=64` the same three-orientation grammar had **2,560** exactly vanishing minors in each of two independent finite-field parameter tests, illustrating that the third orientation does not solve all sizes at the 2x2 level.
4. **Galois conductor gate.** For dyadic `m`, a single high-conductor diagonal sandwiched between two `Q(zeta_m)`-linear matrices cannot complete the `m²`-DFT if the input-side factor has a dense first column. It must have at least `N-m(1+log_2(m)/2)` zeros in that column. This can be checked via an exact Galois permutation and matches the older Phase42 non-base-scaling rank budget. The standard Cooley–Tukey middle twiddle bank saturates the *rank* budget but its input-side Fourier bank has the necessary zeros.
5. **Actual construction tests, all rejected:** 15 exact two-mask circuits `S D2 S D1 S` at `N=4,16,64`, plus 12 trials where the resolver coefficients themselves use `N`-th roots at `N=16,64`. All have wrong Fourier cross ratios and full Weyl-defect rank in the reported finite fields. These reject the tested points only, not every two-mask or high-conductor construction.

---

## 1. Exact q-torus operator

Index the coordinates by `V=Z_m x Z_m`. Let `q` be a primitive complex `m`-th root and define

\[
(Ax)_{a,c}=x_{a-1,c},\qquad (Bx)_{a,c}=q^a x_{a,c-1}.
\]

Then `BA=q AB`, `A^m=B^m=I`. For `alpha beta !=0` and `1-alpha^m-beta^m !=0`, let

\[
G_{\alpha,\beta}=(I-\alpha A-\beta B)^{-1}.
\]

The root-of-unity q-binomial theorem gives

\[
G_{\alpha,\beta}
=\frac{\sum_{t=0}^{m-1}(\alpha A+\beta B)^t}
{1-\alpha^m-\beta^m}.
\]

For output `(a,c)`, input `(a',c')` set `u=(a-a') mod m` and `v=(c-c') mod m`, with representatives `0,...,m-1`. The **exact entry formula** is

\[
\boxed{G[(a,c),(a',c')]=
\begin{cases}
\displaystyle\frac{\alpha^u\beta^v {u+v\brack u}_q\,q^{a'v}}{1-\alpha^m-\beta^m},&u+v<m,\\
0,&u+v\ge m.
\end{cases}}
\tag{1}
\]

The Gaussian binomial coefficient is nonzero for `u+v<m`. Hence the support is *exactly* the triangular set `u+v<m`, independently of the nonzero coefficients.

The previous QTGF checkpoint gives a true `O(N)` two-pass cyclic Green solver. Its code is included unchanged under `q2/verify_recovery.py`; our new tests independently compare the entry formula against this solver.

## 2. New theorem — two orientations are NEVER Fourier (prime-power grids)

Let

\[
\phi(a,c)=(-c,a+c)\pmod m.
\]

Take independently parameterized invertible q-torus resolvents `G_1`, `G_2` (even with different nonzero q-binomial parameters), and arbitrary diagonal gains `L_1,R_1,L_2,R_2` with nonzero entries. Define

\[
\boxed{S=L_1G_1R_1+L_2P_\phi^{-1}G_2P_\phi R_2.}\tag{2}
\]

An arbitrary nonzero overall scalar for either term can be absorbed into its diagonal gains.

### Theorem 2.1

For **every prime power** `m>=4`, `N=m²`, and all admissible complex parameters in (2), **no** invertible diagonal or permutation matrices `U,V` satisfy `USV=F_N`.

### Proof: first family of forced zero minors

Fix `a,c mod m`. Select two **output rows**

\[
R_h=((a,c),(a,c+1))
\]

and two **input columns**

\[
C_h=((a,c+2),(a,c+3)).
\]

The four displacements in the original q-torus coordinates have `u=0` and `v=m-2,m-3,m-1,m-2`, respectively. Since `v>0`, applying `phi` gives displacement `(m-v,v)` with coordinate sum `m`; hence every entry of the second resolver is **zero** on this submatrix. The first resolver contributes, before arbitrary outside diagonal gauges, a scalar multiple of

\[
\begin{pmatrix}
 t^{m-2}&t^{m-3}\\
 t^{m-1}&t^{m-2}
\end{pmatrix},\qquad t=\beta_1q^a.
\]

Its determinant is zero identically. Outside diagonal gauges preserve the zero determinant. Therefore

\[
\boxed{\det S[R_h,C_h]=0.}\tag{3}
\]

### Second family of forced zero minors

Select rows and columns

\[
R_d=((a,c),(a+1,c-1)),\qquad
C_d=((a+2,c-2),(a+3,c-3)).
\]

Each original displacement has `u+v=m`, hence **every entry of the first resolver is zero**. In the `phi`-coordinates, the second displacement coordinate is zero, and the first is one of `m-2,m-3,m-1,m-2`. The second resolver therefore contributes a scalar multiple of

\[
\begin{pmatrix}
 t^{m-2}&t^{m-3}\\
 t^{m-1}&t^{m-2}
\end{pmatrix},\qquad t=\alpha_2.
\]

Its determinant also vanishes, so

\[
\boxed{\det S[R_d,C_d]=0.}\tag{4}
\]

### Connectedness makes these defects incompatible with Fourier

Build a graph on the `m²` output rows. For every `(a,c)` include the row edges

\[
(a,c)\longleftrightarrow(a,c+1),\qquad
(a,c)\longleftrightarrow(a+1,c-1).
\]

Equations (3) and (4) exhibit a vanishing `2x2` minor for each such row pair, with **distinct** input columns. The graph is connected: the two displacement vectors `(0,1)` and `(1,-1)` generate all of `Z_m²`.

For the Fourier matrix `F_N[r,j]=zeta_N^{rj}`, a `2x2` minor on distinct row labels `r,r'` and column labels `j,j'` vanishes exactly when

\[
N\mid(r'-r)(j'-j).
\]

If `N` is a prime power `p^d`, any row difference **not divisible by p** is invertible mod `N`, so no such zero minor is possible. Thus **any** row pair with a zero Fourier minor must have labels congruent modulo `p`.

Assume that row and column permutations/diagonal calibrations transformed `S` to Fourier. Under the row permutation, every edge of our connected forced-zero-minor graph must join row labels congruent modulo `p`. Connectedness forces **all** `N` Fourier row labels to lie in one residue class modulo `p`, which is impossible for a permutation of `0,...,N-1`.

This is a contradiction. QED.

**Crucial scope:** the proof is uniform in all scalar parameters and **all independent nonzero input/output diagonal gauges for each resolver**. It does not cover arbitrary extra non-diagonal layers, a third orientation, or a two-stage *product* of such sums. It proves a topological/structural exclusion, not an unrestricted FFT lower bound.

---

## 3. Explicit third orientation repairs BOTH exact minor families

Define the third linear permutation

\[
\boxed{\psi(a,c)=(a+c,a)\pmod m.}\tag{5}
\]

Let `G=G_(1/4,1/4)` and `J=G_(1/8,1/8)`, with a common primitive `m`-th root `q`. Choose

\[
L_m=4+m\lceil\log_2(2m)\rceil,
\quad \lambda_m=2^{-L_m},
\quad \mu_m=\lambda_m^2.
\]

For every integer `m>=4` put

\[
\boxed{S_m^{(3)}=G+\lambda_m P_\phi^{-1}GP_\phi+\mu_m P_\psi^{-1}JP_\psi.}\tag{6}
\]

### Theorem 3.1 — all-size explicit escape from the connected-minor gate

For every `m>=4`, over complex arithmetic, the matrix in (6):

* has no zero entries;
* is invertible and has `kappa_2 < 4`;
* has an exact `O(N)` solver/forward executor with `N=m²`, including `O(N)` coefficient/routing preparation;
* has **nonzero determinants** at all `2N` row/column pairs (3) and (4) that were identically singular for two orientations.

### Proof of the repaired minors

For the horizontal family, the middle `phi` term still vanishes. The first resolver has geometric base `t_1=q^a/4`. The new `psi` term maps the original displacement `(0,v)` to `(v,0)`, giving geometric base `t_3=1/8`. The `2x2` determinant equals

\[
-\mu_m K_1K_3(t_1t_3)^{m-3}(t_1-t_3)^2,
\]

where the inverse denominators `K_1,K_3` are nonzero. Since `|t_1|=1/4 != 1/8=|t_3|`, this is nonzero.

For the diagonal family, the first resolver still vanishes. The `phi` term has base `t_2=1/4`. The `psi` term maps each original displacement `(u,m-u)` to `(0,u)` in `psi` coordinates, with geometric base `t_3=q^{a+c}/8`. The determinant equals

\[
-\lambda_m\mu_m K_2K_3(t_2t_3)^{m-3}(t_2-t_3)^2\ne0
\]

because `|t_2|=1/4 != 1/8=|t_3|`.

### Proof of full support and conditioning

The previous Q2 theorem gives, for `G=G_(1/4,1/4)`, every supported entry magnitude at least `g_min=4/(2m)^m`. `G` and each permutation conjugate have operator norm at most `2`, while `||J||_2<=4/3`. Moreover `||G^-1||_2<=3/2`.

The original first two terms are entrywise nonzero when `lambda_m<=1/[16(2m)^m]`: on the support of `G`, its magnitude exceeds `g_min-2lambda_m`; off that support, the `phi` term is present with magnitude at least `lambda_m*g_min`. Adding `mu_m J` changes every entry by at most `(4/3)mu_m`, which is smaller than either of those lower bounds. Thus every entry of (6) is nonzero.

Write `S3=G(I+G^-1(lambda H+mu Jpsi))`. The perturbation norm is at most `3lambda+2mu`. Therefore

\[
\kappa_2(S3)
\le\frac{(2+2\lambda+4\mu/3)(3/2)}{1-3\lambda-2\mu}<4
\]

for the explicit tiny lambda. The three q-torus resolvents have independently charged two-pass `O(N)` cyclic Green executors, and all diagonals/permutations/root-power tables also require `O(N)` work. QED.

**Still NOT Fourier:** all entries of this particular explicitly parameterized `S3` belong to `Q(zeta_m)`; every nonzero `2x2` cross ratio does too. Yet `F_(m²)` has a cross ratio equal to the primitive `m²`-th root `zeta_(m²)`, which lies outside `Q(zeta_m)`. Cross ratios survive arbitrary outside nonzero diagonal gauges and permutations. Thus (6) is **not monomially Fourier-equivalent at any `m>=4`**. This is a field-of-definition obstruction for this specific coefficient schedule; arbitrary high-conductor vertex phases could escape it.

### Small-size two-full-spark positive control

`test_three_orientation.py` constructs independently gauged three-resolver sums over a good splitting field. At `N=16`, **all 14,400 nontrivial `2x2` minors are nonzero** and the full matrix rank is 16 for two independent exact assignments. This proves characteristic-zero existence for that finite topology. At `N=64`, the same fixed three orientations have **2,560** identically vanishing `2x2` minors for the tested parameter families, so there is no all-size two-full-spark theorem from this three-orientation grammar. Full spark, even if achieved, would still not prove Fourier phases.

---

## 4. Galois one-mask lower bound and exact twiddle calibration

Let `m=2^r>=2`, `N=m²`, `L=Q(zeta_N)` and `E=Q(zeta_m)`. Let

\[
\sigma(\zeta_N)=\zeta_N^{1+m},\qquad u=1+m.
\]

This fixes `E` and induces a nonidentity Galois automorphism of `L`. Define the input permutation `P_u e_j=e_(u j modN)`. Since `sigma(F_N)=F_N P_u`, any putative factorization

\[
F_N=A D B,
\qquad A,B\in GL_N(E),\quad D\text{ invertible diagonal}
\]

necessarily satisfies

\[
\boxed{B P_u=\Delta B,\qquad\Delta=D^{-1}\sigma(D).}\tag{7}
\]

Although `D` was allowed arbitrary complex entries, the assumed identity forces `D=A^-1 F_N B^-1` to have entries in `L`, so applying `sigma` is valid.

The number of cycles of `P_u` is

\[
\boxed{c=m\left(1+\frac r2\right).}\tag{8}
\]

Proof: `P_u` has order `m`; by Burnside's lemma the number of cycles is

\[
\frac1m\sum_{t=0}^{m-1}\gcd(u^t-1,N)
=m+\sum_{t=1}^{m-1}\gcd(t,m)
=m+rm/2.
\]

Here the equality for `t>0` uses the 2-adic binomial/LTE valuation for `1+m` (and the `m=2` endpoint checks directly).

Thus the `1`-eigenspace of `P_u` has dimension `c`. As `B` is invertible, `Delta` has exactly `c` diagonal entries equal to `1`. Every fixed input coordinate `j` of `P_u`—in particular `j=0` and all multiples of `m`—obeys

\[
\Delta Be_j=Be_j.
\]

Therefore **each such column of `B` has support at most `c`**:

\[
\boxed{\operatorname{nnz}(Be_j)\le m(1+r/2).}\tag{9}
\]

For every `m>=4`, even one q-torus resolver has `m(m+1)/2 > c` nonzero entries in each column; the globally dense two-orientation solver has `N>c`. Neither can serve as that input-side factor in a one-mask `E -> L -> E` Fourier factorization, no matter what `A` is.

There is also an exact *phase-count equality*:

\[
\boxed{\#\{i:\sigma(d_i)\ne d_i\}=\mathrm{rank}(\sigma(F_N)-F_N)=N-c.}\tag{10}
\]

The standard Cooley–Tukey twist `d_(a,c)=zeta_N^(ac)` has precisely `N-c` entries changed by `sigma`, so it **saturates** the rank budget. The general non-base-coefficient budget is closely related to the existing Phase42 project theorem; we do not claim that Galois rank principle as new mathematics.

---

## 5. Exact experiments and negative controls

| Test | Sizes | Result | Meaning |
|---|---|---|---|
| Galois-cycle and middle-twiddle rank | `4,16,64,256,1024` | `1,8,44,208,912` | Exact conductor and row-sparsity certificate |
| Two-orientation forced `2x2` minor witnesses (three independent gains per size) | `16,25,64,81,256,1024` | Every one of `2N` forced minors zero; graph connected | 18 finite-field test cases of all-size theorem |
| Two-mask `S D2 S D1 S` | `4,16,64` | All 15 candidate mask combinations fail Fourier cross ratios and have full Weyl-defect rank | Rejects tested masks/coefficients only |
| Resolver parameters lifted to `N`th roots | `16,64` | All 12 trials fail Fourier cross ratio and have full Weyl-defect rank | Tests escape from E field, not universal rejection |
| Explicit three-orientation repair of the `2N` minors | `16,64,256,1024` | `32,128,512,2048` repaired; scan output matches independent matrix bins | Proves new topology escape; still not Fourier |
| Independent per-branch gauges, three orientations | `16` | 14,400 of 14,400 `2x2` minors nonzero; matrix invertible | Finite structural positive control |
| Same three orientations at `64` | `64` | 2,560 zero `2x2` minors (two independent assignments) | The tested assignments are not 2-full-spark; universal impossibility not proved |

The q-torus entry checker is independently compared to the prior cyclic Green solver, and the three-orientation executor is independently checked against the entry formula on basis vectors for `N=16,64` and on dense vectors at `N=256,1024`. The whole checkpoint uses **exact finite-field arithmetic**; there are no floating-point tolerances. Nonzero good-prime values lift to nonzero complex cyclotomic expressions, but modular failure at one specialization cannot be promoted to a global complex impossibility without the symbolic proofs above.

## 6. What counts as success and what is next

**Not achieved:** `O(N)` or `o(N log log N)` for exact general DFT. The new all-size theorem shows that **two additive orientations are impossible**, independently of gains; third orientation removes that particular zero-minor graph but fails the phase condition under our explicit coefficient schedule. Another architecture with high-conductor phases, multiple noncommuting layers, or different operators remains open.

The next accepted *positive* result must supply a full **exact Fourier** identity, not simply density or full-spark. A credible test is: use `N=16` with **three orientations and independent `N`th-root vertex phases**, solve *all* dephased Fourier cross-ratios simultaneously, then test the *same symbolic rule* at `N=64,256`. Count every Green solve, scalar/gauge preparation, memory pass, and apply. A finite special solution is only a control; a uniform all-N identity and honest `O(N)` (or `o(N log log N)`) total work are mandatory. Phase49's `MX=ZM, Me0=ones` remains the final exact all-output proof.

**Prior art:** q-binomial theorem, quantum/Weyl torus, Galois group of cyclotomic fields, Burnside's lemma, elementary Fourier minors and structural rank are classical. The linked two-orientation connected-minor obstruction and explicit third-orientation repair are **new combinations within the present project**, with historical novelty unassessed. The public 2026 uniform supplied-root exact DFT comparator is `O(N(log N)^(1−10^(-13)))`, in unrestricted exact complex arithmetic; it is not an `O(N)` or stable floating-point FFT. See <https://github.com/openai/math/blob/main/lean/docs/130.md>.
