"""Hard-domain final materialization and publication withholding controls."""
import hashlib,json
from pathlib import Path
from chirp_executor import execute
from fresh_check import synth,verify,audit_ledger
HERE=Path(__file__).parent
results=[]
for N,p,w,a,terms in ((4,5,2,1,[(0,1),(2,2)]),(512,65537,157,255,[(1,1),(511,65536)]),(512,65537,157,254,[(0,2),(256,3)]),(512,65537,157,0,[])):
    record=dict(N=N,p=p,omega=w,x=synth(N,p,w,a,terms))
    full=execute(record,trace=True);verify(record,full);audit_ledger(record,full)
    U=full['meter']['used'];trace=full['meter']['trace']
    checks=[]
    for offset,event in ((3,'materialize.write'),(2,'materialize.container_write'),(1,'terminal.publish')):
        cut=execute(record,U-offset,trace=True)
        assert cut['status']=='LIMIT' and set(cut)=={'status','meter'}
        assert cut['meter']['used']==U-offset
        assert cut['meter']['trace']==trace[:U-offset]
        assert cut['meter']['denied_event']==event
        checks.append({'budget':U-offset,'denied_event':event,'withheld_entire_result':True})
    exact=execute(record,U)
    assert exact['status']=='MEMBER' and exact['X']==full['X']
    results.append({'N':N,'p':p,'input_phase':a,'input_terms':terms,'completed_work':U,'checks':checks})
report={'verdict':'PASS','source_sha256':hashlib.sha256((HERE/'chirp_executor.py').read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':results}
(HERE/'boundary_results.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: 12 final-write/container/publication denials, 4 exact completion budgets.')
