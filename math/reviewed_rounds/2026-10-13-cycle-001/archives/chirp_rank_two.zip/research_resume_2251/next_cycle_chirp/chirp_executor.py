"""Bounded exact rank-at-most-two common-chirp executor, supplied root only.
A unit is one named event, not a CPU instruction or bit operation. See CONTRACT.md.
No local research code, symbolic algebra package, or Fourier routine is imported.
"""
from collections import Counter
MAX_BUDGET = 20_000_000

class _Limit(Exception):
    pass

class _Invalid(Exception):
    pass

class _Meter:
    def __init__(self, budget, trace):
        self.budget = budget
        self.used = 0
        self.stage = "validation"
        self.counts = Counter()
        self.trace = [] if trace else None
        self.denied = None

    def tick(self, event):
        key = self.stage + "." + event
        if self.used == self.budget:
            self.denied = key
            raise _Limit
        self.used += 1
        self.counts[key] += 1
        if self.trace is not None:
            self.trace.append(key)

    def require(self, value, reason):
        self.tick("check")
        if not value:
            raise _Invalid(reason)

    def compare(self, left, right):
        self.tick("compare")
        return left == right

    def read(self, seq, index):
        self.tick("read")
        return seq[index]

    def append(self, seq, value):
        self.tick("write")
        seq.append(value)

    def write(self, seq, index, value):
        self.tick("write")
        seq[index] = value

    def index(self, expression):
        # One stated bounded integer expression, not a primitive instruction.
        self.tick("index")
        return expression()

    def report(self):
        ans = {"used": self.used, "budget": self.budget,
               "remaining": self.budget - self.used,
               "counts": dict(sorted(self.counts.items())),
               "denied_event": self.denied}
        if self.trace is not None:
            ans["trace"] = self.trace
        return ans

class _Field:
    def __init__(self, p, meter):
        self.p, self.m = p, meter

    def add(self, a, b):
        self.m.tick("field_add")
        return (a + b) % self.p

    def sub(self, a, b):
        self.m.tick("field_sub")
        return (a - b) % self.p

    def mul(self, a, b):
        self.m.tick("field_mul")
        return (a * b) % self.p

    def inverse(self, value):
        self.m.tick("inverse")
        self.m.require(value != 0, "internal zero inverse")
        exponent = self.m.index(lambda: self.p - 2)
        bits = self.m.index(lambda: exponent.bit_length())
        acc = 1
        for bit in range(bits - 1, -1, -1):
            self.m.tick("pow_bit")
            acc = self.mul(acc, acc)
            if self.m.index(lambda: (exponent >> bit) & 1):
                acc = self.mul(acc, value)
        self.m.require(self.mul(acc, value) == 1, "internal inverse check")
        return acc

def _gcd(a, b, m):
    while b:
        m.tick("gcd_step")
        a, b = b, m.index(lambda: a % b)
    return a

def _run(record, m):
    m.require(type(record) is dict, "record must be an exact dict")
    m.require(len(record) == 4, "record keys must be N,p,omega,x")
    keys = []
    for key in record:
        m.tick("key_visit")
        m.require(type(key) is str, "keys must be exact strings")
        m.append(keys, key)
    m.require(set(keys) == {"N", "p", "omega", "x"}, "wrong keys")
    N, p, omega, raw = (m.read(record, k) for k in ("N", "p", "omega", "x"))
    for value in (N, p, omega):
        m.require(type(value) is int, "headers must be exact integers; supplied root required")
    m.require(3 <= N <= 512, "N outside [3,512]")
    m.require(5 <= p <= 65537, "p outside [5,65537]")
    m.require(1 <= omega < p, "omega outside canonical nonzero residues")
    m.require(m.index(lambda: (p - 1) % N) == 0, "N must divide p-1")
    m.require(type(raw) is list, "x must be an exact list")
    m.require(len(raw) == N, "wrong x length")
    x = []
    center = None
    for j in range(N):
        m.tick("raw_visit")
        value = m.read(raw, j)
        m.require(type(value) is int, "coordinates must be exact integers")
        m.require(0 <= value < p, "coordinate outside canonical residues")
        m.append(x, value)
        m.tick("center_test")
        if value != 0 and center is None:
            m.tick("center_write")
            center = j
    m.stage = "prime"
    divisor = 2
    while True:
        m.tick("trial_guard")
        if m.index(lambda: divisor * divisor) > p:
            break
        m.tick("trial_visit")
        m.require(m.index(lambda: p % divisor) != 0, "p is composite")
        divisor = m.index(lambda: divisor + 1)
    f = _Field(p, m)
    m.stage = "root"
    roots = []
    value = 1
    for j in range(N):
        m.tick("root_visit")
        if j:
            m.require(value != 1, "omega has order less than N")
        m.append(roots, value)
        value = f.mul(value, omega)
    m.require(value == 1, "omega does not have order N")
    if center is None:
        return _output(N, p, omega, 0, [], True, roots, f, m)
    m.stage = "filter_coeff"
    values = []
    for offset in (0, -1, 1, -2, 2):
        m.tick("cyclic_visit")
        m.append(values, m.read(x, m.index(lambda: (center + offset) % N)))
    z, u, v, U, V = values
    e = []
    m.append(e, f.mul(f.mul(z, z), z))
    m.append(e, f.sub(0, f.mul(2, f.mul(f.mul(z, u), v))))
    m.append(e, 0)
    m.append(e, f.add(f.mul(f.mul(u, u), V), f.mul(U, f.mul(v, v))))
    m.append(e, f.sub(0, f.mul(f.mul(z, U), V)))
    period_gcd = _gcd(2, N, m)
    L = m.index(lambda: N // period_gcd)
    phases = []
    m.stage = "filter_scan"
    for a in range(L):
        m.tick("phase_visit")
        t = m.read(roots, m.index(lambda: (-2 * a) % N))
        val = m.read(e, 4)
        for r in (3, 2, 1, 0):
            val = f.add(f.mul(val, t), m.read(e, r))
        if m.compare(val, 0):
            m.append(phases, a)
    for candidate_index in range(len(phases)):
        m.stage = "candidate"
        m.tick("candidate_visit")
        a = m.read(phases, candidate_index)
        m.stage = "moments"
        y = []
        for j in range(4):
            m.tick("moment_visit")
            q = m.read(x, m.index(lambda: j % N))
            h = m.read(roots, m.index(lambda: (-a * j * j) % N))
            m.append(y, f.mul(q, h))
        y0, y1, y2, y3 = y
        m.stage = "solve"
        delta = f.sub(f.mul(y0, y2), f.mul(y1, y1))
        if m.compare(delta, 0):
            if m.compare(y0, 0):
                continue
            node = f.mul(y1, f.inverse(y0))
            bs = []
            m.stage = "rank1_grid"
            for b in range(N):
                m.tick("node_visit")
                if m.compare(m.read(roots, b), node):
                    m.append(bs, b)
            if not m.compare(len(bs), 1):
                continue
            terms = []
            m.append(terms, (m.read(bs, 0), y0))
        else:
            # One inverse of Delta serves BOTH recovered coefficients.
            delta_inverse = f.inverse(delta)
            S = f.mul(f.sub(f.mul(y0, y3), f.mul(y1, y2)), delta_inverse)
            P = f.mul(f.sub(f.mul(y1, y3), f.mul(y2, y2)), delta_inverse)
            bs = []
            m.stage = "rank2_grid"
            for b in range(N):
                m.tick("node_visit")
                node = m.read(roots, b)
                q = f.add(f.sub(f.mul(node, node), f.mul(S, node)), P)
                if m.compare(q, 0):
                    m.append(bs, b)
            if not m.compare(len(bs), 2):
                continue
            m.stage = "amplitudes"
            b0, b1 = m.read(bs, 0), m.read(bs, 1)
            n0, n1 = m.read(roots, b0), m.read(roots, b1)
            c0 = f.mul(f.sub(y1, f.mul(y0, n1)), f.inverse(f.sub(n0, n1)))
            c1 = f.sub(y0, c0)
            zero0, zero1 = m.compare(c0, 0), m.compare(c1, 0)
            if zero0 or zero1:
                continue
            terms = []
            m.append(terms, (b0, c0))
            m.append(terms, (b1, c1))
        m.stage = "verify"
        mismatch = False
        for j in range(N):
            m.tick("raw_visit")
            total = 0
            for ti in range(len(terms)):
                b, c = m.read(terms, ti)
                h = m.read(roots, m.index(lambda: (b * j) % N))
                total = f.add(total, f.mul(c, h))
            h = m.read(roots, m.index(lambda: (a * j * j) % N))
            value = f.mul(total, h)
            matches = m.compare(value, m.read(x, j))
            m.tick("mismatch_update")
            mismatch = mismatch or not matches
        if not mismatch:
            return _output(N, p, omega, a, terms, False, roots, f, m)
    m.stage = "terminal"
    m.tick("publish")
    return {"status": "NONMEMBER"}

def _output(N, p, omega, a, terms, zero, roots, f, m):
    m.stage = "gauss"
    row = []
    for _ in range(N):
        m.tick("row_visit")
        m.append(row, 0)
    if not zero:
        d = _gcd(m.index(lambda: 2 * a), N, m)
        K = m.index(lambda: N // d)
        c0 = m.index(lambda: (-a * K) % d)
        seed = 0
        for j in range(N):
            m.tick("seed_visit")
            seed = f.add(seed, m.read(roots, m.index(lambda: (a * j * j + c0 * j) % N)))
        m.write(row, c0, seed)
        c, value = c0, seed
        for _ in range(K - 1):
            m.tick("orbit_visit")
            h = m.read(roots, m.index(lambda: (-a - c) % N))
            value = f.mul(value, h)
            c = m.index(lambda: (c + 2 * a) % N)
            m.write(row, c, value)
    m.stage = "mixture"
    transformed = []
    for k in range(N):
        m.tick("output_visit")
        if not terms:
            value = 0
        else:
            b0, c0 = m.read(terms, 0)
            value = f.mul(c0, m.read(row, m.index(lambda: (k + b0) % N)))
            if len(terms) == 2:
                b1, c1 = m.read(terms, 1)
                value = f.add(value, f.mul(c1, m.read(row, m.index(lambda: (k + b1) % N))))
        m.append(transformed, value)
    m.stage = "materialize"
    answer = {}
    for key, value in (("status", "MEMBER"), ("N", N), ("p", p),
                       ("omega", omega), ("a", a)):
        m.tick("header_write")
        answer[key] = value
    out_terms = []
    for i in range(len(terms)):
        b, c = m.read(terms, i)
        m.tick("term_pair")
        m.append(out_terms, [b, c])
    m.tick("container_write")
    answer["terms"] = out_terms
    out_x = []
    for i in range(N):
        m.tick("output_copy_visit")
        m.append(out_x, m.read(transformed, i))
    m.tick("container_write")
    answer["X"] = out_x
    m.stage = "terminal"
    m.tick("publish")
    return answer

def execute(record, budget=MAX_BUDGET, *, trace=False):
    """Return atomic result and consumed-event telemetry. Input is read-only.
    Unmetered bootstrap validates budget/trace; invalid options give INVALID
    with zero work. LIMIT withholds all mathematical output. Trace contains
    event labels only. omega=None is INVALID: root discovery is unsupported.
    """
    if type(budget) is not int or not 0 <= budget <= MAX_BUDGET or type(trace) is not bool:
        return {"status": "INVALID", "reason": "invalid budget or trace option",
                "meter": {"used": 0, "budget": None, "remaining": None,
                          "counts": {}, "denied_event": None}}
    m = _Meter(budget, trace)
    try:
        result = _run(record, m)
    except _Limit:
        result = {"status": "LIMIT"}
    except _Invalid as exc:
        result = {"status": "INVALID", "reason": str(exc)}
    result["meter"] = m.report()
    return result
