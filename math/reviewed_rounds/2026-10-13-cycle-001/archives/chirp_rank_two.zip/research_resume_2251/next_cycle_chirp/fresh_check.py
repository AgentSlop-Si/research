"""Producer controls: independent Fourier-support oracle, predicted ledger,
actual field-call reconciliation and interruption replay. Not external review.
"""
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
from collections import Counter
import chirp_executor as implementation

HERE = Path(__file__).parent

def root(N,p):
    for w in range(2,p):
        if pow(w,N,p)==1 and all(pow(w,j,p)!=1 for j in range(1,N)):
            return w
    raise AssertionError('no root')

def synth(N,p,w,a,terms):
    return [sum(c*pow(w,(a*j*j+b*j)%N,p) for b,c in terms)%p for j in range(N)]

def dft(x,p,w,sign=1):
    N=len(x); out=[]
    for k in range(N):
        step=pow(w,sign*k%N,p); h=1; total=0
        for value in x:
            total=(total+value*h)%p
            h=h*step%p
        out.append(total)
    return out

def support_oracle(record):
    N,p,w,x=(record[k] for k in ('N','p','omega','x'))
    witnesses=[]
    for a in range(N//math.gcd(2,N)):
        y=[v*pow(w,(-a*j*j)%N,p)%p for j,v in enumerate(x)]
        spectrum=[v*pow(N,-1,p)%p for v in dft(y,p,w,-1)]
        terms=[(b,c) for b,c in enumerate(spectrum) if c]
        if len(terms)<=2:
            witnesses.append((a,terms))
    return witnesses

def verify(record,result,expected=None):
    N,p,w,x=(record[k] for k in ('N','p','omega','x'))
    assert result['status'] in ('MEMBER','NONMEMBER')
    if result['status']=='NONMEMBER':
        assert not any(k in result for k in ('N','p','omega','a','terms','X'))
        return
    assert (result['N'],result['p'],result['omega'])==(N,p,w)
    a,terms=result['a'],result['terms']
    assert type(a) is int and 0<=a<N//math.gcd(2,N)
    assert len(terms)<=2 and terms==sorted(terms)
    assert len({b for b,c in terms})==len(terms)
    assert all(type(b) is int and 0<=b<N and type(c) is int and 0<c<p for b,c in terms)
    assert synth(N,p,w,a,terms)==x
    assert result['X']==(dft(x,p,w) if expected is None else expected)

def steps(a,b):
    n=0
    while b:a,b=b,a%b;n+=1
    return n

def predict(record):
    """Route prediction from raw algebra and closed formulas, no telemetry."""
    N,p,w,x=(record[k] for k in ('N','p','omega','x'))
    stages=Counter(); field=Counter(); inverses=0
    ell=(p-2).bit_length(); weight=(p-2).bit_count(); I=6+3*ell+weight; M=ell+weight+1
    def add(stage,total,mul=0,add=0,sub=0,inv=0):
        nonlocal inverses
        stages[stage]+=total
        field['field_mul']+=mul;field['field_add']+=add;field['field_sub']+=sub
        inverses+=inv
    add('validation',29+6*N+int(any(x)))
    add('prime',6*(math.isqrt(p)-1)+2)
    add('root',4*N,mul=N)
    def output(a,s):
        if s:
            K=N//math.gcd(2*a,N)
            add('gauss',6*N+2*steps(2*a,N)+4+6*(K-1),add=N,mul=K-1)
        else:add('gauss',2*N)
        add('mixture',[2,6,11][s]*N,mul=s*N,add=(N if s==2 else 0))
        add('materialize',7+3*s+3*N)
        add('terminal',1)
    if not any(x):
        output(0,0);return stages,field,inverses
    c=next(i for i,v in enumerate(x) if v)
    z,u,v,U,V=[x[(c+o)%N] for o in (0,-1,1,-2,2)]
    e=(z**3%p,(-2*z*u*v)%p,0,(u*u*V+U*v*v)%p,(-z*U*V)%p)
    L=N//math.gcd(2,N)
    phases=[a for a in range(L) if sum(co*pow(pow(w,(-2*a)%N,p),r,p) for r,co in enumerate(e))%p==0]
    assert len(phases)<=4
    add('filter_coeff',40+2*steps(2,N),mul=11,add=1,sub=2)
    add('filter_scan',17*L+len(phases),mul=4*L,add=4*L)
    nodes=[pow(w,b,p) for b in range(N)]
    for a in phases:
        add('candidate',2);add('moments',28,mul=4)
        y0,y1,y2,y3=[x[j%N]*pow(w,(-a*j*j)%N,p)%p for j in range(4)]
        delta=(y0*y2-y1*y1)%p
        if delta==0:
            if y0==0:add('solve',5,mul=2,sub=1);continue
            add('solve',6+I,mul=3+M,sub=1,inv=1)
            node=y1*pow(y0,-1,p)%p
            bs=[b for b,n in enumerate(nodes) if n==node]
            add('rank1_grid',3*N+len(bs)+1+(2 if len(bs)==1 else 0))
            if len(bs)!=1:continue
            terms=[(bs[0],y0)]
        else:
            inv=pow(delta,-1,p)
            S=(y0*y3-y1*y2)*inv%p;P=(y1*y3-y2*y2)*inv%p
            add('solve',12+I,mul=8+M,sub=3,inv=1)
            bs=[b for b,n in enumerate(nodes) if (n*n-S*n+P)%p==0]
            add('rank2_grid',7*N+len(bs)+1,mul=2*N,add=N,sub=N)
            if len(bs)!=2:continue
            n0,n1=nodes[bs[0]],nodes[bs[1]]
            c0=(y1-y0*n1)*pow(n0-n1,-1,p)%p;c1=(y0-c0)%p
            add('amplitudes',11+I+(2 if c0 and c1 else 0),mul=2+M,sub=3,inv=1)
            if not(c0 and c1):continue
            terms=list(zip(bs,(c0,c1)))
        s=len(terms)
        add('verify',(5*s+7)*N,mul=(s+1)*N,add=s*N)
        if synth(N,p,w,a,terms)==x:
            output(a,s);return stages,field,inverses
    add('terminal',1)
    return stages,field,inverses

def audit_ledger(record,result):
    stage_expected,field_expected,inverses=predict(record)
    actual_stages=Counter();actual_field=Counter();actual_inv=0
    meter=result['meter']
    assert meter['used']==sum(meter['counts'].values())
    assert meter['used']+meter['remaining']==meter['budget']
    for name,value in meter['counts'].items():
        stage,event=name.split('.');actual_stages[stage]+=value
        if event in ('field_mul','field_add','field_sub'):actual_field[event]+=value
        if event=='inverse':actual_inv+=value
    assert actual_stages==+stage_expected,(record,actual_stages,stage_expected)
    assert actual_field==+field_expected,(actual_field,field_expected)
    assert actual_inv==inverses<=8


def run():
    result={'scope':'Producer controls; separate source-bound reviewer required','exhaustive':[]}
    completed=0;outputs=0
    for N,p in ((3,7),(4,5),(3,13),(4,13)):
        w=root(N,p);members=0
        for values in itertools.product(range(p),repeat=N):
            record=dict(N=N,p=p,omega=w,x=list(values))
            expected=support_oracle(record)
            actual=implementation.execute(record)
            assert (actual['status']=='MEMBER')==bool(expected),(record,actual,expected)
            verify(record,actual);audit_ledger(record,actual)
            if expected:members+=1;outputs+=N
            completed+=1
        result['exhaustive'].append(dict(N=N,p=p,omega=w,raw_vectors=p**N,members=members))
    cases={
      'four_genuine_phases':dict(N=8,p=17,omega=2,x=[2,0,2,0,2,0,2,0]),
      'false_filter_and_prefix':dict(N=8,p=17,omega=2,x=[1,1,1,1,2,1,1,1]),
      'repeated_quadratic_node':dict(N=8,p=17,omega=2,x=[1,2,3,4,5,6,16,0]),
      'absent_rank_one_node':dict(N=8,p=17,omega=2,x=[pow(3,j,17) for j in (0,1,2,3,4,5,-2,-1)]),
      'leading_zero_cancellation':dict(N=8,p=17,omega=2,x=synth(8,17,2,3,[(1,1),(5,16)])),
      'zero':dict(N=4,p=5,omega=2,x=[0]*4),
      'periodic_N3':dict(N=3,p=7,omega=2,x=synth(3,7,2,2,[(0,1),(2,6)])),
      'rank_one':dict(N=5,p=11,omega=3,x=synth(5,11,3,3,[(4,7)])),
    }
    result['adversarial']={}
    for name,r in cases.items():
        out=implementation.execute(r,trace=True);oracle=support_oracle(r)
        assert (out['status']=='MEMBER')==bool(oracle)
        verify(r,out);audit_ledger(r,out)
        if name=='four_genuine_phases':assert len(oracle)==4 and out['meter']['counts']['filter_scan.write']==4
        result['adversarial'][name]={'status':out['status'],'work':out['meter']['used'],'canonical_witness_count':len(oracle),'record':r,'counts':out['meter']['counts']}
    # Explicit unsupported root discovery, invalid root/composite and late data.
    invalids={
      'composite_zero':dict(N=4,p=9,omega=2,x=[0]*4),
      'short_order_zero':dict(N=4,p=5,omega=4,x=[0]*4),
      'wrong_final_order':dict(N=3,p=13,omega=2,x=[0]*3),
      'last_coordinate_bool':dict(N=4,p=5,omega=2,x=[1,2,3,True]),
      'last_coordinate_out_of_range':dict(N=4,p=5,omega=2,x=[1,2,3,5]),
      'root_discovery_unsupported':dict(N=4,p=5,omega=None,x=[0]*4),
      'N2_excluded':dict(N=2,p=5,omega=4,x=[1,0]),
      'oversized_N':dict(N=513,p=65537,omega=2,x=[]),
      'oversized_p':dict(N=4,p=65541,omega=2,x=[0]*4),
      'extra_key':dict(N=4,p=5,omega=2,x=[0]*4,extra=0),
      'missing_key':dict(N=4,p=5,omega=2),
      'list_subclass':None,
    }
    class ListSubclass(list):pass
    class IntSubclass(int):pass
    class DictSubclass(dict):pass
    invalids['list_subclass']=dict(N=4,p=5,omega=2,x=ListSubclass([0]*4))
    invalids['integer_subclass']=dict(N=IntSubclass(4),p=5,omega=2,x=[0]*4)
    invalids['record_subclass']=DictSubclass(dict(N=4,p=5,omega=2,x=[0]*4))
    invalids['bool_header']=dict(N=True,p=5,omega=2,x=[0]*4)
    invalids['wrong_record']=[]
    result['invalid']={}
    for name,r in invalids.items():
        out=implementation.execute(r,trace=True)
        assert out['status']=='INVALID',(name,out)
        assert implementation.execute(r,0)['status']=='LIMIT'
        result['invalid'][name]={'work':out['meter']['used'],'reason':out['reason']}
    for b in (-1,True,1.0,20_000_001):
        assert implementation.execute(cases['zero'],b)['status']=='INVALID'
    assert implementation.execute(cases['zero'],trace=1)['status']=='INVALID'
    # Complete interruption prefixes and actual returned field arithmetic calls.
    arithmetic=Counter();original={}
    for name in ('add','sub','mul'):
        original[name]=getattr(implementation._Field,name)
        def wrapper(self,a,b,_name=name):
            value=original[_name](self,a,b)
            arithmetic[self.m.stage+'.field_'+_name]+=1
            return value
        setattr(implementation._Field,name,wrapper)
    interruptions=[];prefix_count=0
    try:
        for name,r in list(cases.items())+[(k,invalids[k]) for k in ('composite_zero','short_order_zero','wrong_final_order','last_coordinate_bool','root_discovery_unsupported')]:
            full=implementation.execute(r,trace=True);U=full['meter']['used'];trace=full['meter']['trace']
            saved=copy.deepcopy(r)
            for budget in range(U+1):
                arithmetic.clear();got=implementation.execute(r,budget,trace=True)
                assert r==saved
                assert got['meter']['used']==budget
                assert got['meter']['trace']==trace[:budget]
                claimed={k:v for k,v in got['meter']['counts'].items() if '.field_' in k}
                assert dict(arithmetic)==claimed,(name,budget,arithmetic,claimed)
                if budget<U:
                    assert got['status']=='LIMIT' and set(got)=={'status','meter'}
                    assert got['meter']['denied_event']==trace[budget]
                else:
                    assert {k:v for k,v in got.items() if k!='meter'}=={k:v for k,v in full.items() if k!='meter'}
                prefix_count+=1
            interruptions.append({'name':name,'terminal_status':full['status'],'completed_work':U,'budget_prefixes':U+1,'last_events':trace[-5:]})
    finally:
        for name,fn in original.items():setattr(implementation._Field,name,fn)
    result['every_unit_interruptions']=interruptions
    result['interruption_prefixes']=prefix_count
    # Every canonical input phase, including endpoints and composite lengths.
    result['all_phase_structured']=[]
    for N,p in ((3,7),(4,5),(5,11),(6,7),(8,17),(12,13),(16,17),(32,97),(64,257),(128,257),(256,257),(512,65537)):
        w=root(N,p);count=0;maxwork=0
        for a in range(N//math.gcd(2,N)):
            for terms in ([(1,1),(N-1,p-1)],[(0,2),(N//2,3)]):
                r=dict(N=N,p=p,omega=w,x=synth(N,p,w,a,terms))
                out=implementation.execute(r)
                assert out['status']=='MEMBER'
                verify(r,out);audit_ledger(r,out)
                maxwork=max(maxwork,out['meter']['used']);count+=1;outputs+=N
        result['all_phase_structured'].append(dict(N=N,p=p,omega=w,cases=count,max_work=maxwork))
    rng=random.Random(20261012)
    random_counts=Counter()
    for _ in range(400):
        N,p,w=rng.choice([(5,11,3),(6,7,3),(8,17,2),(12,13,2),(16,17,3)])
        r=dict(N=N,p=p,omega=w,x=[rng.randrange(p) for j in range(N)])
        out=implementation.execute(r);oracle=support_oracle(r)
        assert (out['status']=='MEMBER')==bool(oracle)
        verify(r,out);audit_ledger(r,out);random_counts[out['status']]+=1
    result['random_raw']=dict(random_counts)
    result['exhaustive_raw_vectors']=completed
    result['direct_DFT_coordinate_checks']=outputs
    result['verdict']='PASS'
    result['source_sha256']=hashlib.sha256((HERE/'chirp_executor.py').read_bytes()).hexdigest()
    result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE/'fresh_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('verdict','exhaustive_raw_vectors','interruption_prefixes','direct_DFT_coordinate_checks','source_sha256')},indent=2))

if __name__=='__main__':run()
