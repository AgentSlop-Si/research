# Supplied-root rank-two bounded executor

## Scope

`chirp_executor.execute(record, budget=20_000_000, trace=False)` is a standalone,
resident-input API. It does not replace the accepted general-rank or rank-one
entry point. The first implementation intentionally requires a supplied root;
`omega=None` is `INVALID`, and optional deterministic root discovery remains open.
The mathematical recognition theorem and fixed-rank linear field-work route
already exist. The new deliverable is source-bound execution and accounting.

The exact built-in dict has exactly the exact-string keys `N,p,omega,x`. Headers
are exact integers (no booleans/subclasses): `3<=N<=512`, prime `5<=p<=65537`,
`N|(p-1)`, and `1<=omega<p` of exact order N. `x` is an exact list of N exact
integers in `[0,p)`. The resident input must remain unmutated during a call.
Integer/list/dict subclasses and implicit coercions are unsupported. Budget is
an exact integer in `[0,20000000]`; trace is an exact boolean. Only validation
of these two execution options is an unmetered bootstrap; invalid options return
`INVALID` with zero work. No other domain rectangle/default budget promise is
used as evidence that a call completed.

`MEMBER` returns N, p, omega, a, sorted distinct nonzero `[frequency,amplitude]`
pairs (zero, one or two), and all N positive-sign unnormalized DFT entries X.
It proves `x[j]=omega^(a*j*j)*sum(c*omega^(b*j))`, with
`0<=a<N/gcd(2,N)`. Any fully verified witness suffices. It does not assert phase
identifiability. `NONMEMBER` exhausts all filtered phases and returns no witness
or transform. `INVALID` reports a detected malformed/out-of-domain input.
`LIMIT` is indeterminate and can occur before invalidity is detected. Neither
`LIMIT` nor `NONMEMBER` publishes any partial mathematical result. Invalidity
is a paid failed predicate, so it does not need a further publication event.
Completed positive and negative mathematical decisions pay a terminal publish.

## Algorithm and correctness boundary

Complete raw validation/copy and first-nonzero-center selection precede trial
primality and root-order validation. Zero is accepted only after all three.
The root table is made by N paid multiplications; intermediate return to one
or final failure to return to one invalidates the supplied root.

The original nonzero quartic `z^3-2zuv*t+(u^2V+Uv^2)*t^3-zUV*t^4` is retained.
All L=N/gcd(2,N) phase points are scanned before recovery begins. At most four
candidates survive. At each candidate, four periodic dechirped moments include
N=3's reuse of index zero. Delta=0 follows the checked one-node route; Delta!=0
computes Delta inverse ONCE and reuses it for S and P. The complete root grid
is scanned on every reached route. Two distinct nodes then require only the
second inverse of their difference. Coefficients must be nonzero.

Every reached candidate reconstructs and compares all N raw coordinates,
including those after its first mismatch. Rejection eliminates only that phase.
For the first verified witness the shared Gauss row uses its N-term seed,
correct affine support coset, and K-1 orbit recurrence steps. Mixture outputs
are generated in linear work; no dense DFT, inverse DFT, root-search oracle,
generic polynomial-root oracle, or dense N-by-N matrix occurs in the executor.
The exact identities and completeness proof are in the unchanged parent
`chirp_rank2_next_gate.md` and independent design review.

## Exact named-event model

Each admitted event costs one unit. `_Meter.tick` checks the remaining allowance
BEFORE incrementing counters; the next denied event is recorded without charge.
Field operations and data reads/writes occur after admission. Each `index` event
executes one explicitly written bounded integer expression via a thunk after
admission (including modulo, bit length, integer products and shifts). This is
one named expression event, not a count of its primitive integer instructions.
A `check` event charges the observation/decision of a built-in predicate; its
Python argument expression and scalar binding are not separately metered.
`compare` charges an equality test. All event names are stage-qualified.

- `field_add`, `field_sub`, `field_mul`: one operation reduced modulo p.
- `inverse`: starts a checked nonzero Fermat inverse, NOT a substitute for its
  work. All bit visits, exponent/bit index expressions, multiplications and
  final inverse check are separately paid.
- `read`, `write`: indicated array/dict access or append/overwrite. Fixed-size
  scalar tuple binding is outside the model; list allocation headers, Python
  reference management and loop mechanics are outside it too.
- `check`, `compare`, `index`, `gcd_step`, `pow_bit`: explicitly named validation,
  decision, bounded integer expression and algorithmic step events.
- Named `*_visit`, `center_test`, `center_write`, `mismatch_update`: the exact
  source-stated visit/selection/accumulation events, including every raw, phase,
  grid, seed, recurrence, output and final-copy visit.
- `header_write`, `term_pair`, `container_write`, `publish`: full output
  materialization and atomic publication. A denied final scalar write, container
  write or publish withholds the entire result, even if private buffers exist.

Budget/report formatting, event-counter maintenance, optional label trace,
exception unwinding and returning a failure diagnostic are outside this named
algorithmic ledger. No private mathematical values occur in failure telemetry.
The trace is diagnostic instrumentation; only its labels are exposed. Default
trace=False has O(N) live field arrays and constant-size event counters. A full
trace additionally occupies O(named work) labels, including primality work.
This is not CPU/bit/process-memory/wall-clock certification or an optimized FFT
comparison. Source pinning, source review and executed-prefix tests matter.

## Complete-route ledger predictions

Here are total named-event formulas; the checker also predicts every field
operation count. Let T=floor(sqrt(p))-1 for a valid prime, h(u,v) be the number
of Euclidean divisions for gcd(u,v), ell=bit_length(p-2), w=popcount(p-2), and
I=6+3ell+w. Each inverse has ell+w+1 actual field multiplications (the final
verification multiplication included), two checks, ell bit visits, ell+2 index
events and one inverse event.

- Valid input validation: 29+6N+epsilon, epsilon=1 iff nonzero raw input.
- Complete prime trial: 6T+2, including the final failed loop guard; invalid
  composites retain the actual tested prefix through the failed divisor check.
- Valid supplied-root table/order check: 4N.
- Nonzero quartic coefficients/center lookups: 40+2h(2,N), with 11 multiplies,
  one add and two subtractions. Five cyclic reads are explicit even if repeated.
- Full phase filter: 17L+C for C surviving candidates; 4L multiplies, 4L adds.
- Each attempted candidate: two selection events and 28 moment events;
  the moments have four multiplies.
- Delta=0,y0=0 solve: 5. Delta=0,y0!=0 solve: 6+I.
  Delta!=0 solve: 12+I. The latter has eight ordinary solve multiplies,
  three subtractions plus the inverse's internal multiplies.
- Rank-one grid with r matches: 3N+r+1, plus two events if r=1 to read the
  frequency and append its term. Full grid even after an early match.
- Rank-two grid with r matches: 7N+r+1, with 2N multiplies, N adds, N subs.
- Reached amplitude recovery: 11+I, plus two term writes if both are nonzero;
  two ordinary multiplies and three subtractions, plus inverse internals.
- Each reached full raw verification with s terms: (5s+7)N; (s+1)N multiplies,
  sN adds, N comparisons and N mismatch updates, regardless of outcome.
- Zero Gauss buffer: 2N. Nonzero Gauss stage with d=gcd(2a,N), K=N/d:
  6N+2h(2a,N)+4+6(K-1); N adds and K-1 multiplies. This includes all initialized
  zeros and support preparation, even when a=0 or the seed is zero.
- Mixture stage: 2N for zero, 6N for rank one, 11N for rank two; respectively
  zero, N, 2N multiplies and respectively zero, zero, N adds.
- MEMBER materialization: 7+3s+3N, followed by one terminal publish.
- NONMEMBER: one terminal publish after all attempted candidates.

Add all attempted/rejected routes, not only the accepted one. For zero the
closed total is 39+17N+6T. For invalid prefixes, the exact source's event sequence
stops at the first failed check, with all prior events retained. All truncated
calls must be the exact admitted prefix of their unlimited execution; tests
check every unit for representative routes and exact final-output boundaries.

At most four candidates and at most two inverses per candidate give at most
eight scalar inverses. Supplied-root field additions/multiplications are
O(N+log p); complete named work is O(N+sqrt(p)+log p), including primality.
Default live field-array storage is O(N). These are bounded-source structural
claims. General-rank integration, optional root discovery, legacy dispatch,
min(B,H), numerical stability, bit complexity, FFT speed and priority are open
or separately scoped and are not promoted by this implementation.
