# Bounded rank-two common-chirp executor

Date: 12 October 2026 UTC.

## Current result

The supplied-root-only exact executor is independently accepted at its bounded
named-event scope. Producer and independently authored reviewer controls pass.
This is execution/accounting progress for an already accepted fixed-rank recognition theorem; it is not a
new rank-two theorem, a new Prony method, an FFT speed claim, or priority clearance.

Source SHA-256: `efc0b42360c1433fd1bf5da8f61f795a5d80ebedd592f3cba877dd9eca0690a8`.

The implementation covers the baseline primitive-N-root, positive-sign DFT
family for 3<=N<=512 and prime 5<=p<=65537 with N dividing p-1. It checks all
parameters and raw values before zero acceptance. It scans every canonical
phase-filter point, attempts candidates in ascending phase order, caches each
nonzero Delta inverse, scans every grid node on reached recovery routes,
reconstructs all original coordinates even after a mismatch, and computes every
output using a shared Gauss row. At most four candidates and eight scalar
inversions are possible. There is no dense DFT fallback in the executor.

The public outcomes remain distinct: INVALID means detected invalid input,
NONMEMBER means complete family rejection, and LIMIT is indeterminate. A denied
last output write or terminal publication yields LIMIT without any witness,
root, or transform. A supplied `omega=None` is explicitly INVALID; optional
root discovery is not silently performed.

## Reproducible producer evidence

`fresh_check.py` uses complete dechirped inverse-Fourier support as its membership
oracle and direct DFT sums as its output oracle, without taking answers from
implementation telemetry. It separately predicts stage totals and field counts
from raw input/routes and the closed event formulas in CONTRACT.md.

- 31,726 exhaustive raw vectors: all 343 over N=3,F7; all 625 over N=4,F5;
  all 2,197 over N=3,F13; all 28,561 over N=4,F13. Accepted counts are respectively
  271, 177, 1,189 and 1,489. No membership disagreement.
- 1,054 structured rank-two cases cover every canonical input phase at N=3,4,5,
  6,8,12,16,32,64,128,256,512, with cancellation and endpoint p=65537.
- 360,812 direct-DFT output-coordinate checks in the exhaustive/structured
  suites. The additional named adversaries and boundary checks also use direct
  DFT verification, but are not included in this coordinate count.
- 400 reproducible random raw-vector controls use the complete support oracle.
- 4,273 every-unit budget prefixes cover MEMBER, NONMEMBER, malformed data,
  composite modulus, invalid root and unsupported discovery. Each trace is the
  exact admitted prefix of the completed trace; completed Field.add/sub/mul
  calls reconcile exactly to corresponding paid counters, including cutoffs
  within inversion.
- `boundary_check.py` adds 12 exact last-scalar-write, last-container-write and
  final-publication denials, including N=512,p=65537, and four exact-budget
  completion controls. All withhold the whole result when interrupted.

The explicit four-phase ambiguity retains all four phase-filter roots and
returns a valid any-witness answer: on N=8,p=17,omega=2,
`x=[2,0,2,0,2,0,2,0]` completes in 720 events, with witness
`a=0, terms=[[0,1],[4,1]]` and `X=[8,0,0,0,8,0,0,0]`.
The false-prefix vector `[1,1,1,1,2,1,1,1]` rejects in 721 events, after
16 raw-coordinate reconstructions across its two failed candidates. It never
promotes a vanishing quartic or a four-moment fit to membership.
The repeated-node control reaches a complete rank-two grid scan and finds only
one distinct node; an absent-node control reaches an unmatched rank-one scan.

The largest named work among the structured controls was 35,373 events at
N=512,p=65537. This is an observed test maximum, not a universal runtime claim.
The finite budget maximum is 20,000,000 named events. No performance comparison
with an optimized FFT was made.

## Independent acceptance

The separately authored `../next_cycle_chirp_review/INDEPENDENT_REVIEW.md`
accepts final source `efc0b42360c1433fd1bf5da8f61f795a5d80ebedd592f3cba877dd9eca0690a8`
and the exact CONTRACT.md. It reports 1,296 fresh complete decisions (669
members, 627 nonmembers), 17,814 independently recomputed DFT coordinates,
130 exact per-stage ledger predictions, and 4,475 cutoff runs. The last count
includes 1,556 consecutive final-stage denials at N=512,p=65537. Its independent
field-call reconciliation and deliberately corrupted-output control both pass.

The reviewer inspected the complete source, proved the witness/output route
against the declared identities, and accepted the distinctions among MEMBER,
NONMEMBER, INVALID and LIMIT. Acceptance closes the standalone supplied-root
implementation/accounting gate only; it is internal project review, not external
peer review or historical-priority clearance. Reviewer results are separate
from, and not added to, the producer counts above. The reviewer also cold-replayed
all three suites in an isolated directory; all three result JSON files were
byte-identical (see its COLD_REPLAY.json).

## Paid model and remaining scope

The source and CONTRACT.md define an exact named field/data-event model. Field
operations and array reads/writes are admitted before execution; integer/index
expressions are explicitly paid thunks. Predicate observations, visits, actual
trial-divisor work, root preparation, inversion internals, failed candidates,
verification, zero initialization, output copies and terminal publication are
included. Python interpreter steps, scalar bindings, allocation headers,
telemetry formatting and diagnostic exception handling are explicitly outside
this model. Default storage is linear in N field entries; optional full traces
also store the named-work label sequence.

For supplied-root completed calls, field work is O(N+log p). Including trial
primality, named work is O(N+sqrt(p)+log p). These qualifications are integral
to the claim. The implementation does not establish CPU/bit/process-memory
complexity, numerical robustness, general-rank production integration, min(B,H),
optional root discovery, FFT speed, or historical novelty.

No frozen source, ranking score, external workbook cell, legacy dispatcher or
accepted rank-one source was edited. The next-task assessment is a separate
additive proposal in NEXT_TASK.json, not a change to frozen priority 64.

## Reproduction

From this directory, with Python 3.10+ and no third-party packages:

1. `python fresh_check.py` regenerates fresh_results.json.
2. `python boundary_check.py` regenerates boundary_results.json.
3. In ../next_cycle_chirp_review, run independent_check.py,
   ledger_atomicity_check.py and hard_boundary_check.py. These independently
   authored tests bind the exact reviewed source snapshot.

The test-only direct Fourier oracles deliberately have quadratic work. They
are outside the executor and are not presented as structural execution.
