"""Record hashes of this additive delivery; verify unchanged source bindings."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bindings=json.loads((HERE/'SOURCE_BINDINGS.json').read_text())
for relative,digest in bindings.items():
    assert sha(HERE.parent/relative)==digest,relative
entries=[]
for p in sorted(HERE.iterdir()):
    if p.is_file() and p.name!='MANIFEST.json':
        entries.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'scope':'Additive bounded rank-two CHIRP executor delivery','source_sha256':sha(HERE/'chirp_executor.py'),'source_bindings_verified':True,'files':entries}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'PASS: {len(entries)} files pinned; all frozen input bindings unchanged.')
