"""Independent route totals and observed successful arithmetic-call accounting."""
import collections, hashlib, json, math, pathlib
from independent_check import execute, module, dft
HERE=pathlib.Path(__file__).resolve().parent
calls=collections.Counter()
for name,event in [('add','field_add'),('sub','field_sub'),('mul','field_mul')]:
    old=getattr(module._Field,name)
    def wrapper(self,*args,_old=old,_event=event):
        key=self.m.stage+'.'+_event
        answer=_old(self,*args)
        calls[key]+=1
        return answer
    setattr(module._Field,name,wrapper)
def run(r,b=20_000_000):
    calls.clear();ans=execute(r,budget=b,trace=True)
    obs={k:v for k,v in ans['meter']['counts'].items() if k.rsplit('.',1)[-1] in ('field_add','field_sub','field_mul')}
    assert dict(calls)==obs,(r,b,calls,obs)
    return ans
def h(a,b):
    n=0
    while b:a,b=b,a%b;n+=1
    return n
def totals(r,ans):
    N,p,w,x=r['N'],r['p'],r['omega'],r['x'];stage=collections.Counter()
    for key,value in ans['meter']['counts'].items():stage[key.split('.')[0]]+=value
    ell=(p-2).bit_length();I=6+3*ell+(p-2).bit_count()
    predicted={'validation':29+6*N+int(any(x)), 'prime':6*(math.isqrt(p)-1)+2,'root':4*N,'terminal':1}
    if any(x):
        center=next(i for i,v in enumerate(x) if v);z=x[center];u=x[(center-1)%N];v=x[(center+1)%N];U=x[(center-2)%N];V=x[(center+2)%N]
        phases=[]
        for a in range(N//math.gcd(2,N)):
            t=pow(w,-2*a%N,p)
            if (z**3-2*z*u*v*t+(u*u*V+U*v*v)*t**3-z*U*V*t**4)%p==0:phases.append(a)
        predicted['filter_coeff']=40+2*h(2,N)
        predicted['filter_scan']=17*(N//math.gcd(2,N))+len(phases)
        for a in phases:
            predicted['candidate']=predicted.get('candidate',0)+2;predicted['moments']=predicted.get('moments',0)+28
            y=[x[j%N]*pow(w,-a*j*j%N,p)%p for j in range(4)]
            delta=(y[0]*y[2]-y[1]**2)%p
            if delta==0:
                predicted['solve']=predicted.get('solve',0)+5
                if y[0]==0:continue
                predicted['solve']+=1+I
                target=y[1]*pow(y[0],-1,p)%p
                bs=[b for b in range(N) if pow(w,b,p)==target]
                predicted['rank1_grid']=predicted.get('rank1_grid',0)+3*N+len(bs)+1
                if len(bs)!=1:continue
                predicted['rank1_grid']+=2;terms=[(bs[0],y[0])]
            else:
                predicted['solve']=predicted.get('solve',0)+12+I
                S=(y[0]*y[3]-y[1]*y[2])*pow(delta,-1,p)%p;P=(y[1]*y[3]-y[2]**2)*pow(delta,-1,p)%p
                bs=[b for b in range(N) if (pow(w,2*b,p)-S*pow(w,b,p)+P)%p==0]
                predicted['rank2_grid']=predicted.get('rank2_grid',0)+7*N+len(bs)+1
                if len(bs)!=2:continue
                c=(y[1]-y[0]*pow(w,bs[1],p))*pow((pow(w,bs[0],p)-pow(w,bs[1],p))%p,-1,p)%p
                terms=[(bs[0],c),(bs[1],(y[0]-c)%p)]
                predicted['amplitudes']=predicted.get('amplitudes',0)+11+I
                if any(v==0 for _,v in terms):continue
                predicted['amplitudes']+=2
            s=len(terms);predicted['verify']=predicted.get('verify',0)+(5*s+7)*N
            if all(x[j]==pow(w,a*j*j%N,p)*sum(c*pow(w,b*j%N,p) for b,c in terms)%p for j in range(N)):break
    if ans['status']=='MEMBER':
        s=len(ans['terms']);a=ans['a']
        if s:
            d=math.gcd(2*a,N);K=N//d
            predicted['gauss']=6*N+2*h(2*a,N)+4+6*(K-1)
        else:predicted['gauss']=2*N
        predicted['mixture']=[2,6,11][s]*N
        predicted['materialize']=7+3*s+3*N
        assert ans['X']==dft(x,p,w)
    assert dict(stage)==predicted,(r,dict(stage),predicted)
    return predicted
def main():
    cases=[{'N':8,'p':17,'omega':2,'x':[2,0,2,0,2,0,2,0]},
           {'N':8,'p':17,'omega':2,'x':[1,1,1,1,2,1,1,1]},
           {'N':8,'p':17,'omega':2,'x':[0,1,0,0,0,0,0,0]},
           {'N':3,'p':7,'omega':2,'x':[0,1,2]}]
    records=[];cutoffs=0;complete=0
    for r in cases:
        full=run(r);pred=totals(r,full);B=full['meter']['used'];complete+=1
        for b in range(B):
            t=run(r,b);assert set(t)=={'status','meter'} and t['status']=='LIMIT'
            assert t['meter']['trace']==full['meter']['trace'][:b]
            assert t['meter']['denied_event']==full['meter']['trace'][b]
            assert t['meter']['used']==b;cutoffs+=1
        exact=run(r,B);assert exact['status']==full['status'];assert exact.get('X')==full.get('X')
        records.append({'input':r,'status':full['status'],'terms':full.get('terms'),'events':B,'predicted_stages':pred})
    # Every canonical phase, including leading cancellation, at varied grids.
    for N,p,w in [(3,7,2),(4,5,2),(6,13,4),(8,17,2),(12,13,2),(16,97,8),(32,97,19)]:
        assert pow(w,N,p)==1 and all(pow(w,k,p)!=1 for k in range(1,N))
        for a in range(N//math.gcd(2,N)):
            for cs in [(1,1),(1,p-1),(1,0)]:
                x=[pow(w,a*j*j%N,p)*(cs[0]+cs[1]*pow(w,j,p))%p for j in range(N)]
                r={'N':N,'p':p,'omega':w,'x':x};ans=run(r);assert ans['status']=='MEMBER';totals(r,ans);complete+=1
    for r in [{'N':4,'p':9,'omega':2,'x':[1]*4},{'N':8,'p':17,'omega':1,'x':[0]*8},{'N':8,'p':17,'omega':2,'x':[1]*7+[17]}]:
        full=run(r);assert full['status']=='INVALID'
        for b in range(full['meter']['used']):
            ans=run(r,b);assert ans['status']=='LIMIT' and set(ans)=={'status','meter'};cutoffs+=1
        assert run(r,full['meter']['used'])['status']=='INVALID'
    # Bounded negative controls for witness/output verification.
    r=cases[0];ans=run(r);bad=ans['X'].copy();bad[-1]=(bad[-1]+1)%17
    assert bad!=dft(r['x'],17,2)
    return {'passed':True,'source_sha256':hashlib.sha256((HERE/'reviewed_executor_snapshot.py').read_bytes()).hexdigest(),'completed_stage_predictions':complete,'additional_every_event_cutoffs':cutoffs,'arithmetic_reconciliation':'Successful field add/sub/mul wrapper calls equal reported admitted counts for every completed and truncated call.','cases':records,'exclusions':['Named-event model; primitive host instructions, parsing, Python containers, telemetry and bit cost excluded as disclosed.','Original source unchanged.']}
if __name__=='__main__':
    result=main();(HERE/'LEDGER_ATOMICITY_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
