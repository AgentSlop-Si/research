# Independent review: bounded supplied-root rank-two CHIRP executor

12 October 2026 UTC. Internal project review; no external peer-review or historical-priority claim.

## Decision

**ACCEPT at the exact bounded, supplied-root, named-event scope below.**

- Reviewed final program SHA256: `efc0b42360c1433fd1bf5da8f61f795a5d80ebedd592f3cba877dd9eca0690a8`.
- Reviewed contract SHA256: `5c1309efb97c2002ef4e2d06491629ac9f746f8e601fef239a4be92d63d5ce3d`.
- Interface: resident exact built-in record; `3 <= N <= 512`, supplied prime `5 <= p <= 65537`, `N | p-1`, supplied root checked to have exact order N, and N canonical field residues. Budget and trace options have the separately disclosed unmetered bootstrap.
- Family: zero, or at most two distinct nonzero exponential modes multiplied by one common quadratic chirp in the primitive-N-root baseline family.
- On `MEMBER`, one fully verified canonical-phase witness and every positive-sign unnormalized DFT output are returned. `NONMEMBER` exhausts the complete candidate family. `INVALID` and `LIMIT` retain their distinct detected-invalidity and indeterminate meanings.
- Supplied-root field arithmetic is O(N + log p), including inverse internals; complete **named** work is O(N + sqrt(p) + log p), including primality trials. Default live field arrays are O(N); optional diagnostic traces are O(named work).

This closes the specifically declared standalone bounded rank-two structural execution/accounting gate. It does not newly prove general-rank recognition, change the accepted rank-one interface, implement optional root discovery, integrate a legacy dispatcher, prove min(B,H), certify numerical/bit/physical/CPU costs, or show an FFT speedup. The earlier mathematical theorem and classical Prony/Gauss ingredients keep their attribution.

## What was inspected

All final program text and the full contract were read. The program imports only `collections.Counter`; no old research program, Fourier package or symbolic solver is hidden behind the API. The independent checker imports the pinned program as the object being reviewed, uses no private producer mathematical helper to decide membership, and supplies an independent complete Fourier-support oracle and full direct DFT/witness verification.

The design in `../chirp_rank2_next_gate.md` was read as a dependency, including its nonzero quartic, periodic N=3 case, cancellation controls, finite-field guards and all-phase Gauss support. This is an implementation review of an already established fixed-rank route, not an independent historical novelty audit of that route.

## Completeness and output proof

Full raw validation and copying precede primality and root validation. Zero therefore cannot bypass any of those guards. Trial divisors run through the actual square-root threshold; the root table rejects every early return to one and requires return at N.

For nonzero data, the chosen nonzero coordinate gives the original quartic

`z^3 - 2*z*u*v*t + (u^2*V + U*v^2)*t^3 - z*U*V*t^4`.

Its nonzero constant term makes it a nonzero polynomial of degree at most four. Canonical phase points are distinct. The program tests every N/gcd(2,N) point before trying candidates, so at most four candidates survive and none is lost through a guessed phase, a generic root oracle or a prefix-only test. The original polynomial is retained even at short lengths.

For a true two-node sequence, Delta equals `c0*c1*(lambda0-lambda1)^2` and is nonzero. The source recovers the node sum/product with one cached Delta inverse, scans the entire supplied root grid, obtains distinct nodes, and solves amplitudes with the second inverse. True nonzero one-node sequences have nonzero y0 and zero Delta. The periodic fourth moment is valid at N=3. Cancellation of y0 in a genuine two-node signal therefore does not create a false rejection. A candidate is accepted only after reconstruction of all original N coordinates; every reached verification runs beyond the first mismatch.

For the Gauss row, put d=gcd(2a,N), K=N/d. Shifting the summation variable by K multiplies the sum by `omega^(K*(a*K+c))`; the sum vanishes unless c is congruent to -aK modulo d. Shifting by one gives `G(c+2a)=omega^(-a-c)G(c)`. The source initializes all N entries, computes the N-term seed, traverses exactly K-1 remaining points, and forms every one-/two-mode shifted mixture. These identities hold with the stated primitive-root/field guards at odd, even, composite and nonunit phases, including a=0. No nonzero-seed assumption is imposed.

Soundness follows from the complete raw reconstruction; completeness follows from the quartic and Prony identities. Thus exhausting filtered phases justifies `NONMEMBER`, while all positive outputs follow from the complete shared Gauss row and mixture identity.

## Accounting and atomicity

The accepted model is explicitly the source's named exact-field/data-event model. Field operations, indexed data access, output writes and thunked integer expressions execute after their event is admitted. A check event pays observation of a built-in predicate; Python argument evaluation, scalar/tuple binding, loop machinery, container bookkeeping, diagnostics and telemetry are outside this model as disclosed. It is not a primitive-RAM, bit-operation or physical memory-traffic census.

All preparation, rejected candidates, full raw scans, node scans, inverse multiplication internals, zero-filled Gauss storage, output copies and final publication are present. Independent closed formulas reproduce 130 complete per-stage route ledgers, including all canonical phases on seven small/medium grids, genuine rank-two leading cancellation, one-node recovery, false quartic roots and complete nonmembers. Independently wrapped successful add/sub/mul calls exactly equal the corresponding charged counts for complete and truncated runs; a scalar inverse is not treated as free.

The final source contains the producer's corrected admission ordering for the phase-period gcd: gcd work finishes before the N/gcd division expression is admitted. The earlier source nested paid gcd steps inside an admitted index thunk. Totals and mathematics were unchanged, but that intermediate arrangement is not the reviewed final identity. All independent suites were regenerated after the change.

Every-unit cutoffs reproduce the unlimited trace prefix, identify the exact next denied event, consume precisely the cap, and withhold all mathematical output. In particular, a denial during final scalar copy, container attachment or terminal publication returns only LIMIT plus label/count telemetry. No partial root, witness or DFT vector leaks through failure results. Every test verifies that the input record remains unchanged.

## Fresh independent evidence

`independent_check.py` and `INDEPENDENT_RESULTS.json`:

- 1,296 complete decisions; 669 members and 627 nonmembers.
- Exhaustive raw-vector coverage: all 343 vectors at N=3/F7 and all 625 vectors at N=4/F5.
- 1,080 complete Fourier-support membership-oracle calls; 17,814 independently recomputed direct-DFT coordinates.
- Odd/even/composite sizes from 3 through 512, including p=65537, nonunit phases, leading cancellation and every-coordinate corruptions at N8/16/32.
- 826 every-unit cutoff controls and 27 malformed-input/option controls.

`ledger_atomicity_check.py` and `LEDGER_ATOMICITY_RESULTS.json`:

- 130 completed exact per-stage ledger predictions.
- 2,093 additional every-unit cutoff controls, including genuine rank-two success, four-phase ambiguity, two false phase roots requiring full raw rejection, invalid composite/low-order-root/late-coordinate cases, and cancellation.
- Successful field-call reconciliation on every completed and truncated call; independent witness/output verification rejects a changed final output.

`hard_boundary_check.py` and `HARD_BOUNDARY_RESULTS.json`:

- N=512, p=65537, omega=157, input/returned phase255, with cancellation at coordinate zero and genuine rank two.
- Every one of the 512 DFT coordinates independently recomputed.
- 1,556 consecutive final-stage budget denials, including all final output-copy/container/publication boundaries; exact completion succeeds at the recorded event total.

The totals across the three suites are 4,475 cutoff runs. These are fresh reviewer runs, not copied producer counts. Producer totals and historical suites are separate evidence and are not counted here. `COLD_REPLAY.json` confirms an isolated-directory replay with all three JSON result files byte-identical. The final producer program was also rechecked against the reviewed snapshot.

## Remaining work

Use the bounded implementation as a completed component. Any next task should name a new requirement: a paid optional root-search front end, a source-pinned caller/dispatcher integration, broader field/domain support, growing-r kernels, or a separately declared bit/numerical/performance model. Repeating this exact rank-two gate is not an open obligation absent contradictory evidence. There is no new canonical theorem identity or historical-priority promotion.
