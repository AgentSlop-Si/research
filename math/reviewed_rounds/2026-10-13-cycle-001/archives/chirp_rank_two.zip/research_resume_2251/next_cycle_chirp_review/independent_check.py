"""Independent full-vector Fourier oracle; no producer private helper used."""
import importlib.util, itertools, json, pathlib, hashlib, random
HERE=pathlib.Path(__file__).resolve().parent
SOURCE=HERE/'reviewed_executor_snapshot.py'
spec=importlib.util.spec_from_file_location('reviewed_executor',SOURCE)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
execute=module.execute
COUNTS={}; details=[]
def inc(k,n=1): COUNTS[k]=COUNTS.get(k,0)+n
def root(N,p):
    return next(w for w in range(2,p) if pow(w,N,p)==1 and all(pow(w,j,p)!=1 for j in range(1,N)))
def dft(x,p,w,sign=1):
    return [sum(v*pow(w,(sign*j*k)%len(x),p) for j,v in enumerate(x))%p for k in range(len(x))]
def oracle(x,p,w):
    N=len(x); invN=pow(N,-1,p)
    for a in range(N//__import__('math').gcd(2,N)):
        y=[x[j]*pow(w,(-a*j*j)%N,p)%p for j in range(N)]
        c=[v*invN%p for v in dft(y,p,w,-1)]
        if sum(v!=0 for v in c)<=2:return True
    return False
def check(record,want=None):
    before=json.dumps(record,sort_keys=True)
    r=execute(record,trace=True);m=r['meter'];N=record['N'];p=record['p'];w=record['omega'];x=record['x']
    assert json.dumps(record,sort_keys=True)==before
    assert m['used']==len(m['trace'])==sum(m['counts'].values())
    assert m['remaining']==m['budget']-m['used'] and m['denied_event'] is None
    assert m['counts'].get('filter_scan.phase_visit',0) in (0,N//__import__('math').gcd(2,N))
    assert m['counts'].get('candidate.candidate_visit',0)<=4
    assert m['counts'].get('validation.raw_visit',0)==N
    assert m['counts'].get('verify.raw_visit',0)%N==0
    if want is None:want=oracle(x,p,w);inc('oracle_calls')
    assert r['status']==('MEMBER' if want else 'NONMEMBER'),(record,r,want)
    if want:
        assert set(r)=={'status','N','p','omega','a','terms','X','meter'}
        assert 0<=r['a']<N//__import__('math').gcd(2,N)
        assert len(r['terms'])<=2 and len({t[0] for t in r['terms']})==len(r['terms'])
        assert all(0<=b<N and 0<c<p for b,c in r['terms'])
        rebuilt=[pow(w,r['a']*j*j%N,p)*sum(c*pow(w,b*j%N,p) for b,c in r['terms'])%p for j in range(N)]
        assert rebuilt==x
        assert r['X']==dft(x,p,w);inc('verified_output_bins',N)
        inc('members')
    else:assert set(r)=={'status','meter'};inc('nonmembers')
    inc('decisions');return r
def record(N,p,x):return {'N':N,'p':p,'omega':root(N,p),'x':x}
def run():
    for N,p in [(3,7),(4,5)]:
        w=root(N,p)
        for x in itertools.product(range(p),repeat=N):check({'N':N,'p':p,'omega':w,'x':list(x)})
        details.append({'exhaustive_raw_vectors':{'N':N,'p':p,'count':p**N}})
    rng=random.Random(9127985)
    for N,p in [(3,13),(4,17),(5,11),(6,13),(7,29),(8,17),(9,19),(10,41),(12,37),(16,97),(24,97),(32,97),(64,257),(128,257),(256,65537),(512,65537)]:
        w=root(N,p)
        for a in sorted({0,1,N//2,N-1,rng.randrange(N)}):
            for rank in [0,1,2]:
                bs=rng.sample(range(N),rank);cs=[rng.randrange(1,p) for _ in bs]
                x=[pow(w,a*j*j%N,p)*sum(c*pow(w,b*j%N,p) for b,c in zip(bs,cs))%p for j in range(N)]
                check({'N':N,'p':p,'omega':w,'x':x},True)
        for _ in range(4 if N<=32 else 1):
            x=[rng.randrange(p) for _ in range(N)]
            check({'N':N,'p':p,'omega':w,'x':x})
    # A late-coordinate corruption must not bypass full validation.
    for N,p in [(8,17),(16,97),(32,97)]:
        w=root(N,p);x=[pow(w,j*j%N,p)*(1+2*pow(w,j,p))%p for j in range(N)]
        for j in range(N):
            z=x.copy();z[j]=(z[j]+1)%p;check({'N':N,'p':p,'omega':w,'x':z})
    # Every consumed event cutoff for complete small positive/negative/zero paths.
    for r0 in [record(3,7,[0,0,0]),record(3,7,[1,2,4]),record(4,5,[1,1,2,3]),record(8,17,[1,2,3,4,5,6,7,8])]:
        full=check(r0);B=full['meter']['used']
        for b in range(B):
            r=execute(r0,budget=b,trace=True);m=r['meter']
            assert r['status']=='LIMIT' and set(r)=={'status','meter'}
            assert m['used']==b==len(m['trace'])==sum(m['counts'].values())
            assert m['remaining']==0 and m['denied_event'] is not None
            assert m['trace']==full['meter']['trace'][:b]
            assert m['denied_event']==full['meter']['trace'][b]
            inc('exhaustive_budget_cutoffs')
        exact=execute(r0,budget=B,trace=True)
        assert {k:v for k,v in exact.items() if k!='meter'}=={k:v for k,v in full.items() if k!='meter'}
        details.append({'budget_path':{'N':r0['N'],'x':r0['x'],'status':full['status'],'events':B}})
    valid=record(8,17,[1]*8)
    bad=[None,[],{},dict(valid,extra=1),dict(valid,N=True),dict(valid,N=2),dict(valid,N=513),dict(valid,p=9),dict(valid,p=65538),dict(valid,omega=None),dict(valid,omega=1),dict(valid,omega=0),dict(valid,omega=17),dict(valid,x=(1,)*8),dict(valid,x=[1]*7),dict(valid,x=[1]*7+[True]),dict(valid,x=[1]*7+[-1]),dict(valid,x=[1]*7+[17])]
    # Composite p still satisfying N | p-1 must be rejected by primality trial.
    bad.append({'N':4,'p':9,'omega':2,'x':[1]*4})
    for q in bad:
        r=execute(q);assert r['status']=='INVALID' and 'X' not in r and 'terms' not in r
        inc('invalid_record_controls')
    for b in [-1,True,20000001,1.0,None]:
        r=execute(valid,budget=b);assert r['status']=='INVALID' and r['meter']['used']==0;inc('invalid_option_controls')
    for t in [None,1,'yes']:
        r=execute(valid,trace=t);assert r['status']=='INVALID' and r['meter']['used']==0;inc('invalid_option_controls')
    return {'passed':True,'producer_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'counts':COUNTS,'details':details,'limits':['Named-event model only; Python/bit/physical instruction costs not certified.','Uniform correctness requires the separately reviewed mathematical proof; bounded tests do not replace it.','No historical priority or performance comparison established.']}
if __name__=='__main__':
    r=run();(HERE/'INDEPENDENT_RESULTS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
