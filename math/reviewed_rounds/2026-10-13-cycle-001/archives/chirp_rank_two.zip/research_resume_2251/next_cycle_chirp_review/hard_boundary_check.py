import json,pathlib
from independent_check import root,dft
from ledger_atomicity_check import run,totals
HERE=pathlib.Path(__file__).resolve().parent
N,p=512,65537;w=root(N,p);a=255
x=[pow(w,a*j*j%N,p)*(1-pow(w,7*j%N,p))%p for j in range(N)]
r={'N':N,'p':p,'omega':w,'x':x}
full=run(r);assert full['status']=='MEMBER';pred=totals(r,full);B=full['meter']['used']
assert full['X']==dft(x,p,w)
cuts=[]
for b in range(B-(3*N+20),B):
    cut=run(r,b);assert cut['status']=='LIMIT' and set(cut)=={'status','meter'}
    assert cut['meter']['trace']==full['meter']['trace'][:b]
    cuts.append({'budget':b,'denied':cut['meter']['denied_event']})
assert run(r,B)['X']==full['X']
result={'passed':True,'N':N,'p':p,'omega':w,'input_phase':a,'returned_phase':full['a'],'returned_terms':full['terms'],'events':B,'cutoffs':len(cuts),'final_denied_events':cuts[-8:],'predicted_stages':pred,'independent_DFT_bins':N}
(HERE/'HARD_BOUNDARY_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
