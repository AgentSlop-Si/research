# Bounded antecedent comparison and novelty limits

12 October 2026. Primary source bodies were browsed in this fusion pass. This is a targeted comparison, not an exhaustive literature clearance.

## Readable primary antecedents

1. **Gorodetsky, q-congruences**, arXiv:1805.01254v2, equation (1.5), PDF p.2. The finite q-binomial product is expressly recorded there as an established identity. The diagonal exponential rewriting is immediate coefficient algebra on that identity. The present packet claims no novelty for either input. [Primary PDF](https://arxiv.org/pdf/1805.01254v2)

2. **Schultz–Walker, A generalization of the Gaussian formula and a q-analog of Fleck's congruence**, arXiv:1202.0199v1, Theorem 1.1, PDF p.3; primitive-choice argument p.13. For a cluster root of order 2c with c|d, take their odd block parameter d/c, polynomial weight s(s−1)…(s−ℓ+1), derivative order r, and auxiliary exponent/congruence order zero. Their bound gives the below-weight-A vanishing when 2r+ℓ<A. That vanishing does not on its own specify the first surviving coefficient or establish simplicity of its roots. This direction and limitation agree with the accepted all-order review. [Primary PDF](https://arxiv.org/pdf/1202.0199v1)

3. **Ismail–Witte, Discriminants and functional equations for polynomials orthogonal on the unit circle**, arXiv:math/0012259v2, (1.7)–(1.9), (5.12), Theorem 5.2 and (5.16)–(5.18). Their explicit Rogers–Szegő product in §5 is the q-difference/generalized discriminant, not automatically the ordinary derivative discriminant used here. Already for a quadratic, the invariants differ. The paper also states the usual ordinary resultant–discriminant relation. Neither that relation nor root-product assembly is claimed as new. [Primary PDF](https://arxiv.org/pdf/math/0012259v2)

4. **Sawa–Uchida, Discriminants of classical quasi-orthogonal polynomials**, JMSJ 71 (2019), Theorem 3.8, p.846, and Remark 3.9, p.847. The displayed quasi-Hermite family is the adjacent-degree combination H_n+cH_(n−1), in physicists' convention. Here J_(A+1) is a same-parity degree-gap-two combination. The cited result must not be silently substituted for the actual nonreal-parameter b27 simplicity certificate. Remark 3.9 attributes the ordinary Hermite discriminant product to established work; after normalization it is P_A. [Published primary PDF](https://www.jstage.jst.go.jp/article/jmath/71/3/71_831/_pdf)

5. **Stacks Project, Lemma 10.153.9** and §59.32. Complete local rings have simple-root lifting. The inertia corollary is a standard uniqueness-and-parity deduction from this mechanism once every initial root is simple. Its technical contribution here is the explicit exact cycle count and correct constant-field scope, not a new lifting principle. [Lemma](https://stacks.math.columbia.edu/tag/04GM), [section](https://stacks.math.columbia.edu/tag/03QD)

## Historical boundary

The existing project prior-art audit locates Lubinsky–Saff's static root-of-unity factorization at Lemma 4.5/(4.15), p.346, and separates it from transverse splitting. This pass found the article in [Saff's primary publication list](https://my.vanderbilt.edu/edsaff/research-articles/), but the linked PDF open returned an internal tool error. No content was inferred from that error, and no absence claim is made. Earlier audit reports carry their own time-stamped access limitations; they are not promoted into a statement that material remains unavailable today.

This pass did not independently inspect the complete 1997 Zhedanov body or redo the entire earlier comparison chain. The catalog's historical-priority qualification stays in force. “No exact antecedent located in these selected passages” would be only a bounded observation, not evidence of world-first novelty.

## What can honestly be claimed

- Mathematically compatible accepted inputs now discharge all b27 Section 3.2 guards simultaneously, for every odd d>27 and every A≥1.
- The exact discriminant order and leading coefficient follow from the existing accepted local formula.
- The quadratic splitting/inertia cycle type is derived explicitly and is stronger root-level information than the separate residual and overlap certificates.
- Correctness of the fusion candidate is supported by a proof and fresh tests; its separate independent review remains pending.
- The family specialization may be useful without being a new mechanism. No canonical count, historical novelty status, FFT speed, or broad fusion-family rank is promoted.
