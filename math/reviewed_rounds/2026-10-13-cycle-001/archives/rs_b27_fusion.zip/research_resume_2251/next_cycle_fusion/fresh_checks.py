#!/usr/bin/env python3
"""Independent-style fusion controls; no author/reviewer code is imported.
Only finite controls, never an infinite-range proof. Standard library only.
"""
from pathlib import Path
import json, math, hashlib, time
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name, ok, detail=None):
    checks.append({'name':name,'pass':bool(ok),'detail':detail})
    if not ok: raise AssertionError(name)

def trim(a):
    a=list(a)
    while len(a)>1 and a[-1]==0:a.pop()
    return a

def add(a,b,p):
    c=[0]*max(len(a),len(b))
    for i,x in enumerate(a):c[i]+=x
    for i,x in enumerate(b):c[i]+=x
    return trim([x%p for x in c])
def mul(a,b,p):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]=(c[i+j]+x*y)%p
    return trim(c)
def scale(a,s,p):return trim([s*x%p for x in a])
def divrem(a,b,p):
    a=trim(a);b=trim(b);q=[0]*max(1,len(a)-len(b)+1);bi=pow(b[-1],-1,p)
    while a!=[0] and len(a)>=len(b):
        j=len(a)-len(b);c=a[-1]*bi%p;q[j]=c
        for i,x in enumerate(b):a[i+j]=(a[i+j]-c*x)%p
        a=trim(a)
    return trim(q),a

def resultant(f,g,p):
    f,g=trim(f),trim(g);r=1
    while len(g)>1:
        m,n=len(f)-1,len(g)-1
        rem=divrem(f,g,p)[1]
        if rem==[0]:return 0
        s=len(rem)-1
        r=r*pow(-1,m*n,p)*pow(g[-1],m-s,p)%p
        f,g=g,rem
    return r*pow(g[0],len(f)-1,p)%p

def disc(f,p):
    n=len(f)-1
    if n<=1:return 1
    der=[i*f[i]%p for i in range(1,len(f))]
    return pow(-1,n*(n-1)//2,p)*resultant(f,der,p)*pow(f[-1],-1,p)%p

def evaluate(f,x,p):
    y=0
    for c in reversed(f):y=(y*x+c)%p
    return y

def rs(n,q,p):
    a=[1];b=[1,1]
    if n==0:return a
    for r in range(2,n+1):a,b=b,add(mul([1,1],b,p),scale([0]+a,pow(q,r-1,p)-1,p),p)
    return b

def hermite(n,p):
    a=[1];b=[0,1]
    if n==0:return a
    for r in range(1,n):a,b=b,add([0]+b,scale(a,-r,p),p)
    return b

def jpoly(A,tau,p):return add([0]+hermite(A,p),scale(hermite(A-1,p),-A*tau,p),p)
def isprime(n):return n>1 and all(n%r for r in range(2,math.isqrt(n)+1))
def prime_factors(n):return [r for r in range(2,n+1) if n%r==0 and isprime(r)]
def primitive(d,p):
    for g in range(2,p):
        q=pow(g,(p-1)//d,p)
        if pow(q,d,p)==1 and all(pow(q,d//r,p)!=1 for r in prime_factors(d)):return q
    raise ValueError('no primitive root')
def parameter(d,b,q,p):
    G=rs(b,q,p);U,rem=divrem(G,[1,1],p);assert rem==[0]
    g=evaluate(U,-1,p);num=den=1
    for r in range(1,b+1):num=num*(1-pow(q,r,p))%p
    for r in range(1,(d+b)//2+1):den=den*(1-pow(q,2*r,p))%p
    if not g*den%p:raise ZeroDivisionError
    return G,U,g,d*num*pow(den*g,-1,p)%p

def choose_good(d,b,As):
    for m in range(2,200):
        p=d*m+1
        if p<=max(As)*d+b+10 or not isprime(p):continue
        q=primitive(d,p)
        try:G,U,g,t=parameter(d,b,q,p)
        except ZeroDivisionError:continue
        if disc(U,p) and all(disc(jpoly(A,t,p),p) for A in As) and all(evaluate(U,-pow(q,k,p),p) for k in range(d)):
            return p,q
    raise ValueError('no good finite specialization found')

# sparse bivariate epsilon,x recurrence; coefficients reconstructed directly.
def local_series(n,d,q,alpha,K,p):
    def plus(a,b):
        c=dict(a)
        for key,v in b.items():c[key]=(c.get(key,0)+v)%p
        return {key:v for key,v in c.items() if v}
    def times(a,b):
        c={}
        for (e,i),x in a.items():
            for (f,j),y in b.items():
                if e+f<=K:c[e+f,i+j]=(c.get((e+f,i+j),0)+x*y)%p
        return {key:v for key,v in c.items() if v}
    z={(0,0):alpha%p,(1,1):1};oneplus=plus(z,{(0,0):1})
    a={(0,0):1};b=oneplus
    for r in range(2,n+1):
        exponent=(r-1)*pow(d,-1,p)%p;c=1;qp={(0,0):(pow(q,r-1,p)-1)%p}
        for k in range(1,K//2+1):
            c=c*(exponent-k+1)*pow(k,-1,p)%p;qp[2*k,0]=pow(q,r-1,p)*c%p
        a,b=b,plus(times(oneplus,b),times(qp,times(z,a)))
    return b

def displacement(A,d,alpha,tau,shared,p):
    if shared:
        f=jpoly(A,tau,p);degree=A+1
    else:f=hermite(A,p);degree=A
    out=[0]*(degree+1)
    for k,c in enumerate(f):
        if c:
            assert (degree-k)%2==0
            r=(degree-k)//2
            out[k]=c*pow(d,-r,p)%p
            if not shared:out[k]=out[k]*pow(alpha,2*r,p)%p
    return trim(out)

# Truncated t-series ring and division-free-coefficient H_n, followed by a
# full Sylvester determinant using minimum-valuation pivoting over F_p[[t]].
def smul(a,b,K,p):
    # Exact Kronecker convolution for longer series; base exceeds the full
    # unreduced coefficient bound, so no coefficient carry can mix positions.
    if K>8:
        w=(max(1,K*(p-1)**2).bit_length()+7)//8
        aa=int.from_bytes(b''.join(int(x).to_bytes(w,'little') for x in a[:K]),'little')
        bb=int.from_bytes(b''.join(int(x).to_bytes(w,'little') for x in b[:K]),'little')
        cc=(aa*bb).to_bytes(2*K*w,'little')
        return [int.from_bytes(cc[i*w:(i+1)*w],'little')%p for i in range(K)]
    c=[0]*K
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b[:K-i]):
                if y:c[i+j]=(c[i+j]+x*y)%p
    return c

def sinv(a,K,p):
    assert a[0];b=[pow(a[0],-1,p)]+[0]*(K-1)
    for r in range(1,K):b[r]=-sum(a[i]*b[r-i] for i in range(1,r+1))*b[0]%p
    return b

def rs_series(n,d,q,K,p):
    # list of z coefficients, each a truncated t series
    one=[1]+[0]*(K-1);zero=[0]*K;a=[one[:]];b=[one[:],one[:]]
    def plus(a,b):
        out=[zero[:] for _ in range(max(len(a),len(b)))]
        for src in (a,b):
            for i,c in enumerate(src):out[i]=[(x+y)%p for x,y in zip(out[i],c)]
        return out
    for r in range(2,n+1):
        e=(r-1)*pow(d,-1,p)%p;c=1;qp=[(pow(q,r-1,p)-1)%p]
        for k in range(1,K):c=c*(e-k+1)*pow(k,-1,p)%p;qp.append(pow(q,r-1,p)*c%p)
        a,b=b,plus(plus(b,[zero[:]]+b),[zero[:]]+[smul(qp,c,K,p) for c in a])
    return b

def series_det(M,K,p):
    N=len(M);sign=1;offset=0;unit=[1]+[0]*(K-1)
    def val(a):return next((i for i,x in enumerate(a) if x),K)
    for r in range(N):
        best=(K,None,None)
        for i in range(r,N):
            for j in range(r,N):
                v=val(M[i][j])
                if v<best[0]:best=(v,i,j)
                if v==0:break
            if best[0]==0:break
        v,i,j=best
        if v==K:return [0]*(K+offset)
        if i!=r:M[i],M[r]=M[r],M[i];sign=-sign
        if j!=r:
            for row in M:row[j],row[r]=row[r],row[j]
            sign=-sign
        if v:
            # All active entries have valuation at least v; extract from row r.
            for j in range(r,N):M[r][j]=M[r][j][v:]+[0]*v
            offset+=v;K-=v
            if K<=0:return [0]*offset
            unit=unit[:K]
            for row in M:
                for j in range(N):row[j]=row[j][:K]
        pivot=M[r][r];unit=smul(unit,pivot,K,p);inv=sinv(pivot,K,p)
        for i in range(r+1,N):
            if not any(M[i][r]):continue
            fac=smul(M[i][r],inv,K,p)
            for j in range(r+1,N):
                prod=smul(fac,M[r][j],K,p)
                M[i][j]=[(a-b)%p for a,b in zip(M[i][j],prod)]
            M[i][r]=[0]*K
    return [0]*offset+[sign*x%p for x in unit]

def full_discriminant_series(A,d,b,p,q):
    n=A*d+b;L=d*A*(A-1)//2+A;K=L+2
    f=rs_series(n,d,q,K,p);g=[[i*x%p for x in f[i]] for i in range(1,len(f))]
    fd=list(reversed(f));gd=list(reversed(g));N=2*n-1;zero=[0]*K
    M=[]
    for s in range(n-1):M.append([zero[:] for _ in range(s)]+[c[:] for c in fd]+[zero[:] for _ in range(N-s-len(fd))])
    for s in range(n):M.append([zero[:] for _ in range(s)]+[c[:] for c in gd]+[zero[:] for _ in range(N-s-len(gd))])
    out=series_det(M,K,p);out=[x*pow(-1,n*(n-1)//2,p)%p for x in out]
    return out

def leading_coefficient(A,d,b,p,q):
    G,U,g,tau=parameter(d,b,q,p);PA=math.prod(pow(j,j,p) for j in range(1,A+1))%p
    R=math.prod(evaluate(U,-pow(q,k,p),p) for k in range(d))%p
    C=pow(-1,A*(d-1)//2,p)*pow(d,d*A*(A+1)//2+A,p)*pow(PA,d-1,p)*disc(jpoly(A,tau,p),p)*disc(U,p)*pow(R,2*A,p)*g*g%p
    return C

start=time.time();cases=[]
# Boundary, composite, exceptional d57, far-middle, and tail representative.
for d,As in [(29,[1,2,3,4]),(31,[2,3]),(33,[1,2,3]),(55,[1,2]),(57,[1,2,3,4,7,8]),(65,[3]),(211,[1,2])]:
    b=27;p,q=choose_good(d,b,As);G,U,g,tau=parameter(d,b,q,p)
    check(f'd{d}: primitive exact order',pow(q,d,p)==1 and all(pow(q,d//r,p)!=1 for r in prime_factors(d)),{'p':p,'q':q})
    check(f'd{d}: all four finite guards',g*disc(U,p)*math.prod(evaluate(U,-pow(q,k,p),p) for k in range(d))%p!=0 and all(disc(jpoly(A,tau,p),p) for A in As))
    # All F roots for smaller A; three selected roots for larger A or d.
    for A in As:
        n=A*d+b;L=d*A*(A-1)//2+A;B=(d-1)*(A//2)+(A+1)//2
        check(f'd{d} A{A}: branch count/parity',n-2*B==(27 if A%2==0 else d+25) and L%2==B%2)
        ks=range(d) if d<=65 and A<=4 else [0,1,d-1]
        for k in ks:
            alpha=-pow(q,k,p)%p;shared=k==0;degree=A+int(shared)
            actual=local_series(n,d,q,alpha,degree,p)
            expected=displacement(A,d,alpha,tau,shared,p)
            pref=pow(d,A,p)*g%p if shared else pow(-d*pow(alpha,-1,p),A,p)*evaluate(G,alpha,p)%p
            lead=[actual.get((degree,j),0) for j in range(degree+1)]
            check(f'd{d} A{A} k{k}: all lower weights vanish',all(e>=degree for e,j in actual))
            check(f'd{d} A{A} k{k}: exact initial polynomial',trim(lead)==scale(expected,pref,p))
        # Independent raw product over cluster centers vs compact C formula.
        centers=[-pow(q,k,p)%p for k in range(d)];multiplicities=[A+1]+[A]*(d-1)
        raw=disc(U,p)
        for k,(alpha,m) in enumerate(zip(centers,multiplicities)):
            raw=raw*disc(displacement(A,d,alpha,tau,k==0,p),p)*pow(evaluate(U,alpha,p),2*m,p)%p
        for i in range(d):
            for j in range(i+1,d):raw=raw*pow(centers[i]-centers[j],2*multiplicities[i]*multiplicities[j],p)%p
        C=leading_coefficient(A,d,b,p,q)
        check(f'd{d} A{A}: raw root-product coefficient',raw==C and C!=0)
        cases.append({'d':d,'A':A,'n':n,'p':p,'q':q,'tau':tau,'L':L,'C_mod_p':C,'inertia_transpositions':B,'fixed_branches':n-2*B})

# Full determinant controls include actual b27, with no cluster-product input.
full=[]
for A,d,b in [(1,29,27),(1,33,27),(2,29,27),(2,33,27),(2,3,1),(3,3,1)]:
    p,q=choose_good(d,b,[A]);L=d*A*(A-1)//2+A;out=full_discriminant_series(A,d,b,p,q);C=leading_coefficient(A,d,b,p,q)
    check(f'full Sylvester A{A} d{d} b{b}: exact order and leading coefficient',all(x==0 for x in out[:L]) and out[L]==C and C!=0)
    full.append({'A':A,'d':d,'b':b,'p':p,'q':q,'L':L,'series':out,'predicted_C':C})

# Failure controls: derivative normalization, residual repeats, overlap repeats,
# missing d in tau, even/nonprimitive domain; and actual-vs-q-discriminant.
check('repeated residual detected',disc(mul([1,1],[1,1],101),101)==0)
check('overlap tau=0 A1 rejected',disc(jpoly(1,0,101),101)==0)
check('overlap tau=-1/2 A2 rejected',disc(jpoly(2,-pow(2,-1,101)%101,101),101)==0)
p,q=choose_good(29,27,[1]);G,U,g,t=parameter(29,27,q,p)
lead=local_series(56,29,q,-1,2,p);wrong=scale(displacement(1,29,-1,t*pow(29,-1,p)%p,True,p),29*g,p)
check('omitted d in tau caught by actual initial polynomial',trim([lead.get((2,j),0) for j in range(3)])!=wrong)
check('ordinary and q-discriminants are distinct',((3*3-4*1*1)%101)!=((2*3*3-(1+2)**2)%101))
for d,q,p in [(28,2,29),(33,1,67),(27,2,109)]:
    legal=d>27 and d%2==1 and pow(q,d,p)==1 and all(pow(q,d//r,p)!=1 for r in prime_factors(d))
    check(f'invalid domain d{d} q{q} rejected',not legal)
# Check commonly dropped factors against independently assembled C.
p,q=choose_good(29,27,[2]);G,U,g,t=parameter(29,27,q,p)
C=leading_coefficient(2,29,27,p,q)
check('missing g squared rejected',C!=C*pow(g*g,-1,p)%p)
check('q-minus-omega and t coefficients distinguished',C!=pow(29*pow(q,28,p),31,p)*C%p)
check('wrong overlap exponent rejected',29*2*(2-1)//2+2!=29*2*(2-1)//2)
# Symbolic parity data, broad range beyond finite q examples.
for A in range(1,101):
    for d in [29,33,57,211,1001]:
        n=A*d+27;B=(d-1)*(A//2)+(A+1)//2;L=d*A*(A-1)//2+A
        check(f'combinatorics A{A} d{d}',B>=1 and n-2*B==(27 if A%2==0 else d+25) and (L-B)%2==0)
# Hensel lifting of actual normalized local series, including the zero-slope
# branch. Verify epsilon reversal on coefficients, rather than merely counts.
def substitute_x(R,x,K,p):
    xp=[[1]+[0]*(K-1)]
    for j in range(1,max((j for e,j in R),default=0)+1):xp.append(smul(xp[-1],x,K,p))
    out=[0]*K
    for (e,j),v in R.items():
        if e<K:
            for r in range(K-e):out[e+r]=(out[e+r]+v*xp[j][r])%p
    return out

def lift_slope(R,a,K,p):
    lead=[R.get((0,j),0) for j in range(max(j for e,j in R)+1)]
    deriv=evaluate([j*lead[j]%p for j in range(1,len(lead))],a,p)
    assert deriv
    x=[a]+[0]*(K-1)
    for r in range(1,K):x[r]=-substitute_x(R,x,r+1,p)[r]*pow(deriv,-1,p)%p
    assert substitute_x(R,x,K,p)==[0]*K
    return x

hensel=[]
for A,d,b,shared in [(1,29,27,True),(2,29,27,True),(3,29,27,False)]:
    for m in range(2,500):
        p=d*m+1
        if not isprime(p) or p<A*d+b+10:continue
        q=primitive(d,p)
        try:G,U,g,tau=parameter(d,b,q,p)
        except ZeroDivisionError:continue
        alpha=p-1 if shared else -q%p;f=displacement(A,d,alpha,tau,shared,p)
        roots=[a for a in range(p) if evaluate(f,a,p)==0]
        if len(roots)==len(f)-1 and disc(f,p):break
    else:raise AssertionError('no split finite Hensel control')
    degree=A+int(shared);K=6
    raw=local_series(A*d+b,d,q,alpha,degree+K-1,p)
    R={(e-degree,j):c for (e,j),c in raw.items()}
    check(f'Hensel A{A} shared{shared}: no lower epsilon power',all(e>=0 for e,j in R))
    branches={a:lift_slope(R,a,K,p) for a in roots}
    for a,x in branches.items():
        # z=alpha+epsilon*x. Reversal sends x(eps) -> -x(-eps).
        rev=[(-1)**(r+1)*c%p for r,c in enumerate(x)]
        check(f'Hensel A{A} slope{a}: reversal partner',rev==branches[-a%p])
        if a==0:check(f'Hensel A{A}: zero-slope branch unramified',all(x[r]==0 for r in range(0,K,2)))
    hensel.append({'A':A,'d':d,'b':b,'p':p,'q':q,'shared':shared,'alpha':alpha,'epsilon_order_of_z_checked':K,'x_series_by_slope':branches})

result={'scope':'Finite fusion controls; not a proof of infinite quantifiers','independence':'Fresh standard-library code, no author/reviewer imports or execution','checks':checks,'check_count':len(checks),'all_passed':all(c['pass'] for c in checks),'cases':cases,'full_sylvester_controls':full,'hensel_reversal_controls':hensel,'elapsed_seconds':round(time.time()-start,3)}
(ROOT/'fresh_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['all_passed','check_count','elapsed_seconds']}))
