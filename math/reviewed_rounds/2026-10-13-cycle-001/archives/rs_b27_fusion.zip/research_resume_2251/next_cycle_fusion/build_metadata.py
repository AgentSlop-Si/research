from pathlib import Path
import hashlib,json,shutil
R=Path(__file__).resolve().parent;W=R.parents[1];B=R.parent
sources=[
 ('local_manuscript_v3', W/'rs_manuscript_v3_1704/package/RS_Local_Discriminants_Working_Note_v3.tex','Sections 3.1–3.2, 4–7; conditional initial forms, exact ordinary-discriminant coefficient and parameter conversion','57bc17168b7b11efe7a5bdc7190473267b0c08fcd4f2bb5b9c59f04f1cbfa282'),
 ('accepted_all_order_review',W/'review_rs_integration_1506/snapshots/F020_All_Order_Independent_Review.md','Accepted all-A formal implication; block filtration and first overlap derivative; original accepted proof hash is recorded inside','aa6fab3492f265fca7a667a213f57f1453dcfb280d94280ce74b330b353bffd3'),
 ('accepted_general_guards',B/'repo/math/reviewed_rounds/2026-10-12-reviewed-research/rs-general-odd.md','Sections 1–3: g≠0, Res(F,U)≠0, denominators; source pinned repository commit 95419a2bd5d0bf6d3b78747bf163a62a7b9e4b5d',None),
 ('accepted_b27_residual',B/'next_cycle_rs_review/INDEPENDENT_REVIEW.md','Every primitive odd d>27 in characteristic zero; both trace endpoints and ordinary residual squarefreeness','b07faa02ec1cce01748e7d88c4b1a3963f5ee16e9c09a7edfca61ba12d5fd812'),
 ('residual_review_results',B/'next_cycle_rs_review/independent_results.json','160 exact checks and modular certificate values',None),
 ('residual_certificate',B/'next_cycle_rs/residual_certificate.json','Author certificate independently accepted by preceding review; inert input here',None),
 ('accepted_b27_overlap',B/'b27_independent_review.md','Every A≥1 and odd d>27; correct d57 finite-A bridge, lower/middle/tail cover','86e0331e551c2bac4cb8e81319ccc7119f631ba223683a8b0c57332f733b3c62'),
 ('overlap_review_manifest',B/'b27_independent_review_manifest.json','Binds accepted fresh interval and finite-A review artifacts',None),
 ('overlap_interval_results',B/'b27_independent_interval_review.json','77 independently reconstructed middle-order interval certificates',None),
 ('overlap_finite_A_results',B/'b27_independent_finite_A_review.json','Independent p229 q3 certificate for d57 A3..7',None),
 ('ranking_method',B/'ranking/RANKING_METHOD.md','Next-action priority rubric and caps; frozen scores not rewritten',None),
 ('frozen_ranked_catalogue',B/'ranking/all_research_ranked.json','Read all-record catalogue; F020 and FUS-02 scope mapping, no edit',None),
]
(R/'sources').mkdir(exist_ok=True);rows=[]
for key,p,role,expected in sources:
 raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest()
 if expected and h!=expected:raise ValueError((key,h,expected))
 # Catalogue retained by hash rather than duplicating its large full contents.
 copy=None
 if key!='frozen_ranked_catalogue':
  out=R/'sources'/(key+p.suffix);out.write_bytes(raw);copy=str(out.relative_to(R))
 rows.append({'id':key,'original_local_path':str(p.relative_to(W)),'sha256':h,'bytes':len(raw),'role':role,'exact_expected_hash_matched':None if not expected else True,'snapshot':copy})
data={'scope':'One b27 completion; independently accepted inputs, candidate fusion','source_review_boundary':'Accepted source statements inherited; no historical proof/certificate program executed by this fusion. New integration code is separate. Exact manuscript source and accepted review hashes checked.','inputs':rows,'dependency_edges':[
 {'from':['accepted_general_guards'],'to':'g and all original W denominators nonzero; Res(F,U) nonzero'},
 {'from':['accepted_b27_residual'],'to':'Disc(U) nonzero'},
 {'from':['accepted_b27_overlap'],'to':'Disc(J_(A+1)) nonzero for every A'},
 {'from':['accepted_all_order_review','local_manuscript_v3','all matched guards'],'to':'unconditional b27 initial forms and exact discriminant'},
 {'from':['all simple initial forms','classical simple-root lifting','parity'],'to':'exact quadratic splitting field after algebraic constant extension and inertia cycle type'}],
 'not_dependencies':['absence of arbitrary unit-circle residual roots','ALG-RS-PAIR prime-support arithmetic','FUS-06 conditioning','bank or FFT runtime claims','finite numerical root plots'],
 'existing_record_mapping':{'F020':'unconditional b27 local discriminant specialization; parent family remains broader','FUS-02':'local-discriminant guard-removal substage only; arithmetic-to-legal-banks component untouched','FUS-06':'context only, no promoted conclusion','ALG-RS-PAIR':'not used; no arithmetic transfer'},'canonical_discoveries_added':0}
(R/'SOURCE_DEPENDENCY_MAP.json').write_text(json.dumps(data,indent=2)+'\n')
weights={'information_gain':.25,'tractability':.25,'novelty_opportunity':.20,'scope_impact':.15,'evidence_readiness':.15}
dims={'information_gain':3,'tractability':5,'novelty_opportunity':1,'scope_impact':4,'evidence_readiness':5};avg=sum(weights[k]*v for k,v in dims.items());score=1+int(99*avg/5+.5)
rank={'as_of_utc':'2026-10-12T23:40:00Z','meaning':'1–100 next-action priority; not probability of truth, novelty, acceptance, publication, or breakthrough','method':'ranking/RANKING_METHOD.md v1.1; 1+round(99*weighted_average/5), then scoped caps','existing_parent_record':'F020','existing_fusion_record':'FUS-02','canonical_discoveries_added':0,'frozen_scores_unchanged':{'F020':67,'FUS-02':37},'next_action':{'task':'Independently review the b27 unconditional local theorem and quadratic-inertia corollary against pinned accepted inputs; replay fresh integration tests','dimension_scores':dims,'weights':weights,'weighted_average':avg,'raw_priority':score,'cap':None,'priority_1_100':score,'reasons':{'information_gain':'3/5: resolves a precise integration and zero-slope ramification question, not another broad open theorem','tractability':'5/5: exact theorem, dependency map, short lifting argument and executable tests are provided','novelty_opportunity':'1/5: assembly and Hensel/parity mechanism are classical; possible usefulness of exact specialization does not establish priority','scope_impact':'4/5: every A≥1 and every odd d>27, including composite orders, with no FFT implication','evidence_readiness':'5/5: independently accepted exact inputs, source hashes, full normalization and fresh finite controls'},'pass_condition':'Independent review finds every Section 3.2 guard discharged, validates C and local coordinates, proves quadratic splitting after algebraically closed constant extension, and passes tests','stop_condition':'A dependency, source mismatch, or proof gap is identified and retained explicitly; otherwise scoped fusion accepted'},'completed_named_targets':[{'target':'ordinary b27 residual gap','status':'independently accepted all odd d>27','next_action_priority_cap':15},{'target':'all-A b27 overlap gap','status':'independently accepted all odd d>27','next_action_priority_cap':15}], 'broader_limits':'Neither cap closes all F020 or FUS-02. No live table or frozen ranking edited.'}
(R/'RANKING.json').write_text(json.dumps(rank,indent=2)+'\n')
print('source bindings',len(rows),'next-action priority',score)
