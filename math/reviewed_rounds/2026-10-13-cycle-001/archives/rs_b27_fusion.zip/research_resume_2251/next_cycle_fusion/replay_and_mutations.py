#!/usr/bin/env python3
from pathlib import Path
import tempfile,subprocess,sys,json,hashlib,time
R=Path(__file__).resolve().parent
source=(R/'fresh_checks.py').read_text();expected=json.loads((R/'fresh_results.json').read_text());expected.pop('elapsed_seconds',None)
receipt={'cold_replay':{},'mutations':[],'source_sha256':hashlib.sha256(source.encode()).hexdigest()}
with tempfile.TemporaryDirectory(prefix='rs_b27_fusion_cold_') as d:
 p=Path(d);(p/'fresh_checks.py').write_text(source)
 run=subprocess.run([sys.executable,'-I',str(p/'fresh_checks.py')],capture_output=True,text=True,timeout=300)
 if run.returncode:raise RuntimeError(run.stderr)
 actual=json.loads((p/'fresh_results.json').read_text());actual.pop('elapsed_seconds',None)
 assert actual==expected
 receipt['cold_replay']={'pass':True,'check_count':actual['check_count'],'exact_comparison':'All result fields except elapsed_seconds are identical','stdout':run.stdout.strip()}
mutations=[
 ('omit d from original tau','return G,U,g,d*num*pow(den*g,-1,p)%p','return G,U,g,num*pow(den*g,-1,p)%p'),
 ('omit residual g squared from C','*pow(R,2*A,p)*g*g%p','*pow(R,2*A,p)%p'),
 ('alter inertia reversal sign','rev=[(-1)**(r+1)*c%p for r,c in enumerate(x)]','rev=[(-1)**r*c%p for r,c in enumerate(x)]'),
 ('drop odd-order domain guard','legal=d>27 and d%2==1 and','legal=d>27 and True and'),
]
for label,old,new in mutations:
 assert source.count(old)==1,(label,source.count(old))
 # Full Sylvester controls are unchanged and already replayed; skip them here
 # so each mutation reaches its relevant failing assertion promptly.
 mutant=source.replace(old,new).replace('[(1,29,27),(1,33,27),(2,29,27),(2,33,27),(2,3,1),(3,3,1)]','[]')
 with tempfile.TemporaryDirectory(prefix='rs_b27_fusion_mutation_') as d:
  p=Path(d)/'fresh_checks.py';p.write_text(mutant)
  run=subprocess.run([sys.executable,'-I',str(p)],capture_output=True,text=True,timeout=60)
  assert run.returncode!=0,label
  receipt['mutations'].append({'name':label,'rejected':True,'last_error':run.stderr.strip().splitlines()[-1]})
receipt['all_passed']=True
(R/'REPLAY_AND_MUTATION_RESULTS.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
