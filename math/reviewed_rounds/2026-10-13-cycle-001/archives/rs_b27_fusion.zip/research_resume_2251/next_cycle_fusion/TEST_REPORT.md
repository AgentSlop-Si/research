# Fresh fusion verification

The mathematical proof is in THEOREM_AND_PROOF.md. These tests are independent-style integration controls written for this packet by its author, **not a separate independent mathematical verdict**. They import and execute no historical author or reviewer program. Standard-library exact arithmetic is used throughout.

## Latest checks

Run: `python fresh_checks.py`

Latest completed run: **1,968 assertions passed**. The mathematical output is `fresh_results.json`.

- Twenty (A,d) cases at b=27, covering d=29,31,33,55,57,65,211. These include the smallest order, composite orders, the lower endpoint, the special d57 all-A bridge boundary A=7/8, and the tail boundary.
- A division-free Rogers–Szegő degree recurrence directly constructs actual local series. For small A and d≤65, every F-root is tested. For larger cases the shared root and two nonshared roots are tested. Every lower-weight coefficient vanishes, and the complete first polynomial matches the normalized Hermite or J expression.
- Every selected finite specialization checks all four needed guards. These are selected good-prime controls, not a theorem that every prime is good.
- The ordinary leading coefficient is recomputed as a raw pairwise product over every cluster center, local displacement discriminants, and residual factors. It matches the compact C formula in all twenty cases.
- Six **full ordinary Sylvester determinants** are computed from actual H_n coefficient series, without using the cluster formula to obtain the determinant. The b27 cases are (A,d)=(1,29),(1,33),(2,29),(2,33). Calibration cases are (A,d,b)=(2,3,1),(3,3,1). Both the exact order and nonzero leading coefficient agree.
- Direct Hensel lifts to z-series order ε^6 verify branch reversal at the shared A=1 and A=2 clusters and a nonshared A=3 cluster, all at b27,d29. These check a nonzero exchanged pair, the exact constant root −1, and a nonconstant but even zero-slope branch.
- Broad integer checks verify the inertia branch count and discriminant parity for A=1,…,100 at five odd d values. These are consistency checks on formulas, not evidence for untested simplicity.
- Negative controls cover repeated residuals, both low-degree repeated-J parameters, missing d in τ, missing g² in C, confusion between t and q−ω normalization, omission of the overlap exponent correction, even order, nonprimitive roots, the excluded boundary d=27, and ordinary versus q-discriminants.

The full b27 determinant controls use t=q^d−1. For (A,d,b)=(1,29,27), p=233,q=23, the discriminant starts 223t+108t². For (1,33,27), p=199,q=64, it starts 183t+102t². The A=2 values, which probe the large exact orders 31 and 35, are recorded in the JSON.

## Determinant implementation boundary

The checker forms the full (2n−1)-square Sylvester matrix over truncated F_p[[t]]. It uses minimum-valuation row/column pivoting, extracting powers of t before unit inversion and reducing the remaining precision accordingly. Thus it never inverts a nonunit. For series length greater than eight, multiplication uses exact integer Kronecker convolution. The base is larger than K(p−1)², so integer coefficient carries cannot mix polynomial positions. The implementation makes no floating-point calculation.

A development run of the newly added normalization control failed because an invalid-domain test loop had overwritten its finite-field parameters. Explicitly choosing the intended specialization fixed the test-harness issue. No theorem or certificate input changed. A slower schoolbook-convolution run then passed all 1,968 checks in about 96 seconds; exact packed convolution reduced the repeat to about 24 seconds, with the same mathematical output.

## Cold replay and adversarial mutations

Run: `python replay_and_mutations.py`

The script copies only fresh_checks.py to an isolated temporary directory, runs isolated Python, and compares every result field except elapsed_seconds with the saved output. It then verifies rejection of four deliberate source mutations: remove d from τ, remove g² from C, flip the inertia-reversal sign, and remove the odd-order domain guard. Mutation passes omit unchanged full Sylvester computations solely to reach the relevant failing assertions promptly.

The receipt is `REPLAY_AND_MUTATION_RESULTS.json`. No tests here establish historical priority, positive-characteristic uniformity, or the infinite b27 quantifiers. The latter depend on the explicitly pinned accepted theorems and the formal proof.
