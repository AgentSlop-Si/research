# b27 local-discriminant fusion packet

One bounded theorem integrates the independently accepted b27 residual and all-A overlap results with the accepted general separation guards and local initial-form theorem. For every odd d>27 and A≥1 it removes all Section 3.2 guards and gives the exact ordinary-discriminant valuation and coefficient. Its strengthened corollary gives exact quadratic splitting and the inertia cycle type after algebraic closure of the constant field.

- `THEOREM_AND_PROOF.md`: exact hypotheses, full proof, stronger corollary, boundaries; frozen candidate awaiting separate independent review
- `SOURCE_DEPENDENCY_MAP.json` and `sources/`: exact accepted dependencies and snapshots, guard map and existing-ID mapping
- `NOVELTY_AND_PRIOR_ART.md`: targeted primary-source comparison and honest priority limits
- `fresh_checks.py`, `fresh_results.json`, `TEST_REPORT.md`: fresh exact integration tests; 1,968 assertions passed
- `replay_and_mutations.py`, `REPLAY_AND_MUTATION_RESULTS.json`: isolated replay and four rejected mutations
- `RANKING.json`: next action, independent fusion review, scores **71/100** under the existing next-action rubric
- `MANIFEST.json`: hashes of this packet

Existing IDs: F020, with only the compatible local-guard substage of FUS-02. No canonical identity is added. FUS-06 and ALG-RS-PAIR claims remain separate. No external table, frozen stage, or frozen score is changed.

The packet proves a coherent scoped composition; it does not label a classical assembly or Hensel argument novel. Historical priority remains unresolved. Independent acceptance of each input is not misrepresented as independent review of the new fusion.
