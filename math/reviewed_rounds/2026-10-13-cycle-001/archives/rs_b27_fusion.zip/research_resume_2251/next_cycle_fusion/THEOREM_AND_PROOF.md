# Unconditional b27 local discriminants and quadratic inertia

12 October 2026 UTC. **Fusion candidate proved below from independently accepted inputs; fresh integration controls pass. Independent review of this fusion and its new corollary remains pending.**

Canonical parent: **F020**. Compatible fusion record: **FUS-02**, specifically its local-discriminant guard-removal substage. This is one coherent specialization of the existing local theorem, not a new canonical discovery. No arithmetic-to-bank, FUS-06 conditioning, or ALG-RS-PAIR conclusion is imported.

## 1. Exact theorem

Let k be any field of characteristic zero, let d>27 be an odd integer, let ω∈k have exact multiplicative order d, and let A≥1 be an integer. Put n=Ad+27 and

H_n(z;q)=Σ_(j=0)^n [n choose j]_q z^j,   D_n(q)=Disc_z H_n(z;q).

Gaussian coefficients mean their polynomials in Z[q], including at roots of unity. The discriminant is the **ordinary monic polynomial discriminant**, with Disc(1)=Disc(linear)=1. Define

F(z)=1+z^d,   H_27(z;ω)=(z+1)U(z),   g=U(−1),

W=(ω;ω)_27/(ω²;ω²)_((d+27)/2),   τ=dW/g,

J_(A+1)(y;τ)=y He_A(y)−Aτ He_(A−1)(y)
             =He_(A+1)(y)+A(1−τ)He_(A−1)(y),

where He_r is the monic probabilists' Hermite polynomial, and P_A=∏_(j=1)^A j^j. All factors defining W and g are nonzero. Put

L=dA(A−1)/2+A.

Then, without additional simplicity or separation assumptions,

1. U is squarefree; U(−1)≠0; Res_z(F,U)≠0; and J_(A+1) is squarefree.
2. With q(ε)=ω(1+ε²)^(1/d),

   D_n(q(ε))=ε^(2L)(C_(A,d)(ω)+O(ε²)),

   C_(A,d)(ω)=(−1)^(A(d−1)/2) d^(dA(A+1)/2+A) P_A^(d−1)
              ·Disc_y J_(A+1)·Disc_z U·Res_z(F,U)^(2A)·g² ≠0.

3. In Z[q], ord_(Φ_d) D_n=L. If D_n=Φ_d^L E_(A,d), then

   E_(A,d)(ω)=Q_d(ω)^L C_(A,d)(ω)≠0,
   Q_d(q)=(q^d−1)/Φ_d(q).

   The coefficient of (q−ω)^L is instead (dω^(d−1))^L C_(A,d)(ω). These normalizations are distinct.

4. Over the algebraically closed constant field k̄, put t=q^d−1 and q=ω(1+t)^(1/d). The splitting field of H_n(z;q) over k̄((t)) is exactly k̄((√t)). Its nonidentity automorphism, equivalently complex local monodromy when k⊂C, has cycle type

   2^B 1^(n−2B),   B=(d−1)⌊A/2⌋+⌊(A+1)/2⌋.

   Thus there are exactly 27 fixed branches when A is even, and d+25 fixed branches when A is odd. The remaining roots form the displayed transposed pairs. This is a statement after extending constants to k̄, not a claim that the original k((t)) splitting field has degree two.

The word “simplicity” concerns the residual and first-displacement polynomials. D_n itself generally has the large multiplicity L at ω; it is not claimed to have a simple zero except when A=1.

## 2. Why the inputs really fit

The working note, Section 3.2, requires exactly g≠0 and

Disc(U)·Res(F,U)·Disc(J_(A+1))≠0.

It requires neither absence of all unit-circle zeros of U nor a good-prime condition. Its overlap degree is A+1; b=27 is the residual Rogers–Szegő index.

- **General guards:** rs-general-odd.md, §§1–3, proves g≠0 and Res(F,U)≠0 for every odd b<d in characteristic zero. Its original W has denominator length (d+b)/2<d. Since ω² has order d, all original denominator factors are nonzero. This applies at b=27 and includes composite d.
- **Residual simplicity:** next_cycle_rs_review/INDEPENDENT_REVIEW.md accepts Disc(U)≠0 for b=27, every odd d>27. It proves both trace endpoints P(±2;ω)≠0 and Disc(P)≠0 using an exact characteristic-two reciprocal-gcd certificate. Its modulus support only permits odd orders 1,3,5,7,9,11,13. This is not a finite d scan. In particular it closes the former 27<d<2916 residual obligation and also covers all larger d.
- **Overlap simplicity:** b27_independent_review.md accepts Disc(J_(A+1))≠0 for all A≥1 and all odd d>27. The lower range is 29≤d≤55; the 77 middle orders are 57≤d≤209; the tail starts at the first odd d≥210, namely 211. At d=57 the norm exclusion handles A≥8, nonreality handles A=1,2, and a separate exact finite-field argument handles A=3,…,7. No finite-A extrapolation is used.
- **Local implication:** the independently accepted all-order proof supplies the initial forms and root-product discriminant formula under exactly these guards. The working note v3, §§3.1–3.2 and 4–7, reproduces that implication with the same normalizations. Its exact source and review hashes are pinned separately.

The newly closed residual input cannot by itself prove overlap simplicity or separation. Conversely the all-A overlap input did not imply residual simplicity. Both are now available at precisely the same (b,d,ω) domain, so their conjunction removes the remaining guard from this b27 family.

## 3. Proof of the discriminant assertion

We spell out the local derivation used, so composition does not hide a normalization or missing hypothesis.

The finite q-binomial product is

Π_(j=0)^(n−1)(1+q^j z)=Σ_k q^(k(k−1)/2)[n choose k]_q z^k.

Write q=ωe^h, T_ω(z^k)=ω^(k(k−1)/2)z^k and ℒ=z²∂_z². Coefficient comparison gives the exact formal identity

H_n(z;ωe^h)=exp(−hℒ/2)R_n(z,h),
R_n=T_ω^(−1)Π_(j=0)^(n−1)(1+ω^j e^(jh)z).

Since d is odd, T_ω commutes with multiplication by F. Grouping the first Ad factors into A blocks of size d proves that the coefficient R_(n,r) of h^r is divisible by F^max(A−r,0). Also R_(n,0)=F^A H_27. This is an all-order product-rule argument.

At a root α≠−1 of F, the weight-A term, with wt(z−α)=1 and wt(h)=2, is (−d/α)^A H_27(α)(z−α)^A. The associated-graded heat operator is exp(−hα²∂_z²/2). With h=log(1+ε²)/d, it yields

H_n(α+εx;q(ε))
 =ε^A(−1)^A d^(A/2)H_27(α)He_A(√d x/α)+O(ε^(A+1)).

At α=−1 there is one extra static factor. The accepted first-block derivative calculation, using the classical even-degree value

H_(d+27)(−1;q)=(q;q)_(d+27)/(q²;q²)_((d+27)/2),

gives the weight-(A+1) part of R_n as

d^A g[(z+1)^(A+1)+A(1−τ)h(z+1)^(A−1)].

Indeed the first h derivative of this even-degree value at ω is −d²W: there is exactly one vanishing numerator factor 1−q^d, its derivative is −d, and the remaining full-order product is d. Applying the same associated-graded heat operator gives

H_n(−1+εx;q(ε))
 =ε^(A+1)d^((A−1)/2)g J_(A+1)(√d x;τ)+O(ε^(A+2)).

The square roots cancel in each displayed polynomial coefficient. A wrong missing factor d in τ changes this initial polynomial and is rejected by the fresh recurrence test.

All initial roots are simple by the matched guards and the simplicity of ordinary Hermite roots. Formal implicit-function lifting produces A root branches at each of the d−1 nonshared roots of F, A+1 at −1, and 26 branches at the simple zeros of U. Their total is (d−1)A+(A+1)+26=n.

The within-cluster product of squared differences has leading factor

ε^(2L) d^(−L) P_A^(d−1) Disc(J_(A+1)).

Let F_0=F/(z+1). Then F_0(−1)=d, Disc(F_0)=(−1)^((d−1)/2)d^(d−2), and the product of its roots is 1. Cross-cluster squared differences contribute

Disc(F_0)^(A²)d^(2A(A+1))=(−1)^(A(d−1)/2)d^(dA²+2A).

Residual pairs and cluster–residual pairs contribute

Disc(U) Res(F,U)^(2A) g².

The extra g² records the extra root in the shared cluster. Multiplication yields precisely C_(A,d), since dA²+2A−L=dA(A+1)/2+A. Every factor is nonzero. The discriminant is an even ε-series because q(ε) is even, so its normalized error is O(ε²).

Since t=q^d−1=ε² and dt/dq at ω equals dω^(d−1)≠0, the ordinary root multiplicity is L. The polynomial D_n lies in Z[q]. Galois conjugacy gives the same multiplicity at every primitive d-th root, and monic division by Φ_d yields the integral quotient E_(A,d) and the asserted value. This proves parts 1–3.

## 4. Strengthened corollary: exact quadratic splitting and inertia

This conclusion uses the full simple initial forms, not just a nonzero discriminant coefficient. It supplies root-level information absent from either separate b27 acceptance.

Let ε²=t and work over k̄. At a cluster center α let m=A or A+1 as appropriate and divide H_n(α+εx;q(ε)) by ε^m. Its specialization at ε=0 has simple roots. Each simple root a lifts uniquely to x_a(ε)∈k̄[[ε]], giving z_a(ε)=α+εx_a(ε). Simple residual roots lift already over k̄[[t]]. Therefore all n roots lie in k̄[[ε]], and the splitting field is contained in k̄((ε)).

The original polynomial is invariant under ε↦−ε. A branch of slope a becomes one of slope −a. Both He_A and J_(A+1) have their indicated parity, so their simple slope sets are closed under sign. Uniqueness of lifting shows that nonzero slopes are exchanged in distinct pairs and that a zero-slope branch is fixed. A fixed formal series is even, hence belongs to k̄[[t]]. This argument justifies the zero-slope case; a vanishing first displacement does not leave an unexamined higher ramification.

Each nonshared Hermite cluster has ⌊A/2⌋ pairs. The shared J cluster has ⌊(A+1)/2⌋ pairs. Thus the involution has B pairs and n−2B fixed roots, giving the stated counts. B≥1 for every A≥1, so at least one root has nonzero ε coefficient and does not lie in k̄((t)). The splitting field is therefore exactly the quadratic extension, proving part 4.

When A is even, n is odd and H_n is reciprocal; the shared zero-slope branch is the exact root z=−1 for all q. When A is odd, the d−1 nonshared zero-slope branches are unramified but need not be constant. Fresh Hensel controls include both cases. As a consistency check, B≡L mod 2, as required by the sign of discriminant monodromy.

This uses the classical simple-root lifting mechanism (for example, [Stacks Project, Lemma 10.153.9](https://stacks.math.columbia.edu/tag/04GM)). It is an explicitly derived b27 consequence, not a claim to have invented Hensel lifting or local quadratic ramification.

## 5. Exact status and boundaries

The actual strengthened mathematical conclusion is an **unconditional infinite b27 local family**, including every composite odd order, plus its exact inertia cycle type. It is stronger than keeping Section 3.2 conditionally guarded or listing two separate simplicity certificates. It does not increase the number of canonical identities, and the assembly itself is elementary once the accepted inputs are available.

No statement is made for b=29, arbitrary odd b, even d, nonprimitive ω, A=0, or positive characteristic. Finite-field controls below do not change the characteristic-zero theorem. This is a local splitting statement with algebraically closed constants, not an identification of the global Galois group. There is no uniform growing-degree stability estimate, numerical root-conditioning theorem, Fourier bank/rank conclusion, FFT runtime claim, or historical-priority clearance.

Independent review should especially verify the constant-field restriction in part 4, uniqueness for zero slopes, the extra g² in C, the t versus q−ω conversion, and the full d57 all-A bridge. Frozen ranking and external tables were not edited.
