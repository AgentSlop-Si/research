#!/usr/bin/env python3
"""Fresh reviewer controls: Gaussian-Pascal coefficients and Bezout determinants.
No author or prior reviewer executable is loaded. Exact finite fields only.
Finite tests support the separately written characteristic-zero proof review.
"""
from pathlib import Path
from math import comb, factorial, isqrt, prod
from functools import lru_cache
import hashlib, json
import numpy as np

ROOT=Path(__file__).resolve().parent
CHECKS=[]
def ck(name, condition, detail=None):
    ok=bool(condition); CHECKS.append({'name':name,'pass':ok,'detail':detail})
    if not ok: raise AssertionError(name)
def prime(p):
    return p>1 and all(p%i for i in range(2,isqrt(p)+1))
def factors(d):
    return [r for r in range(2,d+1) if d%r==0 and prime(r)]
def primitive(d,p):
    for a in range(2,p):
        q=pow(a,(p-1)//d,p)
        if q!=1 and all(pow(q,d//r,p)!=1 for r in factors(d)): return q
    raise ValueError('No root of requested order')
def smul(a,b,K,p): return np.convolve(a,b)[:K]%p
def inverse(a,K,p):
    assert int(a[0])%p
    b=np.zeros(K,dtype=np.int64); b[0]=pow(int(a[0]),-1,p)
    for j in range(1,K): b[j]=-int(np.dot(a[1:j+1],b[j-1::-1]))*int(b[0])%p
    return b

def qpower(j,d,q,K,p,coordinate):
    a=np.zeros(K,dtype=np.int64)
    if coordinate=='delta':
        for r in range(min(j,K-1)+1): a[r]=comb(j,r)*pow(q,j-r,p)%p
    else:
        exponent=j*pow(d,-1,p)%p; c=1
        for r in range(K):
            if r: c=c*(exponent-r+1)*pow(r,-1,p)%p
            a[r]=pow(q,j,p)*c%p
    return a

def gaussian_coefficients(n,d,q,K,p,coordinate='t'):
    # [n,j]=[n-1,j-1]+q^j[n-1,j], unlike the degree recurrence.
    powers=[qpower(j,d,q,K,p,coordinate) for j in range(n+1)]
    old=np.zeros((1,K),dtype=np.int64); old[0,0]=1
    for r in range(1,n+1):
        new=np.zeros((r+1,K),dtype=np.int64)
        new[1:]+=old
        for j in range(r): new[j]=(new[j]+smul(powers[j],old[j],K,p))%p
        old=new
    return old

def bezout(f,p):
    # (f(x)f'(y)-f(y)f'(x))/(x-y), ascending x,y powers.
    n,K=f.shape[0]-1,f.shape[1]
    g=np.zeros_like(f)
    for j in range(n):g[j]=(j+1)*f[j+1]%p
    B=np.zeros((n,n,K),dtype=np.int64)
    for i in range(1,n+1):
        for j in range(i):
            c=(smul(f[i],g[j],K,p)-smul(f[j],g[i],K,p))%p
            for r in range(i-j):B[i-1-r,j+r]=(B[i-1-r,j+r]+c)%p
    return B

def determinant_series(B,p):
    # Exact Gaussian elimination over F_p[[t]]. If the entire active
    # constant block vanishes, take t from every active row, not a single
    # minimum-valuation Sylvester pivot. Return the known truncated series.
    M=B.copy(); n,_,K=M.shape
    requested=K; unit=np.zeros(K,dtype=np.int64);unit[0]=1
    exponent=0;sign=1;rank_trace=[];r=0
    while r<n:
        where=np.argwhere(M[r:,r:,0]!=0)
        if len(where)==0:
            rows=n-r;exponent+=rows
            rank_trace.append({'unit_pivots':r,'extracted_rows':rows,'order_floor':exponent})
            if exponent>=requested:return np.zeros(requested,dtype=np.int64),rank_trace
            K-=rows
            # Every active row contributes t; shift once in every entry,
            # then retain only the determinant precision still needed.
            M=M[:,:,1:1+K].copy();unit=unit[:K]
            continue
        i,j=(where[0]+r).tolist()
        if i!=r:M[[r,i]]=M[[i,r]];sign=-sign
        if j!=r:M[:,[r,j]]=M[:,[j,r]];sign=-sign
        pivot=M[r,r].copy();unit=smul(unit,pivot,K,p)
        inv=inverse(pivot,K,p)
        if r+1<n:
            fac=np.array([smul(v,inv,K,p) for v in M[r+1:,r]])
            row=M[r,r+1:].copy()
            for k in range(K):
                cross=fac[:,:k+1]@row[:,k::-1].T
                M[r+1:,r+1:,k]=(M[r+1:,r+1:,k]-cross)%p
            M[r+1:,r]=0
        r+=1
    out=np.zeros(requested,dtype=np.int64);out[exponent:exponent+K]=sign*unit%p
    return out,rank_trace

def disc(f,p):
    if len(f)<=2:return 1
    f=np.array(f,dtype=np.int64)[:,None]
    return int(determinant_series(bezout(f,p),p)[0][0])
def ev(f,x,p):
    r=0
    for c in reversed(f):r=(r*x+int(c))%p
    return r

def hermite(m,p):
    a=[0]*(m+1)
    for j in range(m//2+1):
        a[m-2*j]=((-1)**j*factorial(m)//(2**j*factorial(j)*factorial(m-2*j)))%p
    return a

def jpoly(A,tau,p):
    h=hermite(A,p);prev=hermite(A-1,p);out=[0]+h
    for j,c in enumerate(prev):out[j]=(out[j]-A*tau*c)%p
    return out

@lru_cache(None)
def parameters(d,q,p):
    G=gaussian_coefficients(27,d,q,1,p)[:,0].tolist()
    U=[G[0]]
    for j in range(1,27):U.append((G[j]-U[j-1])%p)
    assert U[-1]==G[-1]
    g=ev(U,-1,p); num=prod((1-pow(q,r,p))%p for r in range(1,28))%p
    den=prod((1-pow(q,2*r,p))%p for r in range(1,(d+27)//2+1))%p
    if not g*den%p:raise ZeroDivisionError
    tau=d*num*pow(g*den,-1,p)%p
    R=prod(ev(U,-pow(q,j,p),p) for j in range(d))%p
    return G,U,g,tau,R,disc(U,p)

def choose(d,As):
    minimum=max(As)*d+27
    for k in range(2,300):
        p=k*d+1
        if p<=minimum+16 or not prime(p):continue
        q=primitive(d,p)
        try: P=parameters(d,q,p)
        except ZeroDivisionError:continue
        if P[-1]*P[-2]%p and all(disc(jpoly(A,P[3],p),p) for A in As):return p,q
    raise RuntimeError('Good finite control unavailable')

def expected_C(A,d,q,p):
    G,U,g,tau,R,DU=parameters(d,q,p)
    L=d*A*(A-1)//2+A
    return (pow(-1,A*(d-1)//2,p)*pow(d,d*A*(A+1)//2+A,p)*
      pow(prod(pow(j,j,p) for j in range(1,A+1))%p,d-1,p)*disc(jpoly(A,tau,p),p)*DU*pow(R,2*A,p)*g*g)%p

def local_jet(coeff,alpha,max_weight,p):
    n=len(coeff)-1; out=np.zeros((max_weight+1,max_weight+1),dtype=np.int64)
    for r in range(min(n,max_weight)+1):
        for e in range(min(coeff.shape[1],(max_weight-r)//2+1)):
            out[2*e+r,r]=sum(int(coeff[j,e])*comb(j,r)*pow(alpha,j-r,p) for j in range(r,n+1))%p
    return out

def expected_initial(A,d,alpha,shared,P,p):
    G,U,g,tau,R,DU=P;m=A+int(shared)
    h=jpoly(A,tau,p) if shared else hermite(A,p)
    monic=[0]*(m+1)
    for r,c in enumerate(h):
        if c:
            s=(m-r)//2; monic[r]=c*pow(d,-s,p)%p
            if not shared:monic[r]=monic[r]*pow(alpha,2*s,p)%p
    pref=pow(d,A,p)*g%p if shared else pow(-d*pow(alpha,-1,p),A,p)*ev(G,alpha,p)%p
    return [c*pref%p for c in monic],monic

def hensel(F,slope,p,order):
    # F(e,x) has simple initial root slope. Lift x(e), one coefficient at
    # a time; no epsilon-reversal identities are used during the lift.
    x=np.zeros(order+1,dtype=np.int64);x[0]=slope
    derivative=sum(j*int(F[0,j])*pow(slope,j-1,p) for j in range(1,F.shape[1]))%p
    assert derivative
    def coefficient(k):
        powers=[np.zeros(k+1,dtype=np.int64)];powers[0][0]=1
        for r in range(1,F.shape[1]):powers.append(smul(powers[-1],x[:k+1],k+1,p))
        return sum(int(F[e,r])*int(powers[r][k-e]) for e in range(k+1) for r in range(F.shape[1]))%p
    assert coefficient(0)==0
    for k in range(1,order+1):
        x[k]=-coefficient(k)*pow(derivative,-1,p)%p
        assert coefficient(k)==0
    return x.tolist()

# Sign and normalization control from explicit simple roots, unrelated to RS.
for roots,p in [([1,2],101),([1,2,5],101),([0,1,3,7],101)]:
    f=[1]
    for r in roots:
        h=[0]*(len(f)+1)
        for j,c in enumerate(f):h[j]=(h[j]-r*c)%p;h[j+1]=(h[j+1]+c)%p
        f=h
    reference=prod((a-b)**2 for i,a in enumerate(roots) for b in roots[i+1:])%p
    ck('Bezout orientation '+str(roots),disc(f,p)==reference)
ck('Repeated-root Bezout negative control',disc([1,-2,1],101)==0)

cases=[];lifts=[];wrong_tau_detected=0
for d,As in [(29,[1,2,3]),(31,[1,2]),(33,[1,2,4]),(55,[1]),(57,[1,3,7,8]),(211,[1,2])]:
    p,q=choose(d,As);P=parameters(d,q,p)
    ck(f'd{d} exact primitive order',pow(q,d,p)==1 and all(pow(q,d//r,p)!=1 for r in factors(d)),{'p':p,'q':q})
    ck(f'd{d} original guards',P[2]*P[4]*P[5]%p!=0)
    for A in As:
        n=A*d+27;mmax=A+1;weight=mmax+6
        coeff=gaussian_coefficients(n,d,q,weight//2+1,p)
        centers=[(-pow(q,j,p))%p for j in range(d)]
        # Full static polynomial is independently checked coefficientwise.
        static=[0]*(n+1)
        for j in range(A+1):
            for r,c in enumerate(P[0]):static[j*d+r]=(static[j*d+r]+comb(A,j)*c)%p
        ck(f'd{d} A{A} static q-Lucas factorization',np.array_equal(coeff[:,0],static))
        ks=range(d) if d<=57 and A<=3 else [0,1,d-1]
        for k in ks:
            alpha=centers[k];shared=(k==0);m=A+int(shared)
            jet=local_jet(coeff,alpha,weight,p)
            initial,monic=expected_initial(A,d,alpha,shared,P,p)
            ck(f'd{d} A{A} k{k} lower weighted jets',not np.any(jet[:m]))
            ck(f'd{d} A{A} k{k} initial form',jet[m,:m+1].tolist()==initial)
            if k in (0,1) and A<=3:
                f=jet[m:m+7,:];slope_roots=[x for x in range(p) if ev(initial,x,p)==0]
                lifted={x:hensel(f,x,p,6) for x in slope_roots}
                for a,x in lifted.items():
                    b=(-a)%p
                    if b in lifted:
                        ck(f'd{d} A{A} k{k} slope{a} reversal',all(lifted[b][j]==((-1)**(j+1)*x[j])%p for j in range(7)))
                    if a==0:
                        ck(f'd{d} A{A} k{k} zero slope is even z',all(x[j]==0 for j in (0,2,4,6)))
                if slope_roots:lifts.append({'d':d,'A':A,'k':k,'p':p,'slopes':slope_roots,'x_series':lifted})
            if shared:
                bad=list(P);bad[3]=P[3]*pow(d,-1,p)%p
                wrong_tau_detected+=expected_initial(A,d,alpha,True,tuple(bad),p)[0]!=initial
        B=(d-1)*(A//2)+(A+1)//2;L=d*A*(A-1)//2+A
        ck(f'd{d} A{A} degree and inertia counts',n-2*B==(27 if A%2==0 else d+25) and L%2==B%2 and B>0)
        # Direct product over pairwise centers, independent of the closed
        # Disc(F_0) and compact d-power formula.
        raw=P[5]
        for k,a in enumerate(centers):
            _,f=expected_initial(A,d,a,k==0,P,p);m=A+int(k==0)
            raw=raw*disc(f,p)*pow(ev(P[1],a,p),2*m,p)%p
        for i,a in enumerate(centers):
            for j,b in enumerate(centers[i+1:],i+1):
                raw=raw*pow(a-b,2*(A+int(i==0))*(A+int(j==0)),p)%p
        C=expected_C(A,d,q,p)
        ck(f'd{d} A{A} expanded coefficient product',raw==C and C!=0)
        cases.append({'d':d,'A':A,'n':n,'p':p,'q':q,'L':L,'C':C,'transpositions':B,'fixed':n-2*B})
ck('Missing d in tau rejected',wrong_tau_detected==len(cases))

full=[]
for d,A in [(29,1),(31,1),(33,1),(55,1),(29,2),(31,2)]:
    p,q=choose(d,[A]);L=d*A*(A-1)//2+A;K=L+2;n=A*d+27
    f=gaussian_coefficients(n,d,q,K,p);B=bezout(f,p)
    actual,trace=determinant_series(B,p);expected=expected_C(A,d,q,p)
    ck(f'FULL d{d} A{A} zero coefficients below L',not np.any(actual[:L]))
    ck(f'FULL d{d} A{A} leading coefficient',int(actual[L])==expected and expected!=0)
    P=parameters(d,q,p);wrong_without_g2=expected*pow(P[2]*P[2],-1,p)%p
    full.append({'d':d,'A':A,'n':n,'p':p,'q':q,'matrix_size':n,'L':L,'disc_coefficients':actual.tolist(),'expected_C':expected,'without_g_squared':wrong_without_g2,'rank_extractions':trace})
    if A==1:
        fdelta=gaussian_coefficients(n,d,q,3,p,'delta')
        delta,_=determinant_series(bezout(fdelta,p),p)
        expected_delta=pow(d*pow(q,-1,p),L,p)*expected%p
        ck(f'FULL d{d} A1 q-minus-omega normalization',int(delta[L])==expected_delta)
        full[-1]['delta_leading']=int(delta[L]);full[-1]['expected_delta']=expected_delta
ck('At least one missing g squared mutation rejected',any(x['without_g_squared']!=x['expected_C'] for x in full))
ck('Odd sign is independently exercised',any(x['A']*(x['d']-1)//2%2 for x in full))

pins={}
for name in ['THEOREM_AND_PROOF.md','SOURCE_DEPENDENCY_MAP.json']:
    f=ROOT/'snapshots'/name;pins[name]=hashlib.sha256(f.read_bytes()).hexdigest()
ck('Frozen theorem exact hash',pins['THEOREM_AND_PROOF.md']=='691214844206fbcdbb15e7f999d76d91c3b97320108e194b4ee5f1081dbe5f9d')
ck('Frozen dependency map exact hash',pins['SOURCE_DEPENDENCY_MAP.json']=='a8b0b42d0edfcb0ead516c53eb4071dd6a96f5c9d19467035d0fd85a35f6d987')
results={'status':'PASS','algorithm':'independent Gaussian-Pascal jets; Hermite factorial sum; ordinary Bezout determinants; exact finite fields','finite_test_boundary':'These tests do not prove the characteristic-zero infinite family or positive-characteristic generality.','inputs':pins,'check_count':len(CHECKS),'checks':CHECKS,'local_cases':cases,'hensel_lifts':lifts,'full_discriminant_cases':full,'dependencies':{'python':'3.12','numpy':np.__version__}}
(ROOT/'independent_results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(CHECKS),'local_cases':len(cases),'hensel_cases':len(lifts),'full_discriminant_cases':len(full)},indent=2))
