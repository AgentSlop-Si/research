# Independent review: unconditional b27 local discriminants and inertia

12 October 2026 UTC. **Mathematical decision: ACCEPT.**

The exact theorem and proof in the frozen `THEOREM_AND_PROOF.md` are correct for every characteristic-zero field k, every primitive root omega of odd order d>27, and every integer A>=1. This accepts the simultaneous discharge of all b27 Section 3.2 guards, its ordinary-discriminant order and complete leading coefficient, and the exact geometric quadratic splitting field with the stated inertia cycle type. No mathematical repair is required.

This is not an acceptance of publication priority or of every accompanying comparison paragraph. The separate historical-comparison review identified an omitted known adjacent-Laguerre interface in the author's novelty note. That attribution repair does not invalidate this theorem. There are **zero additional canonical discoveries** in this review. F020 remains the parent, and only the local-discriminant guard-removal substage of FUS-02 is affected.

## 1. Frozen identity and independence

The exact reviewed files are copied, unchanged, under `snapshots/`:

- `THEOREM_AND_PROOF.md`: SHA256 `691214844206fbcdbb15e7f999d76d91c3b97320108e194b4ee5f1081dbe5f9d`.
- `SOURCE_DEPENDENCY_MAP.json`: SHA256 `a8b0b42d0edfcb0ead516c53eb4071dd6a96f5c9d19467035d0fd85a35f6d987`.

The source audit checks all 12 dependency-map entries, including the original source bytes where present and the unmodified frozen ranking catalogue. The theorem and map were rehashed after the author declared them frozen. Source identities and the isolated replay receipt are in `REPLAY_AND_SOURCE_VERIFICATION.json`.

No author program or prior reviewer program was imported or executed. The author's test source was inspected only as inert text to choose a genuinely separate route. The fresh reviewer program constructs Gaussian coefficients by the coefficient-level q-Pascal identity and computes full discriminants by Bezout matrices. This differs from the author's degree recurrence and Sylvester matrices. Its local lifting routine independently solves coefficients one at a time, without assuming reversal parity. Accepted prior proofs and certificates are inherited at their stated scopes, not claimed to have been replayed by this fusion review.

## 2. The exact Section 3.2 contract

The pinned working note's Section 3.2, Theorem 2, equations (5)-(10), has precisely the following input requirements:

1. Characteristic zero, odd d>=3, A>=1, odd b with 1<=b<d.
2. G=H_b=(z+1)U and g=U(-1) nonzero.
3. Original W=(omega;omega)_b/(omega^2;omega^2)_((d+b)/2), tau=dW/g.
4. Disc(U), Res(1+z^d,U), and Disc(J_(A+1)) all nonzero for the global discriminant.

The denominator length is strictly below d and omega^2 has exact order d. Thus no W denominator vanishes. There is no additional hypothesis excluding every unit-circle zero of U, no good-prime hypothesis, and no arithmetic prime-support assumption. In fact Res(F,U) nonzero already implies g nonzero, though retaining the separate condition makes tau's definition clear.

The input domains coincide exactly at b=27:

- The accepted general-odd review supplies g and Res(F,U) nonvanishing for every odd b<d. Its separation proof explicitly includes composite orders. Its sector proof uses a selected complex embedding and then transfers algebraic nonvanishing through the cyclotomic field; it does not require the entire ambient field k to embed into C.
- `next_cycle_rs_review/INDEPENDENT_REVIEW.md` accepts Disc(U) nonzero for every primitive odd d>27. Its trace certificate proves both endpoints P(2), P(-2) and Disc(P) nonzero. The characteristic-two reciprocal-gcd certificate has only root orders 1,3,5,7,9,11,13. Therefore it covers every odd d>27, rather than only a finite range. In particular, its endpoint P(-2) independently supplies g nonzero.
- `b27_independent_review.md` accepts Disc(J_(A+1)) nonzero for every A>=1 and every odd d>27. The original normalization is the same tau=dW/g, and the overlap degree is A+1, not 27.

The overlap bridge has no missing order or block-multiplicity endpoint. The lower interval is odd d=29,...,55; the 77 middle orders are d=57,...,209; the tail's numerical threshold is d>=210, so its first odd value is 211. At d=57 the strict rho>9/4 certificate covers A>=8. Nonreality covers A=1,2. The independent F_229 specialization covers precisely A=3,...,7. For the other 76 middle orders, rho>8/3 covers A>=3 and nonreality covers A=1,2. None of these statements extrapolates from finitely many A.

The source's auxiliary analytic, conditioning, API, numerical-root and Fourier-bank material is not needed. Pending editorial fidelity of the larger working-note integration does not override the separate accepted all-order proof and its pinned review.

## 3. Independent audit of the initial forms

Write u=z-alpha, q=omega exp(h), and assign u weight one and h weight two. The finite q-binomial identity gives exactly

H_n = exp(-h L/2) R_n, with L=z^2 partial_z^2 and R_n=T_omega^(-1) product_(j=0)^(n-1)(1+omega^j exp(jh)z).

The multiplier in T_omega is unchanged when its monomial exponent increases by odd d, so T_omega and its inverse commute with F=1+z^d. Every h^r derivative touches at most r of the A complete d-factor blocks. Therefore its coefficient has F^(max(A-r,0)) as a factor, at every r, not merely through a computed order.

At a nonshared F-root alpha, the weight-A part of R_n is (-d/alpha)^A H_27(alpha)u^A. Terms with r>=1 have strictly larger weight. The associated-graded action of the heat operator is exp(-h alpha^2 partial_u^2/2); the other two terms of h L increase weight. Substituting h=log(1+epsilon^2)/d gives precisely the stated scaled He_A. There is no analytic convergence assumption in this formal step.

At alpha=-1, the zeroth part has leading term d^A g u^(A+1). The r=1 block calculation can contribute at weight A+1; every r>=2 term has weight at least A+2. Determine the needed first derivative at A=1. The even-degree special value H_(d+27)(-1;q) has a unique zero numerator factor 1-q^d. Its h derivative is -d, and the product of the remaining full-order factors contributes d, so the derivative is -d^2 W. Passing from H to R contributes +(L/2)(F H_27)(-1)=dg. Hence the block correction is dg-d^2 W=dg(1-tau), giving exactly

d^A g [u^(A+1)+A(1-tau)h u^(A-1)].

After applying the associated-graded heat operator, this is the stated J_(A+1) initial form. This argument works at A=1: the A(A-1) term vanishes and no negative-power term is introduced. It also fixes the easily lost d in tau and 1/d in h. The formal square roots of d cancel coefficientwise.

The source and candidate use the same ordinary monic Hermite normalization. The accepted simple initial forms give A branches at each of d-1 nonshared F-roots, A+1 at -1, and 26 simple residual branches. Their total is Ad+27. Thus the root list is exhaustive.

## 4. Discriminant constants, signs and coordinates

The local multiplicities give

L=(d-1)A(A-1)/2+A(A+1)/2=dA(A-1)/2+A.

The within-cluster squared differences contribute

epsilon^(2L) d^(-L) P_A^(d-1) Disc(J_(A+1)).

The nonshared centers have product one. With F_0=(1+z^d)/(z+1),

F_0(-1)=d, and Disc(F_0)=(-1)^((d-1)/2)d^(d-2).

Cross-cluster terms therefore contribute

Disc(F_0)^(A^2) d^(2A(A+1))=(-1)^(A(d-1)/2)d^(dA^2+2A).

Here reducing A^2 modulo two is legitimate; no sign has been lost. The residual and mixed pairs contribute Disc(U) Res(F,U)^(2A) g^2. The extra g^2 is forced by the one extra root in the shared cluster. The total exponent of d is

dA^2+2A-L=dA(A+1)/2+A,

which proves exactly the candidate's C_(A,d). Every factor is nonzero. Because q(epsilon) is even, the normalized discriminant remainder is O(epsilon^2), even though individual root series need not be even.

The three local normalizations are correctly distinguished:

- For t=q^d-1, D_n=t^L(C+O(t)).
- For q-omega, the leading coefficient is (d omega^(d-1))^L C.
- For D_n=Phi_d^L E in Z[q], E(omega)=Q_d(omega)^L C, where Q_d=(q^d-1)/Phi_d.

Characteristic zero makes the first coordinate change unramified. Since D_n is an integral polynomial, cyclotomic Galois conjugacy gives exactly the same multiplicity at every primitive dth root. Monic division gives the integral quotient E. This proves the precise cyclotomic valuation, not merely a lower bound.

## 5. Quadratic splitting and all zero-slope branches

Work over kbar((t)), with epsilon^2=t. At each cluster, the normalized polynomial epsilon^(-m) H_n(alpha+epsilon x;q(epsilon)) has a simple initial root a. This normalized polynomial need not be monic in x; simple-root lifting is valid anyway. Completeness and the nonmonic form of the lifting criterion are covered respectively by [Stacks 04GM](https://stacks.math.columbia.edu/tag/04GM) and [Stacks 04GG, Lemma 10.153.3(2)](https://stacks.math.columbia.edu/tag/04GG), whose primary text was checked in this review. Uniqueness also follows directly: two series with the same constant term have difference times a unit equal to zero.

Consequently every root lies in kbar[[epsilon]]. The 26 simple residual roots already lie in kbar[[t]]. For a cluster branch write z_a(epsilon)=alpha+epsilon x_a(epsilon), x_a(0)=a. Reversal sends it to a branch whose slope is -a. The initial Hermite and J polynomials have their stated parity and simple roots, so their nonzero slopes occur in distinct pairs.

If a=0, reversal has the same initial slope. Uniqueness implies

x_0(epsilon)=-x_0(-epsilon), and z_0(epsilon)=z_0(-epsilon).

Thus every zero-slope branch is genuinely unramified. A vanishing first displacement cannot conceal ramification at a higher odd epsilon power. It need not be a constant branch: the reviewer controls explicitly find nonconstant even z-series at nonshared A=1 and A=3 centers.

An even simple parity polynomial has no zero root, and an odd simple parity polynomial has exactly one. Therefore the number of transpositions is exactly

B=(d-1)floor(A/2)+floor((A+1)/2).

The fixed-root count is 27 for even A and d+25 for odd A. When A is even, H_n has odd degree and its shared zero-slope branch is identically -1 by reciprocity. For all A>=1, B>=1. A nonzero-slope branch has a nonzero epsilon coefficient and cannot lie in kbar((t)). Since every branch already lies in the quadratic extension, the splitting field is exactly kbar((sqrt(t))).

For a chosen complex embedding, the same normalized polynomials are analytic in epsilon near zero. The analytic implicit-function theorem gives convergent lifts, and a once-around loop in t exchanges the two determinations of epsilon. Hence the stated formal involution is the complex local monodromy. The equality B=L modulo two is an independent sign consistency check.

The algebraically closed constant field is essential to the precise degree-two statement. No degree-two assertion is made over the original k((t)), where residual centers and slopes may require extra constants. No embedding of an arbitrary characteristic-zero k into C is assumed. This is a geometric local statement, not a global Galois-group identification.

## 6. Boundary and degeneracy audit

- **A=1:** L=1 and J_2=y^2-tau has two distinct nonzero roots because tau is nonzero. Exactly one transposition remains; the d-1 ordinary cluster branches and 26 residual branches are fixed. No exceptional A=1 correction is needed.
- **A=0:** excluded correctly. The residual polynomial alone has simple roots here, so its geometric local splitting extension is trivial. The exact-quadratic conclusion must not be extended to A=0.
- **d=27 or b>=d:** excluded correctly; the displayed denominator length and the one-simple-overlap setup no longer have the required hypotheses.
- **Even d:** excluded correctly. The diagonal multiplier changes sign after an exponent shift by d, so this block-commutation proof does not apply unchanged.
- **Positive characteristic:** excluded correctly. Hermite simplicity and divisions by d, factorials and small integers can fail; finite-field control examples do not create a general positive-characteristic theorem.
- **Composite odd d:** included. The cyclotomic and denominator arguments, accepted guards, and original tau retain this full domain.

## 7. Fresh exact controls and reproducibility

Run `python -I next_cycle_fusion_review/independent_checks.py` from the working root. The program passes **916 checks**, with 15 local (d,A) profiles, 17 explicit Hensel cases, and six complete ordinary-discriminant series. Orders include 29,31,33,55,57,211; A values include 1,2,3,4,7,8. These are finite controls, not the infinite-family proof.

The Gaussian coefficient construction uses [n,j]=[n-1,j-1]+q^j[n-1,j], with direct truncated binomial coefficients for q(t)^j. Hermite coefficients use the factorial sum. Local jets are evaluated by ordinary binomial expansion of each z^j, rather than the author's sparse recurrence. Every tested lower weighted term vanishes, and the entire first polynomial matches. The original normalization with the factor d in tau is distinguished from an altered version in all 15 cases.

For a monic f of degree n, the determinant of the n-by-n Bezout matrix of f and f' equals the ordinary discriminant. Its orientation is checked against explicit polynomials with prescribed simple roots, plus a repeated-root negative control. The full series computations construct the entire b27 polynomial before forming this matrix; no local cluster formula is supplied to the determinant. Exact finite-field results include:

- (d,A)=(29,1), p=233, omega=23: leading t coefficient 223; leading q-omega coefficient 190.
- (31,1), p=311, omega=91: leading t coefficient 38; leading q-omega coefficient 218.
- (33,1), p=199, omega=64: leading t coefficient 183; leading q-omega coefficient 141.
- (55,1), p=331, omega=67: leading t coefficient 188; leading q-omega coefficient 16.
- (29,2), p=233, omega=23: all coefficients below t^31 vanish, coefficient t^31 is 61.
- (31,2), p=311, omega=91: all coefficients below t^33 vanish, coefficient t^33 is 213.

The d=31 and d=55 A=1 computations exercise the negative sign, which is absent in d=29 and d=33. Omitting g^2 changes the predicted coefficient in these controls. The Bezout elimination extracts t from all remaining rows only when its entire active constant block vanishes; determinant precision is reduced by the corresponding row count. The largest matrix here is 89-by-89. NumPy performs only bounded integer convolutions and dot products, with each coefficient reduced modulo p; the actual maximum p and series lengths keep products far below signed 64-bit overflow. No floating-point arithmetic is used.

The Hensel controls lift roots without using parity and subsequently verify epsilon reversal through the recorded truncation. At d=29,A=1, a nonshared zero-slope x-series modulo 233 is 189 epsilon+99 epsilon^3+122 epsilon^5. Thus z is nonconstant but even. The paired shared slopes are 54 and 179, and their lifted series satisfy the predicted reversal coefficientwise.

A cold replay copies only the fresh reviewer program and the two frozen source-identity snapshots into a new temporary directory, uses isolated Python, and reproduces `independent_results.json` byte for byte. Full data, all assertions, lifted series, determinant traces and code/source hashes are retained. This verifies the new tests, not the historical proof archive chain.

## 8. Historical boundary and current next action

The frozen novelty note omits the already reviewed exact reduction of J to adjacent-degree quasi-Laguerre polynomials and hence the relevant Sawa-Uchida Theorem 3.6 interface. This review read the saved independent repair text and flags the omission; the separate primary-source comparison lane owns its final publication wording. The earlier adjacent-Hermite-only discussion must not be used to imply that ordinary J-discriminant machinery is absent from prior work. Neither the classical reduction nor a closed discriminant formula alone supplies nonvanishing at the RS-specific tau.

Static root-of-unity factorizations, weighted vanishing, the finite q-binomial identity, Hermite/Laguerre transformations, resultant/discriminant algebra and simple-root lifting remain established mechanisms. This scoped fusion establishes that the accepted hypotheses now coexist and derives the displayed inertia count. It does not establish worldwide novelty for that count or the exact RS local formulas.

The previous b27 overlap, residual, and fusion-review stages are all mathematically complete. Their completed-stage priority cap is 15 under `ranking/RANKING_METHOD.md`. Frozen F020=67 and FUS-02=37 remain unchanged. A separately scoped next candidate is a **b29 residual reciprocal-gcd feasibility gate**, priority 65 with dimensions (information gain, tractability, novelty opportunity, scope/impact, evidence readiness)=(4,4,1,3,4). It asks for an exact certificate or an exact obstruction to this certificate route, not an assumed b29 theorem. Its contract is in `NEXT_GATE_RANKING.json`; it does not silently claim any b29 all-A overlap closure.
