from pathlib import Path
from datetime import datetime,timezone
import json, hashlib
base=Path(__file__).resolve().parent
stamp=datetime.now(timezone.utc).isoformat()
def save(name,x):
 (base/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
weights={'information_gain':0.25,'tractability':0.25,'novelty_opportunity':0.2,'scope_impact':0.15,'evidence_readiness':0.15}
dims={'information_gain':3,'tractability':1,'novelty_opportunity':2,'scope_impact':2,'evidence_readiness':1}
avg=sum(weights[k]*v for k,v in dims.items()); score=1+round(99*avg/5)
assert score==38
save('RANKING.json',{
 'as_of_utc':stamp,'meaning':'1–100 next-action work priority, not probability of truth, novelty, publication or breakthrough',
 'method':'ranking/RANKING_METHOD.md v1.1: 1+round(99*weighted_average/5), then exact-scope caps',
 'records':['F020','FUS-02 local-discriminant guard-removal substage'],'canonical_discoveries_added':0,
 'frozen_history':{'F020':67,'FUS-02':37,'fusion_independent_review_task':71},
 'next_distinct_research_action':{
  'task':'With a genuinely new authorized copy of Zhedanov 1997 pp.289–294, compare exact statements and any directly relevant cited theorem against the fixed-odd-d, all-A moving-q ordinary-discriminant and quadratic-inertia target.',
  'primary_source':'https://doi.org/10.1142/S0217751X97000438',
  'status':'awaiting genuinely new authorized primary material; known failed or restricted retrieval routes are not to be repeated',
  'dimensions':dims,'weights':weights,'weighted_average':avg,'raw_priority':score,'cap':None,'priority_1_100':score,
  'reasons':{
    'information_gain':'3/5: resolves a named historical antecedent gap in an otherwise precisely bounded comparison, rather than a new mathematical truth question',
    'tractability':'1/5: exact six-page target is known, but the original body was not obtained and prior access routes remain exhausted',
    'novelty_opportunity':'2/5: the exact RS-specific coefficient/application is not matched in inspected sources; this is no novelty guarantee',
    'scope_impact':'2/5: may settle attribution or publication framing for one existing family, without additional canonical or runtime consequences',
    'evidence_readiness':'1/5: target theorem and normalization checklist are ready; decisive original source body is absent'},
  'pass_condition':'Original theorem/page passages are readable and a parameter, normalization, invariant and domain match or precise nonmatch is documented; any earlier exact antecedent is credited.',
  'stop_condition':'The original body is still absent or a permitted route denies access: retain awaiting_source and do not convert search failure into absence of precedent.',
  'excludes':['Repeating closed b27 proof/certificate reviews','Calling static factorization a moving-root theorem','Substituting a q-discriminant for an ordinary discriminant','World-first claims from no exact search match']},
 'next_distinct_mathematical_gate':{'task':'Test b29 residual reciprocal-gcd certificate route','source':'../next_cycle_fusion_review/NEXT_GATE_RANKING.json','priority_1_100':65,'scores_inherited_not_freshly_recomputed':True,'dimensions':{'information_gain':4,'tractability':4,'novelty_opportunity':1,'scope_impact':3,'evidence_readiness':4},'domain':'U=H_29/(z+1); both trace endpoints and ordinary trace discriminant nonzero for every primitive odd d>29 in characteristic zero','boundary':'This lane did not execute or assess the distinct running b29 test. A surviving modular factor is not automatically a characteristic-zero multiple root; all-A b29 overlap and general odd b remain separate.'},
 'completed_scope_handling':[
  {'task':'b27 ordinary residual squarefreeness','status':'independently accepted input','priority_cap':15},
  {'task':'b27 all-A overlap simplicity','status':'independently accepted input','priority_cap':15},
  {'task':'b27 fused theorem and inertia independent review','status':'ACCEPTED; separate mathematical review read, no fresh replay here','historical_score_while_pending':71,'priority_cap_after_ACCEPT':15},
  {'task':'new standalone Hensel/Puiseux or quasi-Hermite discriminant mechanism','status':'established mechanisms; no separate new target specified','priority_cap':12}],
 'editorial_followthrough':'Fusion ACCEPT is recorded; integrate the theorem and corrected antecedents into the existing manuscript and current-scope text. This is not ranked as a new high-priority research gate.',
 'live_score_proposal':'If the parent updates current-next-action fields, distinguish the inherited b29 mathematical gate at65 from the historical target at38/awaiting_source, preserve 67/37/71 as dated checkpoint history, and mark the completed b27 stage separately. Neither score rates all FUS-02 arithmetic-to-legal-bank work.',
 'writes_performed':'Local report files only; no frozen ranking, Sheet, repository, or external document changed.'})
sources=[
 ('LS87','Lubinsky–Saff 1987','https://doi.org/10.1007/BF01890574','Lemma 4.5/(4.15), printed p.346; (1.5), p.332; Lemma 4.1, p.343','Local authorized scan OCR and saved image-based primary review read','Exact static RS factorization; mathematical-body comparison closure inherited, not freshly certified in full','Printed p.360 bibliography absent; current author link internal error, no body obtained'),
 ('AAK09','Atakishiyeva–Atakishiyev–Koornwinder, arXiv 0811.4100v2','https://pure.uva.nl/ws/files/848901/75463_0811.4100v2.pdf','(2.2),(2.7),(2.8), PDF pp.3–4; (3.8), PDF p.6; reference [28], p.12','Fresh primary extracted text','Exact equivalent all-block static factorization and q→1 endpoint Hermite limit','Does not supply fixed-d transverse coefficients in inspected passages; Z97 description is attribution only'),
 ('SW','Schultz–Walker, arXiv 1202.0199v1','https://arxiv.org/pdf/1202.0199v1','Gaussian formula p.2; Theorem 1.1 p.3; primitive-choice passage p.13','Fresh theorem and Gaussian formula; primitive-choice detail inherited from accepted comparison','Weighted derivative vanishing; classical even-degree value at -1','Not an explicit complete first-surviving RS cluster polynomial'),
 ('GOR','Gorodetsky, arXiv 1805.01254v2','https://arxiv.org/pdf/1805.01254v2','(1.5) p.2; Propositions 8.1–8.2 pp.23–24; Corollary 8.2 p.27','Fresh primary extracted text around propositions; saved exact prior review consulted','Actual low-order ordinary q-derivative formulas at roots of unity','Index-divisibility and derivative-order restrictions; not all-A mixed cluster formula'),
 ('ZUD','Zudilin, arXiv 1901.07843v2','https://arxiv.org/pdf/1901.07843v2','Lemma 1/(9), PDF pp.3–4','Fresh primary extracted text','Cubic weighted q-binomial root-of-unity expansion','Both indices divisible by root order; formal path conversion required'),
 ('SU','Sawa–Uchida 2019','https://www.jstage.jst.go.jp/article/jmath/71/3/71_831/_pdf','Theorem 3.6/(3.6), printed pp.844–845; Theorem 3.8 p.846; Remark 3.9 p.847; §2.1–2.2','Fresh primary extracted text; screenshot failed cache miss','Direct quasi-Laguerre discriminant interface for J via quadratic map; ordinary root-product rules','Does not identify RS tau or prove nonvanishing at complex b27 parameters'),
 ('DLMF','NIST DLMF §18.7','https://dlmf.nist.gov/18.7','18.7.11, 18.7.19, 18.7.20','Fresh official formula text','Exact Hermite normalization and Hermite–Laguerre quadratic transformations','Normalization reference; not a priority claim for the RS application'),
 ('IW','Ismail–Witte, arXiv math/0012259v2','https://arxiv.org/pdf/math/0012259v2','(1.7)–(1.9), PDF pp.2–3; (4.20), p.21; (5.17), p.24','Fresh primary extracted text','Ordinary versus q-discriminant distinction; explicit RS q-discriminant','Own comparison gives q-discriminant order dA(A+1)/2, not ordinary L'),
 ('SZ','Spiridonov–Zhedanov, arXiv q-alg/9605034v2','https://arxiv.org/pdf/q-alg/9605034v2','Simplicity caveat p.2; §2 (2.4)–(2.8), p.3','Fresh primary extracted text','Static degree-equals-order Askey–Wilson zeros and complex simplicity caveat','Distinct from Zhedanov 1997 Gauss sums paper; not a substitute for its body'),
 ('DIW','Dai–Ismail–Wang 2024','https://userweb.ucs.louisiana.edu/~xxw6637/papers/RJ2024.pdf','§5, PDF pp.19–21; Lemma 5.1/(5.2), p.21','Fresh primary extracted text','Root-of-unity weak measure limit and degree-n q-Hermite specialization','Not the target degree-Ad+27 first-displacement statement in inspected passages'),
 ('ACL26','Åhag–Czyż–Lundow 2026','https://arxiv.org/pdf/2607.09150','Theorem 2.2, PDF p.4; §3','Fresh primary extracted text','Positive-real (p,q), growing n quartic asymptotic and scaled-zero regime','Different parameter/domain from fixed d>27 and t→0'),
 ('PUISEUX','Puiseux 1850','https://www.numdam.org/item/JMPA_1850_1_15__365_0.pdf','§§1–3 pp.365–368; §19 pp.396–397; §§21–22 pp.399–401','Fresh primary extracted text; screenshot failed cache miss','Square-root sign change, cyclic branch systems, fractional-power expansions','Historical branching antecedent; no RS specialization'),
 ('MC','Mannaa–Coquand Dynamic Newton–Puiseux Theorem','https://arxiv.org/pdf/1304.6770','Theorem 1.9, PDF pp.6–7','Fresh primary extracted text','Formal splitting after finite power substitution over algebraically closed characteristic-zero constants','General theorem does not identify exponent 2 or RS inertia count'),
 ('ST_H','Stacks Project','https://stacks.math.columbia.edu/tag/04GM','Lemma 10.153.9','Fresh primary HTML','Complete local rings are henselian','Mechanism only'),
 ('ST_L','Stacks Project','https://stacks.math.columbia.edu/tag/04GG','Lemma 10.153.3(2)','Fresh primary HTML','Simple-root lifting for arbitrary, not necessarily monic, polynomials','Fits the rescaled cluster polynomial'),
 ('ST_U','Stacks Project','https://stacks.math.columbia.edu/tag/04GE','Lemma 10.153.2','Fresh primary HTML','Uniqueness of the simple-root lift','Parity and RS pair count are the candidate application'),
 ('Z97','Zhedanov Gauss sums and orthogonal polynomials 1997','https://doi.org/10.1142/S0217751X97000438','International Journal of Modern Physics A 12(1), pp.289–294','Original body NOT obtained; DOI tool error; AAK09 reference and discussion read','Bibliographic identity and later attribution only','Exact theorem-level comparison remains open')]
save('SOURCE_LEDGER.json',{'as_of_utc':stamp,'scope':'Page-level primary comparisons; no whole-literature search certification','sources':[dict(zip(['id','source','url','locators','reading_depth','match','limits'],x)) for x in sources]})
claims=[
 ('C01','H_(Ad+27)(z;ω)=(1+z^d)^A H_27(z;ω)','Exact classical match','LS87; AAK09','Do not claim static factorization or static multiplicity as new'),
 ('C02','Below-weight mixed q/z vanishings','Classical theorem interface','SW','Does not fix complete first surviving polynomial'),
 ('C03','All-A initial Hermite and shared J with τ=dW/g','No complete exact match in inspected passages','GOR; ZUD; AAK09; SW','Exact RS application priority unresolved; broad expansion novelty excluded'),
 ('C04','Disc(J) standalone evaluation','Known direct transformed family interface','SU; DLMF','Must credit adjacent-Laguerre Theorem 3.6; complex simplicity still requires its own argument'),
 ('C05','Ordinary valuation L and coefficient C for n=Ad+27','No complete exact match in inspected passages; q-discriminant is nonmatch','IW; project F020','IW cyclotomic order differs by A(d−1)'),
 ('C06','All b27 guards removed for every odd d>27 and A≥1','Specific certificate/application package not matched here','Accepted project residual/overlap inputs','Not a new general discriminant mechanism; independent fusion acceptance separate'),
 ('C07','Splitting over k̄((√t)) and exact inertia count','Classical mechanism, exact application not matched in inspected sources','PUISEUX; MC; ST_H; ST_L; ST_U','No claim before constant extension; no global Galois conclusion'),
 ('C08','Historical worldwide-first publication','Unresolved, not justified','Z97 gap and uninspected citation-chain bodies','No absence inference from failed search'),
 ('C09','FUS-02 arithmetic-to-legal-bank completion','Not part of theorem','Frozen FUS-02 scope','Do not transfer local acceptance to bank, conditioning or FFT claims')]
save('CLAIM_MATRIX.json',{'as_of_utc':stamp,'claims':[dict(zip(['id','target','disposition','sources','scope_rule'],x)) for x in claims]})
queries=[
 'Rogers Szego polynomial discriminant roots unity local splitting monodromy',
 'Lubinsky Saff 1987 Rogers Szego polynomials zeros roots unity',
 'Zhedanov 1997 Rogers Szego polynomials roots unity',
 '"Rogers-Szegö" "discriminant"', '"Rogers-Szego" "Zhedanov" "1997"',
 '"Rogers-Szegő" "Puiseux"', '"Rogers-Szego" "monodromy"',
 '"Gauss sums and orthogonal polynomials"', '"Rogers-Szego" "discriminants" "roots"',
 '"continuous q-Hermite" "root of unity" "Hermite" zeros limit',
 '"S0217751X97000438"', '"Gauss sums" "Zhedanov" 289',
 '"Rogers-Szegő" discriminant cyclotomic', '"Rogers-Szego" "splitting" roots',
 '"q-Hermite" "discriminant"', '"Rogers" "Szego" "Puiseux"',
 '"Rogers" "Szegő" "ramification"', '"Rogers-Szego" "zeros" "perturbation"',
 '"q-Hermite" "root of unity" limit zeros', '"Rogers-Szegő" "root of unity" asymptotic',
 '"Rogers-Szego" "Hermite" "roots of unity"', '"q-Hermite" "Puiseux"',
 'Newton Puiseux theorem algebraically closed characteristic zero power series primary proof pdf',
 'Puiseux 1850 recherches fonctions algebriques journal math pures appliquées numdam',
 '"polynomial" "simple roots" "square root" "monodromy" perturbation theorem']
save('SEARCH_LOG.json',{'as_of_utc':stamp,'queries':queries,'source_policy':'Only primary research papers, official mathematical reference statements, and authorized source scans support technical conclusions; incidental secondary search results are not theorem evidence.','coverage_limit':'Targeted name, alternate-family, invariant, parameter and branching terms; not systematic exhaustive coverage.','access_outcomes':[
 {'target':'Saff publication index','result':'Readable, confirms 1987 title and linked primary route'},
 {'target':'Saff links 270 and 272','result':'Internal tool errors; no source body. Prior route restrictions subsequently encountered in saved review; no further attempt or workaround.'},
 {'target':'Z97 DOI','result':'Internal tool error; original body remains uninspected'},
 {'target':'arXiv 0811.4100v2 PDF','result':'Internal tool error; public institutional version read, no security/access denial was shown for arXiv'},
 {'target':'SU and Puiseux screenshots','result':'Cache miss; extracted text only, no rendered-image claim'}]})
files={}
for p in sorted(base.iterdir()):
 if p.is_file() and p.name!='MANIFEST.json':
  b=p.read_bytes(); files[p.name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
save('MANIFEST.json',{'as_of_utc':stamp,'files':files,'purpose':'Pins this bounded source-comparison deliverable only; no correctness or historical-priority certificate implied'})
print('Wrote',len(files),'payloads; next distinct source-comparison priority',score)
