# b27 Rogers–Szegő fusion: exact antecedents and publication scope

12 October 2026 UTC. Bounded source comparison of the sealed `next_cycle_fusion` theorem. The separate `next_cycle_fusion_review/INDEPENDENT_REVIEW.md` now records mathematical ACCEPT; that verdict was read after the primary-source comparison. This report adds no correctness replay, complete bibliography, or publication-priority clearance. No external document, table, repository, or frozen score was changed.

## Findings that affect use of the result

1. **Retain the fixed-b27 application; do not present a new general mechanism.** The unconditional family and its explicit inertia count are useful consequences of the accepted project inputs. No inspected primary passage states their whole conjunction. That is a bounded comparison result, not evidence of worldwide first publication.
2. **Repair the quasi-Hermite comparison.** The new packet omits the existing independent review's exact reduction to Sawa–Uchida's quasi-Laguerre Theorem 3.6. Theorem 3.8's adjacent-Hermite degree mismatch is not a reason to dismiss their known discriminant machinery.
3. **The published Rogers–Szegő q-discriminant is genuinely a different invariant.** An explicit comparison below gives a different cyclotomic order, so even its valuation cannot be imported into this ordinary-discriminant theorem.
4. **Quadratic inertia is a classical lifting-and-parity consequence, with RS-specific input.** The assertion that every branch lives over the same square-root extension uses simple initial polynomials, not merely the discriminant valuation. The all-b27 nonvanishing certificates are the substantive condition-removal work.
5. **Distinguish access gaps.** LS87's missing printed p.360 is a bibliography-page gap. The saved FUS-02 record already treats the mathematical-body comparison as closed. Zhedanov's exact 1997 six-page body and substantive relevant citation-chain comparisons remain uninspected; no absence claim is justified.

## Exact comparison target

The candidate fixes b=27, characteristic zero, any odd d>27, any primitive d-th root ω, and every integer A≥1. With n=Ad+27 and ordinary monic D_n(q)=Disc_z H_n(z;q), it proves

L=dA(A−1)/2+A,

D_n(ω(1+t)^(1/d))=t^L(C_(A,d)(ω)+O(t)),

where

C_(A,d)=(-1)^[A(d−1)/2] d^[dA(A+1)/2+A] P_A^(d−1)
 · Disc(J_(A+1)) Disc(U) Res(z^d+1,U)^(2A) U(-1)^2 ≠0.

Here H_27=(z+1)U, P_A=∏_(j=1)^A j^j, and

J_(A+1)=He_(A+1)+A(1−τ)He_(A−1),
τ=d(ω;ω)_27/[(ω²;ω²)_((d+27)/2)U(-1)].

The exact local splitting field over algebraically closed constants is k̄((√t)), with inertia cycle type 2^B 1^(n−2B), where

B=(d−1)⌊A/2⌋+⌊(A+1)/2⌋.

There are 27 fixed branches for even A and d+25 for odd A. This is not a global Galois-group statement or a quadratic splitting-field statement before extending constants. The cyclotomic quotient value multiplies C by Q_d(ω)^L; a (q−ω)-coefficient instead multiplies C by (dω^(d−1))^L. Any exact-equivalence claim must match these normalizations.

The target's new conclusion relative to the earlier guarded project result is the simultaneous removal of the residual and overlap guards at b27 and the explicitly stated inertia consequence. The guarded formula already belongs to F020. Only FUS-02's local-guard-removal substage is implicated; its arithmetic-to-legal-bank program is not completed.

## Theorem-level matches and nonmatches

### A. Static factorization: an exact classical match

Lubinsky–Saff, *Convergence of Padé approximants of partial theta functions and the Rogers–Szegö polynomials* (1987), Lemma 4.5/(4.15), printed p.346, states the block factorization with parameters (ν,k,ℓ)=(d,A,27). Its G_n is this project's H_n. The relevant local scan text and previous image-based review were read; this pass does not claim a fresh whole-paper image review. [Publisher identity](https://doi.org/10.1007/BF01890574).

An independently accessible alternate-name match is Atakishiyeva–Atakishiyev–Koornwinder, arXiv:0811.4100v2, §2 (2.2),(2.7),(2.8), PDF pp.3–4. Their continuous q-Hermite C satisfies

C_n((s+s^(-1))/2|q)=s^(-n)H_n(s²;q),
C_(Ad+b)(x|ω)=(2T_d(x))^A C_b(x|ω).

Thus (2.8) gives the same static RS factorization after substitution. Their (3.8), PDF p.6, takes q→1; the accompanying fixed-j, M→∞ limit changes the root order. Neither is the present fixed-d transverse deformation. [Primary institutional PDF](https://pure.uva.nl/ws/files/848901/75463_0811.4100v2.pdf).

Static multiplicity does not determine the first moving coefficients. The comparison still has to identify the mixed q/z initial form and τ, rather than relabel (1+z^d)^A H_27 as a moving-root theorem.

### B. Vanishing and low-order coefficient expansions: genuine antecedents

Schultz–Walker, Theorem 1.1, PDF p.3, supplies weighted Gaussian-derivative divisibility. Taking their kc=d, polynomial weight the ℓ-th falling factorial, derivative order r, and auxiliary orders zero recovers the below-weight-A vanishing when 2r+ℓ<A. Their Gaussian formula on p.2 supplies the even-degree value at -1. The source explicitly distinguishes divisibility from an explicit surviving coefficient. [Primary preprint](https://arxiv.org/pdf/1202.0199v1).

Gorodetsky, Propositions 8.1–8.2, PDF pp.23–24, and Corollary 8.2, p.27, evaluate ordinary q-derivatives at roots of unity. The first derivative includes the nondivisible lower-index case; the second derivative requires root order dividing the lower index as well as the upper. These are actual coefficient formulas, not just static identities. [Primary preprint](https://arxiv.org/pdf/1805.01254v2).

Zudilin, Lemma 1/(9), PDF pp.3–4, expands a weighted Gaussian coefficient with upper and lower indices divisible by the root order through cubic radial order. Its comparison parameter is η=1−(1+t)^(1/d); a formal Taylor conversion is allowed, but the candidate's positive-real t path is not thereby an inward radial path. [Primary preprint](https://arxiv.org/pdf/1901.07843v2).

None of these selected statements gives the entire all-A, residual-27, one-overlap initial polynomial and normalized ordinary-discriminant coefficient. They do rule out broad claims such as inventing root-of-unity expansions or surviving-coefficient methods.

### C. Disc(J) already has a direct known family interface

Sawa–Uchida Theorem 3.6/(3.6), printed pp.844–845, evaluates the ordinary discriminant of L_m^α+cL_(m−1)^α. Theorem 3.8 concerns adjacent Hermite degrees. The former is directly relevant here. [Primary paper](https://www.jstage.jst.go.jp/article/jmath/71/3/71_831/_pdf).

With N=A+1=2m+s, s∈{0,1}, α=s−1/2 and γ=−(N−1)(1−τ)/(2m), set

Q(x)=(-1)^m m![L_m^α(x)+γL_(m−1)^α(x)].

Then J_N(y;τ)=2^m y^s Q(y²/2). This is the exact normalized map preserved in the earlier independent repair, using [DLMF 18.7.11, 18.7.19–20](https://dlmf.nist.gov/18.7). Root products give

Disc(J_N)=(-1)^m 2^[2m²+(2s+1)m] Q(0)^(2s+1) Disc(Q)^2.

Consequently the standalone evaluation machinery is established. Algebraic continuation handles complex τ; real quasi-orthogonality does not itself establish simplicity there. Neither this transformation nor Theorem 3.6 identifies the RS-specific τ or proves nonvanishing at all its b27 values. Those are distinct application obligations.

### D. The q-discriminant does not match even the target valuation

Ismail–Witte define the ordinary and q-discriminants separately in (1.7) and (1.8)–(1.9). Their explicit RS product (5.17), PDF p.24, is the latter. Their polynomial normalization (4.20) differs by z↦q^(-1/2)z, a local unit scaling at ω. [Primary paper](https://arxiv.org/pdf/math/0012259v2).

Our algebraic comparison of that product, not a theorem attributed to them, gives for n=Ad+27:

ord_(Φ_d) D_q(H_n)=nA−Σ_(j=1)^(n−1)⌊j/d⌋=dA(A+1)/2.

This exceeds the candidate's ordinary L by A(d−1). For A=1 it is d versus 1. Normalization by a power of q cannot remove this difference. The paper therefore remains an antecedent for generalized discriminants and root-product machinery, not an exact source for the present ordinary valuation or coefficient.

### E. Fixed-root measure results do not settle the moving-root target

Spiridonov–Zhedanov, §2 (2.4)–(2.8), PDF p.3, describes degree-equals-order Askey–Wilson zeros; §1, p.2, expressly warns that complex recurrence coefficients do not ensure simple roots. [Primary preprint](https://arxiv.org/pdf/q-alg/9605034v2).

Dai–Ismail–Wang, §5 and Lemma 5.1/(5.2), PDF pp.19–21, analyzes limiting measures and a q-Hermite specialization at order n. That is a genuine q→ω deformation, but the displayed conclusion concerns the measure and degree-n specialization, not the degree-Ad+27 root-cluster initial polynomials. [Author-hosted published paper](https://userweb.ucs.louisiana.edu/~xxw6637/papers/RJ2024.pdf).

The 2026 Åhag–Czyż–Lundow paper, Theorem 2.2 and §3, uses positive real (p,q) approaching 1 with growing even n and n^(3/4)-scaled zeros near w=1. Its parameter regime is explicitly different from fixed d>27 and t→0. It is relevant current RS asymptotics, not an exact match in the inspected statements. [Primary preprint](https://arxiv.org/pdf/2607.09150).

### F. The inertia mechanism is classical, while its exact RS count is an application

Puiseux's 1850 original treats the square-root sign change in §§1–3, printed pp.365–368; circular systems of branches in §19, pp.396–397; and fractional-power expansions in §§21–22, pp.399–401. These are precise historical antecedents to branching and monodromy, not RS results. [Original primary scan](https://www.numdam.org/item/JMPA_1850_1_15__365_0.pdf).

For formal characteristic-zero scope, Mannaa–Coquand's Theorem 1.9, PDF pp.6–7, states splitting after a finite power substitution over algebraically closed constants. It does not assert exponent two for this RS family. [Primary preprint](https://arxiv.org/pdf/1304.6770).

The sharper applicable mechanism needs only simple-root lifting: [Stacks Lemma 10.153.9](https://stacks.math.columbia.edu/tag/04GM) makes k̄[[ε]] henselian; [Lemma 10.153.3(2)](https://stacks.math.columbia.edu/tag/04GG) covers nonmonic rescaled cluster polynomials; [Lemma 10.153.2](https://stacks.math.columbia.edu/tag/04GE) supplies uniqueness. This improves the candidate's citation precision.

Once the simple initial forms are accepted, parity sends slope a to −a. A unique zero-slope lift is fixed and hence even in ε. Therefore every root lies in k̄[[√t]], and a nonzero slope forces the extension to be genuinely quadratic. Counting signed pairs gives B. The source provides the lifting principle; the explicit B and fixed-branch counts are the candidate's application of its RS initial forms. No inspected source states this exact b27 result. The argument does not establish a new general Newton–Puiseux or ramification theorem, and discriminant order alone would not justify it.

## Publication wording and recommended scope

Suggested contribution statement, with independent mathematical acceptance now recorded:

“For the Rogers–Szegő family H_(Ad+27), we discharge the residual-separation and initial-root simplicity conditions for every odd order d>27 and every A≥1. Combining these certificates with the all-order local initial forms gives an unconditional formula for the ordinary discriminant's cyclotomic valuation and normalized leading coefficient. We also record the resulting quadratic local splitting field over algebraically closed constants and its explicit inertia cycle type. The factorization, Hermite–Laguerre discriminant, and Hensel/Puiseux mechanisms are classical; historical priority for this specific RS application remains unresolved.”

Use this as a substantive specialization/corollary in the existing F020 manuscript. A separate paper claiming “new quadratic ramification,” “a new quasi-Hermite discriminant,” or “first root-of-unity asymptotics” is not supported. The finite-degree residual certificate and all-A overlap argument should be presented as checkable condition-removal results, not as many additional canonical discoveries.

An exact antecedent must match, or demonstrably imply, all relevant hypotheses and conversions: moving q, fixed primitive odd d, arbitrary A, residual b=27, ordinary z-derivative discriminant, τ=dW/g, the coefficient's extra g², local-coordinate normalization, and constant-field scope. A mere citation count, static factorization, or failed search does not meet that standard.

## Access gaps and freshness

- LS87's authorized scan contains printed pp.331–359 and 361; p.360 is absent. The saved primary-source review identifies the missing material as intervening references, while the mathematical formulas used above are present. The current FUS-02 record's mathematical-body closure must not be silently undone. This pass inherits that closure rather than independently certifying every page.
- The current Saff publication list was readable. Its paper links returned internal tool errors and furnished no PDF body. After the older documented route restriction was encountered in the saved source review, no further retrieval of those links or workaround was attempted. The failed click supplied no evidence about the article's contents.
- Zhedanov, *Gauss sums and orthogonal polynomials* (1997), pp.289–294, DOI [10.1142/S0217751X97000438](https://doi.org/10.1142/S0217751X97000438), remains unread. The DOI open returned an internal error. The 2009 primary paper explicitly attributes finite complex-weight orthogonality to it, but that does not substitute for the original six pages or exclude additional results.
- Exact primary bodies along the relevant earlier citation chain remain a bounded historical task. Do not repeat the same denied routes. New authorized source material would permit a meaningful continuation.
- Web PDFs were read as page-indexed extracted text. Sawa–Uchida and Puiseux screenshot requests returned cache misses; no fresh rendered-page verification or downloaded-byte hash is claimed. Local input hashes identify the compared project artifacts only.

## Revised next-action priorities

The detailed reproducible proposal is in `RANKING.json`. Scores mean next-action usefulness, not probability of truth, novelty, publication, or breakthrough.

- **65/100, distinct mathematical gate, inherited from the fusion reviewer:** test the b29 residual reciprocal-gcd route for U=H_29/(z+1), including both trace endpoints and the ordinary trace discriminant, at every primitive odd order d>29. A surviving modular factor is a route obstruction, not proof of a characteristic-zero multiple root. This source review has not run or independently assessed that separate test; it supports the conservative novelty dimension of 1/5. Acceptance would not supply all-A b29 overlap or general odd b.
- **38/100, distinct historical-source gate, awaiting new source material:** compare the original Zhedanov body and substantive unresolved citation-chain passages against the exact claim matrix. Repeated inaccessible-page searches are not the proposed action. This score does not replace the independent mathematical b29 gate.
- **Editorial follow-through, not a new research gate:** integrate the unconditional b27 result and exact inertia corollary into the existing manuscript, including the missing quasi-Laguerre attribution and the correct field/coordinate boundaries. This does not keep a completed proof stage at a high active research score.
- **15/100 cap, now applicable:** repeat the already closed b27 residual/overlap/fusion stage only if new contradictory evidence appears.
- **12/100 cap:** pursue a standalone “new Hensel/Puiseux mechanism” claim; the mechanism is established and no different active target is specified.

F020's frozen 67 and FUS-02's frozen 37 remain unchanged in this local report. The fusion candidate's 71 was for independent correctness review, which is now complete; it must not remain the active score for that stage. Current-next-action fields can instead name the distinct b29 gate or the historical-source gate with its different status, while preserving dated checkpoint history. No canonical identity is added.
