# b29 ordinary-residual certificate

Candidate scope: U=H_29/(z+1) is squarefree at every characteristic-zero primitive odd q-order d>29. Both trace endpoints and the trace discriminant are nonzero. Independent review is pending.

- REPORT.md: complete theorem, even-degree/nonmonic-B normalization, cyclotomic transfer, scope, and controls.
- residual_certificate.json: complete F₂[q] masks, Sylvester matrix, F/G, Bezout identity, and 38 exact low-order strips ending at 1.
- G_factorization.json: complete reduced-cyclotomic product.
- build_certificate.py: finite Euler construction and 13×13 division-free subset determinant.
- check_certificate.py: integer q-Pascal reconstruction, 13×13 and 26×26 Bareiss determinants, and controls.
- residual_checks.json: deterministic output of 7956 checks plus integer trace coefficients.
- replay_and_mutations.py and cold_replay_and_mutation_receipt.json: isolated byte replay and seven rejected corruptions.
- NEXT_STEP_RANKING.json: pending independent-review priority 73; completed producer-stage cap 15.
- SOURCE_BINDINGS.json and FILE_MANIFEST.json: source and packet hashes.

Run the three Python scripts in the order listed in REPORT.md. No non-standard package is required. This packet makes no b29 overlap, all-b, novelty, FFT, or conditioning claim.
