#!/usr/bin/env python3
"""Bounded m=14 ordinary-residual certificate; arithmetic adapted from the accepted b27 builder; Python standard library only."""
import json, time, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def deg(p): return p.bit_length()-1

def mul(a,b):
    if a.bit_length()<b.bit_length():a,b=b,a
    if not b:return 0
    if b.bit_length()<=80:
        c=0
        while b:
            l=b&-b;c^=a<<(l.bit_length()-1);b^=l
        return c
    n=max(a.bit_length(),b.bit_length())//2
    mask=(1<<n)-1
    al,ah=a&mask,a>>n;bl,bh=b&mask,b>>n
    low=mul(al,bl);high=mul(ah,bh)
    return low^((mul(al^ah,bl^bh)^low^high)<<n)^(high<<(2*n))

def divmodp(a,b):
    assert b
    q=0;db=deg(b)
    while a and deg(a)>=db:
        s=deg(a)-db;q^=1<<s;a^=b<<s
    return q,a

def gcd(a,b):
    while b:a,b=b,divmodp(a,b)[1]
    return a

def xgcd(a,b):
    r0,r1=a,b;s0,s1=1,0;t0,t1=0,1
    while r1:
        q,r=divmodp(r0,r1);r0,r1=r1,r
        s0,s1=s1,s0^mul(q,s1);t0,t1=t1,t0^mul(q,t1)
    assert mul(s0,a)^mul(t0,b)==r0
    return r0,s0,t0

def sqr(a):
    c=0
    while a:
        l=a&-a;c^=1<<(2*(l.bit_length()-1));a^=l
    return c

def reverse(a):return int(bin(a)[2:][::-1],2) if a else 0

def padd(a,b):
    c=[0]*max(len(a),len(b))
    for j,v in enumerate(a):c[j]^=v
    for j,v in enumerate(b):c[j]^=v
    while len(c)>1 and not c[-1]:c.pop()
    return c

def pscale(a,b):return [mul(v,b) for v in a]

def euler_trace(m):
    b=2*m+1;E=[1]
    for r in range(b):
        f=E+[0]
        for j in range(1,len(f)):f[j]^=E[j-1]<<r
        E=f
    H=[]
    for j,p in enumerate(E):
        shift=j*(j-1)//2
        assert not (p&((1<<shift)-1))
        H.append(p>>shift)
    assert H==H[::-1]
    U=[];last=0
    for h in H[:-1]:last^=h;U.append(last)
    assert H[-1]==last and U==U[::-1]
    S=[0,2]
    for j in range(2,m+1):S.append((S[-1]<<1)^S[-2])
    P=[0]*(m+1);P[0]=U[m]
    for k in range(1,m+1):
        for j in range(k+1):
            if (S[k]>>j)&1:P[j]^=U[m+k]
    return E,H,U,P

def recurrence(m):
    old=[1]
    if not m:return old
    cur=[6,1]
    for j in range(2,m+1):
        cur,old=padd(padd([0]+cur,pscale(cur,(1<<(2*j-1))^(1<<(2*j)))),pscale(old,mul(1^(1<<(2*j-1)),1^(1<<(2*j-2))))),cur
    return cur

def resultant_subset(A,B):
    da,db=len(A)-1,len(B)-1;n=da+db
    matrix=[]
    for i in range(db):matrix.append([0]*i+A[::-1]+[0]*(db-i-1))
    for i in range(da):matrix.append([0]*i+B[::-1]+[0]*(da-i-1))
    D=[0]*(1<<n);D[0]=1;products=0
    for mask in range(1<<n):
        row=mask.bit_count()
        if row==n or not D[mask]:continue
        for j,a in enumerate(matrix[row]):
            if a and not(mask>>j&1):D[mask|1<<j]^=mul(D[mask],a);products+=1
    return D[-1], {'matrix_order':n,'subset_states':1<<n,'nonzero_products':products,'row_masks_hex':[[hex(v) for v in row] for row in matrix]}

def main():
    start=time.monotonic();m=14
    E,H,U,P=euler_trace(m);assert P==recurrence(m)
    A=P[::2];B=P[1::2];assert len(A)==8 and len(B)==7 and A[-1]==1
    assert B[-1]==sum(1<<j for j in range(1,29))
    R,stats=resultant_subset(A,B);assert R
    F=mul(P[0],sqr(R));assert F
    Frev=reverse(F);G,s,t=xgcd(F,Frev)
    L=1
    for j in range(1,30,2):L=mul(L,1^(1<<j))
    current=G;strips=[]
    while True:
        factor=gcd(current,L)
        if factor==1:break
        quotient,remainder=divmodp(current,factor);assert not remainder
        strips.append({'input_degree':deg(current),'factor_hex':hex(factor),'factor_degree':deg(factor),'quotient_degree':deg(quotient)})
        current=quotient
    certificate={
        'schema':'ordinary-residual-mod2-v1','m':m,'b':29,'field':'F_2[q]',
        'bitmask_convention':'Bit j is coefficient of q^j; polynomial coefficients are ascending in z/t/y.',
        'construction':'Finite Euler product, exact shift removal, z+1 division, reciprocal trace; separate recurrence equality.',
        'euler_coefficients_hex':[hex(v) for v in E], 'H_coefficients_hex':[hex(v) for v in H],
        'U_coefficients_hex':[hex(v) for v in U], 'P_coefficients_hex':[hex(v) for v in P],
        'A_coefficients_hex':[hex(v) for v in A], 'B_coefficients_hex':[hex(v) for v in B],
        'A_degree':len(A)-1,'B_degree':len(B)-1,'A_leading_hex':hex(A[-1]),'B_leading_hex':hex(B[-1]),
        'resultant_hex':hex(R),'resultant_degree':deg(R),'discriminant_hex':hex(sqr(R)),
        'F_hex':hex(F),'F_degree':deg(F),'F_q_valuation':(F&-F).bit_length()-1,'reverse_F_hex':hex(Frev),
        'G_hex':hex(G),'G_degree':deg(G),'bezout_s_hex':hex(s),'bezout_t_hex':hex(t),
        'L_hex':hex(L),'L_degree':deg(L),'stripping_steps':strips,
        'survivor_hex':hex(current),'survivor_degree':deg(current),
        'all_odd_orders_above_29_excluded':current==1,'determinant_work':stats
    }
    (ROOT/'residual_certificate.json').write_text(json.dumps(certificate,indent=2)+'\n')
    print(json.dumps({k:certificate[k] for k in ['F_degree','G_degree','resultant_degree','survivor_degree','all_odd_orders_above_29_excluded']},indent=2))
    print('elapsed seconds',round(time.monotonic()-start,6))
    print('strip count',len(strips),'P degree',len(P)-1,'P0 degree',deg(P[0]))
if __name__=='__main__':main()
