# Candidate theorem: b29 ordinary Rogers–Szegő residual squarefreeness

12 October 2026 UTC. Status: exact producer certificate with orthogonal author checks; independent acceptance remains a separate decision.

## Result and scope

Let k be any characteristic-zero field and q in k have primitive odd multiplicative order d>29. Define the Gaussian-coefficient polynomial

H_29(z;q) = sum_(j=0)^29 [29 choose j]_q z^j = (z+1)U(z;q).

The finite certificate in this packet proves the candidate conclusion that U is squarefree over an algebraic closure of k. For its unique monic degree-14 trace polynomial P, defined by U(z;q)=z^14 P(z+z^(-1);q), the stronger componentwise conclusion is

P(2;q) != 0, P(-2;q) != 0, and Disc_t P(t;q) != 0.

The result covers every odd d>29 directly, with no finite d cutoff and no large-order analytic premise. It concerns the ordinary residual only. It does not establish b29 all-A overlap simplicity, arbitrary b, positive-characteristic squarefreeness, historical novelty, Fourier running time, or numerical conditioning.

The decisive calculation in F_2[q] is

G = gcd(F,F*) = Phi_1^566 Phi_3^170 Phi_5^48 Phi_7^56 Phi_9^17 Phi_11^11 Phi_13^13,

where the Phi polynomials are reduced modulo 2, and F is the reduction of either P(2)Disc(P) or P(-2)Disc(P). This is a complete coefficientwise product identity, not an assertion that all displayed cyclotomic polynomials are irreducible over F_2.

Recorded dimensions and degrees:

- deg_t P=14; P is monic over both Z[q] and F_2[q]
- P=A(t²)+tB(t²), with deg_y A=7, deg_y B=6
- A is monic; B is not monic: lc_y B = q+q²+...+q²⁸
- deg_q P(0)=210, with q-adic valuation 0
- deg_q R=1820 and valuation 7, where R=Res_y(A,B)
- deg_q F=3850 and valuation 14
- F*=q^3850 F(1/q) has degree 3836
- deg_q G=1802, with constant coefficient 1
- L=product_(j=1,3,...,29)(q^j-1) has degree 225
- 38 successive exact gcd/division strips by L remove G completely
- The complete root-order set of G is {1,3,5,7,9,11,13}

All coefficient bitmasks, full Bezout coefficients, matrix entries, and every stripping step are in residual_certificate.json. The redundant complete factor product is in G_factorization.json.

## 1. Integral normalization

All Gaussian coefficients are taken as polynomials in Z[q], before any root-of-unity specialization. The finite Euler identity

product_(r=0)^28 (1+q^r z) = sum_(j=0)^29 q^(j(j-1)/2)[29 choose j]_q z^j

constructs them by exact monomial-shift removal. Gaussian reciprocity makes H_29 reciprocal and monic of degree 29. Thus H_29(-1)=0; division by z+1 gives a monic reciprocal U of degree 28 with constant coefficient 1. A symmetric Laurent polynomial is uniquely an integer polynomial in t=z+z^(-1): the basis z^j+z^(-j) satisfies S_0=2, S_1=t, S_j=tS_(j-1)-S_(j-2). Consequently U=z^14 P(t) with monic P of degree 14 in Z[q,t].

The accepted trace recurrence is

P_0=1, P_1=t+q+q²,
P_j=(t+q^(2j-1)+q^(2j))P_(j-1) -(1-q^(2j-1))(1-q^(2j-2))P_(j-2).

The builder constructs P from the Euler product and reciprocal basis, then checks this recurrence coefficientwise modulo 2. The checker separately builds the integer Gaussian coefficients by q-Pascal, divides H_29 by z+1 over Z[q], and constructs the integer trace. It verifies all reduced coefficients against the builder. A further integer binomial-Laurent substitution reconstructs U exactly from P, rather than relying only on the reciprocal-basis recurrence.

The same integer check verifies

H_29(1)=2P(2), and H'_29(-1)=P(-2).

The second sign is positive because m=14 is even. The b27 identity has the opposite sign and has not been copied into this proof. Reducing H_29(1) directly modulo 2 would lose the endpoint information; the calculation uses P itself.

## 2. Even-degree characteristic-two discriminant normalization

This derivation does not assume B is monic. Work first over K=F_2(q), where

p(t)=A(t²)+tB(t²), deg_t p=14, A monic of degree 7, B of degree 6 and leading coefficient c=q+...+q²⁸ !=0.

The derivative is p'(t)=B(t²), of degree 12 and leading coefficient c. Let gamma_1,...,gamma_6 be the roots of B over an algebraic closure, counted with multiplicity. In characteristic 2 each t²-gamma_i has its root twice, and p at those roots equals A(gamma_i). The resultant product formula gives

Res_t(p,p') = c^14 product_(i=1)^6 A(gamma_i)^2.

Independently,

Res_y(B,A) = c^7 product_(i=1)^6 A(gamma_i).

The resultant-swap sign is immaterial in characteristic 2, and monicity of p means that its discriminant equals Res_t(p,p') there. Therefore

Disc_t p = Res_y(A,B)^2 = R².

The powers of c agree exactly. If B were first divided by c, its resultant with degree-7 A would be multiplied by c^(-7), so omitting the compensation would remove a factor c^14 from the discriminant. No such normalization is performed here. In particular, the input B leading coefficient is stored explicitly as the mask 0x1ffffffe, not 1.

This reasoning gives an identity in the polynomial coefficient ring: both discriminant and Sylvester resultant are polynomial expressions, and equality on the generic coefficients extends to all specializations. Thus B degree drops or repeated roots after specializing q do not create an omitted denominator or an exception. A remains monic at every q. The orthogonal checker compares the split 13-by-13 Sylvester resultant with the direct 26-by-26 resultant of p (degree 14) and p' (actual degree 12), so the instance is also checked without using the split formula as an assumption.

## 3. Construction of the finite certificate

Define integral polynomials

C_+(q)=P(2;q)Disc_t P(t;q), C_-(q)=P(-2;q)Disc_t P(t;q).

In characteristic 2, 2=-2=0, so both reduce to the same nonzero polynomial

F=P(0)R².

The builder computes R as a division-free subset determinant on the exact 13-by-13 Sylvester matrix for A and B. There are 8192 subset states and 24401 nonzero polynomial multiplications. Coefficients in F_2[q] are represented as integers whose bit j is the coefficient of q^j; additions are XOR and products are carryless products. No floating-point calculation or root approximation is used.

It reverses F with its actual reduced degree 3850, retaining the q-adic factor q^14. The polynomial F* therefore has degree 3836. An extended Euclidean calculation produces the complete s,t satisfying

sF+tF*=G.

Both the gcd and this full Bezout identity are checked coefficientwise by the second program using a different multiplication routine.

For complete low-order exclusion, start with G_0=G. Repeatedly set h_i=gcd(G_i,L) and G_(i+1)=G_i/h_i, where L=product_(j=1,3,...,29)(q^j-1). Every gcd, degree and exact division is recorded and rechecked. The result after 38 rounds is exactly 1, including all multiplicities. Every root of each factor q^j-1 has odd order dividing j<=29. The product L can have repeated factors, but that causes no issue: repeated stripping accounts for all multiplicities in G. Thus G has no root of odd order above 29.

As a redundant stronger check, construct every odd reduced cyclotomic polynomial through order 29 recursively from q^n-1. Extract exact gcd layers of G with each polynomial. All nontrivial layers in this case are full cyclotomic factors with uniform multiplicity. Their product is exactly the displayed G. The degree sum is

566 + 170·2 + 48·4 + 56·6 + 17·6 + 11·10 + 13·12 = 1802.

This accounts for every coefficient and factor of G. It does not suggest a general order-at-most-m theorem; the inherited m=12/order17 obstruction to that stronger heuristic remains valid.

## 4. Characteristic-zero implication

Suppose either C_+ or C_- vanished at a primitive d-th root q in a characteristic-zero field, for odd d>29. The map Q(zeta_d) to k taking zeta_d to q is injective. Hence the minimal polynomial Phi_d divides that integral C in Q[q]. Monic division by Phi_d gives a quotient in Z[q] and zero remainder. Reduction modulo 2 therefore makes bar(Phi_d) divide F.

For d>1, Phi_d is monic, reciprocal, and has constant coefficient one; its reduction preserves these properties and its degree. If F=bar(Phi_d)Q and N=deg F, reversal using that exact N gives

F*=bar(Phi_d) q^(N-deg Phi_d) Q(1/q).

The second factor is a polynomial even when Q has zero constant coefficient. Thus bar(Phi_d) also divides F* and therefore G. Possible characteristic-zero degree loss after reduction is irrelevant because the reversal used deg F itself.

For odd d, q^d-1 is separable in characteristic 2: its derivative is q^(d-1), coprime to it. Reduce the identity q^d-1=product_(e|d)Phi_e. The factors have no common roots, and induction over divisors proves that every root of bar(Phi_d) has exact multiplicative order d. This contradicts the complete order-at-most-29 support of G. Therefore C_+ and C_- are both nonzero at every primitive odd d>29. Since k is a field, both endpoints and Disc_t P are separately nonzero.

Finally, factor P(t)=product_i(t-t_i) over an algebraic closure. Then U(z)=product_i(z²-t_i z+1). Each quadratic has discriminant t_i²-4; the resultant between distinct indexed quadratics is (t_i-t_j)². Consequently the polynomial identity

Disc_z U = P(2)P(-2)(Disc_t P)²

holds over Z[q], including exceptional configurations by polynomial identity. The already established three nonzero factors prove Disc_z U !=0. No embedding of all of k into C, spectral argument, finite-order scan, or inherited large-order theorem is required.

A modular obstruction would only have been a failure of this sufficient route, not a characteristic-zero multiple-root counterexample. Here no obstruction survives. The conditional characteristic-zero survivor inspection was therefore unnecessary and was not run.

## 5. Validation and reproducibility

Run in this folder, with Python's standard library only:

python build_certificate.py
python check_certificate.py
python replay_and_mutations.py

The checker passes 7956 exact assertions. It constructs integer coefficients separately, reconstructs U from the trace, verifies the endpoint signs, and compares two Bareiss determinants against the subset determinant: 650 exact-division assertions for the split 13-by-13 matrix and 5525 for the direct 26-by-26 discriminant matrix. It verifies every stripping step, complete factor reconstruction, saved metadata, and full Bezout identity.

Fresh controls specifically cover the even-degree change:

- A quadratic with nonmonic constant B has discriminant B².
- A monic quartic with nonmonic linear B satisfies the split formula.
- At q=0 that quartic's B drops from degree 1 to degree 0; the specialized identity remains valid.
- Replacing this b29 B leading coefficient by 1 changes the computed resultant and is rejected.
- Genuine repeated-root even polynomials produce zero resultants; a separable quadratic produces a nonzero one.
- A complete order-31 factor is coprime to L and would survive this filter.
- Using q^29-1 alone is insufficient and is rejected.
- Endpoint erasure, altered Bezout data, and padded reverse-degree conventions are detected.

A cold replay copies only the two programs to a fresh temporary directory, runs them with python -I, and requires byte-identical certificate, check, and factorization outputs. Seven separately mutated certificate inputs must fail: resultant bit, Bezout bit, missing final strip, nonmonic trace leading coefficient, falsely monic B field, padded F-degree metadata, and false survivor metadata. All seven fail with the expected assertion classes. The receipt records the exact SHA-256 values and diagnostics.

These are orthogonal author checks, not an independent external review. Arithmetic routines and the Euler/q-Pascal architecture were transparently adapted from the accepted b27 packet. The direct degree-14 discriminant calculation and even-degree controls are new at this scope. Independent acceptance should reconstruct the b29 input and resultant by a third route rather than simply rerun these scripts.

## 6. Next step and ranking

The requested fixed b29 construction gate succeeds. Its completed producer stage should not remain an active unsolved target. The next distinct task is independent reconstruction and review of the b29 ordinary-residual theorem and certificate.

Using ranking/RANKING_METHOD.md v1.1, the dimensions for that pending review are information gain 4, tractability 5, defensible novelty opportunity 1, scope/impact 3, and evidence readiness 5. Their weighted average is 3.65, giving priority 1+round(99·3.65/5)=73. This is a next-action priority, not correctness, novelty, or success probability. The completed construction stage has the rubric's cap 15. The frozen F020 score 67 and the prior proposed-construction score 65 are preserved as historical scores, not silently rewritten.

The independent review can settle one all-order b29 ordinary guard. It cannot settle b29 overlap or arbitrary b. No higher-b expansion, prime search, or new overlap investigation was performed in this bounded task.

## 7. Sources and provenance boundary

The task contract is next_cycle_fusion_review/NEXT_GATE_RANKING.json. The accepted b27 construction/report and next_cycle_rs_review/INDEPENDENT_REVIEW.md supply the validated normalization and reciprocal-gcd transfer pattern. The local publication derivative repo/math/reviewed_rounds/2026-10-12-reviewed-research/rs-ordinary-squarefree.md, sections 2 and 4, supplies the general trace normalization and even-degree resultant identity, which are explicitly rederived above. That derivative was cited by the accepted packet at repository commit 95419a2bd5d0bf6d3b78747bf163a62a7b9e4b5d. This task verifies the local source bytes, not the underlying historical archive or historical priority.

SOURCE_BINDINGS.json hashes the source bytes actually used and identifies copied/adapted arithmetic. FILE_MANIFEST.json binds this new packet. No frozen predecessor or external service was modified, no source table was reranked, and no additional canonical discovery is asserted.
