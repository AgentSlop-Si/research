#!/usr/bin/env python3
"""Verify exact producer bindings and review-context source identities."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
PACKET = BASE/'next_cycle_b29'
items = []
for source in json.loads((PACKET/'SOURCE_BINDINGS.json').read_text())['sources']:
    items.append(('source', BASE/source['path_relative_to_research_resume_2251'],source))
for source in json.loads((PACKET/'FILE_MANIFEST.json').read_text())['files']:
    items.append(('producer_packet',PACKET/source['path'],source))
files = []
for scope,path,expected in items:
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    entry = {'scope':scope,'path_relative_to_research_resume_2251':str(path.relative_to(BASE)),
             'sha256':digest,'bytes':len(data),'hash_match':digest == expected['sha256'],
             'size_match':len(data) == expected['bytes']}
    if not entry['hash_match'] or not entry['size_match']:
        raise AssertionError(entry)
    files.append(entry)
context = []
for name in ['next_cycle_b29/FILE_MANIFEST.json','b27_independent_review.md',
             'next_cycle_fusion_review/INDEPENDENT_REVIEW.md']:
    data = (BASE/name).read_bytes()
    context.append({'path_relative_to_research_resume_2251':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
result = {'all_passed':True,'bound_files_verified':len(files),'files':files,
          'additional_review_context':context,
          'boundary':'Exact local bytes verified. No remote commit or historical archive replay is asserted.'}
(HERE/'source_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_passed':True,'bound_files_verified':len(files)}))
