#!/usr/bin/env python3
"""Isolated producer/reviewer replay and independently selected corruptions."""
import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKET = HERE.parent/'next_cycle_b29'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def execute(path, *args):
    return subprocess.run([sys.executable,'-I',str(path),*map(str,args)],
                          capture_output=True,text=True,timeout=120)

receipt = {'producer_cold_replay':{},'independent_cold_replay':{},
           'independent_mutations':[],'all_passed':False}
with tempfile.TemporaryDirectory(prefix='b29-independent-review-') as tmp:
    root = Path(tmp)
    packet = root/'next_cycle_b29'
    review = root/'review'
    packet.mkdir()
    review.mkdir()
    for file in PACKET.iterdir():
        if file.is_file():
            shutil.copyfile(file,packet/file.name)
    for name in ['build_certificate.py','check_certificate.py','replay_and_mutations.py']:
        r = execute(packet/name)
        assert r.returncode == 0,(name,r.stderr)
        # Runtime is not proof data; omit the producer's variable timing line.
        stable_stdout = '\n'.join(line for line in r.stdout.splitlines() if not line.startswith('elapsed seconds'))+'\n'
        receipt['producer_cold_replay'][name] = {'exit_code':0,'stdout':stable_stdout}
    for name in ['residual_certificate.json','residual_checks.json','G_factorization.json','cold_replay_and_mutation_receipt.json']:
        assert (packet/name).read_bytes() == (PACKET/name).read_bytes(),name
        receipt['producer_cold_replay'][name] = {'byte_identical':True,'sha256':sha(packet/name)}
    shutil.copyfile(HERE/'independent_checker.py',review/'independent_checker.py')
    r = execute(review/'independent_checker.py','--packet',packet,'--output',review/'independent_results.json')
    assert r.returncode == 0,r.stderr
    assert (review/'independent_results.json').read_bytes() == (HERE/'independent_results.json').read_bytes()
    receipt['independent_cold_replay'] = {'byte_identical':True,'sha256':sha(review/'independent_results.json'),'python_isolated':True,'producer_code_imported_by_independent_checker':False}
    orig_cert = (packet/'residual_certificate.json').read_bytes()
    orig_factors = (packet/'G_factorization.json').read_bytes()
    def both_B(c):
        c['B_coefficients_hex'][-1] = '0x1'
        c['B_leading_hex'] = '0x1'
    def pad_reverse(c):
        c['F_degree'] += 1
        c['reverse_F_hex'] = hex(int(c['reverse_F_hex'],16)<<1)
    def matrix_bit(c):
        c['determinant_work']['row_masks_hex'][0][0] = '0x0'
    mutations = [
        ('resultant_one_bit','certificate',lambda c:c.update(resultant_hex=hex(int(c['resultant_hex'],16)^1))),
        ('Bezout_one_bit','certificate',lambda c:c.update(bezout_s_hex=hex(int(c['bezout_s_hex'],16)^1))),
        ('missing_final_strip','certificate',lambda c:c['stripping_steps'].pop()),
        ('false_monic_B_consistent_metadata','certificate',both_B),
        ('padded_degree_and_reverse_together','certificate',pad_reverse),
        ('altered_H_input','certificate',lambda c:c['H_coefficients_hex'].__setitem__(1,'0x1')),
        ('altered_Euler_payload','certificate',lambda c:c['euler_coefficients_hex'].__setitem__(1,'0x1')),
        ('altered_integer_trace_mod2','certificate',lambda c:c['P_coefficients_hex'].__setitem__(0,hex(int(c['P_coefficients_hex'][0],16)^1))),
        ('false_survivor_metadata','certificate',lambda c:c.update(survivor_hex='0x3')),
        ('discriminant_one_bit','certificate',lambda c:c.update(discriminant_hex=hex(int(c['discriminant_hex'],16)^1))),
        ('Sylvester_matrix_payload_one_bit','certificate',matrix_bit),
        ('factorization_lost_multiplicity','factorization',lambda c:c['factorization'][0].update(multiplicity=c['factorization'][0]['multiplicity']-1)),
        ('factorization_false_primitive_order','factorization',lambda c:c['factorization'][2].update(cyclotomic_order=31)),
    ]
    for name,kind,mutate in mutations:
        (packet/'residual_certificate.json').write_bytes(orig_cert)
        (packet/'G_factorization.json').write_bytes(orig_factors)
        target = packet/('residual_certificate.json' if kind == 'certificate' else 'G_factorization.json')
        data = json.loads(target.read_text())
        mutate(data)
        target.write_text(json.dumps(data,indent=2)+'\n')
        r = execute(review/'independent_checker.py','--packet',packet,'--output',review/'mutant.json')
        assert r.returncode != 0,(name,'corruption incorrectly accepted')
        diagnostic = r.stderr.strip().splitlines()[-1]
        assert diagnostic.startswith('AssertionError:'),(name,diagnostic)
        receipt['independent_mutations'].append({'name':name,'rejected':True,'diagnostic':diagnostic})
receipt['all_passed'] = True
(HERE/'replay_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'all_passed':True,'independent_mutations_rejected':len(receipt['independent_mutations']),
                  'independent_output_sha256':receipt['independent_cold_replay']['sha256']},indent=2))
