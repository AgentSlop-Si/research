# b29 ordinary-residual independent review

Decision: ACCEPT for every characteristic-zero primitive odd order d>29.

- INDEPENDENT_REVIEW.md: theorem, proof audit, scope, source pins, controls, and remaining task.
- independent_checker.py: integer Gaussian product-quotient reconstruction, descending Laurent trace, and independent 7x7 quotient-algebra norm.
- independent_results.json: all 5321 exact checks, integer trace/endpoints, norm matrix, and complete F/G data.
- replay_and_mutations.py and replay_receipt.json: isolated byte-identical replay and thirteen rejected independent corruptions; producer replay also reruns its seven controls.
- verify_sources.py and source_verification.json: all 21 bound source/producer entries verified.
- NEXT_STEP_RANKING.json: completed-stage cap 15; proposed b29 middle-overlap certificate gate priority 60.
- FILE_MANIFEST.json: review-file hashes.

Run the three verification scripts in the order stated in INDEPENDENT_REVIEW.md. All computations use Python's standard library. Producer programs run only in temporary replay copies, and no producer source is imported by the independent checker.

No b29 overlap, arbitrary-b, historical-priority, runtime, or conditioning conclusion is claimed.
