#!/usr/bin/env python3
"""Independent b29 reconstruction, quotient-algebra norm, and exact guards.

No producer or predecessor program is imported. The resultant is the determinant
of multiplication by B on F_2[q,y]/(A), with A monic; it is evaluated by the
literal 7! Leibniz terms, sharing only partial products. All coefficient products
use integer Kronecker substitution with 16-bit lanes, not carryless shifts.
"""
import argparse
import hashlib
import json
import math
from functools import lru_cache
from pathlib import Path

HERE = Path(__file__).resolve().parent
CHECKS = []

def need(label, condition):
    if not condition:
        raise AssertionError(label)
    CHECKS.append(label)

def trim(a):
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a

def zadd(a, b, sign=1, shift=0):
    out = a[:] + [0] * max(0, len(b) + shift - len(a))
    for i, v in enumerate(b):
        out[i + shift] += sign * v
    return trim(out)

def zdiv_exact(a, b):
    out = [0] * max(1, len(a) - len(b) + 1)
    rem = trim(a[:])
    while len(rem) >= len(b) and rem != [0]:
        s = len(rem) - len(b)
        q, r = divmod(rem[-1], b[-1])
        need('integer divisor leading coefficient exact', r == 0)
        out[s] = q
        rem = zadd(rem, [v * q for v in b], -1, s)
    need('Gaussian product-quotient exact remainder', rem == [0])
    return trim(out)

def gaussian_product_row(n):
    row = [[1]]
    for j in range(1, n + 1):
        numerator = zadd(row[-1], row[-1], -1, n + 1 - j)
        divisor = [1] + [0] * (j - 1) + [-1]
        row.append(zdiv_exact(numerator, divisor))
    return row

def parity(a):
    return sum((v & 1) << j for j, v in enumerate(a))

def trace_elimination(H):
    U = []
    last = [0]
    for h in H[:-1]:
        last = zadd(h, last, -1)
        U.append(last)
    need('integer division by z+1 has no remainder', last == H[-1])
    need('integer H reciprocal and monic', H == H[::-1] and H[-1] == [1])
    need('integer U reciprocal and monic', U == U[::-1] and U[-1] == [1])
    rem = [v[:] for v in U]
    P = [[0] for _ in range(15)]
    for j in range(14, -1, -1):
        coeff = rem[14 + j][:]
        P[j] = coeff
        for ell in range(j + 1):
            power = 14 + j - 2 * ell
            rem[power] = zadd(rem[power], [v * math.comb(j, ell) for v in coeff], -1)
    need('descending Laurent elimination exact residual', all(v == [0] for v in rem))
    need('integer trace monic degree14', P[-1] == [1])
    return U, P

ASCII_BITS = bytes(1 if i == 49 else 0 for i in range(256))
PARITY_ASCII = bytes(48 + (i & 1) for i in range(256))

@lru_cache(maxsize=8192)
def spread16(a):
    s = format(a, 'b')[::-1].encode().translate(ASCII_BITS)
    buf = bytearray(2 * len(s))
    buf[::2] = s
    return int.from_bytes(buf, 'little')

def kmul(a, b):
    if not a or not b:
        return 0
    if a == 1:
        return b
    if b == 1:
        return a
    # Each integer convolution coefficient is at most min(lengths), so there
    # is no inter-lane carry. A failed bound is an error, never silent overflow.
    if min(a.bit_length(), b.bit_length()) >= 65536:
        raise ArithmeticError('Kronecker lane bound exceeded')
    length = a.bit_length() + b.bit_length() - 1
    raw = (spread16(a) * spread16(b)).to_bytes(2 * length, 'little')
    return int(raw[::2].translate(PARITY_ASCII)[::-1], 2)

def fdiv(a, b):
    if not b:
        raise ZeroDivisionError('zero polynomial divisor')
    q = 0
    while a.bit_length() >= b.bit_length():
        s = a.bit_length() - b.bit_length()
        a ^= b << s
        q ^= 1 << s
    return q, a

def fgcd(a, b):
    while b:
        a, b = b, fdiv(a, b)[1]
    return a

def fpow(a, n):
    out = 1
    while n:
        if n & 1:
            out = kmul(out, a)
        n >>= 1
        if n:
            a = kmul(a, a)
    return out

def quotient_norm(A, B):
    A = trim(A[:])
    B = trim(B[:])
    if A[-1] != 1 or len(A) < 2:
        raise ValueError('norm modulus must be monic and nonconstant')
    n = len(A) - 1
    columns = []
    for shift in range(n):
        r = [0] * shift + B[:]
        while len(r) > n:
            lc = r[-1]
            offset = len(r) - len(A)
            for j, a in enumerate(A):
                r[offset + j] ^= kmul(lc, a)
            trim(r)
        columns.append(r + [0] * (n - len(r)))
    M = [[columns[j][i] for j in range(n)] for i in range(n)]
    total = 0
    terms = 0
    partial_products = 0
    def visit(row, used, value):
        nonlocal total, terms, partial_products
        if row == n:
            total ^= value
            terms += 1
            return
        for col in range(n):
            if not (used >> col) & 1:
                partial_products += 1
                visit(row + 1, used | (1 << col), kmul(value, M[row][col]))
    visit(0, 0, 1)
    return total, {'dimension': n, 'leibniz_terms': terms,
                   'partial_products': partial_products,
                   'matrix_hex': [[hex(v) for v in row] for row in M]}

def exact_order_factor(f, n):
    need('order factor divides q^n-1 at '+str(n), fdiv((1 << n) ^ 1, f)[1] == 0)
    need('order factor constant coefficient one at '+str(n), f & 1 == 1)
    for d in range(1, n):
        if n % d == 0:
            need('no proper-divisor root order '+str(n)+'/'+str(d), fgcd(f, (1 << d) ^ 1) == 1)

def run(packet):
    C = json.loads((packet / 'residual_certificate.json').read_text())
    H = gaussian_product_row(29)
    U, IP = trace_elimination(H)
    P = list(map(parity, IP))
    need('certificate exact domain', C['b'] == 29 and C['m'] == 14 and C['field'] == 'F_2[q]')
    for name, actual in [('H', list(map(parity, H))), ('U', list(map(parity, U))), ('P', P)]:
        need(name+' coefficientwise reconstruction', actual == [int(v, 16) for v in C[name+'_coefficients_hex']])
    need('Euler coefficient payload agrees with independent Gaussian row',
         [parity(h) << (j * (j-1)//2) for j, h in enumerate(H)] == [int(v, 16) for v in C['euler_coefficients_hex']])
    A, B = P[::2], P[1::2]
    need('even split A', C['A_degree'] == 7 and C['A_leading_hex'] == '0x1' and A == [int(v,16) for v in C['A_coefficients_hex']])
    need('nonmonic split B', C['B_degree'] == 6 and B == [int(v,16) for v in C['B_coefficients_hex']] and C['B_leading_hex'] == hex(B[-1]) == '0x1ffffffe')
    plus = [0]
    minus = [0]
    hsum = [0]
    deriv = [0]
    for j, p in enumerate(IP):
        plus = zadd(plus, [v * 2**j for v in p])
        minus = zadd(minus, [v * (-2)**j for v in p])
    for j, h in enumerate(H):
        hsum = zadd(hsum, h)
        if j:
            deriv = zadd(deriv, [v * j * (-1)**(j-1) for v in h])
    need('positive endpoint exact factor two', hsum == [2*v for v in plus])
    need('negative endpoint correct even-m sign', minus == deriv)
    need('endpoint reductions both P0', parity(plus) == parity(minus) == P[0])
    need('endpoint erasure control', parity(hsum) == 0 and P[0] != 0)
    producer_checks = json.loads((packet / 'residual_checks.json').read_text())
    need('producer integer trace data exact', producer_checks['integer_P_coefficients'] == IP)
    need('producer integer endpoint data exact', producer_checks['P_plus2_integer_coefficients'] == plus and producer_checks['P_minus2_integer_coefficients'] == minus)
    R, norm = quotient_norm(A, B)
    need('quotient-algebra norm equals supplied resultant', R == int(C['resultant_hex'],16))
    need('resultant degree1820 and valuation7', C['resultant_degree'] == R.bit_length()-1 == 1820 and (R & -R).bit_length()-1 == 7)
    D = kmul(R, R)
    need('ordinary discriminant coefficient payload', D == int(C['discriminant_hex'],16))
    F = kmul(P[0], D)
    need('F exact reconstruction', F == int(C['F_hex'],16))
    need('actual F degree3850 and valuation14', C['F_degree'] == F.bit_length()-1 == 3850 and C['F_q_valuation'] == (F & -F).bit_length()-1 == 14)
    rev = sum(1 << (3850-i) for i in range(F.bit_length()) if (F >> i) & 1)
    need('actual-degree reciprocal not padded', rev == int(C['reverse_F_hex'],16) and rev.bit_length()-1 == 3836)
    G = fgcd(F, rev)
    need('full gcd reconstruction', G == int(C['G_hex'],16) and C['G_degree'] == G.bit_length()-1 == 1802 and G & 1 == 1)
    need('full Bezout equality', kmul(int(C['bezout_s_hex'],16), F) ^ kmul(int(C['bezout_t_hex'],16), rev) == G)
    L = 1
    for j in range(1,30,2):
        L = kmul(L, (1 << j) ^ 1)
    need('L all odd orders through29', C['L_hex'] == hex(L) and C['L_degree'] == L.bit_length()-1 == 225)
    cur = G
    need('exact38 stripping records', len(C['stripping_steps']) == 38)
    for i, s in enumerate(C['stripping_steps']):
        h = fgcd(cur,L)
        need('strip input and factor '+str(i), s['input_degree'] == cur.bit_length()-1 and s['factor_hex'] == hex(h) and s['factor_degree'] == h.bit_length()-1 and h > 1)
        cur, rem = fdiv(cur,h)
        need('strip exact quotient '+str(i), rem == 0 and s['quotient_degree'] == cur.bit_length()-1)
    need('all factors exhausted at one', cur == 1 and C['survivor_hex'] == '0x1' and C['survivor_degree'] == 0 and C['all_odd_orders_above_29_excluded'] is True)
    facts = json.loads((packet / 'G_factorization.json').read_text())
    cyclo = {}
    for n in range(1,30,2):
        v = (1 << n) ^ 1
        for d in range(1,n):
            if n % d == 0:
                v, r = fdiv(v,cyclo[d])
                need('cyclotomic exact quotient '+str(n)+'/'+str(d), r == 0)
        cyclo[n] = v
    profile = {1:566,3:170,5:48,7:56,9:17,11:11,13:13}
    need('complete listed multiplicities', {v['cyclotomic_order']:v['multiplicity'] for v in facts['factorization']} == profile)
    prod = 1
    for v in facts['factorization']:
        n = v['cyclotomic_order']
        f = int(v['polynomial_hex'],16)
        need('factor exact reduced cyclotomic '+str(n), f == cyclo[n])
        exact_order_factor(f,n)
        prod = kmul(prod,fpow(f,v['multiplicity']))
    need('complete product coefficientwise G', prod == G == int(facts['G_hex'],16) and facts['G_degree'] == 1802 and facts['product_checked'] is True)
    sylv = [[0]*i+A[::-1]+[0]*(5-i) for i in range(6)] + [[0]*i+B[::-1]+[0]*(6-i) for i in range(7)]
    work = C['determinant_work']
    need('producer13x13 matrix entry payload', work['row_masks_hex'] == [[hex(v) for v in row] for row in sylv] and work['matrix_order'] == 13 and work['subset_states'] == 8192)
    # Additional mathematical negative controls independent of saved certificates.
    controls = {}
    controls['insufficient_q29_only_leaves_factors'] = fgcd(G,(1 << 29)^1) != G
    phi31 = (1 << 31)-1
    exact_order_factor(phi31,31)
    controls['out_of_domain_order31_survives_L'] = fgcd(phi31,L) == 1
    # Composite orders matter: Phi_33=(q^33+1)/((q+1)Phi_3 Phi_11).
    phi33, rem33 = fdiv((1 << 33)^1, kmul(kmul(cyclo[1],cyclo[3]),cyclo[11]))
    exact_order_factor(phi33,33)
    controls['composite_order33_survives_L'] = rem33 == 0 and fgcd(phi33,L) == 1
    # Reducing Phi_62 over F2 gives Phi_31. The root-order lifting argument
    # cannot be used for even d; q^62-1 is not separable in characteristic two.
    phi62_integer = [(-1)**j for j in range(31)]
    controls['even_order_guard_is_essential'] = parity(phi62_integer) == phi31 and kmul((1 << 31)^1,(1 << 31)^1) == (1 << 62)^1
    controls['q0_specialization'] = quotient_norm([v&1 for v in A],[v&1 for v in B])[0] == R & 1 == 0
    # p=t^2+(q+1)t+q^2+q: constant nonmonic B=q+1 gives R=B.
    controls['nonmonic_constant_B'] = quotient_norm([6,1],[3])[0] == 3
    # p=t^4+q*t^3+t^2+(q+1)t+q; A=y^2+y+q, B=q*y+q+1.
    toyR = quotient_norm([2,1,1],[3,2])[0]
    # Elementary quadratic norm d^2+b*c*d+a*c^2, with a=q,b=1,c=q,d=q+1.
    controls['nonmonic_linear_B_exact_formula'] = toyR == kmul(3,3)^kmul(2,3)^kmul(2,kmul(2,2))
    controls['B_scaling_preserves_full_degree_power'] = quotient_norm([2,1,1],[kmul(3,3),kmul(3,2)])[0] == kmul(kmul(3,3),toyR)
    controls['nonmonic_B_degree_drop_q0'] = quotient_norm([0,1,1],[1])[0] == toyR & 1 == 1
    controls['zero_B_repeated_even_polynomial'] = quotient_norm([1,4,1],[0])[0] == 0
    controls['common_factor_repeated_even_polynomial'] = quotient_norm([1,0,1],[1,1])[0] == 0
    controls['separable_quadratic_positive'] = quotient_norm([1,1],[1])[0] == 1
    wrongB = B[:]
    wrongB[-1] = 1
    controls['forcing_B_monic_changes_norm'] = quotient_norm(A,wrongB)[0] != R
    for name, val in controls.items():
        need(name,val)
    # Small exhaustive check of Kronecker arithmetic against set convolution.
    for a in range(32):
        for b in range(32):
            expected = 0
            for i in range(5):
                for j in range(5):
                    if (a >> i) & 1 and (b >> j) & 1:
                        expected ^= 1 << (i+j)
            need('Kronecker convolution '+str(a)+'/'+str(b), kmul(a,b) == expected)
    return {'verdict':'PASS','construction':'Gaussian product-quotient in Z[q]; descending Laurent elimination; 7x7 multiplication-by-B norm and full Leibniz determinant; 16-bit Kronecker arithmetic',
            'source_certificate_sha256':hashlib.sha256((packet/'residual_certificate.json').read_bytes()).hexdigest(),
            'check_count':len(CHECKS),'checks':CHECKS,'integer_P_coefficients':IP,
            'integer_P_plus2':plus,'integer_P_minus2':minus,'quotient_norm':norm,
            'R_hex':hex(R),'F_hex':hex(F),'reverse_F_hex':hex(rev),'G_hex':hex(G),
            'exact_root_order_multiplicities':profile,'controls':controls}

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--packet',type=Path,default=HERE.parent/'next_cycle_b29')
    p.add_argument('--output',type=Path,default=HERE/'independent_results.json')
    args = p.parse_args()
    result = run(args.packet)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['verdict','check_count','source_certificate_sha256','controls']},indent=2))
