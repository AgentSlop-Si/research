# Independent review: b29 ordinary residual squarefreeness

13 October 2026 UTC. **Decision: ACCEPT at the exact scope below.** Parent: F020.

No mathematical repair is required. The producer's ordinary-residual construction and its pending independent-review stage are complete. The separate b29 all-A overlap problem remains open in this packet.

## Accepted theorem

Let k be any characteristic-zero field, and let q in k have primitive odd multiplicative order d>29. With Gaussian coefficients understood as integral polynomials before specialization, put

H_29(z;q) = sum_(j=0)^29 [29 choose j]_q z^j = (z+1)U(z;q),

and let P(t;q) be the unique monic degree-14 polynomial satisfying U(z;q)=z^14 P(z+z^(-1);q). Then P(2;q), P(-2;q), and Disc_t P(t;q) are all nonzero. Consequently U is squarefree over an algebraic closure of k.

This acceptance covers every odd d>29, including composite d, with no finite order cutoff or analytic large-order dependency. It does not establish b29 all-A overlap simplicity, arbitrary b, positive-characteristic squarefreeness, historical priority, a new canonical discovery, or a runtime or conditioning conclusion.

## Frozen inputs and independence

The accepted producer report is next_cycle_b29/REPORT.md, SHA-256:

413e8dea0b652b5e6f19a1a5a473453b0f7de849a942fc312cb42eaa9d188563

The accepted complete certificate is next_cycle_b29/residual_certificate.json, SHA-256:

9c0d12c0500e7b93648aed3282326acbd3ee5f8b2e5c95d4d9e8ea953b952ca7

All ten source bindings and all eleven producer-file manifest entries match their recorded byte counts and hashes. SOURCE_BINDINGS.json itself is bound by the producer manifest. The review also records the manifest's own identity and the additional source texts used only for context and the next-task proposal. No frozen producer or predecessor file was changed.

The fresh independent checker imports no producer or predecessor code. The producer programs were read as text and, separately, executed only in isolated replay copies. Their outputs are comparison targets, not a source of the independent mathematical input or resultant.

The reviewer uses three different construction steps:

1. Build [29 choose j]_q over Z[q] using [29 choose j-1]_q(1-q^(30-j))/(1-q^j), checking every exact integer polynomial division. This is neither the producer's Euler-product expansion nor its author's q-Pascal checker.
2. Divide by z+1 in Z[q] and eliminate the highest remaining Laurent powers in descending order, using the binomial expansion of z^14(z+z^(-1))^j. This does not use the producer's S_j basis recurrence or its trace recurrence. The full integer trace and both integer endpoints agree with the saved author checks, not just their reductions.
3. Compute Res_y(A,B) as the determinant of multiplication by B in the rank-seven algebra F_2[q,y]/(A). Because A is monic, its ordered basis is 1,y,...,y^6 and the determinant equals the resultant without any division by the leading coefficient of B. The resulting 7-by-7 matrix is distinct from both the producer's 13-by-13 Sylvester matrix and its author's 26-by-26 direct discriminant matrix. The reviewer sums all 7!=5040 Leibniz terms, sharing only partial products; no Sylvester or Bareiss routine is used in this independent resultant.

Every reviewer coefficient multiplication uses integer Kronecker substitution with 16-bit lanes and reduction of each convolution coefficient modulo two. The program enforces the no-carry bound min(input lengths)<65536. This differs from both producer Karatsuba carryless multiplication and author single-bit convolution. A separate exhaustive set-convolution control checks all 1024 pairs of five-bit polynomials.

## Algebraic guards

### Integral trace and endpoints

Gaussian symmetry makes H reciprocal and monic of odd degree 29. Its factor U is monic reciprocal of degree 28, with constant term one. Descending elimination gives the unique integral monic degree-14 trace. Integer reconstruction verifies

H_29(1)=2P(2), and H'_29(-1)=P(-2).

The second sign is positive for m=14. The endpoint factor two is essential: H_29(1) reduces to zero in characteristic two while P(2) does not. Both P(2) and P(-2) reduce to P(0), which is the endpoint used in F.

### Nonmonic B and characteristic-two discriminants

After reduction write p(t)=A(t^2)+tB(t^2), with A monic of degree seven, B of degree six, and

c=lc(B)=q+q^2+...+q^28, recorded exactly as 0x1ffffffe.

Over F_2(q), p'=B(t^2). If gamma_1,...,gamma_6 are B's roots with multiplicity, the resultant product formula gives

Res_t(p,p')=c^14 product_i A(gamma_i)^2,

while Res_y(B,A)=c^7 product_i A(gamma_i). Signs disappear in characteristic two. As p is monic, Disc_t p=Res_t(p,p')=Res_y(A,B)^2. Thus the full factor c^14 is present. Dividing B by c without compensating its resultant would be incorrect.

The review's quotient-algebra norm never normalizes B and never inverts c. The identity is polynomial in the coefficients, so it survives repeated B roots, specialization of q, and drops in B's degree. A remains monic. The controls exercise a nonmonic constant B, a nonmonic linear B, scaling B with the full degree power, degree loss at q=0, zero B, a common A/B factor, and an actual alteration of the b29 leading coefficient to one. The latter changes the independently computed norm.

### Exact computed certificate

The independent coefficients give:

- deg P(0)=210, with q-adic valuation zero
- deg R=1820, with valuation seven
- F=P(0)R^2 of degree 3850, with valuation fourteen
- F*=q^3850 F(1/q) of degree 3836
- G=gcd(F,F*) of degree 1802, with constant coefficient one
- L=product_(j=1,3,...,29)(q^j-1) of degree 225
- All 38 supplied gcd/division strips are exact and end at one

The supplied full Bezout coefficients satisfy sF+tF*=G coefficientwise. The redundant complete factorization is independently reconstructed as

G=Phi_1^566 Phi_3^170 Phi_5^48 Phi_7^56 Phi_9^17 Phi_11^11 Phi_13^13 in F_2[q].

The factors here are reduced cyclotomic polynomials, not assertions of irreducibility. The reviewer constructs each from q^n-1, checks it divides q^n-1, and checks coprimality with q^e-1 at every proper divisor e of n. Multiplying the full powers reproduces every coefficient of G. Their degree sum is 1802. Thus its exact root-order set is {1,3,5,7,9,11,13}, and in particular contains no order above 29.

The proof only needs the full stripping argument, so it does not depend on an unverified irreducibility table or numerical root orders. An order-31 factor and a composite order-33 factor both survive L, demonstrating that the filter is not simply forcing every input to disappear. The insufficient replacement L=q^29-1 leaves factors of this G unaccounted for.

### Primitive-root transfer and reversal degree

Define C_+=P(2)Disc(P) and C_-=P(-2)Disc(P) in Z[q]. Both reduce to the same nonzero F. If either vanished at a characteristic-zero primitive d-th root, the irreducible polynomial Phi_d would divide it in Q[q]. Since Phi_d is monic, the quotient is integral and reduction makes bar(Phi_d) divide F.

For d>1 this reduced cyclotomic polynomial is monic, reciprocal, and has constant coefficient one. Write F=bar(Phi_d)Q. Using N=deg F, reversal gives

F*=bar(Phi_d) q^(N-deg Phi_d) Q(1/q).

The second factor is a polynomial of degree at most deg Q, even when Q has a factor q. This argument uses the actual degree after reduction; a larger characteristic-zero degree does not enter. Hence bar(Phi_d) divides G.

For odd d, q^d-1 is separable over F_2 because its derivative q^(d-1) is coprime to it. Its reduced cyclotomic factorization has no overlapping roots. Induction over divisors implies that every root of bar(Phi_d) has exact order d. This contradicts the verified low-order support of G whenever d>29. The odd-order hypothesis is indispensable to this argument: for example bar(Phi_62)=bar(Phi_31), and q^62-1 is a square in characteristic two; the reviewer explicitly checks this control.

The map Q(zeta_d) -> k taking zeta_d to q is injective for any characteristic-zero field in the theorem. No embedding of all of k into C is needed. Both C values are nonzero, so each endpoint and Disc(P) is nonzero separately.

Finally, factoring P as product_i(t-t_i) gives U=product_i(z^2-t_i z+1). Each quadratic discriminant is t_i^2-4 and each cross-resultant is (t_i-t_j)^2. Therefore the polynomial identity

Disc_z U=P(2)P(-2)(Disc_t P)^2

proves the stated ordinary residual squarefreeness. It is valid also at exceptional configurations by polynomial identity.

## Replay and adversarial controls

The final independent run passes 5321 exact assertions. The count includes individual exact-division and arithmetic sanity checks; it is an execution count, not a measure of theorem strength.

The cold replay copies the producer packet and the fresh reviewer script to a temporary directory. Each script runs under Python -I. It reproduces the producer certificate, producer check output, complete factorization, and the producer's seven-mutation receipt byte for byte. The independent result is also byte identical:

f8a31452309e3dea7ce2225b0f03c8d1d7fcc9aaf2824668b78613d0574ee0e4

Thirteen independently selected corruptions are rejected with assertion diagnostics: changed resultant, changed Bezout coefficient, missing final strip, consistently falsified monic-B coefficient and metadata, jointly padded degree and reversal, changed Gaussian input, changed Euler payload, changed trace, false survivor, changed discriminant, altered recorded Sylvester entry, lost factor multiplicity, and falsely relabeled primitive order. The last two target the separate factorization file. These supplement, rather than replace, the genuine repeated-root and separable-polynomial controls.

Run in this review folder:

python -I verify_sources.py
python -I independent_checker.py
python -I replay_and_mutations.py

The replay runner executes all producer programs only in temporary copies. No external write is performed. Detailed output is retained in independent_results.json, replay_receipt.json, and source_verification.json. The code and all deliverables are bound by FILE_MANIFEST.json.

## Remaining work and ranking

The b29 ordinary-residual construction and independent review are accepted completed stages, each subject to the completed-stage priority cap 15. Frozen F020=67, the prior construction score 65, and the former pending-review score 73 remain historical values and are not silently overwritten.

A separate proposed task is to construct the b29 all-A overlap certificates in the remaining middle range. The original parameter must stay tau=dW/H'_29(-1), with W=(q;q)_29/(q^2;q^2)_((d+29)/2), and the overlap polynomial is x He_A-A tau He_(A-1), of degree A+1. The accepted general lower and tail statements, as documented and rechecked in the b27 independent review, specialize to odd d=31,...,59 and odd d>=225. The still-uncertified middle has exactly 82 odd orders d=61,63,...,223.

Provisional next-action priority: **60/100**, using rubric v1.1 dimensions (information gain, tractability, novelty opportunity, scope/impact, evidence readiness)=(4,3,1,3,4), weighted average 3.00. It measures the value of this proposed task, not correctness or expected success. The lower tractability score reflects that no b29 middle-order witness or finite-A exceptional bridge has been computed here. The inherited annulus/specialization machinery supplies a precise contract, but b27 data must not be reused as b29 data.

The gate should deliver verified all-A exclusions for those middle orders, with explicit finite-A bridges wherever a weaker strict annulus bound leaves exceptions, or stop with the exact unresolved orders and A ranges. It must not extrapolate a finite A scan or treat a failed sufficient bound as a multiple-root counterexample. No b29 overlap computation, higher-b expansion, or prime search was conducted in this review. NEXT_STEP_RANKING.json records this proposal separately.

## Provenance boundary

The mathematical certificate is self-contained after the integral Gaussian definition and standard resultant/cyclotomic facts checked above. The accepted b27 packet and the pinned local publication derivative were inspected for conventions; this review does not replay their nested historical archives, verify the remote repository commit, or establish historical priority. The next-task proposal inherits only the stated accepted general overlap ranges. It adds no theorem claim to the accepted ordinary-residual result.
