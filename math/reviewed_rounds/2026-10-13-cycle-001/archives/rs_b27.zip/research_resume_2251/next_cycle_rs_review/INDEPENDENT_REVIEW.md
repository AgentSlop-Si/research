# Independent review: b=27 ordinary Rogers–Szegő residual

**Decision: ACCEPT, 12 October 2026.** The exact certificate proves the theorem below for every odd order d>27, with no finite-order cutoff. This decision is independent of the author's determinant algorithms and does not concern historical priority, general b, or a new Fourier algorithm.

## Exact accepted theorem

Let k be any characteristic-zero field, let q in k have primitive odd multiplicative order d>27, and write

H_27(z;q) = sum_{j=0}^{27} [27 choose j]_q z^j = (z+1) U(z;q).

Then U is squarefree over an algebraic closure of k. More precisely, for the uniquely defined monic degree-13 trace polynomial P satisfying U(z;q)=z^13 P(z+z^(-1);q), both P(2;q) and P(-2;q) and the ordinary discriminant Disc_t P are nonzero.

This closes the separate b27 residual-squarefreeness obligation. The all-A overlap theorem is separate existing work. Combining this accepted residual theorem with the separately accepted b27 overlap and the already proved root-product/non-overlap guards closes the corresponding b27 local-discriminant simplicity guards. General b and every broader extrapolation remain separate.

## Independent construction and computation

The review script imports or executes neither author program. It reconstructs all integer Gaussian coefficients using exact product-quotient steps

[27 choose j]_q = [27 choose j-1]_q (1-q^(28-j))/(1-q^j),

where every division is checked in Z[q]. It divides H_27 by z+1 in Z[q], verifies the exact remainder and reciprocal coefficient symmetry, and obtains P by descending Laurent elimination using the integer binomial expansion of z^13(z+z^(-1))^j. This is distinct from the author's finite Euler expansion and reciprocal Chebyshev trace basis; it is also distinct from the author's auxiliary q-Pascal checker.

Reducing P modulo 2 gives p(t)=A(t^2)+tB(t^2), with deg A=deg B=6 and B monic. The review computes Res_y(A,B) by polynomial Euclidean division over the rational-function field F_2(q), cancelling numerator/denominator gcds at every operation. This uses neither the author's 12-by-12 subset determinant nor its auxiliary Bareiss Sylvester determinants. Each Euclidean remainder degree and coefficient numerator/denominator degree is recorded. The final rational-function denominator equals one.

The identity Disc_t p=Res_y(A,B)^2 follows because p'=B(t^2). At a root y of B, A(y)+tB(y)=A(y), and each root of B(t^2) occurs twice over an algebraic closure; the monic odd-degree normalization introduces no omitted leading coefficient. This is a polynomial identity, so specializations and repeated roots are included.

The independent computation gives:

- deg Res_y(A,B) = 1456
- F = P(0;q) Res_y(A,B)^2 has degree 3094 and q-adic valuation 13
- F* uses the actual degree 3094, not a pre-reduction padded degree
- G = gcd(F,F*) has degree 1483
- The supplied Bezout identity sF+tF*=G holds coefficientwise
- With L = product over odd j=1,3,...,27 of (q^j-1), all 37 recorded gcd/division strips reconstruct exactly, terminating at 1

A second exact check multiplies the complete factor profile

G = Phi_1^505 Phi_3^170 Phi_5^48 Phi_7^13 Phi_9^17 Phi_11^11 Phi_13^13 in F_2[q].

These are reduced cyclotomic polynomials, not a claim that every displayed Phi is irreducible over F_2. Their multiplicities account for all degree 1483. Thus every root of G has odd multiplicative order in {1,3,5,7,9,11,13}. The weaker order-at-most-27 statement needed by the certificate also follows directly from the 37 stripping steps, without factorization.

## Characteristic-two certificate implies the characteristic-zero theorem

All polynomial identities are formed in Z[q]. Put C_+(q)=P(2;q) Disc_t P and C_-(q)=P(-2;q) Disc_t P. Reduction modulo 2 sends each C_+ and C_- to the same nonzero F because 2=-2=0 in F_2.

Suppose C_+ or C_- vanished at one characteristic-zero primitive d-th root, for odd d>27. The minimal polynomial Phi_d would divide that integer polynomial in Q[q], and monicity gives division in Z[q]. After reduction, the monic nonzero reduced Phi_d divides F. For d>1 it has constant term one and is reciprocal. Writing F=Phi_d Q and reversing with the actual degree shows that Phi_d also divides F*, even if the degree of the original integer C dropped modulo 2 or Q has a factor q. Hence reduced Phi_d divides G.

For odd d, q^d-1 is separable over F_2. Reducing its integer cyclotomic factorization and inducting over divisors shows that every root of reduced Phi_d has exact order d; different divisor orders cannot overlap in the separable product. This contradicts the complete low-order root support of G. Therefore C_+ and C_- are nonzero at every primitive odd d>27. In a field this proves that both endpoints and Disc_t P are nonzero.

If P(t)=product_i(t-t_i), then U(z)=product_i(z^2-t_i z+1). Each quadratic has discriminant t_i^2-4, while each pairwise resultant equals (t_i-t_j)^2. Therefore, identically over Z[q],

Disc_z U = P(2) P(-2) (Disc_t P)^2.

The three established nonvanishing factors prove the theorem. The argument in Q(zeta_d) transfers to every characteristic-zero field containing a primitive d-th root by the injective map Q(zeta_d) -> k. No metric argument, finite d scan, or extrapolation is involved.

### Endpoint guard and normalization

The independent integer construction verifies H_27(1)=2P(2) and P(-2)=-H'_27(-1). Reducing H_27(1) directly would erase the factor two; the checker explicitly detects this and works with P before reduction. The same modular certificate covers both endpoints directly. Consequently the accepted general derivative-nonzero theorem is an optional independent cross-check, **not a dependency** of this new residual proof.

The source rs-ordinary-squarefree.md (pinned commit 95419a2bd5d0bf6d3b78747bf163a62a7b9e4b5d; SHA256 63da5717579f66c1bdc5033c9bbc02473f31c16b724a7b1c04ecf1f2f7c6959d), sections 2, 4 and 5, was read for the normalization, modular criterion and older b<=25 boundary. The present review supplies the complete b27 certificate and independently checks the argument above, rather than extending that source's finite table by assertion.

## Controls and reproducibility

Run: python next_cycle_rs_review/independent_checker.py

The current run passes 160 checks. Controls include exact integer divisions; trace elimination; coefficientwise H,U,P agreement; independent resultant and full F/G reconstruction; Bezout equality and altered-Bezout rejection; all 37 strips; exact cyclotomic-product reconstruction; a genuine repeated-root polynomial sent through the same resultant function; a separable polynomial positive control; three altered A-coefficient resultants; a surviving order-29 factor; failure of the insufficient q^27-1-only modulus; the actual-degree reverse; and the factor-of-two endpoint erasure control.

The complete results, integer trace coefficients, rational-resultant trace, exact F/G masks, and input certificate SHA256 are in independent_results.json. The certificate file being accepted is next_cycle_rs/residual_certificate.json. All three programs can be examined separately; agreement does not rely on shared imports.

## Required status changes and retained limits

The former task “ordinary b27 residual gap for odd 27<d<2916” is complete, with the stronger accepted domain all odd d>27. Do not leave that exact task as the active next gate in F020 or NEXT-RS-RESIDUAL-B27. Record this scoped closure and choose a genuinely new, separately specified gate if further work is desired. Do not revise frozen triage scores merely because this proof closed.

No general bound for the roots of G_m is established. In particular the known m=12/order17 counterexample to the stronger order<=m heuristic remains valid. No general-b squarefreeness theorem, historical-priority clearance, novelty count increase, or runtime claim follows.
