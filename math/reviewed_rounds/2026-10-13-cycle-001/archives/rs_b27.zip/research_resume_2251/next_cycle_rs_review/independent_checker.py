#!/usr/bin/env python3
"""Independent b=27 review: integer product quotients and rational-function Euclid.
Never imports or executes the author's builder/checker. Standard library only.
"""
from pathlib import Path
import json, hashlib, time
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
checks=[]
def ck(name,condition):
    if not condition: raise AssertionError(name)
    checks.append(name)
def it(a):
    while len(a)>1 and not a[-1]:a.pop()
    return a
def ia(a,b,sgn=1):
    c=a+[0]*max(0,len(b)-len(a))
    for j,v in enumerate(b):c[j]+=sgn*v
    return it(c)
def ishift(a,n):return [0]*n+a

def quotient_one_minus(a,k):
    # Solve (1-q^k) b=a from lowest to highest degree, then verify tail.
    b=a[:]
    for j in range(k,len(b)):b[j]+=b[j-k]
    ck('integer Gaussian exact quotient by 1-q^%d'%k,not any(b[max(0,len(a)-k):]))
    return it(b[:max(1,len(a)-k)])
def gaussian_product_row(n):
    a=[1];h=[a]
    for k in range(1,n+1):
        a=quotient_one_minus(ia(a,ishift(a,n-k+1),-1),k)
        h.append(a)
    ck('Gaussian product symmetry',h==h[::-1])
    return h

def p2(a):return sum((v%2)<<j for j,v in enumerate(a))
def mul(a,b):
    # Classic shift/XOR convolution, independent of author Karatsuba.
    out=0
    while b:
        if b&1:out^=a
        a<<=1;b>>=1
    return out

def div(a,b):
    if b==0:raise ZeroDivisionError
    q=0
    while a.bit_length()>=b.bit_length():
        k=a.bit_length()-b.bit_length();q^=1<<k;a^=b<<k
    return q,a

def gcd(a,b):
    while b:a,b=b,div(a,b)[1]
    return a

def power(a,n):
    r=1
    while n:
        if n&1:r=mul(r,a)
        a=mul(a,a);n//=2
    return r

class Rat:
    def __init__(self,a=0,b=1):
        if not b:raise ZeroDivisionError
        g=gcd(a,b); self.a=div(a,g)[0];self.b=div(b,g)[0]
    def __bool__(self):return bool(self.a)
    def __add__(x,y):return Rat(mul(x.a,y.b)^mul(y.a,x.b),mul(x.b,y.b))
    def __mul__(x,y):
        g=gcd(x.a,y.b);h=gcd(y.a,x.b)
        return Rat(mul(div(x.a,g)[0],div(y.a,h)[0]),mul(div(x.b,h)[0],div(y.b,g)[0]))
    def __truediv__(x,y):return x*Rat(y.b,y.a)
    def __pow__(x,n):return Rat(power(x.a,n),power(x.b,n))

def tr(p):
    while p and not p[-1]:p.pop()
    return p

def rem(a,b):
    a=a[:]
    while a and len(a)>=len(b):
        shift=len(a)-len(b);c=a[-1]/b[-1]
        for j,v in enumerate(b):a[j+shift]=a[j+shift]+c*v
        tr(a)
    return a

def rational_resultant(aa,bb):
    a=tr([Rat(v) for v in aa]);b=tr([Rat(v) for v in bb]);out=Rat(1);steps=[]
    while len(b)>1:
        m,n=len(a)-1,len(b)-1
        r=rem(a,b)
        if not r:return 0,steps
        k=len(r)-1
        out=out*b[-1]**(m-k)
        steps.append({'dividend_degree':m,'divisor_degree':n,'remainder_degree':k,
                      'remainder_coefficient_q_degrees':[[x.a.bit_length()-1,x.b.bit_length()-1] for x in r]})
        a,b=b,r
    if not b:return 0,steps
    out=out*b[0]**(len(a)-1)
    ck('rational Euclidean resultant denominator is one',out.b==1)
    return out.a,steps

def trace_integer(h,m):
    # Descending symmetric-Laurent elimination.  Coefficients of t^k are
    # recovered against z^m (z+1/z)^k, with binomial coefficients.
    from math import comb
    u=[];prev=[0]
    for c in h[:-1]:prev=ia(c,prev,-1);u.append(prev)
    ck('exact integer (z+1) division',u[-1]==h[-1])
    ck('integer residual reciprocity',u==u[::-1])
    residual=[v[:] for v in u];p=[[0] for _ in range(m+1)]
    for k in range(m,-1,-1):
        p[k]=residual[m+k][:]
        for j in range(k+1):
            row=m+k-2*j
            residual[row]=ia(residual[row],[comb(k,j)*v for v in p[k]],-1)
    ck('Laurent binomial elimination exact',all(v==[0] for v in residual))
    return u,p

def endpoint(p,t):
    v=[0]
    for j,c in enumerate(p):v=ia(v,[t**j*x for x in c])
    return v

def check_certificate(c,p,rr):
    ck('b=27 m=13',c['b']==27 and c['m']==13)
    ck('integer trace matches author F2 trace',[p2(v) for v in p]==[int(v,16) for v in c['P_coefficients_hex']])
    ck('independent rational resultant matches author',rr==int(c['resultant_hex'],16))
    f=mul(p2(p[0]),mul(rr,rr));rev=int(bin(f)[2:][::-1],2);g=gcd(f,rev)
    ck('F reconstruction',f==int(c['F_hex'],16))
    ck('F degree3094',f.bit_length()-1==3094==c['F_degree'])
    ck('actual-degree reverse',rev==int(c['reverse_F_hex'],16))
    ck('G reconstruction',g==int(c['G_hex'],16))
    ck('G degree1483',g.bit_length()-1==1483==c['G_degree'])
    ck('Bezout equality',mul(f,int(c['bezout_s_hex'],16))^mul(rev,int(c['bezout_t_hex'],16))==g)
    ck('Bezout mutation caught',mul(f,int(c['bezout_s_hex'],16)^1)^mul(rev,int(c['bezout_t_hex'],16))!=g)
    low=1
    for k in range(1,28,2):low=mul(low,(1<<k)^1)
    ck('L reconstruction',low==int(c['L_hex'],16))
    cur=g;steps=[]
    while cur!=1:
        h=gcd(cur,low)
        ck('nontrivial strip '+str(len(steps)),h!=1)
        old=cur;cur,r=div(cur,h);ck('strip exact '+str(len(steps)),r==0)
        steps.append({'input_degree':old.bit_length()-1,'factor_hex':hex(h),'factor_degree':h.bit_length()-1,'quotient_degree':cur.bit_length()-1})
    ck('all37 strip rows identical',steps==c['stripping_steps'] and len(steps)==37)
    ck('survivor1',c['survivor_hex']=='0x1' and c['survivor_degree']==0)
    # Independent multiplication of the claimed entire cyclotomic profile.
    phis={}
    for n in range(1,28,2):
        v=(1<<n)^1
        for d in phis:
            if n%d==0:v,r=div(v,phis[d]);ck('cyclotomic construction '+str((n,d)),r==0)
        phis[n]=v
    profile={1:505,3:170,5:48,7:13,9:17,11:11,13:13};reconstruction=1
    for n,m in profile.items():reconstruction=mul(reconstruction,power(phis[n],m))
    ck('complete factorization into cyclotomic powers',reconstruction==g)
    ck('order29 factor is not stripped',gcd(sum(1<<j for j in range(29)),low)==1)
    ck('using only q27-1 misses known factors',gcd(g,(1<<27)^1)!=g)
    ck('q=0 is not a G root',g&1==1)
    ck('padding reverse erroneously adds q',rev!=(rev<<1))
    return {'F_hex':hex(f),'G_hex':hex(g),'F_degree':f.bit_length()-1,'G_degree':g.bit_length()-1,
            'R_degree':rr.bit_length()-1,'F_valuation':(f&-f).bit_length()-1,'strips':len(steps),'root_order_multiplicities':profile}

def main():
    start=time.monotonic();c=json.loads((BASE/'next_cycle_rs/residual_certificate.json').read_text())
    h=gaussian_product_row(27);u,p=trace_integer(h,13)
    ck('H coefficientwise agreement',[p2(v) for v in h]==[int(x,16) for x in c['H_coefficients_hex']])
    ck('U coefficientwise agreement',[p2(v) for v in u]==[int(x,16) for x in c['U_coefficients_hex']])
    plus=endpoint(p,2);minus=endpoint(p,-2);sumh=[0];dh=[0]
    for j,v in enumerate(h):
        sumh=ia(sumh,v)
        if j:dh=ia(dh,[j*(-1)**(j-1)*x for x in v])
    ck('H27(1)=2P13(2)',sumh==[2*x for x in plus])
    ck('P13(-2)=-H27prime(-1)',minus==[-x for x in dh])
    ck('both endpoint reductions equal P0',p2(plus)==p2(minus)==p2(p[0]))
    ck('erasing factor two would lose endpoint',p2(sumh)==0 and p2(plus)!=0)
    pp=[p2(v) for v in p]
    rr,steps=rational_resultant(pp[::2],pp[1::2])
    results=check_certificate(c,p,rr)
    # This genuine repeated-root control goes through the SAME resultant code.
    dr,_=rational_resultant([1,0,1],[0])
    ck('repeated polynomial resultant zero',dr==0)
    sr,_=rational_resultant([1,1,1],[1])
    ck('separable polynomial resultant nonzero',sr==1)
    for j in (0,1,6):
        a=pp[::2][:];a[j]^=1;bad,_=rational_resultant(a,pp[1::2])
        ck('mutated A coefficient rejected '+str(j),bad!=rr)
    result={'verdict':'PASS','scope':'b=27 ordinary residual, every primitive odd d>27, characteristic zero',
            'method':'Integer Gaussian product quotients; descending Laurent/binomial trace; Euclidean resultant over F2(q), with rational cancellation at every step.',
            'certificate_sha256':hashlib.sha256((BASE/'next_cycle_rs/residual_certificate.json').read_bytes()).hexdigest(),
            'check_count':len(checks),'checks':checks,'exact_polynomial_summary':results,'rational_resultant_steps':steps,
            'both_endpoint_factors_directly_covered':True,
            'integer_trace_coefficients':p,'elapsed_seconds':round(time.monotonic()-start,6)}
    (ROOT/'independent_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['verdict','check_count','exact_polynomial_summary','elapsed_seconds']},indent=2))
if __name__=='__main__':main()
