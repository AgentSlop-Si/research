#!/usr/bin/env python3
"""Orthogonal local tests. Does not import or execute the certificate builder."""
import json, hashlib, tempfile, shutil, subprocess, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
C=json.loads((BASE/'residual_certificate.json').read_text())
checks=[]
def require(name,cond):
    assert cond,name
    checks.append(name)
def fmul(a,b):
    # Direct carryless convolution, deliberately not the builder's Karatsuba.
    z=0
    while a:
        if a&1:z^=b
        a>>=1;b<<=1
    return z
def fdiv(a,b):
    if not b:raise ZeroDivisionError
    c=0
    while a.bit_length()>=b.bit_length():
        shift=a.bit_length()-b.bit_length();c^=1<<shift;a^=b<<shift
    return c,a
def fgcd(a,b):
    while b:a,b=b,fdiv(a,b)[1]
    return a
def sdet(coeff1,coeff2):
    a=coeff1[::-1];b=coeff2[::-1];m=len(a)-1;n=len(b)-1;N=m+n
    M=[[0]*i+a+[0]*(n-1-i) for i in range(n)]+[[0]*i+b+[0]*(m-1-i) for i in range(m)]
    previous=1;divisions=0;pivots=[]
    for k in range(N-1):
        if not M[k][k]:
            j=next((j for j in range(k+1,N) if M[j][k]),None)
            if j is None:return 0,{'dimension':N,'exact_divisions':divisions,'pivots':pivots}
            M[k],M[j]=M[j],M[k]
        pivot=M[k][k];pivots.append(pivot.bit_length()-1)
        for i in range(k+1,N):
            for j in range(k+1,N):
                numerator=fmul(pivot,M[i][j])^fmul(M[i][k],M[k][j])
                quotient,remainder=fdiv(numerator,previous);require('Bareiss exact division %d'%divisions,remainder==0)
                M[i][j]=quotient;divisions+=1
            M[i][k]=0
        previous=pivot
    return M[-1][-1],{'dimension':N,'exact_divisions':divisions,'pivot_degrees':pivots}
def trim(p):
    while len(p)>1 and p[-1]==0:p.pop()
    return p
def iadd(a,b,sign=1,shift=0):
    c=a+[0]*max(0,len(b)+shift-len(a))
    for j,v in enumerate(b):c[j+shift]+=sign*v
    return trim(c)
def imul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,v in enumerate(a):
        for j,w in enumerate(b):c[i+j]+=v*w
    return trim(c)
def parity(a):return sum((v&1)<<j for j,v in enumerate(a))
def gaussian_row(n):
    row=[[1]]
    for r in range(1,n+1):
        row=[iadd(row[k] if k<r else [0],row[k-1] if k else [0],shift=r-k) for k in range(r+1)]
    return row
def integer_trace(H,m):
    U=[];last=[0]
    for h in H[:-1]:last=iadd(h,last,-1);U.append(last)
    require('integer z+1 division',last==H[-1])
    S=[[2],[0,1]]
    for j in range(2,m+1):S.append(iadd([0]+S[-1],S[-2],-1))
    P=[[0] for _ in range(m+1)];P[0]=U[m]
    for k in range(1,m+1):
        for j,v in enumerate(S[k]):
            if v:P[j]=iadd(P[j],[v*x for x in U[m+k]])
    return U,P

def main():
    P=[int(v,16) for v in C['P_coefficients_hex']]
    H=gaussian_row(27);U,IP=integer_trace(H,13)
    require('integer Gaussian coefficients reduce to Euler input',[parity(h) for h in H]==[int(v,16) for v in C['H_coefficients_hex']])
    require('integer trace coefficients reduce to claimed P',[parity(p) for p in IP]==P)
    plus=[0];minus=[0];hsum=[0];derivative=[0]
    for j,v in enumerate(IP):
        plus=iadd(plus,[x*2**j for x in v]);minus=iadd(minus,[x*(-2)**j for x in v])
    for j,h in enumerate(H):
        hsum=iadd(hsum,h)
        if j:derivative=iadd(derivative,[j*(-1)**(j-1)*x for x in h])
    require('integer H27(1)=2P13(2)',hsum==[2*x for x in plus])
    require('integer P13(-2)=-H27prime(-1)',minus==[-x for x in derivative])
    require('endpoint reduction P13(2)=P13(0) mod2',parity(plus)==P[0])
    require('negative endpoint has same mod2 reduction',parity(minus)==P[0])
    R,splitstats=sdet(P[::2],P[1::2]);require('Bareiss vs subset resultant',R==int(C['resultant_hex'],16))
    derivative_mod2=[P[j] if j&1 else 0 for j in range(1,len(P))]
    D,directstats=sdet(P,derivative_mod2)
    require('direct degree13 discriminant vs split identity',D==fmul(R,R)==int(C['discriminant_hex'],16))
    F=fmul(P[0],D);Rvs=int(format(F,'b')[::-1],2)
    require('F reconstruction',F==int(C['F_hex'],16))
    require('actual-degree reverse',Rvs==int(C['reverse_F_hex'],16))
    G=fgcd(F,Rvs);require('gcd reconstruction',G==int(C['G_hex'],16))
    require('Bezout identity',fmul(F,int(C['bezout_s_hex'],16))^fmul(Rvs,int(C['bezout_t_hex'],16))==G)
    L=1
    for j in range(1,28,2):L=fmul(L,(1<<j)^1)
    require('low-order L reconstruction',L==int(C['L_hex'],16))
    cur=G
    for i,s in enumerate(C['stripping_steps']):
        f=fgcd(cur,L);require('stripping gcd '+str(i),f==int(s['factor_hex'],16) and f>1)
        cur,rem=fdiv(cur,f);require('stripping exact division '+str(i),rem==0)
    require('all roots stripped',cur==1)
    # A factor-by-factor exact multiplicity decomposition, without irreducible factorization.
    remaining=G;cyclotomics={};profiles=[]
    for n in range(1,28,2):
        f=(1<<n)^1
        for d in range(1,n,2):
            if n%d==0:f,rem=fdiv(f,cyclotomics[d]);require('cyclotomic exact division '+str(n)+'/'+str(d),rem==0)
        cyclotomics[n]=f;part=1;layers=[]
        while True:
            g=fgcd(remaining,f)
            if g==1:break
            remaining,rem=fdiv(remaining,g);require('order-profile exact division '+str(n)+'/'+str(len(layers)),rem==0)
            part=fmul(part,g);layers.append({'factor_hex':hex(g),'factor_degree':g.bit_length()-1})
        if layers:profiles.append({'root_order':n,'total_degree':part.bit_length()-1,'layers':layers,'component_hex':hex(part)})
    require('root-order decomposition reconstructs G',remaining==1)
    concise=[];product=1
    for profile in profiles:
        factors={v['factor_hex'] for v in profile['layers']}
        require('uniform cyclotomic multiplicity '+str(profile['root_order']),len(factors)==1)
        factor=int(next(iter(factors)),16);multiplicity=len(profile['layers'])
        require('complete cyclotomic factor '+str(profile['root_order']),factor==cyclotomics[profile['root_order']])
        concise.append({'cyclotomic_order':profile['root_order'],'polynomial_hex':hex(factor),'multiplicity':multiplicity})
        for _ in range(multiplicity):product=fmul(product,factor)
    require('complete cyclotomic factorization equals G',product==G)
    (BASE/'G_factorization.json').write_text(json.dumps({'G_degree':G.bit_length()-1,'G_hex':hex(G),'factorization':concise,'product_checked':product==G},indent=2)+'\n')
    controls={
       'mutated_Bezout_rejected': fmul(F,int(C['bezout_s_hex'],16)^1)^fmul(Rvs,int(C['bezout_t_hex'],16))!=G,
       'mutated_resultant_rejected': (R^1)!=int(C['resultant_hex'],16),
       'wrong_modulus_q_to_27_only_rejected':fgcd(G,(1<<27)^1)!=G,
       'out_of_domain_order29_factor_survives':fgcd(sum(1<<j for j in range(29)),L)==1,
       'repeated_polynomial_detected':fgcd(0b101,0)==0b101,
       'actual_degree_reverse_differs_from_padding':Rvs!=(Rvs<<1),
       'endpoint_erasure_control':parity(hsum)==0 and parity(plus)!=0,
    }
    for k,v in controls.items():require(k,v)
    results={'verdict':'PASS','check_count':len(checks),'checks':checks,'source_certificate_sha256':hashlib.sha256((BASE/'residual_certificate.json').read_bytes()).hexdigest(),'construction':'independent integer q-Pascal and reciprocal trace; fraction-free Bareiss on split and full Sylvester matrices; direct carryless arithmetic',
             'split_resultant':splitstats,'direct_discriminant':directstats,'exact_root_orders':[p['root_order'] for p in profiles],'root_order_profile':profiles,'negative_controls':controls,
             'integer_P_coefficients':IP,'P_plus2_integer_coefficients':plus,'P_minus2_integer_coefficients':minus}
    (BASE/'residual_checks.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:results[k] for k in ['verdict','check_count','exact_root_orders','negative_controls']},indent=2))
if __name__=='__main__':main()
