#!/usr/bin/env python3
"""Cold byte replay and deliberate certificate-corruption controls."""
from pathlib import Path
import copy, hashlib, json, shutil, subprocess, sys, tempfile
HERE=Path(__file__).resolve().parent
SCRIPTS=['build_residual_certificate.py','check_residual_certificate.py']
OUTPUTS=['residual_certificate.json','residual_checks.json','G_factorization.json']
receipt={'cold_replay':{},'mutation_tests':[],'all_passed':False}
with tempfile.TemporaryDirectory(prefix='rs27-cold-') as folder:
    dest=Path(folder)
    for f in SCRIPTS:shutil.copyfile(HERE/f,dest/f)
    for f in SCRIPTS:
        proc=subprocess.run([sys.executable,'-I',str(dest/f)],capture_output=True,text=True,timeout=60)
        assert proc.returncode==0,(f,proc.stderr)
    for f in OUTPUTS:
        got=(dest/f).read_bytes();expected=(HERE/f).read_bytes()
        assert got==expected,f
        receipt['cold_replay'][f]={'byte_identical':True,'sha256':hashlib.sha256(got).hexdigest()}
    orig=json.loads((dest/'residual_certificate.json').read_text())
    changes=[
       ('resultant_one_bit',lambda x:x.update(resultant_hex=hex(int(x['resultant_hex'],16)^1))),
       ('Bezout_one_bit',lambda x:x.update(bezout_s_hex=hex(int(x['bezout_s_hex'],16)^1))),
       ('missing_last_strip',lambda x:x['stripping_steps'].pop()),
       ('nonmonic_trace_polynomial',lambda x:x['P_coefficients_hex'].__setitem__(-1,'0x3')),
    ]
    for name,mutate in changes:
        data=copy.deepcopy(orig);mutate(data)
        (dest/'residual_certificate.json').write_text(json.dumps(data))
        proc=subprocess.run([sys.executable,'-I',str(dest/'check_residual_certificate.py')],capture_output=True,text=True,timeout=60)
        assert proc.returncode!=0,(name,'Corrupted input was not rejected')
        receipt['mutation_tests'].append({'name':name,'rejected':True,'diagnostic':proc.stderr.strip().splitlines()[-1]})
receipt['all_passed']=True
(HERE/'cold_replay_and_mutation_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
