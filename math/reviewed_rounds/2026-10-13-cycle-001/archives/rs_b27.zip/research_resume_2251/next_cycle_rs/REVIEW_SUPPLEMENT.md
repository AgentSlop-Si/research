# Explicit report revision: both endpoints from one modular certificate

12 October 2026 UTC, 23:31. No certificate coefficient or finite-arithmetic conclusion changed.

REPORT_INITIAL.md preserves the first producer report byte for byte. Its SHA-256 is f0e6be8c68f551d5727f3028c45c5fb18e5b90472142888bca9c36907b5b9c9f. The independent reviewer then observed that the same modular certificate also directly excludes the negative endpoint. The producer agreed mathematically and notified the reviewer before revising REPORT.md. This supplement records that change explicitly.

Let C_plus=P_13(2)Disc(P_13) and C_minus=P_13(-2)Disc(P_13). Since 2=-2=0 in characteristic 2, both reduce to the saved F_13. The characteristic-zero cyclotomic-divisibility and actual-degree reciprocal argument therefore excludes zeros of both polynomials for odd d>27. The previously inherited negative-endpoint theorem becomes an optional cross-check rather than a necessary premise.

Equivalently, Disc_z U modulo 2 equals F_13^2. If an odd cyclotomic polynomial divided the characteristic-zero discriminant, its squarefree mod-2 reduction would divide F_13, giving the same impossible root order in G_13.

The saved residual_certificate.json is unchanged: SHA-256 de3ee491c09e8eca917f12ca44096dd81877ec7d5696ddaf4244d6cdca258a44. G_factorization.json is also unchanged: fd0d2b056572e1c7084e51181ea25a226767aec234e97d3eafea1a505dfc2ef8.

One exact assertion was added to the author checker: the integer P_13(-2) reduces to P_13(0). This raises the passing count from 6,315 to 6,316. The original check JSON hash was aa541ba1a152366e418d334586b5e1ab729b7671d5ab2842730e1cbf7cfdefb3; the amended output hash is a0ae6ae5fafa2df95e084c27d708b0f50ce57ce23746fe07bd6078f93bf9f7a8. Cold byte replay and all four deliberately corrupted-certificate rejection tests were rerun successfully after this addition.

This is a proof-dependency simplification, not a theorem-scope expansion. Both report versions remain producer candidates pending the separate review decision. No frozen predecessor or external service was changed.
