# Candidate theorem: ordinary b27 Rogers–Szegő residual squarefreeness

12 October 2026 UTC. Status: fresh exact candidate with orthogonal author checks; independent acceptance is a separate decision. The previously accepted b27 overlap result is not used to prove this result.

## Result and exact scope

Let k be any characteristic-zero field, let q in k have primitive odd order d>27, and define

H_27(z;q)=sum_(j=0)^27 [27 choose j]_q z^j=(z+1)U(z;q).

The new certificate proves the candidate conclusion Disc_z U(z;q) != 0 for every such d. The finite calculation covers all odd d>27 directly, not only the remaining 1,444 odd orders 29..2915. The accepted large-order analytic theorem is therefore not needed for this new proof.

The decisive exact calculation, in F_2[q], is

G_13 = gcd(F_13,F_13*)
     = Phi_1^505 Phi_3^170 Phi_5^48 Phi_7^13 Phi_9^17 Phi_11^11 Phi_13^13,

where each Phi is reduced modulo 2. Here F_13 is the reduction of P_13(2) Disc_t P_13, and the star reverses F_13 using its actual degree. The recorded values are:

- deg P_13=13, with leading coefficient exactly 1 over Z[q] and F_2[q]
- deg P_13(0)=182
- deg Res_y(A,B)=1456, its q-adic valuation is 6
- deg F_13=3094, its q-adic valuation is 13
- deg G_13=1483, with constant coefficient 1
- complete root-order set of G_13: 1,3,5,7,9,11,13

The complete coefficient bitmasks and a Bezout identity are in residual_certificate.json. G_factorization.json gives every cyclotomic bitmask and multiplicity. No irreducibility assumption about these reduced cyclotomic polynomials is used.

This is a fixed-b extension of an accepted method. It asserts no general-b theorem, even-order or positive-characteristic result, historical novelty, complexity improvement, Fourier speedup, or numerical-conditioning statement. It also does not reprove the separate overlap theorem. If independently accepted, this ordinary guard can be joined to the separately accepted b27 overlap and inherited general guards within their stated hypotheses.

## 1. Integral normalization and the remaining factors

The Gaussian coefficients are polynomials in Z[q], recovered from the finite Euler product

product_(r=0)^26 (1+q^r z) = sum_(j=0)^27 q^(j(j-1)/2) [27 choose j]_q z^j.

After exact removal of the monomial shifts, coefficient reversal gives H_27(z)=z^27 H_27(1/z). Its odd degree implies H_27(-1)=0. Dividing by z+1 gives the monic reciprocal degree-26 polynomial U. Thus there is a unique monic degree-13 P_13 in Z[q,t] satisfying

U(z;q)=z^13 P_13(z+z^(-1);q).

The accepted recurrence is P_0=1, P_1=t+q+q^2, and for j>=2,

P_j=(t+q^(2j-1)+q^(2j))P_(j-1)
    -(1-q^(2j-1))(1-q^(2j-2))P_(j-2).

The author builder constructs the mod-2 polynomial from the finite Euler product, division by z+1, and the reciprocal trace basis; the recurrence is a separate coefficientwise control. The author checker instead constructs the integer Gaussian coefficients by q-Pascal and recovers the integer trace polynomial. It agrees coefficientwise after reduction. All polynomials P_j are monic in t, so degree is retained under q-specialization and reduction modulo 2; no leading-coefficient factor has been omitted.

The integral identity

Disc_z U=P_13(2) P_13(-2) (Disc_t P_13)^2

follows by factoring U into quadratics z^2-t_i z+1, using their discriminants t_i^2-4 and pairwise resultants (t_i-t_j)^2. This is an identity over Z[q], hence also at exceptional root configurations. The accepted derivative-nonzero theorem supplies

P_13(-2)=(-1)^13 H'_27(-1;q) != 0

for every primitive odd d>27 in characteristic zero. A direct explanation of that inherited endpoint is given below. Therefore it suffices to exclude zeros of

C_13(q)=P_13(2;q) Disc_t P_13(t;q) in Z[q].

The integer checker also verifies H_27(1)=2P_13(2) and P_13(-2)=-H'_27(-1) exactly. In particular, reducing H_27(1) itself modulo 2 would erase information; this proof does not do so.

## 2. The bounded characteristic-2 determinant

Write the reduction of P_13 as A(t^2)+tB(t^2). Both A and B have degree 6 in y, and B is monic. In characteristic 2 the t-derivative is B(t^2). The polynomial identity

Disc_t P_13 = Res_y(A,B)^2

holds here without an additional leading factor. Indeed, B is monic; at a root gamma of B, P_13(t)=A(gamma) whenever t^2=gamma, with the two roots counted with multiplicity. The resultant product is therefore product_gamma A(gamma)^2. The discriminant/resultant sign disappears in characteristic 2. This argument is a polynomial identity, so it also covers repeated roots and specializations that lower the degree of A.

The author builder computes R=Res_y(A,B) by a division-free Sylvester determinant on a 12-by-12 matrix. Its subset recurrence has exactly 4,096 states and executes 10,732 nonzero polynomial products. All coefficient operations are exact integer bit operations, with bit j representing the coefficient of q^j. It forms

F_13=P_13(0)R^2 != 0.

Because 2=0 modulo 2, this is exactly C_13 modulo 2. Actual-degree reversal gives F_13*=q^3094 F_13(1/q). The q-adic valuation 13 is retained: reversal is performed using degree 3094, without removing q factors or padding to a guessed characteristic-zero degree.

The gcd certificate includes full s,t in F_2[q] with sF_13+tF_13*=G_13; polynomial long division also reconstructs G_13. There is no numerical root test.

The author checker uses direct carryless convolution and fraction-free Bareiss elimination, without importing the builder. It computes both:

- the 12-by-12 Sylvester resultant R, with 506 exact-division assertions;
- the direct 25-by-25 Sylvester resultant of P_13 and its derivative, with 4,900 exact-division assertions.

Both agree with the saved split determinant and discriminant, respectively. The second computation checks the characteristic-2 split formula directly in this degree-13 instance.

## 3. Complete root-order exclusion

The primary sufficient certificate uses the exact polynomial

L(q)=product_(j odd,1<=j<=27)(q^j-1).

At each step replace the current G by G/gcd(G,L). The gcd is recomputed exactly, and every division is exact. After 37 rounds the remainder is 1. Thus every factor of G, with all multiplicities, is removed by the finite set of odd-order factors at most 27. Since q^j-1 is separable for odd j in characteristic 2, every root of L has odd order dividing some j<=27. No factor of order greater than 27 remains.

A redundant exact factorization strengthens the certificate:

- Phi_1=q+1, multiplicity 505
- Phi_3=q^2+q+1, multiplicity 170
- Phi_5=q^4+q^3+q^2+q+1, multiplicity 48
- Phi_7=q^6+q^5+q^4+q^3+q^2+q+1, multiplicity 13
- Phi_9=q^6+q^3+1, multiplicity 17
- Phi_11=sum_(j=0)^10 q^j, multiplicity 11
- Phi_13=sum_(j=0)^12 q^j, multiplicity 13

Their product is checked against all 1,484 coefficients of G. The sum of factor degrees with multiplicity is 505+340+192+78+102+110+156=1483. These identities prove that this particular G has precisely the listed root orders. They do not suggest that the bound by m=13 holds for every m; the already accepted m=12 order-17 exception remains unchanged.

## 4. Why the finite calculation proves characteristic-zero nonvanishing

Suppose C_13(q)=0 at a primitive odd order-d root with d>27 in a characteristic-zero field k. The root generates an injective copy of Q(zeta_d), so its minimal polynomial over Q is Phi_d. Hence Phi_d divides C_13 in Q[q]. Because Phi_d is monic integral, polynomial division gives a quotient in Z[q] and zero remainder. Reducing this divisibility modulo 2 gives

bar(Phi_d) divides F_13.

The reduced cyclotomic polynomial remains monic with its original degree and constant coefficient 1. It is reciprocal. If F_13=bar(Phi_d)K and N=deg F_13, then deg K=N-deg Phi_d, and

F_13*=q^N F_13(1/q)
      =bar(Phi_d)(q) q^(N-deg Phi_d) K(1/q).

The last factor is a polynomial, even if K has zero constant coefficient. Therefore bar(Phi_d) also divides F_13*, and thus divides G_13. This is why the actual reduced degree must be used and why F_13's q-adic valuation does not invalidate the argument.

For odd d, q^d-1 is separable in characteristic 2: its derivative is q^(d-1), coprime to q^d-1. Reducing the identity q^d-1=product_(e|d)Phi_e shows that its distinct cyclotomic factors share no roots. Induction over divisors then shows that every root of bar(Phi_d) has exact multiplicative order d, not merely an order dividing d. As d>27, this contradicts the complete G root-order exclusion.

Consequently C_13(q) is nonzero for every primitive odd d>27. Its two factors P_13(2) and Disc_t P_13 are nonzero in k. Combining them with the negative endpoint and the integral discriminant identity proves Disc_z U != 0.

This argument makes no claim that a modular zero would be a characteristic-zero counterexample. Its direction is solely: a characteristic-zero cyclotomic zero would force the impossible modular cyclotomic divisor. No embedding of all of k into C is needed.

## 5. Inherited negative endpoint, with hypotheses checked

Set m=13, choose the principal primitive complex embedding q=exp(2iv), v=pi/d, and use the accepted identity

H'_(2m+1)(-1;q) = product_(r=1)^m (1-q^(2r))
  times sum_(j=0)^m product_(r=1)^j (1-q^(2r-1))/(1-q^(2r)).

All exponents are positive and at most 26<d, so all product factors and denominators are nonzero. The j-th summand has the form a_j exp(-ijv), with a_j>0: the relevant sine arguments lie strictly between 0 and pi. Also 0<=jv<=13pi/d<pi/2. Each summand has positive real part, so their sum is nonzero. Hence H'_27(-1) is nonzero at this embedding. Its value is a polynomial in q over Q, so nonzero at one primitive embedding means nonzero at every primitive conjugate. The injective cyclotomic-field map gives the result in any characteristic-zero field k.

The identity and the general discriminant criterion were inherited from the accepted ordinary-squarefreeness review. This packet rechecks their hypotheses and adds a fresh integer identity check at b27; it does not claim a new replay of the historical archive chain.

## 6. Validation and reproducibility

Run, from this directory:

python build_residual_certificate.py
python check_residual_certificate.py
python replay_and_mutation_tests.py

Only the Python standard library is used. The author check reports 6,315 passing exact assertions. These include integral normalization, the two differently sized exact determinants, gcd and Bezout identities, every stripping quotient, complete cyclotomic factorization, endpoint-erasure and actual-degree controls.

A cold replay in a fresh temporary directory runs the two scripts using python -I and requires byte-identical certificate, check output and factorization files. Four separate corrupted-certificate runs must fail: one flipped resultant bit, one flipped Bezout bit, a missing final stripping step, and a nonmonic trace leading coefficient. The receipt records the observed assertion diagnostics. These are author validation and reproducibility checks; an independent reviewer remains necessary for a project acceptance upgrade.

The fixed bounded certificate succeeded. Accordingly, the 1,444-order fallback, characteristic-zero survivor calculations, prime search and higher-m expansion were not run. No frozen artifact or external service was modified.

## 7. Ranking of the proposed next step

The frozen F020 next-cycle score 67 remains unchanged. The immediate new task is: independently reconstruct and review this exact b27 ordinary-residual packet and its cyclotomic implication. Using ranking/RANKING_METHOD.md:

- Information gain: 4/5. It would close the exact remaining b27 ordinary guard if accepted.
- Tractability: 5/5. Fixed integer/matrix data, a 12-by-12 determinant and explicit Bezout/factor identities are available.
- Defensible novelty opportunity: 2/5. This extends a fixed parameter using an accepted method; no historical priority is claimed.
- Scope/impact: 4/5. It joins the independently accepted b27 overlap within the exact characteristic-zero primitive-odd domain.
- Evidence readiness: 5/5. Full coefficients, proofs, source pins, orthogonal checks and mutation receipts are available.

Weighted average is 4.00/5, giving priority 1+round(99*4/5)=80 for the independent-review task. This is a provisional work-priority score, not a probability of correctness, novelty or success. No completed-stage cap applies to the still-pending independent review; the completed author-construction stage itself should not remain an active research target.

After successful independent acceptance, a separately scoped next mathematical target could be b29 ordinary residual squarefreeness (m=14), with its own fixed determinant and fallback contract. It has not been attempted here. Retaining the original dimension vector 4,3,2,4,4 gives a provisional priority 67 for that conditional new task; b29 overlap remains separate. No source table is silently reranked by this report.

## Sources and provenance

The parent folder's b27_ordinary_residual_next_gate.md supplies the fixed task and stopping condition. The accepted ordinary-squarefreeness source is repo/math/reviewed_rounds/2026-10-12-reviewed-research/rs-ordinary-squarefree.md, inspected at pinned repository commit 95419a2bd5d0bf6d3b78747bf163a62a7b9e4b5d. Its modular criterion, polynomial normalization, derivative endpoint and historic b<=25 scope are inherited. Its embedded historical original-report hash does not assert that the underlying original archive was replayed in this cycle.

b27_independent_review.md is the separate accepted overlap report; it is a composition source only. ranking/RANKING_METHOD.md is the scoring source. SOURCE_BINDINGS.json in this directory hashes the exact source bytes read; FILE_MANIFEST.json binds the new packet. This report makes no outside literature or historical-priority claim.
