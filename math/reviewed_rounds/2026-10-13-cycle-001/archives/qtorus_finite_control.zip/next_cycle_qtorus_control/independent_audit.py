#!/usr/bin/env python3
"""Fresh audit. Reads JSON/text only; never imports or executes supplied code.

Three constructions: sparse-operator inversion mod p, Gaussian-product entry
formula mod p, and exact Q[z]/(z^4+1) cyclic scanning against integral Gaussian
polynomials. All arithmetic and loops below are review-authored.
"""
from pathlib import Path
from fractions import Fraction
from math import isqrt, comb
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'inert'
W = json.loads((SOURCE / 'five_orientation_witness.json').read_text())
P, Q, M, N = W['p'], W['q'], W['m'], W['N']
assert (M, N, P, Q) == (8, 64, 2013265921, 1592366214)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def mod_inverse(a):
    return pow(a % P, -1, P)

def matrix_inverse(a):
    n = len(a)
    b = [[x % P for x in row] + [int(i == j) for j in range(n)]
         for i, row in enumerate(a)]
    det = 1
    for j in range(n):
        k = next(i for i in range(j, n) if b[i][j])
        if k != j:
            b[j], b[k] = b[k], b[j]
            det = -det
        pivot = b[j][j]
        det = det * pivot % P
        inv = mod_inverse(pivot)
        b[j] = [x * inv % P for x in b[j]]
        for i in range(n):
            if i != j and b[i][j]:
                factor = b[i][j]
                b[i] = [(x - factor * y) % P for x, y in zip(b[i], b[j])]
    return [row[n:] for row in b], det % P

def orientation(name):
    maps = {'id':(1,0,0,1), 'phi':(0,-1,1,1), 'psi':(1,1,1,0),
            'eta':(0,1,-1,0), 'swap':(0,1,1,0)}
    a,b,c,d = maps[name]
    v = [((a*x+b*y)%M)*M+(c*x+d*y)%M for x in range(M) for y in range(M)]
    assert sorted(v) == list(range(N))
    return v

def operator_matrix(alpha, beta):
    a = [[0] * N for _ in range(N)]
    for x in range(M):
        for y in range(M):
            i = M*x+y
            a[i][i] = 1
            a[i][M*((x-1)%M)+y] -= alpha
            a[i][M*x+(y-1)%M] -= beta*pow(Q,x,P)
    return a

def gaussian_product(n, k):
    out = 1
    for j in range(1, k+1):
        out = out * (1-pow(Q,n-k+j,P)) * mod_inverse(1-pow(Q,j,P)) % P
    return out

def direct_entry(i,j,alpha,beta):
    x,y = divmod(i,M)
    u,v = divmod(j,M)
    dx,dy = (x-u)%M,(y-v)%M
    if dx+dy >= M:
        return 0
    return (pow(alpha,dx,P)*pow(beta,dy,P)*gaussian_product(dx+dy,dx)
            *pow(Q,u*dy,P)*mod_inverse(1-alpha**M-beta**M)) % P

# Exact field elements are four rational coefficients in basis 1,z,z²,z³,
# where z⁴=-1. Scans require only addition and multiplication by integer*z^e.
ZERO = (Fraction(0),)*4
ONE = (Fraction(1),)+ZERO[1:]

def add(a,b):
    return tuple(x+y for x,y in zip(a,b))

def scale(a,s):
    return tuple(x*s for x in a)

def shift(a,e):
    b = [Fraction(0)]*4
    for j,x in enumerate(a):
        k=(j+e)%8
        b[k%4] += x if k<4 else -x
    return tuple(b)

def reduce_field(a):
    return sum((x.numerator*mod_inverse(x.denominator)%P)*pow(Q,k,P)
               for k,x in enumerate(a)) % P

GP = [[ZERO]*M for _ in range(M)]
GP[0][0] = ONE
for n in range(1,M):
    GP[n][0] = ONE
    for k in range(1,n+1):
        GP[n][k] = add(GP[n-1][k-1], shift(GP[n-1][k], k))

def exact_entry(i,j,alpha,beta):
    x,y=divmod(i,M)
    u,v=divmod(j,M)
    dx,dy=(x-u)%M,(y-v)%M
    if dx+dy >= M:
        return ZERO
    return scale(shift(GP[dx+dy][dx],u*dy),
                 Fraction(alpha**dx*beta**dy,1-alpha**M-beta**M))

def row_scan(rhs,beta,a):
    # Solve y_c - beta*z^a*y_(c-1) = rhs_c with cyclic c.
    if 1-beta**M == 0:
        raise ValueError('row-solver guard beta^m != 1 failed')
    tail=ZERO
    for f in rhs:
        tail=add(f,scale(shift(tail,a),beta))
    tail=scale(tail,Fraction(1,1-beta**M))
    out=[]
    for f in rhs:
        tail=add(f,scale(shift(tail,a),beta))
        out.append(tail)
    return out

def branch_scan(x,alpha,beta):
    if 1-alpha**M-beta**M == 0:
        raise ValueError('resolvent guard failed')
    def traverse(initial):
        prev=initial
        result=[]
        for a in range(M):
            rhs=[add(x[a*M+c],scale(prev[c],alpha)) for c in range(M)]
            prev=row_scan(rhs,beta,a)
            result.extend(prev)
        return prev,result
    forced,_=traverse([ZERO]*M)
    factor=Fraction(1-beta**M,1-alpha**M-beta**M)
    _,out=traverse([scale(z,factor) for z in forced])
    return out

def main():
    started=time.time()
    # Deterministic trial division is a primality proof at this small p.
    assert P>2 and P%2 and all(P%d for d in range(3,isqrt(P)+1,2))
    assert pow(Q,8,P)==1 and pow(Q,4,P)==P-1
    assert (pow(Q,4,P)+1)%P==0
    manifest=[]
    for line in (SOURCE/'MANIFEST.sha256').read_text().splitlines():
        sha,name=line.split(maxsplit=1)
        ok=digest(SOURCE/name)==sha
        assert ok
        manifest.append({'name':name,'sha256':sha,'matched':ok})
    assert (HERE/'source/THEOREM(20261012-233512).md').read_bytes()==(SOURCE/'THEOREM.md').read_bytes()
    assert W['orientations']==['id','phi','psi','eta','swap']
    assert len(W['parameters'])==len(W['branch_scalars'])==5
    assert len(W['left_diagonals'])==len(W['right_diagonals'])==5
    for rows in (W['left_diagonals'],W['right_diagonals']):
        assert all(len(r)==N and all(type(x) is int and 0<x<P for x in r) for r in rows)
    permutations=[orientation(name) for name in W['orientations']]
    branches=[]
    guards=[]
    for alpha,beta in W['parameters']:
        guard={'alpha':alpha,'beta':beta,'resolvent_integer':1-alpha**M-beta**M,
               'resolvent_mod_p':(1-alpha**M-beta**M)%P,
               'row_integer':1-beta**M,'row_mod_p':(1-beta**M)%P}
        assert all(guard[k]!=0 for k in ('resolvent_integer','resolvent_mod_p','row_integer','row_mod_p'))
        guards.append(guard)
        inv,det=matrix_inverse(operator_matrix(alpha,beta))
        assert all(inv[i][j]==direct_entry(i,j,alpha,beta) for i in range(N) for j in range(N))
        branches.append(inv)
    out=[[sum(W['branch_scalars'][t]*W['left_diagonals'][t][i]
                   *branches[t][permutations[t][i]][permutations[t][j]]
                   *W['right_diagonals'][t][j] for t in range(5))%P
          for j in range(N)] for i in range(N)]
    _,det=matrix_inverse(out)
    assert det and all(x for row in out for x in row)
    total=0
    smallest=P
    for i in range(N):
        for k in range(i+1,N):
            for j in range(N):
                for ell in range(j+1,N):
                    d=(out[i][j]*out[k][ell]-out[i][ell]*out[k][j])%P
                    assert d, (i,k,j,ell)
                    smallest=min(smallest,d)
                    total+=1
    assert total==comb(N,2)**2==4064256
    rho=out[1][1]*out[0][0]*mod_inverse(out[1][0]*out[0][1])%P
    assert pow(rho,N,P)!=1
    print('PASS modular matrix, invertibility, all 4,064,256 minors',flush=True)

    # Exact characteristic-zero scans, stronger than source's modular-only tests.
    basis_checks=0
    exact_branches=[]
    for branch,(alpha,beta) in enumerate(W['parameters']):
        dense=[[exact_entry(i,j,alpha,beta) for j in range(N)] for i in range(N)]
        assert all(reduce_field(dense[i][j])==branches[branch][i][j] for i in range(N) for j in range(N))
        for j in range(N):
            vec=[ZERO]*N
            vec[j]=ONE
            actual=branch_scan(vec,alpha,beta)
            assert actual==[dense[i][j] for i in range(N)],(branch,j)
            basis_checks+=1
        exact_branches.append(dense)
        print('PASS exact Q(zeta8) branch',branch,'64 basis columns',flush=True)
    # Verify each fully gauged/oriented characteristic-zero coefficient specializes.
    full_exact=[]
    for i in range(N):
        row=[]
        for j in range(N):
            value=ZERO
            for t in range(5):
                value=add(value,scale(exact_branches[t][permutations[t][i]][permutations[t][j]],
                    W['branch_scalars'][t]*W['left_diagonals'][t][i]*W['right_diagonals'][t][j]))
            assert reduce_field(value)==out[i][j]
            row.append(value)
        full_exact.append(row)
    combined_basis_checks=0
    for j in range(N):
        applied=[ZERO]*N
        for t,(alpha,beta) in enumerate(W['parameters']):
            vec=[ZERO]*N
            vec[permutations[t][j]]=scale(ONE,W['right_diagonals'][t][j])
            resolved=branch_scan(vec,alpha,beta)
            for i in range(N):
                applied[i]=add(applied[i],scale(resolved[permutations[t][i]],
                    W['branch_scalars'][t]*W['left_diagonals'][t][i]))
        assert applied==[full_exact[i][j] for i in range(N)],j
        combined_basis_checks+=1
    # Negative guard control: resolvent exists when alpha=2,beta=1,
    # while this particular row-scan factorization is undefined.
    assert 1-2**M-1**M != 0
    try:
        branch_scan([ZERO]*N,2,1)
    except ValueError as e:
        assert 'row-solver' in str(e)
        rejected=True
    else:
        raise AssertionError('Expected row guard rejection')
    result={
        'status':'PASS — independently accepted at stated finite scope',
        'record_id':'QTORUS-CONNECTED-MINOR-20261013',
        'uploaded_programs_executed':False,
        'source_manifest':manifest,
        'separate_theorem_matches_archive':True,
        'prime':P,'prime_verified_by':'trial division through floor(sqrt(p))',
        'sqrt_prime_floor':isqrt(P),'primitive_eighth_root':Q,
        'q_power_4':pow(Q,4,P),'q_power_8':pow(Q,8,P),
        'gaussian_product_denominators_mod_p':[(1-pow(Q,j,P))%P for j in range(1,M)],
        'branches':guards,
        'matrix_dimensions':[N,N],
        'operator_inverse_vs_gaussian_product_entries':5*N*N,
        'exact_cyclotomic_branch_basis_checks':basis_checks,
        'exact_cyclotomic_dense_entries_reduced':5*N*N,
        'fully_gauged_oriented_exact_entries_reduced':N*N,
        'fully_gauged_oriented_exact_basis_checks':combined_basis_checks,
        'rank_mod_p':N,'determinant_mod_p':det,
        'nonzero_entries':N*N,'nonzero_2x2_minors':total,
        'minimum_nonzero_2x2_residue':smallest,
        'cross_ratio_rows':[0,1],'cross_ratio_columns':[0,1],
        'cross_ratio_mod_p':rho,'cross_ratio_power_64_mod_p':pow(rho,N,P),
        'negative_guard_control_rejected':rejected,
        'source_positive_result_agrees':json.loads((SOURCE/'RESULTS.json').read_text())['five_orientation_exact_finite_positive']['all_2x2_minors_nonzero']==total,
        'finite_2_full_spark_over_characteristic_zero':True,
        'full_spark_claimed':False,'all_size_claimed':False,
        'Fourier_equivalent':False,'universal_faster_DFT_claimed':False,
        'runtime_seconds':round(time.time()-started,3)
    }
    matrix_bytes=json.dumps(out,separators=(',',':')).encode()
    result['matrix_mod_p_json_sha256']=hashlib.sha256(matrix_bytes).hexdigest()
    (HERE/'MATRIX_MOD_P.json').write_bytes(matrix_bytes+b'\n')
    (HERE/'RESULTS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(result,indent=2,ensure_ascii=False),flush=True)

if __name__=='__main__':
    main()
