# Independent review: five-orientation quantum-torus positive control

Reviewed 12 October 2026 UTC. Verdict: **ACCEPT at the finite, exact scope stated below.** The separate three-orientation obstruction was already accepted; this review does not count it again.

## Result and identity

The new source supplies a genuinely positive finite control in the existing family: one explicitly frozen, invertible 64-by-64 matrix over Q(zeta_8), made from five diagonally gauged oriented quantum-torus resolvents, with all 4,064,256 minors of size 2 nonzero. Independent reconstruction and exhaustive exact finite-field checking succeeded. A fresh exact cyclotomic implementation additionally verifies all 64 basis columns of the complete gauged/oriented two-pass executor, and all 320 branch basis columns.

Map this milestone to **QTORUS-CONNECTED-MINOR-20261013**. It is an update to that intake, not a new canonical identity, additional canonical theorem count, or reacceptance of the old three-orientation result. Suggested updated title: “Q-torus restricted obstruction and verified finite positive control.”

This is not an all-size 2-full-spark theorem, a claim about all higher-order minors, a uniform coefficient-generation theorem, a full Fourier algorithm, or an unrestricted Fourier complexity lower bound. The positive matrix is provably not Fourier. Historical novelty remains unassessed.

## Source binding and safe inspection

- Standalone theorem: Library `libfile_ccf3236044b08191a7516b211023aafb`, `THEOREM(20261012-233512).md`.
- Archive: Library `libfile_4a51c11f9920819190be7370165d7431`, `FFT_Verified_Three_Orientation_Theorem_2026-10-13.zip`, 17,844 bytes.
- Archive SHA-256: `aee75b3b09f01ea1ca77133abbeada707e1fa8e269a81e9cb3f9c922b3387547`.
- Theorem SHA-256: `e4ab589332fca3deedc3672b338de9deb96719cd924d11534ea82dfec1bb6d5b`.
- Frozen JSON witness SHA-256: `3bd6a16d16121026cab4ab1682099fe6eae9d829eeee966123a56ad23915d1c8`.

All six entries in the archive's SHA-256 manifest match. The standalone theorem is byte-identical to its archived counterpart. The archive was inspected as inert bounded text/JSON. No uploaded program was run or imported; no pickle was opened. `SOURCE_BINDING.json` records all members. Source report date 13 October is retained as its label; this audit actually occurred on 12 October UTC.

## Independent construction and exact checks

The review-authored `independent_audit.py` reads only the literal witness JSON and source text/hash manifest. It uses three differently implemented constructions:

1. Build each sparse operator directly from the shifts A and B, then invert I-alpha A-beta B by modular Gauss–Jordan elimination.
2. Build each entry separately using the product formula for the Gaussian binomial. All 20,480 entries agree with the five independently inverted operators.
3. Work exactly in Q[z]/(z^4+1), using four rational coefficients, an alternative integral Gaussian-binomial recurrence, and a fresh cyclic scan. All 320 branch basis columns agree exactly. All 64 full five-branch, diagonally gauged, oriented basis columns agree exactly with the characteristic-zero dense matrix. Every characteristic-zero coefficient reduces to the modular matrix.

The theorem, rather than the JSON's modular root field alone, defines the characteristic-zero interpretation: z is a primitive eighth root; the integer 1592366214 is its chosen image modulo p, not the characteristic-zero value of z.

Certified results:

- p = 2,013,265,921 is prime, proved by trial division through floor(sqrt(p)) = 44,869.
- q = 1,592,366,214 satisfies q^8 = 1 and q^4 = -1 modulo p. Thus q has exact order 8 and satisfies Phi_8(q) = q^4+1 = 0.
- All five orientation maps are permutations; all 640 left/right gauge values and five branch weights are nonzero.
- Every resolvent denominator D_t = 1-alpha_t^8-beta_t^8 and every cyclic-row denominator E_t = 1-beta_t^8 is nonzero both as an integer and modulo p.
- All seven auxiliary factors 1-q^j, 1 <= j <= 7, are nonzero. The exact Gaussian-binomial construction itself uses polynomials and needs no such division.
- The resulting matrix has 4,096 nonzero entries and rank 64. Its determinant modulo p is **750,789,467**.
- Exactly C(64,2)^2 = 2,016^2 = **4,064,256** distinct unordered-row/unordered-column 2-by-2 minors were checked. Every residue is nonzero; the smallest positive residue is 281.
- A concrete cross ratio on rows 0,1 and columns 0,1 is 232,289,060 modulo p, whose 64th power is 718,025,072, not 1.

The resolver-denominator residues, in branch order, are 1670565027, 1178087705, 988562855, 300279781, 764472527. The row-solver residues are 534734779, 669578225, 1488913787, 568714691, 1512914990. Full integer denominators and detailed checks appear in `RESULTS.json`.

## Why reduction proves characteristic-zero nonvanishing

The entries belong to the localization of Z[z]/(Phi_8(z)) obtained by inverting the five rational-integer resolvent denominators. The verified denominator guards give a well-defined ring homomorphism to F_p sending z to q. An entry, 2-by-2 determinant, or full determinant that was zero over Q(zeta_8) would reduce to zero under this good specialization. Therefore every reported nonzero residue proves that the corresponding characteristic-zero determinant is nonzero. This implication is one-way and is used only in that direction.

Merely testing an equality modulo one prime would not prove it over characteristic zero. The source's 64 modular solver-column tests alone are therefore finite-field equality evidence. This audit supplies exact characteristic-zero basis equalities as well as the algebraic solver derivation below; neither relies on reversing the nonvanishing argument.

## Solver correctness, guard, and cost

Write T for cyclic shift in the second coordinate. At row a, solve

(I-beta*z^a*T)y_a = x_a + alpha*y_(a-1).

A cyclic scalar recurrence takes two length-m scans, dividing by 1-beta^m. These row operators commute, and the product of (I-beta*z^a*T) over a=0,...,m-1 is (1-beta^m)I, since z is primitive and T^m=I. Consequently the transfer around all rows is the scalar alpha^m/(1-beta^m). A first row traversal from zero computes the forcing term for the last row; multiplication by (1-beta^m)/(1-beta^m-alpha^m) enforces cyclic closure. The second traversal then produces the required solution. This proves the two-pass algorithm whenever both denominators are nonzero.

The extra guard **beta^m != 1** is essential for this factorization even though the full resolvent can exist without it. A negative control with alpha=2, beta=1 has nonzero full resolvent denominator but is correctly rejected by the row solver. All five supplied branches satisfy both guards, so this is a scope clarification, not a defect in the frozen witness. The source verifier already states the extra guard; Section 5's prose should state it explicitly if reused alone.

For a fixed number of branches, supplied/prepared coefficients, and valid guards, the parameterized scan needs O(m^2)=O(N) exact field operations and O(N) state. Permutations, gains, summing branches and producing all outputs also cost O(N). This is a field-operation statement; it supplies neither a uniform all-length construction of the special gauge arrays nor a bit-complexity/conditioning guarantee. Fixed N=64 data alone cannot establish an asymptotic family of 2-full-spark examples.

## Section 6: non-Fourier argument independently accepted

If M over E=Q(zeta_m) were monomially equivalent to F_(m^2), it would have no zero entries. Its cross ratios belong to E, while nonzero row/column scalings cancel in each cross ratio and permutations merely relabel them. The Fourier cross-ratio collection contains a primitive m^2-th root (use adjacent row and column labels). Hence zeta_(m^2) would lie in E.

But Q(zeta_m) is contained in Q(zeta_(m^2)), and

[Q(zeta_(m^2)):Q(zeta_m)] = phi(m^2)/phi(m) = m > 1

for every integer m >= 2. This contradiction proves the Section 6 assertion, including the current m=8 witness. Arbitrary complex outer diagonal gauges cannot evade a cross-ratio invariant. The argument says nothing about matrices whose coefficients are allowed outside E.

There are two additional concrete checks here. First, the displayed modular cross ratio does not have 64th power 1, whereas every F_64 cross ratio does. Second, F_64 already has zero 2-by-2 minors (for example rows 0,8 and columns 0,8), unlike the positive control. Either independently excludes monomial Fourier equivalence for this witness.

## Ranking and next action

Recommended existing-packet priority: **50/100, unchanged**. Apply the published rubric to the still-open prior-art/model-comparison task: information gain 3, tractability 3, defensible novelty opportunity 1, scope/impact 2, evidence readiness 3. Weighted average 2.45/5 gives 1+round(99*2.45/5)=50. The fresh finite control improves proof coverage, but does not make the unresolved worldwide-priority comparison more source-ready or make Fourier synthesis plausible.

The finite positive-control audit is now a **completed stage**, subject to the rubric's completed-stage cap of **15/100**; do not repeat it as an open next-cycle task. The already excluded fixed-three-orientation full-Fourier synthesis route stays closed at 8/100. These are distinct scopes, not contradictory scores.

Remaining bounded task: compare the accepted connected-minor obstruction and this exactly stated finite positive control against model-matched prior results; record either an exact implication or the precise unmatched clause. Stop when that source-bound comparison is established. Do not turn a finite positive example into a new all-length objective without specifying a separate contract. Root owns all live Sheet/GitHub/Library write decisions; none were performed in this lane.

## Reproduce

Run `python3 next_cycle_qtorus_control/independent_audit.py` from the workspace root. Only standard Python libraries are required. It reads inert source JSON/text, writes `RESULTS.json` and `MATRIX_MOD_P.json`, and never runs supplied source programs. `RUN.log` records the completed run. `PRIORITY_RECOMMENDATION.json` carries a machine-readable proposed update for the existing intake.
