# Independent review of the Gaussian preweight precision gate

13 October 2026 UTC. Decision: ACCEPT the local mathematical obstruction, deterministic perturbation lemma, and sufficient precision bound at their stated scope. The whole randomized Fourier consequence remains conditional on the explicitly inherited ideal Gaussian theorem. This review neither re-proves that theorem nor certifies a finite-word Fourier implementation.

## Independent checks

The reviewer read the complete candidate proof and rebuilt its recurrence-error ledger without importing candidate code. Symbolic error multiplicities are propagated directly through the two coupled recurrences. They give seed exponent r squared, step-rounding exponent r(r−1)/2, aggregate ratio-rounding exponent r(r−1)/2, and weight-rounding exponent r. Their sum is exactly 2r squared. The normalizer and final weight multiplication add two.

For relative perturbations of magnitude at most u, the product is between (1−u)^K and (1+u)^K, where K=2r squared+2. Both deviations from one are bounded by exp(Ku/(1−u))−1. Since r≤N/2, N≥4, and u≤N^(−2−α)/256, the exponent is at most N^(−α)/128. This implies the advertised N^(−α)/64 relative preweight error. The general algebra establishes the bound; the checked specializations are regression controls.

The exact script independently checks 129 multiplicity states, 1,277 precision and centering inequalities, the binary64 scalar collapse certificate N=2^32, and three deliberately false statements. It uses only rational arithmetic and standard-library code. All candidate manifest entries match. These controls do not reproduce the candidate's larger execution suite and are not presented as source-level mutation coverage.

## Obstruction and probability

For 0<λ≤2^(−p−2), p≥1, exp(λ) lies in the rounding cell of one under the specified nearest-even convention. A compiler using only the rounded base therefore generates constant dimensionless weights. Its input to the remaining graph equals the correctly preweighted damped input x′. This is a pathwise identity; it does not assume that medians are linear.

For the fixed last-quarter indicator, N divisible by four, π>3, L≥12, and Q≤8N, every supported entry has damping exponent at least 9/256. The normalized unitary-DFT DC discrepancy is at least 9/530, strictly greater than 1/64. The inherited fixed-input guarantee applies to deterministic x′ independently of the fresh random tape. The stated constant-error probability consequence follows once its asymptotic error constant is sufficiently small. A finite scalar rounding certificate alone does not prove failure at that finite N.

For the positive result, deterministic relative perturbations of magnitude η change the input by at most η times its Euclidean norm. The unitary DFT row bound and the inherited ideal guarantee give error at most [C N^(−α)(1+η)+η] times the original norm. This preserves the actual infinity-output/Euclidean-input norm and the fixed-input probability quantifier.

## Cost and boundary

The preweight-only construction uses O(N) precision-p arithmetic operations with p=O(log N), plus polynomial-in-log-N seed work for supplied admissible integer parameters. Certified approximate seeds suffice; correctly rounding a transcendental at an arbitrarily close midpoint is unnecessary. Computing or validating the caller's padding, selecting its global parameters, representing arbitrary input data, and multiplying those data by the weights remain caller obligations. No unit-cost bit-arithmetic claim follows.

The remainder of a finite-word transform still needs a stability and resource theorem for its phases, Green operations, FFT/convolution backend, randomness, medians, input/output formats, and exponent range. This audit does not verify HIKP backend integration or change its separate queue status. No source NumPy implementation is alleged to use the failed rounded-base compiler.

## Research status

Record this as an accepted local compiler analysis within the existing approximation family, with no additional canonical discovery ID or historical novelty clearance. The proposed next Gaussian subgate is an independently executable, certified-seed preparer at priority54/100. The F016/HIKP task and its existing priority60 remain separate. The priority values describe work usefulness, not confidence or breakthrough probability.

Evidence: `check_local_lemmas.py`, `LOCAL_CHECKS.json`, and the bound candidate manifest. The original candidate files remain unchanged.
