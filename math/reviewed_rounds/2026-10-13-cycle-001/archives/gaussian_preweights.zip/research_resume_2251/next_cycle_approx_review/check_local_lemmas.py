"""Independent exact controls for the local Gaussian preweight proof.

No imports from the candidate, no historical executable evaluation.
The all-length randomized Fourier theorem remains an explicit premise.
"""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent / 'next_cycle_approx'


def multiplicities(limit=128):
    w = Counter()
    ratio = Counter(seed=1)
    step = Counter(seed=2, step_round=1)
    rows = []
    for r in range(limit + 1):
        assert w['seed'] == r*r
        assert w['step_round'] == r*(r-1)//2
        assert sum(v for k,v in w.items() if k.startswith('ratio_')) == r*(r-1)//2
        assert sum(v for k,v in w.items() if k.startswith('weight_')) == r
        assert sum(w.values()) == 2*r*r
        rows.append({'r': r, 'seed_power': w['seed'], 'total': sum(w.values())})
        w += ratio
        w[f'weight_{r}'] += 1
        ratio += step
        ratio[f'ratio_{r}'] += 1
    return rows


def precision_bounds():
    checks = 0
    # alpha=1/4, N=2^(4k), so delta=N^-alpha=2^-k exactly.
    for k in range(1, 65):
        n = 2**(4*k)
        p = 9*k + 8
        delta, u = F(1,2**k), F(1,2**p)
        for r in [0, 1, n//4, n//2]:
            count = 2*r*r + 2
            t = count*u/(1-u)
            assert t <= delta/128
            # exp(t)-1 <= t/(1-t), by the positive Taylor series.
            assert 0 <= t < 1
            assert t/(1-t) <= delta/64
            checks += 1
    # The general algebra uses r<=N/2 and N>=4:
    # 2r^2+2 <= N^2, u<=delta/(256N^2), and 1/(1-u)<=2.
    for n in range(4, 1025):
        r = n - 1 - (n-1)//2
        assert 2*r <= n
        assert 2*r*r+2 <= n*n
        checks += 1
    return checks


def collapse_and_bias():
    n, q, p, ell = 2**32, 17179869193, 52, 12
    assert 4*n <= q <= 8*n
    assert q == 37*464320789
    upper_lambda = F(22,7)*ell/(q*q)
    assert upper_lambda < F(1, 2**(p+2))
    # 1/(1-lambda) encloses exp(lambda), without a transcendental oracle.
    assert 1/(1-upper_lambda) < 1 + F(1,2**(p+1))
    # General last-quarter damping lower bound uses pi>3, L>=12.
    t = F(3*12,1024)
    assert t == F(9,256)
    bias = t/(2*(1+t))
    assert bias == F(9,530) and bias > F(1,64)
    assert bias-F(1,128) > F(1,128)
    return {'n': n, 'q': q, 'fraction_bits': p, 'strict_bias_lower_bound': str(bias)}


def main():
    hashes = []
    manifest = json.loads((CANDIDATE/'MANIFEST.json').read_text())
    for v in manifest['files']:
        path = CANDIDATE/v['path']
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual == v['sha256']
        assert path.stat().st_size == v['bytes']
        hashes.append({'path': v['path'], 'sha256': actual})
    rows = multiplicities()
    guards = precision_bounds()
    scalar = collapse_and_bias()
    # Distinct corruption controls: omit amplified seed, weaken DC bound,
    # and change the scalar padding without changing its certificate.
    rejected = []
    for name, predicate in [
        ('omit amplified seed', lambda: rows[8]['total']-rows[8]['seed_power'] == 128),
        ('claim bias at least one quarter', lambda: F(9,530) >= F(1,4)),
        ('wrong scalar padding', lambda: scalar['q'] == 4*scalar['n']),
    ]:
        assert not predicate()
        rejected.append(name)
    result = {'status':'PASS local independent controls', 'multiplicity_rows':len(rows),
              'precision_and_centering_checks':guards, 'scalar':scalar,
              'rejected_corruptions':rejected, 'candidate_files_bound':hashes,
              'scope':'Local proof only; no downstream finite-word or global ideal-theorem replay.'}
    (HERE/'LOCAL_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='candidate_files_bound'}))


if __name__ == '__main__':
    main()
