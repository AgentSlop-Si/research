# F016 / APPROX: the near-one Gaussian-base precision gate

Work interval: 2026-10-12/13 UTC. Local research only. **Candidate result, awaiting independent review.**

## Result

One unresolved preparation gate is now quantified: the ideal Gaussian audit's O(N) two-ratio preweight construction cannot simply be instantiated with a low-precision rounded base. When exp(πL/Q²) rounds to 1, the resulting full algorithm computes the accepted Gaussian estimator on a different, damped input. A fixed dyadic input family has normalized DC bias exceeding 1/64. Consequently, under the accepted ideal theorem, this modified algorithm has constant error with probability tending to one. The ideal theorem itself is not refuted.

The same gate has a positive local repair: a centered two-ratio construction with certified seeds and p ≥ ceil((2+α)log₂N)+8 fraction bits prepares every preweight to relative error at most N^(−α)/64, with O(N) precision-p operations plus poly(log N) cold seed work. A fixed-input coupling transfers that preweight error into the theorem's actual l∞/input-l2 norm. It does not certify subsequent finite-word Green, FFT, convolution, phase or median operations.

This is an analysis of the proposed near-one-base coefficient compiler, not a failure allegation against the source NumPy implementation. The latter evaluates exp directly and expressly disclaims a finite-word theorem. It is also distinct from the HIKP/S6 implementation route and the already completed packed-table resource refusal.

## 1. Source and exact selected contract

The source-bound Gaussian audit, SHA-256 eced2bc72d85f7cf4666dac4d1ba9faaf2c268cb343bcc497261edd2bb206cad, §5 proposes

    a = exp(πL/Q²),  g_j = a^((j-c)²)/sqrt(L),  c=floor((N−1)/2),

and changing multiplicative ratios in O(N) exact operations. Its §5 explicitly leaves recurrence stability and precision unproved. The source gaussian_lift.py, SHA-256 1a7943e27eb46951ef04dca355ff054fee51a23d50b9b3a24ca646b624c26018, prepare_centered_weighted_input, repeats the two-ratio comment but actually uses NumPy exp.

Use the accepted rough padding, with M prime Θ(log N), Q=MK=4N+N^o(1), no prime factor below M, and all sufficiently large N. In particular, 4N≤Q≤8N eventually. Put L=max(12,ceil((2α/π)ln N)), 0<α<1/2. Input x is fixed independently of fresh random states. The accepted ideal Gaussian algorithm A_N returns all N coordinates with

    ||A_N(x)−U_Nx||∞ ≤ C N^(−α)||x||₂

except probability at most N^(−c₀), for a suitable fixed row count depending on α,c₀. Its work is O_{α,c₀}(N log log N). U_N is the negative-sign unitary DFT. This historical theorem is used as a stated premise, not freshly recertified here.

The current repaired F016 action is the separate HIKP whole-output/backend refinement beyond two admitted fixtures. This bounded cycle selects the explicitly authorized Gaussian preparation alternative; it does not replace, retire, or claim completion of that HIKP action. The current admitted-backend primary report was fetched at commit 95419a2bd5d0bf6d3b78747bf163a62a7b9e4b5d and read in full. Its 471,063 source calls per positive n=32,768 fixture, fixed selected tape, limited constructor totality, and open S6 integration remain unchanged.

ALG-034's six binary64 failures concern a different direct unequal-block route and are not used against F016. The repaired FUS-04/FUS-12 actions request a successful fully charged theorem-precision executor or a new exact obstruction. Their accepted 3–4–5 family and declared-cap refusal were not rerun, and this result gives them no Fourier or production promotion.

## 2. Precision model

For positive numbers in binade [2^e,2^(e+1)), p fraction bits mean spacing 2^(e−p). fl_p is round-to-nearest, ties-to-even. Thus the successor to 1 is 1+2^(−p), and the midpoint is 1+2^(−p−1). We use the safe relative error bound u=2^(−p), even though the usual bound can be smaller. Exponents are assumed sufficiently wide; overflow/underflow are excluded from this local gate, not declared solved. Binary64 has p=52 in this convention.

The negative result rounds only a and then generates dimensionless powers from that value. The normalizer, input multiplication and all downstream arithmetic may be ideal. Failure even in this strengthened model prevents certification by merely ignoring base error. The positive result separately charges a certified approximate normalizer and the rounded final multiplication.

## 3. Base-collapse lemma

Let λ=πL/Q². If 0<λ≤2^(−p−2), then

    1 < exp(λ) ≤ 1+2λ ≤ 1+2^(−p−1).

Here exp(λ)−1≤2λ for 0≤λ≤1/2; p≥1 suffices. At equality the tie rounds to the even value 1. Therefore fl_p(exp λ)=1. Any powers, repeated squaring, or multiplicative-ratio recursion made solely from that rounded base produces the dimensionless weight 1 exactly, giving

    g̃_j = 1/sqrt(L),
    x′_j = (g̃_j/g_j)x_j = exp(−λ(j−c)²)x_j.

Every later input presented to the Gaussian engine is exactly the one produced by its correct preweights on x′. Hence, with the same random tape,

    Ã_N(x) = A_N(x′).

This is a pathwise equality, including all separate real/imaginary medians. It uses only the location of preweighting before the rest of the source graph, not linearity of the median.

The collapse condition is a concrete near-one-base threshold, not a lower bound on all Gaussian preparation algorithms. For any fixed p it holds eventually; more generally it holds eventually when p≤(2−ε)log₂N for fixed ε>0. A well-chosen O(log N)-bit precision can avoid it.

## 4. Full-output error consequence in the same norm

Take N divisible by four and x_j=1 for 3N/4≤j<N, zero otherwise. This is a fixed Gaussian-dyadic input, chosen before any random tape. Its norm is sqrt(N)/2. On its support j−c≥N/4, and Q≤8N, so

    λ(j−c)² ≥ πL/1024 ≥ 9/256.

At DC all x entries are nonnegative and

    |(U_Nx)_0−(U_Nx′)_0| / ||x||₂
       ≥ (1/2)(1−exp(−9/256))
       ≥ 9/530 > 1/64.

The middle inequality uses exp(t)≥1+t, not a numerical approximation. Also ||x′||₂≤||x||₂. Apply the inherited fixed-input theorem to x′ and use the pathwise identity. With probability at least 1−N^(−c₀),

    ||Ã_N(x)−U_Nx||∞ / ||x||₂ > 1/64 − C N^(−α).

In particular, once C N^(−α)≤1/128 the error exceeds 1/128 on that event. This cannot be O(N^(−α)) for growing N. No finite experimental success/failure frequency is used as a proof. The construction proves a constant-error obstruction for this compiler while preserving the accepted exact-coefficient theorem.

A certified scalar instance is N=2^32, M=37, K=464320789, Q=17179869193, L=12, p=52. Exact rational enclosures put exp(πL/Q²) in the rounding cell of 1. No N-sized array or full transform at this size was allocated. That scalar certificate alone is not a finite-N violation of an unspecified asymptotic constant C; the preceding growing-family argument is what establishes the contradiction.

## 5. Positive perturbation lemma in the target norm

Suppose fixed, input-independent prepared weights obey g̃_j=g_j(1+δ_j), with max_j|δ_j|≤η. Put x′=diag(1+δ)x. With all later arithmetic ideal, Ã_N(x)=A_N(x′), so the accepted theorem and unitary-row norm give, on its event,

    ||Ã_N(x)−U_Nx||∞
      ≤ [C N^(−α)(1+η)+η] ||x||₂.

Indeed ||x′||₂≤(1+η)||x||₂ and ||U_N(x′−x)||∞≤||x′−x||₂≤η||x||₂. The probability is still for each fixed input and fresh randomness; δ may depend on N and the fixed preparation procedure but not on the current random tape. Thus η≤N^(−α)/64 is sufficient for this component. A looser l2 bound N^(1/2−α)||x||₂ would not prove this statement and is not substituted here.

## 6. A centered two-ratio precision bound

Generate nonnegative r=|j−c|, then reflect/copy weights; r≤N/2. Let ã/a∈[1−u,1+u], b̃=fl_p(ã²), w̃_0=1, q̃_0=ã, and iterate

    w̃_(r+1)=fl_p(w̃_r q̃_r),
    q̃_(r+1)=fl_p(q̃_r b̃).

A certified seed γ̃ approximates 1/sqrt(L) to relative error ≤u, and g̃_r=fl_p(γ̃w̃_r). Expanding the products rather than summing local error bounds gives the following multiplicity ledger for w̃_r/a^(r²):

- error in ã: exponent r²;
- error in b̃/ã²: exponent r(r−1)/2;
- ratio-update rounding errors: total multiplicity r(r−1)/2;
- w-update rounding errors: multiplicity r.

Total is exactly 2r². The normalizer and final multiplication add two. Each elementary relative perturbation is between 1−u and 1+u. Consequently

    |g̃_r/g_r−1| ≤ exp((2r²+2)u/(1−u))−1.                (P)

This is a worst-case forward error bound, with the base and recurrent amplification included. Counting only O(N) local roundings without their multiplicities would miss the quadratic sensitivity.

For N≥4, p≥ceil((2+α)log₂N)+8 implies u≤N^(−2−α)/256. Since r≤N/2, the exponent in (P) is at most N^(−α)/128. It is below 1/2, so exp(t)−1≤2t yields

    max_r |g̃_r/g_r−1| ≤ N^(−α)/64.

This proves the promised local repair. The constant +8 is deliberately conservative. No optimal-precision or universal necessity claim is made.

## 7. Cold preparation, output and bit ledger

A correctly rounded transcendental seed is not required for (P): a certified relative-u approximation suffices. This avoids a hidden unbounded search for an exact rounding decision near a midpoint. For example:

1. Enclose π by the alternating Machin arctangent series; form λ using exact integer Q² and directed rational division.
2. Enclose exp(λ) by Taylor series after a fixed range reduction. Refine to an absolute enclosure of width below a fixed fraction of u, and choose a dyadic approximation with certified relative error ≤u. These elementary series and exact rational operations have poly(log N) bit cost for p=O(log N). This is cold, paid seed work. It is not N calls to a transcendental oracle.
3. Enclose 1/sqrt(L) using integer square-root comparisons at the required dyadic scale and obtain γ̃ with relative error ≤u. Again charge poly(log N) work.
4. Pay one b̃ preparation, two rounded products per nonnegative r, reflection/copy, normalization multiplication and all N input-weight products. The last products are outside (P)'s preweight-only output guarantee and need their own input-representation error budget.

Stored preweights and dimensionless intermediates are positive and bounded between constant multiples of 1/sqrt(L) and exp(πL/64)/sqrt(L). Since L=O(log N), magnitude is polynomial in N. Their binary exponents have O(log log N) bits; mantissas have O(log N) bits. Q² and indices require O(log N) bits with an explicit constant factor, not fixed int64 wraparound. The p-bit multiplications have O(p)-bit input/output widths (with O(p)-bit-wide temporary products) and must be charged as such.

Preparation: O(N) precision-p operations + poly(log N) cold seed operations; O(Np) bits if the N weights are stored, or O(p) generator state plus the input/output arrays if streamed. In a word-RAM with a fixed sufficiently large number of Θ(log N)-bit words per coefficient and the named multiplication/rounding primitives, this is O(N)+poly(log N) word work. In a bit model it is O(N M(p)+poly(log N)), where M(p) is the cost of p-bit multiplication; do not call it O(N) bit work. Parsing and input/output mantissa/exponent costs remain part of the caller contract.

The Gaussian transform still emits N complex answers, taking Ω(N) word writes or Ω(Np_out) output bits at a prescribed p_out. This gate does not reduce that output cost. Total finite-word Gaussian work cannot yet be claimed: root preparation, long/short FFT arithmetic, Green compression/scans, filter taps, phase reduction, input conversion, finite exponents, medians and the fully bounded randomness/abort ledger remain separate obligations. The S6/HIKP route has separate source and totality obligations; these formulas do not certify its filter constructor.

## 8. Fresh exact tests and what they establish

Run `python fresh_precision_checks.py`. The script imports only Python's standard library and no historical program.

- 13,689 exact rational nearest-even controls across signed values, binades and precision settings.
- Nine exact rough-padding/base-collapse certificates, including N=2^32,p=52 and growing scalar plans up to N=2^128. π, ln 2 and exp are enclosed by rational/integer outward arithmetic. No huge arrays are allocated.
- 1,994 dimensionless recurrence coordinates and 1,994 normalized preweight checks across ten freshly executed centered recurrence cases, N=64,...,1024. Each implemented dyadic value is compared with an outward exponential enclosure using exact inequalities. Every multiplicity bound and every +8-bit repair bound passes.
- At N=4096,p=8, a certified endpoint relative preweight error exceeds 0.4429. This is a coefficient diagnostic, not a theorem-precision end-to-end pilot.

The proof supplies all-input/growing-family claims; enumeration checks its formulas and conventions. The large scalar plans are analytic certificates, not claims of physical execution or successful theorem-precision dense output.

## 9. Primary comparison and next action

`primary_comparison.md` checks HIKP Theorem 4.4 and Nakos–Song–Wang 2019 in the same normalization/norm. HIKP plus the separate accepted S6 transfer already yields an ideal O(N) all-length dense-output weak approximation. NSW's formal time is O(n log³n log k), distinct from its sample count O(k log k log n); its noise-scale, dynamic-range and negligible-roundoff assumptions are not a finite-word certificate. Neither constitutes a general exact FFT result.

**Recommended next priority: 54/100 for this Gaussian finite-word subgate**, reduced from family slot 60 after identifying a narrowly repairable obstruction with a quantified remedy. This is a recommendation, not a frozen-score edit. Keep F016/HIKP's existing next action independently open. The next useful Gaussian step is to pin an executable centered preweight preparer with certified approximate seeds, exact rounding/range metadata and charged cold preparation, then independently verify its variable-N contract before tackling the downstream FFT/Green arithmetic. Stop at a first explicit contract/range/cost failure if that executable cannot meet the lemma; do not repeat the base-collapse test as a new milestone.

No novelty, unrestricted lower bound, measured speedup, production qualification or exact/general FFT promotion is asserted. No Sheet, GitHub, Library or frozen-ranking writes were made.
