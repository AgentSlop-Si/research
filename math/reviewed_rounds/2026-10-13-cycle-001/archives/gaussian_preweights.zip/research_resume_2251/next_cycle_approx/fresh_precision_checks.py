#!/usr/bin/env python3
"""Fresh exact rational/integer controls; no historical executable imports."""
from fractions import Fraction as F
from math import isqrt
import json, pathlib, hashlib
HERE=pathlib.Path(__file__).resolve().parent

def ceilq(x): return -((-x.numerator)//x.denominator)
def arctan_interval(q, terms=150):
    s=F(0)
    for j in range(terms): s+=F((-1)**j,(2*j+1)*q**(2*j+1))
    z=F((-1)**terms,(2*terms+1)*q**(2*terms+1))
    return min(s,s+z),max(s,s+z)
a,b=arctan_interval(5); c,d=arctan_interval(239)
PI=(16*a-4*d,16*b-4*c)
# log 2 = 2 sum_{j>=0} (1/3)^(2j+1)/(2j+1); positive tail.
lnlo=sum((F(2,(2*j+1)*3**(2*j+1)) for j in range(200)),F(0))
LN2=(lnlo,lnlo+F(2,401*3**401)*F(9,8))

def exp_interval(lo,hi,bits=240):
    assert 0<=lo<=hi
    S=1<<bits
    k=0
    while hi>F(1,8): lo/=2;hi/=2;k+=1
    xl=(lo*S).__floor__(); xu=ceilq(hi*S)
    tl=tu=S; sl=su=S
    # Outward-rounded Taylor terms; after 96 terms ratio to next <=1/2.
    for j in range(1,97):
        tl=tl*xl//(S*j);tu=(tu*xu+S*j-1)//(S*j)
        sl+=tl;su+=tu
    nextu=(tu*xu+S*97-1)//(S*97)
    su+=2*nextu
    for _ in range(k): sl=sl*sl//S;su=(su*su+S-1)//S
    return F(sl,S),F(su,S)

def rne_integer(x):
    s=-1 if x<0 else 1;x=abs(x);q,r=divmod(x.numerator,x.denominator)
    return s*(q+int(2*r>x.denominator or (2*r==x.denominator and q%2)))
def rne_float(x,p):
    if x==0:return F(0)
    s=-1 if x<0 else 1;x=abs(x)
    e=x.numerator.bit_length()-x.denominator.bit_length()
    if x<F(2)**e:e-=1
    step=F(2)**(e-p)
    return s*rne_integer(x/step)*step

def prime(n):return n>=2 and all(n%d for d in range(2,isqrt(n)+1))
def pad(m):
    N=1<<m;M=m+2
    while not prime(M):M+=1
    K=(4*N+M-1)//M;ps=[d for d in range(2,M) if prime(d)]
    tries=0
    while any(K%d==0 for d in ps):K+=1;tries+=1
    return M,K,M*K,tries

def width(m):
    lo=F(2*m,3)*LN2[0]/PI[1];hi=F(2*m,3)*LN2[1]/PI[0]
    assert ceilq(lo)==ceilq(hi)
    return max(12,ceilq(lo))

# Exact IEEE-style nearest-even property on rational inputs and many binades.
round_cases=0
for p in range(2,15):
 for e in range(-6,7):
  for j in range(-40,41):
   x=F(j,13)*F(2)**e
   y=rne_float(x,p)
   assert abs(y-x)<=F(1,1<<p)*abs(x) if x else y==0
   assert rne_float(-x,p)==-y
   round_cases+=1

collapse=[]
for m,p in [(12,8),(16,16),(20,24),(24,32),(28,40),(32,52),(40,52),(64,52),(128,52)]:
 N=1<<m;M,K,Q,tries=pad(m);L=width(m)
 lam=(PI[0]*L/Q**2,PI[1]*L/Q**2)
 alo,ahi=exp_interval(*lam)
 left,right=rne_float(alo,p),rne_float(ahi,p)
 assert left==right==1
 assert lam[1]<=F(1,1<<(p+2))
 assert 4*N<=Q<=8*N and K>=M
 # On last-quarter input, transformed-input DC gap / ||x||2 > 1/64.
 lower=F(1,2)*F(9,265)
 assert lower>F(1,64)
 collapse.append(dict(m=m,N=N,M=M,K=K,Q=Q,L=L,p=p,padding_trials=tries,
   certified_base_rne="1",lambda_upper=str(lam[1]),
   symbolic_dc_gap_lower=str(lower),no_dense_allocation=True))

# Full recurrence execution for bounded plans, every coordinate.
# Each result is compared to rigorous exponential enclosures, not binary64.
recurrence=[]; coords=0; normalized_coords=0
for m in range(6,11):
 N=1<<m;M,K,Q,_=pad(m);L=width(m)
 lam=(PI[0]*L/Q**2,PI[1]*L/Q**2)
 for extra in (0,8):
  p=ceilq(F(7*m,3))+extra
  lo,hi=exp_interval(*lam)
  aa=rne_float(lo,p);assert aa==rne_float(hi,p)
  bb=rne_float(aa*aa,p);w=F(1);ratio=aa;u=F(1,1<<p)
  scale=1<<240;sq=isqrt(L*scale*scale)
  sqrtlo=F(sq,scale);sqrthi=F(sq+1,scale)
  gamma=rne_float(1/sqrthi,p);assert gamma==rne_float(1/sqrtlo,p)
  assert max(abs(gamma*sqrtlo-1),abs(gamma*sqrthi-1))<=u
  worst=F(0)
  for r in range(N//2+1):
   elo,ehi=exp_interval(lam[0]*r*r,lam[1]*r*r)
   err=max(abs(w/elo-1),abs(w/ehi-1))
   # (1-u)^(2r²) <= implemented/exact <= (1+u)^(2r²).
   # Use a weaker rational exp bound exp(T)-1 <= T/(1-T).
   T=F(2*r*r)*u/(1-u)
   assert T<1 and err<=T/(1-T)
   if extra==8:
    # N^(-1/3) >= 2^(-ceil(m/3)); use this stronger rational target.
    target=F(1,64*(1<<ceilq(F(m,3))))
    assert err<=target
   # Include both the certified normalizer and final rounded product.
   gg=rne_float(w*gamma,p)
   glo=elo/sqrthi;ghi=ehi/sqrtlo
   gerr=max(abs(gg/glo-1),abs(gg/ghi-1))
   Tg=F(2*r*r+2)*u/(1-u)
   assert Tg<1 and gerr<=Tg/(1-Tg)
   if extra==8: assert gerr<=target
   normalized_coords+=1
   worst=max(worst,err,gerr);coords+=1
   if r<N//2:
    w=rne_float(w*ratio,p);ratio=rne_float(ratio*bb,p)
  recurrence.append(dict(m=m,N=N,Q=Q,L=L,p=p,coordinates=N//2+1,
      extra_guard_bits=extra,worst_relative_error_upper=float(worst),
      all_bounds_exact=True))

# Scalar failure at representable moderate size, checked with exact intervals.
# With collapsed a, every generated dimensionless weight is exactly one.
N=4096;M,K,Q,_=pad(12);L=12;p=8
lo,hi=exp_interval(PI[0]*L/Q**2,PI[1]*L/Q**2)
a=rne_float(lo,p);assert a==rne_float(hi,p)==1
r=N//2;elo,ehi=exp_interval(PI[0]*L*r*r/Q**2,PI[1]*L*r*r/Q**2)
assert 1-F(1,1)/elo>F(1,4)

out={"status":"PASS","exact_arithmetic":True,"historical_programs_executed":False,
 "rounding_cases":round_cases,"collapse_cases":collapse,
 "recurrence_coordinate_checks":coords,"normalized_preweight_checks":normalized_coords,"recurrence_cases":recurrence,
 "moderate_collapsed_endpoint_relative_error_lower":float(1-1/elo),
 "interpretation":"Exact finite controls check the new lemmas; the all-length/high-probability claim uses the stated analytic proof and inherited ideal theorem, not enumeration."}
(HERE/'FRESH_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('collapse_cases','recurrence_cases')},indent=2))
