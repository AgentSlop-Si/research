# Primary-source comparison for the F016 preparation gate

Checked 2026-10-12. Read the Gaussian all-length audit and P05_ACCEPTED §S6 as inert text; no submitted implementation was executed. The conclusions below distinguish published results, the local S6 transfer, and new deductions from those contracts.

## Decision

The relevant next question for Gaussian-padded F016 is a fully charged finite-word preparation/stability theorem. Its ideal-arithmetic O(N log log N) weak-error headline is already weaker in runtime than local S6's HIKP-based O(N) all-length dense-output corollary. Neither primary sparse-Fourier source supplies a finite-word certificate for Gaussian/Green F016. NSW's arbitrary-length and pointwise guarantee is relevant prior art, but its sample bound must not be called its runtime.

## Common target and normalization

Use U_N x[k] = N^(-1/2) sum_j x[j] exp(-2πijk/N). The F016 target is, for fixed 0<α<1/2 and c>0, all N entries of y with

    ||y-U_N x||∞ ≤ C_α N^(-α)||x||₂,
    Pr(success) ≥ 1-N^(-c),

for each fixed input independent of the fresh random choices. This is an absolute all-bin bound relative to total input energy. It is neither binwise relative accuracy nor a small relative-l2 error: the direct implication is only ||error||₂ ≤ C_α N^(1/2-α)||x||₂. All N writes cost Ω(N), regardless of sparse intermediate output. Changing the Fourier sign merely permutes frequency indices, preserving these norms and costs.

## Published HIKP contract (source summary)

Hassanieh–Indyk–Katabi–Price, *Simple and Practical Algorithm for Sparse Fourier Transform*, §4.2, Theorem 4.4: for dyadic n, its unnormalized positive-sign spectrum X and top-k set S, the output obeys

    ||X'-X||∞² ≤ (ε/k)||X-X_S||₂² + δ²||X||₁²

with probability 1-1/n, in O(sqrt(n k log(n/δ)/ε) log n) arithmetic work. Lemma 4.3 gives candidate support at most 2dkn/B, where d=O(1/ε) and B is chosen near sqrt(nk/(ε log(n/δ))). Do not label this output k-sparse. The sublinear parameter regime requires B=Ω(k/ε); outside it the paper falls back to FFT. Its general-length discussion after Lemma 3.6 predicts a totient loss, whereas the displayed binning primitive requires B|n. Its filter-tolerance parameter is not a machine-roundoff theorem.

Primary: https://people.csail.mit.edu/haitham/Papers/sFFT.pdf (PDF pages 4, 8–9).

## HIKP normalization deduction and S6 resource comparison

Set z=X/sqrt(n) and z'=X'/sqrt(n). Dividing the displayed squared inequality by n gives exactly

    ||z'-z||∞² ≤ (ε/k)||z-z_S||₂² + δ²||z||₁².

Parseval and ||z||₁≤sqrt(n)||z||₂ imply the conservative bound

    ||z'-z||∞ ≤ (sqrt(ε/k)+sqrt(n)δ)||x||₂.

This validates S6 equation (6.1); no stronger introductory convention is needed.

The local S6 transfer chooses α<β<1/2, dyadic M≈N, k≈M^(2β), and δ=M^(-D). Its sparse work and support are O(M^(1/2+β) polylog M)=o(N). A centered, truncated interpolation has O(log N) l∞ amplification, so the sparse error becomes O(log N·M^(-β))||x||₂ = O(N^(-α))||x||₂. Sparse scatter touches only O(S log N) incidences. Reading x, initializing/writing N outputs, and constant-repeat coordinate medians cost O(N). Thus local S6 is O_{α,c}(N) work and memory, explicitly including dense output. This remains an inherited ideal sparse-engine arithmetic contract. S6 separately bounds its interpolation coefficient approximation, but does not certify sparse-engine arithmetic or accumulation roundoff. It does not cover α=1/2.

## Published Nakos–Song–Wang contract (source summary)

Nakos–Song–Wang (2019), Theorem 1.1, Appendix A and Theorem A.16, use a unitary positive-sign transform. They return O(k)-sparse y satisfying

    ||X-y||∞ ≤ ||X-X_k||₂/sqrt(k)

with probability 1-1/poly(n), for arbitrary integer side length (d=1 covers every n). Sample complexity is O(k log k log n); formal runtime is O(n log³n log k). Appendix A assumes supplied μ≈||X-X_k||₂/sqrt(k) and R*≥||X||∞/μ with log R*=O(log n); constant-factor μ knowledge suffices. §1.5 explicitly treats FFT rounding error as negligible. The printed A.16 definition has 1/k rather than 1/sqrt(k); Appendix A's opening and Algorithm 3 consistently give the latter, so this inconsistency must not silently become a new normalization.

Primary: https://arxiv.org/html/1909.11123 (§1.1, §1.5, Appendix A, Algorithm 3, Theorem A.16); PDF: https://arxiv.org/pdf/1909.11123 .

## NSW comparison deductions

Taking k≈N^(2α) converts its guarantee to the F016 weak tolerance under the stated premises. Then samples are O(N^(2α) log²N), whereas formal decoding time is O_α(N log⁴N). Materializing its sparse answer adds O(N+k) operations and N output words, without reducing decoding time. The sparse representation by itself occupies O(k) entries; do not mistake that for a bound on all workspace.

A supplied tail estimate and polynomial dynamic range are additional interfaces relative to F016's fixed arbitrary-input contract. Exactly sparse nonzero spectra have zero tail, so their treatment cannot be inferred by substituting μ=0 into this algorithm. A norm-based threshold adaptation might avoid that issue for F016's weaker target, but it would be a separately proved adaptation. NSW therefore does not, by its displayed theorem alone, establish an unconditional O(N) dense-output replacement or a finite-word implementation.

## Gaussian F016 model and finite-word acceptance gate

The existing Gaussian audit establishes O_{α,c}(N log log N) work and O_{α,c}(N) memory with exact complex arithmetic, supplied length-dependent exponential/root bases, O(log N)-bit integer operations, and a stated fresh-randomness contract. It charges N outputs, long K-point transform via ordinary FFT reduction, short convolutions, and rough padding. It also supplies a bounded fair-bit sampler repair with explicit abort probability. Those are genuine model specifications, not a proof for complex128.

For a finite-word theorem, preparation must give all of the following:

1. Input mantissa/exponent and target accuracy contracts; exact integer widths for phase reduction, chirp products, and addresses; an explicit word-operation versus bit-operation cost model.
2. Charged algorithms for roots, normalizers, Gaussian preweights and filter taps. Exact supplied transcendental constants must be removed or retained as an explicitly separate input assumption.
3. Certified coefficient errors and propagation through preweighting, Green solve/scan, compression, long FFT, short convolution, centering and medians, with a total deterministic numerical error at most a fixed share of N^(-α)||x||₂.
4. A bounded randomness implementation and abort accounting; fixed PRNG seeds do not satisfy the independent-fresh-randomness quantifier.
5. Every setup operation, table entry, read, write and temporary charged, including first use. State whether cached setup is amortized.

Polynomially bounded coefficient magnitudes alone do not establish stable recurrences or mantissa accuracy. In particular, invoking a generic polylog(N)-cost transcendental routine separately for Θ(N) preweights gives only N·polylog(N), potentially exceeding the claimed N log log N preparation budget. Conversely, S6's o(N) sparse incidences can absorb a fixed polylogarithmic per-incidence preparation cost. This asymmetry is why coefficient preparation is a substantive F016 gate even though the ideal weak-error headline is no longer distinctive.
