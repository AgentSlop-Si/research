# Gaussian coefficient precision candidate

Read REPORT.md first. It proves a base-collapse obstruction and a sufficient centered-recurrence precision bound for one F016 coefficient-preparation gate. Existing ideal Gaussian and HIKP/S6 theorems are preserved.

- REPORT.md: exact lemmas, scope, finite-word and full-output ledger, next priority 54/100.
- fresh_precision_checks.py / FRESH_RESULTS.json: new exact arithmetic tests.
- primary_comparison.md: primary-source norm/model comparison.
- SOURCE_BINDINGS.json: source hashes, immutable/current record links and selected gate.
- sources/current_hikp_admitted_backend.md: read-only current backend review context.

Candidate status only; independent proof review remains required. No historical executable was run.
