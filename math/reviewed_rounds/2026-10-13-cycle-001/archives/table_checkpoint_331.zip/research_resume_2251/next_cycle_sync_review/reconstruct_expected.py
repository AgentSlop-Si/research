"""Reconstruct expected current state from a frozen native baseline and explicit edits.

The pre-existing user permutation is applied by stable ID before current edits.
This does not use final live reads to infer expected values.
"""
import copy
import json
from pathlib import Path
P=Path(__file__).resolve().parents[1]
D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
colnum=lambda s:sum((ord(c)-64)*26**i for i,c in enumerate(s[::-1]))
sheets={s['title']:copy.deepcopy(s) for s in read(P/'live_final_full_values.json')}
permutation=read(P/'next_cycle_table_b/CURRENT_IDENTITY_ROW_MAP.json')['novelity breakthough']
s=sheets['novelity breakthough']
byid={r[2]:r for r in s['values'][5:]}
assert set(byid)==set(permutation)
s['values']=s['values'][:5]+[byid[rid] for rid,row in sorted(permutation.items(),key=lambda x:x[1])]
for edit in read(D/'ROOT_MUTATIONS.json'):
    sheet=sheets[edit['sheet']]
    row=edit['row']-1
    col=edit['column']-1 if isinstance(edit['column'],int) else colnum(edit['column'])-1
    while len(sheet['values'])<=row:sheet['values'].append([])
    while len(sheet['values'][row])<=col:sheet['values'][row].append('')
    sheet['values'][row][col]=edit['value']
specs={'Catalogue':(3,0,26),'novelity breakthough':(5,2,20),'Research overview':(4,1,11),'Incoming queue':(3,0,6),'Next cycle':(3,0,6)}
records={}
for title,(h,idx,c) in specs.items():
    for rn,row in enumerate(sheets[title]['values'][h:],h+1):
        if len(row)<=idx or not row[idx]:continue
        rid=row[idx]
        values=copy.deepcopy(row[c:c+6])
        if values and isinstance(values[0],str) and values[0].isdigit():values[0]=int(values[0])
        records.setdefault(rid,{'record_id':rid,'values':values,'source_rows':[],'overlay_views':[]})
        records[rid]['overlay_views'].append({'sheet':title,'row':rn,'values':values})
for title,s in sheets.items():
    if title=='Progress':continue
    h=s['header_row'];idx=specs.get(title,(h,0))[1]
    for rn,row in enumerate(s['values'][h:],h+1):
        if len(row)<=idx:continue
        rid=row[idx]
        if rid not in records:continue
        records[rid]['source_rows'].append({'sheet':title,'row':rn,'url':f'https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit#gid={s["sheet_id"]}&range=A{rn}',
                                          'identity_column':'C' if idx==2 else 'B' if idx==1 else 'A','verified_id':rid})
frozen={r['record_id']:r for r in read(D/'FROZEN_BASE_CHECKPOINT.json')['records']}
frozen.update({r['record_id']:r for r in read(D/'FROZEN_WORKFLOW_CHECKPOINT.json')})
canon={r['record_id'] for r in read(P/'ranking/canonical_178_ranked.json')}
parents={'NEXT-PREFIX-P13':'NEW-16','NEXT-RS-RESIDUAL-B27':'F020','NEXT-PREFIX-TWO-PRIME':'NEW-16','NEXT-RS-RESIDUAL-B29':'F020'}
for rid,r in records.items():
    r['canonical_counted']=rid in canon
    r['record_kind']='canonical_claim' if rid in canon else 'bounded_workflow_task' if rid in parents else 'supplemental_or_scoped_view'
    if rid in parents:r['parent_id']=parents[rid]
    if rid in frozen:
        r['frozen_prior_values']=frozen[rid]['values']
        r['historical_source_rows']=frozen[rid].get('source_rows',[])
        r['historical_source_time_scope']='Frozen previous checkpoint; older row addresses and pending-intake aliases are historical only.'
mapping={'headers':read(D/'FROZEN_BASE_CHECKPOINT.json')['headers'],
         'scope':'Current state reconstructed from frozen native baseline, user row permutation, and explicit ordered root mutation inventory. Awaiting independent live verification.',
         'records':list(records.values())}
(D/'EXPECTED_FULL_VALUES.json').write_text(json.dumps(list(sheets.values()),indent=2,ensure_ascii=False))
(D/'CURRENT_EXPECTED_MAPPING.json').write_text(json.dumps(mapping,indent=2,ensure_ascii=False))
print(json.dumps({'expected_ids':len(records),'expected_canonical':sum(r['canonical_counted'] for r in records.values()),'source_locators':sum(len(r['source_rows']) for r in records.values())},indent=2))
