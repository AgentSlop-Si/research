import json
import hashlib
from pathlib import Path

P=Path(__file__).resolve().parents[1]
D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={s:read(D/('target_'+s.lower().replace(' ','_')+'.json'))['structuredContent']['values'] for s in ['Research queue','Theorem register','New results']}
stamp='[2026-10-12 23:49 UTC; independently accepted bounded rank-two executor]'
chirp=("Independent scoped ACCEPT for the supplied-root standalone rank<=2 common-chirp executor: 3<=N<=512, supplied prime 5<=p<=65537, N divides p-1, a supplied root verified to have exact order N, and N canonical field residues. Zero and at most two distinct nonzero exponential modes under one common quadratic chirp are covered. MEMBER returns one fully verified canonical-phase witness and all positive-sign unnormalized DFT outputs; NONMEMBER exhausts this complete bounded family. INVALID and indeterminate LIMIT remain distinct; LIMIT withholds all mathematical outputs. This is implementation/accounting progress using the accepted CHIRP theorem and classical Prony/Gauss ingredients.")
chirp_next=("The specifically declared supplied-root bounded rank-two structural acquisition/execution gate is complete. Choose a separately scoped paid optional root-search front end or a source-pinned caller/dispatcher integration. Growing-rank acquisition, general min(B,H), optimized blocked/Toeplitz kernels, broader domains, bit/numerical/physical/CPU costs and matched FFT performance remain separate open requirements. The earlier rank-one optional-root-search interface remains independently accepted in its own domain; it is not automatically inherited by rank two. Do not retire the full Q13/STR-Q2 research gate or repeat the completed bounded executor.")
chirp_cost=("Final rank-two program SHA256 efc0b42360c1433fd1bf5da8f61f795a5d80ebedd592f3cba877dd9eca0690a8. Resident exact built-in record with supplied checked root; optional root discovery and legacy dispatcher integration are absent. Field arithmetic is O(N+log p), including inverse internals; complete named exact-field/data work is O(N+sqrt(p)+log p), including primality trials. Default live field arrays use O(N); optional diagnostics use O(named work). Bootstrap, Python/container/loop bookkeeping, bit/CPU/physical-memory costs are disclosed exclusions. Every attempted candidate, full verification and final publication is charged; a finite cap need not complete.")
chirp_evidence=("Independent review next_cycle_chirp_review/INDEPENDENT_REVIEW.md, SHA256 "+sha(P/'next_cycle_chirp_review/INDEPENDENT_REVIEW.md')+". Reviewed final program SHA256 efc0b42360c1433fd1bf5da8f61f795a5d80ebedd592f3cba877dd9eca0690a8; contract SHA256 5c1309efb97c2002ef4e2d06491629ac9f746f8e601fef239a4be92d63d5ce3d. Fresh independent checks: 1,296 complete decisions; 17,814 direct-DFT coordinates; 130 exact per-stage ledger predictions; 4,475 cutoff runs across three suites, including N512/p65537 final publication. Isolated cold replay reproduces all three JSON result files byte-identically. Existing broader theorem, rank-one, source-comparison and historical-priority boundaries are unchanged.")
prefix_stamp='[2026-10-12 23:49 UTC; independently accepted p13 residue-one PREFIX slice]'
prefix=("Independent project ACCEPT for G=D8 x C13 x Cr, with D8 of order 8, prime r>13 and r congruent to 1 modulo 104: unrestricted prefix maximum 356r-104 and sharp full-escape maximum 330r-104, deficit 26r. The reviewed compatibility graph has weighted independent-set maximum at most 226r-103 for r=104t+1, every integer t>=9; independently checked prime bases r=313 and 521 complete this residue. The group corollary retains the accepted group-to-graph and proper-subgroup bounds explicitly. The separate finite p13,r17 maximum5948/full-escape5506 and earlier p3,p5,p7,p11 families remain accepted. This review does not accept the other 47 residue classes or new optimizer/count classification.")
prefix_next=("NEW-16 remains progressed/open. NEXT-PREFIX-P13 is the dedicated bounded workflow for the full p13 family. Residue 1 modulo104 is accepted; independently prove and review the remaining 47 prime-compatible residue classes, with complete finite bases and inherited group-to-graph assumptions explicit. The producer's supplementary rho3/103 cones are not accepted by the residue-one review. Both-prime-variable matching bounds, full-escape optimizer classification/counts, broader nonabelian and nilpotent groups, EFK body/equality comparison and historical priority remain open. No rank, canonical-count, novelty or Fourier-speed promotion follows.")
prefix_evidence=("Independent residue-one review next_cycle_management/PREFIX_INDEPENDENT_REVIEW.md, SHA256 "+sha(P/'next_cycle_management/PREFIX_INDEPENDENT_REVIEW.md')+". Pinned cone certificate SHA256 97a52ea64a5bc3dda4a5c3866aaa212974189c6f3fafa70ee65e97be33fd80f8. The independent checker reconstructs transitions and replays 27,651 affine rows and 138,255 coefficient inequalities; prime-base graph optima are 70,635 at313 and117,643 at521. Three certificate mutations are rejected. Group-attaining orders and the inherited subgroup substitution are checked; earlier proof archives are not newly replayed. Only rho=1 is accepted by this review.")

changes=[]
def add(sheet,rid,col,prefix,body):
    rows=sources[sheet]
    hits=[(i,r) for i,r in enumerate(rows,1) if r and r[0]==rid]
    assert len(hits)==1,(sheet,rid)
    rownum,row=hits[0]; idx=ord(col)-65
    old=row[idx] if len(row)>idx else ''
    changes.append({'record_id':rid,'sheet':sheet,'range':f"'{sheet}'!{col}{rownum}",'row':rownum,'column':col,'column_title':rows[2][idx],
                    'expected_before':old,'proposed_value':prefix+'\n'+body+'\n\nEarlier dated history (preserved verbatim):\n'+old,
                    'history_preserved_verbatim':True,'source_read':str((D/('target_'+sheet.lower().replace(' ','_')+'.json')).relative_to(P))})
add('Research queue','Q13','C',stamp,'The bounded supplied-root rank<=2 standalone structural acquisition and full-output named-event executor is independently accepted. Q13/STR-Q2 remains open only for separately specified broader integration, root-discovery, general-rank or cost-model work. Earlier accepted rank-one and other interfaces retain their own scope.')
add('Research queue','Q13','E',stamp,chirp)
add('Research queue','Q13','F',stamp,chirp_next)
add('Research queue','Q13','J',stamp,chirp_cost)
add('Research queue','Q13','L',stamp,chirp_evidence)
add('Theorem register','C06','F',stamp,chirp+' '+chirp_cost)
add('Theorem register','C06','G',stamp,chirp_next)
add('Theorem register','C06','J',stamp,chirp_evidence)
add('New results','NEW-16','D',prefix_stamp,prefix)
add('New results','NEW-16','E',prefix_stamp,prefix_next)
add('New results','NEW-16','G',prefix_stamp,'NEXT-PREFIX-P13 is the dedicated bounded workflow for the remaining p13 prime-compatible residue classes; NEW-16 remains the result anchor. Unrelated SCHUR-V28 and SPARSE-PREFIX scopes are unchanged.')
add('New results','NEW-16','H',prefix_stamp,prefix_evidence)
result={'status':'PROPOSED_ONLY_NO_EXTERNAL_WRITES','fresh_reads':'Native UNFORMATTED_VALUE reads at 2026-10-12 23:49 UTC before final stable marker; final audit still pending.',
        'notes':['No separate STR-Q2, ALG-CHIRP-ELIM, or NEW-16 identity occurs in Research queue or Theorem register; Q13 and C06 are the matching records there. NEW-16 is anchored in New results row19.',
                 'All changes prepend current evidence and preserve every earlier character verbatim. The proof-closed label and original general theorem statement are unchanged.'],
        'sheet_changes':changes}
(D/'SUPPLEMENTAL_SCOPE_DELTAS_12.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))

ids=read(P/'next_cycle_table_b/CURRENT_IDENTITY_ROW_MAP.json')
gids={s['title']:s['sheet_id'] for s in read(P/'live_final_full_values.json')}
frozen=read(P/'sheet_frozen_v1_baseline.json')
locators=[]
for rid in ['QTORUS-CONNECTED-MINOR-20261013','PR622-REPACKING-CANDIDATE-20261013','Q2-DENSE-TORUS-20261013']:
    before=next(r['source_rows'] for r in frozen['records'] if r['record_id']==rid)
    current=[{'sheet':s,'row':ids[s][rid],'url':f'https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit#gid={gids[s]}&range=A{ids[s][rid]}','identity_column':'B' if s=='Research overview' else 'A','verified_live_id':rid} for s in ['Incoming queue','Research overview']]
    locators.append({'record_id':rid,'historical_snapshot_source_rows':before,'current_identity_resolved_source_rows':current,'historical_alias_time_scope':'Old pending-intake placeholder retained as historical provenance only; not a current source locator.'})
(D/'CURRENT_INTAKE_LOCATOR_REPAIRS_3.json').write_text(json.dumps(locators,ensure_ascii=False,indent=2))
rec=read(D/'RECONCILIATION_329.json')
for r in rec:
    fix=next((x for x in locators if x['record_id']==r['record_id']),None)
    if fix:r['current_source_rows']=fix['current_identity_resolved_source_rows'];r['historical_snapshot_source_rows']=fix['historical_snapshot_source_rows']
(D/'RECONCILIATION_329_CURRENT_LOCATORS.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2))
print(json.dumps({'proposed_scope_cells':len(changes),'historical_preservation':all(x['proposed_value'].endswith(x['expected_before']) for x in changes),'intake_locator_records':len(locators),'external_writes':False},indent=2))
