"""Read-only full-cycle identity, edit-scope and source-locator reconciliation."""
import collections
import hashlib
import json
import re
from pathlib import Path

P = Path(__file__).resolve().parents[1]
D = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
A = read(P / 'next_cycle_table_a/COVERAGE_LEDGER_164_LIVE_LOCATORS.json')
B = read(P / 'next_cycle_table_b/ledger_live_rebound.json')
mapping = read(P / 'sheet_frozen_v1_baseline.json')
frozen = {r['record_id']: r for r in mapping['records']}
workflow = read(P / 'new_workflow_tasks_delta.json')
identities = read(P / 'next_cycle_table_b/CURRENT_IDENTITY_ROW_MAP.json')
gid = {s['title']: s['sheet_id'] for s in read(P / 'live_final_full_values.json')}
records = []
errors = []
source_count = 0
for lane, recs in [('A', A['records']), ('B', B['records'])]:
    for r in recs:
        rid = r['record_id']
        locators = r.get('current_identity_resolved_source_rows', r.get('current_live_source_rows', []))
        for s in locators:
            source_count += 1
            if s['sheet'] not in gid:
                errors.append(['current_locator_is_nonexistent_tab', rid, s])
                continue
            if identities.get(s['sheet'], {}).get(rid) != s['row']:
                errors.append(['source_identity_mismatch', rid, s])
            if f'gid={gid[s["sheet"]]}' not in s['url']:
                errors.append(['source_gid_mismatch', rid, s])
            if not re.search(r'&range=[A-Z]+' + str(s['row']) + r'(?:$|[^0-9])', s['url']):
                errors.append(['source_url_row_mismatch', rid, s])
        score = r.get('frozen_priority', r.get('priority_1_100_preserved'))
        if rid not in frozen or frozen[rid]['values'][0] != score:
            errors.append(['frozen_score_mismatch', rid, score])
        records.append({'record_id': rid, 'lane': lane, 'canonical_counted': r['canonical_counted'],
                        'frozen_score': score, 'current_source_rows': locators,
                        'review_boundary': 'Full-table source/current-field consistency; no new mathematical proof acceptance.'})
for r in workflow:
    records.append({'record_id': r['record_id'], 'lane': 'B_workflow', 'canonical_counted': False,
                    'parent_id': r['parent_id'], 'frozen_score': r['values'][0],
                    'review_boundary': 'Separate bounded task; no canonical count increment.'})
counts = collections.Counter(r['record_id'] for r in records)
expected = set(frozen) | {r['record_id'] for r in workflow}
if len(records) != 329 or set(counts) != expected or any(n != 1 for n in counts.values()):
    errors.append(['329_ID_reconciliation', len(records), sorted(set(counts) - expected), sorted(expected - set(counts))])
if sum(r['canonical_counted'] for r in records) != 178:
    errors.append(['canonical_count', sum(r['canonical_counted'] for r in records)])
canonical_expected = {r['record_id'] for r in read(P / 'ranking/canonical_178_ranked.json')}
canonical_actual = {r['record_id'] for r in records if r['canonical_counted']}
if canonical_actual != canonical_expected:
    errors.append(['canonical_membership_mismatch', sorted(canonical_actual - canonical_expected), sorted(canonical_expected - canonical_actual)])
case_groups = collections.defaultdict(list)
for rid in expected:
    case_groups[rid.casefold()].append(rid)
if any(len(v) > 1 for v in case_groups.values()):
    errors.append(['case_ambiguous_ids', [v for v in case_groups.values() if len(v) > 1]])
parents = {'NEXT-PREFIX-P13': 'NEW-16', 'NEXT-RS-RESIDUAL-B27': 'F020'}
for r in workflow:
    if r['parent_id'] != parents[r['record_id']]:
        errors.append(['workflow_parent_mismatch', r['record_id'], r['parent_id']])

targets = {}
repair_ids = []
evidence_count = 0
for lane, fn in [('A', 'PROPOSED_ACTION_REPAIRS_77_LIVE_REBOUND.json'), ('B', 'PROPOSED_ACTION_REPAIRS_83_LIVE_REBOUND.json')]:
    repair = read(P / ('next_cycle_table_' + lane.lower()) / fn)
    for r in repair['repairs']:
        rid = r['record_id']
        repair_ids.append(rid)
        e = r['evidence']
        evidence_count += 1
        if identities.get(e['sheet'], {}).get(rid) != e['row']:
            errors.append(['repair_evidence_identity_mismatch', rid, e])
        if f'gid={gid[e["sheet"]]}' not in e['url']:
            errors.append(['repair_evidence_gid_mismatch', rid, e])
        for t in r['targets']:
            if identities.get(t['sheet'], {}).get(rid) != t['row']:
                errors.append(['target_identity_mismatch', rid, t])
            if t.get('verified_live_id') != rid:
                errors.append(['target_verified_ID_mismatch', rid, t])
            col = re.search(r'!([A-Z]+)[0-9]+$', t['a1']).group(1)
            allowed = {'Catalogue': ['AE', 'AF'], 'novelity breakthough': ['Y', 'Z'], 'Research overview': ['P', 'Q'], 'Next cycle': ['K', 'L'], 'Incoming queue': ['K', 'L']}
            if col not in allowed.get(t['sheet'], []):
                errors.append(['historical_or_non_action_target', rid, t])
            key = (t['sheet'], t['row'], col)
            if key in targets:
                errors.append(['duplicate_target', key, rid, targets[key]['record_id']])
            targets[key] = {'record_id': rid, 'lane': lane, **t}

summary = {
    'status': 'PASS_PREFLIGHT_NOT_FINAL' if not errors else 'FAIL',
    'base_records': len(A['records']) + len(B['records']),
    'workflow_records': len(workflow), 'total_unique_records': len(counts),
    'canonical_count': sum(r['canonical_counted'] for r in records),
    'record_partition': dict(collections.Counter(r['lane'] for r in records)),
    'current_identity_locators_checked': source_count,
    'action_repair_records': len(repair_ids), 'action_repair_unique_IDs': len(set(repair_ids)),
    'action_target_cells': len(targets), 'action_evidence_locators_checked': evidence_count,
    'current_action_targets_only': True if not any(e[0] == 'historical_or_non_action_target' for e in errors) else False,
    'accepted_scope_protected_from_generic_repairs': sorted(set(repair_ids) & {'F020', 'Q08', 'Q13', 'STR-Q2', 'ALG-CHIRP-ELIM', 'C06', 'NEW-16', 'NEXT-PREFIX-P13', 'NEXT-RS-RESIDUAL-B27'}),
    'errors': errors,
    'notes': ['Final independent native readback must await the root stable marker.',
              'Stable identity, not physical row, is the preservation join key.',
              'Source availability is not proof validity or historical priority.'],
    'inputs': {str(p.relative_to(P)): sha(p) for p in [
        P / 'next_cycle_table_a/COVERAGE_LEDGER_164_LIVE_LOCATORS.json',
        P / 'next_cycle_table_b/ledger_live_rebound.json',
        P / 'sheet_frozen_v1_baseline.json', P / 'new_workflow_tasks_delta.json']}}
(D / 'PREFLIGHT_SUMMARY.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False))
(D / 'RECONCILIATION_329.json').write_text(json.dumps(records, indent=2, ensure_ascii=False))
(D / 'ACTION_TARGETS_870.json').write_text(json.dumps(list(targets.values()), indent=2, ensure_ascii=False))
print(json.dumps(summary, indent=2, ensure_ascii=False))
