"""Normalize explicitly supplied root mutation inventories, in application order."""
import json
import re
import sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
gid={s['sheet_id']:s['title'] for s in read(P/'live_final_full_values.json')}
out=[]
def scalar(cell):
    x=cell.get('userEnteredValue',cell.get('effectiveValue',{}))
    return x.get('stringValue',x.get('numberValue',x.get('boolValue',x.get('formulaValue',''))))
def record(sheet,row,col,value,source,extra=None):
    m={'sheet':sheet,'row':row,'column':col,'value':value,'source_inventory':source}
    if extra:m.update(extra)
    out.append(m)
for arg in sys.argv[1:]:
    file=Path(arg)
    if not file.exists():file=P/arg
    x=read(file); source=str(file.relative_to(P))
    if isinstance(x,dict) and 'edits' in x:
        for t in x['edits']:
            match=re.search(r'!([A-Z]+)([0-9]+)$',t['a1'])
            record(t['sheet'],int(match[2]),match[1],t['value'],source,{'record_id':t.get('id')})
    elif isinstance(x,dict) and 'sheet_changes' in x:
        for t in x['sheet_changes']:
            match=re.search(r'!([A-Z]+)([0-9]+)$',t.get('range',t.get('a1','')))
            record(t['sheet'],int(match[2]),match[1],t.get('proposed_value',t.get('new_value',t.get('value'))),source,{'record_id':t.get('record_id')})
    else:
        requests=x['requests'] if isinstance(x,dict) else x
        for req in requests:
            if 'updateCells' not in req:
                if 'copyPaste' in req and req['copyPaste'].get('pasteType')=='PASTE_FORMAT':continue
                if any(k in req for k in ['repeatCell','updateSheetProperties','setBasicFilter','autoResizeDimensions','updateDimensionProperties','addConditionalFormatRule','deleteConditionalFormatRule','updateBorders']):continue
                raise ValueError(('Unsupported mutation shape',req.keys(),source))
            up=req['updateCells']
            region=up.get('range',up.get('start'))
            sheet=gid[region['sheetId']]
            startrow=region.get('startRowIndex',region.get('rowIndex',0))
            startcol=region.get('startColumnIndex',region.get('columnIndex',0))
            for i,row in enumerate(up.get('rows',[])):
                for j,cell in enumerate(row.get('values',[])):
                    record(sheet,startrow+i+1,startcol+j+1,scalar(cell),source)
(D/'ROOT_MUTATIONS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'inventories':sys.argv[1:],'mutations_in_sequence':len(out)},indent=2))
