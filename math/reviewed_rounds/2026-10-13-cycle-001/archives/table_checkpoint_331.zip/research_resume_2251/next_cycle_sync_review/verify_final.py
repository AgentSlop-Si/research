"""Independent identity-resolved final Google Sheets consistency audit.

Inputs are independent native readbacks under native_final/ and root mutation
inventory in ROOT_MUTATIONS.json, normalized to sheet, row, column, value.
No external writes occur.
"""
import collections
import hashlib
import json
import re
import sys
from pathlib import Path

P = Path(__file__).resolve().parents[1]
D = Path(__file__).resolve().parent
partial='--partial' in sys.argv
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cols=lambda s:sum((ord(c)-64)*26**i for i,c in enumerate(s[::-1]))
norm=lambda v: '' if v is None else str(v).upper() if isinstance(v,bool) else str(v)
get=lambda row,j: row[j] if j<len(row) else ''
specs={'Catalogue':(3,0,26,178),'novelity breakthough':(5,2,20,216),
       'Research overview':(4,1,11,327),'Incoming queue':(3,0,6,42),'Next cycle':(3,0,6,12)}
base={s['title']:s for s in read(P/'live_final_full_values.json')}
live={}
for f in (D/'native_final').glob('*.json'):
    x=read(f)
    if 'title' in x and 'values' in x: live[x['title']]=x
frozen=read(D/'FROZEN_BASE_CHECKPOINT.json')
frozen_map={r['record_id']:r['values'] for r in frozen['records']}
workflow=read(P/'new_workflow_tasks_delta.json')
frozen_workflow=read(D/'FROZEN_WORKFLOW_CHECKPOINT.json')
frozen_map.update({r['record_id']:r['values'] for r in frozen_workflow})
final_mapping=read(D/'CURRENT_EXPECTED_MAPPING.json')
current_expected={r['record_id']:r['values'] for r in final_mapping['records']}
expected_views={(v['sheet'],v['row']):v['values'] for r in final_mapping['records'] for v in r['overlay_views']}
def current_part(v):
    if not isinstance(v,str):return v
    v=v.split('\n\nEarlier dated history (preserved verbatim):\n',1)[0]
    if v.startswith('[') and '\n' in v:v=v.split('\n',1)[1]
    return v
result={'scope':'329 original stable IDs plus 2 explicit successor workflows (331 total); full current-overlay and history-preservation reconciliation, no new mathematical proof acceptance.',
        'errors':[], 'warnings':[], 'scored_tabs':{},'cross_view_checks':0,'current_mapping_checks':0,
        'prior_score_comparisons':0,'current_score_changes':[],'historical_checks':0,'historical_changes':[], 'source_locator_checks':0,
        'mutation_checks':0,'mutation_mismatches':[]}
errors=result['errors']
observed=collections.defaultdict(list)
ids_by_tab={}
for title,s in live.items():
    if title in specs:h,idx,c,n=specs[title]
    else:h=base[title]['header_row'];idx=0
    rows=s['values'][h:]
    ids=collections.defaultdict(list)
    for i,r in enumerate(rows,h+1):
        rid=get(r,idx)
        if rid:ids[rid].append(i)
    ids_by_tab[title]=dict(ids)
    if title not in specs:continue
    if len(rows)!=n or len(ids)!=n or any(len(v)!=1 for v in ids.values()):errors.append([title,'count_or_duplicate',len(rows),len(ids)])
    head=s['values'][h-1][c:c+6]
    if head!=frozen['headers']:errors.append([title,'current_headers_mismatch',head])
    result['scored_tabs'][title]={'rows':len(rows),'unique_ids':len(ids),'expected':n}
    for rownum,r in enumerate(rows,h+1):
        rid=get(r,idx);values=[get(r,j) for j in range(c,c+6)]
        observed[rid].append({'sheet':title,'row':rownum,'values':values})
        if any(v=='' for v in values):errors.append([title,rownum,rid,'blank_overlay'])
        if type(values[0]) is not int or not 1<=values[0]<=100:errors.append([title,rownum,rid,'invalid_native_score',values[0]])
        result['prior_score_comparisons']+=1
        if rid not in frozen_map:
            if rid not in {'NEXT-PREFIX-TWO-PRIME','NEXT-RS-RESIDUAL-B29'}:errors.append([title,rownum,rid,'not_in_frozen_inventory'])
        elif values[0]!=frozen_map[rid][0]:result['current_score_changes'].append({'sheet':title,'row':rownum,'column':c+1,'record_id':rid,'old_score':frozen_map[rid][0],'current_score':values[0]})
        result['current_mapping_checks']+=6
        wanted=expected_views.get((title,rownum))
        if values!=wanted:errors.append([title,rownum,rid,'current_map_mismatch',values,wanted])
for rid,views in observed.items():
    result['cross_view_checks']+=max(0,len(views)-1)*6
    if any([current_part(x) for x in v['values']]!=[current_part(x) for x in views[0]['values']] for v in views[1:]):errors.append([rid,'cross_view_current_prefix_mismatch',views])
expected_ids=set(frozen_map)|{'NEXT-PREFIX-TWO-PRIME','NEXT-RS-RESIDUAL-B29'}
result['union_count']=len(observed)
overview_statuses=collections.Counter(get(r,4) for r in live['Research overview']['values'][4:])
result['overview_workflow_status_counts']=dict(overview_statuses)
if overview_statuses.get('CLOSED')!=(20 if partial else 21) or overview_statuses.get('TO RESEARCH')!=(307 if partial else 306):
    errors.append(['overview_status_count_mismatch',dict(overview_statuses)])
result['missing_ids']=sorted(expected_ids-set(observed));result['unexpected_ids']=sorted(set(observed)-expected_ids)
if len(observed)!=331 or result['missing_ids'] or result['unexpected_ids']:errors.append(['331_union_mismatch'])

mutations=read(D/'ROOT_MUTATIONS.json')
allowed={}
for m in mutations:
    col=m['column'] if isinstance(m['column'],int) else cols(m['column'])
    key=(m['sheet'],m['row'],col)
    allowed[key]=m
for key,m in allowed.items():
    sheet,row,col=key;actual=get(live[sheet]['values'][row-1],col-1)
    result['mutation_checks']+=1
    if norm(actual)!=norm(m['value']):result['mutation_mismatches'].append({'target':key,'actual':actual,'expected':m['value']})
if result['mutation_mismatches']:errors.append(['mutation_readback_mismatch',len(result['mutation_mismatches'])])
for change in result['current_score_changes']:
    key=(change['sheet'],change['row'],change['column'])
    if key not in allowed:errors.append(['uninventoried_current_priority_change',change])
result['frozen_base_checkpoint_preserved']=read(P/'sheet_frozen_v1_baseline.json')==frozen
if not result['frozen_base_checkpoint_preserved']:errors.append(['frozen_base_checkpoint_changed'])
result['previous_progress_checkpoint_preserved']=any(base['Progress']['values'][0][0]==v for row in live['Progress']['values'] for v in row)
if not result['previous_progress_checkpoint_preserved']:errors.append(['previous_progress_checkpoint_not_retained'])

result['canonical_id_set_preserved']=set(ids_by_tab.get('Catalogue',{}))=={r['record_id'] for r in read(P/'ranking/canonical_178_ranked.json')}
result['novelty_id_set_preserved']=set(ids_by_tab.get('novelity breakthough',{}))=={r['record_id'] for r in read(P/'ranking/novelty_216_ranked.json')}
if not result['canonical_id_set_preserved']:errors.append(['canonical_ID_set_changed'])
if not result['novelty_id_set_preserved']:errors.append(['novelty_ID_set_changed'])

# Original historical prefixes by stable record identity. Intro/header cells remain positional.
for title,s in base.items():
    if title not in live:errors.append([title,'missing_native_read']);continue
    h=s['header_row'];idx=specs.get(title,(h,0))[1]
    historical_width=specs[title][2] if title in specs else s['width']
    for i,row in enumerate(s['values'],1):
        target_row=i
        rid=get(row,idx)
        if i>h and title in specs:
            hits=ids_by_tab[title].get(rid,[])
            if len(hits)!=1:errors.append([title,i,rid,'history_identity_unresolved']);continue
            target_row=hits[0]
        for j,before in enumerate(row[:historical_width],1):
            result['historical_checks']+=1
            after=get(live[title]['values'][target_row-1],j-1)
            if norm(before)==norm(after):continue
            change={'sheet':title,'baseline_row':i,'current_row':target_row,'record_id':rid if i>h else None,'column':j,
                    'before':before,'after':after,'explicitly_inventoried':(title,target_row,j) in allowed,
                    'old_text_preserved_verbatim':isinstance(before,str) and isinstance(after,str) and before in after}
            result['historical_changes'].append(change)
            if not change['explicitly_inventoried']:errors.append([title,target_row,j,'uninventoried_historical_change'])
            elif before and not change['old_text_preserved_verbatim'] and (title,target_row,j)!=("Progress",1,1):
                result['warnings'].append([title,target_row,j,'inventoried_historical_text_replaced_not_appended'])

# Preserve the user's already-observed new novelty order, not frozen physical rows.
order_expected=read(P/'next_cycle_table_b/CURRENT_IDENTITY_ROW_MAP.json')['novelity breakthough']
novel_ids=[get(r,2) for r in live['novelity breakthough']['values'][5:]]
expected_order=[rid for rid,rn in sorted(order_expected.items(),key=lambda kv:kv[1])]
result['user_novelty_order_preserved']=novel_ids==expected_order
if not result['user_novelty_order_preserved']:errors.append(['user_novelty_order_changed'])
base_pos={get(r,2):i for i,r in enumerate(base['novelity breakthough']['values'][5:],6)}
result['novelty_rows_moved_from_frozen']=sum(base_pos[rid]!=i for i,rid in enumerate(novel_ids,6))

# Check active source maps against final IDs. Historical maps are not silently rewritten.
for rec in final_mapping['records']:
    rid=rec['record_id']
    for loc in rec['source_rows']:
        result['source_locator_checks']+=1
        title=loc['sheet'];row=loc['row']
        if title not in live or row not in ids_by_tab[title].get(rid,[]):errors.append([rid,'current_source_locator_mismatch',loc])
        elif f'gid={base[title]["sheet_id"]}' not in loc['url']:errors.append([rid,'current_source_gid_mismatch',loc])

records=[]
rec_meta={r['record_id']:r for r in final_mapping['records']}
lane_meta={r['record_id']:r for r in read(D/'RECONCILIATION_329_CURRENT_LOCATORS.json')}
for rid in sorted(observed):
    records.append({'record_id':rid,'frozen_priority':frozen_map[rid][0] if rid in frozen_map else None,
                    'canonical_counted':rec_meta[rid]['canonical_counted'],'record_kind':rec_meta[rid]['record_kind'],
                    'parent_id':rec_meta[rid].get('parent_id'),'current_source_rows':rec_meta[rid]['source_rows'],
                    'breadth_ledger_lane':lane_meta.get(rid,{}).get('lane','new_explicit_successor_workflow'),
                    'current_values':[current_part(x) for x in observed[rid][0]['values']],'views':observed[rid],
                    'review_scope':'Full current-field, source-identity and historical-preservation audit; scientific acceptance attributed to named source reviews.'})
result['source_hashes']={str(p.relative_to(P)):sha(p) for p in [P/'sheet_frozen_v1_baseline.json',D/'CURRENT_EXPECTED_MAPPING.json',D/'FROZEN_WORKFLOW_CHECKPOINT.json',D/'ROOT_MUTATIONS.json']}
result['full_reconstructed_cell_checks']=0
result['full_reconstruction_mismatches']=[]
for exp in read(D/'EXPECTED_FULL_VALUES.json'):
    title=exp['title'];actual=live[title]['values'];expected_rows=exp['values']
    for i in range(max(len(actual),len(expected_rows))):
        erow=expected_rows[i] if i<len(expected_rows) else []
        arow=actual[i] if i<len(actual) else []
        for j in range(max(len(erow),len(arow))):
            result['full_reconstructed_cell_checks']+=1
            if norm(get(erow,j))!=norm(get(arow,j)):
                result['full_reconstruction_mismatches'].append({'sheet':title,'row':i+1,'column':j+1,'expected':get(erow,j),'actual':get(arow,j)})
if result['full_reconstruction_mismatches']:errors.append(['full_reconstruction_mismatch',len(result['full_reconstruction_mismatches'])])
ranking=read(P/'next_cycle_management/CURRENT_CYCLE_RANKING_331.json')['records']
fields=['priority_1_100','priority_rationale','current_proof_status','current_novelty_status','next_bounded_task','stopping_condition']
result['published_current_ranking_fields_checked']=len(ranking)*6
result['published_current_ranking_mismatches']=[]
native_map={r['record_id']:r['current_values'] for r in records}
scope_priority_expected={'NEW-16':71,'NEXT-PREFIX-TWO-PRIME':71,'NEXT-PREFIX-P13':15,'F020':60,
                        'NEXT-RS-RESIDUAL-B27':15,'NEXT-RS-RESIDUAL-B29':15,'ALG-CHIRP-ELIM':55,'C06':55,'Q13':55,'STR-Q2':55,
                        'FUS-02':38,'F016':60,'QTORUS-CONNECTED-MINOR-20261013':50}
result['named_scope_priority_checks']={rid:{'expected':score,'actual':native_map[rid][0]} for rid,score in scope_priority_expected.items()}
if not partial:
    for rid,score in scope_priority_expected.items():
        if native_map[rid][0]!=score:errors.append([rid,'named_scope_priority_mismatch'])
    b27_current=' '.join(str(v) for v in native_map['NEXT-RS-RESIDUAL-B27'])
    if 'successor at73' in b27_current or 'Continue only through the separate b29 review' in b27_current:
        errors.append(['NEXT-RS-RESIDUAL-B27','stale_b29_review_cross_reference'])
for r in ranking:
    vals=[current_part(r.get(k,'')) for k in fields]
    if vals!=native_map.get(r['record_id']):result['published_current_ranking_mismatches'].append(r['record_id'])
if result['published_current_ranking_mismatches']:errors.append(['current_ranking_fields_mismatch',result['published_current_ranking_mismatches']])
result['native_read_hashes']={str(f.relative_to(P)):sha(f) for f in (D/'native_final').glob('*.json')}
result['status']=('PASS_ACTUAL_PAUSED_CHECKPOINT_NOT_FINAL' if partial else 'PASS') if not errors else 'FAIL'
(D/'FINAL_CHECKS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
(D/'FINAL_331_ID_LEDGER.json').write_text(json.dumps(records,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in result.items() if k not in ['errors','historical_changes','native_read_hashes','source_hashes','mutation_mismatches']},indent=2,ensure_ascii=False))
print('ERRORS',json.dumps(errors,ensure_ascii=False)[:14000])
