import json
from pathlib import Path
P=Path(__file__).resolve().parents[1]
D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
actual=read(D/'native_final/metadata.json')['structuredContent']
before=read(P/'next_cycle_management/CURRENT_CYCLE_METADATA_BEFORE.json')
before=before.get('structuredContent',before)
errors=[]
a=[s['properties'] for s in actual['sheets']]
b=[s['properties'] for s in before['sheets']]
if a!=b:errors.append('Sheet properties changed outside intended content/row-style scope')
styles=read(D/'native_final/workflow_styles.json')['structuredContent']
red={'red':1,'green':0.8784314,'blue':0.8784314}
green={'red':0.8509804,'green':0.9490196,'blue':0.8666667}
expect={'Next cycle':{12:red,13:red,14:green,15:red},'Research overview':{328:red,329:red,330:green,331:red}}
checks=0
score_checks=0
for sheet in styles['sheets']:
    title=sheet['properties']['title']
    for block in sheet['data']:
        start=block.get('startRow',0)+1
        for rn,row in enumerate(block['rowData'],start):
            for c,cell in enumerate(row['values']):
                checks+=1
                f=cell.get('userEnteredFormat',{})
                rgb=f.get('backgroundColorStyle',{}).get('rgbColor',{})
                if any(abs(rgb.get(k,0)-v)>1e-6 for k,v in expect[title][rn].items()):errors.append([title,rn,c+1,'wrong workflow color'])
                if f.get('wrapStrategy')!='WRAP' or f.get('verticalAlignment')!='TOP':errors.append([title,rn,c+1,'wrong wrap/alignment'])
                if c==(6 if title=='Next cycle' else 11):
                    score_checks+=1
                    if f.get('numberFormat',{}).get('pattern')!='0':errors.append([title,rn,c+1,'noninteger priority format'])
result={'status':'PASS' if not errors else 'FAIL','metadata_sheet_properties_preserved':a==b,'sheet_count':len(a),'workflow_style_cells_checked':checks,
        'native_integer_priority_formats_checked':score_checks,'errors':errors,
        'visual_scope':'Independent native style/structure inspection only; rendered/export visual QA is owned separately by the sheet writer.'}
(D/'STRUCTURE_STYLE_CHECKS.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
