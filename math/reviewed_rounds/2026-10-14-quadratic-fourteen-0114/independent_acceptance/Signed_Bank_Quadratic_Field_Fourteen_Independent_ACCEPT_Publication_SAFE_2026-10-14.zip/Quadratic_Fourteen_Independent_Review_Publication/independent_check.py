#!/usr/bin/env python3
"""New, independent exact checker. No candidate/historical program imports."""
import argparse, copy, hashlib, itertools, json
from pathlib import Path

P, N, Q = 23, 11, 13
Z, O = (0, 0), (1, 0)
def fp(a): return (a % P, 0)
def dec(a):
    assert isinstance(a, int) and 0 <= a < P*P
    return (a % P, a // P)
def enc(a): return a[0]+P*a[1]
def add(a,b): return ((a[0]+b[0])%P,(a[1]+b[1])%P)
def neg(a): return ((-a[0])%P,(-a[1])%P)
def sub(a,b): return add(a,neg(b))
def mul(a,b): return ((a[0]*b[0]-a[1]*b[1])%P,(a[0]*b[1]+a[1]*b[0])%P)
def inv(a):
    n=(a[0]*a[0]+a[1]*a[1])%P
    assert n != 0, 'Zero/nonfield denominator'
    k=pow(n,-1,P)
    return (a[0]*k%P,-a[1]*k%P)
def power(a,n):
    if n < 0: return power(inv(a),-n)
    s=O
    while n:
        if n&1: s=mul(s,a)
        a=mul(a,a); n//=2
    return s
def summ(xs):
    s=Z
    for x in xs:s=add(s,x)
    return s
def qm(n): return fp(pow(Q,n,P))
def ident(): return [[O if i==j else Z for j in range(N)] for i in range(N)]
def zero(): return [[Z for j in range(N)] for i in range(N)]
def matadd(A,B):return [[add(a,b) for a,b in zip(x,y)] for x,y in zip(A,B)]
def matscale(c,A):return [[mul(c,a) for a in row] for row in A]
def matmul(A,B):return [[summ(mul(x,y) for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def matenc(A):return [[enc(a) for a in row] for row in A]
def matdec(A):return [[dec(a) for a in row] for row in A]
def mismatch(A,B):return [[i,j,enc(A[i][j]),enc(B[i][j])] for i in range(N) for j in range(N) if A[i][j]!=B[i][j]]
def matrix_inverse(A):
    rows=[a[:]+b[:] for a,b in zip(A,ident())]
    for c in range(N):
        pivot=next((r for r in range(c,N) if rows[r][c]!=Z),None)
        assert pivot is not None, 'Singular literal branch'
        rows[c],rows[pivot]=rows[pivot],rows[c]
        k=inv(rows[c][c]); rows[c]=[mul(k,v) for v in rows[c]]
        for r in range(N):
            if r!=c and rows[r][c]!=Z:
                k=rows[r][c]; rows[r]=[sub(a,mul(k,b)) for a,b in zip(rows[r],rows[c])]
    return [r[N:] for r in rows]
def literal(b,j,flip=False):
    A=ident(); e,d=b['epsilon'],b['delta']; a,c=dec(b['alpha']),dec(b['beta'])
    for t in range(N):
        A[(t+e)%N][t]=sub(A[(t+e)%N][t],a)
        phase=(-1 if flip else 1)*e*d*j+d*t
        A[t][t]=sub(A[t][t],mul(c,qm(phase)))
    return A
def get_bank(b,flipped=False):
    B=zero(); branches=[]
    for j,w in enumerate(b['weights']):
        A=literal(b,j,flipped); R=matrix_inverse(A)
        assert matmul(A,R)==ident() and matmul(R,A)==ident()
        B=matadd(B,matscale(mul(inv(fp(N)),dec(w)),R))
        branches.append((A,R))
    return B,branches

def direct_solve(A,y):
    nr,nc=len(A),len(A[0]); rows=[r[:]+[v] for r,v in zip(A,y)]; piv=[]
    for c in range(nc):
        pivot=next((r for r in range(len(piv),nr) if rows[r][c]!=Z),None)
        if pivot is None:continue
        r=len(piv);rows[r],rows[pivot]=rows[pivot],rows[r]
        z=inv(rows[r][c]);rows[r]=[mul(z,v) for v in rows[r]]
        for s in range(nr):
            if s!=r and rows[s][c]!=Z:
                z=rows[s][c]; rows[s]=[sub(a,mul(z,b)) for a,b in zip(rows[s],rows[r])]
        piv.append(c)
    assert all(any(v!=Z for v in row[:-1]) or row[-1]==Z for row in rows)
    x=[Z]*nc
    for r,c in enumerate(piv):x[c]=rows[r][-1]
    assert all(summ(mul(a,b) for a,b in zip(row,x))==v for row,v in zip(A,y))
    return x,piv

def poly_product(A,B):
    C=[Z]*(len(A)+len(B)-1)
    for i,a in enumerate(A):
        for j,b in enumerate(B):C[i+j]=add(C[i+j],mul(a,b))
    return C
def poly_eval(A,x):
    r=Z
    for a in reversed(A):r=add(mul(r,x),a)
    return r
def prem(a,b):
    a=a[:]
    while len(a)>=len(b):
        c=a[-1]*pow(b[-1],-1,P)%P; offset=len(a)-len(b)
        for i,x in enumerate(b):a[offset+i]=(a[offset+i]-c*x)%P
        while a and a[-1]==0:a.pop()
    return a

def G(e,d,a,b):
    r,ell=(e*a)%N,(d*b)%N
    if r+ell>N-1:return 0
    # Every choice is an actual binary word; p_i-i counts V-before-U pairs.
    return sum(pow(Q,e*d*sum(pos-i for i,pos in enumerate(ps)),P) for ps in itertools.combinations(range(r+ell),r))%P

def coefficient(A,a,b):
    return mul(inv(fp(N)),summ(mul(A[(t+a)%N][t],qm(-b*t)) for t in range(N)))
def determinant_mod(A):
    n=len(A); result=0
    for p in itertools.permutations(range(n)):
        term=1
        for i in range(n):term=term*A[i][p[i]]%P
        parity=sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))%2
        result+=(1 if parity==0 else -1)*term
    return result%P

def run(source,out):
    out.mkdir(parents=True,exist_ok=True)
    def save(n,d): (out/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
    pins={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(source.iterdir()) if p.is_file()}
    assert pins['RAW_WITNESS.json']['sha256']=='5afef05b733e2838eed4b1a42ccb50ebaac3253a4bfa60b0b1aed995c26b7dc8'
    assert pins['EXTENSION_LOWER_BOUND_PROOF_REVIEW.md']['sha256']=='3031f45d467e0cd0e7860de9fc59beb49758033ea0e1765e084eb19c2f97ee19'
    save('SOURCE_HASHES.json',pins)
    raw=json.loads((source/'RAW_WITNESS.json').read_text());full=json.loads((source/'FULL_WITNESS.json').read_text()); candbranches=json.loads((source/'LITERAL_BRANCHES.json').read_text())
    assert raw['field']['characteristic']==P and raw['field']['degree']==2
    assert raw['field']['modulus_coefficients_ascending']==[1,0,1]
    assert all((a*a+1)%P for a in range(P))
    for x in itertools.product(range(P),repeat=2):
        if x!=Z: assert mul(x,inv(x))==O
    assert power(fp(Q),N)==O and all(power(fp(Q),k)!=O for k in range(1,N))
    degree_eleven_checks=0
    for e,d in [(1,1),(-1,1),(1,-1),(-1,-1)]:
        for r in range(1,N):
            word_sum=sum(pow(Q,e*d*sum(pos-i for i,pos in enumerate(ps)),P) for ps in itertools.combinations(range(N),r))%P
            assert word_sum==0;degree_eleven_checks+=1
    banks=raw['banks']; assert len(banks)==14
    orientations=[(1,1),(-1,1),(1,-1),(-1,-1)]
    nodes={str(o):[b['alpha'] for b in banks if (b['epsilon'],b['delta'])==o] for o in orientations}
    assert [len(nodes[str(o)]) for o in orientations]==[6,1,1,6]
    support=[5,6,77,188,349,468]
    assert nodes[str((1,1))]==support==nodes[str((-1,-1))]
    assert nodes[str((-1,1))]==nodes[str((1,-1))]==[4]
    assert all(b['beta']==1 and len(b['weights'])==N for b in banks)
    poly=[O]
    for alpha in support:poly=poly_product(poly,[neg(dec(alpha)),O])
    selected=[9,15,21,6,0,11,1]
    assert [enc(x) for x in poly]==selected==full['candidate']['coefficients_ascending']
    factors=[[18,1],[17,1],[4,7,1],[11,15,1]]; product=[O]
    for f in factors:
        product=poly_product(product,list(map(fp,f)))
        if len(f)==3:assert all(poly_eval(list(map(fp,f)),fp(x))!=Z for x in range(P))
    assert product==poly and len(set(support))==6 and all(support)
    assert all(poly_eval(poly,dec(a))==Z for a in support)
    save('FIELD_AND_SUPPORT.json',{'all_528_nonzero_elements_invertible':True,'modulus_no_base_roots':True,'primitive_q_order':N,'six_node_product':selected,'factors':factors,'orientation_nodes':nodes})
    target=[[qm(-k*t) for t in range(N)] for k in range(N)]
    total=zero(); originals=[]; branch_records=[]; Brecords=[]; recover=[]
    for i,b in enumerate(banks):
        assert b['index']==i
        D=sub(sub(O,power(dec(b['alpha']),N)),power(dec(b['beta']),N))
        assert D!=Z and enc(D)==b['Delta']
        B,branches=get_bank(b); originals.append(B); total=matadd(total,B)
        assert B!=zero() and matenc(B)==full['banks'][i]['matrix']
        # At a=0, Gaussian coefficient and alpha^0 are both one for every b.
        H=[coefficient(B,0,bsec) for bsec in range(N)]
        rebuilt=[mul(D,summ(mul(H[bsec],qm(-b['epsilon']*j*bsec)) for bsec in range(N))) for j in range(N)]
        assert list(map(enc,rebuilt))==b['weights']
        assert list(map(enc,H))==full['banks'][i]['sector_amplitudes']
        assert any(h!=Z for h in H)
        for j,(A,R) in enumerate(branches):
            c=candbranches[i*N+j]; assert c['bank']==i and c['phase']==j
            assert c['matrix']==matenc(A) and c['inverse']==matenc(R)
            branch_records.append({'bank':i,'phase':j,'matrix':matenc(A),'inverse':matenc(R)})
        C=[[enc(coefficient(B,a,bb)) for bb in range(N)] for a in range(N)]
        assert C==full['banks'][i]['weyl_coefficients']
        for a in range(N):
            for bb in range(N):
                predicted=mul(mul(power(dec(b['alpha']),(b['epsilon']*a)%N),fp(G(b['epsilon'],b['delta'],a,bb))),H[bb])
                assert enc(predicted)==C[a][bb]
        Brecords.append({'bank':i,'matrix':matenc(B),'Delta':enc(D),'weyl_coefficients':C,'nonzero':True,'effective':True})
        recover.append({'bank':i,'recovered_raw_weights':list(map(enc,rebuilt)),'sector_amplitudes':list(map(enc,H))})
    assert total==target
    save('LITERAL_BRANCHES.json',branch_records);save('BANKS.json',Brecords);save('RECOVERED_RAW_WEIGHTS.json',recover)
    save('TARGET_COMPARISON.json',{'target':matenc(target),'sum':matenc(total),'mismatches':mismatch(total,target)})
    # Re-solve the fully literal 121 equations, with raw weights as unknowns.
    design=[[mul(inv(fp(N)),dec(r['inverse'][k][t])) for r in branch_records] for k in range(N) for t in range(N)]
    solved,pivots=direct_solve(design,[x for row in target for x in row])
    freshsum=zero(); freshbanks=[]
    for i in range(14):
        b=copy.deepcopy(banks[i]);b['weights']=list(map(enc,solved[i*N:(i+1)*N]));B,_=get_bank(b)
        assert B!=zero(); freshbanks.append(b);freshsum=matadd(freshsum,B)
    assert freshsum==target
    save('DIRECT_SYSTEM_RECONSTRUCTION.json',{'row_count':121,'unknown_count':154,'rank':len(pivots),'pivots':pivots,'free_variables_zero':True,'banks':freshbanks,'all_banks_nonzero':True,'all_target_entries_equal':True})
    # Independently rebuild and certify the rank-five extension obstruction.
    coeff=[[enc(coefficient(target,a,b)) for b in range(N)] for a in range(N)]
    assert all(coeff[a][b]==18*pow(Q,3*(a+b)**2,P)%P for a in range(N) for b in range(N))
    moments=[]; Ts=[]
    for b in [1,2]:
        a=N-b
        assert [G(e,d,a,b)!=0 for e,d in orientations]==[False,True,False,False]
        T=pow(pow(4,b,P)*G(-1,1,a,b)%P,-1,P);Ts.append(T)
        row=[]
        for a in range(b,N-b):
            assert G(1,-1,a,b)==G(-1,-1,a,b)==0
            row.append((pow(Q,3*(a+b)**2,P)-T*pow(4,N-a,P)*G(-1,1,a,b))*pow(G(1,1,a,b),-1,P)%P)
        moments.append(row)
    assert moments==[[19,4,20,14,20,3,14,16,8],[21,15,14,11,13,22,19]] and Ts==[22,20]
    M=[moments[0][i:i+6] for i in range(4)]+[moments[1][i:i+6] for i in range(2)]
    g=[6,4,18,1,8,1]
    assert all(sum(x*y for x,y in zip(r,g))%P==0 for r in M)
    assert determinant_mod([r[:5] for r in M[:5]])==3
    divisors_checked=[]
    for deg in [1,2]:
        for cs in itertools.product(range(P),repeat=deg):
            div=list(cs)+[1]; assert prem(g,div)
            divisors_checked.append(div)
    assert len(divisors_checked)==552
    reflectionchecks=0
    for e,d in orientations:
        for a in range(N):
            for b in range(N):
                assert G(e,d,a,b)==G(-e,-d,-a%N,-b%N);reflectionchecks+=1
    assert all(target[k][t]==target[-k%N][-t%N] for k in range(N) for t in range(N))
    save('REBUILT_LOWER_BOUND_PREMISES.json',{'target_normalization':18,'forced_amplitudes':Ts,'moments':moments,'matrix':M,'minor_determinant':3,'rank':5,'quintic_ascending':g,'linear_quadratic_nondivisors_tested':552,'irreducible':True,'reflection_identities':reflectionchecks,'degree_eleven_mixed_term_vanishings':degree_eleven_checks,'accepted_lower_bound':'b4(F23^d)>=14 when 5 does not divide d','new_equality':'b4(F23^d)=14 for even d with 5 not dividing d'})
    # Adversarial controls; arithmetic predictions are checked against the target.
    controls=[]
    for k,r in enumerate(branch_records):
        changed=matadd(total,matscale(inv(fp(N)),matdec(r['inverse'])))
        bad=mismatch(changed,target);assert bad
        controls.append({'kind':'raw_weight_plus_one','bank':k//N,'phase':k%N,'rejected':True,'differing_entries':len(bad)})
    for i,B in enumerate(originals):
        bad=mismatch(matadd(total,matscale(neg(O),B)),target);assert bad
        controls.append({'kind':'omit_bank','bank':i,'rejected':True,'differing_entries':len(bad)})
    for kind in ['alpha','beta','phase_sign']:
        changed=copy.deepcopy(banks[2])
        if kind=='alpha':changed['alpha']=enc(add(dec(changed['alpha']),O))
        if kind=='beta':changed['beta']=0
        try: B,_=get_bank(changed,flipped=kind=='phase_sign'); bad=mismatch(matadd(matadd(total,matscale(neg(O),originals[2])),B),target)
        except AssertionError:bad=['singular']
        assert bad;controls.append({'kind':kind,'bank':2,'rejected':True,'difference':len(bad)})
    wrongnorm=matscale(fp(N),total);assert wrongnorm!=target
    controls.append({'kind':'omit_one_over_eleven','rejected':True,'differing_entries':len(mismatch(wrongnorm,target))})
    wrongtarget=[[qm(k*t) for t in range(N)] for k in range(N)];assert wrongtarget!=total
    controls.append({'kind':'positive_fourier_target','rejected':True,'differing_entries':len(mismatch(total,wrongtarget))})
    changed=matdec(branch_records[0]['inverse']);changed[0][0]=add(changed[0][0],O);A=matdec(branch_records[0]['matrix'])
    assert matmul(A,changed)!=ident() and matmul(changed,A)!=ident()
    controls.append({'kind':'inverse_entry_plus_one','rejected_both_sides':True})
    for i in range(6):
        altered=g[:];altered[i]=(altered[i]+1)%P
        assert any(sum(x*y for x,y in zip(r,altered))%P for r in M)
        controls.append({'kind':'kernel_coefficient_plus_one','coefficient':i,'rejected':True})
    assert any((a*a-1)%P==0 for a in range(P))
    controls.append({'kind':'reducible_modulus_z_squared_minus_one','rejected':True})
    save('MUTATION_CONTROLS.json',controls)
    finalpins={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(source.iterdir()) if p.is_file()}
    assert finalpins==pins
    result={'verdict':'ACCEPT_SCOPED','raw_weights_checked':154,'raw_weights_recovered_independently':154,'literal_branches_rebuilt':154,'two_sided_inverse_checks':308,'bank_entries_compared':1694,'original_bank_count':14,'all_banks_nonzero':True,'all_nodes_effective':True,'all_Delta_nonzero':True,'target_entries_checked':121,'target_mismatches':0,'direct_system_rank':len(pivots),'fresh_direct_raw_weight_solution_verified':True,'mutation_controls':len(controls),'source_bytes_unchanged':True,'not_reviewed':'Full 529-factor census; cubic attainment; unrestricted or unpinned minima; novelty; arithmetic speed'}
    save('RESULTS.json',result);print(json.dumps(result,sort_keys=True))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='outputs');a=p.parse_args();here=Path(__file__).resolve().parent
    run(here/'sources',here/a.out)
