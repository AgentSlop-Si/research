# Independent quadratic-field literal-bank audit

14 October 2026. Audit the frozen raw witness with SHA-256
5afef05b733e2838eed4b1a42ccb50ebaac3253a4bfa60b0b1aed995c26b7dc8.
Read candidate JSON and proof reports as inert data only. Do not execute or
import any candidate or historical scientific program. No external writes.

Use newly written standard-library Python, representing field elements as
coordinate pairs rather than the source's integer encoding. Rebuild each
literal 11-by-11 resolvent from the original S and T, independently invert
all 154 branches, verify both inverse products, aggregate the supplied raw
weights with the literal 1/11 factor, and compare all 121 target entries.
Check all 14 banks are nonzero, all denominators legal, orientation counts
(6,1,1,6), and both cross-sign nodes 4. Independently recover the raw weights
and independently solve a direct literal 121-by-154 system as a cross-check.

Rebuild the pinned lower-bound gate from word expansions and direct target
coefficient extraction. Check rank, the quintic kernel and irreducibility,
and review the field/ordinary-node/reflection proof. Check the quadratic
modulus, the six roots, and the selected sextic factorization. Include
mutation controls, exact outputs, hashes, a cold replay and a scoped verdict.

The potentially accepted new conclusion is b4(F23^2)=14. Embedding gives
b4(F23^d)=14 for even d with 5 not dividing d, using the reviewed lower bound.
Do not infer an exact cubic or other odd-degree value, an unpinned or
unrestricted optimum, characteristic-zero behavior, novelty, or an FFT
arithmetic speedup. The full 529-polynomial census is outside this witness
audit unless separately checked and explicitly labeled.
