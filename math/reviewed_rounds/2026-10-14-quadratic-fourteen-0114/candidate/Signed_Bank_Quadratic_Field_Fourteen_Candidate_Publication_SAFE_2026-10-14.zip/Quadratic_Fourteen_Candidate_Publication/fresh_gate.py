#!/usr/bin/env python3
"""Fresh exact standard-library gate; imports no supplied scientific programs."""
import argparse, collections, datetime, hashlib, itertools, json, math, pathlib, time
P=23; N=11; Q=13
BASE=pathlib.Path(__file__).resolve().parent

def dump(p,x): p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def trim(a):
    a=list(a)
    while len(a)>1 and a[-1]%P==0:a.pop()
    return [v%P for v in a]
def padd(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def psub(a,b):return padd(a,[-x for x in b])
def pmul(a,b):
    z=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):z[i+j]=(z[i+j]+x*y)%P
    return trim(z)
def pdiv(a,b):
    a=trim(a); b=trim(b); q=[0]*max(1,len(a)-len(b)+1); bi=pow(b[-1],-1,P)
    while a!=[0] and len(a)>=len(b):
        n=len(a)-len(b); c=a[-1]*bi%P;q[n]=c
        for j,x in enumerate(b):a[n+j]=(a[n+j]-c*x)%P
        a=trim(a)
    return trim(q),a
def pmod(a,b):return pdiv(a,b)[1]
def ppow(a,n,m):
    z=[1]
    while n:
        if n&1:z=pmod(pmul(z,a),m)
        a=pmod(pmul(a,a),m);n//=2
    return z
def pgcd(a,b):
    while b!=[0]:a,b=b,pmod(a,b)
    return trim([x*pow(a[-1],-1,P) for x in a])
def peval(a,x):
    z=0
    for c in reversed(a):z=(z*x+c)%P
    return z
def irreducible(f):
    n=len(f)-1
    if n==1:return True
    x=[0,1];xp=x;checks=[]
    for k in range(1,n+1):
        xp=ppow(xp,P,f)
        if k<=n//2 and pgcd(f,psub(xp,x))!=[1]:return False
    return xp==x

def rrefp(M):
    R=[row[:] for row in M]; piv=[];i=0
    for j in range(len(R[0])):
        k=next((k for k in range(i,len(R)) if R[k][j]),None)
        if k is None:continue
        R[i],R[k]=R[k],R[i]; inv=pow(R[i][j],-1,P);R[i]=[v*inv%P for v in R[i]]
        for k in range(len(R)):
            if k!=i:
                c=R[k][j];R[k]=[(a-c*b)%P for a,b in zip(R[k],R[i])]
        piv.append(j);i+=1
        if i==len(R):break
    return R,piv

def build_grammar():
    assert pow(Q,N,P)==1 and Q!=1
    D={}
    for e,d in [(1,1),(-1,1),(1,-1),(-1,-1)]:
        w=pow(Q,(e*d)%N,P);v={(0,0):1}
        for n in range(1,N+1):
            for r in range(n+1):
                ell=n-r;v[r,ell]=(pow(w,ell,P)*v.get((r-1,ell),0)+v.get((r,ell-1),0))%P
        assert all(v[r,N-r]==0 for r in range(1,N))
        D[e,d]=v
    def G(e,d,a,b):
        r=e*a%N;ell=d*b%N
        return D[e,d][r,ell] if r+ell<N else 0
    C=sum(pow(Q,(-t*t)%N,P) for t in range(N))*pow(N,-1,P)%P
    F=[[pow(Q,(-k*t)%N,P) for t in range(N)] for k in range(N)]
    coefficients=[[sum(F[(t+a)%N][t]*pow(Q,(-b*t)%N,P) for t in range(N))*pow(N,-1,P)%P for b in range(N)] for a in range(N)]
    assert coefficients==[[C*pow(Q,(3*(a+b)**2)%N,P)%P for b in range(N)] for a in range(N)]
    seq=[];forced=[]
    for b in (1,2):
        a=N-b;t=pow(pow(4,b,P)*G(-1,1,a,b)%P,-1,P);forced.append(t)
        seq.append([(pow(Q,(3*(a+b)**2)%N,P)-t*pow(4,N-a,P)*G(-1,1,a,b))*pow(G(1,1,a,b),-1,P)%P for a in range(b,N-b)])
    H=[seq[0][i:i+7] for i in range(3)]+[seq[1]]
    R,piv=rrefp(H)
    assert piv==[0,1,2,3]
    return G,F,coefficients,dict(C=C,forced_cross_amplitudes=forced,moments=seq,H=H,rref=R,pivots=piv)

def factor_census(out,grammar):
    irrs={1:[[(-a)%P,1] for a in range(P)]}
    for degree in (2,3):
        irrs[degree]=[list(c)+( [1]) for c in itertools.product(range(P),repeat=degree) if not any(peval(list(c)+[1],a)==0 for a in range(P))]
    assert len(irrs[2])==253 and len(irrs[3])==4048
    family=[];patterns=collections.Counter();eligible=collections.Counter();R=grammar['rref']
    supplied=json.loads((BASE/'sources/SEXTIC_FAMILY.json').read_text())
    for u,v in itertools.product(range(P),repeat=2):
        h=[(-row[4]*u-row[5]*v-row[6])%P for row in R]+[u,v,1]
        assert h==supplied[u*P+v]['coefficients_ascending']
        rem=h[:];factors=[]
        for degree in (1,2,3):
            for f in irrs[degree]:
                if len(rem)-1<2*degree and degree>1:break
                while True:
                    q,r=pdiv(rem,f)
                    if r!=[0]:break
                    factors.append(f);rem=q
        if rem!=[1]:factors.append(rem)
        product=[1]
        for f in factors:
            assert irreducible(f)
            product=pmul(product,f)
        assert product==h
        pattern=sorted(len(f)-1 for f in factors)
        squarefree=pgcd(h,trim([i*h[i] for i in range(1,7)]))==[1]
        nonzero=h[0]!=0
        split_degree=math.lcm(*pattern)
        legal=squarefree and nonzero
        assert squarefree==(len({tuple(f) for f in factors})==len(factors))
        patterns[','.join(map(str,pattern))]+=1
        if legal:eligible[str(split_degree)]+=1
        family.append(dict(u=u,v=v,coefficients_ascending=h,factors_ascending=factors,degree_pattern=pattern,squarefree=squarefree,nonzero_roots=nonzero,splitting_degree=split_degree,eligible_support=legal))
    result=dict(polynomials=529,irreducible_factor_checks=sum(len(a['factors_ascending']) for a in family),pattern_counts=dict(sorted(patterns.items())),eligible_by_minimum_splitting_degree=dict(sorted(eligible.items(),key=lambda kv:int(kv[0]))),eligible_F23_squared=sum(a['eligible_support'] and 2%a['splitting_degree']==0 for a in family),eligible_F23_cubed=sum(a['eligible_support'] and 3%a['splitting_degree']==0 for a in family))
    dump(out/'FACTOR_CENSUS.json',family);dump(out/'FACTOR_SUMMARY.json',result);print(json.dumps(result),flush=True)
    return family,irrs

class Field:
    def __init__(self,modulus):
        assert irreducible(modulus)
        self.modulus=modulus;self.d=len(modulus)-1;self.order=P**self.d
        self.vectors=[tuple((i//(P**k))%P for k in range(self.d)) for i in range(self.order)]
        self.inv_cache={1:1}
    def encode(self,v):return sum((x%P)*(P**i) for i,x in enumerate(v))
    def add(self,a,b):
        if a<P and b<P:return (a+b)%P
        return self.encode([x+y for x,y in zip(self.vectors[a],self.vectors[b])])
    def neg(self,a):return self.encode([-x for x in self.vectors[a]])
    def sub(self,a,b):
        if a<P and b<P:return (a-b)%P
        return self.encode([x-y for x,y in zip(self.vectors[a],self.vectors[b])])
    def mul(self,a,b):
        if a==0 or b==0:return 0
        if a==1:return b
        if b==1:return a
        if a<P and b<P:return a*b%P
        av=self.vectors[a];bv=self.vectors[b]
        if self.d==2:
            x=av[0]*bv[0]-self.modulus[0]*av[1]*bv[1]
            y=av[0]*bv[1]+av[1]*bv[0]-self.modulus[1]*av[1]*bv[1]
            return x%P+P*(y%P)
        prod=[0]*(2*self.d-1)
        for i,x in enumerate(av):
            for j,y in enumerate(bv):prod[i+j]=(prod[i+j]+x*y)%P
        for k in range(len(prod)-1,self.d-1,-1):
            for i,c in enumerate(self.modulus[:-1]):prod[k-self.d+i]=(prod[k-self.d+i]-prod[k]*c)%P
        return self.encode(prod[:self.d])
    def pow(self,a,n):
        z=1
        while n:
            if n&1:z=self.mul(z,a)
            a=self.mul(a,a);n//=2
        return z
    def inv(self,a):
        assert a
        if a not in self.inv_cache:
            self.inv_cache[a]=self.pow(a,self.order-2)
            assert self.mul(a,self.inv_cache[a])==1
        return self.inv_cache[a]
    def sum(self,seq):
        s=0
        for v in seq:s=self.add(s,v)
        return s
    def eval(self,p,x):
        z=0
        for c in reversed(p):z=self.add(self.mul(z,x),c)
        return z

def solve(K,A,b):
    n=len(A[0]);R=[row[:]+[v] for row,v in zip(A,b)];r=0;piv=[]
    for c in range(n):
        k=next((k for k in range(r,len(R)) if R[k][c]),None)
        if k is None:continue
        R[r],R[k]=R[k],R[r];inv=K.inv(R[r][c]);R[r]=[K.mul(v,inv) for v in R[r]]
        for k in range(len(R)):
            if k!=r and R[k][c]:
                f=R[k][c];R[k]=[K.sub(x,K.mul(f,y)) for x,y in zip(R[k],R[r])]
        piv.append(c);r+=1
        if r==len(R):break
    bad=next((row for row in R if not any(row[:n]) and row[n]),None)
    if bad is not None:return None,dict(rank=r,inconsistent_row=bad,rref=R,pivots=piv)
    x=[0]*n
    for i,c in enumerate(piv):x[c]=R[i][n]
    assert all(K.sum(K.mul(a,v) for a,v in zip(row,x))==t for row,t in zip(A,b))
    return x,dict(rank=r,rref=R,pivots=piv)

def matrix_inverse(K,A):
    n=len(A);R=[row[:]+[int(i==j) for j in range(n)] for i,row in enumerate(A)]
    for c in range(n):
        k=next(k for k in range(c,n) if R[k][c]);R[c],R[k]=R[k],R[c]
        inv=K.inv(R[c][c]);R[c]=[K.mul(v,inv) for v in R[c]]
        for k in range(n):
            if k!=c and R[k][c]:
                f=R[k][c];R[k]=[K.sub(x,K.mul(f,y)) for x,y in zip(R[k],R[c])]
    assert [row[:n] for row in R]==[[int(i==j) for j in range(n)] for i in range(n)]
    return [row[n:] for row in R]
def matrix_product(K,A,B):
    return [[K.sum(K.mul(a,b) for a,b in zip(row,col)) for col in zip(*B)] for row in A]
def field_matrix_add(K,A,B):return [[K.add(x,y) for x,y in zip(a,b)] for a,b in zip(A,B)]
def field_matrix_scale(K,a,A):return [[K.mul(a,x) for x in row] for row in A]

def seek_witness(out,family,irrs,G,F,target_coefficients):
    attempts=[]
    for degree in (2,3):
        K=Field(irrs[degree][0]);candidates=[a for a in family if a['eligible_support'] and degree%a['splitting_degree']==0]
        for candidate in candidates:
            roots=[a for a in range(1,K.order) if K.eval(candidate['coefficients_ascending'],a)==0]
            assert len(roots)==6
            bank_params=[(1,1,a) for a in roots]+[(-1,1,4),(1,-1,4)]+[(-1,-1,a) for a in roots]
            H=[[0]*N for _ in bank_params];sector_records=[]
            for b in range(N):
                A=[[K.mul(K.pow(alpha,(e*a)%N),G(e,d,a,b)) for e,d,alpha in bank_params] for a in range(N)]
                sol,record=solve(K,A,[target_coefficients[a][b] for a in range(N)])
                sector_records.append(dict(b=b,**record))
                if sol is None:break
                for i,x in enumerate(sol):H[i][b]=x
            attempt=dict(extension_degree=degree,u=candidate['u'],v=candidate['v'],roots=roots,compatible=sol is not None,sector_records=sector_records)
            attempts.append(attempt)
            if sol is None:continue
            dump(out/'COMPATIBILITY_ATTEMPTS.json',attempts)
            print('All sectors compatible:',degree,candidate['u'],candidate['v'],roots,flush=True)
            return verify_witness(K,out,bank_params,H,F,G,candidate,sector_records,attempts)
    dump(out/'COMPATIBILITY_ATTEMPTS.json',attempts)
    dump(out/'WITNESS_RESULT.json',dict(found=False,attempt_count=len(attempts),scope='Equal same-sign supports from the 529 base-coefficient candidates over F23^2 and F23^3.'))
    return None

def verify_witness(K,out,bank_params,H,F,G,candidate,sector_records,attempts):
    zero=[[0]*N for _ in range(N)];aggregate=[r[:] for r in zero];I=[[int(i==j) for j in range(N)] for i in range(N)];invN=pow(N,-1,P)
    records=[];branches=[];controls=[];literal_checks=0;weyl_checks=0
    for i,((e,d,alpha),sectors) in enumerate(zip(bank_params,H)):
        beta=1;Delta=K.neg(K.pow(alpha,N));assert Delta and any(sectors)
        weights=[K.mul(Delta,K.sum(K.mul(sectors[b],pow(Q,(-e*j*b)%N,P)) for b in range(N))) for j in range(N)]
        recovered=[K.mul(K.mul(invN,K.inv(Delta)),K.sum(K.mul(weights[j],pow(Q,(e*j*b)%N,P)) for j in range(N))) for b in range(N)]
        assert recovered==sectors
        bank=[r[:] for r in zero]
        for j,w in enumerate(weights):
            A=[r[:] for r in I]
            for t in range(N):
                A[t][t]=K.sub(A[t][t],pow(Q,(e*d*j+d*t)%N,P))
                A[(t+e)%N][t]=K.sub(A[(t+e)%N][t],alpha)
            inverse=matrix_inverse(K,A)
            assert matrix_product(K,A,inverse)==I and matrix_product(K,inverse,A)==I
            literal_checks+=2
            bank=field_matrix_add(K,bank,field_matrix_scale(K,K.mul(invN,w),inverse))
            branches.append(dict(bank=i,phase=j,matrix=A,inverse=inverse))
        assert any(any(row) for row in bank)
        weyl=[[K.mul(invN,K.sum(K.mul(bank[(t+a)%N][t],pow(Q,(-b*t)%N,P)) for t in range(N))) for b in range(N)] for a in range(N)]
        predicted=[[K.mul(K.mul(K.pow(alpha,(e*a)%N),G(e,d,a,b)),sectors[b]) for b in range(N)] for a in range(N)]
        assert weyl==predicted;weyl_checks+=N*N
        aggregate=field_matrix_add(K,aggregate,bank)
        records.append(dict(index=i,epsilon=e,delta=d,alpha=alpha,beta=beta,Delta=Delta,weights=weights,sector_amplitudes=sectors,matrix=bank,weyl_coefficients=weyl))
    assert aggregate==F
    assert len(records)==14 and len({(b['epsilon'],b['delta'],b['alpha']) for b in records})==14
    assert [sum(b['epsilon']==e and b['delta']==d for b in records) for e,d in [(1,1),(-1,1),(1,-1),(-1,-1)]]==[6,1,1,6]
    assert all(b['alpha']==4 for b in records if b['epsilon']!=b['delta'])
    for rec in branches:
        changed=field_matrix_add(K,aggregate,field_matrix_scale(K,invN,rec['inverse']))
        assert changed!=F
        controls.append(dict(kind='one_raw_weight_plus_one',bank=rec['bank'],phase=rec['phase'],detected=True))
    for b in records:
        changed=field_matrix_add(K,aggregate,field_matrix_scale(K,P-1,b['matrix']))
        assert changed!=F
        controls.append(dict(kind='delete_bank',bank=b['index'],detected=True))
    rec=branches[0];bad=[r[:] for r in rec['inverse']];bad[0][0]=K.add(bad[0][0],1)
    assert matrix_product(K,rec['matrix'],bad)!=I and matrix_product(K,bad,rec['matrix'])!=I
    controls.append(dict(kind='corrupt_inverse_entry_both_sides',detected=True))
    assert field_matrix_scale(K,N,aggregate)!=F
    controls.append(dict(kind='omit_one_over_eleven',detected=True))
    assert K.sub(K.sub(1,K.pow(0,N)),K.pow(1,N))==0
    controls.append(dict(kind='zero_alpha_beta_one_illegal',detected=True))
    field_spec=dict(characteristic=P,degree=K.d,modulus_coefficients_ascending=K.modulus,modulus_irreducible=True,encoding='Integer sum(c_i * 23^i) encodes sum(c_i * z^i), with 0 <= c_i < 23; z is the residue of t modulo the listed monic modulus.',roots=[dict(encoded=a,coordinates=list(K.vectors[a])) for e,d,a in bank_params if e==d==1])
    dump(out/'RAW_WITNESS.json',dict(field=field_spec,bank_grammar='(1/11) sum_j w_j (I-alpha*S^epsilon-beta*13^(epsilon*delta*j)*T^delta)^(-1)',target='F[k,t]=13^(-k*t), indices 0..10',banks=[{k:b[k] for k in ['index','epsilon','delta','alpha','beta','Delta','weights']} for b in records]))
    dump(out/'FULL_WITNESS.json',dict(field=field_spec,candidate=candidate,banks=records,target=F,aggregate=aggregate,sector_records=sector_records))
    dump(out/'LITERAL_BRANCHES.json',branches);dump(out/'MUTATION_CONTROLS.json',controls)
    result=dict(found=True,extension_degree=K.d,bank_count=len(records),allocation=[6,1,1,6],candidate_parameters=[candidate['u'],candidate['v']],all_banks_nonzero=True,all_nodes_effective=True,all_denominators_nonzero=True,pinned_cross_nodes=[4,4],sector_ranks=[r['rank'] for r in sector_records],literal_branch_count=len(branches),two_sided_inverse_checks=literal_checks,bank_weyl_entries_checked=weyl_checks,raw_weights_checked=len(records)*N,aggregate_entries_checked=N*N,aggregate_mismatches=0,mutation_controls=len(controls),compatibility_attempts=len(attempts))
    dump(out/'WITNESS_RESULT.json',result);print(json.dumps(result),flush=True)
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='outputs');args=ap.parse_args();out=BASE/args.out;out.mkdir(exist_ok=True)
    t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    hashes={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((BASE/'sources').iterdir())}
    G,F,coefficients,grammar=build_grammar();dump(out/'GRAMMAR_AND_MOMENTS.json',grammar)
    family,irrs=factor_census(out,grammar)
    seek_witness(out,family,irrs,G,F,coefficients)
    dump(out/'SOURCE_HASHES.json',hashes)
    assert hashes=={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((BASE/'sources').iterdir())}
    dump(out/'TIMING.json',dict(start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t))
if __name__=='__main__':main()
