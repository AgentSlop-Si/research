# Pinned base-field fourteen-bank attainment: exhaustive negative certificate

13 October 2026. **Candidate theorem and new finite arithmetic certificate, pending independent review.**

## Result

Fourteen original banks do **not** attain the target in the declared pinned base-field model. The full monic-sextic census and an independent enumeration of all 74,613 six-element nonzero node sets leave no candidate same-sign support. The stronger consequence is

    b4(F23) >= 16.

Here N=11, q=13, and b4 is the accepted model with exactly one effective alpha node in each cross-sign orientation, both fixed at 4. All original alpha, beta and raw weights lie in F23. If there is no representation, the minimum is infinity. The result does not establish sixteen-bank attainment.

Combining this candidate lower bound with the separately accepted extension-field theorem would give

    b4(F23) >= 16,       b4(F23^5) = 12.

The twelve-bank equality is inherited from the independent pinned-theorem proof review and its independently verified witness. It is not re-proved or re-executed in this packet. The newly proved base-field statement is narrower than any claim covering all finite extensions whose degrees are not divisible by five. The accepted bound of fourteen remains the general statement for those other fields.

## 1. Exact legal grammar and provenance

The target and matrices remain

    S e_t=e_(t+1 mod11),  T e_t=13^t e_t,  F[k,t]=13^(-kt).

A bank is literally

    (1/11) sum_(j=0)^10 w_j
      (I-alpha S^epsilon-beta 13^(epsilon delta j) T^delta)^(-1),

with epsilon,delta in {+1,-1} and Delta=1-alpha^11-beta^11 nonzero. No replacement generators, transformed target, pre/post map, derivative atom, trace-bank primitive, infinite node, or limiting singular bank is permitted.

Within an orientation, equal-alpha sector vectors may be added for the necessity argument. This is effective-node bookkeeping, not a license to reduce the count of actual original summands. Repeated ordinary nodes do not produce derivative terms. A zero node contributes zero on the strictly positive-exponent windows used below. Arbitrary legal beta values, including beta=0, are permitted throughout the lower bound.

SOURCE_PINS.json binds exact inert copies of the accepted base-field review, extension witness review, pinned theorem proof review, fusion report and scoring rubric. These reports were read, but no historical or candidate scientific program was executed, imported or compiled. Only the new standard-library fresh_check.py performs this packet's scientific computations. It rebuilds Gaussian coefficients by direct binary-word expansion rather than calling any predecessor's code.

The frozen CONTRACT.md declared a complete sextic census, full six-node subset census, and complete sector tests for every surviving support pair. The stopping condition was an exact witness or exhaustion of that finite class. The first calculation followed that declaration. The logical result does not depend on trusting the declaration's date.

## 2. Original bank coefficients and necessary moment data

Set U=S^epsilon and V=T^delta, so VU=13^(epsilon delta) UV. In a binary word with r copies of U and ell copies of V, ordering it as U^r V^ell contributes one factor of 13^(epsilon delta) for each V-before-U inversion. Summing those factors gives D(r,ell). The new program enumerates all such words through degree eleven and verifies that the degree-eleven mixed terms vanish.

Hence X_j^11=(alpha^11+beta^11)I, and the original inverse is

    (I-X_j)^(-1)=(I+X_j+...+X_j^10)/Delta.

At S^a T^b its coefficient is alpha^r G_(epsilon,delta)(a,b) times a sector amplitude, where r=[epsilon a]_11, ell=[delta b]_11, and G is D(r,ell) if r+ell<=10 and zero otherwise. The sector amplitude absorbs beta^ell, 1/(11 Delta), and the raw-weight finite character sum. This identity never divides by beta.

Direct coefficient extraction from the literal target gives C*f(a,b), with C=18 and f(a,b)=13^(3(a+b)^2). All 121 coefficients are freshly checked by the direct finite sum.

At (a,b)=(11-b,b), b=1,2, only (-,+) is supported. Its singleton node is 4, forcing normalized amplitudes T_1=22 and T_2=20. On b<=a<=10-b, the negative-delta orientations vanish and G_++ is nonzero. Therefore

    v_b(a) = [f(a,b)-T_b 4^(11-a) G_-+(a,b)] / G_++(a,b)
           = sum_(x in X) A_(b,x) x^a,

where X is the distinct nonzero effective ++ support. Freshly reconstructed values are

    b=1, a=1,...,9: 19,4,20,14,20,3,14,16,8;
    b=2, a=2,...,8: 21,15,14,11,13,22,19.

The two sectors have separate amplitude vectors but must share the same alpha support. It is precisely this shared-support condition that the census tests.

## 3. Every monic sextic common-node polynomial

If |X|<=6, pad X to a six-element subset X' of F23* and form

    h(t)=product_(x in X') (t-x).

This padding is always possible because F23* has 22 members. It handles fewer nodes, repeated banks and a discarded zero node without inventing derivative atoms. The polynomial is monic of degree six with six distinct nonzero roots. Every length-seven window of either moment sequence must annihilate its ascending coefficient vector.

There are three such windows in b=1 and one in b=2. Their matrix is

    H = [19  4 20 14 20  3 14]
        [ 4 20 14 20  3 14 16]
        [20 14 20  3 14 16  8]
        [21 15 14 11 13 22 19].

The determinant of its first four columns is 4 modulo 23, independently evaluated by the complete 24-term determinant formula. Its reduced row echelon form is

    [1 0 0 0  7  7  6]
    [0 1 0 0 10  8 12]
    [0 0 1 0 16 15 21]
    [0 0 0 1  4 13 12].

Consequently every possible monic sextic, with u=h_4 and v=h_5, is exactly

    h_(u,v)(t)=t^6+v t^5+u t^4
       +(11-4u-13v)t^3+(2-16u-15v)t^2
       +(11-10u-8v)t+(17-7u-7v),

where (u,v) ranges over all 23^2=529 pairs. This is the entire sextic family, not only multiples of the predecessor quintic g.

All 529 polynomials were evaluated at all 22 nonzero base-field elements. Counts by number of distinct nonzero roots are

    0 roots: 190 polynomials
    1 root:  214 polynomials
    2 roots:  92 polynomials
    3 roots:  26 polynomials
    4 roots:   5 polynomials
    5 roots:   2 polynomials
    6 roots:   0 polynomials.

The two five-distinct-root cases have ascending coefficients

    (10,3,10,21,0,1,1), roots {1,13,18,19,21};
    (16,3,3,17,10,0,1), roots {4,9,14,15,18}.

Neither has six distinct nonzero roots. A degree-six polynomial with a repeated root is not an admissible six-distinct-node annihilator. AFFINE_SEXTIC_FAMILY.json records every parameter pair, polynomial, root list, and zero-root flag.

## 4. Second exhaustive certificate on supports

Independently of solving the affine family, the program enumerates every one of the C(22,6)=74,613 nonzero six-node sets, multiplies its six linear factors, and calculates all four recurrence residuals. ALL_SIX_NODE_SETS.csv stores all nodes, seven polynomial coefficients and four residuals for every set; no rejected rows are omitted.

Successive survivor counts after the four equations are

    74,613 -> 3,233 -> 121 -> 3 -> 0.

The three sets that satisfy all b=1 equations and their failed b=2 equation are:

- {2,3,5,12,20,22}: coefficients (22,4,10,21,20,5,1), final residual 17.
- {2,7,9,10,12,13}: coefficients (2,8,13,9,4,16,1), final residual 15.
- {3,4,8,17,19,20}: coefficients (11,11,10,4,19,21,1), final residual 20.

All three final residuals are nonzero in F23. The affine-polynomial census and the complete support census agree exactly on an empty survivor list.

No full eleven-sector support-pair solve is necessary or attempted: there are zero eligible ++ supports, hence zero ordered pairs to submit. PAIR_COMPATIBILITY.json explicitly contains the empty list. This is an impossibility certificate from necessary constraints; no sufficiency is inferred from recurrence rank. The program includes the declared complete linear compatibility and literal-witness validation route for a survivor, but that route is unreachable on the actual data.

## 5. From empty census to a sixteen-bank lower bound

Suppose a legal representation has at most six distinct nonzero effective ++ nodes. The padding argument produces one of the six-distinct-root sextics from section 3. The exhaustive certificate says none exists, a contradiction. Thus the pinned (-,+) singleton alone forces at least seven distinct nonzero ++ nodes, even if both negative-delta groups are unrestricted in size.

Let J e_t=e_(-t mod11). Then JSJ=S^-1, JTJ=T^-1, and JFJ=F. Conjugation exchanges ++ with -- and -+ with +-, preserves alpha, beta, the phase product epsilon*delta and every legal denominator. This is a proof symmetry applied to an identity, not an extra transform allowed in the representation. The checker verifies all 484 Gaussian-coefficient reflection identities and all 121 target reflection equalities.

The pinned (+,-) singleton at 4 therefore forces at least seven distinct nonzero -- nodes. Each cross-sign group needs at least one actual bank, so every representation under the pinned architecture has at least

    7+1+1+7 = 16

actual banks. Additional zero nodes, repeated original banks, ineffective groups and sector cancellation cannot lower this count. In particular, (6,1,1,6) and every other actual-bank allocation totaling fourteen or fifteen are impossible in this same pinned model.

## 6. Controls, reproducibility and bounded stop

The new code verifies four synthetic necessary-recurrence controls: six nodes, three nodes, repeated nodes and a zero node. The smaller nonzero supports are padded with distinct nonzero field elements, and every recurrence residual is zero.

For each of the four sign orientations it separately checks legal (alpha,beta) values (0,5), (5,0), (1,1), (2,5). All 176 literal 11-by-11 branch inverses are computed by Gauss-Jordan elimination, with 352 two-sided inverse-product checks. Weighted literal banks have all 1,936 Weyl coefficients compared with the predicted original-grammar formula, including the original 1/11 factor. These are controls for the negative certificate, not a bank representation of F.

Run:

    python fresh_check.py --out replay

A cold run reproduced the four scientific output files byte for byte. COLD_REPLAY_VERIFICATION.json records their lengths and SHA-256 values. RUN.log and COLD_REPLAY.log retain summaries. The package manifest binds its complete contents; the external seal binds the final archive.

The declared census is decisive and finished. No seven-node search, sixteen-bank attainment search, extension-degree search, unpinned-singleton search, or broader Fourier algorithm search was started. No external service was written.

## 7. Honest relevance and priority calibration

This is a small exact finite-algebra result: the same original representation dictionary has a more substantial pinned base/extension-field separation than the previous bound established. It strengthens a carefully scoped mathematical example. Publication significance and novelty remain separate open questions requiring comparison and independent review.

It supplies no asymptotic FFT mechanism, no family at increasing N, no upper bound on scalar arithmetic, and no improvement in arithmetic operation count. Banks contain resolvents; counting them ignores both branch evaluation and extension-field arithmetic costs. The result should stay in the finite-algebra/publication queue rather than be cited as evidence of increased chances of beating FFT complexity.

The predecessor's proposed priority 87 (and review's 86) was an author proposal for the now-resolved attainment question. It is not a verified research-table score. Under the supplied rubric, this completed bounded census belongs to the completed/inactive 1–15 band. If a separately named independent exact review is queued, a recommendation of 56 fits the 50–64 consequential-uncertain-gate band: inputs and certificate are ready, the check is small, but its broader scientific leverage is limited and unproven. There is no time-critical or asymptotic-algorithm evidence supporting 80–100. No live table score was changed.

Independent review should check the complete sextic family, all-subset file, original-bank moment necessity, padding at fewer nodes, the reflection/counting argument, and the strict pinned-field scope. Further research must be separately authorized and scoped after that review; this bounded study stops here.
