# Bounded base-coefficient sextic extension gate

2026-10-14 01:06 UTC. Read the accepted lower-bound and attainment reviews
as inert sources. Use only newly authored exact standard-library Python.
No historical scientific code is executed or imported. No external writes.

Reconstruct the original grammar at N=11, q=13 over F23, with one effective
cross-sign node in each orientation, each pinned at alpha=4. Derive forced
b=1 and b=2 moments and all 529 monic degree-six annihilators with coefficients
in F23. Factor every polynomial exactly and verify irreducibility/product,
nonzero constant term, and separability. Report minimum splitting degree
and six-distinct-nonzero-root eligibility. In particular inspect degrees 2
and 3. This family restricts coefficients to F23 and cannot certify absence
of supports with extension-valued annihilators.

For eligible split sextics, attempt full eleven-sector compatibility with
both same-sign supports equal to the six roots and cross pins 4. Prefer d=2,
then d=3, and lexicographic (u,v) ordering. Stop the construction at the first
full legal original-bank witness, retaining failed compatibility records.
If no eligible d=2 or d=3 candidate admits a witness, report the complete
bounded failure in that class, without a universal claim. Factor census
still covers all 529 polynomials.

Witness obligations: explicit quotient field with irreducible modulus,
alpha/beta/eleven raw phase weights for each actual bank, nonzero legal
Delta, exactly six nonzero effective same-sign nodes each and pinned cross
singletons, all literal branch inverses checked on both sides, and all 121
entries compared with unmodified F[k,t]=13^(-kt). Include mutation controls,
source integrity, timings, full machine-readable output and a cold replay.

Any exact minimum conclusion must combine a fully checked witness with the
accepted pinned theorem b4(F23^d)>=14 when 5 does not divide d. No universal
minimum follows from factor patterns alone. No novelty, characteristic-zero,
unpinned, unrestricted, or asymptotic/arithmetic-speed claim.
