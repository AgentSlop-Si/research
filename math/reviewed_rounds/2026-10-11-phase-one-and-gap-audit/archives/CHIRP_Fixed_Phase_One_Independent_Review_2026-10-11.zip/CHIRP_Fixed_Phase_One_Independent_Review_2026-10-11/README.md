# Fixed phase-one CHIRP: independent acceptance

Read INDEPENDENT_REVIEW.md and REVIEW_VERDICT.json for the accepted scope and exact final source. General phase selection, production and priority remain open.

Reproduce fresh independent decisions with `python independent_controls.py`. Reproduce import-free Gauss controls with `python check_phase_one_identity.py`. The author replay runs in a copy of frozen/ with `python test_phase_one.py`; it writes its results and examples. The original author archive is included and remains labeled candidate; this external review supplies its independent acceptance.

No live Sheet change is included. The new table-correction pass was canceled and remains unapplied.
