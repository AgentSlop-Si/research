"""One fresh process for every engine and saved benchmark fixture.

This verifies saved exact ledgers and outputs. Timings are fresh diagnostics,
not replications of medians or evidence of a portable speedup.
"""
import hashlib,json,pathlib,subprocess,sys,time
HERE=pathlib.Path(__file__).resolve().parent
prior=json.loads((HERE/'BENCHMARK_RESULTS.json').read_text())
child='''import sys,json,time,hashlib
sys.path.insert(0,sys.argv[1])
import chirp_phase_one as c, accepted_dispatch_v1 as a, reference_v1 as d
p=json.load(sys.stdin);f={"candidate":c.recognize,"accepted_dispatch":a.recognize,"dense_reference":d.recognize}[p["engine"]]
t=time.perf_counter_ns();r=f(p["problem"],d.Limits(512,128,64,20000000));elapsed=time.perf_counter_ns()-t
print(json.dumps({"ledger":r["ledger"],"status":r["status"],"digest":hashlib.sha256(json.dumps([r["status"],r["dft"]],separators=(",",":")).encode()).hexdigest(),"api_ns":elapsed}))'''
out=[]
for case in prior['cases']:
 for engine,record in case['engines'].items():
  samples=record['samples']
  assert len(samples)==5
  assert all(x['ledger']==samples[0]['ledger'] for x in samples)
  assert all(x['decision_output_sha256']==samples[0]['decision_output_sha256'] for x in samples)
  t=time.perf_counter_ns()
  p=subprocess.run([sys.executable,'-c',child,str(HERE/'frozen')],input=json.dumps({'engine':engine,'problem':case['problem']}),text=True,capture_output=True,check=True)
  r=json.loads(p.stdout);r['process_ns']=time.perf_counter_ns()-t
  assert r['ledger']==samples[0]['ledger'],(case['name'],engine)
  assert r['digest']==samples[0]['decision_output_sha256'],(case['name'],engine)
  out.append({'fixture':case['name'],'engine':engine,**r})
result={'status':'PASS','fresh_samples':len(out),'author_samples_checked':sum(len(e['samples']) for c in prior['cases'] for e in c['engines'].values()),'scope':'Exact ledger/digest replay, one independent cold process per fixture/engine; no timing-median reproduction claim.','source_sha256':hashlib.sha256((HERE/'frozen/chirp_phase_one.py').read_bytes()).hexdigest(),'samples':out}
(HERE/'INDEPENDENT_COLD_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='samples'}))
