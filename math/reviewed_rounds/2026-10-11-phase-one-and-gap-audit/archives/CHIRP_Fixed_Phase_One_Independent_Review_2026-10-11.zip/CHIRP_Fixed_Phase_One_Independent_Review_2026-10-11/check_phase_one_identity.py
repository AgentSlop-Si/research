"""Independent finite-field checks of the candidate's phase-one output identity.

Fresh standalone code. Does not import any candidate or uploaded program.
These finite controls support, and do not replace, the algebraic proof.
"""
import json
from pathlib import Path


def main():
    counts = {"root_fields": 0, "gauss_entries": 0, "single_mode_outputs": 0}
    for p in (5, 13, 17, 41, 97, 193, 257):
        for n in (4, 8, 16, 32):
            if (p - 1) % n:
                continue
            for omega in range(2, p):
                if pow(omega, n, p) != 1 or pow(omega, n // 2, p) == 1:
                    continue
                counts["root_fields"] += 1
                roots = [pow(omega, j, p) for j in range(n)]
                g = [sum(roots[(j*j+s*j) % n] for j in range(n)) % p for s in range(n)]
                for s in range(n):
                    expected = 0 if s % 2 else g[0] * roots[-(s//2)**2 % n] % p
                    assert g[s] == expected, (p, n, omega, s)
                    counts["gauss_entries"] += 1
                for b in range(n):
                    delta = b % 2
                    h = ((b + delta) // 2) % (n // 2)
                    for k in range(n):
                        direct = sum(roots[(j*j + (b+k)*j) % n] for j in range(n)) % p
                        u = k // 2
                        split = 0 if k % 2 != delta else g[0]*roots[(-u*u-h*h-2*u*h) % n] % p
                        assert direct == split, (p, n, omega, b, k)
                        counts["single_mode_outputs"] += 1
    result = {"status": "PASS", "scope": "All primitive roots in listed prime fields; linearity extends single modes to their sums.", **counts}
    Path(__file__).with_suffix(".json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
