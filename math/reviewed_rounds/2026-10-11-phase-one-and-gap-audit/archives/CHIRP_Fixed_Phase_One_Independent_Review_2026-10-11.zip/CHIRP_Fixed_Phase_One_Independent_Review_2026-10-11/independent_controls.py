"""Fresh reviewer-owned controls for the frozen phase-one candidate."""
import ast
from collections import Counter
from dataclasses import replace
import hashlib
import itertools
import json
from pathlib import Path
import random
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "frozen"))
import chirp_phase_one as candidate
import reference_v1 as reference
import accepted_dispatch_v1 as previous

CAPS = reference.Limits(512, 128, 64, 20_000_000)
COUNT = Counter()
ROUTES = Counter()
rng = random.Random(202610112015)


def primitive(n, p):
    return [w for w in range(1, p) if pow(w, n, p) == 1 and all(pow(w, k, p) != 1 for k in range(1, n))]


def oracle(problem):
    n, p, w, x = [problem[k] for k in ("N", "p", "omega", "x")]
    roots = [pow(w, k, p) for k in range(n)]
    support_sizes = []
    for a in range(n // (2 if n % 2 == 0 else 1)):
        transformed = [sum(x[j] * roots[(-a*j*j-b*j) % n] for j in range(n)) % p for b in range(n)]
        support_sizes.append(sum(v != 0 for v in transformed))
    output = [sum(x[j] * roots[(j*k) % n] for j in range(n)) % p for k in range(n)]
    return support_sizes, output


def validate(problem):
    expected_supports, output = oracle(problem)
    r = candidate.recognize(problem, CAPS)
    expected = "MEMBER" if min(expected_supports) <= problem["r"] else "NONMEMBER"
    assert r["status"] == expected, (problem, r, expected_supports)
    assert r["ledger"]["work_units"] == sum(r["ledger"]["counts"].values())
    if expected == "MEMBER":
        assert r["dft"] == output
        witness = r["representation"]
        n, p, w = problem["N"], problem["p"], problem["omega"]
        assert len(witness["modes"]) <= problem["r"]
        assert len({m["b"] for m in witness["modes"]}) == len(witness["modes"])
        for j in range(n):
            reconstructed = sum(m["gamma"] * pow(w, witness["a"]*j*j+m["b"]*j, p) for m in witness["modes"]) % p
            assert reconstructed == problem["x"][j]
        COUNT["member_output_coordinates"] += n
    else:
        assert r["representation"] is None and r["dft"] is None
    if problem["N"] & (problem["N"]-1) == 0:
        if expected_supports[0] <= problem["r"]:
            assert r["route"] == "sparse_frontend"
        elif problem["N"] >= 4 and expected_supports[1] <= problem["r"]:
            assert r["route"] == "sparse_phase_one"
        else:
            assert r["route"] == "dense_reference_fallback"
    if r["route"] in ("sparse_frontend", "dense_reference_direct"):
        old = previous.recognize(problem, CAPS)
        assert r["ledger"] == old["ledger"]
        COUNT["unchanged_route_ledgers"] += 1
    if "fallback" in r["ledger"]:
        residual = replace(CAPS, max_work_units=CAPS.max_work_units-r["ledger"]["frontend"]["work_units"])
        d = reference.recognize(problem, residual)
        assert r["ledger"]["fallback"] == d["ledger"]
        assert r["status"] == d["status"] and r["dft"] == d["dft"]
        COUNT["residual_fallback_replays"] += 1
    COUNT["complete_independent_decisions"] += 1
    ROUTES[r["route"]] += 1
    return r


def run():
    # New independent raw and adversarial families, using all small roots.
    for n, p in ((4, 13), (8, 41), (16, 113), (32, 193)):
        for w in primitive(n, p):
            for trial in range(5):
                rank = 1 + trial % min(4, n-1)
                vectors = [[rng.randrange(p) for _ in range(n)]]
                for a in (0, 1, n//2-1):
                    bs = rng.sample(range(n), rank)
                    gs = [rng.randrange(1, p) for _ in bs]
                    vectors.append([sum(g*pow(w, a*j*j+b*j, p) for b,g in zip(bs, gs)) % p for j in range(n)])
                for vector in vectors:
                    validate(dict(N=n, p=p, r=rank, omega=w, x=vector))
                # Late corruption leaves the initial window unchanged at rank 1.
                if trial == 0:
                    vector = vectors[2][:]
                    vector[-1] = (vector[-1]+1) % p
                    validate(dict(N=n, p=p, r=rank, omega=w, x=vector))
    for n,p in ((3,7),(5,11),(6,13),(10,41)):
        w = primitive(n,p)[0]
        for r in (1,n-1):
            for _ in range(10):
                validate(dict(N=n,p=p,r=r,omega=w,x=[rng.randrange(p) for _ in range(n)]))
    # Budget prefixes and final write, with fixtures independently selected.
    fixtures=[]
    for n,p in ((4,13),(8,41)):
        w=primitive(n,p)[-1]
        for a in (1, n//2-1):
            fixtures.append(dict(N=n,p=p,r=1,omega=w,x=[3*pow(w,a*j*j+(n-1)*j,p)%p for j in range(n)]))
        fixtures.append(dict(N=n,p=p,r=1,omega=w,x=[1]+[0]*(n-1)))
    for problem in fixtures:
        full=validate(problem)
        total=full["ledger"]["work_units"]
        for cap in range(total):
            limited=candidate.recognize(problem,replace(CAPS,max_work_units=cap))
            assert limited["status"]=="LIMIT", (problem,cap,limited)
            assert limited["dft"] is None and limited["representation"] is None
            assert limited["ledger"]["work_units"] <= cap
            assert limited["ledger"]["work_units"] == sum(limited["ledger"]["counts"].values())
            COUNT["every_unit_cutoffs"] += 1
        assert candidate.recognize(problem,replace(CAPS,max_work_units=total))["dft"]==full["dft"]
    # No executable changes in the reused kernels, guard, meter or CLI.
    def defs(filename):
        tree=ast.parse((HERE/"frozen"/filename).read_text())
        return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
    old,new=defs("accepted_dispatch_v1.py"),defs("chirp_phase_one.py")
    for name in ("Meter","_append","_copy","_bm","_pruned_fft","_horner","_known_non_dyadic","main"):
        assert old[name]==new[name], name
        COUNT["unchanged_AST_definitions"] += 1
    result={"status":"PASS","counts":dict(COUNT),"routes":dict(ROUTES),"candidate_sha256":hashlib.sha256((HERE/"frozen/chirp_phase_one.py").read_bytes()).hexdigest()}
    (HERE/"INDEPENDENT_RESULTS.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    run()
