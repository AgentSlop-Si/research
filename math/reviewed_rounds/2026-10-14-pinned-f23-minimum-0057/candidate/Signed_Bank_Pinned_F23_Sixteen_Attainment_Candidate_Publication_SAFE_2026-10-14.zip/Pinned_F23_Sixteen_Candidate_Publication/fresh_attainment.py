#!/usr/bin/env python3
"""Fresh exact finite-field search; no imported historical scientific code."""
import argparse, csv, hashlib, itertools, json, math, pathlib, time, datetime
P, N, Q = 23, 11, 13
INV_N = pow(N, -1, P)

def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def solve(A, y):
    """RREF over F23; deterministic free variables zero; returns rank and solution."""
    m, n = len(A), len(A[0])
    rows = [[v % P for v in a] + [b % P] for a, b in zip(A, y)]
    pivots = []
    for col in range(n):
        pivot = next((i for i in range(len(pivots), m) if rows[i][col]), None)
        if pivot is None:
            continue
        k = len(pivots)
        rows[k], rows[pivot] = rows[pivot], rows[k]
        inv = pow(rows[k][col], -1, P)
        rows[k] = [v * inv % P for v in rows[k]]
        for i in range(m):
            if i != k and rows[i][col]:
                f = rows[i][col]
                rows[i] = [(x - f * z) % P for x, z in zip(rows[i], rows[k])]
        pivots.append(col)
    if any(not any(row[:n]) and row[n] for row in rows):
        return len(pivots), None
    x = [0] * n
    for i, col in enumerate(pivots):
        x[col] = rows[i][n]
    assert all(sum(a * b for a, b in zip(row, x)) % P == v % P for row, v in zip(A, y))
    return len(pivots), x

def identity():
    return [[int(i == j) for j in range(N)] for i in range(N)]

def mm(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(N)) % P for j in range(N)] for i in range(N)]

def inverse(A):
    # Literal modular inverse, not the geometric-series coefficient formula.
    z = [row[:] + [int(i == j) for j in range(N)] for i, row in enumerate(A)]
    for k in range(N):
        pivot = next(i for i in range(k, N) if z[i][k])
        z[k], z[pivot] = z[pivot], z[k]
        inv = pow(z[k][k], -1, P)
        z[k] = [v * inv % P for v in z[k]]
        for i in range(N):
            if i != k:
                scale = z[i][k]
                z[i] = [(x - scale * y) % P for x, y in zip(z[i], z[k])]
    assert [row[:N] for row in z] == identity()
    return [row[N:] for row in z]

def polynomial(nodes):
    c = [1]
    for x in nodes:
        d = [0] * (len(c) + 1)
        for i, v in enumerate(c):
            d[i] = (d[i] - x * v) % P
            d[i + 1] = (d[i + 1] + v) % P
        c = d
    return c

def gaussian(e, d, a, b, D):
    r, ell = (e * a) % N, (d * b) % N
    return D[e*d][r, ell] if r + ell < N else 0

def main(out):
    started = time.monotonic()
    start_wall = datetime.datetime.now(datetime.timezone.utc).isoformat()
    out.mkdir(parents=True, exist_ok=True)
    assert pow(Q, N, P) == 1 and all(pow(Q, k, P) != 1 for k in range(1, N))
    D, controls = {}, 0
    for sign in (1, -1):
        omega = pow(Q, sign % N, P)
        values = {}
        for degree in range(N + 1):
            for r in range(degree + 1):
                ell = degree - r
                # Enumerate words by the U-position set. A V before a U contributes omega.
                total = 0
                for positions in itertools.combinations(range(degree), r):
                    inversions = sum(pos - j for j, pos in enumerate(positions))
                    total += pow(omega, inversions, P)
                values[r, ell] = total % P
                if degree:
                    rec = (pow(omega, ell, P) * values.get((r-1, ell), 0) + values.get((r, ell-1), 0)) % P
                    assert rec == values[r, ell]
                    controls += 1
        assert all(values[r, N-r] == int(r in (0, N)) for r in range(N + 1))
        D[sign] = values
    F = [[pow(Q, (-k*t) % N, P) for t in range(N)] for k in range(N)]
    coeff = [[INV_N * sum(F[(t+a) % N][t] * pow(Q, (-b*t) % N, P) for t in range(N)) % P for b in range(N)] for a in range(N)]
    C = coeff[0][0]
    f = [[pow(Q, (3*(a+b)**2) % N, P) for b in range(N)] for a in range(N)]
    assert C == 18
    assert all(coeff[a][b] == C * f[a][b] % P for a in range(N) for b in range(N))
    reconstructed = [[sum(coeff[(k-t) % N][b] * pow(Q, b*t, P) for b in range(N)) % P for t in range(N)] for k in range(N)]
    assert reconstructed == F
    moments = {}
    for b in (1, 2):
        a = N-b
        g = gaussian(-1, 1, a, b, D)
        assert all(gaussian(e, d, a, b, D) == 0 for e,d in ((1,1),(1,-1),(-1,-1)))
        amp = f[a][b] * pow(pow(4, (-a) % N, P) * g % P, -1, P) % P
        seq = []
        for a in range(b, N-b):
            assert gaussian(1,-1,a,b,D) == gaussian(-1,-1,a,b,D) == 0
            den = gaussian(1,1,a,b,D)
            seq.append((f[a][b] - amp * pow(4, (-a) % N, P) * gaussian(-1,1,a,b,D)) * pow(den,-1,P) % P)
        moments[b] = {'start': b, 'forced_singleton_amplitude': amp, 'values': seq}
    v = moments[1]['values']
    survivors, prefix, residual_hist = [], [0, 0, 0], {}
    with (out / 'SEVEN_NODE_CENSUS.csv').open('w', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow([f'x{i}' for i in range(7)] + [f'h{i}' for i in range(8)] + ['residual_1', 'residual_2'])
        for nodes in itertools.combinations(range(1,P),7):
            h = polynomial(nodes)
            res = [sum(h[k] * v[s+k] for k in range(8)) % P for s in range(2)]
            writer.writerow(list(nodes) + h + res)
            prefix[0] += 1
            if res[0] == 0:
                prefix[1] += 1
                if res[1] == 0:
                    prefix[2] += 1
                    survivors.append(nodes)
    assert prefix[0] == math.comb(P-1, 7)
    save(out/'SURVIVORS.json', {'moments':moments, 'prefix_counts':prefix, 'supports':survivors})
    print('Complete seven-node census:', prefix, flush=True)
    pairs = itertools.chain(((s,s) for s in survivors), ((s,t) for s in survivors for t in survivors if s != t))
    tested, failures, selected, amplitudes, sector_ranks = 0, {}, None, None, None
    for plus, minus in pairs:
        tested += 1
        banks = [(1,1,x) for x in plus] + [(-1,1,4), (1,-1,4)] + [(-1,-1,x) for x in minus]
        sols, ranks = [], []
        for b in range(N):
            A = [[pow(x, (e*a) % N, P) * gaussian(e,d,a,b,D) % P for e,d,x in banks] for a in range(N)]
            rank, sol = solve(A, [f[a][b] for a in range(N)])
            if sol is None:
                failures[b] = failures.get(b, 0) + 1
                break
            sols.append(sol)
            ranks.append(rank)
        if len(sols) == N:
            selected, amplitudes, sector_ranks = banks, sols, ranks
            break
    summary = {'field': P, 'N':N, 'q':Q, 'cross_singleton_alpha':4, 'prefix_counts':prefix, 'pairs_tested':tested, 'pair_budget':len(survivors)**2, 'pair_failures_first_sector':failures, 'gaussian_word_recurrence_checks':controls, 'target_coefficients_checked':121, 'full_target_recomposition':True}
    if selected is None:
        summary.update({'status':'EXHAUSTED_DECLARED_FAMILY', 'no_broader_nonexistence_claim':True})
    else:
        bank_results, branches, aggregate = [], [], [[0]*N for _ in range(N)]
        for i, (e,d,alpha) in enumerate(selected):
            beta = 1
            Delta = (1-pow(alpha,N,P)-pow(beta,N,P)) % P
            assert Delta != 0
            Ab = [amplitudes[b][i] for b in range(N)]
            weights = [Delta * C * sum(Ab[b] * pow(Q,(-e*b*j) % N,P) for b in range(N)) % P for j in range(N)]
            recovered = [sum(weights[j] * pow(Q,(e*b*j) % N,P) for j in range(N)) * pow((N*Delta*C) % P,-1,P) % P for b in range(N)]
            assert recovered == Ab and any(Ab)
            bank_matrix = [[0]*N for _ in range(N)]
            for j in range(N):
                R = identity()
                for t in range(N):
                    R[(t+e) % N][t] = (R[(t+e) % N][t] - alpha) % P
                    R[t][t] = (R[t][t] - beta * pow(Q,(e*d*j+d*t) % N,P)) % P
                inverse_R = inverse(R)
                assert mm(R,inverse_R) == identity()
                assert mm(inverse_R,R) == identity()
                branches.append({'bank_index':i, 'phase':j, 'inverse':inverse_R, 'left_product_is_identity':True, 'right_product_is_identity':True})
                for k in range(N):
                    for t in range(N):
                        bank_matrix[k][t] = (bank_matrix[k][t] + INV_N * weights[j] * inverse_R[k][t]) % P
            assert any(v for row in bank_matrix for v in row)
            # Compare all 121 coefficients of each literal bank with the sector formula.
            for a in range(N):
                for b in range(N):
                    actual = INV_N * sum(bank_matrix[(t+a) % N][t] * pow(Q,(-b*t) % N,P) for t in range(N)) % P
                    expected = C * Ab[b] * pow(alpha,(e*a) % N,P) * gaussian(e,d,a,b,D) % P
                    assert actual == expected
            bank_results.append({'index':i, 'epsilon':e, 'delta':d, 'alpha':alpha, 'beta':beta, 'Delta':Delta, 'normalized_sector_amplitudes':Ab, 'weights':weights, 'matrix':bank_matrix})
            for k in range(N):
                for t in range(N):
                    aggregate[k][t] = (aggregate[k][t] + bank_matrix[k][t]) % P
        mismatches = [{'row':k,'col':t,'actual':aggregate[k][t],'target':F[k][t]} for k in range(N) for t in range(N) if aggregate[k][t] != F[k][t]]
        assert not mismatches
        assert len(bank_results) == 16 and len(branches) == 176
        save(out/'WITNESS.json', {'field':P, 'N':N, 'q':Q, 'normalization':'1/11', 'banks':bank_results, 'target':F, 'sum':aggregate, 'mismatches':mismatches, 'sector_ranks':sector_ranks})
        save(out/'LITERAL_INVERSES.json', branches)
        summary.update({'status':'VERIFIED_SIXTEEN_BANK_WITNESS', 'same_sign_plus':[x for e,d,x in selected if e==d==1], 'same_sign_minus':[x for e,d,x in selected if e==d==-1], 'orientation_counts':[7,1,1,7], 'sector_ranks':sector_ranks, 'literal_inversions':176, 'two_sided_inverse_product_checks':352, 'bank_weyl_coefficient_checks':1936, 'nonzero_bank_count':16, 'raw_weight_count':176, 'literal_target_entries_checked':121, 'target_mismatches':0})
    save(out/'RESULTS.json', summary)
    save(out/'RUN_TIMING.json', {'host_start_utc':start_wall, 'host_end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds':time.monotonic()-started, 'token_usage':'unavailable', 'errors':[]})
    print(json.dumps(summary, sort_keys=True), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=pathlib.Path, required=True)
    args = parser.parse_args()
    main(args.out)
