# Bounded pinned sixteen-bank attainment contract

Declared before new scientific computations at observed UTC 2026-10-14 00:49:52.

Work over F23 only, with N=11, q=13, the literal target F[k,t]=13^(-kt), S e_t=e_(t+1), T e_t=13^t e_t, and original banks

B(e,d,alpha,beta,w)=(1/11) sum_(j=0)^10 w_j (I-alpha S^e-beta 13^(edj) T^d)^(-1).

Require Delta=1-alpha^11-beta^11 nonzero. Search exactly seven distinct nonzero alpha nodes for ++, seven for --, and one alpha=4 in each cross orientation. All witnesses use beta=1, a legal subfamily because alpha is nonzero. Do not change the pins, field, target, generators, or primitive.

Finite budget: enumerate all binomial(22,7)=170544 seven-element nonzero supports. Retain supports satisfying both length-eight recurrence windows in the freshly derived b=1 forced moments. Test the complete eleven-sector linear system for support pairs in deterministic order: equal-support pairs first, then all remaining ordered pairs. The pair budget is the square of the survivor count, no more than 170544^2=29085255936 pairs. Stop immediately on the first literal fully verified witness or after the complete declared pair list. Necessary recurrence compatibility alone does not count as a witness. A failed finite search is reported only for this exact searched family.

For a witness, reconstruct all raw weights, independently invert every one of 176 literal resolvent matrices by modular Gauss-Jordan elimination, check both inverse products, confirm every bank is nonzero and every effective node is present, and compare all 121 literal target entries. Re-run the fresh program in a cold output directory and compare deterministic results. Read historical proof and data as inert input only; never execute, compile or import their programs. No external writes.

Save the full witness, scientific checks, source hashes, run timing and any errors. Token usage is unavailable unless exposed by the environment. No asymptotic, unpinned, extension-field, characteristic-zero or novelty claim follows from this task.
