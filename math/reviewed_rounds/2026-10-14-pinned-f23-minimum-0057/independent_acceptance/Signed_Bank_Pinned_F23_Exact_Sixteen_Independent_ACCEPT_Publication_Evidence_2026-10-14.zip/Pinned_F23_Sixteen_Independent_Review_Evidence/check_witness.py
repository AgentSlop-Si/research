#!/usr/bin/env python3
"""Independent finite-field review. Standard library only; no producer imports."""
import argparse
import copy
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import time
import traceback
import zipfile

P, N, Q = 23, 11, 13
ROOT = Path(__file__).resolve().parent.parent
CAND = ROOT / 'pinned_sixteen_candidate'
LOWER = ROOT / 'accepted_pinned_lower_bound'
PIN = 'ad1437b4c796550d02772b7cedd78d6ff6109b180e2d9853a08b176a415dbc81'
LOWER_PIN = 'a2d110738cbfb31d51f6a20ad1fd7343e7932149088f11cee18a108c7bf2afc2'
ARCHIVE = ROOT / 'Signed_Bank_Pinned_F23_Sixteen_Attainment_Candidate_2026-10-14.zip'
ARCHIVE_PIN = '82cf62eb1a9c430c2dc833a092821dbe2988ab24a5ac6540ae6d401f33d826f1'
ORIENT = [(1, 1), (-1, 1), (1, -1), (-1, -1)]

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

def zero():
    return [[0] * N for _ in range(N)]

def eye():
    return [[int(r == c) for c in range(N)] for r in range(N)]

def product(a, b):
    return [[sum(a[r][k] * b[k][c] for k in range(N)) % P
             for c in range(N)] for r in range(N)]

def add_scaled(a, b, scale):
    return [[(a[r][c] + scale * b[r][c]) % P for c in range(N)]
            for r in range(N)]

def nonzero(a):
    return any(v for row in a for v in row)

def differences(a, b):
    return [[r, c, a[r][c], b[r][c]] for r in range(N)
            for c in range(N) if a[r][c] != b[r][c]]

def branch(alpha, beta, eps, delta, phase):
    """Construct I-alpha*S^eps-beta*q^(eps*delta*phase)*T^delta literally."""
    out = eye()
    for t in range(N):
        out[(t + eps) % N][t] = (out[(t + eps) % N][t] - alpha) % P
        out[t][t] = (out[t][t] - beta * pow(Q, eps*delta*phase + delta*t, P)) % P
    return out

def cyclic_inverse(matrix, alpha, eps):
    """Solve every column by affine propagation around the eleven-cycle.

    Row r says d_r*x_r-alpha*x_(r-eps)=y_r. Express consecutive x entries
    as u*x_0+v, close the cycle, then substitute. No elimination routines,
    quantum-binomial formulas, candidate matrices, or amplitudes are used.
    """
    if not alpha % P:
        raise ValueError('cyclic inverse requires a nonzero alpha')
    ia = pow(alpha, -1, P)
    ans = zero()
    for col in range(N):
        coeff = {0: (1, 0)}
        r, u, v = 0, 1, 0
        for step in range(N):
            u = matrix[r][r] * u * ia % P
            v = (matrix[r][r] * v - int(r == col)) * ia % P
            r = (r - eps) % N
            if step + 1 < N:
                coeff[r] = (u, v)
        if u == 1:
            raise ValueError('singular cycle closure')
        x0 = v * pow(1-u, -1, P) % P
        for r, (a, b) in coeff.items():
            ans[r][col] = (a*x0 + b) % P
    return ans

def weyl(a):
    return [[sum(a[(t+r) % N][t] * pow(Q, -s*t, P) for t in range(N))
             * pow(N, -1, P) % P for s in range(N)] for r in range(N)]

def qbinomial(omega, r, ell):
    """Compute ordered-word coefficients by Pascal recurrence, not product."""
    if r + ell >= N:
        return 0
    vals = [[0] * (ell+1) for _ in range(r+1)]
    vals[0][0] = 1
    for i in range(r+1):
        for j in range(ell+1):
            if i+j:
                vals[i][j] = ((pow(omega, j, P)*vals[i-1][j] if i else 0)
                              + (vals[i][j-1] if j else 0)) % P
    return vals[r][ell]

def g(eps, delta, a, b):
    return qbinomial(pow(Q, eps*delta, P), eps*a % N, delta*b % N)

def rref(a):
    a = copy.deepcopy(a)
    row = 0
    pivots = []
    for col in range(len(a[0])):
        pivot = next((k for k in range(row, len(a)) if a[k][col]), None)
        if pivot is None:
            continue
        a[row], a[pivot] = a[pivot], a[row]
        inv = pow(a[row][col], -1, P)
        a[row] = [v*inv % P for v in a[row]]
        for k in range(len(a)):
            if k != row:
                scale = a[k][col]
                a[k] = [(x-scale*y) % P for x,y in zip(a[k], a[row])]
        pivots.append(col)
        row += 1
        if row == len(a):
            break
    return a, pivots

def scope(banks):
    assert len(banks) == 16
    assert [sum((b['epsilon'], b['delta']) == o for b in banks) for o in ORIENT] == [7,1,1,7]
    for b in banks:
        assert type(b['alpha']) is int and 0 < b['alpha'] < P
        assert b['beta'] == 1
        assert len(b['weights']) == N and all(type(w) is int and 0 <= w < P for w in b['weights'])
        assert (1-pow(b['alpha'],N,P)-pow(b['beta'],N,P)) % P != 0
        if b['epsilon'] != b['delta']:
            assert b['alpha'] == 4
    for o in [ORIENT[0], ORIENT[3]]:
        assert len({b['alpha'] for b in banks if (b['epsilon'],b['delta']) == o}) == 7

def reject(call):
    try:
        call()
    except (AssertionError, ValueError):
        return True
    return False

def main(out):
    initial = {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
               for base in [CAND, LOWER] for p in sorted(base.rglob('*')) if p.is_file()}
    assert digest((CAND/'outputs/WITNESS.json').read_bytes()) == PIN
    assert digest((LOWER/'REVIEW.md').read_bytes()) == LOWER_PIN
    archive_bytes = ARCHIVE.read_bytes()
    assert digest(archive_bytes) == ARCHIVE_PIN
    initial[str(ARCHIVE.relative_to(ROOT))] = {'bytes':len(archive_bytes),'sha256':ARCHIVE_PIN}
    with zipfile.ZipFile(ARCHIVE) as archive:
        candidate_manifest = json.loads(archive.read('MANIFEST.json'))
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == set(candidate_manifest) | {'MANIFEST.json'}
        for name, entry in candidate_manifest.items():
            data = archive.read(name)
            assert len(data) == entry['bytes'] and digest(data) == entry['sha256']
        for name in archive.namelist():
            assert archive.read(name) == (CAND/name).read_bytes()
        assert archive.read('source_evidence/ACCEPTED_LOWER_BOUND_REVIEW.md') == (LOWER/'REVIEW.md').read_bytes()
        assert archive.read('source_evidence/ACCEPTED_LOWER_BOUND.json') == (LOWER/'ACCEPTANCE.json').read_bytes()
    declared_source_pins = []
    for line in (CAND/'SOURCE_HASHES.txt').read_text().splitlines():
        sha, rel = line.split(maxsplit=1)
        assert digest((ROOT/rel).read_bytes()) == sha
        declared_source_pins.append({'path': rel, 'sha256': sha})
        initial[rel] = {'bytes':(ROOT/rel).stat().st_size,'sha256':sha}
    manifest_rows = json.loads((LOWER/'MANIFEST.json').read_text())
    for row in manifest_rows:
        data = (LOWER/row['path']).read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
    replay_rows = json.loads((CAND/'REPLAY_VERIFICATION.json').read_text())
    for row in replay_rows:
        data = (CAND/'outputs'/row['name']).read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert data == (CAND/'cold_replay'/row['name']).read_bytes()

    raw = json.loads((CAND/'outputs/WITNESS.json').read_text())
    assert (raw['field'], raw['N'], raw['q'], raw['normalization']) == (P,N,Q,'1/11')
    assert pow(Q,N,P) == 1 and len({pow(Q,k,P) for k in range(N)}) == N
    banks = raw['banks']
    scope(banks)
    assert [b['index'] for b in banks] == list(range(16))
    inv11 = pow(N,-1,P)
    target = [[pow(Q,-r*c,P) for c in range(N)] for r in range(N)]
    target_coeff = weyl(target)
    C = target_coeff[0][0]
    assert C == 18
    assert target_coeff == [[C*pow(Q,3*(a+b)**2,P) % P for b in range(N)] for a in range(N)]
    total = zero()
    rebuilt, branches, cache = [], [], {}
    supplied_branches = json.loads((CAND/'outputs/LITERAL_INVERSES.json').read_text())
    assert len(supplied_branches) == 176
    supplied_map = {(x['bank_index'],x['phase']):x for x in supplied_branches}
    assert len(supplied_map) == 176
    for i,b in enumerate(banks):
        eps,delta,alpha,beta = b['epsilon'],b['delta'],b['alpha'],b['beta']
        determinant_parameter = (1-pow(alpha,N,P)-pow(beta,N,P)) % P
        assert b['Delta'] == determinant_parameter
        matrix = zero()
        for j,w in enumerate(b['weights']):
            a = branch(alpha,beta,eps,delta,j)
            v = cyclic_inverse(a,alpha,eps)
            assert product(a,v) == eye() and product(v,a) == eye()
            assert v == supplied_map[i,j]['inverse']
            cache[i,j] = (a,v)
            branches.append({'bank_index':i,'phase':j,'matrix':a,'inverse':v})
            matrix = add_scaled(matrix,v,w*inv11)
        assert nonzero(matrix)
        assert matrix == b['matrix']
        h = [pow(beta,delta*s % N,P)*inv11*pow(determinant_parameter,-1,P)
             *sum(w*pow(Q,eps*delta*j*(delta*s % N),P) for j,w in enumerate(b['weights'])) % P
             for s in range(N)]
        normalized = [v*pow(C,-1,P) % P for v in h]
        assert any(h) and normalized == b['normalized_sector_amplitudes']
        wc = weyl(matrix)
        formula = [[pow(alpha,eps*a % N,P)*g(eps,delta,a,s)*h[s] % P
                    for s in range(N)] for a in range(N)]
        assert wc == formula
        rebuilt.append({'index':i,'epsilon':eps,'delta':delta,'alpha':alpha,'beta':beta,
                        'weights':b['weights'],'Delta':determinant_parameter,
                        'matrix':matrix,'normalized_sector_amplitudes':normalized,'weyl_coefficients':wc})
        total = add_scaled(total,matrix,1)
    assert total == target == raw['target'] == raw['sum']
    assert not raw['mismatches']

    ranks=[]
    for s in range(N):
        design = [[pow(b['alpha'],b['epsilon']*a % N,P)*g(b['epsilon'],b['delta'],a,s) % P
                   for b in banks] for a in range(N)]
        ranks.append(len(rref(design)[1]))
    assert ranks == raw['sector_ranks']

    # Rebuild the two necessary moment windows of the accepted lower bound.
    f = [[v*pow(C,-1,P) % P for v in row] for row in target_coeff]
    moments, forced = {}, {}
    for s in [1,2]:
        a = N-s
        assert all(g(e,d,a,s)==0 for e,d in [(1,1),(1,-1),(-1,-1)])
        ts = f[a][s]*pow(pow(4,(-a)%N,P)*g(-1,1,a,s),-1,P) % P
        forced[s]=ts
        vals=[]
        for a in range(s,N-s):
            assert g(1,-1,a,s)==0 and g(-1,-1,a,s)==0
            val=(f[a][s]-ts*pow(4,(-a)%N,P)*g(-1,1,a,s))*pow(g(1,1,a,s),-1,P) % P
            vals.append(val)
        moments[s]=vals
    assert forced == {1:22,2:20}
    assert moments == {1:[19,4,20,14,20,3,14,16,8],2:[21,15,14,11,13,22,19]}
    hankel = [moments[1][k:k+7] for k in range(3)] + [moments[2]]
    reduced,pivots=rref(hankel)
    assert pivots==[0,1,2,3]
    census=[]
    hist=[0]*7
    for u,v in itertools.product(range(P),repeat=2):
        coeff=[0,0,0,0,u,v,1]
        for row,pivot in zip(reduced,pivots):
            coeff[pivot]=-sum(row[k]*coeff[k] for k in [4,5,6]) % P
        assert all(sum(x*y for x,y in zip(row,coeff)) % P == 0 for row in hankel)
        roots=[x for x in range(1,P) if sum(c*pow(x,k,P) for k,c in enumerate(coeff)) % P == 0]
        hist[len(roots)]+=1
        census.append({'u':u,'v':v,'coefficients_ascending':coeff,'nonzero_roots':roots})
    assert hist==[190,214,92,26,5,2,0]
    # Exact literal reflection checks, without a transformed target assumption.
    def refl(a):
        return [[a[-r % N][-c % N] for c in range(N)] for r in range(N)]
    assert refl(target)==target
    for i,b in enumerate(banks):
        for j in range(N):
            assert refl(cache[i,j][0]) == branch(b['alpha'],b['beta'],-b['epsilon'],-b['delta'],j)
    lb={'source_review_sha256':LOWER_PIN,'C':C,'forced_cross_amplitudes':forced,
        'moments':moments,'hankel':hankel,'rref':reduced,'sextic_histogram':hist,
        'monic_sextics_checked':len(census),'six_distinct_nonzero_roots_found':0,
        'bank_lower_bound':16,'scope_includes_beta_one_witness':True,
        'reflection_checks':177,'family':census}

    # Negative controls alter in-memory copies only, never the source witness.
    mutations=[]
    for i,b in enumerate(banks):
        for j in range(N):
            # Rebuilding the affected bank after w_j -> w_j+1 is exactly this
            # linear update, since the literal resolvents do not depend on w.
            perturbed=add_scaled(total,cache[i,j][1],inv11)
            delta_entries=differences(perturbed,target)
            assert delta_entries
            mutations.append({'kind':'single_raw_weight_increment','bank':i,'phase':j,
                              'mismatch_count':len(delta_entries),'first_mismatch':delta_entries[0]})
    for i,b in enumerate(rebuilt):
        d=differences(add_scaled(total,b['matrix'],-1),target)
        assert d
        mutations.append({'kind':'delete_original_bank','bank':i,'mismatch_count':len(d)})
    a,v=cache[0,0]
    corrupt=copy.deepcopy(v); corrupt[0][0]=(corrupt[0][0]+1)%P
    assert product(a,corrupt)!=eye() and product(corrupt,a)!=eye()
    mutations.append({'kind':'inverse_entry_increment','two_sided_products_reject':True})
    no_norm=add_scaled(zero(),total,N)
    assert differences(no_norm,target)
    mutations.append({'kind':'omit_one_over_eleven','mismatch_count':len(differences(no_norm,target))})
    bad=copy.deepcopy(banks); bad[7]['alpha']=5
    assert reject(lambda:scope(bad))
    mutations.append({'kind':'cross_pin_alpha_four_to_five','scope_rejects':True})
    bad=copy.deepcopy(banks); bad[0]['alpha']=0
    assert reject(lambda:scope(bad))
    assert reject(lambda:cyclic_inverse(branch(0,1,1,1,0),0,1))
    mutations.append({'kind':'singular_alpha_zero_beta_one','legality_and_solver_reject':True})
    bad=copy.deepcopy(banks); bad[0]['epsilon']=-1
    assert reject(lambda:scope(bad))
    mutations.append({'kind':'orientation_mutation','scope_rejects':True})
    assert digest((CAND/'outputs/WITNESS.json').read_bytes()+b' ') != PIN
    mutations.append({'kind':'one_byte_witness_mutation','hash_pin_rejects':True})

    for rel,old in initial.items():
        data=(ROOT/rel).read_bytes()
        assert {'bytes':len(data),'sha256':digest(data)}==old, rel
    result={'verdict':'ACCEPT_EXACT_PINNED_MINIMUM_16','field':P,'N':N,'q':Q,
            'normalization':'1/11','original_bank_count':16,'orientation_counts':[7,1,1,7],
            'same_sign_supports':[[1,2,3,4,5,6,9],[1,2,3,4,5,6,9]],
            'cross_alpha_pins':[4,4],'witness_beta':1,'raw_weights_checked':176,
            'literal_branches_inverted':176,'two_sided_inverse_products':352,
            'rebuilt_bank_matrix_entries_checked':1936,'bank_weyl_coefficients_checked':1936,
            'normalized_amplitudes_checked':176,'literal_target_entries_checked':121,
            'target_mismatches':0,'nonzero_banks':16,'sector_ranks':ranks,
            'negative_mutation_controls':len(mutations),'source_files_unchanged':len(initial),
            'accepted_lower_bound_manifest_entries_verified':len(manifest_rows),
            'declared_source_pins_verified':len(declared_source_pins),
            'candidate_archive_sha256':ARCHIVE_PIN,
            'candidate_manifest_entries_verified':len(candidate_manifest),
            'producer_cold_replay_files_verified':len(replay_rows),
            'witness_sha256':PIN,'lower_bound_review_sha256':LOWER_PIN,
            'no_producer_or_historical_code_executed':True,'no_external_writes':True,
            'model_token_usage':'unknown','errors':[],
            'scope':'Original signed-bank grammar over F23, N=11, q=13, exactly one effective alpha node in each cross-sign orientation, both at alpha=4; arbitrary legal beta allowed in the minimization.',
            'excluded_claims':['unpinned optimum','other fields','characteristic-zero transfer',
                               'historical novelty','asymptotic or arithmetic-speed improvement']}
    write(out/'REBUILT_BRANCHES.json',branches)
    write(out/'REBUILT_WITNESS.json',{'banks':rebuilt,'sum':total,'target':target,'target_coefficients':target_coeff})
    write(out/'LOWER_BOUND_CHECK.json',lb)
    write(out/'MUTATION_CONTROLS.json',mutations)
    write(out/'SOURCE_INTEGRITY.json',{'files_unchanged':initial,'declared_source_pins':declared_source_pins})
    write(out/'RESULTS.json',result)
    print(json.dumps(result,sort_keys=True))

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--root',type=Path,default=ROOT,
                        help='Source workspace root, or the packaged source_tree directory.')
    args=parser.parse_args()
    ROOT=args.root.resolve()
    CAND=ROOT/'pinned_sixteen_candidate'
    LOWER=ROOT/'accepted_pinned_lower_bound'
    ARCHIVE=ROOT/'Signed_Bank_Pinned_F23_Sixteen_Attainment_Candidate_2026-10-14.zip'
    args.output.mkdir(parents=True,exist_ok=True)
    started=utc(); wall=time.monotonic(); cpu=time.process_time(); errors=[]
    try:
        main(args.output)
    except Exception:
        errors.append(traceback.format_exc())
        raise
    finally:
        write(args.output/'TIMING.json',{'started_utc':started,'ended_utc':utc(),
              'wall_seconds':time.monotonic()-wall,'process_cpu_seconds':time.process_time()-cpu,
              'model_token_usage':'unknown','errors':errors})
