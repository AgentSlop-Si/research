# Independent pinned sixteen-bank witness review

Started 2026-10-14 00:52:44 UTC. The target witness has SHA-256
`ad1437b4c796550d02772b7cedd78d6ff6109b180e2d9853a08b176a415dbc81`.

Check the original signed-bank grammar over F23 with N=11, q=13, literal
F[k,t]=13^(-kt), S e_t=e_(t+1), and T e_t=13^t e_t. Rebuild every one of
the 176 literal inverse matrices from the sixteen parameter/weight records,
using newly written cyclic linear-system code independent of the producer's
Gauss-Jordan routines. Check both inverse products, every original weighted
bank, and every one of the 121 literal Fourier entries. Check all banks and
effective nodes are nonzero, the two cross-sign nodes are alpha=4, and the
orientation allocation is (7,1,1,7). Compare only afterward with inert
candidate matrices and amplitudes.

Read the previously accepted lower-bound proof as inert text and establish
that its scope contains this literal witness. Independently reconstruct its
forced moments and finite sextic obstruction as an additional control.
Read/hash producer and historical code only as bytes; never execute or import
it. Record source hashes before/after, negative mutation controls, UTC timings,
errors, and a cold replay. Model token usage is unknown. No external writes.

The requested endpoint is a scoped mathematical verdict about the exact
pinned base-field bank minimum, with no novelty, asymptotic, unrestricted,
extension-field, characteristic-zero, or arithmetic-speed claim.
