# Cubic-field thirteen-bank candidate

Read REPORT.md for the result and CONTRACT.md for the predeclared three-case scope. The standalone original raw-weight certificate is outputs/RAW_CERTIFICATE.json; outputs/WITNESS.json adds derivation and matrices. outputs/BRANCHES.json contains every literal matrix and inverse for all three cases. Run only the new self-contained Python3 program:

    python3 -I fresh_thirteen_gate.py --out reproduced

No external libraries are needed. All field elements in the certificates are explicit triples in F23 in the basis1,u,u², where u³+13u²+13u+13=0. Source evidence is inert documentation. This is an author-certified upper bound, pending independent acceptance; no minimum is claimed here.
