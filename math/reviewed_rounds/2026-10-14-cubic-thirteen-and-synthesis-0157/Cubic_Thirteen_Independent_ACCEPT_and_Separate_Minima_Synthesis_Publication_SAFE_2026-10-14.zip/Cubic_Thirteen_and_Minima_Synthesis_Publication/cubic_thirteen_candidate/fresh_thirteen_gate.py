#!/usr/bin/env python3
"""Fresh bounded F23^3 original-bank test; standard library only."""
import argparse, functools, hashlib, itertools, json, pathlib, time
P=23; N=11; Q=13; FIELD_ORDER=P**3
Z=(0,0,0); O=(1,0,0); U=(0,1,0)
def k(x): return (x%P,0,0)
def add(a,b): return tuple((a[i]+b[i])%P for i in range(3))
def neg(a): return tuple(-x%P for x in a)
def sub(a,b): return add(a,neg(b))
@functools.lru_cache(None)
def mul(a,b):
    c=[0]*5
    for i in range(3):
        for j in range(3): c[i+j]+=a[i]*b[j]
    for d in (4,3):
        t=c[d]%P
        for j in range(3): c[d-3+j]-=13*t
    return tuple(x%P for x in c[:3])
def fpow(a,n):
    if n<0: return fpow(inv(a),-n)
    r=O
    while n:
        if n&1: r=mul(r,a)
        a=mul(a,a); n//=2
    return r
@functools.lru_cache(None)
def inv(a):
    if a==Z: raise ZeroDivisionError('zero field inverse')
    r=fpow(a,FIELD_ORDER-2); assert mul(a,r)==O
    return r
def fsum(xs):
    r=Z
    for x in xs:r=add(r,x)
    return r
def dot(a,b): return fsum(mul(x,y) for x,y in zip(a,b))
def eye(n): return [[O if i==j else Z for j in range(n)] for i in range(n)]
def mm(a,b): return [[dot(row,col) for col in zip(*b)] for row in a]
def poly_eval(c,x):
    r=Z
    for a in reversed(c):r=add(mul(r,x),a)
    return r
def poly_prod(a,b):
    c=[Z]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]=add(c[i+j],mul(x,y))
    return c
def solve(a,b):
    rows=len(a); cols=len(a[0]); r=[list(x)+[y] for x,y in zip(a,b)]; tr=eye(rows); piv=[]
    for col in range(cols):
        pivot=next((i for i in range(len(piv),rows) if r[i][col]!=Z),None)
        if pivot is None:continue
        j=len(piv);r[j],r[pivot]=r[pivot],r[j]; tr[j],tr[pivot]=tr[pivot],tr[j]
        scale=inv(r[j][col]);r[j]=[mul(x,scale) for x in r[j]];tr[j]=[mul(x,scale) for x in tr[j]]
        for i in range(rows):
            if i==j or r[i][col]==Z:continue
            fac=r[i][col];r[i]=[sub(x,mul(fac,y)) for x,y in zip(r[i],r[j])];tr[i]=[sub(x,mul(fac,y)) for x,y in zip(tr[i],tr[j])]
        piv.append(col)
        if len(piv)==rows:break
    bad=[i for i in range(rows) if all(x==Z for x in r[i][:-1]) and r[i][-1]!=Z]
    record={'rank':len(piv),'augmented_rank':len(piv)+bool(bad),'consistent':not bad,'pivots':piv,'matrix':a,'rhs':b,'rref_augmented':r}
    if bad:
        lam=tr[bad[0]]; assert all(dot(lam,col)==Z for col in zip(*a));val=dot(lam,b);assert val!=Z
        record.update(left_null_vector=lam,target_pairing=val)
    else:
        x=[Z]*cols
        for i,col in enumerate(piv):x[col]=r[i][-1]
        assert all(dot(row,x)==v for row,v in zip(a,b))
        record['solution']=x
    return record
def gaussian(e,d):
    counts={}
    for n in range(N+1):
        for bits in itertools.product((0,1),repeat=n):
            r=bits.count(0); ell=n-r; vbefore=0; inversions=0
            for bit in bits:
                if bit:vbefore+=1
                else:inversions+=vbefore
            counts[r,ell]=(counts.get((r,ell),0)+pow(Q,(e*d*inversions)%N,P))%P
    assert counts[N,0]==counts[0,N]==1
    assert all(counts[r,N-r]==0 for r in range(1,N))
    for (r,ell),v in counts.items():
        if r+ell>=N:continue
        prod=1
        for t in range(1,r+1):prod=prod*(1-pow(Q,(e*d*(ell+t))%N,P))*pow((1-pow(Q,(e*d*t)%N,P))%P,-1,P)%P
        assert prod==v
    return [[k(counts[((e*a)%N,(d*b)%N)]) if (e*a)%N+(d*b)%N<N else Z for b in range(N)] for a in range(N)]
def matrix_inverse(a):
    n=len(a);r=[list(row)+unit for row,unit in zip(a,eye(n))]
    for j in range(n):
        p=next((i for i in range(j,n) if r[i][j]!=Z),None)
        if p is None:raise ValueError('singular literal matrix')
        r[j],r[p]=r[p],r[j];scale=inv(r[j][j]);r[j]=[mul(x,scale) for x in r[j]]
        for i in range(n):
            if i==j or r[i][j]==Z:continue
            scale=r[i][j];r[i]=[sub(x,mul(scale,y)) for x,y in zip(r[i],r[j])]
    assert [row[:n] for row in r]==eye(n)
    return [row[n:] for row in r]
def literal_branch(bank,j,phase_sign=1):
    e,d,x,beta=bank['epsilon'],bank['delta'],bank['alpha'],bank['beta'];m=eye(N)
    for t in range(N):
        m[(t+e)%N][t]=sub(m[(t+e)%N][t],x)
        m[t][t]=sub(m[t][t],mul(beta,k(pow(Q,(phase_sign*e*d*j+d*t)%N,P))))
    return m
def matrix_sum(ms):return [[fsum(m[r][t] for m in ms) for t in range(N)] for r in range(N)]
def scale_matrix(m,c):return [[mul(v,c) for v in row] for row in m]
def matrix_sub(a,b):return [[sub(x,y) for x,y in zip(ar,br)] for ar,br in zip(a,b)]
def entry_mismatches(a,b):return sum(x!=y for ar,br in zip(a,b) for x,y in zip(ar,br))
def coefficient(m,a,b):return mul(k(pow(N,-1,P)),fsum(mul(m[(t+a)%N][t],k(pow(Q,(-b*t)%N,P))) for t in range(N)))
def functional(m,lam,b):return dot(lam,[coefficient(m,a,b) for a in range(N)])
def secondary_product(a,b):
    # Independent polynomial dictionary multiplication and monic long division.
    terms={}
    for i,x in enumerate(a):
        for j,y in enumerate(b):terms[i+j]=(terms.get(i+j,0)+x*y)%P
    while terms and max(terms)>=3:
        degree=max(terms);factor=terms.pop(degree)%P
        for j in range(3):terms[degree-3+j]=(terms.get(degree-3+j,0)-13*factor)%P
    return tuple(terms.get(i,0)%P for i in range(3))
def verify_case(case,G,C,target):
    branches=[];bmats=[];banks=case['banks'];sectors=case['sectors'];success=case['consistent'];inversechecks=0;transformchecks=0;weylchecks=0
    bad=next((s for s in sectors if not s['consistent']),None)
    inverse_functionals=[];arithmetic_samples={Z,O,U}
    for i,bank in enumerate(banks):
        assert sub(sub(O,fpow(bank['alpha'],N)),fpow(bank['beta'],N))==bank['Delta']!=Z
        invs=[]
        for j in range(N):
            m=literal_branch(bank,j);mi=matrix_inverse(m)
            assert mm(m,mi)==eye(N) and mm(mi,m)==eye(N);inversechecks+=2
            branches.append({'bank_index':i,'j':j,'matrix':m,'inverse':mi});invs.append(mi)
            arithmetic_samples.update(v for row in mi for v in row)
            if bad:
                val=functional(mi,bad['left_null_vector'],bad['sector']);assert val==Z;inverse_functionals.append(val)
        if success:
            amps=[s['solution'][i] for s in sectors]
            weights=[mul(mul(bank['Delta'],C),fsum(mul(amps[b],k(pow(Q,(-bank['epsilon']*b*j)%N,P))) for b in range(N))) for j in range(N)]
            for b in range(N):
                recovered=mul(inv(mul(k(N),mul(bank['Delta'],C))),fsum(mul(weights[j],k(pow(Q,(bank['epsilon']*b*j)%N,P))) for j in range(N)))
                assert recovered==amps[b];transformchecks+=1
            bm=matrix_sum([scale_matrix(invs[j],mul(k(pow(N,-1,P)),weights[j])) for j in range(N)])
            for a in range(N):
                for b in range(N):
                    expected=mul(C,mul(amps[b],mul(fpow(bank['alpha'],(bank['epsilon']*a)%N),G[bank['epsilon'],bank['delta']][a][b])))
                    assert coefficient(bm,a,b)==expected;weylchecks+=1
            assert any(v!=Z for row in bm for v in row),'zero actual bank'
            bank.update(amplitudes=amps,raw_weights=weights,literal_matrix=bm);bmats.append(bm)
    for x in arithmetic_samples:
        assert secondary_product(x,O)==x
        if x!=Z:assert secondary_product(x,inv(x))==O
        assert secondary_product(x,U)==mul(x,U)
    result={'z':case['z'],'consistent':success,'literal_inverse_count':len(branches),'inverse_product_checks':inversechecks,'secondary_arithmetic_samples':len(arithmetic_samples),'sector_ranks':[s['rank'] for s in sectors],'inconsistent_sectors':[s['sector'] for s in sectors if not s['consistent']]}
    if success:
        aggregate=matrix_sum(bmats);assert aggregate==target
        pairs=[(b['epsilon'],b['delta'],b['alpha']) for b in banks];assert len(set(pairs))==13
        assert sum((b['epsilon'],b['delta'])==(-1,1) for b in banks)==1
        assert sum((b['epsilon'],b['delta'])==(1,-1) for b in banks)==1
        case.update(aggregate=aggregate,target=target)
        result.update(raw_transform_checks=transformchecks,bank_weyl_checks=weylchecks,nonzero_banks=len(bmats),aggregate_entry_checks=N*N,aggregate_mismatches=0)
    else:
        pairing=functional(target,bad['left_null_vector'],bad['sector']);assert pairing==mul(C,bad['target_pairing'])!=Z
        case.update(literal_failure_sector=bad['sector'],literal_target_pairing=pairing,literal_inverse_functionals=inverse_functionals)
        result.update(literal_inverse_functional_zero_checks=len(inverse_functionals),literal_target_functional=pairing)
    return result,branches

def run_controls(case,branches,target,G,C):
    controls=[];banks=case['banks'];mats=[b['literal_matrix'] for b in banks];aggregate=matrix_sum(mats)
    def reject(name,condition,**data):
        assert condition,name
        controls.append({'name':name,'rejected':True,**data})
    changed=matrix_sum([aggregate,scale_matrix(branches[0]['inverse'],k(pow(N,-1,P)))])
    reject('perturb_first_raw_weight_by_one',changed!=target,mismatches=entry_mismatches(changed,target))
    reject('omit_one_over_eleven',scale_matrix(aggregate,k(N))!=target)
    reverse_target=[[k(pow(Q,(r*t)%N,P)) for t in range(N)] for r in range(N)]
    reject('reverse_target_fourier_exponent',aggregate!=reverse_target)
    for i,m in enumerate(mats):
        reduced=matrix_sub(aggregate,m);reject('delete_bank_'+str(i),reduced!=target,mismatches=entry_mismatches(reduced,target))
    wrongphase=[]
    for bank in banks:
        invs=[matrix_inverse(literal_branch(bank,j,phase_sign=-1)) for j in range(N)]
        wrongphase.append(matrix_sum([scale_matrix(mi,mul(k(pow(N,-1,P)),w)) for mi,w in zip(invs,bank['raw_weights'])]))
    reject('reverse_all_branch_phase_signs',matrix_sum(wrongphase)!=target)
    corrupt=[list(row) for row in branches[0]['inverse']];corrupt[0][0]=add(corrupt[0][0],O)
    reject('corrupt_inverse_entry',mm(branches[0]['matrix'],corrupt)!=eye(N))
    zero=dict(banks[0]);zero['alpha']=Z;zero['Delta']=Z
    singular=False
    try:matrix_inverse(literal_branch(zero,0))
    except ValueError:singular=True
    reject('admit_zero_alpha_beta_one',singular and sub(sub(O,fpow(Z,N)),fpow(O,N))==Z)
    reject('wrong_cubic_constant',poly_eval([k(14),k(13),k(13),O],U)!=Z)
    xmut=dict(banks[0]);xmut['alpha']=k(1)
    xmutmat=matrix_sum([scale_matrix(matrix_inverse(literal_branch(xmut,j)),mul(k(pow(N,-1,P)),w)) for j,w in enumerate(xmut['raw_weights'])])
    reject('replace_support_three_by_one',matrix_sum([matrix_sub(aggregate,mats[0]),xmutmat])!=target)
    altered=dict(banks[0]);altered['epsilon']=-1
    alteredmat=matrix_sum([scale_matrix(matrix_inverse(literal_branch(altered,j)),mul(k(pow(N,-1,P)),w)) for j,w in enumerate(altered['raw_weights'])])
    reject('move_first_bank_to_cross_orientation',matrix_sum([matrix_sub(aggregate,mats[0]),alteredmat])!=target and altered['alpha']!=banks[5]['alpha'])
    swapped=[dict(b) for b in banks];swapped[5]['alpha'],swapped[6]['alpha']=swapped[6]['alpha'],swapped[5]['alpha']
    swapped_mats=[]
    for b in swapped:swapped_mats.append(matrix_sum([scale_matrix(matrix_inverse(literal_branch(b,j)),mul(k(pow(N,-1,P)),w)) for j,w in enumerate(b['raw_weights'])]))
    reject('swap_cross_nodes_without_reflecting_supports',matrix_sum(swapped_mats)!=target)
    return controls

def dump(path,data):path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--probe',action='store_true');args=ap.parse_args();out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True);start=time.monotonic()
    assert all((x**3+13*x*x+13*x+13)%P for x in range(P))
    assert poly_eval([k(13),k(13),k(13),O],U)==Z
    X=[k(3),k(21),U,fpow(U,23),fpow(U,529)]
    assert len(set(X))==5 and Z not in X and fpow(U,FIELD_ORDER)==U
    h=[O]
    for x in X:h=poly_prod(h,[neg(x),O])
    assert h==list(map(k,[14,1,14,17,12,1]))
    G={(e,d):gaussian(e,d) for e,d in [(1,1),(-1,1),(1,-1),(-1,-1)]}
    target=[[k(pow(Q,(-r*t)%N,P)) for t in range(N)] for r in range(N)]
    tc=[[mul(k(pow(N,-1,P)),fsum(mul(target[(t+a)%N][t],k(pow(Q,(-b*t)%N,P))) for t in range(N))) for b in range(N)] for a in range(N)]
    C=tc[0][0];assert C==k(18)
    f=[[mul(tc[a][b],inv(C)) for b in range(N)] for a in range(N)]
    assert all(f[a][b]==k(pow(Q,(3*(a+b)**2)%N,P)) for a in range(N) for b in range(N))
    cases=[]
    for z,Y in [(7,[6,7,12,13,17,19]),(10,[1,2,4,11,13,18]),(12,[3,12,14,15,16,19])]:
        banks=[{'epsilon':e,'delta':d,'alpha':x,'beta':O,'Delta':neg(fpow(x,N))} for e,d,support in [(1,1,X),(-1,1,[k(15)]),(1,-1,[k(z)]),(-1,-1,list(map(k,Y)))] for x in support]
        assert len(banks)==13 and all(b['Delta']!=Z for b in banks)
        sectors=[]
        for b in range(N):
            a=[[mul(fpow(bank['alpha'],(bank['epsilon']*a)%N),G[bank['epsilon'],bank['delta']][a][b]) for bank in banks] for a in range(N)]
            rec=solve(a,[f[a][b] for a in range(N)]);rec['sector']=b;sectors.append(rec)
        case={'z':z,'X':X,'Y':list(map(k,Y)),'banks':banks,'sectors':sectors,'consistent':all(s['consistent'] for s in sectors)};cases.append(case)
        print('z',z,'ranks',[s['rank'] for s in sectors],'inconsistent',[s['sector'] for s in sectors if not s['consistent']],flush=True)
    dump(out/'SECTOR_CASES.json',cases)
    dump(out/'FOUNDATION.json',{'X':X,'annihilator':h,'G':{str(key):value for key,value in G.items()},'target':target,'target_coefficients':tc,'C':C,'f':f})
    if not args.probe:
        results=[];allbranches={};controls=[]
        for case in cases:
            result,branches=verify_case(case,G,C,target);results.append(result);allbranches[str(case['z'])]=branches
            if case['consistent']:controls.extend(run_controls(case,branches,target,G,C))
            else:
                bad=next(s for s in case['sectors'] if not s['consistent']);lam=bad['left_null_vector'];perturbed=list(lam);perturbed[0]=add(perturbed[0],O)
                assert any(dot(perturbed,col)!=Z for col in zip(*bad['matrix']))
                assert dot([Z]*N,bad['rhs'])==Z
                controls.extend([{'name':'z'+str(case['z'])+'_perturb_left_null_vector','rejected':True},{'name':'z'+str(case['z'])+'_zero_left_null_vector','rejected':True}])
            print('verified',result,flush=True)
        dump(out/'CASES.json',cases);dump(out/'BRANCHES.json',allbranches);dump(out/'MUTATION_CONTROLS.json',controls)
        witness=next(c for c in cases if c['consistent'])
        dump(out/'WITNESS.json',witness)
        raw={'field':{'characteristic':23,'order':12167,'modulus_ascending':[13,13,13,1],'element_encoding':'[a,b,c]=a+b*u+c*u^2 modulo23'},'N':11,'q':13,'target':'F[k,t]=13^(-k*t), 0<=k,t<=10','grammar':'B_(e,d)(alpha,beta;w)=(1/11)sum_(j=0)^10 w_j*(I-alpha*S^e-beta*13^(e*d*j)*T^d)^(-1); S e_t=e_((t+1) mod11), T e_t=13^t e_t; Delta=1-alpha^11-beta^11!=0','orientation_allocation':[5,1,1,6],'banks':[{key:b[key] for key in ['epsilon','delta','alpha','beta','Delta','raw_weights']} for b in witness['banks']]}
        dump(out/'RAW_CERTIFICATE.json',raw)
        dump(out/'RESULTS.json',{'status':'CANDIDATE_THIRTEEN_BANK_WITNESS','cases':results,'mutation_controls_passed':len(controls),'field_modulus_ascending':[13,13,13,1],'field_characteristic':23,'field_order':FIELD_ORDER,'basis':'1,u,u^2; elements are triples modulo23','N':N,'q':Q,'orientation_allocation':[5,1,1,6],'scope':'Exactly the three declared configurations. No lower-bound or minimum claim. Fresh standard-library code only; no external writes.'})
    dump(out/'TIMING.json',{'wall_seconds':time.monotonic()-start})
if __name__=='__main__':main()
