# Independent thirteen-bank cubic-field witness review

Declared 2026-10-14 01:46 UTC before independent arithmetic. Rebuild the supplied candidate over K=F23[u]/(u^3+13u^2+13u+13), N=11, q=13, using only newly authored standard-library code and source data read inertly. The proposed allocation (++,-+,+-,--)=(5,1,1,6) uses ++ nodes roots(h15), -+ node15, +- node7, -- nodes{6,7,12,13,17,19}, beta1 throughout.

Independently construct all 143 original branch matrices I-alpha S^e-beta q^(edj)T^d, invert each by Gaussian elimination, check both inverse products, rebuild raw weighted banks with the original 1/11 coefficient, check each bank nonzero, all 121 target entries, all legal denominators and exactly one effective node each cross orientation. Recover phase weights from independently extracted Fourier/Weyl bank coefficients and check agreement. Include deterministic mutation controls, source hashes, isolated cold replay and a scoped acceptance or rejection. Do not execute, import, or compile historical/candidate programs; do not write externally.

Only combine with the independently accepted <=12-bank exclusion once its sealed report and hash have been received and its scope compared explicitly. No unrestricted optimum, characteristic-zero, novelty, field-rank novelty or FFT speedup conclusion.
