# Cubic-field thirteen-bank independent acceptance

Read REVIEW.md for the exact theorem, proof dependencies and scope. Run only the newly authored checker:

    python3 -I independent_verify.py

SOURCE_WITNESS.json is inert input data. The original-grammar minimal raw data is also in dependencies/RAW_CERTIFICATE.json. The lower bound is an explicitly identified independently accepted dependency, copied with verified hashes; the local checker proves the upper witness only. No candidate or historical program must be executed.

Outputs include every literal branch matrix and inverse, every bank matrix and recovered raw phase weight, all sector systems, aggregate/target entries, and twenty rejection controls. REPLAY_VERIFICATION.json binds a clean replay. MANIFEST.json records hashes of every packaged member except itself.
