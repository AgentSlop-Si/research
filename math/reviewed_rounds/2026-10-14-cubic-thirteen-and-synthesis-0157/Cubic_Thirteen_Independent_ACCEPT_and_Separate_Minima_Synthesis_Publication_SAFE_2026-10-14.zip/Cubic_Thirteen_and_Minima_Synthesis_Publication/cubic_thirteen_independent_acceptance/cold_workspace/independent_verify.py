#!/usr/bin/env python3
"""Fresh, standalone, literal cubic-field bank audit. No source programs imported."""
import argparse, collections, hashlib, itertools, json, pathlib, time
P=23; N=11; Q=13
Z=(0,0,0); O=(1,0,0); U=(0,1,0)
def K(x):
    if isinstance(x,int): return (x%P,0,0)
    assert isinstance(x,(list,tuple)) and len(x)==3 and all(type(t) is int and 0<=t<P for t in x)
    return tuple(x)
def add(a,b): return tuple((a[i]+b[i])%P for i in range(3))
def neg(a): return tuple(-x%P for x in a)
def sub(a,b): return tuple((a[i]-b[i])%P for i in range(3))
def scale(a,c): return tuple(x*c%P for x in a)
def mul(a,b):
    if a==Z or b==Z: return Z
    if b[1:]==(0,0): return scale(a,b[0])
    if a[1:]==(0,0): return scale(b,a[0])
    v=[0]*5
    for i in range(3):
        for j in range(3): v[i+j]+=a[i]*b[j]
    for deg in (4,3):
        v[deg]%=P
        for i in range(3): v[deg-3+i]-=13*v[deg]
    return tuple(x%P for x in v[:3])
def power(a,n):
    assert n>=0
    out=O
    while n:
        if n&1: out=mul(out,a)
        a=mul(a,a);n//=2
    return out
def inverse(a):
    assert a!=Z,'Cannot invert zero'
    if a[1:]==(0,0): return K(pow(a[0],-1,P))
    r=power(a,P**3-2)
    assert mul(r,a)==O
    return r
def div(a,b): return mul(a,inverse(b))
def qp(n): return pow(Q,n%N,P)
def total(items):
    s=Z
    for x in items:s=add(s,x)
    return s
def zero_matrix():return [[Z for _ in range(N)] for _ in range(N)]
def identity():return [[O if i==j else Z for j in range(N)] for i in range(N)]
ID=identity()
def matmul(A,B):
    BT=list(zip(*B))
    return [[total(mul(x,y) for x,y in zip(row,col)) for col in BT] for row in A]
def matsum(A,B):return [[add(a,b) for a,b in zip(x,y)]for x,y in zip(A,B)]
def matscale(A,x):return [[mul(x,y) for y in row]for row in A]
def castmat(A):
    assert len(A)==N and all(len(row)==N for row in A)
    return [[K(v)for v in row] for row in A]
def matinv(A):
    M=[row[:]+ID[i][:] for i,row in enumerate(A)]
    for col in range(N):
        piv=next((r for r in range(col,N) if M[r][col]!=Z),None)
        assert piv is not None,'Singular literal branch'
        M[col],M[piv]=M[piv],M[col]
        M[col]=[mul(inverse(M[col][col]),x) for x in M[col]]
        for r in range(N):
            if r!=col and M[r][col]!=Z:
                a=M[r][col];M[r]=[sub(x,mul(a,y)) for x,y in zip(M[r],M[col])]
    assert [row[:N]for row in M]==ID
    return [row[N:]for row in M]
def rank(A):
    M=[row[:] for row in A]; h=len(M);w=len(M[0]);k=0
    for c in range(w):
        p=next((r for r in range(k,h)if M[r][c]!=Z),None)
        if p is None:continue
        M[k],M[p]=M[p],M[k];f=inverse(M[k][c]);M[k]=[mul(f,v) for v in M[k]]
        for r in range(k+1,h):
            if M[r][c]!=Z:
                f=M[r][c];M[r]=[sub(v,mul(f,q))for v,q in zip(M[r],M[k])]
        k+=1
        if k==h:break
    return k
def literal(e,d,alpha,beta,j):
    A=identity()
    for t in range(N):
        A[(t+e)%N][t]=sub(A[(t+e)%N][t],alpha)
        A[t][t]=sub(A[t][t],scale(beta,qp(e*d*j+d*t)))
    return A
def coefficients(A):
    return [[scale(total(scale(A[(t+a)%N][t],qp(-b*t)) for t in range(N)),pow(N,-1,P))for b in range(N)] for a in range(N)]
def from_coefficients(C):
    return [[total(scale(C[(k-t)%N][b],qp(b*t)) for b in range(N))for t in range(N)]for k in range(N)]
def word_factors(e,d):
    # Count each literal binary word. A T preceding an S supplies q^(ed).
    G={}
    for n in range(N+1):
        for word in itertools.product((0,1),repeat=n):
            r=word.count(0);s=n-r
            inversions=sum(1 for i in range(n)for j in range(i+1,n)if word[i]==1 and word[j]==0)
            key=(r,s);G[key]=(G.get(key,0)+qp(e*d*inversions))%P
    assert G[(N,0)]==G[(0,N)]==1
    assert all(G[(r,N-r)]==0 for r in range(1,N))
    return G
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(out,name,value):
    (out/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def run(src,out):
    started=time.perf_counter(); source=json.loads(src.read_text());banks=source['banks']
    assert len(banks)==13 and source['z']==7
    assert pow(Q,N,P)==1 and all(pow(Q,r,P)!=1 for r in range(1,N))
    cubic=[13,13,13,1]
    evaluations=[sum(c*pow(t,i,P)for i,c in enumerate(cubic))%P for t in range(P)]
    assert all(evaluations),'Cubic not irreducible'
    assert add(add(add(power(U,3),scale(power(U,2),13)),scale(U,13)),K(13))==Z
    assert power(U,P**3)==U and power(U,P)!=U
    roots=[K(3),K(21),U,power(U,P),power(U,P*P)]
    assert len(set(roots))==5 and all(x!=Z for x in roots)
    h=[O]
    for x in roots:
        new=[Z]*(len(h)+1)
        for i,c in enumerate(h):new[i]=sub(new[i],mul(x,c));new[i+1]=add(new[i+1],c)
        h=new
    assert h==[K(x)for x in [14,1,14,17,12,1]]
    allocation=collections.Counter((b['epsilon'],b['delta']) for b in banks)
    assert allocation=={(1,1):5,(-1,1):1,(1,-1):1,(-1,-1):6}
    expected={(1,1):set(roots),(-1,1):{K(15)},(1,-1):{K(7)},(-1,-1):set(K(x)for x in [6,7,12,13,17,19])}
    assert all(set(K(b['alpha'])for b in banks if (b['epsilon'],b['delta'])==pair)==nodes for pair,nodes in expected.items())
    G={pair:word_factors(*pair)for pair in expected}
    F=[[K(qp(-k*t))for t in range(N)]for k in range(N)]
    CF=coefficients(F); C0=CF[0][0]
    assert C0==K(18) and from_coefficients(CF)==F
    assert all(CF[a][b]==scale(C0,qp(3*(a+b)**2))for a in range(N)for b in range(N))
    assert F==castmat(source['target'])
    aggregate=zero_matrix();branch_records=[];bank_records=[];branch_cache=[];effective={}
    for index,bank in enumerate(banks):
        e,d=bank['epsilon'],bank['delta'];alpha=K(bank['alpha']);beta=K(bank['beta'])
        assert beta==O and alpha!=Z
        Delta=sub(sub(O,power(alpha,N)),power(beta,N))
        assert Delta!=Z and Delta==K(bank['Delta'])
        weights=[K(x)for x in bank['raw_weights']];assert len(weights)==N
        B=zero_matrix();branches=[]
        for j in range(N):
            A=literal(e,d,alpha,beta,j);R=matinv(A)
            assert matmul(A,R)==ID and matmul(R,A)==ID
            branches.append(R);branch_records.append({'bank':index,'phase':j,'literal':A,'inverse':R,'left_identity':True,'right_identity':True})
            B=matsum(B,matscale(R,scale(weights[j],pow(N,-1,P))))
        assert any(x!=Z for row in B for x in row),'Zero physical bank'
        assert B==castmat(bank['literal_matrix'])
        CB=coefficients(B);assert from_coefficients(CB)==B
        recovered_amplitudes=[div(CB[0][b],C0)for b in range(N)]
        assert recovered_amplitudes==[K(x)for x in bank['amplitudes']]
        # Independently recover each raw phase weight from literal bank diagonal.
        character_sums=[div(mul(Delta,CB[0][b]),power(beta,(d*b)%N))for b in range(N)]
        recovered=[total(scale(character_sums[b],qp(-e*b*j))for b in range(N))for j in range(N)]
        assert recovered==weights
        expected_C=[]
        for a in range(N):
            row=[]
            for b in range(N):
                r=(e*a)%N;s=(d*b)%N
                value=scale(mul(mul(power(alpha,r),power(beta,s)),div(character_sums[b],Delta)),G[(e,d)].get((r,s),0)) if r+s<N else Z
                row.append(value)
            expected_C.append(row)
        assert CB==expected_C
        assert from_coefficients(expected_C)==B
        aggregate=matsum(aggregate,B);branch_cache.append(branches)
        key=(e,d,alpha);effective[key]=matsum(effective.get(key,zero_matrix()),B)
        bank_records.append({'bank':index,'orientation':[e,d],'alpha':alpha,'beta':beta,'Delta':Delta,'raw_weights':weights,'recovered_raw_weights':recovered,'normalized_amplitudes':recovered_amplitudes,'matrix':B,'coefficients':CB,'nonzero_entries':sum(v!=Z for row in B for v in row)})
    assert aggregate==F and aggregate==castmat(source['aggregate'])
    effective_count={pair:sum((e,d)==pair and any(v!=Z for row in M for v in row)for (e,d,a),M in effective.items())for pair in expected}
    assert effective_count==dict(allocation)
    sector_records=[]
    for b in range(N):
        columns=[]
        for bank in banks:
            e,d=bank['epsilon'],bank['delta'];alpha=K(bank['alpha']);s=(d*b)%N
            columns.append([scale(power(alpha,(e*a)%N),G[(e,d)].get(((e*a)%N,s),0))if (e*a)%N+s<N else Z for a in range(N)])
        M=[list(row)for row in zip(*columns)];rhs=[div(CF[a][b],C0)for a in range(N)]
        solution=[r['normalized_amplitudes'][b]for r in bank_records]
        assert all(total(mul(c,v)for c,v in zip(row,solution))==y for row,y in zip(M,rhs))
        r=rank(M);ra=rank([row+[v]for row,v in zip(M,rhs)]);assert r==ra
        orig=source['sectors'][b]
        assert orig['sector']==b and M==[[K(v)for v in row]for row in orig['matrix']]
        assert rhs==[K(v)for v in orig['rhs']] and solution==[K(v)for v in orig['solution']]
        assert r==orig['rank'] and ra==orig['augmented_rank']
        sector_records.append({'sector':b,'rank':r,'augmented_rank':ra,'matrix':M,'rhs':rhs,'recovered_solution':solution})
    literal_columns=[[scale(R[i][j],pow(N,-1,P))for i in range(N)for j in range(N)]for branch_list in branch_cache for R in branch_list]
    literal_system=[list(row)for row in zip(*literal_columns)]
    literal_rank=rank(literal_system)
    literal_augmented_rank=rank([row+[F[k//N][k%N]]for k,row in enumerate(literal_system)])
    assert literal_rank==literal_augmented_rank==sum(x['rank']for x in sector_records)
    controls=[]
    def reject(name,changed,reference=F):
        unequal=[(i,j)for i in range(N)for j in range(N)if changed[i][j]!=reference[i][j]]
        assert unequal,name
        controls.append({'name':name,'rejected':True,'differing_entries':len(unequal),'first_difference':unequal[0]})
    for index in range(13):
        reject('delete_bank_'+str(index),matsum(aggregate,matscale(bank_records[index]['matrix'],K(-1))))
    reject('raw_weight_0_0_plus_one',matsum(aggregate,matscale(branch_cache[0][0],K(pow(N,-1,P)))))
    reject('omit_1_over_11',matscale(aggregate,K(N)))
    reject('reverse_target_exponent',aggregate,[[K(qp(k*t))for t in range(N)]for k in range(N)])
    corrupt=[row[:]for row in branch_cache[0][0]];corrupt[0][0]=add(corrupt[0][0],O)
    reject('corrupt_inverse_0_0',matmul(branch_records[0]['literal'],corrupt),ID)
    for index in (5,6):
        bank=banks[index];e,d=bank['epsilon'],bank['delta'];alpha=K(bank['alpha']);beta=K(bank['beta']);changed_B=zero_matrix()
        for j,w in enumerate(bank_records[index]['raw_weights']):
            R=matinv(literal(e,d,alpha,beta,-j));changed_B=matsum(changed_B,matscale(R,scale(w,pow(N,-1,P))))
        reject('reverse_cross_phase_'+str(index),matsum(matsum(aggregate,matscale(bank_records[index]['matrix'],K(-1))),changed_B))
    assert sub(sub(O,power(Z,N)),power(O,N))==Z
    assert rank(literal(1,1,Z,O,0))<N
    controls.append({'name':'zero_alpha_beta_one','rejected':True,'zero_denominator':True,'literal_rank':rank(literal(1,1,Z,O,0))})
    # The coefficient extraction and reconstruction are inverse transforms; the
    # direct branch column space is their block decomposition, hence rank sum.
    summary={'verdict':'ACCEPT_UPPER_BOUND_13','scope':'K=F23[u]/(u^3+13u^2+13u+13), N11 q13, original signed resolvent banks; exactly one effective alpha node per cross orientation',
      'source_witness_sha256':digest(src),'field_size':P**3,'modulus_low_to_high':cubic,'modulus_values_on_F23':evaluations,'q_order':N,
      'same_sign_plus_nodes':roots,'h15_low_to_high':h,'orientation_counts':{str(k):v for k,v in allocation.items()},'effective_orientation_counts':{str(k):v for k,v in effective_count.items()},
      'literal_inverse_count':len(branch_records),'left_right_inverse_checks':2*len(branch_records),'raw_weights_recovered':13*N,'bank_matrices_nonzero':13,'bank_Weyl_coefficients_checked':13*N*N,'target_entries_equal':N*N,
      'sector_ranks':[x['rank']for x in sector_records],'literal_full_system_rank':literal_rank,'literal_full_augmented_rank':literal_augmented_rank,'mutation_controls_passed':len(controls),
      'no_candidate_or_historical_programs_executed':True,'external_writes':False,'minimum_assertion':'Requires separately accepted matching lower bound; this program proves only attainment.'}
    write(out,'INDEPENDENT_RESULTS.json',summary);write(out,'LITERAL_BRANCHES.json',branch_records);write(out,'BANKS_AND_RAW_WEIGHTS.json',bank_records);write(out,'SECTORS.json',sector_records);write(out,'MUTATION_CONTROLS.json',controls);write(out,'AGGREGATE_AND_TARGET.json',{'aggregate':aggregate,'target':F,'target_coefficients':CF})
    write(out,'TIMING.json',{'elapsed_seconds':time.perf_counter()-started,'historical_programs_executed':0,'model_token_count':'unavailable','errors':[]})
    print(json.dumps(summary,sort_keys=True));print('elapsed_seconds',time.perf_counter()-started)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,default=pathlib.Path(__file__).parent/'SOURCE_WITNESS.json');p.add_argument('--output',type=pathlib.Path,default=pathlib.Path(__file__).parent/'outputs');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);run(a.source,a.output)
