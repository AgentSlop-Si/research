#!/usr/bin/env python3
"""Independent exact review controls. Candidate/historical code is never loaded."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from pathlib import Path
from hashlib import sha256
import json, random, zipfile
OUT=Path(__file__).resolve().parent
SOURCE=Path('/workspace/shared/robust_separator_20261013')
ZIP=Path('/workspace/shared/Robust_Separator_Duplicate_and_Correction_Candidate_20261013.zip')
EXPECTED='5aeca15f59661efe037593a4b39646c11127209320c9d23abf5862e7d75d9401'
assert sha256(ZIP.read_bytes()).hexdigest()==EXPECTED
binding=[]
with zipfile.ZipFile(ZIP) as z:
    manifest=json.loads(z.read('MANIFEST.json'))
    assert set(z.namelist())=={p['path'] for p in manifest}|{'MANIFEST.json'}
    for p in manifest:
        data=z.read(p['path'])
        assert len(data)==p['bytes'] and sha256(data).hexdigest()==p['sha256']
        assert data==(SOURCE/p['path']).read_bytes()
    for p in json.loads(z.read('SOURCE_BINDINGS.json')):
        original=Path(p['source_path'])
        assert original.exists()
        assert sha256(original.read_bytes()).hexdigest()==p['sha256']
        assert original.read_bytes()==Path(p['copied_path']).read_bytes()
        binding.append({'path':str(original),'sha256':p['sha256'],'bytes':p['bytes'],'original_exists_and_matches':True})
counts={}
def ceildiv(n,d): return -((-n)//d)
def seq(n,q,r):
    out=[n]
    for j in range(r): out.append(ceildiv(out[-1]-q,3))
    return out
ncase=0
for q in range(1,13):
    for r in range(1,9):
        a=3**r; c=q*(a-1)//2; b=a//3
        H=(4*q-1)*b+q*(b-1)//2+1
        for n in sorted(set(range(601))|set(range(max(0,H-10),H+11))|{2*H,10*H}):
            v=seq(n,q,r)
            assert v[-1]==ceildiv(n-c,a)
            assert all(x>=4*q for x in v[:-1])==(n>=H)
            ncase+=1
        assert seq(H-1,q,r)[-2]==4*q-1
        assert seq(H,q,r)[-2]==4*q
        for d in range(1,9):
            assert all(x>=4*q for x in seq((d*H)//d,q,r)[:-1])
            assert not all(x>=4*q for x in seq((d*H-1)//d,q,r)[:-1])
counts['recurrence_and_exact_guard_cases']=ncase
counts['N_guard_endpoint_pairs']=12*8*8
# Exhaustively check all admissible red/blue counts, independently of packing.
ncase=0
for u in range(1,101):
    for a in range(u+1):
        for b in range(u+1):
            if 2*u<=3*(a+b)<=4*u:
                retained=max(min(a,u-b),min(u-a,b))
                assert retained>=ceildiv(u,3)
                ncase+=1
counts['admissible_color_orientation_cases']=ncase
# Exact cutoff implications at first forbidden N and non-neighbor points.
ncase=0
for q in range(1,7):
    for r in range(1,6):
        a=3**r
        for d in range(1,6):
            for t in (0,1,3,11):
                k=q*r+t; z=d*a; C=d*q*(a-1)//2+d-1; B=z*z*k
                for v in (F(0),F(1,100),F(1,3),F(2,3),F(9,10),F(99,100)):
                    eta2=v/(z*z); eps2=v/z
                    TF=F(B+2*C)/(1-z*z*eta2)
                    TO=(C*(2-z*eps2)+B*(1-eps2))/(1-z*eps2)
                    assert TF>=B+2*C and TO>=B+2*C
                    assert (TO-(B+2*C))==eps2*(B*(z-1)+C*z)/(1-z*eps2)
                    if not v: assert TF==TO==B+2*C
                    for kind,T in [('F',TF),('O',TO)]:
                        n0=T.numerator//T.denominator+1
                        for N in (n0,n0+z,3*n0):
                            mvec=seq(N//d,q,r); m=mvec[-1]
                            assert all(x>=4*q for x in mvec[:-1])
                            assert m>k and F(m*m,N)>k
                            x=F(N-C,z)
                            assert m>=x>0
                            if kind=='F':
                                assert F(m*m,N)-k>N*eta2
                                assert (1-z*z*eta2)*N*N-(B+2*C)*N+C*C>0
                            else:
                                assert (F(m*m,N)-k)/(m-k)>eps2
                                assert z*z*(x*x-N*eps2*x-N*k*(1-eps2))==((1-z*eps2)*N*N-(C*(2-z*eps2)+B*(1-eps2))*N+C*C)
                                assert x*x-N*eps2*x-N*k*(1-eps2)>0
                            ncase+=1
counts['exact_tolerance_violation_cases']=ncase
# Exact abstract spectra with a finer grid than the candidate; retain zero and full budgets.
ncase=0
for m in range(1,10):
    for asc in combinations_with_replacement([F(i,6) for i in range(7)],m):
        lam=asc[::-1]; E=sum(lam)
        for k in range(m+2):
            lower=max(F(0),E-k)
            tail=sum(lam[k:])
            assert tail>=lower
            if k<m: assert lam[k]>=lower/F(m-k)
            else: assert lower==0
            ncase+=1
counts['exact_spectrum_budget_cases']=ncase
# General exact rational elimination, written here rather than imported from research code.
def rank(A):
    if not A: return 0
    A=[[F(x) for x in row] for row in A]
    h=len(A); w=len(A[0]); k=0
    for j in range(w):
        pivot=next((i for i in range(k,h) if A[i][j]),None)
        if pivot is None: continue
        A[k],A[pivot]=A[pivot],A[k]
        v=A[k][j]; A[k]=[x/v for x in A[k]]
        for i in range(k+1,h):
            if A[i][j]:
                v=A[i][j]; A[i]=[x-v*y for x,y in zip(A[i],A[k])]
        k+=1
        if k==h: break
    return k
rng=random.Random(7301013)
def components(G,removed):
    seen=set(removed); result=[]
    for v in range(len(G)):
        if v in seen: continue
        seen.add(v); stack=[v]; comp=[]
        while stack:
            x=stack.pop(); comp.append(x)
            for y in G[x]:
                if y not in seen: seen.add(y); stack.append(y)
        result.append(comp)
    return result
def centroid(G,allowed,marks):
    root=next(iter(allowed)); parents={root:None}; order=[root]
    for x in order:
        for y in G[x]:
            if y in allowed and y!=parents[x]:
                assert y not in parents # This helper requires a tree.
                parents[y]=x; order.append(y)
    weight={x:marks.get(x,0) for x in order}
    for x in reversed(order[1:]): weight[parents[x]]+=weight[x]
    total=weight[root]
    for x in order:
        chunks=[total-weight[x]]+[weight[y] for y in G[x] if parents.get(y)==x]
        if all(2*w<=total for w in chunks): return x
    raise AssertionError('centroid missing')
def denominator(N,kind):
    # Matching edges join lower i=N+i to upper i; additional edges encode Q.
    G=[set() for _ in range(2*N)]
    def edge(i,j): G[i].add(N+j); G[N+j].add(i)
    for i in range(N): edge(i,i)
    if kind=='cycle':
        for i in range(N): edge(i,(i+1)%N)
        def inverse(i,j): return -1 if j>=i else -2
        return G,inverse
    parent=[None]+[rng.randrange(j) for j in range(1,N)]
    weights=[1]+[rng.choice([-2,-1,1,2]) for j in range(1,N)]
    for j in range(1,N): edge(parent[j],j)
    cache=[]
    for j in range(N):
        vals={j:1}; x=j; v=1
        while x:
            v*=weights[x]; x=parent[x]; vals[x]=v
        cache.append(vals)
    def inverse(i,j): return cache[j].get(i,0)
    return G,inverse

def family(N,r,q,s,t,delta):
    d=s+1+delta; rows=list(range(N//d))
    # Degree exactly s in every row. Values may be arbitrary after support clearing.
    S=[set(rng.sample(range(N),s)) for _ in range(N)]
    forbidden=set().union(*(S[i]|({i} if delta else set()) for i in rows))
    cols=[j for j in range(N) if j not in forbidden][:len(rows)]
    assert len(cols)==len(rows)
    branches=[]; trace=[len(rows)]; sep_sizes=[]
    for b in range(r):
        kind='tree' if q==1 else 'cycle'
        G,inv=denominator(N,kind)
        p=list(range(N)); h=list(range(N)); rng.shuffle(p); rng.shuffle(h)
        left=[rng.choice([0,0,1,-1]) for _ in range(N)]
        right=[rng.choice([0,1,-1]) for _ in range(N)]
        branches.append((inv,p,h,left,right))
        m=len(rows); assert m>=4*q
        marks={N+p[i]:1 for i in rows}; marks.update({h[j]:1 for j in cols})
        assert len(marks)==2*m
        X=set()
        if kind=='cycle': X.add(0)
        comps=components(G,X)
        heavy=[c for c in comps if sum(marks.get(x,0) for x in c)>m]
        if heavy: X.add(centroid(G,set(heavy[0]),marks))
        assert len(X)<=q
        comps=components(G,X)
        assert all(sum(marks.get(x,0) for x in c)<=m for c in comps)
        u=m-q
        rows=[i for i in rows if N+p[i] not in X][:u]
        cols=[j for j in cols if h[j] not in X][:u]
        assert len(rows)==len(cols)==u
        retained={N+p[i] for i in rows}|{h[j] for j in cols}
        weights=[len(retained.intersection(c)) for c in comps]
        assert sum(weights)==2*u and max(weights)<=F(4*u,3)
        large=next((a for a,w in enumerate(weights) if 3*w>=2*u),None)
        if large is not None: A=set(comps[large])
        else:
            A=set(); mass=0
            for comp,w in zip(comps,weights):
                A.update(comp); mass+=w
                if 3*mass>=2*u: break
        assert 2*u<=3*len(retained&A)<=4*u
        B=set(range(2*N))-X-A
        want=ceildiv(u,3)
        options=[([i for i in rows if N+p[i] in A],[j for j in cols if h[j] in B]),([i for i in rows if N+p[i] in B],[j for j in cols if h[j] in A])]
        chosen=next((pair for pair in options if min(map(len,pair))>=want),None)
        assert chosen is not None
        rows=chosen[0][:want]; cols=chosen[1][:want]
        trace.append(want); sep_sizes.append(len(X))
    assert trace==seq(N//d,q,r)
    assert all(j not in S[i] and (not delta or i!=j) for i in rows for j in cols)
    branch_matrices=[]; branks=[]
    for inv,p,h,left,right in branches:
        A=[[left[i]*right[j]*inv(p[i],h[j]) for j in cols] for i in rows]
        branks.append(rank(A)); assert branks[-1]<=q
        branch_matrices.append(A)
    m=len(rows)
    X=[[rng.choice([-1,0,1]) for _ in range(t)] for i in rows]
    Y=[[rng.choice([-1,0,1]) for j in cols] for _ in range(t)]
    K=[[sum(X[i][a]*Y[a][j] for a in range(t)) for j in range(m)] for i in range(m)]
    total=[[K[i][j]+sum(A[i][j] for A in branch_matrices) for j in range(m)] for i in range(m)]
    kr=rank(K); mr=rank(total); assert kr<=t and mr<=r*q+t
    # All terms and the target are scaled by 1/sqrt(N); squared arithmetic is rational.
    E=[[(1 if (rows[i]&cols[j]).bit_count()%2==0 else -1)-total[i][j] for j in range(m)] for i in range(m)]
    E2=F(sum(e*e for row in E for e in row),N)
    floor=max(F(0),F(m*m,N)-(r*q+t))
    assert E2>=floor
    # Trace/m is a rigorous lower bound on operator squared; it independently certifies these witnesses.
    if m>r*q+t: assert E2/m>=floor/(m-r*q-t)
    return {'N':N,'r':r,'q':q,'s':s,'t':t,'delta':delta,'side_sequence':trace,'separator_sizes':sep_sizes,'branch_ranks':branks,'K_rank':kr,'sum_rank':mr,'F_squared_floor':str(floor),'actual_rectangle_error_squared':str(E2),'positive_floor':floor>0,'rows':rows,'columns':cols}
# Exact rational Hadamard block: V has squared singular values (1,1,1/4).
V=[[F(x,2) for x in row] for row in [[1,1,1],[1,-1,1],[1,1,-1]]]
def mm(A,B): return [[sum(x*y for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def sub(A,B): return [[x-y for x,y in zip(ar,br)] for ar,br in zip(A,B)]
I=[[F(i==j) for j in range(3)] for i in range(3)]
G=mm([list(c) for c in zip(*V)],V)
Iquarter=[[x/4 for x in row] for row in I]
assert mm(sub(G,I),sub(G,Iquarter))==[[0]*3 for _ in range(3)]
assert rank(sub(G,I))==1
P=[[x*F(4,3) for x in row] for row in sub(I,G)]
assert mm(P,P)==P and rank(P)==1
best=mm(V,sub(I,P)); residual=sub(V,best)
assert rank(best)==2 and rank(residual)==1
assert sum(x*x for row in residual for x in row)==F(1,4)
assert F(3*3,4)-2==F(1,4)
assert 4*(F(9,4)-2)==9-4*2==1
counts['actual_exact_sharp_Hadamard_tail_example']=1
actual=[family(*params) for params in [(64,1,1,0,0,0),(512,1,1,1,1,1),(256,2,1,0,1,0),(64,1,2,0,0,0),(512,1,2,1,1,1),(1024,2,2,0,1,0)]]
counts['actual_independently_routed_tree_cycle_families']=len(actual)
# Negative controls against specific invalid proof substitutions.
assert rank([[F(1,2)]*4 for _ in range(4)])==1
# V=I_3, B=diag(2,0,0): rank(B)=1, rank(V-B)=3, not m-k=2.
assert rank([[-1,0,0],[0,1,0],[0,0,1]])==3
negative={
    'unnormalized_factor':'For N=4,m=3,k=2 the normalized squared floor is 1/4 and the unnormalized squared floor is 1, exactly a factor N.',
    'flat_without_unitarity':'J4/2 has flat entries but rank one, so an alleged F-squared floor 4-1 would fail at an exact rank-one approximation.',
    'actual_error_rank':'V=I3 and B=diag(2,0,0) have rank(B)=1 and rank(V-B)=3, refuting rank(error)<=m-k.',
    'guard_off_by_one':'For every tested q,r, H-1 has last input exactly 4q-1; H has last input exactly 4q.',
    'zero_spectral_denominator':'k=m makes m-k=0 and the spectral formula unavailable; k>m gives a misleading negative denominator.',
    'averaged_sparsity':'One dense row and all other rows zero have average degree one; selecting the dense row can forbid every column.',
    'fixed_tolerance':'The one-rectangle floors decay as 1/(d 3^r) and 1/sqrt(d 3^r), so they do not establish logarithmic r at fixed positive error.'}
result={'status':'PASS','input_archive_sha256':EXPECTED,'arithmetic':'exact integers and fractions only','candidate_code_execution':False,'historical_code_execution':False,'manifest_payloads_verified':len(manifest),'original_source_bindings':binding,'counts':counts,'actual_controls':actual,'negative_controls':negative}
(OUT/'CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','counts':counts,'source_bindings_verified':len(binding),'actual_control_summary':[{k:v for k,v in x.items() if k not in ('rows','columns')} for x in actual]},indent=2))
