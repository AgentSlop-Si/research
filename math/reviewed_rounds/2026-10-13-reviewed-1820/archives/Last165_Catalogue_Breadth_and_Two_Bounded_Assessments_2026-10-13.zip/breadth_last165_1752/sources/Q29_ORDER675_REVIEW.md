# Independent review: exact second-stage valuation at order 675

13 October 2026 UTC.

## Decision

**Scoped ACCEPT.** For the fixed case t=27, p=5, e=2, s=675, the candidate establishes

    v_pi(D(zeta)) = 2862,
    v_pi(Delta) = 1080,
    v_pi(pi)=1, v_pi(5)=20.

Both D(zeta)/pi^2862 and Delta/pi^1080 belong to the local cyclotomic DVR and are units there. This is a new independently verified exact valuation, rather than an inherited claim from the first-normalization review. It gives characteristic-zero nonvanishing for this same order-675 target. It does not imply global algebraic-integer unitness, any larger tower result, or any uniform squarefreeness theorem. The broader Q29 / ALG-OPEN-UNIFORM-SQUAREFREE / NEXT-RS-AUGMENTED gate 54 stays OPEN.

The frozen candidate is `next_cycle_intrinsic_second_cluster_0438.zip`, SHA256 `d89b4de83995db3e7a310a5c3b17c3bc445d2c1d092e3dada49f50e3a5b59755`. Every archive member, manifest entry, and source binding was checked against the preserved files. Candidate and historical programs were inspected as inert text and were never imported or executed. All reconstruction, validation, and cold-replay programs in this review are newly written and separate.

There is one harmless reporting convention to make explicit: at j=0 the candidate checker's exported A-coordinate vector is the coefficient of H/v, whereas its theorem defines L_0=-H/v. The actual A, B, C, and outer coefficient in that theorem therefore have the opposite sign. The candidate's tests concern zero regions and homogeneous ratios, so those tests remain valid and the theorem requires no mathematical repair. This review explicitly applies the minus sign before verifying the local formula, ordinary derivative, and normalized discriminant residue.

## 1. Exact inherited facts and local setting

The earlier accepted review supplies only the following previously established facts needed here:

- U(z;q)=H_337(z;q)/(z+1) is a monic polynomial in Z[q,z], of degree 336 in z.
- D(q)=Disc_z U(z;q) uses the ordinary derivative.
- ord_(Phi27) D=1782, so d(q)=D(q)/Phi27(q)^1782 lies in Z[q].
- Delta=d(zeta), hence D(zeta)=Phi27(zeta)^1782 Delta.

The previous review did not know the exact intrinsic valuation. Its 5^390 leading-coefficient content and nonunit obstruction are not used as an exact valuation or multiplied by the ramification index to fabricate a bound.

Write eta=zeta^325 and xi=zeta^351. Direct arithmetic gives orders 27 and 25 and eta*xi=zeta. The polynomial Phi27(X)=X^18+X^9+1 is irreducible over F5: independently, ord_27(5)=18, and a separate symbolic irreducibility check passes. Consequently O=Z_5[eta] is the unramified degree-18 DVR, and its residue field is the single field K=F5[eta]/Phi27. No favorable factors from different residue components are combined.

Phi25(1+X) is Eisenstein at 5 of degree 20. The completed local ring R=O[xi] therefore has uniformizer pi=xi-1 with v_pi(5)=20. All coefficient calculations below come from integral polynomials evaluated at the actual q=eta(1+pi)=zeta. They do not treat a formal q-parameter as an independently chosen uniformizer after specialization.

The derivative eta*Phi27'(eta) is a unit, independently checked in K. The exact Taylor expansion gives v_pi(Phi27(zeta))=1. Once the new D-valuation is established, subtracting 1782 is therefore legitimate.

## 2. Independent finite reconstruction

The review reconstructs the Hasse jets from the finite Euler product

    product_(r=0)^336 (1+t q^r)
      = sum_(k=0)^337 q^[k(k-1)/2] [337 choose k]_q t^k.

The implementation uses the 27-dimensional cyclic group algebra F5[C27], with q=eta(1+x), rather than the candidate's 18-dimensional field representation. After multiplication it removes the unit q^[k(k-1)/2], then substitutes z=-eta^j(1+v), and only at the end projects to the primitive factor Phi27. In the x^18-truncated ring, (1+x)^25=1, so negative powers of this unit are replaced by bounded nonnegative powers. No factorial, repeated-root factor, vanishing q-difference, or other nonunit is inverted.

The rebuilt rectangle has a<=17 and original Hasse degree b<=17 at all 27 centers. All 8,748 field coefficients, including zero coefficients, match the candidate's wide output. The overlapping rectangles of its two other outputs also match; 17,982 field-coefficient comparisons are made in total. The independent reconstruction is not a replay of either candidate recurrence.

A separate direct-subset oracle checks the reconstruction at n=0,1,2,7,13. It enumerates subsets, counts the exact nonnegative Gaussian exponents sum(r)-k(k-1)/2, and performs ordinary integer binomial translation. Its 24,300 field-coefficient comparisons pass. This tests, among other things, the removed q-weight, signs, truncation, cyclic shifts, projection, and low-degree endpoint cases without another polynomial-product or Pascal recurrence.

For j!=0 set L_j=H_337(-eta^j(1+v);eta(1+x)). Its extra root -1 is unit-separated from this center. For j=0, divide the exact polynomial by its persistent factor z+1=-v first, obtaining L_0=-H/v. The reconstruction shows that every raw v^0 coefficient at this shared center is zero; the accepted integral persistent-factor identity justifies the division over Z[q,z], not merely after reduction.

After this exact division and its sign correction, write L_j=sum c_(a,b,j) x^a v^b. At every center the independent certificate finds units A_j=c_(1,10,j) and C12_j=c_(0,12,j), together with

    c_(10,0,j)=A_j,
    c_(5,6,j)=3 A_j.

These three monomials are exactly the nonzero reduced terms of weight 10a+9b<105. The complete checked zero region gives 10a+9b>=100 for all effective terms. The first Newton-face bound is 2a+b>=12 for b<=12. The first requested post-Hermite coefficient is supported only at degrees 11 and 13. The explicit A-coordinate vectors in this review always refer to the defined L, including its shared-center minus sign.

## 3. Lower guards and all global separations

The lower H13 polynomial is independently reconstructed by enumerating all 8,192 subsets in its Euler product. Exact synthetic division by z+1 is checked by multiplication back. In the same field K, an ordinary polynomial gcd verifies gcd(U13,U13')=1. Every one of the 27 values U13(-eta^j) is nonzero, and the collective gcd with z^27+1 is also 1.

All 351 pairwise differences between the 27 centers are independently nonzero in K. The q-Lucas specialization is

    U(z;eta)=(z^27+1)^12 U13(z;eta).

Reduction at q=zeta has this same specialization, since pi is in the maximal ideal. Coprime-factor Hensel lifting therefore gives 27 monic degree-12 factors P_j and one monic degree-12 residual factor V in R[z]. It is essential that the factors belonging to different centers are coprime; no squarefreeness of an individual repeated center block is asserted here.

Disc(V) is a unit, and all 378 global cross-factor resultants are units: 351 center-center pairs and 27 center-residual pairs. This uses the freshly verified lower guards. The degree count 27*12+12=336 exhausts the whole monic U, so no roots or remaining discriminant factors are omitted.

## 4. From the finite jet to a true integral second scale

Adjoin rho with rho^10=pi. This is an Eisenstein extension of R, with complete DVR E, v_rho(rho)=1, and v_rho(5)=200. Put u=rho^5, so u^2=pi. These equations are exact in a finite extension of the actual local cyclotomic field.

For each center define

    F_j(Y)=rho^(-100) L_j(rho^9 Y,pi).

This is integral coefficientwise for the full finite polynomial, not just its recorded truncation. If a Hasse coefficient is nonzero modulo 5, the certified low region gives 10a+9b>=100. If it is zero modulo 5, its rho-valuation is at least 200, and its normalized contribution has valuation at least 100. Terms outside the sufficient rectangle a<=11, effective b<=12 have normalized exponents at least 20 when a>=12, or at least 17 when b>=13. Thus no unseen term affects integrality or the residue jet through rho^4.

The exact integral congruence is

    F_j(Y) = A_j (Y^10+1+3 rho^4 Y^6) mod rho^5 E[Y].

An integral lift of the actual coefficient c_(1,10,j) may be used for A_j. Differences between the other two coefficients and the indicated multiples of A_j lie in 5O, hence have rho-valuation at least 200. This addresses the lift ambiguity, rather than identifying a finite-field vector with an exact characteristic-zero equality.

The lower Newton polygon has vertices (0,10),(10,1),(12,0). Coefficients divisible by 5 have pi-valuation at least 20, above both relevant faces; the omitted finite-polynomial tails are likewise above them. The three vertices have exact valuations by the nonzero A_j and C12_j residues. There are exactly ten roots of displacement valuation 9/10 and two of valuation 1/2. All other roots of the full L_j have displacement valuation zero from this center.

At the first scale u, the reduction is a nonzero scalar times Y^10(C12_j Y^2+A_j). The quadratic has nonzero constant and leading coefficients and nonzero ordinary discriminant because 2 is a unit. All 27 separability checks pass. Thus the outer two roots have difference valuation 1/2, and each of the 20 inner-to-outer differences also has valuation 1/2.

For the integral factor construction, use the monic polynomial

    Q_j(W)=(alpha_j*u)^(-12) P_j(alpha_j(1+u W)).

Its roots are integral by the first Newton bound, so its coefficients are integral by elementary symmetric functions. Its reduction is W^10 times a coprime monic quadratic. Hensel lifting gives monic factors T_j and E_j of degrees 10 and 2. Their resultant and Disc(E_j) are units. The roots of T_j have rho-valuation 4, so

    R_j(Y)=rho^(-40) T_j(rho^4 Y)

is again monic and integral, by the same elementary-symmetric argument. It is defined over E even if its individual roots require a further extension.

R_j divides F_j in the fraction field. Monic division by the integral R_j shows that the quotient S_j is integral; the zero remainder is the already established fraction-field identity. Therefore

    F_j=R_j S_j,
    R_j mod rho=Y^10+1,
    S_j mod rho=A_j.

The last two assertions also follow from monicity and the degree-10 reduction of F_j. In particular Res(R_j,S_j) has residue A_j^10 and is a verified unit. There is no unguarded Hensel claim for the nonmonic F_j and no inversion of a repeated-root derivative.

## 5. Ordinary derivative and the exact unit certificate

Y^10+1=(Y^2+1)^5 in characteristic 5, and its ordinary derivative is zero. Thus the second residual polynomial is emphatically not squarefree. The next jet term supplies the needed information.

Differentiate the integral congruence. Since v_rho(10)=200 and 6*3=18=3 modulo 5,

    G_j=F_j'/rho^4 is integral,
    G_j mod rho=3 A_j Y^5.

The derivative of the rho^5 error remains divisible by rho^5. The reviewer also tests the low-weight derivative support using the actual integer exponent b, rather than replacing the derivative by a Hasse derivative.

The needed discriminant relation is the multiplied identity

    Disc(R_j) Res(R_j,S_j) = -rho^40 Res(R_j,G_j).

It follows without assuming distinct roots: in the finite free algebra E[Y]/(R_j), F_j'=R_j'S_j, and determinant norms are multiplicative. Homogeneity gives Res(R_j,rho^4 G_j)=rho^40 Res(R_j,G_j). Finally Disc(R_j)=(-1)^45 Res(R_j,R_j')=-Res(R_j,R_j'). This proves the identity as a polynomial identity and rules out circularly assuming nonvanishing in the derivation.

The residues of the two auxiliary resultants are A_j^10 and (3A_j)^10, both nonzero in the same K. Only the already verified unit Res(R_j,S_j) is canceled. Consequently

    v_rho(Disc(R_j))=40,
    Disc(R_j)/rho^40 mod rho = -3^10 = 1 in F5.

The independent exact integer model discriminant for Y^10+1+3 rho^4 Y^6 has minimal mixed-characteristic weight 40, with coefficient residue 1 when v_rho(5)=200. This is an additional arithmetic consistency check; the proof for the actual polynomial is the integral norm identity and its guarded residues, not the toy model.

## 6. Every discriminant exponent

Let I_j and O_j be the monic inner and outer factors of P_j in the original z coordinate. The exact identities are

    Disc(P_j)=Disc(I_j) Disc(O_j) Res(I_j,O_j)^2,
    Disc(I_j)=(alpha_j rho^9)^90 Disc(R_j),
    Disc(O_j)=(alpha_j rho^5)^2 Disc(E_j),
    Res(I_j,O_j)=(alpha_j rho^5)^20 Res(T_j,E_j).

All alpha_j are units. The within-inner contribution is rho^(9*90+40); the within-outer contribution is rho^10; the squared cross-resultant contributes rho^200. Thus each center contributes rho^1060, equivalently pi^106, times a unit.

A separate count through the first-scale discriminant agrees:

    12*11*5 + 10*9*4 + 40 = 1060.

The first term accounts for scaling all twelve roots by u, and the latter two account for the discriminant of the degree-10 inner block after its additional rho^4 scaling. Equivalently there are 45 inner pairs, 20 inner-outer pairs, and one outer pair. No pair is lost or counted with a single rather than squared resultant.

The global monic discriminant product has unit Disc(V) and all 378 cross-resultants unit, so

    v_pi(D(zeta)) = 27*106 = 2862.

D(zeta)/pi^2862 is an element of Frac(R) whose valuation is zero, so it lies in R^*. Although E was used to expose the root radii, the final normalized discriminant descends automatically. Individual auxiliary factors need not descend.

Finally D(zeta)=Phi27(zeta)^1782 Delta and v_pi(Phi27(zeta))=1 yield

    v_pi(Delta)=2862-1782=1080,
    Delta/pi^1080 in R^*.

The characteristic-zero Phi27-order 1782, the intrinsic pi-valuations 2862 and 1080, the integer 5-adic content 390, and rho-normalization exponents are four distinct quantities. The proof never substitutes one for another.

## 7. Adversarial controls, replay, and scope limits

The main fresh checker passes 18,492 assertions. It rejects 113 deliberately invalid inputs, including removal of either required inner leading term at every center, alteration of the rho^4 derivative term, insertion of a forbidden rho^1 term, a nonzero shared-center division remainder, omission or duplication of a center, a nonprimitive lower parameter, and inversion of zero. It independently confirms that the unscaled second residual derivative cannot give a unit certificate.

A clean temporary directory recompiles only the newly written Euler program, reconstructs the complete wide output, and reruns only the new review checker. Both generated files are byte-identical to the primary outputs. The direct-subset small-degree oracle adds 24,300 successful coefficient comparisons. Candidate source, candidate output, historical source, and source archives are untouched.

The accepted result closes the finite intrinsic exact-valuation question at s=675 and supplies a genuinely integral second-stage normalization with a same-component unit proof. It preserves the first-normalization nonunit obstruction: Delta675 is nonzero but has positive exact local valuation 1080. It does not establish the analogous jets at e>=3, other primes, other base orders, an all-tower squarefreeness family, or a uniform algorithm. The broader gate remains OPEN; extending these guarded integral jets or finding a precise higher-stage obstruction is a separate obligation.
