# Independent review: uniform cyclotomic transport, with a quotient-quantifier correction

13 October 2026 UTC.

## Verdict: split, with a proved review amendment

The frozen candidate is `next_cycle_uniform_cluster_obstruction_0512.zip`, SHA256 `1cfbdfa718007ce07129dcf1a6a51e463e7fc40101eca98cf5a5af2c17c944cf`. Its text is preserved unchanged in `source_snapshot`.

- **ACCEPT (A)**: the integral cyclotomic block identity, including its quotient form when both half-degrees are odd.
- **ACCEPT (B)**: the integral transport modulo pi_e^phi(p^r), in one fixed primitive residue component, with the lower polynomial evaluated at the same higher root q_e.
- **ACCEPT (C)**: the formal and integral zero rectangle, under the stated quotient parity guard and with the shared-center convention exactly −H/v.
- **ACCEPT the H version of (D)** and its no-fixed-rectangle conclusion. The no-fixed-rectangle conclusion also holds along the layers at which U exists, using the corrected sufficient condition below.
- **REJECT the unrestricted shared-center U version of (D)'s advertised sufficient inequalities**. The proof's choice r=e−1 can violate the quotient parity guard. An explicit counterexample is given below.
- **ACCEPT the fixed t=27, p=5, r=2 application at every e≥3**, including the rho^100 divisibility obstruction to reusing the order-675 normalization. This application always satisfies the parity guard and is unaffected by the rejected part of (D).

This is not an acceptance of the candidate's four statements without qualification. The original incorrect sufficient condition remains in the frozen history. The replacement in Section 3 is an independently derived review amendment, not a silent rewrite of the source.

The Q29 / ALG-OPEN-UNIFORM-SQUAREFREE / NEXT-RS-AUGMENTED gate 54 remains OPEN. No characteristic-zero squarefreeness theorem, exact higher-layer discriminant valuation, uniform algorithm, FFT, runtime, or historical novelty assertion follows. Previously accepted order-675 valuations 2862 and 1080 are unchanged and are not re-proved by this review.

## 1. Independent proof audit of the accepted transport

Let t be any positive odd integer, p an odd prime not dividing t, and e>r≥1. Put n_i=(t p^i−1)/2, M=t p^r, a=(p^(e−r)−1)/2, B=(p^e−p^r)/2, and h_i=phi(p^i). Then n_e=aM+n_r, with 0≤n_r<M.

Classical q-Lucas gives, coefficient by coefficient,

    H_(n_e)(z;q) = (1+z^M)^a H_(n_r)(z;q) mod Phi_M(q).

This congruence is over the integral universal polynomial ring. One may derive it directly from the finite Euler product: modulo Phi_M, each complete M-block is 1+T^M. When k=d+ell M, the difference of the two triangular q-exponents is M ell(2d+ell M−1)/2, an integer multiple of M because M is odd. Thus the q-weights really cancel; no factorial or vanishing q-difference is inverted. Since Phi_M is monic, divisibility produces J in Z[q,z], not just a rational or local quotient.

The Gaussian coefficient symmetry gives the exact factor z+1 in H_n when n is odd. If both n_e and n_r are odd, cancel this monic persistent factor in (Z[q]/Phi_M)[z], a domain, and use monic division in q. This gives an integral quotient J^U. This argument does not divide by a nonunit after reduction. At an even half-degree the claimed exact persistent quotient is unavailable.

Choose a single complete unramified DVR O containing the chosen primitive t-th root eta. Set R_e=O[xi_e], pi_e=xi_e−1, and q_e=eta xi_e. For 0≤k<e, v_pi(xi_e^(p^k)−1)=p^k. The root eta^(p^k) of Phi_t is simple modulo p, so its derivative is a unit in this same component. Therefore

    v_pi(Phi_t(q_e^(p^k)))=p^k.

The exact identity Phi_(t p^r)(X)=Phi_t(X^(p^r))/Phi_t(X^(p^(r−1))) then gives

    v_pi(Phi_(t p^r)(q_e))=p^r−p^(r−1)=h_r.

Both arguments are nonzero because r<e. For r=e the numerator vanishes and this finite valuation calculation cannot be used. Evaluating the universal divisibility identity at q_e is therefore justified. Frobenius makes the difference between (1+z^(t p^r))^a and (1+z^t)^B a multiple of p; since v_pi(p)=h_e>h_r, it is negligible at the required precision. This proves (B) in mixed characteristic without a lower discriminant, separation, or unit assumption.

In characteristic p, Phi_(t p^r)(q)=Phi_t(q)^h_r. Substitution q=eta(1+x) gives x^h_r times a unit because Phi_t'(eta) is a unit. Thus the formal transport holds modulo x^h_r. At alpha_j=−eta^j,

    1+(alpha_j(1+v))^t = 1−(1+v)^t = v V_t(v),
    V_t(0)=−t, a unit.

Consequently the local H target has a zero rectangle u<h_r, b<B at every center. Where both quotients exist, the U transport has exactly the same rectangle. At the shared center the actual quotient is U(−(1+v))=−H(−(1+v))/v. There is no extra loss of v degree when the universal U identity was already available. The integral analogue follows directly from the integral transport before reduction. All centers and all primitive residue components satisfy these conclusions separately; no favorable coefficients from different components are combined.

## 2. Exact counterexample to the original shared-U sufficient condition in (D)

Take

    t=1, p=3, e=3, r=1,
    n_e=13, n_r=1, A=4, C=8.

Both n_e and n_r are odd, so this is inside the candidate's stated quotient domain. Nevertheless

    [x^4 v^8] U_13(−(1+v);1+x) = 1 in F_3.

The advertised inequalities both hold:

    h_(e−1)=h_2=6>4=A,
    h_e/2=h_3/2=9>8=C.

Thus the asserted zero rectangle under those inequalities fails for the shared quotient.

A compact symbolic derivation also explains the defect. Use the valid H transport with r=2, whose lower half-degree is 4, even:

    H_13(z;1+x) = (1+z)^9 H_4(z;1+x) mod x^6.

At z=−(1+v), divide the exact H_13 polynomial by −v. The identity implies

    U_13(−(1+v);1+x) = v^8 H_4(−(1+v);1+x) mod x^6.

The congruence remains valid after division because the left and transported term are both exactly divisible by v; the error coefficients are still multiples of x^6. The exact polynomial identity

    H_4(−1;q)=(1−q)(1−q^3)

becomes x^4 in F_3 at q=1+x. Hence the displayed coefficient is 1.

The independent executable obtains the same coefficient by exact integer q-Pascal reconstruction and exact synthetic division by z+1, then coefficient extraction. A second oracle enumerates all 8,192 subsets of {0,...,12}, reconstructs every Gaussian polynomial without Pascal or product multiplication, and matches the exact integer row. The raw H coefficient at x^4 v^9 is 2, confirming that replacing −H/v by H/v gives the wrong sign.

The cause is precise: if p≡3 modulo 4, adjacent half-degrees have opposite parity. The source's proof of (D) cannot apply its quotient theorem at r=e−1. This does not invalidate the guarded quotient transport or any statement for t=27,p=5.

## 3. Independently proved amendment to (D)

For H at every center, retain the original sufficient condition, for e≥2:

    h_(e−1)>A and h_e/2>C.

For the shared quotient at any layer with n_e odd, a uniform sufficient condition is instead

    h_(e−1)>A and h_e/2>C+1.                 (review amendment)

Proof: apply the always-valid H transport with r=e−1. It kills x^u v^d for u<h_(e−1), d<h_e/2. A U coefficient at degree b is minus the H coefficient at degree b+1. The revised inequality ensures b+1<h_e/2 throughout b≤C. This proof never requires U_(n_(e−1)) to exist. Since both bounds tend to infinity, every fixed finite rectangle eventually vanishes along all layers for which U is defined. The nonshared H targets retain the original stronger bound.

When n_e and n_(e−1) are both odd, the source's original bound for U remains valid by the quotient theorem itself. More generally one may take any parity-compatible 1≤s<e satisfying

    h_s>A and (p^e−p^s)/2>C.

For p≡3 modulo 4 and e≥3, s=e−2 is parity-compatible whenever n_e is odd. This is an alternative amendment, not required for the simpler C+1 bound.

For clarity, the exact domains are:

- H: every positive odd t, odd prime p not dividing t, and e>r≥1.
- U_i exists by the persistent-factor argument exactly on the domain used here: t p^i≡3 modulo 4.
- If p≡1 modulo 4, the quotient transport applies at every pair of layers when t≡3 modulo 4; when t≡1 modulo 4 no layer has odd half-degree.
- If p≡3 modulo 4, the quotient transport requires e and r of the same parity and t p^e≡3 modulo 4. There is no assertion of U at the intervening even-degree layers.

No change to p≡1 modulo 4 is imposed on the original H theorem, and no broad false statement is retained by silently narrowing all parameters.

## 4. The fixed order-675 normalization obstruction survives, with fewer dependencies

Take t=27, p=5, r=2 and any e≥3. Both relevant half-degrees are odd. Then h_r=20 and B_e=(5^e−25)/2≥50. For every center, including the correctly signed shared quotient, the coefficients at (u,b)=(1,10),(10,0),(5,6) vanish. The accepted order-675 coefficients were A_j,A_j,3A_j with A_j a unit. These particular unit witnesses therefore cannot survive unchanged.

In the actual higher cyclotomic ring, write the integral local identity

    L_e(v,pi_e)=[1−(1+v)^27]^B_e L_2(v,pi_e)+pi_e^20 W_e(v),

where L_2 is evaluated at q_e, and W_e is integral. Adjoin rho with rho^10=pi_e, and apply the exact old normalization

    F_e(Y)=rho^(−100) L_e(rho^9 Y,pi_e).

The bracket after substitution is coefficientwise divisible by rho^9. Raw integrality of L_2 alone gives a first summand in rho^(9B_e−100)E[Y], which is contained in rho^350 E[Y]. The error term lies in rho^(200−100)E[Y]=rho^100 E[Y]. Hence

    F_e in rho^100 E[Y],
    F_e'/rho^4 in rho^96 E[Y].

This proves the accepted obstruction without importing any order-675 coefficient bounds or its exact discriminant valuation. In particular the older second-normalization integrality proof, while valid, is unnecessary for this obstruction. The ordinary Y derivative cannot lower coefficient valuation because its multipliers are integers.

Thus the residue of F_e is zero, contradicting the proposed unchanged factorization with R monic reducing to Y^10+1 and S reducing to nonzero A_j. The old divided derivative is zero in the residue field as well. A positive-degree resultant involving this divided derivative cannot be a unit. This does not predict the actual higher Newton polygon, two root radii, factor degrees, or a higher discriminant valuation: the unknown pi_e^20 error can matter after another normalization.

## 5. Independent evidence and adversarial controls

Only newly written review programs execute. Candidate and historical programs are frozen as inert source text. Accepted historical output is used only for explicit comparisons; it is not used to produce the new rows.

`independent_global.cpp` builds the complete Gaussian row at n=1687 and n=337 in F_5[q]/(q^675−1), using a global q-Pascal recurrence rather than the candidate's local degree recurrence. Reduction of the difference by Phi_27(q)^20 checks all 1,688 z coefficients and all 360 q coordinates, totaling 607,680 scalar zero checks. Because q^675−1 has primitive-factor multiplicity 25, this computation legitimately retains the required precision 20. It does not pretend that q_e has order 675 in characteristic zero.

The same fresh global rows directly reconstruct 108 order-675 field coefficients (four at each of 27 centers), agreeing with the frozen independent Euler data and its corrected shared-center sign. They also directly show the 81 next-layer critical coefficients are zero. Stronger precision Phi_27^21 fails at z-degree 135. Replacing the lower root by the lower-layer root fails at z-degree 1; in this truncated ring the incorrect substitution is q→q^55, obtained from eta=q^325 and xi=q^351. These are genuine arithmetic failures, not only schema rejections.

`independent_check.py` uses the standard library to reconstruct exact integer Gaussian polynomials, prove finite cyclotomic divisibilities, and evaluate directly in finite mixed-characteristic rings

    O/p^4[x] / Phi_(p^e)(1+x).

The program retains p-adic carries and uses the Eisenstein relation, rather than merely treating p as zero. For an unramified basis, the valuation of an x-coordinate is h_e times its coefficient valuation plus its x-degree; distinct x-degrees have distinct weights modulo h_e, so no cancellation invalidates this test. Ten H/U controls cover t=1,3,7; p=3,5,7; e=2,3; r=1,2; the endpoint t=1; alternating quotient parity; nonsplit primitive fields; and both Hensel-lifted primitive t=3 components over p=7. Actual-root divisor valuations equal h_r, the congruences hold, and incorrect lower-root substitutions and excess precision are detected in mixed characteristic.

The failed original D rectangle and the corrected C+1 rectangle receive separate explicit tests. These finite tests are controls; the quantified proofs are in Sections 1, 3, and 4.

## 6. Primary-source attribution and replay

The block mechanism is classical q-Lucas. Bruce E. Sagan, *Congruence properties of q-analogs*, Advances in Mathematics 95 (1992), 127–143, Theorem 2.2 (printed page 131), gives the cyclotomic q-Lucas congruence and records antecedents. The primary full text was independently inspected on 13 October 2026:

https://users.math.msu.edu/users/bsagan/Papers/Old/cpq-pub.pdf

No novelty is claimed for q-Lucas, and historical novelty of the explicit tower obstruction remains unassessed. The new work here is the independent audit, the concrete falsification of the unrestricted quotient sufficient condition, its precise amendment, and the dependency-reduced obstruction proof.

Run `python3 replay.py` from any directory. It copies the packet into a clean temporary directory, compiles only `independent_global.cpp` with a C++17 compiler, executes only this review's Python checker, and requires both generated result files to be byte-identical to the sealed outputs. Python's standard library and a C++17 compiler are the only dependencies. `verify_artifact.py` checks every sealed file against its manifest. The frozen source ZIP hash, per-file source comparisons, primary-source locator, replay receipts, and final archive SHA256 are included alongside the review.
