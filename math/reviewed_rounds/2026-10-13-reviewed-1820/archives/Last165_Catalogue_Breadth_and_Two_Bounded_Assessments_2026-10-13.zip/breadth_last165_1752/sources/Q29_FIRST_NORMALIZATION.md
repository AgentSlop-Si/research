# Full cyclotomic normalization still fails at the second prime layer

13 October 2026 UTC. Candidate, not independently reviewed.

## Result in one paragraph

For the intrinsic residual discriminant D_s=Disc_z(H_((s−1)/2)/(z+1)), normalize by its **entire exact characteristic-zero Φ27 factor**, not by a known lower bound or by scalar content. The quotient is an integral polynomial, and hence defines an intrinsic integral cyclotomic element. For every prime p≡1 (mod 4) and every e≥2, s=27p^e, that normalized element has zero residue in **every** component above p. This disproves the proposed implication “good lower augmented guards imply a unit after exact characteristic-zero cyclotomic normalization.” For p=5 the lower field has one component and every lower guard passes. The first layer s=135 has a unit normalized discriminant and exact intrinsic uniformizer order 27; the second s=675 does not. A direct good-characteristic witness proves that the latter residual discriminant is nevertheless nonzero. No repeated-prime squarefreeness transfer or exact higher-layer valuation follows.

## 1. Definitions, inherited premises, and the proposed implication

Let H_n(z;q)=Σ_k [n choose k]_q z^k in Z[q,z], with the ordinary z derivative used throughout. For s≡3 (mod 4), let

    U_s(z;q)=H_((s−1)/2)(z;q)/(z+1),     D_s(q)=Disc_z(U_s(z;q)).

The quotient is an integral monic polynomial by odd-degree reciprocity. Put t=27, b=13, N=p^e, A=(N−1)/2, and

    ν=t A(A−1)/2,              Q_t(q)=(q^t−1)/Φ_t(q).

The source-bound accepted ordinary lower guard, resonance separation and all-A overlap theorem at t=2b+1 give **exactly** ord_(Φ_t) D_s=ν. Thus monic polynomial division defines

    d_(t,A)(q)=D_s(q)/Φ_t(q)^ν ∈ Z[q],
    O_s=Z[q]/Φ_s(q),       Δ_s=d_(t,A)(q) mod Φ_s(q).

These are distinct operations. The first is exact division in characteristic zero in Z[q]; the second is cyclotomic specialization. No zero or nilpotent residue is divided out. The exact integral relation is

    D_s(ζ_s)=Φ_t(ζ_s)^ν Δ_s                    in O_s.       (1)

Here Φ_t(ζ_s)≠0 because s>t, so it is a nonzero divisor. Consequently a nonzero residue of Δ_s in any one prime component implies D_s(ζ_s)≠0 in characteristic zero. This is a valid one-way certificate, with no missing denominator. It does **not** assert the converse.

The proposal being falsified is more specific: select a lower residue component in which Γ_t, Γ_t^ι and δ_t are units, and conclude that Δ_s is a unit in the corresponding ramified component after the exact Φ_t normalization. The counterexample below satisfies all the lower guards, yet the conclusion is false. No universal assertion about all conceivable normalizations is made.

## 2. An exact residual-cluster coefficient with no hidden g denominator

All quantities in this section are evaluated at a primitive characteristic-zero t-th root ω. Write

    U=U_t(z;ω),  g=U(−1),  D=Disc_z(U),
    F=z^t+1, F_0=F/(z+1), R_0=Res_z(F_0,U), R=g R_0,
    W=∏_(j=1)^b (1−ω^j) / ∏_(j=1)^((t+b)/2) (1−ω^(2j)),
    w=tW,        P_A=∏_(j=1)^A j^j.

A is even. Hence He_(A−1)(y)/y is an integral polynomial. Define the degree-A polynomial

    B_A(y)=g He_A(y) − A w He_(A−1)(y)/y.

The discriminant of B_A is the ordinary universal discriminant for a nonmonic degree-A polynomial, with leading coefficient g. Let ν=tA(A−1)/2. Then the following exact identity holds in the cyclotomic field:

    d_(t,A)(ω)
      = (−1)^[A(t−1)/2] Q_t(ω)^ν t^[tA(A+1)/2]
        · P_A^(t−1) · D · g² · R_0^(2A) · Disc_y(B_A).     (2)

Its right side belongs to the localization of Z[ω] obtained by inverting only

    S=∏_(j=1)^((t+b)/2) (1−ω^(2j)).

In particular **g is not a denominator in (2)**. Neither a factorial, A, He_A(0), nor a vanishing cluster discriminant is inverted.

### Independent derivation from the accepted local initial forms

Use q(ε)=ω(1+ε²)^(1/t). At each of the t−1 roots α≠−1 of F, the A initial displacements are the roots of He_A, scaled by α/√t. At −1 remove the persistent exact factor z+1 first; the A remaining initial displacements are the roots of

    T_A(y)=He_A(y)−A(w/g) He_(A−1)(y)/y,

scaled by 1/√t. This temporary field expression is legitimate in characteristic zero, where g≠0. The accepted overlap theorem supplies the required distinct initial displacements. All t clusters now have exactly A roots; the other roots are the b−1 simple residual roots of U.

The within-cluster squared differences contribute

    ε^(2ν) t^(−ν) P_A^(t−1) Disc(T_A).

The product of the roots of F_0 is 1, so no α factor was discarded. The cross-cluster contribution is Disc(F)^(A²), where Disc(F)=(−1)^((t−1)/2)t^t. Residual pairs and cluster-to-residual pairs contribute D R^(2A). Therefore the coefficient of ε^(2ν) in D_s(q(ε)) is

    C_D=(−1)^[A(t−1)/2] t^[tA(A+1)/2]
         P_A^(t−1) D R^(2A) Disc(T_A).                    (3)

The exponent of t is tA²−ν, and A²≡A (mod 2); these verify the scale and sign independently of division by the full H discriminant.

Since B_A=gT_A, homogeneity of the degree-A discriminant gives

    Disc(B_A)=g^(2A−2) Disc(T_A).

Substitute R=gR_0 into (3). All inverse g powers cancel, leaving exactly g² R_0^(2A) Disc(B_A). Finally q(ε)^t−1=ε²=Φ_t(q(ε))Q_t(q(ε)), so d_(t,A)(ω)=Q_t(ω)^ν C_D. This proves (2). In particular the conversion factor is Q_t^ν, not Q_t^(−ν).

## 3. The characteristic boundary and the nonunit theorem

Let p≡1 (mod 4) be prime. Then p∤27. In every primitive t-th-root residue component above p:

- t and 2 are units;
- each factor of S is a unit, since 1≤j≤20<t and t is odd;
- Q_t is a unit, since q^t−1 is separable modulo p and Φ_t is one of its coprime factors;
- every coefficient of B_A is integral in that component, even without assuming g is a unit.

Thus (2) proves that its entire right side is divisible by

    p^k,   k=(t−1) v_p(P_A),                             (4)

in Z[ω]⊗Z_p. This is a statement about the **leading characteristic-zero cyclotomic coefficient**, not about the full target Δ_s's p-adic valuation.

For e≥2, A=(p^e−1)/2≥p, and therefore v_p(P_A)>0. It follows that d_(t,A)(ω) reduces to zero in every component of Z[ω]/p. The standard reduction

    Φ_(tp^e)(q) mod p = (Φ_t(q) mod p)^h,
    h=φ(p^e),

identifies the reduced components of O_s/pO_s with these same primitive t-th-root fields. Since d_(t,A) is the **same integral polynomial** in both places, its value Δ_s has zero residue in every ramified component. Hence Δ_s is a nonunit in each component of O_s⊗Z_p. This proves the asserted uniform obstruction for all e≥2.

Equivalently, the accepted local ramification calculation gives v_i(Φ_t(ζ_s))=1 and v_i(p)=h. Relation (1) gives

    v_i(D_s(ζ_s))≥ν+1,

allowing infinity. We do not conclude ν+hk: subsequent Φ_t-adic coefficients can have smaller p-divisibility. We also do not conclude that Δ_s∈pO_s, that Δ_s is zero, or that D_s is zero. Field-component nonunits, full nonreduced residue classes, integer-coordinate content, and ordinary polynomial orders remain distinct.

### Why the Hermite factor is genuinely present

The classical identities He'_n=n He_(n−1) and He_n=y He_(n−1)−(n−1)He_(n−2) yield, by the resultant recurrence,

    Res(He_n,He_(n−1))=(−1)^[n(n−1)/2]∏_(j=1)^(n−1)j^j.

The monic discriminant formula therefore gives Disc(He_A)=P_A. No factorial inversions are used in this proof. The recurrence and normalization are recorded in [NIST DLMF §18.9](https://dlmf.nist.gov/18.9#T1); the resultant computation here is explicit. This classical mechanism is not claimed as new.

## 4. Fully guarded concrete counterexample: 27 → 135 → 675

Take p=5. The polynomial f=Φ27=q^18+q^9+1 is irreducible over F5, because ord_27(5)=18. The independent program additionally checks the finite-field irreducibility criterion at subdegrees 6 and 9. Thus there is exactly **one** lower residue component K=F_(5^18), and exactly one corresponding 5-adic component at every layer 27·5^e. Its ramification index at s=675 is 20.

The newly written checker constructs H13 twice, by q-Pascal and by the degree recurrence, then divides by z+1 with a multiplication-back check. It computes ordinary D27 and R27 both by Euclidean resultants and independent Sylvester determinants. It repeats the complete calculation at the actual inverse q^26. In the unique component it verifies every relevant quantity is nonzero:

    D27, R27, D27^ι, R27^ι, Γ27, Γ27^ι, δ27,
    g27, g27^ι, v27, v27^ι, S, S^ι, Q27, Q27^ι.

The inverse δ is nonzero too, though the original augmented test does not require it. Full ascending q-coordinate arrays are preserved in LOWER_COMPONENT_RESULTS.json. No separately chosen component is used for any guard. This independently establishes the needed mod-5 antecedent without reusing the historical c27⁺ coordinate certificate.

At the first layer s=135, A=2, ν=27, P_2=4, and

    T_2(y)=y²−1−2τ,       Disc(T_2)=4(1+2τ).

The checker verifies Disc(T_2)≠0 in K. Therefore (2) gives a nonzero residue for Δ135, and (1) proves the exact intrinsic valuation

    v_(Φ27)(D135(ζ135))=27

in its unique 5-adic DVR (where v(5)=4). This is a valid same-component unit implication for this first layer with all denominator guards supplied.

At the second layer s=675, A=12 and ν=1782. Since only j=5,10 contribute,

    v5(P_12)=5·v5(5)+10·v5(10)=15,
    v5(P_12^26)=390.

So (2) forces the normalized residue Δ675 mod the unique maximal ideal to be zero. In fact the explicitly constructed cluster polynomials reduce as

    He_12=y^10(y²−1),     He_11=y^11,
    T_12=y^10(y²−1−2τ)=y^10 T_2          over K.

This supplies an additional visible degeneration; it is not needed to cancel or weaken the factor P_12^26. The checker verifies the identities and both discriminant outcomes. The exact characteristic-zero polynomial order remains **1782**, while the intrinsic order is at least **1783**. Its exact value is not computed here.

### Nonunit does not mean nonsquarefree

A separate fresh scalar checker uses the prime 4051 and q=3454, of exact order 675. It constructs H337 by q-Pascal and independently by the finite Euler product, removes the Gaussian weights, and compares all coefficients. Direct finite-field computation gives

    Disc_z U675=3010,       U675(−1)=2005,
    Disc_z H337=3066,       Φ27(q)=3857,
    d_(27,12)(q)=2778             in F4051.

A separate Euclidean resultant reproduces the residual discriminant; the ordinary derivative gcd is 1. Exact order is checked by q^675=1, q^225=797≠1 and q^135=4019≠1. If D675 vanished at a primitive characteristic-zero 675th root, monicity and irreducibility of Φ675 would force divisibility in Z[q], contradicting this evaluation. Thus D675 and Δ675 are **nonzero** in characteristic zero while Δ675 is a **nonunit** at 5. This is one control for the same counterexample, not a uniform new squarefreeness family.

## 5. Scope, independent checks, and next useful obligation

The new result is an explicit integral residual-cluster coefficient, a valid normalized invariant, a first-layer unit certificate, and a uniform second-and-later-layer obstruction to this specified normalization. It is stronger than saying that a scalar-content remainder may be nilpotent: the **whole exact characteristic-zero cyclotomic factor of the actual intrinsic residual discriminant** has been removed. It is not a counterexample to every possible normalization or to repeated-prime simplicity.

The computations also directly reconstruct the full q-polynomial D_s at (t,A)=(3,2),(3,4), perform exact integer monic division, and match (2) coefficient-for-coefficient modulo Φ3. A separate full-degree integer jet at (t,A,ell)=(7,2,29) has nonconstant lower g and rejects omission of g², omission of the Hermite factor, and inversion of the Q power. Together these test the sign, t scale, g homogeneity and Q direction. They do not stand in for the proof's quantifiers. The full degree-336 q-polynomial D675 is not reconstructed; its integral quotient is established by the accepted exact-order theorem and the new algebraic proof. No predecessor research program was imported or executed.

The broader Q29 / ALG-OPEN-UNIFORM-SQUAREFREE / NEXT-RS-AUGMENTED priority-54 parent stays OPEN. Its endpoint-content mixed-characteristic subtask43 and the unrelated F2 paired-support gate58 remain separate. The first-normalization route is now decisively falsified at the second prime layer. A meaningful next target is an integral second-stage normalization of the degenerate local clusters, together with a genuine mixed-characteristic discriminant relation and one same-component unit proof. Another scalar-content census or repetition of this first leading coefficient would not discharge it.

No historical novelty, journal acceptance, FFT consequence, or bank-minimum improvement is claimed. The candidate must receive independent mathematical review before ledger promotion.
