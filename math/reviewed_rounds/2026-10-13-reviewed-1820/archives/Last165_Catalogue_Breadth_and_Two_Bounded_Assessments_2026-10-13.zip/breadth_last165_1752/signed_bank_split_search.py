"""Fresh exact F23 split-node test for source two-parameter sextic family."""
import json
from pathlib import Path
p=23
s=[1,17,2,0,5,11,18,10,14];u=[9,11,11,20,12,15,19]
A=[s[:4],s[1:5],s[2:6],u[:4]]
def solve(A,v):
 a=[r[:]+[x] for r,x in zip(A,v)]
 for j in range(len(A)):
  k=next(k for k in range(j,len(A)) if a[k][j]%p)
  a[j],a[k]=a[k],a[j];a[j]=[x*pow(a[j][j]%p,-1,p)%p for x in a[j]]
  for k in range(len(A)):
   if k!=j:
    d=a[k][j];a[k]=[(x-d*y)%p for x,y in zip(a[k],a[j])]
 return [r[-1] for r in a]
found=[]
for l in range(p):
 for m in range(p):
  rhs=[-s[6]-l*s[4]-m*s[5],-s[7]-l*s[5]-m*s[6],-s[8]-l*s[6]-m*s[7],-u[6]-l*u[4]-m*u[5]]
  c=solve(A,rhs)+[l,m,1]
  roots=[x for x in range(1,p) if sum(a*pow(x,i,p) for i,a in enumerate(c))%p==0]
  if len(roots)==6:found.append({'lambda':l,'mu':m,'coefficients':c,'roots':roots})
r={'scope':'N11,q2,F23. Source mirrored six-node, singleton-one two-parameter sextic family only. All 529 parameters tested for six distinct nonzero F23 roots; full physical rows not tested.','cases':529,'split_candidates':found,'limits':'No absence of a split polynomial outside this two-parameter source family; no field-extension, unrestricted-bank or characteristic-zero claim.'}
Path(__file__).with_name('SIGNED_BANK_SPLIT_SEARCH.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
