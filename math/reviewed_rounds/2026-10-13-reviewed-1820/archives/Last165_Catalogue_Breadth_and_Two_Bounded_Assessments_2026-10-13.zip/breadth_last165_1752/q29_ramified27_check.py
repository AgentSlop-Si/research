"""Fresh exact ordinary-discriminant computation in Q(zeta27)."""
import sympy as s,json,time
from pathlib import Path
from sympy.polys.rings import ring
x=s.symbols('x'); phi=s.Poly(s.cyclotomic_poly(27,x),x)
K=s.QQ.alg_field_from_poly(phi);q=K.unit
R,z=ring('z',K)
one,zero=K.one,K.zero
row=[one]
for n in range(1,14):
 row=[(row[k] if k<len(row) else zero)+(q**(n-k)*row[k-1] if k>0 else zero) for k in range(n+1)]
H=R.from_dict({(i,):c for i,c in enumerate(row)})
U,rem=divmod(H,z+1);assert rem==0
print('constructed U',U.degree(),flush=True)
D=U.resultant(U.diff(z))
# degree12 sign is +1; U monic, so ordinary discriminant equals resultant.
# resultant is an ANP field element
val=D
coeff=[s.Rational(a) for a in val.to_list()]
P=s.Poly.from_list(coeff,x)
Ppi=s.Poly(P.as_expr().subs(x,1+x),x).rem(s.Poly(phi.as_expr().subs(x,1+x),x))
def vp(a,p):
 a=s.Rational(a)
 if not a:return None
 n,d=int(a.p),int(a.q);v=0
 while n%p==0:v+=1;n//=p
 while d%p==0:v-=1;d//=p
 return v
weights=[(i,18*vp(Ppi.nth(i),3)+i) for i in range(18) if Ppi.nth(i)]
report={'scope':'t=1,p=3,e=3,q primitive27,n13,U13=H13/(z+1),ordinary discriminant. Exact cyclotomic field; unique 3-adic component; pi=q-1,v_pi(3)=18.', 'degree_U':U.degree(),'D_q_ascending':[str(P.nth(i)) for i in range(18)],'D_pi_ascending':[str(Ppi.nth(i)) for i in range(18)],'weights':weights,'v_pi_D':min(v for i,v in weights),'nonzero':bool(val),'limits':'This is a fresh bounded candidate calculation, not the t27,p5 higher-tower normalization, independent acceptance, all-layer result, global unitness or novelty.'}
Path(__file__).with_name('Q29_RAMIFIED27_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
