"""Fresh bounded necessary-recurrence test. No predecessor program imported."""
import json,itertools
from pathlib import Path
p,N=23,11

def inv(a): return pow(a%p,-1,p)
def gauss(n,k,q):
 if k<0 or k>n:return 0
 t=1
 for j in range(1,k+1):t=t*(1-pow(q,n-k+j,p))*inv(1-pow(q,j,p))%p
 return t

def G(a,b,e,d,q):
 r=e*a%N;l=d*b%N
 return gauss(r+l,l,pow(q,e*d%(p-1),p)) if r+l<N else 0

def det(A):
 A=[x[:] for x in A];D=1
 for j in range(len(A)):
  k=next((k for k in range(j,len(A)) if A[k][j]%p),None)
  if k is None:return 0
  if j!=k:A[j],A[k]=A[k],A[j];D=-D
  v=A[j][j]%p;D=D*v%p
  for k in range(j+1,len(A)):
   c=A[k][j]*inv(v)%p
   A[k]=[(u-c*v)%p for u,v in zip(A[k],A[j])]
 return D%p

def matrix(q,y):
 h=pow(4,-1,N)
 v={}
 for b in [1,2]:
  amp=inv(pow(y,b,p)*G(N-b,b,-1,1,q))
  start=1 if b==1 else 2
  v[b]=[(pow(q,h*(a+b)**2%N,p)-amp*pow(y,(-a)%N,p)*G(a,b,-1,1,q))*inv(G(a,b,1,1,q))%p for a in range(start,N-b)]
 return [v[1][i:i+6] for i in range(4)]+[v[2][i:i+6] for i in range(2)]
roots=[q for q in range(1,p) if pow(q,N,p)==1 and q!=1]
rows=[]
for q in roots:
 for y in range(1,p):
  A=matrix(q,y);D=det(A)
  rows.append({'q':q,'minus_plus_node':y,'determinant_mod_23':D,'local_5node_gate':'EXCLUDED' if D else 'NOT_EXCLUDED','matrix':A})
report={'scope':'N=11,F23, all 10 primitive roots q, one nonzero minus-plus singleton node y; at most five effective plus-plus nodes. Necessary central recurrence only. Original signed-bank grammar, no new gauges.', 'cases':len(rows),'excluded':sum(r['determinant_mod_23']!=0 for r in rows),'not_excluded':sum(r['determinant_mod_23']==0 for r in rows),'survivors':[{k:r[k] for k in ['q','minus_plus_node']} for r in rows if not r['determinant_mod_23']], 'zero_node_case':'y=0 is impossible because the exclusive target coefficient at (a,b)=(10,1) is nonzero and has a factor y.', 'limits':'No full-row construction, unrestricted bank minimum, characteristic-zero transfer, extension-field exclusion, acceptance or novelty claim.', 'rows':rows}
Path(__file__).with_name('SIGNED_BANK_F23_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
