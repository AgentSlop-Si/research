"""Fresh alternate controls, imports no historical or candidate scientific program."""
import json,math
from pathlib import Path
import sympy as s
P=Path(__file__).parent
p,N=23,11

def inv(x,p):return pow(x%p,-1,p)
def rank(A,p):
 a=[r[:] for r in A];r=0
 for j in range(len(a[0])):
  k=next((i for i in range(r,len(a)) if a[i][j]%p),None)
  if k is None:continue
  a[r],a[k]=a[k],a[r];t=inv(a[r][j],p);a[r]=[x*t%p for x in a[r]]
  for i in range(len(a)):
   if i!=r:
    t=a[i][j];a[i]=[(x-t*y)%p for x,y in zip(a[i],a[r])]
  r+=1
  if r==len(a):break
 return r

def gp(n,k,q,p):
 r=[1]
 for m in range(1,n+1):r=[((r[j] if j<len(r) else 0)+(pow(q,m-j,p)*r[j-1] if j else 0))%p for j in range(m+1)]
 return r[k]

def G(a,b,e,d,q):
 r=e*a%N;l=d*b%N
 return gp(r+l,l,pow(q,e*d%(p-1),p),p) if r+l<N else 0
raw=json.loads((P/'SIGNED_BANK_F23_RESULT.json').read_text());count=0
for old in raw['rows']:
 q,y=old['q'],old['minus_plus_node'];seq={}
 for b in [1,2]:
  forced=inv(pow(y,b,p)*G(N-b,b,-1,1,q),p)
  seq[b]=[(pow(q,3*(a+b)**2%N,p)-forced*pow(y,(-a)%N,p)*G(a,b,-1,1,q))*inv(G(a,b,1,1,q),p)%p for a in range(b,N-b)]
 A=[seq[1][i:i+6] for i in range(4)]+[seq[2][i:i+6] for i in range(2)]
 assert A==old['matrix'];assert (rank(A,p)==6)==bool(old['determinant_mod_23']);count+=1
# Independent finite-field literal resultant controls for the discriminant field vector.
d=json.loads((P/'Q29_RAMIFIED27_RESULT.json').read_text());x,y=s.symbols('x y');phi=s.Poly(s.cyclotomic_poly(27,x),x)
D=s.Poly(sum(s.Integer(a)*x**i for i,a in enumerate(d['D_q_ascending'])),x)
# Independent norm as determinant of multiplication, rather than resultant over number field.
cols=[s.Poly(D.as_expr()*x**i,x).rem(phi) for i in range(18)]
M=s.Matrix([[v.nth(i) for v in cols] for i in range(18)])
norm=int(M.det(method='domain-ge'))
def vp(n,p):
 if n==0:return None
 v=0
 while n%p==0:n//=p;v+=1
 return v
assert vp(norm,3)==174
# Modular H built by degree recurrence, independent of q-Pascal used in candidate.
mods=[]
for p in [109,163,271]:
 roots=[q for q in range(2,p) if pow(q,27,p)==1 and pow(q,9,p)!=1]
 for q in roots:
  A=s.Poly(1,y,modulus=p);B=s.Poly(1+y,y,modulus=p)
  for n in range(2,14): A,B=B,s.Poly((1+y)*B.as_expr()-y*(1-pow(q,n-1,p))*A.as_expr(),y,modulus=p)
  U,rem=s.div(B,s.Poly(1+y,y,modulus=p));assert rem.is_zero
  ans=int(U.discriminant())%p
  assert ans==int(D.eval(q))%p
  mods.append({'p':p,'q':q,'disc_mod_p':ans})
# Exact Hermite initial form and ordinary normalization exponent.
H0,H1=s.Poly(1,y),s.Poly(y,y)
for n in range(2,14):H0,H1=H1,s.Poly(y*H1.as_expr()-(n-1)*H0.as_expr(),y)
L,rem=s.div(H1,s.Poly(y,y));assert rem.is_zero
lead=int(L.discriminant());assert lead!=0
r={'signed_alternate_qPascal_and_rank_cases':count,'signed_negative_control':{'q2_y1_source_det':next(z['determinant_mod_23'] for z in raw['rows'] if z['q']==2 and z['minus_plus_node']==1),'q3_y4_singular_detected':next(z['determinant_mod_23'] for z in raw['rows'] if z['q']==3 and z['minus_plus_node']==4)},'Q29_modular_degree_recurrence_controls':mods,'Q29_norm_D':str(norm),'Q29_v3_norm_D':vp(norm,3),'Q29_ordinary_qminus1_exponent':66,'Q29_Hermite_initial_form':str(L.as_expr()),'Q29_discriminant_initial_coefficient':str(lead),'Q29_v3_initial_coefficient':vp(lead,3),'Q29_intrinsic_normalized_valuation':174-66,'Q29_false_leading_content_extrapolation':66+18*vp(lead,3),'limits':'Alternate controls by same author; not independent review. New finite calculations do not close parents.'}
(P/'CANDIDATE_CROSSCHECKS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['Q29_modular_degree_recurrence_controls','Q29_norm_D']},indent=2))
