import json,csv,hashlib,collections,shutil
from pathlib import Path
import openpyxl
P=Path(__file__).parent
raw=json.loads((P/'INPUT_ROWS.json').read_text());overlay=list(csv.DictReader(open('rank_current_priorities_1539/packet/ALL_331_PRIORITY_OVERLAY.csv')))
groups=collections.defaultdict(list)
for x in overlay:groups[x['group']].append(x['record_id'])
w=openpyxl.load_workbook('later_results_independent_1700/post_application/FINAL_NATIVE_EXPORT.xlsx',data_only=True)
actioncols={'Research overview':['C','P'],'Catalogue':['AE'],'novelity breakthough':['Y'],'Research queue':['F'],'Next cycle':['D','K'],'Incoming queue':['F','K'],'Theorem register':['G'],'Fusion list':['F']}
refinements={
'Q08':('REPEAT_COMPLETED_B31_RISK','The owning Research queue F11 requests b31 ordinary-residual construction while E11 records its accepted completion. Replace this stale task. Keep general uniform reciprocal-support and the separate b31 all-A overlap open.'),
'NEXT-PREFIX-P13':('CLOSED_SUCCESSOR_STALE','The named p13 task is closed, and its referenced two-prime mathematical successor is also now complete. Remove the active-successor wording and obsolete 71 rationale; refer only to the separate publication/attribution parent.'),
'TH-06':('REFUSAL_SCOPE_STALE','Theorem register G17 already records the frozen eager-design resource refusal. Overview C296/P296 should require a changed, fully charged design instead of implying the same eager execution is an open experiment.'),
'Q16':('STALE_PRIORITY_OVERLAY_ONLY','Latest accepted table retires fair-tape and sparse-success audits. Replace older operational metadata with the accepted table current integration gaps; active parent work is excluded here.'),
'STR-Q1':('STALE_PRIORITY_OVERLAY_ONLY','Same Q16 operational alias; no duplicate adapter assignment or independent result count.'),
'Q27':('STALE_PRIORITY_OVERLAY_ONLY','The selected (2;8,9,11) label is complete in the accepted table. Retire the recommendation of that label and preserve unclassified-fiber scope. Active parent work is excluded here.'),
'M-MAGNETIC-SPAN':('PENDING_NEW_BOUNDED_ASSESSMENT','Variable-singleton N11/F23 recurrence and split-family tests performed here, pending independent review; N5 all-field and N11 singleton-one degree-five tests are already accepted and were not rerun.'),
'NEW-17':('SHARED_PENDING_ASSESSMENT','Same signed-bank task view as M-MAGNETIC-SPAN; preserve the distinct historical uniform upper-bound statement. No extra candidate or theorem count.'),
'NEXT-MAGNETIC-SIGNED':('SHARED_PENDING_ASSESSMENT','Same signed-bank task view as M-MAGNETIC-SPAN; no separate dispatch.'),
'Q35':('SHARED_PENDING_ASSESSMENT','Same signed-bank task view as M-MAGNETIC-SPAN; no separate dispatch.'),
'Q29':('PENDING_NEW_BOUNDED_ASSESSMENT','Exact t1,p3,e3 discriminant calibration gives candidate v_pi D=174 and normalized valuation108; this is not the still-open t27,p5,e>=3 normalization.'),
'NEXT-RS-AUGMENTED':('SHARED_PENDING_ASSESSMENT','Same Q29 normalization parent. Small ramified calibration is pending review and does not reclose the accepted old-normalization obstruction.'),
'M-TREE-WITNESS':('DUPLICATE_COMPARISON_GUARD','The source-readiness record says the available comparison overlaps the broad native instruction. Select a genuinely different theorem and exact clause before dispatch; no automatic generic repeat.'),
'NEW-01':('ACTIVE_RELATED_SCOPE_GUARD','Q16 finite-word developments do not automatically replace this ideal-arithmetic theorem. No separately selected NEW-01 task; avoid duplicate active Q16 work.'),
'NF-02':('ACTIVE_RELATED_SCOPE_GUARD','No specific chart selected; coordinate with active Q27. Distinct views are not separate feasible-fiber dispatches.'),
'Q23':('ACTIVE_RELATED_SCOPE_GUARD','No specific surviving chart selected; coordinate with NF02 and active Q27. Do not rerun accepted witnesses or invent56 missing historical cases.'),
'N256-FULL-MODEL-20261011':('DUPLICATE_TARGET_GUARD','Same downstream affine Fourier feasibility target as N256-SOLVER-SATURATION; select at most one bounded chart/solver task, not two assignments.'),
'N256-SOLVER-SATURATION-20261011':('DUPLICATE_TARGET_GUARD','Determinant/saturation scope is complete; same downstream target as N256-FULL-MODEL. No second solver assignment.'),
'STRUCTURED-RESIDUAL-EXECUTOR-20261012':('AUTHORIZATION_GATE_PRESERVED','Exact historical program execution is a separate preserved authorization gate. No historical script run or workaround performed here.'),
'Q30':('DATED_SOURCE_GAP_RECONCILED','Current report body has been recovered; three exact source bodies remain absent in accepted snapshot. Frozen225 register intentionally retains its dated four-pin account; do not rerun broad source search without a new locator.'),
'Q34':('NO_BROAD_RECOVERY_GUARD','Exact original certificate/checker pins remain required. Explicit no further broad recovery without a new locator is preserved.'),
}
# Source rechecks are packet-level, not proof or row-specific clearance.
pins=json.loads((P/'SOURCE_PIN_RECHECKS.json').read_text());pc=collections.defaultdict(collections.Counter)
for x in pins:pc[x['packet_id']][x['fresh_local_recheck']]+=1
ledger=[];bindings=[]
for i,d in enumerate(raw,166):
 k=d['record_id'];c=d.get('coverage');cur=d['current'];closed=d['baseline_status']=='CLOSED'
 if k in refinements:flag,note=refinements[k]
 elif closed:flag,note='CLOSED_SCOPE_PRESERVED','No active proof task at the named closed scope. Parent or historical-priority caveats do not reopen it.'
 elif 'SOURCE_BLOCKED' in d['operational_state']:flag,note='DATED_SOURCE_GAP_PRESERVED','The current source gap is dated and qualified. Available predecessor text does not replace the required latest body; no new locator or source-dependent experiment selected.'
 elif c and c['frozen_readiness']=='NEEDS_SCOPE_SELECTION':flag,note='BOUNDED_SCOPE_UNSELECTED','Source/task register names the missing exact successor. Availability and broad topic lists do not themselves create a ready mathematical task.'
 elif int(d['recommended_priority'])<=15:flag,note='COMPLETED_SELECTED_SLICE_PARENT_PRESERVED','Selected stage is complete/inactive; retained parent status is not a request to rerun it. A new bounded successor requires its own contract.'
 else:flag,note='CURRENT_SCOPE_RETAINED','Accepted snapshot and source/action record give no new independently accepted evidence for changing this score or reopening a completed stage.'
 row={'lexical_index_zero_based':i,'record_id':k,'title':d['title'],'obligation_group':d['group'],'baseline_status':d['baseline_status'],'current_status':cur.get('5',d['baseline_status']),'existing_score':int(d['recommended_priority']),'proposed_score':int(d['recommended_priority']),'score_delta':0,'score_band':('completed/inactive' if int(d['recommended_priority'])<=15 else 'low-leverage optional' if int(d['recommended_priority'])<=34 else 'supporting' if int(d['recommended_priority'])<=49 else 'consequential uncertain parent gate'),'audit_depth':'STATUS_SOURCE_ACTION_ONLY; selected fresh calculations separately marked pending review','audit_flag':flag,'audit_finding':note,'current_next_action':cur.get('16','No overview row; inspect bound owning view.'),'current_stop_boundary':cur.get('17',''),'source_availability':(c['frozen_readiness']+' AS_DATED' if c else 'CURRENT_ACCEPTED_VIEW_ONLY; see selected-source evidence if assessed'),'source_limits':json.dumps(c['selection_or_source_limit'],ensure_ascii=False) if c else cur.get('10',''),'coverage_packet':c['packet_id'] if c else '', 'coverage_readiness_sha256':c['readiness_record_sha256'] if c else '', 'fresh_packet_source_recheck_counts':json.dumps(dict(pc[c['packet_id']])) if c else '', 'preserve_completed_scope':c['preserve_completed_scope'] if c else cur.get('14',''), 'shared_record_views':' | '.join(sorted(groups[d['group']])), 'duplicate_rule':'Preserve every ID and distinct theorem scope. One coordinated dispatch per shared actual task; repeated views are not discoveries.', 'rubric_evidence':'Value and breadth: inherited bounded parent importance; readiness: '+(c['frozen_readiness'] if c else 'current accepted source/action view')+'; distinctness and tractability: '+note+' No new accepted score-changing evidence; pending calculations receive no novelty credit.', 'evidence_locations':'; '.join(f"{b['sheet']}!{b['id_column']}{b['row']}" for b in d['bindings'])}
 ledger.append(row)
 for b in d['bindings']:
  sheet=w[b['sheet']];assert sheet[f"{b['id_column']}{b['row']}"].value==k,(k,b)
  fields={col:sheet[f'{col}{b["row"]}'].value for col in actioncols.get(b['sheet'],[])}
  bindings.append({'record_id':k,'sheet':b['sheet'],'row':b['row'],'id_column':b['id_column'],'verified_id':k,'action_fields_verbatim':fields})
with (P/'LAST165_COVERAGE_LEDGER.csv').open('w') as f:
 wr=csv.DictWriter(f,fieldnames=list(ledger[0]));wr.writeheader();wr.writerows(ledger)
(P/'LAST165_COVERAGE_LEDGER.json').write_text(json.dumps(ledger,indent=2,ensure_ascii=False)+'\n')
(P/'ALL_BOUND_ACTION_FIELDS.json').write_text(json.dumps(bindings,indent=2,ensure_ascii=False)+'\n')
# Minimal immutable preimage proposals; not applied. Prepends preserve original dated history verbatim.
proposals=[]
def add(id,sheet,cell,new,why):
 old=w[sheet][cell].value
 proposals.append({'record_id':id,'sheet':sheet,'cell':cell,'before':old,'before_sha256_utf8':hashlib.sha256(str(old).encode()).hexdigest(),'after':'[2026-10-13; breadth action audit proposal, not yet applied]\n'+new+'\n\nEarlier dated history (preserved verbatim):\n'+str(old),'reason':why})
q08='The b31 ordinary-residual certificate and independent review are complete, alongside the earlier b27/b29 scopes. Continue only through a separately declared remaining F020 uniform reciprocal-support task or the distinct b31 all-A overlap question with its own exact guards. Do not reconstruct or re-review the accepted b31 ordinary-residual stage.'
for sh,cell in [('Research queue','F11'),('Research overview','C25'),('Research overview','P25')]:add('Q08',sh,cell,q08,'Research queue E11 records b31 ACCEPT but F11 still orders its construction; overview names only b27 and can redispatch this completed successor.')
pre='No active mathematical task remains at this p13 stage or the referenced two-prime group route. Preserve both accepted completions at priority15. Only NEW-16’s separate publication/attribution obligations remain, including the source-blocked complete EFK comparison and author/venue/release decisions; no new mathematical successor is selected.'
for sh,cell in [('Next cycle','D12'),('Next cycle','K12'),('Research overview','C328'),('Research overview','P328')]:add('NEXT-PREFIX-P13',sh,cell,pre,'The referenced two-prime mathematical route is already accepted complete in its current row; avoid treating a closed sibling as an active successor.')
add('NEXT-PREFIX-P13','Next cycle','H12','This named p13 scope and the referenced two-prime mathematical route are COMPLETE at their retained priority15. The earlier successor71 was historical workflow triage and is no longer a live task score. No score cell changes are proposed.','Current top rationale still calls the closed successor71, conflicting with its accepted15 score.')
th='Preserve the accepted paid3-4-5 template construction and the separately accepted frozen eager-design resource refusal. Any executor continuation must specify a genuinely changed, fully charged design or a distinct implemented certified interface. Do not rerun the refused eager build; broader compiler and regular-fast-jet obligations remain separate.'
for cell in ['C296','P296']:add('TH-06','Research overview',cell,th,'Theorem register G17 records accepted resource refusal; overview still lists eager execution without the required changed-design qualification.')
(P/'MINIMAL_CELL_CORRECTIONS.json').write_text(json.dumps(proposals,indent=2,ensure_ascii=False)+'\n')
meta=[]
for k in ['Q16','STR-Q1','Q27']:
 d=next(x for x in raw if x['record_id']==k)
 meta.append({'record_id':k,'field':'operational_state','before':d['operational_state'],'after':'ACCEPTED_SELECTED_SUBGATE_RETIRED; CURRENT_PARENT_INTEGRATION_ACTIVE_ELSEWHERE' if k!='Q27' else 'SELECTED_2_8_9_11_LABEL_ACCEPTED; DISTINCT_UNCLASSIFIED_SLICE_REQUIRED','evidence':'Current accepted Research overview action and result; no accepted-table change requested here.'})
(P/'PRIORITY_OVERLAY_METADATA_CORRECTIONS.json').write_text(json.dumps(meta,indent=2)+'\n')
rubric={'score_meaning':'Ordinal research work priority only; not novelty, significance, probability, correctness or publication merit.','bands':{'1-15':'completed/inactive','16-34':'low-leverage optional','35-49':'supporting','50-64':'consequential uncertain parent gates','65-79':'unusually tractable high-leverage gates','80-100':'decisive time-critical opportunities'},'questions':['value','evidence readiness','distinctness from completed work','bounded tractability/cost','breadth of benefit'],'formula':'No calibrated numeric formula asserted; preserve existing integer unless accepted new evidence justifies a change.','decision':'All165 scores unchanged. Accepted subgates change action definitions, not parent novelty or score. Fresh calculations are pending independent review.','source':'rank_current_priorities_1539/packet/EVIDENCE_AND_METHOD.json; coordinated with first-half audit.'}
(P/'SCORING_RUBRIC.json').write_text(json.dumps(rubric,indent=2)+'\n')
validation={'assigned_rows':165,'first_id':ledger[0]['record_id'],'last_id':ledger[-1]['record_id'],'unique_ids':len({x['record_id'] for x in ledger}),'matches_sorted_331_slice': [x['record_id'] for x in ledger]==[x['record_id'] for x in sorted(overlay,key=lambda x:x['record_id'])[166:]],'all_scores_preserved':all(x['existing_score']==x['proposed_score'] for x in ledger),'statuses':dict(collections.Counter(x['baseline_status'] for x in ledger)),'verified_native_bindings':len(bindings),'coverage225_member_ids':sum(bool(x['coverage']) for x in raw),'source_register_entries_rechecked':len(pins),'source_recheck_outcomes':dict(collections.Counter(x['fresh_local_recheck'] for x in pins)),'source_scope':'571 register references across relevant packets, not571 distinct sources or proof audits. 122 entries originally have no bound local body. Missing-source history is not resolved.','minimal_cell_proposals':len(proposals),'external_writes':False,'historical_scientific_programs_executed':False,'proof_audit_of165':False}
(P/'VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(validation,indent=2))
