# Last165 catalogue breadth audit

## Result

All165 assigned stable IDs, lexical indices166–330 from M-F8-EXACT through TH-10, are preserved. All165 existing and proposed work-priority scores are equal. The audit resolves413 native ID/view bindings and covers138 research-open and27 closed named scopes. This is a status/source/action audit, not a proof or novelty audit of165 results.

The rowwise ledger records the current bounded action, completed scope, source limitation, shared views, explicit scoring rubric and evidence. It is joined to the current accepted post-application workbook, not merely the earlier priority overlay.112 of the165 IDs belong to the original225-group source-readiness cohort. Across the corresponding source packets,449 already-bound local source references rehash exactly;122 register references have no originally bound local body. These are571 references, not571 distinct proof sources or new acceptances. Dated missing-source limitations remain.

## Minimal corrections, not applied

`MINIMAL_CELL_CORRECTIONS.json` contains10 exact before/after proposals with UTF-8 preimage hashes:

- Q08: Research queue F11 still requests b31 ordinary-residual construction even though E11 records its accepted completion. Correct F11 and align overview C25/P25. Keep b31 all-A overlap and F020 uniform support separate.
- NEXT-PREFIX-P13: Next cycle D12/K12 and overview C328/P328 still direct work to the now-completed two-prime mathematical successor. Next cycle H12 still advertises its old71 rationale. Preserve both completed15 scores and route only to the separate NEW-16 publication/attribution parent.
- TH-06: Overview C296/P296 should acknowledge the already accepted frozen eager-design refusal and require a changed, fully charged executor design. Theorem register G17 already provides that accepted refusal.

The older priority CSV also needs three metadata-only retirements, in `PRIORITY_OVERLAY_METADATA_CORRECTIONS.json`: Q16 and STR-Q1 fair-tape recommendation, and Q27's selected (2;8,9,11) label. Their current accepted table actions are already later. No accepted-table score/status/ID change is proposed for these.

Other important repeat guards are in the rowwise ledger: the two N256 views share one downstream target; NF02/Q23 must not duplicate active Q27; M-TREE-WITNESS needs a genuinely different comparator; dated Q30/Q34 recovery restrictions remain. No missing current body is silently replaced by an older theorem.

## Two source-bound assessments, pending independent review

1. Signed banks, parent56: a new N11/F23 variable-cross-singleton recurrence gate. It excludes211/220 primitive-root/node pairs; at q=2 all22 nonzero singleton nodes are excluded for a plus-plus support of at most5 nodes. Reflection gives the corresponding14-bank restricted lower. The exact mirrored six-node source family has no F23 split witness across529 parameter pairs; a separate enumeration of all74,613 six-node subsets agrees. This is not an unrestricted bank minimum or characteristic-zero transfer. The later accepted non-depressed-quintic result was discovered and preserved rather than rerun as an open task.

2. Q29, parent54: a small t1,p3,e3 ramified ordinary-discriminant calibration. Exact U13 at a primitive27th root gives intrinsic valuation174; exact Phi1 multiplicity66 gives normalized valuation108. A multiplication-matrix norm and54 modular degree-recurrence controls agree. The leading coefficient has v3=33, showing why naively charging its entire content by ramification would falsely predict660. This is not the still-open t27,p5 higher-layer normalization or a uniform squarefreeness theorem.

Full mathematical statements, reductions, scripts, exact outputs and source bytes are included in `SIGNED_BANK_ASSESSMENT.md` and `Q29_ASSESSMENT.md`. These calculations are same-worker candidate work, not independent acceptance. They do not increase scores or discovery counts.

## Bounded next tasks

- Independently review the variable-singleton source reduction, all220 matrices and both split-node calculations. Stop at exact scoped accept/reject or a precise mismatch; do not expand to unrestricted14-bank optimality.
- Independently reconstruct the U13 ordinary discriminant, Phi1 multiplicity66 and unique-prime local valuation174/108. Stop at exact scoped accept/reject or a mismatch; do not transfer it to the main t27,p5 tower.

No Sheet or GitHub writes, historical scientific program execution, source-authority workaround, or claim of complete proof review occurred.
