"""Fresh alternate all-six-node-subset check; no affine pencil solver."""
from itertools import combinations
from pathlib import Path
import json,math
p=23
# Reconstruct source s/u from the fresh variable-singleton matrix at q2,y1.
r=json.loads(Path(__file__).with_name('SIGNED_BANK_F23_RESULT.json').read_text())
A=next(x['matrix'] for x in r['rows'] if x['q']==2 and x['minus_plus_node']==1)
v1=A[0]+[A[1][-1],A[2][-1],A[3][-1]]
s=[x*pow(16,-1,23)%23 for x in v1]
u=A[4]+[A[5][-1]]
assert s==[1,17,2,0,5,11,18,10,14] and u==[9,11,11,20,12,15,19]
solutions=[];count=0
for nodes in combinations(range(1,23),6):
 c=[1]
 for a in nodes:
  d=[0]*(len(c)+1)
  for i,x in enumerate(c):d[i]=(d[i]-a*x)%23;d[i+1]=(d[i+1]+x)%23
  c=d
 count+=1
 if any(sum(c[k]*s[i+k] for k in range(7))%23 for i in range(3)):continue
 if sum(c[k]*u[k] for k in range(7))%23:continue
 solutions.append(nodes)
assert count==math.comb(22,6)==74613
out={'six_nonzero_node_subsets':count,'compatible_subsets':solutions,'moment_arrays_reconstructed_from_fresh_gaussian_checker':True,'source_parameter_family_scope':'Every monic sextic satisfying all4 shared recurrence equations. All6-node subsets have been checked independently of affine-pencil enumeration.','independent_reviewer':False}
Path(__file__).with_name('SPLIT_SUBSET_CROSSCHECK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
