"""New independent source/text and arithmetic review; never execute candidate code.

Only AST parsing, byte verification, fresh mathematical models, and a newly
written Python-language witness run. No AST interpreter or extracted code runs.
"""
import ast
import hashlib
import io
import itertools
import json
from pathlib import Path
import zipfile
from fractions import Fraction

ROOT = Path(__file__).resolve().parents[1]
checks = 0
cases = 0

def check(ok, label):
    global checks
    checks += 1
    if not ok:
        raise AssertionError(label)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def opened(name, expected):
    data = (ROOT/'evidence'/name).read_bytes()
    check(digest(data) == expected, 'archive pin '+name)
    archive = zipfile.ZipFile(io.BytesIO(data))
    check(archive.testzip() is None, 'CRC '+name)
    check(len(archive.namelist()) == len(set(archive.namelist())), 'unique members')
    return archive

candidate = opened('Q16_Exact_Centered_Source_Constructor_Candidate_2026-10-13.zip',
                   'a837bf0dfc376a6914e6fa3e75d10323766be41202a30e240eb85ccb2e446ae9')
manifest = json.loads(candidate.read('MANIFEST.json'))['files']
check(set(candidate.namelist()) == set(manifest)|{'MANIFEST.json'}, 'complete inventory')
for name, rec in manifest.items():
    data = candidate.read(name)
    check(len(data) == rec['bytes'] and digest(data) == rec['sha256'], name)
for rec in json.loads(candidate.read('SOURCES.json'))['sources']:
    data = candidate.read(rec['frozen_copy'])
    check(len(data) == rec['bytes'] and digest(data) == rec['sha256'], 'source '+rec['frozen_copy'])

accepted = opened('Q16_Sparse_Success_Contract_Bridge_Independent_Acceptance_2026-10-13.zip',
                  '4ebd428764c96ec2c233db76604fc47b3705fa3489850ab0b2a468c7a3f17333')
review = accepted.read('q16_success_independent_1633/INDEPENDENT_REVIEW.md')
check(review == candidate.read('evidence/SPARSE_INDEPENDENT_REVIEW.md'), 'accepted sparse report')
bridge_data = accepted.read('q16_success_independent_1633/evidence/Q16_Sparse_Success_Contract_Bridge_Audit_2026-10-13.zip')
check(digest(bridge_data) == '55c074877d47b7c0f8d0d6f5f1394005b650ff29a428b9180e6de34d488d5f6f', 'bridge pin')
bridge = zipfile.ZipFile(io.BytesIO(bridge_data))
for name, frozen in [('buckets.py','buckets.py.txt'), ('pipeline.py','pipeline.py.txt'), ('RECOVERED_EDITION.md','RECOVERED_EDITION.md')]:
    check(bridge.read('q16_success_bridge_audit_20261013/sources/'+name) == candidate.read('evidence/'+frozen), 'historical source '+name)
gap = opened('Q16_Exact_Input_Interface_Gap_Ledger_2026-10-13.zip',
             '1248773169d32ed606b2750843d6cf9992840dde2eb86ca974ed8637003d330e')
check(gap.read('q16_next_gate_1651/MATERIALIZATION_LEMMA.md') == candidate.read('evidence/MATERIALIZATION_LEMMA.md'), 'materialization lemma')
check((ROOT/'evidence/MATERIALIZATION_REVIEW.md').read_bytes() == candidate.read('evidence/MATERIALIZATION_REVIEW.md'), 'materialization review copy')

# Parse only. These trees are not compiled to bytecode or interpreted.
source = ast.parse(candidate.read('src/exact_source.py').decode())
buckets = ast.parse(candidate.read('evidence/buckets.py.txt').decode())
pipeline = ast.parse(candidate.read('evidence/pipeline.py.txt').decode())
functions = {n.name:n for n in source.body if isinstance(n,ast.FunctionDef)}
construct = functions['_construct']
imports = [n for n in ast.walk(source) if isinstance(n,(ast.Import,ast.ImportFrom))]
check(len(imports)==2, 'only two imports')
check([(n.module,[(a.name,a.asname) for a in n.names]) for n in imports] ==
      [('dataclasses',[('dataclass',None)]),('buckets',[('DyadicSource',None)])], 'exact imports')
check(not any(isinstance(n,ast.ClassDef) and n.name=='DyadicSource' for n in source.body), 'no local source class')
check([x.arg for x in functions['materialize_exact'].args.args]==['values','exponent','d'], 'no extra promise inputs')
check(ast.unparse(functions['materialize_exact'].body[-1])=='return _construct(values, exponent, d, False)', 'unrestricted wrapper')
check(ast.unparse(functions['materialize_practical'].body[-1])=='return _construct(values, exponent, d, True)', 'practical wrapper')
scan = next(n for n in construct.body if isinstance(n,ast.For))
zero_branch = next(n for n in construct.body if isinstance(n,ast.If))
check(ast.unparse(scan.iter)=='range(N)' and ast.unparse(zero_branch.test)=='maximum == 0', 'scan then zero')
check(scan.end_lineno < zero_branch.lineno, 'zero only after whole scan')
check(not any(isinstance(n,(ast.Return,ast.Break)) for n in ast.walk(scan)), 'no early zero/partial success')
check(zero_branch.end_lineno < next(n.lineno for n in imports if n.module=='buckets'), 'zero return before import')
check(sum(isinstance(n,ast.AugAssign) and ast.unparse(n.target)=='validated' for n in ast.walk(scan))==2, 'both prefix advances')
for code in ['type(real) is not int','type(imag) is not int','not negative_limit <= real <= limit','not negative_limit <= imag <= limit']:
    check(any(isinstance(n,ast.If) and ast.unparse(n.test)==code for n in ast.walk(scan)), 'scalar guard '+code)

# Exact two defects, tied to candidate line locations.
vulnerable = [n for n in ast.walk(source) if isinstance(n,ast.Compare) and any(isinstance(op,ast.NotIn) for op in n.ops)]
check([(n.lineno,ast.unparse(n)) for n in vulnerable] ==
      [(102,'type(values) not in (tuple, list)'),(138,'type(pair) not in (tuple, list)')], 'two membership-based type gates')
klass=next(n for n in buckets.body if isinstance(n,ast.ClassDef) and n.name=='DyadicSource')
check(ast.unparse(klass.decorator_list[0])=='dataclass(frozen=True)', 'frozen source schema')
check([(n.target.id,ast.unparse(n.annotation),n.value) for n in klass.body if isinstance(n,ast.AnnAssign)] ==
      [('values','tuple',None),('fractional_bits_bound','int',None)], 'two ordered fields')
for tree in [buckets,pipeline]:
    check(any(isinstance(n,ast.Compare) and ast.unparse(n)=='type(source) is not DyadicSource' for n in ast.walk(tree)), 'identity-based consumer gate')
check(any(isinstance(n,ast.ImportFrom) and n.module=='buckets' and any(a.name=='DyadicSource' and a.asname is None for a in n.names) for n in pipeline.body), 'same imported class')
producer_tests = ast.parse(candidate.read('tests/check_constructor.py').decode())
check("sys.modules['buckets'] = fixture" in candidate.read('tests/check_constructor.py').decode(), 'producer installs fresh fixture')
check('spec.loader.exec_module(module)' in candidate.read('tests/check_constructor.py').decode(), 'producer runs constructor with fixture')

# Fresh standalone language witness. No candidate function or extracted code.
protocols=[]
class CounterfeitMeta(type):
    def __eq__(cls, other):
        protocols.append(('metaclass_equality',other.__name__))
        return other is tuple
class ForeignVector(metaclass=CounterfeitMeta):
    def __len__(self):
        protocols.append(('foreign_vector_length',))
        return 1
    def __getitem__(self,key):
        protocols.append(('foreign_vector_index',key))
        return (0,0)
class ForeignCell(metaclass=CounterfeitMeta):
    def __len__(self):
        protocols.append(('foreign_cell_length',))
        return 2
    def __getitem__(self,key):
        protocols.append(('foreign_cell_index',key))
        return 0
class ForeignList(list,metaclass=CounterfeitMeta):
    pass
witnesses=[]
for obj,role in [(ForeignVector(),'outer'),(ForeignCell(),'cell'),(ForeignList([(0,0)]),'list_subclass')]:
    protocols.clear()
    admitted = type(obj) in (tuple,list)
    check(admitted, 'membership flaw reproduced '+role)
    check(type(obj) is not tuple and type(obj) is not list, 'foreign exact type '+role)
    if role=='outer':
        check(len(obj)==1 and obj[0]==(0,0), 'foreign outer can supply zero input')
    elif role=='cell':
        check(len(obj)==2 and obj[0]==0 and obj[1]==0, 'foreign cell can supply zeros')
    observations=list(protocols)
    protocols.clear()
    repaired_rejects = type(obj) is not tuple and type(obj) is not list
    check(repaired_rejects and not protocols, 'identity repair avoids protocols '+role)
    witnesses.append({'role':role,'membership_admitted':admitted,'protocol_calls':observations,'identity_repair_rejects_without_protocols':True})

# Independent arithmetic models: scatter with power doubling, compared to the
# declarative inverse-residue formula. Neither is the candidate implementation.
def model_case(raw,e,d):
    global cases
    cases += 1
    N=len(raw)
    M=1
    while M<4*N: M*=2
    m=M.bit_length()-1
    A=max(map(abs,itertools.chain.from_iterable(raw)))
    check(4*N<=M<8*N and m==(4*N-1).bit_length(), 'padding')
    if not A:
        check(all(a==b==0 for a,b in raw), 'zero exactly')
        return
    unit=1; k=0
    while unit<A: unit*=2; k+=1
    check(k==(A-1).bit_length() and 0<=k<=d*m, 'minimal exponent')
    center=(N-1)//2
    scatter=[(0,0) for _ in range(M)]
    residues=set()
    for j,pair in enumerate(raw):
        residue=(j-center)%M
        check(residue not in residues, 'injectivity')
        residues.add(residue)
        scatter[residue]=tuple(pair)
        check(8*abs(j-center)<=M, 'center support')
    for r in range(M):
        j=(r+center)%M
        expected=tuple(raw[j]) if j<N else (0,0)
        check(scatter[r]==expected, 'scatter equals inverse residue')
    S=sum(a*a+b*b for a,b in raw)
    check(4*S>unit*unit and S<=2*N*unit*unit, 'strict norm and Cartesian upper')
    check(sum(a*a+b*b for a,b in scatter)==S, 'norm preserved')
    factor=Fraction(2**(k-e)) if k>=e else Fraction(1,2**(e-k))
    for a,b in raw:
        check(Fraction(a,unit)*factor==Fraction(a,2**e), 'real symbolic scale')
        check(Fraction(b,unit)*factor==Fraction(b,2**e), 'imaginary symbolic scale')
for N in (1,2,3):
    for flat in itertools.product((-1,0,1),repeat=2*N):
        raw=list(zip(flat[::2],flat[1::2]))
        for e in (0,(4*N-1).bit_length()): model_case(raw,e,1)
for N in (1,2,3,4,7,8,9,16,17,64,65,257):
    m=(4*N-1).bit_length()
    for d in (1,8):
        for a in sorted({1,2,3,2**(d*m)-1,2**(d*m)}):
            for sign in (-1,1):
                raw=[(0,0)]*N; raw[-1]=(0,sign*a)
                model_case(raw,d*m,d)

# Count independent pass inventories algebraically, and check envelopes at
# boundary lengths without claiming any gigantic vector has been allocated.
metadata_cases=0
for m in list(range(2,257))+[512,1024,4096,8192]:
    M=1<<m
    for N in {M//8+1,M//4}:
        for d in (1,8,128):
            metadata_cases += 1
            c=(N-1)//2; H=(d*m+m+16)**2; W=64+(d+16)*(m+1)
            common_E=1+1+N+N+2*N+2*N+2*N+2*N+N+1+1
            nonzero_E=common_E+1+M+M+M+c+M+N+(M-N)+M+M+1+1
            zero_E=common_E+N+N+N+1
            check(nonzero_E==11*N+7*M+c+7 and zero_E==14*N+5,'event formulas')
            nonzero_A=256+N+2*N+M+6*M+M+2
            zero_A=256+N+2*N+N+6*N+N
            nonzero_B=64+1+N+1+3*M+1+1
            zero_B=64+1+N+1+3*N+1
            U=nonzero_E+nonzero_A+nonzero_B+H+256
            Z=zero_E+zero_A+zero_B+H+256
            check(U==15*N+18*M+c+589+H and Z==29*N+584+H,'complete U formulas')
            check(m*m<=8*N and H<=8*(d+9)**2*N,'one-time metadata absorbs')
            check(max(U,Z)<=(750+8*(d+9)**2)*N,'linear growing-word bound')
            check(W<=2*(d+40)*m,'word width bound')
            for V in (U,Z):
                check((64*1024*V*W*W).bit_length()+1<=W,'receipt metadata width')
check((4*65536-1).bit_length()==18 and 8*18==144,'practical caps')
check(not any(name in __import__('sys').modules for name in ['buckets','pipeline','compact_window','exact_source','fresh_exact_source']), 'no scientific/candidate import')
result={'status':'PASS_WITH_REQUIRED_REPAIR_REPRODUCED','assertions':checks,
        'valid_model_cases':cases,'metadata_only_cases':metadata_cases,
        'candidate_execution':False,'historical_execution':False,
        'production_dependency_dynamic_integration':False,
        'candidate_maximum_practical_case_independently_replayed':False,
        'required_repair':{'sites':[102,138],'issue':'Equality-based type membership can admit foreign classes and invoke user protocols','witnesses':witnesses},
        'scope':'Fresh witness, mathematical models, source AST and archive checks; no production conformance run'}
(ROOT/'results/INDEPENDENT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
