"""Independent read-only audit. Historical/candidate code is never imported or run."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import isqrt
from collections import Counter
import csv,hashlib,io,json,re,zipfile,time,os
ROOT=Path(os.environ.get('AUDIT_ROOT','/workspace/scratch/928904ebc9b0'))
OUT=Path(__file__).parent
CAND=ROOT/'breadth_catalogue_first_1751/FIRST_166_BREADTH_AUDIT_2026-10-13.zip'
EXPECTED='2aba99854ac42614fee15cad2a57e9a8d57e0beb4b12bec0e2bd7f0de521c812'
checks=Counter(); details={}; start=time.perf_counter()
def need(ok,group,context=''):
 checks[group]+=1
 if not ok: raise AssertionError((group,context))
def sha(b):return hashlib.sha256(b).hexdigest()
def local(p): return ROOT/p
need(sha(CAND.read_bytes())==EXPECTED,'archive_binding')
z=zipfile.ZipFile(CAND); names=z.namelist()
need(len(names)==len(set(names))==23,'archive_binding')
need(not any(n.startswith('/') or '..' in Path(n).parts for n in names),'archive_binding')
def obj(p):return json.loads(z.read(p))
manifest=obj('MANIFEST.json')
need(set(names)==set(x['path'] for x in manifest['files'])|{'MANIFEST.json'},'archive_binding')
for f in manifest['files']:
 b=z.read(f['path']);need(len(b)==f['bytes'] and sha(b)==f['sha256'],'manifest_file',f['path'])
for n in names:
 need((ROOT/'breadth_catalogue_first_1751'/n).read_bytes()==z.read(n),'candidate_disk_matches_archive',n)
bindings=obj('INPUT_BINDINGS.json')
for k,v in bindings.items():need(sha(local(v['path']).read_bytes())==v['sha256'],'primary_input_hash',k)
for f in obj('SOURCE_ASSESSMENT_BINDINGS.json'):
 b=local(f['path']).read_bytes()
 need(len(b)==f['bytes'] and sha(b)==f['actual_sha256'],'source_rehash',f['path'])
 if 'expected_sha256' in f:need(sha(b)==f['expected_sha256'],'source_inherited_pin',f['path'])
current_acceptance=json.loads(local('later_results_independent_1700/post_application/APPLIED_VERDICT.json').read_bytes())
need(current_acceptance['verdict']=='ACCEPT_EXACT_APPLIED_96_CELL_SYNC' and current_acceptance['final_native_sha256']==bindings['current_native']['sha256'],'current_accepted_table_link')
# Tie the accepted ALG049 review bytes to the sealed prior acceptance archive.
accepted_name='ALG049_Rational_Cycle_Final_Factor_Extension_Independent_Acceptance_2026-10-13.zip'
accepted_bytes=local(accepted_name).read_bytes();seal=json.loads(local(accepted_name+'.seal.json').read_bytes())
need(sha(accepted_bytes)==seal['sha256'] and len(accepted_bytes)==seal['bytes'] and seal['verdict']=='ACCEPT','accepted_source_seal')
az=zipfile.ZipFile(io.BytesIO(accepted_bytes));am=json.loads(az.read('REVIEW_MANIFEST.json'))
need(az.read('INDEPENDENT_REVIEW.txt')==z.read('evidence/ALG049_LATER_ACCEPTED_REVIEW.txt'),'accepted_review_identity')
need(az.read('REVIEW_MANIFEST.json')==z.read('evidence/ALG049_LATER_REVIEW_MANIFEST.json'),'accepted_manifest_identity')
for f in am['files']:
 bb=az.read(f['path']);need(len(bb)==f['bytes'] and sha(bb)==f['sha256'],'accepted_source_manifest',f['path'])
# Decode the frozen lossless JSON DAG directly, not the author's cells/extraction.
packed=json.loads(local(bindings['current_native']['path']).read_bytes());nodes=packed['nodes'];cache={}
need(packed['format']=='lossless-json-dag-v1','native_format')
def decode(i):
 if i not in cache:
  t,v=nodes[i]
  if t==0:cache[i]=v
  elif t==1:cache[i]=[decode(j) for j in v]
  elif t==2:cache[i]={k:decode(j) for k,j in v}
  else:raise AssertionError(('unknown node',t))
 return cache[i]
native=decode(packed['root']); cells={}; raw={}
for rd in native['reads']:
 for sheet in rd['data']['sheets']:
  title=sheet['properties']['title']
  for data in sheet.get('data',[]):
   for r, row in enumerate(data.get('rowData',[]),data.get('startRow',0)+1):
    for c, cell in enumerate(row.get('values',[]),data.get('startColumn',0)+1):
     key=(title,r,c); val=cell.get('userEnteredValue',{})
     if val:
      need(len(val)==1,'native_value_shape',key)
      value=next(iter(val.values()))
      if key in cells:need(cells[key]==value,'native_duplicate_read',key)
      cells[key]=value;raw[key]=cell
     elif cell.get('formattedValue','')!='':
      cells[key]=cell['formattedValue'];raw[key]=cell
ranking=list(csv.DictReader(io.StringIO(local(bindings['ranking_csv']['path']).read_text())))
rank_by={r['record_id']:r for r in ranking};allids=sorted(rank_by)
base=json.loads(local('rank_current_priorities_1539/packet/ALL_331_BASELINE_AND_RECOMMENDATIONS.json').read_bytes())
base_by={x['record_id']:x for x in base}
assignment=obj('ASSIGNMENT.json');ledger=obj('FIRST_166_COVERAGE_LEDGER.json');by={x['record_id']:x for x in ledger}
need(len(ranking)==len(allids)==len(base_by)==331,'partition')
need(allids==sorted(base_by)==assignment['all331_ids_in_lexical_order'],'partition')
need([x['record_id'] for x in ledger]==assignment['owned_ids']==allids[:166],'partition')
need(len(ledger)==len(by)==166 and assignment['first_half_count']==166,'partition')
need(allids[0]=='ACWL-20261012' and allids[165]=='M-EXPANDER-COEFFICIENT' and allids[166]==assignment['other_half_first_id']=='M-F8-EXACT','partition')
need(not(set(by)&set(allids[166:])) and len(set(by)|set(allids[166:]))==331,'partition')
coverage=json.loads(local(bindings['coverage']['path']).read_bytes());covby={rid:r for r in coverage for rid in r['record_ids']}
def colnum(s):
 n=0
 for c in s:n=26*n+ord(c)-64
 return n
def a1(c):
 out=''
 while c:c,i=divmod(c-1,26);out=chr(65+i)+out
 return out
def addr(k):return "'%s'!%s%d"%(k[0],a1(k[2]),k[1])
identities=[];scores=[];statuses=[];source_counts=Counter()
for i,r in enumerate(ledger,1):
 rid=r['record_id'];b=base_by[rid]['baseline'];score=int(rank_by[rid]['baseline_priority'])
 need(r['lexical_position']==i and r['existing_priority_1_to_100']==r['proposed_priority_1_to_100']==b['priority']==score and r['numeric_delta']==0 and int(rank_by[rid]['delta'])==0,'record_score',rid)
 need(r['view_bindings']==b['view_bindings'],'identity_binding_set',rid)
 expected_scores=[]
 for v in b['view_bindings']:
  k=(v['sheet'],v['row'],colnum(v['id_column']));need(cells[k]==rid,'identity_binding',addr(k));identities.append({'record_id':rid,'cell':addr(k),'value':cells[k]})
 for v in b['native_view_fields']:
  k=(v['sheet'],v['row'],v['priority_cell_column_number']);need(cells[k]==score,'score_binding',addr(k));scores.append({'record_id':rid,'cell':addr(k),'value':cells[k]})
  expected_scores.append({'record_id':rid,'cell':addr(k),'expected':score,'actual':score,'pass':True})
 need(r['native_score_bindings']==expected_scores,'ledger_score_binding_set',rid)
 overview=[v for v in b['view_bindings'] if v['sheet']=='Research overview']
 if overview:
  row=overview[0]['row']; st=cells['Research overview',row,5]
  need(r['current_status']==st==b['status']==rank_by[rid]['baseline_status'],'status_binding',rid)
  for field,c in [('current_accepted_scope',14),('current_next_action',16),('current_stop_or_boundary',17)]:
   need(r[field]==cells.get(('Research overview',row,c),''),'current_text_binding',rid+':'+field)
 else:need(r['current_status']=='INTAKE_ALIAS' and rid.startswith('IN-'),'alias_status',rid)
 statuses.append(r['current_status'])
 if rid in covby:
  cov=covby[rid]; source_counts[cov['frozen_readiness']]+=1
  need(r['frozen_readiness']==cov['frozen_readiness'] and r['frozen_source_limits']==cov.get('selection_or_source_limit') and r['frozen_completed_scope']==cov.get('preserve_completed_scope'),'canonical_source_member',rid)
 else:need(r['frozen_readiness']=='OUTSIDE_COHORT','outside_cohort',rid)
need(len(identities)==503 and len(scores)==446,'binding_counts')
need(Counter(statuses)=={'TO RESEARCH':144,'CLOSED':18,'INTAKE_ALIAS':4},'status_counts')
need(source_counts=={'NEEDS_SCOPE_SELECTION':97,'SOURCE_BLOCKED':27,'READY':3},'source_counts')
rowscsv=list(csv.DictReader(io.StringIO(z.read('FIRST_166_COVERAGE_LEDGER.csv').decode())))
need(len(rowscsv)==166,'csv_binding')
for r,c in zip(ledger,rowscsv):
 for k,v in c.items():need(v==('' if r[k] is None else str(r[k])),'csv_cell_binding',r['record_id']+':'+k)
# All proposed preimages from directly decoded frozen native cells.
patch=obj('MINIMAL_TEXT_CORRECTIONS.json');need(patch['base_native_sha256']==bindings['current_native']['sha256'],'patch_base')
need(patch['cell_count']==len(patch['patches'])==14,'patch_count')
need(Counter(p['record_id'] for p in patch['patches'])=={'ALG-049':11,'FUS-11':3},'patch_record_counts')
locations=set(); projected=cells.copy();patch_report=[]
expected={('ALG-049','accepted_scope'):{('Catalogue',83,29),('novelity breakthough',60,23),('Research overview',138,14),('Research overview',138,7)},('ALG-049','next_action'):{('Catalogue',83,31),('novelity breakthough',60,25),('Research overview',138,16),('Research overview',138,3)},('ALG-049','scope_boundary'):{('Catalogue',83,32),('novelity breakthough',60,26),('Research overview',138,17)},('FUS-11','next_action'):{('Research overview',184,3),('Research overview',184,16),('Fusion list',17,6)}}
found={k:set() for k in expected};prefixes={}
for p in patch['patches']:
 m=re.fullmatch(r"'(.+)'!([A-Z]+)(\d+)",p['cell']);need(m is not None,'patch_address')
 k=(m[1],int(m[3]),colnum(m[2]));need(k not in locations,'unique_patch_cell');locations.add(k)
 need(isinstance(cells[k],str) and raw[k].get('userEnteredValue')=={'stringValue':p['old_value']} and cells[k]==p['old_value'],'exact_preimage',p['cell'])
 need(sha(p['old_value'].encode())==p['old_value_utf8_sha256'],'preimage_sha',p['cell'])
 suffix='\n\nEarlier dated history (preserved verbatim):\n'+p['old_value']
 need(p['proposed_value'].endswith(suffix),'history_preservation',p['cell'])
 group=p['record_id'],p['semantic_field'];need(k in expected[group],'semantic_patch_location',p['cell']);found[group].add(k)
 prefix=p['proposed_value'][:-len(suffix)]
 if group in prefixes:need(prefixes[group]==prefix,'duplicate_view_prefix',p['cell'])
 else:prefixes[group]=prefix
 need(p['write_authorized_by_this_packet'] is False,'no_write_authority')
 projected[k]=p['proposed_value'];patch_report.append({'record_id':p['record_id'],'cell':p['cell'],'semantic_field':p['semantic_field'],'old_sha256':sha(p['old_value'].encode()),'new_sha256':sha(p['proposed_value'].encode())})
need(found==expected,'complete_patch_locations')
need({k for k in cells if cells[k]!=projected[k]}==locations,'projected_exact_14_changes')
for k,v in cells.items():
 if k not in locations:need(projected[k]==v,'non_target_preservation')
 if isinstance(v,(int,float,bool)) or raw[k].get('userEnteredValue',{}).get('formulaValue') is not None:need(projected[k]==v,'numeric_formula_preservation')
for rec in scores+identities:
 m=re.fullmatch(r"'(.+)'!([A-Z]+)(\d+)",rec['cell']);k=(m[1],int(m[3]),colnum(m[2]));need(projected[k]==rec['value'],'id_score_projection_preservation')
q=obj('evidence/Q13_ACCEPTED_CURRENT_VIEW.json');need(q['source']==bindings['current_native']['path'] and q['source_sha256']==bindings['current_native']['sha256'],'q13_view_provenance')
for c in q['cells']:need(cells[c['sheet'],c['row'],c['col']]==c['value'],'q13_native_binding')
# Independent exact rational controls, including complex spectra and both error signs.
# This checker models ideal spectral subtrees only. It implements no DIF/numeric backend.
math_counts=Counter(); examples={}
def norm_interval(E,step):
 t=E/step**2;k=isqrt(t.numerator//t.denominator);lo=k*step
 hi=lo if lo*lo==E else lo+step
 need(lo*lo<=E<=hi*hi and hi-lo<=step,'norm_enclosure')
 return lo,hi

def case(y,eps,policy):
 N=len(y);E=sum(a*a+b*b for a,b in y);zero=[(F(0),F(0)) for _ in y]
 if E==0:
  need(len(zero)==N and all(v==(0,0) for v in zero),'zero_output');math_counts['zero_cases']+=1;return
 # Choose a dyadic lower norm bound without irrational arithmetic.
 ell=F(1)
 while ell*ell>E:ell/=2
 while 4*ell*ell<E:ell*=2
 need(ell>0 and ell*ell<=E<=4*ell*ell,'ell_budget')
 theta=eps*ell;delta=theta/4;out=zero;live=Counter();V=0;norm_volume=0;visited=0
 def visit(ids,d):
  nonlocal V,norm_volume,visited
  visited+=1;norm_volume+=len(ids);e=sum(y[i][0]**2+y[i][1]**2 for i in ids)
  lo,hi=norm_interval(e,delta/2)
  a=[lo,hi,(lo+hi)/2,lo-delta/2,hi+delta/2][policy]
  need(a+delta>=0 and (a+delta)**2>=e and (a-delta<=0 or (a-delta)**2<=e),'norm_error_budget')
  if a+delta<=theta:
   need(e<=theta*theta,'pruned_energy_error');return
  live[d]+=1;need(4*e>theta*theta,'live_energy_gap')
  if len(ids)==1:
   k=ids[0];direction=[(F(1),F(0)),(F(-1),F(0)),(F(0),F(1)),(F(3,5),F(4,5)),(F(-3,5),F(-4,5))][policy]
   out[k]=(y[k][0]+delta*direction[0],y[k][1]+delta*direction[1]);return
  V+=len(ids);visit(ids[::2],d+1);visit(ids[1::2],d+1)
 visit(list(range(N)),0)
 error2=max((a-c)**2+(b-d)**2 for (a,b),(c,d) in zip(y,out))
 need(error2<=theta*theta<=eps*eps*E,'global_error')
 for depth,count in live.items():
  need(count<=2**depth and count*theta*theta<4*E and count<=16/(eps*eps),'live_count')
 L=N.bit_length()-1
 need(V<=N*sum(min(F(1),16/(eps*eps*2**d)) for d in range(L)),'split_volume')
 need(norm_volume==N+V and len(out)==N and visited<=2*N-1,'full_work_volume')
 math_counts['nonzero_cases']+=1
alphabet=[(F(0),F(0)),(F(1),F(0)),(F(-1),F(0)),(F(0),F(1)),(F(0),F(-1))]
for N in (1,2,4):
 for y in product(alphabet,repeat=N):
  for eps in (F(1,16),F(1,3),F(3,5),F(9,10)):
   for policy in range(5):case(y,eps,policy)
for N in (8,16,32):
 vectors=[[(F(0),F(0))]*N,[(F(1,2**i),F((-1)**i,3)) for i in range(N)],[(F(1),F(0))]+[(F(0),F(0))]*(N-1),[(F(1,2**30),F(0))]*N,[(F(2**30),F(0))]*N]
 for y in vectors:
  for eps in (F(1,16),F(1,3),F(3,5),F(9,10)):
   for policy in range(5):case(y,eps,policy)
# Exact adversarial guard and mask witnesses, independent of enumeration.
theta=F(1);delta=theta/4
need(F(7,8)<=theta<F(9,8) and abs(F(7,8)-F(9,8))<=delta and F(7,8)+delta>theta,'unsafe_raw_guard_witness')
need(F(1)+delta>theta,'mask_tie_retained_witness')
need(F(3,4)+delta==theta and abs(F(3,4)-1)==delta,'mask_tie_pruned_witness')
# Global source-threshold mask can differ even below the original threshold.
need(F(1)<=F(17,8)<=F(4) and F(3,4)**2 < F(3,4)**2*F(17,8) and F(3,4)+F(3,16)>F(3,4),'mask_relaxation_boundary')
# Exact geometric-sum algebra controls, without adopting numeric backend claims.
for L in range(0,31):
 for ep in (F(1,1024),F(1,8),F(1,2),F(9,10),F(999,1000)):
  q=16/(ep*ep);h=0
  while 2**h<q:h+=1
  total=sum(min(F(1),q/F(2**d)) for d in range(L))
  need(total<=min(F(L),F(h+2)),'geometric_work_bound')
# Confirm the entire archive and primary data remain unchanged after review.
need(sha(CAND.read_bytes())==EXPECTED,'post_review_archive_hash')
for v in bindings.values():need(sha(local(v['path']).read_bytes())==v['sha256'],'post_review_input_hash')
results={'verdict_catalogue':'ACCEPT_EXACT_14_TEXT_CORRECTIONS_AND_166_RECORD_LEDGER','verdict_alg029':'ACCEPT_CONDITIONAL_CONSERVATIVE_PRUNING_LEMMA_ONLY','candidate_sha256':EXPECTED,'baseline_json_sha256':sha(local('rank_current_priorities_1539/packet/ALL_331_BASELINE_AND_RECOMMENDATIONS.json').read_bytes()),'checks':dict(checks),'total_assertions':sum(checks.values()),'partition':{'all':331,'first_half':166,'second_half':165,'first':'ACWL-20261012','last':'M-EXPANDER-COEFFICIENT','next':'M-F8-EXACT'},'identity_bindings':len(identities),'score_bindings':len(scores),'statuses':dict(Counter(statuses)),'frozen_source_counts':dict(source_counts),'patches':patch_report,'exact_contract_case_counts':dict(math_counts),'elapsed_seconds':round(time.perf_counter()-start,6),'historical_candidate_programs_executed':0,'network_calls':0,'external_writes':0,'numeric_backend_certified':False,'required_repairs':[]}
(OUT/'INDEPENDENT_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
(OUT/'INDEPENDENT_BINDINGS.json').write_text(json.dumps({'identities':identities,'scores':scores},indent=2)+'\n')
print(json.dumps(results,indent=2))
