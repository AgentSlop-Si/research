import json,csv,pathlib,hashlib,collections
D=pathlib.Path(__file__).parent
rows=json.load(open(D/'first166_current.json')); cells={(x['sheet'],x['row'],x['col']):x['value'] for x in json.load(open(D/'cells.json'))}
allrows=json.load(open('rank_current_priorities_1539/packet/ALL_331_BASELINE_AND_RECOMMENDATIONS.json'))
coverage=json.load(open('complete_source_coverage_1453/packet/CANONICAL_225_COVERAGE.json')); covby={i:r for r in coverage for i in r['record_ids']}
groups=collections.defaultdict(list)
for r in allrows:
 g=r['baseline'].get('obligation_group')
 if g:groups[g].append(r['record_id'])
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
bindings={'ranking_csv':{'path':'rank_current_priorities_1539/packet/ALL_331_PRIORITY_OVERLAY.csv','sha256':sha('rank_current_priorities_1539/packet/ALL_331_PRIORITY_OVERLAY.csv')},'current_native':{'path':'later_results_independent_1700/post_application/FINAL_NATIVE_PACKED.json','sha256':sha('later_results_independent_1700/post_application/FINAL_NATIVE_PACKED.json'),'read_end_utc':'2026-10-13T17:25:53.226Z'},'coverage':{'path':'complete_source_coverage_1453/packet/CANONICAL_225_COVERAGE.json','sha256':sha('complete_source_coverage_1453/packet/CANONICAL_225_COVERAGE.json')}}
json.dump(bindings,open(D/'INPUT_BINDINGS.json','w'),indent=2)
def a1(n):
 s=''
 while n:n,k=divmod(n-1,26);s=chr(65+k)+s
 return s
def address(s,r,c):return f"'{s}'!{a1(c)}{r}"
completed={'ALG-006':'The fixed-D single-channel primary comparison and guarded field transfer are complete; a new cross-channel comparator is unselected.','ALG-025':'Indexed Reif theorem comparison complete only as a qualified partial result; full-body recovery remains specifically gated.','ALG-026':'Indexed Reif theorem comparison complete only as a qualified partial result; full-body recovery remains specifically gated.','ALG-029':'The selected robust Bringmann comparison is complete; this pass selects only a new conditional numerical-pruning contract.','ALG-034':'The bounded M<=4096 paid source wrapper is accepted and complete; authentic producer, all-size source/zero and downstream integration remain. Active Q16 lane is excluded here.','ALG-049':'Common-phase, two-active-phase and newer rational-final-factor extensions are all complete at exact scope; a distinct successor is not selected.','ALG-068':'The complete small-marker schedule is already Theta(Nn); no cost gain or automatic next sharing mechanism.','M-CRT-TRANSFER':'Exact characteristic-zero N16 minimum112 is complete; do not repeat the dated GF17-to-characteristic-zero gate.','F016':'Q16 fair-tape and sparse-success bridge already accepted; active Q16 lane excluded.','FUS-09':'Same active Q16 dependencies; no second dispatch from this fusion view.','ENGINEERING-NTT-BASELINE-20261012':'Later accepted protocol/pilot supersedes the frozen first-protocol task; active NTT lane excluded.'}
already_applied={'ALG-017','ALG-055','ALG-056','ALG-078'}
ledger=[]; numeric_checks=[]; identity_checks=[]; canonical_readiness_checks=[]
for r in rows:
 rid=r['record_id'];b=r['baseline'];c=r['current_overview'];score=b['priority'];status=b['status'];g=b.get('obligation_group','');sr=r['source'];fr=sr.get('frozen_225_cohort_record');
 for v in b['view_bindings']:
  ic=0
  for ch in v['id_column']:ic=ic*26+ord(ch)-64
  actual=cells.get((v['sheet'],v['row'],ic))
  identity_checks.append({'record_id':rid,'cell':address(v['sheet'],v['row'],ic),'expected':rid,'actual':actual,'pass':actual==rid})
 for v in b.get('native_view_fields',[]):
  pc=v['priority_cell_column_number']; actual=cells.get((v['sheet'],v['row'],pc)); numeric_checks.append({'record_id':rid,'cell':address(v['sheet'],v['row'],pc),'expected':score,'actual':actual,'pass':actual==score})
 if fr:canonical_readiness_checks.append({'record_id':rid,'pass':fr==covby[rid]})
 current_status=c[4] if c else status
 assert not c or c[11]==score
 assert not c or current_status==status
 old=b.get('overview_cells_A_to_Q_verbatim',[]);changed=[a1(i+1) for i,(a,z) in enumerate(zip(old,c)) if a!=z]
 nexttext=str(c[15]) if c else 'Intake alias only; no separate research job.'
 proof=str(c[13]) if c else ''
 source_state='OUTSIDE_ORIGINAL_225; no blanket source-clearance implied'
 if fr:source_state='DATED_'+fr['frozen_readiness']+'; source/body availability not globally retested'
 action='Retain exact current action; select one new scope/source before dispatch when required.'
 if rid in completed:action=completed[rid]
 if rid in already_applied:action='The source-alignment correction is already present in the accepted current table; do not reapply it. '+action
 if status=='CLOSED':action='No dispatch at this closed named scope. Parent/other scopes remain separate.'
 if rid.startswith('IN-'):action='Preserve intake alias and its score1; no separate result/discovery/job.'
 if rid=='FUS-11':action='Correct the rank-one-only current summary to acknowledge bounded rank<=2 and paid root-preparation acceptance; preserve broader general-rank/caller boundaries.'
 if rid=='ALG-029':source_state='SELECTED_OWN_PROOF_AND_IMPLEMENTATION_REHASHED; new sufficient-condition candidate is not independently accepted'
 if rid=='ALG-049':source_state='LATER_ACCEPTED_EXTENSION_REVIEW_AND_ARCHIVE_REHASHED; no new mathematical replay here'
 if rid=='FUS-11':source_state='Current accepted Q13 cross-view evidence inspected; original executor not re-executed or newly certified'
 # Scores are retained rather than synthesized from ordinal qualitative assessments.
 ledger.append({'record_id':rid,'lexical_position':len(ledger)+1,'title':b['title'],'existing_priority_1_to_100':score,'proposed_priority_1_to_100':score,'numeric_delta':0,'current_status':current_status or 'INTAKE_ALIAS','obligation_group':g,'shared_group_record_ids':sorted(groups[g]) if g else [],'view_bindings':b['view_bindings'],'native_score_bindings':[x for x in numeric_checks if x['record_id']==rid],'current_accepted_scope':proof,'current_next_action':nexttext,'current_stop_or_boundary':str(c[16]) if c else 'Alias only; preserve canonical source association.','frozen_readiness':fr['frozen_readiness'] if fr else 'OUTSIDE_COHORT','frozen_source_limits':fr.get('selection_or_source_limit') if fr else None,'frozen_completed_scope':fr.get('preserve_completed_scope') if fr else None,'source_availability_assessment':source_state,'stale_overlay_columns':changed,'action_assessment':action,'duplicate_and_closure_guard':('Shared work group, not a proof-equivalence assertion; one dispatch per selected task; preserve every member score and ID.' if len(groups[g])>1 else 'A separate record does not by itself create a distinct result; preserve exact named scope.') if g else 'Closed named scope or intake alias is preserved without inventing a work group.','qualitative_rubric':{'value':'Existing native rationale retained; no new whole-program value calibration.','evidence_readiness':source_state,'distinctness':action,'bounded_tractability_and_cost':'Only a selected source-bound finite task is eligible. Existing complete-cost and source limits remain; no broad parent treated as a ready experiment.','breadth':'Shared dependencies are linked without multiplying result counts or scores.'},'score_rationale':'Preserve the accepted ordinal work-priority score. Status/source/action reconciliation and a pending local candidate do not supply calibrated accepted evidence for an integer score change. Score is not novelty, significance, correctness or success probability.','audit_depth':{'identity_score_status_action_checked':True,'current_view_text_and_frozen_source_register_read':True,'all_historical_source_bodies_reopened':False,'full_mathematical_proof_audit':False,'new_candidate_assessment':rid=='ALG-029'},'evidence_refs':['INPUT_BINDINGS.json',"later_results_independent_1700/post_application/APPLIED_VERDICT.json"]+(['ALG029_CONDITIONAL_PRUNING_CONTRACT.txt','ALG029_FRESH_CONTROLS.json'] if rid=='ALG-029' else ['MINIMAL_TEXT_CORRECTIONS.json'] if rid in ['ALG-049','FUS-11'] else [])})
assert len(ledger)==166 and len({r['record_id'] for r in ledger})==166
assert all(x['pass'] for x in identity_checks+numeric_checks+canonical_readiness_checks)
json.dump(ledger,open(D/'FIRST_166_COVERAGE_LEDGER.json','w'),ensure_ascii=False,indent=2)
fields=['record_id','lexical_position','title','existing_priority_1_to_100','proposed_priority_1_to_100','numeric_delta','current_status','obligation_group','frozen_readiness','source_availability_assessment','action_assessment','score_rationale']
with open(D/'FIRST_166_COVERAGE_LEDGER.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:r[k] for k in fields} for r in ledger)
checks={'status':'PASS_ID_SCORE_STATUS_SOURCE_REGISTER_RECONCILIATION','first_id':ledger[0]['record_id'],'last_id':ledger[-1]['record_id'],'records':166,'all331_unique_ids':len(set(x['record_id'] for x in allrows)),'identity_bindings_checked':len(identity_checks),'numeric_bindings_checked':len(numeric_checks),'frozen_source_membership_rows_checked':len(canonical_readiness_checks),'status_counts':dict(collections.Counter(r['current_status'] for r in ledger)),'frozen_readiness_counts_by_record_not_group':dict(collections.Counter(r['frozen_readiness'] for r in ledger)),'scores_changed':0,'statuses_changed':0,'source_register_checks':canonical_readiness_checks,'identity_checks':identity_checks,'numeric_checks':numeric_checks,'historical_scientific_programs_executed':0,'sheet_writes':0,'github_writes':0,'proof_audit_of_166':False}
json.dump(checks,open(D/'VALIDATION.json','w'),ensure_ascii=False,indent=2)
print({k:v for k,v in checks.items() if not isinstance(v,list)})
