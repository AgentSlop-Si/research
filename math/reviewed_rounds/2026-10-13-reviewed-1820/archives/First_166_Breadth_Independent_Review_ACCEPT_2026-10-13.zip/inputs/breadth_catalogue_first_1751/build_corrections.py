import json,hashlib,pathlib
D=pathlib.Path(__file__).parent
cs=json.load(open(D/'cells.json')); cells={(x['sheet'],x['row'],x['col']):x['value'] for x in cs}
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def col(i):
 s=''
 while i:i,k=divmod(i-1,26);s=chr(65+k)+s
 return s
sources=[]
for r in json.load(open('alg029_robust_comparison_1242/SOURCE_INTEGRITY.json')):
 p='alg029_robust_comparison_1242/'+r['path'];h=sha(p);assert h==r['sha256'];sources.append({'purpose':'ALG029 original ideal DIF/numerical boundary','path':p,'bytes':pathlib.Path(p).stat().st_size,'expected_sha256':r['sha256'],'actual_sha256':h,'matches':True})
for p in ['alg029_independent_review_1250/REVIEW.txt','alg049_rational_cycle_independent_review_1648/INDEPENDENT_REVIEW.txt','alg049_rational_cycle_independent_review_1648/REVIEW_MANIFEST.json','ALG049_Rational_Cycle_Final_Factor_Extension_Independent_Acceptance_2026-10-13.zip','ALG049_Rational_Cycle_Final_Factor_Extension_Independent_Acceptance_2026-10-13.zip.seal.json']:
 sources.append({'path':p,'bytes':pathlib.Path(p).stat().st_size,'actual_sha256':sha(p),'inspection':'Read inert review/binding text or safely hashed archive; no historical scientific code executed.'})
json.dump(sources,open(D/'SOURCE_ASSESSMENT_BINDINGS.json','w'),indent=2)
proof='[2026-10-13; later independent ALG049 rational-final-factor acceptance]\nFor the exact pinned N=8 two-factor prefix, all four sign pairs and every unit phase z, no invertible final factor C with constant diagonal of (C^-1)* C^-1 can yield a nonzero scalar-unitary product, even with a unitary monomial separator at the LAST boundary. Every spectrally regular, invertible rational function of a uniform-modulus weighted Hamiltonian cycle satisfies that final-factor hypothesis. The first boundary and prefix remain fixed; unrestricted ALG049 remains open.'
nextaction='[2026-10-13; later independent ALG049 rational-final-factor acceptance]\nThe common-phase, two-active-phase and rational-final-factor extensions are complete. Select a genuinely new prefix, first-boundary model, nonconstant inverse-Gram-diagonal final factor or longer-word scope before another experiment. Merely changing the final uniform-modulus cycle, its phases or its spectrally regular invertible rational function is already covered, including a last-boundary unitary monomial. No successor is selected here; preserve parent priority42.'
stop='[2026-10-13; later independent ALG049 rational-final-factor acceptance]\nThe obstruction is for the displayed N=8 prefix. The cycle lemma is all-dimensional, not the prefix obstruction. Arbitrary unitary separators at the LAST boundary have a recorded counterexample; they are not included. Uniform edge modulus, spectral no-pole/no-zero guards and the original coordinate-basis inverse Gram matter. Quantitative bounds depend on ||C^-1||^2 and are not uniform over rescaling or ill-conditioned families. No general Fourier/FFT, runtime or novelty claim.'
fus='[2026-10-13; accepted Q13 bounded rank-two/preparation cross-view alignment]\nThe supplied-root unified recognition/rejection theorem, D06 provenance and earlier bounded references remain accepted. Related Q13/STR-Q2 also has accepted bounded unknown-phase rank<=2 full-output execution and optional deterministic paid primitive-root preparation for exact resident inputs: 3<=N<=512, prime5<=p<=65537, N|(p-1). All root candidates, validation, failed work and atomic outputs are charged; LIMIT withholds mathematical results. These bounded stages need no first review. Beyond this accepted domain, general-rank/min(B,H), actual caller integration with returned-root order and full budget, optimized blocked/Toeplitz kernels, numerical/bit/production costs and matched comparisons remain open. Q14 retains its distinct interface and prerequisite boundaries; this is no closure of the entire FUS-11 parent.'
patches=[]
def add(rid,kind,text,locs):
 for s,r,c in locs:
  old=cells[(s,r,c)];assert isinstance(old,str)
  new=text+'\n\nEarlier dated history (preserved verbatim):\n'+old
  patches.append({'record_id':rid,'semantic_field':kind,'cell':f"'{s}'!{col(c)}{r}",'old_value':old,'old_value_utf8_sha256':hashlib.sha256(old.encode()).hexdigest(),'proposed_value':new,'write_authorized_by_this_packet':False})
add('ALG-049','accepted_scope',proof,[('Catalogue',83,29),('novelity breakthough',60,23),('Research overview',138,14),('Research overview',138,7)])
add('ALG-049','next_action',nextaction,[('Catalogue',83,31),('novelity breakthough',60,25),('Research overview',138,16),('Research overview',138,3)])
add('ALG-049','scope_boundary',stop,[('Catalogue',83,32),('novelity breakthough',60,26),('Research overview',138,17)])
add('FUS-11','next_action',fus,[('Research overview',184,3),('Research overview',184,16),('Fusion list',17,6)])
obj={'status':'READ_ONLY_MINIMAL_TEXT_PROPOSAL_REQUIRES_PARENT_RECONCILIATION','base_native_sha256':sha('later_results_independent_1700/post_application/FINAL_NATIVE_PACKED.json'),'cell_count':len(patches),'stable_ids':['ALG-049','FUS-11'],'scores_statuses_ranks_ids_formulas_changed':False,'history_preserved':True,'scope':'Two source/status alignment updates only. ALG029 new candidate is intentionally NOT proposed as an accepted table result. Recheck live exact preimages before any authorized later execution.','patches':patches}
json.dump(obj,open(D/'MINIMAL_TEXT_CORRECTIONS.json','w'),indent=2,ensure_ascii=False)
print('corrections',len(patches),'source bindings',len(sources))
