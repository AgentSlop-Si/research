# Energy-pruned Fourier graph: a precise approximation result

This continuation constructs a deterministic, adaptive, full-output Fourier
approximation. For N a power of two, write U=F_N/sqrt(N), using the negative
exponent convention. Given a fresh arbitrary complex vector x and 0<epsilon<1,
the ideal algorithm returns all N entries of

    yhat[k] = (Ux)[k] if |(Ux)[k]| > epsilon ||x||_2, and 0 otherwise.

Consequently ||yhat-Ux||_infinity <= epsilon ||x||_2. Its total work is

    O(N [1+min(log N, log(epsilon^-2))]),

including coefficient preparation, input/norm scans, adaptive decisions,
addressing and every output. Its workspace is O(N). For fixed positive epsilon,
this is deterministic O(N) ideal arithmetic work. No previous-input cache,
frequency support oracle, randomized sampling, or uncharged transform is used.
See `PROOF.md` for the model and all-size proof.

This does **not** compute an exact arbitrary-input FFT below N log N. The error
is measured against the global input norm, not against the magnitude of each
bin. A diffuse spectrum may validly be replaced entirely by zero. The exact
epsilon=0 route retains an ordinary FFT. The complex128 implementation is not
a certified floating-point realization of the theorem and is slower than
NumPy in every recorded timing case. No mathematical priority claim is made.

## Relation to the supplied surrogate packages

Both packages use a normalized Fourier transform. Their guarantees must be
compared at the same scale. Put tau=||x||_1/(sqrt(N)||x||_2), for x nonzero.

| Contract or input family | Energy-pruned graph | Supplied time-domain surrogate |
|---|---|---|
| Error <= epsilon ||x||_2, fixed epsilon | Deterministic O(N) | Stated randomized O(N log log N) general bound |
| Error <= epsilon ||x||_1/sqrt(N) | Set epsilon_E=epsilon tau; O(N[1+min(log N,log(epsilon^-2 tau^-2))]) | Stated randomized O(N log log N), fixed epsilon and polynomially small failure probability |
| Constant-modulus input, fixed epsilon | tau=1, hence O(N) for either scale | General support/sampling theorem remains valid |
| Impulse, stricter l1 scale, epsilon<1 | All Fourier bins survive; full DIF tree | Exact sparse-input route is O(N) |
| Exact arbitrary fresh input | No sub-N-log-N result | No sub-N-log-N result |

Thus there is no uniform same-contract domination of v2. Its support barrier
is also consistent with this construction: it constrains sparse **time-domain**
surrogates. Here the output spectrum is sparse, while its inverse can be dense.
For x=(1,...,1), the graph finds the one nonzero Fourier coefficient in linear
work, and its exact time-domain preimage still has support N.

For epsilon=(log N)^(-a), fixed a>0, the energy method costs O(N log log N).
For epsilon=exp(-(log N)^gamma), 0<gamma<1, it costs O(N(log N)^gamma).
Polynomially small epsilon only gives O(N log N) from this bound. These are
accuracy-multiplier statements; absolute error need not vanish unless the
input norm is also controlled.

## Verification and measured limitations

`python3 exact_small_audit.py` uses exact Gaussian rational arithmetic and
passes 3,331 cases for N=1,2,4, including positive threshold ties at roots,
internal nodes and leaves. It verifies 12,959 output coordinates, exact
hard thresholding, subtree energies and work-volume inequalities. These are
finite implementation certificates; the all-size theorem has a separate proof.

`python3 run_audit.py` requires NumPy. It records 4,085 direct-DFT comparisons
(including 655 exhaustive input vectors), 232 adversarial cases, 12 extreme
scaling cases and five invalid-input controls. These numerical tests allow
rounding and test threshold masks outside the rounding band.

`results/benchmark.json` records 36 cold timing comparisons, with preparation
and full output included: zero wins against NumPy. The prototype is about
1.25 to 58.63 times slower. For a length-262,144 tone it visits about 11.1% of
the full butterfly work, but is still about 2.2 to 2.6 times slower. Fewer
butterflies are not a measured runtime win. `IMPLEMENTATION.md` describes the
logical counters, memory accounting, scaling precautions and numerical limits.

## Prior art and research status

Classical FFT pruning already reduces work when output or input sparsity is
known; adaptive traversal of FFT computation trees is also established.
Relevant primary sources consulted for this continuation:

- FFTW, [Pruned FFTs](https://fftw.org/pruned.html): O(N log K) pruning and practical overhead caveats.
- Bringmann et al., [Traversing the FFT Computation Tree for Dimension-Independent Sparse Fourier Transforms](https://arxiv.org/abs/2107.07347): related adaptive-tree work with different recovery guarantees.
- Alon, [Perturbed identity matrices have high rank](https://web.math.princeton.edu/~nalon/PDFS/identity1.pdf): the rank theorem behind v2's representation-specific barrier.

The contribution here is a proved, implemented and checked route within this
research project, with an explicit error contract and complete cost accounting.
The literature check is not an exhaustive novelty search. The unresolved exact
goal and the stronger v2 error scale must remain separate from this result.
