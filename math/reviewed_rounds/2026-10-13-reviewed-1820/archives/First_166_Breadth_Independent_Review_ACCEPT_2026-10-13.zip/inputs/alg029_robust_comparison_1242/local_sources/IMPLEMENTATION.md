# Deterministic energy-pruned DIF prototype

`energy_pruned_fft(x, epsilon)` returns a full length-N vector and detailed
logical operation/traffic counters. The transform convention is
`numpy.fft.fft(x, norm='ortho')`. The length must be a positive power of two;
inputs and the nonnegative tolerance must be finite.

This implementation accompanies an **ideal-arithmetic approximation theorem**.
It is a complex128 numerical prototype, not an exact FFT implementation or a
certified floating-point error bound. Its numerical tests include a stated
rounding allowance. No mathematical priority or practical speedup is asserted.

## The actual recursive graph

Each live node contains m values of a unitary, partially evaluated DIF FFT. Its
two children are formed by

    even[j] = (v[j]+v[j+m/2])/sqrt(2),
    odd[j]  = (v[j]-v[j+m/2])*exp(-2*pi*i*j/m)/sqrt(2).

The children are the even and odd frequency branches. Their squared Euclidean
norms sum to the parent's squared norm in ideal arithmetic. A node at depth d
owns one residue class `offset mod stride`, with stride=2^d. Its final output
positions are disjoint from every other live node's positions.

The algorithm initializes the entire N-entry output to zero. If a node's norm
is at most `epsilon*input_norm`, it leaves that residue class zero and stops
descending. Every actual leaf is also tested. Otherwise, its single coefficient
is written at its correct frequency index. No ordinary FFT is called in this
positive-tolerance route; the graph uses the explicit DIF butterflies above.

In ideal arithmetic this produces exactly the hard-thresholded unitary Fourier
vector: coefficients of magnitude greater than `epsilon*||x||_2` are retained
exactly, and coefficients at or below that threshold are zero. This follows
because a leaf magnitude cannot exceed any ancestor's norm. Thus pruning an
ancestor cannot remove a coefficient above the threshold.

The positive-tolerance promise is global-norm-scaled, not relative accuracy in
each bin. For a long diffuse spectrum, the promised tolerance can exceed every
coefficient and the valid answer can be the all-zero vector. This substantially
weaker problem must remain separate from an exact fresh-input FFT.

## Preparation, norms and complete output costs

The prototype scans the input for finite values and for its largest absolute
real or imaginary component. It scales those components separately into a safe
range. Every node norm is also computed with a local component scale, so the
norm routine does not directly square extremely large or tiny components.
The returned vector is rescaled at the end. This avoids avoidable norm overflow
and underflow; it does not eliminate floating-point rounding or certify every
pruning decision.

If a mathematically necessary output cannot be represented finitely in
complex128, the rescaling stage raises `OverflowError` instead of quietly
returning infinities. Nonfinite input values and invalid lengths/tolerances are
rejected. For epsilon=0 the implementation explicitly calls a full ordinary
FFT on the scaled input. Epsilon>=1 can return the complete zero vector.

All N/2 complex twiddle values are prepared lazily at the first split in O(N)
numerical work. A node reads a strided view of that root table. In an exact
arithmetic theorem with a supplied primitive root, the analogous preparation
is one root-power chain. The numerical code evaluates exponentials and does
not claim that machine values are exact roots.

Let V be the sum of lengths of split nodes. The implementation records:

- V/2 DIF butterflies, V complex additions/subtractions, V/2 complex
  multiplications and V real scalings of complex values;
- norm **value volume** exactly N+V for a nonzero input and 0<epsilon<1;
- every local norm's scaling scans, temporary writes, real divisions,
  multiplications, sums, square roots and comparisons;
- input validation/scaling, root preparation, stack/index work and coefficient
  reads;
- N initial output-zero writes, every retained-coefficient write, and N
  rescaling writes for the main route.

Norm value volume counts the number of vector entries processed by norm calls,
not literal memory reads. The latter require several constant-size passes and
are exposed by separate component-read counters. Array counters are logical
NumPy operations, not CPU cache traffic or Python bytecode counts. List/array
allocation and scalar bookkeeping have the same stated asymptotic bounds.

The depth-first traversal, pending siblings, current work arrays, root table and
complete output occupy O(N) storage. Optional tracing adds at most O(N) node
records; it is disabled in benchmarks. No cache of previous input values or
answers is assumed.

At depth d there are at most min(2^d,epsilon^-2) nodes above threshold in ideal
arithmetic. Therefore

    V <= N * sum_(d=0)^(log2(N)-1) min(1,epsilon^-2 / 2^d).

The norm scans, branch tests, root table, indexing and full output writes do not
add a logarithmic factor. For fixed positive epsilon this bound is O(N); for
0<epsilon<1 it is O(N*(1+min(log N,log(1/epsilon)))). The authoritative
theorem and novelty discussion belong in the root research write-up.

## Validation

Run `python3 run_audit.py`. The final audit passes:

- all 655 vectors over the alphabet {0,1,-1,i,-i} at N=1,2,4;
- 4,085 direct-DFT comparisons, including full real/imaginary basis vectors
  through N=64 and complex random vectors;
- 232 adversarial cases through N=4,096: zero, impulse, constant, alternating,
  pure tone, Gaussian, near-constant, and equal-amplitude many-tone inputs on
  either side of the threshold support count;
- 12 scaling cases with magnitudes from 1e-300 through 1e300;
- five invalid-input controls.

The checks validate the global error promise with an explicit rounding band,
the exact hard-threshold mask away from that band, full output length, correct
frequency indexing, the observed split-work bound, and `norm_value_volume=N+V`.
They do not prove certified floating-point correctness. The all-size error and
work statements instead follow from the ideal unitary graph and energy proof.

## Timing experiment

Run `python3 benchmark.py`. It compares three cold calls, using their median,
with the median of three ordinary NumPy FFT calls. Each approximate timed call
includes finite checks, scaling, all roots, all norms, graph execution and the
complete output. Test families are complex Gaussian data, a pure tone, and
15 equal-amplitude tones; N=4,096 through 262,144 and epsilon=.125,.25,.5.

The recorded results are in `results/benchmark.json`. The Python/NumPy prototype
has not established a wall-clock win: it introduces norm passes, many small
allocations, and Python tree traversal absent from a tuned native FFT. Reduced
butterfly counts must not be presented as measured speedup. This benchmark is
an implementation limitation alongside the separate arithmetic work theorem.
