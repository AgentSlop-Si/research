"""Fresh correctness oracle for paid-ntt-v2-20261013; never a timing contender.

No recovered implementation, generator, tables, or permutations are imported.
Default execution is deliberately bounded to n <= 256. Widening that budget
is a later evaluation; legality of larger lengths is not tested correctness.
"""
from __future__ import annotations

import struct

P = 998244353
G = 3
MAX_LEGAL_N = 1 << 23
TINY_MAX_N = 256
PROTOCOL_ID = "paid-ntt-v2-20261013"


class OracleScopeError(ValueError):
    pass


def checked_length(n: int, p: int = P, g: int = G) -> int:
    if type(p) is not int or p != P or type(g) is not int or g != G:
        raise ValueError("fixed modulus 998244353 and generator 3 required")
    if type(n) is not int or n < 2 or n > MAX_LEGAL_N or n & (n - 1):
        raise ValueError("length must be an integer power of two in [2, 2^23]")
    if (p - 1) % n:
        raise ValueError("length does not divide p-1")
    return n


def checked_root(n: int, p: int = P, g: int = G) -> int:
    checked_length(n, p, g)
    omega = pow(g, (p - 1) // n, p)
    validate_root(n, omega)
    return omega


def validate_root(n: int, omega: int):
    """Reject an invalid root or a different primitive root/sign convention."""
    checked_length(n)
    p = P
    if type(omega) is not int or not 0 <= omega < p:
        raise ValueError("root must be a canonical integer residue")
    if pow(omega, n, p) != 1 or pow(omega, n // 2, p) == 1:
        raise ValueError("root does not have exact order n")
    if n >= 4 and pow(pow(omega, n // 4, p), 2, p) != p - 1:
        raise ValueError("quarter root does not square to -1")
    if omega != pow(G, (P - 1) // n, P):
        raise ValueError("root has wrong pinned primitive-root/sign convention")


def checked_values(values, n: int) -> tuple[int, ...]:
    # Materialize only an already bounded list/tuple; do not silently consume
    # arbitrary iterators or normalize malformed coefficients modulo p.
    if not isinstance(values, (list, tuple)) or len(values) != n:
        raise ValueError("exactly n list/tuple coefficients required")
    if any(type(v) is not int or not 0 <= v < P for v in values):
        raise ValueError("coefficients must be canonical integer residues")
    return tuple(values)


def checked_request(values, n=None, *, max_n=TINY_MAX_N):
    if n is None:
        if not isinstance(values, (list, tuple)):
            raise ValueError("bounded list/tuple input required")
        n = len(values)
    checked_length(n)
    checked_length(max_n)
    if n > max_n:
        raise OracleScopeError("length exceeds this invocation's explicit oracle budget")
    return checked_values(values, n)


def forward_direct(values, n=None) -> list[int]:
    """Definition: F_+(x)[k] = sum_j x[j] omega^(jk), no normalization.

    Independent pow per summand and arbitrary-precision integer accumulation.
    The direct-definition oracle is intentionally limited to n <= 256.
    """
    x = checked_request(values, n)
    n = len(x)
    omega = checked_root(n)
    return [sum(x[j] * pow(omega, j * k, P) for j in range(n)) % P
            for k in range(n)]


def forward_reference(values, n=None, *, max_n=TINY_MAX_N) -> list[int]:
    """Independent recursive even/odd radix-2 reference in natural order.

    Derive a local stage root directly from G at each recursion length. There
    is no imported Plan, global root table, bit-reversal map, or in-place DIF.
    Internal length-one leaves do not extend the public n>=2 domain.
    """
    x = checked_request(values, n, max_n=max_n)
    checked_root(len(x))

    def evaluate(a):
        m = len(a)
        if m == 1:
            return [a[0]]
        evens = evaluate(a[::2])
        odds = evaluate(a[1::2])
        local_root = pow(G, (P - 1) // m, P)
        half = m // 2
        products = [(odds[k] * pow(local_root, k, P)) % P for k in range(half)]
        return ([(evens[k] + products[k]) % P for k in range(half)] +
                [(evens[k] - products[k]) % P for k in range(half)])

    return evaluate(x)


def inverse_direct(values, n=None) -> list[int]:
    """Independent inverse by Horner evaluation at omega^(-j), divided by n.

    Does not call either forward transform or reverse their input/output.
    """
    y = checked_request(values, n)
    n = len(y)
    inverse_root = pow(checked_root(n), P - 2, P)
    inverse_n = pow(n, P - 2, P)
    out = []
    for j in range(n):
        z = pow(inverse_root, j, P)
        value = 0
        for coefficient in reversed(y):
            value = (value * z + coefficient) % P
        out.append(value * inverse_n % P)
    return out


def pack_residues(values) -> bytes:
    checked_values(values, len(values))
    return b"".join(struct.pack("<I", value) for value in values)


def unpack_residues(data: bytes, n: int) -> list[int]:
    checked_length(n)
    if type(data) is not bytes or len(data) != 4 * n:
        raise ValueError("wire bytes must contain exactly n little-endian uint32 words")
    values = list(struct.unpack("<" + "I" * n, data))
    checked_values(values, n)
    return values


def exact_compare(actual, expected, *, context=""):
    """Check length, canonical range and every coordinate; never hash-only."""
    if not isinstance(actual, (list, tuple)) or len(actual) != len(expected):
        raise AssertionError(f"{context}: output length mismatch")
    checked_values(expected, len(expected))
    for k, (got, want) in enumerate(zip(actual, expected)):
        if type(got) is not int or not 0 <= got < P:
            raise AssertionError(f"{context}: noncanonical output at {k}: {got!r}")
        if got != want:
            raise AssertionError(f"{context}: coordinate {k}: expected {want}, actual {got}")


def check_transform_invariants(x, y):
    x = checked_request(x)
    y = checked_values(y, len(x))
    n = len(x)
    if y[0] != sum(x) % P:
        raise AssertionError("DC identity failed")
    if sum(y) % P != n * x[0] % P:
        raise AssertionError("sum-output identity failed")
    exact_compare(inverse_direct(y), x, context="inverse identity")


def linear_schoolbook(a, b) -> list[int]:
    """Product in F_p[z], length len(a)+len(b)-1; not integer recovery."""
    if not a or not b or len(a) + len(b) - 1 > TINY_MAX_N:
        raise OracleScopeError("nonempty, tiny polynomial factors required")
    aa, bb = checked_values(a, len(a)), checked_values(b, len(b))
    out = [0] * (len(aa) + len(bb) - 1)
    for i, av in enumerate(aa):
        for j, bv in enumerate(bb):
            out[i + j] = (out[i + j] + av * bv) % P
    return out


def cyclic_schoolbook(a, b, n: int) -> list[int]:
    """Product modulo z^n-1 over F_p; wraparound is intentional."""
    aa, bb = checked_request(a, n), checked_request(b, n)
    out = [0] * n
    for i, av in enumerate(aa):
        for j, bv in enumerate(bb):
            out[(i + j) % n] = (out[(i + j) % n] + av * bv) % P
    return out


def cyclic_transform_product(a, b, n: int) -> list[int]:
    aa, bb = checked_request(a, n), checked_request(b, n)
    ya, yb = forward_reference(aa), forward_reference(bb)
    return inverse_direct([u * v % P for u, v in zip(ya, yb)])


def linear_transform_product(a, b, n: int) -> list[int]:
    """Return all L coefficients after an explicitly legal zero-padded NTT.

    Reject n < L instead of silently returning cyclicly aliased coefficients.
    Also verify every padded tail coordinate is zero before trimming.
    """
    checked_length(n)
    if n > TINY_MAX_N:
        raise OracleScopeError("tiny convolution demonstration only")
    aa, bb = checked_values(a, len(a)), checked_values(b, len(b))
    if not aa or not bb:
        raise ValueError("nonempty polynomial factors required")
    length = len(aa) + len(bb) - 1
    if n < length:
        raise ValueError("linear convolution requires n >= len(a)+len(b)-1")
    out = cyclic_transform_product(list(aa) + [0] * (n - len(aa)),
                                   list(bb) + [0] * (n - len(bb)), n)
    if any(out[length:]):
        raise AssertionError("nonzero linear-product padding tail")
    return out[:length]


def independent_constant_certificate():
    """Fresh exact constant proof; no transform buffers for large lengths."""
    divisor = 2
    while divisor * divisor <= P:
        if P % divisor == 0:
            raise AssertionError("modulus is composite")
        divisor += 1
    if P - 1 != (1 << 23) * 7 * 17:
        raise AssertionError("factorization mismatch")
    generator_tests = {str(q): pow(G, (P - 1) // q, P) for q in (2, 7, 17)}
    if any(value == 1 for value in generator_tests.values()):
        raise AssertionError("generator does not have full order")
    roots = [{"n": 1 << exponent, "omega": checked_root(1 << exponent)}
             for exponent in range(1, 24)]
    return {"p": P, "g": G, "prime_by_trial_division": True,
            "factorization": {"2": 23, "7": 1, "17": 1},
            "generator_tests": generator_tests, "roots": roots,
            "large_length_transform_execution": False}
