# Paid NTT candidate oracle and implementation gap report

Date: 2026-10-13. Protocol: paid-ntt-v2-20261013.

## Decision

CANDIDATE_ORACLE_TINY_SELF_VALIDATION_PASS; BENCHMARK_NOT_READY.

The exact reference is now authored, source-bound, and self-validated on the complete small portion of the frozen corpus. This is not independent acceptance of the candidate oracle, correctness acceptance of any recovered schedule, the full preflight gate, an implemented paid adapter, authorization to run inherited code, or performance evidence. The accepted v2 protocol is unchanged. No recovered C++ or generator was imported, compiled, or executed. No timings were collected. No Sheet/GitHub writes occurred.

## What is established

- All 16 accepted v2 manifest entries match their byte lengths and SHA-256; both pinned historical CPP/CSV files match. The design-only acceptance receipt's three pins also match.
- Every one of the 288 frozen input vectors was checked for contiguous extent, case/length ordering, exact hash, decoding, and canonical coefficient range. That is a data audit, not 288-transform correctness coverage.
- At all eight powers of two from 2 through 256, all 16 frozen cases agree coordinate-for-coordinate between the fresh direct-definition oracle and fresh recursive radix-2 reference: 128 vectors and 8,160 coefficients. The direct result supplies the stored expected output.
- All tiny cases pass an independently implemented inverse, DC and sum identities, F_+ squared, applicable zero/constant/impulse/alternating formulas, and complete input-byte immutability checks.
- There are three literal output anchors, 90 exhaustive vectors over {0,1,p-1} at n=2 and n=4, linearity and exact schoolbook cyclic-product checks at n=2,4,8,16,32, and four linear-product examples.
- All 44 negative/corruption controls are detected. Controls include a wrong primitive root with the correct order but opposite sign convention; truncation; extra/noncanonical coordinates; wrong normalization/permutation; and two-coordinate corruption preserving both DC and the output sum. The last control demonstrates why those invariants cannot replace all-coordinate comparison.
- Fresh trial division verifies the modulus is prime, fresh factor-order checks establish the primitive generator, and fresh modular checks agree with every pinned root through n=2^23. No large transform is executed by these constant checks.

The files TEST_REPORT.json, CORRUPTION_CONTROLS.json, CONSTANT_CERTIFICATE.json and BINDING_CHECKS.json record the checks without timings.

## Exact mathematics and oracle independence

The public transform domain is fixed p=998244353, g=3, n=2^e for integer 1<=e<=23. The tested transform domain in this delivery is only 1<=e<=8. A supplied coefficient vector must have exactly n canonical integer residues in [0,p-1]; bad inputs are rejected rather than reduced. Booleans, floats, strings, wrong sizes, and invalid lengths are rejected by the new oracle. The execution-budget guard is distinct from mathematical legality: n=512 is legal but rejected by this invocation's default n<=256 budget.

Let omega=g^((p-1)/n) mod p. The output is exactly n canonical residues in increasing natural frequency order:

    y[k] = sum(j=0..n-1) x[j] * omega^(j*k) mod p.

There is no forward normalization. A different exact-order root is insufficient: the root must equal this pinned omega. Its inverse would change the transform convention.

forward_direct evaluates that definition with an independent modular exponentiation per summand and arbitrary-precision integer accumulation. It uses no inherited transform, tables, recurrence, index map, or arithmetic helper.

forward_reference separates even and odd coefficient subsequences recursively, evaluates each at length n/2, and combines E[k]+omega^k O[k] and E[k]-omega^k O[k]. Because omega^2 is the stage root and omega^(n/2)=-1, those are exactly output coordinates k and k+n/2. It derives each recursion-length root from g; it does not share the source's iterative bit reversal, global tables, in-place DIF or mixed-radix layout. Internal length-one leaves do not admit public n=1 requests. The two fresh references share only the fixed mathematical constants, validation and serialization, not the source implementation. Agreement remains empirical self-validation rather than an independently reviewed proof of code correctness.

inverse_direct is a separately implemented Horner polynomial evaluation at omega^(-j), multiplied by n^(-1). It calls neither forward function and does not implement inversion by reversing their inputs. Root orthogonality makes the inverse exact. Python integers avoid machine-width assumptions; this does not replace the future C++ type-width, overflow, allocation and sanitizer gates.

## Linear versus cyclic semantics

The n-point product theorem is cyclic convolution in F_p[z]/(z^n-1), not an unpadded linear product. The separate schoolbook oracle checks every coordinate of that cyclic result.

A linear product in F_p[z] has L=len(a)+len(b)-1 coefficients. The demonstration requires a legal power-of-two transform length n>=L, zero-pads both factors, checks every padded tail coordinate is zero after inverse transformation, and returns all L coefficients. It rejects n<L rather than silently accepting wraparound. Empty factors are not admitted by these demonstration functions.

Concrete exact control: [1,2,3] times [4,5,6] has linear coefficients [4,13,28,27,18]. An n=4 cyclic product is [22,13,28,27], because the final 18 wraps into index 0. Linear n=4 is rejected; linear n=8 returns the full five correct coefficients and has three zero tail entries. These are finite-field semantics only. No integer-convolution reconstruction, coefficient-bound guarantee, CRT, Bluestein support, arbitrary-length support or FFT novelty follows.

## Stored outputs and missing coverage

TINY_EXPECTED_MANIFEST.json binds exact_oracle.py and test_exact_oracle.py hashes, the frozen input-corpus hash, every tiny input hash, every output offset/length/hash, and the full tiny output file. tiny_expected_outputs.bin contains 32,640 bytes in little-endian uint32 format with the original frozen case order. It contains no header. The format and full-coordinate checker reject missing, extra or noncanonical outputs; hashes are provenance tools and never replace comparing all values.

This is deliberately not the required complete expected-output artifact. The remaining 160 frozen vectors at n=512 through 262144 have no expected outputs in this delivery. None of the four inherited schedules has been compared, even at n=2. No claim is made for tested n>256, and mathematical support up to 2^23 does not establish resource feasibility or tested coverage there. Before the pilot, the complete 288-vector output artifact and exact release/diagnostic binary gates are still mandatory.

## Source defects and incompatibilities established by text

All line references below refer to the immutable 400-line fft_engine.cpp, SHA-256 0bd324e62b302e4b2e6405c953cb513a93b8840b74137755bd7388b86cddafa7. The following witnesses are reasoning from source text; none was executed.

### S1: Missing request-size validation can access out of bounds

bitrev_copy and unbitrev_copy read x[i] for i=0..n-1 at lines 44-52 without checking x.size(). radix2 and fused_radix4 call the former at 55-56 and 71-72. Thus a Plan(4) request with only two coefficients reads beyond the input at i=2. The DIF4 and split-radix paths likewise copy x and then use plan-n indexing at 107-129 and 152-155. Longer inputs are not consistently rejected. A checked common wrapper is required before any schedule access; no source-method acceptance follows from legal-length constructor checks.

### S2: Missing canonical-range rejection is a real contract violation

No Plan forward entry scans its coefficients. For n=2 and malformed x=[p,0], source radix2 arithmetic yields [0,p] from plusm(p,0) and minusm(p,0), rather than rejecting; the latter output is noncanonical. This witness uses source expressions 15-16 and 61-64 and is not an executed result. On the CLI path, line 371 instead silently replaces every parsed z by z%MOD. Entering p there becomes 0, again contrary to v2's reject-malformed-input contract. The v2 adapter must implement explicit rejection, not reuse that normalizing CLI as its correctness interface.

### S3: Zero or negative benchmark repetitions can index empty vectors

benchmark_fair accepts repeats from stoi without a positive-count check (395). With repeats=0, runs 0..3 are discarded warmups, no sample is stored by line 356, and line 364 indexes v[v.size()/2] on an empty vector. Nonpositive repeats can reach the same empty-vector condition. The older benchmark has an analogous zero-repeat path at 297-304. This is a concrete undefined-behavior path from standard vector indexing semantics, without running it. Very large repeats additionally need checked repeats+warmups and run/index arithmetic. These historical benchmark entrypoints must not be used as v2 harnesses.

### S4: CLI allocation precedes length/resource validation

run_stdin allocates vector<u32>x(n) at 371 before Plan/Bluestein validates length at 374/385. A negative int converts to an unsigned vector size before those checks, and a large invalid length can request allocation first. A future adapter must validate signed/representable lengths and checked byte sizes before allocation or narrowing. The Plan constructor's own n guard at 27 does not repair the earlier CLI allocation.

### S5: Empty inverse inputs form an invalid iterator before rejection

inverse_by_radix2 copies the supplied vector then forms begin()+1 without a size check (162-169). The Bluestein inverse does the same at 216-223. For an empty vector, begin()+1 is outside its permitted iterator range before a downstream forward method can reject. The latter path is outside this pilot, but must not be advertised as a guarded general inverse API.

### S6: Bluestein n=1 comment/API mismatch, outside v2 comparison

get_m(1) returns 1, then Bluestein constructs Plan(1), rejected by line 27. The broad fallback comment at 171 does not describe that boundary accurately. The CLI separately returns x for n=1 at 382, but that is not Bluestein(1) support and n=1 remains outside v2. Neither this gap nor the CLI exception expands the admitted pilot domain.

These findings do not identify a proved butterfly error on valid canonical inputs. Source inspection and tiny independent-oracle tests are not execution of those butterflies. Preserve their exact bodies pending the explicitly authorized source-bound adapter and correctness gate.

## Implementation readiness gaps

1. There is no reviewed source-to-adapter diff or schedule-owned paid implementation. The shared Plan builds both permutation families and retains unrelated fields; permitted changes remain only plan pruning, guards, ownership and instrumentation. Preserve the four original schedule bodies, data flow, arithmetic, recursion and mapping. Preserve the DIF4 recursive map algorithm while removing only its unused preliminary resize as v2 specifies.
2. There is no common paid request wrapper rejecting bad sizes/ranges before unsafe access, allocating/materializing each immutable input, and covering complete output consumption and request destruction.
3. There is no adapter implementing common paid plan validation, repeated exact-order/imag checks, overflow/resource guards and type-width checks. Fresh mathematical constant proofs are outside timers; repeated plan checks stay inside.
4. There is no pinned external no-inline full-output sink with separate warm/useful states, exact resets and every per-vector publication. The old one-coordinate checksums cannot fill this role.
5. There is no implemented fresh private eight-vector fixture per trial with required paid load/decode/range/SHA checks, lifetime and H=K. K=1 still loads all eight and uses dense_0 only; warmups remain dense_0..dense_3; K=64 still uses each case eight times.
6. There is no implementation of the frozen direct enclosing workflow/service/useful intervals and cleanup boundaries. Primary timings cannot be assembled from diagnostic phases or polluted by fine-grained timers. Diagnostic fields must retain a separate-run identity rather than fabricated primary values.
7. There are no exact release/diagnostic build commands, binary/sink/adapter hashes, sanitizer results, type-width results, platform/resource/clock preflight, or confirmed execution authorization for inherited code.
8. There is no independent review of this fresh candidate, no full expected-output generation for the remaining 160 vectors, and no all-coordinate preflight/postflight comparisons against any inherited schedule.
9. The source/CSV identities still do not recover or rebind the missing historical review body with hash 32b9e8e7c33b69633e1616188b59e0f9ad643677680bbb5b6175ee5900ddf4d8.

SOURCE_INSPECTION_CHECKLIST.json records each gate and required evidence. The next safe handoff is independent review of this candidate and a separately authorized, source-bound adapter implementation/correctness task. Do not proceed directly to timing. The already accepted 8192-point pilot, full preflight through 2^18, 768 paired trials and inference restrictions remain unchanged.
