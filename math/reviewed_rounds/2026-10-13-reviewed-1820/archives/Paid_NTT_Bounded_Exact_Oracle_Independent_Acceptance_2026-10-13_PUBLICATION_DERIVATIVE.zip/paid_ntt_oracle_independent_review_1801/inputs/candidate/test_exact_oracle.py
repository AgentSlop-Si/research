"""Fresh tiny-only oracle validation and immutable source/data binding audit.

Only exact_oracle.py is imported. Existing .cpp/.py files are read as bytes
for identity checks, never imported, compiled, or executed. No clocks exist
in this harness, and its outputs contain no performance observations.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
import sys

from exact_oracle import (
    P, G, TINY_MAX_N, PROTOCOL_ID, OracleScopeError,
    checked_length, checked_root, validate_root, checked_request, checked_values,
    forward_direct, forward_reference, inverse_direct,
    pack_residues, unpack_residues, exact_compare, check_transform_invariants,
    linear_schoolbook, cyclic_schoolbook, linear_transform_product,
    cyclic_transform_product, independent_constant_certificate,
)

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
CONTRACT = WORKSPACE / "paid_ntt_contract_v2_1622"
AUDIT = WORKSPACE / "paid_ntt_contract_v2_audit_1627"
PINS = {
    "PAID_NTT_CONTRACT.md": "0cefd28b3548a2368ca87b6429b4775aff7e8e16d28913dfaaf4c2a324ca2301",
    "PROTOCOL.json": "e97f0f3da08ed17804169262fb8f31872032f53ab708091419af4b2eec28f3dd",
    "FILES_SHA256.json": "def2f742943cc2a50b15c785cf1a14b4605f9a93a6d48e3ed9e029688be676ff",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def save_json(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n")


def audit_bindings():
    receipt = json.loads((AUDIT / "ACCEPTANCE_RECEIPT.json").read_text())
    require(receipt["execution_acceptance"] is False, "not a design-only receipt")
    require(receipt["performance_evidence"] is False, "unexpected performance acceptance")
    expected_receipt_keys = {
        "PAID_NTT_CONTRACT.md": "accepted_contract_sha256",
        "PROTOCOL.json": "accepted_protocol_sha256",
        "FILES_SHA256.json": "accepted_manifest_sha256",
    }
    for filename, expected in PINS.items():
        require(digest((CONTRACT / filename).read_bytes()) == expected, f"pin mismatch: {filename}")
        require(receipt[expected_receipt_keys[filename]] == expected, "acceptance receipt pin differs")
    checks = []
    for entry in json.loads((CONTRACT / "FILES_SHA256.json").read_text()):
        raw = (CONTRACT / entry["file"]).read_bytes()
        require(len(raw) == entry["bytes"] and digest(raw) == entry["sha256"], "v2 artifact changed")
        checks.append({**entry, "match": True})
    sources = json.loads((CONTRACT / "SOURCE_IDENTITIES.json").read_text())
    for entry in sources["sources"]:
        raw = Path(entry["path"]).read_bytes()
        require(len(raw) == entry["bytes"] and digest(raw) == entry["sha256"], "source changed")
    raw = (CONTRACT / "corpus_inputs.bin").read_bytes()
    manifest = json.loads((CONTRACT / "CORPUS_MANIFEST.json").read_text())
    require(len(raw) == manifest["bytes"] and digest(raw) == manifest["sha256"], "corpus changed")
    require(manifest["lengths"] == [1 << e for e in range(1, 19)], "length grid changed")
    require(len(manifest["case_ids"]) == 16 and len(set(manifest["case_ids"])) == 16, "case grid malformed")
    require(len(manifest["vectors"]) == 288, "vector count changed")
    offset = 0
    pairs = [(n, case) for n in manifest["lengths"] for case in manifest["case_ids"]]
    for entry, (n, case) in zip(manifest["vectors"], pairs):
        require((entry["n"], entry["case"]) == (n, case), "vector ordering differs")
        require(entry["offset_bytes"] == offset and entry["length_bytes"] == 4 * n,
                "vector extent differs")
        data = raw[offset:offset + 4 * n]
        require(digest(data) == entry["sha256"], "per-vector hash mismatch")
        unpack_residues(data, n)  # Data audit only, not an NTT evaluation.
        offset += 4 * n
    require(offset == len(raw), "unaccounted corpus bytes")
    binding = {
        "protocol_id": PROTOCOL_ID, "accepted_protocol_pins": PINS,
        "v2_manifest_entries_verified": len(checks), "v2_entries": checks,
        "source_identities_verified": sources["sources"],
        "corpus_vectors_hash_length_range_verified": 288,
        "corpus_sha256": digest(raw), "corpus_bytes": len(raw),
        "inherited_code_imported_compiled_or_executed": False,
        "protocol_mutated": False,
        "historical_review_body_gap": sources["missing_later_review_sha256"],
        "historical_review_body_gap_resolved": False,
    }
    save_json("BINDING_CHECKS.json", binding)
    return raw, manifest


def check_case_formula(case, x, y):
    n = len(x)
    expected = None
    if case == "zero":
        expected = [0] * n
    elif case == "ones":
        expected = [n % P] + [0] * (n - 1)
    elif case == "minus_ones":
        expected = [(-n) % P] + [0] * (n - 1)
    elif case.startswith("impulse_"):
        j = {"impulse_0": 0, "impulse_1": 1, "impulse_floor_n3": n // 3}[case]
        expected = [pow(checked_root(n), j * k, P) for k in range(n)]
    elif case == "alternating":
        expected = [0] * n
        expected[n // 2] = n % P
    if expected is not None:
        exact_compare(y, expected, context=f"closed-form {case}/{n}")


def tiny_corpus(raw, manifest):
    entries = []
    full_bytes = bytearray()
    for entry in manifest["vectors"]:
        n, case = entry["n"], entry["case"]
        if n > TINY_MAX_N:
            continue
        data = raw[entry["offset_bytes"]:entry["offset_bytes"] + entry["length_bytes"]]
        x = unpack_residues(data, n)
        expected = forward_direct(x)
        require(pack_residues(x) == data, "direct oracle mutated input")
        actual = forward_reference(x)
        require(pack_residues(x) == data, "recursive reference mutated input")
        exact_compare(actual, expected, context=f"frozen {case}/{n}")
        check_transform_invariants(x, expected)
        check_case_formula(case, x, expected)
        # F_+(F_+(x))[k] = n*x[-k mod n], all coordinates.
        twice = forward_reference(actual)
        exact_compare(twice, [(n * x[(-k) % n]) % P for k in range(n)], context="F squared")
        out_bytes = pack_residues(expected)
        entries.append({"n": n, "case": case, "input_sha256": digest(data),
                        "offset_bytes": len(full_bytes), "length_bytes": len(out_bytes),
                        "sha256": digest(out_bytes), "all_coordinates": True,
                        "direct_equals_recursive": True, "independent_inverse": True,
                        "closed_form_where_applicable": True, "input_immutable": True})
        full_bytes.extend(out_bytes)
    require(len(entries) == 128 and len(full_bytes) == 32640, "tiny coverage changed")
    (HERE / "tiny_expected_outputs.bin").write_bytes(full_bytes)
    output = {
        "protocol_id": PROTOCOL_ID,
        "status": "CANDIDATE_TINY_ONLY_NOT_FULL_CORPUS_ACCEPTANCE",
        "format": "little-endian uint32; no header; ascending n then frozen case order",
        "p": P, "g": G, "direction": "positive exponent; unnormalized; natural order",
        "oracle_source_sha256": digest((HERE / "exact_oracle.py").read_bytes()),
        "test_source_sha256": digest(Path(__file__).read_bytes()),
        "input_corpus_sha256": manifest["sha256"], "max_tested_n": TINY_MAX_N,
        "vectors_count": len(entries), "bytes": len(full_bytes),
        "file": "tiny_expected_outputs.bin", "sha256": digest(full_bytes), "vectors": entries,
        "missing_frozen_vectors": 160, "missing_frozen_exponents": list(range(9, 19)),
        "inherited_schedule_outputs_verified": 0,
    }
    save_json("TINY_EXPECTED_MANIFEST.json", output)
    return output


def run_exact_properties():
    exact_compare(forward_direct([1, 2]), [3, P - 1], context="literal n2")
    exact_compare(forward_direct([1, 2, 3, 4]),
                  [10, 173167434, 998244351, 825076915], context="literal n4")
    exact_compare(forward_direct([0, 1, 0, 0]),
                  [1, 911660635, P - 1, 86583718], context="literal impulse n4")
    count = 0
    for n in (2, 4):
        for vector in itertools.product((0, 1, P - 1), repeat=n):
            exact_compare(forward_reference(vector), forward_direct(vector), context="exhaustive tiny")
            exact_compare(inverse_direct(forward_reference(vector)), vector, context="exhaustive inverse")
            count += 1
    convolution_cases = []
    for n in (2, 4, 8, 16, 32):
        a = [(3 * j + 7) % P for j in range(n)]
        b = [(P - 1 - j * j) % P for j in range(n)]
        exact_compare(cyclic_transform_product(a, b, n), cyclic_schoolbook(a, b, n),
                      context=f"cyclic convolution n={n}")
        alpha, beta = 17, P - 3
        combined = [(alpha * av + beta * bv) % P for av, bv in zip(a, b)]
        fa, fb = forward_reference(a), forward_reference(b)
        exact_compare(forward_reference(combined),
                      [(alpha * av + beta * bv) % P for av, bv in zip(fa, fb)], context="linearity")
        convolution_cases.append(n)
    a, b = [1, 2, 3], [4, 5, 6]
    linear = [4, 13, 28, 27, 18]
    cyclic = [22, 13, 28, 27]
    exact_compare(linear_schoolbook(a, b), linear, context="literal linear")
    exact_compare(linear_transform_product(a, b, 8), linear, context="padded linear")
    exact_compare(cyclic_transform_product(a + [0], b + [0], 4), cyclic, context="literal wrapped cyclic")
    for a, b in (([P - 1], [P - 1]), ([0, P - 1], [1, 1]), ([1], [0, 1, 0, P - 1])):
        length = len(a) + len(b) - 1
        n = max(2, 1 << (length - 1).bit_length())
        exact_compare(linear_transform_product(a, b, n), linear_schoolbook(a, b), context="field-linear")
    return {"literal_transform_vectors": 3, "exhaustive_vectors_n2_n4": count,
            "cyclic_schoolbook_lengths": convolution_cases,
            "linearity_lengths": convolution_cases,
            "linear_product_cases": 4,
            "aliasing_example": {"a": [1, 2, 3], "b": [4, 5, 6],
                                 "linear_Fp": linear, "cyclic_mod_z4_minus_1": cyclic,
                                 "linear_padding_n": 8, "padding_n4_rejected": True}}


def corruption_controls():
    controls = []

    def rejects(name, function, errors=(ValueError, AssertionError)):
        try:
            function()
        except errors as exc:
            controls.append({"name": name, "detected": True, "exception": type(exc).__name__,
                             "diagnostic": str(exc)})
        else:
            raise AssertionError("corruption escaped: " + name)

    for n in (0, 1, -1, 3, 6, (1 << 23) + 1, 1 << 24, True, 2.0, "2"):
        rejects(f"invalid length {n!r}", lambda n=n: checked_length(n))
    rejects("wrong modulus", lambda: checked_length(4, p=P - 2))
    rejects("wrong generator", lambda: checked_length(4, g=4))
    rejects("order-one root", lambda: validate_root(8, 1))
    rejects("noncanonical root", lambda: validate_root(8, P))
    rejects("inverse primitive root has wrong sign binding", lambda: validate_root(8, pow(checked_root(8), P - 2, P)))
    rejects("source length still legal but direct budget rejects 512", lambda: forward_direct([0] * 512))
    rejects("reference default budget rejects 512", lambda: forward_reference([0] * 512))
    rejects("wrong short input length", lambda: forward_reference([1], n=2))
    rejects("wrong long input length", lambda: forward_reference([1, 2, 3], n=2))
    rejects("unbounded input iterator", lambda: forward_reference(iter([1, 2]), n=2))
    for value in (-1, P, P + 1, (1 << 32) - 1, True, 1.0, "1"):
        rejects(f"noncanonical input {value!r}", lambda value=value: forward_reference([value, 0]))
    expected = forward_direct([1, 2, 3, 4, 5, 6, 7, 8])
    for name, bad in (
        ("short output", expected[:-1]), ("long output", expected + [0]),
        ("off-by-one final coordinate", expected[:-1] + [(expected[-1] + 1) % P]),
        ("negative output", [-1] + expected[1:]), ("noncanonical output p", [P] + expected[1:]),
        ("bool output", [True] + expected[1:]),
        ("opposite exponent/natural reversal", [expected[0]] + expected[:0:-1]),
        ("incorrect forward normalization", [value * pow(8, P - 2, P) % P for value in expected]),
    ):
        rejects(name, lambda bad=bad: exact_compare(bad, expected))
    compensated = list(expected)
    compensated[1] = (compensated[1] + 1) % P
    compensated[2] = (compensated[2] - 1) % P
    require(compensated[0] == expected[0] and sum(compensated) % P == sum(expected) % P,
            "compensated control did not preserve weak checks")
    rejects("two-coordinate corruption preserving DC and total", lambda: exact_compare(compensated, expected))
    original_bytes = pack_residues([1, 2, 3, 4])
    mutated = [1, 2, 3, 5]
    rejects("input mutation detected by complete bytes", lambda: require(pack_residues(mutated) == original_bytes, "input bytes changed"))
    rejects("truncated wire bytes", lambda: unpack_residues(original_bytes[:-1], 4))
    rejects("extra wire bytes", lambda: unpack_residues(original_bytes + b"\0", 4))
    rejects("noncanonical wire residue", lambda: unpack_residues(P.to_bytes(4, "little") + b"\0" * 4, 2))
    rejects("wrong endianness gives wrong complete output", lambda: exact_compare(
        [int.from_bytes(original_bytes[j:j+4], "big") for j in range(0, len(original_bytes), 4)],
        [1, 2, 3, 4]))
    rejects("underpadding linear convolution n4", lambda: linear_transform_product([1, 2, 3], [4, 5, 6], 4))
    rejects("negative input not silently normalized", lambda: linear_schoolbook([-1], [1]))
    rejects("cyclic length mismatch", lambda: cyclic_schoolbook([1, 2], [1, 2], 4))
    save_json("CORRUPTION_CONTROLS.json", {"passed": len(controls), "controls": controls,
        "scope": "newly authored oracle and comparison machinery only; no source adapter tested"})
    return len(controls)


def main():
    raw, manifest = audit_bindings()
    certificate = independent_constant_certificate()
    old = json.loads((CONTRACT / "MODULUS_ROOT_CERTIFICATE.json").read_text())
    require(certificate["generator_tests"] == old["primitive_order_checks"], "certificate generator disagreement")
    require(certificate["roots"] == [{"n": item["n"], "omega": item["omega"]}
                                     for item in old["length_root_checks"]], "certificate root disagreement")
    save_json("CONSTANT_CERTIFICATE.json", certificate)
    tiny = tiny_corpus(raw, manifest)
    properties = run_exact_properties()
    negative_count = corruption_controls()
    report = {
        "result": "PASS_CANDIDATE_ORACLE_TINY_SELF_VALIDATION_ONLY",
        "protocol_id": PROTOCOL_ID,
        "python_version": sys.version.split()[0],
        "candidate_files_executed": ["test_exact_oracle.py", "exact_oracle.py"],
        "corpus_data_read_only_audit_vectors": 288,
        "frozen_vectors_full_output_agreement": tiny["vectors_count"],
        "frozen_coefficients_compared": tiny["bytes"] // 4,
        "frozen_transform_lengths": [1 << e for e in range(1, 9)],
        "input_immutability_all_tiny_cases": True,
        "independent_inverse_all_tiny_cases": True,
        "F_squared_identity_all_tiny_cases": True,
        "constant_root_order_checks_through": 1 << 23,
        "larger_length_transform_execution": False,
        "properties": properties, "negative_corruption_controls_passed": negative_count,
        "inherited_code_execution": False, "inherited_schedule_passes": 0,
        "full_288_vector_correctness_gate_passed": False,
        "adapter_or_binary_acceptance": False, "benchmark_ready": False,
        "performance_observations": False, "protocol_v2_modified": False,
    }
    save_json("TEST_REPORT.json", report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
