# Exact NTT oracle candidate, tiny gate

Status: tiny fresh-code self-validation passed; independent acceptance, full correctness preflight and benchmark readiness are pending.

Read IMPLEMENTATION_GAPS.md first. SOURCE_INSPECTION_CHECKLIST.json identifies the exact source-bound gates still missing. The accepted paid-ntt-v2-20261013 files are read-only inputs and were not changed.

## Files

- exact_oracle.py: freshly authored direct modular forward map, independent recursive radix-2 reference, independent Horner inverse, strict comparison/serialization, and finite-field convolution demonstrations
- test_exact_oracle.py: fresh read-only source/data binding checks and tiny correctness/corruption test driver
- TEST_REPORT.json: observed test scope and explicit non-acceptance boundaries
- TINY_EXPECTED_MANIFEST.json and tiny_expected_outputs.bin: all 128 frozen expected-output vectors for n=2..256, packed LE32; 32,640 bytes; remaining 160 frozen vectors are absent
- CONSTANT_CERTIFICATE.json: fresh exact prime/generator/root checks; large root checks are not large transforms
- CORRUPTION_CONTROLS.json: all 44 expected rejections
- BINDING_CHECKS.json: immutable accepted source/protocol/corpus checks
- FILES_SHA256.json: delivery identity manifest, excluding itself

## Reproduce this bounded check only

From the parent workspace:

    python -B paid_ntt_oracle_candidate_1751/test_exact_oracle.py

Only the two newly authored Python modules execute. Existing C++, CSV, JSON, Python and binary corpus artifacts are read as bytes/data only. The driver neither imports nor runs the historical generator or NTT source. It does not collect timings or execute a transform larger than 256. It overwrites this directory's candidate outputs deterministically, not any protocol/source inputs.

The explicit default max_n=256 in the reference is an execution-budget guard, distinct from the mathematical legal domain through 2^23. Do not widen it or interpret constant-root checks as broader transform coverage in this bounded task.

## Observed result

128 frozen vectors, 8,160 complete coordinates, 90 exhaustive n=2/4 vectors, three literal anchors, inverse/identity/immutability checks, finite-field cyclic-versus-linear examples, and 44 negative/corruption controls pass. All 288 frozen input vectors pass read-only hash/extent/range auditing. Zero inherited schedule outputs have been verified.

The next gate is independent review of this candidate plus a separately authorized source-bound paid adapter/correctness task. No timing, speedup, novel FFT/NTT, full-corpus acceptance, or production-readiness claim is made.
