"""Independent bounded audit. Execute this file only; inputs are read as data.

No candidate or historical scientific module is imported, compiled, or run.
Polynomial evaluation and inverse matrix multiplication are freshly authored.
"""
from pathlib import Path
import ast
import hashlib
import itertools
import json
import math
import struct

HERE = Path(__file__).resolve().parent
CAND = HERE / "inputs/candidate"
PROTO = HERE / "inputs/protocol"
OLD = HERE / "inputs/historical"
P = 998244353
G = 3
PIN = "e1bb27b3a767517d9511c93e5aa79c3f4b1b2a58b4eb0b65537e99ebe959dbaf"
PINS = {
    "FILES_SHA256.json": "def2f742943cc2a50b15c785cf1a14b4605f9a93a6d48e3ed9e029688be676ff",
    "PAID_NTT_CONTRACT.md": "0cefd28b3548a2368ca87b6429b4775aff7e8e16d28913dfaaf4c2a324ca2301",
    "PROTOCOL.json": "e97f0f3da08ed17804169262fb8f31872032f53ab708091419af4b2eec28f3dd",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_text())


def need(ok, why):
    if not ok:
        raise AssertionError(why)


def dump(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n")


def legal(n, p=P, g=G):
    # Membership in an explicitly enumerated domain, not candidate bit logic.
    if type(n) is not int or n not in {2 ** e for e in range(1, 24)}:
        raise ValueError("illegal length")
    if type(p) is not int or p != P or type(g) is not int or g != G:
        raise ValueError("fixed constants violated")


def vector(x, n, budget=256):
    legal(n)
    if n > budget or type(x) not in (list, tuple) or len(x) != n:
        raise ValueError("size, type, or execution budget")
    if any(type(a) is not int or a < 0 or a >= P for a in x):
        raise ValueError("noncanonical coefficient")


def root(n, w):
    legal(n)
    if type(w) is not int or w != pow(3, (P - 1) // n, P):
        raise ValueError("root binding")


def decode(raw, n):
    legal(n)
    if type(raw) is not bytes or len(raw) != n * 4:
        raise ValueError("wire extent")
    x = [a[0] for a in struct.iter_unpack("<I", raw)]
    vector(x, n, budget=2 ** 23)
    return x


def encode(x):
    return b"".join(a.to_bytes(4, "little") for a in x)


def full_compare(actual, expected):
    # Positive list check then explicit indexed comparisons, not hashes.
    if type(actual) not in (tuple, list) or len(actual) != len(expected):
        raise ValueError("output extent")
    for k in range(len(expected)):
        if type(actual[k]) is not int or not 0 <= actual[k] < P:
            raise ValueError("noncanonical output")
        if actual[k] != expected[k]:
            raise ValueError("coordinate mismatch: " + str(k))


def polynomial_map(x):
    """Evaluate ascending-coefficient polynomial at each positive root power."""
    n = len(x)
    vector(x, n)
    step = pow(3, (P - 1) // n, P)
    point = 1
    y = []
    for k in range(n):
        acc = 0
        j = n
        while j:
            j -= 1
            acc = (acc * point + x[j]) % P
        y.append(acc)
        point = point * step % P
    return y


def inverse_matrix(y):
    """Separate inverse matrix summation using exact modular inverses."""
    n = len(y)
    vector(y, n)
    w_inv = pow(pow(3, (P - 1) // n, P), -1, P)
    scale = pow(n, -1, P)
    return [sum(y[k] * pow(w_inv, k * j, P) for k in range(n)) * scale % P
            for j in range(n)]


def schoolbook(a, b, n=None):
    c = [0] * (n if n is not None else len(a) + len(b) - 1)
    for i in range(len(a)):
        for j in range(len(b)):
            at = (i + j) % n if n is not None else i + j
            c[at] = (c[at] + a[i] * b[j]) % P
    return c


def product(a, b, n, linear=False):
    legal(n)
    if not a or not b:
        raise ValueError("empty polynomial")
    if linear and n < len(a) + len(b) - 1:
        raise ValueError("linear underpadding")
    aa, bb = list(a) + [0] * (n - len(a)), list(b) + [0] * (n - len(b))
    fa, fb = polynomial_map(aa), polynomial_map(bb)
    out = inverse_matrix([fa[k] * fb[k] % P for k in range(n)])
    if linear:
        end = len(a) + len(b) - 1
        need(not any(out[end:]), "nonzero padded tail")
        return out[:end]
    return out


def audit_manifest(directory, expected_pin=None):
    raw = (directory / "FILES_SHA256.json").read_bytes()
    if expected_pin:
        need(sha(raw) == expected_pin, "manifest pin mismatch")
    entries = json.loads(raw)
    need(len({e['file'] for e in entries}) == len(entries), "duplicate manifest entries")
    for e in entries:
        data = (directory / e['file']).read_bytes()
        need(len(data) == e['bytes'] and sha(data) == e['sha256'], "entry mismatch " + e['file'])
    return entries


def static_audit():
    text = (CAND / 'exact_oracle.py').read_text()
    tree = ast.parse(text)
    funcs = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    calls = {}
    for name in ['forward_direct', 'forward_reference', 'inverse_direct']:
        calls[name] = sorted({n.func.id for n in ast.walk(funcs[name])
                              if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)})
    need('forward_reference' not in calls['forward_direct'], 'direct delegates reference')
    need('forward_direct' not in calls['forward_reference'], 'reference delegates direct')
    need(not {'forward_direct', 'forward_reference'} & set(calls['inverse_direct']), 'inverse delegates forward')
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(n.name for n in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    need(set(imports) == {'__future__', 'struct'}, 'unexpected oracle import')
    test_tree = ast.parse((CAND / 'test_exact_oracle.py').read_text())
    test_imports = []
    for node in ast.walk(test_tree):
        if isinstance(node, ast.Import):
            test_imports.extend(n.name for n in node.names)
        elif isinstance(node, ast.ImportFrom):
            test_imports.append(node.module)
    need(set(test_imports) == {'__future__', 'hashlib', 'itertools', 'json', 'pathlib', 'sys', 'exact_oracle'},
         'unexpected candidate harness import')
    source = (OLD / 'fft_engine.cpp').read_text().splitlines()
    need(len(source) == 400, 'historical source line count')
    witnesses = [
        ('S1', [44, 46, 49, 51, 55, 56, 71, 72, 109, 115, 129, 152, 153, 154],
         'Plan forwards access n elements without a request-size check; n=4 and a two-element input reaches an out-of-range access.'),
        ('S2', [15, 16, 61, 62, 63, 64, 371],
         'For n=2, [p,0] yields [0,p] by the source expressions; CLI z%MOD normalizes instead of rejecting. Static witness only.'),
        ('S3', [294, 297, 300, 304, 347, 350, 356, 364, 395],
         'With repeats=0 the sample vectors stay empty and the median indexes element zero. For benchfair, negative repeats likewise store no samples. Entry into the outer size loop is assumed.'),
        ('S4', [371, 374, 385],
         'vector<u32>x(n) precedes Plan/Bluestein validation; a negative int converts to an unsigned size before the length checks.'),
        ('S5', [162, 163, 164, 217, 218, 219],
         'Empty inverse input forms begin()+1 before downstream validation, outside its valid iterator range.'),
        ('S6', [27, 171, 178, 179, 180, 184, 382],
         'get_m(1)=1, then Plan(1) rejects; CLI has a distinct n=1 special case. Outside the v2 domain.'),
    ]
    return {'method': 'AST parsing and manual text reasoning, never scientific-code execution',
            'oracle_imports': imports, 'harness_imports': test_imports, 'calls': calls,
            'candidate_algorithm_review': {
                'direct': 'Explicit independent pow per summand, positive exponent, final modular reduction, no normalization.',
                'recursive': 'Even/odd coefficient recursion, local g-derived root, concatenated E+w^k O and E-w^k O; natural output order by induction.',
                'inverse': 'Descending Horner evaluation at inverse-root powers, one n^-1 factor; no forward call or reversal shortcut.',
                'shared_components': 'Only constants, validation, and ordinary serialization; algorithmic structure differs.',
                'request_and_input_immutability': 'Public domain guard followed by canonical scan and tuple copy; transforms write fresh lists only.',
                'root_binding': 'Exact order and quarter-root checks plus equality to the g-derived root prevent opposite-sign substitution.',
                'runtime_claim_limit': 'Candidate runtime not rerun; previous 44-control result is source-reviewed evidence. Fresh independent controls are recorded separately.'},
            'source_witnesses': [{'id': code, 'accepted': True, 'reason': reason,
                                  'lines': [{'line': i, 'text': source[i - 1]} for i in indices]}
                                 for code, indices, reason in witnesses]}


def negatives():
    controls = []
    def reject(name, f):
        try:
            f()
        except (ValueError, AssertionError):
            controls.append({'name': name, 'detected': True})
        else:
            raise AssertionError('missed negative control: ' + name)
    for n in [0, 1, -1, 3, 6, 2 ** 23 + 1, 2 ** 24, True, 2.0, '2']:
        reject('invalid length ' + repr(n), lambda n=n: legal(n))
    reject('wrong modulus', lambda: legal(4, p=P - 2))
    reject('wrong generator', lambda: legal(4, g=4))
    reject('order-one root', lambda: root(8, 1))
    reject('noncanonical root', lambda: root(8, P))
    reject('opposite primitive-root sign', lambda: root(8, pow(pow(3, (P - 1) // 8, P), -1, P)))
    reject('default forward budget 512', lambda: polynomial_map([0] * 512))
    reject('default inverse budget 512', lambda: inverse_matrix([0] * 512))
    reject('short input', lambda: vector([1], 2))
    reject('long input', lambda: vector([1, 2, 3], 2))
    reject('iterator input', lambda: vector(iter([1, 2]), 2))
    for v in [-1, P, P + 1, 2 ** 32 - 1, True, 1.0, '1']:
        reject('noncanonical input ' + repr(v), lambda v=v: vector([v, 0], 2))
    y = polynomial_map(list(range(1, 9)))
    for name, v in [
        ('short output', y[:-1]), ('long output', y + [0]),
        ('last coordinate corruption', y[:-1] + [(y[-1] + 1) % P]),
        ('negative output', [-1] + y[1:]), ('output p', [P] + y[1:]),
        ('boolean output', [True] + y[1:]), ('sign reversal', [y[0]] + y[:0:-1]),
        ('forward normalized', [a * pow(8, -1, P) % P for a in y]),
    ]:
        reject(name, lambda v=v: full_compare(v, y))
    v = y[:]
    v[1], v[2] = (v[1] + 1) % P, (v[2] - 1) % P
    need(v[0] == y[0] and sum(v) % P == sum(y) % P, 'compensated mutant invariants')
    reject('compensated corruption preserves DC and sum', lambda: full_compare(v, y))
    reject('input byte change', lambda: need(encode([1, 2, 3, 5]) == encode([1, 2, 3, 4]), 'changed input'))
    data = encode([1, 2, 3, 4])
    reject('wire truncation', lambda: decode(data[:-1], 4))
    reject('extra wire bytes', lambda: decode(data + b'\0', 4))
    reject('noncanonical wire', lambda: decode(encode([P, 0]), 2))
    reject('big-endian words', lambda: full_compare([z[0] for z in struct.iter_unpack('>I', data)], [1, 2, 3, 4]))
    reject('linear underpadding', lambda: product([1, 2, 3], [4, 5, 6], 4, linear=True))
    reject('negative polynomial coefficient', lambda: product([-1], [1], 2, linear=True))
    reject('cyclic wrong extent', lambda: vector([1, 2], 4))
    need(len(controls) == 44, 'independent conceptual control count')
    reject('bit-reversed permutation', lambda: full_compare([y[int(format(k, '03b')[::-1], 2)] for k in range(8)], y))
    reject('floating output', lambda: full_compare([float(y[0])] + y[1:], y))
    reject('string output', lambda: full_compare([str(y[0])] + y[1:], y))
    reject('legal endpoint bool modulus', lambda: legal(2, p=True))
    reject('noncanonical negative root', lambda: root(4, -1))
    return controls


def main():
    candidate = audit_manifest(CAND, PIN)
    protocol = audit_manifest(PROTO, PINS['FILES_SHA256.json'])
    for filename, pin in PINS.items():
        need(sha((PROTO / filename).read_bytes()) == pin, 'protocol pin ' + filename)
    receipt = load(HERE / 'inputs/prior_acceptance/ACCEPTANCE_RECEIPT.json')
    need(receipt['execution_acceptance'] is False and receipt['performance_evidence'] is False, 'design receipt scope')
    for name, key in [('PAID_NTT_CONTRACT.md', 'accepted_contract_sha256'),
                      ('PROTOCOL.json', 'accepted_protocol_sha256'), ('FILES_SHA256.json', 'accepted_manifest_sha256')]:
        need(receipt[key] == PINS[name], 'design acceptance pin')
    identities = load(PROTO / 'SOURCE_IDENTITIES.json')
    for e in identities['sources']:
        data = (OLD / Path(e['path']).name).read_bytes()
        need(len(data) == e['bytes'] and sha(data) == e['sha256'], 'historical source pin')
    need(all(P % d for d in range(2, math.isqrt(P) + 1)), 'prime trial division')
    need(P - 1 == 2 ** 23 * 7 * 17, 'factorization')
    primitive = {str(q): pow(G, (P - 1) // q, P) for q in [2, 7, 17]}
    need(all(a != 1 for a in primitive.values()), 'primitive generator')
    cert = load(CAND / 'CONSTANT_CERTIFICATE.json')
    need(cert['generator_tests'] == primitive and cert['p'] == P and cert['g'] == G, 'certificate constants')
    roots = []
    for e in range(1, 24):
        n = 2 ** e
        legal(n)
        w = pow(G, (P - 1) // n, P)
        need(pow(w, n, P) == 1 and pow(w, n // 2, P) == P - 1, 'root exact order')
        if n >= 4:
            need(pow(pow(w, n // 4, P), 2, P) == P - 1, 'quarter root')
        roots.append({'n': n, 'omega': w})
    need(cert['roots'] == roots, 'candidate root table')
    old_cert = load(PROTO / 'MODULUS_ROOT_CERTIFICATE.json')
    need(roots == [{'n': z['n'], 'omega': z['omega']} for z in old_cert['length_root_checks']], 'pinned root table')
    cm = load(PROTO / 'CORPUS_MANIFEST.json')
    raw = (PROTO / 'corpus_inputs.bin').read_bytes()
    need(len(raw) == cm['bytes'] and sha(raw) == cm['sha256'], 'whole corpus')
    need(cm['lengths'] == [2 ** e for e in range(1, 19)], 'corpus length grid')
    need(len(cm['case_ids']) == 16 and len(set(cm['case_ids'])) == 16, 'cases')
    need(len(cm['vectors']) == 288, 'corpus vector count')
    offset = 0
    tiny_inputs = []
    for e, pair in zip(cm['vectors'], itertools.product(cm['lengths'], cm['case_ids'])):
        n, case = pair
        need((e['n'], e['case']) == pair and e['offset_bytes'] == offset and e['length_bytes'] == n * 4, 'corpus layout')
        data = raw[offset:offset + n * 4]
        need(sha(data) == e['sha256'], 'input vector hash')
        x = decode(data, n)
        if n <= 256:
            tiny_inputs.append((e, x, data))
        offset += n * 4
    need(offset == len(raw), 'corpus extent complete')
    tm = load(CAND / 'TINY_EXPECTED_MANIFEST.json')
    stored = (CAND / 'tiny_expected_outputs.bin').read_bytes()
    need(tm['oracle_source_sha256'] == sha((CAND / 'exact_oracle.py').read_bytes()), 'oracle source binding')
    need(tm['test_source_sha256'] == sha((CAND / 'test_exact_oracle.py').read_bytes()), 'test source binding')
    need(tm['input_corpus_sha256'] == cm['sha256'], 'input corpus binding')
    need(tm['vectors_count'] == len(tm['vectors']) == len(tiny_inputs) == 128, 'tiny vector count')
    need(tm['bytes'] == len(stored) == 32640 and tm['sha256'] == sha(stored), 'output binding')
    need(tm['p'] == P and tm['g'] == G and tm['max_tested_n'] == 256, 'tiny constants')
    need(tm['missing_frozen_vectors'] == 160 and tm['missing_frozen_exponents'] == list(range(9, 19)), 'remaining scope')
    offset = coordinates = mutation_count = closed_forms = 0
    recomputed = bytearray()
    details = []
    for (e, x, data), out_e in zip(tiny_inputs, tm['vectors']):
        n, case = e['n'], e['case']
        need((out_e['n'], out_e['case']) == (n, case), 'tiny case order')
        need(out_e['input_sha256'] == sha(data), 'tiny input binding')
        need(out_e['offset_bytes'] == offset and out_e['length_bytes'] == n * 4, 'tiny output extent')
        payload = stored[offset:offset + n * 4]
        need(sha(payload) == out_e['sha256'], 'tiny output hash')
        y = decode(payload, n)
        ours = polynomial_map(x)
        full_compare(y, ours)
        full_compare(inverse_matrix(y), x)
        full_compare(polynomial_map(y), [n * x[-k % n] % P for k in range(n)])
        need(y[0] == sum(x) % P and sum(y) % P == n * x[0] % P, 'DC/sum')
        formula = None
        if case == 'zero':
            formula = [0] * n
        elif case in ('ones', 'minus_ones'):
            formula = [(n if case == 'ones' else -n) % P] + [0] * (n - 1)
        elif case.startswith('impulse_'):
            j = {'impulse_0': 0, 'impulse_1': 1, 'impulse_floor_n3': n // 3}[case]
            formula = [pow(G, ((P - 1) // n) * j * k, P) for k in range(n)]
        elif case == 'alternating':
            formula = [0] * n
            formula[n // 2] = n
        if formula is not None:
            full_compare(y, formula)
            closed_forms += 1
        for k in range(n):
            changed = y[:]
            changed[k] = (changed[k] + 1) % P
            try:
                full_compare(changed, ours)
            except ValueError:
                mutation_count += 1
            else:
                raise AssertionError('single-coordinate mutant escaped')
        need(encode(x) == data, 'independent input changed')
        recomputed.extend(encode(ours))
        details.append({'n': n, 'case': case, 'coordinates': n,
                        'input_sha256': sha(data), 'expected_output_sha256': sha(encode(ours)),
                        'all_coordinates_agree': True, 'inverse_agrees': True, 'F_squared_agrees': True})
        offset += n * 4
        coordinates += n
    need(offset == len(stored) and bytes(recomputed) == stored, 'entire stored output independently reproduced')
    need(coordinates == mutation_count == 8160, 'coordinate coverage')
    literal = [([1, 2], [3, P - 1]),
               ([1, 2, 3, 4], [10, 173167434, 998244351, 825076915]),
               ([0, 1, 0, 0], [1, 911660635, P - 1, 86583718])]
    for x, y in literal:
        full_compare(polynomial_map(x), y)
    exhaustive = 0
    for n in [2, 4]:
        for x in itertools.product([0, 1, P - 1], repeat=n):
            y = polynomial_map(x)
            full_compare(inverse_matrix(y), list(x))
            exhaustive += 1
    for n in [2, 4, 8, 16, 32]:
        a = [(11 + k * k) % P for k in range(n)]
        b = [(P - 1 - 13 * k) % P for k in range(n)]
        full_compare(product(a, b, n), schoolbook(a, b, n))
        fa, fb = polynomial_map(a), polynomial_map(b)
        full_compare(polynomial_map([(19 * a[k] + (P - 5) * b[k]) % P for k in range(n)]),
                     [(19 * fa[k] + (P - 5) * fb[k]) % P for k in range(n)])
    for a, b in [([1, 2, 3], [4, 5, 6]), ([P - 1], [P - 1]),
                 ([0, P - 1], [1, 1]), ([1], [0, 1, 0, P - 1])]:
        n = max(2, 2 ** (len(a) + len(b) - 2).bit_length())
        full_compare(product(a, b, n, linear=True), schoolbook(a, b))
    full_compare(product([1, 2, 3], [4, 5, 6], 4), [22, 13, 28, 27])
    controls = negatives()
    candidate_controls = load(CAND / 'CORRUPTION_CONTROLS.json')
    need(candidate_controls['passed'] == len(candidate_controls['controls']) == 44, 'reported negative coverage')
    need(all(c['detected'] for c in candidate_controls['controls']), 'reported escaped corruption')
    need(len({c['name'] for c in candidate_controls['controls']}) == 44, 'duplicate candidate controls')
    static = static_audit()
    report = load(CAND / 'TEST_REPORT.json')
    need(report['frozen_vectors_full_output_agreement'] == 128 and report['frozen_coefficients_compared'] == 8160,
         'candidate reported coverage')
    need(report['negative_corruption_controls_passed'] == 44, 'candidate negative count')
    for key in ['larger_length_transform_execution', 'inherited_code_execution',
                'full_288_vector_correctness_gate_passed', 'adapter_or_binary_acceptance',
                'benchmark_ready', 'performance_observations', 'protocol_v2_modified']:
        need(report[key] is False, 'scope expanded: ' + key)
    need(report['inherited_schedule_passes'] == 0, 'schedule acceptance claimed')
    # Recheck all input hashes after independent work.
    audit_manifest(CAND, PIN)
    audit_manifest(PROTO, PINS['FILES_SHA256.json'])
    result = {
        'decision': 'ACCEPT_BOUNDED_EXACT_ORACLE_CANDIDATE',
        'candidate_manifest_sha256': PIN,
        'accepted_scope': 'Independent source review and complete stored-output validation only for n=2..256.',
        'candidate_manifest_entries': len(candidate), 'protocol_manifest_entries': len(protocol),
        'historical_source_entries': len(identities['sources']), 'corpus_vectors_data_audited': 288,
        'frozen_output_vectors': 128, 'frozen_output_coordinates': coordinates,
        'complete_output_bytes': len(stored), 'independent_output_sha256': sha(recomputed),
        'closed_form_vectors': closed_forms, 'literal_anchors': len(literal),
        'exhaustive_n2_n4_vectors': exhaustive, 'cyclic_and_linearity_lengths': [2, 4, 8, 16, 32],
        'linear_product_examples': 4,
        'fresh_negative_controls': len(controls), 'all_coordinate_single_mutants_rejected': mutation_count,
        'candidate_44_controls_source_reviewed_not_rerun': True,
        'constant_root_checks_through': 2 ** 23, 'maximum_executed_transform_n': 256,
        'executed_scientific_files': ['independent_check.py'],
        'candidate_scientific_code_executed_or_imported': False,
        'historical_scientific_code_executed_imported_or_compiled': False,
        'input_sources_preserved': True, 'inherited_schedules_accepted': 0,
        'full_288_vector_correctness_accepted': False, 'benchmark_ready': False,
        'performance_observations': False, 'sheet_or_github_writes': False,
        'remaining_vectors_without_outputs': 160,
    }
    dump('INDEPENDENT_RESULTS.json', result)
    dump('PER_VECTOR_RESULTS.json', details)
    dump('INDEPENDENT_NEGATIVE_CONTROLS.json', {'fresh_controls': controls, 'single_coordinate_controls': mutation_count})
    dump('SOURCE_REVIEW.json', static)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
