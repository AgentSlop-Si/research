# Independent review: bounded N11 signed-bank gates

Review date: 13 October 2026. **Verdict: ACCEPT within the stated finite-field scope.** No arithmetic mismatch or substantive mathematical repair was found. The variable-singleton lower bound does not become an unrestricted bank minimum, a root-uniform statement, or an unrestricted characteristic-zero theorem.

## 1. Accepted statements

1. Work in characteristic 23 with N=11 and the specified primitive root q=2. If there is exactly one effective minus-plus node y in F23*, then at least six effective plus-plus nodes are necessary, even if the plus-plus nodes, all amplitudes, and all legal beta parameters belong to an extension field. No bound on the number of negative-delta banks is needed for this one-sided conclusion.
2. Simultaneous reflection gives the corresponding six-node lower bound for minus-minus when plus-minus is a singleton whose node is in F23*. Consequently, the architecture with one cross-sign singleton in each orientation, both singleton nodes in F23*, needs at least fourteen banks. This does not prove attainment or exclude a different orientation allocation.
3. For all ten primitive eleventh roots q in F23 and all 22 nonzero base-field singleton nodes y, the candidate's 220 matrices and exact determinants agree with fresh original-grammar calculations: 211 are nonsingular, nine are singular. A singular gate is only a surviving necessary condition, never a construction.
4. At q=2, no one of the 529 monic sextics in the specified singleton-one recurrence family has six distinct nonzero F23 roots. Independently, none of the 74,613 six-element subsets of F23* yields a polynomial satisfying all four source recurrence equations. This is an exact base-field split-family obstruction. It does not exclude roots in a splitting field or a construction outside the tested family.

The candidate's own stop condition is met. The parent signed-bank problem stays open.

## 2. What was read and what was executed

Read as inert sources: N11_CONSTRUCTION.md, N11_PARAMETRIC_FAMILY.md, N11_LATER_ENVELOPE.md, N11_LATER_QUINTIC_REVIEW.md, COMMON_NODE_CRITERION.md, SIGNED_BANK_ASSESSMENT.md, the three candidate signed-bank scripts, and the alternate crosscheck script. The full candidate programs were inspected but never executed, imported, compiled, or evaluated. No source file was modified. There were no external writes.

Only the newly written fresh_signed_bank_check.py was executed. It uses Python's standard library. Its scientific results do not depend on importing or running source code. Candidate JSON is opened for equality comparison only after the new calculations finish. The final manifest pins the inspected source and candidate-output bytes.

The new Gaussian factors are not copied tables: every word in powers of alpha S^epsilon + beta z T^delta is enumerated. Each earlier T followed by a later S contributes q^(epsilon delta). These word sums are compared against the product Gaussian formula, but the word sums drive the matrices. Every 6-by-6 determinant is evaluated by the full 720-term permutation formula and crosschecked by independent modular elimination/rank.

## 3. Derivation directly from the original resolvent grammar

Let S e_i=e_(i+1), T e_i=q^i e_i and W_(a,b)=S^a T^b. Then TS=qST. For a fixed orientation and branch j, put

X_j=alpha S^epsilon + beta q^(epsilon delta j) T^delta,
Delta=1-alpha^11-beta^11.

At a primitive eleventh root, the interior Gaussian coefficients of degree eleven vanish, so

X_j^11=(alpha^11+beta^11)I,
(I-X_j)^(-1)=Delta^(-1) sum_(k=0)^10 X_j^k,

when Delta is nonzero. Both inverse products follow by telescoping. This retains exactly the allowed generators, phases, and original branch inverses.

Writing r=[epsilon a]_11 and ell=[delta b]_11, the Weyl coefficient of the complete bank (1/11) sum_j w_j (I-X_j)^(-1) is

alpha^r G_(epsilon,delta)(a,b) [beta^ell/(11 Delta)] sum_j w_j q^(epsilon delta j ell),

with G zero when r+ell>10 and otherwise equal to the corresponding Gaussian coefficient. There is no extra or missing factor eleven.

Direct extraction from F_(k,t)=q^(-kt) gives

(1/11) sum_t q^(-bt) F_(t+a,t)
 = (1/11) sum_t q^(-t^2-(a+b)t)
 = C q^(3(a+b)^2),

where C=(1/11) sum_t q^(-t^2) is nonzero and 4*3=1 modulo eleven. Divide every coefficient by C and absorb the bracketed expression into a sector amplitude h_ell. For all beta, including zero, the resulting contribution is exactly h_ell alpha^r G. Thus arbitrary beta does not alter the common-alpha moment necessity. This is a statement about the coefficients of the same banks, not a new gauge or a change to the target.

The checker verifies the target formula at all 1,210 combinations of primitive q,a,b. It also checks 32 literal banks using the original 11-by-11 matrices, including legal alpha=0 banks and legal beta=0 banks, 352 individual inverse branches, and 3,872 bank Weyl coefficients. The beta=0 cases use alpha=5, so Delta is nonzero; the alpha=0 cases use beta=5. This avoids accidentally testing illegal zero-parameter controls.

## 4. Forced moments and the six-by-six necessary gate

Assume minus-plus has only one effective node y. In physical row b=1 or b=2, the coordinate a=11-b is supported only by minus-plus. Its normalized Fourier coefficient is one and its local alpha exponent is b. Therefore

T_b(y)=1/[y^b G_-+(11-b,b)].

For a=b,...,10-b, both negative-delta orientations have zero support and G_++ is nonzero. The remaining required plus-plus moment is

v_b(a)=[q^(3(a+b)^2)-T_b(y)y^(11-a)G_-+(a,b)]/G_++(a,b).

Every support assertion and every denominator here is checked separately for every primitive q, rather than presumed from stored arrays. This gives nine moments for b=1 and seven for b=2. Four length-six windows of the first sequence and two of the second form the claimed six-by-six matrix.

If the plus-plus contribution used at most five effective nodes x_i, possibly in an extension field, then v_b(a)=sum_i A_(b,i)x_i^a. Let g(t) be the product of t-x_i over the distinct effective nodes. Multiply it by t^(5-deg g) if necessary. The resulting nonzero degree-five polynomial annihilates every selected six-term window, because

sum_(k=0)^5 g_k v_b(a+k)=sum_i A_(b,i)x_i^a g(x_i)=0.

Hence the matrix must be singular. Nonsingularity excludes at most five nodes. There is no assumption of a depressed quintic, singleton-one node, shared plus-plus/minus-minus nodes, or a base-field restriction on the same-sign nodes.

### Zero, repeated-node, and arbitrary-beta guards

- y=0 cannot match the exclusive coordinate (a,b)=(10,1), where its contribution includes y^1 and all other orientations vanish. By reflection the other cross-sign singleton cannot have alpha=0 either.
- A beta=0 cross-sign singleton likewise cannot match this positive sector. For other banks, beta=0 simply gives zero amplitudes in the positive sectors tested here.
- A zero plus-plus node contributes zero at all selected positive exponents. It cannot repair the gate. Repeated ordinary nodes may be merged by adding their sector amplitudes, even when beta differs. This only lowers the number of effective nodes.
- Padding an annihilator by powers of t need not preserve squarefreeness, but the gate only asserts a necessary nonzero kernel vector. It never uses this padded polynomial as a sufficient representation recipe.
- Ordinary repeated banks do not supply derivative or confluent atoms. For sufficiency in the common-node criterion, the squarefree guard really is required.

## 5. Exact 220-case output and reflection

The primitive roots tested are 2,3,4,6,8,9,12,13,16,18. For q=2 and y=1,...,22, respectively, the determinant list is

4,11,9,19,11,16,7,9,12,8,21,3,13,7,19,15,6,7,16,1,6,14.

All are nonzero. The nine singular pairs (q,y) are

(3,4), (4,10), (9,14), (12,7), (13,4), (13,15), (16,11), (18,2), (18,10).

Every singular matrix has rank five. In particular, the q=3,y=4 negative control is detected, so the checker does not accidentally assert nonsingularity for every primitive root.

Under (a,b,epsilon,delta) -> (-a,-b,-epsilon,-delta), both local indices r,ell and epsilon delta are unchanged. The target q^(3(a+b)^2) is unchanged. Hence simultaneous reflection exchanges plus-plus with minus-minus and minus-plus with plus-minus while preserving each alpha node. The checker verifies all 4,840 corresponding G identities. The reflected lower bound uses the same original grammar; no standalone one-coordinate reflection or pre/post matrix operation is introduced.

### Extension-field guard is essential

An invertible matrix over F23 remains invertible over every extension, so allowing same-sign nodes, beta, and amplitudes in an extension does not evade a nonsingular gate when q,y are the tested base-field values.

This is different from allowing the cross-sign singleton y itself to vary in an extension. The fresh checker also simplifies the q=2 gate to its determinant polynomial D(y) in F23[y]. It has degree 27, constant coefficient 5, and leading coefficient 12; its full ascending coefficient vector is in SUMMARY.json. It agrees with all 22 matrix determinants. Since D is nonconstant with nonzero constant, it has nonzero roots in an algebraic closure, each in a finite extension of F23. Thus there really are extension-field singleton values where this necessary gate is singular. These roots are not Fourier constructions, but they prohibit extending the all-y nonsingularity statement beyond F23*.

## 6. Independent sextic and subset enumerations

The source moment arrays are derived afresh from the original word factors and target, not taken as input constants:

H=16, T=9,
s=(1,17,2,0,5,11,18,10,14),
u=(9,11,11,20,12,15,19).

The four-by-four coefficient matrix A has determinant one. For each lambda,mu in F23, the checker solves for c_0,...,c_3 with c_4=lambda, c_5=mu, c_6=1, and verifies all four recurrence residuals are zero. Invertibility of A proves these 529 cases exhaust every monic sextic satisfying these four equations.

The counts by number of distinct nonzero base-field roots are:

- zero roots: 197 sextics
- one root: 198
- two roots: 101
- three roots: 26
- four roots: 7
- five or six roots: 0

Of the 529 sextics, 505 are squarefree. There are 407 with nonzero source exceptional product c_0 Res(g,g') D_0 D_3 D_4 D_5. The nonzero exceptional product is not base-field splitting; the absence of such splitting must not be used to exclude a splitting-field realization.

The second test does not use the affine solver. It independently forms product_(x in X)(t-x) for every six-element subset X of F23* and evaluates the four recurrences. Successive survivor counts are 3,219, 129, 8, and 0. The full CSV contains all 74,613 node sets, their seven polynomial coefficients, and all four residuals, including failed cases.

At lambda=mu=0 the checker independently recovers

g=t^6+4t^3+2t^2+21t+12,
Res(g,g')=6,
(D_0,D_3,D_4,D_5)=(5,3,18,8),
P(0,0)=17.

It reconstructs the selected full-rank solves, both edge-row formulas, and reflected rows, checking all 121 physical coefficient equations. The row ranks are

(11,8,10,11,11,11,11,11,11,10,8).

These supplementary controls check the source guard mechanism and normalization. They are not a new claim that the original characteristic-zero bank roots lie in F23 or Q(q).

## 7. Characteristic-zero and unrestricted boundaries

The fixed singleton-alpha=1 characteristic-zero obstruction is already present in the later source review and is preserved as historical acceptance. The fresh q=2,y=1 determinant four agrees with that historical control. This review does not re-certify, strengthen, or newly accept any characteristic-zero transfer or field/tower result.

The new 22-node modular enumeration is not a theorem for arbitrary complex singleton nodes, every characteristic-zero node, or every primitive root in characteristic 23. Nor can finite-field failure to split be promoted to failure to split over Q(q), much less to failure of the historical splitting-field construction. The source's distinction between exact finite-field diagnostics and its separate characteristic-zero arguments must remain visible.

No lower bound for arbitrary orientation allocations, unrestricted fourteen-bank optimality, minimum over all legal fields, asymptotic formula, FFT speedup, physical cost claim, or literature-priority claim is supported. The later all-order rank envelope and its other-order constructions were read for scope; this review does not re-certify those separate theorems.

## 8. Deliverables and replay

- fresh_signed_bank_check.py: independent executable checker, Python standard library only
- SUMMARY.json: exact headline output and determinant polynomial
- ALL_220_MATRICES.json: all matrices, sequences, forced amplitudes, denominators, ranks, and determinants
- ALL_529_SEXTICS.json: every parameter pair, coefficients, roots, resultant, selected minors, and exceptional product
- ALL_74613_SUBSETS.csv: every subset and all recurrence residuals
- BASEPOINT_ROW_SOLUTIONS.json: all eleven physical row matrices and solutions
- LITERAL_GRAMMAR_CONTROLS.json: direct original-resolvent controls
- RUN.log: exact printed summary followed by PASS
- MANIFEST.json: SHA-256 source and deterministic-output pins; the handwritten report is left for the outer packet seal. RUN.log is excluded from the inner manifest because stdout redirection is still open when the checker writes its manifest

Replay with Python 3 by running fresh_signed_bank_check.py. CANDIDATE_PACKET_DIR may point to a self-contained copy of the source candidate packet; its default is the specified original workspace packet. Results are written next to the fresh checker. No package install or network request is needed.

The enumeration counts are checker workload, not execution cost for a bank representation. A whole N11 bank still comprises eleven branch inverses and eleven raw phase weights.
