ALG049 rational cycle final factor extension
Independent acceptance packet
13 October 2026 UTC

VERDICT: ACCEPT. No mathematical repair is required.

The exact fixed N=8 two-factor prefix is excluded from scalar-unitary
completion by every invertible final factor with constant inverse-Gram
diagonal, with any unitary monomial at the last boundary. Spectrally regular
and invertible rational functions of uniform-modulus weighted Hamiltonian
cycles satisfy that condition. The first boundary is unchanged.

All four prefix sign pairs, both final K signs, quantitative bounds,
pole/zero guards, zero radius and N=1 exceptions, and both scope examples
are verified. The broad rational-cycle exclusion becomes false if arbitrary
unitary last separators are allowed; the stated construction is correct.

The general cycle lemma holds for all N>=1. The ALG049 obstruction remains
fixed-prefix N=8. This does not close unrestricted ALG049 or establish a
Fourier impossibility, FFT lower bound, novelty, or runtime claim.

Read INDEPENDENT_REVIEW.txt for the complete source-bound acceptance and
proof audit. INDEPENDENT_RESULTS.json records all 7,530 independent exact
assertions and derived data. VERIFICATION_LOG.txt contains the complete
successful run: 170.60 seconds wall time and 79,780 KiB peak RSS.

Original candidate preserved unchanged:
ALG049_Rational_Cycle_Final_Factor_Extension_Candidate_2026-10-13.zip
SHA-256 d1716e7f5b33eb087124e125f2a348dae72f5f3674b2c7765846308c9e625367

Reproduce with Python 3 and SymPy 1.14.0, from this directory:
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout 300s python3 review_fresh.py

The fresh verifier reads candidate data only. No historical program was
executed or imported. All mathematical decisions use exact arithmetic.
Limits: 240 CPU seconds, 2 GiB address space, 300 external wall seconds,
and one BLAS/OMP thread. Runtime measurements are provenance only.

No network calls, dependency installations, Sheet writes, or GitHub writes
were made. The external seal identifies this review ZIP by bytes and
SHA-256; REVIEW_MANIFEST.json hashes every enclosed file except itself.
