#!/usr/bin/env python3
"""Independent exact audit. Candidate files are read as bytes/data only."""
from pathlib import Path
from collections import Counter
from io import BytesIO
import hashlib, json, resource, sys, time, zipfile
import sympy as s

HERE = Path(__file__).resolve().parent
START = time.monotonic()
resource.setrlimit(resource.RLIMIT_CPU, (240, 240))
resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
COUNTS = Counter()
RECORDS = {}

def require(group, test):
    if not test:
        raise AssertionError(group)
    COUNTS[group] += 1

def scalar_zero(x):
    return s.cancel(s.expand(x)) == 0

def matrix_equal(group, a, b):
    require(group + '_shape', a.shape == b.shape)
    for x, y in zip(a, b):
        require(group + '_entry', scalar_zero(x-y))

def clean(a):
    return a.applyfunc(s.cancel)

def eval_poly(coeff, q):
    # Horner evaluation, including arbitrary degree.
    out = s.zeros(q.rows)
    for v in reversed(coeff):
        out = clean(q*out + v*s.eye(q.rows))
    return out

def from_edges(n, edges):
    a = s.zeros(n)
    for source, destination, weight in edges:
        a[destination, source] = weight
    return a

def cyc(order, weights):
    return from_edges(len(order), [(order[j], order[(j+1)%len(order)], weights[j]) for j in range(len(order))])

def norm2(x):
    return s.cancel(s.conjugate(x)*x)

def col_norm(a,j):
    return s.cancel(sum(norm2(a[k,j]) for k in range(a.rows)))

def inverse_by_path_coefficients(q, inverse):
    # Recover the unique degree <N polynomial from only column 0,
    # then reconstruct its entire matrix independently.
    n=q.rows
    path=s.eye(n)[:,0]
    h=[]
    for k in range(n):
        location=next(j for j in range(n) if path[j] != 0)
        h.append(s.cancel(inverse[location,0]/path[location]))
        path=clean(q*path)
    return h

# Cryptographic identity and complete candidate contents.
archive=HERE/'ALG049_Rational_Cycle_Final_Factor_Extension_Candidate_2026-10-13.zip'
raw=archive.read_bytes()
require('candidate_zip_hash', hashlib.sha256(raw).hexdigest() == 'd1716e7f5b33eb087124e125f2a348dae72f5f3674b2c7765846308c9e625367')
require('candidate_zip_bytes', len(raw) == 167527)
with zipfile.ZipFile(BytesIO(raw)) as zf:
    names=zf.namelist()
    require('unique_archive_names', len(names)==len(set(names)))
    require('safe_archive_names', all(not p.startswith('/') and '..' not in Path(p).parts for p in names))
    manifest=json.loads(zf.read('MANIFEST.json'))
    for record in manifest['files']:
        data=zf.read(record['path'])
        require('candidate_member_bytes', len(data)==record['bytes'])
        require('candidate_member_hash', hashlib.sha256(data).hexdigest()==record['sha256'])
    require('complete_candidate_manifest', set(names)=={r['path'] for r in manifest['files']}|{'MANIFEST.json'})
    for pin in json.loads(zf.read('SOURCE_PINS.json'))['sources']:
        data=zf.read(pin['path'])
        require('source_pin_bytes', len(data)==pin['bytes'])
        require('source_pin_hash', hashlib.sha256(data).hexdigest()==pin['sha256'])
    prior=zf.read('pinned_sources/ALG049_Two_Independent_Phases_Independent_ACCEPT_2026-10-13.zip')
    require('prior_acceptance_pin', hashlib.sha256(prior).hexdigest()=='06466cfce5d6c24e85025d73b716d8f810da435cc51c5a2a70795a17976f2a78')
    with zipfile.ZipFile(BytesIO(prior)) as nested:
        require('pinned_review_exact_source', nested.read('INDEPENDENT_REVIEW.txt')==zf.read('pinned_sources/TWO_PHASE_INDEPENDENT_REVIEW.txt'))
        candidate_two=nested.read('ALG049_Two_Independent_Phases_Candidate_2026-10-13.zip')
        with zipfile.ZipFile(BytesIO(candidate_two)) as deeper:
            require('pinned_proof_exact_source', deeper.read('PROOF.md')==zf.read('pinned_sources/TWO_PHASE_PROOF.md'))
    author_data=json.loads(zf.read('EXACT_CHECKS.json'))
    require('author_count_arithmetic', sum(author_data['check_counts'].values())==author_data['total_checks']==4198)
RECORDS['source']={'archive':archive.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'members':len(names),'prior_sha256':hashlib.sha256(prior).hexdigest()}
print('PASS source archive, manifests, pins and source prose ancestry',flush=True)

# Prefix reconstructed through a polynomial remainder identity rather than
# importing the candidate implementation or its direct inversion strategy.
z=s.Symbol('z', nonzero=True)
q1=from_edges(8,[(j,(j+1)%8,-1 if j==7 else 1) for j in range(8)])
q2=from_edges(8,[(0,1,z),(1,3,1),(3,4,1),(4,5,1),(5,6,1),(6,2,1),(2,7,1/z),(7,0,-1)])
I8=s.eye(8)
t=s.Symbol('t')
K={}
for index,q in enumerate((q1,q2)):
    matrix_equal('prefix_power', q**8, -I8)
    matrix_equal('prefix_unitarity',q.T.subs(z,1/z)*q,I8)
    require('prefix_charpoly',scalar_zero(q.charpoly(t).as_expr()-t**8-1))
    require('prefix_resolvent_determinant',s.cancel((I8-q).det())==2)
    require('prefix_numerator_determinant',s.cancel((2*I8-q).det())==257)
    plus=eval_poly([s.Rational(3,2)]+[s.Rational(1,2)]*7,q)
    minus=eval_poly([s.Rational(129,257)]+[-s.Rational(2**(7-k),257) for k in range(1,8)],q)
    matrix_equal('primitive_defining_equation',plus*(I8-q),2*I8-q)
    matrix_equal('primitive_two_sided_inverse',plus*minus,I8)
    matrix_equal('primitive_reverse_inverse',minus*plus,I8)
    K[index]={'+':plus,'-':minus}

expected={
    '--':(s.Rational(443686,16974593),-s.Rational(377300,16974593),s.Rational(66386,16974593)),
    '-+':(-s.Rational(57,257),s.Rational(15,257),s.Rational(42,257)),
    '+-':(-s.Rational(35657,66049),s.Rational(28474,66049),s.Rational(7183,66049)),
    '++':(s.Integer(4),s.Integer(-1),s.Integer(3))}
prefix={}
Ts={}
for word,(A,B,d) in expected.items():
    T=clean(K[0][word[0]]*K[1][word[1]])
    Ts[word]=T
    # Compute only the two column norms used in the proof, independently of
    # the full Gram expansion in the author code.
    def unit_column_norm(j):
        return s.cancel(sum(T[k,j].subs(z,1/z)*T[k,j] for k in range(8)))
    delta=s.cancel(unit_column_norm(3)-unit_column_norm(0))
    require('prefix_laurent_identity', scalar_zero(delta-A-B*(z+1/z)/2))
    require('prefix_endpoint_same_sign',(A-B)*(A+B)>0)
    require('prefix_absolute_bound',min(abs(A-B),abs(A+B))==d and d>0)
    prefix[word]={'constant':str(A),'real_z_coefficient':str(B),'absolute_lower_bound':str(d),'laurent_delta':str(delta)}
RECORDS['prefix_certificates']=prefix
print('PASS all four fresh symbolic prefix certificates and strict bounds',flush=True)

# Formal polynomial ring checks, free complex parameters and monodromy.
a,b,mu=s.symbols('a b mu')
for n in range(1,21):
    R=sum(a**(n-1-j)*t**j for j in range(n))
    require('formal_geometric_identity',s.expand((a-t)*R-(a**n-t**n))==0)
    G=a*b**(n-1)-mu+(a-b)*sum(b**(n-1-j)*t**j for j in range(1,n))
    require('formal_mobius_modulus_identity',s.rem(s.expand((b-t)*G-(a-t)*(b**n-mu)),t**n-mu,t)==0)

# Fresh phases/radii/orders are different from the author's finite controls.
phases=[s.I,-1,s.Rational(8,17)+s.I*s.Rational(15,17),s.Rational(7,25)-s.I*s.Rational(24,25)]
cycle_results=[]
selected=None
for n in range(1,10):
    rho=s.Rational(2,3) if n%2 else s.Rational(4,3)
    order=list(reversed(range(n)))
    weights=[s.expand(rho*phases[(j*3+n)%4]) for j in range(n)]
    q=cyc(order,weights); ident=s.eye(n); mon=s.cancel(s.prod(weights))
    require('new_phase_unit_moduli',all(norm2(w)==rho**2 for w in weights))
    matrix_equal('cycle_normality',q.H*q,rho**2*ident)
    matrix_equal('cycle_reverse_normality',q*q.H,rho**2*ident)
    matrix_equal('cycle_monodromy',q**n,mon*ident)
    require('cycle_characteristic_polynomial',scalar_zero(q.charpoly(t).as_expr()-(t**n-mon)))
    powers=[q**k for k in range(n)]
    for j in range(n):
        support=[]
        for k in range(n):
            locations=[r for r in range(n) if powers[k][r,j]!=0]
            require('path_unique_support',len(locations)==1)
            support.append(locations[0])
            require('path_column_norm',col_norm(powers[k],j)==rho**(2*k))
        require('disjoint_path_support',len(set(support))==n)
    # Directly invert aI-Q and check formulas (4), (5), (6).
    for av in [s.Integer(0),s.Integer(1),s.Integer(2),1+s.I]:
        mat=av*ident-q
        require('direct_determinant_guard',scalar_zero(mat.det()-(av**n-mon)))
        require('fresh_resolvent_guard',not scalar_zero(av**n-mon))
        inv=clean(mat.inv(method='DM'))
        coeff=[s.cancel(av**(n-1-k)/(av**n-mon)) for k in range(n)]
        matrix_equal('resolvent_polynomial',inv,eval_poly(coeff,q))
        gamma=s.cancel(sum(norm2(v)*rho**(2*k) for k,v in enumerate(coeff)))
        for j in range(n):
            require('shifted_cycle_inverse_gram',col_norm(inv,j)==gamma)
            target=norm2(av-mon) if n==1 else norm2(av)+rho**2
            require('resolvent_inverse_gram',col_norm(mat,j)==target)
    # Actual K, both signs, complex shifts, zero numerator, zero denominator
    # and a=b are represented. All current fresh radii avoid singular guards.
    for av,bv in [(2,1),(1+s.I,3),(0,1),(3,0),(3,3)]:
        require('mobius_both_guards',not scalar_zero(av**n-mon) and not scalar_zero(bv**n-mon))
        C=clean((av*ident-q)*(bv*ident-q).inv(method='DM'))
        Ci=clean(C.inv(method='DM'))
        c=[s.cancel((av*bv**(n-1)-mon)/(bv**n-mon))]+[s.cancel((av-bv)*bv**(n-1-k)/(bv**n-mon)) for k in range(1,n)]
        matrix_equal('mobius_forward_coefficients',C,eval_poly(c,q))
        gamma=s.cancel((norm2(bv*av**(n-1)-mon)+norm2(bv-av)*sum(norm2(av)**(n-1-k)*rho**(2*k) for k in range(1,n)))/norm2(av**n-mon))
        for j in range(n):
            require('mobius_inverse_gram_constant',scalar_zero(col_norm(Ci,j)-gamma))
        if av==2 and bv==1:
            gplus=s.cancel((norm2(2**(n-1)-mon)+sum(4**(n-1-k)*rho**(2*k) for k in range(1,n)))/norm2(2**n-mon))
            gminus=s.cancel((norm2(2-mon)+sum(rho**(2*k) for k in range(1,n)))/norm2(1-mon))
            require('K_explicit_constant',gamma==gplus)
            for j in range(n):
                require('K_inverse_sign_constant',col_norm(C,j)==gminus)
    # Higher-degree rational factor: reconstruct its inverse from the
    # first column, not from the candidate's Euclidean modular inverse.
    p=[5,0,1,1+s.I]; den=[7,-s.I,0,0,1]
    P=eval_poly(p,q); D=eval_poly(den,q)
    require('rational_pole_guard',D.det()!=0)
    require('rational_zero_guard',P.det()!=0)
    C=clean(P*D.inv(method='DM')); Ci=clean(C.inv(method='DM'))
    h=inverse_by_path_coefficients(q,Ci)
    matrix_equal('rational_inverse_path_reconstruction',Ci,eval_poly(h,q))
    pp=sum(v*t**k for k,v in enumerate(p)); ss=sum(v*t**k for k,v in enumerate(den)); hh=sum(v*t**k for k,v in enumerate(h))
    require('rational_bezout_residue',s.Poly(s.rem(hh*pp-ss,t**n-mon,t),t).is_zero)
    gamma=s.cancel(sum(norm2(v)*rho**(2*k) for k,v in enumerate(h)))
    require('rational_gamma_positive',gamma>0)
    for j in range(n):
        require('rational_inverse_gram_constant',col_norm(Ci,j)==gamma)
    if n==8:
        selected=(C,Ci,gamma)
    cycle_results.append({'dimension':n,'radius':str(rho),'order':order,'weights':[str(w) for w in weights],'monodromy':str(mon),'rational_inverse_coefficients':[str(v) for v in h],'rational_gamma':str(gamma)})
    print('PASS fresh weighted cycle N='+str(n),flush=True)
RECORDS['cycle_controls']=cycle_results

# Explicit pole/zero/removable-pole guards and zero-radius boundary.
for n in [1,2,8]:
    ident=s.eye(n); P=cyc(list(range(n)),[1]*n)
    for rho in [s.Integer(0),s.Integer(1),s.Integer(2)]:
        q=rho*P
        for av in [0,1,2]:
            require('boundary_determinant', (av*ident-q).det()==av**n-rho**n)
        if rho==0:
            K0=(2*ident-q)*(ident-q).inv()
            matrix_equal('zero_radius_K',K0,2*ident)
            for j in range(n):
                require('zero_radius_K_gamma',col_norm(K0.inv(),j)==s.Rational(1,4))
                require('zero_radius_K_inverse_gamma',col_norm(K0,j)==4)
            # The rational factor reduces to p(0)/s(0).
            C0=eval_poly([5,0,1,1+s.I],q)*eval_poly([7,-s.I,0,0,1],q).inv()
            matrix_equal('zero_radius_rational',C0,s.Rational(5,7)*ident)
            require('zero_radius_rational_gamma',col_norm(C0.inv(),0)==s.Rational(49,25))
        elif rho==1:
            require('K_pole_guard_singular',(ident-q).det()==0)
            require('removable_expression_literal_singular',(ident-q).rank()<n)
            # Reduced rational (t-1)/(t-1)=1 gives I, unlike literal 0 inverse.
            require('cancelled_regular_rational',s.cancel((t-1)/(t-1))==1)
        else:
            require('K_zero_guard_denominator_regular',(ident-q).det()!=0)
            C=(2*ident-q)*(ident-q).inv()
            require('K_zero_guard_singular',C.det()==0 and C.rank()<n)
    require('genuine_pole_gcd',s.degree(s.gcd(t-1,t**n-1),t)>0)
    require('genuine_zero_gcd',s.degree(s.gcd(t-2,t**n-2**n),t)>0)
require('accepted_K_constant',s.Rational(129**2+sum(4**j for j in range(7)),257**2)==s.Rational(86,257))
require('accepted_K_inverse_constant',s.Rational(9+7,4)==4)

# Last-boundary full congruence, using nontrivial permutation and phases.
C,Ci,gamma=selected
S=s.zeros(8)
for j in range(8): S[(3*j+1)%8,j]=[1,s.I,-1,-s.I][j%4]
matrix_equal('separator_unitarity',S*S.H,I8)
H=clean(Ci.H*Ci); SH=clean(S*H*S.H)
for j in range(8): require('monomial_constant_diagonal',SH[j,j]==gamma)
z0=s.Rational(20,29)+s.I*s.Rational(21,29)
for word,Tsymbolic in Ts.items():
    T=clean(Tsymbolic.subs(z,z0)); L=clean(T.H*T); B=clean(T*S*C)
    for cv in [s.Integer(-2),s.Integer(0),s.Rational(7,3)]:
        E=clean(B.H*B-cv*I8)
        pulled=clean(S*Ci.H*E*Ci*S.H)
        matrix_equal('quantitative_congruence',pulled,L-cv*SH)
        require('quantitative_diagonal_witness',scalar_zero(pulled[3,3]-pulled[0,0]-(L[3,3]-L[0,0])))
        require('quantitative_strict_witness',abs(L[3,3]-L[0,0])>=expected[word][2])
    require('product_not_scalar_unitary',any(not scalar_zero(v) for v in B.H*B-(B.H*B)[0,0]*I8))
# Sharpness of universal diagonal extraction constants 2 and sqrt(2).
d=s.Rational(7,11); D=s.diag(-d/2,d/2)
require('spectral_diagonal_extraction_sharp',D[1,1]-D[0,0]==2*max(abs(D[0,0]),abs(D[1,1])))
require('frobenius_diagonal_extraction_sharp',(D[1,1]-D[0,0])**2==2*sum(norm2(v) for v in D))
print('PASS full congruence and quantitative witness controls',flush=True)

# Original N=8 scope examples, now direct exact numerical reconstruction.
Q=cyc(list(range(8)),[2,s.Rational(1,2),1,1,1,1,1,-1])
Ci=(I8-Q).inv(); nu=[col_norm(Ci,j) for j in range(8)]
require('nonuniform_counterexample_values',nu==[s.Rational(11,4),s.Rational(11,16)]+[s.Rational(11,4)]*6)
Q=cyc(list(range(8)),[s.Rational(1,2)]*8)
Ci=(I8-Q).inv(); H=Ci.H*Ci
R=I8.copy(); R[:2,:2]=s.Matrix([[s.Rational(3,5),s.Rational(4,5)],[-s.Rational(4,5),s.Rational(3,5)]])
matrix_equal('nonmonomial_separator_unitary',R*R.H,I8)
require('nonmonomial_H00',H[0,0]==s.Rational(1028,765))
require('nonmonomial_H01',H[0,1]==s.Rational(104,153))
rot=R*H*R.H
require('nonmonomial_new_diagonals',rot[0,0]==s.Rational(7636,3825) and rot[1,1]==s.Rational(2644,3825))
RECORDS['scope_examples']={'nonuniform_inverse_gram':[str(v) for v in nu],'uniform_H00':str(H[0,0]),'uniform_H01':str(H[0,1]),'unitary_rotated_first_diagonals':[str(rot[j,j]) for j in range(2)]}

# An exact nontrivial N=8 construction corroborates the arbitrary-unitary
# separator counterexample without a numerical SVD or eigensolver.
# F has entries omega^(-jk)/sqrt(8), lambda_k=omega^k for forward P.
w=(1+s.I)/s.sqrt(2)
F=s.Matrix(8,8,lambda j,k:s.expand_complex(w**((-j*k)%8))/s.sqrt(8))
F=F.applyfunc(s.simplify)
P=cyc(list(range(8)),[1]*8)
lam=[s.simplify(w**k) for k in range(8)]
matrix_equal('Fourier_control_unitarity',F.H*F,I8)
matrix_equal('Fourier_cycle_diagonalization',P*F,F*s.diag(*lam))
D=s.diag(*[s.Integer(k) for k in range(1,9)])
V=R; W=S
T=V*D*W.H; separator=W*F.H
# Interpolant coefficients are inverse DFT of positive spectral data.
h=[s.simplify(sum(s.Rational(1,k+1)*lam[k]**(-j) for k in range(8))/8) for j in range(8)]
Cp=eval_poly(h,P).applyfunc(s.simplify)
matrix_equal('interpolated_cycle_factor',Cp,(F*D.inv()*F.H).applyfunc(s.simplify))
matrix_equal('arbitrary_unitary_separator_control',separator*separator.H,I8)
matrix_equal('unitary_completion_control',(T*separator*Cp).applyfunc(s.simplify),(V*F.H).applyfunc(s.simplify))
require('unitary_completion_separator_nonmonomial',any(sum(v!=0 for v in separator.row(j))>1 for j in range(8)))
RECORDS['arbitrary_unitary_completion']={'dimension':8,'singular_values':list(range(1,9)),'polynomial_coefficients':[str(v) for v in h],'exact_identity':'T S C = V F*','applies_to_fixed_prefix_by_proof':True}
print('PASS both scope examples and exact N=8 interpolated unitary completion',flush=True)

RECORDS['verdict']='ACCEPT'
RECORDS['counts']=dict(sorted(COUNTS.items()))
RECORDS['total_exact_checks']=sum(COUNTS.values())
RECORDS['resources']={'python':sys.version,'sympy':s.__version__,'wall_seconds':time.monotonic()-START,'user_cpu_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cpu_cap_seconds':240,'address_space_cap_bytes':2*1024**3,'historical_programs_executed_or_imported':False,'floating_point_mathematical_decisions':False,'network_calls':False}
(HERE/'INDEPENDENT_RESULTS.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
print(json.dumps({'verdict':'ACCEPT','total_exact_checks':RECORDS['total_exact_checks'],'resources':RECORDS['resources']},indent=2),flush=True)
