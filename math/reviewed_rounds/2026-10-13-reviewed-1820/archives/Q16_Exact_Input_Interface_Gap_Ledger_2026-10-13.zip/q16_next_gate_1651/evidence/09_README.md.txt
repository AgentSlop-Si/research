# Q16: fresh, bounded executable conformance harness

13 October 2026. Private research deliverable. Standard-library Python 3.12.

## Result

A new executable closes a narrowly scoped gap: exact parameter/normalization
components and a certified dense Fourier path for feasible lengths now have
source-pinned tests against a separately authored rational-interval reference.
The final results are in `results/checks.json`; the code does not load or run any
historical program. The all-length theorem and the missing historical checker
are not replaced or re-reviewed here.

Run from this directory:

    python3 tests/run_checks.py
    python3 verify_package.py

`run_checks.py` rewrites its result receipts. The package seal describes the
included run; a rerun may differ in elapsed time and platform metadata and
therefore invalidate the old result-file hashes. Verify the delivered seal
before rerunning, or keep the rerun in a copy.

## What actually runs

- Exact rational ceilings, integer power-of-two embedding length, every stated
  outer branch guard, word/precision formulas, support/workload bounds, and
  amplification budgeting.
- One paid max-component scan; exact zero/identity paths; strict normalization
  and centered implicit-zero source adapter.
- A deterministic dense transform for 2 <= N <= 32 with paid root/scale
  preparation, fixed finite scalar loops, exact integer complex products/sums,
  signed nearest-even final rounding, and exact power-of-two scale-back.
- Separate small combinatorial fixtures for affine bit draws, hash fibers,
  magnitude ties, voting and Cartesian medians.
- Injected failed-output envelope checks and exact signed row accumulation
  using supplied coefficient fixtures, not generated transfer coefficients.

## What does not run

No sparse filter/tap construction, sparse bucket FFT, integrated E(beta)
recovery, active interpolation coefficient generator, global tensor engine, or
full amplified sparse-to-dense path is implemented. The 4096-bit length case
executes only integer parameter arithmetic; it allocates no length-M vector,
consumes no giant random tape, and performs no sparse transform. No statistical
experiment certifies the theorem's universal probability guarantee.

The public `execute` function raises `NotImplementedError` for an unsupported
sparse branch or a dense nonzero length above 32. These are explicit limitations
of this test harness. They are not claimed to be allowable aborts in the
accepted all-length algorithm. Thus this package is not a total all-length
implementation or a complete integrated-conformance certificate.

## Concrete defects caught by controls

1. For A = 2^53+1, a floating log2/ceiling gives k0 = 53 on this host. The exact
   answer is 54. The float result violates the required normalized component
   bound <= 1. Integer `(A-1).bit_length()` avoids this defect.
2. For beta = 1/4 + 2^-60 and m = 4, converting beta to float changes
   ceil(2 beta m) from 3 to 2. Exact rational ceilings avoid this defect.
3. Signed half rounding, closed-vs-half-open fibers and a reversed Fourier sign
   have additional deliberately bad controls.

These are demonstrated implementation traps, not allegations about unavailable
historical source and not counterexamples to the accepted theorem.

## Certified dense numerics

The production scalar code works on outward integer intervals on grid 2^-K,
where Q = 16m+16, K = Q+64. Roots and scale are rounded to grid 2^-(Q+4).
Pi uses 16 atan(1/5) - 4 atan(1/239), each with exactly K+4 alternating-series
terms and a next-term tail enclosure. Sine and cosine use K+4 terms, outward
fixed-grid interval arithmetic, and factorial Taylor remainder bounds after
exact rational argument reduction to magnitude below 4. Reciprocal square
root uses integer-square-root bracketing. No floating trigonometric routine is
used. Each prepared root's squared complex error bound is checked against
2^-2Q before it can be used; the scale bound is checked against 2^-Q.

The independent oracle uses 4[atan(1/2)+atan(1/3)], uncentered angles, a complex
exponential Taylor recurrence over Fraction intervals, and fixed-depth
bisection for reciprocal square root. It shares no scalar/rounding code with
the implementation. It encloses exact negative-sign unitary DFT values. Exact
axis roots at N=1,2,4 provide additional oracle controls.

Each tested dense output is enclosed relative to the reference and is checked
against the specified absolute normalized bound 7N*2^-Q, using squared rational
inequalities. This is an actual numerical certificate for those coordinates,
not ordinary floating-point agreement. The fixed precision/iteration choices
have not received a universal all-m source-level proof in this package.

## Cost and model boundary

`results/dense_cases.json` includes each fixture's input/output numerators,
exponents, m/Q/K, and semantic operation ledger. Setup is charged anew on every
production call. Counters include all N roots, the reciprocal scale, every
scalar loop, N^2 exact complex terms and normalized source reads, the input
scan, final rounds and output fields. There is no free norm oracle or uncharged
root table in the tested path. The reference may cache its own results; that
cache is outside the algorithm being measured.

The counted arithmetic has a conservative operand-size proxy, rather than
unit-cost arbitrary precision. Integer bit lengths are observed. This is not
an exact Python instruction count, memory allocator measurement, binary
serializer, peak-live-memory proof, or full growing-word simulator. Parameter
construction is counted as a semantic operation; its individual Python/Fraction
steps are not primitive-instrumented. Factorial, exponentiation, index arithmetic
and loop bookkeeping are not each decomposed into growing-word instructions.
The complete cost claim remains a gap, explicitly recorded in `COVERAGE.json`
and `RESOURCE_LEDGER.md`. No O(N) bit-work or practical speed claim is made.

## Next concrete implementation step

Implement and certify the E(beta) compact-window preparation component:
exact sliding-window convolution coefficients, common-grid normalizer C,
sine-ratio D_H taps with exact zero limits, and the M*F_t*D_H/C normalization.
Use reduced component fixtures to compare direct exact/rational-interval
Fourier responses and the identity (1/M) sum_t w_t omega^(-jt) = G_j, while
keeping those fixtures distinct from a theorem-parameter sparse run. It should
reuse the finite scalar foundation only after proving the extra division/power
error budget and counting all preparation. This targets the first missing
numerical dependency before building a complete bucket/recovery engine.

No external sheet, repository, publication or third-party communication was
changed by this work. The archive is saved only to the user's private Library.
