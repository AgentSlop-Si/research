"""New exact controls of the materialization lemma; no scientific imports.

The tuple model below is not a production DyadicSource constructor, parser,
source-level cost certificate, or execution of the sparse Fourier pipeline.
"""
from pathlib import Path
from itertools import product
from collections import Counter
import hashlib
import json

counts=Counter()

def check(condition, category):
    if not condition:
        raise AssertionError(category)
    counts[category]+=1

def materialize(rows,e,d):
    N=len(rows)
    m=(4*N-1).bit_length(); M=1<<m
    A=max(abs(x) for pair in rows for x in pair)
    if not A:
        return None,(N,m,M,0,-e)
    k=(A-1).bit_length(); a0=(N-1)//2
    vals=[]
    for r in range(M):
        j=r+a0
        if j>=M:
            j-=M
        a,b=rows[j] if j<N else (0,0)
        vals.append(((a,k),(b,k)))
    return tuple(vals),(N,m,M,k,k-e)

def verify(rows,e,d):
    frozen=tuple(tuple(p) for p in rows)
    values,meta=materialize(rows,e,d)
    N,m,M,k,l=meta
    check(4*N<=M<8*N,'embedding_length')
    check(0<=e<=d*m,'input_exponent_domain')
    check(all(abs(x)<=1<<(d*m) for p in frozen for x in p),'input_numerator_domain')
    A=max(abs(x) for p in frozen for x in p)
    if values is None:
        check(all(x==0 for p in frozen for x in p),'zero_branch')
        return
    check(type(values) is tuple and len(values)==M,'outer_tuple')
    check(0<=k<=d*m and -d*m<=l<=d*m,'exponent_value_bounds')
    # Independent minimum-power oracle, deliberately no bit_length.
    oracle=0
    while (1<<oracle)<A:
        oracle+=1
    check(k==oracle,'exact_log_boundary')
    sq=sum(a*a+b*b for a,b in frozen)
    check(4*sq>(1<<(2*k)),'strict_norm_half')
    check(sq<=2*N*(1<<(2*k)),'norm_upper')
    a0=(N-1)//2
    occupied={}
    for j,pair in enumerate(frozen):
        residue=(j-a0)%M
        check(residue not in occupied,'injective_centering')
        occupied[residue]=pair
        check(2*abs(j-a0)<=N,'centered_support')
    for r,cell in enumerate(values):
        expected=occupied.get(r,(0,0))
        check(type(cell) is tuple and len(cell)==2,'complex_cell')
        check((cell[0][0],cell[1][0])==expected,'inverse_center_mapping')
        for component,expected_n in zip(cell,expected):
            check(type(component) is tuple and len(component)==2,'dyadic_cell')
            n,exponent=component
            check(type(n) is int and type(exponent) is int,'integer_fields')
            check(exponent==k and abs(n)<=1<<exponent,'global_source_validity')
            # lambda * n / 2^k = n / 2^e, checked by nonnegative shifts.
            left_exp=l+e
            check(left_exp==k,'scale_exponent_identity')
            check(n==expected_n,'exact_scale_numerator')
    if all(type(p) is list for p in rows):
        before=values
        for p in rows:
            p[:]=[1234567,-7654321]
        check(values==before and values==materialize(frozen,e,d)[0],'copy_isolation')

for N in range(1,5):
    m=(4*N-1).bit_length()
    for fields in product((-1,0,1),repeat=2*N):
        rows=[[fields[2*j],fields[2*j+1]] for j in range(N)]
        verify(rows,0,1)
        counts['exhaustive_input_vectors']+=1

for N in range(1,258):
    m=(4*N-1).bit_length()
    for d in (1,2,3):
        maxima=sorted({1,2,3,1<<(d*m),(1<<(d*m))-1,(1<<(d*m-1))+1})
        for A in maxima:
            if A>1<<(d*m):
                continue
            for e in (0,d*m):
                rows=[[0,0] for _ in range(N)]
                rows[0]=[A,-A]
                rows[-1][1]=-A
                verify(rows,e,d)
                counts['boundary_input_vectors']+=1

# Symbolic widths only: no huge vectors and no huge exponent values are built.
for m in (54,64,128,512,4096):
    for A in (1<<(m-1),(1<<(m-1))+1,(1<<m)-1,1<<m):
        k=(A-1).bit_length()
        check(A<=1<<k and (k==0 or A>1<<(k-1)),'large_exact_power_boundary')

here=Path(__file__).resolve().parent
result={'status':'PASS','counts':dict(sorted(counts.items())),
        'total_checked_assertions':sum(v for k,v in counts.items() if not k.endswith('_input_vectors')),
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':'Fresh tuple-model controls only. No accepted/historical scientific source imported or executed. No FFT, sparse recovery, production DyadicSource constructor or probability experiment executed.'}
(here/'CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
