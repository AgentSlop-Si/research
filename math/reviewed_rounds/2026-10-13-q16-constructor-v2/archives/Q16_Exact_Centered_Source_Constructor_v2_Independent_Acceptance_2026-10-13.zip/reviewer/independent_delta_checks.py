"""Fresh v2 delta audit: source/AST data and independent boundary model only.
No candidate, producer, historical or previous reviewer program is executed.
"""
import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
checks=0

def check(condition,label):
    global checks
    checks+=1
    if not condition: raise AssertionError(label)

def sha(data): return hashlib.sha256(data).hexdigest()

def read_zip(data,pin):
    check(sha(data)==pin,'archive hash')
    z=zipfile.ZipFile(io.BytesIO(data))
    check(z.testzip() is None,'CRC')
    check(len(z.namelist())==len(set(z.namelist())),'unique members')
    return z

v2data=(ROOT/'evidence/Q16_Exact_Centered_Source_Constructor_Candidate_v2_2026-10-13.zip').read_bytes()
v2=read_zip(v2data,'5efa51f2293e57550458c1ededa93e5dd437f676bb3be23941d8b36c0bdcb181')
manifest=json.loads(v2.read('MANIFEST.json'))['files']
check(set(v2.namelist())==set(manifest)|{'MANIFEST.json'},'exact v2 member inventory')
for name,rec in manifest.items():
    data=v2.read(name)
    check(len(data)==rec['bytes'] and sha(data)==rec['sha256'],'member '+name)
for rec in json.loads(v2.read('SOURCES.json'))['sources']:
    data=v2.read(rec['frozen_copy'])
    check(len(data)==rec['bytes'] and sha(data)==rec['sha256'],'provenance '+rec['frozen_copy'])
v1=read_zip(v2.read('evidence/V1_CANDIDATE.zip'),'a837bf0dfc376a6914e6fa3e75d10323766be41202a30e240eb85ccb2e446ae9')
prior=read_zip(v2.read('evidence/V1_REPAIR_REVIEW.zip'),'3d21101d48a0a43d9981e64dfab7652cf0346a0e891186f53927417605fbb1a6')
check(prior.read('INDEPENDENT_REVIEW.md')==v2.read('evidence/V1_INDEPENDENT_REPAIR_REVIEW.md'),'prior report bytes')
check(prior.read('evidence/Q16_Exact_Centered_Source_Constructor_Candidate_2026-10-13.zip')==v2.read('evidence/V1_CANDIDATE.zip'),'reviewed v1 exact archive')
old=v1.read('src/exact_source.py')
new=v2.read('src/exact_source.py')
check(sha(new)=='8334e657dd0048bdb91459e5f6e126080c7513d341ef3d17665b05422a8bbada','v2 constructor hash')
repairs=[(b'type(values) not in (tuple, list)',b'type(values) is not tuple and type(values) is not list'),
         (b'type(pair) not in (tuple, list)',b'type(pair) is not tuple and type(pair) is not list')]
expected=old
for before,after in repairs:
    check(expected.count(before)==1,'unique requested old guard')
    expected=expected.replace(before,after)
check(expected==new,'entire production delta is exactly two guard replacements')
changed_lines=[i for i,(a,b) in enumerate(zip(old.splitlines(),new.splitlines()),1) if a!=b]
check(changed_lines==[102,138] and len(old.splitlines())==len(new.splitlines()),'exact line delta')
for name in ['INPUT_CONTRACT.md','RESOURCE_LEDGER.md','tests/check_constructor.py','tests/check_mutations.py',
             'tests/check_metadata.py','tests/check_ledger_formulas.py','results/CONTROLS.json',
             'results/LEDGER_FORMULAS.json','results/METADATA.json','results/MUTATIONS.json']:
    check(v1.read(name)==v2.read(name),'unchanged '+name)
for name in v1.namelist():
    if name.startswith('evidence/'):
        check(v1.read(name)==v2.read(name),'unchanged scientific evidence '+name)

# AST data is parsed, not compiled into executable code or interpreted.
tree=ast.parse(new.decode())
funs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
comparisons=[n for n in ast.walk(tree) if isinstance(n,ast.Compare) and
             any(isinstance(c,ast.Call) and isinstance(c.func,ast.Name) and c.func.id=='type' for c in ast.walk(n))]
expected_guards=['type(values) is not tuple','type(values) is not list','type(pair) is not tuple','type(pair) is not list',
                 'type(d) is not int','type(exponent) is not int','type(real) is not int','type(imag) is not int']
check(sorted(ast.unparse(n) for n in comparisons)==sorted(expected_guards),'complete type boundary inventory')
check(all(all(isinstance(op,ast.IsNot) for op in n.ops) for n in comparisons),'all identity-only operators')
check(not any(isinstance(n,(ast.In,ast.NotIn)) for n in ast.walk(tree)),'no membership comparisons remain')
header=funs['_header']; body=header.body
check(ast.unparse(body[0].test)=='type(values) is not tuple and type(values) is not list','outer reject first')
check(ast.unparse(body[1])=='N = len(values)','length only after outer identity')
check(ast.unparse(body[3].test)=='type(d) is not int or d < 1','d short-circuit rejection before comparison')
check(ast.unparse(body[4].test)=='type(exponent) is not int','exponent identity before comparisons')
scan=next(n for n in funs['_construct'].body if isinstance(n,ast.For))
check(ast.unparse(scan.body[2].test)=='type(pair) is not tuple and type(pair) is not list','cell identity before length')
check(ast.unparse(scan.body[3].test)=='len(pair) != 2','cell length follows rejection')
check(not any(isinstance(n,(ast.Break,ast.Return)) for n in ast.walk(scan)),'no early successful scan exit')
for name,flag in [('materialize_exact','False'),('materialize_practical','True')]:
    check([a.arg for a in funs[name].args.args]==['values','exponent','d'],'bounded public input surface')
    check(ast.unparse(funs[name].body[-1])==f'return _construct(values, exponent, d, {flag})','fixed private practical flag')
forbidden={'exec','eval','compile','__import__','isinstance','issubclass','int','float','str','repr','bool','getattr','hasattr','iter'}
check(not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in forbidden for n in ast.walk(tree)), 'no dynamic, coercive or protocol-oriented boundary calls')
check(not any(isinstance(n,ast.Attribute) and isinstance(n.value,ast.Name) and n.value.id in {'values','pair','real','imag','exponent','d'} for n in ast.walk(tree)), 'no supplied-object attribute access')
imports=[(n.module,[(a.name,a.asname) for a in n.names]) for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
check(imports==[('dataclasses',[('dataclass',None)]),('buckets',[('DyadicSource',None)])], 'unchanged direct class dependency')

# Independent grammar classifier. This is reviewer-owned model code; it neither
# calls nor simulates statements loaded from the candidate.
def classify(vector,e,d,practical=False):
    if not (type(vector) is list or type(vector) is tuple): return ('VECTOR_TYPE',0,None,None)
    N=len(vector)
    if N==0: return ('EMPTY_VECTOR',0,None,None)
    if type(d) is not int: return ('D_DOMAIN',0,None,None)
    if d<1: return ('D_DOMAIN',0,None,None)
    if type(e) is not int: return ('EXPONENT_TYPE',0,None,None)
    if practical and N>65536: return ('PRACTICAL_N_LIMIT',0,None,None)
    if practical and d>8: return ('PRACTICAL_D_LIMIT',0,None,None)
    m=(4*N-1).bit_length()
    if e<0 or e>d*m: return ('EXPONENT_RANGE',0,None,None)
    limit=2**(d*m)
    for j in range(N):
        p=vector[j]
        if not (type(p) is list or type(p) is tuple): return ('CELL_TYPE',2*j,j,None)
        if len(p)!=2: return ('CELL_LENGTH',2*j,j,None)
        for c in (0,1):
            a=p[c]
            if type(a) is not int: return ('FIELD_TYPE',2*j+c,j,c)
            if abs(a)>limit: return ('FIELD_RANGE',2*j+c,j,c)
    return ('VALID',2*N,None,None)

calls=[]

def boom(*args,**kwargs):
    calls.append('forbidden supplied callback')
    raise AssertionError('a supplied-object hook ran')
class PoisonTruth:
    __bool__=boom

def foreign(base,mode):
    def equality(cls,other):
        calls.append('metaclass equality '+mode)
        if mode=='yes': return True
        if mode=='no': return False
        if mode=='poison': return PoisonTruth()
        raise RuntimeError('forbidden metaclass equality')
    meta=type('BoundaryMeta',(type,),{'__eq__':equality,'__ne__':boom,'__hash__':boom})
    hooks={k:boom for k in ['__getattribute__','__len__','__getitem__','__iter__','__bool__','__index__',
       '__int__','__float__','__str__','__repr__','__eq__','__ne__','__lt__','__le__','__gt__','__ge__',
       '__abs__','__neg__','__add__','__sub__','__mul__','__radd__','__rsub__','__rmul__']}
    cls=meta('BoundaryForeign',(base,),hooks)
    return cls()

rejections=0
acceptances=0

def rejected(v,e,d,practical,expected):
    global rejections
    calls.clear()
    check(classify(v,e,d,practical)==expected,'independent boundary rejection and prefix')
    check(calls==[],'no equality, attributes, coercion or sequence hooks')
    rejections+=1

for mode in ('yes','no','raise','poison'):
    for base in (object,list,tuple,int):
        obj=foreign(base,mode)
        for practical in (False,True):
            rejected(obj,0,1,practical,('VECTOR_TYPE',0,None,None))
            for prefix in (0,1,9):
                for outer in (list,tuple):
                    rejected(outer([(0,0)]*prefix+[obj]),0,1,practical,('CELL_TYPE',2*prefix,prefix,None))
            rejected([(0,0)],0,obj,practical,('D_DOMAIN',0,None,None))
            rejected([(0,0)],obj,1,practical,('EXPONENT_TYPE',0,None,None))
            rejected([(0,0)]*9+[(obj,0)],0,1,practical,('FIELD_TYPE',18,9,0))
            rejected([(0,0)]*9+[(0,obj)],0,1,practical,('FIELD_TYPE',19,9,1))
for practical in (False,True):
    for outer in (list,tuple):
        for cell in (list,tuple):
            for N in (1,2,3,7,8,17,65):
                m=(4*N-1).bit_length()
                for d in (1,8):
                    for e in (0,d*m):
                        for a in (0,1,2**(d*m)):
                            vector=outer([cell((0,0))]*(N-1)+[cell((-a,a))])
                            calls.clear()
                            check(classify(vector,e,d,practical)==('VALID',2*N,None,None),'genuine built-in bounded inputs accepted')
                            check(calls==[],'no callbacks for genuine inputs')
                            acceptances+=1
for value in [True,False,1.0,None,'0',{}]:
    rejected([(0,0)],0,value,False,('D_DOMAIN',0,None,None))
    rejected([(0,0)],value,1,False,('EXPONENT_TYPE',0,None,None))
    rejected([(0,value)],0,1,False,('FIELD_TYPE',1,0,1))
rejected([(0,0)]*65537,0,1,True,('PRACTICAL_N_LIMIT',0,None,None))
rejected([(0,0)],0,9,True,('PRACTICAL_D_LIMIT',0,None,None))

# The old predicate is independently shown to trigger the custom equality;
# this distinguishes a working adversary from a vacuous no-callback control.
old_witness=foreign(object,'yes')
calls.clear()
check(type(old_witness) in (tuple,list),'old equality-based predicate admits adversary')
check(calls==['metaclass equality yes'],'adversary hook actually active')
calls.clear()
check(type(old_witness) is not tuple and type(old_witness) is not list,'new rejection predicate rejects')
check(calls==[],'new predicate does not invoke metaclass equality')

formula_cases=0
for m in list(range(2,258))+[1024,4096,8192]:
    M=1<<m
    for N in {M//8+1,M//4}:
        for d in (1,8,128):
            H=(d*m+m+16)**2; c=(N-1)//2
            U=15*N+18*M+c+589+H; Z=29*N+584+H
            check(m*m<=8*N and max(U,Z)<=(750+8*(d+9)**2)*N,'unchanged all-size envelope')
            formula_cases+=1
check(not any(x in sys.modules for x in ['exact_source','buckets','pipeline','compact_window','fresh_identity_v2']), 'no candidate/scientific runtime import')
producer=json.loads(v2.read('results/IDENTITY_BOUNDARY.json'))
check(producer['hostile_rejection_cases']==296 and producer['genuine_builtin_acceptance_cases']==24 and producer['callbacks_observed']==0,'producer report retained accurately')
result={'status':'PASS','verdict':'ACCEPT_SCOPED_SOURCE_CONSTRUCTOR_V2','assertions':checks,
        'production_changed_lines':changed_lines,'identity_type_guards':8,
        'independent_model_rejection_cases':rejections,'independent_model_acceptance_cases':acceptances,
        'independent_model_callbacks_observed':0,'metadata_formula_cases':formula_cases,
        'candidate_or_producer_execution':False,'historical_or_prior_reviewer_execution':False,
        'actual_pinned_class_dynamic_integration':False,
        'producer_dynamic_results':'296 hostile rejections and 24 genuine cases reported; statically inspected, not independently rerun',
        'scope':'Exact two-line delta, full source boundary audit, independent language/grammar models and provenance checks'}
(ROOT/'results/DELTA_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
