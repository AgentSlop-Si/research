#!/usr/bin/env python3
"""Fresh bounded audit: independent dense reduction plus boundary tests.
Loads only the newly authored Ring class and integer coefficient construction.
Does not run H1687, R843, any historical program, or any external write.
"""
from pathlib import Path
from math import comb
import ast, hashlib, json, random, time
BASE=Path(__file__).resolve().parent
SRC=BASE.parent/'q29_precision_contract/fresh_exact_controls.py'
start=time.monotonic()
f=[sum(comb(25*r,j) if j<=25*r else 0 for r in range(5)) for j in range(101)]
ns={'F':f}
a=ast.parse(SRC.read_text())
cls=next(n for n in a.body if isinstance(n,ast.ClassDef) and n.name=='Ring')
exec(compile(ast.Module(body=[cls],type_ignores=[]),str(SRC),'exec'),ns)
B=ns['Ring'](2)

def dense_product(x,y):
    # Independent dense schoolbook product; pi reduction is done BEFORE alpha,
    # in the opposite order to the submitted sparse implementation.
    c=[[0]*199 for _ in range(35)]
    for (i,j),u in x.items():
        for (k,l),v in y.items(): c[i+k][j+l]+=u*v
    for j in range(198,99,-1):
        for i in range(35):
            u=c[i][j]%25
            for k in range(100): c[i][j-100+k]-=u*f[k]
            c[i][j]=0
    for i in range(34,17,-1):
        for j in range(100):
            u=c[i][j]%25
            c[i-18][j]-=u
            c[i-9][j]-=u
            c[i][j]=0
    return {(i,j):c[i][j]%25 for i in range(18) for j in range(100) if c[i][j]%25}

rng=random.Random(290125)
def small():
    return B.clean({(rng.randrange(18),rng.randrange(100)):rng.randrange(25) for _ in range(12)})
for _ in range(20):
    x,y=small(),small()
    assert dense_product(x,y)==B.mul(x,y)

# All possible quotient precisions, including all stagger boundaries.
y=B.add(small(),B.one)
for N in range(1,201):
    p=B.power(B.pi,N)
    changed=B.add(y,B.mul(p,B.add(B.a,B.one)))
    assert B.truncate(y,N)==B.truncate(changed,N)
    assert B.eqprec(y,B.truncate(y,N),N)
    exponents=[max(0,(N-j+99)//100) for j in range(100)]
    assert sum(exponents)==N

# New tests exercise each ramified boundary with unramified coordinates.
for h in [1,2,25,60,99,100,101,125,199]:
    y=B.add(small(),B.a)
    x=B.mul(B.power(B.pi,h),y)
    z,P=B.divide(x,h,200)
    assert P==200-h and B.eqprec(z,y,P)

# Precision-140 sharpness after division by pi^60: two valid outputs for the
# same B2 numerator agree modulo pi^140 and disagree modulo pi^141.
y1=B.one
y2=B.add(B.one,B.power(B.pi,140))
assert B.mul(B.power(B.pi,60),y1)==B.mul(B.power(B.pi,60),y2)
assert B.eqprec(y1,y2,140) and not B.eqprec(y1,y2,141)

support={j:(f[j]//5)%5 for j in range(100) if (f[j]//5)%5}
assert support=={0:1,25:2,50:2,75:1,80:4,85:3,90:3,95:4}
assert B.val(B.scalar(5))==100
assert B.val(B.add(B.scalar(5),B.power(B.pi,100)))==125
xi=B.add(B.one,B.pi)
d=B.sub(B.sub(B.power(xi,5),B.one),B.power(B.pi,5))
assert B.val(d)==101
q,P=B.divide(d,101,200)
assert B.truncate(q,1)==B.scalar(4)

# Source integrity is checked without rerunning predecessor computations.
target=SRC.parent
manifest=json.loads((target/'MANIFEST.json').read_text())
for row in manifest['files']:
    data=(target/row['path']).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
replay=json.loads((BASE/'CONTROL_RESULT.json').read_text())
saved=json.loads((target/'CONTROL_RESULT.json').read_text())
replay.pop('elapsed_seconds');saved.pop('elapsed_seconds')
assert replay==saved

# Count a declared straightforward recurrence, not a benchmark or feasibility promise.
L=100;m=843;D=18*100
countA=sum(min(i,L) for i in range(1,m+1))
countB=sum(min(max(i-1,0),L) for i in range(1,m+1))
result={
 'verdict':'ACCEPT bounded precision contract; full Q29 OPEN',
 'independent_dense_vs_sparse_products':20,
 'quotient_precisions_tested':list(range(1,201)),
 'division_exponents_tested':[1,2,25,60,99,100,101,125,199],
 'pi60_division_precision140_is_sharp':True,
 'carry_valuations':[100,125,101],
 'carry_first_visible_precisions':[101,126,102],
 'target_manifest_members_verified':len(manifest['files']),
 'replayed_author_non_timing_outputs_identical':True,
 'budget':{'coefficient_ring_dimension':D,'A_coefficient_products':countA,
 'B_coefficient_products':countB,'total_ring_products_baseline':countA+countB,
 'dense_scalar_product_accumulations_upper_bound':(countA+countB)*D*D,
 'transform_scaled_ring_additions':sum(200-2*k for k in range(100)),
 'three_rolling_R_slices_uint8_bytes':3*100*D,
 'raw_U_jet_uint8_bytes':200*D,
 'baseline_excludes_q_power_setup_and_monic_reduction':True,
 'wall_time_or_python_dict_memory_estimate':None},
 'H1687_executed':False,'R843_executed':False,'historical_code_executed':False,
 'elapsed_seconds':round(time.monotonic()-start,3)}
(BASE/'INDEPENDENT_CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='quotient_precisions_tested'},indent=2))
