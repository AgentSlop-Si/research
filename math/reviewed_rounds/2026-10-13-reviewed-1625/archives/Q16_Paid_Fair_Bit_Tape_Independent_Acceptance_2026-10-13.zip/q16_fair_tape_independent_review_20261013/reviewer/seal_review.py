#!/usr/bin/env python3
"""Seal verified present-review artifacts. No external writes or scientific execution."""
import hashlib,json,pathlib,platform,sys,zipfile
root=pathlib.Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):(root/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
summary=json.loads((root/'results/SUMMARY.json').read_text())
assert summary['status']=='PASS'
last=json.loads((root/'results/run.log').read_text().strip().splitlines()[-1]);assert last['status']=='PASS'
assert last['primitive_records']==summary['ledger']['primitive_records_reconstructed']
assert last['mutants_killed']==18
production=root/'frozen/q16_fair_tape_schedule_20261013/src/fair_tape.py'
pin=digest(production)
assert pin=='252d154e654d58bac4a9dddaaddcec939607801efc8ad6d9babd2c9cf8d260c4'
guards=summary['source_guard_grid']
verdict={
 'date_utc':'2026-10-13','overall':'ACCEPT','required_repairs':[],
 'scope':'Exact finite paid fair-bit schedule law, source-parameter binding, and bounded composition with the accepted deterministic pipeline; source success remains conditional.',
 'candidate_archive':'Q16_Paid_Fair_Bit_Tape_Schedule_Candidate_2026-10-13.zip',
 'candidate_archive_bytes':104614,
 'candidate_archive_sha256':'0d664d295d0672ce4926c70f495ba64b89e0960456fa08d243b4dcf0e43909de',
 'production_source_sha256':pin,
 'algorithm_sha256':summary['provenance']['algorithm_sha256'],
 'proof_sha256':summary['provenance']['proof_sha256'],
 'deterministic_acceptance_archive_sha256':'e7175180014ca6de6bd085579d139b8a3218a476e826a4e261024e5892f2b573',
 'accepted_dependency_pins':{k:v['sha256'] for k,v in summary['provenance']['accepted_dependencies'].items()},
 'exact_law':{'M':'2^m','location_rounds':'L=4m+1','estimation_rounds':'L=4m+1','bits_per_round':'(m-1)+m=2m-1','total_bits':'N=2L(2m-1)','sigma':'2A+1','tau':'m-bit word','word_order':'most significant bit first','distribution':'Uniform full product conditional on a uniform N-bit input tape independent of the fixed numerical input','m1':'A empty, A=0, sigma=1'},
 'closed_obligations':[
  'Unique full-tape inverse proves full mutual independence, not only pairwise independence',
  'Every well-formed tape is decoded with exactly N reads and without random rejection or refill',
  'Exact types, lengths and bits checked with reached actual integer widths charged',
  'All source parameters and sparse predicates bound internally on the source route',
  'Reduced fixtures explicitly separated from source-theorem-sized execution',
  'Generated schedule objects passed directly to the unchanged accepted pipeline',
  'Actual retained numerical traces and two-ledger cumulative work/storage sums checked',
  'Helper return/reference allocations and tuple copies counted in the declared model'],
 'fresh_checks':dict(last,source_parameter_grid_cases=len(guards),source_parameter_grid_accepted=sum(x['eligible'] for x in guards),source_parameter_grid_rejected=sum(not x['eligible'] for x in guards),all_candidate_manifest_entries=summary['provenance']['manifest_files_verified']),
 'fixture_candidate_counts':[x['candidate_count'] for x in summary['fixtures']],
 'source_parameter_probe':{'m':32,'beta':'1/8','q':131072,'L':129,'N':16254,'numerical_pipeline_executed':False,'meaning':'Only exact parameter and actual generated schedule-object handoff'},
 'resource_formulas':{'make_schedule_slots':'22+23R, R=2L','sample_affine_slots':'27','fixture_adapter_slots':'37+23R','source_adapter_slots':'41+23R','schedule_bit_work':'O(m^4)','schedule_cumulative_auxiliary_bits':'O(m^3)','combined_work_storage':'Sum of adapter and actual pipeline ledgers; retained traces included','model':'Conservative schoolbook bit arithmetic plus explicit control envelope; not Python/runtime measurement or formal interpreter proof'},
 'conditional_probability_transfer':'If the source theorem and its domain/numerical hypotheses apply, the scheduling law supplies failure <=2M*2^(-L)=M^(-3)<=1/M at the source 4M^(-beta)||v||_2 target.',
 'caller_obligations':['Uniform independent fair input bits independent of a fixed source','Original source and tape construction/storage and physical randomness acquisition','Previously validated deeply immutable source and normalization/norm promise','Source numerical-specialization and finite-error hypotheses','External source access and physical I/O costs'],
 'not_established':['Full E(beta) numerical recovery','Unwindowed spectral guarantee from deterministic component alone','Theorem-parameter-sized numerical pipeline execution','Dense fallback','All-length executable','Outer transfer','Physical entropy implementation','Host totality','Physical RAM bound','Practical speed','Worldwide novelty'],
 'no_external_writes':{'sheets':True,'github':True,'sharing_permissions':True},
 'historical_or_producer_programs_executed':False,'accepted_dependency_bytes_changed':False,
 'reviewer_development_corrections':['m=31,beta=1/8 is sparse-eligible; m=30 fails. Corrected initial harness expectation.','sqrt_input records an empty operand tuple and the input as output. Corrected initial harness assertion.'],
 'reviewer_source_sha256':digest(root/'reviewer/review.py')}
write('VERDICT.json',verdict)
write('EXECUTION_RECEIPT.json',{'status':'PASS','date_utc':'2026-10-13','python':sys.version,'platform':platform.platform(),'fresh_reviewer_sha256':digest(root/'reviewer/review.py'),'successful_run_log_sha256':digest(root/'results/run.log'),'summary_sha256':digest(root/'results/SUMMARY.json'),'final_run':last,'review_artifact_only':True})
entries=[]
for p in sorted(root.rglob('*')):
 rel=p.relative_to(root).as_posix()
 if not p.is_file() or rel in ('MANIFEST.json','SEAL.json'):continue
 assert not p.is_symlink() and '__pycache__' not in p.parts
 entries.append({'path':rel,'bytes':p.stat().st_size,'sha256':digest(p)})
write('MANIFEST.json',{'schema':'scoped-independent-review-v1','files':entries})
write('SEAL.json',{'files':len(entries),'manifest_sha256':digest(root/'MANIFEST.json'),'production_source_sha256':pin,'verdict':'ACCEPT','scope':verdict['scope']})
archive=root.parent/'Q16_Paid_Fair_Bit_Tape_Independent_Acceptance_2026-10-13.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file():
   info=zipfile.ZipInfo(root.name+'/'+p.relative_to(root).as_posix(),(2026,10,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   z.writestr(info,p.read_bytes())
receipt={'file':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive),'manifest_sha256':digest(root/'MANIFEST.json'),'source_sha256':pin}
archive.with_suffix(archive.suffix+'.seal.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,sort_keys=True))
