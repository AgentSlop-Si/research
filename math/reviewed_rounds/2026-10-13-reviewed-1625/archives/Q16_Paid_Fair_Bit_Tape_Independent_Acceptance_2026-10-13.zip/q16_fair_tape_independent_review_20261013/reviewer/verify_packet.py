#!/usr/bin/env python3
"""Verify exact sealed review bytes without executing any scientific module."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
manifest_path=root/'MANIFEST.json';seal=json.loads((root/'SEAL.json').read_text())
assert hashlib.sha256(manifest_path.read_bytes()).hexdigest()==seal['manifest_sha256']
manifest=json.loads(manifest_path.read_text())
seen=set()
for row in manifest['files']:
 relative=pathlib.PurePosixPath(row['path'])
 assert not relative.is_absolute() and '..' not in relative.parts
 assert row['path'] not in seen;seen.add(row['path'])
 path=root/relative
 assert path.is_file() and not path.is_symlink()
 data=path.read_bytes()
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],str(relative)
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and str(p.relative_to(root)) not in {'MANIFEST.json','SEAL.json'}}
assert actual==seen,{'unexpected':sorted(actual-seen),'missing':sorted(seen-actual)}
verdict=json.loads((root/'VERDICT.json').read_text())
assert verdict['overall']=='ACCEPT' and not verdict['required_repairs']
assert verdict['production_source_sha256']==seal['production_source_sha256']
print(json.dumps({'status':'PASS','files':len(seen),'manifest_sha256':seal['manifest_sha256'],'production_source_sha256':seal['production_source_sha256'],'verdict':verdict['overall']},sort_keys=True))
