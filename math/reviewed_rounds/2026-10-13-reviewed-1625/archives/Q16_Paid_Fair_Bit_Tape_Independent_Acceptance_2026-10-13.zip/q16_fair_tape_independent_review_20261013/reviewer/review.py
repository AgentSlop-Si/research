#!/usr/bin/env python3
"""Independent reviewer controls, authored 2026-10-13. Execute current components only."""
import ast, collections, dataclasses, hashlib, importlib, itertools, json, math, pathlib, sys, types, zipfile
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parents[1]
CAND=ROOT/'frozen/q16_fair_tape_schedule_20261013'
SRC=CAND/'src'
sys.dont_write_bytecode=True
sys.path.insert(0,str(SRC))
import fair_tape as ft
import pipeline as pp
from compact_window import WindowSpec
from buckets import DyadicSource
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
R={}
def save(name,obj):
 (OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def widths(x): return max(1,len(format(abs(x),'b')))
def allbits(n): return itertools.product((0,1),repeat=n)
def bits(v,w): return tuple((v//(2**j))%2 for j in reversed(range(w)))
def nbits(m): return 2*(4*m+1)*(2*m-1)
def reference(m,tape):
 w=2*m-1; L=4*m+1
 pairs=[]; ranges=[]
 for k in range(2*L):
  s=k*w
  A=sum(tape[s+j]*2**(m-2-j) for j in range(m-1))
  t=sum(tape[s+m-1+j]*2**(m-1-j) for j in range(m))
  pairs.append((2*A+1,t))
  ranges.append((s,s+m-1,s+m-1,s+w,A))
 return tuple(pairs[:L]),tuple(pairs[L:]),ranges

def check_schedule(module,m,tape):
 run=module.make_schedule(m,tape); s=run.schedule
 a,b,ranges=reference(m,tape); L=4*m+1; Rn=2*L; N=nbits(m)
 assert s.plan==module.TapePlan(m,2**m,L,2*m-1,N)
 assert s.location==a and s.estimation==b and s.consumed_bits==N and s.tape is tape
 assert len(s.draws)==Rn
 rebuilt=[]
 for k,(draw,rng,pair) in enumerate(zip(s.draws,ranges,a+b)):
  assert (draw.a_start,draw.a_stop,draw.tau_start,draw.tau_stop,draw.A)==rng
  assert (draw.sigma,draw.tau)==pair
  assert (draw.role,draw.ordinal)==(('location' if k<L else 'estimation'),k%L)
  rebuilt.extend(bits((pair[0]-1)//2,m-1)); rebuilt.extend(bits(pair[1],m))
 assert tuple(rebuilt)==tape
 D=run.ledger; o=D['operations']
 assert o['tape_bit_read']==N and o['word_complete']==2*Rn and o['affine_draw']==Rn
 assert o['parameter_input']==1+N+Rn and D['allocated_slots']==22+23*Rn
 assert o['schedule_tuple_copy']==Rn and o['draw_tuple_copy']==Rn
 return run

# The shadow ledger never copies reported arithmetic totals or counter state.
BASE=pp.CompositionLedger
class AuditLedger(BASE):
 instances=[]; records=0; reports=0
 def __init__(self):
  super().__init__(); self.c=collections.Counter(); self.work=0; self.produced=0; self.mx=1; self.alloc=0; self.pb=0; self.pm=1
  self.parameter_values=[]; self.rejected_types=0; self.__class__.instances.append(self)
 def record(self,kind,inputs,out):
  assert all(type(x) is int for x in (*inputs,out))
  op={'add':lambda a,b:a+b,'subtract':lambda a,b:a-b,'multiply':lambda a,b:a*b,
      'floor_divide':lambda a,b:a//b,'modulo':lambda a,b:a%b,'bit_and':lambda a,b:a&b,
      'bit_length':lambda a:a.bit_length(),'binary_power':lambda a:2**a}
  if kind in op: assert out==op[kind](*inputs),(kind,inputs,out)
  if kind=='power_input': assert out==1 and len(inputs)==2
  if kind=='sqrt_input': assert inputs==() and out>=0
  sizes=[widths(v) for v in (*inputs,out)]
  self.c[kind]+=1; self.work+=16*(2+sum(sizes))**2; self.produced+=sizes[-1]+1; self.mx=max(self.mx,*sizes)
  self.__class__.records+=1
  return super().record(kind,inputs,out)
 def parameter(self,value):
  if type(value) is not int: self.rejected_types+=1
  else:
   w=widths(value); self.pb+=w; self.pm=max(self.pm,w); self.parameter_values.append(value)
  return super().parameter(value)
 def allocate(self,n):
  assert type(n) is int and n>=0
  self.alloc+=n; self.c['allocated_slots']+=n; self.produced+=n
  return super().allocate(n)
 def event(self,name,count=1):
  assert type(count) is int and count>=0
  self.c[name]+=count; return super().event(name,count)
 def report(self):
  actual=super().report(); E=sum(self.c.values())+256; H=self.mx+widths(E)+2
  expected={'operations':dict(sorted(self.c.items())),'arithmetic_bit_work_upper':self.work,
   'bookkeeping_bit_work_upper':512*E*H**2,'total_bit_work_upper':self.work+512*E*H**2,
   'cumulative_storage_upper_bits':self.produced+512*E*H,'max_observed_integer_bits':self.mx,
   'allocated_slots':self.alloc,'parameter_input_bits':self.pb,'max_parameter_bits':self.pm}
  assert all(actual[k]==v for k,v in expected.items()),(actual,expected)
  self.__class__.reports+=1
  return actual

# Archive and dependency provenance. Read receipts; never execute prior tests.
archive=ROOT/'inputs/Q16_Paid_Fair_Bit_Tape_Schedule_Candidate_2026-10-13.zip'
assert archive.stat().st_size==104614 and sha(archive)=='0d664d295d0672ce4926c70f495ba64b89e0960456fa08d243b4dcf0e43909de'
with zipfile.ZipFile(archive) as original:
 assert all(not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts for name in original.namelist())
 for name in original.namelist():
  if not name.endswith('/'): assert original.read(name)==(ROOT/'frozen'/name).read_bytes()

manifest=json.loads((CAND/'MANIFEST.json').read_text())
for row in manifest['files']:
 p=CAND/row['path']; assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
assert sha(SRC/'fair_tape.py')=='252d154e654d58bac4a9dddaaddcec939607801efc8ad6d9babd2c9cf8d260c4'
assert sha(CAND/'MANIFEST.json')==json.loads((CAND/'SEAL.json').read_text())['manifest_sha256']
accepted=ROOT/'inputs/Q16_Deterministic_Pipeline_Independent_Acceptance_2026-10-13.zip'
assert sha(accepted)=='e7175180014ca6de6bd085579d139b8a3218a476e826a4e261024e5892f2b573'
with zipfile.ZipFile(accepted) as z:
 dependency_matches={}
 for name,pin in manifest['accepted_dependency_pins'].items():
  matches=[n for n in z.namelist() if n.endswith('/src/'+name)]
  assert matches and all(hashlib.sha256(z.read(n)).hexdigest()==pin for n in matches)
  assert sha(SRC/name)==pin
  dependency_matches[name]={'sha256':pin,'acceptance_archive_matches':matches}
R['provenance']={'manifest_files_verified':len(manifest['files']),'accepted_dependencies':dependency_matches,
 'source_sha256':sha(SRC/'fair_tape.py'),'algorithm_sha256':sha(CAND/'sources/ALGORITHM.txt'),
 'proof_sha256':sha(CAND/'sources/PROOF.md'),'historical_or_producer_tests_executed':False}
save('provenance.json',R['provenance'])

# Exhaustive finite distribution and unique inverse, separate from the general proof.
counts=[]
for m in range(1,8):
 seen=collections.Counter()
 for tape in allbits(2*m-1):
  r=ft.sample_affine(m,tape); d=r.draw
  expected=reference(m,tape+(0,)*(nbits(m)-len(tape)))[0][0]
  assert (d.sigma,d.tau)==expected
  assert bits((d.sigma-1)//2,m-1)+bits(d.tau,m)==tape
  assert r.tape is tape and r.ledger['allocated_slots']==27
  assert r.ledger['operations']['tape_bit_read']==2*m-1
  seen[d.sigma,d.tau]+=1
 assert len(seen)==2**(2*m-1) and set(seen.values())=={1}
 assert set(seen)==set(itertools.product(range(1,2**m,2),range(2**m)))
 counts.append({'m':m,'tapes':sum(seen.values()),'multiplicity':1})
whole=set()
for tape in allbits(nbits(1)):
 s=check_schedule(ft,1,tape).schedule; whole.add((s.location,s.estimation))
assert len(whole)==2**nbits(1)
projected=[]
for m in (1,2,3):
 L=4*m+1; w=2*m-1
 for ia,ib in ((0,1),(L-1,L),(0,2*L-1)):
  seen=collections.Counter()
  for a in allbits(w):
   for b in allbits(w):
    tape=[0]*nbits(m); tape[ia*w:(ia+1)*w]=a; tape[ib*w:(ib+1)*w]=b
    s=check_schedule(ft,m,tuple(tape)).schedule; pairs=s.location+s.estimation
    seen[pairs[ia],pairs[ib]]+=1
  assert len(seen)==2**(2*w) and set(seen.values())=={1}
  projected.append({'m':m,'blocks':[ia,ib],'assignments':sum(seen.values())})
bit_influences=0
for m in range(1,11):
 for j in range(nbits(m)):
  tape=[0]*nbits(m); tape[j]=1
  check_schedule(ft,m,tuple(tape)); bit_influences+=1
R['distribution']={'single_round':counts,'whole_m1_tapes':len(whole),'two_block_projections':projected,'one_hot_full_tape_checks':bit_influences,
 'general_independence_basis':'Full product bijection proof, not bounded enumeration alone'}
save('distribution.json',R['distribution']); print('distribution PASS',flush=True)

# All returned reports and all rejection paths sampled below receive an independent reconstruction.
ft.CompositionLedger=AuditLedger; pp.CompositionLedger=AuditLedger
ledger_cases=[]
for m in (1,2,3,8,32):
 for bit in (0,1):
  x=check_schedule(ft,m,(bit,)*nbits(m)); ledger_cases.append({'api':'make_schedule','m':m,'bit':bit,'ledger':x.ledger})
for m in (1,4,9):
 for bit in (0,1):
  x=ft.sample_affine(m,(bit,)*(2*m-1)); ledger_cases.append({'api':'sample_affine','m':m,'bit':bit,'ledger':x.ledger})
reject=[]
def rejected(name,call,error=ValueError,expected_reads=None,wide=False):
 before=len(AuditLedger.instances)
 try: call()
 except error as e: msg=str(e)
 else: raise AssertionError('not rejected: '+name)
 ledgers=AuditLedger.instances[before:]
 for l in ledgers: l.report()
 reads=sum(l.c['tape_bit_read'] for l in ledgers)
 if expected_reads is not None: assert reads==expected_reads,(name,reads,expected_reads)
 if wide: assert any(l.mx>=16385 for l in ledgers)
 reject.append({'case':name,'exception':error.__name__,'message':msg,'tape_reads':reads,'actual_width_16385_verified':wide})
class I(int): pass
class T(tuple): pass
N=nbits(3); good=(0,)*N
for m in (0,-1,True,1.0,'3',None,I(3),-(1<<16384)):
 rejected('bad_m_'+str(type(m).__name__)+'_'+str(len(reject)),lambda m=m:ft.make_schedule(m,good),expected_reads=0,wide=type(m) is int and m<-(1<<100))
for tape in (list(good),iter(good),T(good),None,good[:-1],good+(0,)):
 rejected('bad_tape_'+str(len(reject)),lambda tape=tape:ft.make_schedule(3,tape),expected_reads=0)
for j in (0,N//2,N-1):
 for value in (True,1.0,'0',None,I(1),2,-1,1<<16384):
  tape=list(good);tape[j]=value
  rejected('bad_bit_'+str(j)+'_'+str(len(reject)),lambda tape=tuple(tape):ft.make_schedule(3,tape),expected_reads=j+1,wide=type(value) is int and value>(1<<100))
for tape in ((),(0,)*4,(False,0,0),(2,0,0)):
 rejected('single_bad_'+str(len(reject)),lambda tape=tape:ft.sample_affine(2,tape))

# Exact source constructor against literal rational ceiling and independent guards.
params=[]
def ceiling(fr):return -((-fr.numerator)//fr.denominator)
for m,beta in ((31,Fraction(1,8)),(32,Fraction(1,8)),(48,Fraction(1,4)),(64,Fraction(1,8)),(96,Fraction(1,3)),(128,Fraction(3,8)),(51,Fraction(1,10)),(32,Fraction((1<<100)+1,8*(1<<100)))):
 x=ft.source_parameters(m,beta)
 M=2**m;k=2**ceiling(2*beta*m);B=2**ceiling((Fraction(1,2)+beta)*m)
 assert x.spec==WindowSpec(M,B,2*m+1,16*m+16,beta) and x.q==512*k
 assert B>=4096*k and B>=4 and M%B==0 and M//B>=4 and x.spec.W<M
 assert x.plan==ft.TapePlan(m,M,4*m+1,2*m-1,nbits(m))
 params.append({'m':m,'beta':str(beta),'B':B,'q':x.q,'r':x.spec.r,'P':x.spec.P,'L':x.plan.rounds_per_role,'N':x.plan.required_bits,'ledger':x.ledger})
for m,beta in ((1,Fraction(1,8)),(16,Fraction(1,8)),(30,Fraction(1,8)),(32,0.125),(32,Fraction(0)),(32,Fraction(1,2)),(32,Fraction(-1,8)),(True,Fraction(1,8))):
 rejected('source_params_'+str(m)+'_'+str(beta),lambda m=m,beta=beta:ft.source_parameters(m,beta),expected_reads=0)

# Complete sparse-guard classification across a finite parameter grid, no arrays.
guard_grid=[]
for beta in (Fraction(1,16),Fraction(1,8),Fraction(1,4),Fraction(3,8),Fraction(7,16)):
 for m in range(1,129):
  M=2**m;k=2**ceiling(2*beta*m);B=2**ceiling((Fraction(1,2)+beta)*m);W=2*(2*m+1)*(8*B-1)+1
  eligible=(M%B==0 and B>=4 and M//B>=4 and B>=4096*k and W<M)
  try:result=ft.source_parameters(m,beta)
  except ValueError:assert not eligible;actual=False
  else:assert eligible and result.q==512*k;actual=True
  guard_grid.append({'m':m,'beta':str(beta),'eligible':actual})
rejected('source_beta_oversized_invalid',lambda:ft.source_parameters(32,Fraction(1<<16384,3)),expected_reads=0,wide=True)
R['source_guard_grid']=guard_grid
save('source_guard_grid.json',guard_grid)

# A probe proves wrapper binding only, not a theorem-sized numerical run.
original_pipeline=ft.run_pipeline
probe_calls=[]
def handoff_probe(spec,source,q,loc,est):
 assert source is sentinel
 assert spec==WindowSpec(2**32,2**20,65,528,Fraction(1,8)) and q==131072
 a,b,_=reference(32,probe_tape);assert loc==a and est==b
 probe_calls.append((loc,est))
 return types.SimpleNamespace(ledger=BASE().report(),probe_only=True)
sentinel=object(); probe_tape=tuple(((i*17+i//11)%19)<9 for i in range(nbits(32)))
probe_tape=tuple(map(int,probe_tape))
ft.run_pipeline=handoff_probe
probe=ft.run_source_tape(32,Fraction(1,8),sentinel,probe_tape)
ft.run_pipeline=original_pipeline
assert len(probe_calls)==1 and probe.schedule.location is probe_calls[0][0] and probe.schedule.estimation is probe_calls[0][1]
assert probe.resources['adapter']['allocated_slots']==41+23*(2*(4*32+1))
R['source_parameters']={'valid_cases':params,'source_handoff_probe':{'m':32,'beta':'1/8','numerical_pipeline_executed':False,'direct_schedule_object_identity':True,'ledger':probe.resources}}
save('source_parameters.json',R['source_parameters'])

# Actual accepted pipeline runs from generated schedules, fully retained.
def make_source(M,kind):
 if kind=='zero': vals=tuple(((0,0),(0,0)) for i in range(M))
 elif kind=='impulse': vals=tuple(((1 if i==5 else 0,0),(0,0)) for i in range(M))
 else: vals=tuple((((i*13)%17-8,3),((i*7)%17-8,3)) for i in range(M))
 return DyadicSource(vals,3)
fixtures=[]
for name,M,B,P,q,kind,tapemode in (
 ('all_zero_one_bucket',64,4,8,1,'pattern','zero'),
 ('all_one_full_candidates',64,4,12,4,'impulse','one'),
 ('varying_schedule_nonempty',64,4,8,4,'pattern','varied'),
 ('zero_candidate_larger_grid',128,8,8,0,'zero','one')):
 spec=WindowSpec(M,B,1,P);m=M.bit_length()-1;source=make_source(M,kind)
 tape=(0,)*nbits(m) if tapemode=='zero' else (1,)*nbits(m) if tapemode=='one' else tuple(int((i*31+i//3)%37<18) for i in range(nbits(m)))
 a,b,_=reference(m,tape)
 run=ft.run_fixture_tape(spec,source,q,tape)
 direct=pp.run_pipeline(spec,source,q,a,b)
 assert run.pipeline==direct
 assert run.scope=='reduced_component_fixture; no source recovery probability claim'
 assert run.resources['adapter']['allocated_slots']==37+23*(2*(4*m+1))
 assert run.resources['pipeline'] is run.pipeline.ledger
 assert len(run.pipeline.location_trace)==len(a) and len(run.pipeline.estimation_trace)==len(b)
 for actual,pair in zip(run.pipeline.location_trace,run.schedule.location):assert actual.affine is pair
 for actual,pair in zip(run.pipeline.estimation_trace,run.schedule.estimation):
  assert actual.affine is pair and actual.candidates is run.pipeline.candidates
 ad,pl=run.resources['adapter'],run.resources['pipeline']
 for key in ('total_bit_work_upper','cumulative_storage_upper_bits'):assert run.resources[key]==ad[key]+pl[key]
 assert run.resources['max_observed_integer_bits']==max(ad['max_observed_integer_bits'],pl['max_observed_integer_bits'])
 assert pl['operations']['buckets_call']==2*(4*m+1)
 assert pl['operations']['source_query']==2*(4*m+1)*spec.W
 tracefile='trace_'+name+'.json'; save(tracefile,dataclasses.asdict(run))
 fixtures.append({'name':name,'M':M,'B':B,'r':1,'P':P,'q':q,'L':4*m+1,'N':nbits(m),'candidate_count':len(run.pipeline.candidates),'whole_pipeline_equal':True,'actual_affine_object_identity':True,'trace_file':tracefile,'buckets_calls':pl['operations']['buckets_call'],'source_queries':pl['operations']['source_query']})
 print('fixture PASS',name,flush=True)

spec=WindowSpec(64,4,1,8);source=make_source(64,'pattern');tape=(0,)*nbits(6)
for name,spec0,q0,source0,tape0 in (
 ('wrong_spec',None,1,source,tape),('beta_spec',WindowSpec(2**32,2**20,65,528,Fraction(1,8)),1,source,tape),
 ('q_bool',spec,True,source,tape),('q_negative',spec,-1,source,tape),('q_above_B',spec,5,source,tape),
 ('wrong_source',spec,1,None,tape),('source_length',spec,1,DyadicSource(source.values[:-1],3),tape),
 ('short_tape',spec,1,source,tape[:-1]),('bad_spec_M',WindowSpec(63,4,1,8),1,source,tape),
 ('bad_spec_W',WindowSpec(64,4,2,8),1,source,tape),('bad_spec_B',WindowSpec(64,3,1,8),1,source,tape),
 ('bad_spec_P',WindowSpec(64,4,1,7),1,source,tape),('bad_spec_T',WindowSpec(64,32,1,8),1,source,tape)):
 rejected(name,lambda spec0=spec0,q0=q0,source0=source0,tape0=tape0:ft.run_fixture_tape(spec0,source0,q0,tape0))
rejected('public_schedule_injection',lambda:ft.run_fixture_tape(spec,source,1,tape,location_schedule=((1,0),)),TypeError)
rejected('source_sparse_unsupported',lambda:ft.run_source_tape(16,Fraction(1,8),source,()),expected_reads=0)
for l in AuditLedger.instances:l.report()
R['ledger']={'instances':len(AuditLedger.instances),'primitive_records_reconstructed':AuditLedger.records,'report_snapshots_reconstructed':AuditLedger.reports,'valid_decoder_cases':ledger_cases,'all_rejected_instances_reconstructed':True,
 'model':'Conservative finite-bit source model; independent replay is not an interpreter-level proof or a physical memory measurement'}
R['rejections']=reject;R['fixtures']=fixtures
save('ledger.json',R['ledger']);save('rejections.json',reject);save('fixtures.json',fixtures)
print('ledger/rejections PASS',len(reject),AuditLedger.records,flush=True)
ft.CompositionLedger=BASE;pp.CompositionLedger=BASE

# Fresh in-memory adapter mutants; no altered source is saved over a frozen input.
source_code=(SRC/'fair_tape.py').read_text()
mutants=[
 ('wrong_L','L.add(L.mul(4, m), 1)','L.add(L.mul(4, m), 3)','schedule'),
 ('wrong_N','required = L.mul(L.mul(2, rounds), per_round)','required = L.mul(rounds, per_round)','schedule'),
 ('repeated_estimation','tuple(location), tuple(estimation), tuple(draws)','tuple(location), tuple(location), tuple(draws)','schedule'),
 ('swapped_roles','tuple(location), tuple(estimation), tuple(draws)','tuple(estimation), tuple(location), tuple(draws)','schedule'),
 ('nonodd_sigma','sigma = L.add(L.mul(2, A), 1)','sigma = L.mul(2, A)','schedule'),
 ('biased_A','sigma = L.add(L.mul(2, A), 1)','sigma = L.add(L.mul(2, A % 2), 1)','schedule'),
 ('wrong_endianness','value = L.add(L.mul(2, value), bit)','value = L.add(value, L.mul(bit, L.shift(position-start)))','schedule'),
 ('dropped_final_bit','for position in range(start, stop):','for position in range(start, max(start,stop-1)):','schedule'),
 ('underpaid_read',"L.event('tape_bit_read')","L.event('unpaid_read')",'schedule'),
 ('underpaid_word_return','L.allocate(3)\n    return value, stop','L.allocate(0)\n    return value, stop','schedule'),
 ('underpaid_draw_copy',"L.event('draw_tuple_copy', total_rounds)","L.event('draw_tuple_copy', 0)",'schedule'),
 ('bad_ordinal','return RoundDraw(role, ordinal, start','return RoundDraw(role, 0, start','schedule'),
 ('surplus_accepted','if size != required:','if size < required:','surplus'),
 ('list_accepted','if type(tape) is not tuple:','if not isinstance(tape, (tuple,list)):','container'),
 ('bit_two_accepted','if bit not in (0, 1):','if bit not in (0, 1, 2):','badbit'),
 ('wrong_source_q','q = L.mul(512, k)','q = L.mul(256, k)','source'),
 ('wrong_pipeline_roles','q, schedule.location, schedule.estimation)','q, schedule.estimation, schedule.location)','handoff'),
 ('wrong_resource_sum',"own['total_bit_work_upper'] + inherited['total_bit_work_upper']","own['total_bit_work_upper']",'handoff')]
kills=[]
for index,(name,old,new,mode) in enumerate(mutants):
 assert source_code.count(old)==1,(name,source_code.count(old))
 altered=source_code.replace(old,new);node=ast.parse(altered)
 mod=types.ModuleType('review_mutant_'+str(index));sys.modules[mod.__name__]=mod
 exec(compile(node,'<fresh-review-mutant:'+name+'>','exec'),mod.__dict__)
 killed=False;detail=None
 try:
  if mode=='schedule':
   for m in (1,3):
    tp=tuple(int((i*11+i//5)%23<10) for i in range(nbits(m)))
    check_schedule(mod,m,tp)
  elif mode in ('surplus','container','badbit'):
   tp=(0,)*nbits(3)
   tp=tp+(0,) if mode=='surplus' else list(tp) if mode=='container' else (2,)+tp[1:]
   try:mod.make_schedule(3,tp)
   except ValueError:pass
   else:raise AssertionError('malformed tape accepted')
  elif mode=='source':assert mod.source_parameters(32,Fraction(1,8)).q==131072
  elif mode=='handoff':
   tp=tuple(int((i*5+i//7)%13<6) for i in range(nbits(6)));a,b,_=reference(6,tp)
   def spy(s,v,q,loc,est):
    assert loc==a and est==b
    return types.SimpleNamespace(ledger={'total_bit_work_upper':12345,'cumulative_storage_upper_bits':9876,'max_observed_integer_bits':5})
   mod.run_pipeline=spy
   run=mod.run_fixture_tape(spec,source,1,tp)
   assert run.resources['total_bit_work_upper']==run.resources['adapter']['total_bit_work_upper']+12345
 except (AssertionError,ValueError,ArithmeticError,KeyError) as e:
  killed=True;detail=type(e).__name__+': '+str(e)[:180]
 assert killed,('mutation survived',name)
 kills.append({'name':name,'detected':killed,'oracle':mode,'detection':detail})
 del sys.modules[mod.__name__]
R['mutations']=kills;save('mutations.json',kills)

# Production import/call inventory, with any unsupported escape marked by AST.
node=ast.parse(source_code)
imports=[]
for x in ast.walk(node):
 if isinstance(x,(ast.Import,ast.ImportFrom)): imports.append(ast.unparse(x))
assert imports==['from dataclasses import dataclass','from compact_window import WindowSpec, theorem_spec, validate_beta','from pipeline import CompositionLedger, run_pipeline']
for x in ast.walk(node):
 if isinstance(x,ast.Name):assert x.id not in {'random','secrets','urandom','eval','exec','open','input','sleep','time'}
R['static']={'imports':imports,'no_entropy_refill_or_rejection_rng':True,'all_tape_loops_have_parameter_fixed_bounds':True,'exceptional_dense_branch_implemented':False}
R['status']='PASS'; save('SUMMARY.json',R)
print(json.dumps({'status':'PASS','single_round_tapes':sum(x['tapes'] for x in counts),'whole_m1_tapes':len(whole),'projected_block_cases':sum(x['assignments'] for x in projected),'one_hot_checks':bit_influences,'rejections':len(reject),'fixtures':len(fixtures),'mutants_killed':len(kills),'ledger_instances':len(AuditLedger.instances),'primitive_records':AuditLedger.records,'reports':AuditLedger.reports},sort_keys=True),flush=True)
