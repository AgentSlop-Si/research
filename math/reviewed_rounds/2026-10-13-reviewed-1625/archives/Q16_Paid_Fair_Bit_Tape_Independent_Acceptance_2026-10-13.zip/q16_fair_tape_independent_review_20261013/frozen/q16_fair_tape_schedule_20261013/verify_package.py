"""Read-only seal check; does not import or execute numerical code."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
body=(ROOT/'MANIFEST.json').read_bytes()
manifest=json.loads(body)
seal=json.loads((ROOT/'SEAL.json').read_text())
assert hashlib.sha256(body).hexdigest()==seal['manifest_sha256']
seen=set()
for item in manifest['files']:
    rel=Path(item['path'])
    assert not rel.is_absolute() and '..' not in rel.parts
    assert str(rel) not in seen
    seen.add(str(rel))
    data=(ROOT/rel).read_bytes()
    assert len(data)==item['bytes'],str(rel)
    assert hashlib.sha256(data).hexdigest()==item['sha256'],str(rel)
for name,pin in manifest['accepted_dependency_pins'].items():
    assert hashlib.sha256((ROOT/'src'/name).read_bytes()).hexdigest()==pin
source=hashlib.sha256((ROOT/'src/fair_tape.py').read_bytes()).hexdigest()
assert source==seal['production_source_sha256']
for name in ['schedule_controls','integration_controls','mutation_controls']:
    receipt=json.loads((ROOT/'results'/(name+'.json')).read_text())
    assert receipt['status']=='PASS' and receipt['source_sha256']==source
assert json.loads((ROOT/'PROOF_LEDGER.json').read_text())['status']=='CANDIDATE_AWAITING_INDEPENDENT_REVIEW'
print(json.dumps({'status':'PASS','verified_files':len(seen),'manifest_sha256':seal['manifest_sha256'],
                  'production_source_sha256':source,'scope':seal['scope']},indent=2))
