"""Paid fixed-tape scheduling for the pinned deterministic Q16 pipeline.

This module draws no host randomness. A tape is an exact immutable tuple of
exact integer bits. The distribution theorem is conditional on the caller
supplying the specified independent fair bits, independent of the fixed input.
Word order is most significant bit first. Public source and reduced-fixture
execution are distinct; neither implements an exceptional dense branch.
"""
from dataclasses import dataclass

from compact_window import WindowSpec, theorem_spec, validate_beta
from pipeline import CompositionLedger, run_pipeline


@dataclass(frozen=True)
class TapePlan:
    m: int
    M: int
    rounds_per_role: int
    bits_per_round: int
    required_bits: int


@dataclass(frozen=True)
class RoundDraw:
    role: str
    ordinal: int
    a_start: int
    a_stop: int
    tau_start: int
    tau_stop: int
    A: int
    sigma: int
    tau: int


@dataclass(frozen=True)
class ScheduleTrace:
    plan: TapePlan
    tape: tuple
    location: tuple
    estimation: tuple
    draws: tuple
    consumed_bits: int


@dataclass(frozen=True)
class ScheduleRun:
    schedule: ScheduleTrace
    ledger: dict


@dataclass(frozen=True)
class AffineRun:
    m: int
    tape: tuple
    draw: RoundDraw
    ledger: dict


@dataclass(frozen=True)
class SourceParameters:
    spec: WindowSpec
    q: int
    plan: TapePlan
    ledger: dict


@dataclass(frozen=True)
class FixedTapeRun:
    scope: str
    schedule: ScheduleTrace
    pipeline: object
    resources: dict


def _plan(m, ledger):
    L = ledger
    L.event('tape_plan_call')
    L.parameter(m)
    if m < 1:
        raise ValueError('m must be an exact integer >= 1')
    M = L.shift(m)
    rounds = L.add(L.mul(4, m), 1)
    per_round = L.sub(L.mul(2, m), 1)
    required = L.mul(L.mul(2, rounds), per_round)
    L.allocate(6)
    return TapePlan(m, M, rounds, per_round, required)


def _tape(tape, required, L):
    L.event('tape_container_validation')
    if type(tape) is not tuple:
        raise ValueError('tape must be an exact immutable tuple')
    size = L.record('tape_length', (), len(tape))
    if size != required:
        raise ValueError('tape length must equal the exact required bit count')
    # Individual bits are read, width-paid, and validated exactly once below.


def _word(tape, start, width, L):
    stop = L.add(start, width)
    value = L.record('word_initial_value', (), 0)
    for position in range(start, stop):
        L.event('tape_bit_read')
        bit = tape[position]
        L.parameter(bit)
        if bit not in (0, 1):
            raise ValueError('each tape entry must be an exact integer bit')
        value = L.add(L.mul(2, value), bit)
    L.event('word_complete')
    L.allocate(3)
    return value, stop


def _draw(m, tape, start, role, ordinal, L):
    L.event('affine_draw')
    L.parameter(ordinal)
    A, a_stop = _word(tape, start, L.sub(m, 1), L)
    sigma = L.add(L.mul(2, A), 1)
    tau, tau_stop = _word(tape, a_stop, m, L)
    L.allocate(10)
    return RoundDraw(role, ordinal, start, a_stop, a_stop, tau_stop, A, sigma, tau)


def _schedule(plan, tape, L):
    _tape(tape, plan.required_bits, L)
    L.event('schedule_generation')
    location, estimation, draws = [], [], []
    total_rounds = L.mul(2, plan.rounds_per_role)
    L.allocate(L.add(L.mul(2, total_rounds), 3))
    cursor = L.record('tape_initial_cursor', (), 0)
    for role, target in (('location', location), ('estimation', estimation)):
        for ordinal in range(plan.rounds_per_role):
            draw = _draw(plan.m, tape, cursor, role, ordinal, L)
            target.append((draw.sigma, draw.tau))
            L.allocate(3)
            draws.append(draw)
            cursor = draw.tau_stop
    if cursor != plan.required_bits:
        raise ArithmeticError('internal fixed tape consumption mismatch')
    L.event('tape_consumption_check')
    L.event('schedule_tuple_copy', total_rounds)
    L.event('draw_tuple_copy', total_rounds)
    L.allocate(L.add(L.mul(2, total_rounds), 10))
    return ScheduleTrace(plan, tape, tuple(location), tuple(estimation), tuple(draws), cursor)


def make_schedule(m, tape):
    """Generate exactly two L=4m+1 schedules, without numerical pipeline work.

    Short and surplus tapes are malformed and rejected before any bit read.
    A malformed bit is rejected on its one reached read. These interface errors
    are not random rejections; every correctly shaped binary tape succeeds.
    """
    L = CompositionLedger()
    plan = _plan(m, L)
    schedule = _schedule(plan, tape, L)
    L.allocate(3)
    L.event('schedule_output')
    return ScheduleRun(schedule, L.report())


def sample_affine(m, tape):
    """Standalone single-round version of precisely the same bit-word decoder."""
    L = CompositionLedger()
    plan = _plan(m, L)
    _tape(tape, plan.bits_per_round, L)
    draw = _draw(m, tape, 0, 'single', 0, L)
    if draw.tau_stop != plan.bits_per_round:
        raise ArithmeticError('internal single-round consumption mismatch')
    L.event('tape_consumption_check')
    L.allocate(5)
    L.event('affine_output')
    return AffineRun(m, tape, draw, L.report())


def _source_parameters(m, beta, L):
    # This is the accepted exact sparse parameter/guard implementation.
    spec = theorem_spec(m, beta, L)
    n, d = validate_beta(beta, L)
    k = L.shift(L.ceildiv(L.mul(L.mul(2, n), m), d))
    q = L.mul(512, k)
    plan = _plan(m, L)
    if plan.M != spec.M or q > spec.B:
        raise ArithmeticError('source parameter binding mismatch')
    L.event('source_parameter_binding')
    L.allocate(4)
    return spec, q, plan


def source_parameters(m, beta):
    """Paid exact source parameters only; no source allocation or preparation.

    Failed sparse guards report an unsupported branch by finite ValueError.
    This function is not the source algorithm's all-length branch dispatcher.
    """
    L = CompositionLedger()
    spec, q, plan = _source_parameters(m, beta, L)
    L.allocate(5)
    L.event('source_parameters_output')
    return SourceParameters(spec, q, plan, L.report())


def _execute(spec, source, q, plan, tape, scope, L):
    schedule = _schedule(plan, tape, L)
    L.event('deterministic_pipeline_handoff')
    # No public schedule/intermediary injection or altered accepted dependency.
    actual = run_pipeline(spec, source, q, schedule.location, schedule.estimation)
    L.event('deterministic_pipeline_return')
    L.allocate(18)
    L.event('fixed_tape_output')
    own = L.report()
    inherited = actual.ledger
    # Fixed-size reporting arithmetic follows the accepted metadata convention.
    # The summed bounds pay both sequential components and retained traces.
    resources = {
        'adapter': own,
        'pipeline': inherited,
        'total_bit_work_upper': own['total_bit_work_upper'] + inherited['total_bit_work_upper'],
        'cumulative_storage_upper_bits': own['cumulative_storage_upper_bits'] + inherited['cumulative_storage_upper_bits'],
        'max_observed_integer_bits': max(own['max_observed_integer_bits'], inherited['max_observed_integer_bits']),
        'model': 'sum of two paid sequential source-model ledgers; original input/tape construction and physical I/O excluded',
    }
    return FixedTapeRun(scope, schedule, actual, resources)


def run_source_tape(m, beta, source, tape):
    """Execute source-correct sparse parameters and fixed finite scheduling.

    All source domain/normalization preconditions and true bit independence
    remain caller obligations. No success guarantee is certified by inspecting
    a concrete tape. Failed sparse guards do not invoke dense fallback.
    """
    L = CompositionLedger()
    L.event('source_tape_call')
    spec, q, plan = _source_parameters(m, beta, L)
    return _execute(spec, source, q, plan, tape,
                    'source_sparse_parameters; mathematical success conditional on source theorem and caller domain/randomness', L)


def run_fixture_tape(spec, source, q, tape):
    """Reduced-parameter integration controls; never an E(beta) recovery claim."""
    L = CompositionLedger()
    L.event('fixture_tape_call')
    if type(spec) is not WindowSpec or spec.beta is not None:
        raise ValueError('an exact reduced WindowSpec with beta=None is required')
    spec.validate(L)
    L.parameter(q)
    if not 0 <= q <= spec.B:
        raise ValueError('q must be between zero and B')
    m = L.sub(L.bits(spec.M), 1)
    plan = _plan(m, L)
    return _execute(spec, source, q, plan, tape,
                    'reduced_component_fixture; no source recovery probability claim', L)
