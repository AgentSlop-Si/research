# Paid composition resource ledger

The unit is the inherited conservative binary schoolbook source model.
Every recorded primitive with operand/result magnitude widths d_i costs
16(2+sum d_i)^2. Let N be the sum of all recorded event/operation/allocation
counts plus 256, and H be the maximum observed integer width plus
bit_length(N)+2. The final report adds 512*N*H^2 for control/bookkeeping,
and the cumulative storage bound is produced signed-integer bits plus
512*N*H. Cumulative storage upper-bounds peak auxiliary storage in this
source model; it is not a resident-memory measurement.

## 1. What is charged by this API

1. Initial spec validation, including all supplied beta numerator/denominator
   widths and any derived sparse-front-end checks.
2. q and source-header recognition, exact length/F checks, every supplied
   schedule entry and both affine field widths. Invalid reached values pay
   their actual widths before rejection.
3. One actual WINDOW construction, all exact coefficient work and retained
   tap certificates; fresh certified FFT roots, reciprocal-square-root
   scale and the general BUCKETS error bound. No prior cost receipt or cache
   substitutes for computation.
4. Every BUCKETS call, including repeated spec validation, all W sample
   reads, actual queried fields, exponent alignment, folding, B-point
   bit reversal, all butterflies, scaling and final rounding.
5. Each decoder's B-pair parsing, exact magnitude ranking, q-bin selection,
   bounded inverse and all qT memberships.
6. Aggregation's complete membership parsing, per-round duplicate checks,
   complete sorting, threshold counts and increasing candidate output.
7. Each estimator's complete B-pair and K-candidate validation, K genuine
   inverse-phase preparations (including fresh pi), bucket accesses,
   exact products and final rounding. K=0 still executes and validates
   every scheduled BUCKETS output; it has zero phase preparations.
8. Median row/grid/pair validation, coordinate extraction, two exact signed
   sorts per candidate and output assembly. No numerical median rounding.
9. All new context/wrapper/trace objects, retained references, list and tuple
   copies, binding validations, loop controls and final diagnostics.

One `CompositionLedger` passes through all nine. Location's extra band/bits
methods use the same charged primitive record mechanism. The three accepted
consumers do not insist on exact ledger type and their source was inspected
to verify this interface compatibility. The two accepted report snapshots
(WINDOW's diagnostic snapshot and the final pipeline report) use the inherited
constant-sized metadata/control convention; report counters are not
recursively instrumented as data operations.

## 2. Exact new glue allocation inventory

For n_l location rounds and n_e estimation rounds, glue-only `allocate`
calls total exactly

    17 + 18*n_l + 25*n_e slots.

This includes seven initial context/engine/token slots; two list slots per
location round; nine bound-bucket slots for every round; five location
trace/reference slots; the n_l-entry membership tuple; two estimation-list
slots per round; seven estimate-binding slots; five estimation-trace slots;
the n_e-entry median-row tuple; and n_l+n_e+10 final trace/output/diagnostic
slots. These are cumulative conservative slot charges, not claims of Python
object layout. Numerical arrays are the actual component-returned tuples,
shared by reference; they are already charged by their producers.

Additional new finite events include n_l+n_e schedule entry validations,
n_l+n_e bound productions, n_l+2*n_e bucket-binding validations (the
estimate-row gate rechecks its bucket binding), n_e estimate bindings,
n_l location compositions, n_e estimation compositions, and all
2(n_l+n_e) entries across membership, estimate-row and trace tuple-copy
events. Parameter re-reads inside gates are charged
again. The report-wide envelope covers fixed-arity type/identity checks,
tuple-field access, comparisons, control counters, exception branches,
loop indices, object references and report metadata.

## 3. Component call inventory

On every successful run:

- WINDOW and BUCKETS engine construction: once
- Window spec validations: n_l+n_e+2
- BUCKETS calls: n_l+n_e
- Source queries: (n_l+n_e)W; Cartesian alignments: twice this count
- Decoder calls: n_l; membership outputs: n_l*qT
- Membership aggregation: once; output cardinality K<=min(M,2qT)
- Estimate calls: n_e; phase preparations: n_e*K
- Cartesian medians: once

The fresh trace fixture checks these exact identities against the recorded
operations. All reached malformed paths retain their prior records in the
test instrumenter; the public failure interface itself is a finite exception,
not a returned success certificate.

## 4. Symbolic event and width account

Write Q=qT, b=log2 B, p=P+1. Apart from inherited paid preparation,
a conservative event bound for execution is

    O(n_l+n_e
      +(n_l+n_e)(W+B(1+b))
      +n_l[m+B(1+log(B+1))+Q(1+log(Q+1))]
      +n_l*Q(1+log(n_l*Q+1))
      +n_e[B+K(1+p)]
      +K*n_e(1+log(n_e+1))).

The n_l*m term includes the bounded Euclidean inverse even when q=0.
The Q terms include per-round membership sorting; the n_l*Q log term
includes the combined sort. Zero-size cases are read using log(x+1) and
explicit container costs. The paid preparation is exactly the accepted
WINDOW plus B/2 certified roots, scale and error-bound preparation and is
not omitted from either the actual ledger or final asymptotic statement.

Let h bound supplied beta-field width when present. Widths include the
accepted window bound O(r*log ell+r*K_window+K_window*log K_window+P+m),
the BUCKETS bound O(h+F+(b+2)(P+2)+m+log(r+1)), the phase/factorial bound
O(P*log(P+1)+m), numerical bucket/estimate widths, and the full schedule
counter width O(log(n_l+n_e+1)). Reached malformed fields are accounted at
their actual widths, even if far wider. Neither arbitrary F, P, r, schedule
length nor beta encoding is silently treated as a fixed-size word.

For the source-specific finite regimes r=2m+1, P=16m+16, F=O_d(m),
n_l=n_e=4m+1 and q=512k, this yields an inherited conditional bound of

    O((B+T+qT)*poly_d(m+h))

for both work and cumulative auxiliary storage. The source guard and beta
fixing may be substituted only when separately established; no outer
all-length result follows. For fixed beta, h is fixed. The candidate does
not claim the displayed polynomial exponent is optimized or practical.

## 5. Caller costs and diagnostic storage

The finite input tuple is already present and read-only. Its M samples,
construction, whole-input validation and normalization are not secretly
performed or charged as zero. End-to-end usage must add their actual cost:

    C_total = C_input_representation + C_full_validation + C_normalization
              + C_pipeline + C_external_IO,

including whatever terms the caller actually performs. A caller already
holding validated immutable input need not rerun these operations, but it
cannot cite this pipeline as evidence that they happened. Original input
and supplied schedules are input storage; schedule reads/retained references
are charged here. A physical source requiring nonunit I/O must add that cost.

The diagnostic trace retains (n_l+n_e)B bucket pairs, n_l*qT memberships and
n_e*K estimates, in addition to candidates, output and preparation storage.
No claim of an ephemeral one-row peak bound is made. Their production and
references are covered by cumulative allocation. Optional user serialization
or file/network export is not part of the numerical API and needs its own
size/I/O cost. JSON receipts, source hashing, ZIP packaging, Library saving
and independent oracle work are artifact-production work, separate from
the mathematical pipeline ledger.

## 6. Fresh reconstruction

The fresh TraceLedger reconstructs arithmetic identities, operation counts,
operand/result widths using an independent binary-string length method,
the 16-square primitive charge, signed produced-integer bits, parameter
widths, allocations and final control/storage formulas. It covers successful
composition, early/late rejection and direct provenance-gate tests. The
completed receipt records 29 instances, 309,509 primitive records and
31 reconstructed reports. This checks the stated source model; it does
not formally verify Python's interpreter or the constant 512 envelope.
