"""Fresh closed whole-pipeline controls for the new fair-bit adapter."""
from dataclasses import asdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import fair_tape as f
import pipeline
from buckets import DyadicSource
from compact_window import WindowSpec
from fresh_schedule_controls import oracle, TraceLedger


def run():
    cases=[]
    fixtures=[
        ('same_round_all_zero',64,4,1,8,1,'zero'),
        ('varied_schedule',64,4,1,8,1,'pattern'),
        ('zero_candidate_all_one',64,4,1,8,0,'one'),
        ('larger_grid_all_one',128,8,1,12,1,'one'),
    ]
    for name,M,B,r,P,q,kind in fixtures:
        m=M.bit_length()-1
        n=2*(4*m+1)*(2*m-1)
        bits=tuple(0 if kind=='zero' else 1 if kind=='one' else ((j*j+j//5+j//13)%2) for j in range(n))
        source=DyadicSource(tuple((((i%5)-2,2),((i%3)-1,2)) for i in range(M)),2)
        spec=WindowSpec(M,B,r,P)
        locations,estimates=oracle(m,bits)
        actual=f.run_fixture_tape(spec,source,q,bits)
        direct=pipeline.run_pipeline(spec,source,q,locations,estimates)
        assert actual.pipeline == direct
        assert actual.schedule.location == locations and actual.schedule.estimation == estimates
        assert actual.schedule.consumed_bits == n and actual.schedule.tape is bits
        assert 'reduced_component_fixture' in actual.scope
        out=actual.pipeline
        K=len(out.candidates)
        assert K<=min(M,2*q*(M//B))
        for j,trace in enumerate(out.location_trace):
            assert trace.affine is actual.schedule.location[j]
        for j,trace in enumerate(out.estimation_trace):
            assert trace.affine is actual.schedule.estimation[j]
            assert trace.candidates is out.candidates
        ops=out.ledger['operations']
        rounds=4*m+1
        assert ops['buckets_call']==2*rounds
        assert ops['source_query']==2*rounds*spec.W
        assert ops['decode_call']==rounds and ops['estimate_call']==rounds
        assert ops.get('phase_preparation',0)==rounds*K
        assert ops['median_call']==1
        a=actual.resources['adapter']; b=actual.resources['pipeline']
        assert a['operations']['tape_bit_read']==n
        assert a['allocated_slots']==37+23*2*rounds
        assert a['operations']['deterministic_pipeline_handoff']==1
        assert a['operations']['deterministic_pipeline_return']==1
        assert actual.resources['total_bit_work_upper']==a['total_bit_work_upper']+b['total_bit_work_upper']
        assert actual.resources['cumulative_storage_upper_bits']==a['cumulative_storage_upper_bits']+b['cumulative_storage_upper_bits']
        record={'name':name,'spec':{'M':M,'B':B,'r':r,'P':P,'q':q},'candidate_count':K,
                'actual':asdict(actual)}
        (ROOT/'results'/('trace_'+name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
        cases.append({'name':name,'M':M,'B':B,'q':q,'L':rounds,'N':n,'K':K,
                      'buckets_calls':ops['buckets_call'],'source_queries':ops['source_query'],
                      'exact_entire_pipeline_equal_to_literal_schedule_control':True})

    original=f.CompositionLedger
    original_p=pipeline.CompositionLedger
    f.CompositionLedger=TraceLedger
    pipeline.CompositionLedger=TraceLedger
    spec=WindowSpec(64,4,1,8)
    source=DyadicSource(tuple(((0,0),(0,0)) for _ in range(64)),0)
    tape=(0,)*550
    traced=f.run_fixture_tape(spec,source,0,tape)
    assert traced.resources['adapter']['operations']['tape_bit_read']==550
    assert traced.pipeline.ledger['operations']['buckets_call']==50
    assert traced.pipeline.candidates==()
    captured=[]
    def reject(name,call):
        try:
            call()
        except (ValueError,TypeError):
            captured.append(name)
            TraceLedger.instances[-1].report()
        else:
            raise AssertionError('accepted '+name)
    for name,args in [
        ('fixture_wrong_spec',(object(),source,0,tape)),
        ('fixture_q_bool',(spec,source,True,tape)),
        ('fixture_q_negative',(spec,source,-1,tape)),
        ('fixture_q_too_large',(spec,source,5,tape)),
        ('fixture_short_tape',(spec,source,0,tape[:-1])),
        ('fixture_extra_tape',(spec,source,0,tape+(0,))),
        ('fixture_wrong_source',(spec,object(),0,tape)),
    ]:
        reject(name,lambda args=args:f.run_fixture_tape(*args))
    reject('fixture_source_spec_forbidden',lambda:f.run_fixture_tape(f.source_parameters(32,Fraction(1,8)).spec,source,0,tape))
    reject('public_schedule_injection',lambda:f.run_fixture_tape(spec,source,0,tape,location_schedule=((1,0),)))
    reject('public_bucket_injection',lambda:f.run_source_tape(32,Fraction(1,8),source,(),numerators=((0,0),)))
    reject('source_dense_branch',lambda:f.run_source_tape(6,Fraction(1,8),source,tape))

    # Routing-only probe for the impractically large source branch. This is
    # intentionally separate from the genuine whole numerical fixtures above.
    real_run=f.run_pipeline
    seen=[]
    zero_ledger=original().report()
    def handoff_probe(spec,source,q,loc,est):
        seen.append((spec,source,q,loc,est))
        return SimpleNamespace(ledger=zero_ledger)
    f.run_pipeline=handoff_probe
    marker=object()
    m=32; beta=Fraction(1,8); N=2*(4*m+1)*(2*m-1)
    source_tape=tuple((j//17+j)%2 for j in range(N))
    result=f.run_source_tape(m,beta,marker,source_tape)
    s,source_seen,q,loc,est=seen[0]
    assert source_seen is marker and s.M==2**32 and s.B==2**20
    assert s.r==65 and s.P==528 and s.beta==beta and q==131072
    assert loc is result.schedule.location and est is result.schedule.estimation
    assert (loc,est)==oracle(m,source_tape)
    assert len(loc)==129 and len(est)==129 and result.schedule.consumed_bits==16254
    assert result.resources['adapter']['allocated_slots']==41+23*258
    assert 'source_sparse_parameters' in result.scope
    f.run_pipeline=real_run
    f.CompositionLedger=original
    pipeline.CompositionLedger=original_p
    record={
        'status':'PASS','source_sha256':hashlib.sha256((ROOT/'src/fair_tape.py').read_bytes()).hexdigest(),
        'genuine_whole_pipeline_fixtures':cases,
        'additional_instrumented_q0_whole_pipeline':True,'public_rejections':captured,
        'source_handoff_probe':{'m':32,'beta':'1/8','L':129,'N':16254,'q':131072,
                                'numerical_pipeline_executed':False,'only_parameter_and_schedule_handoff_verified':True},
        'accounting_instances':len(TraceLedger.instances),
        'reconstructed_primitive_records':sum(x.records for x in TraceLedger.instances),
        'reconstructed_reports':sum(x.reports for x in TraceLedger.instances),
        'historical_test_execution':False,'dependency_bytes_changed':False,
        'source_theorem_sized_numerical_pipeline_executed':False,
    }
    (ROOT/'results/integration_controls.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ['status','genuine_whole_pipeline_fixtures','accounting_instances','reconstructed_primitive_records','reconstructed_reports']},indent=2))


if __name__=='__main__':
    run()
