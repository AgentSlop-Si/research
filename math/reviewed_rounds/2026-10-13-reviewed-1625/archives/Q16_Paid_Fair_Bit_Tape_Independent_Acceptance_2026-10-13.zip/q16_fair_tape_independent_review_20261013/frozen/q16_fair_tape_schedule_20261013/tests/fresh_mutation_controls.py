"""Fresh in-memory mutations of this newly authored adapter, never old code."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import fair_tape as original
from compact_window import WindowSpec
from fresh_schedule_controls import oracle, TraceLedger


def probe(module):
    for m in (1,2,3,6):
        n=2*(4*m+1)*(2*m-1)
        for bits in [(0,)*n,(1,)*n,tuple(((j*7)^(j>>1)^(j>>3))&1 for j in range(n))]:
            result=module.make_schedule(m,bits)
            t=result.schedule
            assert (t.location,t.estimation)==oracle(m,bits)
            assert t.consumed_bits==n
            assert result.ledger['operations']['parameter_input']==1+n+2*(4*m+1)
            assert result.ledger['allocated_slots']==22+23*2*(4*m+1)
            for k,d in enumerate(t.draws):
                assert (d.a_start,d.a_stop,d.tau_start,d.tau_stop)==(k*(2*m-1),k*(2*m-1)+m-1,k*(2*m-1)+m-1,(k+1)*(2*m-1))
    for bits in [(0,)*9,(0,)*11,(0,)*9+(2,),(True,)+(0,)*9]:
        try:
            module.make_schedule(1,bits)
        except (ValueError,TypeError):
            pass
        else:
            raise AssertionError('malformed tape accepted')
    ledger_class=module.CompositionLedger
    module.CompositionLedger=TraceLedger
    try:
        module.make_schedule(1,(0,)*9+(2**4096,))
    except ValueError:
        assert TraceLedger.instances[-1].max_parameter_bits==4097
        TraceLedger.instances[-1].report()
    else:
        raise AssertionError('wide malformed bit accepted')
    module.CompositionLedger=ledger_class
    seen=[]
    def route(spec,source,q,loc,est):
        seen.append((spec,source,q,loc,est))
        return SimpleNamespace(ledger=ledger_class().report())
    module.run_pipeline=route
    m=6;n=550;bits=tuple(((j*7)^(j>>1)^(j>>3))&1 for j in range(n))
    source=object(); spec=WindowSpec(64,4,1,8)
    result=module.run_fixture_tape(spec,source,1,bits)
    assert seen[-1][0] is spec and seen[-1][1] is source and seen[-1][2]==1
    assert seen[-1][3:]==oracle(m,bits)
    m=32;n=16254;bits=tuple(((j*7)^(j>>1)^(j>>3))&1 for j in range(n))
    result=module.run_source_tape(m,Fraction(1,8),source,bits)
    assert seen[-1][2]==131072 and seen[-1][3:]==oracle(m,bits)
    assert seen[-1][0].beta==Fraction(1,8)
    try:
        module.source_parameters(6,Fraction(1,8))
    except ValueError:
        pass
    else:
        raise AssertionError('unsupported dense branch accepted')


def run():
    source=(ROOT/'src/fair_tape.py').read_text()
    edits=[
        ('wrong_L','rounds = L.add(L.mul(4, m), 1)','rounds = L.add(L.mul(2, m), 1)'),
        ('wrong_bit_count','per_round = L.sub(L.mul(2, m), 1)','per_round = L.mul(2, m)'),
        ('wrong_word_base','value = L.add(L.mul(2, value), bit)','value = L.add(value, bit)'),
        ('missing_odd_offset','sigma = L.add(L.mul(2, A), 1)','sigma = L.mul(2, A)'),
        ('overlapping_tau_word','_word(tape, a_stop, m, L)','_word(tape, start, m, L)'),
        ('reuse_location_bits',"for ordinal in range(plan.rounds_per_role):","if role == 'estimation':\n            cursor = 0\n        for ordinal in range(plan.rounds_per_role):"),
        ('substitute_location_for_estimation','tuple(location), tuple(estimation), tuple(draws)','tuple(location), tuple(location), tuple(draws)'),
        ('omit_bit_width_charge','L.parameter(bit)','pass  # mutation: omit width accounting'),
        ('allow_surplus_tape','if size != required:','if size < required:'),
        ('accept_non_bit','if bit not in (0, 1):','if False:'),
        ('wrong_empty_word','value = L.record(\'word_initial_value\', (), 0)','value = L.record(\'word_initial_value\', (), 1)'),
        ('wrong_source_q','q = L.mul(512, k)','q = L.mul(256, k)'),
        ('drop_pipeline_q','run_pipeline(spec, source, q, schedule.location, schedule.estimation)','run_pipeline(spec, source, 0, schedule.location, schedule.estimation)'),
        ('swap_pipeline_roles','run_pipeline(spec, source, q, schedule.location, schedule.estimation)','run_pipeline(spec, source, q, schedule.estimation, schedule.location)'),
        ('unpaid_word_pair',"L.event('word_complete')\n    L.allocate(3)","L.event('word_complete')\n    L.allocate(0)"),
        ('wrong_trace_tau_start','start, a_stop, a_stop, tau_stop, A, sigma, tau','start, a_stop, start, tau_stop, A, sigma, tau'),
    ]
    baseline=ModuleType('fair_tape_baseline_control')
    sys.modules[baseline.__name__]=baseline
    exec(compile(source,str(ROOT/'src/fair_tape.py'),'exec'),baseline.__dict__)
    probe(baseline)
    caught=[]
    for i,(name,old,new) in enumerate(edits):
        assert source.count(old)==1,(name,source.count(old))
        module=ModuleType('fresh_fair_tape_mutant_'+str(i))
        sys.modules[module.__name__]=module
        exec(compile(source.replace(old,new),'<new-source-mutant:'+name+'>','exec'),module.__dict__)
        try:
            probe(module)
        except (AssertionError,ValueError,ArithmeticError,IndexError) as error:
            caught.append({'name':name,'detected_by':type(error).__name__})
        else:
            raise AssertionError('undetected mutant '+name)
    result={'status':'PASS','source_sha256':hashlib.sha256((ROOT/'src/fair_tape.py').read_bytes()).hexdigest(),
            'baseline_control':'PASS','new_adapter_mutants_detected':caught,
            'mutants_executed_only_in_memory':True,'original_source_modified':False,
            'historical_scientific_code_or_test_execution':False,
            'route_probes_execute_numerical_pipeline':False}
    (ROOT/'results/mutation_controls.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','detected':len(caught)},indent=2))


if __name__=='__main__':
    run()
