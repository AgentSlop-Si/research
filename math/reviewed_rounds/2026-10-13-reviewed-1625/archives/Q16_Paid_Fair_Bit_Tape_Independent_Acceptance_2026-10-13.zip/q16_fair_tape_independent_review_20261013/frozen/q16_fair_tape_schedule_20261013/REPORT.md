# Candidate result

The recovered text has an exact scheduling law; no missing-law assumption had to be invented. The new adapter pays and records exactly 2(4m+1)(2m-1) bits, producing the required two independent uniform-affine schedules under an independent fair input tape.

Fresh checks pass:

- 2,730 exhaustive single-round tapes across m=1 through 6
- All 1,024 whole schedule tapes for m=1
- 2,184 exhaustive two-variable-block assignments, both within-location and across roles
- Four genuine reduced whole-pipeline fixtures with entire numerical trace/ledger equality to literal-schedule execution; a fifth q=0 fixture reconstructs both ledgers
- 31 malformed schedule/parameter rejections and 11 integration-interface rejection controls
- Exact source parameter controls, including one clearly labeled source-route handoff probe without theorem-sized numerical execution
- 16 new-adapter source mutants detected
- 243,961 primitive records and 55 reports independently reconstructed by fresh test instrumentation

The source-specific route derives all sparse parameters and q internally; the reduced route explicitly refuses source-theorem provenance. Every completed execution returns the original tape, exact draw/word boundaries, generated schedules and actual accepted-pipeline numerical traces.

The implementation, documentation and resource account remain a candidate awaiting independent review. Conditional on the existing source theorem and all its hypotheses, the adapter supplies precisely its required distribution. No full E(beta), all-length engine or dense-fallback claim is made. No historical scientific scripts, old tests, Sheet writes or GitHub writes were used.
