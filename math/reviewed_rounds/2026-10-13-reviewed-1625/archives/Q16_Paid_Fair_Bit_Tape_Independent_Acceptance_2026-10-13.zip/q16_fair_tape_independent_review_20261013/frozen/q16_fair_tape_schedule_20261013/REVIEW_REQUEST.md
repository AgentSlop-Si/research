# Independent review request

Review the frozen new `src/fair_tape.py`, proof/resource account, and dependency identity. Do not rewrite any current accepted dependency. Use fresh reviewer-authored checks, not predecessor or producer test runners as independent evidence.

Please verify:

1. The exact recovered law, L=4m+1, N=2L(2m-1), input-fixed-before-randomness hypothesis, and fresh estimation independence.
2. Full-product uniformity, m=1 empty A edge case, word endianness, unique inverse and disjoint bit offsets.
3. Syntactic short/surplus/non-bit rejection versus no rejection on every valid binary tape; no hidden entropy/refill.
4. Actual-width charging, all helper return/reference allocations, finite controls and the two-ledger cumulative work/storage sum.
5. Source q/B/r/P binding and all sparse guards; reduced fixtures and source handoff probes clearly separated from real source-sized execution.
6. Actual generated schedule identity at the accepted pipeline, retained full traces, and unchanged byte pins.
7. Conditional success wording and explicit exclusions: no full E(beta), no dense fallback, no all-length executable, no host-totality or speed/novelty claims.

Return an independent acceptance or exact repairs, with fresh bounded tests, resources, source pin and a sealed review packet. No Sheet or GitHub writes are needed.
