# Exact finite scheduling proof and source binding

Status: new bounded implementation candidate awaiting independent review.

## 1. Frozen source and dependency

The source `ALGORITHM.txt` is byte-identical to recovered `E_BETA_ALGORITHM_V1.txt`, SHA-256 `17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1`. The source `PROOF.md` is byte-identical to recovered `E_BETA_PROOF_V1.md`, SHA-256 `0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b`. Both exact recovered bytes are included. Their recovery provenance describes historical results as historical, not fresh execution receipts.

The deterministic pipeline source is pinned to `c3a2da5a11ceba2cfa0df7bbb346525013e740e7bc170b3d27dfadc3f2be4d3b`. Its independent acceptance archive has SHA-256 `e7175180014ca6de6bd085579d139b8a3218a476e826a4e261024e5892f2b573`, verified from the available archive. Its acceptance verdict and explanation are included. All five dependency modules are unchanged; only `fair_tape.py` is a new production module.

## 2. Recovered scheduling obligations

The following source hypotheses are explicit, so there is no missing scheduling-law gap:

1. PROOF section 0 fixes the source vector before fresh independent fair bits. The domain is a previously validated normalized dyadic source; the normalization/norm promise is not established by this adapter.
2. PROOF section 1 fixes L=4m+1, q=512k, k=2^ceil(2 beta m), B=2^ceil((1/2+beta)m), r=2m+1 and P=16m+16, subject to the stated sparse guards.
3. ALGORITHM step 5 and PROOF section 3 require an (m-1)-bit uniform word A, sigma=2A+1, and a fresh m-bit word tau. PROOF section 3 explicitly requires disjoint independent bits across rounds and fixes 2m-1 bits per round.
4. ALGORITHM step 6 and PROOF section 7 require L estimation rounds, independent of all L location rounds. The same affine sampling rule applies.
5. PROOF section 7 specifies precisely 2L(2m-1) bits with no rejection, retry, timeout, hidden entropy source, or conditioning on successful tapes.

Most-significant-bit-first word interpretation is this adapter's explicit encoding convention. The source does not require an endianness. Either fixed bijective word convention has the same required law; our exact traces and tests use the stated convention.

## 3. Deterministic finite decoder

Let m>=1, M=2^m, L=4m+1, R=2L, w=2m-1, N=Rw. A valid external tape is an exact tuple of N exact integer bits in {0,1}. No Boolean, float, tuple subclass, iterator, callback, PRNG, or supplied schedule is substituted.

For round k=0,...,R-1, define s=kw. Its A word is tape[s:s+m-1] and its tau word is tape[s+m-1:s+w]. Start a word value at zero and replace it by twice itself plus the next bit. The resulting values satisfy 0<=A<2^(m-1) and 0<=tau<2^m. Set sigma=2A+1, an odd residue in [1,M-1]. For m=1 the A word is empty and A=0 exactly, so sigma=1. No inverse-CDF approximation, modulo reduction, rejection sampling, or entropy retry occurs.

The first L pairs form the location schedule; the next L form the estimation schedule. Each RoundDraw records its role, role-local ordinal, the two half-open tape ranges, A, sigma and tau. The cursor starts at zero, advances by w each round, and ends at N. Therefore all and only N tape entries are read, exactly once. The loops and retained trace sizes are fixed by m, not by bit values.

The implementation reads the full finite tape before numerical pipeline execution. The source specification interleaves these reads with computations, but its read counts and positions are independent of all numerical results. For an already fixed immutable input and no random-dependent callbacks, moving these disjoint reads earlier leaves every affine pair and numerical operation unchanged. This argument does not permit an adaptive input chosen after seeing the tape.

## 4. Exact uniformity and independence

The map from an (m-1)-bit string to A is a bijection to [0,2^(m-1)-1]. A -> 2A+1 is a bijection to odd residues modulo M. Independently, the m-bit tau block is bijective to [0,M-1]. Thus each affine pair has exactly one w-bit preimage. Under independent fair bits its probability is exactly 2^(-w)=1/((M/2)M); sigma and tau are mutually independent and uniform on their specified domains.

For the whole tape, concatenate these bijections on the R disjoint blocks. Every ordered pair of schedules of length L has exactly one N-bit preimage: recover A=(sigma-1)/2, write A and tau in their fixed widths, then concatenate. Consequently the map is a bijection between {0,1}^N and the full product schedule space. Every schedule pair has probability 2^(-N). This establishes full mutual independence of all 2L rounds, including across the location/estimation boundary, not only pairwise independence.

These are distributional claims under the fair-bit product measure. The code deterministically maps a concrete tuple to its schedules and cannot establish that the caller's randomness has that law. Repeated/all-zero tapes are valid individual outcomes and are not rejected; no promise says every tape successfully recovers the Fourier transform.

## 5. Interface rejection and exhaustion

A short or surplus tuple is outside the API's exact-length encoding domain and is rejected before any bit read. A correctly sized tuple with a malformed entry is rejected on that entry's first reached read after paying its actual integer width, where applicable. There is no incremental request for more bits, no wrapping the cursor, no refill, no zero padding, and no partial successful schedule returned. These syntactic failures are not probabilistic rejections: every element of {0,1}^N decodes successfully with exactly N reads.

The single-round API analogously requires exactly w bits. Supplying longer random streams requires a separately paid caller-side construction of the N-bit input; surplus bits are not silently ignored. Physical entropy acquisition and tuple construction are not secretly performed by the code. Every logical random-tape read is charged here.

Source parameter failures are finite unsupported-branch errors for this sparse-only component. They do not implement the source algorithm's dense fallback and must not be counted as successful all-length execution. Invalid source data, wrong fixture parameters and numerical-domain failures retain the accepted pipeline's semantics. Mathematical valid-domain finite behavior does not prove a concrete Python host cannot run out of memory.

## 6. Source-parameter binding and deterministic composition

`run_source_tape` accepts m, exact rational beta, source and tape. It calls the accepted paid sparse parameter constructor and validation, derives k and q=512k with exact integer arithmetic, and constructs the unique plan L=4m+1. Callers cannot supply a different q, B, r, P, schedule, bucket set or candidate list through this route. Guards include B dividing M, B>=4, T>=4, W<M and B>=4096k. The source guard only dispatches a sparse component; it does not implement the all-length source algorithm.

`run_fixture_tape` is explicitly separate: beta must be None and its result says reduced-component fixture. It is useful for feasible tests while retaining the exact tape law and L, but its q, r, P and B are not source parameters. It has no recovery-success claim.

Both routes pass the two actual generated immutable tuples directly to the unchanged accepted `run_pipeline`. No source-dependent schedule adaptation or intermediate replacement occurs. That pipeline supplies its own provenance-bound location, estimation and output traces. The wrapper returns those actual objects without reencoding coefficients. The four fresh feasible fixture runs match direct accepted-pipeline execution on an independently decoded literal schedule, including every numerical trace and its original ledger.

## 7. Conditional mathematical implication and exclusions

If the existing source theorem is valid and applies to this numerical instantiation, all its domain, exact-parameter, finite-error and sparse-branch hypotheses hold, and the caller supplies fresh independent fair bits independent of the fixed input, the scheduling law required by that theorem is exactly the law proved here. Under those assumptions its section 7 probability calculation remains applicable: failure at most 2M*2^(-L)=M^(-3)<=1/M, with the stated 4M^(-beta)||v||_2 target.

This is a conditional transfer of the scheduling hypothesis, not a new proof or executable certificate of the entire source theorem. In particular, this packet does not independently close all numerical-specialization/source-theorem obligations or execute a feasible theorem-parameter-sized source. The accepted deterministic component's ideal-supported-window error contract remains unchanged. Source-sized tests here cover exact parameters and handoff only; they do not masquerade as genuine numerical pipeline runs.

No full E(beta), dense fallback, all-length executable, original input validation/normalization, outer transfer, physical randomness generator, host-totality, physical RAM usage, practical speed, or novelty conclusion is asserted.

## 8. Fresh bounded evidence

The fresh controls enumerate every single-round tape for m=1,...,6, every full schedule tape for m=1, and all two-variable-block assignments in m=1,...,3 for both within-location and cross-role positions. Enumeration proves exact finite counts in these tested domains; the general result is the bijection proof above.

Four genuine reduced whole-pipeline fixtures, a fifth fully ledger-instrumented q=0 pipeline, malformed encodings, source-parameter guard controls, a clearly labeled source handoff probe, and sixteen independently detected mutations of the new adapter test the implementation. Complete counts, traces and width-accounting reconstructions are included. No predecessor test script or recovered historical scientific program was run.
