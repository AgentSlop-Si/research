# Paid finite tape and composition resource ledger

This is the accepted conservative binary schoolbook source model, not a Python runtime or resident-memory measurement. The unchanged numerical pipeline has its own cumulative ledger. The adapter has a separate sequential ledger; the returned total is their sum. Neither earlier preparation receipts nor cached numerical arrays substitute for actual execution.

## 1. Model

For each recorded primitive, magnitude widths d_i of operands and result incur 16(2+sum d_i)^2 bit-work units. Let E be the sum of event/operation/allocation counts plus 256, and H the maximum observed integer width plus bit_length(E)+2. Each ledger adds 512 E H^2 for controls and bookkeeping, and bounds cumulative auxiliary storage by produced signed-integer bits plus 512 E H. Cumulative storage conservatively bounds peak auxiliary storage for its sequential computation. The sum bounds retaining both traces.

The inherited fixed-size reporting convention covers report-counter manipulation, dictionary/report metadata and final sums of the two reports; reports do not recursively instrument themselves. Fixed-arity type/identity tests, comparisons, local indexing, loops, counters, exception branches, field accesses and static strings fall in the explicit control envelope. The source-model envelope is not a formal interpreter proof.

## 2. Operations that are paid

- Exact m recognition, actual parameter width, M=2^m, L=4m+1, w=2m-1 and N=2Lw.
- Exact tuple type/length validation, including the actual returned length width.
- Exactly N logical tape reads; each bit's integer recognition and width, exact multiply-by-two/add word accumulation, word bounds and role-local ordinal.
- Every A, sigma, tau and cursor, and the two freshly generated immutable schedules and word-boundary traces.
- All source beta numerator/denominator widths, accepted source sparse construction/guards, k and q arithmetic, and source/plan binding.
- Reduced fixture spec and q validation where that API is used.
- The handoff and return, wrapper trace references and result objects.
- The unchanged actual numerical pipeline: genuine preparation, all 2L BUCKETS calls, reached source fields, decoder/aggregation, phase estimates, medians, traces and its full original ledger.

Malformed exact integers are charged at actual width before range rejection; tests use 16,385-bit invalid m/bit encodings. Wrong noninteger types do not have an integer width and fail type recognition. There is no assumption that a malformed field fits the valid-domain word size.

## 3. Exact tape and allocation counts

Write R=2L. On every successful `make_schedule` call:

- tape reads: N=R(2m-1)
- affine draws: R
- completed words: 2R, including empty A words at m=1
- parameter-input records: 1+N+R
- schedule-tuple copies: R; draw-tuple copies: R
- cumulative explicitly allocated reference/object slots: 22+23R

The allocation inventory is six plan slots; initial list objects/references 2R+3; for each draw, ten RoundDraw slots, two three-slot word return pairs and three affine-pair slots; final schedule/draw tuple copies plus ScheduleTrace 2R+10; and three final ScheduleRun slots. Thus 6+(2R+3)+19R+(2R+10)+3=22+23R. These are conservative abstract slots, not CPython object sizes.

The standalone sampler has exactly w reads, two words, one draw and 27 explicit slots. Its plan construction also pays the source L/N formulas even though this helper returns just one affine draw.

The internal schedule construction itself allocates 23R+13 slots. Wrapper execution adds 18 slots for its result and six-entry resource map. Source parameter binding returns a separately charged four-slot tuple; the accepted parameter constructor's own finite bookkeeping convention is inherited. The reduced execution route therefore has 37+23R adapter explicit slots, and source execution has 41+23R, in addition to the numerical pipeline's allocations. Repeated spec/beta validations are charged again, not silently deduplicated.

## 4. Width and asymptotic account

For valid input, A has at most m-1 magnitude bits (the empty/zero value uses the model's one-bit minimum), sigma and tau at most m, M at most m+1, and tape/round offsets O(log(N+1)) bits. Word accumulators never exceed their final valid widths. Source rational beta encoding width h and derived arithmetic are paid separately; beta is fixed only when making the source's fixed-beta asymptotic specialization.

There are O(N) schedule primitives/events and O(R) retained records, plus fixed source-parameter work polynomial in m+h. Consequently the schedule decoder's work is O(N(m+log(N+1))^2), hence O(m^4), and its cumulative auxiliary storage is O(N(m+log(N+1))), hence O(m^3), within this model. The logical tape itself is an N-bit input; its retained reference does not copy its entries. Large Python tuple/object representations and physical I/O are not identified with this abstract bit model.

The pipeline retains its accepted source-model bound with n_l=n_e=L: preparation plus O((B+T+qT) poly_d(m+h)) under the source-specific parameter and caller width promises. Adding the paid O(m^4) scheduling overhead preserves that conditional regime. This is not an all-length result; unsupported sparse guards have no implemented dense branch here.

## 5. Trace storage and excluded caller costs

The returned trace includes the actual input tape reference, R draw records, R affine pairs, all L location bucket/selection/membership traces, all L estimation bucket/candidate/estimate traces, candidates and median output. Original numerical arrays remain shared actual dependency objects. We do not claim a streaming one-row memory bound.

Original input representation/storage, whole-input validity, normalization and source fixing before randomness remain caller duties. If the tape must first be materialized as a tuple, pay that construction and original storage separately. Physical random-bit generation is not implemented; the model's N bit reads are paid. External source access latency, disk/network I/O, JSON serialization, ZIP hashing/sealing, Library delivery, independent tests/oracles and source artifact construction are separate costs, not numerical free work.

For valid fixed input and a correctly formed tape, no random rejection, refill, retry or timeout is present. Malformed interfaces and unsupported sparse branches fail finitely as described in the proof. Actual host exhaustion is not relabeled a probability-zero event or a successful mathematical return.

## 6. Fresh reconstruction evidence

The newly written TraceLedger independently reconstructs arithmetic results, binary widths using string representations, operation counts, schoolbook charges, cumulative produced bits, parameter widths, allocation totals and both report envelopes. It covers successful schedules, source parameter calculations, rejected inputs, a genuine q=0 numerical pipeline and the source handoff probe. Receipts give exact instance, primitive and report counts. Other whole numerical fixtures compare all actual pipeline traces and ledgers against direct execution with literal positional-value decoded schedules.
