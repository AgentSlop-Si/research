"""Fresh finite enumeration and source-accounting checks; no prior tests imported."""
from collections import Counter
from dataclasses import asdict
from fractions import Fraction
from itertools import product
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import fair_tape as f


def oracle(m, tape):
    """Literal positional-value decoder, independent of production recurrence."""
    rounds = 4*m + 1
    width = 2*m - 1
    assert len(tape) == 2*rounds*width
    pairs = []
    for offset in range(0, len(tape), width):
        A = sum(tape[offset+j] * 2**(m-2-j) for j in range(m-1))
        tau = sum(tape[offset+m-1+j] * 2**(m-1-j) for j in range(m))
        pairs.append((2*A+1, tau))
    return tuple(pairs[:rounds]), tuple(pairs[rounds:])


class TraceLedger(f.CompositionLedger):
    instances = []

    def __init__(self):
        super().__init__()
        self.counts = Counter()
        self.work = self.produced = self.slots = self.parameters = 0
        self.width = self.parameter_width = 1
        self.records = self.reports = 0
        self.instances.append(self)

    def record(self, kind, inputs, output):
        operations = {
            'add': lambda x,y:x+y, 'subtract': lambda x,y:x-y,
            'multiply': lambda x,y:x*y, 'floor_divide': lambda x,y:x//y,
            'modulo': lambda x,y:x%y, 'binary_power': lambda x:2**x,
            'bit_length': lambda x:len(bin(x))-2, 'bit_and': lambda x,y:x&y,
        }
        if kind in operations:
            assert output == operations[kind](*inputs)
        widths = [max(1, len(format(abs(x), 'b'))) for x in (*inputs, output)]
        self.counts[kind] += 1
        self.work += 16 * (2 + sum(widths))**2
        self.produced += widths[-1] + 1
        self.width = max(self.width, *widths)
        self.records += 1
        return super().record(kind, inputs, output)

    def parameter(self, value):
        if type(value) is int:
            width = max(1, len(format(abs(value), 'b')))
            self.parameters += width
            self.parameter_width = max(self.parameter_width, width)
        return super().parameter(value)

    def event(self, name, count=1):
        self.counts[name] += count
        super().event(name, count)

    def allocate(self, count):
        assert type(count) is int and count >= 0
        self.counts['allocated_slots'] += count
        self.slots += count
        self.produced += count
        super().allocate(count)

    def report(self):
        result = super().report()
        events = sum(self.counts.values()) + 256
        envelope_width = self.width + len(format(events, 'b')) + 2
        assert result['operations'] == dict(sorted(self.counts.items()))
        assert result['arithmetic_bit_work_upper'] == self.work
        assert result['bookkeeping_bit_work_upper'] == 512*events*envelope_width**2
        assert result['total_bit_work_upper'] == self.work + 512*events*envelope_width**2
        assert result['cumulative_storage_upper_bits'] == self.produced + 512*events*envelope_width
        assert result['allocated_slots'] == self.slots
        assert result['max_observed_integer_bits'] == self.width
        assert result['parameter_input_bits'] == self.parameters
        assert result['max_parameter_bits'] == self.parameter_width
        self.reports += 1
        return result


def run():
    single = []
    for m in range(1, 7):
        counts = Counter()
        for bits in product((0, 1), repeat=2*m-1):
            result = f.sample_affine(m, bits)
            d = result.draw
            A = sum(bits[j]*2**(m-2-j) for j in range(m-1))
            tau = sum(bits[m-1+j]*2**(m-1-j) for j in range(m))
            assert (d.A, d.sigma, d.tau) == (A, 2*A+1, tau)
            assert (d.a_start, d.a_stop, d.tau_start, d.tau_stop) == (0, m-1, m-1, 2*m-1)
            assert result.ledger['operations']['tape_bit_read'] == len(bits)
            assert result.ledger['allocated_slots'] == 27
            counts[d.sigma, d.tau] += 1
        target = {(sigma, tau) for sigma in range(1, 2**m, 2) for tau in range(2**m)}
        assert set(counts) == target and set(counts.values()) == {1}
        single.append({'m':m,'tapes':sum(counts.values()),'outcomes':len(counts),'multiplicity':1})

    whole = Counter()
    for bits in product((0, 1), repeat=10):
        result = f.make_schedule(1, bits)
        trace = result.schedule
        assert (trace.location, trace.estimation) == oracle(1, bits)
        assert trace.consumed_bits == 10
        whole[trace.location, trace.estimation] += 1
    assert len(whole) == 1024 and set(whole.values()) == {1}

    joint = []
    for m in range(1, 4):
        n, L, width = 2*(4*m+1)*(2*m-1), 4*m+1, 2*m-1
        for relation, second in [('within_location',width), ('cross_role',L*width)]:
            counts = Counter()
            for variable in product((0,1), repeat=2*width):
                tape = [0]*n
                tape[:width] = variable[:width]
                tape[second:second+width] = variable[width:]
                trace = f.make_schedule(m, tuple(tape)).schedule
                assert (trace.location, trace.estimation) == oracle(m, tuple(tape))
                rhs = trace.location[1] if relation == 'within_location' else trace.estimation[0]
                counts[trace.location[0],rhs] += 1
            assert len(counts) == 2**(2*width) and set(counts.values()) == {1}
            joint.append({'m':m,'relation':relation,'tapes':sum(counts.values()),'outcomes':len(counts),'multiplicity':1})

    old = f.CompositionLedger
    f.CompositionLedger = TraceLedger
    widths = []
    for m in (1,2,6,17):
        n = 2*(4*m+1)*(2*m-1)
        bits = tuple((j*j+j//3+1)%2 for j in range(n))
        result = f.make_schedule(m,bits)
        trace, ops = result.schedule, result.ledger['operations']
        R = 2*(4*m+1)
        assert (trace.location,trace.estimation) == oracle(m,bits)
        assert ops['tape_bit_read'] == n
        assert ops['affine_draw'] == R
        assert ops['word_complete'] == 2*R
        assert ops['allocated_slots'] == 22+23*R
        assert ops['parameter_input'] == 1+n+R
        assert trace.tape is bits
        cursor = 0
        for j, draw in enumerate(trace.draws):
            assert draw.a_start == cursor
            assert draw.role == ('location' if j < 4*m+1 else 'estimation')
            assert draw.ordinal == j % (4*m+1)
            cursor = draw.tau_stop
        assert cursor == n
        widths.append({'m':m,'required_bits':n,'report':result.ledger})

    class TupleSubclass(tuple):
        pass
    bad = []
    def reject(name, call, bits_read=None):
        try:
            call()
        except (ValueError, TypeError):
            ledger = TraceLedger.instances[-1]
            if bits_read is not None:
                assert ledger.operations['tape_bit_read'] == bits_read
            ledger.report()
            bad.append(name)
        else:
            raise AssertionError('accepted malformed '+name)
    for name, m in [('m_bool',True),('m_float',1.0),('m_zero',0),('m_negative',-1),('m_wide_negative',-(2**16384))]:
        reject(name,lambda m=m:f.make_schedule(m,()),0)
    assert TraceLedger.instances[-1].max_parameter_bits == 16385
    for name, tape in [('short',(0,)*9),('surplus',(0,)*11),('empty',()),
                       ('list',[0]*10),('tuple_subclass',TupleSubclass([0]*10)),('iterator',iter([0]*10))]:
        reject(name,lambda tape=tape:f.make_schedule(1,tape),0)
    for pos in (0,4,9):
        for name, value in [('bool',True),('float',0.0),('negative',-1),('two',2),('wide',2**16384)]:
            tape = tuple(value if i==pos else 0 for i in range(10))
            reject(f'{name}_bit_{pos}',lambda tape=tape:f.make_schedule(1,tape),pos+1)
            if name=='wide':
                assert TraceLedger.instances[-1].max_parameter_bits == 16385
    for name, beta in [('beta_float',0.125),('beta_zero',Fraction(0)),('beta_half',Fraction(1,2))]:
        reject(name,lambda beta=beta:f.source_parameters(32,beta),0)
    reject('source_dense_length_6',lambda:f.source_parameters(6,Fraction(1,8)),0)
    reject('source_sparse_B_guard_30',lambda:f.source_parameters(30,Fraction(1,8)),0)
    positive = []
    for m,beta in [(31,Fraction(1,8)),(32,Fraction(1,8)),(64,Fraction(1,4)),(96,Fraction(3,10))]:
        result = f.source_parameters(m,beta)
        assert result.ledger['allocated_slots'] == 15
        k=2**(-(-2*beta.numerator*m//beta.denominator))
        B=2**(-(-(beta.denominator+2*beta.numerator)*m//(2*beta.denominator)))
        assert result.spec.M == 2**m and result.spec.B == B
        assert result.spec.r == 2*m+1 and result.spec.P == 16*m+16
        assert result.q == 512*k and B >= 4096*k
        assert result.spec.W < 2**m
        assert result.plan.rounds_per_role == 4*m+1
        assert result.plan.required_bits == 2*(4*m+1)*(2*m-1)
        positive.append({'m':m,'beta':str(beta),'M':2**m,'B':B,'q':result.q,'required_bits':result.plan.required_bits})
    f.CompositionLedger = old
    record = {
        'status':'PASS', 'source_sha256':hashlib.sha256((ROOT/'src/fair_tape.py').read_bytes()).hexdigest(),
        'single_round_exact_enumerations':single,
        'whole_schedule_m1':{'tapes':1024,'outcomes':1024,'multiplicity':1},
        'joint_disjoint_block_enumerations':joint,'width_reconstructions':widths,
        'malformed_rejections':bad,'source_parameter_positive_controls':positive,
        'accounting_instances':len(TraceLedger.instances),
        'reconstructed_primitive_records':sum(x.records for x in TraceLedger.instances),
        'reconstructed_reports':sum(x.reports for x in TraceLedger.instances),
        'historical_test_execution':False,
        'limits':['Finite enumeration checks bounded domains. General distribution is proved by a bijection.',
                  'No empirical test can certify that a supplied tape was generated with independent fair bits.',
                  'Source parameter tests allocate no source or theorem-sized numerical pipeline.'],
    }
    (ROOT/'results/schedule_controls.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ['status','accounting_instances','reconstructed_primitive_records','reconstructed_reports']},indent=2))


if __name__=='__main__':
    run()
