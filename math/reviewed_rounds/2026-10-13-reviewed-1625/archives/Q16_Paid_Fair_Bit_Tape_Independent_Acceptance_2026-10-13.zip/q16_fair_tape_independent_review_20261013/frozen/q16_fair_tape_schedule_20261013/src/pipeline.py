"""Bounded deterministic composition of the four pinned Q16 components.

The only scientific inputs are a WindowSpec, already represented immutable
DyadicSource, q, and two finite immutable affine schedules. There is deliberately
no public prepared-state, bucket, candidate, or estimate-row input. No randomness
or normalization pass is supplied. This is a source-level arithmetic model.
"""
from dataclasses import dataclass
from compact_window import Ledger, WindowSpec
from buckets import BucketEngine, BucketResult, DyadicSource
from location_decode import decode_round, aggregate_memberships
from phase_medians import estimate_round, cartesian_medians, EstimateResult


class CompositionLedger(Ledger):
    """The location component's two extra primitives on one cumulative ledger."""
    def band(self, a, b):
        return self.record('bit_and', (a, b), a & b)

    def bits(self, a):
        return self.record('bit_length', (a,), a.bit_length())


@dataclass(frozen=True)
class LocationTrace:
    affine: tuple
    buckets: BucketResult
    selected_buckets: tuple
    memberships: tuple


@dataclass(frozen=True)
class EstimationTrace:
    affine: tuple
    buckets: BucketResult
    candidates: tuple
    estimates: EstimateResult


@dataclass(frozen=True)
class PipelineRun:
    output: object  # The accepted MedianResult numerical interface, unchanged.
    candidates: tuple
    location_trace: tuple
    estimation_trace: tuple
    ledger: dict  # Diagnostics, never interpreted as coefficient encodings.
    bucket_error: tuple  # Numerator and exponent of the general BUCKETS error.


@dataclass(frozen=True)
class _Context:
    spec: WindowSpec
    source: DyadicSource
    location: tuple
    estimation: tuple
    capability: object


@dataclass(frozen=True)
class _BoundBuckets:
    context: _Context
    capability: object
    role: int
    ordinal: int
    affine: tuple
    spec: WindowSpec
    source: DyadicSource
    result: BucketResult


@dataclass(frozen=True)
class _BoundEstimates:
    context: _Context
    capability: object
    ordinal: int
    candidates: tuple
    buckets: _BoundBuckets
    result: EstimateResult


def _schedule(schedule, M, name, odd, L):
    L.event('schedule_container_validation')
    if type(schedule) is not tuple:
        raise ValueError(name + ' must be an exact immutable tuple')
    count = L.record('schedule_length', (), len(schedule))
    if count < 1 or (odd and L.mod(count, 2) != 1):
        raise ValueError(name + ' must be nonempty' + (' and odd length' if odd else ''))
    for affine in schedule:
        L.event('schedule_entry_validation')
        if type(affine) is not tuple:
            raise ValueError('affine entry must be an exact immutable tuple')
        size = L.record('affine_length', (), len(affine))
        if size != 2:
            raise ValueError('affine entry must contain sigma and tau')
        sigma, tau = affine
        L.parameter(sigma)
        L.parameter(tau)
        if not 1 <= sigma < M or L.mod(sigma, 2) != 1 or not 0 <= tau < M:
            raise ValueError('odd residue sigma and residue tau required')
    return count


def _initial(spec, source, q, location, estimation, L):
    L.event('pipeline_validation')
    if type(spec) is not WindowSpec:
        raise ValueError('exact WindowSpec required')
    spec.validate(L)
    L.parameter(q)
    if not 0 <= q <= spec.B:
        raise ValueError('q must be between zero and B')
    if type(source) is not DyadicSource or type(source.values) is not tuple:
        raise ValueError('exact immutable already represented DyadicSource required')
    F = L.parameter(source.fractional_bits_bound)
    size = L.record('source_length', (), len(source.values))
    if F < 0 or size != spec.M:
        raise ValueError('source header mismatch')
    nl = _schedule(location, spec.M, 'location schedule', False, L)
    ne = _schedule(estimation, spec.M, 'estimation schedule', True, L)
    return nl, ne


def _produce(context, engine, role, ordinal, L):
    L.event('bound_bucket_production')
    schedule = context.location if role == 0 else context.estimation
    affine = schedule[ordinal]
    sigma, tau = affine
    actual = engine.run(context.source, sigma, tau)
    L.allocate(9)
    return _BoundBuckets(context, context.capability, role, ordinal, affine,
                         context.spec, context.source, actual)


def _read_buckets(context, bound, role, ordinal, L):
    """Internal provenance gate; never an external scientific-data interface."""
    L.event('bucket_binding_validation')
    for value in (role, ordinal):
        L.parameter(value)
    if role not in (0, 1):
        raise ValueError('invalid bucket role')
    schedule = context.location if role == 0 else context.estimation
    size = L.record('binding_schedule_length', (), len(schedule))
    if not 0 <= ordinal < size or type(bound) is not _BoundBuckets:
        raise ValueError('bucket origin mismatch')
    # Identity is intentional: same-valued source/spec/schedule replacements
    # are not accepted as evidence of execution by this particular run.
    if (bound.context is not context or bound.capability is not context.capability
            or bound.spec is not context.spec or bound.source is not context.source
            or bound.affine is not schedule[ordinal]):
        raise ValueError('bucket origin mismatch')
    L.parameter(bound.role)
    L.parameter(bound.ordinal)
    if bound.role != role or bound.ordinal != ordinal:
        raise ValueError('bucket schedule mismatch')
    actual = bound.result
    if type(actual) is not BucketResult:
        raise ValueError('exact produced BucketResult required')
    L.parameter(actual.bits)
    if actual.bits != context.spec.P:
        raise ValueError('produced bucket grid mismatch')
    # Consumers parse every numerical field themselves; no duplicate data scan
    # is hidden here and no rounded/reencoded substitute is constructed.
    L.event('actual_bucket_forward')
    return actual


def _read_estimates(context, bound, ordinal, candidates, L):
    L.event('estimate_binding_validation')
    L.parameter(ordinal)
    if type(bound) is not _BoundEstimates:
        raise ValueError('estimate origin mismatch')
    if (bound.context is not context or bound.capability is not context.capability
            or bound.candidates is not candidates):
        raise ValueError('estimate origin or candidate-order mismatch')
    L.parameter(bound.ordinal)
    if bound.ordinal != ordinal:
        raise ValueError('estimate schedule mismatch')
    _read_buckets(context, bound.buckets, 1, ordinal, L)
    row = bound.result
    if type(row) is not EstimateResult:
        raise ValueError('exact produced EstimateResult required')
    L.parameter(row.bits)
    if row.bits != context.spec.P:
        raise ValueError('estimate grid mismatch')
    L.event('actual_estimate_forward')
    return row


def run_pipeline(spec, source, q, location_schedule, estimation_schedule):
    """Run finite deterministic Q16 steps 2--7 on supplied legal schedules.

    Location has any positive finite length; estimation has positive odd length.
    q=0 and zero sources are legal reduced-component fixtures. The source
    algorithm's q=512k and common L=4m+1 are not inferred. No external scientific
    intermediates, callback, cache, instrumenter, or deserialization are accepted.
    All source sample fields reached by BUCKETS are checked and paid there.
    Unsampled source validity, deep immutable representation, prior input
    construction/validation/normalization and any norm promise are caller duties.
    """
    L = CompositionLedger()
    L.event('pipeline_call')
    nl, ne = _initial(spec, source, q, location_schedule, estimation_schedule, L)
    context = _Context(spec, source, location_schedule, estimation_schedule, object())
    L.allocate(7)
    engine = BucketEngine(spec, L)  # Actual preparation, once, on this ledger.
    location_trace = []
    memberships = []
    L.allocate(L.mul(2, nl))
    for ordinal in range(nl):
        bound = _produce(context, engine, 0, ordinal, L)
        buckets = _read_buckets(context, bound, 0, ordinal, L)
        sigma, tau = location_schedule[ordinal]
        decoded = decode_round(spec.M, spec.B, q, sigma,
                               buckets.numerators, buckets.bits, L)
        memberships.append(decoded.memberships)
        location_trace.append(LocationTrace(bound.affine, buckets,
                                             decoded.selected_buckets, decoded.memberships))
        L.allocate(5)
        L.event('location_composition')
    L.allocate(nl)
    L.event('membership_tuple_copy', nl)
    candidates = aggregate_memberships(spec.M, spec.B, q, tuple(memberships), L)
    L.event('canonical_candidate_binding')
    estimation_trace = []
    rows = []
    L.allocate(L.mul(2, ne))
    for ordinal in range(ne):
        bound = _produce(context, engine, 1, ordinal, L)
        buckets = _read_buckets(context, bound, 1, ordinal, L)
        sigma, tau = estimation_schedule[ordinal]
        estimated = estimate_round(spec.M, spec.B, spec.P, candidates, sigma, tau,
                                   buckets.numerators, buckets.bits, L)
        bound_estimate = _BoundEstimates(context, context.capability, ordinal,
                                          candidates, bound, estimated)
        L.allocate(7)
        rows.append(_read_estimates(context, bound_estimate, ordinal, candidates, L))
        estimation_trace.append(EstimationTrace(bound.affine, buckets, candidates, estimated))
        L.allocate(5)
        L.event('estimation_composition')
    L.allocate(ne)
    L.event('estimate_tuple_copy', ne)
    output = cartesian_medians(spec.M, spec.P, candidates, tuple(rows), L)
    L.allocate(L.add(L.add(nl, ne), 10))
    L.event('trace_tuple_copy', L.add(nl, ne))
    L.event('pipeline_output')
    return PipelineRun(output, candidates, tuple(location_trace), tuple(estimation_trace),
                       L.report(), (engine._error_numerator, engine._error_bits))
