# Q16 paid fixed fair-bit tape schedule adapter

Candidate dated 2026-10-13. Independent review of this new adapter is pending.

This packet adds exact, paid finite scheduling to the independently accepted deterministic pipeline. It does not obtain physical randomness. The caller supplies an immutable finite tuple of bits. Under independent uniform fair bits, its schedules have precisely the law required by the recovered Q16 source.

- New implementation: `src/fair_tape.py`
- Exact source binding and distribution proof: `SCHEDULE_PROOF.md`
- Integer work, storage, and tape account: `RESOURCE_LEDGER.md`
- Obligation status and limits: `PROOF_LEDGER.json`
- Current dependency pins: `SOURCE_PROVENANCE.json`
- Full reduced-fixture tape and numerical traces: `results/trace_*.json`

## API

`make_schedule(m, tape)` makes L=4m+1 location and L estimation affine pairs, consuming exactly N=2L(2m-1) bits. `sample_affine(m, tape)` exposes the identical single-round decoder, consuming 2m-1 bits. Both reject a short or surplus tape before any bit read.

`source_parameters(m, beta)` computes and pays the source's exact sparse parameters and guards, with beta an exact Fraction. It neither allocates a source nor executes its numerical pipeline.

`run_source_tape(m, beta, source, tape)` derives q and the full source sparse specification internally, makes the two exact schedules, and invokes the unchanged accepted pipeline. It has no dense fallback. The caller must already hold a valid, deeply immutable DyadicSource, fixed before the fresh randomness, with the source's normalization and input promises.

`run_fixture_tape(spec, source, q, tape)` accepts only a reduced WindowSpec with beta=None. It uses the same number of rounds and tape procedure but makes no recovery probability claim. This is the practical whole-pipeline test route.

Results retain the original tape by reference, every draw's roles/word boundaries/values, both affine schedules, and all accepted pipeline numerical traces. There is no public schedule, bucket, candidate, or prepared-state injection interface into these execution routes.

## Fresh verification

Run only the newly authored checks:

    python tests/fresh_schedule_controls.py
    python tests/fresh_integration_controls.py
    python tests/fresh_mutation_controls.py
    python verify_package.py

The first three checks execute this new adapter and the exact currently accepted component implementations. They import no historical scientific script or predecessor test runner. The seal verifier only reads and hashes artifacts. Test/oracle, packaging, and optional serialization costs are not the numerical API's ledger.

## Scope

Uniformity and full independence are proved for the pushforward of a uniform fixed-length bit tape; observing a particular tape does not certify that it was fairly generated. Mathematical recovery success remains conditional on the existing source theorem and all its input, numerical and sparse-branch hypotheses. No full E(beta), all-length implementation, dense fallback, physical RAM bound, host-totality, practical-speed, or novelty claim is made. No Sheet or GitHub changes were made.
