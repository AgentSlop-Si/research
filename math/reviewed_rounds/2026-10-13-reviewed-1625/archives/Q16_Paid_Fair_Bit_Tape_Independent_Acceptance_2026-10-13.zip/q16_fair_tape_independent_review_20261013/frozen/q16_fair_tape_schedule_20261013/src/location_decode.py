"""Exact paid Q16 step-5 rank/decode and majority-membership candidate.

No source access, roots, random generator, probability guarantee, or recovery
loop is supplied. Common-grid bucket numerators and odd sigma are inputs.
Only this fresh module is executed; accepted predecessors are source evidence.
"""
from collections import Counter
from dataclasses import dataclass, field


@dataclass
class Ledger:
    """Same conservative finite-bit source model as accepted WINDOW/BUCKETS."""
    operations: Counter = field(default_factory=Counter)
    arithmetic_bit_work_upper: int = 0
    cumulative_integer_bits: int = 0
    max_integer_bits: int = 1
    allocated_slots: int = 0
    parameter_input_bits: int = 0
    max_parameter_bits: int = 1

    def record(self, kind, inputs, output):
        widths = [max(1, abs(x).bit_length()) for x in (*inputs, output)]
        width = 2 + sum(widths)
        self.operations[kind] += 1
        self.arithmetic_bit_work_upper += 16 * width * width
        self.cumulative_integer_bits += widths[-1] + 1
        self.max_integer_bits = max(self.max_integer_bits, *widths)
        return output

    def parameter(self, value):
        if type(value) is not int:
            self.event('invalid_integer_type')
            raise ValueError('exact integer required')
        width = max(1, abs(value).bit_length())
        self.parameter_input_bits += width
        self.max_parameter_bits = max(self.max_parameter_bits, width)
        return self.record('parameter_input', (), value)

    def add(self, a, b): return self.record('add', (a, b), a + b)
    def sub(self, a, b): return self.record('subtract', (a, b), a - b)
    def mul(self, a, b): return self.record('multiply', (a, b), a * b)
    def div(self, a, b): return self.record('floor_divide', (a, b), a // b)
    def mod(self, a, b): return self.record('modulo', (a, b), a % b)
    def band(self, a, b): return self.record('bit_and', (a, b), a & b)
    def bits(self, a): return self.record('bit_length', (a,), a.bit_length())
    def event(self, name, count=1): self.operations[name] += count

    def allocate(self, n):
        self.allocated_slots += n
        self.operations['allocated_slots'] += n
        self.cumulative_integer_bits += n

    def report(self):
        events = sum(self.operations.values()) + 256
        width = self.max_integer_bits + events.bit_length() + 2
        controls = 512 * events * width * width
        return dict(operations=dict(sorted(self.operations.items())),
                    arithmetic_bit_work_upper=self.arithmetic_bit_work_upper,
                    bookkeeping_bit_work_upper=controls,
                    total_bit_work_upper=self.arithmetic_bit_work_upper + controls,
                    cumulative_storage_upper_bits=self.cumulative_integer_bits + 512 * events * width,
                    max_observed_integer_bits=self.max_integer_bits,
                    allocated_slots=self.allocated_slots,
                    parameter_input_bits=self.parameter_input_bits,
                    max_parameter_bits=self.max_parameter_bits,
                    model='schoolbook binary arithmetic plus conservative control/cumulative storage; excludes Python runtime and test oracle')


@dataclass(frozen=True)
class RoundCandidates:
    selected_buckets: tuple
    memberships: tuple


def _geometry(M, B, q, L):
    L.event('geometry_validation')
    for value in (M, B, q): L.parameter(value)
    if M < 4 or B < 2 or q < 0:
        raise ValueError('M>=4, B>=2 and q>=0 required')
    if L.band(M, L.sub(M, 1)) or L.band(B, L.sub(B, 1)):
        raise ValueError('M and B must be powers of two')
    if B > L.div(M, 2) or q > B:
        raise ValueError('B<=M/2 and q<=B required')
    T = L.div(M, B)
    m = L.sub(L.bits(M), 1)
    return T, m, L.mul(q, T)


def _merge_sort(values, ranked, L):
    """Explicit stable bottom-up merges; ranked items are (score, index)."""
    n = L.record('sort_length', (), len(values))
    L.allocate(L.mul(2, n))
    src = list(values)
    dst = [None] * n
    L.event('sort_initial_copy', n)
    width = 1
    while width < n:
        step = L.mul(2, width)
        for start in range(0, n, step):
            middle = min(L.add(start, width), n)
            end = min(L.add(start, step), n)
            left, right = start, middle
            for out in range(start, end):
                if left >= middle:
                    take_left = False
                elif right >= end:
                    take_left = True
                else:
                    a, b = src[left], src[right]
                    if ranked:
                        take_left = a[0] > b[0] or (a[0] == b[0] and a[1] <= b[1])
                    else:
                        take_left = a <= b
                    L.event('sort_compare')
                if take_left:
                    dst[out] = src[left]
                    left = L.add(left, 1)
                else:
                    dst[out] = src[right]
                    right = L.add(right, 1)
                L.event('sort_copy')
            L.event('sort_merge')
        src, dst = dst, src
        width = step
        L.event('sort_pass')
    return src


def _inverse_odd(sigma, M, m, L):
    """Extended Euclid, at most 2m+2 divisions on the validated domain."""
    old_r, r = M, sigma
    old_t, t = 0, 1
    limit = L.add(L.mul(2, m), 2)
    for _ in range(limit):
        if r == 0:
            break
        quotient = L.div(old_r, r)
        old_r, r = r, L.sub(old_r, L.mul(quotient, r))
        old_t, t = t, L.sub(old_t, L.mul(quotient, t))
        L.event('euclid_step')
    if r != 0 or old_r != 1:
        raise ArithmeticError('unreachable Euclidean invariant failure')
    inverse = L.mod(old_t, M)
    if L.mod(L.mul(sigma, inverse), M) != 1:
        raise ArithmeticError('unreachable modular inverse failure')
    L.event('inverse_output')
    return inverse


def decode_round(M, B, q, sigma, numerators, bits, ledger=None):
    """Exact ALGORITHM step-5 ranking and unknown-index enumeration.

    Numerators is exactly a tuple of B tuples (real_int, imag_int), on common
    grid 2**(-bits). q may be zero for this reduced component. The theorem
    caller uses q=512k>0 and has already constructed BUCKETS, not done here.
    Returns indices in selected-rank order, then increasing half-open offset.
    """
    L = ledger if ledger is not None else Ledger()
    L.event('decode_call')
    T, m, count = _geometry(M, B, q, L)
    L.parameter(sigma)
    L.parameter(bits)
    if sigma < 1 or sigma >= M or L.mod(sigma, 2) != 1 or bits < 0:
        raise ValueError('odd residue sigma and nonnegative common exponent required')
    if type(numerators) is not tuple:
        raise ValueError('immutable bucket tuple required')
    size = L.record('bucket_length', (), len(numerators))
    if size != B:
        raise ValueError('bucket count differs from B')
    scores = []
    L.allocate(B)
    for j in range(B):
        pair = numerators[j]
        L.event('bucket_read')
        if type(pair) is not tuple:
            raise ValueError('two-integer Cartesian bucket tuple required')
        pair_size = L.record('bucket_pair_length', (), len(pair))
        if pair_size != 2:
            raise ValueError('two-integer Cartesian bucket tuple required')
        real, imag = pair
        L.parameter(real)
        L.parameter(imag)
        score = L.add(L.mul(real, real), L.mul(imag, imag))
        scores.append((score, j))
        L.allocate(3)
        L.event('bucket_score')
    ordered = _merge_sort(scores, True, L)
    selected = []
    L.allocate(q)
    for at in range(q):
        selected.append(ordered[at][1])
        L.event('bucket_selected')
    inverse = _inverse_odd(sigma, M, m, L)
    half = L.div(T, 2)
    output = []
    L.allocate(count)
    for j in selected:
        start = L.sub(L.mul(j, T), half)
        for offset in range(T):
            residue = L.mod(L.add(start, offset), M)
            index = L.mod(L.mul(inverse, residue), M)
            output.append(index)
            L.event('membership_output')
    L.allocate(L.add(q, count))
    L.event('round_output')
    return RoundCandidates(tuple(selected), tuple(output))


def aggregate_memberships(M, B, q, rounds, ledger=None):
    """Validate explicit per-round distinct lists and retain ceil(L/2) votes.

    rounds must be a nonempty immutable tuple of immutable qT-index tuples.
    No claimed origin or stochastic independence is inferred from these lists.
    All lists, duplicates/rejections and sorting are visibly paid.
    """
    L = ledger if ledger is not None else Ledger()
    L.event('aggregation_call')
    T, m, count = _geometry(M, B, q, L)
    if type(rounds) is not tuple:
        raise ValueError('immutable rounds tuple required')
    number = L.record('round_count', (), len(rounds))
    if number < 1:
        raise ValueError('at least one round required')
    total = L.mul(number, count)
    threshold = L.div(L.add(number, 1), 2)
    complete = []
    L.allocate(total)
    for current in rounds:
        L.event('round_read')
        if type(current) is not tuple:
            raise ValueError('immutable membership tuple required')
        size = L.record('membership_length', (), len(current))
        if size != count:
            raise ValueError('every round must contain qT entries')
        for index in current:
            L.parameter(index)
            L.event('membership_read')
            if index < 0 or index >= M:
                raise ValueError('membership index outside [0,M)')
        ordered = _merge_sort(current, False, L)
        for at in range(1, size):
            if ordered[at] == ordered[L.sub(at, 1)]:
                raise ValueError('duplicate index within one round')
            L.event('distinctness_compare')
        for index in ordered:
            complete.append(index)
            L.event('complete_membership_copy')
    ordered = _merge_sort(complete, False, L)
    output = []
    L.allocate(total)
    at = 0
    while at < total:
        stop = L.add(at, 1)
        while stop < total and ordered[stop] == ordered[at]:
            stop = L.add(stop, 1)
            L.event('equal_membership')
        votes = L.sub(stop, at)
        if votes >= threshold:
            output.append(ordered[at])
            L.event('candidate_output')
        at = stop
        L.event('membership_group')
    output_count = L.record('candidate_count', (), len(output))
    if L.mul(output_count, threshold) > total:
        raise ArithmeticError('unreachable support cardinality failure')
    L.allocate(output_count)
    L.event('aggregate_output')
    return tuple(output)
