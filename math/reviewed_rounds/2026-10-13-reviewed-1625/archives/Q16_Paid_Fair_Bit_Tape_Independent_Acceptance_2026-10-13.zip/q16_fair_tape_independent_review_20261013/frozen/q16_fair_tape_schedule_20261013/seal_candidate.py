"""Seal this completed new candidate and its fresh controls, without running code."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
pins={
 'pipeline.py':'c3a2da5a11ceba2cfa0df7bbb346525013e740e7bc170b3d27dfadc3f2be4d3b',
 'compact_window.py':'e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59',
 'buckets.py':'df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1',
 'location_decode.py':'e3b592c40906d860d58c12cf7e21f17c6560cb8c95e7bcde4c161b0d52881c3a',
 'phase_medians.py':'45c0c6a59cac18912278dcda183fe8e5bea2a19398cb61fc1bf8ec97cac5a788',
}
for name,pin in pins.items():
 assert sha(ROOT/'src'/name)==pin
math_pins={'ALGORITHM.txt':'17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1',
           'PROOF.md':'0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b'}
recovered={'ALGORITHM.txt':'E_BETA_ALGORITHM_V1.txt','PROOF.md':'E_BETA_PROOF_V1.md'}
for name,pin in math_pins.items():
 assert sha(ROOT/'sources'/name)==pin
 assert (ROOT/'sources'/name).read_bytes()==(BASE/'q16_recovered_from_context_20261013/reconstructed'/recovered[name]).read_bytes()
archive=BASE/'Q16_Deterministic_Pipeline_Independent_Acceptance_2026-10-13.zip'
assert sha(archive)=='e7175180014ca6de6bd085579d139b8a3218a476e826a4e261024e5892f2b573'
source_hash=sha(ROOT/'src/fair_tape.py')
receipts={name:json.loads((ROOT/'results'/(name+'.json')).read_text()) for name in ['schedule_controls','integration_controls','mutation_controls']}
for receipt in receipts.values():
 assert receipt['status']=='PASS' and receipt['source_sha256']==source_hash
node=ast.parse((ROOT/'src/fair_tape.py').read_text())
imports=[]
for obj in ast.walk(node):
 if isinstance(obj,ast.ImportFrom):imports.append(obj.module)
 elif isinstance(obj,ast.Import):imports.extend(n.name for n in obj.names)
assert sorted(imports)==['compact_window','dataclasses','pipeline']
assert not any(isinstance(obj,ast.Constant) and isinstance(obj.value,float) for obj in ast.walk(node))
write(ROOT/'results/static_audit.json',{'status':'PASS','source_sha256':source_hash,'imports':imports,
 'floating_literals':False,'host_randomness_import':False,'dependency_pins_verified':pins,
 'recovered_mathematical_bytes_verified':math_pins,'no_historical_program_executed_by_seal':True})
write(ROOT/'SOURCE_PROVENANCE.json',{
 'accepted_dependency_pins':pins,'new_production_source':{'path':'src/fair_tape.py','sha256':source_hash},
 'deterministic_independent_acceptance_archive':{'filename':archive.name,'sha256':sha(archive)},
 'mathematical_sources':{n:{'sha256':h,'recovered_path':'q16_recovered_from_context_20261013/reconstructed/'+recovered[n]} for n,h in math_pins.items()},
 'recovered_source_bytes_exactly_compared':True,'dependency_bytes_unchanged':True,
 'executed_scientific_code':'Only the new adapter and current independently accepted deterministic component modules; fresh newly authored tests and new in-memory adapter mutants.',
 'historical_scientific_programs_or_predecessor_tests_executed':False,
 'external_mutations':{'sheets':False,'github':False,'sharing_permissions':False},
})
write(ROOT/'PROOF_LEDGER.json',{
 'status':'CANDIDATE_AWAITING_INDEPENDENT_REVIEW','date_utc':'2026-10-13',
 'scope':'Paid exact fixed fair-bit tape schedule adapter into unchanged accepted deterministic sparse/reduced pipeline; no all-length or full-recovery certificate.',
 'obligations':[
  {'id':'S1','claim':'Scheduling law, L, independence and bit count are explicit in exact recovered source.','status':'VERIFIED_SOURCE_BINDING','evidence':['sources/ALGORITHM.txt','sources/PROOF.md','SOURCE_PROVENANCE.json']},
  {'id':'S2','claim':'The deterministic decoder is a bijection from N-bit tapes to all ordered schedule pairs.','status':'PROVED_CANDIDATE','evidence':'SCHEDULE_PROOF.md sections 3-4'},
  {'id':'S3','claim':'Under uniform independent input bits, sigma is uniformly odd, tau uniform, and all 2L rounds mutually independent.','status':'CONDITIONAL_ON_FAIR_BIT_PRODUCT_MEASURE','evidence':['SCHEDULE_PROOF.md section 4','results/schedule_controls.json']},
  {'id':'S4','claim':'Every well-formed tape consumes exactly N=2L(2m-1) bits with no random rejection or refill.','status':'PROVED_CANDIDATE','evidence':'SCHEDULE_PROOF.md section 5'},
  {'id':'S5','claim':'Source route derives exact source sparse parameters and q; reduced route explicitly has no recovery theorem.','status':'VERIFIED_BOUNDED_PARAMETER_AND_HANDOFF_CONTROLS','evidence':'results/integration_controls.json'},
  {'id':'S6','claim':'Actual generated schedules feed the unchanged accepted pipeline and its actual numerical traces are retained.','status':'VERIFIED_REDUCED_WHOLE_PIPELINE_CONTROLS','evidence':'results/integration_controls.json'},
  {'id':'S7','claim':'Tape reads, actual integer widths, allocation, metadata envelope and cumulative resource composition are paid.','status':'SOURCE_MODEL_CANDIDATE','evidence':['RESOURCE_LEDGER.md','results/schedule_controls.json','results/integration_controls.json']},
  {'id':'S8','claim':'Mathematical success guarantee follows only if the existing source theorem and its numerical/domain/branch hypotheses apply.','status':'CONDITIONAL_ONLY','evidence':'SCHEDULE_PROOF.md section 7'},
  {'id':'S9','claim':'The supplied tape was physically generated with independent fair bits, independent of the input.','status':'CALLER_PRECONDITION_NOT_OBSERVATIONALLY_CERTIFIED'},
  {'id':'S10','claim':'Whole-input representation, deep immutability, validity and normalization.','status':'CALLER_OBLIGATIONS_WITH_ADDITIVE_COSTS'},
  {'id':'S11','claim':'Source-theorem-sized genuine numerical execution, full E(beta), dense fallback, all-length engine, outer transfer, host-totality, practical speed, novelty.','status':'NOT_CLAIMED'},
  {'id':'S12','claim':'Independent review of this adapter and its new proof/resource account.','status':'PENDING'},
 ],
 'fresh_controls':{
  'single_round_tapes':sum(x['tapes'] for x in receipts['schedule_controls']['single_round_exact_enumerations']),
  'whole_schedule_m1_tapes':1024,
  'joint_two_variable_block_tapes':sum(x['tapes'] for x in receipts['schedule_controls']['joint_disjoint_block_enumerations']),
  'genuine_reduced_whole_pipeline_fixture_runs':5,'literal_schedule_full_trace_comparisons':4,
  'schedule_malformed_rejections':len(receipts['schedule_controls']['malformed_rejections']),
  'integration_public_rejections':len(receipts['integration_controls']['public_rejections']),
  'new_source_mutants_detected':len(receipts['mutation_controls']['new_adapter_mutants_detected']),
  'reconstructed_primitive_records':receipts['schedule_controls']['reconstructed_primitive_records']+receipts['integration_controls']['reconstructed_primitive_records'],
  'reconstructed_reports':receipts['schedule_controls']['reconstructed_reports']+receipts['integration_controls']['reconstructed_reports'],
  'source_handoff_probe_genuine_numerical_execution':False,
 },
 'sheet_or_github_writes':False,'historical_scientific_execution':False,
})
files=[]
for path in sorted(ROOT.rglob('*')):
 if not path.is_file() or '__pycache__' in path.parts or path.name in ['MANIFEST.json','SEAL.json'] and path.parent==ROOT:continue
 if path.suffix=='.pyc':continue
 files.append({'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':sha(path)})
write(ROOT/'MANIFEST.json',{'files':files,'accepted_dependency_pins':pins})
write(ROOT/'SEAL.json',{'manifest_sha256':sha(ROOT/'MANIFEST.json'),'files':len(files),
 'production_source_sha256':source_hash,'scope':'Paid exact fixed fair-bit tape scheduling and reduced whole-pipeline integration; source success conditional; no full E(beta), dense fallback, or all-length executable.'})
output=BASE/'Q16_Paid_Fair_Bit_Tape_Schedule_Candidate_2026-10-13.zip'
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel in sorted([x['path'] for x in files]+['MANIFEST.json','SEAL.json']):
  info=zipfile.ZipInfo(ROOT.name+'/'+rel,date_time=(2026,10,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  info.external_attr=0o644<<16
  z.writestr(info,(ROOT/rel).read_bytes())
write(Path(str(output)+'.seal.json'),{'filename':output.name,'bytes':output.stat().st_size,'sha256':sha(output),
 'manifest_sha256':sha(ROOT/'MANIFEST.json'),'production_source_sha256':source_hash,
 'status':'CANDIDATE_AWAITING_INDEPENDENT_REVIEW'})
print(json.dumps(json.loads(Path(str(output)+'.seal.json').read_text()),indent=2))
