# Q16 paid fair bit tape schedule independent review

## Verdict and exact scope

ACCEPT, subject to the stated caller and numerical-dependency hypotheses. No repair to the frozen adapter is required for the bounded paid schedule component reviewed here. The final machine-readable verdict and fresh evidence counts are in VERDICT.json and results/SUMMARY.json.

This acceptance closes the exact fair-bit decoder, its full-product scheduling law conditional on a uniform input tape, finite syntactic validation, actual-width source-model accounting, source-parameter binding, and direct composition with the already accepted deterministic pipeline. It does not prove the full E(beta) numerical recovery theorem, certify physical entropy acquisition, implement the exceptional dense branch, or provide an all-length executable. A correctly shaped binary tape always produces a schedule; a particular tape need not recover the Fourier transform successfully.

Reviewed candidate archive: Q16_Paid_Fair_Bit_Tape_Schedule_Candidate_2026-10-13.zip, 104614 bytes, SHA-256 0d664d295d0672ce4926c70f495ba64b89e0960456fa08d243b4dcf0e43909de.

Reviewed production module: src/fair_tape.py, SHA-256 252d154e654d58bac4a9dddaaddcec939607801efc8ad6d9babd2c9cf8d260c4. The review uses an exact extraction of that archive rather than any mutable working copy. All 37 manifest entries and the manifest seal were independently checked. All five numerical dependency modules match the independent deterministic acceptance archive e7175180014ca6de6bd085579d139b8a3218a476e826a4e261024e5892f2b573 byte for byte.

## Scheduling law and full independence

Let m be an exact integer at least one, M=2^m, L=4m+1, R=2L, w=2m-1 and N=Rw. A valid tape is an exact immutable tuple of N exact integer bits, each zero or one. For round k from zero through R-1, put s=kw. The A block is the half-open interval [s,s+m-1); the shift block is [s+m-1,s+w). The first L rounds are location rounds and the remaining L are estimation rounds.

The recurrence starting at zero and replacing x by 2x+b implements the most-significant-bit-first word value. Its value for a width-u block is the sum of b_j times 2^(u-1-j), by induction on the number of consumed positions. It is therefore a bijection from u-bit strings to integers in [0,2^u). In particular A is in [0,2^(m-1)), tau is in [0,2^m), and sigma=2A+1 runs bijectively through the odd residues modulo M. For m=1, A has an empty block, the recurrence returns zero, and sigma is exactly one.

The round map is a bijection from w bits to the pair space of odd sigma and arbitrary tau. Its inverse takes A=(sigma-1)/2 and expands A and tau at their exact widths. Applying that inverse to every ordered round gives a unique inverse for the entire tape. Thus the complete map is a bijection from {0,1}^N to the product of R affine-pair spaces. Under the uniform measure on {0,1}^N, every complete ordered schedule pair has probability 2^(-N), and every round has probability 2^(-w) for each valid pair. This establishes mutual independence of all rounds and, within each round, independence of sigma and tau. Pairwise tests alone would not establish this result; the general proof is the product bijection.

The code implements the same intervals: each draw's next cursor is its shift stop, and each subsequent round begins there. Induction gives starts 0,w,...,(R-1)w and final cursor N. There are exactly N reads, with no overlap, skip, wrap or refill. Location and estimation are not reused or interleaved ambiguously. Endianness is an explicit encoding convention, compatible with the source's uniform-word law.

The source ALGORITHM steps 5 and 6, and PROOF sections 0, 1, 3 and 7, specify these parameters and the independent fair bits. Their included SHA-256 pins are respectively 17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1 and 0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b. They are recovered mathematical source texts, not new execution evidence. The numerical source must have been fixed independently before the random tape. Because the bit positions and counts do not depend on numerical results, producing both schedules before the pipeline preserves the specified joint law for that fixed input. It does not authorize choosing an input after viewing its schedule.

## Validation and all tape behavior

The public schedule and single-round APIs reject tuple subclasses, lists, iterators, noninteger m, Boolean m, nonpositive m, incorrect lengths, and noninteger or nonbinary entries. Boolean and integer-subclass bits are rejected through exact integer recognition. Wrong lengths are rejected before the first bit read. A bad entry in a correctly sized tuple is rejected on its first reached read, with no successful partial schedule. The adapter does not read subsequent entries after an error and does not claim it has validated an unreached suffix.

These are syntactic-domain failures, not random rejections. Every element of the valid binary tape space is processed by the same finite loops. In particular repeated, all-zero and all-one tapes remain valid outcomes, with exactly the same read count. There is no entropy source, rejection sampler, random retry, timeout, partial refill or external schedule injection in the new module. Its imports are limited to dataclasses and the accepted deterministic components.

Actual-width recognition precedes integer range tests. The fresh controls include 16385-bit invalid negative m, out-of-range bits at different positions, and an invalid rational-beta numerator. Their widths are recorded before rejection. Type failures need no integer-width charge but are covered by the fixed control envelope. Public failure paths are finite within the abstract machine model; Python host exhaustion is not thereby ruled out.

## Source binding and numerical provenance

The source route computes the accepted WindowSpec from m and exact rational beta. It independently derives k=2^ceil(2 beta m), q=512k and the plan. Its WindowSpec enforces B=2^ceil((1/2+beta)m), r=2m+1, P=16m+16 and all sparse predicates: B divides M, B>=4, T=M/B>=4, W=2r(8B-1)+1<M and B>=4096k. Hence q<=B; the additional binding check compares the plan M and computed q with the spec. No caller-supplied q, schedule, prepared bucket or candidate set enters this route.

The fresh parameter-grid test independently computes literal rational ceilings and the sparse predicate for 640 (m,beta) pairs. Guard failures are explicitly unsupported sparse cases, not an implementation of the mathematical source's finite dense branch. For beta=1/8, m=31 already passes the sparse predicates; m=30 does not. This exact rounding boundary is covered by the independent tests.

The reduced route requires an exact WindowSpec with beta=None and a legal q. Its result explicitly identifies itself as a reduced component fixture with no source recovery probability claim. Its feasible q, r, P and B cannot be used as evidence of a theorem-parameter-sized run.

Both wrappers pass the actual generated immutable tuple objects directly to the accepted pipeline. The retained pipeline trace's affine entries are the same pair objects in those schedules, and its estimation traces retain the same actual candidate object. Four fresh real numerical pipeline fixtures check this identity as well as exact equality of the complete pipeline result and ledger to a direct run with independently decoded schedules. They include nonzero input, q=B with all M candidates, varied schedules, q=0, and two grid sizes. No numerical result is replaced with a fabricated row or source-dependent schedule.

The separate m=32, beta=1/8 source-route probe checks exact parameter and schedule-object handoff only, using a clearly labeled stub. No numerical theorem-sized pipeline is executed or claimed for that probe. The proof of all-size wrapper dataflow additionally follows from the single direct run_pipeline call in the frozen _execute body.

## Independent resource account

For each recorded primitive with operand and result magnitude widths d_i, the inherited model charges 16(2+sum d_i)^2 units. If E is the sum of operation, event and allocation counts plus 256, and H is maximum recorded width plus bit_length(E)+2, controls add 512 E H^2. Storage is produced signed-integer bits plus 512 E H. These are conservative source-model accounting bounds; their interpretation is inherited from the accepted numerical pipeline. They are not measurements of Python time or resident memory and not a formal interpreter proof.

The new adapter records all plan arithmetic, tuple length, exact bit reads and recognition, word accumulations, draw ordinals and offsets, source-beta fields, source guard computations, and generated tuple/reference allocations. Fixed-arity comparisons, local accesses, loop steps, branches and exception handling are assigned to the explicit control envelope. Fixed-size ledger reporting and the final report sums follow the accepted nonrecursive metadata convention.

For every successful make_schedule call:

- N=R(2m-1) logical tape reads;
- R affine draws and 2R completed words, including empty A words;
- 1+N+R integer-parameter records;
- R schedule-copy events and R draw-copy events;
- 22+23R explicit object/reference slots.

The slot count is 6 for the plan; 2R+3 for initial list storage; 19R for two word-return pairs, one RoundDraw and one affine pair per round; 2R+10 for final immutable tuples and ScheduleTrace; and 3 for ScheduleRun. The single-round sampler has 6+6+10+5=27 slots. Internal _schedule contributes 23R+13; source parameter binding adds a four-slot returned tuple. The complete reduced adapter contributes 37+23R slots, and the source adapter 41+23R, plus the separately paid numerical pipeline. These totals conservatively include allocated return containers and reference copies; the original tape remains an input reference, not a copied tuple.

The fresh shadow ledger reconstructs primitive results where arithmetic applies, operand/result widths from binary strings, counters, exact charges, produced bits, allocation totals, parameter widths and all report fields. It also reconstructs ledgers reached on interface failures, instead of inspecting successful outputs alone. Both numerical and adapter ledgers are traced for actual fixtures, and the final resource sums are checked exactly. Numerical trace and returned resource dictionaries reference the actual pipeline ledger.

On valid tapes, recorded value widths are at most O(m+log(N+1)); the number of schedule primitives is O(N), and N=Theta(m^2). The schoolbook decoder and control terms therefore give O(N(m+log(N+1))^2)=O(m^4) work and O(N(m+log(N+1)))=O(m^3) cumulative auxiliary storage. A fixed rational-beta encoding contributes its separately paid polynomial parameter work; variable encoding widths are not silently treated as constant.

Two ledgers describe sequential components, with both traces retained. Adding their cumulative storage upper bounds bounds the peak auxiliary storage of their composition; adding their work bounds pays both components. The wrapper accounts for its result/resource container before reporting. This does not erase the accepted preparation, source queries, exact arithmetic, decoder, phase, sorting or median costs in the numerical ledger.

Input construction and storage, physical entropy collection, tape-tuple construction, unsampled source validation, prior normalization, external I/O, serialization of review traces and review/sealing work remain explicit caller or delivery costs. No paid numerical work is inferred from cached earlier receipts.

## Conditional recovery wording

Under the product fair-bit measure independent of the fixed input, this adapter supplies exactly the scheduling hypothesis used in the recovered source probability argument. If that source theorem is valid and all its numerical instantiation, domain, normalization, precision, sparse and finite-error hypotheses hold, its stated union bound is unchanged: 2M*2^(-L)=M^(-3)<=1/M and the stated error target is 4M^(-beta)||v||_2.

This review does not independently discharge those remaining numerical hypotheses or promote an ideal-supported-window deterministic acceptance to an unwindowed-spectrum theorem. Reduced executions and parameter handoff probes are not full recovery evidence. The accepted result is a schedule component and its scoped composition, conditional where explicitly stated.

## Reproduction and evidence discipline

Run python3 reviewer/review.py from any working directory after extracting the packet, with Python 3.12 or a compatible standard-library Python. The review script resolves its files relative to itself. The separate pinned deterministic acceptance archive is included as an input receipt, and the script reads its ZIP members without running its historical reviewer programs. Exact candidate components are imported with bytecode writes disabled. No producer test runner, prior scientific program or recovered historical execution was run.

Results include whole traces for the four actual fixtures, independent distribution counts, rejection details, source-guard classifications, ledger reconstructions and freshly generated in-memory mutants. The mutation checks intentionally alter only temporary modules and never overwrite frozen code. The final manifest and seal pin all delivered evidence. Verify the packet with reviewer/verify_packet.py; it checks exact bytes and does not execute the numerical components.

Two reviewer-development corrections are recorded separately: an initially incorrect expectation that m=31,beta=1/8 failed the sparse guard, and an initially incorrect assumption about the inherited sqrt_input record's operand tuple. Both were corrected against the exact source and literal arithmetic before the successful final run. They were review-harness errors, not candidate defects. No failed run is presented as a final passing receipt.

No Sheet, GitHub, sharing-permission or accepted-dependency change was made by this review.
