# Q16 fair bit schedule independent acceptance

Read INDEPENDENT_REVIEW.md for the scoped acceptance, independent full-product probability proof, validation analysis, resource reconstruction, integration provenance and exclusions. VERDICT.json summarizes the closed obligations and fresh evidence.

The accepted source is fixed to fair_tape.py SHA-256 252d154e654d58bac4a9dddaaddcec939607801efc8ad6d9babd2c9cf8d260c4. No source or accepted dependency was changed.

## Reproduce

Use a compatible standard-library Python, tested with Python 3.12. Execute from the extracted packet folder:

    python3 reviewer/verify_packet.py
    PYTHONDONTWRITEBYTECODE=1 python3 reviewer/review.py

The first command checks the sealed files and runs no scientific code. The second reruns only fresh reviewer code and the exact current components, producing the detailed results and four full pipeline traces. It takes roughly two minutes on the review host; runtime is not an algorithmic performance claim. It does not run the producer or predecessor tests.

The candidate archive and the deterministic acceptance archive are included under inputs. The candidate's exact frozen contents are under frozen. Historical receipts and producer tests in those inputs are retained for byte provenance only and are not counted as new evidence.

The full numerical theorem, theorem-parameter-sized pipeline execution, dense fallback, all-length executable, physical entropy generation, host totality, practical speed, and novelty remain outside this acceptance. The source-route handoff probe is explicitly labeled and is not a numerical pipeline run.
