"""Fresh independent audit of the bounded adapter; no author runner is imported.

The exact mathematical oracle uses math.comb, math.isqrt, and Fraction rounding.
Only the pinned current adapter and record declarations are executed. No Q16
window/bucket/pipeline or ALG034 producer algorithm is called. Mutants exist
only in ephemeral reviewer modules. Fixtures are synthetic declarations.
"""
import ast, copy, dataclasses, hashlib, importlib.util, itertools, json, math
import pathlib, random, sys, types
from collections import Counter
from fractions import Fraction

ROOT = pathlib.Path(__file__).resolve().parent
SRC = ROOT / 'inspected_source'
sys.dont_write_bytecode = True
sys.path.insert(0, str(SRC))
import paid_source as subject
from buckets import DyadicSource
SOURCE_HASH = '5cd35d6b3dc1dd6b077db3f1b957cbf4794479aa1b0e592008edf83fa5216d2b'
assert hashlib.sha256((SRC/'paid_source.py').read_bytes()).hexdigest()==SOURCE_HASH
counts=Counter(); cases=Counter(); details={}; mutation_results={}; rejection_codes=Counter()

def check(ok, category):
    counts[category]+=1
    if not ok: raise AssertionError(category)

def width(x): return max(1,abs(x).bit_length())
def ceil_log2(x): return (x-1).bit_length()
def const(n,b): return 64*min(math.comb(n+b-1,b),2**(n-b))*b*2**b*n*n

def digest(n,k,rows):
    data=bytearray(b'ALG034-OUTPUT-v1\x00')
    for x in itertools.chain((n,k),itertools.chain.from_iterable(rows)):
        v=abs(x); body=v.to_bytes((v.bit_length()+7)//8,'big')
        data.extend((int(x<0),)); data.extend(len(body).to_bytes(4,'big')); data.extend(body)
    return hashlib.sha256(data).hexdigest()

def fixture(rows,k=0,b=3,win=1,p=None,t=0,zero=False):
    n=len(rows); C=0 if zero else const(n,b)
    if zero: win=p=t=k=0
    elif p is None: p=max(win,ceil_log2(2*C)+t)
    fin=0 if zero else win-p-k
    payload=[n,k,[list(r) for r in rows]]
    cert=['ALG034-SERIAL-FIXED-POINT-v1','U_negative(P_balanced_longer_first(x))',
          'ALG034-accepted-phase-embedding-v1','frequency-index-order',
          'I attest all accepted ALG034 producer, phase, rounding, range and input premises',
          'a'*64,digest(n,k,rows),n,b,1,0,fin,win,p,t,C,int(zero)]
    return payload,cert

def oracle(rows,k,C):
    n=len(rows); P=16*(n.bit_length()-1)+16; F=P+1
    S=sum(x*x for row in rows for x in row)
    if not S:return None
    root=math.isqrt(S)
    L=max(0,root.bit_length()-1)
    while 2**(2*L)<S:L+=1
    q=tuple(tuple(round(Fraction(x*2**F,2**L)) for x in row) for row in rows)
    sq=sum(x*x for row in q for x in row)
    d=2 if Fraction(sq,2**(2*F))<=Fraction(1,4) else 1
    alpha=k+L-(d==2)
    values=tuple(tuple((d*x,F) for x in row) for row in q)
    passed=Fraction(C*d,2**L)<=Fraction(1,2**P)
    return L,d,alpha,values,passed,P,F

def immutable(x):
    if type(x) in (int,str,type(None)):return True
    if type(x) is tuple:return all(immutable(v) for v in x)
    if dataclasses.is_dataclass(x) and x.__dataclass_params__.frozen:
        return all(immutable(getattr(x,f.name)) for f in dataclasses.fields(x))
    return False

def receipt_checks(r,payload=None,cert=None,success=False):
    e=dict(r.events); E=256+sum(v for k,v in e.items() if k!='byte_processing')
    H=r.max_integer_bits+E.bit_length()+2
    check(r.bookkeeping_work_upper==1024*E*H*H,'receipt_control_formula')
    check(r.total_bit_work_upper==r.arithmetic_work_upper+1024*E*H*H+8192*r.byte_work_units,'receipt_work_formula')
    check(r.cumulative_storage_upper_bits==r.produced_integer_bits+1024*E*H+8*r.byte_work_units,'receipt_storage_formula')
    check(e.get('byte_processing',0)==r.byte_work_units,'receipt_byte_counter')
    check(e.get('allocated_slots',0)==r.allocated_slots,'receipt_slot_counter')
    check(r.max_integer_bits>=r.max_input_integer_bits>=1,'receipt_reached_width')
    check(type(r.events) is tuple and immutable(r),'receipt_immutable')
    if payload is not None and cert is not None:
        vals=[payload[0],payload[1]]+cert[7:]+[x for row in payload[2] for x in row]
        check(r.input_integer_bits==sum(width(x)+1 for x in vals),'receipt_full_input_bits')
        check(r.max_input_integer_bits==max(width(x) for x in vals),'receipt_full_input_max')
        n=payload[0]
        check(e['source_validation_field']==2*n,'receipt_complete_dense_scan')
        check(e.get('binomial_step',0)==(0 if cert[-1] else cert[8]),'receipt_C_reconstruction')
        if success:
            check(r.allocated_slots==21*n+60,'receipt_21Nplus60')
            for key,expected in [('source_second_pass_read',2*n),('cartesian_round',2*n),
                                 ('dyadic_field_write',4*n),('complex_cell_write',n),('immutable_source_copy',n)]:
                check(e.get(key)==expected,'receipt_'+key)
        else:
            check(r.allocated_slots==6*n+58,'receipt_zero_allocations')
            check(e.get('cartesian_round',0)==0 and e.get('immutable_source_copy',0)==0,'receipt_zero_no_source')

def verify(payload,cert,category,mod=subject,ledger=True):
    cases[category]+=1
    actual=mod.adapt(payload,cert); n,k,rows=payload
    exp=oracle(rows,k,cert[15]); check(immutable(actual),'deep_immutability')
    check(actual.producer_contract.fields==tuple(cert),'copied_contract')
    check(actual.conditional_soundness=='CONDITIONAL_ON_TRUSTED_UPSTREAM_CONTRACT','conditional_premise')
    check(actual.output_sha256==digest(n,k,rows),'canonical_output_digest')
    check(actual.delta==(cert[15],k),'delta_symbolic')
    P=16*(n.bit_length()-1)+16;check(actual.rho==(1,-P),'rho_symbolic')
    check(actual.second_transform_target=='R(P_balanced_longer_first(x))/alpha; R[j]=(-j mod M)','reflected_target')
    if exp is None:
        check(actual.status==('EXACT_ZERO_INPUT' if cert[-1] else 'ZERO_APPROXIMATION'),'zero_distinction')
        check(actual.source is None and actual.alpha_exponent is None and actual.normalization_L is None,'zero_no_source')
        check(actual.target_budget=='NO_NORMALIZED_SOURCE' and actual.requantization_error==(0,0),'zero_budget')
    else:
        L,d,a,vals,passed,P,F=exp
        check(actual.status=='VALID_SOURCE','valid_source')
        check(type(actual.source) is DyadicSource,'accepted_exact_class_identity')
        check(actual.source.values==vals and actual.source.fractional_bits_bound==F,'independent_source_oracle')
        check((actual.normalization_L,actual.doubling,actual.alpha_exponent)==(L,d,a),'scale_and_doubling_oracle')
        check(actual.target_budget==('TARGET_BUDGET_PASS' if passed else 'TARGET_BUDGET_NOT_ESTABLISHED'),'allowance_exact_oracle')
        check(actual.requantization_error==(1,1-F),'requantization_symbolic')
        norm=0
        for rr,vv in zip(rows,actual.source.values):
            err=[]
            check(type(vv) is tuple and len(vv)==2,'nested_complex_tuple')
            for x,(num,exponent) in zip(rr,vv):
                check(type(num) is int and type(exponent) is int and exponent==F,'exact_dyadic_fields')
                check(abs(num)<=2**F and width(num)<=F+1,'cartesian_bound_width')
                norm+=num*num
                err.append(Fraction(num,2**F)-Fraction(d*x,2**L))
            check(sum(z*z for z in err)<=Fraction(1,2**(2*P)),'complex_error_squared_bound')
        check(4*norm>2**(2*F),'strict_norm_half')
        check(2**(2*L)>=sum(x*x for row in rows for x in row),'normalizer_upper')
        if L: check(2**(2*(L-1))<sum(x*x for row in rows for x in row),'normalizer_minimal')
    if ledger:receipt_checks(actual.receipt,payload,cert,exp is not None)
    return actual

# All small signed Cartesian configurations, freshly generated.
for vector in itertools.product((-1,0,1),repeat=8):
    verify(*fixture(list(zip(vector[::2],vector[1::2]))),'exhaustive_ternary_M4')

# Wider independent rational-oracle vectors and all supported length exponents.
rng=random.Random(0x03401620261013)
for m in range(2,13):
    n=2**m
    rows=[(rng.randrange(-100,101),rng.randrange(-100,101)) for _ in range(n)]
    verify(*fixture(rows,b=min(n,3+m)),'all_supported_lengths')
for i in range(140):
    n=2**rng.randrange(2,8); bits=rng.choice([1,7,50,77,129,1025])
    rows=[(rng.getrandbits(bits)*rng.choice((-1,1)),rng.getrandbits(bits)*rng.choice((-1,1))) for _ in range(n)]
    verify(*fixture(rows,k=rng.randrange(-800,801),b=rng.randrange(3,n+1)),'wide_exact_vectors')

# Independent signed nearest-even controls, including exact half ties.
for shift in range(-13,9):
    for x in range(-199,200):
        want=round(Fraction(x*2**max(shift,0),2**max(-shift,0)))
        got=subject._round_scaled(x,shift,subject._Ledger())
        check(got==want,'signed_nearest_even')

# Public normalization/doubling boundary cases, every sign and Cartesian axis.
for m in (2,3,6,12):
    n=2**m; F=16*m+17
    for K in (0,1,F-1,F,F+1,F+2,F+50,65535):
        for sign in (-1,1):
            for axis in (0,1):
                for offset in (-1,0,1):
                    val=sign*(2**K+offset)
                    if abs(val).bit_length()>65536:continue
                    rows=[(0,0)]*n; r=[0,0];r[axis]=val;rows[-1]=tuple(r)
                    a=verify(*fixture(rows),'power_and_strict_boundaries')
                    if K>F+1 and offset==1:
                        check(a.doubling==2,'strict_equality_doubling_required')

# Canonical zero and source-isolation controls.
verify(*fixture([(0,0)]*8,zero=True),'asserted_exact_zero')
p,c=fixture([(3,4),(0,0),(0,0),(0,0)])
a=verify(p,c,'mutable_input_isolation'); prior=dataclasses.asdict(a)
p[2][-1][1]=888;p[2][0][0]=0;c[5]='f'*64;c[8]=4
check(dataclasses.asdict(a)==prior,'later_mutation_isolation')
for obj,field,value in [(a,'doubling',9),(a.source,'fractional_bits_bound',0),(a.receipt,'input_integer_bits',0),(a.producer_contract,'fields',())]:
    try:setattr(obj,field,value)
    except dataclasses.FrozenInstanceError:check(True,'frozen_records')
    else:check(False,'frozen_records')

# Symbolic scales: supported 256-bit encodings, no exponential allocation.
for k in (2**200,-2**200,2**255,-2**255):
    a=verify(*fixture([(7,-9)]+[(0,0)]*3,k=k),'huge_symbolic_exponent')
    check(a.receipt.max_integer_bits<1000,'symbolic_no_absolute_expansion')
for p in (2**200,2**255):
    verify(*fixture([(1,2)]+[(0,0)]*3,p=p,t=p-30),'huge_precision_encodings')

# Exact allowance equality in both branches, and indispensable doubling factor.
for m in range(2,8):
    n=2**m; C=const(n,n); P=16*m+16
    check(C & (C-1)==0,'power_two_C_fixture')
    K=P+C.bit_length()-1
    for gap in (-1,0,1):
        rows=[(2**(K+gap),0)]+[(0,0)]*(n-1)
        a=verify(*fixture(rows,b=n),'allowance_neighborhood')
        check((a.target_budget=='TARGET_BUDGET_PASS')==(gap>=0),'allowance_threshold')
    for L in (K,K+1,K+2):
        rows=[(2**(L-1)+1,0)]+[(0,0)]*(n-1)
        a=verify(*fixture(rows,b=n),'doubling_allowance_neighborhood')
        check(a.doubling==2,'allowance_doubling_branch')
        check((a.target_budget=='TARGET_BUDGET_PASS')==(L>=K+1),'factor_d_in_allowance')

# Simultaneous maximum N and reached numerator width, on final second field.
rows=[(0,0)]*4096;rows[-1]=(0,-(2**65535))
verify(*fixture(rows),'joint_N_and_width_maximum')

# Additional deployment cap edges and tuple grammar.
for k in (2**256-1,-(2**256-1)):
    pr=ceil_log2(2*const(4,3))
    a=verify(*fixture([(3,4)]+[(0,0)]*3,k=k,win=pr,p=pr),'full_256_bit_scale_edge')
    check(a.receipt.max_integer_bits>=256,'full_metadata_width_charged')
    if k>0:check(a.alpha_exponent.bit_length()==257,'output_exponent_may_grow')
for fin in (2**256-1,-(2**256-1)):
    p,c=fixture([(0,0)]*4,zero=True);c[11]=fin
    verify(p,c,'signed_Fin_metadata_edge')
pmax=2**256-1
verify(*fixture([(3,-4)]+[(0,0)]*3,p=pmax,t=pmax-17),'full_precision_metadata_edge')
verify(*fixture([(1,0)]+[(0,0)]*4095,b=4096),'maximum_B_reconstruction')
for n in (4,8,16,32):
    for b in range(3,n+1):
        verify(*fixture([(7,-2)]+[(0,0)]*(n-1),b=b),'all_small_block_counts')
p,c=fixture([(3,-4),(1,2),(0,0),(-9,8)])
p=(p[0],p[1],tuple(tuple(row) for row in p[2]));c=tuple(c)
# Ledger helper admits both tuple and list forms; oracle has no mutable-container dependency.
a=verify(p,c,'all_tuple_input',ledger=False)
receipt_checks(a.receipt,list(p),list(c),True)
for q in range(-7,8):
    F=49; K=F+10; small=(2*q+1)*2**(K-F-1)
    for axis in (0,1):
        r=[0,0];r[axis]=small
        a=verify(*fixture([(3*2**(K-2),0),tuple(r),(0,0),(0,0)]),'public_signed_half_ties')
        check(a.normalization_L==K,'public_tie_scale')
        check(a.source.values[1][axis][0]==round(Fraction(2*q+1,2)),'public_tie_to_even')
# Reusing a scalar identity on rescaled numerators preserves the physical signal.
p,c=fixture([(3,-4),(1,0),(0,0),(0,0)],k=-9)
a=verify(p,c,'rescaling_baseline')
for shift in (1,17,150):
    rows=[(x*2**shift,y*2**shift) for x,y in p[2]]
    b=verify(*fixture(rows,k=p[1]-shift),'rescaling_equivalent_signal')
    check(b.source.values==a.source.values and b.alpha_exponent==a.alpha_exponent,'power_rescaling_invariant')

# Public rejection matrix, including exact-type adversarial classes.
class IntSubclass(int):
    def __abs__(self):raise AssertionError('callback forbidden')
class ListSubclass(list):
    def __len__(self):raise AssertionError('callback forbidden')
class StrSubclass(str):
    def __len__(self):raise AssertionError('callback forbidden')
class Poison:
    def __len__(self):raise AssertionError('callback forbidden')
    def __iter__(self):raise AssertionError('callback forbidden')
    def __index__(self):raise AssertionError('callback forbidden')

base=fixture([(1,0)]*4)
def reject(p,c,code,tag):
    cases['public_rejections']+=1
    try:subject.adapt(p,c)
    except subject.Rejection as e:
        check(e.code==code,'rejection_'+tag);rejection_codes[e.code]+=1
        receipt_checks(e.receipt)
        return e
    else:raise AssertionError('accepted malformed '+tag)

def altered(where,index,val):
    p,c=copy.deepcopy(base)
    if where=='p':p[index]=val
    elif where=='c':c[index]=val
    elif where=='row':p[2][index]=val
    elif where=='last':p[2][-1][index]=val
    return p,c

for bad in (None,{},Poison(),ListSubclass(base[0]),'payload'):
    reject(bad,base[1],'SEQUENCE_TYPE','payload_type')
for bad in ([],[1],[1,2,3,4]):reject(bad,base[1],'SEQUENCE_LENGTH','payload_length')
for where,index in [('p',0),('p',1)]+[('c',i) for i in range(7,17)]+[('last',0),('last',1)]:
    for bad in (True,1.5,None,IntSubclass(1),Poison()):
        reject(*altered(where,index,bad),'INTEGER_TYPE','exact_integer')
for bad in (0,1,2,3,5,-4,8192):reject(*altered('p',0,bad),'LENGTH_DOMAIN','N_domain')
for i in range(7):
    reject(*altered('c',i,StrSubclass(base[1][i])),'TEXT_TYPE','text_subclass')
    reject(*altered('c',i,None),'TEXT_TYPE','text_none')
    reject(*altered('c',i,'x'*257),'TEXT_LENGTH_LIMIT','text_length')
for i in range(5):reject(*altered('c',i,base[1][i]+'!'),'CONTRACT_TAG','fixed_tags')
for i in (5,6):
    for bad in ('a'*63,'a'*65,'A'*64,'g'*64,'0'*63+'é'):
        reject(*altered('c',i,bad),'DIGEST_ENCODING','digest_grammar')
for bad in (None,ListSubclass(base[1]),{}):reject(base[0],bad,'SEQUENCE_TYPE','certificate_type')
reject(base[0],base[1][:-1],'SEQUENCE_LENGTH','certificate_length')
for bad in (None,ListSubclass(base[0][2]),{}):reject(*altered('p',2,bad),'SEQUENCE_TYPE','rows_type')
reject(*altered('p',2,[(1,0)]*3),'SEQUENCE_LENGTH','rows_length')
for bad in (None,ListSubclass([1,0]),{}):reject(*altered('row',3,bad),'SEQUENCE_TYPE','last_cell_type')
for bad in ([],[1],[1,0,0]):reject(*altered('row',3,bad),'SEQUENCE_LENGTH','last_cell_shape')
reject(*altered('c',7,8),'CERTIFICATE_LENGTH_MISMATCH','cert_N')
for b in (0,2,5):reject(*altered('c',8,b),'BLOCK_DOMAIN','B')
for a0 in (-1,0,2,4,5):reject(*altered('c',9,a0),'STATE_DOMAIN','a')
for beta in (-1,4):reject(*altered('c',10,beta),'STATE_DOMAIN','beta')
for i in (12,13,14):reject(*altered('c',i,-1),'PRECISION_DOMAIN','negative_precision')
for z in (-1,2):reject(*altered('c',16,z),'PRECISION_DOMAIN','zero_flag')
reject(*altered('c',12,0),'PRECISION_DOMAIN','Win_zero')
p,c=copy.deepcopy(base);c[12]=c[13]+1
reject(p,c,'PRECISION_DOMAIN','p_lt_Win')
reject(*altered('c',11,base[1][11]+1),'EXPONENT_BINDING','scale_binding')
for C in (-1,0,base[1][15]+1,2**16383):reject(*altered('c',15,C),'ERROR_CONSTANT','C_mismatch')
p,c=copy.deepcopy(base);c[13]-=1;c[11]+=1
reject(p,c,'PRECISION_CERTIFICATE','precision_below_exact_threshold')
reject(*altered('c',6,'0'*64),'OUTPUT_BINDING','output_digest')
p,c=fixture([(0,0)]*4,zero=True)
for index in (12,13,14,15):
    cc=c[:];cc[index]=1;reject(p,cc,'ZERO_CONTRACT','zero_canonical')
p,c=fixture([(1,0)]*4,zero=True)
reject(p,c,'ZERO_OUTPUT_CONTRADICTION','false_zero_output')
for where,index,cap in [('p',0,256),('p',1,256)]+[('c',i,16384 if i==15 else 256) for i in range(7,17)]+[('last',0,65536),('last',1,65536)]:
    for s in (-1,1):
        bad=s*2**cap; e=reject(*altered(where,index,bad),'INTEGER_WIDTH_LIMIT','width_cap')
        check(e.receipt.max_input_integer_bits==cap+1,'rejected_width_retained')
        check(e.receipt.max_integer_bits>=cap+1,'rejected_work_width_retained')
        check(e.receipt.input_integer_bits>=cap+2,'rejected_input_width_paid')

# Every advertised semantic rejection is independently reached.
wanted={'BLOCK_DOMAIN','CERTIFICATE_LENGTH_MISMATCH','CONTRACT_TAG','DIGEST_ENCODING','ERROR_CONSTANT',
'EXPONENT_BINDING','INTEGER_TYPE','INTEGER_WIDTH_LIMIT','LENGTH_DOMAIN','OUTPUT_BINDING','PRECISION_CERTIFICATE',
'PRECISION_DOMAIN','SEQUENCE_LENGTH','SEQUENCE_TYPE','STATE_DOMAIN','TEXT_LENGTH_LIMIT','TEXT_TYPE',
'ZERO_CONTRACT','ZERO_OUTPUT_CONTRADICTION'}
check(set(rejection_codes)==wanted,'complete_public_rejection_inventory')

# Independently recompute every record's arithmetic semantics and receipt fields.
traces=[];old_record=subject._Ledger.record

def audited_record(self,kind,args,value):
    if kind=='add':check(value==sum(args),'trace_add')
    elif kind=='subtract':check(value==args[0]-args[1],'trace_subtract')
    elif kind=='multiply':check(value==math.prod(args),'trace_multiply')
    elif kind=='divide':check(value==args[0]//args[1],'trace_divide')
    elif kind=='binary_power':check(value==2**args[0],'trace_binary_power')
    elif kind=='bit_length':check(value==args[0].bit_length(),'trace_bit_length')
    traces.append((kind,tuple(args),value))
    return old_record(self,kind,args,value)
subject._Ledger.record=audited_record
try:
    for label,args in [('ordinary',fixture([(3,-4),(1,2),(0,0),(-3,1)])),
                       ('doubling',fixture([(2**100+1,0)]+[(0,0)]*3)),
                       ('zero',fixture([(0,0)]*4))]:
        traces.clear();a=verify(*args,'independent_ledger_trace')
        A=I=0;Q=1
        for kind,inputs,value in traces:
            widths=[width(x) for x in (*inputs,value)]
            A+=32*(2+sum(widths))**2;I+=widths[-1]+1;Q=max(Q,*widths)
        check(a.receipt.arithmetic_work_upper==A,'trace_exact_work')
        check(a.receipt.produced_integer_bits==I,'trace_exact_produced')
        check(a.receipt.max_integer_bits==Q,'trace_exact_max_width')
        details['ledger_'+label]={'record_count':len(traces),'work':A,'produced_bits':I,'max_width':Q,'slots':a.receipt.allocated_slots}
finally:subject._Ledger.record=old_record

# Deliberate mutations of the newly inspected current adapter, held in memory.
source=(SRC/'paid_source.py').read_text()
def mutant(name,before,after):
    check(source.count(before)==1,'mutation_unique_site')
    module=types.ModuleType('review_mutant_'+name);sys.modules[module.__name__]=module
    exec(compile(source.replace(before,after),str(SRC/'paid_source.py')+'::'+name,'exec'),module.__dict__)
    return module

def detect(name,before,after,args=None,expected=None,assertion=None):
    mod=mutant(name,before,after)
    try:
        if assertion:assertion(mod)
        else:verify(*args,'mutant_'+name,mod=mod)
    except (AssertionError,subject.Rejection,mod.Rejection) as e:
        mutation_results[name]={'detected':True,'by':str(e)}
    else:raise AssertionError('undetected mutation '+name)

boundary=fixture([(2**100+1,0)]+[(0,0)]*3)
detect('omit_doubling','doubling = 2 if L.mul(4,Sq) <= L.mul(unit,unit) else 1','doubling = 1',boundary)
detect('strict_equality_omitted','doubling = 2 if L.mul(4,Sq) <= L.mul(unit,unit) else 1','doubling = 2 if L.mul(4,Sq) < L.mul(unit,unit) else 1',boundary)
detect('wrong_alpha','alpha = L.sub(L.add(kappa,scale), 1 if doubling == 2 else 0)','alpha = L.add(kappa,scale)',boundary)
C=const(4,4);K=48+C.bit_length()-1
missing_d=fixture([(2**(K-1)+1,0)]+[(0,0)]*3,b=4)
detect('omit_allowance_d','passes = _dyadic_le_power(C,L.sub(kappa,alpha),-P,L)','passes = _dyadic_le_power(C,-scale,-P,L)',missing_d)
detect('wrong_signed_round','return L.mul(sign, quotient)','return L.mul(1, quotient)',fixture([(-2**80-3,0)]+[(0,0)]*3))
detect('mutable_outer_source','values = tuple(output);','values = output;',fixture([(1,0)]*4))
detect('zero_conflation',"'EXACT_ZERO_INPUT' if original_zero else 'ZERO_APPROXIMATION'","'EXACT_ZERO_INPUT'",fixture([(0,0)]*4))
detect('omit_final_scan','for index in range(N):','for index in range(N-1):',fixture([(1,0)]*4))
detect('omit_copy_charge','L.allocate(N+2); L.event(\'immutable_source_copy\',N)','L.allocate(2); L.event(\'immutable_source_copy\',N)',fixture([(1,0)]*4))
def check_reject_width(mod):
    p,c=altered('last',1,2**65536)
    try:mod.adapt(p,c)
    except mod.Rejection as e:
        check(e.receipt.max_input_integer_bits==65537,'mutation_rejected_width_retained')
    else:raise AssertionError('oversize not rejected')
detect('cap_reject_before_width_account',"bits = max(1, abs(value).bit_length())\n        self.input_bits += bits + 1;", "bits = max(1, abs(value).bit_length())\n        if bits > cap: self.reject('INTEGER_WIDTH_LIMIT', path)\n        self.input_bits += bits + 1;",assertion=check_reject_width)

# No downstream call was made or injected by the audit.
check(not hasattr(subject,'BucketEngine'),'no_downstream_engine_in_adapter')
result={'status':'PASS','assertions':sum(counts.values()),'categories':dict(sorted(counts.items())),
        'cases':dict(sorted(cases.items())),'rejection_codes':dict(sorted(rejection_codes.items())),
        'mutation_controls':mutation_results,'ledger_traces':details,'source_sha256':SOURCE_HASH,
        'execution_scope':'Fresh reviewer and pinned current adapter only; declarations/record constructor from Q16 dependencies; no author runner, upstream producer or downstream scientific algorithm executed.',
        'fixture_scope':'Synthetic upstream declarations, not authenticated ALG034 executions.'}
(ROOT/'results'/'INDEPENDENT_RESULTS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','assertions':sum(counts.values()),'public_rejections':cases['public_rejections'],'mutations':len(mutation_results),'cases':dict(cases)},sort_keys=True))
