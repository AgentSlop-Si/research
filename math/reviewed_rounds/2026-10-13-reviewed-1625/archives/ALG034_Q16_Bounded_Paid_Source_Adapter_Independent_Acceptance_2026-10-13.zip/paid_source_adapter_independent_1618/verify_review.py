"""Hash-only verification of the sealed review. Executes no research algorithm."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
manifest=root/'MANIFEST.json'
seal=json.loads((root/'SEAL.json').read_text())
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==seal['manifest_sha256']
items=json.loads(manifest.read_text())['files']
for entry in items:
    p=root/entry['path'];b=p.read_bytes()
    assert len(b)==entry['bytes'],entry['path']
    assert hashlib.sha256(b).hexdigest()==entry['sha256'],entry['path']
print('PASS:',len(items),'review members verified; no scientific algorithm executed.')
