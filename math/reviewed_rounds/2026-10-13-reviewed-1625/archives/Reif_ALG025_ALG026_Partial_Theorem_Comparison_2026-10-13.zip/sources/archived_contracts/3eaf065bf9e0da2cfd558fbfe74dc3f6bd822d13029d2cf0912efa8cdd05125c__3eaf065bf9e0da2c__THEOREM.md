# Guarded packed sums close the sparse Fourier decoder's packing gap

## What is proved

Fix an accuracy parameter `epsilon` in (0,1) and a constant `C`. Given an arbitrary fresh list of `K <= C log N` samples `(j, s)`, where `0 <= j < N` and `s` is one of `1,i,-1,-i`, a uniform bounded-word algorithm constructs **all N** approximations to

\[
v_m=\frac1K\sum_{a=1}^K s_a\exp(-2\pi i j_a m/N),\qquad 0\le m<N,
\]

with maximum complex absolute error at most `epsilon/4`, in **O(N) word operations including its entire lookup-table construction**. The constant depends on epsilon and C. The list length is chosen upstream to be a multiple of the group size; increasing an importance-sampling budget by fewer than one group achieves this without padding with biased samples.

The result concerns approximate transforms with an additive error scale. It gives no exact Fourier arithmetic improvement and no relative error guarantee for small Fourier coefficients. Its useful integration is an importance sampler supplying `K=O(epsilon^-2 log(N/delta))`; the O(N) statement assumes fixed epsilon and `delta >= N^-c` for a fixed c. Arbitrary vanishing epsilon or superpolynomially small delta require a new cost calculation.

## The explicit machine model

The machine has words of `w=Theta(log N)` bits, with the constant allowed to depend on the fixed requested accuracy and C. One-word addition, subtraction, multiplication **whose full result fits in a word**, integer division/remainder, shifts, Boolean operations, comparisons, indexed memory reads/writes, and generating a random word (used only upstream) cost O(1). A fixed number of words per output also costs O(1). Addresses fit in one word.

No unbounded packed-integer operation, complex-number operation, sine, cosine, square root, arbitrary real input, or arbitrary real output is a unit-cost primitive. This decoder produces two signed integer numerators per output and a shared integer denominator; each numerator is explicitly written. The normalized sample mean is that rational complex pair. Scaling it to a unitary DFT is charged separately by the integrating algorithm. Every lookup table here is built from scratch and is independent of sample indices and signs.

The prototype uses a conservative `w=max(4 bit_length(N)+4P+64, gp+1,r+1)`, where P is its fixed working precision. This is Theta(log N) for fixed accuracy. Mixed-sign operations are checked against the signed word range; packed nonnegative additions use the unsigned word range. Selected arithmetic/memory counters are reported, and the proof also charges loop/index/control overhead. Python object overhead is not interpreted as a RAM speedup.

## 1. Block descriptors

Take `B=floor(log2 N)` outside a finite small-N base case. Choose powers of two

\[
Q_0\ge64/\epsilon,\qquad Q_1\ge64B/\epsilon.
\]

Use the least such powers, so `Q1` is divisible by `Q0`. In the block starting at `m0`, an atom receives a descriptor `(a0,a1)`:

\[
a_0=\operatorname{round}\bigl(Q_0(\arg(s)/(2\pi)-jm_0/N)\bigr)\pmod{Q_0},
\qquad
a_1=\operatorname{round}(-Q_1j/N)\pmod{Q_1}.
\]

The quarter-turn sign is represented exactly because Q0 is divisible by four. Replacing the atom at lane t by

\[
\exp\left(2\pi i(a_0/Q_0+t a_1/Q_1)\right)
\]

has complex error at most

\[
\eta=\pi/Q_0+\pi(B-1)/Q_1.
\]

This follows from nearest rounding and `|exp(iu)-exp(iv)| <= |u-v|`, choosing the nearest representatives on the circle. Both descriptor coordinates take

\[
p=\log_2 Q_0+\log_2 Q_1=O(\log\log N+\log(1/\epsilon))
\]

bits in total. Slopes are formed once per sample. Every block-start descriptor uses O(1) word operations: compute `jm0 mod N`, scale by Q0, divide by N, and fold the phase. All products fit in the stated constant-factor word width. No recurrence of approximate floating phases is used.

## 2. A complete first table

Fix any constant `gamma` in (0,1), for example 1/2, and let

\[
g=\left\lfloor\frac{\gamma\lfloor\log_2N\rfloor}{p}\right\rfloor,\qquad G=K/g.
\]

For large enough N, `g>=1`. Round the requested upstream sample budget up to `K=Gg`; this preserves `K=O(log N)`. Concatenate exactly g descriptors to produce one `gp`-bit key. The descriptor alphabet size is `D=Q0 Q1=2^p`, and there are exactly

\[
D^g=2^{gp}\le N^\gamma
\]

possible keys. **Enumerate every key.** For each key and every lane, compute the mean of its g quantized phasors, then round each Cartesian coordinate to the grid `h=1/H`, where H is a power of two and `H>=32/epsilon`. Clip the resulting integer coordinate to `[-H,H]`. Trigonometric grid values are computed with complex error `sigma<=epsilon/32` by the uniform integer construction below. Coordinate rounding contributes at most `h/sqrt(2)` to complex error. Clipping to the square cannot increase distance from the true group mean, which lies in that square.

Thus each stored group-average lane has error at most

\[
\eta+\sigma+h/\sqrt2
\le\epsilon\left(\pi/32+1/32+1/(32\sqrt2)\right)
<\epsilon/4.
\]

This error bound remains unchanged when averaging the G equal-size groups. A second averaging table and a packed matrix transpose are unnecessary.

## 3. Guarded lane summation replaces transposition

Offset every signed coordinate integer `q in [-H,H]` by H, giving a code in `[0,2H]`. Define

\[
r=\left\lceil\log_2(2HG+1)\right\rceil,\qquad L=\lfloor w/r\rfloor.
\]

Pack L lane codes per word, each at a multiple of r bits. Real and imaginary coordinates use separate arrays. A row occupies

\[
s=\left\lceil B/L\right\rceil=O(1+Br/w)
\]

words per coordinate. Since each accumulated lane is at most `2HG<2^r`, ordinary addition of G packed words has **no carry across lane fields**. The top field also fits in the word because `Lr<=w`. Add all G table rows with `2Gs` ordinary word additions and reads.

Now extract each output lane exactly once. If its accumulated code is A, its output coordinate is

\[
\frac{A-GH}{GH}.
\]

Writing both integer numerators for every m costs O(N), and their common denominator `GH` occupies one word. All N complex output values are explicitly represented; a compressed generator is not substituted for them. If a final fixed-point grid is required instead, one rounded integer division per coordinate costs O(N), with its additional error charged separately.

For fixed epsilon and C, `G=O(log log N)` and `r=O(log G+1)=O(log log log N+1)`. The packed accumulation work over all blocks is therefore

\[
O\!\left(\frac{N}{\log N}\,\log\log N\,(1+\log\log\log N)\right)=o(N).
\]

This is the missing packing argument: there is no O(G) scalar extraction per output and no hidden N log log N transpose.

## 4. Fully charged uniform phasor construction

Only `Q1=O(B/epsilon)` different phasors occur. Generate all of them at fixed precision; there is no trigonometric oracle.

For target complex error `2^-b`, choose a Taylor degree d satisfying

\[
4^{d+1}/(d+1)!\le2^{-(b+4)},
\]

and working precision

\[
P=b+\operatorname{bitlength}(256(d+1))+4,\qquad S=2^P.
\]

Compute pi to error less than `1/S` using Machin's identity

\[
\pi=16\arctan(1/5)-4\arctan(1/239)
\]

and the alternating rational series for arctangent. Evaluate each term with integer division at precision `R=S 2^u`, where `u=bit_length(128(P+1)^2)`, until its integer quotient is zero. Each term's rounding error is less than `1/R`; the uncomputed alternating tail is also less than `1/R`. There are at most `P+u` terms for either arctangent. The accumulated pi error before rounding to S is at most `20(P+u+1)/R`. For `P>=8`, `P+u+1 <=4(P+1)`, so this error plus the final half-unit rounding is less than `1/S`.

For exponent a, reduce `2*pi*a/Q1` to an angle in `[-pi,pi]`, and round it to an integer theta/S. The angle error is less than `2/S`; its magnitude is less than four. Evaluate the complex Taylor polynomial by the recurrence

\[
t_0=1,\qquad t_n=\operatorname{round}_{1/S}(i\theta t_{n-1}/n),\qquad P_d=\sum_{n=0}^d t_n.
\]

Each complex recurrence rounding error is at most `1/S`. Propagating one injected error through later terms gives a total factor bounded by `exp(4)<64`; summing the d injections gives at most `64d/S`. The Taylor remainder along the imaginary axis is at most `4^(d+1)/(d+1)!`, because the derivatives of `exp(it)` have unit absolute value along the real t interval. The combined error is at most

\[
2/S+64d/S+2^{-(b+4)}<2^{-b}.
\]

Choose `b>=log2(32/epsilon)`. For fixed epsilon, d and P are constants. Every intermediate fits in O(log N) bits under the explicit word choice; the prototype verifies these bounds on each executed arithmetic operation. Pi setup costs a constant depending on epsilon, and the complete phasor grid costs `O_epsilon(Q1)=polylog(N)` word operations. Nothing is stored as an exact transcendental constant.

## 5. Complete cost, including cold preprocessing

| Work | Word operations, fixed epsilon and C |
|---|---:|
| Complete phasor grid | O(log N) |
| Enumerate and build every first-table row | O(N^gamma g B) = N^gamma polylog(N) = o(N) |
| Descriptor and concatenated key construction | O(K ceil(N/B)) = O(N) |
| Packed table reads and group summation | O((N/B)G(1+Br/w)) = o(N) |
| Extract, scale rational coordinates, write every output | O(N) |
| Control, address, loop and index work | Same orders as their corresponding rows |

The table occupies `O(N^gamma (1+Br/w))=o(N)` words. The sample list and working block require polylogarithmic space, and explicit output storage costs O(N) words. Entire cold running time and memory are O(N).

There is a finite small-N region, depending on epsilon and gamma, in which g would be zero or the asymptotic word-width inequalities do not yet hold. A directly evaluated, certified fixed-point DFT/sum handles it. Its O(NK) or O(N^2) cost is bounded by `C_epsilon,C N` on this finite region. This establishes the asymptotic theorem; it does **not** imply a useful practical crossover. For example the declared theoretical schedule may first allow g>=1 only at enormous N. The experimental prototype deliberately uses manageable complete tables rather than claiming to have reached that asymptotic regime.

## Implementation and audit scope

`guarded_decoder.py` implements both complete eager tables and a separately labeled lazy demonstrator. The eager mode is the implementation relevant to preprocessing cost. `asymptotic_parameters` exposes the schedule and returns `None` in its finite base regime; the prototype caller selects finite test parameters explicitly. The package is a research proof plus tested decoder, not an optimized general FFT library.

`run_audit.py` checks complete table enumeration, individual phasor precision, all output coordinates against direct sample sums, and exact equality of packed addition with independent scalar lane summation. Cases include groups of size two, many groups, phase wrap, non-power-of-two N, a final partial block, cancellation, coherent samples, and multiple words per packed row. These tests support implementation correctness; the uniform asymptotic proof above, rather than finite timing, establishes the stated complexity.

This closes the specific checkpoint's decoder gap. It does not by itself establish novelty: guarded fields and table acceleration are general word-RAM techniques, and the integrated approximate Fourier theorem requires a separate prior-art review and sampling proof.
