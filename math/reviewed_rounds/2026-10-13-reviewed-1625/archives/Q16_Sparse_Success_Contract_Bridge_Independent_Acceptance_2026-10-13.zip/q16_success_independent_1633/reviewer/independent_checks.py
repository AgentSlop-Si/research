"""Fresh reviewer controls. Never imports/executes any scientific candidate.

These are finite corroboration and integrity checks, not the universal proof.
The full argument is in INDEPENDENT_REVIEW.md.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from itertools import product
from math import comb
import hashlib, json, zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
CANDIDATE = ROOT / 'evidence/Q16_Sparse_Success_Contract_Bridge_Audit_2026-10-13.zip'
PREFIX = 'q16_success_bridge_audit_20261013/'
EXPECTED = '55c074877d47b7c0f8d0d6f5f1394005b650ff29a428b9180e6de34d488d5f6f'
counts = Counter()
def check(name, condition):
    if not condition:
        raise AssertionError(name)
    counts[name] += 1
def digest(data): return hashlib.sha256(data).hexdigest()
def dist(x, M):
    x %= M
    return min(x, M-x)
def ceil(x): return -((-x.numerator)//x.denominator)

check('archive_sha256', digest(CANDIDATE.read_bytes()) == EXPECTED)
check('archive_size', CANDIDATE.stat().st_size == 117351)
with zipfile.ZipFile(CANDIDATE) as z:
    manifest_bytes = z.read(PREFIX+'MANIFEST.json')
    manifest = json.loads(manifest_bytes)['files']
    seal = json.loads(z.read(PREFIX+'SEAL.json'))
    check('manifest_hash', digest(manifest_bytes) == seal['manifest_sha256'])
    check('manifest_count', len(manifest) == seal['payload_files'])
    check('archive_inventory', set(z.namelist()) == {PREFIX+p for p in manifest} | {PREFIX+'MANIFEST.json', PREFIX+'SEAL.json'})
    for p, meta in manifest.items():
        b = z.read(PREFIX+p)
        check('manifest_member', digest(b) == meta['sha256'] and len(b) == meta['bytes'])
        check('inspected_local_byte_match', (BASE/PREFIX/p).read_bytes() == b)
    provenance = json.loads(z.read(PREFIX+'PROVENANCE.json'))
    with zipfile.ZipFile(BASE/'Q16_Paid_Fair_Bit_Tape_Independent_Acceptance_2026-10-13.zip') as fair:
        check('fair_archive_hash', digest(Path(fair.filename).read_bytes()) == provenance['fair_acceptance_archive_sha256'])
        for p, meta in provenance['files'].items():
            b = z.read(PREFIX+p)
            check('provenance_hash', digest(b) == meta['sha256'])
            if 'original_archive_member' in meta:
                check('production_source_byte_pin', fair.read(meta['original_archive_member']) == b)
            if 'acceptance_archive' in meta:
                ap = BASE/meta['acceptance_archive']
                check('acceptance_archive_hash', digest(ap.read_bytes()) == meta['acceptance_archive_sha256'])
                with zipfile.ZipFile(ap) as a:
                    check('acceptance_report_byte_pin', any(a.read(p2) == b for p2 in meta['matching_archive_member']))

# Independent exact polynomial expansion: characteristic function of r
# differences is the centered 2r-fold uniform convolution. No trig or code import.
def conv(a, b):
    c = Counter()
    for x, nx in a.items():
        for y, ny in b.items(): c[x+y] += nx*ny
    return c
for ell in range(2, 10):
    uniform = Counter({i: 1 for i in range(ell)})
    neg = Counter({-i: 1 for i in range(ell)})
    differences = conv(uniform, neg)
    for r in range(1, 5):
        direct = Counter({0: 1}); centered = Counter({0: 1})
        for _ in range(r): direct = conv(direct, differences)
        for _ in range(2*r): centered = conv(centered, uniform)
        centered = Counter({x-r*(ell-1): n for x,n in centered.items()})
        check('difference_convolution_identity', direct == centered)
        check('probability_mass_symmetry_support', sum(direct.values()) == ell**(2*r) and len(direct) == 2*r*(ell-1)+1 and all(n == direct[-t] for t,n in direct.items()))

# Exhaust all noninvertible differences, odd slopes, and integer radii.
for m in range(2, 8):
    M = 1 << m
    slopes = range(1, M, 2)
    for d in range(1, M):
        histogram = Counter(dist(s*d, M) for s in slopes)
        total = 0
        for radius in range(M//2+1):
            total += histogram[radius]
            check('odd_slope_collision_all_d', F(total, M//2) <= F(4*radius, M))
    for b in range(2, m-1):
        B = 1 << b; T = M//B; g = T//4; H = 3*T//4
        central = {j % M for j in range(-g,g+1)}
        centers = [j*T for j in range(B)]
        check('distinct_dirichlet_residues', len({u % M for u in range(-H,H+1)}) == 2*H+1 < M)
        for f in range(M):
            window = {(f-u) % M for u in range(-H,H+1)}
            if dist(f,M) <= T//2: check('flat_passband_inclusion', central <= window)
            if dist(f,M) > T: check('flat_stopband_exclusion', all(dist(v,M) > g for v in window))
            check('three_near_centers_including_endpoints', sum(dist(j-f,M) <= T for j in centers) <= 3)
        for s in slopes:
            inverse = pow(s, -1, M)
            decoded = []
            for j in range(B):
                fiber = {(inverse*u) % M for u in range(j*T-T//2, j*T+T//2)}
                expected = {i for i in range(M) if (((s*i)%M+T//2)//T)%B == j}
                check('inverse_fiber_half_open_exact', fiber == expected and len(fiber) == T)
                decoded.extend(fiber)
            check('all_fibers_partition', sorted(decoded) == list(range(M)))
        # Fully enumerate target-dependent centers; sigma and h are not independent.
        for i in range(M):
            for d in range(1,M):
                l = (i-d)%M
                near = 0
                for s in slopes:
                    h = (((s*i)%M+T//2)//T)%B
                    if dist(h*T-s*l, M) <= T: near += 1
                check('dependent_hash_near_bound', F(near,M//2) <= F(6,B))

# Exact rational comparisons at both small and very large formal parameters.
for m in list(range(2,81))+[96,127]:
    M=1 << m; rho=F(1,1 << (16*m+16)); A=2*M*M
    for b in sorted({2,max(2,m//2),m}):
        W=M-1
        E=(A+2*W*rho)*(1+rho)**(b+1)-A+rho
        Eta=(1+rho)*E+A*rho+rho
        bound=64*(m+1)*M*M*rho
        check('exact_bucket_constant', E <= 24*(m+1)*M*M*rho)
        check('exact_estimate_constant', Eta <= bound)
    check('normalization_margin_squared', bound*bound < F(1,64*M))
    check('flat_leakage_constant', M*F(1,16**(2*m+1)) <= F(1,M**4))
    check('one_round_markov_bound', F(24,4096)+F(2,M**7) < F(1,128))
    check('all_tape_estimate_bound', A+bound < 3*M*M)
    L=4*m+1; h=(L+1)//2
    check('majority_subset_bound', F(comb(L,h),16**h) <= F(1,2**L))
    check('global_probability_identity', 2*M*F(1,2**L) == F(1,M**3))

# Abstract robust top-q proof control with actual exact ranking ties, independent
# of the production decoder. Units are a/4; errors are at most a/4, a relaxation
# of the strict source error. Selected heavy target is fixed at ideal >=3a.
for B in (2,3,4,5):
    for q in range(1,B+1):
        for rest in product((0,4,8,10,12), repeat=B-1):
            for target in (0,B-1):
                ideal=rest[:target]+(12,)+rest[target:]
                K={j for j,v in enumerate(ideal) if v>=8}
                if len(K)>q: continue
                for signs in product((-1,1), repeat=B):
                    computed=tuple(v+e for v,e in zip(ideal,signs))
                    order=sorted(range(B),key=lambda j:(-computed[j]**2,j))
                    check('robust_top_q_ties', target in order[:q])

# Exact parameter rounding on non-dyadic as well as dyadic beta.
eligible=[]
for beta in [F(1,100),F(1,8),F(1,4),F(2,7),F(7,16),F(49,100)]:
    for m in range(1,513):
        M=1<<m; k=1<<ceil(2*beta*m); B=1<<ceil((F(1,2)+beta)*m)
        r=2*m+1; W=2*r*(8*B-1)+1
        good=M%B==0 and B>=4 and M//B>=4 and B>=4096*k and W<M
        if not good: continue
        eligible.append((str(beta),m))
        T=M//B; q=512*k; L=4*m+1; h=(L+1)//2
        check('source_parameters_support_cap', (L*q*T)//h <= 2*q*T <= M//4 and q<=B and T<=B)
        check('source_precision_value', 16*m+16 == (1 << (16*m+16)).bit_length()-1)

# Exact reduced leakage witness and normalized-domain exclusion witness.
check('reduced_leakage_witness', F(12,32**2*9)==F(1,768)>F(1,64**4))
m=46; M=1<<m; beta=F(1,4); P=16*m+16; FF=P+2*m+5
k=1<<ceil(2*beta*m); B=1<<ceil((F(1,2)+beta)*m)
check('tiny_source_sparse_guards', B==1<<35 and k==1<<23 and B>=4096*k and 2*(2*m+1)*(8*B-1)+1<M)
check('tiny_source_rounding', 4*M*M*F(1,1<<FF)==F(1,1<<(P+3))<F(1,1<<(P+1)))
check('tiny_source_outside_norm', F(1,1<<(FF-m//2)) < F(1,2) and 16<1<<23)

result={'verdict':'PASS','candidate_sha256':EXPECTED,'counts':dict(sorted(counts.items())),
        'total_checks':sum(counts.values()),'eligible_parameter_cases':len(eligible),
        'scientific_source_imports':0,'historical_or_candidate_programs_executed':0,
        'interpretation':'Finite exact controls corroborate the independent universal proof; they do not establish universal success by extrapolation.'}
(ROOT/'results/INDEPENDENT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
