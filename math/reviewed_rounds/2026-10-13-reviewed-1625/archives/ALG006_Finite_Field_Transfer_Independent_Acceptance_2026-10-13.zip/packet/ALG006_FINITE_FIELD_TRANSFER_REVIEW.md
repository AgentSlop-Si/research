# ALG006 finite field Prony transfer review

Date: 2026-10-13 UTC. Verdict: **ACCEPT, exactly for the guarded split-node channel recovery core.** The comparison's coefficient dictionary is correct, and characteristic p>D suffices. No stronger p>2D condition is needed. Nonzero highest coefficients are essential for exact order D; the frozen claim already includes them, or equivalently assumes nonsingular D-square pilot Hankels. Arbitrary nonsingular Hankel data need an additional split, nonzero-root check before claiming a solution over the base finite field.

This review establishes moment algebra, Hankel rank, minimal annihilator and identifiability of unknown multiplicities. It does not certify a full DFT algorithm, cross-channel parameter decoding, sparse forcing, novelty, a fast implementation, numerical stability or an end-to-end complexity bound. No archived scientific program was imported or executed. Fresh controls run only the channel algebra. No Sheet, GitHub repository or reviewed source was changed.

## Frozen inputs and primary source

The reviewed comparison is `ALG006_CONFLUENT_PRONY_COMPARISON.md`, SHA-256 `698da26f192b403680b0b2cd2c0ca6540d712f275741d8ba477f9b8b6d0afaeb`. Its three archived mathematical inputs were independently rehashed and match all stated pins:

- `CONFLUENT_FUSION.md`: `5f31ce4af2eba202f66ce217c07feafdcf038d4d96bb557c53c3a4c7f2f686a4`
- `AUDIT_REPORT.md`: `5597a056be038290dc763c846dab8a1e4a3e280a2b7b1d606c45d911b14e8ac3`
- `INTEGRATED_RESULTS.md`: `2d2a67a3ec1f72c32ac39b54ce853048a195e0b90ddf2543fd8d5f83c34794ae`

The copied inputs and comparison packet metadata are in `sources/`; `INPUT_PIN_RECHECKS.json` gives byte counts and hashes. No additional historical identity beyond these copied inputs is independently certified here.

The primary comparator is Batenkov and Yomdin, *Geometry and Singularities of the Prony Mapping*, Journal of Singularities 10 (2014), 1–25, DOI 10.5427/jsing.2014.10a. Problem 1.3 and Theorem 3.6 concern complex moment data with unknown multiplicities; the theorem uses a rectangular Hankel rank and leading minor, and identifies multiplicities through poles. Definition 1.1 already requires nonzero highest coefficients. These source statements were inspected in the [publisher PDF](https://www.journalofsing.org/volume10/batenkov-yomdin.pdf#page=7), printed pp. 2–3 and 7. The finite-field argument below is an independent algebraic proof, not a literal invocation of a theorem with domain C. PDF text access succeeded; a screenshot request failed. No local PDF bytes or PDF hash are claimed.

## Precise standalone statement

Let K be a field of characteristic p>D, let lambda_1,...,lambda_g be pairwise distinct members of K excluding zero, and let d_1,...,d_g be positive integers summing to D. Suppose

    m_t = sum_j sum_(ell=0)^(d_j-1) B_(j,ell) binom(t,ell) lambda_j^t,
    B_(j,d_j-1) != 0 for every j,   t = 0,1,2,... .

Here binom(t,ell) is the integer binomial coefficient reduced in K, and is zero for t<ell. Then:

1. The transformation alpha_(j,ell)=B_(j,ell) lambda_j^ell / ell! is invertible and gives the ordinary confluent moments sum alpha_(j,ell) (t)_ell lambda_j^(t-ell).
2. The leading D-square Hankel H_D=(m_(a+b))_(0<=a,b<D) is nonsingular; the D-by-(D+1) Hankel has rank D; the infinite Hankel has rank D.
3. The minimal monic forward-shift annihilator is P(z)=product_j(z-lambda_j)^(d_j).
4. The first 2D moments determine P by one nonsingular linear system. Within this model with total order at most D, they uniquely determine all distinct nodes, their true multiplicities, and coefficients, up to permutation.
5. Extracting the nodes and multiplicities from P is a separate factorization/root-extraction step. The theorem does not supply them as a free oracle.

Conversely, given arbitrary 2D elements of K and a nonsingular H_D, form the monic degree-D polynomial from the Hankel solve below. These moments have such an exact-order-D representation with distinct nonzero K-nodes if and only if that polynomial splits entirely into nonzero roots in K. In that event, the recovered highest coefficients are automatically nonzero. This converse is confined to the nonsingular exact-D branch; it is not a completeness claim for a lower-rank or dirty-pilot recognizer.

## Exact coefficient dictionary

For an integer t>=0, define (t)_ell as the product t(t-1)...(t-ell+1), with (t)_0=1. Since ell<=d_j-1<D<p, ell! is invertible. Therefore

    alpha_(j,ell) (t)_ell lambda_j^(t-ell)
      = B_(j,ell) lambda_j^ell (t)_ell lambda_j^(t-ell) / ell!
      = B_(j,ell) binom(t,ell) lambda_j^t.

The inverse is B_(j,ell)=alpha_(j,ell) ell! lambda_j^(-ell). Nonzero nodes are used in this inverse and in the negative exponents when t<ell; the falling-factorial term is then zero.

The identity remains valid when t>=p. One must evaluate the falling product, not an expression that divides t! by (t-ell)! inside K. Those larger factorials may vanish. The only factorial inverted is ell!, so the fact that the available sample indices run as high as 2D-1 does not require p>2D.

Here alpha is explicitly the coefficient of the displayed algebraic falling-factorial moment term. No convention for the sign of a distributional delta derivative is imported. Under the usual distribution convention, the coefficient of delta^(ell) would be (-1)^ell alpha. In the formal rational-function calculation below, the coefficient of (z-lambda_j)^(-ell-1) is positive alpha_(j,ell) ell!.

## Hankel factorization and exact nondegeneracy

Use the Hasse, or divided-derivative, evaluation matrix

    W[t,(j,a)] = binom(t,a) lambda_j^(t-a),
    0<=t<D,  0<=a<d_j,

where the entry is zero for a>t. The columns are ordered by j and then increasing a. Let T be block diagonal, with block

    T_j[a,b] = B_(j,a+b) lambda_j^(a+b) if a+b<d_j,
               0                            otherwise.

Vandermonde's binomial identity, reduced from the integers, gives

    H_D = W T W^T.

Indeed, the (r,s) entry is the sum, over j and a+b=ell, of B_(j,ell) lambda_j^ell binom(r,a) lambda_j^(r-a) binom(s,b) lambda_j^(s-b), which is exactly m_(r+s).

W is invertible in any characteristic. Its transpose represents the map from polynomials f of degree less than D to the truncated Taylor coefficients of f(lambda_j+u) modulo u^(d_j). Its kernel consists of polynomials divisible by every (z-lambda_j)^(d_j). Coprimality of the distinct factors makes that equivalent to divisibility by their degree-D product. Thus the kernel is zero, and the square map is invertible. This argument uses no ordinary derivative factorials.

Equivalently, the confluent Vandermonde determinant is

    det W = product_(i<j) (lambda_j-lambda_i)^(d_i d_j).

This is an integer polynomial identity and survives reduction modulo p. Each T_j has constant anti-diagonal B_(j,d_j-1) lambda_j^(d_j-1) and zero entries beyond it. Consequently,

    det H_D
      = (-1)^(sum_j d_j(d_j-1)/2)
        product_j [B_(j,d_j-1)^d_j lambda_j^(d_j(d_j-1))]
        product_(i<j) (lambda_j-lambda_i)^(2 d_i d_j).

Every factor is nonzero under the stated guard. Conversely, for these fixed distinct nonzero nodes and declared multiplicities, H_D is nonsingular only if every highest B is nonzero. Thus the top-coefficient requirement is necessary and sufficient here, rather than a cosmetic genericity assumption.

The same factorization with arbitrary numbers of nonnegative row and column indices bounds all finite Hankel ranks by D. The leading D-square block attains D, so the infinite Hankel rank is D and the particular D-by-(D+1) pilot Hankel also has rank D.

## Annihilator and recovery of unknown multiplicities

Let E be the forward shift, (Ef)_t=f_(t+1), and put e_(j,ell)(t)=binom(t,ell) lambda_j^t. Pascal's identity gives

    (E-lambda_j)e_(j,ell) = lambda_j e_(j,ell-1),
    e_(j,-1)=0.

Hence (E-lambda_j)^(d_j) kills the jth summand and P(E)m=0. If a nonzero polynomial q of degree r<D annihilated m, its coefficients would give a nontrivial dependence among the first r+1 columns of H_D, using the recurrence at t=0,...,D-1. Nonsingularity rules this out. The monic annihilator P is therefore minimal of exact degree D.

Write P(z)=z^D+sum_(k=0)^(D-1)c_k z^k. The first 2D moments give

    H_D [c_0,...,c_(D-1)]^T = -[m_D,...,m_(2D-1)]^T.

This has a unique solution. Factoring the resulting polynomial, when split over K, recovers the unordered pairs (lambda_j,d_j). Distinct factorization determines the true multiplicities; it cannot identify artificially padded zero top coefficients.

With those pairs known, the amplitude matrix A[t,(j,ell)]=binom(t,ell) lambda_j^t for 0<=t<D equals W times the diagonal matrix with entries lambda_j^ell. It is invertible, so the first D moments uniquely determine all B. If a second nondegenerate representation of order at most D fitted all 2D observations, its order would be at least D by the observed Hankel rank. Its order-D annihilator must solve the same system, after which factorization and the amplitude solve make it identical up to permutation.

For the converse in the standalone statement, split the recovered polynomial and solve this amplitude system. The resulting sequence has that recurrence and agrees on the first D moments. The D equations in the Hankel solve propagate agreement through the remaining D moments. If a recovered top coefficient vanished, the determinant formula would contradict the input H_D being nonsingular.

## Formal rational function check

An independent way to see the poles and uniqueness is to work with a formal Laurent series at infinity:

    S(z) = sum_(t>=0) m_t z^(-t-1)
         = sum_(j,ell) B_(j,ell) lambda_j^ell / (z-lambda_j)^(ell+1)
         = sum_(j,ell) alpha_(j,ell) ell! / (z-lambda_j)^(ell+1).

Each top numerator B_(j,d_j-1) lambda_j^(d_j-1) is nonzero, so S has an actual pole of order d_j at lambda_j. Its reduced denominator is exactly P and its numerator degree is below D. If two such rational functions with denominator degrees at most D had the same first 2D moments, their difference would have Laurent order at most z^(-2D-1). A nonzero numerator over a denominator of degree at most 2D cannot have that order. Thus the rational function is unique over any field. This proof is formal algebra; it requires no complex topology or analytic convergence.

## Sharp boundaries and explicit counterexamples

**Vanishing top coefficient.** Over F5, take one node lambda=2, declared d=2, B_0=1 and B_1=0. The first four moments are (1,2,4,3). The Hankel [[1,2],[2,4]] has rank 1 and determinant 0. The minimal annihilator is z-2, not (z-2)^2. Here p>D and the node is nonzero. Therefore p>D and node separation alone are insufficient. This does not contradict the frozen guarded statement, which expressly includes top-spectrum nonvanishing or nonsingular pilot Hankels.

**Missing split-node hypothesis.** Over F5, the moments (0,1,0,3) give H_2=[[0,1],[1,0]], with determinant 4. Its unique annihilator is z^2+2, which has no root in F5 because 3 is not a square there. The moments have no representation of the stated order over split F5 nodes. The algebraic-closure conclusion associated with complex Prony cannot be copied to F5 without a splitting requirement. This counterexample is also outside the frozen model promise.

**What the characteristic guard really does.** For the coefficient dictionary alone it is enough that every ell! used is invertible, or max_j d_j<=p. The Hankel and binomial recurrence arguments themselves work in every characteristic when binom(t,ell) means the integer binomial sequence reduced in the field. This is a stronger algebraic observation, not a relaxation of the project's contract.

At p=2, d=D=3, lambda=1 and B=(0,0,1), the moments binom(t,2) begin (0,0,1,1,0,0). H_3 is nonsingular. But (t)_2 is zero in F2 for every integer t and 2! is not invertible. No ordinary falling-factorial dictionary of the claimed kind represents this term. The divided-power binomial model and ordinary polynomial-in-t model must not be conflated outside the factorial guard.

The equality case p=D can work perfectly for moment recovery: p=D=3, lambda=1 and B=(0,0,1) give minimal annihilator (z-1)^3=z^3-1. However, its weighted trace d lambda vanishes in F3. Thus a weakened moment guard would not justify weakening the separate ALG-006 trace/composition procedure, which divides by multiplicities and depends on visible nonzero trace weights.

## Costs and interfaces kept separate

- The input to this proof is an already available list of 2D moments in a supplied exact field. Transforming raw ALG-006 rows into moments is separate work. This review does not treat those moments as a free raw-input oracle.
- A literal dense Hankel solve and a dense amplitude solve each use O(D^3) field operations and O(D) pivot inversions. Matrix formation, polynomial arithmetic and field representation must also be paid. These elementary counts assert no optimized algorithm or uniform end-to-end performance.
- The annihilator coefficients can be recovered without knowing its nodes. Nodes and multiplicities require a factorization/root interface. Over F_p, a valid but slow alternative is to test all p field elements and divide out roots repeatedly, with O(pD+D^2) elementary field work. The fresh controls deliberately do that. It is not a free factorization primitive or a promised fast method.
- Even a promise that P splits does not present its roots. Factorization cost is distinct from existence and uniqueness. Extension-field representations and nonsplit inputs would require different contracts.
- The supplied p, its primality, field arithmetic and possible roots of unity are outside this moment proof. There is no bit-complexity, numerical-conditioning or discrete-log conclusion.
- The archive's cross-channel trace/composition route is a different way to produce candidate node data. Nothing here replaces its proof or accounting with a generic free Prony root oracle.

## Fresh exhaustive controls

The new standard-library-only `checks/fresh_field_controls.py` was authored for this review. It imports no archived project code and computes no full DFT. It exhausts every canonical distinct nonzero-node model, every positive multiplicity composition and every coefficient vector with nonzero top coefficients in these ranges:

- F2, 1<=D<=1: 1 model
- F3, 1<=D<=2: 20 models
- F5, 1<=D<=4: 15,104 models
- F7, 1<=D<=3: 14,472 models

All **29,597 in-guard models passed**. Of these, 14,928 have a required 2D-moment index reaching or exceeding p, directly exercising the absence of a p>2D requirement. An additional 83 cases were checked in the suites F2 with D<=2 and F3 with D<=3; 62 of these have D=p. All boundary-suite cases passed the moment checks.

For every model, the script checks the coefficient dictionary across indices beyond p, the confluent determinant, H=W T W^T, the explicit Hankel determinant, rectangular Hankel rank, the solved product annihilator, extra recurrence values, paid exhaustive root extraction with multiplicities, the amplitude solve, and absence of collisions in common bounded-order sample prefixes. It also asserts the explicit boundary witnesses above. Complete counts and exact witnesses are in `checks/CONTROL_RESULTS.json`; `checks/RUN.log` records the completed run. These finite tests supplement the general proof and are not its basis.

Reproduce from the payload root:

    python3 checks/fresh_field_controls.py

The results include wall-clock duration, so that one timing field will naturally vary on rerun. The sealed original run is preserved.

## Disposition

No counterexample was found to the actual guarded transfer. Its exact algebraic identification and unknown-multiplicity recovery are accepted within the declared split, nonzero-node, nondegenerate fixed-total-order channel model. The standalone theorem above makes all required quantifiers explicit. The comparison's phrase about finite-field transport can safely be expanded to cite the determinant, minimal-annihilator proof and split-root condition given here. No archived mathematical status, broader ALG-006 claim, or publication-level novelty assessment is changed by this review.
