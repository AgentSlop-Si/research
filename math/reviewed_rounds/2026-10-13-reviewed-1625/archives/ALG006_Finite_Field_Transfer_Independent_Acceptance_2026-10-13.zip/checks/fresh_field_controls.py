#!/usr/bin/env python3
"""Fresh, standard-library-only moment algebra controls. No archive code is imported."""
from itertools import combinations, product
from math import comb, factorial
from pathlib import Path
import json, time

ROOT = Path(__file__).resolve().parents[1]

def compositions(n, g):
    if g == 1:
        yield (n,)
    else:
        for a in range(1, n-g+2):
            for tail in compositions(n-a, g-1):
                yield (a,) + tail

def rref(a, p):
    a = [[x % p for x in row] for row in a]
    if not a:
        return a, []
    pivots=[]; row=0
    for c in range(len(a[0])):
        k=next((k for k in range(row,len(a)) if a[k][c]),None)
        if k is None:
            continue
        a[row],a[k]=a[k],a[row]
        z=pow(a[row][c],-1,p)
        a[row]=[(x*z)%p for x in a[row]]
        for k in range(len(a)):
            if k != row:
                z=a[k][c]
                a[k]=[(x-z*y)%p for x,y in zip(a[k],a[row])]
        pivots.append(c); row+=1
        if row == len(a):
            break
    return a,pivots

def rank(a,p):
    return len(rref(a,p)[1])

def solve(a,b,p):
    n=len(a)
    r, piv=rref([row+[v] for row,v in zip(a,b)],p)
    assert piv == list(range(n)), (a,b,p,r,piv)
    return [row[-1] for row in r]

def det(a,p):
    a=[row[:] for row in a]; z=1
    for c in range(len(a)):
        k=next((k for k in range(c,len(a)) if a[k][c]%p),None)
        if k is None:
            return 0
        if k != c:
            a[c],a[k]=a[k],a[c]; z=-z
        z=z*a[c][c]%p; inv=pow(a[c][c],-1,p)
        for k in range(c+1,len(a)):
            q=a[k][c]*inv%p
            a[k]=[(x-q*y)%p for x,y in zip(a[k],a[c])]
    return z%p

def mul(a,b,p):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            c[i+j]=(c[i+j]+x*y)%p
    return c

def polyval(q,x,p):
    z=0
    for a in q[::-1]:
        z=(z*x+a)%p
    return z

def roots_with_multiplicity(q,p):
    # Deliberately paid exhaustive search over F_p. This is not a free root oracle.
    q=q[:]; out=[]
    for x in range(p):
        d=0
        while len(q)>1 and polyval(q,x,p)==0:
            b=[0]*(len(q)-1); b[-1]=q[-1]
            for k in range(len(b)-2,-1,-1):
                b[k]=(q[k+1]+x*b[k+1])%p
            assert (q[0]+x*b[0])%p==0
            q=b; d+=1
        if d:
            out.append((x,d))
    return out,q

def moments(nodes,ds,bs,L,p):
    return [sum(B*comb(t,l)*pow(x,t,p) for x,d,bc in zip(nodes,ds,bs)
                for l,B in enumerate(bc) if l<=t)%p for t in range(L)]

def fall(t,l):
    z=1
    for k in range(l):
        z*=t-k
    return z

def matrixmul(a,b,p):
    return [[sum(x*y for x,y in zip(ar,bc))%p for bc in zip(*b)] for ar in a]

def check_model(p,nodes,ds,bs,Dmax):
    D=sum(ds); L=max(2*D+2*p+3,2*Dmax)
    m=moments(nodes,ds,bs,L,p)
    alpha=[[B*pow(x,l,p)*pow(factorial(l),-1,p)%p for l,B in enumerate(bc)]
           for x,bc in zip(nodes,bs)]
    mf=[sum(a*fall(t,l)*pow(x,t-l,p) for x,ac in zip(nodes,alpha)
            for l,a in enumerate(ac))%p for t in range(L)]
    assert m==mf
    H=[[m[a+b] for b in range(D)] for a in range(D)]
    W=[[comb(t,l)*pow(x,t-l,p)%p if l<=t else 0
        for x,d in zip(nodes,ds) for l in range(d)] for t in range(D)]
    T=[[0]*D for _ in range(D)]; off=0
    expected=(-1)**sum(d*(d-1)//2 for d in ds)
    expectedW=1
    for i,(x,d,bc) in enumerate(zip(nodes,ds,bs)):
        for a in range(d):
            for b in range(d):
                if a+b<d:
                    T[off+a][off+b]=bc[a+b]*pow(x,a+b,p)%p
        expected=expected*pow(bc[-1],d,p)*pow(x,d*(d-1),p)%p
        for j in range(i):
            expected=expected*pow(x-nodes[j],2*d*ds[j],p)%p
            expectedW=expectedW*pow(x-nodes[j],d*ds[j],p)%p
        off+=d
    assert det(W,p)==expectedW%p
    assert matrixmul(matrixmul(W,T,p),list(map(list,zip(*W))),p)==H
    assert det(H,p)==expected%p != 0
    assert rank([[m[a+b] for b in range(D+1)] for a in range(D)],p)==D
    got=solve(H,[-m[a+D]%p for a in range(D)],p)+[1]
    want=[1]
    for x,d in zip(nodes,ds):
        for _ in range(d):
            want=mul(want,[-x%p,1],p)
    assert got==want
    assert all(sum(q*m[t+k] for k,q in enumerate(got))%p==0 for t in range(L-D))
    recovered,rest=roots_with_multiplicity(got,p)
    assert recovered==list(zip(nodes,ds)) and rest==[1]
    V=[[comb(t,l)*pow(x,t,p)%p if l<=t else 0
        for x,d in zip(nodes,ds) for l in range(d)] for t in range(D)]
    assert solve(V,m[:D],p)==[v for bc in bs for v in bc]
    return m

def exhaustive(p,Dmax,tag):
    seen={}; counts={}; crossing=0
    for D in range(1,Dmax+1):
        count=0
        for g in range(1,min(D,p-1)+1):
            for nodes in combinations(range(1,p),g):
                for ds in compositions(D,g):
                    if max(ds)>p:
                        continue
                    arrays=[list(product(range(p),repeat=d-1)) for d in ds]
                    for lows in product(*arrays):
                        for tops in product(range(1,p),repeat=g):
                            bs=tuple(low+(top,) for low,top in zip(lows,tops))
                            m=check_model(p,nodes,ds,bs,Dmax)
                            model=(nodes,ds,bs); key=tuple(m[:2*Dmax])
                            assert key not in seen or seen[key]==model
                            seen[key]=model; count+=1
                            crossing += int(2*D-1>=p)
        counts[str(D)]=count
    return {'p':p,'maximum_total_order':Dmax,'tag':tag,'by_exact_order':counts,
            'models':sum(counts.values()),'models_with_2D_sample_indices_reaching_p':crossing,
            'prefix_collision_count':0,'all_checks_passed':True}

def counterexamples():
    p=5; m=moments((2,),(2,),((1,0),),6,p)
    H=[[m[i+j] for j in range(2)] for i in range(2)]
    assert m[:4]==[1,2,4,3] and rank(H,p)==1 and det(H,p)==0
    irreducible=[2,0,1]
    assert roots_with_multiplicity(irreducible,5)==([],[2,0,1])
    m_unsplit=[0,1,0,3]
    H_unsplit=[[0,1],[1,0]]
    assert solve(H_unsplit,[0,2],5)+[1]==irreducible
    m_p=moments((1,),(3,),((0,0,1),),8,2)
    assert m_p[:6]==[0,0,1,1,0,0]
    assert all(fall(t,2)%2==0 for t in range(8))
    assert det([[m_p[i+j] for j in range(3)] for i in range(3)],2)==1
    return [
      {'case':'highest coefficient vanishes','p':5,'declared_D':2,'nodes':[2],
       'multiplicities':[2],'B':[[1,0]],'first_2D_moments':m[:4],
       'H_D_determinant':0,'H_D_rank':1,'actual_minimal_annihilator_low_to_high':[3,1],
       'meaning':'p>D and distinct nonzero nodes alone do not imply exact rank D or identify padded multiplicities.'},
      {'case':'nonsingular Hankel does not imply split nodes over the base field','p':5,'D':2,
       'first_2D_moments':m_unsplit,'H_D_determinant':4,
       'recovered_annihilator_low_to_high':irreducible,'roots_in_base_field':[],
       'meaning':'The split-node hypothesis or a split-factor verification remains essential.'},
      {'case':'factorial dictionary outside the guard','p':2,'D':3,'nodes':[1],
       'multiplicities':[3],'B':[[0,0,1]],'first_2D_moments':m_p[:6],
       'H_D_determinant':1,'falling_factorial_order_p_identically_zero':True,
       'meaning':'The divided-power binomial basis still works, but ordinary falling-factorial coordinates cannot represent binom(t,p).'},
      {'case':'p equals D is valid for moments but can erase trace','p':3,'D':3,
       'nodes':[1],'multiplicities':[3],'B':[[0,0,1]],
       'first_2D_moments':moments((1,),(3,),((0,0,1),),6,3),
       'annihilator_low_to_high':[2,0,0,1],'weighted_trace':0,
       'meaning':'The moment guard can be weakened locally; this does not weaken ALG-006 trace-decoding hypotheses.'}
    ]

def main():
    t=time.time()
    runs=[exhaustive(p,D,'in_guard_p_greater_D') for p,D in [(2,1),(3,2),(5,4),(7,3)]]
    boundaries=[exhaustive(p,D,'boundary_p_equals_D') for p,D in [(2,2),(3,3)]]
    result={'status':'PASS','scope':'Fresh split-node channel moment algebra only',
            'historical_code_imported_or_executed':False,'full_DFT_computed':False,
            'in_guard_runs':runs,'boundary_runs':boundaries,
            'in_guard_models':sum(r['models'] for r in runs),
            'boundary_models':sum(r['models'] for r in boundaries),
            'counterexamples_and_boundary_witnesses':counterexamples(),
            'checks':['binomial/falling-factorial dictionary beyond t=p',
              'Hasse-confluent Vandermonde determinant','H=W T W^T',
              'explicit Hankel determinant formula','rank D of D by D+1 Hankel',
              'unique Hankel solve equals product annihilator','recurrence on extra moments',
              'paid exhaustive F_p root extraction recovers unknown multiplicities',
              'confluent solve recovers all amplitudes','no model collisions in common bounded-order prefixes'],
            'elapsed_seconds':round(time.time()-t,6)}
    (ROOT/'checks/CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
