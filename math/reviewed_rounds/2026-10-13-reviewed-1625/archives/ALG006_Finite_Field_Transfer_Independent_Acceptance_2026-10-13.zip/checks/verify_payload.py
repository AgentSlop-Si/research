#!/usr/bin/env python3
"""Verify every sealed payload member, including this verifier."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest_path=root/'packet/MANIFEST.json'
manifest=json.loads(manifest_path.read_text())
expected={x['path']:x for x in manifest['files']}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=manifest_path}
assert actual==set(expected), {'missing':sorted(set(expected)-actual),'extra':sorted(actual-set(expected))}
for name,entry in expected.items():
    data=(root/name).read_bytes()
    assert len(data)==entry['bytes'],name
    assert hashlib.sha256(data).hexdigest()==entry['sha256'],name
for pin in json.loads((root/'packet/INPUT_PIN_RECHECKS.json').read_text()):
    data=(root/pin['copied_path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==pin['sha256']
    assert len(data)==pin['bytes']
checks=json.loads((root/'checks/CONTROL_RESULTS.json').read_text())
assert checks['status']=='PASS'
assert checks['in_guard_models']==29597 and checks['boundary_models']==83
print(json.dumps({'status':'PASS','verified_files':len(expected),'review_verdict':manifest['verdict']},indent=2))
