"""New exact controls for the finite-win interface; executes no supplied code."""
from fractions import Fraction as F
from itertools import product
from math import comb, prod, log
import json
from pathlib import Path

def mul(a, b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]

def diag(a,b): return [[F(a),F(0)],[F(0),F(b)]]
H=[[F(1),F(1)],[F(1),F(-1)]]
def shear(t):
    a=diag(-t/F(10),-F(1,6))
    for b in [H,diag(2,1),H,diag(-3,1),H,diag(F(5,4)/t,1)]:
        a=mul(a,b)
    return a

assert shear(F(1))==[[1,1],[0,1]]
shear_values=[F(a,b) for a in range(-9,10) if a for b in range(1,10)]
for t in shear_values: assert shear(t)==[[1,t],[0,1]]

moment=[]
for j in range(25):
    weights=[F(comb(j,r)*14**(j-r)*2**r,16**j) for r in range(j+1)]
    assert sum(weights)==1
    assert sum(r*w for r,w in enumerate(weights))==F(j,8)
    moment.append({'groups':j,'mass':'1','mean':str(F(j,8))})
assert 31**200<32**199
assert F(997,1000)<1-F(8762478,10**10)

# Independently enumerate packed sectors, then compare every address with
# the closed-form start and incremental offset rules. Include nonconsecutive
# ordered pairs and reversed pairs, singleton-only axes, and a one-block axis.
axes_choices=[[(0,)],[(1,0)],[(2,0),(1,)],[(3,1),(0,),(2,)],
              [(0,),(1,),(2,)],[(4,1),(3,0),(2,)]]
packing_cases=0
packing_coordinates=0
for length in range(1,5):
    for axes in product(axes_choices,repeat=length):
        radices=[sum(map(len,a)) for a in axes]
        R=prod(radices)
        actual={}
        p_tables=[]
        for axis in axes:
            off=0; d={}
            for bi,block in enumerate(axis):
                d[bi]=off; off+=len(block)
            p_tables.append(d)
        running=0
        for blocks in product(*(range(len(a)) for a in axes)):
            Qs=[len(axes[j][b]) for j,b in enumerate(blocks)]
            start=sum(prod(Qs[:j])*p_tables[j][b]*prod(radices[j+1:])
                      for j,b in enumerate(blocks))
            assert start==running
            for local in product(*(range(q) for q in Qs)):
                original=tuple(axes[j][b][local[j]] for j,b in enumerate(blocks))
                offset=0
                for q,t in zip(Qs,local): offset=offset*q+t
                actual[original]=start+offset
            running+=prod(Qs)
        assert running==R and sorted(actual.values())==list(range(R))
        # Prefix bound excludes radix-one axes, which should be deleted.
        nontrivial=[r for r in radices if r>=2]
        prefix_sum=sum(prod(nontrivial[:j]) for j in range(len(nontrivial)+1))
        assert prefix_sum<2*prod(nontrivial)
        packing_cases+=1; packing_coordinates+=R

def prime(p):
    return p>=2 and all(p%d for d in range(2,int(p**.5)+1))
working=[]
for n in list(range(1,2501))+[10**k for k in range(4,13)]:
    R=1; p=3; count=0
    while R*p<=2*n:
        R*=p; count+=1; p+=2
        while not prime(p): p+=2
    L=R; e=0
    while L<2*n: L*=2; e+=1
    assert 2*n<=L<4*n and 2**e<2*p
    padding_root=1<<((16*L-1).bit_length())
    D=2*n*L*padding_root
    assert D<1024*n**3 and D%(2*n)==0 and D%L==0
    working.append({'n':n,'L':L,'axes':count,'e':e,'D':D})

out={
 'status':'PASS',
 'scope':'Fresh exact finite controls; no 31-call word supplied or verified; no historical code executed.',
 'three_forward_H2_shear_cases':len(shear_values),
 'sector_moment_cases':len(moment),
 'moment_identity':moment,
 'strict_exponent_integer_test':{'lhs_base':31,'lhs_power':200,'rhs_base':32,'rhs_power':199,'passed':True},
 'critical_exponent_display_only':log(31)/log(32),
 'conditional_alpha':'199/200','eventual_beta':'997/1000',
 'matched_baseline':'1 - 8762478/10000000000 = 0.9991237522',
 'packing_cases':packing_cases,'packing_coordinates':packing_coordinates,
 'working_length_root_cases':len(working),
 'selected_working_lengths':working[-9:]
}
Path(__file__).with_name('FRESH_CHECK_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['moment_identity','selected_working_lengths']},indent=2))
