"""Independent byte/native-state audit; no external actions or scientific execution."""
import json, hashlib, zipfile, copy, collections, shutil
from pathlib import Path
P=Path(__file__).parent;W=P.parent;V=W/'current_round_reconciliation_v5_2053'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def wr(n,d):(P/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def decode(jj):
 if jj.get('format')!='lossless-json-dag-v1':return jj
 a=[]
 for t,v in jj['nodes']:a.append(v if t==0 else [a[i] for i in v] if t==1 else {k:a[i] for k,i in v})
 return a[jj['root']]
def flat(reads):
 out={}
 for rd in reads:
  for s in rd['data']['sheets']:
   for g in s.get('data',[]):
    for r,rv in enumerate(g.get('rowData',[]),g.get('startRow',0)+1):
     for c,v in enumerate(rv.get('values',[]),g.get('startColumn',0)+1):
      key=(s['properties']['title'],r,c);assert key not in out;out[key]=v
 return out
archive=W/'Current_Round_2040_Read_Only_Reconciliation_Proposal_v5_2026-10-13.zip'
assert sha(archive)=='d2fb08110b13af6f8cdb2a59369ad501e265681813a792358344704083fa504a'
man=j(V/'MANIFEST.json');az=zipfile.ZipFile(archive);assert az.testzip() is None
for e in man:
 data=az.read(e['path']);assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'];assert data==(V/e['path']).read_bytes()
assert az.read('MANIFEST.json')==(V/'MANIFEST.json').read_bytes()
v4=W/'current_round_independent_2040/proposal_v4_DATA_AUDIT.json';accepted=j(v4)
df=V/'PROPOSED_CELL_DIFF.json';assert sha(df)==accepted['diff_sha256']=='7caa8bb0843161610be9d60c291ce5f7089d7385e1386c656cb1e9c3b8dd741c'
for name in ['OUTCOMES.json','SOURCE_ACCEPTANCE_MAP.json','SCORING_RUBRIC.json','ALL_331_CURRENT_RANKING.json','STABLE_ID_VIEW_BINDINGS.json','ALL_SCORE_BINDINGS.json']:
 assert (V/name).read_bytes()==(W/'current_round_independent_2040/proposal_v4'/name).read_bytes()
B=decode(j(V/'evidence/BASELINE_NATIVE_PACKED.json'));bc=flat(B['reads']);D=j(df);assert len(D)==163
F=[j(f) for f in sorted(P.glob('live_*.json'))];fc=flat(F)
fm=j(P/'LIVE_METADATA_WITH_CONDITIONAL_FORMATS.json')['structuredContent'];assert fm==B['metadata']
bad=[k for k in bc if bc[k]!=fc[k]];assert set(bc)==set(fc) and len(bc)==19795
assert bad==[('Next cycle',4,1)] and fc[bad[0]]['userEnteredValue']=={'stringValue':' '*19}
assert all(bc[bad[0]][k]==fc[bad[0]][k] for k in bc[bad[0]] if k not in ['formattedValue','userEnteredValue','effectiveValue'])
req=j(V/'EXACT_BATCH_UPDATE_REQUEST.json');assert sha(V/'EXACT_BATCH_UPDATE_REQUEST.json')=='1ee1ff776e9fa03fe8f6b6190b07b852381914b9cf881f9d69d856f2196fca11'
assert len(req['requests'])==164 and req['spreadsheet_id']==B['metadata']['spreadsheetId']
sid={s['properties']['sheetId']:s['properties']['title'] for s in B['metadata']['sheets']}
sim={k:copy.deepcopy(v) for k,v in bc.items()};targets=[];expected={(d['sheet'],d['row'],d['column']):d for d in D}
for request in req['requests'][:-1]:
 assert set(request)=={'updateCells'};u=request['updateCells'];assert set(u)=={'range','rows','fields'} and u['fields']=='userEnteredValue'
 rg=u['range'];key=(sid[rg['sheetId']],rg['startRowIndex']+1,rg['startColumnIndex']+1)
 assert rg['endRowIndex']==rg['startRowIndex']+1 and rg['endColumnIndex']==rg['startColumnIndex']+1
 assert len(u['rows'])==len(u['rows'][0]['values'])==1
 v=u['rows'][0]['values'][0];assert set(v)=={'userEnteredValue'} and v['userEnteredValue']=={'stringValue':expected[key]['after']}
 assert bc[key]['userEnteredValue']=={'stringValue':expected[key]['before']}
 assert expected[key]['after'].endswith(expected[key]['before'])
 sim[key]['userEnteredValue']=v['userEnteredValue'];sim[key]['effectiveValue']=v['userEnteredValue'];sim[key]['formattedValue']=v['userEnteredValue']['stringValue'];targets.append(key)
assert set(targets)==set(expected) and len(targets)==163
last=req['requests'][-1];assert last=={'repeatCell':{'range':{'sheetId':1097193514,'startRowIndex':0,'endRowIndex':1,'startColumnIndex':0,'endColumnIndex':1},'cell':{'userEnteredFormat':{'verticalAlignment':'TOP'}},'fields':'userEnteredFormat.verticalAlignment'}}
sim[('Progress',1,1)]['userEnteredFormat']['verticalAlignment']='TOP';sim[('Progress',1,1)]['effectiveFormat']['verticalAlignment']='TOP'
for key,b in bc.items():
 got=copy.deepcopy(sim[key]);want=copy.deepcopy(b)
 if key in expected:
  for f in ['userEnteredValue','effectiveValue','formattedValue']:got.pop(f,None);want.pop(f,None)
 if key==('Progress',1,1):
  for f in ['userEnteredFormat','effectiveFormat']:got[f].pop('verticalAlignment');want[f].pop('verticalAlignment')
 assert got==want,key
visual=j(V/'VISUAL_AUDIT.json');unchanged=[]
for e in visual['panels']:
 v5=V/'render_verification'/e['path'];assert sha(v5)==e['v5_sha256']
 if e.get('equal'):assert e['v4_sha256']==e['v5_sha256'];unchanged.append(e['path'])
assert len(unchanged)==41
held=[d for d in D if d['sheet']=='Next cycle' and d['row']==4];safe=[d for d in D if d not in held]
assert len(held)==5 and len(safe)==158
wr('HELD_5_ORPHAN_ROW_CELLS.json',held)
wr('UNAFFECTED_158_CELL_PROPOSAL_NOT_APPLIED.json',safe)
safe_req={**req,'requests':[q for q in req['requests'][:-1] if not(q['updateCells']['range']['sheetId']==1152106829 and q['updateCells']['range']['startRowIndex']==3)]+[last]}
assert len(safe_req['requests'])==159
wr('UNAFFECTED_158_PLUS_TOP_REQUEST_NOT_APPLIED.json',safe_req)
drift={'cell':'Next cycle!A4','observed_value':' '*19,'prior_value':'STR-Q1','blank_length':19,'before_CellData':bc[bad[0]],'observed_CellData':fc[bad[0]],'is_target_cell':False,'target_ID_dependency_cells':['D4','F4','I4','K4','L4'],'no_restore_proposed':True,'fresh_target_recheck':'DRIFT_TARGET_READBACK.json'}
wr('LIVE_DRIFT.json',drift)
wr('INDEPENDENT_AUDIT.json',{'verdict':'ACCEPT_FROZEN_V5_PATCH_CONTENT_AND_FORMAT; HOLD_V5_APPLICATION_FOR_FRESH_ID_DRIFT',
 'proposal_archive_sha256':sha(archive),'manifest_entries_verified':len(man),'archive_entries':len(az.namelist()),'crc_pass':True,
 'v4_independent_scientific_data_audit_reused_by_exact_identity':sha(v4),'text_diff_sha256':sha(df),'exact_text_edits':163,'exact_additional_format_fields':1,
 'request_sha256':sha(V/'EXACT_BATCH_UPDATE_REQUEST.json'),'all_163_target_text_preimages_still_match':all(fc[k]['userEnteredValue']=={'stringValue':v['before']} for k,v in expected.items()),
 'native_cells_compared':len(bc),'unchanged_native_cells':len(bc)-len(bad),'native_drift_cells':['Next cycle!A4'],
 'metadata_with_conditional_formats_equal':True,'initial_metadata_difference':'Conditional-format rules omitted by default read; explicit include_conditional_format_rules=true removes apparent difference.',
 'full_live_coverage_ranges':len(F),'full_cell_read_started_at':min(x['started_at'] for x in F),'full_cell_read_finished_at':max(x['finished_at'] for x in F),
 'metadata_conditional_rules_recheck_time_utc':'2026-10-13T22:20:38Z','preapplication_note':'The complete CellData read and later conditional-format metadata check are separate evidence. An actual writer must repeat an ordered metadata-plus-cells preflight immediately before applying a separately authorized/reviewed rebased request.',
 'progress_TOP_preview_independently_viewed':True,'other_render_panels_hash_identical':len(unchanged),'all_history_suffixes_preserved':True,'format_notes_validation_formulas_elsewhere_preserved':True,
 'proposed_unaffected_subset':{'text_cells':158,'format_fields':1,'held_orphan_row_targets':5,'preserves_19_space_A4':True,'request_sha256':sha(P/'UNAFFECTED_158_PLUS_TOP_REQUEST_NOT_APPLIED.json'),'status':'PREPARED_NOT_APPLIED; root decision and fresh guarded rebase required'},
 'score_status_formula_ID_changes_proposed':0,'external_writes':0,'supplied_scientific_programs_executed':0})
print((P/'INDEPENDENT_AUDIT.json').read_text())
