"""Exact non-mutating guard for158 preserved text edits plus Progress!A1 TOP.

The19-space A4 cell and five held row4 cells must stay unchanged. This module
authorizes nothing and cannot write remotely. Construct a fresh snapshot using
metadata(include_conditional_format_rules=True), then all17 grid-plan ranges
with cell_fields='*', recording start/end timestamps at the actual calls.
"""
import json,hashlib,copy,datetime
from pathlib import Path
P=Path(__file__).parent
EXPECTED={
 'REBASED_BEFORE_NATIVE_PACKED.json':'3d8aaa965838d705997e13894a2683d90f547b28d017e492a96793a37751bfcd',
 'UNAFFECTED_158_CELL_PROPOSAL_NOT_APPLIED.json':'48456c8647deb5fa90f77ce8de8b679cad1c37cd70c1e6328808b29b5c4bc056',
 'UNAFFECTED_158_PLUS_TOP_REQUEST_NOT_APPLIED.json':'e48bc7c8e54f4e1f7e7cbe22513adc27fafc1437fbf3588b6fcad0c481043560'}
def j(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def decode(v):
 if v.get('format')!='lossless-json-dag-v1':return v
 a=[]
 for t,x in v['nodes']:a.append(x if t==0 else [a[i] for i in x] if t==1 else {k:a[i] for k,i in x})
 return a[v['root']]
def flatten(s):
 out={}
 for rd in s['reads']:
  for sheet in rd['data']['sheets']:
   for g in sheet.get('data',[]):
    for rn,r in enumerate(g.get('rowData',[]),g.get('startRow',0)+1):
     for cn,c in enumerate(r.get('values',[]),g.get('startColumn',0)+1):
      k=(sheet['properties']['title'],rn,cn);assert k not in out;out[k]=c
 return out
def setup():
 for f,h in EXPECTED.items():assert sha(P/f)==h,('file identity',f)
 b=decode(j(P/'REBASED_BEFORE_NATIVE_PACKED.json'));bc=flatten(b)
 d=j(P/'UNAFFECTED_158_CELL_PROPOSAL_NOT_APPLIED.json');t={(v['sheet'],v['row'],v['column']):v for v in d}
 assert len(t)==len(d)==158 and bc[('Next cycle',4,1)]['userEnteredValue']=={'stringValue':' '*19}
 assert not any(k[0]=='Next cycle' and k[1]==4 for k in t)
 return b,bc,t
def expected(applied=None,top=False):
 b,bc,t=setup();applied=set() if applied is None else set(map(tuple,applied));assert applied<=set(t)
 out=dict(bc)
 for k in applied:
  c=copy.deepcopy(bc[k]);after=t[k]['after'];c.update(userEnteredValue={'stringValue':after},effectiveValue={'stringValue':after},formattedValue=after);out[k]=c
 if top:
  k=('Progress',1,1);assert k in applied;c=copy.deepcopy(out[k]);c['userEnteredFormat']['verticalAlignment']='TOP';c['effectiveFormat']['verticalAlignment']='TOP';out[k]=c
 return out
def compare(metadata,cells,applied=None,top=False):
 b,bc,t=setup();assert metadata==b['metadata'],'metadata drift';e=expected(applied,top)
 assert set(cells)==set(e),'coverage drift'
 bad=[k for k in e if cells[k]!=e[k]];assert not bad,('native drift',bad[:8])
 return {'status':'PASS_EXACT_REBASED_NATIVE_STATE','cells':len(e),'applied_text_cells':len(applied or []),'TOP':top,'A4_19_spaces_preserved':True,'held_five_targets_preserved':True}
def time(s):
 d=datetime.datetime.fromisoformat(s.replace('Z','+00:00'));assert d.tzinfo;return d
def full(snapshot,phase,minimum_started_at,applied_cells=None,top=None):
 s=decode(j(snapshot)) if isinstance(snapshot,(str,Path)) else snapshot;b,bc,t=setup();minimum=time(minimum_started_at)
 assert s['cell_fields']=='*' and len(s['reads'])==17 and s['grid_plan']==b['grid_plan'],'coverage plan'
 assert time(s['metadata_read_time'])>minimum,'stale metadata'
 assert [r['ranges'] for r in s['reads']]==[r['ranges'] for r in b['reads']],'range plan'
 for r in s['reads']:
  assert time(r['started_at'])>minimum and time(r['started_at'])>=time(s['metadata_read_time']),'stale cells'
  assert time(r['finished_at'])>=time(r['started_at']),'reverse timestamps'
 assert phase in ['before','partial','after']
 applied=[] if phase=='before' else list(t) if phase=='after' else applied_cells
 top=False if phase=='before' else True if phase=='after' else top
 assert applied is not None and top is not None
 return compare(s['metadata'],flatten(s),applied,top)
