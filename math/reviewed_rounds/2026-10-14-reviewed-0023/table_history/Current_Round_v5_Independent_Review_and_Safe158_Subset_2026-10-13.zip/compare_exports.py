"""Independent read-only XML comparison of authentic spreadsheet exports."""
import json,zipfile,xml.etree.ElementTree as E,hashlib,shutil
from pathlib import Path
P=Path(__file__).parent;W=P.parent
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};M='{'+NS['m']+'}';RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
def read_book(p):
 z=zipfile.ZipFile(p);st=E.fromstring(z.read('xl/styles.xml'))
 banks={n:list(st.find('m:'+n,NS)) for n in ['fonts','fills','borders','cellStyleXfs','cellXfs']};nf=st.find('m:numFmts',NS)
 fm={} if nf is None else {r.attrib['numFmtId']:r.attrib['formatCode'] for r in nf}
 def canonical(e):
  a=dict(e.attrib)
  if e.tag==M+'alignment' and a.get('readingOrder')=='0':a.pop('readingOrder')
  for k,b in [('fontId','fonts'),('fillId','fills'),('borderId','borders'),('xfId','cellStyleXfs')]:
   if k in a:a[k]=canonical(banks[b][int(a[k])])
  if a.get('numFmtId') in fm:a['numFmtId']=fm[a['numFmtId']]
  return [e.tag,sorted(a.items()),e.text or '',[canonical(c) for c in e]]
 styles=[canonical(e) for e in banks['cellXfs']]
 ss=[]
 if 'xl/sharedStrings.xml' in z.namelist():ss=[''.join(t.text or '' for t in s.iter(M+'t')) for s in E.fromstring(z.read('xl/sharedStrings.xml'))]
 rel={r.attrib['Id']:r.attrib['Target'].lstrip('/') for r in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
 vals={};structure={}
 for sh in E.fromstring(z.read('xl/workbook.xml')).find('m:sheets',NS):
  name=sh.attrib['name'];path=rel[sh.attrib[RID]];path=path if path.startswith('xl/') else 'xl/'+path;root=E.fromstring(z.read(path));v={};sty={};rh={}
  for row in root.find('m:sheetData',NS):
   rh[row.attrib['r']]=dict(row.attrib)
   for c in row:
    f=c.find('m:f',NS);e=c.find('m:v',NS);raw=None if e is None else e.text;t=c.attrib.get('t');addr=c.attrib['r']
    if f is not None:kind,value='formula',f.text
    elif t=='s':kind,value='string',ss[int(raw)]
    elif t=='inlineStr':kind,value='string',''.join(t.text or '' for t in c.iter(M+'t'))
    elif t=='b':kind,value='boolean',raw=='1'
    elif t=='e':kind,value='error',raw
    elif raw is None:kind,value='blank',''
    else:
     try:kind,value='number',float(raw)
     except ValueError:kind,value='string',raw
    if value=='':kind='blank'
    v[addr]=[kind,value];sty[addr]={'attributes':{k:a for k,a in c.attrib.items() if k not in ['r','t','s']},'resolved':styles[int(c.attrib.get('s',0))]}
  vals[name]=v;structure[name]={'sheet_attributes':{k:a for k,a in sh.attrib.items() if k!=RID},'rows':rh,'styles':sty,'other':{c.tag:E.tostring(c,encoding='unicode') for c in root if c.tag!=M+'sheetData'}}
 return vals,structure,z
fresh=W/'attachments/1eee674c-34fd-4d6c-9c9b-b34ee2c6916f/Research cycle — accepted proofs and live fusion queue — 10 October 2026.xlsx'
local=P/'FRESH_AUTHENTIC_EXPORT.xlsx';shutil.copyfile(fresh,local)
a,sa,za=read_book(local);b,sb,zb=read_book(W/'current_round_reconciliation_v5_2053/FRESH_AUTHENTIC_EXPORT.xlsx')
diff=[{'sheet':s,'cell':c,'before':b[s].get(c),'after':a[s].get(c)} for s in a for c in set(a[s])|set(b[s]) if a[s].get(c)!=b[s].get(c)]
assert diff==[{'sheet':'Next cycle','cell':'A4','before':['string','STR-Q1'],'after':['string',' '*19]}]
assert sa==sb
comments=[f for f in zb.namelist() if f.startswith('xl/comments') and f.endswith('.xml')];assert all(za.read(f)==zb.read(f) for f in comments)
r={'status':'PASS_AUTHENTIC_EXPORT_CONFIRMS_ONLY_A4_ID_DRIFT','export_sha256':hashlib.sha256(local.read_bytes()).hexdigest(),'changed_values':diff,'all_styles_row_column_dimensions_merges_and_noncells_equal':True,'comment_parts_equal':len(comments),'represented_cells':sum(len(x) for x in a.values()),'Progress_merge_preserved':'A1:C2','Progress_row_dimensions':{k:sa['Progress']['rows'][k] for k in ['1','2']},'external_writes':False}
(P/'FRESH_EXPORT_CHECK.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
