# Field-sensitive original-bank complexity at N=11

13 October 2026. Fusion of the accepted base-field obstruction and independently verified twelve-bank extension-field witness. This note separates inherited results from the new pinned-singleton corollary.

## 1. Main result and status

There is a genuine field-sensitive representation-count separation for the original bank dictionary. At the same target Fourier matrix, the same q=13, and the same requirement of one effective cross-sign node per orientation:

- every all-F23 representation needs at least fourteen actual original banks;
- an explicit representation over F23^5 uses twelve actual original banks, with orientation counts (5,1,1,5).

These are compatible bounds for different coefficient fields. They are not two bounds on an unrestricted Fourier algorithm.

The twelve-bank independent reviewer has reported arithmetic ACCEPT. Its certificate is `../review_twelve_independent_2212/RESULTS.json`; the final review packet is a separate dependency. The stronger pinned-singleton result below is an additional mathematical corollary. On 13 October 2026, the independent reviewer explicitly ACCEPTED its proof and precise scope; a separate dated review addendum is being sealed against this report. This acceptance is separate from the witness-only arithmetic verdict. The fresh local checker validates its small numerical premise independently of both historical and candidate programs.

## 2. Precisely matched model

Let K be a field extending F23. Fix N=11, q=13, and on K^11 set

    S e_t = e_(t+1 mod 11),  T e_t = q^t e_t,
    F[k,t] = q^(-kt),  0 <= k,t <= 10.

An original legal bank, with epsilon,delta in {+1,-1}, is

    B_(epsilon,delta)(alpha,beta;w)
      = (1/11) sum_(j=0)^10 w_j
        (I - alpha S^epsilon - beta q^(epsilon delta j) T^delta)^(-1),

where alpha,beta,w_0,...,w_10 belong to K and

    Delta = 1 - alpha^11 - beta^11 != 0.

No generator replacement, pre/post map, border limit, infinite alpha, derivative atom, or new trace-bank primitive is allowed.

Within one orientation, banks with equal alpha have their sector amplitudes added. A node is effective if the resulting vector of sector contributions is nonzero. This is bookkeeping for necessity; it does not alter the count of actual summands. Repeated nodes do not create confluent or derivative atoms. A bank with alpha=0 remains legal when Delta is nonzero, but contributes nothing to the strictly positive-exponent windows used below.

Let b(K) be the minimum number of actual banks representing F subject to exactly one effective alpha node in each cross-sign orientation (-,+) and (+,-), with no further restriction on the locations of those two nodes. If no representation exists, set the minimum to infinity. The accepted base theorem and the witness give

    b(F23) >= 14,                  b(F23^5) <= 12.

The first minimum permits every legal alpha,beta,w in F23, not only beta=1. The witness uses the permitted subfamily beta=1, with both cross-sign nodes equal to 4. The second minimum permits extension-valued singleton nodes, but its upper bound needs only the base-field choice 4. Thus the theorem compares the same definition of b as the field varies; the different scopes are not silently conflated.

The accepted base theorem is stronger in q: it applies to all ten primitive eleventh roots in F23. The comparison theorem specializes to q=13 because this is what the verified witness establishes. It must not advertise an extension-field witness for every primitive q without additional work.

## 3. New sharper statement with pinned singleton nodes

Let b_4(K) be the same minimum, with both effective cross-sign singleton nodes required to be alpha=4. Other alpha nodes, every beta and every raw weight may lie anywhere in K, subject only to legality.

**Pinned-singleton field theorem.** For every extension K/F23:

1. b_4(K) >= 12.
2. If K contains a copy of F23^5 over F23, then b_4(K)=12.
3. If K does not contain F23^5, then b_4(K)>=14.

In particular, for every positive integer d,

    b_4(F23^d) = 12       if 5 divides d,
    b_4(F23^d) >= 14      if 5 does not divide d.

This is exact twelve-bank optimality only for the pinned architecture. No claim of fourteen-bank attainment is made in the second line. No claim that the unrestricted-singleton minimum b(F23^5) is exactly twelve is made.

The only numerical data required for the lower-bound part of this pinned theorem are the single six-by-six certificate in section 4. It does not require repeating the all-220 census.

## 4. Transparent lower-bound certificate and proof

Write G_(epsilon,delta)(a,b) for the original Weyl coefficient factor obtained from

    r=[epsilon a]_11, ell=[delta b]_11,
    D(r,ell)=q^(epsilon delta ell)D(r-1,ell)+D(r,ell-1), D(0,0)=1,

with G=D(r,ell) when r+ell<=10 and G=0 otherwise. This follows directly by right-multiplication in the algebra with TS=qST. The identity

    (alpha S^epsilon+beta q^(epsilon delta j)T^delta)^11
       = (alpha^11+beta^11)I

gives the original legal inverse by a finite geometric series. A bank's coefficients have common alpha powers with sector-dependent amplitudes. This derivation allows beta=0 and arbitrary legal beta; no division by beta is needed for the lower bound.

Normalize the target coefficients by their common nonzero scalar C=18. They are q^(3(a+b)^2). At (a,b)=(11-b,b), b=1,2, only (-,+) is supported. If its single effective node is 4, its normalized amplitudes are forced to be

    T_b = 1/[4^b G_-+(11-b,b)],
    T_1=22, T_2=20.

For b<=a<=10-b, both negative-delta orientations vanish. The forced residual moments are therefore

    v_b(a) = [q^(3(a+b)^2) - T_b 4^(11-a) G_-+(a,b)]/G_++(a,b)
           = sum_(x in X) A_(b,x) x^a,

where X is the set of distinct nonzero effective ++ nodes. All displayed denominators are nonzero. The two moment sequences are

    b=1, a=1,...,9: 19,4,20,14,20,3,14,16,8;
    b=2, a=2,...,8: 21,15,14,11,13,22,19.

The four length-six windows from the first sequence and two from the second form

    M = [19  4 20 14 20  3]
        [ 4 20 14 20  3 14]
        [20 14 20  3 14 16]
        [14 20  3 14 16  8]
        [21 15 14 11 13 22]
        [15 14 11 13 22 19].

Over F23,

    M (6,4,18,1,8,1)^T = 0,

and the determinant of the first five rows and columns is 3. Thus M has rank five and its entire kernel, over every extension K, is generated by the coefficient vector of

    g(t)=t^5+8t^4+t^3+18t^2+4t+6.

The polynomial is irreducible over F23. Our fresh checker independently divides by all 23 monic linear and all 529 monic quadratic polynomials and finds no divisor. Every reducible quintic has a factor of degree at most two, so this is an exact irreducibility proof. Irreducibility over a finite field also implies separability. Its constant term is nonzero.

Suppose m=|X|<=5 and define the monic ordinary-node annihilator

    h(t)=product_(x in X)(t-x),       p(t)=t^(5-m)h(t).

For every one of the six windows,

    sum_(k=0)^5 p_k v_b(a+k)
      = sum_(x in X) A_(b,x) x^a p(x)=0.

Therefore p is a monic degree-five element of ker(M), hence p=g. Since g(0)=6!=0, m cannot be less than five. If m=5, then g=h and g must split into five distinct nonzero linear factors over K.

Consequently every such representation has at least five distinct nonzero ++ nodes, and at least six if g does not split over K. This remains true if extra zero nodes or repeated original banks occur: they cannot lower the required number of distinct nonzero nodes.

Let J e_t=e_(-t). Conjugation by J exchanges S with S^(-1) and T with T^(-1), and J F J^(-1)=F. It exchanges ++ with -- and -+ with +-, preserves alpha,beta and the original phase convention, and introduces no pre/post map into the claimed representation. Apply the same necessity argument to the reflected identity. The pinned (+,-) node 4 forces the identical bound for --. The two cross-sign orientations contribute at least one actual bank each.

This proves a total lower bound 5+1+1+5=12 over all K, and 6+1+1+6=14 whenever g fails to split.

Finally, an irreducible degree-five polynomial over F23 splits in F23^5. If it has any root in an extension K, the root generates a degree-five finite subfield, isomorphic over F23 to F23^5; all five Frobenius-conjugate roots then lie there. Thus splitting is equivalent to K containing F23^5. For K=F23^d this is equivalent to 5 dividing d.

The verified twelve-bank witness uses exactly those roots and both singleton nodes 4. It embeds in every K containing F23^5, proving the upper bound twelve and completing the pinned theorem.

## 5. Upper-bound proof obligations and what was verified

The witness is not deduced from singularity of M or from splitting g alone. Those give necessary edge conditions, not full four-orientation compatibility. The independently reviewed witness supplies the missing sufficiency:

- the field is F23[z]/(g), with all five distinct roots z^(23^i), 0<=i<5;
- both same-sign groups use those five roots, both cross-sign groups use alpha=4, and beta=1 for all twelve banks;
- all legal denominators are -alpha^11 and are nonzero;
- all eleven complete coefficient row systems are compatible;
- all 132 raw phase weights are given explicitly;
- all 132 literal 11-by-11 resolvent branches are inverted over the extension field, with both inverse products checked;
- every one of the twelve bank matrices is nonzero and their sum equals all 121 entries of the unmodified target F.

The independent review is the dependency for this full witness, not an execution of the candidate's scientific program. This fusion worker executed only its own newly written `fresh_scope_gate.py`, which reconstructs the fixed gate and checks its rank, kernel and irreducibility. Historical and candidate source programs were not executed or imported.

## 6. Restriction audit and forbidden inferences

**Restrictions that agree.** Same N=11; same q=13 for the comparison; same literal S,T,F; same four sign orientations; same original 1/11 normalization; same legal denominator condition; same ordinary finite-alpha nodes; same exactly-one-effective-node condition in each cross-sign orientation; same count of actual original banks. The field of allowed scalar parameters is the intentional change.

**Additional witness restrictions.** Beta=1, singleton alphas both 4, equal five-element same-sign node sets, and Frobenius-compatible amplitudes are construction choices. They are not restrictions imposed on the all-F23 lower bound. The pinned theorem restricts only the two singleton alphas, not beta or same-sign equality.

**Original versus effective count.** The lower bound first counts necessary distinct nonzero effective nodes and hence bounds the number of actual banks. The upper bound explicitly uses twelve distinct orientation/alpha pairs and twelve nonzero matrices. Merging notation cannot turn twelve original banks into a different number without rechecking the permitted dictionary.

**Unrestricted allocations.** The inequalities for b(K) do not imply an unrestricted lower bound of fourteen over F23. Representations with two or more effective cross-sign nodes, or other orientation allocations, have not been excluded. They could in principle use fewer than twelve banks over both fields. Removing the singleton condition changes the problem.

**Extension-valued singleton nodes.** The gate M above is for singleton alpha=4. The accepted all-220 census varies q and y only over the specified F23 values. It cannot exclude smaller representations with extension-valued singleton nodes. Accordingly b_4(F23^5)=12 is not b(F23^5)=12.

**No base-field attainment.** A lower bound of fourteen is not a fourteen-bank F23 construction. A historical characteristic-zero fourteen-bank witness or an extension-field witness does not supply one.

**No characteristic-zero transfer.** F23^5 does not embed in characteristic zero. A polynomial system can have a mod-23 solution without a characteristic-zero solution, and a vanishing determinant modulo 23 need not vanish before reduction. A lift would need a separate exact algebraic construction or a valid lifting argument with its hypotheses checked. The current result neither improves nor refutes a characteristic-zero optimum.

**No descent by cancellation.** The sum of the conjugate banks is base-field valued, but individual same-sign nodes are not. Taking a field trace does not automatically replace a Frobenius orbit by one bank of the original dictionary. Such a replacement would require proof and could change the grammar.

**No arithmetic speed conclusion.** Twelve versus fourteen measures allowed summands over different scalar fields. Extension arithmetic, root construction, raw phase weights, preprocessing and resolvent evaluation all have costs. The 132 branch inversions are a finite verification workload, not a runtime bound for a Fourier algorithm. No asymptotic statement follows from fixed N=11.

## 7. Primary-literature context and publication assessment

The relevant classical mechanism is that recurrence rank and field-rational ordinary-node decomposability are different questions. Hankel kernels recover annihilating polynomials; a legal node decomposition also needs the required distinct roots in the chosen field. Kunis, Roemer and von der Ohe formalize the relation between kernels, vanishing ideals and support in Sections 1-4 of [Learning algebraic decompositions using Prony structures](https://arxiv.org/pdf/1907.01547). This explains the method; it does not settle the present coupled bank problem.

Field-dependent decomposition length is established prior art. Reznick's [On the length of binary forms](https://reznick.web.illinois.edu/hdfv3.pdf), especially Example 1.1 and Theorem 2.1/Corollary 2.2, discusses changing length when the ground field changes and the role of a kernel polynomial splitting into distinct factors. Reznick and Tokcan's [Binary forms with three different relative ranks](https://arxiv.org/pdf/1608.08560) supplies further multi-field examples. Their binary Waring results are characteristic-zero theorems for another dictionary; they are contextual analogies, not substitutes for the finite-field proof here.

Single-orientation shared-node geometry is also classical: see Sturmfels and Sullivant, [Combinatorial secant varieties](https://arxiv.org/pdf/math/0506223), Section 5, and Comon, Qi and Usevich, [Identifiability of an X-rank decomposition of polynomial maps](https://arxiv.org/pdf/1603.01566), Section 2.4. What is application-specific here is the exact four-orientation resolvent grammar, the coupled Fourier target, and a fully checked field-sensitive witness under explicit architectural restrictions.

Assessment: a credible finite algebraic example and a useful correction to any field-uniform bank-count claim. The pinned extension-degree theorem is a cleaner contribution than merely announcing twelve instead of fourteen. It deserves incorporation into a careful manuscript on the dictionary. Alone, one fixed N and a deliberately constrained architecture are a modest publication result. A broader theorem about which extension degrees change the count, or a family of such separations at growing N, would materially strengthen it. No historical novelty or world-first claim is supported by this limited primary-source search.

## 8. Next task and stopping condition

**Next-task priority: 87/100.** Settle whether the F23 lower bound fourteen is attained with both singleton nodes 4. This has a precise payoff: an exact 14-versus-12 field comparison, or a stronger certified base-field obstruction. Preserve the original legal grammar and do not assume a six-node edge recurrence is sufficient for the full target.

The pinned-theorem proof review now has an explicit independent ACCEPT verdict. The proposed attainment stage should stop on a complete literal legal witness, or a stated exhaustive/symbolic impossibility result for the declared class; a failed heuristic search is not a lower bound.

Longer-term extension: unpin the cross-sign nodes and determine whether the minimal extension degree for any twelve-bank singleton-architecture representation is less than five. This requires new gates or exact elimination, not a reinterpretation of the present example. Resolving unrestricted allocations is broader still.
