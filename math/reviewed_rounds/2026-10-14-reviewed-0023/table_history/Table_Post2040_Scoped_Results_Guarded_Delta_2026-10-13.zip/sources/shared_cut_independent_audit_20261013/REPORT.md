# Cost-aware fusion test: shared-cut rational QTGF obstruction

Date: 2026-10-13 UTC. New local mathematical work and newly authored exact controls only. No historical program executed; no repository, Sheet, or other external write.

## Decision

**A valid restricted fusion exists, but it requires shared cuts.** The additive fragmentation result does not extend to arbitrary products. The useful compatible replacement combines the classical product cut-rank inequality with the fragmentation report's flat-unitary energy argument.

For an aligned rational QTGF word on N=m² coordinates, the result is

    ||U-T||_F²/N >= [1 - 1/k - k d/m]_+,
    ||U-T||_2²   >= [1 - 1/k - k d/m]_+,

for every integer divisor k of m with k>=2. Here d is the number of rational stages, and all effective stage denominators must have cut rank at most m on the SAME k row-slab cuts. The familiar directed torus stencil, its coordinate swap/reversals, and arbitrary diagonal gauges have this property. Arbitrary independently routed interior permutations need not.

Consequently an exact flat unitary, including normalized Fourier, requires d>=ceil(m/4), using k=2. More generally, d=o(m) forces the error lower bound toward one. Thus the constant-depth aligned rational QTGF proposal is excluded for all coefficient choices, although the broader arbitrarily routed rational architecture is not excluded.

This is a transparent application of established rank algebra and low-rank approximation, not a new matrix principle or unrestricted FFT lower bound. It is stronger than checking isolated fixed coefficient words inside this restricted aligned grammar. Its novelty as an application is unestablished and unlikely to carry a standalone paper by itself.

## 1. General shared-partition composition lemma

Let U be an N-by-N complex flat unitary, so |U_ij|=1/sqrt(N). Let V_1,...,V_k partition the N coordinate labels. Let Q_1,...,Q_d be invertible and define

    S_t = a_t I + b_t Q_t^(-1),
    W = D_d S_d D_(d-1) ... S_1 D_0,
    T = L W R.

The D_t are arbitrary diagonal matrices. Each of L,R has support contained in a permutation matrix, with arbitrary independent permutations and arbitrary coefficients, including zeros. No conditioning or coefficient-size restriction is used. Put

    rho_(t,j) = rank Q_t[V_j,V_j^c],
    K_j = sum_(t=1)^d rho_(t,j).

Then

    ||U-T||_F²/N >= max(0,
        1 - sum_j |V_j|²/N² - sum_j K_j/N),

and the same right-hand side bounds ||U-T||_2² from below.

This form does not need a separator theorem. A separator or stencil can supply the rho bounds, but the common coordinate cuts must actually exist. One may retain the exact rank budgets rather than assuming all of them equal.

### Proof

For an invertible matrix Q and a complementary cut V,V^c, the classical identity is

    rank Q^(-1)[V,V^c] = rank Q[V,V^c].

No invertibility of principal diagonal blocks is required. For completeness, write E for the coordinate subspace on V^c. The map x -> Qx bijects {x in E: Qx in E} with {y in E: Q^(-1)y in E}. These are the kernels of the two cut matrices, both having |V^c| columns. Their ranks are equal.

For any A,B on the same coordinate split,

    (AB)[V,V^c] = A[V,V]B[V,V^c] + A[V,V^c]B[V^c,V^c],

so cut rank of AB is at most the sum of the two cut ranks. A diagonal factor has cut rank zero; the identity summand in S_t has cut rank zero. Induction gives rank W[V_j,V_j^c]<=K_j.

Complete the two endpoint supports to permutations. On output rows corresponding to V_j and output columns corresponding to V_j^c, T is a row/column scaling of W[V_j,V_j^c]. Its rank is at most K_j. These k rectangles are entry-disjoint because their output row sets are disjoint, even though their column sets overlap. Independent endpoint permutations do not change their areas. Their total area is

    sum_j |V_j|(N-|V_j|) = N² - sum_j |V_j|².

Every coordinate rectangle B of a flat unitary has squared Frobenius norm equal to its area/N and operator norm at most one. An approximation of rank at most K captures at most K units of squared Frobenius energy, by the classical singular-value-tail bound (or orthogonal projection onto its column space). Hence the squared error on rectangle j is at least |V_j|(N-|V_j|)/N-K_j. Sum these disjoint errors, divide by N, and clip at zero. Finally ||E||_F²<=N||E||_2² supplies the operator claim.

This proof controls the rank of the actual product and then its actual error. Cancellation, arbitrarily large diagonal entries, and singular endpoint masks do not create a gap.

## 2. Rational QTGF specialization

Let m=2^r>=2 and N=m²; label coordinates (a,c) in Z_m². A standard stage denominator has

    (Q_t y)[a,c] = y[a,c]
                  - alpha_t[a] y[a-1,c]
                  - beta_t q^a y[a,c-1],

where q is a primitive m-th root, and the denominator is invertible. The cited source uses sufficient solver guards beta_t^m!=1 and 1-beta_t^m-product(alpha_t)!=0. We keep those guards when discussing that executor. The rank argument itself only requires invertibility.

The rational stage is

    S_t = (I+C_t)(I-C_t)^(-1) = 2 Q_t^(-1)-I.

Partition the a labels into k consecutive cyclic intervals of length m/k, and let V_j contain each interval times all m c labels. Each V_j has N/k coordinates. For Q_t[V_j,V_j^c], within-row c moves do not cross the cut. The directed a-predecessor move crosses only at the initial a row of the interval, so there are at most m nonzero cut rows. Therefore rho_(t,j)<=m.

The same conclusion holds for a reversed a direction. Swapping the a and c axes leaves one shift parallel to the slab and the other crossing a single boundary. Thus coordinate swaps, independent axis reversals, and translations of the directed stencil are permitted, as are arbitrary diagonal gauges. The proof uses support, so zeros only improve the rank bound. More general routing is permitted only when its effective denominator passes the same shared-cut rank contract.

Internal monomial interleavings can be pushed to an outer permutation while conjugating later/earlier denominators and reindexing diagonal factors. The condition applies to those EFFECTIVE conjugated denominators. It must not be checked only on each stage before its routing.

Applying the lemma with K_j<=dm gives the displayed bound.

### Exact and approximate consequences

For k=2 and T=U, 0>=1/2-2d/m, hence d>=ceil(m/4). The claim concerns the normalized Fourier matrix; an unnormalized Fourier identity can be normalized by an allowed outer scalar.

For d=o(m), choose a dyadic divisor k approaching sqrt(m/d). For positive d with m/d sufficiently large, take the largest power of two no greater than sqrt(m/d). Then

    1/k <= 2 sqrt(d/m),
    k d/m <= sqrt(d/m),

and the lower bound is at least [1-3 sqrt(d/m)]_+. Thus both errors have liminf at least one. The best achievable error tends exactly to one if zero endpoint masks are allowed, since T=0 is then legal; with invertible endpoints only, arbitrarily small scalar rescaling gives the same infimum. No finite-N optimum or optimal convergence rate is claimed.

For any fixed eta<1, choose a fixed dyadic k>1/(1-eta²). An error at most eta in either norm forces

    d >= (m/k)(1-eta²-1/k) = Omega_eta(m).

This is a model-representation depth statement, not an arithmetic circuit lower bound.

## 3. Paid cost interpretation

The exact-search source reports 14N+3m field operations per application of its literal rational primitive, and a prepared d-stage upper ledger

    (15d+1)N + 3dm

including d+1 diagonal scalings. Root acquisition, root/routing validation, preparation, dense discovery, and certification have separate charges. None are removed by the present theorem.

The depth bound implies that a stage-by-stage evaluator that actually pays Theta(N) work for each full stage requires Omega(N^(3/2)) application work in this ALIGNED subclass. For the literal fixed-count primitive, the primitive calls alone charge at least ceil(m/4)(14N+3m); any diagonal/preparation costs are additional.

It would be incorrect to infer a lower bound merely by substituting a depth lower bound into an arbitrary algorithmic UPPER bound. The work conclusion here expressly assumes the stated full-stage execution contract. A shared or simplified alternative evaluator is not analyzed. Parameter choices that permit skipping work require their own cost ledger. No conclusion is drawn about unrestricted Fourier work.

This closes the aligned family as a route to the desired sub-N log N algorithm. It does not produce a Fourier factorization, improve the claimed QTGF primitive, or invalidate the source's broader arbitrary-routing search.

## 4. Countercontrol A: arbitrary routing breaks the m-rank budget

Take alpha[a]=0 and beta with beta^m!=1 (and hence the actual source solver guards). Each stage consists of m independent c cycles. Reindex the coordinates by

    pi(a,c) = (c mod 2)(N/2) + a(m/2) + floor(c/2).

Thus even c labels occupy the first half of all coordinates and odd c labels the second half. Every predecessor step in c crosses the half-cut. In the conjugated denominator's first-half-to-second-half cut there is exactly one nonzero in every row and every column: it is a scaled permutation matrix of rank N/2. Inverse cut-rank invariance gives the same rank for S=2Q^(-1)-I.

For m>2, N/2>m. This is a genuine allowed QTGF routing, not a numerical fit. It invalidates the proposed common m-cut budget for the arbitrary-routing architecture. It is not a Fourier construction and does not prove that NO other shared partition exists.

## 5. Countercontrol B: two q=1 branches do not retain bounded separators

On an open m-by-m grid define H to shift one step horizontally where possible and V one step vertically where possible. Set

    Q_h=I+H, Q_v=I+V,
    T=Q_h^(-1)Q_v^(-1).

The shifts are nilpotent, so both denominators are invertible. Each symmetric bipartite support lift is a disjoint union of paths. Such a graph has a half-component separator of size at most one for every nonnegative weighting: if one component is heavier than half of the total, delete a weighted median in that path; otherwise no deletion is needed.

But the only denominator of the bare inverse T is

    Q_* = T^(-1) = Q_v Q_h = I+H+V+VH.

Its lift contains identity edges and every horizontal/vertical grid adjacency, with no coefficient cancellation. Any deleted set of s lift vertices damages at most s grid coordinates. At most s grid rows and s grid columns contain damaged coordinates. The union of entirely undamaged rows and entirely undamaged columns is connected and has at least m²-s² coordinates. If s<m/sqrt(2), both an undamaged row and column exist, and this connected union lifts through identity and grid edges to a component with at least 2(m²-s²)>m² vertices. It exceeds half the lift's original 2m² vertices.

Thus even the UNWEIGHTED half-component separator budget of Q_* is at least ceil(m/sqrt(2)). There can be no constant-q closure for products of two such inverse branches. Independent invertible monomial endpoint changes only relabel and scale the support lift, so they do not repair this one-branch closure claim.

This disproves the needed closure premise, not every possible product obstruction. It also shows why a denominator's sparse row degree alone cannot stand in for a bounded separator budget.

## 6. Prior art and local duplication limits

Fresh primary-source inspection positively matched the two algebraic steps:

- Chandrasekaran, Epperly and Govindarajan, *Graph-Induced Rank Structures and their Representations*, Proposition 2.1 (printed p.5) gives inverse cut-rank equality. Proposition 2.3 (printed pp.7-8) gives addition and PRODUCT rank budgets on a common graph, using the same block multiplication argument. This directly covers the composition principle. https://arxiv.org/pdf/1911.05858v3
- Govindarajan, Chandrasekaran and Dewilde, *Tree Quasi-Separable Matrices*, Propositions 4.6-4.8 (arXiv v2 printed pp.14-15) give compatible-tree sum/product/inverse rank-profile algebra. This is another positive antecedent, not an independently routed closure. https://arxiv.org/pdf/2402.13381v2
- Li and Strang, *An elementary proof of Mirsky's low rank approximation theorem*, Theorem 1 (pp.1-2), supplies the classical rectangular low-rank error tail. https://cklixx.people.wm.edu/uinorm-note.pdf
- De Wolf, *Lower Bounds on Matrix Rigidity via a Quantum Argument*, Theorem 1 (credited to Lokam, printed p.5), gives the corresponding flat-Hadamard submatrix rank/area lower bound. https://homepages.cwi.nl/~rdewolf/publ/qc/qr-icalp06.pdf

The exact-search source already flags Phase 53 translated/affine Green products as having common low-cut obstructions. Its full original theorem was not recovered/read in this pass. A current local HERO0 Phase26 source record also describes a shared-order near-unit error floor and a separate common-bipartition two-stage obstruction. The supplied fragmentation prior-art review documents earlier local common-refinement and disjoint-energy methods. Therefore no claim of first local use of products, shared cuts, disjoint energy, or a limit-one obstruction is defensible.

Two narrow additional web search queries ('quantum torus Fourier rank resolvent' and 'Fourier quasiseparable product rank lower bound') did not yield a theorem-level exact match to this QTGF specialization. This is a bounded nonmatch and is not evidence of global priority. The positive GIRS match already makes the key principle classical.

## 7. Fresh controls and limitations

`fresh_controls.py` is entirely newly authored standard-library code. It imports no historical scientific code.

PASS:

- 48 exact finite-field rational-stage word cases, at N=4,16,64 and depths 1-4.
- 352 exact cut checks, with genuinely nonzero q-torus direction coefficients, variable alpha, arbitrary nonzero diagonal interleavings, coordinate swaps/reversals, inverse-rank equality, and product rank growth.
- Six exact rational Frobenius-error controls at N=16,64 and depths 1-3, using genuine beta=0 QTGF stages, independently permuted endpoints, and optimal scalar fitting to normalized Hadamard targets. All approximants are nonzero; one universal bound is positive (1/4), the others are intentionally small-size/vacuous cases.
- Three arbitrary-routing checks: half-cut ranks 2,8,32 for m=2,4,8. The m=4 and m=8 cases strictly violate the m-rank premise.
- 710 exhaustive deleted-vertex checks over the two-factor grid closure counterexample at m=2,3,4, plus exact path-graph checks on both factors. Every deletion below the proved threshold fails half balance.

Finite-field checks concern algebraic ranks, not complex norm inequalities. The norm controls use real rational degenerations, not nonzero complex q phases. The written proof supplies the full complex quantifiers; these controls corroborate it and probe boundaries. No floating-point SVD was used. This new result has not received a separate independent mathematical audit.

## 8. Priority, publishability, and stopping gate

Recommended NEXT-WORK priority: **44/100**, for one bounded independent audit plus local-antecedent reconciliation, followed by adding a shared-cut filter to future QTGF search specifications if the audit passes. This is not a correctness, novelty, or theorem-quality probability.

Rubric: mathematical/decision consequence 10/20; readiness 16/20; tractability of a decisive next check 14/20; extra reuse beyond known common-cut machinery 3/20; demonstrated algorithmic value 1/20.

Publication assessment: useful as a clearly scoped proposition/counterexample section in a rational-QTGF or architecture-obstruction report; insufficient current evidence for a standalone publishable discovery. It closes a natural aligned parameter family uniformly, but the main proof mechanism is explicitly prior art and broader local duplication remains unresolved.

Next gate: independently audit the same-cut product rank accounting, independent endpoint routing, one-boundary torus stencil count, and the exact paid-stage work qualification; read the original Phase53/Phase26 claims before any novelty promotion. Stop once this classification is settled. Do not spend another parameter grid on the aligned constant-depth family. Any next arbitrary-routing work must first produce an actual common-cut certificate or a different invariant, rather than assuming low separators survive products.
