# Phase 53 — Simultaneous-cut obstructions for multistage translated Green networks

**Date:** 11 October 2026  
**Status:** Exact restricted-family theorems, independent two-field audits. **No sub-`N log N` FFT demonstrated.**

## Abstract

Phase 52 proved a single-layer obstruction for sums of weighted Hamiltonian-cycle resolvents. We now give an obstruction which also applies to **noncommuting products of sums** of independently weighted resolvents, including arbitrary nonzero diagonal interstages and affine coordinate shuffles. Its restriction is **graph topology**: the underlying Hamiltonian cycles must be translations `x -> x+s` on `Z/pZ`, possibly with different shifts at different stages. Gains on every graph edge can vary independently and need not have unit modulus. The argument combines the exact off-cut rank of a Hamiltonian Green resolvent with a simultaneous Dirichlet approximation and Fourier's full-minor property at prime length. It produces explicit combinatorial cut witnesses and an operator-norm approximation barrier.

The individual principles (Dirichlet's theorem, matrix inverse nullity, Fourier prime full-spark) are classical. Their combination here is a **project-specific result**; external novelty and publication worth are **not established**.

## 53.1 Circuit and notation

Let `p>=3` be prime. For `s in (Z/pZ)^*`, let `W_{s,g}` denote the weighted cyclic shift

\[
 W_{s,g} e_x = g(x)e_{x+s},\qquad g(x)\in\mathbb C^*.
\]

Translation by nonzero `s` is one directed Hamiltonian `p`-cycle. Suppose its holonomy `h=prod_x g(x)` differs from 1, so the Green operator

\[G_{s,g}=(I-W_{s,g})^{-1}\]

exists. A **Green-sum stage** is a finite sum of such operators with arbitrary complex scalar coefficients; each summand has its own step and gains. A network is a finite product of these stages separated by arbitrary **invertible diagonal** matrices. There may also be **affine coordinate permutations** `x -> ax+b` (`a != 0` in the prime field) and diagonal masks between stages, and arbitrary invertible monomial matrices at the two external ends.

Conjugating a translated weighted shift by an affine coordinate permutation sends its step `s` to `as` and relabels its edge gains. Conjugating by a diagonal changes edge gains without changing the step. Pushing all intermediate affine monomial operators to one outer end therefore reduces the general allowed architecture to a product of Green-sum stages and diagonal masks, with a **transported** multiset of nonzero translation steps. Below, `T` is the total number of Green summands across *all* stages (counting repetitions) and `t<=T` is the number of distinct transported steps.

Unrestricted (non-affine) internal permutations can produce nontranslation Hamiltonian cycles and are **NOT** covered; see the negative control in §53.8.

## 53.2 Lemma — Exactly one independent channel per crossing

For any nonempty proper subset `R` of vertices, set `C = (Z/pZ)\\R`. For a Hamiltonian weighted shift `W` with its unique `p`-cycle, the complementary off-diagonal block of its Green inverse satisfies

\[
\boxed{\operatorname{rank}\bigl(G[R,C]\bigr)
 =\operatorname{rank}\bigl((I-W)[R,C]\bigr)
 = \#\{x\in C:\pi(x)\in R\},}
\]

where `pi(x)` is the vertex following `x` on the Hamiltonian cycle. **This is equality**, not merely an upper bound; it holds for *every* choice of nonzero complex gains as long as `I-W` is invertible.

**Proof.** Put `A=I-W`, in blocks indexed by `R,C`. The induced graph on the proper subset `C` consists of directed paths: no cycle can lie entirely in `C` because `W` is one Hamiltonian cycle. Hence `A[C,C]` is triangularizable with diagonal 1 and is invertible. Since `A` is invertible, its Schur complement `H=A[R,R]-A[R,C]A[C,C]^{-1}A[C,R]` is invertible. The inverse-block formula gives

\[G[R,C]=-H^{-1}A[R,C]A[C,C]^{-1}.\]

Multiplication by two invertible square matrices preserves rank, giving `rank G[R,C]=rank A[R,C]`. The off-diagonal block of `A` is a weighted partial permutation with one nonzero for each crossing edge `C->R`; its distinct nonzeros occupy distinct rows and columns. Its rank is exactly the number of these edges. QED. This is also a special case of the classical matrix nullity theorem.

## 53.3 Lemma — A single cut makes all translated cycles nearly local

Let `s_1,...,s_t` be any distinct nonzero elements of `Z/pZ`. Define

\[Q=\left\lfloor (p-1)^{1/t}\right\rfloor\quad\text{(integer floor, computed exactly)}.\]

There exists a nonzero `k mod p` and signed representatives `delta_j` of `k s_j mod p` such that

\[\boxed{|\delta_j|<p/Q\qquad (j=1,\ldots,t).}\]

When `Q=1` the inequality is trivial. For `Q>=2`, partition `[0,1)^t` into `Q^t` boxes of side `1/Q` and consider the `Q^t+1` points `((i s_1 mod p)/p, ..., (i s_t mod p)/p)` for `i=0,...,Q^t`. Two lie in the same box. Their index difference `k` lies in `[1,Q^t] subset [1,p-1]`; subtracting their coordinates proves that every `k s_j/p` is within `1/Q` of an integer. Since `p` is prime, `x -> kx mod p` is a permutation.

Let `m=(p-1)/2` and

\[R=\{x\in\mathbb Z/p\mathbb Z : 0\le kx\bmod p<m\},\quad C=R^c.\]

In the reindexed coordinate, the translation by `s_j` becomes translation by `delta_j`. Directly counting entries into an interval of length `m` proves

\[\boxed{\#\{x\in C:x+s_j\in R\}=|\delta_j|<p/Q.}\]

The construction is **deterministic in O(pt)** operations for a fixed step set, using a hash table of boxes. For finite sizes we can additionally minimize `sum_s multiplicity(s)*|delta_s|` by examining the `p-1` nonzero characters, also in `O(pT)` integer work. Optimization is not used to justify the all-length theorem.

## 53.4 Theorem — Multistage rank obstruction, including affine interstages

For the network class in §53.1 with total term count `T`, let `k,R,C` be constructed by §53.3 from the transported set of `t` distinct steps. Let

\[c=\sum_{\text{all Green summands }\ell}|\delta_{s_\ell}|.\]

Then the selected block of the core circuit has

\[\boxed{\operatorname{rank} M[R,C]\le \min(m,c)<Tp/Q.}\tag{53.1}\]

The inequality is preserved under all intervening invertible diagonal masks. If external row/column permutations and scalings are included, **some** `m x (p-m)` block of the resulting matrix has the same rank bound, even though its row/column index sets need not be complementary.

**Proof.** The exact single-Green rank is `|delta_s|` by Lemmas 53.2–53.3. A sum's off-cut rank is at most the sum of its terms' off-cut ranks. For any two conformal square matrices `A,B`,

\[(AB)[R,C]=A[R,R]B[R,C]+A[R,C]B[C,C],\]

so `rank(AB)[R,C] <= rank A[R,C]+rank B[R,C]`. Diagonal masks have zero off-cut blocks. Induction across stages yields the total rank bound `c`. Each `|delta| <p/Q`, so `c<Tp/Q`. External invertible diagonal masks preserve ranks and external permutations simply transport the chosen rows and columns. QED.

Let `F_p` be the complex unnormalized `p`-point DFT. Chebotarëv's prime-order Fourier minor theorem states that **every square minor of `F_p` is nonzero**. Thus any `m x (p-m)` submatrix of `F_p` has rank `m`. Equality with a circuit above requires `c>=m`. Consequently

\[\boxed{T>\frac{p-1}{2p}\left\lfloor (p-1)^{1/t}\right\rfloor.}\tag{53.2}\]

This covers **products of sums** of noncommuting, independently weighted Greens and permitted affine shuffles; it does *not* cover arbitrary Hamiltonian cycle permutations or general arithmetic circuits.

**Asymptotic corollaries:** for **fixed `t`**, `T=Omega(p^{1/t})`. When `t` may grow but `t<=T`, we also obtain

\[\boxed{T\log(4T)>\log(p-1),\quad\text{hence}\quad T=\Omega(\log p/\log\log p).}\tag{53.3}\]

For the explicit bound, if exact Fourier equality holds then (53.2) gives `Q < 2p T/(p-1) <= 3T` for `p>=3`. Since `p-1 < (Q+1)^t <=(4T)^T`, taking logarithms proves (53.3).

Online work: an unfused executor that charges `Theta(p)` operations for every Green application costs `Theta(pT)`, which in this model grows at least like `p^{1+1/t}` for fixed `t`. **This is not a general algebraic circuit lower bound**: a fused implementation need not run the Green solves independently.

## 53.5 Theorem — Quantitative Fourier approximation barrier

Let `U_p=F_p/sqrt(p)` (unitary), and let an allowed candidate network, including any external invertible monomial masks, have a selected `m x (p-m)` block of rank at most an integer `r<m`. Then

\[\boxed{\|U_p-M\|_2\ge
\sqrt{\frac{m(p-m)/p-r}{m-r}}\quad
\text{when }r<m(p-m)/p.}\tag{53.4}\]

Otherwise the elementary bound gives zero and we make no nontrivial approximation claim.

**Proof.** The corresponding block `B` of `U_p` (possibly on independently permuted row and column sets) has `||B||_F^2=m(p-m)/p`, since every Fourier entry has squared modulus `1/p`. Also `||B||_2<=1` since it is a restriction of a unitary matrix. Let its singular values be `sigma_1 >=...>=sigma_m`. Then

\[m(p-m)/p=\sum_{j=1}^m\sigma_j^2
\le r+(m-r)\sigma_{r+1}^2,\]

so `sigma_{r+1}^2 >= [m(p-m)/p-r]/(m-r)`. Every rank-`r` approximation to `B` has spectral error at least `sigma_{r+1}` by the Eckart–Young theorem. Passing to a submatrix cannot increase the spectral norm of the full error. QED.

For **fixed total term count `T`**, Lemma 53.3 makes `r=O(T p^{1-1/t})=o(p)` (because `t<=T` fixed). Therefore, uniformly over all allowed gains, masks and transported translation steps,

\[\boxed{\liminf_{p\to\infty\atop p\text{ prime}}\;\inf_M\|U_p-M\|_2\ge1/\sqrt2.}\tag{53.5}\]

This is a worst-case **operator-norm** exclusion for fixed-size translation-step Green networks, not a statement about arbitrary O(p)-time algorithms.

## 53.6 Explicit finite-size certificate table

For two stages with the indicated steps repeated independently at both stages, the deterministic optimized phase interval gives:

| Prime p | Step set | Character k | Total cut rank cap r | Fourier block rank m | Guaranteed `||U_p-M||_2` floor |
|---:|---|---:|---:|---:|---:|
| 127 | 1,35 | 11 | 30 | 63 | 0.230154 |
| 257 | 1,77 | 10 | 22 | 128 | 0.631329 |
| 1009 | 1,319 | 19 | 52 | 504 | 0.665605 |
| 8191 | 1,707,2003 | 139 | 470 | 4095 | 0.659728 |

The table entries are **mathematical cut-rank upper bounds**; the modular audit at `p=127` independently measured actual two-stage cut rank **30**, achieving the bound, in both finite fields. The `p=257,1009,8191` table values are not claims of dense-matrix computations at those lengths: their combinatorial cut witnesses are verified exactly with integer arithmetic.

## 53.7 Direct finite-field and affine-shuffle checks

Two independent fields `998244353` and `2013265921` were used:

- 24 independent modular Gauss–Jordan Green inversions at sizes 7,11,19,31. The full matrices matched a separately coded Green closed-form implementation, and their off-cut ranks matched **exactly** the number of crossing edges for randomly selected cuts.
- 24 deterministic Dirichlet witness checks (prime lengths through 65,537, different sets of 1–4 steps), including an independent `O(pT)` optimal-character search and literal edge-crossing count.
- Two fully formed `p=127` four-Green, two-stage modular networks, including independently varying gains and nonconstant interstage diagonals. In both fields, individual off-cut Green ranks were `[11,4,11,4]`, and the entire product's off-cut rank was `30`, matching the bound.
- With an affine reflection between stages, the transported-step certificate remained valid with measured rank 30 in both fields; 60 entrywise cross-checks per field verified the conjugation formula.

These modular audits check the **Green identities and rank arguments**, not Chebotarëv's theorem over the complex numbers. The proof of the complex Fourier exclusion uses the classical theorem separately.

## 53.8 A critical negative control: unrestricted shuffles can escape

An arbitrary non-affine interstage permutation is **not covered** by the translation-step theorem. In two explicit random permutation controls at `p=127`, the same block's modular rank rose from `30` to **62** or **63** (over the two fields). This is a deliberate failure mode, not an error: arbitrary shuffles can destroy the common low-boundary cut. It demonstrates why no claim is made for all Hamiltonian-cycle orders and arbitrary interstage permutations.

## 53.9 Dependencies, limitations, and Phase 54 direction

- Dirichlet's simultaneous approximation theorem is classical; a published statement appears in *Unconventional height functions in simultaneous Diophantine approximation* (Monatshefte für Mathematik, 2017), https://doi.org/10.1007/s00605-016-0983-0 .
- The inverse off-cut rank identity is a consequence of the matrix nullity theorem; see *A note on the nullity theorem*, Journal of Computational and Applied Mathematics 189 (2006), 179–190, https://doi.org/10.1016/j.cam.2005.02.007 .
- Chebotarëv's prime Fourier minor theorem and related uncertainty principles: T. Tao, *An uncertainty principle for cyclic groups of prime order*, Mathematical Research Letters 12 (2005), 121–127, https://arxiv.org/abs/math/0308286 .

**Not established:** publication novelty; Fourier membership for nontranslation Green graphs; a constant-depth all-length FFT; sub-`N log N` arithmetic complexity.

**Phase 54 target:** Leave the abelian translation/affine-shuffle topology. Search for explicitly generated *nontranslation* Hamiltonian cycle unions with strong cut expansion, independent phase holonomies, a compact fast application algorithm, and global Weyl covariance. The Phase 49 Weyl verifier should check actual Fourier membership; cut-rank feasibility alone is not sufficient. Test unrestricted shuffles as true alternatives, not as instances of the translation-step theorem.
