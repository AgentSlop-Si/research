"""Data-only preparation. This file never calls an external service or runs source programs."""
import copy
import hashlib
import json
import pathlib
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parent
BASE = json.loads((ROOT / 'BASELINE_NATIVE.json').read_text())
FLAT = json.loads((ROOT / 'CELLS.json').read_text())
SOURCES = json.loads((ROOT / 'SOURCE_BINDINGS.json').read_text())
CELLS = {(c['sheet'], c['row'], c['col']): {k:v for k,v in c.items() if k not in ('sheet','row','col')} for c in FLAT}
SHEETS = {s['properties']['title']:s['properties']['sheetId'] for s in BASE['metadata']['sheets']}
STAMP = '[2026-10-13; sealed post-20:40 scientific update]'
HISTORY = '\n\nEarlier dated history (preserved verbatim):\n'
PROTECTED = {('Research overview',252,9),('Research overview',307,9),('Research overview',308,9)}
EDITS = {}

def value(c):
    v=c.get('userEnteredValue',{})
    return v.get('stringValue',v.get('formulaValue',v.get('numberValue','')))

def col(n):
    out=''
    while n:
        n,a=divmod(n-1,26);out=chr(65+a)+out
    return out

def utf16(s): return len(s.encode('utf-16-le'))//2
def sha(b): return hashlib.sha256(b).hexdigest()
def ref(key):
    s=SOURCES[key]
    return f"{s['archive']} (SHA256 {s['sha256']}); {s['review_member']} (SHA256 {s['review_sha256']})"

def add(sheet,row,columns,text,keys,reason):
    for column in columns:
        key=(sheet,row,column)
        assert key not in PROTECTED, key
        assert key in CELLS, key
        assert key not in EDITS, key
        before=CELLS[key]
        assert 'formulaValue' not in before.get('userEnteredValue',{}), key
        assert isinstance(value(before),str), key
        assert not before.get('dataValidation'), key
        assert not before.get('chipRuns'), key
        prefix=STAMP+'\n'+text+HISTORY
        old=value(before)
        after=prefix+old
        assert utf16(after)<=50000,(key,utf16(after))
        writable={'userEnteredValue':{'stringValue':after}}
        fields=['userEnteredValue']
        if before.get('textFormatRuns'):
            # New unlinked prefix; old runs shift by exact UTF-16 code units.
            runs=[{'startIndex':0,'format':{}},{'startIndex':utf16(prefix),'format':{}}]
            for run in before['textFormatRuns']:
                rr=copy.deepcopy(run);rr['startIndex']=run.get('startIndex',0)+utf16(prefix)
                if runs[-1]['startIndex']==rr['startIndex']:runs[-1]=rr
                else:runs.append(rr)
            writable['textFormatRuns']=runs;fields.append('textFormatRuns')
        assert not before.get('userEnteredFormat',{}).get('textFormat',{}).get('link'),key
        EDITS[key]={'sheet':sheet,'sheet_id':SHEETS[sheet],'row':row,'col':column,'a1':f"'{sheet}'!{col(column)}{row}",
            'before':copy.deepcopy(before),'before_user_entered_value':copy.deepcopy(before.get('userEnteredValue',{})),
            'before_native_sha256':sha(json.dumps(before,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),
            'new_prefix':STAMP+'\n'+text,'after_string':after,'write_cell':writable,'fields':','.join(fields),
            'source_keys':keys,'reason':reason,'history_preserved_verbatim':after.endswith(old),
            'rich_text_preserved':bool(before.get('textFormatRuns'))}

# Q16: one bounded successful integration, with the earlier SIGXCPU attempt retained as history.
Q_STATUS='OPEN: full all-length executable and outer implementation; the frozen six-input observer-v2 integration is independently ACCEPTED and complete. Mathematical theorem scopes remain unchanged.'
Q_PROOF='Independent ACCEPT of one source-pinned six-module/six-input constructor-to-BUCKETS-to-deterministic-pipeline run. Six constructors (including two exact zero cases), ten declared rejection cases, three actual/reference pipeline pairs and three identity controls complete. The 593 reached runtime assertions, nine final paid ledgers and all 34 progress records reconcile. Normal exit 0; whole-child CPU 10.391873 s, elapsed 10.438622989 s, peak RSS 45,412 KiB. The original SIGXCPU/no-result attempt remains a distinct historical blocker; the successful run does not diagnose its interruption.'
Q_SCOPE='Bounded fixtures only: N=1,9,16,17; consumer B=4, r=1, P=16, W=63, beta absent, one-round schedules, q in {0,1}. Both nonempty outputs use M=64; M=128 has q=0. All nonzero cases have k0-e=0, so nontrivial outer scale-back is untested. Actual/reference consumers share the inherited numerical implementation. No theorem-sized sparse execution, new recovery probability, all-length dispatcher/dense fallback, full outer interpolation/accumulation, exact DFT, relative-l2 guarantee, novelty or speed claim.'
Q_NEXT='The observer revision, its single authorized run and independent result review are complete; do not redispatch that bounded run. Next, specify and independently review a source-pinned static contract for outer active-incidence enumeration and coefficient preparation: wrapped incidences, zero limits, eta=2^(-(D+3)m), output binding and paid active-support-times-stencil work. Exclude a hidden all-N transcendental pass and identify guards requiring dense dispatch. Keep dispatcher/dense fallback, outer rounding/scale-back and J-call amplification as separate open gates.'
Q_STOP='Stop the next named stage at independent acceptance of the frozen outer-incidence/coefficient contract and cost/error argument, or a precise interface/cost counterexample. Any later historical-program execution needs its own authorization. The completed reduced run does not close the full all-length implementation.'
Q_SCORE='Shared implementation parent priority remains 60/100. The reviewer proposes 96/100 for the distinct outer-incidence/coefficient-contract task, on its own task scale; it is not substituted for the existing comparable parent score and is not a novelty probability.'
Q_SOURCE=ref('Q16')+'. Producer result SHA256 f4842bff0aa524fb1d8dd8a25e3c58b3ebcab182ff86e3533e6b041e52bdcd26; frozen contract SHA256 7d38025fbfbc8ffb54ccddff5f0ca63ea72d44f4d79e007012c71f17bb103ef0. Review is evidence-only, with 489 fresh assertions, not 489 experiments.'
Q_SHORT='Q16 observer-v2 bounded integration ACCEPTED: all six fixtures and final paid-ledger/process checks complete. Full all-length executable remains OPEN. Move to a separately reviewed outer-incidence/coefficient contract; preserve parent priority 60.'
F016_QUAL='Related Q16 implementation dependency only; the Gaussian/Green theorem and its own complexity are unchanged. '

for row in [5,6,7,8]:
    qual=F016_QUAL if row==6 else ''
    for cc,txt in [([3,16],Q_NEXT),([6],Q_STATUS),([7],Q_SHORT),([8],Q_SCORE),([10],Q_SOURCE),([13],Q_SCORE),([14],qual+Q_PROOF),([17],Q_SCOPE+' '+Q_STOP)]:
        add('Research overview',row,cc,qual+txt if cc in ([3,16],[7]) else txt,['Q16'],'Close bounded Q16 integration; retain full parent obligations')
for cc,txt in [([3],Q_STATUS),([5],Q_PROOF),([6],Q_NEXT),([10],Q_SCOPE+' '+Q_STOP),([12],Q_SOURCE)]:add('Research queue',19,cc,txt,['Q16'],'Q16 latest accepted integration and next gate')
for cc,txt in [([3],Q_STATUS),([4,11],Q_NEXT),([5],Q_SOURCE),([6,12],Q_SCOPE+' '+Q_STOP),([8],Q_SCORE),([9],Q_PROOF)]:add('Next cycle',4,cc,txt,['Q16'],'STR-Q1 stable-ID continuation after bounded acceptance')
for cc,txt in [([3],Q_STATUS),([4],F016_QUAL+Q_PROOF),([6],Q_SCOPE),([7],Q_NEXT+' '+Q_STOP),([10],Q_SOURCE)]:add('Theorem register',31,cc,txt,['Q16'],'F016 dependency update, not theorem replacement')
for cc,txt in [([4],Q_PROOF),([5],Q_SCOPE),([6],Q_NEXT+' '+Q_STOP)]:add('Fusion list',15,cc,txt,['Q16'],'FUS-09 implementation gate and exact limits')
for cc,txt in [([28],Q_SCORE),([29],F016_QUAL+Q_PROOF+' '+Q_SOURCE),([31],Q_NEXT),([32],Q_SCOPE+' '+Q_STOP)]:add('Catalogue',5,cc,txt,['Q16'],'Canonical F016 current overlay')
for cc,txt in [([10,23],F016_QUAL+Q_PROOF),([14,26],Q_SCOPE+' '+Q_STOP),([15,25],Q_NEXT),([17],Q_SOURCE),([22],Q_SCORE)]:add('novelity breakthough',6,cc,txt,['Q16'],'F016 current attributed evidence and next action')
for sheet,row,cc in [('Theorem register',4,[4]),('Fusion list',4,[4]),('Research overview',120,[7])]:add(sheet,row,cc,'Q16 component only; other FUS-01 components, including the accepted superlinear Q30 baseline, retain their separate scopes. '+Q_PROOF+' '+Q_SCOPE,['Q16'],'Narrow FUS-01 component crosslink')
for sheet,row,cc in [('Theorem register',4,[7]),('Fusion list',4,[6]),('Research overview',120,[3,16])]:add(sheet,row,cc,'Q16 component: '+Q_NEXT+' Other FUS-01 obligations, including the separate linear P/Fourier acceleration gate, remain unchanged.',['Q16'],'Replace finished Q16 work with actual remaining gate')
for sheet,row,cc in [('New results',4,[5]),('novelity breakthough',113,[14]),('Research overview',242,[14])]:add(sheet,row,cc,'The recorded weak-error mathematical theorem is unchanged. Related Q16 finite integration now has independent bounded acceptance. '+Q_SCOPE,['Q16'],'Do not conflate mathematical result with finite implementation')
add('Proof sources',8,[5],'Q16 supplemental implementation evidence only; this does not change the original P05 proof member or hash. '+Q_SOURCE+' '+Q_SHORT,['Q16'],'Bind supplemental review without replacing proof identity')

# F020: actual endpoint transport, not a four-channel completion.
F_PROOF='Independent endpoint-only ACCEPT in characteristic two: for every m>=1 and alpha of exact odd order d=2m+3, 2m+5 or 2m+7, E_m(alpha) and E_m(alpha^-1) cannot both vanish. This includes composite orders and every primitive Frobenius component, without assuming inversion is a Frobenius power. Uniform complementary affine transport and exact n=0,1,2 symbolic gcd/Bezout certificates prove the three infinite lines; they are not a finite-m extrapolation. Earlier balanced-order and fixed-b acceptances remain separate.'
F_SCOPE='The all-n support/certificate formulation is proved equivalent to the general endpoint gate, but is not proved for all n. Endpoint/collision, collision/endpoint and collision/collision channels remain open. Keep exact-order, characteristic-two, unit-denominator and actual-degree reversal guards. No full four-channel closure, characteristic-zero transfer, all-A overlap consequence, actual-family counterexample, runtime or historical-originality claim.'
F_NEXT='The off-line affine-transport and three-line endpoint lemma is COMPLETE, cap15. General endpoint work remains OPEN53 and full paired-support work OPEN58. Next admissible progress needs a genuinely uniform endpoint argument, or an actual-RS-specific invariant controlling the remaining inverse-parameter collision channels. Full closure requires the localized Q_m,Q_m* unit ideal for every m, or an actual-family common factor with certified exact order >2m+1. Do not replace that goal by fixed-b/growing-n censuses, a one-sided collision, synthetic countermodels or a norm reformulation.'
F_STATUS='OPEN: full paired-support gate 58 and general endpoint gate 53. The balanced-order result and the new d=2m+3,2m+5,2m+7 endpoint-only lemma are independently accepted; the named new lemma is complete at cap15.'
F_SOURCE=ref('F020')+'. Candidate SHA256 6dcafc0ede275e0bbe439400ca3c2fa3f1c246d212a8860d204f8f7f17ebce3d; 478 data-only exact checks, 14 negative controls and two fresh-checker portable replays. No candidate or historical program executed.'
F_SCORE='Retain full-gate priority 58 and separate endpoint priority 53. Reviewer explicitly retains dimensions (4,2,1,4,4) and finds no comparative basis for a tractability increase. Completed transport/three-line stage is cap15; these are work priorities, not correctness or novelty probabilities.'
for cc,txt in [([3],F_STATUS),([4],F_PROOF),([7],F_NEXT+' '+F_SCOPE),([10],F_SOURCE)]:add('Theorem register',22,cc,txt,['F020'],'F020 endpoint-only accepted scope')
for cc,txt in [([28],F_SCORE),([29],F_PROOF+' '+F_SOURCE),([31],F_NEXT),([32],F_SCOPE)]:add('Catalogue',4,cc,txt,['F020'],'F020 current canonical overlay')
for cc,txt in [([10,12,23],F_PROOF),([14,26],F_SCOPE),([15,25],F_NEXT),([17],F_SOURCE),([22],F_SCORE)]:add('novelity breakthough',7,cc,txt,['F020'],'F020 current views preserve open full gate')
for cc,txt in [([3,16],F_NEXT),([6,8],F_STATUS),([7,14],F_PROOF),([10],F_SOURCE),([13],F_SCORE),([17],F_SCOPE)]:add('Research overview',9,cc,txt,['F020'],'F020 overview exact acceptance and remaining gates')
for sheet,row,cc in [('Research queue',11,[6]),('Research overview',116,[3,16])]:add(sheet,row,cc,'Related parent F020 update; the completed Q08 b31 residual/overlap stage is not reopened. '+F_NEXT,['F020'],'Keep completed Q08 successor crosslink current')

# Signed banks: two separately sealed results. A later >=16 review is included only if its source binding exists.
B_PROOF='Two separate independent ACCEPTS at N=11, q=13 and original legal bank grammar. First, a literal twelve-bank negative-Fourier witness over F23^5 has orientation counts (5,1,1,5), both cross-sign singleton alphas 4 and beta=1; all 132 branch inverses and all 121 Fourier entries check exactly. Second, for any K/F23 with exactly one effective alpha node in each cross-sign orientation, both fixed at4, b4(K)>=12 and b4(K)=12 iff K contains F23^5; otherwise b4(K)>=14. The infinity convention covers nonexistence. The earlier nine-case/base-field theorem is retained at its own scope.'
B_SCOPE='The optimum twelve is confined to the pinned effective-singleton model. No free-singleton or unrestricted-architecture minimum, fourteen-bank attainment, all-N/characteristic-zero extension or historical-novelty conclusion is accepted. Bank count is not arithmetic work: the witness uses 132 branch inverses over a degree-five field, and root preparation, representation, inverse evaluation and output work remain paid. No FFT speed claim.'
B_NEXT='The twelve-bank witness and the separate pinned field-sensitive minimum review are COMPLETE. Resolve the remaining pinned F23 attainment/lower-bound question by an independently checked original-grammar witness or stronger obstruction. Keep free singleton choices, other cross-sign allocations, unrestricted minima and shared evaluation separate; do not redispatch the completed nine-case census or witness/minimum review.'
B_SOURCE=ref('SIGNED_WITNESS')+'; '+ref('SIGNED_MINIMUM')+'. The witness-only acceptance and separate proof addendum must remain distinct.'
B_STATUS='TO RESEARCH: broader signed-bank parent remains OPEN56. N5 all-field minimum, N11/F23 nine-case audit, twelve-bank extension witness and pinned field-sensitive minimum are complete at their exact scopes.'
B_SCORE='Broader signed-bank parent priority remains 56/100. The witness review\'s proposed minimum-proof task is now completed by the separate accepted addendum. Its successor recommendation does not replace the existing comparable parent score; no novelty probability or discovery count is inferred.'
if 'SIGNED_SIXTEEN' in SOURCES:
    extra=json.loads((ROOT/'SIGNED_SIXTEEN_CONTENT.json').read_text())
    B_PROOF+=' '+extra['proof'];B_SCOPE=extra['scope']+' '+B_SCOPE.replace('fourteen-bank attainment','sixteen-bank attainment');B_NEXT=extra['next'];B_SOURCE+='; '+ref('SIGNED_SIXTEEN')
    B_STATUS+=' The separate pinned F23 >=16 lower bound is also independently accepted; attainment remains open.'
    B_SCORE+=' The earlier proposed fourteen-bank attainment task is superseded by the accepted >=16 obstruction, not retained as unfinished work.'

for row in [10,11,12,13]:
    for cc,txt in [([3,16],B_NEXT),([6,8],B_STATUS),([7,14],B_PROOF),([10],B_SOURCE),([13],B_SCORE),([17],B_SCOPE)]:add('Research overview',row,cc,txt,['SIGNED_WITNESS','SIGNED_MINIMUM']+(['SIGNED_SIXTEEN'] if 'SIGNED_SIXTEEN' in SOURCES else []),'Propagate exact signed-bank field scopes and finished gates')
for cc,txt in [([3],B_STATUS),([5],B_PROOF),([6],B_NEXT),([10],B_SCOPE),([12],B_SOURCE)]:add('Research queue',38,cc,txt,['SIGNED_WITNESS','SIGNED_MINIMUM'],'Q35 remaining signed-bank work')
for cc,txt in [([3],B_STATUS),([4,11],B_NEXT),([5],B_SOURCE),([6,12],B_SCOPE),([8],B_SCORE),([9],B_PROOF)]:add('Next cycle',10,cc,txt,['SIGNED_WITNESS','SIGNED_MINIMUM'],'Signed-bank successor exact scope')
for cc,txt in [([3],B_STATUS),([4],B_PROOF+' '+B_SOURCE),([5],B_SCOPE)]:add('New results',20,cc,txt,['SIGNED_WITNESS','SIGNED_MINIMUM'],'Keep uniform bank theorem separate from fixed-N result')
for cc,txt in [([28],B_SCORE),([29],B_PROOF+' '+B_SOURCE),([31],B_NEXT),([32],B_SCOPE)]:add('Catalogue',10,cc,txt,['SIGNED_WITNESS','SIGNED_MINIMUM'],'Canonical magnetic current overlay')
for row in [8,9,10]:
    for cc,txt in [([10,23],B_PROOF),([14,26],B_SCOPE),([15,25],B_NEXT),([17],B_SOURCE),([22],B_SCORE)]:add('novelity breakthough',row,cc,txt,['SIGNED_WITNESS','SIGNED_MINIMUM'],'Signed-bank attributed evidence and bounded next gate')
for cc,txt in [([3,9],B_PROOF),([4],B_STATUS),([6,11],B_NEXT),([12],B_SCOPE)]:add('Incoming queue',5,cc,'Q35 shared-workflow supplement; original intake provenance retained. '+txt,['SIGNED_WITNESS','SIGNED_MINIMUM'],'IN-02 source-family workflow crosslink')

# Distinct shared-cut result crosslinks: do not replace the existing q-torus or HERO0 theorem.
S_PROOF='Distinct related shared-cut rational-QTGF product result, independently ACCEPTED. For N=m^2, m=2^r>=2 and k|m, k>=2 equal slabs, if every effective transported denominator has common-cut rank <=m, both squared relative-Frobenius and squared spectral errors to a flat unitary are >=[1-1/k-kd/m]_+. Exact equality forces d>=ceil(m/4); d=o(m) forces best errors toward1. Arbitrary diagonal interstages and independently permuted/scaled outer endpoints, including zeros, are allowed. This does not replace this row\'s original theorem or finite positive control.'
S_SCOPE='The common-cut condition must hold after internal routing is transported through the actual product. Arbitrary internal permutations can violate it. Correct Countercontrol A requires beta!=0 and beta^m!=1 (beta=2 over C works); beta=0 gives rank0. Only the stated separately paid full-stage evaluator yields the conditional Omega(N^(3/2)) execution conclusion. Reorganized/shared evaluators, independently routed QTGF and general Fourier algorithms remain outside the result.'
S_PRIOR='Named antecedent comparison COMPLETE: original HERO0 Phase26 Theorem26.6 supplies shared-order disjoint-energy/near-unit-error reasoning for two mixed-axis rook stages; it is distinct from the later common-bipartition 1/sqrt(2) floor. Green Phase53 supplies common-cut rank accumulation, diagonal interstages, transported affine routing, independently relocated endpoints and paid-evaluator limits for prime-length one-dimensional cycles. Neither statement contains the new square-dyadic 2D slab architecture. This is a scoped application of classical cut algebra/low-rank approximation, suitable for a proposition/counterexample section; worldwide priority is not established.'
S_NEXT='Close the named shared-cut mathematical audit, exact Phase26/53 comparison and constant-depth aligned search. Merge this distinct result as a crosslinked proposition. Do not launch more aligned parameter grids. Any independent-routing continuation needs a new actual common-cut certificate or different invariant. Optional editorial/prefilter work is a separate proposal; the original parent\'s other open scopes remain unchanged.'
S_SCORE='Existing parent numeric priority is unchanged. The independent reviewer assigns 15/100 only to the now-completed shared-cut audit/comparison (replacing its separate historical proposed44), and proposes28 only for optional editorial/prefilter work. Neither is a new score for this whole row.'
S_SOURCE=ref('SHARED_CUT')+'. Original HERO0 Phase26 archive SHA256 c790508658a55ca935f694451f7927a5da7d8acdefcb6371100569f49e54ebee; Green Phase53 archive SHA256 b7734dd2637f6bd96152cc8448ae9bbd489316de8dcf2b84da5aee5396f6f.'
# Correct digest copied from the sealed review, rather than inferred from a filename.
S_SOURCE=S_SOURCE.replace('b7734dd2637f6bd96152cc8448ae9bbd489316de8dcf2b84da5aee5396f6f','b7734dd2637f6bd96152cc8448ae9bbd489316121de8dcf2b84da5aee5396f6f')
for cc,txt in [([3],S_PROOF),([4,9],S_PROOF+' '+S_SCOPE),([5],S_SOURCE),([6,11],S_NEXT+' Historical priority of the separate frozen five-orientation finite positive control remains open under its own exact source/model comparison.'),([8],S_SCORE),([10],S_PRIOR),([12],S_SCOPE)]:add('Incoming queue',43,cc,txt,['SHARED_CUT'],'Distinct dated rational-QTGF shared-cut crosslink only')
for cc,txt in [([3,16],S_NEXT+' Historical priority of the separate frozen five-orientation finite positive control remains open under its own exact source/model comparison.'),([7,14],S_PROOF),([10],S_SOURCE),([13],S_SCORE),([15],S_PRIOR),([17],S_SCOPE)]:add('Research overview',28,cc,txt,['SHARED_CUT'],'Preserve q-torus parent and add related accepted scope')
for cc,txt in [([5],S_SOURCE),([10],S_PRIOR),([6,11],S_NEXT+' Original HERO0 outside-grammar obligations stay open.')]:add('Incoming queue',26,cc,txt,['SHARED_CUT'],'Completed HERO0 antecedent comparison without theorem conflation')
for cc,txt in [([10],S_SOURCE),([15],S_PRIOR),([3,16],S_NEXT+' Original HERO0 outside-grammar obligations stay open.')]:add('Research overview',136,cc,txt,['SHARED_CUT'],'HERO0 comparison complete; broad parent remains open')

# Overview summary, with all previous checkpoint bytes retained.
summary='331 stable IDs and all numeric priorities retained. Later sealed results: Q16 bounded integration accepted; F020 three new endpoint-order lines accepted with full58/endpoint53 open; twelve-bank F23^5 witness and separately pinned field-sensitive minimum accepted; shared-cut audit/Phase26–53 comparison complete. Full all-length/outer execution, full paired support, unrestricted bank minima and general FFT claims remain open.'
if 'SIGNED_SIXTEEN' in SOURCES:summary=summary.replace('pinned field-sensitive minimum accepted','pinned field-sensitive minimum and pinned F23 >=16 lower bound accepted')
add('Progress',1,[1],summary,list(SOURCES),'Post-20:40 scientific snapshot; prior full checkpoint retained')
add('Progress',7,[3],'Completed named stages now also include Q16 observer-v2 integration/result review, F020 affine transport/three endpoint lines, the separate signed-bank extension/minimum acceptances'+(' and pinned F23 >=16 review' if 'SIGNED_SIXTEEN' in SOURCES else '')+', and shared-cut theorem/antecedent review. These are scoped completions, not a live-worker count or new independent-discovery count. Select only distinct remaining gates; do not redispatch completed work.',list(SOURCES),'Finish work gates without changing historical activity count')
add('Progress',18,[2],Q_SHORT,['Q16'],'Resolve stale broad unintegrated statement at exact finite scope')
add('Progress',18,[3],Q_NEXT+' '+Q_SCOPE,['Q16'],'Keep full implementation gates open')
add('Progress',23,[2],B_PROOF,['SIGNED_WITNESS','SIGNED_MINIMUM'],'Later signed-bank accepted results')
add('Progress',23,[3],B_NEXT+' '+B_SCOPE,['SIGNED_WITNESS','SIGNED_MINIMUM'],'Later signed-bank actual next steps')
add('Progress',30,[2],S_PROOF,['SHARED_CUT'],'Distinct shared-cut related result in q-torus progress')
add('Progress',30,[3],S_NEXT+' '+S_SCOPE,['SHARED_CUT'],'Close only aligned shared-cut search')
add('Research overview',3,[5],'Existing 225/225 source-readiness coverage is unchanged and is not a mathematical review count. Post-20:40 sealed result update: '+summary,list(SOURCES),'Update stale latest-result summary while preserving coverage history')

# Build exact field-masked requests and a comprehensive read-before-write guard.
ordered=sorted(EDITS.values(),key=lambda x:(list(SHEETS).index(x['sheet']),x['row'],x['col']))
requests=[]
for e in ordered:
    requests.append({'updateCells':{'range':{'sheetId':e['sheet_id'],'startRowIndex':e['row']-1,'endRowIndex':e['row'],'startColumnIndex':e['col']-1,'endColumnIndex':e['col']},'rows':[{'values':[e['write_cell']]}],'fields':e['fields']}})
    if 'SIGNED_SIXTEEN' in SOURCES and ('SIGNED_WITNESS' in e['source_keys'] or 'SIGNED_MINIMUM' in e['source_keys']):
        if 'SIGNED_SIXTEEN' not in e['source_keys']:e['source_keys'].append('SIGNED_SIXTEEN')

assert all(len(r)==1 for r in requests)
assert not any(e['before_user_entered_value'].get('numberValue') is not None for e in ordered)
assert all(e['history_preserved_verbatim'] for e in ordered)
assert not any((e['sheet'],e['row'],e['col']) in PROTECTED for e in ordered)
json.dump({'spreadsheet_id':BASE['metadata']['spreadsheetId'],'requests':requests},open(ROOT/'EXACT_REQUEST.json','w'),ensure_ascii=False,indent=2)
json.dump({'status':'PREPARED_NOT_APPLIED','baseline':'final_apply_2322/AFTER_NATIVE_PACKED.json','metadata':BASE['metadata'],'protected_cells':[{'sheet':s,'row':r,'col':c,'before':CELLS[(s,r,c)]} for s,r,c in sorted(PROTECTED)],'edits':ordered},open(ROOT/'GUARDED_DELTA.json','w'),ensure_ascii=False,indent=2)
json.dump({'ranges':list(dict.fromkeys(e['a1'] for e in ordered)),'cell_fields':'userEnteredValue,userEnteredFormat,textFormatRuns,chipRuns,dataValidation,note,hyperlink'},open(ROOT/'PREWRITE_READ_PLAN.json','w'),ensure_ascii=False,indent=2)
validation={'status':'PASS_PREPARATION_ONLY','external_writes':0,'historical_program_execution':False,'edit_cells':len(ordered),'requests':len(requests),'numeric_changes':0,'formula_changes':0,'style_changes':0,'id_changes':0,'rich_text_cells_preserved':sum(e['rich_text_preserved'] for e in ordered),'protected_three_cells_untouched':True,'all_old_text_preserved_verbatim':True,'max_after_utf16':max(utf16(e['after_string']) for e in ordered),'by_sheet':dict(Counter(e['sheet'] for e in ordered)),'sources':list(SOURCES),'requires_root_review_and_fresh_live_guard':True}
json.dump(validation,open(ROOT/'VALIDATION.json','w'),ensure_ascii=False,indent=2)
with open(ROOT/'REVIEWABLE_DELTA.md','w') as f:
    f.write('# Post-20:40 guarded scientific delta\n\nPrepared only. No external writes. Every prior cell string is preserved verbatim as dated history. Numeric values, formulas, styles, stable IDs, tab structure and the three protected cells are unchanged.\n\n')
    f.write(json.dumps(validation,indent=2)+'\n\n')
    for e in ordered:
        f.write('## '+e['a1']+'\n\n'+e['new_prefix']+'\n\nSources: '+', '.join(e['source_keys'])+'\n\n')
print(json.dumps(validation,indent=2))
