# H16 finite-word resumption: bounded relocation family excluded

## Result

All **1,845,120 labeled configurations** in the declared delete-two/insert-one family fail full input-output reachability. There are **zero survivors**. Hence no schedule in this family realizes the unnormalized H16 operator on sixteen arbitrary data registers with thirty-one H2 calls, whatever nonzero complex diagonal factors are chosen. The rejection also allows arbitrary endpoint monomials.

This is a bounded negative result. No thirty-one-call word was found; no general thirty-one-call lower bound or improved transform follows. The known ordinary thirty-two-call word remains the positive control.

The interrupted worker's claimed new experiment had no identifiable saved checkpoint. This report records a fresh test, not recovered progress. The older exact-width neighborhood material was read for context but its code was not executed. Both programs in this package were newly written for this test.

## Family and exact census

Use the standard fixed chronological 32-call butterfly schedule: for s=0,1,2,3, in increasing order of i with bit s zero, call on (i,i XOR 2^s).

1. Delete two different original positions, preserving the order of the thirty surviving calls.
2. Select one of the thirty-one cuts before, between, or after the surviving calls.
3. Insert one call on any of the 120 unordered pairs of distinct registers.

Thus the number of labeled configurations is binomial(32,2) * 31 * binomial(16,2) = 1,845,120. This counts edit descriptions, not distinct or nonisomorphic circuits. No claim is made about novelty or disjointness relative to previously tested neighborhoods.

The C++ census directly propagates exact 16-bit input-support sets through all thirty-one calls. It checks each configuration in both chronological directions. Both counts are zero survivors, with zero forward/reverse disagreements. Reversal transposes the structural reachability matrix; full reachability is therefore equivalent in both directions.

## Why the rejection is coefficient-independent

Start with register i depending only on independent input x_i. A linear map on registers a and b can create dependence only on the union of their prior input sets. Propagating that union to both outputs is an upper bound even when arbitrary complex two-register linear maps, including singular ones, are allowed. An H2 call with invertible diagonal factors is contained in this larger class. Scalar cancellation can remove paths' effects; it cannot create dependence where no path exists.

Each tested network has at least one structurally absent input-output path. Its operator therefore has a zero entry at that position for every coefficient assignment. H16 has no zero entries. Neither a nonzero row/column scaling nor a row/column permutation changes whether an operator has a zero entry. The contradiction is consequently valid with arbitrary endpoint monomials and unrestricted nonzero complex scalars.

Internal permutations can be pushed through gates and absorbed into the pair schedule, leaving an endpoint permutation. The family restriction applies to that resulting schedule. It does not permit arbitrary additional routing that moves the schedule outside the declared family.

No initialized scratch register, retained auxiliary output, or restricted input distribution is used. Every accepted word would have to act correctly on all sixteen independent input coordinates. No floating-point calculation is involved in rejection.

## Independent complete check

`independent_verify.py` does not import or execute the C++ enumerator. For every deletion pair and cut it separately computes a Boolean prefix matrix P and suffix matrix S. Without the inserted call the structural operator is the Boolean product S*P. Inserting a call on a,b adds the union of prefix supports P_a and P_b precisely to those final rows whose suffix support contains a or b. This independently reconstructed support matrix excludes every labeled configuration.

The verifier checks this factorization against direct chronological propagation for 15,376 control configurations, one at every deletion-pair/cut combination. It also checks the full integer operator of the ordinary 32-call word against every entry of H16, eight one-call-deletion negative controls, and restoration of each deleted call as a positive control.

A canonical absent path is generated for every configuration in lexicographic deletion-pair, cut, inserted-pair order. Encode its lexicographically first absent output/input position as one byte (16*output + input). The SHA-256 of that 1,845,120-byte stream is:

`74bf2a26bec02505582bd10c52223b60ad5c80b34d6c6aaadecab387cc3be869`

The stream is reproducibly generated rather than bundled. `INDEPENDENT_VERIFICATION.json` includes the exact histogram of the number of incomplete output rows. Even the 336 closest configurations by this row-count measure have one incomplete row and are therefore excluded. This measure is not an arithmetic approximation to H16.

Because reachability rejects the entire family, no rank-cut or scalar-equation stage is necessary. The previously contemplated rank-cut test was never needed for this fresh family. There is no unresolved topology within this declared census.

## Reproduction and boundary

Compile `enumerate.cpp` with a C++17 compiler and pass the package directory as its sole argument. Then run `independent_verify.py` with Python 3.10 or newer. Neither program needs downloaded code or third-party packages. The roughly subsecond C++ and few-second Python runtimes observed here are verification timings, not transform benchmarks.

The finite experiment is complete. The next actual construction question remains an exact thirty-one-call H16 word outside this family, or a separately declared broader search. This report deliberately makes no finite-win amplification, exponent, bit-complexity, or scalar-preparation claim.
