# Fresh bounded family: one relocated/replaced call, one net deletion

This is a new resumption experiment. No saved checkpoint from the interrupted finite-word worker was found; the only inherited mathematical baseline is the existing exact-width research under `/workspace/shared/fft_exact_width_20261008`.

Target: unnormalized H16 = H2 tensor H2 tensor H2 tensor H2, acting on exactly sixteen independent arbitrary data registers. Exactly thirty-one forward H2 calls are permitted here, with invertible monomial interleaves and no initialized scratch or discarded outputs. For rejection, arbitrary two-register linear maps are allowed on each scheduled pair, a strict superset of diagonal-H2-diagonal gates.

Baseline: list stages s=0,1,2,3; within each stage list ascending i with bit s zero; pair i with i XOR 2^s. This fixes a 32-call chronological schedule.

Declared family: delete two distinct original positions d1<d2; take the 30 surviving calls in their original order; choose one of the 31 cuts (before all calls, between consecutive calls, or after all calls); insert one arbitrary unordered pair of distinct physical registers at that cut. Count all 496*31*120 = 1,845,120 labeled configurations, allowing duplicate resulting schedules. An arbitrary internal permutation is understood to have already been absorbed into the resulting pair schedule; permutations that produce a schedule outside this family are outside scope. Arbitrary endpoint row/column permutations and nonzero scaling are allowed.

Tests: exhaustive Boolean input-output reachability screening, with forward and reverse agreement; exact single-value temporal-graph bottleneck certificates for survivors. A certificate separating more than eight input positions from two outputs through one scalar node contradicts every row/column monomial equivalent of H16. Any survivor not excluded by this certificate is unresolved, not an exact word.

Stopping condition: finish this finite census and independently validate emitted rejection witnesses and positive/negative controls. Do not expand the neighborhood without a new explicit scope declaration. No claim of a general lower bound, an improved FFT, or prior progress.
