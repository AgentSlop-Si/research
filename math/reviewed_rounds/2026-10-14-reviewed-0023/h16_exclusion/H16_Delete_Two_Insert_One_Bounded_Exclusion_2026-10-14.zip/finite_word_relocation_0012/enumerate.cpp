#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using Pair=std::array<int,2>;
using Word=std::array<Pair,31>;
bool full(const Word&w,bool reverse){
 std::array<uint16_t,16> m{};
 for(int i=0;i<16;++i)m[i]=uint16_t(1u<<i);
 for(int t=0;t<31;++t){const auto &p=w[reverse?30-t:t]; uint16_t u=m[p[0]]|m[p[1]];m[p[0]]=m[p[1]]=u;}
 for(auto z:m){if(z!=65535)return false;}
 return true;
}
int main(int argc,char**argv){
 if(argc!=2)return 2;
 std::string root=argv[1];std::ofstream out(root+"/survivors.jsonl");
 std::array<Pair,32>b{};int k=0;
 for(int s=0;s<4;++s)for(int i=0;i<16;++i)if(!(i&(1<<s)))b[k++]={i,i^(1<<s)};
 uint64_t total=0,forward=0,backward=0,mismatch=0;
 for(int d1=0;d1<32;++d1)for(int d2=d1+1;d2<32;++d2){
  std::array<Pair,30>kept{};int z=0;for(int t=0;t<32;++t)if(t!=d1&&t!=d2)kept[z++]=b[t];
  for(int cut=0;cut<=30;++cut)for(int a=0;a<16;++a)for(int c=a+1;c<16;++c){
   Word w{};z=0;for(int t=0;t<31;++t)w[t]=t==cut?Pair{a,c}:kept[z++];
   bool f=full(w,false),r=full(w,true);++total;forward+=f;backward+=r;mismatch+=(f!=r);
   if(f)out<<"{\"deleted\":["<<d1<<","<<d2<<"],\"cut\":"<<cut<<",\"pair\":["<<a<<","<<c<<"]}\n";
  }
 }
 std::ofstream report(root+"/census.json");
 report<<"{\"labeled_configurations\":"<<total<<",\"forward_survivors\":"<<forward<<",\"reverse_survivors\":"<<backward<<",\"forward_reverse_mismatches\":"<<mismatch<<"}\n";
 std::cout<<total<<" configurations; "<<forward<<" forward, "<<backward<<" reverse survivors; "<<mismatch<<" mismatches\n";
 return mismatch?1:0;
}
