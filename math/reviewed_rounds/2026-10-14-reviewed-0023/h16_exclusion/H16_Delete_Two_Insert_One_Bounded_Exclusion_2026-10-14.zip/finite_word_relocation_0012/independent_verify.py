#!/usr/bin/env python3
"""Independent complete census using Boolean prefix/suffix factorization.
Does not import or execute the author enumerator or historical research code.
"""
import hashlib, itertools, json, math, time
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=16; FULL=(1<<N)-1
BASE=[(i,i+(1<<s)) for s in range(4) for i in range(16) if (i//(1<<s))%2==0]
PAIRS=list(itertools.combinations(range(N),2))
def propagate(word):
    support=[1<<j for j in range(N)]
    for a,b in word:
        union=support[a]|support[b]
        support[a]=union
        support[b]=union
    return support

def factors(kept,cut):
    # Prefix row supports at the intermediate cut.
    prefix=propagate(kept[:cut])
    # Suffix matrix rows viewed as sets of intermediate registers.
    suffix=propagate(kept[cut:])
    # Boolean suffix * prefix, with the newly inserted gate absent.
    raw=[]
    for mask in suffix:
        m=0
        for k in range(N):
            if mask&(1<<k):m|=prefix[k]
        raw.append(m)
    return prefix,suffix,raw

def inserted_support(prefix,suffix,raw,a,b):
    both=(1<<a)|(1<<b)
    union=prefix[a]|prefix[b]
    return [r|union if s&both else r for s,r in zip(suffix,raw)]

def exact_operator(word):
    m=[[int(i==j) for j in range(N)] for i in range(N)]
    for a,b in word:
        u,v=m[a],m[b]
        m[a]=[x+y for x,y in zip(u,v)]
        m[b]=[x-y for x,y in zip(u,v)]
    return m

def main():
    started=time.monotonic()
    expected=math.comb(32,2)*31*math.comb(16,2)
    census=json.loads((ROOT/'census.json').read_text())
    assert census=={'labeled_configurations':expected,'forward_survivors':0,'reverse_survivors':0,'forward_reverse_mismatches':0}
    # Full operator positive control, all independent input coordinates retained.
    target=[[(-1)**((i&j).bit_count()) for j in range(N)] for i in range(N)]
    assert exact_operator(BASE)==target
    assert propagate(BASE)==[FULL]*N
    counts=Counter(); by_cut=Counter(); witnesses=Counter(); seen=0; full=0
    first_examples=[]; digest=hashlib.sha256()
    # Each byte encodes a canonical missing input-output path for one labeled
    # configuration. The stream is generated and hashed, not externally stored.
    for d1,d2 in itertools.combinations(range(32),2):
        kept=[p for t,p in enumerate(BASE) if t not in (d1,d2)]
        for cut in range(31):
            p,s,r=factors(kept,cut)
            for a,b in PAIRS:
                dep=inserted_support(p,s,r,a,b)
                # Direct chronological propagation independently checks factor
                # interpretation at every deletion/cut for a fixed control pair.
                if (a,b)==(0,15):
                    assert dep==propagate(kept[:cut]+[(a,b)]+kept[cut:])
                seen+=1
                absent=[i for i,x in enumerate(dep) if x!=FULL]
                full+=not absent
                assert absent, (d1,d2,cut,a,b)
                o=absent[0]; missing=FULL^dep[o]; inp=(missing&-missing).bit_length()-1
                counts[len(absent)]+=1;by_cut[cut]+=1;witnesses[(o,inp)]+=1
                digest.update(bytes([o*16+inp]))
                if len(first_examples)<3:
                    first_examples.append({'deleted':[d1,d2],'cut':cut,'pair':[a,b],'missing_output':o,'missing_input':inp})
    assert seen==expected and full==0
    assert all(v==math.comb(32,2)*120 for v in by_cut.values())
    # Mutation controls: restoring both original gates recreates the ordinary
    # full-reach baseline; dropping any one gate never does.
    restored=[]
    for d in (0,7,8,15,16,23,24,31):
        w=BASE[:d]+BASE[d+1:]
        assert propagate(w)!=[FULL]*N
        restored.append(propagate(w[:d]+[BASE[d]]+w[d:])==[FULL]*N)
    assert all(restored)
    report={
        'status':'PASS','method':'independent complete Boolean prefix/suffix factorization',
        'labeled_configurations':seen,'full_reachability_survivors':full,
        'canonical_missing_path_stream_sha256':digest.hexdigest(),
        'configurations_by_number_of_incomplete_outputs':dict(sorted(counts.items())),
        'distinct_canonical_missing_input_output_pairs':len(witnesses),
        'direct_factorization_checks':math.comb(32,2)*31,
        'positive_controls':{'exact_32_call_operator_equals_H16':True,'restored_deleted_gate_checks':len(restored)},
        'negative_controls':{'one_gate_deletions_rejected':8},
        'first_examples':first_examples,'elapsed_seconds':time.monotonic()-started}
    (ROOT/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
