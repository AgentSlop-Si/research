// Independent audit: trace each final output backwards through the temporal graph.
// A gate links its two input wires to either selected output wire. No source imports.
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdexcept>
using E=std::array<int,2>;
using W=std::vector<E>;
uint32_t ancestors(const W& w,int output){
 uint32_t selected=1u<<output;
 for(auto it=w.rbegin();it!=w.rend();++it){
  uint32_t endpoints=(1u<<(*it)[0])|(1u<<(*it)[1]);
  if(selected&endpoints) selected|=endpoints;
 }
 return selected;
}
std::array<uint32_t,16> fullmatrix(const W& w){
 std::array<uint32_t,16> m{};
 for(int r=0;r<16;++r) m[r]=ancestors(w,r);
 return m;
}
bool dense(const W&w){for(auto row:fullmatrix(w))if(row!=65535u)return false;return true;}
int main(int argc,char**argv){
 if(argc!=2)return 2;
 std::string out=argv[1];
 W baseline;
 for(int stride=1;stride<16;stride*=2)
  for(int block=0;block<16;block+=2*stride)
   for(int k=0;k<stride;++k)baseline.push_back({block+k,block+k+stride});
 if(baseline.size()!=32||!dense(baseline))throw std::runtime_error("baseline control failure");
 W identity;
 for(int r=0;r<16;++r)if(ancestors(identity,r)!=(1u<<r))throw std::runtime_error("identity control failure");
 for(int d=0;d<32;++d){auto w=baseline;w.erase(w.begin()+d);if(dense(w))throw std::runtime_error("one deletion survived");w.insert(w.begin()+d,baseline[d]);if(!dense(w))throw std::runtime_error("restore failed");}
 std::ofstream witness(out+"/traceback_witnesses.bin",std::ios::binary);
 std::array<uint64_t,17> histogram{};
 uint64_t total=0,survivors=0,canonical_pairs=0;
 std::array<bool,256> encountered{};
 for(int first=0;first<32;++first)for(int second=first+1;second<32;++second){
  W base=baseline;base.erase(base.begin()+second);base.erase(base.begin()+first);
  for(int cut=0;cut<=30;++cut)for(int lo=0;lo<16;++lo)for(int hi=lo+1;hi<16;++hi){
   W w=base;w.insert(w.begin()+cut,{lo,hi});
   auto m=fullmatrix(w);int incomplete=0,canonical=-1;
   for(int r=0;r<16;++r)if(m[r]!=65535u){
    ++incomplete;
    if(canonical<0)for(int c=0;c<16;++c)if(!(m[r]&(1u<<c))){canonical=16*r+c;break;}
   }
   ++histogram[incomplete];++total;
   if(canonical<0){++survivors;throw std::runtime_error("full reachability survivor");}
   char byte=static_cast<unsigned char>(canonical);witness.write(&byte,1);encountered[canonical]=true;
  }
 }
 for(auto used:encountered)canonical_pairs+=used;
 std::ofstream report(out+"/traceback_results.json");
 report<<"{\"method\":\"per-output backwards temporal reachability\",\"labeled_configurations\":"<<total<<",\"survivors\":"<<survivors<<",\"identity_controls\":16,\"single_deletion_controls\":32,\"restoration_controls\":32,\"distinct_canonical_pairs\":"<<canonical_pairs<<",\"incomplete_output_histogram\":{";
 bool comma=false;for(int i=0;i<=16;++i)if(histogram[i]){if(comma)report<<",";comma=true;report<<"\""<<i<<"\":"<<histogram[i];}report<<"}}\n";
 std::cout<<total<<" configurations; "<<survivors<<" survivors; all controls pass\n";
}
