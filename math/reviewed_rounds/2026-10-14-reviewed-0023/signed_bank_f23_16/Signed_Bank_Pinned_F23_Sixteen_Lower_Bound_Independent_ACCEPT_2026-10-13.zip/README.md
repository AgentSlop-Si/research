# Pinned F23 sixteen-bank lower bound: independent ACCEPT

The independent proof and arithmetic review is in `REVIEW.md`.

Accepted result: at N=11, q=13 over F23, in the original signed-bank grammar with both effective cross-sign singleton alpha nodes fixed at 4, every representation uses at least 16 actual banks. This is not an attainment or optimality claim.

The reviewer independently derived the necessary moments, enumerated all 529 monic sextics and all 74,613 six-node supports, checked the zero/repeated/padded-node cases and reflection, and tested literal resolvent coefficients. No candidate or historical scientific code was executed.

## Replay

Using Python 3.8 or later, with only its standard library:

    python3 -I independent_check.py --candidate INPUT_CANDIDATE.zip --out replay

The candidate is read only as a hash-pinned archive of inert data. Its Python files are never loaded. The fresh verifier recomputes all scientific quantities before comparison. Successful execution prints ACCEPT and produces three deterministic scientific outputs.

Compare the replay files with the recorded hashes in `REPLAY_VERIFICATION.json`. `RUN.log` and `COLD_REPLAY.log` are byte-identical successful transcripts. `MANIFEST.json` binds every other file in this acceptance archive. The sibling `.seal.json` binds the archive itself.

The complete input archive is included to preserve the exact reviewed edition. This review does not rely on accepting its prior extension-field or novelty claims.
