#!/usr/bin/env python3
"""Independent standard-library verifier. No candidate or historical code is loaded."""
import argparse, csv, hashlib, io, itertools, json, math
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

P, N, Q = 23, 11, 13
PIN = 'e58d0405e4d7664b3ed6318181caa4ce79e2af2ef07bc686cd6b0dd8a8274201'
INV = [0] + [pow(x, -1, P) for x in range(1, P)]

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def mm(a,b):
    return [[sum(x*y for x,y in zip(row,col)) % P for col in zip(*b)] for row in a]

def ident(n):
    return [[int(i==j) for j in range(n)] for i in range(n)]

def matpow(a,n):
    ans=ident(len(a))
    while n:
        if n&1: ans=mm(ans,a)
        a=mm(a,a); n//=2
    return ans

def rref(a):
    a=[row[:] for row in a]; rank=0; pivots=[]
    for col in range(len(a[0])):
        k=next((k for k in range(rank,len(a)) if a[k][col]),None)
        if k is None: continue
        a[rank],a[k]=a[k],a[rank]
        z=INV[a[rank][col]]; a[rank]=[(x*z)%P for x in a[rank]]
        for i in range(len(a)):
            if i!=rank:
                z=a[i][col]; a[i]=[(x-z*y)%P for x,y in zip(a[i],a[rank])]
        pivots.append(col); rank+=1
        if rank==len(a): break
    return a,pivots

def inverse(a):
    n=len(a); b,piv=rref([a[i]+ident(n)[i] for i in range(n)])
    assert piv==list(range(n)), 'singular literal inverse'
    assert [r[:n] for r in b]==ident(n)
    return [r[n:] for r in b]

def determinant(a):
    # Independent Leibniz evaluation for the small minor.
    total=0
    for perm in itertools.permutations(range(len(a))):
        sign=(-1)**sum(perm[i]>perm[j] for i in range(len(a)) for j in range(i+1,len(a)))
        total += sign*math.prod(a[i][perm[i]] for i in range(len(a)))
    return total%P

def gauss(r,l,omega):
    if r+l>N-1: return 0
    value=1
    for k in range(1,r+1):
        value=value*(1-pow(omega,l+k,P))*INV[(1-pow(omega,k,P))%P]%P
    return value

def g(e,d,a,b):
    return gauss((e*a)%N,(d*b)%N,pow(Q,e*d,P))

def extract(a):
    return [[sum(a[(t+r)%N][t]*pow(Q,-b*t,P) for t in range(N))*INV[N]%P for b in range(N)] for r in range(N)]

def reconstruct(c):
    return [[sum(c[(k-t)%N][b]*pow(Q,b*t,P) for b in range(N))%P for t in range(N)] for k in range(N)]

def poly_for_support(nodes):
    # Elementary symmetric sums, not successive multiplication of linear factors.
    degree=len(nodes)
    return [((-1)**(degree-k)*sum(math.prod(c) for c in itertools.combinations(nodes,degree-k)))%P for k in range(degree+1)]

def evaluate(coeff,x):
    return sum(a*pow(x,k,P) for k,a in enumerate(coeff))%P

def residuals(h,c):
    return [sum(x*y for x,y in zip(row,c))%P for row in h]

def solve_vandermonde(nodes, values, first):
    # Values at first,...,first+m-1. Distinct nonzero nodes imply invertibility.
    m=len(nodes)
    rows=[[pow(x,first+i,P) for x in nodes]+[values[i]] for i in range(m)]
    red,piv=rref(rows)
    assert piv==list(range(m))
    return [row[-1] for row in red]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--candidate',type=Path,required=True); ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    raw=args.candidate.read_bytes(); assert hashlib.sha256(raw).hexdigest()==PIN
    z=ZipFile(io.BytesIO(raw)); names=z.namelist(); assert len(names)==len(set(names))
    manifest=json.loads(z.read('MANIFEST.json')); assert {r['path'] for r in manifest}==set(names)-{'MANIFEST.json'}
    for item in manifest:
        data=z.read(item['path']); assert len(data)==item['bytes']; assert hashlib.sha256(data).hexdigest()==item['sha256']
    # Only read data documents in the candidate. In particular never import or execute its .py entries.
    source_pins=json.loads(z.read('SOURCE_PINS.json'))
    for source in source_pins:
        data=z.read(source['copy'])
        assert len(data)==source['bytes'] and hashlib.sha256(data).hexdigest()==source['sha256']
    result={'candidate_sha256':PIN,'candidate_manifest_files_verified':len(manifest),'candidate_source_pins_verified':len(source_pins)}
    assert all(P%k for k in range(2,math.isqrt(P)+1))
    assert [pow(Q,k,P) for k in range(1,N)].count(1)==0 and pow(Q,N,P)==1
    result['field_and_root_order']='F23, ord(13)=11'

    # Dynamic ordered-monomial expansion independently checks the closed Gaussian formula.
    dc=0
    for omega in (Q,INV[Q]):
        coeff={(0,0):1}
        for degree in range(N+1):
            for r in range(degree+1):
                l=degree-r
                if degree<N:
                    assert coeff[(r,l)]==gauss(r,l,omega); dc+=1
                elif r==0 or l==0: assert coeff[(r,l)]==1
                else: assert coeff[(r,l)]==0; dc+=1
            nxt={}
            for (r,l),v in coeff.items():
                nxt[(r+1,l)]=(nxt.get((r+1,l),0)+v*pow(omega,l,P))%P
                nxt[(r,l+1)]=(nxt.get((r,l+1),0)+v)%P
            coeff=nxt
    result['quantum_binomial_identity_checks']=dc
    fmat=[[pow(Q,-k*t,P) for t in range(N)] for k in range(N)]
    target=extract(fmat); C=target[0][0]
    assert C==sum(pow(Q,-t*t,P) for t in range(N))*INV[N]%P==18
    f=[[pow(Q,3*(a+b)**2,P) for b in range(N)] for a in range(N)]
    assert all(target[a][b]==C*f[a][b]%P for a in range(N) for b in range(N))
    assert reconstruct(target)==fmat
    result.update(C=C,target_coefficient_checks=N*N)

    moments={}; forced={}; support_geometry_checks=0
    for b in (1,2):
        a=N-b
        supported=[(e,d) for e,d in itertools.product((1,-1),repeat=2) if g(e,d,a,b)]
        assert supported==[(-1,1)]
        amp=f[a][b]*INV[pow(4,(-a)%N,P)*g(-1,1,a,b)%P]%P
        forced[b]=amp
        vals=[]
        for a in range(b,N-b):
            assert g(1,-1,a,b)==g(-1,-1,a,b)==0
            assert g(1,1,a,b)!=0
            vals.append((f[a][b]-amp*pow(4,(-a)%N,P)*g(-1,1,a,b))*INV[g(1,1,a,b)]%P)
            support_geometry_checks+=1
        moments[b]=vals
    assert forced=={1:22,2:20}
    assert moments=={1:[19,4,20,14,20,3,14,16,8],2:[21,15,14,11,13,22,19]}
    H=[moments[b][k:k+7] for b in (1,2) for k in range(len(moments[b])-6)]
    reduced,piv=rref(H); assert piv==[0,1,2,3]
    minor=determinant([row[:4] for row in H]); assert minor==4
    result.update(forced_amplitudes=forced,moments=moments,H=H,homogeneous_rref=reduced,minor=minor,support_geometry_checks=support_geometry_checks)
    # Solve the independently derived affine equations; do not enter the stated family by hand.
    affine,apiv=rref([row[:6]+[-row[6]%P] for row in H]); assert apiv==[0,1,2,3]
    result['affine_rref']=affine
    family=[]; hist=Counter(); family_good=[]
    for u,v in itertools.product(range(P),repeat=2):
        c=[(row[-1]-row[4]*u-row[5]*v)%P for row in affine]+[u,v,1]
        assert residuals(H,c)==[0,0,0,0]
        roots=[x for x in range(1,P) if evaluate(c,x)==0]
        item={'coefficients_ascending':c,'nonzero_roots':roots,'parameters':[u,v],'zero_is_root':c[0]==0}
        family.append(item); hist[len(roots)]+=1
        if len(roots)==6: family_good.append(item)
    assert family==json.loads(z.read('AFFINE_SEXTIC_FAMILY.json'))
    assert len(family)==529 and not family_good
    result['sextic_root_histogram']={str(k):hist[k] for k in range(7)}
    result['affine_family_exact_candidate_rows_verified']=len(family)
    result['five_distinct_root_sextics']=[x for x in family if len(x['nonzero_roots'])==5]
    dump(args.out/'SEXTIC_FAMILY.json',family)
    print('Independent moments and all 529 affine sextics verified; no six-root sextic.',flush=True)

    # The second census derives every annihilator separately from its six nodes.
    reader=csv.reader(io.StringIO(z.read('ALL_SIX_NODE_SETS.csv').decode()))
    header=next(reader); assert header==[f'x{i}' for i in range(6)]+[f'c{i}' for i in range(7)]+[f'residual{i}' for i in range(4)]
    counts=[0]*5; final_three=[]; all_survivors=[]
    with (args.out/'SUPPORT_CENSUS.csv').open('w',newline='') as out:
        writer=csv.writer(out); writer.writerow(header)
        for nodes in itertools.combinations(range(1,P),6):
            c=poly_for_support(nodes); res=residuals(H,c)
            row=list(nodes)+c+res
            assert row==list(map(int,next(reader)))
            writer.writerow(row); counts[0]+=1
            for k in range(1,5):
                if not any(res[:k]): counts[k]+=1
            if not any(res[:3]):
                # Independent sufficiency checks for the truncated moment sequences.
                amps1=solve_vandermonde(nodes,moments[1],1)
                fit1=[sum(w*pow(x,a,P) for x,w in zip(nodes,amps1))%P for a in range(1,10)]
                assert fit1==moments[1]
                amps2=solve_vandermonde(nodes,moments[2],2)
                fit2=[sum(w*pow(x,a,P) for x,w in zip(nodes,amps2))%P for a in range(2,9)]
                assert fit2[:6]==moments[2][:6] and fit2[-1]!=moments[2][-1]
                assert (moments[2][-1]-fit2[-1])%P==res[-1]
                final_three.append({'nodes':list(nodes),'coefficients_ascending':c,'residuals':res,'b1_amplitudes':amps1,'b2_first_six_amplitudes':amps2,'b2_predicted_final_moment':fit2[-1]})
            if not any(res): all_survivors.append(list(nodes))
    assert next(reader,None) is None
    assert counts==[math.comb(22,6),3233,121,3,0]
    assert not all_survivors and json.loads(z.read('PAIR_COMPATIBILITY.json'))==[]
    result.update(support_prefix_survivors=counts,candidate_support_rows_verified=counts[0],final_b1_survivors=final_three,eligible_support_pairs=0)
    print('All 74,613 six-node sets independently verified; survivor counts:',counts,flush=True)

    # Explicit positive recurrence controls cover zero, repeated, empty and padded supports.
    control_specs=[('six_nodes',[(x,(3*x+1)%P) for x in (1,4,7,10,16,22)]),('three_nodes',[(2,5),(8,9),(19,1)]),('repeated_nodes',[(2,5),(2,9),(8,7),(8,16),(19,1)]),('zero_node',[(0,17),(3,4),(12,8)]),('empty',[]),('zero_only',[(0,5)])]
    controls=[]
    for name,terms in control_specs:
        combined={}
        for x,w in terms: combined[x]=(combined.get(x,0)+w)%P
        effective=sorted(x for x,w in combined.items() if x and w)
        padded=effective[:]
        for x in range(1,P):
            if len(padded)==6: break
            if x not in padded: padded.append(x)
        padded.sort(); h=poly_for_support(padded)
        seq=[sum(w*pow(x,a,P) for x,w in terms)%P for a in range(1,15)]
        rr=[sum(h[j]*seq[i+j] for j in range(7))%P for i in range(len(seq)-6)]
        assert not any(rr)
        controls.append({'name':name,'terms':terms,'effective_nonzero_nodes':effective,'padded_six_nodes':padded,'all_recurrences_zero':True})
    result['padding_controls']=controls

    # Formal reflection independently checked on all Weyl coefficients and literal banks below.
    for a,b in itertools.product(range(N),repeat=2):
        assert f[a][b]==f[-a%N][-b%N]
        for e,d in itertools.product((1,-1),repeat=2):
            assert g(e,d,a,b)==g(-e,-d,-a%N,-b%N)
    J=[[int(i==(-j)%N) for j in range(N)] for i in range(N)]
    S=[[int(i==(j+1)%N) for j in range(N)] for i in range(N)]
    T=[[pow(Q,j,P)*int(i==j) for j in range(N)] for i in range(N)]
    assert mm(mm(J,fmat),J)==fmat
    assert mm(mm(J,S),J)==matpow(S,N-1)
    assert mm(mm(J,T),J)==matpow(T,N-1)
    result.update(gaussian_reflection_checks=4*N*N,target_reflection_checks=N*N)

    # Literal resolvent controls, with no inverse formula assumed in matrix elimination.
    I=ident(N); weights=[(3*j*j+7*j+5)%P for j in range(N)]
    pairs=[(0,7),(7,0),(2,2),(4,6),(22,22)]
    literal=[]
    for e,d in itertools.product((1,-1),repeat=2):
        for alpha,beta in pairs:
            delta=(1-pow(alpha,N,P)-pow(beta,N,P))%P
            assert delta
            bank=[[0]*N for _ in range(N)]
            branch_count=0
            for j in range(N):
                A=[[ (I[k][t]-alpha*int(k==(t+e)%N)-beta*pow(Q,e*d*j+d*t,P)*int(k==t))%P for t in range(N)] for k in range(N)]
                B=inverse(A)
                assert mm(A,B)==I and mm(B,A)==I
                reflected=[[A[-k%N][-t%N] for t in range(N)] for k in range(N)]
                expected=[[ (I[k][t]-alpha*int(k==(t-e)%N)-beta*pow(Q,e*d*j-d*t,P)*int(k==t))%P for t in range(N)] for k in range(N)]
                assert reflected==expected
                for k,t in itertools.product(range(N),repeat=2): bank[k][t]=(bank[k][t]+INV[N]*weights[j]*B[k][t])%P
                branch_count+=1
            actual=extract(bank)
            for a,b in itertools.product(range(N),repeat=2):
                r,l=(e*a)%N,(d*b)%N
                amp=pow(beta,l,P)*INV[N]*INV[delta]*sum(weights[j]*pow(Q,e*d*j*l,P) for j in range(N))%P
                expected=pow(alpha,r,P)*g(e,d,a,b)*amp%P
                assert actual[a][b]==expected
            literal.append({'epsilon':e,'delta_sign':d,'alpha':alpha,'beta':beta,'denominator':delta,'branches_checked':branch_count,'coefficients_checked':N*N})
    result['literal_controls']=literal
    result.update(literal_inversions=sum(x['branches_checked'] for x in literal),two_sided_inverse_checks=2*sum(x['branches_checked'] for x in literal),literal_weyl_coefficient_checks=sum(x['coefficients_checked'] for x in literal))
    # Cross-check the candidate's mathematical fields after deriving them independently.
    candidate=json.loads(z.read('RESULTS.json'))
    assert candidate['C']==C
    assert candidate['forced_sector_amplitudes']=={str(k):v for k,v in forced.items()}
    assert candidate['gate_rref']==reduced and candidate['affine_rref']==affine
    assert candidate['first_four_column_minor']==minor
    assert candidate['last_three_b1_survivors']==[{k:x[k] for k in ('coefficients_ascending','nodes','residuals')} for x in final_three]
    result.update(verdict='ACCEPT',accepted_claim='b4(F23) >= 16 in the stated original-bank grammar with both effective cross-sign singleton alpha nodes pinned to 4',same_sign_distinct_nonzero_nodes_lower_bound=7,actual_original_bank_lower_bound=16)
    dump(args.out/'RESULTS.json',result)
    print(json.dumps({k:result[k] for k in ('verdict','literal_inversions','two_sided_inverse_checks','literal_weyl_coefficient_checks','accepted_claim')},indent=2),flush=True)

if __name__=='__main__': main()
