# Compact-window component: candidate certification argument

13 October 2026, revision 2. This argument accompanies new source, not historical code.
Independent source review is pending. It certifies a component contract; it is
not a complete all-length sparse-recovery implementation or a hardware proof.

## 1. Domain and exact mathematical object

The reduced component API accepts powers of two M and B, B >= 4, T = M/B >= 4,
r >= 1, P >= 8, ell = 8B, g = T/4, H = 3T/4, and
W = 2r(ell-1)+1 < M. All parameters are exact integers. Boolean substitutes,
nonintegral encodings, non-dyadic lengths, invalid precision and noncompact
support are rejected before construction. Invalid inputs are outside this
component contract. It has no source-vector argument, norm query or randomness.

The separate `theorem_spec(m, beta)` API requires an exact Fraction
0 < beta < 1/2, computes the accepted k and B ceilings exactly, and checks all
accepted E(beta) front-end sparse guards, r = 2m+1 and P = 16m+16.
It does not decide the outer all-length transfer dispatch: beta*m >= 2 and
t < M, along with the remaining outer predicates, are caller obligations. Supplying beta to `WindowSpec`
also enforces these parameters, so a reduced fixture cannot gain the
`ebeta_frontend_sparse_parameters` provenance label merely by selecting a string. A failed sparse guard is an
explicit unsupported-branch error, not a substitute for the theorem's dense
exceptional branch. This component does not implement that branch.

Write a_t for the coefficient of X^(t+r(ell-1)) in
(1+X+...+X^(ell-1))^(2r), and F_t = a_t/ell^(2r). The exact target is

    Phi_j = |sin(pi ell j/M)/(ell sin(pi j/M))|^(2r), Phi_0 = 1,
    C = sum_{j=-g}^g Phi_j,
    D_H(t) = sum_{u=-H}^H exp(2 pi i u t/M),
    w_t = M F_t D_H(t)/C.

D_H(t) is real and even. The returned taps are signed dyadics on grid 2^-P,
with enclosing intervals on grid 2^-(P+4) and checked absolute error <= 2^-P.
C itself is a certified enclosing interval, not a rounded scalar treated as exact.

## 2. Exact coefficients

The generator starts at [1] and performs 2r box convolutions. In a pass, the
running sum for the new position adds the old coefficient at the current index
when present and removes the old coefficient ell positions behind when present.
This is exactly multiplication by 1+X+...+X^(ell-1). The p-th vector has length
1+p(ell-1). Coefficients are nonnegative integers; symmetry and total sum
ell^(2r) follow by polynomial reflection and evaluation at X = 1.

No transcendental rounding enters this generator. Division by ell^(2r) remains
symbolic. Since ell is dyadic, F_t is exactly dyadic. The common coefficient
width is at most 2r log2 ell+1 bits. There is no length-M coefficient allocation.

## 3. Predetermined finite scalar evaluation

Let u = 2^-K and N = K+8. Pi is enclosed by
16 atan(1/5)-4 atan(1/239). Each alternating series uses exactly N terms.
Each rational term is rounded outward to the K-grid before summation. Its next
term bounds the alternating remainder, with sign. Thus the pi enclosure has
width at most 20(N+1)u and lies strictly between 3 and 4.

For sin(pi p/q), integers reduce p modulo 2q, fold the argument into [0,1/2],
and retain its sign. Integer and half-integer arguments return exactly 0 or +/-1.
This is important for numerator zeros and root singularities. No approximate
argument is used for zero detection. A nontrivial angle is bracketed on the
K-grid using the pi endpoints; a K-grid midpoint x is selected. It obeys
0 <= x <= 2. Its exact distance from the whole angle interval is at most the
integer radius computed in the source.

Sine at this point is enclosed by the first N odd Taylor terms. Term k is
obtained from term k-1 by multiplication by x^2/[(2k)(2k+1)], with outward
integer division. Since this multiplier is at most 2/3 and its subsequent
values decrease, each term interval has width at most 6u. Summation therefore
has width at most 6Nu. The sine remainder after degree 2N-1 is at most
2^(2N+1)/(2N+1)!: use the zero coefficient of degree 2N, then the real Taylor
remainder and |sin^(n)| <= 1. The program computes the factorial and checks
that this bound rounds upward to at most u. This always holds for K >= 16:
(2N+1)! >= N^(N+1), N >= 24, so the bound is already < 2^-K.

Sine is 1-Lipschitz on the real line. Widening the polynomial enclosure by the
computed angle radius therefore encloses the exact sine. Pi width, angle
rounding, Taylor interval width and the tail together are safely below
64(N+1)u; this bound is also checked. Intersection with [-1,1] preserves the
true value. No math.sin, float, Decimal transcendental, supplied root table,
refinement loop or tolerance-driven retry is used.

## 4. Fixed precision and division/power budget

Set

    rho = 2^-P,
    epsilon = rho/(16 M^3),
    J = P+11+6m+ceil(log2 r),
    K = J+2 bit_length(J+1)+16, N = K+8.

The elementary inequality 64(K+9) <= 2^(K-J) is checked by exact integers.
It holds for these domain parameters, giving every sine interval width

    e_s <= 2^-J <= epsilon/(128 r M^3).

For a nonzero residue modulo M, |sin(pi t/M)| >= 2/M. Its enclosing interval
therefore stays at least 1/M from zero: e_s < 1/M. The numerator is in [-1,1].
Corner evaluation and outward division yield width at most 4 M^2 e_s for a
sine quotient, including its K-grid rounding. Dividing by ell can only improve
the bound. The implementation still rejects an interval containing zero rather
than performing unsafe interval division; it is unreachable for these valid
nonzero window denominators. The t = 0 mod M Dirichlet case returns exactly
2H+1 before any division. A numerator at an exact zero returns zero directly.

The normalized box ratio is intersected with [-1,1]. Its even power is evaluated
from the absolute endpoint extrema using exact integer powers and one outward
rounding, not repeated unbounded rational-interval multiplication. On [-1,1],
x -> x^(2r) is 2r-Lipschitz. Therefore the Phi width before its output-grid
rounding is at most 8rM^2 e_s+2u. Intersect it with [0,1].

Each Phi is then rounded outward to the common grid
Q_C = P+9+4m, whose spacing is epsilon/(32M). Its resulting width is strictly
less than epsilon/(4M), checked as <=8 grid units. Add the positive j terms and
double their integer endpoints; Phi_0 = 1 exactly. C width is <=epsilon/4,
and in particular <=epsilon, with 1 <= C <= 2g+1. All cross-coordinate
accumulation uses this one denominator. There is no product of unrelated
rational denominators across T terms.

Each D_H is rounded to grid Q_D = P+8+3m, spacing epsilon/16. Its width is
at most 4M^2 e_s+epsilon/8 < epsilon. Intersect with the exact bound
[-(2H+1),2H+1]. Each scalar computation has predetermined finite loop lengths.
The checked bounds are assertions of the candidate implementation, not allowed
probabilistic aborts in a claimed full E(beta) engine.

## 5. Tap error, symmetry and normalization

The final quotient uses the exact F coefficient and the four corners of the
C and D intervals. C >= 1, |D| <= M and F <= 1. Its width before output-grid
rounding is at most

    M epsilon + M^2 epsilon <= 2M^2 epsilon = rho/(8M).

Rounding its two endpoints outward to the (P+4)-grid adds at most rho/8.
Rounding the interval midpoint nearest-even to the P-grid adds at most rho/2
to the error from the midpoint, so total absolute error is strictly below rho.
For every returned tap, the code checks the maximum distance to both stored
endpoints in exact integer units; <=16 units on grid 2^-(P+4) proves <=rho.
Negative half ties are handled by floor quotient and a nonnegative remainder.
Only nonnegative taps require evaluation. Reflection copies the exact same
signed dyadic and enclosure, enforcing evenness without changing the target.

The normalization is essential. The unnormalized Fourier transform of F is
Phi. Multiplication by D_H convolves that response with the interval indicator.
Consequently

    (1/M) sum_t w_t exp(-2 pi i jt/M)
      = sum_{u=-H}^H Phi_(j-u)/C = G_j.

Omitting M would return G_j/M, which the negative controls decisively reject.
For actually rounded taps, every response differs from G by at most W rho/M,
by the triangle inequality. This bound concerns all frequencies; the executable
DFT response checks use selected boundary frequencies and the exact per-tap
certificate establishes the general bound.

## 6. Window bounds and reduced fixtures

From ell g = 2M, for circular distance |j|_M >= g the normalized sine ratio
has magnitude at most 1/4 and Phi_j <= 16^-r. Since 2H+1 < M, the circular
interval has no repeated residues. A passband shifted interval contains the
core [-g,g]. Its response is exactly 1 plus a nonnegative extra sum divided by
C. A stopband interval has every point outside the core. Thus, with
Delta = (2H+1)16^-r,

    1 <= G_j <= 1+Delta,  |j|_M <= T/2;
    0 <= G_j <= Delta,    |j|_M > T;
    0 <= G_j <= 1+Delta,  every j.

These are exact component bounds. In the accepted r = 2m+1 case, Delta <= M^-4.
Some reduced r fixtures also satisfy this last numerical inequality; that alone
does not make them valid sparse recovery parameters. Tests record both flags.
The tests certify the lower passband bound by exact core-set containment and
nonnegative extra intervals, avoiding a floating tolerance at equality one.
Every frequency's upper pass/stop bound is checked with rational intervals and
zero inequality slack. Reference-coordinate uncertainty remains enclosed.

## 7. Work, width and storage model

See RESOURCE_LEDGER.md. Exact integer arithmetic, finite scalar loops,
coefficient cells, divisions, powers, allocations, special-root cases and
returned taps are instrumented. The ledger includes conservative binary
schoolbook work and cumulative-storage envelopes. This is an explicitly
charged mathematical model; Python object headers, allocator behavior, OS
memory and instruction scheduling have not been certified. Independent review
must assess source fidelity and the conservative bookkeeping envelope.

For fixed beta and accepted E(beta) front-end sparse parameters, r = O(m), P = O(m), K = O(m), ell = O(B),
W = O(Bm), and T <= B. Exact coefficient operations number O(r^2 ell).
There are O(T+W) scalar evaluations, each with O(K) Taylor/factorial operations,
plus O(log r) integer multiplications for endpoint powers. Maximum numeric
intermediates have polynomial bit width, bounded by
O(r log ell + rK + K log K + P + m); in the accepted regime this is O(m^2).
For fixed beta, every instrumented operation and the cumulative-storage charge
fit O((B+T) poly(m)). This fixed-beta statement must not be used as a uniform
per-call bound independent of an arbitrarily long supplied beta encoding. The
standalone v2 input-width-aware bound is stated below. The implementation is not claiming a sublinear host runtime
for its feasible fixtures, and it does not execute at the huge accepted
crossover.


## 8. Revision 2: complete standalone validation charge

The independent v1 review accepted the numerical component and found R1: the
standalone call performed validation before starting its ledger, omitting
arbitrarily wide beta fields. V2 changes the accounting and interface wording;
sections 2–6 and the numerical formulas are unchanged.

`prepare_window` now creates or adopts its ledger before calling
`spec.validate(ledger)`. Validation records M, B, r and P, and, when present,
beta's normalized Fraction numerator and denominator, before using them in
parameter arithmetic. All product, division, subtraction, addition, modulo
and binary-power calculations of validation use the charged primitives.
`theorem_spec` also starts its ledger before checking its inputs and passes it
through validation. Revalidation during preparation is genuine repeated work
and is charged again; shared ledgers accumulate it rather than reset or deduct
it. These are upper charges, so counting a retained input again is safe.

Let h be the maximum bit width of beta's two integer fields (zero if absent),
and let U be the maximum observed width over parameters and every validation
primitive's operands/results. In the accepted front-end regime U is
O(h+m+log(m+1)); validation has a fixed number of primitive operations, with no
loop proportional to beta's value. On a successful beta-bearing validation,
there are 36 ledger events: six parameter records, two validation events,
12 multiplications, six subtractions, four additions, three floor divisions,
one modulo and two binary powers. Six input records explicitly charge reading
and retaining both beta fields as well as the four window parameters. The
schoolbook data charge therefore includes O((h+m)^2) validation bit work and
all its produced-integer storage, not an h-independent constant.

The uninstrumented validation logic is finite bounded control: fixed-arity
field/type checks, comparisons, two power-of-two bit tests, bit lengths and
method/tuple bookkeeping. There is no hidden arbitrary-precision Fraction
arithmetic: beta validity is checked by its recorded numerator sign and the
charged integer comparison against twice that numerator. This control uses
only the observed U-bit integers and fixed-size tags. Its fixed operation
count is below the source-model envelope 512 E L^2, where E includes the new
validation events and L >= U+bit_length(E)+2. Cumulative storage is likewise
charged with this enlarged L; validation temporaries and retained input fields
are no longer absent. This is a conservative finite-arithmetic source model,
not a claim about a verified Python compiler or actual allocator bytes.

The existing whole-call envelope intentionally uses the largest width globally.
Consequently a safe uniform standalone bound, when beta is supplied as part of
the input and E(beta) front-end parameters hold, is

    O((B+T) poly(m+h)) bit work and cumulative charged storage.

It may overcharge the subsequent h-independent numerical preparation. When beta
is fixed, h is fixed and the accepted O_beta((B+T) poly(m)) shape is unchanged.
No restriction on h was added to make the defect disappear. Reduced fixture
r/P values retain their explicit measured costs and the general width formula
in section 7 rather than acquiring the front-end O(m) parameter assumptions.

The API accepts an already represented Python Fraction, like it accepts already
represented integers. Reading/validating/retaining its fields is charged here;
parsing an external file or constructing that input object before the call is
not executed by this API. This is not a prevalidated mathematical-beta loophole:
its range and all front-end parameter equalities are checked inside the call.

The regression uses the exact review witness beta_n=1/4-2^-n with fixed
(M,B,r,P)=(2^46,2^35,93,752) for n=16,128,4096,65536. Validation work/storage
charges grow with n and observe its n+1-bit denominator. An intercepted call
stops at the coefficient-generator entry to verify that a fresh standalone
preparation ledger already contains the complete validation charge. No huge
coefficient array is allocated. Shared-ledger tests verify retained constructor
work and charged repeated validation. The original tap/C/budget data remain
exactly unchanged, and fresh near-support-boundary windows receive independent
rational tap checks.
