# Independent rereview of Q16 compact window revision 2

Date: 13 October 2026.

## Decision

**ACCEPT for the pinned compact-window component and its stated finite-arithmetic source-level accounting model.** Revision 2 closes R1, the missing standalone beta-validation width charge, and resolves C1, the front-end versus outer-dispatch interface ambiguity.

This acceptance preserves the original scope. It covers exact box coefficients, certified scalar and normalizer calculations, Dirichlet factors, signed taps for M F_t D_H(t)/C, their error certificates, and the explicit preparation cost model. It does not certify complete E(beta) recovery, bucket FFTs, the outer sparse-transfer algorithm, all-length execution, a tensor engine, historical executables, real-machine totality or practical speed.

The v1 archive, source and sealed split verdict remain unchanged. V1's overall REPAIR verdict is not retroactively relabeled. This acceptance applies to the separate v2 source hash below.

## Reviewed immutable inputs

- V2 candidate archive: Q16_Certified_Compact_Window_Candidate_v2_2026-10-13.zip
- V2 candidate Library identity: libfile_cd9e8245dd4c8191843cdb960d779379, version 1.
- V2 archive SHA-256: e587382179dd843136053322db5ed1a15165066d1e7330b9fb036e14c3fb4c7e
- V2 production source SHA-256: e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59
- V2 manifest SHA-256: 9f67ca72b3d9259092fd7b883cc0334441706e3be150a5c36d8b0680af98e0b7
- V1 to v2 source diff SHA-256: 23da3932347b760f4d0e3f0b2472cc5f39a10a55890ea11ea84c59578d336416
- V1 candidate SHA-256: 3c37d2d9339301cb3ae35be3c18b2f9ca8a16a9f2eddcbaf258ba40a2969f745
- V1 independent review archive SHA-256: 9fe26440bc1bd55c0db93e2857dbd49b5018e168c6d6528f7f9d776423af5614
- V1 independent review Library reference: libfile_9f35ab942ec881919b1a78c5daeb97ec

The new archive, all 27 manifest files, source and exact diff were verified before replay. Replay used a separate copy. Production files were not patched by this reviewer. The v2 packet's retained v1 source and report match the previously sealed hashes.

## R1 is closed

In v1, prepare_window validated its spec before starting its ledger and never recorded beta's numerator or denominator. The family beta_n=1/4-2^-n gave unbounded validation widths at fixed window parameters and fixed reported preparation charges.

V2 starts or adopts its ledger before validation. WindowSpec.validate records M, B, r and P, then validate_beta records both normalized Fraction integer fields. Beta range checking uses the recorded numerator and a charged multiplication by two. The B and k ceiling computations, support calculation and expected r/P formulas use the charged arithmetic primitives. No arbitrary-width Fraction arithmetic remains hidden in validation. Theorem-spec construction also records inputs before arithmetic and passes its ledger into validation.

The added fields parameter_input_bits and max_parameter_bits expose the input charge. Parameter records also enter the existing observed-width maximum, arithmetic work and produced-integer storage. Consequently the global bookkeeping and storage envelopes include beta width even when a caller directly constructs WindowSpec(..., beta) and calls prepare_window without a prior theorem_spec ledger.

Repeated validation performs real work and is charged again. Shared ledgers retain earlier parameter-generation charges rather than reset or deduct them. An already represented Fraction is the input contract; creating or parsing that object before the call is not execution by this API. This is a normal representation boundary, not an uncharged prevalidated-beta exception: range and parameter equalities are still checked inside preparation.

## Fresh independent accounting regressions

The reviewer wrote and ran 181 accounting/interface checks, separate from the producer's repair tests. They include ten growing-width witnesses from two families:

1. beta_n = 1/4 - 2^-n, with (m,B,r,P) = (46,2^35,93,752).
2. beta_n = 1/100 - 1/(3*2^n), with (m,B,r,P) = (100,2^51,201,1616). This family retains odd factors in the denominator and is not a dyadic-only control.

For both families n = 16, 128, 4096, 65536 and 131072. All relevant front-end guards hold. The actual prepare_window entry was intercepted immediately before coefficient construction; the prefix had to expose the complete validation charge. No gigantic coefficient or tap array was allocated.

The same interception on v1 reproduces its constant reported prefix despite growing beta width. V2's fresh standalone prefix exactly matches separately charged validation. Every parameter-read bit total was checked independently, each primitive's 16-times-squared-width charge was recalculated, and the control/storage reports were reconstructed from their event counts, trace widths and produced-integer widths.

A successful beta-bearing WindowSpec validation has exactly 36 events: six parameter records, two validation events, twelve multiplications, six subtractions, four additions, three floor divisions, one modulo and two binary powers. The runtime inventory matches the revised argument. No coefficient-cell, allocated-slot or sine-evaluation event appears before the interception point.

For the dyadic family's n=131072 case, the denominator is 131073 bits, the observed maximum is 131079 bits, and the parameter-read total is 262243 bits. Its validation work allowance is 2,583,184,306,002,512 model units and cumulative storage allowance is 19,599,921,657 model bits. For the odd-denominator family's same n, the corresponding denominator and observed maximum are 131079 and 131085 bits. These are intentionally loose accounting quantities, not measured instruction counts or allocated bytes.

Direct repeated validation doubles its primitive charges and parameter-read totals. Shared theorem_spec/preparation calls show exact primitive-charge and event additivity. Invalid types, boolean substitutes, invalid beta ranges, non-dyadic lengths and noncompact support remain rejected. These finite checks corroborate the source argument; arbitrary input widths are covered by the source-level reasoning below rather than extrapolation from five tested sizes.

## Universal width and bookkeeping assessment

Let h be the maximum bit width of beta's two fields. Validation now observes those fields and every data-arithmetic operand/result. Its fixed operation inventory uses widths O(h+m); no loop depends on beta's numerical value or encoding length except the charged binary arithmetic itself. The formerly unbounded hidden operation is therefore gone.

The uninstrumented validation work consists of bounded field/type checks, comparisons, power-of-two tests, bit lengths and fixed-size bookkeeping. It operates on already observed widths. The source has no hidden Fraction normalization or gcd inside this path. The documented fixed validation control fits the existing conservative envelope.

The unchanged numerical component retains its original loop accounting: coefficient cells, scalar terms, factorial steps, supported taps, mirrored copies and initialized slots all contribute events. The remaining fixed-arity scalar and ledger bookkeeping works at the observed data width plus counter/address width. Tuple copying and output scans are bounded by counts already present in allocation/tap events. Adding beta to the global width thus enlarges both 512 E L² control work and 512 E L cumulative-storage allowances wherever needed. No separate h-independent validation term is silently assumed.

This review accepts that conservative finite-arithmetic source model. It is not a verified Python bytecode, allocator or instruction-level bound. Metadata has fixed field count, not uniformly bounded bit width: beta's variable-width fields are explicitly charged. Cumulative storage is an upper charge rather than a peak-memory measurement.

The accepted uniform standalone shape is O((B+T) poly(m+h)) for E(beta) front-end parameters. Numerical preparation itself is unchanged: r, P and K are O(m), W=O(Bm), and its arithmetic intermediates have polynomial m-bit width. A globally enlarged ledger may overcharge later arithmetic that does not depend on h. For fixed beta, h is fixed, giving the separate O_beta((B+T) poly(m)) statement. No artificial cap on beta encoding width was introduced.

## C1 is closed without expanding dispatch scope

The origin label is now ebeta_frontend_sparse_parameters. The theorem_spec docstring and README explicitly leave outer beta*m>=2 and t<M conditions with the caller.

The independent test still observes theorem_spec(100, Fraction(1,100)) succeeding with beta*m=1. This is expected front-end eligibility and explicitly does not authorize the outer sparse-transfer branch. The odd-denominator witness family supplies further beta*m<2 examples. The API does not accept the outer transfer parameters needed to decide that branch, nor does the review infer them.

## Numerical preservation and replay

An AST comparison finds only the intended changed existing definitions: Ledger, WindowSpec, theorem_spec and prepare_window, plus the new validate_beta function. The preparation body from its numerical M assignment onward is structurally identical to v1. The coefficient, sine, interval, quotient, power, Dirichlet and rounding implementations are unchanged.

The original 488 checks replayed successfully, including 2,856 taps and 5,504 zero-slack pass/stop frequencies. Every original fixture's exact C interval, taps, certificates, spec and precision budget matches v1 bit-for-bit. Changed ledgers and elapsed fields were deliberately compared separately.

The producer's 46 repair controls also replayed, including its 622 additional directly referenced taps. Independently, the previously sealed alternate-pi rational oracle was rerun against the frozen v2 source, with only input pins, paths and the corresponding no-wrap mutation target adapted. It retains the six fresh window cases and all original independent boundary/mutation tests. The replay passed all 16 groups: 2,216 fresh taps, 1,875 sine enclosures, 1,728 Dirichlet comparisons, 3,600 signed quotient cases, 67,617 rounding cases, 891 quantization intervals, 2,244 even-power cases, guard enumerations and all six targeted mutants. Receipts are recorded in REVIEW_VERDICT.json and independent_results.json.

The numerical acceptance still requires the exact M factor, common C grid, exact sine and Dirichlet singular handling, signed nearest-even rounding, W<M support and the per-tap rho certificate. Rounding gives the same general response bound W*rho/M. Numerical Fourier identity checks remain sampled evidence; the convolution identity and tap certificates supply the all-frequency argument.

## Huge crossover and remaining implementation boundary

The first beta=1/4 front-end sparse eligibility is still m=46:

    M = 70,368,744,177,664
    B = 34,359,738,368
    W = 51,127,290,691,399

Only parameter checks and intercepted prefixes were executed there. No large window preparation or sparse recovery ran. All numerical fixtures remain reduced component cases. The repair establishes no useful crossover, runtime speed advantage, host-memory guarantee or full-pipeline completion.

## Sealed evidence and reproduction

The review package contains this report, machine-readable verdict, exact source pins, the independent regression sources and receipts, replay receipts and the frozen v2 archive. The sealed v1 review is retained as predecessor evidence. Extract the candidate archives alongside the review directories before rerunning; verify their original manifests first and use copies for tests that rewrite receipts.

No production repair was authored by the reviewer. No repository, external sheet, publication, permission or research-score state was changed. The only new deliverable is the private review packet. Its manifest and seal bind this acceptance to the exact frozen source.
