# One missing production regression

**Name:** Odd-exponent/minimum-residue outer coefficient regression.

**Present status:** NOT RUN. No production outer wrapper is included. This document specifies a future bounded test; it is not execution authorization.

## Prerequisites and exact target

Independently review and pin the new wrapper, its signed-power implementation, scalar dependency, enumerator, ledger, fixture, and launcher. Preserve the existing accepted compact-window bytes or review any modified dependency separately. Inspect the actual source before execution to rule out a loop or allocation over all N or M, since the fixture deliberately uses large mathematical lengths.

Use D=5, m=57, M=2^57, N=2^55-1, s=285, h=4561, t=9124, q=floor(M/(8s)), J=587, K=623, p=459, eta=2^-456. The accompanying metadata also pass the theorem's sparse guards at beta=1/8, but the test runs no theorem-sized front end and allocates no N-vector. Exact decimal fixture values are in FRESH_RECOVERY_RESULTS.json.

Use a four-element frozen support tuple formed by sorting {0,1710,k_near,M-1}, where

    ell_near=(N+1)/4=2^53,
    k_near=(ell_near*M-1)/N=2^55+1.

First enumerate its incidences using the actual production enumerator, stream records, and check exact row-first retention membership with integer arithmetic. Do not run coefficient evaluation for every enumerated record in this bounded regression. Evaluate only the following three selected incidence records through the actual production coefficient subroutine:

1. (ell,k)=(0,0): exact Dirichlet zero limit; no division by a sine interval containing zero.
2. (ell,k)=(2^53,2^55+1): ell*M-k*N=1, the smallest nonzero residue; this is the sharp denominator case.
3. (ell,k)=(0,1710): the normalized D_q factor is negative and s=285 is odd. The old even_power API must not be used. This control is an operator/sign test; do not claim its sign alone exceeds eta at the final coefficient.

In the same frozen run, directly test the wrapper's actual signed-power primitive at K=623 on the interval [-1/2,-1/4] with s=285. Its exact outward K-grid integer endpoints are provided in the result JSON and are both strictly negative. Replacing signed power by absolute power or the historical even-only helper must fail this regression.

## Required evidence and success condition

- Verify record binding, parameters, exact indices, fixed precision, preserved signed powers, and each integer squared-radius certificate.
- Enclose each selected true coefficient using a separately authored rational oracle with a different pi identity and independently derived error control; for example pi=4*atan(1/2)+4*atan(1/3), at independently sufficient guard precision. Sharing the production Scalar or its output as the oracle is insufficient.
- Show that the production Cartesian enclosures contain the oracle's tighter guaranteed enclosure, or use an equally rigorous exact enclosure comparison. Confirm absolute complex error <=eta without floating tolerances.
- Retain paid setup, sine-call, power, endpoint, validation, output-certificate, and control/width records. The selected coefficient evaluations need at most five sine calls each; zero/half-integer shortcuts may lower this. Bind this bounded evaluation scope explicitly; it is not a complete four-support coefficient stream run.
- Include an empty-support call proving that no pi/sqrt setup occurs while header validation is still charged. A static source audit is necessary to establish the absence of a hidden N-row pass; timing a large-N call alone is insufficient.
- Freeze pre/post hashes and retain normal process-exit evidence under declared finite resource caps. A cap failure is a resource blocker, not a scientific pass or the theorem's allowed random failure.

Success closes this sharply targeted production coefficient/iterator regression only. Full stream integration, all-length dispatch, accumulation/scale-back, and amplification still need their own proofs and source-pinned gates.
