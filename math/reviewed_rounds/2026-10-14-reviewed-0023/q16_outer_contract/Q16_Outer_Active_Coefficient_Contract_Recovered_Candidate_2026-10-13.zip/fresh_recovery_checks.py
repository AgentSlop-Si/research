"""Fresh exact finite checks for the recovered Q16 outer contract.

Only this newly written file is executed. Historical programs are inert bytes/AST.
No scientific production wrapper, coefficient integration, or transcendental runs.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from math import factorial, isqrt
from pathlib import Path
import ast
import json

ROOT = Path(__file__).resolve().parent
counts = Counter()

def insist(group, value):
    counts[group] += 1
    if not value:
        raise AssertionError((group, counts[group]))

def ceil_ratio(a, b):
    return -((-a) // b)

def lifted(N, M, h, k):
    start = ceil_ratio(N * (k-h-1), M)
    stop = ceil_ratio(N * (k+h+1), M)
    return [r % N for r in range(start, stop)]

source = (ROOT / 'evidence/accepted/compact_window.py.txt').read_bytes()
source_hash = sha256(source).hexdigest()
pins = json.loads((ROOT / 'evidence/accepted/COMPACT_SOURCE_PINS.json').read_text())
pinned = next(x for x in pins['candidate_files'] if x['path']=='src/compact_window.py')
insist('source_pins', source_hash == pinned['sha256'] == 'e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59')
theorem_hash = sha256((ROOT/'evidence/accepted/ALL_LENGTH_THEOREM.md').read_bytes()).hexdigest()
insist('source_pins', theorem_hash == '0a7733e2ac1d1c32cf70609ba0db151a13a73765107907aec44045daaf0a58f5')
observer_hash = sha256((ROOT/'evidence/accepted/OBSERVER_V2_ACCEPTANCE.md').read_bytes()).hexdigest()
insist('source_pins', observer_hash == '5b4020fa5a04b5900a73d5055c1151ba52f2e1be397a396f95e96a9ae81df191')
tree = ast.parse(source)
power_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name=='even_power')
guard = next(n for n in power_node.body if isinstance(n, ast.If))
insist('source_pins', isinstance(guard.test, ast.BinOp) and isinstance(guard.test.op, ast.Mod)
       and isinstance(guard.test.left, ast.Name) and guard.test.left.id=='n'
       and isinstance(guard.test.right, ast.Constant) and guard.test.right.value==2
       and any(isinstance(n,ast.Raise) for n in guard.body))

cases = 0
mutants = {}
for N in range(1,49):
    M = 1 << (4*N-1).bit_length()
    for h in sorted(set(range(min(13, M//2-1))) | {M//2-2}):
        insist('enumeration', 2*h+2 < M)
        reference = [set() for _ in range(M)]
        for row in range(N):
            for offset in range(-h,h+2):
                reference[(row*M//N + offset) % M].add(row)
        for k in range(M):
            found = lifted(N,M,h,k)
            cases += 1
            insist('enumeration', set(found)==reference[k])
            insist('enumeration', len(found)==len(set(found)))
            insist('enumeration', len(found)<=ceil_ratio(N*(2*h+2),M))
            low = ceil_ratio(N*(k-h-1),M)
            for name,stop in [('upper_floor',N*(k+h+1)//M),
                              ('upper_closed',N*(k+h+1)//M+1)]:
                wrong={r%N for r in range(low,stop)}
                if wrong != reference[k] and name not in mutants:
                    mutants[name]=dict(N=N,M=M,h=h,k=k,correct=sorted(reference[k]),wrong=sorted(wrong))
insist('mutant_detection', set(mutants)=={'upper_floor','upper_closed'})

power_cases = 0
for bits in range(1,5):
    U = 1 << bits
    for left in range(-U,U+1):
        for right in range(left,U+1):
            for s in (1,2,3,5,10,285):
                endpoint_values=[F(left,U)**s,F(right,U)**s]
                if left<=0<=right:
                    endpoint_values.append(F(0))
                exact_low,exact_high=min(endpoint_values),max(endpoint_values)
                if s%2:
                    num_low,num_high=left**s,right**s
                else:
                    a=0 if left<=0<=right else min(abs(left),abs(right))
                    b=max(abs(left),abs(right))
                    num_low,num_high=a**s,b**s
                den=1 << (bits*(s-1))
                lo,hi=num_low//den,ceil_ratio(num_high,den)
                insist('signed_power', F(lo,U)<=exact_low<=exact_high<=F(hi,U))
                insist('signed_power', F(hi-lo,U)<=s*F(right-left,U)+F(2,U))
                power_cases += 1

# Independent exact rational corners for the refined normalized quotient estimate.
ratio_cases=0
for Q in (4,17,64,257):
    e=F(1,32*Q)
    for c in (1,3,8):
        for f in (F(-1), F(-2,3), F(0), F(1,7), F(1)):
            b=F(2,Q)
            a=c*b*f
            corners=[]
            for da in (-e/2,e/2):
                for db in (-e/2,e/2):
                    value=(a+da)/(c*(b+db))
                    corners.append(value)
                    insist('normalized_ratio', abs(value-f)<=2*Q*e)
            insist('normalized_ratio', max(corners)-min(corners)<=4*Q*e)
            ratio_cases+=1

budget_cases=0
for D in (5,7,12,63):
    for m in list(range(2,258))+[511,1024,4096]:
        s=D*m; A=(D+3)*m; M=1<<m
        J=(D+5)*m+s.bit_length()+8
        K=J+2*(J+1).bit_length()+16
        insist('precision', K>=A+3 and K>=m and K>=16)
        insist('precision', 64*(K+9)<=1<<(K-J))
        insist('precision', 4*(s+1)*(1<<(2*m+A+6))<=1<<J)
        insist('precision', 6*s+26 <= (s+1)*M*M)
        insist('precision', M*M//4<1<<J)
        budget_cases+=1
insist('precision', 2*9*9<128*128)

scalar_bound_cases=0
for K in list(range(16,81))+[127,255,511,623,1024]:
    n=K+8
    insist('scalar_bounds', F(20*(n+1),1<<K)<F(1,100))
    insist('scalar_bounds', (1<<(K+2*n+1))<=factorial(2*n+1))
    insist('scalar_bounds', 16*n+15<=64*(n+1))
    scalar_bound_cases+=1
insist('scalar_bounds',16*(F(1,5)-F(1,3*5**3))-F(4,239)>F(31,10))

round_cases=0
for gap in range(0,6):
    div=1<<(gap+1)
    for a in range(-36,37):
        for b in range(a,37):
            v,rem=divmod(a+b,div)
            z=v+(2*rem>div or (2*rem==div and v%2==1))
            # Separate nearest candidates based on exact rational distances.
            target=F(a+b,div)
            distances={w:abs(w-target) for w in (v-1,v,v+1,v+2)}
            best=min(distances.values())
            winners=[w for w,d in distances.items() if d==best]
            expected=next((w for w in winners if w%2==0),winners[0])
            insist('signed_rounding', z==expected)
            insist('signed_rounding', abs(z-target)<=F(1,2))
            round_cases+=1

sqrt_cases=0
for N in range(1,97):
    M=1<<(4*N-1).bit_length()
    for K in (16,31,64):
        Z=(M<<(2*K))//N
        lower,upper=0,1<<(K+2)
        for _ in range(K+2):
            middle=(lower+upper)//2
            if middle*middle<=Z: lower=middle
            else: upper=middle
        insist('sqrt', lower==isqrt(Z) and upper-lower==1)
        insist('sqrt', lower*lower*N<=M*(1<<(2*K))<=(lower+1)**2*N)
        sqrt_cases+=1

D=5; m=57; M=1<<m; N=M//4-1; s=D*m; h=16*s+1; t=2*h+2
q=M//(8*s); ell=(N+1)//4; near_k=(ell*M-1)//N; negative_k=6*s
B=1<<ceil_ratio(5*m,8); sparse_k=1<<ceil_ratio(m,4); r=2*m+1
W=2*r*(8*B-1)+1; J=(D+5)*m+s.bit_length()+8; K=J+2*(J+1).bit_length()+16
insist('odd_fixture', s==285 and s%2==1)
insist('odd_fixture', 4*N<=M<8*N and M==1<<(4*N-1).bit_length())
insist('odd_fixture', B>=4 and M%B==0 and M//B>=4 and B>=4096*sparse_k and W<M and t<M and m>=16)
insist('odd_fixture', ell*M-near_k*N==1 and ell in lifted(N,M,h,near_k))
insist('odd_fixture', 0 in lifted(N,M,h,negative_k) and M<(2*q+1)*negative_k<2*M)
insist('odd_fixture', ((M//2+1)*negative_k)//M==855)
insist('odd_fixture', ((M//2+1)*negative_k)%M>0)
U=1<<K
sentinel=[-(U//2),-(U//4)]
signed=[sentinel[0]**s//(1<<(K*(s-1))),ceil_ratio(sentinel[1]**s,1<<(K*(s-1)))]
insist('odd_fixture', signed[0]<signed[1]<0)

result = dict(status='PASS_FRESH_RECOVERY_ALGEBRA_CONTROLS',assertions=sum(counts.values()),groups=dict(counts),
              incidence_cases=cases,signed_power_cases=power_cases,ratio_cases=ratio_cases,
              precision_cases=budget_cases,scalar_bound_cases=scalar_bound_cases,
              signed_rounding_cases=round_cases,sqrt_cases=sqrt_cases,
              endpoint_mutants=mutants,
              source_hashes=dict(compact_window=source_hash,theorem=theorem_hash,observer_acceptance=observer_hash),
              decisive_fixture=dict(D=D,m=m,M=M,N=N,s=s,h=h,t=t,q=q,J=J,K=K,p=(D+3)*m+3,
                   beta='1/8',B=B,sparse_k=sparse_k,r=r,W=W,
                   closest_nonzero=dict(ell=ell,k=near_k,n_u=1,Q=N*M),negative_ratio=dict(ell=0,k=negative_k),
                   signed_power_sentinel=dict(grid_bits=K,lo=str(sentinel[0]),hi=str(sentinel[1]),
                                              expected_lo=str(signed[0]),expected_hi=str(signed[1]))),
              executed_historical_programs=False,production_wrapper_executed=False,
              old_control_receipt_replayed=False,theorem_sized_arrays_allocated=False,
              external_writes=False,scope='New exact finite algebra and data-only source checks; not production numerical integration or independent static acceptance.')
(ROOT/'FRESH_RECOVERY_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','assertions','groups','incidence_cases','signed_power_cases','ratio_cases','precision_cases','scalar_bound_cases','signed_rounding_cases','sqrt_cases')},indent=2))
