"""New local-only integrity sealer. Does not execute scientific code."""
from hashlib import sha256
from pathlib import Path
import json
import zipfile

root=Path(__file__).resolve().parent
archive=root.parent/'Q16_Outer_Active_Coefficient_Contract_Recovered_Candidate_2026-10-13.zip'

def digest(data): return sha256(data).hexdigest()
def write_json(path,data): path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

roles={
 'evidence/accepted/compact_window.py.txt':'Pinned accepted compact-window source, inert bytes/AST only; its even_power API is not the required outer signed-power API.',
 'evidence/accepted/COMPACT_SOURCE_PINS.json':'Prior accepted review source-pin receipt.',
 'evidence/accepted/COMPACT_V2_ACCEPTANCE.md':'Historical accepted component scope; not a new replay.',
 'evidence/accepted/COMPACT_CERTIFICATION.md':'Prior component proof, read as text.',
 'evidence/accepted/ALL_LENGTH_THEOREM.md':'Recovered accepted mathematical theorem; inherited interpolation/transfer context.',
 'evidence/accepted/OBSERVER_V2_ACCEPTANCE.md':'Accepted bounded observer-v2 result and explicit outer-stage exclusions.',
 'evidence/interrupted/CONTRACT.md':'Interrupted candidate contract before recovery repairs.',
 'evidence/interrupted/PROOF.md':'Interrupted candidate proof before reconstruction.',
 'evidence/interrupted/CONTROL_RESULTS.json':'Prior worker receipt; not authenticated as a fresh execution in this recovery.',
 'evidence/interrupted/fresh_controls.py.txt':'Prior worker check source, preserved inert; never run by this recovery.'
}
bindings=[]
for rel,role in roles.items():
    data=(root/rel).read_bytes()
    bindings.append(dict(path=rel,bytes=len(data),sha256=digest(data),role=role))
write_json(root/'SOURCE_BINDINGS.json',dict(date_utc='2026-10-13',inputs=bindings,
          historical_code_execution=False,external_writes=False))

result=json.loads((root/'FRESH_RECOVERY_RESULTS.json').read_text())
write_json(root/'STATUS.json',dict(status='CANDIDATE_READY_FOR_INDEPENDENT_STATIC_REVIEW',
    date_utc='2026-10-13',fresh_assertions=result['assertions'],
    fresh_checker_sha256=digest((root/'fresh_recovery_checks.py').read_bytes()),
    incidence_argument='reconstructed; candidate pending independent review',
    precision_argument='reconstructed; candidate pending independent review',
    fixed_D_m5_cost_argument='reconstructed; candidate pending independent review',
    production_outer_wrapper_present=False,production_test_status='NOT_RUN',
    decisive_missing_test='Odd-exponent/minimum-residue outer coefficient regression; see MISSING_TEST.md',
    historical_source_executed=False,independent_review_obtained=False,
    exact_DFT_claim=False,all_length_executable_claim=False,external_writes=False))

files=[]
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name not in {'MANIFEST.json','SEAL.json'}:
        data=path.read_bytes()
        files.append(dict(path=path.relative_to(root).as_posix(),bytes=len(data),sha256=digest(data)))
write_json(root/'MANIFEST.json',dict(format='sha256-payload-manifest-v1',files=files))
write_json(root/'SEAL.json',dict(status='SEALED_CANDIDATE_PENDING_INDEPENDENT_STATIC_REVIEW',
    date_utc='2026-10-13',manifest_sha256=digest((root/'MANIFEST.json').read_bytes()),
    payload_files=len(files),integrity_only=True,signature=False))

with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(root.rglob('*')):
        if path.is_file():
            name=path.relative_to(root).as_posix()
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16
            z.writestr(info,path.read_bytes())

with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(set(names)) and all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
    sealed=json.loads(z.read('SEAL.json'))
    assert digest(z.read('MANIFEST.json'))==sealed['manifest_sha256']
    manifest=json.loads(z.read('MANIFEST.json'))
    assert set(names)=={x['path'] for x in manifest['files']}|{'MANIFEST.json','SEAL.json'}
    for item in manifest['files']:
        data=z.read(item['path'])
        assert len(data)==item['bytes'] and digest(data)==item['sha256']
    assert z.read('CONTRACT.md')==(root/'CONTRACT.md').read_bytes()
    assert z.read('PROOF.md')==(root/'PROOF.md').read_bytes()

data=archive.read_bytes()
receipt=dict(archive=archive.name,bytes=len(data),sha256=digest(data),
             manifest_sha256=sealed['manifest_sha256'],payload_files=len(files),
             archive_members=len(names),all_payload_hashes_verified=True,
             status='SEALED_CANDIDATE_PENDING_INDEPENDENT_STATIC_REVIEW',
             historical_source_executed=False,external_writes=False)
write_json(Path(str(archive)+'.seal.json'),receipt)
print(json.dumps(receipt,indent=2))
