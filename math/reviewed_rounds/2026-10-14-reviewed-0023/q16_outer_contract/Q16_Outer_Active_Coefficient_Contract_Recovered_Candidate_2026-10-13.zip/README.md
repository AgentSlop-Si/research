# Q16 outer active-coefficient contract: recovered sealed candidate

Date: 13 October 2026 UTC.

**Status: CANDIDATE_READY_FOR_INDEPENDENT_STATIC_REVIEW.** This packet finishes the interrupted specification and proof work. It does not claim that the contract has been independently accepted or that a production outer evaluator exists.

## Result

The proposed exact incidence interval is correct:

    ceil(N(k-h-1)/M) <= r < ceil(N(k+h+1)/M), ell = r mod N.

When t=2h+2<M, this is duplicate-free, equals the retained stencil exactly, and emits at most ceil(Nt/M) incidences per support index. Its arithmetic handles negative lower endpoints and half-open upper endpoints without a deduplication pass.

The candidate precision J=(D+5)m+ceil(log2(s+1))+8, s=Dm, is sufficient. The decisive estimate is the normalized Dirichlet bound |F|,|R|<=1, which reduces the quotient perturbation to O(NM*2^-J), rather than the looser squared-denominator estimate. The derived Cartesian enclosure width is at most eta/64; signed nearest-even rounding on p=(D+3)m+3 then passes an exact squared complex-radius certificate for eta=2^-((D+3)m).

The fixed-D O(m^5) coefficient bit-work claim is justified in the declared schoolbook model: O_D(m) primitive operations and O_D(m^2) maximum integer width. This is an intentionally loose arithmetic/control bound, not a CPU or memory benchmark. Setup, endpoint powers, argument reduction, divisions, certificates and empty-input header work are included.

The accepted compact-window source has an even_power helper that explicitly rejects odd s. The outer target can have odd s and a negative normalized Dirichlet ratio. A signed general-integer power wrapper is therefore genuinely required; the existing helper's acceptance is not enough.

## Repairs made while recovering

1. Restated the full scalar enclosure proof, including Machin widths, fixed Taylor remainder, midpoint angle radius and clipping, rather than relying on a previous worker's assertion.
2. Corrected the empty-support cost to O_D((S+1)m^2 + 1_{E>0}m^5 + E*m^5). The interrupted formula omitted the header-only term at S=E=0.
3. Specified a bounded 32-byte run association label and the caller's provenance obligation. The label alone is not authentication. Variable-width labels and external serialization cannot be hidden in the coefficient cost.
4. Specified signed nearest-even midpoint rounding exactly and retained the warning that the negative-ratio sign witness need not violate the final eta tolerance by itself.

## Fresh evidence

Only the newly written fresh_recovery_checks.py was run. Historical source was read as bytes and parsed as AST, never imported or executed. The interrupted checks and their earlier receipt are preserved as inert evidence and are not counted as fresh runs.

The fresh run passed 334,299 assertions, including 95,228 incidence cases, 4,644 signed-power intervals, 60 synthetic normalized-quotient cases, 1,036 precision-budget cases, 70 scalar-bound cases, 16,206 signed-rounding cases and 288 square-root cases. Assertion totals include repeated algebra and source-pin checks; they are not independent scientific experiments. Two deliberately incorrect endpoint rules are rejected. Exact results and tested ranges are in FRESH_RECOVERY_RESULTS.json and the checker source.

The frozen scalar source matches the hash in its accepted v2 review. The recovered all-length theorem and observer-v2 acceptance are included with their exact hashes. Those accepted scopes are preserved and not enlarged.

## One decisive missing test

After independent static review and any required execution authorization, author and pin the actual outer coefficient wrapper, then run the **odd-exponent/minimum-residue regression** specified in MISSING_TEST.md. At D=5,m=57,N=2^55-1, it must reach the real signed-power path at s=285 and return a certified coefficient for the minimum nonzero rational residue n_u=1, along with zero-limit and negative-ratio controls. An independently implemented high-precision rational enclosure must verify its output, and its source/ledger must rule out a hidden N-row preparation pass.

That source-pinned production test is absent. Finite algebra checks do not substitute for it. The immediate gate for this packet remains independent static acceptance of the contract and argument; a later implementation test has separate authorization and scope.

## Scope retained

- Covers the exact retained-incidence contract, finite coefficient-enclosure recurrence, signed powers, fixed precision, and arithmetic resource argument.
- Does not implement sparse support production, the full outer scatter, finite accumulation, final scale-back, dense fallback, all-length dispatch, or independent J-call amplification.
- Does not establish new recovery probabilities, an exact DFT, relative-l2 accuracy, an alpha=1/2 endpoint, a practical crossover, speed, or novelty.
- The accepted bounded observer-v2 integration result remains unchanged. No historical scientific executable was rerun.
- No repository, external document, score, permission, or publication was changed.

MANIFEST.json authenticates payload files, SEAL.json authenticates that manifest, and the separate archive seal authenticates the ZIP. These are integrity hashes, not digital signatures or host attestation.
