"""New reviewer-authored checks. Never imports/executes candidate source.

Finite controls supplement the symbolic static proof; they are not a production
coefficient test, runtime attestation, or evidence of asymptotic performance.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import ast
import hashlib
import json
import math
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'q16_outer_contract_recovered_2330'
OUT = Path(__file__).resolve().parent
ZIP = ROOT / 'Q16_Outer_Active_Coefficient_Contract_Recovered_Candidate_2026-10-13.zip'
counts = Counter()

def check(ok, category):
    counts[category] += 1
    assert ok, category

def ceildiv(a, b):
    return -((-a)//b)

def outward(lo, hi, K):
    U = 1 << K
    return F(lo.numerator*U//lo.denominator, U), F(ceildiv(hi.numerator*U, hi.denominator), U)

manifest = json.loads((SRC/'MANIFEST.json').read_text())
for entry in manifest['files']:
    b = (SRC/entry['path']).read_bytes()
    check(len(b) == entry['bytes'], 'manifest_size')
    check(hashlib.sha256(b).hexdigest() == entry['sha256'], 'manifest_sha256')
seal = json.loads((SRC/'SEAL.json').read_text())
check(hashlib.sha256((SRC/'MANIFEST.json').read_bytes()).hexdigest() == seal['manifest_sha256'], 'seal')
archive_seal = json.loads(Path(str(ZIP)+'.seal.json').read_text())
check(hashlib.sha256(ZIP.read_bytes()).hexdigest() == archive_seal['sha256'], 'archive_seal')
check(ZIP.stat().st_size == archive_seal['bytes'], 'archive_seal')
with zipfile.ZipFile(ZIP) as z:
    entries = z.namelist()
    check(len(entries) == len(set(entries)), 'zip_unique_names')
    check(set(entries) == {str(p.relative_to(SRC)) for p in SRC.rglob('*') if p.is_file()}, 'zip_file_set')
    for name in entries:
        check(z.read(name) == (SRC/name).read_bytes(), 'zip_directory_identity')

# Static parsing is deliberately separate from importing or executing source.
tree = ast.parse((SRC/'evidence/accepted/compact_window.py.txt').read_text())
even = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'even_power')
check(any(isinstance(n, ast.Raise) for n in ast.walk(even)), 'historical_odd_rejection_source')
check("if n%2: raise ValueError('even exponent required')" in (SRC/'evidence/accepted/compact_window.py.txt').read_text(), 'historical_odd_rejection_source')

# Exact row-first definition versus lifted interval, including signed wraps.
incidence_cases = 0
bad_floor_witness = None
bad_closed_witness = None
for N in range(1, 49):
    M = 1 << ((4*N-1).bit_length())
    hs = sorted(set(range(min(17, (M-3)//2+1))) | {(M-3)//2})
    for h in hs:
        t = 2*h+2
        if t >= M:
            continue
        expected = [set() for _ in range(M)]
        for ell in range(N):
            center = ell*M//N
            for j in range(-h, h+2):
                expected[(center+j)%M].add(ell)
        for k in range(M):
            lo, hi = ceildiv(N*(k-h-1), M), ceildiv(N*(k+h+1), M)
            rows = [r%N for r in range(lo, hi)]
            check(set(rows) == expected[k], 'incidence_exact_membership')
            check(len(rows) == len(set(rows)), 'incidence_no_duplicates')
            check(len(rows) <= ceildiv(N*t,M), 'incidence_count_bound')
            incidence_cases += 1
            floor_rows = {r%N for r in range(lo, N*(k+h+1)//M)}
            if floor_rows != expected[k] and bad_floor_witness is None:
                bad_floor_witness = dict(N=N,M=M,h=h,k=k)
            closed_rows = {r%N for r in range(lo, N*(k+h+1)//M+1)}
            if closed_rows != expected[k] and bad_closed_witness is None:
                bad_closed_witness = dict(N=N,M=M,h=h,k=k)
check(bad_floor_witness is not None, 'endpoint_mutant_rejected')
check(bad_closed_witness is not None, 'endpoint_mutant_rejected')

# Signed endpoint powers independently checked against exact sample powers.
power_intervals = 0
for K in range(1, 6):
    U = 1 << K
    for a in range(-U, U+1):
        for b in range(a, U+1):
            for s in range(1, 12):
                lo, hi = F(a,U), F(b,U)
                if s%2:
                    pl, ph = lo**s, hi**s
                else:
                    pl = F(0) if lo<=0<=hi else min(abs(lo),abs(hi))**s
                    ph = max(abs(lo),abs(hi))**s
                ol, oh = outward(pl,ph,K)
                check(oh-ol <= s*(hi-lo)+F(2,U), 'signed_power_width')
                for j in range(5):
                    x = lo+(hi-lo)*F(j,4)
                    check(ol <= x**s <= oh, 'signed_power_contains_exact')
                power_intervals += 1

# Exact worst-case envelopes for precision, setup, and final complex rounding.
precision_cases = 0
for D in range(5, 25):
    for m in list(range(2,130))+[255,256,257,511,512,1024,4096]:
        s = D*m; M = 1 << m; A = (D+3)*m
        J = (D+5)*m+s.bit_length()+8
        K = J+2*(J+1).bit_length()+16
        check(64*(K+9) <= (1 << (K-J)), 'scalar_width_budget')
        check((4*(s+1)*(M*M) << A+6) <= (1 << J), 'cartesian_eta_over_64')
        check(K >= A+3 and K >= 16 and K >= m, 'grid_requirements')
        check(J > 2*m-2, 'denominator_strict_positivity')
        precision_cases += 1
check(2*9**2 < 128**2, 'squared_complex_certificate_margin')

# Fixed-iteration square-root recurrence against exact integer sqrt.
sqrt_cases = 0
for N in list(range(1, 81))+[255,256,257,1023,1024,1025]:
    M=1 << ((4*N-1).bit_length())
    for K in [16,17,31,64,127,623]:
        U=1<<K; Z=(M*U*U)//N; lo=0; hi=1<<(K+2)
        for _ in range(K+2):
            mid=(lo+hi)//2
            if mid*mid<=Z: lo=mid
            else: hi=mid
        check(hi-lo==1 and lo==math.isqrt(Z), 'fixed_sqrt_exact_floor')
        check(lo*lo*N<=M*U*U<(lo+1)*(lo+1)*N, 'fixed_sqrt_enclosure')
        sqrt_cases+=1

# Normalized quotient perturbation with small denominators and both signs.
quotient_cases = 0
for Q in [4,5,16,257,1024,1<<20]:
    eps=F(1,256*Q); delta=eps/1024; b=F(2,Q)
    for c in [1,2,max(1,Q//2)]:
        for f in [F(-1),F(-1,2),F(0),F(1,2),F(1)]:
            a=c*b*f
            for ao,bo in [(F(0),F(0)),(eps/3,eps/4),(-eps/4,-eps/3)]:
                aa=[a-eps/2+ao,a+eps/2+ao]
                bb=[b-eps/2+bo,b+eps/2+bo]
                corners=[x/(c*y) for x in aa for y in bb]
                check(all(abs(v-f) <= 2*Q*eps for v in corners), 'normalized_quotient_radius')
                check(max(corners)-min(corners) <= 4*Q*eps, 'normalized_quotient_width')
                quotient_cases += 1

# Signed nearest-even midpoint rule against exact Fraction round.
rounding_cases = 0
for K in range(3,9):
    for p in range(1,K+1):
        d = 1 << (K+1-p)
        for sm in range(-(1<<K)-2,(1<<K)+3):
            v, rem = divmod(sm,d)
            got=v+(2*rem>d or (2*rem==d and v%2!=0))
            expected=round(F(sm,d))
            check(got==expected, 'signed_nearest_even')
            rounding_cases += 1

# Large mathematical witness: integer algebra only, no length-N arrays.
D=5; m=57; M=1<<m; N=(1<<55)-1; s=D*m; h=16*s+1; t=2*h+2
q=M//(8*s); kn=2**55+1; en=2**53; J=(D+5)*m+s.bit_length()+8
K=J+2*(J+1).bit_length()+16; p=(D+3)*m+3
check(en*M-kn*N==1, 'minimum_nonzero_residue')
check((J,K,p)==(587,623,459), 'large_witness_precision')
check(M < 2*(2*q+1)*1710 and M < (2*q+1)*1710 < 2*M, 'negative_ratio_witness')
check(855*M < (M//2+1)*1710 < 856*M, 'negative_F_witness')
check(s%2==1, 'odd_exponent_witness')
B=1 << ceildiv(5*m,8); sparse_k=1 << ceildiv(m,4); rw=2*m+1
W=2*rw*(8*B-1)+1
check(M%B==0 and B>=4 and M//B>=4 and B>=4096*sparse_k and W<M and t<M and m>=16, 'all_sparse_guards_beta_one_eighth')
support=sorted([0,1710,kn,M-1]); selected={(0,0),(0,1710),(en,kn)}
large_E=0
for k in support:
    lo,hi=ceildiv(N*(k-h-1),M),ceildiv(N*(k+h+1),M)
    for r in range(lo,hi):
        ell=r%N; shift=(k-ell*M//N)%M
        check(shift<=h+1 or shift>=M-h, 'large_witness_retention')
        selected.discard((ell,k)); large_E+=1
check(not selected, 'selected_records_are_emitted')
power_pair=outward(F(-1,2)**s,F(-1,4)**s,K)
check(power_pair[0]<power_pair[1]<0, 'operator_level_negative_interval')
old_results=json.loads((SRC/'FRESH_RECOVERY_RESULTS.json').read_text())
expected=old_results['decisive_fixture']['signed_power_sentinel']
check([int(z*(1<<K)) for z in power_pair]==[int(expected['expected_lo']),int(expected['expected_hi'])], 'sentinel_matches_exact_powers')

report={
 'verdict':'PASS_FINITE_INDEPENDENT_CONTROLS',
 'historical_code_executed':False,
 'candidate_source_imported':False,
 'production_outer_coefficients_evaluated':False,
 'archive_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),
 'assertions':sum(counts.values()),'categories':dict(counts),
 'case_counts':dict(incidence=incidence_cases,signed_power_intervals=power_intervals,
     precision=precision_cases,normalized_quotient=quotient_cases,
     nearest_even=rounding_cases,square_root=sqrt_cases,large_witness_incidences=large_E),
 'endpoint_mutants':dict(floor_upper=bad_floor_witness,closed_upper=bad_closed_witness),
 'large_witness':dict(D=D,m=m,N=N,M=M,s=s,J=J,K=K,p=p,
     signed_power_K_grid_numerators=[int(z*(1<<K)) for z in power_pair]),
 'scope_note':'Finite controls support the separate symbolic audit. They do not close production/source integration or establish asymptotic bounds by experiments.'
}
(OUT/'INDEPENDENT_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
