# ALG-049 determinant-compatible radical-phase probe

This is a separate six-word exact bounded test. It changes neither the Q(i) theorem nor the parent status. No witness was found. All six mixed sign patterns were checked on one fixed ordered triple of full 8-cycles with pairwise distinct undirected supports and pairwise noncommutation. This is not a field-wide exclusion.

## Exact field and phase

Let s be the positive real root of 2s^8-257=0. Use E=Q(i,s), with complex conjugation fixing s and negating i. The polynomial 2X^8-257 is irreducible over Q by Eisenstein at 257. Q(s) has degree 8 and lies in R, so adjoining i gives degree 16. Therefore the basis 1,s,...,s^7 and i,is,...,is^7 has unique rational coefficients. Exact nonzero coefficients certify nonzero field elements. No approximate root is used.

Define w=(1+is)/(1-is). Its denominator is nonzero and w times its conjugate is exactly 1. Using s^8=257/2 gives

(1+s^2)^(-1)=(-2/255)(1-s^2+s^4-s^6),

w = (-259+4s^2-4s^4+4s^6)/255
    + i(-4s+4s^3-4s^5+4s^7)/255.

The checker independently verifies w(1-is)=1+is and w conjugate(w)=1 from the polynomial representation. Unlike the Q(i) sample, the required scalar c is representable: for net sign +1 it is s^2; for net sign -1 it is (2/257)s^6. They are positive in the specified real embedding, reciprocal to each other, and (s^2)^4=257/2. Thus representability alone no longer rules out this field.

## The finite family

Keep the convention M e_order[j]=weight[j] e_order[(j+1) mod 8]. The three orders are:

- (0,1,2,3,4,5,6,7)
- (0,1,3,4,5,6,2,7)
- (0,1,4,5,6,7,3,2)

The first has seven weights 1 followed by -1. In the second, weight[0]=w, weight[6]=conjugate(w), weight[7]=-1, and all others are 1. In the third, weight[2]=w^2, weight[5]=conjugate(w)^2, weight[7]=-1, and all others are 1. All cycle products equal -1; all weights have modulus one. The graph orders are the first two selected noncanonical graph orders from the Q(i) sample, but their weights are replaced by the explicitly defined radical phases.

Use identity separators in the effective grammar and all six sign patterns --+, -+-, -++, +--, +-+, ++-. No other candidate is included. Each has an exact nonzero off-diagonal entry in its Gram matrix. RADICAL_RESULTS.json records one complete rational-coefficient obstruction per word, plus all orders and weights.

## Computation and controls

check_radical_probe.py is newly authored, standalone Python-standard-library code. It represents real elements by eight Fraction coefficients reduced by s^8=257/2, and complex elements by two such vectors. It checks each unit phase and cycle product, M^8=-I, both K inverse identities, the defining K equation, pairwise noncommutation and distinct graph support, and all six Gram conditions. The same exact geometric numerator formulas as in the main proof define K and K inverse, now in E.

The six Gram tests use 18 dense 8x8 matrix multiplications. The operation logs also count nontrivial complex field multiplications, real polynomial multiplications, and nonzero rational coefficient products, with zero/one shortcuts stated in the source. These are arithmetic counters, not bit-complexity or runtime guarantees; enumeration, comparisons, allocations, fractions' internal gcd work, and data movement are not part of those kernel counters. The positive real algebraic generator s is an explicitly represented input constant for this verification, not free phase synthesis for an algorithmic speed claim.

Only these six radical-phase words are excluded. The general N=8 three-stage arbitrary-phase scalar-unitarity problem remains open. The parent remains TO RESEARCH, priority 42. Independent review of the finite algebraic representation and exact obstruction records is required before acceptance.
