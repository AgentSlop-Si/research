#!/usr/bin/env python3
"""Independent new degree-16 coefficient arithmetic, six bounded N8 words.
Real s is the positive root of 2*s^8-257; conjugation fixes s and sends i to -i.
No decimal root or floating-point matrix arithmetic is used.
"""
from fractions import Fraction as F
from collections import Counter
import json, pathlib, itertools, time, argparse
OPS=Counter(); PZERO=(F(0),)*8
def poly(values): return tuple(F(values[j]) if j<len(values) else F(0) for j in range(8))
def padd(a,b): return tuple(x+y for x,y in zip(a,b))
def pneg(a): return tuple(-x for x in a)
def pmul(a,b):
 OPS['real_polynomial_multiplications']+=1
 c=[F(0)]*8
 for j,x in enumerate(a):
  if not x: continue
  for k,y in enumerate(b):
   if not y: continue
   OPS['nonzero_rational_coefficient_products']+=1
   z=x*y
   if j+k>=8: z*=F(257,2)
   c[(j+k)%8]+=z
 return tuple(c)
ZERO=(PZERO,PZERO); ONE=(poly([1]),PZERO)
def cadd(a,b): return (padd(a[0],b[0]),padd(a[1],b[1]))
def cneg(a): return (pneg(a[0]),pneg(a[1]))
def cmul(a,b):
 if a==ZERO or b==ZERO: return ZERO
 if a==ONE: return b
 if b==ONE: return a
 OPS['nontrivial_complex_field_multiplications']+=1
 return (padd(pmul(a[0],b[0]),pneg(pmul(a[1],b[1]))),padd(pmul(a[0],b[1]),pmul(a[1],b[0])))
def cscale(a,q): return tuple(tuple(x*q for x in pp) for pp in a)
def conj(a): return (a[0],pneg(a[1]))
def eye(): return [[ONE if i==j else ZERO for j in range(8)] for i in range(8)]
def madd(A,B): return [[cadd(x,y) for x,y in zip(a,b)] for a,b in zip(A,B)]
def mscale(A,q): return [[cscale(x,q) for x in row] for row in A]
def mm(A,B):
 OPS['matrix_multiplications']+=1
 C=[]
 for i in range(8):
  row=[]
  for j in range(8):
   a=ZERO
   for k in range(8): a=cadd(a,cmul(A[i][k],B[k][j]))
   row.append(a)
  C.append(row)
 return C
def adj(A): return [[conj(A[j][i]) for j in range(8)] for i in range(8)]
def cyc(order,weights):
 M=[[ZERO for _ in range(8)] for _ in range(8)]
 for j,k in enumerate(order): M[order[(j+1)%8]][k]=weights[j]
 return M
def factors(M):
 pp=[eye()]
 for _ in range(8): pp.append(mm(pp[-1],M))
 assert pp[-1]==mscale(eye(),-1)
 K=mscale(eye(),3); H=mscale(eye(),129)
 for j in range(1,8): K=madd(K,pp[j]); H=madd(H,mscale(pp[j],-2**(7-j)))
 K=mscale(K,F(1,2)); H=mscale(H,F(1,257))
 assert mm(K,H)==eye() and mm(H,K)==eye()
 assert mm(madd(eye(),mscale(M,-1)),K)==madd(mscale(eye(),2),mscale(M,-1))
 return {1:K,-1:H}
def serialize(x): return [[str(q) for q in p] for p in x]
def main(outdir):
 t=time.perf_counter(); out=pathlib.Path(outdir); out.mkdir(parents=True,exist_ok=True)
 # w=(1+i*s)/(1-i*s). Since s^8=257/2, (1+s^2)^-1 = -2/255*(1-s^2+s^4-s^6).
 w=(tuple(F(q,255) for q in [-259,0,4,0,-4,0,4,0]),tuple(F(q,255) for q in [0,-4,0,4,0,-4,0,4]))
 assert cmul(w,conj(w))==ONE
 s=(poly([0,1]),PZERO); is_=(PZERO,poly([0,1])); numerator=cadd(ONE,is_); denominator=cadd(ONE,cneg(is_))
 assert cmul(w,denominator)==numerator
 weights1=[ONE]*8; weights1[7]=cneg(ONE)
 weights2=[ONE]*8; weights2[0]=w; weights2[6]=conj(w); weights2[7]=cneg(ONE)
 w2=cmul(w,w); weights3=[ONE]*8; weights3[2]=w2; weights3[5]=conj(w2); weights3[7]=cneg(ONE)
 perms=list(itertools.permutations(range(1,8)))
 orders=[tuple(range(8)),(0,)+perms[5040//33],(0,)+perms[2*5040//33]]
 weights=[weights1,weights2,weights3]; mats=[cyc(o,w) for o,w in zip(orders,weights)]
 for ww in weights:
  prod=ONE
  for z in ww: assert cmul(z,conj(z))==ONE; prod=cmul(prod,z)
  assert prod==cneg(ONE)
 supports=[{frozenset((o[j],o[(j+1)%8])) for j in range(8)} for o in orders]
 for a,b in itertools.combinations(range(3),2):
  assert supports[a]!=supports[b]; assert mm(mats[a],mats[b])!=mm(mats[b],mats[a])
 fs=[factors(m) for m in mats]; rows=[]; pre=OPS.copy()
 for signs in itertools.product((-1,1),repeat=3):
  if len(set(signs))!=2: continue
  A=mm(mm(fs[0][signs[0]],fs[1][signs[1]]),fs[2][signs[2]])
  G=mm(adj(A),A); obs=[]
  for a in range(8):
   for b in range(8):
    if a!=b and G[a][b]!=ZERO: obs.append((a,b,G[a][b]))
  diag=[j for j in range(1,8) if G[j][j]!=G[0][0]]
  ok=not obs and not diag
  assert not ok
  r,c,z=obs[0]
  rows.append({'signs':''.join('+' if e==1 else '-' for e in signs),'scalar_unitary':False,'nonzero_gram_offdiagonals':len(obs),'unequal_gram_diagonals':len(diag),'first_exact_obstruction':{'row':r,'column':c,'real_and_imaginary_coefficients_degrees_0_to_7':serialize(z)}})
 searchops=dict(OPS-pre)
 # Exact compatible scalar: (s^2)^4=257/2, and its reciprocal exists (2/257)*s^6.
 cplus=cmul(s,s); cminus=(poly([0,0,0,0,0,0,F(2,257)]),PZERO)
 assert cmul(cplus,cminus)==ONE
 cp=cplus
 for _ in range(3): cp=cmul(cp,cplus)
 assert cp==(poly([F(257,2)]),PZERO)
 result={'task':'ALG-049 separate radical probe','field':'Q(i,s), s the positive root of 2*s^8-257','degree_over_Q':16,
 'finite_family':'One explicit ordered graph pair, six mixed sign patterns','exact_words_checked':6,'scalar_unitary_witnesses':0,
 'unit_phase':'w=(1+i*s)/(1-i*s); cycle 2 uses w,conjugate(w); cycle 3 uses w^2,conjugate(w)^2; remaining weights 1 except wrap -1',
 'orders':orders,'weights':[[serialize(z) for z in ww] for ww in weights],
 'required_gram_scalars_representable':['s^2','(2/257)*s^6'],
 'no_floating_point_algebra':True,'all_unit_weights_and_cycle_products_checked_exactly':True,'all_cycle_pairs_noncommuting_and_supports_distinct':True,
 'search_operations':searchops,'all_operations':dict(OPS),'elapsed_seconds':time.perf_counter()-t,
 'results':rows,'boundary':'Only these six exact words are excluded. No field-wide radical-phase exclusion or arbitrary-phase classification is claimed.',
 'independent_review_status':'pending'}
 (out/'RADICAL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ['weights','results']},indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--out',default='.'); main(p.parse_args().out)
