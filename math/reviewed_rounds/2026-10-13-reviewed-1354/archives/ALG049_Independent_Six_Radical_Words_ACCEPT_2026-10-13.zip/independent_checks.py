"""Independent six-word audit via sparse Q-basis arithmetic and monomial gauges.
No author or historical code is imported or executed. No numerical roots.
"""
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
from itertools import combinations
import json
# A sparse tuple (basis index, rational coefficient); indices 0..7=s^j,
# indices 8..15=i*s^j. Reduction relations: s^8=257/2 and i^2=-1.
Z=();O=((0,Q(1)),)
def elt(d):return tuple(sorted((k,Q(v)) for k,v in d.items() if v))
@lru_cache(None)
def plus(a,b):
 c=dict(a)
 for j,v in b:c[j]=c.get(j,Q(0))+v
 return elt(c)
def scale(a,q):return elt({j:q*v for j,v in a})
def neg(a):return scale(a,-1)
def conj(a):return elt({j:(-v if j>=8 else v) for j,v in a})
@lru_cache(None)
def times(a,b):
 c={}
 for j,x in a:
  for k,y in b:
   p=j%8+k%8; ii=j//8+k//8; q=x*y
   if p>=8:q*=Q(257,2)
   if ii==2:q=-q
   r=p%8+8*(ii%2);c[r]=c.get(r,Q(0))+q
 return elt(c)
def power(a,n):
 out=O
 for _ in range(n):out=times(out,a)
 return out
def eye(n=8):return [[O if a==b else Z for b in range(n)] for a in range(n)]
def mm(A,B):
 C=[]
 for row in A:
  rr=[]
  for col in zip(*B):
   v=Z
   for a,b in zip(row,col):
    if a and b:v=plus(v,times(a,b))
   rr.append(v)
  C.append(rr)
 return C
def adj(A):return [[conj(x) for x in col] for col in zip(*A)]
def inverse_rational(A):
 n=len(A);T=[list(map(Q,row))+[Q(a==b) for b in range(n)] for a,row in enumerate(A)]
 for j in range(n):
  p=next(a for a in range(j,n) if T[a][j]);T[j],T[p]=T[p],T[j];q=T[j][j];T[j]=[x/q for x in T[j]]
  for a in range(n):
   if a!=j:
    q=T[a][j];T[a]=[x-q*y for x,y in zip(T[a],T[j])]
 return [r[n:] for r in T]
def rational_mm(A,B):return [[sum(x*y for x,y in zip(r,c)) for c in zip(*B)] for r in A]
def canonical_factors():
 S=[[Q(0) for _ in range(8)] for _ in range(8)]
 for j in range(7):S[j+1][j]=Q(1)
 S[0][7]=Q(-1)
 Im=[[Q(a==b)-S[a][b] for b in range(8)] for a in range(8)]
 two=[[2*Q(a==b)-S[a][b] for b in range(8)] for a in range(8)]
 K=rational_mm(two,inverse_rational(Im));H=inverse_rational(K)
 assert rational_mm(K,H)==[[Q(a==b) for b in range(8)] for a in range(8)]
 return {'+':K,'-':H},S
s=elt({1:1});i=elt({8:1});is_=times(i,s)
inv_norm=elt({0:Q(-2,255),2:Q(2,255),4:Q(-2,255),6:Q(2,255)})
assert times(inv_norm,plus(O,power(s,2)))==O
w=times(power(plus(O,is_),2),inv_norm)
assert times(w,plus(O,neg(is_)))==plus(O,is_) and times(w,conj(w))==O
w2=power(w,2)
orders=[list(range(8)),[0,1,3,4,5,6,2,7],[0,1,4,5,6,7,3,2]]
weights=[[O]*7+[neg(O)],[w,O,O,O,O,O,conj(w),neg(O)],[O,O,w2,O,O,conj(w2),O,neg(O)]]
base,S=canonical_factors();stages=[];cycles=[]
for order,ww in zip(orders,weights):
 d=[O]
 for z in ww[:-1]:d.append(times(d[-1],z))
 assert times(neg(conj(d[-1])),d[0])==ww[-1]
 prod=O
 for z in ww:assert times(z,conj(z))==O;prod=times(prod,z)
 assert prod==neg(O)
 M=[[Z for _ in range(8)] for _ in range(8)]
 for j,v in enumerate(order):M[order[(j+1)%8]][v]=ww[j]
 cycles.append(M)
 f={}
 for sign,K in base.items():
  B=[[Z for _ in range(8)] for _ in range(8)]
  for a in range(8):
   for b in range(8):B[order[a]][order[b]]=scale(times(d[a],conj(d[b])),K[a][b])
  f[sign]=B
 assert mm(f['+'],f['-'])==eye() and mm(f['-'],f['+'])==eye()
 Im=[[plus(O if a==b else Z,neg(M[a][b])) for b in range(8)] for a in range(8)]
 two=[[plus(scale(O,2) if a==b else Z,neg(M[a][b])) for b in range(8)] for a in range(8)]
 assert mm(Im,f['+'])==two
 stages.append(f)
def support(order):return frozenset(tuple(sorted((a,b))) for a,b in zip(order,order[1:]+order[:1]))
for a,b in combinations(range(3),2):
 assert support(orders[a])!=support(orders[b]) and mm(cycles[a],cycles[b])!=mm(cycles[b],cycles[a])
for M in cycles:
 P=eye()
 for _ in range(8):P=mm(P,M)
 assert P==[[neg(x) for x in row] for row in eye()]
def serialize(x):
 d=dict(x);return [[str(d.get(j+8*im,Q(0))) for j in range(8)] for im in range(2)]
src=Path(__file__).with_name('reviewed_author')
if not src.is_dir(): src=Path(__file__).resolve().parents[1]/'alg049_run'
author=json.loads((src/'RADICAL_RESULTS.json').read_text())
assert author['orders']==orders and author['weights']==[[serialize(z) for z in ww] for ww in weights]
patterns=['--+','-+-','-++','+--','+-+','++-']; rows=[]
for signs,rec in zip(patterns,author['results']):
 B=mm(mm(stages[0][signs[0]],stages[1][signs[1]]),stages[2][signs[2]]);G=mm(adj(B),B)
 off=[(a,b,G[a][b]) for a in range(8) for b in range(8) if a!=b and G[a][b]]
 diag=[a for a in range(1,8) if G[a][a]!=G[0][0]]
 assert off and len(off)==56 and len(diag)==7 and rec['signs']==signs
 a,b,z=off[0];obs={'row':a,'column':b,'real_and_imaginary_coefficients_degrees_0_to_7':serialize(z)}
 assert obs==rec['first_exact_obstruction'] and rec['nonzero_gram_offdiagonals']==len(off) and rec['unequal_gram_diagonals']==len(diag)
 rows.append({'signs':signs,'scalar_unitary':False,'Gram_nonzero_offdiagonals':len(off),'unequal_diagonals':len(diag),'first_obstruction':obs})
cp=power(s,2);cm=scale(power(s,6),Q(2,257));assert times(cp,cm)==O and power(cp,4)==elt({0:Q(257,2)})
assert all(257%p for p in range(2,17)) # elementary primality control for Eisenstein.
result={'verdict':'PASS','scope':'Exactly the six listed radical-phase words; no field-wide theorem','author_code_executed':False,'field_representation':'Independent sparse 16-coordinate Q-basis with relations s^8=257/2 and i^2=-1','factor_construction':'Canonical K and inverse by rational Gauss-Jordan elimination; arbitrary cycles by cumulative monomial gauges','field_degree_proof':'Eisenstein at 257 gives [Q(s):Q]=8; Q(s) subset R so adjoining i doubles degree','all_author_weights_matched':True,'all_six_exact_Gram_records_matched':True,'all_phase_cycle_inverse_and_defining_equations_pass':True,'required_positive_Gram_scalars_representable':True,'results':rows}
Path(__file__).with_name('INDEPENDENT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))
