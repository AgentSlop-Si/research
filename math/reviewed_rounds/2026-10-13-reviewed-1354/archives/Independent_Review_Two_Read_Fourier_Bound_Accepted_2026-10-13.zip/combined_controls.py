#!/usr/bin/env python3
"""Independent exact composed factorization controls; imports only this review's fresh library."""
from independent_controls import Field, rank, bound, inverse, direction, RNG
from pathlib import Path
import json
OUT=Path(__file__).resolve().parent
records=[]
for f,N in [(Field(2),1),(Field(3),2),(Field(5),4),(Field(7),6),(Field(13),12),(Field(17),16),(Field(97),96),(Field(2,0b111),3),(Field(2,0b1011),7),(Field(2,0b10011),15)]:
    omega=next(x for x in range(1,f.q) if f.pow(x,N)==1 and all(f.pow(x,t)!=1 for t in range(1,N)))
    for L in sorted(set([1,min(2,N),min(3,N),N//2 or 1,N])):
        selected=RNG.sample(range(N),L)
        F=[[f.pow(omega,a*j) for j in range(N)] for a in selected]
        M=2*L+3
        V=[[0]*N for _ in range(M)]
        R=[[0]*M for _ in range(L)]
        # V has a zero padding state at each end; the final nonzero coupling crosses the boundary.
        for i in range(L):
            t=2*i+1
            u=[F[i][j] if (i+j)%3==0 else (0 if (i+j)%3==1 else f.mul(F[i][j],2%f.q)) for j in range(N)]
            V[t]=u
            V[t+1]=[f.sub(x,y) for x,y in zip(F[i],u)]
            R[i][t]=R[i][t+1]=1
        d=[RNG.randrange(f.q) for _ in range(M)]
        d[M//2]=0
        C=[[f.sub(V[t][j],f.mul(d[t],V[(t-1)%M][j])) for j in range(N)] for t in range(M)]
        T=[[int(i==j) for j in range(M)] for i in range(M)]
        for i in range(M): T[i][(i-1)%M]=f.sub(T[i][(i-1)%M],d[i])
        G=inverse(T,f); assert G is not None
        recovered=[[f.dot(G[t],[C[u][j] for u in range(M)]) for j in range(N)] for t in range(M)]
        assert recovered==V
        Y=[[f.dot(R[i],[V[t][j] for t in range(M)]) for j in range(N)] for i in range(L)]
        assert Y==F
        w=min(L,bound(L)); window_nnz=0
        for start in range(N):
            J=[(start+j)%N for j in range(w)]
            k=sum(any(row[j] for j in J) for row in C)
            dirs={direction([row[j] for j in J],f) for row in V}; dirs.discard(None)
            assert len(dirs)<=k
            assert k>=(L+1)//2
            window_nnz+=sum(row[j]!=0 for row in C for j in J)
        A=sum(x!=0 for row in C for x in row)
        lower=max(N,(N*((L+1)//2)+w-1)//w)
        assert window_nnz==w*A and A>=lower
        records.append({'field':f.q,'characteristic':f.p,'N':N,'L':L,'M':M,'A':A,'lower':lower})
# Assumption-negative controls, which must violate the intended intermediate claim or bound.
f=Field(3)
d=[1,1]; C=[[0,0],[0,0]]; V=[[1,2],[1,2]]
assert all(V[t][j]==f.add(f.mul(d[t],V[(t-1)%2][j]),C[t][j]) for t in range(2) for j in range(2))
assert sum(any(row) for row in C)==0 and len({direction(row,f) for row in V})==1
N=96; L=96; w=min(L,bound(L)); lower=max(N,(N*((L+1)//2)+w-1)//w)
assert N<lower # D=0,C=I,R=F is valid only after dropping the two-read restriction.
result={'status':'PASS','combined_representations':len(records),'records':records,
  'singular_k_zero_negative':'Nonzero constant V solves homogeneous cyclic recurrence when product(d)=1; excluded as required.',
  'unrestricted_read_negative':{'N':N,'A':N,'two_read_lower':lower,'row_support_of_R':N}}
(OUT/'COMBINED_CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
