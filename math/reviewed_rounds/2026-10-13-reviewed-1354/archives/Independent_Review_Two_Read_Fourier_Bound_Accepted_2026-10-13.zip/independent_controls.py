#!/usr/bin/env python3
"""Fresh exact controls for the 2026-10-13 two-read theorem; standard library only.
No historical code, no network, no executable imports outside standard library.
Controls are evidence against implementation mistakes, not a replacement for proof.
"""
from itertools import product, combinations
from collections import deque, Counter
from pathlib import Path
import json, random, hashlib, time

OUT=Path(__file__).resolve().parent
RNG=random.Random(103610132026)
COUNTS=Counter()
EXAMPLES={}

def ceil_log2(n): return (n-1).bit_length()
def bound(L): return 4*ceil_log2(L)+6

def witness(n,edges,L=None,root_mode='all',peel=True):
    L=len(edges) if L is None else L
    alive=set(range(n)); active=set(range(len(edges)))
    if peel:
        assert len(edges)>2*n
        while True:
            deg=Counter()
            for eid in active:
                u,v=edges[eid]; deg[u]+=1; deg[v]+=1
            remove=next((v for v in sorted(alive) if deg[v]<=2),None)
            if remove is None: break
            active={e for e in active if remove not in edges[e]}
            alive.remove(remove)
            assert len(active)>2*len(alive)
        assert alive
    adj={v:[] for v in alive}
    for eid in active:
        u,v=edges[eid]; adj[u].append((v,eid)); adj[v].append((u,eid))
    assert min(map(len,adj.values()))>=3
    roots=sorted(alive) if root_mode=='all' else RNG.sample(sorted(alive),min(8,len(alive)))
    r=ceil_log2(L)+1
    for root in roots:
        dist={root:0}; parent={}; q=deque([root])
        while q:
            u=q.popleft()
            if dist[u]==r: continue
            for v,e in adj[u]:
                if v not in dist:
                    dist[v]=dist[u]+1; parent[v]=(u,e); q.append(v)
        tree={e for u,e in parent.values()}
        extra=sorted(e for e in active if all(v in dist for v in edges[e]) and e not in tree)
        assert len(extra)>=2,(n,edges,root,r)
        chosen=set(extra[:2]); vertices={root}
        for e in extra[:2]:
            for v in edges[e]:
                vertices.add(v)
                while v!=root:
                    u,pe=parent[v]; chosen.add(pe); vertices.add(u); v=u
        assert len(chosen)==len(vertices)+1
        assert len(chosen)<=bound(L)
        seen={root}; q=deque([root])
        while q:
            u=q.popleft()
            for e in chosen:
                a,b=edges[e]
                if a==u and b not in seen: seen.add(b); q.append(b)
                if b==u and a not in seen: seen.add(a); q.append(a)
        assert seen==vertices
        COUNTS['graph_bfs_roots']+=1
        COUNTS['witness_edges_max']=max(COUNTS['witness_edges_max'],len(chosen))
    COUNTS['graphs']+=1


def graph_controls():
    for n in range(1,5):
        types=list(combinations(range(n),2))+[(v,v) for v in range(n)]
        for mult in product(range(3),repeat=len(types)):
            if sum(mult)<=2*n: continue
            edges=[e for e,m in zip(types,mult) for _ in range(m)]
            witness(n,edges)
            COUNTS['exhaustive_multigraphs']+=1
    named={
      'three_loops':(1,[(0,0)]*3),
      'five_parallel':(2,[(0,1)]*5),
      'dense_core_isolates_tendril':(12,[(0,1)]*27+[(1,2),(2,3),(3,4)]),
      'root_loop_and_parallel':(3,[(0,0),(0,1),(0,1),(1,2),(1,2),(2,2),(0,2)]),
    }
    for name,(n,e) in named.items(): witness(n,e); EXAMPLES[name]={'n':n,'edges':e}
    # Sparse simple graphs at density just above the peeling threshold, various sizes.
    for n in [5,6,7,8,15,16,17,31,32,33,63,64,65,127,128,129,255,256,257,511,512,1024]:
        for iteration in range(12):
            # The circulant initially has degree four; add one new edge.
            es={tuple(sorted((u,(u+d)%n))) for u in range(n) for d in [1,2]}
            while len(es)<=2*n:
                u,v=RNG.sample(range(n),2); es.add(tuple(sorted((u,v))))
                if n==5 and len(es)==10: break
            if len(es)<=2*n: continue
            witness(n,sorted(es),root_mode='sample')
            COUNTS['large_simple_graphs']+=1
    # The BFS subclaim itself only needs minimum degree three and n <= L.
    for n in [4,6,8,10,16,32,64,128,256,512]:
        for iteration in range(10):
            perm=list(range(n)); RNG.shuffle(perm)
            es=[(i,(i+1)%n) for i in range(n)]+list(zip(perm[::2],perm[1::2]))
            witness(n,es,root_mode='sample',peel=False)
            COUNTS['min_degree_three_graphs']+=1

class Field:
    def __init__(self,p,poly=None):
        self.p=p; self.poly=poly; self.q=p if poly is None else 1<<(poly.bit_length()-1)
    def add(self,a,b): return (a+b)%self.p if self.poly is None else a^b
    def neg(self,a): return (-a)%self.p if self.poly is None else a
    def sub(self,a,b): return self.add(a,self.neg(b))
    def mul(self,a,b):
        if self.poly is None: return a*b%self.p
        c=0
        while b:
            if b&1: c^=a
            b>>=1; a<<=1
            if a&self.q: a^=self.poly
        return c
    def pow(self,a,n):
        z=1
        while n:
            if n&1: z=self.mul(z,a)
            a=self.mul(a,a); n>>=1
        return z
    def inv(self,a): assert a; return self.pow(a,self.q-2)
    def dot(self,x,y):
        r=0
        for a,b in zip(x,y): r=self.add(r,self.mul(a,b))
        return r

def rank(A,f):
    if not A: return 0
    T=[list(row) for row in A]; rows=len(T); cols=len(T[0]); r=0
    for c in range(cols):
        pivot=next((j for j in range(r,rows) if T[j][c]),None)
        if pivot is None: continue
        T[r],T[pivot]=T[pivot],T[r]; inv=f.inv(T[r][c])
        T[r]=[f.mul(x,inv) for x in T[r]]
        for j in range(r+1,rows):
            z=T[j][c]
            if z: T[j]=[f.sub(x,f.mul(z,y)) for x,y in zip(T[j],T[r])]
        r+=1
        if r==rows: break
    return r

def inverse(A,f):
    n=len(A); T=[row[:]+[int(i==j) for j in range(n)] for i,row in enumerate(A)]
    for c in range(n):
        pivot=next((j for j in range(c,n) if T[j][c]),None)
        if pivot is None: return None
        T[c],T[pivot]=T[pivot],T[c]; inv=f.inv(T[c][c]); T[c]=[f.mul(x,inv) for x in T[c]]
        for j in range(n):
            if j==c: continue
            z=T[j][c]
            if z: T[j]=[f.sub(x,f.mul(z,y)) for x,y in zip(T[j],T[c])]
    return [row[n:] for row in T]

def direction(row,f):
    x=next((x for x in row if x),None)
    return None if x is None else tuple(f.mul(y,f.inv(x)) for y in row)

def recurrence_case(d,C,f,inv=None):
    M=len(d); Q=len(C[0]); T=[[int(i==j) for j in range(M)] for i in range(M)]
    for i in range(M): T[i][(i-1)%M]=f.sub(T[i][(i-1)%M],d[i])
    prod=1
    for x in d: prod=f.mul(prod,x)
    G=inv if inv is not None else inverse(T,f)
    assert (G is None)==(prod==1)
    if G is None: COUNTS['singular_recurrence_weights']+=1; return
    V=[[f.dot(G[i],[C[t][j] for t in range(M)]) for j in range(Q)] for i in range(M)]
    assert all(V[t][j]==f.add(f.mul(d[t],V[(t-1)%M][j]),C[t][j]) for t in range(M) for j in range(Q))
    # Independently verify every column restriction, including empty and nonconsecutive J.
    for mask in range(1<<Q):
        J=[j for j in range(Q) if mask>>j&1]
        k=sum(any(row[j] for j in J) for row in C)
        dirs={direction([row[j] for j in J],f) for row in V}; dirs.discard(None)
        assert len(dirs)<=k,(f.q,d,C,J,V,k,dirs)
        COUNTS['recurrence_restrictions']+=1
    COUNTS['recurrence_instances']+=1

def recurrence_controls():
    for p,maxM in [(2,4),(3,3),(5,2)]:
        f=Field(p)
        for M in range(1,maxM+1):
            for d in product(range(p),repeat=M):
                T=[[int(i==j) for j in range(M)] for i in range(M)]
                for i in range(M): T[i][(i-1)%M]=f.sub(T[i][(i-1)%M],d[i])
                G=inverse(T,f)
                prod=1
                for x in d: prod=f.mul(prod,x)
                assert (G is None)==(prod==1)
                if G is None: COUNTS['singular_recurrence_weights']+=1; continue
                for values in product(range(p),repeat=2*M):
                    C=[list(values[2*t:2*t+2]) for t in range(M)]
                    recurrence_case(d,C,f,G)
                    COUNTS['exhaustive_recurrence_instances']+=1
    for f in [Field(2,0b111),Field(2,0b1011),Field(2,0b10011),Field(7),Field(97)]:
        for it in range(250):
            M=RNG.randrange(1,19); Q=4
            d=[RNG.randrange(f.q) for _ in range(M)]
            C=[[0 if RNG.randrange(3) else RNG.randrange(f.q) for _ in range(Q)] for _ in range(M)]
            recurrence_case(d,C,f)
            COUNTS['random_recurrence_trials']+=1

def fourier_controls():
    fields=[Field(p) for p in [2,3,5,7,11,13,17,19,31,97]]+[Field(2,0b111),Field(2,0b1011),Field(2,0b10011)]
    for f in fields:
        # Check all exact-order roots, with exhaustive rowsets for N <= 8.
        for omega in range(1,f.q):
            N=next(n for n in range(1,f.q) if f.pow(omega,n)==1)
            widths=range(1,N+1) if N<=8 else sorted(set([1,2,3,min(5,N),N//2,N]))
            for w in widths:
                for start in range(N):
                    if N<=8:
                        subsets=(s for size in range(1,w+1) for s in combinations(range(N),size))
                    else:
                        subsets=[sorted(RNG.sample(range(N),RNG.randint(1,w))) for _ in range(3)]
                    for rows in subsets:
                        Y=[[f.pow(omega,a*((start+j)%N)) for j in range(w)] for a in rows]
                        assert rank(Y,f)==len(rows),(f.q,N,omega,w,start,rows)
                        COUNTS['fourier_row_window_ranks']+=1
                        if f.poly: COUNTS['characteristic_two_rank_controls']+=1
                        if start+w>N: COUNTS['wrapped_rank_controls']+=1
            COUNTS['fourier_exact_order_roots']+=1
    # Negative control: arbitrary, nonconsecutive columns need not be full spark at composite N.
    f=Field(5); omega=2; rows=[0,2]; cols=[0,2]
    Y=[[f.pow(omega,a*j) for j in cols] for a in rows]
    assert rank(Y,f)==1
    EXAMPLES['composite_nonconsecutive_minor']={'field':5,'N':4,'omega':2,'rows':rows,'columns':cols,'rank':1}

def windows_controls():
    for N in range(1,130):
        for L in range(1,N+1):
            w=min(L,bound(L)); occur=[0]*N
            for start in range(N):
                J=[(start+j)%N for j in range(w)]
                assert len(set(J))==w
                for j in J: occur[j]+=1
            assert set(occur)=={w}
            COUNTS['window_multiplicity_cases']+=1
    for N in [1,2,3,4,5,8,16,64,1024,1000000]:
        w=min(N,bound(N)); lower=max(N,(N*((N+1)//2)+w-1)//w)
        EXAMPLES[f'bound_N_L_{N}']={'w':w,'lower':lower}

def sparse_factor_controls():
    # Graph witness must imply actual linear dependence for arbitrary gains, not equality of matroids.
    for f in [Field(2),Field(3),Field(5),Field(2,0b1011)]:
        for k in range(1,12):
            for it in range(100):
                L=2*k+1; B=[]; edges=[]
                for e in range(L):
                    sup=RNG.sample(range(k),min(k,RNG.choice([1,2])))
                    row=[0]*k
                    for u in sup: row[u]=RNG.randrange(1,f.q)
                    B.append(row); edges.append(tuple(sup) if len(sup)==2 else (sup[0],sup[0]))
                witness(k,edges,root_mode='sample')
                # Brute-force a small excess subset in this random support graph.
                found=None
                for s in range(2,min(L,8)+1):
                    for subset in combinations(range(L),s):
                        used=set(v for e in subset for v in edges[e])
                        if len(used)<s: found=subset; break
                    if found: break
                if found is None: continue
                U=[[RNG.randrange(f.q) for _ in range(6)] for _ in range(k)]
                Y=[[f.dot(B[e],[U[t][j] for t in range(k)]) for j in range(6)] for e in found]
                assert rank(Y,f)<len(found)
                COUNTS['weighted_support_dependence_cases']+=1

if __name__=='__main__':
    t=time.time()
    for fn in [graph_controls,recurrence_controls,fourier_controls,windows_controls,sparse_factor_controls]:
        fn(); print(fn.__name__,dict(COUNTS),flush=True)
    result={'status':'PASS','seed':103610132026,'counts':dict(COUNTS),'examples':EXAMPLES,
            'runtime_seconds':round(time.time()-t,3),'proof_file_sha256':hashlib.sha256((OUT/'THEOREM_v1_reviewed.md').read_bytes()).hexdigest()}
    (OUT/'CONTROL_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
