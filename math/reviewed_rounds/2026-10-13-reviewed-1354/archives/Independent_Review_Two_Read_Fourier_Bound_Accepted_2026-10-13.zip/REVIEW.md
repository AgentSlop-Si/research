# Independent review of the fresh two read Fourier endpoint theorem

13 October 2026 UTC

## Verdict

**ACCEPT as stated. No mathematical repair is required.** This accepts the self-contained proof in the exact file identified below, within its stated one-scalar-cyclic-scan and at-most-two-fixed-reads-per-output model. It does not establish novelty, unrestricted Fourier arithmetic lower bounds, or recovery of a previous unavailable candidate.

The accepted inequality is

    A >= max{N, ceil(N ceil(L/2) / min(L, 4 ceil(log_2 L) + 6))},

for 1 <= L <= N, an exact-order-N root over any field, arbitrary distinct selected Fourier rows, arbitrary finite M, and F = R(I-D S_M)^(-1)C with at most two nonzeros per row of R and product(d_t) != 1. Here A counts the nonzero scalar entries of C. In particular, the square case gives Omega(N^2/log N) injections in this restricted model.

## Exact identity and independence

Reviewed theorem: THEOREM_v1.md, copied byte-for-byte into this review bundle as THEOREM_v1_reviewed.md.

SHA-256: 55f316d15c3299757bd79e1d9c829bfc570637293f9d850f43e644f33bca5f9e

Author's sealed candidate ZIP: Two_Read_Fourier_Endpoint_Obstruction_New_Candidate_2026-10-13.zip

SHA-256: a0e2adbfa4add3c9420c464a1046ad582f725ed5cf6cabc427de8917a0c4e71e

Author's MANIFEST.json SHA-256: 5ee41815e4cfcd370a4cfbb9561ebe6ecfddd0086f89e47347e18718d9485f96

All three identities were independently rehashed. The mathematical review is based on the theorem text itself. The author's controls were read only as corroborating evidence. All executable checks supplied with this review were freshly implemented; no historical program or author control program was executed. This is a fresh independent acceptance, not an endorsement of the inaccessible earlier theorem bytes.

## Proof audit

### Invertibility and cyclic recurrence

The hypothesis product(d_t) != 1 is sufficient and necessary: traversing a homogeneous cycle gives v_t = product(d_t) v_t, so its only solution is zero under the hypothesis. The square matrix I-D S_M is therefore invertible. This argument also covers M=1, zero weights, and arbitrary characteristic. There is no implicit division by any individual d_t.

For a restricted column set J, if no row of C[:,J] is nonzero, invertibility gives V[:,J]=0. Otherwise, partition the cyclic order into blocks beginning at each forced row and ending immediately before the next forced row. Every state in a block is a scalar multiple of the block's initial state. A zero recurrence coefficient can only kill that direction until another forced row. Consequently there are at most k_J nonzero projective directions. The boundary between M-1 and 0 is an ordinary block segment, not an extra uncharged initial state. This is the key use of the single scalar recurrence.

### Graph peeling

When a vertex of degree at most two is removed, the number q of removed edges satisfies q<=2, including a loop, whose degree contribution is two but whose edge contribution is one. Hence m'-2n' = m-2n+(2-q) stays positive. The process cannot end at the empty graph, where this difference is zero. The remaining nonempty multigraph has minimum degree at least three; its vertex count is at most the original n, which is less than m/2<=L/2. Isolated vertices, long degree-two tendrils, loops, and disconnected components cause no problem.

### Breadth first search

Every vertex at distance less than r has all incident endpoints inside the induced radius-r ball. If the ball has at most one edge outside the BFS tree, the total number of its endpoints, counted with multiplicity, is at most two. A root-loop consumes both of those endpoints at level zero; a parallel parent edge is one of the non-tree edges, never an additional tree child. Therefore the level inequalities stated in the theorem are valid with multigraph degrees.

The worst total endpoint deficit is two at the earliest possible level. This gives a_j >= 2^(j-1), and the ball must contain at least 2^r vertices. With r=ceil(log_2 L)+1 this is greater than L. If the component is exhausted earlier, a later level is empty and directly contradicts the same inequality. The argument applies to any root in the peeled graph.

Two distinct non-tree edges together with their endpoint-to-root tree paths give a connected subgraph. The path union is a tree, including coincident or empty paths. Adding two distinct non-tree edges makes e=v+1, also for loops or parallel edges. At most four paths of length r and two additional edges are used, so e<=4r+2. The subgraph may retain a dangling root path and need not be an inclusion-minimal bicycle. Minimality is not required for the support-count contradiction.

### Sparse row factorization

A nonzero output row forces the corresponding row of B to have support one or two. Map a support-one row to a loop and a support-two row to an edge. If k<ceil(L/2), then L>2k; unused columns do not invalidate this inequality or the peeling. The short excess subgraph picks s rows supported in v=s-1 columns. Their products through U lie in the span of at most v rows of U, so are linearly dependent over every field.

This is only a dimension upper bound. It does not assume that arbitrary edge coefficients represent the full bicircular matroid, that all graph circuits are minimal linear dependencies, or that gains are generic. Additional coefficient cancellations can create earlier dependencies and cannot invalidate the contradiction. If h>=L, the proof correctly uses full row rank instead of the graph lemma.

### Consecutive Fourier columns

For a cyclic interval starting at c, row i is lambda_i^c times (1,lambda_i,...,lambda_i^(w-1)), where lambda_i=omega^(a_i). Wrapping the column residues does not change entries because lambda_i^N=1. Distinct row residues give distinct nonzero lambda_i by exact order. Any s<=w chosen rows have an invertible Vandermonde minor on the first s interval coordinates, with determinant equal to a nonzero row factor times a product of nonzero pairwise differences.

This argument has no prime-N assumption and does not require arbitrary Fourier minors to be nonzero. In a field of characteristic p>0, an element of order divisible by p cannot exist: x^p-1=(x-1)^p. Thus the existence assumption already excludes p|N; no extra restriction is being silently imposed. Extension fields of characteristic two are included.

### Compression and counting

Replace every nonzero restricted latent row with its scalar multiple of a representative of its projective direction. At most two read terms per output remain at most two representative terms. Equal directions combine and may cancel, but each restricted Fourier row contains only nonzero entries and cannot become the zero vector. Applying the sparse-factor lemma gives k_J>=ceil(L/2).

The window length w=min(L,b_L) obeys 1<=w<=N, so each window has w distinct columns. There are N windows indexed by their start, even when w=N makes their underlying column sets equal; this is deliberate multiplicity. Every column appears w times, so the sum of restricted injection counts is exactly wA. Finally, every Fourier column is nonzero, hence each corresponding column of C is nonzero and A>=N. Integer rounding is in the correct direction.

## Boundary and model controls

- N=L=M=1 is included and has minimum injection count one; one nonzero output read is also necessary. The proof does not claim that a single total endpoint suffices.
- L=1 or L=2 and every regime with w=L is handled without invoking a large-graph assumption. The direct A>=N term is retained.
- Zero weights, nonzero wrap coupling, arbitrary padding, repeated read locations after compression, single reads, and cancellation are allowed.
- The result counts scalar nonzeros of C. It does not count a dense injected linear form as one scalar operation, and is not an unrestricted arithmetic-complexity result.
- Three-read outputs, arbitrary-read outputs, vector-valued or interacting scans, data-dependent coefficients, and singular cyclic systems are outside this proof.
- If the read restriction is dropped, take D=0, C=I_N, R=F. At N=L=96 this has A=96, below the two-read bound 136, with 96 reads per output. This is an explicit reason the restriction matters.
- If invertibility is dropped, over F_3 take d=(1,1), C=0, and both rows of V equal to (1,2). There is one nonzero latent direction and zero forced rows. This invalidates the needed intermediate claim exactly where the hypothesis was removed.
- Nonconsecutive columns cannot replace consecutive windows. Over F_5, N=4 and omega=2, rows {0,2} and columns {0,2} form an all-ones, rank-one minor.

## Independent exact controls

All independent controls passed. The completed run checked 47,405 graphs across 181,676 BFS roots, including 42,649 exhaustive small multigraphs; 36,105 invertible recurrence instances and 158,676 column restrictions; 229,535 Fourier row-window rank checks, including 102,743 wrapped cases and 28,331 characteristic-two cases; 8,385 exact window-count identities; 4,400 weighted support-dependence cases; and 38 complete legal two-read factorizations. The principal run took 432.502 seconds.

The control code uses only standard-library Python, exact finite-field arithmetic and integer graph operations. It writes machine-readable results and ordinary run logs. Counts and scope are recorded in CONTROL_RESULTS.json and COMBINED_CONTROL_RESULTS.json; all assertions must pass for status PASS.

The graph checks independently perform peeling and BFS witness extraction, verify connectivity, check e=v+1, and check the stated size bound. They exhaust all labeled multigraphs on at most four vertices with each loop or nonloop edge multiplicity in {0,1,2} satisfying m>2n. Named controls add three loops on one vertex, five parallel edges, a dense core with isolates and a tendril, and mixed root-loop/parallel-edge cases. Larger simple examples go to 1,024 vertices; separate minimum-degree-three examples test the BFS subclaim even without the density premise of the full lemma.

The recurrence checks exhaust all two-column C matrices for F_2 with M<=4, F_3 with M<=3, and F_5 with M<=2, for all invertible weight patterns. Every column restriction, including the empty set, is checked. Further random sparse tests cover prime fields and F_4, F_8, F_16. Matrix inversion and direct substitution verify the cyclic equations and singularity criterion independently of the block-direction proof.

Fourier controls test consecutive and wrapped windows over prime and characteristic-two extension fields. Small orders use exhaustive row subsets; larger orders use seeded exact samples. The composed-factorization controls build legal two-read representations, reconstruct V from C using matrix inversion, verify R V=F, and check each window bound and the complete nonzero-count identity. Deliberately excluded-model examples are tested separately.

These finite tests are corroboration. They neither prove the universal theorem nor enumerate all legal factorizations, all coefficient fields, or all multigraphs.

## Primary prior work and novelty boundary

1. Mohanty, O'Donnell and Paredes, *Explicit near-Ramanujan graphs of every degree*, author manuscript dated 5 October 2019, Section 2.2.2, Definitions 2.9-2.11 and the following paragraph. The paper defines multigraph excess and bicyclic graphs, identifies radius-r bicycle-freeness with BFS encountering at most one non-tree edge, and observes a logarithmic radius limit for regular graphs. This is a close conceptual antecedent of Lemma 1. The exact constants and minimum-degree reduction here are proved independently. [Author-hosted paper](https://www.cs.cmu.edu/~odonnell/papers/explicit-near-ramanujan.pdf).

2. Jun-Ting Hsieh, *Algorithms and Explicit Constructions via Spectral Techniques*, CMU-CS-25-131, August 2025, Theorem 3.1.3 and Section 4.1. It gives a generalized Moore bound for short cycles and bicycles in terms of the non-backtracking spectral radius. This is a further explicit antecedent of logarithmic-size bicycle arguments. I have not substituted its theorem for the current proof or transferred its graph conventions to the multigraph setting without checking them. [University-hosted thesis](https://csd-web-01.andrew.cmu.edu/sites/default/files/phd-thesis/CMU-CS-25-131.pdf).

3. Funk, Mayhew and Newman, *Defining bicircular matroids in monadic logic*, Introduction. This primary research paper describes the standard bicycle circuits: theta subgraphs, loose handcuffs, and tight handcuffs, and identifies them as circuits of B(G). The present support argument only needs e>v, and does not need an exact representation theorem for a bicircular matroid over the coefficient field. [Author-hosted paper](https://dillon128.github.io/FMN-III.pdf).

4. Kumar and Volk, *Lower Bounds for Matrix Factorization*, Sections 1.1 and 1.3. Sparse factorizations, depth-two linear circuits, and linear data-structure query/update costs are an established framework. Section 1.1 also explains the classical rank-through-a-cut argument. The proof reviewed here imposes a special scalar recurrence and two reads, so its injection lower bound cannot be promoted to the general sparse-factorization or unrestricted linear-circuit problem. [Author-hosted paper](https://benleevolk.bitbucket.io/pdf/matrix-factorization.pdf).

The scoped search did not establish whether this exact recurrence-plus-consecutive-Fourier-window composition has appeared before. It did establish substantial antecedents for its ingredients. The safe description is a fresh self-contained proof of a restricted-model bound, with no novelty or priority claim. A comprehensive novelty assessment would require a separate systematic search.

## Recommendation

Retain the theorem and exact scope unchanged. Add the prior-work context above when preparing a public exposition, while keeping the current elementary proof as its own dependency chain. Do not replace its consecutive-column Vandermonde argument with a prime-only arbitrary-minor theorem or replace its support-count argument with an unjustified generic-gain claim. The existing v1 theorem itself needs no repair.
