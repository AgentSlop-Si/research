# Fresh reconstruction: a two-read Fourier endpoint obstruction

13 October 2026 UTC. Status: new candidate, proved below; independent review not yet obtained. This is not a recovery of the unavailable prior candidate. No external novelty or priority claim is made.

## Statement

Let K be any field, let N >= 1, and let omega in K have exact multiplicative order N. Select L distinct residues a_1,...,a_L modulo N, where 1 <= L <= N. Let F be the L-by-N matrix F[i,j] = omega^(a_i j), for j = 0,...,N-1.

Suppose

    F = R (I - D S_M)^(-1) C,

where M >= 1, S_M is the scalar cyclic predecessor permutation, D = diag(d_t), the product of all d_t is not 1, C is M-by-N, and R is L-by-M with at most two nonzero entries per row. All coefficients and choices are fixed independently of the input. Set A = nnz(C). Zero weights, arbitrary M, padding, arbitrary read locations and arbitrary cancellation are allowed.

Put

    b_L = 4 ceil(log_2 L) + 6,
    w_L = min(L, b_L).

Then

    A >= max{N, ceil(N ceil(L/2) / w_L)}.

In particular, when b_L <= N, the slightly weaker bound

    A >= ceil(N ceil(L/2) / b_L)

holds. For L=N this is Omega(N^2 / log N). This bounds scalar injection nonzeros, not unrestricted arithmetic complexity. Output-read cost is separately nnz(R), between L and 2L. The theorem does not cover three or more reads per output or interacting scans.

The logarithm in b_L is used only for the combinatorial estimate. The definition w_L=min(L,b_L) supplies an all-size statement without requesting a window longer than N.

## Lemma 1: short excess subgraph

Let G be a finite undirected multigraph with n vertices and m edges, permitting loops and parallel edges. If m > 2n and m <= L, G contains a connected subgraph H with

    |E(H)| = |V(H)| + 1,
    |E(H)| <= 4 ceil(log_2 L) + 6.

Proof. Iteratively delete vertices of degree at most 2, counting a loop twice in degree. Each deletion removes at most two edges, so the strict inequality m > 2n persists for the remaining graph. The process cannot end with the empty graph. The remaining nonempty multigraph G' has minimum degree at least 3 and at most L vertices, because its vertex count is at most the original n < m/2 <= L/2.

Take a root in G', a breadth-first-search tree, and r = ceil(log_2 L)+1. Let B_r be the vertices at graph distance at most r from the root, and retain every edge with both endpoints in B_r. Suppose this induced multigraph has at most one edge outside the BFS tree. For each i, write a_i for the number of vertices at distance i, and b_i for the number of endpoints of that one extra edge lying at distance i; a loop contributes two endpoints. If there is no extra edge, all b_i are zero. Thus sum b_i <= 2.

Every vertex at distance less than r has all its neighbors inside B_r. A non-root vertex has exactly one tree-parent edge, and all other tree edges lead to children. Minimum degree at least 3 therefore gives

    a_1 >= 3 - b_0,
    a_(i+1) >= 2 a_i - b_i,       1 <= i < r.

Induction yields, for 1 <= j <= r,

    a_j >= 3*2^(j-1) - sum_(i=0)^(j-1) 2^(j-1-i) b_i
        >= 2^(j-1).

Consequently |B_r| >= 1 + sum_(j=1)^r 2^(j-1) = 2^r > L, contradicting |V(G')| <= L. This also covers a BFS that exhausts its component before depth r: then a later a_j=0 contradicts the same inequality.

Thus B_r has at least two distinct non-tree edges. Choose two, and take the union of their endpoints' root paths in the BFS tree, followed by those two edges. The tree-path union is connected and acyclic, including the case that some paths are empty or coincide. Adding the two distinct non-tree edges gives precisely two independent graph cycles, so e=v+1. At most four paths of length r and two extra edges occur, hence e <= 4r+2 = b_L. Loops and parallel edges require no exception. QED.

## Lemma 2: two-sparse row factorization

Let Y be a matrix with L nonzero rows. Suppose every subset of at most h rows is linearly independent. If h >= min(L,b_L), and Y = B U with B having at most two nonzeros per row and k columns, then k >= ceil(L/2).

Proof. If h>=L, rank(Y)=L and k>=L. Otherwise h>=b_L. Remove unused columns of B if desired. Each row of B has one or two nonzeros, since Y's rows are nonzero. Create one graph edge per row, joining its two support columns; a singleton support is represented by a loop. If k<ceil(L/2), then L>2k. Lemma 1 supplies s<=b_L<=h rows supported on fewer than s vertices. Their product rows in Y lie in a space spanned by those fewer than s rows of U, hence are dependent. This contradicts the hypothesis. QED.

## Lemma 3: injection-window directions

Set V=(I-D S_M)^(-1)C, so v_t=d_t v_(t-1)+c_t with cyclic indices. Fix any input-column set J. Let k_J count the indices t for which c_t restricted to J is nonzero. All nonzero rows of V restricted to J lie in at most k_J projective directions.

Proof. If k_J=0, then C[:,J]=0 and invertibility gives V[:,J]=0. If k_J>0, start after any forced row and traverse the cyclic order. Between consecutive forced rows, repeated use of the homogeneous recurrence makes each row a scalar multiple of the last forced state's row. A zero d_t may make it zero but cannot create a new nonzero direction. This charges each nonzero direction to one of the k_J forced-row states. No division by d_t is used. QED.

## Proof of the theorem

For each cyclic interval J of w_L consecutive column indices, ordered cyclically, the restricted Fourier rows have the form

    lambda_i^s (1, lambda_i, ..., lambda_i^(w_L-1)),
    lambda_i = omega^a_i.

Wrapping exponents past N does not alter this formula because lambda_i^N=1. The lambda_i are distinct and nonzero. Any s<=w_L selected rows are independent: their first s coordinates form a Vandermonde determinant, a product of nonzero row factors and pairwise differences lambda_j-lambda_i. This proof works in every characteristic and for composite N.

By Lemma 3 choose at most k_J nonzero representative latent-row directions. Express each latent row as a scalar multiple of its representative, or as zero. Each output, originally a sum of at most two latent rows, becomes a sum of at most two representatives. Coincident representatives combine; cancellation can reduce a support, but it cannot produce the zero output row. Thus F[:,J] has a two-sparse row factorization through at most k_J representative rows. Lemma 2 gives k_J >= ceil(L/2).

Since k_J <= nnz(C[:,J]), every such window contains at least ceil(L/2) injection nonzeros. There are N cyclic windows, with starting indices 0,...,N-1, and each input column occurs in exactly w_L windows. Counting nonzeros with multiplicity yields

    w_L A = sum_J nnz(C[:,J]) >= N ceil(L/2).

Finally every column of F is nonzero. A zero column of C would give a zero output column, so every column of C contains an injection and A>=N. Integer rounding proves the stated bound. QED.

## Explicit boundaries and limitations

- L=1: w_L=1 and the theorem gives A>=N. One dense latent injection row achieves A=N and one read, with a reset weight.
- N=L=1: A>=1 and nnz(R)>=1, so the scalar endpoint minimum is 2. The theorem never claims one endpoint.
- L=2: w_L=2; the general A>=N term is retained. No small-N exceptional graph assumption is used.
- The bound is field-independent provided an exact-order root exists. In positive characteristic, existence already rules out characteristic dividing N. No Chebotarev or total-nonsingularity theorem is invoked.
- The graph bound is not claimed sharp. No claim is made that a general unrestricted-read one-Green factorization needs this many endpoints.
- The prior published one-read/masked-block report is a model/provenance reference, not a proof dependency for the new two-read result. Its prime-only two-by-two-minor argument must not be substituted for the consecutive-column Vandermonde argument here.

## Source inspected

AgentSlop-Si/research, math/reviewed_rounds/2026-10-12-reviewed-research/sparse-endpoint-obstructions.md, fetched through the connected GitHub tool on 13 October 2026. GitHub blob SHA b2862c2be105712bb6313184d09620b4b062c6fe. The report binds its separate accepted theorem to SHA-256 65dde91db7cb97abe32220c74cdd9ffbaa372a22dc186211f51124970c4149da; those theorem bytes were not recovered or rehashed here.
