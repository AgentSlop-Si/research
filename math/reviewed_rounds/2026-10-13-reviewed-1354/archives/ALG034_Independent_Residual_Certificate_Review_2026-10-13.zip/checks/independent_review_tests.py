#!/usr/bin/env python3
"""Independent exact/interval tests. Imports only the newly authored candidate verifier.
No historical source is imported or executed. The direct oracle and exact algebra
below do not use candidate phases, roots, interval classes, producer, or DFT oracle.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import gcd, factorial, isqrt, comb
from pathlib import Path
import importlib.util, json, random, hashlib
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('new_candidate',ROOT/'replay/certified_checker.py')
cv=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(cv)
COUNTS={}
def count(k,n=1):COUNTS[k]=COUNTS.get(k,0)+n

def dyadlo(x,p=190):return F((x.numerator*2**p)//x.denominator,2**p)
def dyadhi(x,p=190):return -dyadlo(-x,p)
class R:
    def __init__(self,l=0,u=None):
        if isinstance(l,R):self.l,self.u=l.l,l.u
        else:self.l,self.u=F(l),F(l if u is None else u)
        assert self.l<=self.u
    def __add__(a,b):
        b=R(b);return R(dyadlo(a.l+b.l),dyadhi(a.u+b.u))
    __radd__=__add__
    def __neg__(a):return R(-a.u,-a.l)
    def __sub__(a,b):return a+-R(b)
    def __mul__(a,b):
        b=R(b);v=[a.l*b.l,a.l*b.u,a.u*b.l,a.u*b.u]
        return R(dyadlo(min(v)),dyadhi(max(v)))
    __rmul__=__mul__
    def inv(a):
        assert a.l>0 or a.u<0
        return R(dyadlo(1/a.u),dyadhi(1/a.l))
    def upperabs(a):return max(abs(a.l),abs(a.u))
    def lowerabs(a):return F(0) if a.l<=0<=a.u else min(abs(a.l),abs(a.u))
    def mid(a):return (a.l+a.u)/2
class Z:
    def __init__(self,a=0,b=0):
        if isinstance(a,Z):self.a,self.b=a.a,a.b
        elif isinstance(a,tuple):self.a,self.b=R(a[0]),R(a[1])
        else:self.a,self.b=R(a),R(b)
    def __add__(x,y):y=Z(y);return Z(x.a+y.a,x.b+y.b)
    __radd__=__add__
    def __neg__(x):return Z(-x.a,-x.b)
    def __sub__(x,y):return x+-Z(y)
    def __mul__(x,y):y=Z(y);return Z(x.a*y.a-x.b*y.b,x.a*y.b+x.b*y.a)
    __rmul__=__mul__
    def bar(x):return Z(x.a,-x.b)
    def mid(x):return x.a.mid(),x.b.mid()
    def modulus2_upper(x):return x.a.upperabs()**2+x.b.upperabs()**2
    def modulus2_lower(x):return x.a.lowerabs()**2+x.b.lowerabs()**2

def sqrtR(v):
    v=F(v);k=isqrt((v.numerator*2**380)//v.denominator);lo=F(k,2**190)
    return R(lo,lo if lo*lo==v else F(k+1,2**190))
@lru_cache(None)
def independent_pi():
    # atan(1/2)+atan(1/3)=pi/4, both in (0,pi/4).
    def arctan(q):
        s=F(0)
        for j in range(230):s+=F((-1)**j,(2*j+1)*q**(2*j+1))
        nxt=F(1,(461)*q**461)
        return R(s,s+nxt) # last included term was negative
    return (arctan(2)+arctan(3))*4
@lru_cache(None)
def phase(e,n):
    e%=2*n
    if e==0:return Z(1)
    if e==n:return Z(-1)
    if 2*e==n:return Z(0,1)
    if 2*e==3*n:return Z(0,-1)
    if e>n:e-=2*n
    theta=independent_pi()*F(e,n);t=theta.mid();rad=(theta.u-theta.l)/2
    # Fixed-degree independently rounded interval recurrence. The exact midpoint
    # Taylor sum is enclosed; |t|<4 bounds the uncomputed alternating tail.
    assert abs(t)<4
    minus_t2=R(-t*t);si=R(t);co=R(1);st=R(t);ct=R(1)
    for j in range(1,90):
        st=st*minus_t2*F(1,(2*j)*(2*j+1));si=si+st
        ct=ct*minus_t2*F(1,(2*j-1)*(2*j));co=co+ct
    se=F(4**181,factorial(181))+rad
    ce=F(4**180,factorial(180))+rad
    return Z(R(dyadlo(co.l-ce),dyadhi(co.u+ce)),R(dyadlo(si.l-se),dyadhi(si.u+se)))

def partition(n,b):
    lengths=[n//b+int(j<n%b) for j in range(b)];starts=[];s=0
    for v in lengths:starts.append(s);s+=v
    return starts,lengths

def direct_target(x,n,b,a,beta):
    # Definition P=vv*: independently build time-domain rank-one blocks then DFT.
    starts,lengths=partition(n,b);y=[];h=n%2
    for start,length in zip(starts,lengths):
        local=[phase(a*t*(t-1)+2*(a*start+beta)*t+h*t,n) for t in range(length)]
        d=sum((z*Z(v) for z,v in zip(local,x[start:start+length])),Z())
        y.extend(z.bar()*d for z in local)
    scale=Z(sqrtR(n).inv())
    return [sum((phase(-2*k*j,n)*v for j,v in enumerate(y)),Z())*scale for k in range(n)]

def direct_errors(x,Y,n,b,a,beta):
    t=direct_target(x,n,b,a,beta);e=[Z(v)-z for v,z in zip(Y,t)]
    return max(z.modulus2_upper() for z in e),sum(z.modulus2_upper() for z in e),max(z.modulus2_lower() for z in e)

def randomvec(rng,m,scale=F(1)):
    return [(scale*F(rng.randint(-20,20),8),scale*F(rng.randint(-20,20),8)) for _ in range(m)]

def test_primitives():
    for den in range(1,26):
        for e in range(-den,den+1):
            z=phase(e,den)
            for p in [4,12,32,64,100]:
                t=cv.root_pi(e,den,p)
                assert t.re.lo<=z.a.l<=z.a.u<=t.re.hi,('rootreal',e,den,p)
                assert t.im.lo<=z.b.l<=z.b.u<=t.im.hi,('rootimag',e,den,p)
                count('root_rectangles_enclose_independent_oracle')
    rng=random.Random(34001)
    for p in [2,9,40,100]:
        cv.P=p
        for _ in range(400):
            u,v=sorted([F(rng.randrange(-1000,1001),rng.randrange(1,99)) for j in range(2)])
            w,z=sorted([F(rng.randrange(-1000,1001),rng.randrange(1,99)) for j in range(2)])
            x,y=cv.I(u,v),cv.I(w,z)
            plus=x+y;times=x*y
            assert plus.lo<=u+w and plus.hi>=v+z
            vals=[u*w,u*z,v*w,v*z];assert times.lo<=min(vals) and times.hi>=max(vals)
            if u>0 or v<0:
                inv=x.inv();assert inv.lo<=1/v and inv.hi>=1/u;count('reciprocal_inclusions')
            q=abs(u*v);rt=cv.sqrt_interval(q,p)
            assert rt.lo**2<=q<=rt.hi**2;count('scalar_arithmetic_groups')

def test_exact_four_roots():
    roots=[(F(1),F(0)),(F(0),F(1)),(F(-1),F(0)),(F(0),F(-1))]
    def add(z,w):return z[0]+w[0],z[1]+w[1]
    def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
    def bar(z):return z[0],-z[1]
    rng=random.Random(34102)
    for b in [3,4]:
      for a in [1,3]:
       for beta in range(4):
        for it in range(12):
          x=randomvec(rng,4,F(2)**([-90,0,70][it%3]));y=[];starts,lengths=partition(4,b)
          for s,le in zip(starts,lengths):
            loc=[roots[(a*t*(t-1)//2+(a*s+beta)*t)%4] for t in range(le)]
            d=(F(0),F(0))
            for z,w in zip(loc,x[s:s+le]):d=add(d,mul(z,w))
            y.extend(mul(bar(z),d) for z in loc)
          truth=[]
          for k in range(4):
            val=(F(0),F(0))
            for j,v in enumerate(y):val=add(val,mul(v,roots[(-k*j)%4]))
            truth.append((val[0]/2,val[1]/2))
          Y=randomvec(rng,4,F(2)**([-90,0,70][it%3])) if it%2 else truth
          row=dict(n=4,b=b,a=a,beta=beta,x=x,Y=Y,d=randomvec(rng,b),D=randomvec(rng,4),E=randomvec(rng,4),f=randomvec(rng,4))
          err=[(z[0]-w[0])**2+(z[1]-w[1])**2 for z,w in zip(Y,truth)]
          c=cv.certificate(row,120);o=cv.output_only_certificate({k:row[k] for k in ['n','b','a','beta','x','Y']},120)
          assert max(err)<=c['epsilon_inf']**2 and sum(err)<=c['epsilon_2']**2
          assert max(err)<=o['epsilon_inf']**2
          count('exact_fourth_root_rows')

def test_arbitrary_rows():
    rng=random.Random(34303)
    for n in range(3,18):
      for b in sorted({3,(n+1)//2,n}):
       if b<3:continue
       for a in [j for j in range(1,n) if gcd(j,n)==1][::max(1,(n-1)//4)]:
        beta=rng.randrange(n)
        for p in [7,45]:
          x=randomvec(rng,n);Y=randomvec(rng,n)
          row=dict(n=n,b=b,a=a,beta=beta,x=x,Y=Y,d=randomvec(rng,b),D=randomvec(rng,n),E=randomvec(rng,n),f=randomvec(rng,n))
          c=cv.certificate(row,p);minimal={k:row[k] for k in ['n','b','a','beta','x','Y']};o=cv.output_only_certificate(minimal,p)
          ei,e2,el=direct_errors(x,Y,n,b,a,beta)
          assert ei<=c['epsilon_inf']**2 and e2<=c['epsilon_2']**2,(n,b,a,p)
          assert ei<=o['epsilon_inf']**2,(n,b,a,p,'outputonly')
          # Output-only result cannot depend on or inspect producer checkpoints.
          bad=dict(minimal,d=object(),D=None,E='wrong',f={'bad':True},nodes='untrusted')
          assert cv.output_only_certificate(bad,p)==o
          count('arbitrary_unrelated_checkpoint_rows');count('output_only_no_checkpoint_trust')

def test_mutations():
    rng=random.Random(34504)
    cases=[(7,3,3,6),(9,5,4,2),(12,4,5,11),(13,6,7,3),(16,16,3,8)]
    data=[]
    for n,b,a,beta in cases:
      x=randomvec(rng,n);truth=direct_target(x,n,b,a,beta);Y=[z.mid() for z in truth]
      for label,yy in [('oracle_midpoints',Y),('one_output',[(v[0]+F(j==n-1,4),v[1]) for j,v in enumerate(Y)]),('cycle_order',[Y[a*j%n] for j in range(n)]),('zero_output',[(F(0),F(0))]*n)]:
        row=dict(n=n,b=b,a=a,beta=beta,x=x,Y=yy);c=cv.output_only_certificate(row,85);ei,e2,el=direct_errors(x,yy,n,b,a,beta)
        assert ei<=c['epsilon_inf']**2
        threshold=F(1,2**25)
        if label=='oracle_midpoints':assert c['epsilon_inf']<threshold
        elif label!='cycle_order' or yy!=Y:assert c['epsilon_inf']>=threshold
        data.append(dict(n=n,b=b,a=a,beta=beta,mutation=label,bound=str(c['epsilon_inf']),actual_error2_lower=str(el)))
        count('independent_output_mutation_rows')
    # Exact homogeneous-cycle trap: make all but wrap residual vanish for x=0.
    n=4;a=1;beta=0;Y=[(F(1),F(0)),(F(1),F(0)),(F(0),F(1)),(F(0),F(-1))]
    residual=[Z(Y[k])-phase(-2*k,n)*Z(Y[(k+1)%n]) for k in range(n)]
    assert all(z.modulus2_upper()==0 for z in residual[:-1]) and residual[-1].modulus2_lower()==4
    row=dict(n=n,b=3,a=a,beta=beta,x=[(F(0),F(0))]*n,Y=Y)
    c=cv.output_only_certificate(row,90)
    assert c['epsilon_inf']>=1;count('single_wrap_only_defect')
    # New producer faults exercised separately; never used as oracle.
    for fault in ['compression','boundary','nodes','coefficients','reciprocal','seed','normalization','forcing','closure','mapping','output','parity']:
      n,b,a,beta=9,4,2,3;x=randomvec(rng,n)
      row=cv.producer(x,n,b,a,beta,44,fault);c=cv.certificate(row,85);o=cv.output_only_certificate(row,85)
      ei,e2,el=direct_errors(x,row['Y'],n,b,a,beta)
      assert ei<=c['epsilon_inf']**2 and e2<=c['epsilon_2']**2 and ei<=o['epsilon_inf']**2
      assert c['epsilon_inf']>F(1,1024)*c['X_lower'];count('new_producer_faults_independent_oracle')
    # Exact shared common-mode channel corruption must cancel completely.
    row=cv.producer(randomvec(rng,9),9,4,2,3,44);base=cv.certificate(row,85)
    for j in range(9):
        common=(F(2)**140+F(j,7),-F(2)**130)
        for key in ['D','E']:row[key][j]=(row[key][j][0]+common[0],row[key][j][1]+common[1])
    assert cv.certificate(row,85)==base;count('common_mode_channel_cancellation')
    # Exact wrong-source, exact solve: no rounding excuse can hide the trap.
    roots=[(F(1),F(0)),(F(0),F(1)),(F(-1),F(0)),(F(0),F(-1))]
    def pa(z,w):return z[0]+w[0],z[1]+w[1]
    def pm(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
    def ps(z,w):return z[0]-w[0],z[1]-w[1]
    x=[(F(1),F(0))]+[(F(0),F(0))]*3
    truth=[z.mid() for z in direct_target(x,4,3,1,0)]
    basef=[ps(truth[k],pm(roots[-k%4],truth[(k+1)%4])) for k in range(4)]
    f=[pa(v,(F(1,2),F(0))) for v in basef]
    term=f[:];tot=f[:]
    for _ in range(3):
        term=[pm(roots[-k%4],term[(k+1)%4]) for k in range(4)]
        tot=[pa(u,v) for u,v in zip(tot,term)]
    Y=[(v[0]/2,v[1]/2) for v in tot]
    row=dict(n=4,b=3,a=1,beta=0,x=x,Y=Y,d=[(F(1),F(0)),(F(0),F(0)),(F(0),F(0))],D=[(2*v[0],2*v[1]) for v in f],E=[(F(0),F(0))]*4,f=f)
    c=cv.certificate(row,100)
    assert c['green_residual_inf']==0 and c['normalization_error']==0 and c['compression_inf']==0
    assert c['recurrence_defect']==0 and c['seed_defect']>0 and c['source_error']>0
    ei,e2,el=direct_errors(x,Y,4,3,1,0)
    assert el>0 and ei<=c['epsilon_inf']**2
    count('exact_zero_residual_wrong_source_trap')
    return data

# Exact cyclotomic quotient ring; Phi_N built by exact monic polynomial division.
def trim(p):
    while len(p)>1 and p[-1]==0:p.pop()
    return p

def int_div(p,q):
    p=p[:];out=[0]*max(1,len(p)-len(q)+1)
    while len(p)>=len(q):
        k=len(p)-len(q);v=p[-1];out[k]=v
        for j,w in enumerate(q):p[k+j]-=v*w
        trim(p)
        if p==[0]:break
    assert p==[0];return trim(out)
@lru_cache(None)
def cyclo(n):
    p=[-1]+[0]*(n-1)+[1]
    for d in range(1,n):
        if n%d==0:p=int_div(p,cyclo(d))
    return p

def test_exact_complement():
    for n in range(3,22):
      mod=cyclo(n);d=len(mod)-1;zero=(0,)*d;one=(1,)+(0,)*(d-1)
      def red(p):
        p=p[:]
        while len(p)>d:
          v=p.pop();k=len(p)-d
          for j in range(d):p[k+j]-=v*mod[j]
        return tuple(p+[0]*(d-len(p)))
      def plus(x,y):return tuple(a+b for a,b in zip(x,y))
      def minus(x):return tuple(-a for a in x)
      def times(x,y):
        p=[0]*(2*d-1)
        for j,a in enumerate(x):
          for k,b in enumerate(y):p[j+k]+=a*b
        return red(p)
      powers=[red([0]*j+[1]) for j in range(n)]
      def poly(inds):
        q=[one]
        for j in inds:
          z=[zero]*(len(q)+1);lam=powers[-j%n]
          for k,v in enumerate(q):z[k]=plus(z[k],v);z[k+1]=plus(z[k+1],minus(times(lam,v)))
          q=z
        return q
      for b in range(3,n+1):
        starts,_=partition(n,b);Q=poly(starts);C=poly([j for j in range(n) if j not in starts]);prod=[zero]*(n+1)
        for j,u in enumerate(Q):
          for k,v in enumerate(C):prod[j+k]=plus(prod[j+k],times(u,v))
        assert prod==[one]+[zero]*(n-1)+[minus(one)]
        inv=[one]
        for k in range(1,n):
          val=zero
          for j in range(1,min(k,b)+1):val=plus(val,times(Q[j],inv[k-j]))
          inv.append(minus(val))
        assert inv==C+[zero]*(n-len(C));count('exact_cyclotomic_complement_and_inverse')

def main():
    test_primitives();print('Primitive inclusions passed',flush=True)
    test_exact_four_roots();print('Exact fourth-root controls passed',flush=True)
    test_arbitrary_rows();print('Arbitrary checkpoint and output-only rows passed',flush=True)
    mutations=test_mutations();print('Mutation controls passed',flush=True)
    test_exact_complement();print('Exact complement identities passed',flush=True)
    result={'status':'PASS','counts':COUNTS,'historical_code_executed':False,'candidate_main_executed':False,'independent_oracle':'Separate rational rectangles, pi=4(atan(1/2)+atan(1/3)), fixed Taylor tails, direct rank-one projection plus DFT; exact rational fourth roots; integer cyclotomic quotient rings','mutation_results':mutations,'candidate_verifier_sha256':hashlib.sha256((ROOT/'replay/certified_checker.py').read_bytes()).hexdigest()}
    (ROOT/'INDEPENDENT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','counts':COUNTS},indent=2))
if __name__=='__main__':main()
