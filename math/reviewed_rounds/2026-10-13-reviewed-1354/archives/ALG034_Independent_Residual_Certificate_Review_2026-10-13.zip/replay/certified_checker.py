#!/usr/bin/env python3
"""Fresh ALG034 small-case producer and deterministic dyadic interval checker.

No historical program is imported or executed. All certificate arithmetic uses
fractions.Fraction, integer arithmetic, and outward dyadic rounding. The fresh
producer uses rounded rational complex arithmetic and naive block convolution;
it is a reference test producer, not the historical NumPy/FFT executor.
"""
from fractions import Fraction as F
from math import gcd, comb, factorial, isqrt
from functools import lru_cache
import json
from pathlib import Path

P = 100
COUNTS = {"interval_add": 0, "interval_mul": 0}

def down(x, p=None):
    p = P if p is None else p
    return F((x.numerator << p) // x.denominator, 1 << p)

def up(x, p=None):
    return -down(-x, p)

class I:
    def __init__(self, lo=0, hi=None):
        if isinstance(lo, I):
            self.lo, self.hi = lo.lo, lo.hi
            return
        self.lo, self.hi = F(lo), F(lo if hi is None else hi)
        assert self.lo <= self.hi
    def __add__(self, b):
        b=I(b); COUNTS['interval_add']+=1
        return I(down(self.lo+b.lo), up(self.hi+b.hi))
    __radd__=__add__
    def __neg__(self): return I(-self.hi,-self.lo)
    def __sub__(self,b): return self+-I(b)
    def __rsub__(self,b): return I(b)+-self
    def __mul__(self,b):
        b=I(b); COUNTS['interval_mul']+=1
        v=[self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi]
        return I(down(min(v)),up(max(v)))
    __rmul__=__mul__
    def inv(self):
        assert self.lo>0 or self.hi<0
        return I(down(1/self.hi),up(1/self.lo))
    def __truediv__(self,b): return self*I(b).inv()
    def midpoint(self): return (self.lo+self.hi)/2
    def abs_upper(self): return max(abs(self.lo),abs(self.hi))

class C:
    def __init__(self,re=0,im=0):
        if isinstance(re,C): self.re,self.im=re.re,re.im
        elif isinstance(re,tuple): self.re,self.im=I(re[0]),I(re[1])
        else: self.re,self.im=I(re),I(im)
    def __add__(self,b):
        b=C(b); return C(self.re+b.re,self.im+b.im)
    __radd__=__add__
    def __neg__(self): return C(-self.re,-self.im)
    def __sub__(self,b): return self+-C(b)
    def __rsub__(self,b): return C(b)+-self
    def __mul__(self,b):
        b=C(b); return C(self.re*b.re-self.im*b.im,self.re*b.im+self.im*b.re)
    __rmul__=__mul__
    def conj(self): return C(self.re,-self.im)
    def abs_upper(self): return self.re.abs_upper()+self.im.abs_upper()
    def midpoint(self): return (self.re.midpoint(),self.im.midpoint())

@lru_cache(None)
def pi_interval(p):
    # Machin identity pi=16 atan(1/5)-4 atan(1/239), alternating remainders.
    def atan_inv(q):
        s=F(0);j=0
        while True:
            t=F((-1)**j,(2*j+1)*q**(2*j+1));s+=t
            nxt=F((-1)**(j+1),(2*j+3)*q**(2*j+3))
            if abs(nxt)<F(1,1<<(p+12)):
                return min(s,s+nxt),max(s,s+nxt)
            j+=1
    a,b=atan_inv(5),atan_inv(239)
    return I(down(16*a[0]-4*b[1],p+5),up(16*a[1]-4*b[0],p+5))

@lru_cache(None)
def root_pi(num,den,p):
    # exp(pi*i*num/den); exact integer reduction and certified Taylor remainder.
    num%=2*den
    if num>den:num-=2*den
    if num==0:return C(1)
    if num==den or num==-den:return C(-1)
    if 2*num==den:return C(0,1)
    if 2*num==-den:return C(0,-1)
    pi=pi_interval(p+8)
    lo,hi=sorted([pi.lo*F(num,den),pi.hi*F(num,den)])
    t=(lo+hi)/2; rad=(hi-lo)/2; a=abs(t)
    m=0
    while a**(2*m+1)/factorial(2*m+1)>F(1,1<<(p+8)):m+=1
    co=sum(((-1)**j*t**(2*j)/factorial(2*j) for j in range(m+1)),F(0))
    si=sum(((-1)**j*t**(2*j+1)/factorial(2*j+1) for j in range(m+1)),F(0))
    ec=a**(2*m+1)/factorial(2*m+1)+rad
    es=a**(2*m+2)/factorial(2*m+2)+rad
    return C(I(down(co-ec,p),up(co+ec,p)),I(down(si-es,p),up(si+es,p)))

def sqrt_interval(q,p=None):
    p=P if p is None else p;q=F(q);assert q>=0
    k=isqrt((q.numerator<<(2*p))//q.denominator)
    lo=F(k,1<<p)
    return I(lo,lo if lo*lo==q else F(k+1,1<<p))

def invsqrt(n): return sqrt_interval(n).inv()

def validate(n,b,a,beta):
    if not(3<=b<=n and 0<a<n and gcd(a,n)==1 and 0<=beta<n):
        raise ValueError('invalid dimensions or state')
    lens=[n//b+(j<n%b) for j in range(b)]
    starts=[];s=0
    for le in lens:starts.append(s);s+=le
    assert s==n and 2*(max(lens)-1)<n
    return starts,lens

def phases(n,b,a,beta,p):
    starts,lens=validate(n,b,a,beta);h=n%2
    R=lambda e:root_pi(e,n,p)
    loc=[[R(2*(a*t*(t-1)//2+(a*s+beta)*t)+h*t) for t in range(le)] for s,le in zip(starts,lens)]
    boundary=[R(-2*(a*le*(le-1)//2+a*s*le+beta*le)-h*le) for s,le in zip(starts,lens)]
    nodes=[R(-2*s) for s in starts]
    alpha=[R(-2*(k+beta)-h) for k in range(n)]
    gauge=[R(2*(a*j*(j-1)//2+beta*j)+h*j) for j in range(n)]
    return starts,lens,loc,boundary,nodes,alpha,gauge

ZERO=(F(0),F(0));ONE=(F(1),F(0))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def sub(a,b):return add(a,neg(b))
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def div(a,b):
    d=b[0]*b[0]+b[1]*b[1];assert d
    return ((a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d)
def abs1(a):return abs(a[0])+abs(a[1])
def quant(a,p):return (down(a[0]+F(1,1<<(p+1)),p),down(a[1]+F(1,1<<(p+1)),p))

def producer(x,n,b,a,beta,p=40,fault=None):
    """Independently authored rounded two-channel blocked recurrence producer."""
    global P
    P=p+20
    starts,lens,loc,bc,nodes,alpha,gauge=phases(n,b,a,beta,p+15)
    if fault=='parity':
        R0=lambda e:root_pi(e,n,p+15)
        loc=[[R0(2*(a*t*(t-1)//2+(a*s+beta)*t)) for t in range(le)] for s,le in zip(starts,lens)]
        bc=[R0(-2*(a*le*(le-1)//2+a*s*le+beta*le)) for s,le in zip(starts,lens)]
        gauge=[R0(2*(a*j*(j-1)//2+beta*j)) for j in range(n)]
    R=lambda z:quant(z.midpoint(),p)
    loc=[[R(v) for v in vv] for vv in loc];bc=list(map(R,bc));nodes=list(map(R,nodes));gauge=list(map(R,gauge))
    plus=lambda x,y:quant(add(x,y),p)
    times=lambda x,y:quant(mul(x,y),p)
    quotient=lambda x,y:quant(div(x,y),p)
    def dot(u,v):
        z=ZERO
        for xx,yy in zip(u,v):z=plus(z,times(xx,yy))
        return z
    def conv(u,v):
        z=[ZERO]*(len(u)+len(v)-1)
        for i,uu in enumerate(u):
            for j,vv in enumerate(v):z[i+j]=plus(z[i+j],times(uu,vv))
        return z
    d=[dot(lv,x[s:s+le]) for s,le,lv in zip(starts,lens,loc)]
    if fault=='compression':d[0]=plus(d[0],(F(1,8),F(0)))
    end=[ZERO]*b
    for j in range(b):end[(j+1)%b]=times(bc[j],d[j])
    if fault=='boundary':end=end[1:]+end[:1]
    if fault=='nodes':nodes=[(v[0],-v[1]) for v in nodes]
    q=[ONE]
    for lam in nodes:q=conv(q,[ONE,neg(lam)])
    if fault=='coefficients':q[1]=plus(q[1],(F(1,16),F(0)))
    inv=[ONE]
    for k in range(1,b):inv.append(neg(dot(q[1:k+1],inv[::-1])))
    if fault=='reciprocal' and b>1:inv[1]=plus(inv[1],(F(1,16),F(0)))
    channels=[]
    for weights in [d,end]:
        powers=[ONE]*b;seq=[]
        for k in range(b):
            seq.append(dot(weights,powers));powers=[times(v,w) for v,w in zip(powers,nodes)]
        while len(seq)<n:
            take=min(b,n-len(seq));past=conv(seq[-b:],q)
            rhs=[neg(v) for v in past[b:b+take]]
            seq+=conv(rhs,inv)[:take]
        channels.append(seq)
    if fault=='seed':channels[0]=[plus(v,(F(1,4),F(0))) for v in channels[0]]
    scale=down(invsqrt(n).midpoint(),p)
    if fault=='normalization':scale=F(1)
    raw=[sub(u,v) for u,v in zip(*channels)]
    f=[times(v,(scale,F(0))) for v in raw]
    if fault=='forcing':f[0]=plus(f[0],(F(1,4),F(0)))
    idx=[a*j%n for j in range(n)]
    terms=[quotient(f[k],gauge[j]) for j,k in enumerate(idx)]
    # Tree sum and prefix tree, explicitly different code from historical source.
    def tree(v):
        if len(v)==1:return v[0]
        m=len(v)//2;return plus(tree(v[:m]),tree(v[m:]))
    seed=times(tree(terms),(F(1,2),F(0)))
    if fault=='closure':seed=ZERO
    prefix=[ZERO]*n
    def scan(v,offset=ZERO,start=0):
        if len(v)==1:prefix[start]=offset;return
        m=len(v)//2;scan(v[:m],offset,start);scan(v[m:],plus(offset,tree(v[:m])),start+m)
    scan(terms)
    out=[ZERO]*n
    for j,k in enumerate(idx):out[k]=times(gauge[j],plus(seed,neg(prefix[j])))
    if fault=='mapping':out=out[1:]+out[:1]
    if fault=='output':out[-1]=plus(out[-1],(F(1,4),F(0)))
    return dict(n=n,b=b,a=a,beta=beta,x=x,d=d,D=channels[0],E=channels[1],f=f,Y=out,p=p,fault=fault)

def certificate(row,pcheck=100):
    """Sound certificate relative to the exact sampled row U_N P_(a,beta) x.

    Coefficient/seed/source checks are O(NB+B^2); only the final scan check is
    O(N). Uses the independently intended roots, not producer root assertions.
    """
    global P
    P=pcheck;n,b,a,beta=[row[t] for t in ['n','b','a','beta']]
    starts,lens,loc,bc,nodes,alpha,gauge=phases(n,b,a,beta,pcheck)
    x,d,D,E,f,Y=[row[t] for t in ['x','d','D','E','f','Y']]
    assert all(len(v)==n for v in [x,D,E,f,Y]) and len(d)==b
    true_d=[sum((v*C(xx) for v,xx in zip(lv,x[s:s+le])),C()) for s,le,lv in zip(starts,lens,loc)]
    ed=[(C(dd)-td).abs_upper() for dd,td in zip(d,true_d)]
    sig=invsqrt(n)
    comp_inf=up(sig.hi*sum(le*er for le,er in zip(lens,ed)))
    comp_2=sqrt_interval(sum(le*er*er for le,er in zip(lens,ed))).hi
    # Target source built from exported d with exact intended boundary phases.
    weights=[C(d[j])-bc[(j-1)%b]*C(d[(j-1)%b]) for j in range(b)]
    q=[C(1)]
    for lam in nodes:
        z=[C()]*(len(q)+1)
        for j,v in enumerate(q):z[j]=z[j]+v;z[j+1]=z[j+1]-lam*v
        q=z
    powers=[C(1)]*b;seederr=[]
    raw=[sub(u,v) for u,v in zip(D,E)]
    for k in range(b):
        val=sum((w*v for w,v in zip(weights,powers)),C())
        seederr.append((C(raw[k])-val).abs_upper())
        powers=[v*w for v,w in zip(powers,nodes)]
    # Initial convolution defects: sharpen using each individual seed radius.
    eta_seed=max((sum(q[j].abs_upper()*seederr[k-j] for j in range(k+1)) for k in range(b)),default=F(0))
    defects=[]
    for k in range(b,n):
        defects.append(sum((q[j]*C(raw[k-j]) for j in range(b+1)),C()).abs_upper())
    delta=max(defects,default=F(0));eta=max(eta_seed,delta)
    H=min(comb(n+b-1,b),1<<(n-b))
    source=up(H*eta*sig.hi)
    normerr=max((C(ff)-C(ss)*C(sig)).abs_upper() for ff,ss in zip(f,raw))
    residuals=[(C(Y[k])-alpha[k]*C(Y[(k+a)%n])-C(f[k])).abs_upper() for k in range(n)]
    rinf=max(residuals);r2=sqrt_interval(sum(v*v for v in residuals)).hi
    force=source+normerr
    eps_inf=up(comp_inf+F(n,2)*(rinf+force))
    sinlo=root_pi(1,2*n,pcheck).im.lo;assert sinlo>0
    k2=up(1/(2*sinlo))
    eps_2=up(comp_2+k2*(r2+sqrt_interval(n).hi*force))
    xn2=sum(xx[0]**2+xx[1]**2 for xx in x);xl=sqrt_interval(xn2).lo
    return dict(epsilon_inf=eps_inf,epsilon_2=eps_2,X_lower=xl,compression_inf=comp_inf,
        compression_2=comp_2,seed_error=max(seederr),seed_defect=eta_seed,
        recurrence_defect=delta,H=H,source_error=source,normalization_error=normerr,
        green_residual_inf=rinf,green_residual_2=r2,check_precision=pcheck)

def direct_error(row,pcheck=150):
    """Independent direct materialization and DFT interval oracle, O(N^2)."""
    global P
    P=pcheck;n,b,a,beta=[row[t] for t in ['n','b','a','beta']]
    starts,lens,loc,*_=phases(n,b,a,beta,pcheck)
    y=[]
    for s,le,lv in zip(starts,lens,loc):
        dd=sum((v*C(xx) for v,xx in zip(lv,row['x'][s:s+le])),C())
        y += [v.conj()*dd for v in lv]
    sc=C(invsqrt(n));errors=[]
    for k in range(n):
        val=sum((v*root_pi(-2*k*j,n,pcheck) for j,v in enumerate(y)),C())*sc
        err=C(row['Y'][k])-val
        errors.append(sqrt_interval(err.re.abs_upper()**2+err.im.abs_upper()**2).hi)
    return max(errors),sqrt_interval(sum(e*e for e in errors)).hi

def output_only_certificate(row,pcheck=100):
    """Check x and final Y alone, without trusting or needing producer states.

    V=(I-T)Y is enclosed, then V-F is certified through the normalized forcing
    recurrence. This remains O(NB+B^2), not an O(N) full checker.
    """
    global P
    P=pcheck;n,b,a,beta=[row[t] for t in ['n','b','a','beta']]
    starts,lens,loc,bc,nodes,alpha,gauge=phases(n,b,a,beta,pcheck)
    x,Y=row['x'],row['Y'];assert len(x)==n and len(Y)==n
    d=[sum((v*C(xx) for v,xx in zip(lv,x[s:s+le])),C()) for s,le,lv in zip(starts,lens,loc)]
    weights=[d[j]-bc[(j-1)%b]*d[(j-1)%b] for j in range(b)]
    V=[C(Y[k])-alpha[k]*C(Y[(k+a)%n]) for k in range(n)]
    q=[C(1)]
    for lam in nodes:
        z=[C()]*(len(q)+1)
        for j,v in enumerate(q):z[j]=z[j]+v;z[j+1]=z[j+1]-lam*v
        q=z
    powers=[C(1)]*b;err=[];sc=C(invsqrt(n))
    for k in range(b):
        seed=sum((w*v for w,v in zip(weights,powers)),C())*sc
        err.append((V[k]-seed).abs_upper())
        powers=[v*w for v,w in zip(powers,nodes)]
    eta0=max(sum(q[j].abs_upper()*err[k-j] for j in range(k+1)) for k in range(b))
    etar=max((sum((q[j]*V[k-j] for j in range(b+1)),C()).abs_upper() for k in range(b,n)),default=F(0))
    H=min(comb(n+b-1,b),1<<(n-b));force=H*max(eta0,etar)
    return {'epsilon_inf':F(n,2)*force,'forcing_error':force,'seed_defect':eta0,
        'recurrence_defect':etar,'H':H,'check_precision':pcheck}

def serial(v):
    if isinstance(v,F):return {'fraction':str(v),'approx':float(v)}
    if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [serial(x) for x in v]
    return v

def run():
    results=[];cases=0;entries=0
    for n in range(3,13):
        for b in sorted({3,(n+3)//2,n}):
            for a,beta in [(1,0),(n-1,n-1)]:
                inputs=[]
                inputs.append([ONE if j in [0,n-1] else ZERO for j in range(n)])
                inputs.append([(F((-1)**j,2**(j%4)),F((j%3)-1,8)) for j in range(n)])
                for x in inputs:
                    row=producer(x,n,b,a,beta,48);cert=certificate(row)
                    einf,e2=direct_error(row)
                    assert einf<=cert['epsilon_inf'],('inf',n,b,a,einf,cert)
                    assert e2<=cert['epsilon_2'],('l2',n,b,a,e2,cert)
                    assert cert['epsilon_inf']<=F(1,1024)*cert['X_lower']
                    cases+=1;entries+=n
    # Zero input: the exact arithmetic rows and certificates remain exactly zero.
    row=producer([ZERO]*7,7,3,2,4,32);c=certificate(row)
    assert c['epsilon_inf']==0 and c['epsilon_2']==0
    adversarial=[]
    x=[(F((-1)**j*(j+1),8),F((j%3)-1,4)) for j in range(9)]
    for fault in ['compression','boundary','nodes','coefficients','reciprocal','seed',
                  'normalization','forcing','closure','mapping','output']:
        row=producer(x,9,4,2,3,48,fault);c=certificate(row);actual,_=direct_error(row)
        assert actual<=c['epsilon_inf']
        assert c['epsilon_inf']>F(1,1024)*c['X_lower']
        adversarial.append({'fault':fault,'certificate':c,'direct_error_upper':actual})
    row=producer(x,9,4,2,3,48,'parity');c=certificate(row);actual,_=direct_error(row)
    assert actual<=c['epsilon_inf'] and c['epsilon_inf']>F(1,1024)*c['X_lower']
    adversarial.append({'fault':'parity','certificate':c,'direct_error_upper':actual})
    # Missing source validation trap: a wrong source followed by a correct scan.
    trap=adversarial[5]
    assert trap['certificate']['green_residual_inf']<F(1,1<<30)
    assert trap['certificate']['source_error']>F(1,10)
    precision=[]
    for p in [8,12,20,32,48]:
        row=producer(x,9,4,2,3,p);c=certificate(row)
        precision.append({'producer_fraction_bits':p,'pass_tau_2^-10':c['epsilon_inf']<=F(1,1024)*c['X_lower'],'certificate':c})
    assert not precision[0]['pass_tau_2^-10'] and precision[-1]['pass_tau_2^-10']
    # Very large and small exact input magnitudes have no hidden exponent cap.
    scaled=[]
    for power,prec in [(120,48),(-80,130)]:
        scale=F(2)**power;xx=[(v[0]*scale,v[1]*scale) for v in x]
        row=producer(xx,9,4,2,3,prec);c=certificate(row,180);actual,_=direct_error(row,220)
        assert actual<=c['epsilon_inf']
        assert c['epsilon_inf']<=F(1,1024)*c['X_lower']
        scaled.append({'input_power_of_two':power,'producer_fraction_bits':prec,'certificate':c})
    invalid=0
    for vals in [(8,3,2,0),(8,2,1,0),(8,9,1,0),(8,3,1,8),(8,3,0,0)]:
        try:validate(*vals)
        except ValueError:invalid+=1
        else:raise AssertionError(vals)
    # Exact complex-rational identity e = Q^{-1} eta on a 4th-root subset.
    exact_cases=0
    nodes=[ONE,(F(0),F(1)),(F(-1),F(0))];q=[ONE]
    for lam in nodes:
        z=[ZERO]*(len(q)+1)
        for j,v in enumerate(q):z[j]=add(z[j],v);z[j+1]=sub(z[j+1],mul(lam,v))
        q=z
    for size in range(4,31):
        h=[ONE]
        for k in range(1,size):
            t=ZERO
            for j in range(1,min(k,3)+1):t=add(t,mul(q[j],h[k-j]))
            h.append(neg(t))
        for pos in range(size):
            e=[ZERO]*size;e[pos]=(F(1,8),F(-1,16));eta=[]
            for k in range(size):
                t=ZERO
                for j in range(min(k,3)+1):t=add(t,mul(q[j],e[k-j]))
                eta.append(t)
            for k in range(size):
                t=ZERO
                for j in range(k+1):t=add(t,mul(h[j],eta[k-j]))
                assert t==e[k]
            exact_cases+=1
    output_only=[]
    for fault in [None,'seed','normalization','mapping','closure']:
        row=producer(x,9,4,2,3,48,fault);c=output_only_certificate(row);actual,_=direct_error(row)
        assert actual<=c['epsilon_inf']
        xn=sqrt_interval(sum(v[0]**2+v[1]**2 for v in x)).lo
        assert (c['epsilon_inf']<=F(1,1024)*xn)==(fault is None)
        output_only.append({'fault':fault,'certificate':c,'direct_error_upper':actual})
    result={'status':'PASS','historical_code_executed':False,'ordinary_rows':cases,
        'ordinary_output_entries':entries,'zero_rows':1,'invalid_states_rejected':invalid,
        'exact_rational_convolution_cases':exact_cases,'adversarial_cases':adversarial,
        'precision_sweep':precision,'scaled_cases':scaled,'output_only_cases':output_only,'interval_operation_counts':COUNTS,
        'certifier_cost':'O(NB+B^2) rational interval operations; direct oracle O(N^2)',
        'spectral_bound':'proved in report; ordinary rows also cross-checked against direct interval l2 error',
        'sampling_quality_improved':False}
    dest=Path(__file__).resolve().parent.parent/'CHECK_RESULTS.json'
    dest.write_text(json.dumps(serial(result),indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['adversarial_cases','precision_sweep','output_only_cases','scaled_cases']},indent=2))
    print('Precision passes:',[(s['producer_fraction_bits'],s['pass_tau_2^-10']) for s in precision])

if __name__=='__main__':run()
