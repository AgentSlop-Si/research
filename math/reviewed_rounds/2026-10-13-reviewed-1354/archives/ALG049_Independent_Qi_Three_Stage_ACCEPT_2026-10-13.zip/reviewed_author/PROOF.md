# ALG-049: bounded three-stage mixed-sign scalar-unitarity test

Date: 2026-10-13. Status: new candidate result pending independent review.
Parent obligation remains TO RESEARCH, priority 42. No Sheet or GitHub mutation.

## Result and exact boundary

No scalar-unitary word was found in the fully enumerated finite family: 5,928 words, 988 for each mixed sign pattern --+, -+-, -++, +--, +-+, ++-. Every word has three genuinely changing full 8-cycles: their undirected supports are pairwise distinct and their matrices are pairwise noncommuting.

A separate exact field argument excludes every legal three-stage mixed word whose effective factors have entries in Q(i), including but not limited to this finite fourth-root-of-unity sample. This is not a classification of arbitrary unit-modulus complex phases. It tests scalar unitarity only, not Fourier equality, speed, or novelty.

## 1. Source-pinned grammar

The pinned PROOF.md, Sections 1-3,8-9, defines a unit-modulus weighted full N-cycle M with total cycle weight -1 and

K(M) = (2I-M)(I-M)^(-1).

Full cycle means one directed cycle visiting all coordinates, with exactly one nonzero of modulus one in every row and column. Thus det(tI-M)=t^N+1, not merely M^N=-I. Inverses are legal: 1 and 2 are not eigenvalues. Both K and K^(-1) stages are allowed. The criterion here is A* A = c I with real c>0. The star is conjugate transpose. No claim of Fourier equality is tested or inferred.

A general word has the form

Q0 K(M1)^e1 Q1 K(M2)^e2 Q2 K(M3)^e3 Q3,

where each Qj is unitary monomial, ej is +1 or -1, and both signs occur. Nonzero global scalars may also be removed since they do not affect whether the word is scalar-unitary.

Endpoint Q0 and the final monomial do not affect scalar unitarity. Pushing the interior monomials right gives the effective cycles

C1=M1; C2=Q1 M2 Q1*; C3=(Q1 Q2) M3 (Q1 Q2)*,

and the effective word B=K(C1)^e1 K(C2)^e2 K(C3)^e3 followed by Q1 Q2 Q3. Conjugation preserves full cycles, unit-modulus weights and cycle product -1. The field theorem assumes the effective cycles Cj have entries in Q(i). A sufficient condition is that all raw cycles and interior separators have entries in Q(i). Arbitrary unitary monomial endpoints remain harmless. Arbitrary interior phases that take effective cycles outside Q(i) are not covered.

The finite sample uses identity separators in this effective grammar. This is a legal nonempty subclass, not an assertion that every arbitrary-phase word can be reduced into the finite sample. Every fourth-root-weight cycle may individually be conjugated to the canonical signed cycle by a fourth-root monomial. Thus simultaneously fixing the first such cycle to S is legitimate for a full fourth-root search, but our selection of the other two cycles is only a finite subset of that search.

## 2. Exact determinant obstruction for Q(i)

Theorem. At N=8, no product B of exactly three legal K or K^(-1) stages, with both signs present and effective cycles in Q(i), is scalar-unitary.

Proof. A full weighted cycle of product -1 has characteristic polynomial t^8+1. Therefore

det K(Cj) = det(2I-Cj)/det(I-Cj) = (2^8+1)/(1^8+1) = 257/2.

Let s=e1+e2+e3. The six mixed patterns have s=+1 or -1. Since rational matrix inversion preserves Q(i), B is a Q(i)-valued matrix. If B*B=cI, any diagonal entry is a sum of norms of Gaussian rationals, so c is a positive rational number.

Taking determinants gives c^8=|det B|^2=(257/2)^(2s). Taking the positive square root, justified by c>0 and 257/2>0, gives

c^4=(257/2)^s.

But the exponent of the prime 257 in the right side is s, which is +1 or -1. In a fourth power of a nonzero rational the exponent of every prime is divisible by four. Contradiction. QED.

The same contradiction holds without primality by using the 2-adic valuation, which is -s; the checker nevertheless verifies that 257 is prime. No irrational normalization was applied to the primitive. If a nonzero global scalar multiplies B, scalar unitarity of that scaled word is equivalent to scalar unitarity of B itself, so it does not evade this argument.

This field condition is substantive and nonempty. The explicit candidates below satisfy every primitive constraint. Q(i) also admits non-root-of-unity unit phases (a+ib)/(a-ib) for nonzero a-ib, with a,b rational. The theorem covers all such phases, arbitrary full-cycle orders, and admissible monomial separators preserving the effective field. It does not rely on changing cycles or on the absence of adjacent unitary pairs, so it also covers the broader Q(i) triple subclass. Three factors with a locally unitary opposite-sign pair still leave a single K-type stage; the theorem does not assume such a decomposition.

## 3. Deterministic finite sample

The coordinate convention is M e_order[j] = i^q[j] e_order[(j+1) mod 8]. Canonical S has order (0,1,2,3,4,5,6,7) and exponent vector (0,0,0,0,0,0,0,2), giving the wrap weight -1.

For k=1,...,32, lexicographically enumerate all 7! permutations of (1,...,7), zero-indexed. Choose rank floor(5040 k/33), prepend 0, and define q[j]=SHA256(UTF-8("ALG049-QI-v1|"+decimal(k)))[j] mod 4 for j=0,...,6. Set q[7]=(2-sum(q[0:7])) mod 4. Thus each complete weight product is i^2=-1 exactly.

Retain cycles whose undirected support differs from S and whose matrix does not commute with S. All 32 pass. Enumerate ordered pairs (a,b) from these cycles. Remove a=b (32 pairs) and equal undirected supports (4 additional pairs); require noncommutation of a and b. The remaining 988 pairs all pass noncommutation. Combine every ordered pair with all six explicitly enumerated mixed sign patterns. No sign-pattern symmetry is invoked. CANDIDATES.json contains every selected order and phase vector. EXACT_WORD_RESULTS.jsonl contains every tested case and an exact nonzero Gram off-diagonal or diagonal inequality.

Completeness: the direct run is exhaustive for these 988 ordered pairs times six sign patterns only. The field theorem excludes all Q(i)-valued effective triples, but neither the sample nor theorem excludes arbitrary complex unit phases. The whole fourth-root-cycle space is far larger: 7! times 4^7 = 82,575,360 cycles before fixing a canonical first factor. The finite count is not presented as enumeration of that entire space.

## 4. Fresh exact computation and legal inverses

For any sampled M with M^8=-I, use the exact Gaussian-integer numerators

K(M) = [3I + sum(j=1,...,7) M^j]/2,
K(M)^(-1) = [129I - sum(j=1,...,7) 2^(7-j) M^j]/257.

The checker verifies M^8=-I, both orders of K K^(-1)=I, and (I-M)K=2I-M for every prepared cycle. It then forms every three-stage numerator and its exact conjugate-transpose Gram matrix. Positive integer denominators are carried separately; all numerator arithmetic uses Python arbitrary-precision integers. There are no floats or tolerance decisions in any classification. Elapsed wall time is descriptive only.

All original pinned research sources are read as text and hashed. No historical program is imported, compiled or executed. check_alg049.py was authored for this run and uses only the Python standard library.

## 5. Countercontrols

The fresh checker verifies these exact positives:

- N=8 cancellation K(S) K(S)^(-1), Gram scalar 1.
- N=8 all-pass K(S) K(S*)^(-1), Gram scalar 1.
- Explicit unitary monomial separator Q with M2=Q* S Q, so K(S) Q K(M2)^(-1)=Q.
- N=8 four forward factors at phases 1,i,-1,-i. Their product is (17I+15S^4)/2 with Gram scalar 257/2. This is the sharp half-cycle length control, not a three-stage mixed candidate.
- N=2, all six three-stage mixed patterns, Gram scalar 5/2 for net +1 and 2/5 for net -1. This preserves the exceptional dimension.

One N=8 forward stage and two identical N=8 forward stages are exact negatives. Controls check that the Gram test can accept legal scalar-unitary words and does not conflate scalar unitarity with identity or Fourier equality.

## 6. Operation accounting

The dense direct search uses exactly three 8x8 Gaussian-integer matrix multiplications per word: two to form the word and one for its Gram. A dense multiplication uses 8^3=512 Gaussian multiplications and 8^2(8-1)=448 Gaussian additions. Across 5,928 words this is 17,784 matrix multiplications, 9,105,408 Gaussian multiplications, and 7,967,232 Gaussian additions. The largest numerator component in any search Gram uses 34 bits. JSON reporting, hashing, enumeration, denominator multiplication, comparisons, cycle preparation, storage, and controls are additional paid work, not hidden in the three-product count.

The complete original checker run, including preparation, commutators and controls, records 20,300 matrix multiplications, 10,382,008 Gaussian multiplications, and 9,084,188 Gaussian additions. These counters count the dense matrix kernels only; they are not a full machine-instruction or bit-complexity count. Each Gaussian multiplication in the implementation uses four ordinary integer multiplications and two additions/subtractions; each Gaussian addition uses two integer additions. Exact integer operation cost depends on bit length.

For the actual cycle primitive, a K or K^(-1) application can separately be done by a charged linear recurrence in O(N) scalar operations from supplied cycle weights. Three explicitly applied factors therefore cost O(N) scalar arithmetic with O(N) data movement/space at fixed stage count. This experiment gives neither a fused runtime improvement nor a general FFT lower bound. The dense verification cost is distinct from primitive application cost and from synthesis of arbitrary phases.

## 7. Review gate and unresolved algebraic problem

Before treating this as accepted evidence, an independent reviewer should check the source hashes and effective-cycle grammar, legality/nonemptiness of candidate construction, determinant sign and exponent, rational Gram diagonal argument, six-pattern counts, direct exact obstruction records, and positive countercontrols. A separately written determinant/Gram reconstruction of at least one triple across all six signs is recommended. A rerun of this checker corroborates reproducibility but is not independent derivation by itself.

The exact remaining target is an arbitrary-phase three-stage word with c=(257/2)^(1/4) for net +1 or its reciprocal for net -1. A witness must use phases whose generated conjugation-stable field permits that positive Gram scalar, and must still satisfy all full-cycle and unit-modulus constraints. A bounded radical-phase sample may be added as a separately scoped experiment; it cannot turn a finite negative into arbitrary-phase impossibility.

The parent remains TO RESEARCH with priority 42. The already accepted two-stage, fixed-operator, and phase-rotated short-word results are not reopened. Worldwide novelty, unrestricted execution, production speed, and Fourier realization remain unassessed.
