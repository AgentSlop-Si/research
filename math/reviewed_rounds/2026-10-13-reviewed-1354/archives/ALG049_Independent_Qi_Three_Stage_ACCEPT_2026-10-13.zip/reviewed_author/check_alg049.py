#!/usr/bin/env python3
"""Fresh, self-contained exact Gaussian-integer ALG-049 experiment.
No imports or execution of historical research programs. Python standard library only.
Matrices are Gaussian-integer numerators with separate positive integer denominator.
"""
import argparse, hashlib, itertools, json, math, pathlib, time
from collections import Counter
Z=(0,0); ONE=(1,0); PHASES=((1,0),(0,1),(-1,0),(0,-1))
OPS=Counter()
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def neg(a): return (-a[0],-a[1])
def mul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def conj(a): return (a[0],-a[1])
def eye(n): return [[ONE if i==j else Z for j in range(n)] for i in range(n)]
def smul(A,s): return [[(s*a,s*b) for a,b in row] for row in A]
def plus(A,B): return [[add(a,b) for a,b in zip(ar,br)] for ar,br in zip(A,B)]
def star(A): return [[conj(A[j][i]) for j in range(len(A))] for i in range(len(A))]
def mm(A,B):
 n=len(A); OPS['matrix_multiplications']+=1; OPS['gaussian_multiplications']+=n**3; OPS['gaussian_additions']+=n*n*(n-1)
 C=[]
 for i in range(n):
  row=[]
  for j in range(n):
   s=mul(A[i][0],B[0][j])
   for k in range(1,n): s=add(s,mul(A[i][k],B[k][j]))
   row.append(s)
  C.append(row)
 return C
def powers(M,n):
 out=[eye(n)]
 for _ in range(n): out.append(mm(out[-1],M))
 return out
def cycle(order,exponents):
 n=len(order); M=[[Z for _ in range(n)] for _ in range(n)]
 for j,v in enumerate(order): M[order[(j+1)%n]][v]=PHASES[exponents[j]%4]
 return M
def edges(order): return frozenset(frozenset((order[j],order[(j+1)%len(order)])) for j in range(len(order)))
def canonical(n): return cycle(list(range(n)),[0]*(n-1)+[2])
def factor(M):
 n=len(M); pp=powers(M,n)
 assert pp[n]==smul(eye(n),-1)
 F=smul(eye(n),3); H=smul(eye(n),2**(n-1)+1)
 for j in range(1,n):
  F=plus(F,pp[j]); H=plus(H,smul(pp[j],-2**(n-1-j)))
 # F/2=K; H/(2^n+1)=K^-1. Verify both multiplication orders.
 D=2**n+1
 assert mm(F,H)==smul(eye(n),2*D)
 assert mm(H,F)==smul(eye(n),2*D)
 # Exact rational equation defining K; therefore no numerical inversion.
 assert mm(plus(eye(n),smul(M,-1)),F)==smul(plus(smul(eye(n),2),smul(M,-1)),2)
 return {1:(F,2),-1:(H,D)}
def scalar_gram(B):
 G=mm(star(B),B); n=len(B)
 off=[(i,j,G[i][j]) for i in range(n) for j in range(n) if i!=j and G[i][j]!=Z]
 diag=[(i,G[i][i]) for i in range(1,n) if G[i][i]!=G[0][0]]
 ok=not off and not diag and G[0][0][1]==0 and G[0][0][0]>0
 first={'kind':'off_diagonal','row':off[0][0],'column':off[0][1],'value':off[0][2]} if off else ({'kind':'diagonal_mismatch','row':diag[0][0],'value':diag[0][1],'reference':G[0][0]} if diag else None)
 return ok,G,first,len(off),len(diag)
def scalar_word(factors):
 B,d=factors[0]
 for C,e in factors[1:]: B=mm(B,C); d*=e
 ok,G,first,no,nd=scalar_gram(B)
 return ok,G[0][0][0],d*d,first,no,nd,B,G

def main(outdir):
 t=time.perf_counter(); out=pathlib.Path(outdir); out.mkdir(parents=True,exist_ok=True)
 n=8; signs=list(itertools.product((-1,1),repeat=3)); signs=[s for s in signs if len(set(s))==2]
 perm=list(itertools.permutations(range(1,n)))
 candidates=[]
 for k in range(1,33):
  rank=k*math.factorial(7)//33; order=(0,)+perm[rank]
  digest=hashlib.sha256(('ALG049-QI-v1|'+str(k)).encode()).digest()
  exps=[digest[j]%4 for j in range(7)]; exps.append((2-sum(exps))%4)
  assert len(set(order))==n and sum(exps)%4==2
  candidates.append({'id':k,'permutation_rank':rank,'order':order,'edge_exponents_mod4':exps,'M':cycle(order,exps),'edges':edges(order)})
 S=canonical(n); eS=edges(tuple(range(n))); fs=factor(S)
 for a in candidates:
  a['factors']=factor(a['M'])
  a['eligible_with_S']=a['edges']!=eS and mm(S,a['M'])!=mm(a['M'],S)
 eligible=[a for a in candidates if a['eligible_with_S']]
 pairs=[]; skipped=Counter()
 for a in eligible:
  for b in eligible:
   if a['id']==b['id']: skipped['identical_candidate']+=1; continue
   if a['edges']==b['edges']: skipped['same_undirected_support']+=1; continue
   if mm(a['M'],b['M'])==mm(b['M'],a['M']): skipped['commuting_pair']+=1; continue
   pairs.append((a,b))
 before=OPS.copy(); rows=[]; bysign=Counter(); maxbits=0
 for a,b in pairs:
  for s in signs:
   ok,g,d2,first,no,nd,B,G=scalar_word([fs[s[0]],a['factors'][s[1]],b['factors'][s[2]]])
   assert not ok, 'Unexpected scalar-unitary candidate: save witness and investigate.'
   key=''.join('+' if v==1 else '-' for v in s); bysign[key]+=1
   maxbits=max(maxbits,max(abs(v).bit_length() for row in G for z in row for v in z))
   rows.append({'cycle_ids':[0,a['id'],b['id']],'signs':key,'scalar_unitary':ok,'gram_denominator':d2,'first_exact_obstruction':first,'nonzero_off_diagonals':no,'unequal_diagonals':nd})
 mainops=dict(OPS-before)
 # Positive controls: cancellation, all-pass, and dressed cancellation.
 controls=[]
 fstar=factor(star(S))
 for label,ff in [('cancellation',[fs[1],fs[-1]]),('all_pass',[fs[1],fstar[-1]])]:
  ok,g,d2,*_=scalar_word(ff); assert ok and g==d2
  controls.append({'name':label,'passed':True,'gram_scalar':'1'})
 # Legal monomial Q is a transposition. M2=Q* S Q, with explicit separator Q.
 p=list(range(n)); p[0],p[3]=p[3],p[0]; Q=[[ONE if i==p[j] else Z for j in range(n)] for i in range(n)]
 M2=mm(mm(star(Q),S),Q); f2=factor(M2)
 ok,g,d2,*_=scalar_word([fs[1],(Q,1),f2[-1]])
 assert ok and g==d2
 controls.append({'name':'monomial_separator_cancellation','passed':True,'gram_scalar':'1'})
 # Strict short-word boundary: four forward factors at phases 1,i,-1,-i.
 phasef=[factor([[mul(PHASES[r],z) for z in row] for row in S]) for r in range(4)]
 ok,g,d2,first,no,nd,B,G=scalar_word([f[1] for f in phasef]); assert ok and 2*g==257*d2
 S4=powers(S,n)[4]; expected=plus(smul(eye(n),17),smul(S4,15))
 assert B==smul(expected,8) # denominator 16 versus formula denominator 2.
 controls.append({'name':'N8_four_forward_halfcycle_boundary','passed':True,'gram_scalar':'257/2','formula':'(17 I + 15 S^4)/2'})
 # N=2 spectral degeneracy: all six mixed patterns are positive.
 fsmall=factor(canonical(2))
 for s in signs:
  ok,g,d2,*_=scalar_word([fsmall[v] for v in s]); assert ok
  if sum(s)==1: assert 2*g==5*d2
  else: assert 5*g==2*d2
 controls.append({'name':'N2_all_six_three_stage_mixed_patterns','passed':True,'gram_scalars':['5/2','2/5']})
 # Negative controls: one N8 stage and two N8 forward stages are not scalar-unitary.
 for label,ff in [('one_N8_forward',[fs[1]]),('two_N8_forward',[fs[1],fs[1]])]:
  ok,*_=scalar_word(ff); assert not ok
  controls.append({'name':label,'passed':True,'scalar_unitary':False})
 # Full-cycle guard: M^8=-I alone is insufficient; this 8x8 repeated 2-cycle has M^8=I,
 # so use an independently symbolic diagonal exp(i*pi/8) I in proof, not this candidate set.
 # Determinant arithmetic for a fully instantiated source-cycle factor (Bareiss over Q(i)
 # not needed): det(t I-M)=t^8+1 follows from single-cycle support; evaluate at t=1,2.
 assert 2**8+1==257 and 1**8+1==2
 # 257 is prime, and its valuation in 257/2 and 2/257 is +/-1, not a multiple of four.
 assert all(257%p for p in range(2,math.isqrt(257)+1))
 summary={'task':'ALG-049','N':8,'stage_count':3,'field':'Q(i); direct finite set uses fourth roots of unity',
 'candidate_construction':'ALG049-QI-v1','generated_cycles':32,'eligible_cycles_with_canonical_S':len(eligible),
 'ordered_pairs':len(pairs),'skipped_pairs':dict(skipped),'sign_patterns':bysign,'exact_words_checked':len(rows),'scalar_unitary_witnesses':0,
 'all_three_underlying_undirected_supports_distinct':True,'all_cycle_pairs_noncommuting':True,
 'exact_obstruction':'If A*A=cI, c is rational and c^4 is 257/2 or 2/257, impossible by the 257-adic valuation.',
 'main_search_operations':mainops,'all_checker_matrix_operations':dict(OPS),'max_gram_numerator_component_bits':maxbits,
 'countercontrols':controls,'elapsed_seconds':time.perf_counter()-t,
 'independent_review_status':'pending','historical_code_executed':False,'Fourier_equality_tested':False,
 'parent_status_unchanged':'TO RESEARCH','parent_priority_unchanged':42,
 'completeness_boundary':'Exact exhaustive direct check only of the generated family. The rational-Gram proof additionally excludes all Q(i)-valued legal words of this three-stage grammar. Arbitrary unit-modulus phases and unrestricted changing-cycle words remain unresolved.'}
 (out/'RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
 with (out/'EXACT_WORD_RESULTS.jsonl').open('w') as f:
  for r in rows: f.write(json.dumps(r,separators=(',',':'))+'\n')
 serial=[{k:v for k,v in a.items() if k not in ('M','edges','factors')} for a in candidates]
 (out/'CANDIDATES.json').write_text(json.dumps({'canonical_cycle':{'id':0,'order':list(range(n)),'edge_exponents_mod4':[0]*7+[2]},'candidates':serial},indent=2)+'\n')
 print(json.dumps(summary,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); args=ap.parse_args(); main(args.out)
