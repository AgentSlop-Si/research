"""New independent ALG049 audit; never imports or executes the author checker."""
from fractions import Fraction as F
from itertools import permutations,product
from collections import Counter
from pathlib import Path
import hashlib,json
Z=(0,0); O=(1,0)
def za(a,b):return (a[0]+b[0],a[1]+b[1])
def zm(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def zc(a):return(a[0],-a[1])
def zs(a,b):return(a[0]-b[0],a[1]-b[1])
def zd(a,b):
 t=b[0]*b[0]+b[1]*b[1]; c=zm(a,zc(b));return(F(c[0],t),F(c[1],t))
def ident(n):return [[O if r==c else Z for c in range(n)] for r in range(n)]
def scale(A,z):return [[zm(x,z) for x in row] for row in A]
def add(A,B):return [[za(x,y) for x,y in zip(a,b)] for a,b in zip(A,B)]
def trans(A):return [[zc(A[c][r]) for c in range(len(A))] for r in range(len(A))]
def mm(A,B):
 Bt=list(zip(*B))
 return [[(sum(a[0]*b[0]-a[1]*b[1] for a,b in zip(row,col)),sum(a[0]*b[1]+a[1]*b[0] for a,b in zip(row,col))) for col in Bt] for row in A]
def invdet(A):
 n=len(A); T=[list(row)+list(idrow) for row,idrow in zip(A,ident(n))]; d=O
 for j in range(n):
  pivot=next(r for r in range(j,n) if T[r][j]!=Z)
  if pivot!=j:T[j],T[pivot]=T[pivot],T[j];d=zm(d,(-1,0))
  p=T[j][j];d=zm(d,p);T[j]=[zd(z,p) for z in T[j]]
  for r in range(n):
   if r!=j:
    p=T[r][j];T[r]=[zs(z,zm(p,t)) for z,t in zip(T[r],T[j])]
 return [row[n:] for row in T],d
phases=(O,(0,1),(-1,0),(0,-1))
def cycle(order,weights):
 M=[[Z for _ in order] for _ in order]
 for j,v in enumerate(order):M[order[(j+1)%len(order)]][v]=weights[j]
 return M
def support(order):return frozenset(tuple(sorted([a,b])) for a,b in zip(order,order[1:]+order[:1]))
def prepare(M):
 n=len(M); P=ident(n); forward=scale(P,(3,0));back=scale(P,(2**(n-1)+1,0))
 for j in range(1,n):
  P=mm(P,M);forward=add(forward,P);back=add(back,scale(P,(-2**(n-1-j),0)))
 assert mm(P,M)==scale(ident(n),(-1,0))
 assert mm(forward,back)==scale(ident(n),(2*(2**n+1),0))
 assert mm(back,forward)==scale(ident(n),(2*(2**n+1),0))
 return {'+':(forward,2),'-':(back,2**n+1)}
def gram(A):return mm(trans(A),A)
def scalar(G):
 n=len(G);return G[0][0][0]>0 and G==scale(ident(n),G[0][0]) and G[0][0][1]==0
def word(factors):
 A,d=factors[0]
 for B,e in factors[1:]:A=mm(A,B);d*=e
 return A,d
src=Path(__file__).with_name('reviewed_author')
if not src.is_dir(): src=Path(__file__).resolve().parents[1]/'alg049_run'
data=json.loads((src/'CANDIDATES.json').read_text());orders=list(permutations(range(1,8)))
S=cycle(list(range(8)),[O]*7+[(-1,0)]); mats={0:S}; specs={0:list(range(8))}; factors={0:prepare(S)}
for c in data['candidates']:
 k=c['id']; r=5040*k//33;order=[0]+list(orders[r]); h=hashlib.sha256(('ALG049-QI-v1|'+str(k)).encode()).digest(); q=[h[j]%4 for j in range(7)];q.append((2-sum(q))%4)
 assert order==c['order'] and q==c['edge_exponents_mod4'] and r==c['permutation_rank']
 M=cycle(order,[phases[v] for v in q]);assert support(order)!=support(specs[0]) and mm(M,S)!=mm(S,M)
 mats[k]=M;specs[k]=order;factors[k]=prepare(M)
# Direct Gauss-Jordan inversion and elimination determinants independently check
# the rational-function definition rather than relying solely on the geometric series.
direct_determinants=[]
for k in (0,1,2):
 M=mats[k];n=len(M); Im=add(ident(n),scale(M,(-1,0)));two=add(scale(ident(n),(2,0)),scale(M,(-1,0)))
 ii,di=invdet(Im);_,dt=invdet(two);K=mm(two,ii);ki,dk=invdet(K)
 assert di==(F(2),0) and dt==(F(257),0) and dk==(F(257,2),0)
 assert K==scale(factors[k]['+'][0],(F(1,2),0)) and ki==scale(factors[k]['-'][0],(F(1,257),0))
 direct_determinants.append({'id':k,'det(I-M)':'2','det(2I-M)':'257','det(K)':'257/2'})
# Explicit legal Q(i) cycle containing a non-root-of-unity phase, beyond finite sample.
z=(F(3,5),F(4,5));weights=[z]+[O]*6+[(-z[0],z[1])];R=cycle(list(range(8)),weights)
assert zm(z,zc(z))==O
_,dR=invdet(add(ident(8),scale(R,(-1,0))));assert dR==(F(2),0)
fR=prepare(R);KR=scale(fR['+'][0],(F(1,2),0));_,dKR=invdet(KR);assert dKR==(F(257,2),0)
pairs=[];skips=Counter()
for a,b in product(range(1,33),repeat=2):
 if a==b:skips['same_id']+=1;continue
 if support(specs[a])==support(specs[b]):skips['same_support']+=1;continue
 if mm(mats[a],mats[b])==mm(mats[b],mats[a]):skips['commuting']+=1;continue
 pairs.append((a,b))
assert len(pairs)==988 and skips=={'same_id':32,'same_support':4}
patterns=['--+','-+-','-++','+--','+-+','++-']
records=[json.loads(l) for l in (src/'EXACT_WORD_RESULTS.jsonl').read_text().splitlines()];assert len(records)==5928
seen=set();counts=Counter();maxbits=0;first_triple=[]
for rec in records:
 _,a,b=rec['cycle_ids'];s=rec['signs'];key=(a,b,s)
 assert (a,b) in pairs and s in patterns and key not in seen;seen.add(key);counts[s]+=1
 B,d=word([factors[0][s[0]],factors[a][s[1]],factors[b][s[2]]]);G=gram(B)
 assert not scalar(G) and rec['scalar_unitary'] is False and d*d==rec['gram_denominator']
 off=[(r,c,G[r][c]) for r in range(8) for c in range(8) if r!=c and G[r][c]!=Z]
 mismatch=sum(G[r][r]!=G[0][0] for r in range(1,8));assert len(off)==rec['nonzero_off_diagonals'] and mismatch==rec['unequal_diagonals']
 if off:
  r,c,v=off[0];expected={'kind':'off_diagonal','row':r,'column':c,'value':list(v)}
 else:
  r=next(r for r in range(1,8) if G[r][r]!=G[0][0]);expected={'kind':'diagonal_mismatch','row':r,'value':list(G[r][r]),'reference':list(G[0][0])}
 assert expected==rec['first_exact_obstruction']
 maxbits=max(maxbits,max(abs(v).bit_length() for row in G for z in row for v in z))
 if (a,b)==(1,2):first_triple.append({'signs':s,'gram_0_1_numerator':list(G[0][1]),'gram_denominator':d*d})
assert counts=={s:988 for s in patterns} and maxbits==34
# Positive countercontrols reconstructed independently.
positive=[]
for label,ff in [('cancellation',[factors[0]['+'],factors[0]['-']]),('all_pass',[factors[0]['+'],prepare(trans(S))['-']])]:
 B,d=word(ff);G=gram(B);assert G==scale(ident(8),(d*d,0));positive.append(label)
Q=ident(8);Q[0],Q[3]=Q[3],Q[0];M2=mm(mm(trans(Q),S),Q);B,d=word([factors[0]['+'],(Q,1),prepare(M2)['-']]);assert B==scale(Q,(d,0));positive.append('separator_cancellation')
B,d=word([prepare(scale(S,z))['+'] for z in phases]);G=gram(B);assert scalar(G) and 2*G[0][0][0]==257*d*d
S4=mm(mm(S,S),mm(S,S));expected=add(scale(ident(8),(17,0)),scale(S4,(15,0)));assert scale(B,(2,0))==scale(expected,(d,0));positive.append('four_forward_halfcycle')
S2=cycle([0,1],[O,(-1,0)]);ff=prepare(S2)
for s in patterns:
 B,d=word([ff[z] for z in s]);G=gram(B);assert scalar(G)
 if s.count('+')==2:assert 2*G[0][0][0]==5*d*d
 else:assert 5*G[0][0][0]==2*d*d
positive.append('N2_all_six_patterns')
for ff in ([factors[0]['+']],[factors[0]['+'],factors[0]['+']]):
 B,d=word(ff);assert not scalar(gram(B))
result={'verdict':'PASS','executed':'This reviewer-authored script only','source_checker_executed':False,'reconstructed_candidates':32,'legal_pairs':len(pairs),'skips':dict(skips),'recorded_words_fully_reconstructed':len(seen),'sign_pattern_counts':dict(counts),'every_obstruction_value_and_count_matched':True,'maximum_Gram_component_bits':maxbits,'direct_elimination_determinants':direct_determinants,'nonroot_Qi_phase_control':'(3+4i)/5 with compensating wrap phase; det K=257/2','all_six_signs_first_triple':first_triple,'positive_controls':positive,'negative_controls':2,'main_kernel_counts_arithmetically_verified':{'matrix_products':5928*3,'Gaussian_multiplications':5928*3*8**3,'Gaussian_additions':5928*3*8**2*7}}
Path(__file__).with_name('INDEPENDENT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
