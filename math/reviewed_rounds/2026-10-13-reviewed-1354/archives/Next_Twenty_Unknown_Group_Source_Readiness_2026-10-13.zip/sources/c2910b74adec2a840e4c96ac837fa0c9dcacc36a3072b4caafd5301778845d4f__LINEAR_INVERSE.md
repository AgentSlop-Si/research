# Exact O(N) inverse of the parity-mixed Green stage

**Scope:** Exact field arithmetic for even N, assuming division by the nonzero pivots of the stated SPD matrices. For complex/rational arithmetic, real SPD guarantees the pivots are nonzero. A modular field may occasionally make a pivot zero; the supplied F_998244353 sample sizes pass.

## Identity

Let `A=P T P^T`, `B=T`, and `M=A^-1 + epsilon B^-1`. Then

```
A^-1 (B+epsilon A) B^-1 = A^-1 + epsilon B^-1 = M.
```

Therefore

```
M^-1 = B (B+epsilon A)^-1 A.
```

This is a matrix identity, not a guessed inverse.

## Hidden banded system

Let `Q=P^T` be the tau interleaving permutation from `HIDDEN_ORDER_THEOREM.md`. Then `Q A Q^T = T`, while `B'=Q B Q^T` has offdiagonal entries `-1` at `(i,i+2)` and `(i+2,i)` for all `0<=i<=N-3`, plus ONE extra `-1` at `(1,N-2)` and `(N-2,1)`.

Thus

```
K' = Q(B+epsilon A)Q^T
   = K0 - e_1 e_{N-2}^T - e_{N-2} e_1^T,
```

where K0 is a symmetric pentadiagonal matrix with

- main diagonal `3(1+epsilon)`;
- first offdiagonals `-epsilon`;
- second offdiagonals `-1`.

For `epsilon=1/20`, K0 is strictly diagonally dominant with positive diagonal, hence SPD. A band-2 LDL^T factorization of K0 costs O(N) field operations with O(N) coefficients and solves each RHS in O(N).

Let `U=[e_1,e_{N-2}]`, `C=[[0,-1],[-1,0]]`, so `K'=K0+U C U^T`. The rank-two Woodbury identity gives

```
K'^-1 b = z - W (C^-1 + U^T W)^-1 U^T z,
z=K0^-1 b, W=K0^-1 U, C^-1=C.
```

The two columns of W and 2x2 correction matrix can be precomputed in O(N). Each application of K'^-1 then requires a banded solve plus two vector updates, O(N).

Finally, to compute `M^-1 x`:

```
1. v=Qx                          # interleave, O(N)
2. b=T v                         # tridiagonal multiply, O(N)
3. z=K'^-1 b                     # banded + rank-2 correction, O(N)
4. w=Q^T z                       # undo interleave, O(N)
5. output=T w                    # tridiagonal multiply, O(N)
```

This is an **exact O(N)-work inverse and setup** in the field-operation model. It makes the previous stage less compelling as a candidate for inherently difficult global transforms: a dense matrix and dense inverse can both be cheap.

## Audits

`linear_inverse.py` implements modular LDL^T plus Woodbury (no dense inverse materialized). `exact_audit.py` compares M^-1 M and M M^-1 against independently coded tridiagonal Green solves, 6 fresh full-length inputs for each direction and each N=4,8,16,32,64,128,256. All passed. The setup builds O(N) scalars; the audit's dense matrices, when used, are outside the executor.
