# Phase 12: an exactly unitary, O(N)-work, order-robust, high-1-norm global mixer

**Date:** 2026-10-09. **Status:** A mathematically proved *linear-time transform primitive*, NOT an exact DFT factorization, NOT an `o(N log N)` Fourier algorithm, and NOT a claim of priority over published work.

This continues the user's global-Green/graph-computation path. Unlike the previous SPD Green sum, this stage simultaneously (a) has a linear-time exact inverse, (b) is spectrally unitary, (c) has **Omega(N) uniformly non-negligible balanced off-cut singular values in every coordinate order**, and (d) has **growing induced 1-norm and 1-condition**. All four statements concern the stage, not the Fourier transform. The construction combines standard Cayley and involution identities with the earlier random two-path expansion argument.

## 1. Notation and fully charged executor

Let `N` be even. All matrices have dimension `N`, except `B` below, dimension `m=N/2`. Complex arithmetic is exact in the stated arithmetic model; all scalar constants are independent of N.

Let `A1` and `A2` be adjacency matrices of two Hamilton paths: the first in natural coordinate order; the second independently uniformly random. Set `a=1/32`. For any real symmetric adjacency A write

```
C_a(A) = (I + i a A) (I - i a A)^(-1)
       = 2 (I - i a A)^(-1) - I.
```

Set `U = C_a(A1) C_a(A2)`. Each Cayley is **exactly unitary**; application or inversion requires ONE tridiagonal solve, optionally after permuting coordinates. Its inverse is `2 (I + i a A)^(-1) - I`.

On `m` coordinates, choose a complete binary tree with `2^(L+1)-1 <= m` vertices of maximal depth L, plus isolated vertices to fill the remainder. Let `A_T` be its adjacency and set `B=C_2(A_T)` (the same Cayley identity with coefficient `a=2`, not 1/32). `B` is symmetric, exactly unitary. Forest equations for `(I ± 2 i A_T)` are solved by leaf-to-root elimination followed by root-to-leaf substitution in O(m) scalar operations. All elimination pivots are positive real, so no singular pivot occurs over C.

Build the **Hermitian involution**

```
R = [ 0   B  ]    R*=R,   R^2=I.
    [ B*  0  ]
```

Set `e=1/512` and define

```
V = (I + i e R) / sqrt(1+e^2),
S = V U.
```

`V` and `S` are **exactly unitary**, and their inverses have the same O(N) work. The operator `R` is applied with **two** tree Cayley operations of size m, and all other scalar/vector operations cost O(N). The path permutations and elimination pivots are built in O(N) operations. There are no precomputed input-output answers or dense N-by-N matrices in the executor.

### Finite-field validation note

The code also supports exact arithmetic modulo 998244353, which has a specified square root of -1. Its finite-field `V` is deliberately *unnormalized* `Q=I+i e R`; `Q^-1=(I-i e R)/(1+e^2)` avoids requiring the square root of `1+e^2` in the field. The complex numerical implementation uses the normalized, exactly unitary definition above. Finite-field forward/inverse identities are valid algebraic audits, **not** a numerical unitary test.

## 2. Lemma: robust cross-cut singular values for the two Cayley paths

For any balanced cut `(I,J)` with `|I|=|J|=N/2`, let `E` be the total count of edges of the two paths crossing it (counting multiplicity), and let `H=A1+A2`. Maximum multigraph degree is <=4.

Greedy induced-edge selection: choose a crossing edge `(u,v)` and delete all crossing edges incident to any neighbor of `u` or any neighbor of `v`. At most `2*4^2=32` edge occurrences are deleted each time. Thus at least `ceil(E/32)` crossing edges survive as a mutually induced matching. The corresponding `k x k` submatrix of `H[I,J]` is diagonal with integer diagonal values >=1, where `k>=ceil(E/32)`. Since restriction to rows/columns cannot enlarge singular values,

```
sigma_k( H[I,J] ) >= 1,    k=ceil(E/32).
```

For each path adjacency A with `||A||2<=2`, let `C=C_a(A)`. The spectrum of A is real, so `||(I-i a A)^(-1)||2 <=1` and

```
||C-I||2 <= 4a,
||C-I-2 i a A||2 <= 8a^2.
```

Expanding `U=C_a(A1)C_a(A2)` gives

```
|| U - (I + 2 i a (A1+A2)) ||2 <= 32 a^2.
```

The off-cut block of I vanishes, so the singular-value perturbation inequality shows

```
sigma_k( U[I,J] ) >= 2a - 32a^2 = 1/32.
```

The earlier phase-11 random-Hamilton-path union-bound proof (reproduced in the following paragraph) shows, for `N` divisible by 16 and >=32, that with probability at least

```
1 - 4(N+1) 2^[-c N],
c = 1 - 2 H_2(1/16) > 0.3254,
```

**every balanced cut** has `E>N/16`. Proof: for a fixed balanced vertex set, the set's random path-membership bit string is a uniform balanced binary word. Strings with <=N/16 changes number at most `2 sum_{j<=N/16} binom(N-1,j)`. Square the bound for two independent random paths, union-bound over all balanced sets, use `sum binom <=2^[N H_2(1/16)]` and `binom(N,N/2)>=2^N/(N+1)`. Simultaneously relabeling vertices fixes the first path without altering distribution.

Therefore with that probability every balanced cut has at least `ceil(E/32)>N/512` significant singular values, each >=1/32. This includes the middle cut in **every simultaneous coordinate ordering**.

## 3. Lemma: the tree Cayley has polynomial induced 1-norm

Consider the complete binary tree depth L. Let `x=(I-2 i A_T)^(-1) e_root` and define integers

```
D_0=D_1=1,
D_{j+2}=D_{j+1}+8 D_j.
```

Schur-eliminating its subtrees from leaves upward, the effective diagonal for a subtree of height h is `d_0=1` and `d_h=1+8/d_(h-1)`. The telescoping identity `d_h=D_(h+1)/D_h` shows every leaf, at depth L, receives

```
|x_leaf| = 2^L / D_(L+1).
```

Since `B=2(I-2 i A_T)^(-1)-I`, leaf coordinates of `B e_root` have magnitude `2^(L+1)/D_(L+1)` and there are `2^L` leaves. Thus

```
||B||1 >= ||B e_root||1 >= 2 * 4^L / D_(L+1).
```

Let `lambda=(1+sqrt(33))/2`. It satisfies `lambda^2=lambda+8`, and elementary induction yields `D_j<=lambda^j`. Hence

```
||B||1 >= (2/lambda) * (4/lambda)^L.
```

As `lambda<4`, this grows exponentially in the tree depth. For the largest full binary subtree occupying `m' = 2^(L+1)-1<=m=N/2` coordinates, maximality gives `2^L>(m+1)/4`; consequently

```
||B||1 = Omega( N^theta ),
theta=log_2(4/lambda) >0   (approximately 0.246).
```

The leftover isolated vertices do not affect this lower bound. The same bound applies to `||B*||1` and `||B||infinity`, because B is symmetric and unitary.

**This is not an artificial rank-one or gigantic precomputed table:** the binary tree has O(N) edges, its Cayley has an O(N) executor and inverse, and the construction uses many nontrivial coordinates. The growth originates from the number of tree leaves overcoming pointwise resolvent decay.

## 4. Theorem: unite all four stage properties

Because R is a Hermitian involution, V is exactly unitary and

```
||V-I||2 <= e + e^2/2 < 1/64.
```

Therefore the off-cut block of `S=VU` differs from that of U by spectral norm <1/64. Weyl's singular-value inequality and Lemma 2 imply, simultaneously across **every balanced cut** with high probability,

```
#{ singular values of S[I,J] >= 1/64 } >= ceil(E/32) > N/512.
```

At the same time, `||S||2=||S^-1||2=1`, so `kappa_2(S)=1` *exactly*.

The norm budget really grows. The two path Cayleys satisfy

```
||C_a(Aj)||1 <= (1+2a)/(1-2a) = 17/15,
||U||1, ||U^-1||1, ||U||infinity, ||U^-1||infinity <= (17/15)^2.
```

A coordinate vector in the first half of V is sent to **disjoint** first- and second-half supports:

```
||V e_root||1 = (1+e ||B* e_root||1)/sqrt(1+e^2).
```

Thus `||V||1=Omega(N^theta)` and similarly `||V^-1||1=Omega(N^theta)`. Since `V=S U^-1` and `V^-1=U S^-1`,

```
||S||1 >= ||V||1/||U^-1||1 = Omega(N^theta),
||S^-1||1 >= ||V^-1||1/||U||1 = Omega(N^theta),
kappa_1(S)=Omega(N^(2theta)).
```

**Summary:** For powers of two `N>=32`, a sampled fixed pair of Hamilton paths with the above high-probability guarantee yields a uniform, input-independent, exactly unitary transform S, with O(N) preparation and work, O(N) inverse work, robust Omega(N) singular values at every balanced cross cut in every coordinate order, and polynomially growing induced-1-condition. The exact algebra is for every N; the probabilistic expansion event is for N divisible by 16. Four prior spectral witnesses yield deterministic *finite-N* certificates, not a deterministic all-N expander family.

## 5. Precisely what this DOES NOT prove

- This **does not** compute `F_N` or give an exact factorization of `F_N`.
- It **does not** beat `O(N log N)` FFT complexity; a structural property is not a Fourier identity.
- Growing `||S||1` only removes the previous **constant induced-condition obstruction**. It does not establish any sufficiency theorem.
- The operator is built from classical Cayley and tree-resolvent identities. **No claim of mathematical priority or novelty over the literature** is made.
- It does not claim good finite-precision error bounds: in-depth analysis of the tree solve, constant precision requirements, and huge-N scaling would be necessary for a numerical FFT application.
- Nor does it imply faster *bit-complexity* integer multiplication. Exact field arithmetic operations and random access are charged in their own model.

## 6. Reproduction

- `unitary_mixer.py`: standalone O(N) forward/inverse executor, both complex and exact finite-field arithmetic.
- `audit.py`, `audit_results.json`: inverse and involution checks N=16..256, approximate numerical unitarity and sampled cut singular values N=32,64,128; complete binary tree leaf formula depths 2..8.
- `tests/test_phase12.py`: independent dense-modular controls and theorem-inequality checks.
- `RUN.md`: commands and dependency details.
- `../fft_green_phase11_graph_separator/spectral_certificate.py`: source of prior fully integer N32,64,128,256 gap certificates. Copied corresponding witness recipes into this package for provenance.
