#!/usr/bin/env python3
"""New edition QA checks. Reads evidence only; executes no archived program."""
from pathlib import Path
from fractions import Fraction
import hashlib, io, json, re, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE_NAME = 'Q16_Reviewed_All_Length_Theorem_Exact_Text_Recovery_2026-10-13.zip'
EXPECTED_ARCHIVE = 'abc583f6731cf252e7a3223493e1b4df452c0868463a6afac2cf5472311a788b'
THEOREM_PIN = '0a7733e2ac1d1c32cf70609ba0db151a13a73765107907aec44045daaf0a58f5'
PDF_PIN = '9fdbe5c17519706befe964f9fedec3d77e07e13b26f4aca3ec1db342df677a7a'
ORIGINALS = {
 'THEOREM_AND_PROOF_V1.md': '4bc3e876a680cfb031d4e7d2363f81dfc713c45ef680b3a34eedb167a536d408',
 'INDEPENDENT_REVIEW_REPORT.md': 'e68a8910ada71f03018a9d5c994a597550d8b0ca2f21b438c96e6f261eb60928',
 'INDEPENDENT_VERDICT.json': 'a07c0d728a707b582e2dfad6fd28ef4d344b98f7e84facfd95fbc6af6ae7bb78',
 'INDEPENDENT_RESULTS.json': 'd3d746db827868918c5d2172742c9fe78dae8f0ecbfea3fd765d1b8e49bae40a',
 'E_BETA_PROOF_V1.md': '0bc9c71af3f084f465aeadd3a4c53122abb6b11673d25f5d5d87c43ca57a675b',
 'E_BETA_ALGORITHM_V1.txt': '17240b411c59c51f579d5675f6ac80975ca86553714ad5d8296594bc71dc6cc1',
 'P05_ACCEPTED.md': '02ec40df49f0585c57f98d3af7cbb9867216773f98a2998db9d51237fd69b787',
 'UNIFORM_TRANSFER_LEMMA.md': 'fed947dce547463d3829aadfe9f6e23410fb70a0b139a3b8da64d399a4cc8a9d',
 'TRANSFER_AUTHOR_CONTROLS.json': 'c68f473fb670bb05475978081a95a59866521413acd42e85efc45db6d74d0fe6',
 'TRANSFER_INDEPENDENT_CONTROLS.json': '07026e92329f342860111906b5110f39b7ec0a0850d151c2b239ff1810b618d3',
 'ORIGINAL_ROWS.json': 'b316d4e57e857531ae250087edffe434c07d46d3cac31e68efe756f320ca8641',
 'PRIOR_COMPARISON_REPORT.md': 'd2b6b8f1a0ad74626f3d10f00bf1ebf7fe9bd25e23448f2c2a710aae2c88d0ef',
}
def sha(b): return hashlib.sha256(b).hexdigest()
def open_archive(b):
 z = zipfile.ZipFile(io.BytesIO(b))
 assert z.testzip() is None
 prefixes = {n.rsplit('/',1)[0]+'/' for n in z.namelist() if n.endswith('/MANIFEST.json') and n.count('/') == 1}
 assert len(prefixes) == 1
 prefix = next(iter(prefixes))
 return z, prefix
def inventory(z, prefix):
 manifest_bytes = z.read(prefix+'MANIFEST.json')
 manifest = json.loads(manifest_bytes)
 rows = manifest if isinstance(manifest,list) else manifest['files']
 seal = json.loads(z.read(prefix+'SEAL.json'))
 assert sha(manifest_bytes) == seal['manifest_sha256']
 for row in rows:
  b = z.read(prefix+row['path'])
  assert len(b) == row['bytes'] and sha(b) == row['sha256'], row['path']
 assert len(rows) == seal['payload_count']
 return {'payloads':len(rows),'manifest_sha256':sha(manifest_bytes),'seal_sha256':sha(z.read(prefix+'SEAL.json'))}
def section(s, n):
 return s.split('## '+str(n)+'. ',1)[1].split('\n## '+str(n+1)+'. ',1)[0]

data = (ROOT/'input'/ARCHIVE_NAME).read_bytes()
assert sha(data) == EXPECTED_ARCHIVE
z, pre = open_archive(data)
result = {'status':'PASS','archive':{'filename':ARCHIVE_NAME,'sha256':sha(data),'bytes':len(data)},'edition_inventory':inventory(z,pre)}
get = lambda s:z.read(pre+s)
edition = get('FINAL_THEOREM_AND_PROOF.md')
pdf = get('Q16_Final_Theorem_and_Proof_Recovered_2026-10-13.pdf')
assert sha(edition) == THEOREM_PIN and sha(pdf) == PDF_PIN
assert edition == (ROOT/'input/FINAL_THEOREM_AND_PROOF.md').read_bytes()
assert pdf == (ROOT/'input/Q16_Final_Theorem_and_Proof_Recovered_2026-10-13.pdf').read_bytes()
result['theorem']={'sha256':sha(edition),'bytes':len(edition)}
result['pdf']={'sha256':sha(pdf),'bytes':len(pdf)}
result['original_pins']=[]
for name, pin in ORIGINALS.items():
 b = get('reconstructed/'+name)
 assert sha(b) == pin,name
 result['original_pins'].append({'path':'reconstructed/'+name,'sha256':pin,'bytes':len(b)})
old=get('reconstructed/THEOREM_AND_PROOF_V1.md').decode()
new=edition.decode()
assert all(section(old,n)==section(new,n) for n in range(2,9))
plan=json.loads(get('verification/EDIT_PLAN.json'))
rebuilt=old
for entry in plan:
 assert rebuilt.count(entry['old']) == 1
 rebuilt=rebuilt.replace(entry['old'],entry['new'],1)
assert rebuilt == new
assert len(plan)==6
assert 'r_amp = floor(c)+2' in new
result['revision']={'unchanged_proof_sections':list(range(2,9)),'exact_edit_plan_reconstruction':True,'edit_groups':len(plan),'manual_edit_scope':'Witness clarification; equivalent input display; historical review, attribution, implementation and recovery boundaries'}

down=get('sources/ACCEPTED_DOWNSTREAM_REVIEW.zip')
assert sha(down)=='84d6b0a45c5bc432095c8705ba84384e2825f0d46b4daab33f65e52d70784dc7'
dz,dp=open_archive(down)
result['downstream_inventory']=inventory(dz,dp)
author=dz.read(dp+'input/next_cycle_q16_parent_scope_audit.zip')
assert sha(author)=='2a8b8d9ad3230dade9764553f5f31575083067a67d11a2f97bd292da68cc1fda'
az,ap=open_archive(author)
result['nested_author_inventory']=inventory(az,ap)
for here,there in [('P05_ACCEPTED.md','sources/P05_ACCEPTED.md'),('UNIFORM_TRANSFER_LEMMA.md','UNIFORM_TRANSFER_LEMMA.md'),('ORIGINAL_ROWS.json','ORIGINAL_ROWS.json')]:
 assert get('reconstructed/'+here)==az.read(ap+there)
assert get('reconstructed/TRANSFER_INDEPENDENT_CONTROLS.json')==dz.read(dp+'INDEPENDENT_RESULTS.json')
assert get('reconstructed/TRANSFER_AUTHOR_CONTROLS.json')==dz.read(dp+'AUTHOR_CONTROLS_REPLAY.json')
result['exact_nested_provenance_matches']=5

count=0
for denom in [1,2,3,10,100,1000]:
 for num in range(1,81):
  c=Fraction(num,denom)
  r=c.numerator//c.denominator+2
  assert r > c+1
  for N in [1,2,3,17,1024]:
   M=1 << (4*N-1).bit_length()
   bound=Fraction(2**(2*r-1),M**r)
   assert bound<=Fraction(1,2*N**r)
   count+=1
result['new_exact_witness_and_amplification_cases']=count
result['witness_proof']='For any real c>0, floor(c)>c-1, hence r=floor(c)+2>c+1. With M>=4N, 2^(2r-1)M^(-r)<=N^(-r)/2<=N^(-c). Finite cases corroborate, not prove, the universal statement.'

pdf_path=ROOT/'input/Q16_Final_Theorem_and_Proof_Recovered_2026-10-13.pdf'
txt=subprocess.check_output(['pdftotext','-layout',str(pdf_path),'-']).decode()
fmt=re.sub(r'\[([^\]]+)\]\([^)]*\)',r'\1',new)
fmt=re.sub(r'^#+\s*','',fmt,flags=re.M).replace('**','').replace('`','')
txt=re.sub(r'Q16\s*\|\s*Review-incorporating recovered edition\s*\|\s*Private\s*\d+','',txt)
a=''.join(fmt.split()); b=''.join(txt.split())
assert a==b
result['pdf_text']={'entire_document_match_after_formatting_only_normalization':True,'normalized_characters':len(a),'pages':11,'visual_inspection_record':'verification/VISUAL_QA.json'}
result['execution_scope']={'only_new_reviewer_program_executed':True,'archived_or_producer_programs_executed':False,'full_historical_replay':False,'engineering_or_novelty_certification':False}
print(json.dumps(result,indent=2,sort_keys=True))
