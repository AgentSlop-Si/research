"""New exact-arithmetic controls for the ALG029 contract comparison.
No inherited research code or Fourier implementation is imported/executed.
These finite algebraic controls supplement, not replace, the report's proofs.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

def norm2(y): return sum(v*v for v in y)
def hard(y,theta2): return tuple(v if v*v>theta2 else F(0) for v in y)
def err2(y,z): return norm2(tuple(a-b for a,b in zip(y,z)))
def tail2(y,k): return sum(sorted((v*v for v in y),reverse=True)[k:])

y=tuple(map(F,[30,3,1,0]));a=F(1,10);t2=F(1);theta2=a*a*norm2(y)
z=hard(y,theta2)
assert theta2==F(91,10) and z==(30,0,0,0)
assert F(3)**2>=9*t2 and err2(y,z)==10 and err2(y,z)>F(11,10)*t2
assert err2(y,z)>F(11,10)**2*t2
w=(F(3),F(1),F(0),F(0));candidate=(F(13,4),F(0),F(0),F(0))
assert hard(w,F(1))==(3,0,0,0)
assert err2(w,candidate)==F(17,16) and candidate!=hard(w,F(1))
diffuse=(F(1,2),)*4
assert norm2(diffuse)==1 and hard(diffuse,F(1,4))==(0,0,0,0)
assert err2(diffuse,hard(diffuse,F(1,4)))==1
assert tail2(w,2)==0
# Exhaustive independent check of the additive-tail inequality on real spectra.
count=0
for n in [1,2,4]:
 for y in product(map(F,[-2,-1,0,1,2]),repeat=n):
  for k in range(1,n+1):
   for theta2 in map(F,[0,F(1,4),1,F(9,4),4,9]):
    z=hard(y,theta2)
    assert err2(y,z)<=tail2(y,k)+k*theta2
    count+=1
out={
 'status':'PASS',
 'role':'Finite exact controls only; analytical proofs in REPORT.txt',
 'historical_or_supplied_code_executed':False,
 'witnesses':{
  'positive_tail_high_snr':{'y':['30','3','1','0'],'k':2,'a':'1/10','theta_squared':'91/10','threshold_output':['30','0','0','0'],'tail_squared':'1','error_squared':'10','source_squared_target_at_b_1_10':'11/10'},
  'reverse_contract':{'y':['3','1','0','0'],'k':1,'theta':'1','allowed_approximate_output':['13/4','0','0','0'],'tail_squared':'1','error_squared':'17/16','b':'1/16','not_exact_threshold':True},
  'diffuse_ties':{'y':['1/2']*4,'theta':'1/2','relative_l2_error':'1'},
  'decomposition_vs_best_k':{'y':['3','1','0','0'],'head_size':1,'budget_k':2,'decomposition_tail_squared':'1','best_k_tail_squared':'0'}
 },
 'additive_tail_inequality_control_count':count
}
Path(__file__).with_name('FRESH_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
