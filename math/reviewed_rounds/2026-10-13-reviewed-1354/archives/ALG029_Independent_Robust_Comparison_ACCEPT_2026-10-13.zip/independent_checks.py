"""Reviewer-authored controls. No author or historical program is executed."""
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path

def mag2(z): return z[0]*z[0]+z[1]*z[1]
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def hard(y,q): return tuple(z if mag2(z)>q else (Q(0),Q(0)) for z in y)
def error(y,z): return sum(mag2(sub(a,b)) for a,b in zip(y,z))
def tail(y,k): return sum(sorted([mag2(z) for z in y],reverse=True)[k:])
def real(v): return tuple((Q(z),Q(0)) for z in v)
y=real([30,3,1,0]); energy=sum(map(mag2,y)); q=energy/100
assert energy==910 and q==Q(91,10)
assert hard(y,q)==real([30,0,0,0]) and error(y,hard(y,q))==10
assert tail(y,2)==1 and 3**2==9*tail(y,2)
assert 10>Q(11,10) and 10>Q(11,10)**2
x=((Q(17),Q(0)),(Q(29,2),Q(3,2)),(Q(14),Q(0)),(Q(29,2),Q(-3,2)))
assert sum(map(mag2,x))==energy
# Independent exact U4 transform of the supplied inverse witness.
powers=((Q(1),Q(0)),(Q(0),Q(-1)),(Q(-1),Q(0)),(Q(0),Q(1)))
def mul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
out=[]
for r in range(4):
 terms=[mul(x[c],powers[(r*c)%4]) for c in range(4)]
 out.append((sum(z[0] for z in terms)/2,sum(z[1] for z in terms)/2))
assert tuple(out)==y
assert hard(y,Q(1))==real([30,3,0,0])
assert error(y,hard(y,Q(1)))==1
rev=real([3,1,0,0]); approx=real([Q(13,4),0,0,0])
assert error(rev,approx)==Q(17,16) and approx!=hard(rev,Q(1))
assert tail(rev,1)==1 and tail(rev,2)==0
alpha_fixed_k_checks=0
# For k=2,N=2^(2^q), alpha*log2(N)=2^(q-sqrt(q+1));
# q^2>q+1 proves the exponent positive, increasingly so for integer q>=2.
for exponent in range(2,101):
 assert exponent*exponent>exponent+1
 alpha_fixed_k_checks+=1
alphabet=((Q(0),Q(0)),(Q(1),Q(0)),(Q(0),Q(1)),(Q(1),Q(1)))
count=0
for n in (1,2,4):
 for spectrum in product(alphabet,repeat=n):
  for k in range(1,n+1):
   for threshold2 in (Q(0),Q(1,4),Q(1),Q(3,2),Q(2),Q(3)):
    assert error(spectrum,hard(spectrum,threshold2))<=tail(spectrum,k)+k*threshold2
    count+=1
result={'verdict':'PASS','executed':'Reviewer-authored script only','complex_spectrum_inequality_cases':count,'fixed_k_alpha_exact_sign_checks':alpha_fixed_k_checks,'witness_energy':'910','witness_threshold_squared':'91/10','witness_error_squared':'10','witness_best_2_tail_squared':'1','inverse_U4_witness':['17','29/2+3i/2','14','29/2-3i/2'],'supplied_tail_threshold_error_squared':'1','reverse_error_squared':'17/16','decomposition_tail_squared':'1','best_2_tail_squared':'0'}
Path(__file__).with_name('INDEPENDENT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
