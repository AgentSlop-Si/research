#!/usr/bin/env python3
"""Verify this review's manifest without executing any research program."""
from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parent
m=json.loads((base/'MANIFEST.json').read_text())
for item in m['files']:
    rel=Path(item['path'])
    assert not rel.is_absolute() and '..' not in rel.parts
    b=(base/rel).read_bytes()
    assert len(b)==item['size_bytes'], str(rel)
    assert hashlib.sha256(b).hexdigest()==item['sha256'], str(rel)
print(json.dumps({'status':'PASS','payload_members_verified':len(m['files'])},sort_keys=True))
