# Independent review of marker Schur fill in and constant input action

Reviewed 13 October 2026 UTC. Verdict: **ACCEPT within the stated arithmetic, input, and output model.** No mathematical repair of the candidate is required. The qualifications below fix how the accepted statements may be used.

The exact first-return fill-in count, nonzero-scalar support preservation, paired-row top coefficient, and paid constant-input action are valid. None supplies a fast polynomial-input inverse, a sub-N-log-N full Fourier algorithm, or an automatic application of either quadratic scalar-cycle endpoint theorem. The recommendation 56/100 may stand as a next-work recommendation only; the existing ALG-068 priority 48 is unchanged.

## 1 Accepted object and provenance

This verdict binds to the following supplied candidate, whose actual bytes were available:

- Archive: Marker_Schur_Fill_In_and_Constant_Action_Candidate_2026-10-13.zip
- Archive size: 15,274 bytes
- Archive SHA-256: 32391d3bf9b675b61c08a0b83fd3959c648076d08a939949be6cd213f2c32a9f
- REPORT.md SHA-256: 69937b7458e3ae50cfa86cd4353cff6cfb76ca42d5878fb341d0400d07ad1782

All five manifest-listed candidate members were independently checked against their recorded sizes and hashes. All six ZIP members, including the manifest, match the supplied local candidate bytes. The complete original ZIP and its unchanged extracted contents are preserved in this review packet.

Earlier ALG-068 source archives were not present at the supplied location. This review does not authenticate or newly rehash those missing originals. Historical hashes quoted by the candidate remain historical assertions, not newly verified evidence. Instead, the matrix, marker, Schur, and Fourier identities below were rederived from the explicit definitions in the available candidate. This is sufficient for the accepted self-contained claims; it is not a reconstruction of every earlier ALG-068 result.

The published endpoint review was independently fetched through the connected repository. Its returned GitHub blob SHA is b2862c2be105712bb6313184d09620b4b062c6fe, matching the candidate's binding. A read-only snapshot is included. No candidate, predecessor, or downloaded research program was executed or imported. The independent controls were written first; the candidate checker was subsequently inspected only as text.

## 2 Definitions and conventions

Let N=2^n, n>=1, and let K contain a supplied root omega of exact order N. Then char(K) is not 2. Work with column vectors and destination rows:

    Q e_s = e_(2s mod N) + omega^s e_(2s+1 mod N).

For 1<=b<n, set L=n-b, r=2^L, eta=omega^(2^b), h=L+1. R consists of all n-bit words ending in 0^b, A consists of the n-bit words avoiding 0^b, T=R union A, and F is the complementary set. Leading zeros are included when testing these fixed-length words. R and A are disjoint. The matrix B=Q_FF is indexed by F.

Let a_b(j) count j-bit words avoiding 0^b, with a_b(0)=1. Its initial values a_b(j)=2^j for j<b and its b-term recurrence for j>=b are correct, including b=1.

All cost statements count exact field operations and word-address/index operations on O(log N)-bit words. They do not provide bit complexity for representing arbitrary field elements, numerical stability, root discovery, or floating-point precision guarantees.

## 3 Independent proof of the horizon and all input identity

A free word contains a marker and does not end in one. Its rightmost marker therefore begins at position at most L-1, with positions counted from zero at the left. As the state shifts, an existing marker moves left by one. If a new marker is formed, it ends at the suffix and the state is immediately retained. Without a new marker, every old marker has disappeared after at most L shifts, and the state is in A. Thus there is no path of L edges entirely in F and B^L=0. This is a weighted support argument, so it is unaffected by the allowed field.

It follows directly that D(z)=I-zB has polynomial inverse sum_(j=0)^(L-1) z^j B^j and determinant one. Block elimination gives the candidate's S(z)=I-sum_(t=1)^h z^t K_t, its forced source, and its recovery formulas. These identities hold over K[[z]] for every fresh x. S(0)=I ensures a unique formal solution. At a scalar specialization, det S(z)=det(I-zQ); inversion must still exclude the zeros of that determinant.

For a path of t<=n edges from s with appended t-bit word v, direct accumulation of the odd-edge exponents gives

    path weight = omega^[s rev_t(v)+gamma(v)],

where gamma(v) is the sum of the prefixes preceding the 1 bits of v. This gamma obeys the candidate's recurrence. Reduction of intermediate state indices modulo N only changes exponents by multiples of N. At t=n the endpoint is exactly v, and each source has exactly one such path. Consequently

    (Q^n x)_v = omega^gamma(v) sum_s x_s omega^[s rev_n(v)].

This verifies the Fourier sign, the exact n-bit reversal, the row phase, the source indexing, and the all-input requirement. No transposed Fourier convention or pretransformed input is being used.

## 4 Excursion count and scalar specialization

A source in A cannot enter F: creating a marker puts it in R, and otherwise it remains in A. A source in R has one retained zero-edge and one 1-edge into F. The latter fact uses b<n.

After appending that first 1, an excursion stays free while its new suffix avoids 0^b and the old rightmost marker has not expired. At depth t=1,...,L there are a_b(t-1) surviving appended prefixes. Both children of each surviving node exist. Returns before h are precisely first completion of the new marker; every remaining branch returns at h when the old marker expires. The associated full binary tree has sum_(j=0)^(L-1) a_b(j) internal vertices and one more leaf than internal vertices. Hence, for each source in R, the number of return words is

    ell_b(L)=1+sum_(j=0)^(L-1) a_b(j).

Every return uses at most h<=n edges. Given source, target, and length, its appended word is fixed by the target's last t bits, so there cannot be two paths in one coefficient entry. Its weight is a nonzero monomial. Therefore

    sum_(t=2)^h nnz K_t = r ell_b(L),
    nnz K_1 = r+2|A|.

The cross-degree support assertion also holds. For a fixed R source, a direct retained target has at least b+1 trailing zeros. An earlier excursion return has exactly b trailing zeros; its second-rightmost marker begins at L-t, the shifted position of the old rightmost marker. No intervening new marker can occur. A return at h has no old marker and at most the newly formed suffix marker. These cases identify the return length and are mutually exclusive. A sources contribute only at degree one.

Thus all positive-degree coefficient supports are disjoint. For every z0!=0, each supported entry of K(z0) is exactly one nonzero monomial times z0^t, giving

    nnz K(z0)=r+2|A|+r ell_b(L).

This assertion is about the operator entries, not their values on a chosen input. It does not imply that every output is nonzero. For S(z0), cancellation with the identity is possible on the diagonal. For example, the (0,0) direct term cancels at z0=1. Off-diagonal feedback entries cannot be canceled by the identity. Neither scalar invertibility nor a generic-specialization assumption is needed for this support conclusion.

## 5 Highest coefficient and its rank

Set m=r/2, and let V contain the (L-1)-bit words avoiding 0^b. Write a=|V|=a_b(L-1). The top return words are exactly

    w=r+2v+epsilon, v in V, epsilon in {0,1}.

Let W be this set of 2a targets. The entire support of H=K_h is W x R. In the full retained matrix, every column outside R and every row outside W is zero. Substitution of s=2^b j into the short-path formula gives

    H[w,2^b j] = omega^gamma(w) eta^[j(1+2 rev_(L-1)(v))].

The terminal bit changes only the output phase. In particular, the 2a rows are paired proportional rows, not 2a independent Fourier rows. The required small-trajectory index is floor(w/2), the leading L bits. Reversing the trailing L bits is wrong, including at n=2,b=1.

Since eta has exact order r, eta^m=-1. For arbitrary u in K^r set

    g_j=eta^j(u_j-u_(j+m)), 0<=j<m.

The top action becomes an m-point Fourier transform of g at frequencies rev_(L-1)(v), followed by the two output phases for each v. The difference fold is surjective: any g is obtained by choosing u_(j+m)=0 and u_j=eta^(-j)g_j. The m-point Fourier matrix is invertible because its nodes are distinct and m is invertible in K. Any subset of its rows is independent. Thus

    nnz H=2r a_b(L-1),
    rank H=a_b(L-1).

This argument includes m=1 and the empty 0-bit word. A factorization through q scalar linear measurements requires q>=a, but this is a linear-dimension statement. It does not lower-bound the number of arithmetic operations by nnz H. A nonzero input can also lie in H's kernel; the equal-halves input is an explicit example.

## 6 Asymptotic fill in

For a word of length j, fix the bits in one-based positions b,2b,... to 1. Every block of b consecutive positions contains one of those fixed positions, so the resulting 2^[j-floor(j/b)] words avoid 0^b. Hence

    nnz H >= 2^[2L-floor((L-1)/b)].

For b=floor(log2(n/(4 ln n))) and sufficiently large n, 1<=b<n, b tends to infinity, and b=o(n). Its lower-bound exponent is 2n-O(b)-O(n/b)=2n-o(n). The upper bound nnz H<=r^2<=N^2 then proves nnz H=N^(2-o(1)). The formula for b is an asymptotic choice, not a valid small-n definition without checking b>=1.

At most |W|=2a entries of the top block can be diagonal. Its off-diagonal entries survive in every S(z0), z0!=0, so

    nnz S(z0)>=2a(r-1)=N^(2-o(1))

under that asymptotic choice. This holds even at singular scalar specializations. It is a lower bound on scalar writes for explicit materialization, including sparse storage that writes every nonzero entry. Shared formulas, implicit circuits, and implicit solvers need not pay that materialization cost.

The action complexity below requires only |T|<=N and r=N/2^b=Theta(N ln n/n). It does not silently rely on an unproved small-|A| estimate. The stronger historical small-retained-set motivation is therefore unnecessary for accepting this particular cost bound.

## 7 Paid constant input action and complete cost model

Take an arbitrary constant u_T, and form the r-vector u_R indexed by j with global index 2^b j. For the small weighted shift Q_r with root eta, stream q_t=Q_r^t u_R for t=0,...,L. Each step uses O(r) scalar work and can overwrite a two-buffer representation.

For t=2,...,L, let a0 be a small-state index and w=a0 mod 2^t. Admit it only when its t-bit word begins with 1 and first completes 0^b at its end. All paths represented in (q_t)_a0 then correspond exactly to first returns from the large R source set. Their global destination is

    y=2^b(a0-w)+w.

The source-dependent phases agree; changing from eta to omega changes the appended-word phase by (omega/eta)^gamma(w). This proves the candidate's routing formula. Distinct admitted a0 have distinct destinations: a0-w is divisible by 2^t and w is less than 2^t, so their high and low pieces cannot collide. For these indices the displayed y already lies in [0,N); the candidate's modulo N is harmless.

At degree h, q_L at floor(w/2) has precisely the source-dependent phase required by the preceding top-coefficient formula. Multiplication by omega^gamma(w) eta^[-gamma(floor(w/2))] gives the correct result for both terminal bits. Add the direct retained action, negate the positive-degree feedback terms, and emit u_T at degree zero. This computes all coefficients of S(z)u_T.

The claimed ledger can be implemented without hiding an extra logarithm:

1. Generate omega powers by recurrence, and eta powers as a subtable. Gamma phases for any base rho can be generated using phase(2a)=phase(a) and phase(2a+1)=phase(a) rho^a. Precompute the required rho powers. This costs O(N) scalar operations rather than an exponentiation per output.
2. Generate fixed-length marker membership, first-completion flags, and clipped zero-run lengths by a binary-prefix dynamic program. All prefix nodes of lengths 0 through n together number less than 2N. This pays O(N) indexing operations and storage, including leading-zero states.
3. Read and copy u_T and process its direct retained edges in O(|T|). Compute the L small steps, test at most r indices per step, and apply phase corrections in O(rL). All route tests use the prepared flags or constant-time bit/index operations.
4. Emit degree-coordinate-value records. Their count is O(|T|+rL). The direct degree may accumulate two incoming contributions; these are ordinary paid additions. The nontrivial excursion routes are injective within each degree. A dense |T|-by-(L+2) rectangle or a sorted output is not being promised for free.

Therefore the constant-input action has total O(N+rL) work, including preparation, with O(N+r) streaming working storage. Storing all output records adds O(|T|+rL) storage. Substituting the marker choice gives O(N log n)=O(N log log N).

The separate O(r log r) action for H uses its active R input and W output, or an equivalent sparse output convention. Demanding a full dense retained vector additionally costs O(|T|) writes for zero coordinates. That convention must accompany any isolated use of the H bound. The main S(z)u_T bound already pays |T| and is unaffected.

The supplied checkers are correctness oracles. Their repeated modular powers, string tests, dictionaries, and explicit matrix construction are not benchmarks or implementations of the asymptotic optimized ledger. The bound follows from the paid construction above, not their runtimes.

## 8 Polynomial input and inverse boundary

The unknown y_T(z) in a Schur solve is a polynomial jet or formal series. It is not one constant retained vector. Applying the constant routine to each of m0+1 input coefficients independently, sharing setup and charging shifts/additions, yields only

    O(N+(m0+1)(|T|+rL)).

Likewise a causal recurrence for an inverse jet can compute each new retained coefficient, invoke the constant feedback action, and add its future contributions. This is a valid schedule, but at m0=n its displayed cost is O(N n log n) for the marker choice. It does not improve the known O(Nn) full-state trajectory for arbitrary fresh source, solve, and recovery together. The associated jet input/output and accumulation storage must also be paid.

A stronger result needs an actual sharing or convolution construction for polynomial inputs or a paid retained inverse together with fresh-source and recovery accounting. Neither the top coefficient's Fourier structure nor its rank supplies this. This review accepts no faster complete transform.

## 9 Endpoint theorem boundary

The independently fetched [endpoint review](https://github.com/AgentSlop-Si/research/blob/main/math/reviewed_rounds/2026-10-12-reviewed-research/sparse-endpoint-obstructions.md) proves exact d^2 and d^2+q endpoint counts in stated single scalar-cycle grammars. It requires nonzero target entries and 2-by-2 minors. Its multi-read theorem additionally requires separately correct masked target-row contributions.

Here B can branch. At n=3,b=1, the free destination 011 has free predecessors 001 and 101. No permutation and nonzero diagonal gauge turns two nonzero incoming entries into the one allowed by a scalar predecessor. This does not exclude a general basis change or state splitting; those would need a new paid conversion.

Dyadic Fourier targets at N>=4 also have zero 2-by-2 minors: use rows 0,N/2 and columns 0,2. The active H block contains proportional row pairs, and the full retained H has zero rows/columns. Its retained dimension, r, or rank a cannot simply be substituted for d in the endpoint theorem. The small multistage Q_r circuit and coefficient recovery do not establish independently correct masked reads from a single cyclic Green state.

The quadratic theorems consequently do not transfer. Conversely, the cheap constant action does not contradict them. This review does not newly verify or strengthen the separate historical general mixed-read baseline.

## 10 Primary source comparison and novelty

[Zheng, Kingsford, and Marcais, Definition 2 and Lemma 2](https://arxiv.org/html/2001.06550v1) use the prefix-marker/marker-avoiding depathing set. Reversing words gives the suffix-marker set used here. Their path length counts vertices; n-b surviving vertices correspond to B^(n-b)=0. The binary parameter in that source is one larger than this candidate's chosen b. The parameterized language argument applies. The source does not establish the weighted Fourier inverse claimed as a remaining goal here.

[Boito and Eidelman, Section 2](https://arxiv.org/html/2308.02701v1#S2) state the band-inverse/Green-rank relationship and describe quasiseparable representations. Branching nilpotence alone supplies none of the constant-bandwidth hypotheses needed to invoke that structure.

[De Sa et al., Appendix B, PDF pages 36-39](https://arxiv.org/pdf/1611.01569) was read directly in this review. Its sparse-product-width definition subtracts intermediate dimensions, relates the resulting measure to linear straight-line programs, and discusses FFT factorizations and prefix sums. This directly supports distinguishing entry materialization, endpoint cost, and multistage arithmetic work. The PDF was accessible although the PMC HTML body returned a browser-check page. The candidate's earlier access limitation therefore need not be inherited by this review.

These are targeted primary-source checks. The marker language and general sparse-factorization principles have clear classical overlap. The accepted fusion is a useful source-specific derivation and implementation interface; this review makes no worldwide novelty or historical-priority claim.

## 11 Fresh controls and disposition

All independent controls passed, with a byte-identical replay:

- 147 parameter cases across GF(3), GF(5), GF(17), GF(41), GF(97), GF(193), GF(257), and GF(65537), through n=10 where the field contains the needed root
- 39 b=n empty-free-set boundary cases
- 2,329 constant-action vectors, including 1,888 retained basis vectors
- 108 exact excursion-count, disjoint-support, and top-rank cases
- 54,716 exact top-entry phase identities and 1,804 difference-fold output identities
- 707 nonzero scalar specializations and 108 nonzero-input kernel guards
- 4,257 free-basis horizon checks
- 648 fresh full-input vectors, 2,964 source/solve coefficient checks, 2,964 recovery coefficient checks, and 10,648 full Fourier output values
- 220 avoidance-count/lower-bound checks
- Independent branching, composite-minor, and incorrect trailing-index guards
- A separate field-independent checker verifying 173,740 short-path exponent congruences for every source and appended word at all t<=n, n=1,...,8

Examples: n=4,b=1 gives 32 excursion entries and 16 top entries; n=6,b=2 gives 192 excursion entries and 160 top entries. At n=10,b=4 there are 3,840 excursion entries and 3,712 top entries.

The first development run of the new review checker exposed a checker-only sentinel issue: a string search returning -1 could match t-b when t<b. Requiring t>=b+1 corrected that test implementation. The candidate's condition was already correct. This was not a mathematical counterexample or a candidate repair. The final independently replayed code is sealed with the review.

**Final disposition: scoped ACCEPT.** Preserve the exact fill-in and constant-action interface as established. Keep polynomial-input sharing, retained inverse, fresh-source/recovery, and any legal scalar-cycle representation as open work. Recommendation 56/100 is unchanged as a recommendation; no table, repository, public publication, or external research rank was changed.
