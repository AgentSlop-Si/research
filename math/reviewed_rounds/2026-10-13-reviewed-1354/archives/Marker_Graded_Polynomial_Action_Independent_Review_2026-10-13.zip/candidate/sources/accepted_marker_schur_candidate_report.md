# Marker Schur fill-in versus scalar endpoint accounting

Date: 2026-10-13. Status: self-contained candidate theorem and fresh exact controls; independent review is still required. This is a bounded extension of the existing ALG-068 object, not a new research identity, a novelty claim, or a faster complete Fourier transform.

## Result

There is a legitimate useful fusion at the **accounting interface**, but neither accepted quadratic sparse-endpoint theorem directly applies to marker elimination.

1. The complete first-return feedback has an exact fill-in count. Its different positive-degree coefficient matrices have disjoint entry supports; hence no cancellation of those entries occurs at a nonzero scalar specialization.
2. Its highest coefficient has a rectangular, fully nonzero block with **paired proportional rows**. It is exactly an odd-frequency partial Fourier transform, with a paid difference-fold implementation. Its rank is half its number of nonzero rows.
3. Explicit materialization is nearly quadratic in the original Fourier length for the asymptotic small-marker choice. Nonetheless, applying the **whole Schur polynomial to a constant arbitrary retained vector** costs only O(N+rL), including preparation. This is a specific action circuit, not an inverse circuit.
4. The single scalar-cycle hypothesis, target minor hypothesis, and independently correct masked-read hypothesis of the accepted endpoint theorems are missing. Replacing the branching eliminated graph by a scalar scan would require a new, fully paid representation.

The existing cheap polynomial-input inverse, source/recovery, and full Fourier synthesis obligations remain open. Historical ALG-068 priority 48 is unchanged.

## 1. Parameters and the all-input identity

Let K be a field containing a supplied primitive Nth root omega, where N=2^n, n>=1. Thus char(K)!=2. For 1<=b<n put

    L=n-b, r=2^L, eta=omega^(2^b), h=L+1.

All states are fixed-length n-bit words, including leading zeros. Matrices act on column vectors, rows being destinations. Let

    Q e_s = e_(2s mod N) + omega^s e_(2s+1 mod N),
    R = {2^b j : 0<=j<r},
    A = {n-bit words avoiding 0^b},
    T = R union A, F = complement(T), B=Q_FF.

R and A are disjoint. Let a_b(m) count m-bit words avoiding 0^b, with a_b(0)=1. It equals 2^m for m<b and obeys a_b(m)=sum_(j=1)^b a_b(m-j) for m>=b.

The already accepted horizon B^L=0 makes D(z)=I-zB unimodular: D^(-1)=sum_(j=0)^(L-1)z^j B^j and det D=1. Define

    K_1=Q_TT,
    K_t=Q_TF B^(t-2)Q_FT  (2<=t<=h),
    K(z)=sum_(t=1)^h z^t K_t,
    S(z)=I-K(z).

For every arbitrary fresh x in K^N, the exact formal identities are

    f(z)=x_T+z Q_TF D(z)^(-1)x_F,
    y_T(z)=S(z)^(-1)f(z),
    y_F(z)=D(z)^(-1)x_F+z D(z)^(-1)Q_FT y_T(z),
    y(z)=(I-zQ)^(-1)x.

Define gamma(0)=0, gamma(2a)=gamma(a), gamma(2a+1)=gamma(a)+a, and let rev_m reverse exactly m bits. Then

    [z^n]y_w(z)=omega^gamma(w) sum_(s=0)^(N-1) x_s omega^(s rev_n(w)).

Thus the recovered top coefficient is an all-input Fourier transform with explicitly fixed row reversal and phase. No special input or pretransformed source is assumed. S(0)=I gives formal invertibility. At a scalar z, the inverse is permitted only if det(I-zQ)=det S(z)!=0; fill-in claims below do not presume invertibility.

When b=n, F is empty, T is the whole state set, and S=I-zQ. The nonempty-block formulas below are not asserted at L=0.

## 2. First-return language and exact fill-in

Only R can feed an excursion into F. A word in A can acquire a first marker only at its new suffix, which immediately belongs to R. From s in R, append 1 to enter F. The old rightmost marker is then at position L-1 (zero-based from the left). While the walk stays free, that position decreases by one per step. A new marker would end at the suffix and terminate the excursion.

Consequently every first return from R has the following description, independent of which source in R was used:

- It begins with appended bit 1.
- Before time h, it returns only when the first new 0^b is completed.
- Any surviving prefix of length L exits at time h, because the last old marker has expired. Either final bit is permitted.

At depth t, 1<=t<=L, the number of surviving internal words is a_b(t-1). The first bit is fixed at 1, so the suffix of length t-1 must avoid 0^b. This is a finite full binary tree, with sum_(j=0)^(L-1)a_b(j) internal nodes and therefore

    ell_b(L)=1+sum_(j=0)^(L-1)a_b(j)

leaves. Each leaf is one first-return appended word.

Every path considered has t<=h<=n edges. Given its source and target, its appended t bits are the target's last t bits, so it is unique. Its weight is a single nonzero product. Thus there is no weighted-path cancellation inside a coefficient entry, over any admitted field. It follows that

    sum_(t=2)^h nnz(K_t)=r ell_b(L),
    nnz(K_1)=r+2|A|.

The second equation holds because each R source has exactly its zero-edge retained, whereas each A source has both edges retained.

### Disjoint coefficient supports, including scalar specialization

For a source in A only K_1 has nonzeros. Fix instead a source in R.

- A one-step retained destination has at least b+1 trailing zeros. Its second-rightmost occurrence of 0^b starts at position L-1.
- A first return at 2<=t<=L has exactly b trailing zeros. Its rightmost marker is the newly formed suffix at position L, and its second-rightmost marker is the old rightmost marker shifted to position L-t. No intervening new marker is possible before a first return.
- A first return at h has lost every old marker. Its destination has at most one marker, which, if present, is the final suffix.

These destination properties are mutually exclusive and determine t. Therefore no matrix entry (destination,source) occurs in two distinct K_t. This proves

    nnz K(z0)=r+2|A|+r ell_b(L)  for every z0 in K with z0!=0.

The same equality counts the positive-degree nonzero coefficient entries of K(z). This stronger claim is specific to this first-return language. It is not inferred from nilpotence or from arbitrary DAG support.

The diagonal of S(z0)=I-K(z0) can cancel at particular z0; that is the only possible cancellation between its identity term and this feedback. The bounds in Section 3 use off-diagonal entries and remain valid even there. At z0=0 the feedback vanishes, so the nonzero-specialization qualification is essential.

## 3. Exact highest coefficient, rank, and materialization barrier

Let H=K_h. Write m=r/2=2^(L-1) and define

    V={v:0<=v<m, the (L-1)-bit word v avoids 0^b},
    a=|V|=a_b(L-1),
    W={r+2v+epsilon : v in V, epsilon in {0,1}}.

Then |W|=2a, W is contained in T, and the entire support of H is **W x R**. Hence

    nnz H=2ra.

For j in {0,...,r-1}, v in V and epsilon in {0,1}, put w=r+2v+epsilon. Its length-h appended word is 1 followed by v followed by epsilon. The short-path phase formula gives

    H[w,2^b j]
      =omega^gamma(w) eta^[j(1+2 rev_(L-1)(v))].             (1)

The terminal bit epsilon disappears from the source frequency modulo r, but not from the destination phase. Thus these rows come in nonzero proportional pairs. They are **not 2a independent rows of F_r**. Reading the trailing L bits in place of the leading L bits gives a false formula, already at n=2,b=1.

Set theta=eta^2, a primitive mth root (m=1 is allowed). For arbitrary u in K^r define the paid modulated difference fold

    g_j=eta^j(u_j-u_(j+m)),  0<=j<m.

Since eta^m=-1, equation (1) becomes the all-input identity

    (H u_R)_w=omega^gamma(w)
               sum_(j=0)^(m-1) g_j theta^[j rev_(L-1)(v)].  (2)

The fold is surjective onto K^m. The selected a rows of the m-point Fourier matrix are distinct and linearly independent, and the phased row-duplication map is injective on those a values. Therefore

    rank H=a_b(L-1).

Any factorization of H through q scalar linear measurements needs q>=a. This is an information-dimension statement, not an arithmetic lower bound. Inputs can cancel individual leading outputs; nonzero matrix entries do not mean nonzero values for every input.

### Near-quadratic explicit fill-in

For every m0>=0, forcing bits at positions b,2b,... to 1 constructs 2^[m0-floor(m0/b)] marker-avoiding words. Thus

    a_b(m0)>=2^[m0-floor(m0/b)],
    nnz H>=2^[2L-floor((L-1)/b)].                          (3)

At the source's asymptotic choice b=floor(log2(n/(4 ln n))), for sufficiently large n we have b tending to infinity and b=o(n). The logarithm base 2 of the lower bound is 2n-O(b)-O(n/b)=2n-o(n). Since nnz H<=r^2<=N^2,

    nnz H=N^(2-o(1)).

This counts scalar coefficient entries, not the number of symbols in a shared formula. It forces that many scalar writes in an explicitly materialized coefficient representation. For every nonzero scalar z0, all off-diagonal entries of the H block survive in S(z0); at most 2a entries of the block are diagonal. Therefore

    nnz S(z0)>=2a(r-1)=N^(2-o(1))

at that asymptotic marker choice. No claim is made that an implicit solver must materialize these entries. In fact Section 4 supplies a much cheaper action.

## 4. Paid constant-input Schur-polynomial action

Let u_T be an arbitrary **constant** retained vector; its R restriction is indexed as u_j=u_(2^b j). Compute the stationary trajectory

    q_t=Q_r^t u_R, 0<=t<=L,

where Q_r uses the primitive root eta. Each stage costs O(r) exact field operations, and the full trajectory costs O(rL).

For 2<=t<=L and a0 in {0,...,r-1}, let w=a0 mod 2^t. Retain w precisely when its t-bit form begins with 1 and its first occurrence of 0^b ends at its last bit. Then route

    (omega/eta)^gamma(w) (q_t)_(a0)

to degree t and global coordinate

    y=2^b(a0-w)+w mod N.                                 (4)

This route is injective among admitted a0. The small and large paths have the same source-dependent phase eta^[j rev_t(w)]. Their respective path-only phases are eta^gamma(w) and omega^gamma(w), proving (4) for every input.

At the last degree h, for each w in W route

    omega^gamma(w) eta^[-gamma(floor(w/2))]
        (q_L)_(floor(w/2))                               (5)

to coordinate w. The correct small-trajectory index is the **leading L bits**, floor(w/2). It agrees with the paired-row formula (1).

Add K_1 u_T by its r+2|A| original edges, negate the positive-degree outputs, and emit u_T at degree zero. This computes every coefficient of S(z)u_T exactly.

### Complete cost ledger

- Root powers, phase/gamma recurrences, zero-run masks, and coordinate membership tables: O(N) field/index operations and O(N) storage. Root existence/discovery is not hidden in this charge; omega is supplied.
- Read u_T, copy degree zero, and apply the direct retained edges: O(|T|).
- Small trajectories, tested routes, phase corrections, and scalar accumulations: O(rL).
- Emit at most O(|T|+rL) coefficient-coordinate-value records. No dense |T|-by-(L+2) rectangle is required. The records are produced by degree; within each degree the routes are injective, and any requested reordering is separately paid.

Total: **O(N+|T|+rL)=O(N+rL)** operations, including setup, in exact-field arithmetic with O(log N)-bit addressing. At the asymptotic marker choice r=O(N log n/n), this is **O(N log n)=O(N log log N)**. Streaming working storage is O(N+r); storing all output records additionally costs their O(|T|+rL) count. Equation (2) also gives an independent O(r log r) action for H alone, with its O(r) fold and O(a) duplicate writes paid.

This bound belongs to applying S(z) to one constant vector. An unknown retained solution y_T(z) is polynomial or a formal series, not such a vector. Reusing the constant routine independently on each of m0+1 polynomial coefficients gives only

    O(N+(m0+1)(|T|+rL))

after sharing preparation and charging shifts/additions. A causal inverse recurrence can use the same bound by applying K(z) to each newly determined y_j and accumulating its future contributions. At m0=n and the marker choice this displayed schedule is O(N n log n), rather than a sub-Nn full transform. It also charges reading/writing the supplied retained jet. Better convolution, shared inverse, fresh-source, and recovery schedules require additional arguments.

For arbitrary fresh x, the complete known O(Nn) full-state trajectory remains a paid reference for all source, solve, and output coefficients. The new constant-input circuit alone does not improve that complete task. Large fill-in and a cheap individual action coexist without contradiction.

## 5. Why the accepted endpoint lower bounds do not transplant

The [published endpoint review](https://github.com/AgentSlop-Si/research/blob/main/math/reviewed_rounds/2026-10-12-reviewed-research/sparse-endpoint-obstructions.md) treats a square d-by-d target M=R_e(I-D_e S_M)^(-1)C_e. Here S_M is one scalar cyclic predecessor, and the cost is nnz(C_e)+nnz(R_e), with no free dense transforms. The exact d^2 theorem also requires one read per output and all target entries and 2-by-2 minors nonzero. Its d^2+q masked-block theorem requires independently correct masked target-row contributions, not arbitrary mixing between reads.

The marker construction does not meet that interface:

1. **Branching.** At n=3,b=1 the free row 011 has incoming edges from both 001 and 101. In GF(17), omega=9 gives weights 9 and 8. A scalar weighted predecessor has at most one incoming nonzero in each row, a property preserved by permutations and nonzero diagonal gauges. Hence B is not such an operator in these coordinates or by these monomial relabelings. General basis changes or state splitting remain possible but require their own paid endpoint/representation proofs.
2. **Composite target.** For N=2^n>=4, Fourier rows 0,N/2 and columns 0,2 give a zero 2-by-2 minor. Row permutation/phases in Q^n do not repair it. The prime-Fourier specialization therefore does not apply. N=2 is a boundary with b=n and no eliminated block.
3. **The reduced coefficient is also outside the minor grammar.** H has zero A columns, is supported on a 2a-by-r rectangle, and contains explicit proportional row pairs. Even its active block fails the all-2-by-2-minors-nonzero premise. Calling its rank a or its retained dimension |T| the endpoint theorem's d is invalid.
4. **Read semantics are missing.** Schur recovery, coefficient convolution, and the shared Q_r trajectory are not independently correct masked contributions from one scalar cyclic Green state. They contain interacting stages and computed linear combinations. Each original input use, intermediate use, and output read must be translated and charged before a multi-read endpoint theorem is invoked.

The existing general mixed-read Omega(N log N/log log N) result is a separate baseline in its declared grammar. This pass does not strengthen it, re-prove it, or supply a legal single-Green representation to which it can be applied. Conversely, the constant-input action in Section 4 is a sparse multistage circuit and is not a counterexample to that baseline.

The precise sealed incompatibility is: **the marker horizon is a weighted branching-graph elimination fact; scalar-cycle endpoint counts are costs of a different explicitly restricted representation. Neither the horizon, retained size, nor Schur fill-in supplies the missing conversion.**

## 6. Primary-source overlap and provenance

The existing marker language is the reversal of the forbidden-word depathing construction of Zheng, Kingsford, and Marcais, [Definition 2 and Lemma 2](https://arxiv.org/html/2001.06550v1). The theorem counts vertices, so its n-b surviving vertices mean B^(n-b)=0. Their prescribed marker parameter is one larger than the source's asymptotic choice; the parameterized language proof is the pertinent comparison. No Fourier weights or cheap retained inverse are attributed to that paper.

[Boito and Eidelman, Section 2](https://arxiv.org/html/2308.02701v1#S2), state the classical band-inverse/Green-rank relation and quasiseparable representations. A nilpotent branching graph does not establish its constant-order band/Green hypotheses. The [De Sa et al. paper record](https://arxiv.org/abs/1611.01569) was checked for its structured matrix-vector framework; the current attempt to read its PMC body returned an access/checking page, and an arXiv HTML version failed. No fresh Appendix B body verification is claimed here.

This is a targeted overlap check, not an exhaustive historical search. The new statements are elementary, source-specific consequences of existing short-path phase and suffix-routing formulas. No worldwide novelty or priority conclusion is made.

Before the execution workspace was replaced, this task read the supplied ALG-068 review, its source-bound checker/provenance, the marker audit, triage, and relevant mathematical source sections as inert text. The recorded source hashes are:

- FREE_BOUNDARY_ESCAPE_CERTIFICATE.md: 0104d324f31e729377993add23c845f4f008363d9ac097293ea62be24ab015c8
- MARKED_CYCLE_AND_FIRST_SCHUR_AUDIT.md: aae67ad1f4d35278c8ed495658c6873f8ddce0c336ee25d299a93ae6004f895a
- EXACT_SOURCE_FORCED_RECOVERY_AND_FREE_TERM.md: 8457d31fac181ef49a81b349d011831422b0a34b28eb264e3c88ce4a583b79ed

The earlier directories were absent on resume. This packet relies on the recorded tool-result texts and source bindings, and does not claim to have newly rehashed those now-absent source bytes. The endpoint review was fetched again after resume and has GitHub blob SHA b2862c2be105712bb6313184d09620b4b062c6fe. No historical/downloaded executable was run, and no external file, research rank, or repository was changed.

## 7. Fresh controls and disposition

Run `python -I check_fusion.py > CONTROLS.json`. The checker is fresh, uses only the Python standard library, and reads no predecessor files. It compares direct weighted graph propagation against the independent compressed routes. Exact controls passed:

- 106 arbitrary constant-action cases in GF(17), GF(97), GF(257), and GF(65537), through n=9, with 26 empty-boundary cases.
- 2,175 all-basis constant-action vectors.
- 80 exact fill-in/disjoint-support cases, 19,464 highest-coefficient entry identities, 46 exact rank computations, and 240 nonzero scalar support checks.
- 258 full fresh-input basis vectors and 1,404 source/solve/recovery coefficient identities through degree n, including all b at n<=5.
- 396 word-count/bound cases, including independent enumeration where feasible.
- Explicit branching and composite-minor guards, an input-cancellation guard, and a negative control for the incorrect trailing-bit highest-coefficient formula.

Examples (all exact): n=4,b=1 gives r=8, 2 nonzero top rows, rank 1, 16 top nonzeros, and 32 total excursion entries. At n=6,b=2 these become r=16, 10 rows, rank 5, 160 top entries, and 192 total excursion entries. These finite controls support the proofs, not asymptotic performance or an all-size field construction.

**Research priority for this fusion: 56/100**, solely as a next-work recommendation. The exact monomial fill-in formula and paid constant-action compiler justify one independent review and establish a reusable interface. The decisive polynomial-input inverse and source/recovery costs remain untouched, so there is no basis for a high breakthrough score. After review, do not repeat the fill-in census or rebrand the marker set; only a new paid polynomial-sharing/inverse construction or a genuine model-matched endpoint conversion would advance the full problem. This recommendation does not change ALG-068's existing rank 48 or any external ranking.
