# Graded marker DAG: exact polynomial-input Schur action

13 October 2026 UTC. Candidate for independent review. This is a bounded continuation of the accepted marker-Schur object. It is not a new algorithm identity or a faster full Fourier transform.

## Result and disposition

The rightmost marker gives the free graph a **grading**, stronger than nilpotence. Every path from an R input to a given free state has the same length. Moreover, every R first return to a given retained destination has the same length, independently of its R source.

Consequently the Schur feedback on R factors as a constant spatial map followed by one delay per output row. The constant map has an O(N) topological DAG circuit. For an arbitrary explicitly supplied retained polynomial U(z) of degree at most d, the complete product S(z)U(z) can therefore be computed in

    O(N + N(d+1)) = O(N(d+1))

exact field/word operations, with all input, output, preprocessing, and coalescing charged under the sparse-row interval convention below. In particular, the complete constant-input polynomial action is O(N), sharpening the accepted O(N+rL) upper bound. This does not contradict that accepted bound; it supplies a better schedule.

This is **spatial sharing and delay factoring**, not an FFT speedup in the input degree. Repeating the new constant circuit on d+1 independent coefficients already attains the bound. No additional temporal batching gain is proved. The automatic causal inverse schedule now has O(N(m+1)) work to precision z^(m+1), which only matches the full-state O(Nm) reference at m=n. Fresh-source and recovery costs still cannot be discarded.

**Recommendation: 60/100 for independent review and one subsequent inverse/source gate.** This is a research recommendation only. Existing ALG-068 rank 48 is unchanged. No table, repository, or external rank is edited by this packet.

## 1. Domain, inputs, precision, and output convention

Let n>=1, N=2^n, and let K be any field containing a **supplied** element omega of exact order N. Thus char(K) is not 2. All arithmetic is exact; one field addition/subtraction/multiplication is charged as one field operation. Address arithmetic on O(log(N+d+2))-bit words is charged. No floating-point accuracy, coefficient bit complexity, field representation, or root discovery is included. Testing uses prime fields but the proof is field-independent under these assumptions.

Let 1<=b<n, L=n-b>=1, r=2^L, and h=L+1. Fixed-length n-bit words include leading zeros. With column vectors and destination rows,

    Q e_s = e_(2s mod N) + omega^s e_(2s+1 mod N).

Let R be the states ending in 0^b, A the n-bit states avoiding 0^b, T=R union A, and F its complement. R and A are disjoint, |R|=r, and B=Q_FF. Write Q_XY for the destination-X/source-Y block. The accepted Schur polynomial is

    S(z)=I-K(z),
    K(z)=z Q_TT + z^2 Q_TF (I-zB)^(-1) Q_FT,
    (I-zB)^(-1)=sum_(j=0)^(L-1) z^j B^j.

The input is U(z)=sum_(j=0)^d u_j z^j in K[z]^T, with **all |T|(d+1) coefficients explicitly supplied**. d is any nonnegative integer, including d much larger than N; leading coefficients may vanish. The required product has degree at most d+h. This is multiplication by S, not solving S Y=U.

The primary output is a complete coalesced scalar-coefficient representation by retained row. For each row y, store the union of the three integer intervals

    [0,d], [1,d+1], [tau(y),tau(y)+d].

The delay tau(y) is defined in Section 2. Intervals that overlap or touch are merged. Each listed coefficient is the actual sum, not an unevaluated contribution list. Entries outside these intervals are identically zero; zero entries inside may be retained or omitted after testing. The output contains at most 3|T|(d+1) scalar slots. Each row has at most three interval descriptors, sorted by degree, so lookup, accumulation, and serialization require constant indexing work per contribution/slot, with no general-purpose sorting or expected-time hash assumption.

If a dense |T|-by-(d+h+1) rectangle is demanded instead, charge an additional O(|T|(d+h+1)) writes and that much output storage. The O(N(d+1)) claim does not hide those requested zero writes. For an output jet modulo z^q, q>=0, clip the intervals to [0,q-1] and discard inputs of degree at least q when they are not required to be read; reading an explicitly delivered full input still costs |T|(d+1). The main theorem is for the full product and gives no unproved sublinear precision bound.

Boundary b=n is handled separately: F is empty, T is the whole state space, and S=I-zQ. The same O(N(d+1)) algorithm is just a sparse Q action per coefficient, with intervals [0,d+1]. It includes n=b=1. b=0, b>n, n=0, characteristic 2, and a root of insufficient order are outside this domain.

## 2. The grading and destination delay

Number bit positions from 0 at the left. For s in F let p(s) be the start of its rightmost 0^b. Since s contains a marker but does not end in one,

    0 <= p(s) <= L-1,    a(s)=L-p(s) in {1,...,L}.

The integer a(s) is its grade.

**Lemma 1 (free grading).** Every R-to-F edge lands in grade 1; every F-to-F edge increases grade by exactly one; A has no edge to F.

Proof. The sole free edge from R appends 1. The original suffix marker moves from start L to start L-1, remains the rightmost marker, and no new marker is created. A state in A either stays marker-free or creates a suffix marker and enters R. Along a free edge no new suffix marker can be created. The old rightmost marker therefore shifts left by one. If it had started at 0, it would disappear and the destination would be in A or R, not F. Hence a free-to-free edge has p(next)=p(s)-1 and a(next)=a(s)+1. This argument allows branching and overlapping markers.

Thus every R-to-s path whose internal states are free has exactly a(s) edges. Its path weights can be summed at s without losing a time-degree label. This equal-length property is stronger than B^L=0 and is what makes the improved action possible.

For any y in T, let p2(y) be the start of the second-rightmost marker if at least two markers occur (including overlaps). Define

    tau(y)=L-p2(y)  if a second marker exists,
    tau(y)=h       otherwise.

Some such rows are unreachable from R and their spatial output is zero; assigning them this harmless delay avoids a support-dependent output format.

**Lemma 2 (row-homogeneous R return).** Every direct R-to-T edge has tau(y)=1. Every F-to-T edge s->y satisfies tau(y)=a(s)+1.

Proof. The direct R edge appends 0, so the two rightmost marker starts are L and L-1. For a free exit, first suppose p(s)>=1. The old rightmost marker survives at p(s)-1. To be retained, y must acquire the new suffix marker at L; no marker occurs between the surviving old one and the new one. Thus p2(y)=p(s)-1 and tau(y)=L-p(s)+1. If p(s)=0, all old markers disappear on the shift and y has at most the newly formed suffix marker, giving tau(y)=h=a(s)+1.

This proves a uniform return length for **each destination row over all R sources**, not merely disjoint support for a fixed matrix entry. Direct A-to-T contributions still have degree 1, and may share rows with a delayed R contribution. They must remain separate.

As a counting check, grade t contains exactly

    |F_t| = 2^(L-t) a_b(t-1),    1<=t<=L,

where a_b(j) counts j-bit words avoiding 0^b. Such a word consists of an arbitrary prefix of length L-t, the rightmost marker, then 1 and t-1 marker-avoiding bits. Consequently sum_t |F_t|=|F| and |F|<=rL/2. The algorithm visits these actual states once, rather than scanning r small states at all L stages.

## 3. Exact delayed spatial factorization

Define the constant matrices

    C=Q_TA,
    M=Q_TR + Q_TF (I-B)^(-1) Q_FR,
    Delta(z)=diag_(y in T)(z^tau(y)).

The inverse (I-B)^(-1) exists because B is nilpotent. It is used here as a definition; the algorithm does not form it or M. Lemmas 1-2 show, row by row and for every input,

    K(z)U(z) = z C U_A(z) + Delta(z) M U_R(z),             (1)
    S(z)U(z) = U(z) - z C U_A(z) - Delta(z) M U_R(z).      (2)

The formula is valid even if S(1) is singular: only I-B is specialized and inverted. Weighted-path cancellations, including a zero M U_R for selected rows, do not affect the proof. This factorization does not assert that every row is active or that M has independent rows.

An equivalent internal identity is

    [z(I-zB)^(-1)Q_FR U_R(z)]_s
       = z^a(s) [(I-B)^(-1)Q_FR U_R(z)]_s.               (3)

Its right-hand polynomial has the same degree bound d as U. All edge recurrences become scalar-weight additions of these degree-d payloads after stripping the known grade delay.

## 4. Paid algorithm

Preprocess the supplied powers omega^s by recurrence. Build marker membership, rightmost and second-rightmost marker starts, and clipped trailing-zero lengths with a binary-prefix dynamic program. Fewer than 2N prefix nodes occur through length n. At each appended bit, update these quantities in constant word work; when a new suffix marker appears, shift the old rightmost to second-rightmost. Bucket F by grade and build retained coordinate maps. This is O(N) field/word work and O(N) storage, without repeated length-n string scanning or exponentiation per edge.

For a single constant retained coefficient u:

1. Zero free accumulators v_F and retained accumulators c_R,c_A.
2. For every R source s, add u_s along its retained zero-edge to c_R and omega^s u_s along its free one-edge to v_F.
3. For every A source s, add both weighted outgoing contributions to c_A. Both destinations are retained.
4. Visit the buckets F_1,...,F_L. At a free state s, propagate v_s over its two actual Q edges. Add to v_F at a free destination and to c_R at a retained destination.
5. Return c_R=M u_R and c_A=C u_A. Emit u at degree zero, -c_A at degree 1, and -c_R[y] at degree tau(y), coalescing any collisions.

All predecessors of a free state have already been processed at step 4. Dynamic programming sums exactly all weighted paths from R to that state, and then their first retained exits. Lemma 2 supplies their degree labels. Hence this algorithm proves (1)-(2).

Every one of the N original source states is processed once, with two edges. An unoptimized ledger performs **N multiplications by the precomputed odd-edge weights and 2N edge additions** per coefficient; multiplications by 1 could be omitted. Initialization, reading u, output signs, and coalescing add O(N+|T|) word/field work. Only O(N) working storage is needed for a scalar pass. This is an O(N) constant-input action for the complete polynomial, including its explicit scalar output records.

For U(z), run the pass for j=0,...,d, and add its three outputs to the preallocated merged row intervals at degrees j, j+1, and j+tau(y). Initialize and finally serialize the at-most 3|T|(d+1) output slots. The full paid work is

    O(N) setup
    + O(|T|(d+1)) input reads
    + O(N(d+1)) circuit/initialization work
    + O(|T|(d+1)) output initialization, coalescing and writes
    = O(N(d+1)).

The input may be streamed coefficient by coefficient. Working storage, excluding stored input and output, is O(N). Stored coalesced output adds O(|T|(d+1)); retaining the entire input adds the same amount. Equivalently one can propagate length-(d+1) payload arrays once through the graded DAG, using O(N(d+1)) storage. The coefficient-streaming version gives the smaller workspace guarantee.

The test implementation deliberately uses dictionaries and a dense comparison rectangle for clarity. It verifies mathematics and exact edge-operation counts, not a memory benchmark. The deterministic interval and bucket implementations just described establish the asymptotic indexing/storage bounds.

## 5. Comparison with the accepted schedule and classical methods

### Accepted coefficientwise action

Sharing its setup, the accepted small-Q_r evaluator costs

    O(N+(d+1)(|T|+rL)).

The new schedule costs O(N(d+1)). Since |F|<=rL/2, |T|+rL>=N, so the new bound is never asymptotically worse than this particular accepted ledger. It can be strictly better: at the asymptotic marker choice b=floor(log2(n/(4 ln n))), for sufficiently large n, rL=Theta(N ln n). The bound improves from O(N+(d+1)N log n) to O(N(d+1)), including O(N) for d=0. No small-|A| assumption is needed.

The gain is obtained before polynomial batching: the new scalar circuit already removes redundant trajectory scans. It would be inaccurate to claim that convolution has shared different arbitrary u_j for free.

### Classical forced recurrence

Without using grades one can run

    v_k = B v_(k-1) + Q_FT u_(k-1),
    [z^k]S U = u_k - Q_TT u_(k-1) - Q_TF v_(k-1).

A whole-state time sweep costs O(N(d+h)) through the last output. Grading strips each state's known delay, avoiding an L-step drain of identically shifted arrays. For this special boundary injection, the recurrence has no mixture of input times at a fixed retimed state. The result is a standard acyclic dynamic-programming/retiming phenomenon once the marker grading is proved, not a new general-purpose recurrence theory.

The primary paper [Leiserson and Saxe, Retiming Synchronous Circuitry, Section 3, equation (2) and Lemma 1](https://www.cs.columbia.edu/~cs6861/handouts/leiserson-algorithmica-88.pdf) formulates vertex lag changes and telescoping path delays. Its Section 2 uses topological processing of an acyclic subgraph. Those are classical structural precedents; the paper does not state this marker-Schur factorization or its field-arithmetic bound. The present proof derives those separately. No optimal-retiming theorem or circuit-clock bound is imported.

### Polynomial convolution and FFT

A dense scalar polynomial product uses convolution across many temporal taps. Here each entry of the R block is one monomial in z and every row has a common delay. After (1), the temporal operation is just a shift. Entrywise multiplication of an explicitly materialized M would still cost O(nnz(M)(d+1)); FFT does not erase that spatial work. The sparse DAG circuit avoids materializing M.

Classical evaluate/multiply/interpolate is correctly described in [Moreno Maza, Fast Convolution and Multiplication, Algorithm 2 and Theorem 2](https://www.csd.uwo.ca/~mmorenom/CS424/Lectures/FastMultiplication.html/node6.html): a sufficiently long transform and suitable primitive root support exact convolution. This source's root and product-degree conditions matter. Our input d is arbitrary; the supplied Nth root alone does not supply a transform root of every required length. Extensions, root construction, or alternative multiplication algorithms require their own costs.

For a directly paid comparison, if K supplies a primitive power-of-two mth root with m>d+h, time-variable evaluation/interpolation of all retained coordinates costs O(|T|m log m), and m scalar Schur actions by triangular propagation cost O(Nm). Thus this particular FFT wrapper costs O(Nm+|T|m log m). It does not automatically beat O(N(d+1)); for small d it needlessly evaluates at Omega(h) points. No lower bound against all possible batched spatial circuits is claimed.

For causal unknown series, [van der Hoeven, New algorithms for relaxed multiplication, Sections 1-3](https://www.texmacs.org/joris/newrelax/newrelax.html) explicitly distinguishes known-input products from relaxed/semi-relaxed schedules, and states extra root-of-unity assumptions for its FFT-based improvements. This distinction prevents taking an offline polynomial action and simply declaring the inverse solved at the same cost. The citation is an algorithmic comparison, not an assertion that scalar relaxed multiplication immediately solves this growing-dimensional matrix problem.

## 6. Inversion, source, and recovery boundary

Equation (2) is an action oracle. Inversion still requires finding a new unknown coefficient vector at each step. With f(z) supplied through degree m, the causal relation is

    y_(y,k) = f_(y,k)
              + [C y_(A,k-1)]_y
              + [M y_(R,k-tau(y))]_y,

with negative-index coefficients zero. Because the delay depends on the destination row, the final term is not generally one ordinary M action on a common input-time vector. A correct schedule scatters: once y_j is known, apply the scalar circuit once, schedule C y_(A,j) for time j+1, and schedule row y of M y_(R,j) for time j+tau(y). All delays are positive, so the computation is causal.

This supplies a straightforward O(N(m+1)) inverse-jet schedule, including its |T|(m+1) input/output cost. Streaming pending contributions can use a circular buffer of h+1 retained vectors, costing O(|T|h), plus O(N) circuit workspace; storing the full result costs O(|T|(m+1)). It is a valid improvement over the old O(Nm log n) invocation schedule in the stated marker regime, but at m=n it merely reaches O(Nn). It is not a sub-Nn full Fourier transform.

Fresh source uses x_F injected at every free grade, rather than only grade 1. Those injections have different delay origins, so a single scalar value per free state no longer records all polynomial source coefficients. Likewise recovery includes the independent term (I-zB)^(-1)x_F and must pay its requested precision/output. This packet does not claim a cheaper complete fresh-source/solve/recovery construction. The accepted all-input identity and full-state O(Nn) route remain the benchmark.

Nor can pointwise scalar inverses silently replace a truncated formal inverse: evaluation at mth roots computes modulo z^m-1, not modulo z^m. For example in GF(17), S(z)=1-2z and m=4 is nonsingular at all fourth roots. Its truncated inverse coefficients are (1,2,4,8), whereas its inverse modulo z^4-1 is (9,1,2,4). This exact negative control prevents aliasing from being mislabeled a Schur-jet solver.

The next worthwhile gate is a genuinely lower-cost retained inverse or a source/recovery schedule at the required full Fourier precision, with its representation and input/output obligations explicit. Repeating this action proof, its layer census, or the fill-in result is not further progress.

## 7. Fresh controls and provenance

The fresh standard-library program check_polynomial_action.py does not import, execute, or read predecessor research programs. Its independent reference uses the defining full time-domain block recurrence and string-defined marker sets. The candidate compiler uses binary-prefix metadata and grade buckets. A third, newly written implementation of the accepted mathematical Q_r routing equations checks the constant-input specialization. All tests passed and a second isolated run produced byte-identical JSON.

- 147 parameter cases over GF(3), GF(5), GF(17), GF(41), GF(97), GF(193), GF(257), GF(65537), through n=10 where the supplied root exists
- 39 b=n empty-free boundary cases
- 46,160 edge grading/destination-delay checks, including a large-degree guard's preprocessing
- 666 random polynomial-input cases and 600 input-coordinate/time-basis cases
- 904,780 exact output coefficient values compared
- 7,717 truncation-view comparisons
- 147 exact matches to the fresh accepted-formula implementation
- 3,676 R-basis row/degree matrix positions checked for the row delay condition
- 98 causal inverse-jet round trips, with multiplication and inversion kept as separate routines
- 108 equal-halves highest-coefficient kernel guards
- d=37 over GF(17) with N=16, where a sufficiently long radix-two time-transform root is unavailable in the base field
- The regular cyclic-inverse/truncated-inverse negative control above

The exact arithmetic operation counter records N odd-edge multiplications and 2N edge additions per input coefficient, before separately charged setup and output assembly. Tests validate finite instances and implementation correspondence; the proof establishes the arbitrary-field and all-size claim.

The source review and the included candidate REPORT.md were read as inert text. Their current local bytes are hashed in PROVENANCE.json. This packet does not authenticate absent older ALG-068 source archives or inherit their executable claims. No worldwide novelty, historical-priority claim, or numerical-stability result is made. The method is an elementary graded-DAG specialization with clear classical overlap.
