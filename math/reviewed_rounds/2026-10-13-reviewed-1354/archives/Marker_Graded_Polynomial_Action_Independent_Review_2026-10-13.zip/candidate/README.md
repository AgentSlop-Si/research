# Graded marker polynomial-action candidate

Start with REPORT.md. The full mathematical domain, output convention, proof, paid work/memory bounds, classical comparison, inverse boundary, and controls are there.

Run the fresh exact checker with:

    python -I check_polynomial_action.py

It reads no predecessor artifacts and uses only the Python standard library. Compare output with CONTROLS.json and REPLAY_CONTROLS.json. They are byte-identical. The checker is a correctness oracle, not an optimized runtime benchmark.

The sources/ directory preserves the unchanged accepted base review and the candidate definitions it reviewed, as inert text. PROVENANCE.json records their hashes and primary-source reading. MANIFEST.json binds the candidate payload members. This packet is a candidate pending independent review, not an accepted new theorem or faster full Fourier transform. Recommendation 60/100 only; existing ALG-068 rank 48 unchanged.
