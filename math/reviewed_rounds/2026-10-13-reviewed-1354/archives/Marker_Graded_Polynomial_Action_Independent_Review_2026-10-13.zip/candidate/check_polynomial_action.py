#!/usr/bin/env python3
"""Fresh exact controls, written 2026-10-13. Standard library only.
No predecessor programs or research artifacts are read, imported, or executed.
The optimized circuit is compared with independent time-domain block propagation.
"""
import hashlib
import json
import random

PRIMES=(3,5,17,41,97,193,257,65537)
RNG=random.Random(105220261013)
COUNTS={"parameter_cases":0,"empty_free_boundaries":0,"graded_edges":0,
        "random_polynomial_cases":0,"basis_polynomial_cases":0,
        "coefficient_values_compared":0,"truncations_compared":0,
        "compressed_constant_comparisons":0,"row_delay_matrix_entries":0,
        "inverse_jet_cases":0,"kernel_guards":0}
DIGEST=hashlib.sha256()


def root_for(p,n):
    N=1<<n
    if (p-1)%N: return None
    for g in range(2,p):
        w=pow(g,(p-1)//N,p)
        if pow(w,N,p)==1 and pow(w,N//2,p)!=1: return w
    raise AssertionError("No root found in a permitted prime field")


def compile_plan(n,b,p,w):
    assert n>=1 and 1<=b<=n
    N=1<<n; L=n-b; h=L+1
    # Prefix dynamic program, paying fewer than 2N nodes. Positions include leading zeros.
    # A node carries clipped trailing-zero length, rightmost and second-rightmost marker.
    nodes=[(0,-1,-1)]
    for length in range(1,n+1):
        next_nodes=[]
        for run,last,second in nodes:
            run0=min(b,run+1)
            next_nodes.append((run0,length-b,last) if run0==b else (run0,last,second))
            next_nodes.append((0,last,second))
        nodes=next_nodes
    R=[]; A=[]; F=[]; age={}; tau={}; buckets=[[] for _ in range(L+1)]
    for s,(run,last,second) in enumerate(nodes):
        if last==L: R.append(s)
        elif last==-1: A.append(s)
        else:
            F.append(s); age[s]=L-last; buckets[age[s]].append(s)
    T=sorted(R+A); inT=set(T); inF=set(F)
    if L:
        for y in T:
            second=nodes[y][2]
            tau[y]=L-second if second>=0 else h
    powers=[1]*N
    for s in range(1,N): powers[s]=powers[s-1]*w%p
    # Check every permitted edge against the compiled grading, including exit delays.
    for s in range(N):
        for bit in (0,1):
            y=(2*s+bit)%N
            if s in age:
                if y in inF: assert age[y]==age[s]+1
                else: assert tau[y]==age[s]+1
            elif s in R and L:
                if y in inF: assert age[y]==1
                else: assert tau[y]==1
            elif s in A:
                assert y in inT
            COUNTS["graded_edges"]+=1
    return dict(n=n,b=b,p=p,w=w,N=N,L=L,h=h,R=R,A=A,F=F,T=T,
                inT=inT,inF=inF,age=age,tau=tau,buckets=buckets,powers=powers)


def constant_circuit(P,u):
    p=P['p']; N=P['N']; L=P['L']; F=P['F']; T=P['T']; powers=P['powers']
    free={s:0 for s in F}; outR={s:0 for s in T}; outA={s:0 for s in T}
    multiplies=0; additions=0
    if not L:
        direct={s:0 for s in T}
        for s in T:
            v=u[s]
            direct[2*s%N]=(direct[2*s%N]+v)%p
            direct[(2*s+1)%N]=(direct[(2*s+1)%N]+powers[s]*v)%p
            multiplies+=1; additions+=2
        return direct,outA,multiplies,additions
    for s in P['R']:
        y0=2*s%N; y1=(2*s+1)%N
        outR[y0]=(outR[y0]+u[s])%p
        free[y1]=(free[y1]+powers[s]*u[s])%p
        multiplies+=1; additions+=2
    for s in P['A']:
        outA[2*s%N]=(outA[2*s%N]+u[s])%p
        outA[(2*s+1)%N]=(outA[(2*s+1)%N]+powers[s]*u[s])%p
        multiplies+=1; additions+=2
    for k in range(1,L+1):
        for s in P['buckets'][k]:
            for bit in (0,1):
                y=(2*s+bit)%N; v=free[s]*(powers[s] if bit else 1)%p
                target=free if y in P['inF'] else outR
                target[y]=(target[y]+v)%p
            multiplies+=1; additions+=2
    assert multiplies==N and additions==2*N
    return outR,outA,multiplies,additions


def polynomial_circuit(P,U):
    d=len(U)-1; p=P['p']; T=P['T']; h=P['h']
    # Oracle-friendly dictionary realizes the stated sparse-row interval convention.
    # The report supplies a deterministic O(1)-address merged-interval implementation.
    Y={y:{} for y in T}
    for y in T:
        tau=P['tau'][y] if P['L'] else 1
        for k in set(range(d+1))|set(range(1,d+2))|set(range(tau,tau+d+1)):
            Y[y][k]=0
        assert len(Y[y])<=3*(d+1)
    ops=[0,0]
    for j,u in enumerate(U):
        r,a,m,adds=constant_circuit(P,u); ops[0]+=m; ops[1]+=adds
        for y in T:
            tau=P['tau'][y] if P['L'] else 1
            Y[y][j]=(Y[y][j]+u[y])%p
            Y[y][j+1]=(Y[y][j+1]-a[y])%p
            Y[y][j+tau]=(Y[y][j+tau]-r[y])%p
    assert ops==[P['N']*(d+1),2*P['N']*(d+1)]
    return [[Y[y].get(k,0) for y in T] for k in range(d+h+1)],ops


def independent_reference(n,b,p,w,U):
    N=1<<n; L=n-b; h=L+1; marker='0'*b
    R={s for s in range(N) if f'{s:0{n}b}'.endswith(marker)}
    A={s for s in range(N) if marker not in f'{s:0{n}b}'}
    T=sorted(R|A); inT=set(T); F=set(range(N))-inT
    assert set(U[0])==inT
    d=len(U)-1; free={s:0 for s in F}; result=[]
    # Full forced recurrence: v_k = B v_(k-1) + Q_FT u_(k-1).
    # y_k = u_k - Q_TT u_(k-1) - Q_TF v_(k-1).
    for k in range(d+h+1):
        y={s:U[k][s] if k<=d else 0 for s in T}
        next_free={s:0 for s in F}
        if k:
            for s in range(N):
                value=U[k-1][s] if s in inT and k-1<=d else free.get(s,0)
                for bit in (0,1):
                    dest=(2*s+bit)%N
                    value_edge=value*(pow(w,s,p) if bit else 1)%p
                    if dest in inT: y[dest]=(y[dest]-value_edge)%p
                    else: next_free[dest]=(next_free[dest]+value_edge)%p
        result.append([y[s] for s in T]); free=next_free
    assert all(v==0 for v in free.values())
    return result


def qstep(q,p,w):
    r=len(q); out=[0]*r
    for j,x in enumerate(q):
        out[2*j%r]=(out[2*j%r]+x)%p
        out[(2*j+1)%r]=(out[(2*j+1)%r]+pow(w,j,p)*x)%p
    return out


def gamma(a):
    if not a: return 0
    return gamma(a//2)+(a//2 if a%2 else 0)


def accepted_formula_reimplementation(P,u):
    # Written from accepted mathematical equations, not copied from historical checker code.
    N=P['N']; n=P['n']; b=P['b']; L=P['L']; p=P['p']; w=P['w']; h=P['h']
    T=P['T']; out=[[0]*len(T) for _ in range(h+1)]; idx={s:i for i,s in enumerate(T)}
    out[0]=[u[s] for s in T]
    for s in T:
        for bit in (0,1):
            y=(2*s+bit)%N
            if y in idx: out[1][idx[y]]=(out[1][idx[y]]-u[s]*(pow(w,s,p) if bit else 1))%p
    if not L: return out
    r=1<<L; eta=pow(w,1<<b,p); q=[u[(1<<b)*j] for j in range(r)]
    for t in range(1,L+1):
        q=qstep(q,p,eta)
        if t>=2:
            for a0 in range(r):
                v=a0%(1<<t); bits=f'{v:0{t}b}'
                if bits[0]=='1' and t>=b+1 and bits.find('0'*b)==t-b:
                    y=(1<<b)*(a0-v)+v
                    phase=pow(w*pow(eta,-1,p)%p,gamma(v),p)
                    out[t][idx[y]]=(out[t][idx[y]]-phase*q[a0])%p
    for v in range(1<<(L-1)):
        if '0'*b in (f'{v:0{L-1}b}' if L>1 else ''): continue
        for bit in (0,1):
            y=r+2*v+bit; lead=y//2
            phase=pow(w,gamma(y),p)*pow(eta,-gamma(lead),p)%p
            out[h][idx[y]]=(out[h][idx[y]]-phase*q[lead])%p
    return out


def compare(P,U,kind,compressed=False):
    Y,ops=polynomial_circuit(P,U)
    Z=independent_reference(P['n'],P['b'],P['p'],P['w'],U)
    assert Y==Z,(P['n'],P['b'],P['p'],len(U)-1,kind)
    COUNTS[kind]+=1; COUNTS['coefficient_values_compared']+=sum(map(len,Y))
    for q in sorted(set((0,1,P['h'],len(U),len(Y)-1,len(Y),len(Y)+2))):
        assert Y[:q]==Z[:q]
        COUNTS['truncations_compared']+=1
    if compressed:
        assert len(U)==1
        assert Y==accepted_formula_reimplementation(P,U[0])
        COUNTS['compressed_constant_comparisons']+=1
    DIGEST.update(json.dumps([P['n'],P['b'],P['p'],Y],separators=(',',':')).encode())


def solve_jet(P,source):
    # Separate optional boundary control: a causal inverse uses a fresh constant action per step.
    # This is not polynomial multiplication substituted for inversion.
    m=len(source)-1; T=P['T']; p=P['p']
    future=[{y:0 for y in T} for _ in range(m+1)]; sol=[]
    for j,f in enumerate(source):
        u={y:(f[y]+future[j][y])%p for y in T}; sol.append(u)
        r,a,_,_=constant_circuit(P,u)
        for y in T:
            tau=P['tau'][y] if P['L'] else 1
            if j+1<=m: future[j+1][y]=(future[j+1][y]+a[y])%p
            if j+tau<=m: future[j+tau][y]=(future[j+tau][y]+r[y])%p
    back,_=polynomial_circuit(P,sol)
    assert back[:m+1]==[[f[y] for y in T] for f in source]
    COUNTS['inverse_jet_cases']+=1


def main():
    for p in PRIMES:
        for n in range(1,11):
            w=root_for(p,n)
            if w is None: continue
            for b in range(1,n+1):
                P=compile_plan(n,b,p,w); T=P['T']; COUNTS['parameter_cases']+=1
                if b==n: COUNTS['empty_free_boundaries']+=1
                for d in sorted(set((0,1,P['L'],P['L']+2,2*P['L']+3))):
                    U=[{s:RNG.randrange(p) for s in T} for _ in range(d+1)]
                    compare(P,U,'random_polynomial_cases',compressed=(d==0))
                # All input-coordinate/time monomials for n<=5 in selected exact fields.
                if n<=5 and p in (5,17,97):
                    for s in T:
                        for j in (0,2):
                            U=[{y:0 for y in T} for _ in range(4)]
                            U[j][s]=1
                            compare(P,U,'basis_polynomial_cases')
                # Check actual matrix row delays independently by all R basis columns.
                if n<=6 and P['L'] and p in (17,97):
                    for s in P['R']:
                        u={y:int(y==s) for y in T}
                        Z=independent_reference(n,b,p,w,[u])
                        for k in range(1,P['h']+1):
                            for i,y in enumerate(T):
                                if Z[k][i]: assert k==P['tau'][y]
                                COUNTS['row_delay_matrix_entries']+=1
                if n<=6:
                    solve_jet(P,[{s:RNG.randrange(p) for s in T} for _ in range(n+3)])
                if P['L']:
                    # Highest R-feedback coefficient vanishes for equal halves, despite nonzero entries.
                    u={y:0 for y in T}; r=1<<P['L']; half=[RNG.randrange(p) for _ in range(r//2)]
                    if not any(half): half[0]=1
                    for j in range(r): u[j*(1<<b)]=half[j%(r//2)]
                    Y,_=polynomial_circuit(P,[u]); assert not any(Y[P['h']])
                    COUNTS['kernel_guards']+=1
    # A degree beyond any sufficient transform root available in GF(17).
    P=compile_plan(4,2,17,root_for(17,4))
    compare(P,[{s:RNG.randrange(17) for s in P['T']} for _ in range(38)],'random_polynomial_cases')
    # Time evaluation does not supply a truncated inverse: a regular cyclic inverse aliases coefficients.
    p=17; a=2; m=4; den=(1-pow(a,m,p))%p; assert den
    truncated=[pow(a,j,p) for j in range(m)]
    cyclic=[v*pow(den,-1,p)%p for v in truncated]
    assert cyclic!=truncated
    print(json.dumps({'status':'PASS','counts':COUNTS,'deterministic_output_sha256':DIGEST.hexdigest(),
      'field_primes':PRIMES,'largest_n':10,'large_degree_guard':37,
      'operation_ledger':'Exactly N constant multiplications and 2N edge additions per input coefficient; output assembly and preprocessing separately paid.',
      'negative_controls':{'cyclic_inverse_is_not_truncated_inverse':{'field':17,'a':2,'m':4,'truncated':truncated,'cyclic':cyclic}},
      'historical_code_executed':False},indent=2,sort_keys=True))

if __name__=='__main__': main()
