#!/usr/bin/env python3
"""Additional independent row-delay, interval-layout and precision controls."""
from collections import defaultdict
import json, random
RNG=random.Random(1101)
C=defaultdict(int)

def plan(n,b,p):
 N=2**n;L=n-b
 w=next(w for w in range(2,p) if pow(w,N,p)==1 and pow(w,N//2,p)!=1)
 marks={s:[i for i in range(n-b+1) if format(s,f'0{n}b')[i:i+b]=='0'*b] for s in range(N)}
 R={s for s in range(N) if marks[s] and marks[s][-1]==L}
 A={s for s in range(N) if not marks[s]};T=R|A;F=set(range(N))-T
 age={s:L-marks[s][-1] for s in F}
 tau={s:(L-marks[s][-2] if len(marks[s])>=2 else L+1) for s in T}
 if L==0:tau={s:1 for s in T}
 edges={s:[(2*s%N,1),((2*s+1)%N,pow(w,s,p))] for s in range(N)}
 # Prefix metadata recurrence includes overlaps and leading zeros.
 meta=[(0,-1,-1)]
 for k in range(1,n+1):
  new=[]
  for run,last,second in meta:
   r=min(run+1,b)
   new += [(r,k-b,last) if r==b else (r,last,second),(0,last,second)]
  meta=new
 for s in range(N):
  last=marks[s][-1] if marks[s] else -1
  second=marks[s][-2] if len(marks[s])>1 else -1
  assert meta[s][1:]==(last,second);C['second_marker_metadata_states']+=1
 for s in range(N):
  for v,_ in edges[s]:
   if s in F:assert (age[v]==age[s]+1) if v in F else (tau[v]==age[s]+1)
   if s in R and L:assert (age[v]==1) if v in F else (tau[v]==1)
   if s in A:assert v in T
   C['row_delay_edges']+=1
 for t in range(1,L+1):
  avoid=sum('0'*b not in format(v,f'0{t-1}b') for v in range(2**(t-1))) if t>1 else 1
  assert sum(x==t for x in age.values())==2**(L-t)*avoid
  C['grade_census_checks']+=1
 return N,R,A,T,F,age,tau,edges

def oracle(P,U,p):
 N,R,A,T,F,age,tau,edges=P;d=len(next(iter(U.values())))-1;h=max(tau.values())
 free={s:0 for s in F};result={s:[0]*(d+h+1) for s in T}
 for k in range(d+h+1):
  nf={s:0 for s in F}
  for s in T:result[s][k]=U[s][k] if k<=d else 0
  if k:
   for s in range(N):
    x=free[s] if s in F else (U[s][k-1] if k-1<=d else 0)
    for v,w in edges[s]:
     if v in T:result[v][k]=(result[v][k]-w*x)%p
     else:nf[v]=(nf[v]+w*x)%p
  free=nf
 return result

def row_delayed(P,U,p):
 N,R,A,T,F,age,tau,edges=P;d=len(next(iter(U.values())))-1
 # Real deterministic array-of-merged-intervals output, with coalescing.
 out={};slots=0
 for s in T:
  intervals=[]
  for lo,hi in sorted([(0,d),(1,d+1),(tau[s],tau[s]+d)]):
   if intervals and lo<=intervals[-1][1]+1:intervals[-1][1]=max(intervals[-1][1],hi)
   else:intervals.append([lo,hi])
  out[s]=[(lo,[0]*(hi-lo+1)) for lo,hi in intervals]
  slots+=sum(len(a) for lo,a in out[s])
 assert slots<=3*len(T)*(d+1)
 def add(s,k,x):
  for lo,a in out[s]:
   if lo<=k<lo+len(a):a[k-lo]=(a[k-lo]+x)%p;return
  raise AssertionError('Unrepresented contribution')
 for j in range(d+1):
  free={s:0 for s in F};mr={s:0 for s in T};ca={s:0 for s in T}
  for s in T:
   for v,w in edges[s]:
    target=free if v in F else (mr if s in R else ca)
    target[v]=(target[v]+w*U[s][j])%p
  for s in sorted(F,key=lambda s:age[s]):
   for v,w in edges[s]:
    target=free if v in F else mr
    target[v]=(target[v]+w*free[s])%p
  for s in T:
   add(s,j,U[s][j]);add(s,j+1,-ca[s]);add(s,j+tau[s],-mr[s])
 result={s:[0]*(d+max(tau.values())+1) for s in T}
 for s in T:
  for lo,a in out[s]:result[s][lo:lo+len(a)]=a
 return result,slots

for p,nmax in [(3,1),(5,2),(17,4),(41,3),(97,5),(193,6),(257,8),(65537,10)]:
 for n in range(1,nmax+1):
  for b in range(1,n+1):
   P=plan(n,b,p);N,R,A,T,F,age,tau,edges=P
   C['parameter_cases']+=1
   for d in [0,2,7]+([37] if N<=16 else []):
    U={s:[RNG.randrange(p) for j in range(d+1)] for s in T}
    row,slots=row_delayed(P,U,p);ref=oracle(P,U,p)
    assert row==ref;C['row_interval_vectors']+=1;C['row_interval_coefficients']+=slots
    for q in [0,1,d+1,d+max(tau.values())+1]:
     assert {s:v[:q] for s,v in row.items()}=={s:v[:q] for s,v in ref.items()}
     C['precision_views']+=1
   if n<=5:
    for src in R:
     U={s:[int(s==src)] for s in T};ref=oracle(P,U,p)
     for y in T:
      for k,v in enumerate(ref[y]):
       # Remove the degree zero identity before examining K.
       if k==0:continue
       assert not v or k==tau[y]
       C['basis_row_degree_entries']+=1
# A direct cyclic-versus-truncated inverse check, both multiplied in their own rings.
a=2;p=17;m=4
truncated=[pow(a,j,p) for j in range(m)]
cyclic=[x*pow(1-pow(a,m,p),-1,p)%p for x in truncated]
assert truncated==[1,2,4,8] and cyclic==[9,1,2,4]
assert [(truncated[j]-a*(truncated[j-1] if j else 0))%p for j in range(m)]==[1,0,0,0]
assert [(cyclic[j]-a*cyclic[(j-1)%m])%p for j in range(m)]==[1,0,0,0]
assert all((1-a*z)%p for z in range(p) if pow(z,m,p)==1)
print(json.dumps({'status':'PASS','counts':dict(sorted(C.items())),'cyclic_inverse_guard':{'p':p,'truncated':truncated,'cyclic':cyclic,'all_fourth_root_specializations_nonsingular':True}},indent=2,sort_keys=True))
