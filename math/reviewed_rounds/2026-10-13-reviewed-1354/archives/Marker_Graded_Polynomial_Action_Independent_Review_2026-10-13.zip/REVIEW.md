# Independent review of graded marker polynomial action

Reviewed 13 October 2026 UTC. Verdict: **scoped ACCEPT**. No substantive mathematical repair of the frozen candidate is required.

The complete constant-input Schur polynomial action is O(N), and the complete degree-d retained polynomial action is O(N(d+1)), with the candidate's explicit coalesced row-interval output. The separate causal inverse-jet schedule is valid and costs O(N(m+1)) through degree m. It is a genuine solve, but at m=n it only matches the O(Nn) full-state reference. No faster complete Fourier transform, worldwide novelty, scalar-cycle reduction, or external rank change is accepted.

The advance is a sharper schedule for the existing marker-Schur object: grading permits a common delay to be removed from each free state, and a second-marker label gives a common return delay for each retained output row. The new result does not contradict the earlier accepted O(N+rL) constant-action upper bound. It improves that particular ledger.

## 1 Reviewed bytes and independence

This review binds to the following frozen candidate supplied by its author:

- Archive: Marker_Graded_Polynomial_Action_Candidate_2026-10-13.zip
- Archive size: 34,146 bytes
- Archive SHA-256: 4ae498624a446560268509f8609f403cdbd433a6b77253f0df8f71157f634211
- Candidate REPORT.md SHA-256: c9b7e1c93c4660bb023f9f57a0370f467df76479224605773f6d8c905d4c1aa5

All eight manifest-listed members were independently rehashed and size-checked. All nine ZIP members, including the manifest, were compared byte for byte to the extracted copy. The unchanged candidate ZIP and its extracted contents are included in this review packet.

The accepted predecessor review was read before the novelty judgment. Its SHA-256 is a52eb59cc26509ec53eb3deaefe395df1a9c860215141aac347f7b2b08fd311c. The supplied predecessor review archive, SHA-256 ebfc076ad0b4e73afce42fbfd3aeaf29f18131947c4efbfa6fa0f3a6a268e4ee, is included unchanged; its REVIEW.md was checked against the current predecessor text. No unavailable older source is newly authenticated here.

No candidate, predecessor, downloaded, or historical research program was executed or imported. The initial independent control program was written and run before the frozen candidate's program was inspected. A second independent control program checks the stronger row-delay claim and actually assembles merged-interval arrays. The candidate program was later read as inert text to determine what its inverse test establishes. Both review programs were independently replayed with byte-identical result files.

## 2 Definitions and domain

Let n>=1, N=2^n, and let K be a field with a supplied element omega of exact order N. For column vectors, Q has destination rows and acts by

    Q e_s = e_(2s mod N) + omega^s e_(2s+1 mod N).

Thus a transition shifts an n-bit word left and appends its new bit on the right. All words are fixed length n, including leading zeros. This convention is essential: bit positions below are counted from zero at the left. It must not be silently replaced by a least-significant-first convention or a transposed matrix.

For 1<=b<n, let L=n-b and h=L+1. Let R contain words ending in 0^b, A contain words avoiding 0^b, T=R union A, and F be the complement. R and A are disjoint. Put B=Q_FF. With destination/source block order, the Schur polynomial is

    S(z)=I-K(z),
    K(z)=z Q_TT + z^2 Q_TF (I-zB)^(-1) Q_FT.

A free path has fewer than L free edges, so B^L=0 and the displayed inverse is a polynomial. The stronger graded proof below independently establishes that fact.

The input U(z)=sum_(j=0)^d u_j z^j supplies all |T|(d+1) coefficients explicitly. d may be any nonnegative integer, including d>N. The action returns the full product through degree at most d+h. The cost model counts exact field operations and address operations on O(log(N+d+2))-bit words. Root discovery, coefficient bit complexity, numerical conditioning, and floating-point error are outside the theorem. Exact order N implies that the field's characteristic is not 2. The proof itself uses the graph structure and linearity, not a prime-field-only identity.

For b=n, the only word containing 0^n is the all-zero word, which lies in R; every other word lies in A. Hence F is empty, T is the full state space, and S=I-zQ. This boundary is handled directly and includes n=b=1. The excluded cases b=0, b>n, n=0, characteristic 2, and insufficient-order roots need no extrapolated conclusion.

## 3 Independent proof of the grading

For s in F, let p(s) be the rightmost start of a marker 0^b and define

    a(s)=L-p(s).

Because s contains a marker but has no suffix marker, 0<=p(s)<=L-1, so 1<=a(s)<=L.

An A state cannot enter F. If its shift makes a marker, that new marker is a suffix and the destination is R; otherwise it remains A. From R, appending zero stays in R. Appending one shifts the old suffix marker from start L to start L-1 and creates no new marker, so the free destination has grade one. This uses b<n; the empty-free boundary is separate.

Now consider a free-to-free edge. Every surviving old marker shifts left by one. The only possible newly created marker is the length-b suffix; creating it would retain the destination, which is excluded. If the old rightmost marker started at zero, it would disappear and leave no marker at all, also a retained destination. Therefore an actual free-to-free edge satisfies

    p(next)=p(s)-1,
    a(next)=a(s)+1.

Overlapping markers cause no exception: they all move in the same way, and only one new length-b window is introduced by a shift. Thus every first-entry path from R to a given free state s has exactly a(s) edges. In particular, no L-edge path lies entirely in F, so B^L=0.

The grade census is also correct. A grade-t state consists of an arbitrary prefix of length L-t, then its rightmost 0^b, then one bit 1, then a (t-1)-bit marker-avoiding word. If a_b(j) counts the latter language, including a_b(0)=1, then

    |F_t|=2^(L-t) a_b(t-1),
    sum_(t=1)^L |F_t|=|F|,
    |F_t|<=2^(L-1)=r/2,
    |F|<=rL/2,

where r=2^L. The census is a check and a comparison with the old ledger; the new circuit's O(N) work does not depend on a small retained-set estimate.

## 4 Independent proof of the common output delay

The candidate's additional row claim is stronger than saying each individual matrix entry appears at only one degree. For a retained word y, let p2(y) be its second-rightmost marker start, counting overlapping occurrences separately, and set

    tau(y)=L-p2(y) if p2(y) exists,
    tau(y)=h otherwise.

For a direct R-to-T edge, a zero is appended to a word already ending in 0^b. The destination has markers starting at L and L-1, so tau=1.

For a free exit s->y with p(s)>=1, the old rightmost marker survives at p(s)-1. Retention cannot then be caused by becoming marker-free, so the new suffix marker at L must be created. No marker lies between the surviving old rightmost marker and that new marker. Hence p2(y)=p(s)-1 and

    tau(y)=L-p(s)+1=a(s)+1.

If p(s)=0, that rightmost old marker disappears and no old marker survives. The destination has either no marker or just the new suffix marker, so tau=h=a(s)+1 again. Every first return from R to a fixed y therefore has exactly tau(y) edges, independently of its R source. Unreachable rows may be assigned their stated delay without affecting the zero output.

A-source direct contributions always have degree one and must be kept separately: their row may coincide with an R contribution having a different delay. This distinction is observed by the candidate.

## 5 Weighted factorization and cancellations

Define constant spatial maps

    C=Q_TA,
    M=Q_TR + Q_TF (I-B)^(-1) Q_FR,
    Delta(z)=diag_(y in T)(z^tau(y)).

Neither inverse nor M is to be explicitly materialized. The path-length facts imply the exact polynomial identity

    K(z)U(z)=z C U_A(z)+Delta(z) M U_R(z),
    S(z)U(z)=U(z)-z C U_A(z)-Delta(z) M U_R(z).

Internally, for every free s,

    [z(I-zB)^(-1)Q_FR U_R(z)]_s
      = z^a(s) [(I-B)^(-1)Q_FR U_R(z)]_s.

Each weighted path to s has the same factor z^a(s), so it may be removed before summing its scalar weights. Likewise every R-return path to y has the same factor z^tau(y). Any cancellation among those scalar weights is preserved exactly. The statements do not require nonzero outputs, independent rows, or generic inputs.

For example, take n=3, b=1, K=GF(17), omega=2. The nonzero retained input u_0=u_4=1 has two contributions to free state 001: 1 and omega^4=-1. Their sum is zero. This is fully compatible with the homogeneous grade-one representation; zero is allowed.

Only I-B is specialized at z=1 to define the spatial map. It is invertible because B is nilpotent. No invertibility of S(1), or of S at any nonzero scalar, is required by the action theorem. The zero specialization gives S(0)U(0)=U(0) as expected.

## 6 Full work and storage proof

### Preparation

Generate omega^s for 0<=s<N by recurrence using N-1 field multiplications. A binary-prefix dynamic program tracks a clipped trailing-zero run, rightmost marker start, and second-rightmost marker start. Appending a zero creates exactly one new suffix marker once the run reaches b; the previous rightmost start becomes the second-rightmost. Appending a one resets the zero-run and preserves both marker starts. Fewer than 2N nonempty prefixes are visited through length n, so the membership and marker metadata cost O(N) word operations.

Enumerate all final states, form retained coordinate maps, and bucket free states by a(s). There are L<=n<=N buckets. No comparison sort, repeated n-bit scan, or independent exponentiation at each edge is necessary. Preparation and its storage are O(N).

### One constant coefficient

Zero scalar arrays for free states and for the two retained accumulators c_R and c_A. Read u. Send the R zero-edge to c_R and the R one-edge to the corresponding free accumulator. Send both A edges to c_A. Then process F in increasing grade, propagating each accumulator along its two actual Q edges. A free target has strictly greater grade, so every contribution arrives before that target is processed. A retained target receives its first-return contribution in c_R.

Induction in grade shows that each free accumulator is the sum of all weighted paths from R to that state. Consequently c_R=M u_R and c_A=C u_A. Each of the N source states is processed once and has exactly two outgoing edges. The algebraic graph ledger is N odd-edge weight multiplications and 2N additions; additions, input copying, zeroing, and signs outside that ledger cost O(N+|T|). A literal program may waste multiplications by one; that remains O(N), and the optimized scalar schedule omits them. The report's exact edge ledger describes the mathematical schedule rather than every Python operation in its oracle.

Emit u at degree zero, -c_A at degree one, and -c_R[y] at degree tau(y). Equal degree/row coordinates are actually summed. There are O(|T|) scalar output slots, so the full constant-input polynomial action costs O(N), including setup and output. This is not merely evaluating the polynomial at one z.

### Degree d and coalesced output

For each retained row y, reserve the union of

    [0,d], [1,d+1], [tau(y),tau(y)+d].

Only three interval descriptors need examination; in fact the first two already touch. Sort and merge this constant-size list, assign offsets to its merged intervals, and allocate only the represented scalar slots. The total length is at most 3|T|(d+1). Any of the three scheduled contributions locates its slot with at most a constant number of comparisons and additions. This supplies deterministic constant-time addressing without a hash table or a general sorting assumption.

Run the scalar circuit for j=0,...,d. Add u_j to degree j, -c_A to degree j+1, and -c_R[y] to degree j+tau(y). Initialize and serialize all reserved output slots; those are actual coefficients, including any retained zeros, not unevaluated lists of contributions. The total cost is

    O(N) setup
      + O(|T|(d+1)) input reads
      + O(N(d+1)) scalar passes and resets
      + O(|T|(d+1)) output initialization, coalescing and serialization
      = O(N(d+1)).

Coefficient streaming uses O(N) working storage besides input/output. Stored input and output each cost O(|T|(d+1)); a payload-array version uses O(N(d+1)) workspace instead. If a dense |T|-by-(d+h+1) rectangle is requested, its additional writes and storage must be charged. The sparse-row result does not give those zero writes for free. Similarly, clipping to a jet cannot retroactively avoid reading explicitly delivered input that the interface requires to be read.

This improves the old coefficientwise bound O(N+(d+1)(|T|+rL)). The census implies |T|+rL>=N. At b=floor(log2(n/(4 ln n))) for sufficiently large n, rL=Theta(N ln n), so the old schedule has an additional log n factor. The new gain comes from the constant spatial circuit. It does not compress d+1 arbitrary independent input coefficient vectors into one field operation.

## 7 What the inverse test establishes

Because S(0)=I, the equation S(z)Y(z)=f(z) has a unique formal solution. For k>=0 its row recurrence is

    y_(y,k)=f_(y,k)
      + [C y_(A,k-1)]_y
      + [M y_(R,k-tau(y))]_y,

with negative times zero. The varying row delay prevents interpreting the final term as one M multiplication on one common input-time vector. The valid implementation uses a scatter schedule: once y_j is known, compute C y_(A,j) and M y_(R,j), then add each contribution to its positive future time.

Induction on j proves this algorithm solves for new coefficients rather than testing a preselected solution. One scalar circuit per j and O(|T|) scheduled row additions give O(N(m+1)) time through degree m. Input, output, and pending storage can be represented by full length-(m+1) retained arrays and cost O(|T|(m+1)), with O(N) circuit workspace. A streaming pending ring may use min(h,m)+1 retained slots; clipping its size to the requested horizon keeps initialization within the bound even when m is much smaller than h. The candidate's optional h+1 ring should be understood with that ordinary truncation, or replaced by the full m+1 array used in its checker.

The candidate's solve_jet routine was inspected as text. It constructs each new coefficient from the supplied source and accumulated previous feedback, then verifies S Y=f modulo z^(m+1). Thus it is a real causal inverse-jet control, not merely a truncated action test. The test alone cannot prove an asymptotic claim; the recurrence and ledger above do. The independent review additionally compares its own causal solve against the full N-state forced recurrence, avoiding reliance on one action routine for both generation and verification.

There is no sub-Nn consequence at Fourier precision m=n. The full-state recurrence already computes the relevant trajectory in O(Nn). The new inverse schedule removes the former extra logarithmic invocation overhead and reaches that benchmark. It does not establish a faster complete transform.

Pointwise inverse sampling is also distinct from formal inversion. In GF(17), for S(z)=1-2z and m=4, the truncated inverse is (1,2,4,8), while the inverse modulo z^4-1 is (9,1,2,4). Both multiply to one in their own quotient rings, and every fourth-root scalar specialization is nonsingular. Hence even nonsingular cyclic evaluation cannot be mislabeled a truncated inverse.

## 8 Arbitrary fresh source and Fourier boundary

For an arbitrary fresh full-state source x, free recovery contains

    (I-zB)^(-1)x_F,

and the retained forced source contains

    x_T + z Q_TF (I-zB)^(-1)x_F.

The independent x_F terms enter at many grades. Their delay origins differ, so the one-payload-per-free-state representation proved for R injection does not carry over. For n=3, b=1, GF(17), omega=2, choose x_F=e_001+e_011. Then the 011 coordinate of (I-zB)^(-1)x_F is 1+2z. That coordinate has grade two but is not one grade-two monomial. This explicit example prevents extending the R-injection homogeneity claim to general free sources.

The example is a limitation of that particular compression, not a lower bound against every possible source algorithm. The candidate correctly leaves a cheaper complete source/solve/recovery construction open. The independent tests include arbitrary fresh sources, construct the forced retained source, solve the jet, and recover all free coordinates against a full-state reference.

To check the Fourier convention independently, a path with appended n-bit word v has weight

    omega^[s rev_n(v)+gamma(v)],

where gamma(v) is the sum of the prefixes preceding its appended one-bits. Therefore

    (Q^n x)_v=omega^gamma(v) sum_s x_s omega^[s rev_n(v)].

The positive Fourier sign, exact n-bit reversal, and row phase were verified on fresh inputs. These checks authenticate the conventions used in this continuation. They do not turn polynomial action into a new complete Fourier algorithm.

The accepted predecessor's fill-in lower bound is compatible with this circuit. Dense entry materialization may be expensive while applying the operator is cheap. No new single-cycle scalar representation, constant-bandwidth representation, or applicability of the prior quadratic endpoint theorems follows from the grading.

## 9 Primary comparisons and novelty scope

The prior marker source was independently opened before the novelty judgment. Zheng, Kingsford, and Marcais define a prefix-marker-or-marker-avoiding depathing set and prove a short remaining path bound. Word reversal gives the suffix orientation here. The marker language and its nilpotence are classical overlap. The present review derives the stronger common-delay weighted factorization rather than attributing it to that source. [Definition 2 and Lemma 2](https://arxiv.org/html/2001.06550v1)

Leiserson and Saxe give topological processing for acyclic circuit subgraphs and show that vertex retiming changes path delay only by an endpoint lag difference. Their primary paper was inspected at Section 2 and Section 3, equation (2) and Lemma 1. This is direct classical precedent for stripping a known vertex-dependent delay. It does not state this marker-Schur arithmetic theorem or provide its input/output ledger. [Retiming Synchronous Circuitry](https://www.cs.columbia.edu/~cs6861/handouts/leiserson-algorithmica-88.pdf)

The scalar convolution comparison is properly bounded: exact FFT-based multiplication needs a sufficiently long transform and suitable roots. Moreno Maza's Algorithm 2 and Theorem 2 were checked directly. A supplied Nth root does not supply a suitable transform for every d>N. The candidate's paid evaluation/action/interpolation wrapper and its root caveat are valid; no general convolution lower bound is established. [Fast Convolution and Multiplication](https://www.csd.uwo.ca/~mmorenom/CS424/Lectures/FastMultiplication.html/node6.html)

Van der Hoeven distinguishes full, truncated, relaxed, and semi-relaxed products, including whether input coefficients arrive progressively. His root-of-unity assumptions were checked in Sections 1-3. That comparison supports separating a known-input action from a causal unknown-series solve. No numerical complexity formula obscured by the page's image-rendered mathematics was imported into this review. [New algorithms for relaxed multiplication](https://www.texmacs.org/joris/newrelax/newrelax.html)

De Sa and coauthors explicitly relate sparse product width to linear straight-line programs and separate sparse circuit descriptions from dense matrix entries. Appendix B was inspected directly. This supports the materialization/action distinction, not a claim that the particular graded circuit is unprecedented. [Appendix B](https://arxiv.org/pdf/1611.01569)

Boito and Eidelman's band/Green correspondence has actual bandwidth hypotheses. A grading with large layer widths does not by itself establish those hypotheses, so no fast quasiseparable inverse is imported. [Section 2](https://arxiv.org/html/2308.02701v1#S2)

This is a useful, elementary, source-specific graded-DAG derivation with clear classical structural precedents. The targeted comparison is not an exhaustive novelty or priority search. The candidate's recommendation 60/100 may stand as a next-work recommendation only; existing ALG-068 rank 48 is unchanged.

## 10 Fresh exact controls

All review controls passed; both programs produced byte-identical replay JSON. The finite fields were GF(3), GF(5), GF(17), GF(41), GF(97), GF(193), GF(257), and GF(65537), only at sizes with the required exact-order root, through n=10.

The first independent suite records:

- 147 parameter cases and 39 empty-free boundaries
- 23,064 independently checked marker metadata states
- 46,128 structural edges and 4,257 free states with exactly one R-entry path length
- 1,951 polynomial vectors, including 961 retained basis vectors, zero vectors, and cancellation inputs
- 302,437 internal free coefficient comparisons
- 5,448 scalar specialization checks including z=0
- 147 causal inverse cases and 220,533 inverse coefficient comparisons against full-state recurrence
- 147 arbitrary fresh-source and recovery cases
- 4,120 direct Fourier output checks

The independently written row-delay suite adds:

- 46,128 delay-checked edges and 23,064 second-marker metadata checks
- 319 exact grade-census checks
- 501 full row-interval action vectors, including degrees greater than N
- 397,616 represented scalar output slots, with actual deterministic interval-array coalescing
- 13,340 R-basis row/degree entries
- 2,004 precision views, including zero precision
- Exact cyclic-versus-truncated inverse, inhomogeneous-source, and weighted-cancellation guards

The programs are correctness controls, not performance benchmarks. Their reference routines deliberately use direct time propagation, strings, and dense comparisons. The asymptotic theorem rests on the explicit paid construction in Section 6. Passing small instances does not substitute for the all-size proof.

## 11 Final disposition and next boundary

**ACCEPT:** the free grading, common retained R-return delay, exact delayed spatial factorization, complete O(N) constant-input action, complete O(N(d+1)) polynomial action under coalesced row intervals, and separate O(N(m+1)) causal inverse-jet schedule.

**Not established:** an O(N) full Fourier transform; any sub-N-log-N full transform; a cheaper arbitrary fresh-source and recovery pipeline; a faster general retained inverse; world-first novelty; or a legal single scalar-cycle implementation. These remain separate obligations, not corollaries of the accepted action.

No external sheet, repository, publication, or research rank was changed. The sealed review includes the unchanged candidate and the accepted predecessor needed to audit the scope.
