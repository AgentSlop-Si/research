#!/usr/bin/env python3
"""Fresh review controls. No candidate or historical code imported/executed."""
from collections import defaultdict
from pathlib import Path
import json, random, hashlib

COUNTS=defaultdict(int)
CASES=[]
RNG=random.Random(110113)

def power_root(p,n):
    N=1<<n
    for v in range(2,p):
        if pow(v,N,p)==1 and pow(v,N//2,p)!=1:
            return v
    raise AssertionError((p,n))

def graph(n,b,p,omega):
    N=1<<n
    words=[format(s,f'0{n}b') for s in range(N)]
    R={s for s,w in enumerate(words) if w.endswith('0'*b)}
    A={s for s,w in enumerate(words) if '0'*b not in w}
    T=R|A; F=set(range(N))-T
    grades={s:n-b-words[s].rfind('0'*b) for s in F}
    edges=[((2*s)%N,1,((2*s+1)%N),pow(omega,s,p)) for s in range(N)]
    return N,R,A,T,F,grades,edges

def each_edge(edges,s):
    v,a,w,c=edges[s]
    return ((v,a),(w,c))

def graded_action(G,U,p):
    N,R,A,T,F,grade,edges=G
    d=len(next(iter(U.values())))-1
    # Independent fresh recurrence. Exact coefficient output is coalesced.
    free={s:[0]*(d+1) for s in F}; out=defaultdict(int)
    for s in T:
        for j,x in enumerate(U[s]): out[(s,j)]=(out[(s,j)]+x)%p
        for v,w in each_edge(edges,s):
            COUNTS['action_edges_processed']+=1
            if v in F:
                assert grade[v]==1
                for j,x in enumerate(U[s]): free[v][j]=(free[v][j]+w*x)%p
            else:
                for j,x in enumerate(U[s]): out[(v,j+1)]=(out[(v,j+1)]-w*x)%p
    for s in sorted(F,key=lambda s:grade[s]):
        for v,w in each_edge(edges,s):
            COUNTS['action_edges_processed']+=1
            if v in F:
                assert grade[v]==grade[s]+1
                for j,x in enumerate(free[s]): free[v][j]=(free[v][j]+w*x)%p
            else:
                for j,x in enumerate(free[s]): out[(v,j+grade[s]+1)]=(out[(v,j+grade[s]+1)]-w*x)%p
    return {k:v for k,v in out.items() if v}, free

def time_action(G,U,p):
    N,R,A,T,F,grade,edges=G
    d=len(next(iter(U.values())))-1
    L=max(grade.values(),default=0)
    H=d+L+1
    # Full coefficient-in-time free recurrence, no grades used in propagation.
    free={s:0 for s in F}; out={}; free_time=[]
    for t in range(H+1):
        yy={s:(U[s][t] if t<=d else 0) for s in T}
        ff={s:0 for s in F}
        if t:
            for s in T:
                x=U[s][t-1] if t-1<=d else 0
                for v,w in each_edge(edges,s):
                    if v in T: yy[v]=(yy[v]-w*x)%p
                    else: ff[v]=(ff[v]+w*x)%p
            for s in F:
                for v,w in each_edge(edges,s):
                    if v in T: yy[v]=(yy[v]-w*free[s])%p
                    else: ff[v]=(ff[v]+w*free[s])%p
        free=ff; free_time.append(ff.copy())
        for s,v in yy.items():
            if v: out[s,t]=v
    return out,free_time

def prefix_metadata(n,b):
    # Implement O(N) construction, independently compare to string definition.
    last=[-1]; runs=[0]
    for length in range(1,n+1):
        newlast=[]; newruns=[]
        for s in range(1<<length):
            parent=s>>1; bit=s&1
            run=min(b,runs[parent]+1) if bit==0 else 0
            newruns.append(run)
            newlast.append(length-b if run==b else last[parent])
        last,runs=newlast,newruns
    return last,runs

def full_step(x,edges,p):
    y=[0]*len(x)
    for s,a in enumerate(x):
        for v,w in each_edge(edges,s):y[v]=(y[v]+w*a)%p
    return y

def solve_jet(G,g,p,H):
    # Fresh causal coefficient-by-coefficient feedback solve, not candidate code.
    N,R,A,T,F,grade,edges=G
    pending={(s,t):g.get((s,t),0) for s in T for t in range(H+1)}
    Y={s:[0]*(H+1) for s in T}
    for t in range(H+1):
        u={s:[pending[s,t]] for s in T}
        for s in T:Y[s][t]=u[s][0]
        au,_=graded_action(G,u,p)
        for (s,j),val in au.items():
            if j and t+j<=H:pending[s,t+j]=(pending[s,t+j]-val)%p
    return Y

def scalar_dag_action(G,U,p,z):
    N,R,A,T,F,grade,edges=G
    f={s:0 for s in F}; y={s:U[s] for s in T}
    for s in T:
        for v,w in each_edge(edges,s):
            if v in F:f[v]=(f[v]+z*w*U[s])%p
            else:y[v]=(y[v]-z*w*U[s])%p
    for s in sorted(F,key=lambda s:grade[s]):
        for v,w in each_edge(edges,s):
            if v in F:f[v]=(f[v]+z*w*f[s])%p
            else:y[v]=(y[v]-z*w*f[s])%p
    return y

for p,nmax in [(3,1),(5,2),(17,4),(41,3),(97,5),(193,6),(257,8),(65537,10)]:
  for n in range(1,nmax+1):
    omega=power_root(p,n)
    for b in range(1,n+1):
        G=graph(n,b,p,omega); N,R,A,T,F,grade,edges=G
        COUNTS['parameter_cases']+=1
        if not F: COUNTS['empty_free_cases']+=1
        last,runs=prefix_metadata(n,b)
        for s in range(N):
            assert ((s in T)==(last[s]<0 or runs[s]==b))
            if s in F:assert grade[s]==n-b-last[s]
            COUNTS['metadata_states']+=1
        lengths={s:set() for s in F}
        for s in T:
            for v,w in each_edge(edges,s):
                if s in A:assert v in T
                if v in F:
                    assert s in R and grade[v]==1
                    lengths[v].add(1)
                COUNTS['structural_edges']+=1
        for s in sorted(F,key=lambda s:grade[s]):
            for v,w in each_edge(edges,s):
                if v in F:
                    assert grade[v]==grade[s]+1
                    lengths[v].update({a+1 for a in lengths[s]})
                COUNTS['structural_edges']+=1
        for s in F:
            assert lengths[s]=={grade[s]}
            COUNTS['single_length_states']+=1
        tests=[]
        for d in [0,1,3]:
            tests.append({s:[RNG.randrange(p) for _ in range(d+1)] for s in T})
            tests.append({s:[0]*(d+1) for s in T})
        if n<=5:
            for a in T:
                tests.append({s:[int(s==a)] for s in T})
                COUNTS['basis_vectors']+=1
        # Adversarial cancellation pair across the dropped leading bit.
        if b<n:
            tests.append({s:[int(s in (0,N//2))] for s in T})
        for U in tests:
            out,fr=graded_action(G,U,p); oracle,ft=time_action(G,U,p)
            assert out==oracle
            d=len(next(iter(U.values())))-1
            for s in F:
                for t,vec in enumerate(ft):
                    expected=fr[s][t-grade[s]] if 0<=t-grade[s]<=d else 0
                    assert vec[s]==expected
                    COUNTS['free_coefficient_comparisons']+=1
            if d==0:
                for z in sorted({0,1,p-1,2%p}):
                    evaluated={s:0 for s in T}
                    for (s,j),v in out.items():evaluated[s]=(evaluated[s]+v*pow(z,j,p))%p
                    assert scalar_dag_action(G,{s:U[s][0] for s in T},p,z)==evaluated
                    COUNTS['scalar_specializations']+=1
            COUNTS['polynomial_vectors']+=1
        # Independent arbitrary retained-source inverse against full-state recurrence.
        H=n+2; g={(s,t):RNG.randrange(p) for s in T for t in range(H+1)}
        Y=solve_jet(G,g,p,H)
        sy,_=graded_action(G,Y,p)
        for s in T:
            for t in range(H+1):assert sy.get((s,t),0)==g[s,t]
        x=[0]*N
        for t in range(H+1):
            if t:x=full_step(x,edges,p)
            for s in T:x[s]=(x[s]+g[s,t])%p
            for s in T:assert Y[s][t]==x[s]
        COUNTS['causal_inverse_cases']+=1
        COUNTS['causal_inverse_coefficients']+=len(T)*(H+1)
        # Fresh full source and recovery using block recurrence including inhomogeneous F.
        x0=[RNG.randrange(p) for _ in range(N)]
        xs=[x0]
        for t in range(H):xs.append(full_step(xs[-1],edges,p))
        ff={s:x0[s] for s in F}; source={(s,0):x0[s] for s in T}
        for t in range(1,H+1):
            nf={s:0 for s in F}
            for s in F:
                for v,w in each_edge(edges,s):
                    if v in T:source[v,t]=(source.get((v,t),0)+w*ff[s])%p
                    else:nf[v]=(nf[v]+w*ff[s])%p
            ff=nf
        YY=solve_jet(G,source,p,H)
        for s in T:
            for t in range(H+1):assert YY[s][t]==xs[t][s]
        free={s:x0[s] for s in F}
        for t in range(1,H+1):
            nf={s:0 for s in F}
            for s in T:
                for v,w in each_edge(edges,s):
                    if v in F:nf[v]=(nf[v]+w*YY[s][t-1])%p
            for s in F:
                for v,w in each_edge(edges,s):
                    if v in F:nf[v]=(nf[v]+w*free[s])%p
            free=nf
            for s in F:assert free[s]==xs[t][s]
        COUNTS['fresh_source_recovery_cases']+=1
        # Fourier orientation is an independent direct sum (small cases only).
        if n<=7:
            for v in range(N):
                rev=int(format(v,f'0{n}b')[::-1],2)
                pref=0;gamma=0
                for bit in format(v,f'0{n}b'):
                    if bit=='1':gamma+=pref
                    pref=2*pref+int(bit)
                want=pow(omega,gamma,p)*sum(a*pow(omega,s*rev,p) for s,a in enumerate(x0))%p
                assert xs[n][v]==want
                COUNTS['fourier_outputs']+=1
        CASES.append({'p':p,'n':n,'b':b,'retained':len(T),'free':len(F),'maximum_grade':max(grade.values(),default=0)})

# Explicit guards against overclaims.
p=17;omega=2;G=graph(3,1,p,omega);N,R,A,T,F,grade,edges=G
assert pow(omega,8,p)==1 and pow(omega,4,p)!=1
_,fr=graded_action(G,{s:[int(s in [0,4])] for s in T},p)
assert fr[1]==[0]
# x_F=e_1+e_3 gives (D^-1 x_F)_3=1+2z, not one grade-2 monomial.
f=[0]*8;f[1]=f[3]=1
nextf=full_step(f,edges,p)
assert f[3]==1 and nextf[3]==2 and grade[1]==1 and grade[3]==2
# Inverse is genuinely recurrent, already when F is empty.
G1=graph(1,1,3,2);g={(0,0):1};Y=solve_jet(G1,g,3,4)
assert Y[0]==[1,1,2,2,1]
summary={'status':'PASS','control_code_origin':'Fresh review code; no candidate or historical code imported or executed.','counts':dict(sorted(COUNTS.items())),'guards':{'weighted_cancellation':{'p':17,'n':3,'b':1,'omega':2,'input_nonzero_indices':[0,4],'free_state':1,'amplitude':0},'inhomogeneous_source':{'p':17,'n':3,'b':1,'source_free_indices':[1,3],'state':3,'resolvent_polynomial':[1,2]},'empty_free_inverse_nontrivial':{'p':3,'n':1,'b':1,'coordinate_zero_jet':Y[0]}},'cases':CASES}
print(json.dumps(summary,indent=2,sort_keys=True))
