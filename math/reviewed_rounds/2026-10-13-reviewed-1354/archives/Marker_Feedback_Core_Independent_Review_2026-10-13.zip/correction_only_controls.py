#!/usr/bin/env python3
"""Fresh correction-only control using only this review's fresh module."""
import json
from independent_controls import Graph, add, solve


cases = []
for p, top in ((17, 4), (97, 5), (257, 7)):
    for n in range(2, top+1):
        for b in range(2, n):
            G = Graph(n, b, p)
            r, q = len(G.R), b-2
            inputs = []
            for s in range(r):
                jet = [[0]*r for _ in range(q+1)]
                jet[0][s] = 1
                inputs.append(jet)
            inputs.append([[(u+2)*(t+3)+(u+t)**2 for u in range(r)] for t in range(q+1)])
            comparisons = 0
            for raw in inputs:
                g = [[v % p for v in row] for row in raw]
                expected = solve(G.Z, g, p)
                found = []
                for t in range(q+1):
                    incoming = [0]*r
                    if t:
                        for u, value in enumerate(found[t-1]):
                            incoming[2*u % r] = (incoming[2*u % r]+value) % p
                    found.append(add(g[t], incoming, p))
                assert found == expected
                comparisons += r*(q+1)
            cases.append(dict(n=n,b=b,p=p,horizon=q,constant_basis_sources=r,
                              dense_forced_jets=1,scalar_comparisons=comparisons))
print(json.dumps(dict(status='PASS',independent_new_code=True,cases=cases,
                      total_cases=len(cases),
                      scalar_comparisons=sum(x['scalar_comparisons'] for x in cases)),
                 indent=2,sort_keys=True))
