# Marker feedback core independent review

Read REVIEW.md for the scoped ACCEPT of the frozen candidate. No speed claim or numerical score promotion is accepted.

STRENGTHENING.md is a separate new lemma discovered during review and awaiting its own independent review. Its status is intentionally different from the acceptance of the submitted candidate. It contains an all-domain one-correction path argument and a short correction-only solve corollary.

Evidence files:

- independent_controls.py is fresh review code using only the Python standard library.
- CONTROLS.json and REPLAY_CONTROLS.json are byte-identical independent executions.
- correction_only_controls.py is fresh review code importing only independent_controls.py.
- CORRECTION_CONTROLS.json and CORRECTION_REPLAY.json are byte-identical executions: 24 cases and 2,800 exact scalar comparisons.
- The original candidate ZIP is included unchanged and is bound by its SHA-256 in PROVENANCE.json.
- MANIFEST.json binds all deliverable members by size and SHA-256.

To replay the main controls, extract the unchanged candidate ZIP into a separate directory and run python3 independent_controls.py with that directory as its only argument. Do not run any candidate programs. To replay the correction-only check, run python3 correction_only_controls.py in this review directory.

No historical research program was executed. No Sheet, GitHub repository, publication, or external ranking was changed.
