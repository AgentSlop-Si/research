# Independent review of marker feedback core reduction

13 October 2026 UTC. Verdict on the frozen candidate: **scoped ACCEPT**. No substantive repair is required for its Schur closure, sufficient one-correction condition, exact port ranks, or bounded interpretation of the realization witness.

The candidate isolates the delayed R-return inverse but does not provide a cheaper full-horizon inverse or selected-output recovery. Its unrestricted Hankel certificate is valid in its stated realization model and is explicitly not a lower bound for the n-step Fourier task. The current O(N(n+1)) complete reference remains in force. This review makes no numerical score, rank, priority, publication, or repository change.

Two additional observations made during this review are segregated in STRENGTHENING.md. They are new claims awaiting a separate independent review, rather than part of the acceptance of the submitted candidate: the one-correction formula appears to hold for every 1<=b<n by a stronger path-length bound, and the short correction inverse can be performed using Z_0 alone. Neither observation resolves the first H_R solve.

## Reviewed bytes and independent evidence

The frozen candidate is Marker_Feedback_Core_Finite_Horizon_Reduction_2026-10-13.zip, 41,905 bytes, supplied under Library identity libfile_76175293a2c08191b48ec67743d8a892. Its SHA-256 is

    437c9e13158c5e8348c616ad992703a7d2d40f58b8ec8e9c82d53c1891cc7e0e

The report SHA-256 is e32e9216adc794852a60cf226d41459259c1ac0d3980f9fb0bd485449bc7c10f. All eleven manifest-listed members were size-checked and rehashed inside the twelve-member archive. Their bytes and the manifest were compared with the supplied extracted copy. The accepted graded-action and arbitrary-source reviews were read as antecedents; their included hashes agree with the candidate manifest.

No candidate, predecessor, downloaded, or historical research program was executed or imported. independent_controls.py was newly written for this audit. It constructs Q directly, enumerates first returns while retaining their edge counts, uses independently implemented exact modular elimination, and compares several distinct causal constructions. It imports only the Python standard library. correction_only_controls.py imports only that new review module. The candidate research programs were treated as bytes for provenance checks, not executed.

The main controls and an isolated replay are byte-identical. The main evidence covers:

- 37 parameter cases through n=7 over GF(17), GF(97), and GF(257).
- 460 constant full-state basis sources, including all states in every tested case with n<=5.
- 74 dense polynomial full-state forcing jets, two per parameter case.
- Horizon 2n+2 for full source, retained closure, and recovery comparisons.
- 182,200 full-state scalar comparisons, including 138,330 retained comparisons, 42,852 R-only closure comparisons, and 139,348 A/F recovery comparisons. These counts describe overlapping comparison interfaces, not disjoint independent trials.
- 19,732 n-horizon R coefficient comparisons for the one-correction formula.
- 1,262 exact Fourier-port entries, both port ranks, common row delays, and the short-return gap in every case.
- Exact rational numerator/denominator, polynomial coprimality, a matrix annihilator, three Hankel certificates, and the scalar-chart guard.

Finite controls corroborate the arguments below; they do not prove all-size complexity, establish minimality for every parameter, or authenticate the candidate's numerical score recommendation. The delivered control code is a deliberately simple oracle, not an implementation of an asymptotic improvement.

## Exact R only closure

Use n>=2, 1<=b<n, N=2^n, L=n-b, h=L+1, and r=2^L. Let omega have exact order N in a field K. Put D=Q_AA, C=Q_RA, E=M_AR, and Z=Delta_R M_RR. With T ordered as (A,R), the accepted grading gives

    S = [ I-zD       -z^h E ]
        [ -zC         I-Z  ].

Solving its first row gives

    Y_A = (I-zD)^(-1) f_A + z^h (I-zD)^(-1) E Y_R.

Substitution into the second row, retaining multiplication order, yields exactly

    L_R Y_R = f_R + z C(I-zD)^(-1)f_A,
    L_R = I-Z-z^(h+1)C(I-zD)^(-1)E.

Both I-zD and L_R have identity constant coefficient. Their inverses exist unconditionally in K[[z]], including in every field permitted by the root-order assumption. This closure has r output coordinates, but its rational coefficient transfer can contain more than r internal dynamic states.

The candidate's non-nilpotence argument is correct: the only self-loop inside A is the all-one word, with weight omega^(N-1), so trace(D)=omega^(-1) is nonzero. A nilpotent matrix has zero trace in every field. Hence (I-zD)^(-1) cannot be a polynomial matrix, although C and E can cancel particular modes after projection.

The determinant identity det(I-zQ)=det(I-zD)det L_R is a rational identity, using det(I-zB)=1 for the free block. It does not allow evaluating the chosen Schur chart at a singular A pivot. In the independently rebuilt n=3, b=1, GF(17), omega=2 example at z=2, the A pivot determinant is zero but the full determinant is 8. This reproduces the candidate's important scalar-chart warning.

At b=n, F is empty, the block split is simply that of I-zQ, h=1, E=Q_AR, and the same elimination is valid. The terminal port census is not asserted at that boundary. The candidate's stated boundary handling is mathematically sound and does not supply a small-core algorithm.

## The finite horizon theorem as submitted

Let H_R=(I-Z)^(-1), J=z^ell Psi, ell=h+1=n-b+2, and Psi=C(I-zD)^(-1)E. The factorization

    I-Z-J = (I-Z)(I-H_R J)

gives the formal identity

    (I-Z-J)^(-1) = sum_(k>=0) (H_R J)^k H_R.

Every H_R has nonnegative powers and every J has valuation at least ell. Modulo z^(m+1), terms with k>floor(m/ell) vanish. For m=n, the sufficient condition 2ell>n is exactly b<=floor((n+3)/2), and under this condition the candidate's formula

    L_R^(-1) = H_R + H_R J H_R modulo z^(n+1)

is correct, with the displayed noncommutative order.

Only Psi coefficients through n-ell=b-2 can contribute. For b=1 there is no correction, and for b=2 only Psi(0)=CE is needed. If u=H_R g is already known through n, computing the correction requires u only through b-2 inside J. After removing z^ell, the final inverse application also needs precision only b-2. Charging a second complete n-step inverse would be unnecessary.

The condition is sufficient, not claimed necessary. Its lack of sharpness is therefore not a correctness repair. The stronger condition-free path argument discovered in this review is isolated in STRENGTHENING.md and awaits separate independent verification. None of these finite-degree identities lowers the cost of the first H_R solve by itself.

## Exact port ranks

Put f_L=a_b(L-1), the number of (L-1)-bit words avoiding 0^b.

The nonzero C rows are exactly y=p10^b with p avoiding and |p|=L-1. Each such row has at least one A predecessor and entries equal to 1, because the edge appends zero. Different destination rows have disjoint predecessor-column supports. The f_L rows are therefore independent over every field. A row can have only one A predecessor; the candidate correctly does not assume two. Thus rank(C)=f_L.

The nonzero E rows are exactly y=0^(b-1)1v with v an avoiding L-bit word. Their unique first-passage paths append w=1v in h steps. With input R coordinate s=2^b u, the path exponent has the form

    gamma_h(w) + 2^b u rev_h(w) modulo N,

where rev_h uses the time ordering of appended bits and gamma_h sums the preceding prefixes at one-bits. Hence an active row is a nonzero phase times a Fourier row for rho=omega^(2^b).

Writing v=v'c, its frequency modulo r is 1+2 rev_(L-1)(v'), independent of c. Every avoiding v' has the extension c=1, and the f_L frequencies are distinct modulo r. Since rho has exact order r, these are distinct rows of an invertible r-point Fourier matrix. Duplicated rows differ only by nonzero phase. Thus rank(E)=f_L without a genericity assumption.

The resulting f_L-dimensional external port factorization does not bound the transfer's internal realization order. The candidate correctly preserves D and the cost of its propagation rather than treating port compression as a nilpotent reduction. Likewise, mixing R rows with different delays changes the polynomial delay operator; the diagonal Delta_R cannot silently be retained unchanged.

The stated bound O(min(N,rL+a_b(L))) for one E application is a valid choice between the inherited spatial circuit and a full r-point Fourier transform followed by selection and phases. It presupposes the explicitly charged root powers and coordinate/phase metadata. It does not make the complete M_RR application faster than its presently paid O(N) circuit.

## What the Hankel witness proves

For n=3, b=2, GF(17), omega=2, the independently rebuilt D, C, and E exactly match the candidate. Its scalar factor is

    phi(z) = (1+10z+15z^2+2z^3+15z^4)
             /(1+8z+13z^2+11z^3+8z^4).

The polynomial gcd is constant. The first coefficients agree with 1,2,3,9,10,9,15,6,3,1,5,2,3,6,4. Independent matrix multiplication verifies

    D^5+8D^4+13D^3+11D^2+8D=0.

Together with the initial numerator identities, this certifies the rational expression at all degrees, not only the 30 coefficients generated for the control.

The unshifted 5-by-5 Hankel determinant is 4. The shifted 4-by-4 determinant is 15. The 7-by-7 standard shifted Hankel matrix of z^3 phi has determinant 1. Consequently:

- A realization of phi allowing a separate direct-feedthrough term has minimum dynamic order four. Its shifted Hankel rank gives the lower bound; the coprime degree-four denominator gives a four-state realization.
- A representation of phi as C'(I-zD')^(-1)E' without a separate feedthrough term needs five coordinates. The unshifted rank proves the lower bound, and the displayed five-state D realizes it.
- The delayed scalar transfer z^3 phi has standard dynamic order seven. In lambda=z^(-1), its coprime denominator is lambda^3(lambda^4+8lambda^3+13lambda^2+11lambda+8), and the shifted rank-seven certificate agrees.

These exact realization statements are correctly separated by convention. Hankel factorization through a d-dimensional state gives rank at most d over any field, so the finite-field lower bounds require no numerical or real-field theorem.

**The witness is not an n-step lower bound.** At the requested n=3 horizon, z^3 phi is just z^3 modulo z^4. Only s_0 enters the feedback transfer. The higher coefficients needed by the order-four, order-five, and order-seven certificates are outside this Fourier horizon. They cannot rule out a small finite-horizon arithmetic circuit or a faster full transform. The candidate states this distinction correctly and prominently. No arithmetic-operation lower bound is accepted from these certificates.

## Paid unresolved solve and recovery obligations

The exact core remains

    H_R:g -> (I-Delta_R M_RR)^(-1)g modulo z^(n+1).

The direct zero-appending map is Z_0 e_u=e_(2u mod r). It is a merging functional graph with one loop, not a permutation or a scalar cycle. Every nondirect R return starts with an appended one and cannot reach another suffix 0^b before b additional steps. Therefore Z=zZ_0+O(z^(b+1)), as claimed. Eliminating Z_0 does not eliminate the cost of the remaining delayed composition.

For a general original vector x, source formation is

    f_T=x_T+z Q_TF(I-zB)^(-1)x_F,
    a0=(I-zD)^(-1)f_A,
    g_R=f_R+zCa0.

The accepted O(N+W) source construction and its at-most-2N structural slots are preserved. A sparse D recurrence through n costs O(|A|(n+1)+input slots); it is not shortened by the feedback factor z^ell. Dense g_R input/output also costs r(n+1) scalars. The candidate's conditional ledger correctly pays these terms and O(N) setup before invoking the unresolved first H_R routine.

The available generic causal solve costs O(N(q+1)) at precision q, using the spatial return circuit and explicit future-time scatter. Merely supplying the algebraic inverse, a rational matrix, a rank factorization, a characteristic polynomial, or a scalar recurrence does not replace this cost with a smaller bound. All coefficients, initial conditions, input/output transformations, and preprocessing of any claimed shortcut must be charged.

Free recovery is

    Y_F=(I-zB)^(-1)x_F + diag(z^a(s)) P Y_R.

At degree n the first term vanishes for a constant original x because B^L=0 and L<n. The remaining row s reads a different R time n-a(s). It is not one P multiplication on one common vector. The naive full-jet spatial-pass implementation is O(N(n+1)); a cheaper selected-time recovery remains a separate task. The actual requested transform has only N output scalars, so a dense polynomial-output size argument cannot lower-bound every algorithm for the selected coefficient.

A output has the unsimplified source part a0_n, plus the injected part which needs R coefficients through b-1. This b-1 recovery horizon differs from the b-2 A-to-R feedback horizon. The candidate keeps them separate. Our independent tests compare both recovery interfaces with direct full-state propagation through 2n+2, including arbitrary polynomial forcing as an additional control.

An improved arbitrary-jet H_R circuit would be a sufficient useful research advance. It is not proved to be a necessary intermediate for every possible faster transform, which might exploit a more specialized source or output representation. That logical distinction should remain visible in future work.

## Classical comparison and bounded disposition

The nonsymmetric block elimination is classical; the candidate applies it correctly to this graded marker operator. This review checked the block LDU and inverse formulas in Sanjay Lall's Stanford matrix notes, slides 6 and 7: https://ee263.stanford.edu/lectures/matrix_facts.pdf .

The relation between Hankel rank and time-invariant realization order is classical. This review checked the discussion and realization section of Fazel, Hindi, and Boyd: https://web.stanford.edu/~boyd/papers/pdf/rank_min_sys_theory.pdf . The finite-field rank lower bounds above were independently justified by algebraic factorization, rather than by importing numerical conclusions from that paper.

No exhaustive literature or worldwide novelty review was performed. The candidate's comparisons with recurrence acceleration, polynomial-system solving, and FFT evaluation are contextual, not evidence of a speed improvement. This review does not independently certify all claims in every cited publication or adopt the candidate's proposed numerical recommendation.

**Accepted:** the precise formal R-only Schur closure; the sufficient one-correction theorem as stated; exact feedback-port ranks and Fourier factorization; the scoped unrestricted realization witness; the scalar-chart warning; and the explicit paid source, core inverse, and selected-recovery obligations.

**No required repair:** the reviewed mathematical claims are valid within their stated scope. The candidate's one-excursion range can be sharpened, but a valid sufficient condition is not an error.

**Still not established:** a cheaper uniform full-horizon H_R solve; a cheaper complete source-to-selected-output transform; a sub-Nn/sub-FFT arithmetic bound; an arithmetic lower bound; an all-parameter minimal realization theorem; or worldwide novelty. STRENGTHENING.md contains separately labeled new claims pending independent review. No Sheet, GitHub repository, publication, or external ranking was changed.
