#!/usr/bin/env python3
"""Fresh independent finite-field controls. No research-code imports.

Build the full graph directly from its definition. First-return operators are
then enumerated without using the candidate's implementation or identities.
All arithmetic is exact. These tests corroborate proofs, not asymptotic costs.
"""
import hashlib
import json
from pathlib import Path
import sys
import zipfile


def zero(a, b):
    return [[0] * b for _ in range(a)]


def mv(M, v, p):
    return [sum(x*y for x, y in zip(row, v)) % p for row in M]


def add(a, b, p):
    return [(x+y) % p for x, y in zip(a, b)]


def mm(A, B, p):
    if not B:
        return [[] for _ in A]
    BT = list(zip(*B))
    return [[sum(x*y for x, y in zip(row, col)) % p for col in BT] for row in A]


def rank(M, p):
    A = [row[:] for row in M]
    r = 0
    if not A:
        return 0
    for j in range(len(A[0])):
        k = next((k for k in range(r, len(A)) if A[k][j] % p), None)
        if k is None:
            continue
        A[r], A[k] = A[k], A[r]
        inv = pow(A[r][j], -1, p)
        A[r] = [(x*inv) % p for x in A[r]]
        for k in range(r+1, len(A)):
            fac = A[k][j]
            if fac:
                A[k] = [(x-fac*y) % p for x, y in zip(A[k], A[r])]
        r += 1
        if r == len(A):
            break
    return r


def det(M, p):
    A = [row[:] for row in M]
    d = 1
    for j in range(len(A)):
        k = next((k for k in range(j, len(A)) if A[k][j] % p), None)
        if k is None:
            return 0
        if k != j:
            A[j], A[k] = A[k], A[j]
            d = -d
        pivot = A[j][j]
        d = d*pivot % p
        inv = pow(pivot, -1, p)
        for k in range(j+1, len(A)):
            fac = A[k][j]*inv % p
            A[k] = [(x-fac*y) % p for x, y in zip(A[k], A[j])]
    return d % p


def root(p, n):
    N = 1 << n
    return next(w for w in range(2, p) if pow(w, N, p) == 1 and pow(w, N//2, p) != 1)


def avoid(word, b):
    return '0'*b not in word


class Graph:
    def __init__(self, n, b, p):
        self.n, self.b, self.p = n, b, p
        self.N, self.L, self.h = 1 << n, n-b, n-b+1
        self.w = root(p, n)
        self.words = [format(s, f'0{n}b') for s in range(self.N)]
        self.R = [s for s in range(self.N) if s % (1 << b) == 0]
        self.A = [s for s, word in enumerate(self.words) if avoid(word, b)]
        self.T = self.A + self.R
        self.F = sorted(set(range(self.N)) - set(self.T))
        self.ai = {s: i for i, s in enumerate(self.A)}
        self.ri = {s: i for i, s in enumerate(self.R)}
        self.fi = {s: i for i, s in enumerate(self.F)}
        self.edges = [[(2*s % self.N, 1), ((2*s+1) % self.N, pow(self.w, s, p))] for s in range(self.N)]
        self.D = self.block(self.A, self.A)
        self.C = self.block(self.R, self.A)
        self.B = self.block(self.F, self.F)
        self.K = [zero(len(self.T), len(self.R)) for _ in range(self.h+1)]
        self.P = zero(len(self.F), len(self.R))
        # Enumerate first returns, explicitly retaining their edge counts.
        for j, s in enumerate(self.R):
            live = {s: 1}
            for t in range(1, self.h+1):
                nxt = {}
                for u, c in live.items():
                    for v, wt in self.edges[u]:
                        value = c*wt % p
                        if v in self.fi:
                            nxt[v] = (nxt.get(v, 0) + value) % p
                            self.P[self.fi[v]][j] = (self.P[self.fi[v]][j] + value) % p
                        else:
                            i = self.ai[v] if v in self.ai else len(self.A)+self.ri[v]
                            self.K[t][i][j] = (self.K[t][i][j]+value) % p
                live = {u: c for u, c in nxt.items() if c}
            assert not live
        self.E = [[sum(self.K[t][i][j] for t in range(1, self.h+1)) % p for j in range(len(self.R))] for i in range(len(self.A))]
        self.Z = [[row[:] for row in K[len(self.A):]] for K in self.K]
        self.tau = []
        for s in self.R:
            positions = [j for j in range(self.L+1) if self.words[s][j:j+b] == '0'*b]
            self.tau.append(self.L-positions[-2] if len(positions) > 1 else self.h)
        self.grade = [self.L-max(j for j in range(self.L+1) if self.words[s][j:j+b] == '0'*b) for s in self.F]

    def block(self, rows, cols):
        ix = {s: i for i, s in enumerate(rows)}
        M = zero(len(rows), len(cols))
        for j, s in enumerate(cols):
            for v, wt in self.edges[s]:
                if v in ix:
                    M[ix[v]][j] = (M[ix[v]][j]+wt) % self.p
        return M

    def apply(self, x):
        y = [0]*self.N
        for s, value in enumerate(x):
            if value:
                for v, wt in self.edges[s]:
                    y[v] = (y[v]+wt*value) % self.p
        return y

    def psi(self, m):
        W = [row[:] for row in self.E]
        out = []
        for _ in range(m+1):
            out.append(mm(self.C, W, self.p))
            W = mm(self.D, W, self.p)
        return out


def solve(kernel, g, p):
    """Generic causal series recurrence, dense coefficient input/output."""
    y = []
    for t, source in enumerate(g):
        value = source[:]
        for k in range(1, min(t+1, len(kernel))):
            value = add(value, mv(kernel[k], y[t-k], p), p)
        y.append(value)
    return y


def convolute(kernel, y, p):
    out = []
    for t in range(len(y)):
        value = [0]*len(y[0])
        for k in range(min(t+1, len(kernel))):
            value = add(value, mv(kernel[k], y[t-k], p), p)
        out.append(value)
    return out


def check_case(n, b, p):
    G = Graph(n, b, p)
    A, R, F, h, L = G.A, G.R, G.F, G.h, G.L
    a, r, f = len(A), len(R), len(F)
    m = 2*n+2
    ell = h+1
    bound = max(L+2, b+1)
    psi = G.psi(m)
    # Structural common-delay formula and short-return gap.
    for t in range(1, h+1):
        for i in range(a):
            assert t == h or not any(G.K[t][i])
        for i in range(r):
            assert t == G.tau[i] or not any(G.Z[t][i])
    Z0 = zero(r, r)
    for u in range(r):
        Z0[2*u % r][u] = 1
    assert G.Z[1] == Z0
    assert all(not any(row) for t in range(2, min(h, b)+1) for row in G.Z[t])
    fl = sum(avoid(format(j, f'0{L-1}b') if L > 1 else '', b) for j in range(1 << (L-1)))
    assert rank(G.C, p) == fl
    assert rank(G.E, p) == fl
    assert sum(any(row) for row in G.C) == fl
    assert sum(any(row) for row in G.E) == sum(avoid(format(j, f'0{L}b'), b) for j in range(1 << L))
    fourier_entries = 0
    for i, s in enumerate(A):
        y = G.words[s]
        active = y.startswith('0'*(b-1)+'1')
        if not active:
            assert not any(G.E[i])
            continue
        wbits = y[b-1:]
        rev = sum(int(bit)*(1 << k) for k, bit in enumerate(wbits))
        prefix = 0
        gamma = 0
        for bit in wbits:
            if bit == '1':
                gamma += prefix
            prefix = 2*prefix+int(bit)
        for u in range(r):
            assert G.E[i][u] == pow(G.w, gamma+(1 << b)*u*rev, p)
            fourier_entries += 1
    # Additional review observation: complete A excursions also cost >= b+1.
    assert all(not any(row) for k in range(max(0, bound-ell)) for row in psi[k])
    firstJ = next((ell+k for k, matrix in enumerate(psi) if any(any(row) for row in matrix)), None)
    assert firstJ is None or firstJ >= bound
    J = [zero(r, r) for _ in range(m+1)]
    for k in range(m+1-ell):
        J[k+ell] = psi[k]
    KR = [zero(r, r) for _ in range(m+1)]
    for k in range(1, m+1):
        KR[k] = [[(J[k][i][j]+(G.Z[k][i][j] if k < len(G.Z) else 0)) % p for j in range(r)] for i in range(r)]

    full_comp = retained_comp = r_comp = recovery_comp = finite_comp = 0
    jets = []
    if n <= 5:
        for s in range(G.N):
            X = zero(m+1, G.N)
            X[0][s] = 1
            jets.append(X)
    for seed in (3, 11):
        jets.append([[(seed*(s+1)*(t+2)+(s+t)**2+7*t) % p for s in range(G.N)] for t in range(m+1)])
    for X in jets:
        full = []
        for t in range(m+1):
            full.append(add(X[t], G.apply(full[t-1]) if t else [0]*G.N, p))
        # Original free source, constructed independently by causal B evolution.
        free0 = []
        forced = []
        QTF = G.block(G.T, F)
        for t in range(m+1):
            free0.append(add([X[t][s] for s in F], mv(G.B, free0[t-1], p) if t else [0]*f, p))
            forced.append(add([X[t][s] for s in G.T], mv(QTF, free0[t-1], p) if t else [0]*(a+r), p))
        # Direct retained recurrence, without the R-only Schur elimination.
        retained = []
        for t in range(m+1):
            value = forced[t][:]
            if t:
                value[:a] = add(value[:a], mv(G.D, retained[t-1][:a], p), p)
                value[a:] = add(value[a:], mv(G.C, retained[t-1][:a], p), p)
            for k in range(1, min(t, h)+1):
                value = add(value, mv(G.K[k], retained[t-k][a:], p), p)
            retained.append(value)
            assert value == [full[t][s] for s in G.T]
            retained_comp += a+r
        a0 = []
        g = []
        for t in range(m+1):
            a0.append(add(forced[t][:a], mv(G.D, a0[t-1], p) if t else [0]*a, p))
            g.append(add(forced[t][a:], mv(G.C, a0[t-1], p) if t else [0]*r, p))
        YR = solve(KR, g, p)
        YA = []
        for t in range(m+1):
            value = forced[t][:a]
            if t:
                value = add(value, mv(G.D, YA[t-1], p), p)
            if t >= h:
                value = add(value, mv(G.E, YR[t-h], p), p)
            YA.append(value)
            assert YR[t] == [full[t][s] for s in R]
            assert value == [full[t][s] for s in A]
            r_comp += r
            recovery_comp += a
            for i, s in enumerate(F):
                response = sum(G.P[i][j]*YR[t-G.grade[i]][j] for j in range(r)) % p if t >= G.grade[i] else 0
                assert (free0[t][i]+response) % p == full[t][s]
                recovery_comp += 1
            full_comp += G.N
        # Finite Neumann expansion, including several excursions at long horizons.
        term = solve(G.Z, g, p)
        total = [row[:] for row in term]
        for k in range(1, m//ell+1):
            term = solve(G.Z, convolute(J, term, p), p)
            total = [add(x, y, p) for x, y in zip(total, term)]
        assert total == YR
        u = solve(G.Z, g, p)
        correction = solve(G.Z, convolute(J, u, p), p)
        one = [add(x, y, p) for x, y in zip(u, correction)]
        # Stronger statement checked for every b, including outside candidate range.
        assert one[:n+1] == YR[:n+1]
        finite_comp += r*(n+1)
        if b >= 2:
            q = b-2
            shortJ = convolute(psi[:q+1], u[:q+1], p)
            shortCorrection = solve(G.Z, shortJ, p)
            assert correction[ell:n+1] == shortCorrection
        else:
            assert all(not any(row) for row in correction[:n+1])
    return dict(n=n, b=b, p=p, omega=G.w, A=a, R=r, F=f, port_rank=fl,
                original_constant_basis_sources=(G.N if n <= 5 else 0), dense_forced_jets=2,
                horizon=m, full_scalar_checks=full_comp, retained_scalar_checks=retained_comp,
                R_closure_scalar_checks=r_comp, A_F_recovery_scalar_checks=recovery_comp,
                finite_horizon_scalar_checks=finite_comp, fourier_entry_checks=fourier_entries,
                candidate_one_excursion_condition=(2*ell > n), stronger_excursion_bound=bound,
                actual_first_J_degree=firstJ)


def poly_trim(a, p):
    a = [x % p for x in a]
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a


def poly_rem(a, b, p):
    a = poly_trim(a, p)
    b = poly_trim(b, p)
    while len(a) >= len(b) and a != [0]:
        t = len(a)-len(b)
        q = a[-1]*pow(b[-1], -1, p) % p
        for j, x in enumerate(b):
            a[j+t] = (a[j+t]-q*x) % p
        a = poly_trim(a, p)
    return a


def witness():
    G = Graph(3, 2, 17)
    assert G.w == 2
    D = [[0,0,1,0,0],[0,0,15,0,0],[4,0,0,13,0],[0,1,0,0,1],[0,8,0,0,9]]
    C = [[0,0,0,0,0],[1,0,0,1,0]]
    E = [[1,16],[2,15],[0,0],[0,0],[0,0]]
    assert (G.D, G.C, G.E) == (D, C, E)
    e, c = [1,2,0,0,0], [1,0,0,1,0]
    seq = []
    v = e[:]
    for _ in range(30):
        seq.append(sum(x*y for x, y in zip(c, v)) % 17)
        v = mv(D, v, 17)
    num, den = [1,10,15,2,15], [1,8,13,11,8]
    a, b = num[:], den[:]
    while b != [0]:
        a, b = b, poly_rem(a, b, 17)
    assert len(a) == 1
    for t in range(30):
        assert sum(den[k]*seq[t-k] for k in range(min(t+1, len(den)))) % 17 == (num[t] if t < len(num) else 0)
    # All-degree recurrence certificate, independently multiplied matrices.
    powers = [[[int(i == j) for j in range(5)] for i in range(5)]]
    for _ in range(5):
        powers.append(mm(D, powers[-1], 17))
    annihilator = [[(powers[5][i][j]+8*powers[4][i][j]+13*powers[3][i][j]+11*powers[2][i][j]+8*powers[1][i][j]) % 17 for j in range(5)] for i in range(5)]
    assert not any(any(row) for row in annihilator)
    Hu = [[seq[i+j] for j in range(5)] for i in range(5)]
    Hs = [[seq[i+j+1] for j in range(4)] for i in range(4)]
    delayed = [0,0,0]+seq
    Hd = [[delayed[i+j+1] for j in range(7)] for i in range(7)]
    assert det(Hu,17) == 4 and det(Hs,17) == 15
    assert rank(Hd,17) == 7
    assert delayed[:4] == [0,0,0,1]
    # Exact scalar chart failure while the full scalar system remains invertible.
    H = Graph(3, 1, 17)
    Q = H.block(list(range(8)), list(range(8)))
    full = [[(int(i == j)-2*Q[i][j]) % 17 for j in range(8)] for i in range(8)]
    pivot = [[(int(i == j)-2*H.D[i][j]) % 17 for j in range(len(H.A))] for i in range(len(H.A))]
    assert det(pivot,17) == 0 and det(full,17) == 8
    return dict(n=3,b=2,p=17,omega=2,coefficients=seq,
                numerator=num,denominator=den,coprime=True,matrix_annihilator_zero=True,
                unshifted_5x5_determinant=det(Hu,17),shifted_4x4_determinant=det(Hs,17),
                delayed_7x7_determinant=det(Hd,17),delayed_Hankel_rank=rank(Hd,17),
                Fourier_horizon_delayed_coefficients=delayed[:4],
                singular_chart=dict(n=3,b=1,p=17,alpha=2,A_pivot_det=0,full_det=8))


def binding(candidate):
    name = 'Marker_Feedback_Core_Finite_Horizon_Reduction_2026-10-13.zip'
    data = (candidate/name).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == '437c9e13158c5e8348c616ad992703a7d2d40f58b8ec8e9c82d53c1891cc7e0e'
    with zipfile.ZipFile(candidate/name) as z:
        manifest = json.loads(z.read('MANIFEST.json'))
        checked = []
        for item in manifest['files']:
            contents = z.read(item['path'])
            assert len(contents) == item['size_bytes']
            assert hashlib.sha256(contents).hexdigest() == item['sha256']
            assert contents == (candidate/item['path']).read_bytes()
            checked.append(item['path'])
        assert z.read('MANIFEST.json') == (candidate/'MANIFEST.json').read_bytes()
        return dict(archive=name,sha256=digest,bytes=len(data),manifest_members_checked=checked,
                    archive_members=len(z.namelist()),all_manifest_bytes_match=True)


def main():
    candidate = Path(sys.argv[1])
    cases = []
    for p, top in ((17,4),(97,5),(257,7)):
        for n in range(2,top+1):
            for b in range(1,n):
                cases.append(check_case(n,b,p))
    fields = ['original_constant_basis_sources','dense_forced_jets','full_scalar_checks',
              'retained_scalar_checks','R_closure_scalar_checks','A_F_recovery_scalar_checks',
              'finite_horizon_scalar_checks','fourier_entry_checks']
    result = dict(status='PASS',independent_new_code=True,historical_research_code_run=False,
                  binding=binding(candidate),cases=cases,totals={key:sum(x[key] for x in cases) for key in fields},
                  total_parameter_cases=len(cases),
                  outside_candidate_condition_cases=sum(not x['candidate_one_excursion_condition'] for x in cases),
                  exact_witness=witness())
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__ == '__main__':
    main()
