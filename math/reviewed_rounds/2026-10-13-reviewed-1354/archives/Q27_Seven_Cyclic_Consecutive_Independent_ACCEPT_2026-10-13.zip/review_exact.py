#!/usr/bin/env python3
"""Independent exact verifier. Reads candidate JSON as data; executes no candidate code."""
import sys,json,hashlib,math,itertools,time,zipfile,copy
from pathlib import Path
from fractions import Fraction
from sympy.polys.domains import QQ_I,ZZ_I
from sympy.polys.rings import ring
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'input'
RQ,xq,yq,zq=ring('x,y,z',QQ_I)
R,x,y,z=ring('x,y,z',ZZ_I)
V=[xq,yq,zq]
Z=(0,0,0)
ARCHIVE=ROOT/'candidate/Q27_Seven_Cyclic_Consecutive_Affine_Certificates_Author_Candidate_2026-10-13.zip'
AH='c9073944b7fa366b2492a58d7a52e51f190ca6984799698c8ef9217fb290e585'
MH='d4f23da6855bd1fdb2a93353d6b254315074d4524b8d6d85d7ca771de7b56c3f'
CH='5528afbbd5b4008a5e0f79043870e72a613e0fd421288d2ce1e5dbffee1c9e98'
COUNTS={}
def check(b,msg):
 if not b:raise RuntimeError(msg)
 COUNTS[msg]=COUNTS.get(msg,0)+1

def sha(b):return hashlib.sha256(b).hexdigest()
def js(p):return json.loads(Path(p).read_text())
def qc(a):return QQ_I(a.x,-a.y)
def enc(a):return [str(a.x),str(a.y)]
def Q(a):return QQ_I.convert(a)
def parseg(pair,integer=False):
 check(isinstance(pair,list) and len(pair)==2 and all(isinstance(x,str) for x in pair),'Gaussian pair schema')
 re,im=map(Fraction,pair)
 a=QQ_I(QQ_I.dom(re.numerator,re.denominator),QQ_I.dom(im.numerator,im.denominator))
 if integer:check(a.x.denominator==a.y.denominator==1,'Gaussian integer schema')
 return ZZ_I(int(a.x),int(a.y)) if integer else a

def parsepoly(data,integer=False):
 check(isinstance(data,list),'Polynomial schema')
 out={}
 for e,a in data:
  check(isinstance(e,list) and len(e)==3 and all(type(t)==int and t>=0 for t in e),'Nonnegative exponent schema')
  check(tuple(e) not in out,'Unique polynomial exponents')
  val=parseg(a,integer);check(bool(val),'Nonzero sparse coefficient');out[tuple(e)]=val
 return (R if integer else RQ).from_dict(out)

def torq(p):return RQ.from_dict({e:Q(a) for e,a in p.items()})
def torz(p):
 check(all(a.x.denominator==a.y.denominator==1 for a in p.values()),'Integral polynomial conversion')
 return R.from_dict({e:ZZ_I(int(a.x),int(a.y)) for e,a in p.items()})
def serial(p):return [[list(e),enc(a)] for e,a in sorted(p.items())]
def mzero():return [[RQ.zero for c in range(8)] for r in range(8)]
def eye():return [[RQ.one if r==c else RQ.zero for c in range(8)] for r in range(8)]
def madd(A,B):return [[A[r][c]+B[r][c] for c in range(8)] for r in range(8)]
def mscale(A,a):return [[a*p for p in row] for row in A]
def mmul(A,B):
 O=mzero()
 for r in range(8):
  for k in range(8):
   if A[r][k]:
    for c in range(8):
     if B[k][c]:O[r][c]+=A[r][k]*B[k][c]
 return O

def meq(A,B,label):
 for r in range(8):
  for c in range(8):check(A[r][c]==B[r][c],label)

def evalp(p,point):
 o=QQ_I.zero
 for e,a in p.items():o+=Q(a)*math.prod(t**k for t,k in zip(point,e))
 return o

def evalm(A,point):return [[evalp(p,point) for p in row] for row in A]
def invdet(A):
 # Gauss-Jordan elimination independently reconstructs the five fixed Greens.
 T=[list(row)+[QQ_I.one if r==c else QQ_I.zero for c in range(8)] for r,row in enumerate(A)]
 det=QQ_I.one
 for c in range(8):
  k=next((k for k in range(c,8) if T[k][c]),None)
  if k is None:return None,QQ_I.zero
  if k!=c:T[k],T[c]=T[c],T[k];det=-det
  pivot=T[c][c];det*=pivot;T[c]=[a/pivot for a in T[c]]
  for r in range(8):
   if r!=c and T[r][c]:
    a=T[r][c];T[r]=[b-a*d for b,d in zip(T[r],T[c])]
 return [row[8:] for row in T],det

def cc_mmul(A,B):return [[sum((A[r][k]*B[k][c] for k in range(8)),QQ_I.zero) for c in range(8)] for r in range(8)]
def inversecheck(A,B):
 for prod in (cc_mmul(A,B),cc_mmul(B,A)):
  for r in range(8):
   for c in range(8):check(prod[r][c]==(QQ_I.one if r==c else QQ_I.zero),'Direct inverse entries')

def primitive(p):
 d=math.lcm(*(int(v.x.denominator) for v in p.values()),*(int(v.y.denominator) for v in p.values()))
 vals={e:ZZ_I(int(a.x*d),int(a.y*d)) for e,a in p.items()}
 g=math.gcd(*(int(v.x) for v in vals.values()),*(int(v.y) for v in vals.values()))
 check(g>0 and d>0,'Positive primitive normalization')
 return R.from_dict({e:ZZ_I(int(a.x)//g,int(a.y)//g) for e,a in vals.items()}),QQ_I(g)/QQ_I(d)

def defectmatrix(N,conjugate=True):
 NT=[[R.from_dict({tuple(1-k for k in e):ZZ_I(a.x,-a.y if conjugate else a.y) for e,a in p.items()}) for p in row] for row in N]
 D=[]
 for r in range(1,8):
  for c in range(1,8):D.append(N[r][c]*N[0][0]*NT[r][c]*NT[0][0]-N[r][0]*N[0][c]*NT[r][0]*NT[0][c])
 return D

def coefficientsum(polys,terms):
 acc=R.zero
 for t in terms:
  j=t['window_index'];a=parseg(t['numerator'],True);m=R.from_dict({tuple(t['shift']):a})
  acc+=m*polys[j]
 return acc

def expect_rejection(residual,label,controls):
 check(bool(residual),'Mutation rejected: '+label);controls.append(label)

# Immutable package and source admission.
check(sha(ARCHIVE.read_bytes())==AH,'Final archive SHA256')
with zipfile.ZipFile(ARCHIVE) as zf:
 names=zf.namelist();check(len(names)==39 and len(set(names))==39,'Archive exact membership count')
 check(all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names),'Safe archive paths')
 check(sha(zf.read('MANIFEST.json'))==MH,'Final manifest SHA256')
 manifest=json.loads(zf.read('MANIFEST.json'))['files']
 check(set(names)=={'MANIFEST.json'}|{m['path'] for m in manifest},'Manifest complete membership')
 check(len(manifest)==38,'Manifest payload count')
 for m in manifest:
  b=zf.read(m['path']);check(len(b)==m['bytes'] and sha(b)==m['sha256'],'Payload exact byte binding')
  check((INPUT/m['path']).read_bytes()==b,'Extracted byte binding')
for pin in js(INPUT/'SOURCE_PINS.json'):
 b=(INPUT/'sources'/pin['document']).read_bytes();check(len(b)==pin['bytes'] and sha(b)==pin['sha256'],'Predecessor source binding')
chart=js(INPUT/'sources/CHART.json');check(sha((INPUT/'sources/CHART.json').read_bytes())==CH,'Chart hash')
check(chart['N']==8 and chart['product_order']=='M=S2*S1' and chart['sum_coefficients']==[1,1,1] and chart['free_phase_indices']==list(range(7,24)),'Exact chart admission')
expected={(8,9,15),(8,14,15),(9,10,11),(10,11,12),(11,12,13),(12,13,14),(13,14,15)}
cyclic={tuple(sorted(8+(a+k)%8 for k in range(3))) for a in range(8)}
check(expected==cyclic-{(8,9,10)},'Exact cyclic and wraparound labels')
G=[];GS=[];HOL=[];Wfixed=[]
for s in range(2):
 gs=[QQ_I.one]*7
 for a,b in chart['stages'][s]['gaussian_pairs']:
  check(type(a)==type(b)==int and a*a+b*b>0,'Frozen pair admission')
  gs.append(QQ_I(a*a-b*b,2*a*b)/QQ_I(a*a+b*b))
 check(len(gs)==24 and all(v*qc(v)==QQ_I.one for v in gs),'All frozen gains unit')
 GS.append(gs);gg=[];hh=[];ww=[]
 for branch,cycle in enumerate(chart['stages'][s]['cycles']):
  check(sorted(cycle)==list(range(8)),'Cycle permutation')
  W=mzero()
  for j in range(8):W[cycle[j]][cycle[(j-1)%8]]=RQ(gs[8*branch+j])
  A=[[RQ.one-W[r][c] if r==c else -W[r][c] for c in range(8)] for r in range(8)]
  Ai=evalm(A,[QQ_I.one]*3);inverse,det=invdet(Ai)
  h=math.prod(gs[8*branch:8*branch+8]);check(h*qc(h)==QQ_I.one and bool(1-h),'Nonzero frozen Green guard')
  check(det==1-h,'Fixed inverse determinant guard');inversecheck(Ai,inverse)
  gg.append([[RQ(a) for a in row] for row in inverse]);hh.append(h);ww.append(W)
 G.append(gg);HOL.append(hh);Wfixed.append(ww)
check([[enc(v) for v in row] for row in HOL]==js(INPUT/'GUARDS.json'),'All six serialized holonomies')
h=HOL[0][1];f=1-h*xq*yq*zq
H=math.lcm(int(h.x.denominator),int(h.y.denominator));F=torz(H*f)
C=madd(G[0][0],G[0][2]);L=madd(madd(G[1][0],G[1][1]),G[1][2])
check(H==449660889716782337425,'Active guard denominator')
results=[]
print('PASS immutable package, chart, six direct inverses and all six guards',flush=True)
for edges in sorted(expected):
 start=time.time();tag='_'.join(map(str,edges));cert=js(INPUT/f'certificates/s1b1_{tag}.json');stored=js(INPUT/f'certificates/quotients_{tag}.json')
 check(cert['stage']==1 and cert['branch']==1 and cert['edges']==list(edges) and cert['variables_in_edge_order']==['x','y','z'] and cert['chart_sha256']==CH,'Certificate declared slice')
 check(parsepoly(cert['target'],True)==F and parsepoly(cert['original_guard'])==f and cert['target_integer_scale']==H,'Certificate guard and target')
 W=[[p.copy() for p in row] for row in Wfixed[0][1]];cycle=chart['stages'][0]['cycles'][1]
 for var,edge in zip(V,edges):
  j=edge-8;W[cycle[j]][cycle[(j-1)%8]]*=var
 A=[[RQ.one-W[r][c] if r==c else -W[r][c] for c in range(8)] for r in range(8)]
 # Independent matrix powers, rather than candidate's path traversal.
 B=mzero();power=eye()
 for k in range(8):B=madd(B,power);power=mmul(power,W)
 meq(power,mscale(eye(),h*xq*yq*zq),'Active eighth-power coefficient identity')
 meq(mmul(A,B),mscale(eye(),f),'Active left inverse coefficient identity')
 meq(mmul(B,A),mscale(eye(),f),'Active right inverse coefficient identity')
 Nraw=mmul(L,madd(B,mscale(C,f)))
 S=math.lcm(*(int(a.x.denominator) for row in Nraw for p in row for a in p.values()),*(int(a.y.denominator) for row in Nraw for p in row for a in p.values()))
 check(S>0 and str(S)==cert['numerator_scale'],'Exact numerator denominator scale')
 N=[[torz(S*p) for p in row] for row in Nraw]
 check(all(all(k in (0,1) for k in e) for row in N for p in row for e in p),'Global triaffine support')
 P=defectmatrix(N);q=[];c=[];Pclear=[]
 check(len(stored)==49 and len(cert['quotient_normalizations'])==49,'All 49 quotient rows')
 quotient_coefficient_count=0;defect_coefficient_count=0
 for j in range(49):
  qr,rem=divmod(torq(P[j]),f)
  check(not rem,'Every original defect division remainder')
  qq,cc=primitive(qr);q.append(qq);c.append(cc)
  sq=parsepoly(stored[j],True);sc=parseg(cert['quotient_normalizations'][j])
  check(qq==sq,'Every stored quotient coefficient')
  check(cc==sc and cc.y==0 and cc.x>0,'Every stored normalization scalar')
  check(f*torq(qq)*cc==torq(P[j]),'Every original defect multiplication back')
  pc=torz(torq(P[j])*H/cc);Pclear.append(pc)
  check(pc==F*qq,'Direct original defect normalized row')
  quotient_coefficient_count+=len(qq);defect_coefficient_count+=len(P[j])
 terms=cert['terms'];check(len(terms)==(51 if edges==(8,14,15) else 47 if edges==(8,9,15) else 46),'Exact multiplier term count')
 seen=set()
 for t in terms:
  j=t['window_index'];check(type(j)==int and 0<=j<49,'Multiplier row range')
  check((t['row'],t['column'])==(j//7+1,j%7+1),'Multiplier row labels')
  shift=tuple(t['shift']);check(shift in (Z,(0,0,1)),'Only constant and z shifts')
  check((j,shift) not in seen,'Unique multiplier terms');seen.add((j,shift))
  check(bool(parseg(t['numerator'],True)),'Nonzero multiplier numerator')
 d=parseg(cert['common_denominator'],True);check(bool(d),'Nonzero scalar denominator')
 total=coefficientsum(q,terms);totalP=coefficientsum(Pclear,terms)
 check(total==d*F,'Full quotient multiplier coefficient identity')
 check(totalP==d*F*F,'Full original defect multiplier coefficient identity')
 fullsupport=set()
 for qq in q:
  for e in qq:
   for shift in [Z,(1,0,0),(0,1,0),(0,0,1)]:fullsupport.add(tuple(a+b for a,b in zip(e,shift)))
 check(sorted(fullsupport)==[tuple(e) for e in cert['full_expanded_support']],'All degree-one output support')
 proofdir=ROOT/'reconstructed';proofdir.mkdir(exist_ok=True)
 proof={'edges':list(edges),'numerator_scale':str(S),'numerator':[[serial(p) for p in row] for row in N],'original_defects':[serial(p) for p in P],'normalized_original_rows_H_P_over_c':[serial(p) for p in Pclear]}
 (proofdir/f'proof_{tag}.json').write_text(json.dumps(proof,separators=(',',':'))+'\n')
 original_fullsupport={tuple(a+b for a,b in zip(e,shift)) for pp in P for e in pp for shift in [Z,(1,0,0),(0,1,0),(0,0,1)]}
 # Controls reconstruct original M at one new, exact unit point; pole check is separate.
 point=[QQ_I(3,4)/5,QQ_I(-5,12)/13,QQ_I(8,-15)/17]
 check(all(v*qc(v)==QQ_I.one for v in point),'Control point unit modulus')
 fp=evalp(f,point);Ai=evalm(A,point);gi,det=invdet(Ai)
 check(det==fp and bool(fp),'Fresh active direct determinant');inversecheck(Ai,gi)
 c0=evalm(C,point);l0=evalm(L,point);s1=[[gi[r][c]+c0[r][c] for c in range(8)] for r in range(8)];M=cc_mmul(l0,s1)
 for r in range(8):
  for col in range(8):check(evalp(N[r][col],point)==S*fp*M[r][col],'All original numerator entries')
 for j,pp in enumerate(P):
  r=j//7+1;col=j%7+1
  av=M[r][col]*M[0][0];bv=M[r][0]*M[0][col]
  actual=av*qc(av)-bv*qc(bv)
  expectedP=S**4*math.prod(point)**2*(fp*qc(fp))**2*actual
  check(evalp(pp,point)==expectedP,'All original modulus defect rows')
 pole=[QQ_I.one,QQ_I.one,qc(h)];pole_inv,pole_det=invdet(evalm(A,pole))
 check(evalp(f,pole)==QQ_I.zero and pole_inv is None and pole_det==QQ_I.zero,'Unit pole rejected by original inverse')
 controls=[];first=terms[0];j=first['window_index'];shift=tuple(first['shift']);mono=R.from_dict({shift:ZZ_I.one});a=parseg(first['numerator'],True)
 expect_rejection(total+mono*q[j]-d*F,'multiplier numerator +1',controls)
 expect_rejection(total-mono*q[j]*a-d*F,'omitted multiplier',controls)
 expect_rejection(total-(d+1)*F,'denominator +1',controls)
 expect_rejection(total-d*(F+1),'target constant +1',controls)
 expect_rejection(total-d*F*F,'wrong target power',controls)
 expect_rejection(coefficientsum(q,[t for t in terms if tuple(t['shift'])==Z])-d*F,'all affine terms removed',controls)
 relabeled=copy.deepcopy(terms)
 for t in relabeled:
  if t['shift']==[0,0,1]:t['shift']=[1,0,0]
 expect_rejection(coefficientsum(q,relabeled)-d*F,'z shifts relabeled x',controls)
 k=next(k for k in range(49) if q[k]!=q[j])
 expect_rejection(total+a*mono*(q[k]-q[j])-d*F,'wrong polynomial row',controls)
 expect_rejection(torq(P[0])-(f+1)*torq(q[0])*c[0],'changed active guard',controls)
 badP=defectmatrix(N,False);check(all(a!=b for a,b in zip(P,badP)),'Every window detects missing coefficient conjugation');controls.append('missing coefficient conjugation')
 # An exponent outside all author output rows must never be silently discarded.
 for e in [(9,0,0),(0,9,0)]:expect_rejection(total-(d*F+R.from_dict({e:ZZ_I.one})),'out-of-support target '+str(e),controls)
 badB=[[p.copy() for p in row] for row in B];badB[0][0]+=(xq+1)*(xq-2)
 check(mmul(A,badB)!=mscale(eye(),f),'Mutation rejected: sampled-invisible inverse perturbation');controls.append('sampled-invisible inverse perturbation')
 # Reversed stage product is directly compared without sharing reconstruction order.
 Nreverse=mmul(madd(B,mscale(C,f)),L)
 check(Nreverse!=Nraw,'Mutation rejected: reversed stage product');controls.append('reversed stage product')
 record={'edges':list(edges),'status':'PASS','quotient_rows':49,'stored_nonzero_quotient_coefficients':quotient_coefficient_count,'original_nonzero_defect_coefficients':defect_coefficient_count,'degree_one_quotient_output_rows':len(fullsupport),'degree_one_original_defect_output_rows':len(original_fullsupport),'actual_quotient_accumulation_rows':len(set().union(*(set((tuple(a+b for a,b in zip(e,t['shift'])) for e in q[t['window_index']])) for t in terms))), 'multiplier_terms':len(terms),'constant_terms':sum(t['shift']==[0,0,0] for t in terms),'linear_terms':sum(t['shift']==[0,0,1] for t in terms),'mutation_rejections':controls,'seconds':round(time.time()-start,3)}
 results.append(record);print('PASS',tag,json.dumps(record),flush=True)
 (ROOT/'PARTIAL_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
# Coordinate universe uses actual stage-labelled free phases, including mixed-stage triples.
coords=list(itertools.product((1,2),range(7,24)));universe=set(itertools.combinations(coords,3));check(len(universe)==5984,'Full coordinate universe')
prior128={(s,7,a,b) for s in (1,2) for a in range(8,16) for b in range(16,24)}
check(len(js(INPUT/'sources/PRIOR_128_ACCEPTED_COVERAGE.json')['coordinates'])==128 and {tuple(e) for e in js(INPUT/'sources/PRIOR_128_ACCEPTED_COVERAGE.json')['coordinates']}==prior128,'Exact inherited 128 source coordinates')
nonconsecutive={(1,)+e for e in itertools.combinations(range(8,16),3) if e not in cyclic}
prior=prior128|nonconsecutive|{(1,8,9,10)};new={(1,)+e for e in expected}
cov=js(INPUT/'COVERAGE.json');declared=cov['accepted_prior_ledger'];newdecl=cov['candidate_new_labels']
check(len(declared)==177 and {tuple(e) for e in declared}==prior,'Exact source ledger 177')
check(len(newdecl)==7 and {tuple(e) for e in newdecl}==new,'Exact seven new labels')
check(all(tuple((t[0],edge) for edge in t[1:]) in universe for t in prior|new),'Every ledger coordinate in full universe')
check(not (prior&new) and len(prior|new)==184,'New prior label disjointness')
check(len({t for t in prior|new if t[0]==1 and all(8<=e<=15 for e in t[1:])})==56,'Complete stage1 branch1 56 labels')
check(5984-len(prior|new)==5800,'Remaining unclassified 5800')
check(cov['new_accepted']==0 and cov['prior_accepted']==177 and cov['full_34_phase_fiber']=='OPEN' and cov['priority_unchanged']==50 and cov['geometric_slices_pointwise_disjoint'] is False,'Candidate provisional status preserved')
# Scope admission rejection tests use the independently enumerated set.
scope_bad=[(2,8,9,15),(1,8,9,10),(1,7,8,9),(1,8,8,15),(1,8,9,16),(1,8,10,12)]
for a in scope_bad:check(a not in new,'Out-of-scope label rejected')
verdict={'status':'INDEPENDENT_ACCEPT_RESTRICTED_SEVEN_SLICES','candidate_archive_sha256':AH,'candidate_manifest_sha256':MH,'chart_sha256':CH,'new_exclusions':7,'accepted_prior':177,'accepted_union':184,'coordinate_universe':5984,'remaining_unclassified':5800,'complete_stage1_branch1_triples':56,'full_34_phase_fiber':'OPEN','priority_unchanged':50,'inherited_177_proofs_rerun':False,'all_seven_full_coefficient_checks':True,'mutation_rejections':sum(len(r['mutation_rejections']) for r in results),'scope_rejections':len(scope_bad),'historical_or_candidate_code_executed':False,'external_sheet_repository_publication_changes':False,'results':results,'check_counts':COUNTS}
(ROOT/'VERDICT.json').write_text(json.dumps(verdict,indent=2)+'\n')
(ROOT/'ACCEPTED_COVERAGE.json').write_text(json.dumps({'prior_labels':sorted(prior),'new_labels':sorted(new),'accepted_union_labels':sorted(prior|new),'universe_size':5984,'accepted':184,'remaining_unclassified':5800,'label_disjointness_only':True},indent=2)+'\n')
print('INDEPENDENT PASS: seven new labels; accepted union 184/5984; 5800 unclassified; full fiber OPEN.',flush=True)
