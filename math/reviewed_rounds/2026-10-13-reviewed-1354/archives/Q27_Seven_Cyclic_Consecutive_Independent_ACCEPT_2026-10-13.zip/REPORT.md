# Independent Q27 seven cyclic consecutive slice review

13 October 2026 UTC. Decision: **ACCEPT for the seven exact restricted slices below.** No mathematical repair is required.

## Accepted result

The seven stage-1, zero-based branch-1 triples (8,9,15), (8,14,15), (9,10,11), (10,11,12), (11,12,13), (12,13,14), and (13,14,15) are excluded from external invertible complex row and column monomial equivalence to F8 on the pinned N=8 chart. The same necessary-modulus argument excludes any nonzero constant-entry-modulus target.

For each triple, precisely those three frozen gains receive independent unit-complex multipliers x, y, z in increasing edge-label order. The other 31 free phases and all 14 tree-pinned gains remain frozen. All six directed cycle masks, unit branch-sum coefficients, M=S2*S1, absence of a free interstage diagonal, and all six original Green inverse guards are retained. The two wraparound triples are verified directly in their original coordinates. No cyclic symmetry or gauge transport is assumed.

The accepted 177-label ledger and these seven distinct new labels have disjoint coordinate-label sets. Their union is **184 of 5,984**, leaving **5,800 unclassified**. All 56 stage-1 branch-1 triples among edges 8 through 15 are now covered through this one frozen witness. The full 34-phase fiber remains **OPEN**, and Q27 priority remains **50**. Geometric slices intersect; they are not asserted pointwise disjoint.

## Immutable inputs and independence

The exact candidate is Q27_Seven_Cyclic_Consecutive_Affine_Certificates_Author_Candidate_2026-10-13.zip, 3,944,888 bytes, SHA-256:

c9073944b7fa366b2492a58d7a52e51f190ca6984799698c8ef9217fb290e585

Its MANIFEST.json SHA-256 is:

d4f23da6855bd1fdb2a93353d6b254315074d4524b8d6d85d7ca771de7b56c3f

All 39 ZIP paths are unique and safe. The 38 payload members are verified by exact size and SHA-256 against the manifest, and the extracted files are compared byte-for-byte with the archive. The chart is pinned to:

5528afbbd5b4008a5e0f79043870e72a613e0fd421288d2ce1e5dbffee1c9e98

The four source bindings are checked against their packaged bytes:

- Accepted nonconsecutive-class review: c92a946f8bb57dfc6abb868cb604ad3ef7720eda48c844027ded121ee9776d40
- Accepted class verdict: cd55032b4c6afab04f0548fddb40ef386c634b79c00d9ab918dc6951ff1decfa
- Exact chart: 5528afbbd5b4008a5e0f79043870e72a613e0fd421288d2ce1e5dbffee1c9e98
- Accepted affine predecessor report, with its declared final-LF normalization: 515c13dda2d0ff49bd1baa4f8c34c74a2c786ffe89c9b6e4035c71f3cb9bdc72

The inherited 177 exclusion proofs and historical source recipe remain accepted dependencies; this audit does not rerun them. The predecessor reports' normalization and provenance caveats remain in force. This review verifies the exact supplied pinned chart, rather than newly proving its historical random-seed provenance.

The fresh review_exact.py program imports only Python standard-library modules and installed SymPy exact Gaussian-rational and Gaussian-integer polynomial rings. No candidate, predecessor, or historical research program was executed, imported, compiled, or evaluated. Candidate constructor text was inspected only to clarify serialization semantics. The new checker never invokes or trusts the author's solver, modular selection, internal checks, or sampled vanishing. All acceptance conditions use explicit runtime checks rather than removable Python assert statements.

## Exact chart and guards

Each frozen gain is independently rebuilt from the pair (a,b) as (a^2-b^2+2ab i)/(a^2+b^2). All 48 stage-edge gains have exact unit modulus. Edge 8b+j maps cycle[j-1] to cycle[j]. The six original I-W matrices are independently inverted by fresh exact Gauss-Jordan elimination; both matrix products are checked in all 64 entries and each determinant agrees with its guard.

The independently reconstructed holonomies exactly equal the serialized values:

- h_10=(65+72i)/97
- h_11=(-383187819337037874577+235291331868842780736i)/449660889716782337425
- h_12=(-7219486963274846816853-5897211386485827321196i)/9321914725516081613405
- h_20=(-780+731i)/1069
- h_21=(-4335586066535028372496+1298149621513208810103i)/4525759492081695535625
- h_22=(91471421459307165236012877+37193164409786343925998436i)/98743872835733949286881365

The five inactive guards 1-h_sb are nonzero constants. The active guard is f=1-h_11 xyz. Let H=449660889716782337425 and F=Hf. H is a nonzero positive integer. At the unit-torus pole (1,1,conjugate(h_11)), direct elimination finds each active I-W singular and f=0. All seven such poles are rejected, not treated as admissible points after denominator clearing.

## Complete polynomial reconstruction

For each actual triple, fresh polynomial matrix multiplication constructs B=I+W+...+W^7. This uses matrix powers, rather than the author's directed-path traversal. The complete coefficient identities W^8=h_11 xyz I and (I-W)B=B(I-W)=fI are checked. There are 448 eighth-power entry checks and 896 active two-sided inverse entry checks across the seven slices.

With C=G_10+G_12 and L=G_20+G_21+G_22, the checker reconstructs n=L(B+fC)=fM. It computes the least positive integer S clearing every Gaussian-rational coefficient, compares S exactly with the recorded numerator_scale, and obtains the Gaussian-integer triaffine numerator N=S n. The reciprocal-conjugate numerator is rebuilt as

    Ntilde = xyz conjugate(N)(1/x,1/y,1/z).

Every coefficient is conjugated, and every exponent is complemented componentwise. All 49 anchored original defects per slice are reconstructed directly:

    P_rc = N_rc N_00 Ntilde_rc Ntilde_00
           - N_r0 N_0c Ntilde_r0 Ntilde_0c,  1 <= r,c <= 7.

Exact division by f has zero remainder for all 343 polynomials. Each quotient is independently normalized by clearing rational denominators and dividing the positive integer content of its real and imaginary integer components. This yields P_j=f c_j q_j with c_j a positive rational scalar and q_j a primitive Gaussian-integer polynomial.

All 13,146 stored nonzero quotient coefficients and all 343 normalizers agree exactly. Multiplication back independently verifies every original defect. The reconstruction contains 19,243 nonzero original-defect coefficients. The fresh reconstructed numerators, original defects, and normalized original rows are preserved in the seven reconstructed/proof_*.json data files.

## Both full certificate identities

All serialized Gaussian numerators are read literally, with no floating-point conversion. The checker validates every row-major window index, displayed row/column pair, distinct multiplier term, nonzero numerator, and permitted shift. The common Gaussian-integer denominator d is checked nonzero.

The (8,9,15) certificate has 41 constant and six z-linear terms; (8,14,15) has 41 constant and ten z-linear terms; each remaining certificate has 41 constant and five z-linear terms. There are 328 nonzero multiplier terms in total. The symbol z always means the last edge in increasing label order, including both wraparound cases.

The checker accumulates the complete quotient identity in the Gaussian-integer polynomial ring:

    sum_j a_j monomial_j q_j = d F.

It separately normalizes the freshly rebuilt original defects to R_j=H P_j/c_j, verifies R_j=F q_j, and accumulates directly from those original-defect rows:

    sum_j a_j monomial_j R_j = d F^2.

The latter is exactly the denominator-cleared version of

    sum_j (a_j/c_j) monomial_j P_j = d H f^2.

Every coefficient of both complete polynomial residuals is zero. No projection onto the author's chosen subsystem is used. The complete degree-at-most-one quotient support has 85 monomials per slice; the corresponding original-defect support has 119. Actual selected multiplier supports are smaller, but all absent and present coefficients are controlled by full polynomial equality. Coefficients outside those supports are zero by exhaustive sparse accumulation, not assumed from a sampled fit. No rank bound or minimal-multiplier-degree claim is accepted or needed.

## Saturation and Fourier implication

The original-defect identity puts f^2 in the ideal generated by the P_j, because d, H, and every c_j are nonzero field scalars. Consequently that ideal becomes the unit ideal after localization at f. It also becomes the unit ideal after localization at xyz times all six original guards. These literal characteristic-zero coefficient identities remain valid over any characteristic-zero field extension, including an algebraic closure. No pole or forbidden denominator-zero point is admitted by this statement.

On the complex unit torus, reciprocal variables equal their complex conjugates, giving

    P_rc = S^4 (xyz)^2 |f|^4
           (|M_rc M_00|^2 - |M_r0 M_0c|^2).

An invertible row/column monomial image of a nonzero constant-entry-modulus matrix has rank-one squared-entry moduli. Thus every displayed necessary defect vanishes at a Fourier-equivalent admissible point. The full certificate would force f^2=0, contrary to the original inverse guard. No matrix entry is divided out. This is a necessary-condition exclusion, without any claim that anchored defect vanishing would be sufficient for Fourier equivalence.

The algebraic-closure statement is about this necessary polynomial system. It does not extend the original Fourier-equivalence conclusion to nonunit moving gains, where reciprocal-conjugation no longer represents ordinary conjugation.

## Direct and adversarial controls

At the exact new unit point ((3+4i)/5,(-5+12i)/13,(8-15i)/17), each active matrix is directly inverted again. All 448 original numerator entries agree with N=S fM, and all 343 anchored evaluations agree exactly with the actual squared-modulus defect formula. These controls supplement, rather than replace, the coefficient identities. Across frozen and test matrices there are 13 successful direct inversions, 1,664 two-sided inverse-entry checks, and seven singular pole rejections.

For each slice, the verifier rejects 14 independent corruptions or reconstruction errors:

1. Add one to a multiplier numerator
2. Omit a nonzero multiplier
3. Add one to the common denominator
4. Change the target constant coefficient
5. Use the wrong target power
6. Remove every affine multiplier
7. Relabel every z shift as x
8. Assign a multiplier to an unequal polynomial row
9. Change the active guard constant
10. Omit coefficient conjugation, changing all 49 windows
11. Add an unsupported target monomial x^9
12. Add an unsupported target monomial y^9
13. Perturb B_00 by (x+1)(x-2), invisible at a two-point interpolation grid but caught by the global inverse identity
14. Reverse the stage-product order

All 98 controls succeed. Six additional coordinate-admission controls exclude the wrong stage, already accepted predecessor triple, a tree-edge triple, a repeated edge, a different-branch edge, and a nonconsecutive triple from the claimed new set.

## Coverage and retained limitations

The full coordinate universe consists of three-element subsets of the 34 stage-labelled free phases and has size choose(34,3)=5,984. The old ledger is independently reconstructed as:

- 128 labels (s;7,a,b), with s=1,2, a=8..15, b=16..23
- The 48 stage-1 branch-1 nonconsecutive triples, excluding all eight cyclic intervals
- The separately accepted consecutive label (1;8,9,10)

The explicit prior-128 source coordinates, all 177 prior labels, all seven new labels, universe membership, uniqueness, and exact new/prior disjointness are checked. The seven new labels are exactly the remaining cyclic intervals, including both wraparounds. ACCEPTED_COVERAGE.json supplies the full 184-label union. The candidate's provisional ledger is left intact in the preserved candidate; this independent review supplies the accepted delta.

This completes only the 56 triples of one branch in one stage through one frozen witness. Other coordinate triples, other witnesses, four-or-more moving phases, larger N, weighted branch sums, nonunit internal gains, a free interstage diagonal, full-fiber nonexistence, Fourier synthesis, runtime improvements, and historical novelty remain unproved here. The remaining 5,800 coordinate triples are unclassified, not feasible or excluded by this review.

No spreadsheet, repository, publication, priority, or sharing-permission state was changed. The result is preserved privately as a review and reproducibility archive.
