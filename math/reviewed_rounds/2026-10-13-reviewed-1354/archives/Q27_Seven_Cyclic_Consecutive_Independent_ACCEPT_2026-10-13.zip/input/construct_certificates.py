#!/usr/bin/env python3
"""Fresh constructor, 2026-10-13. Executes no source-package program."""
import json,sys,time,math,hashlib,itertools
from pathlib import Path
from sympy import QQ_I, ZZ_I, ZZ
from sympy.polys.rings import ring
from sympy.polys.matrices import DomainMatrix
sys.set_int_max_str_digits(1000000)
ROOT=Path(__file__).resolve().parent
R,x,y,z=ring('x,y,z',QQ_I)
ONE=(0,0,0); XYZ=(1,1,1)
VARIABLES=[x,y,z]
P=1000000009 # 1 modulo 4
# A root of -1; used solely to choose a rational nonsingular subsystem.
IROOT=pow(13,(P-1)//4,P)
if IROOT*IROOT%P != P-1: raise ValueError('bad modular embedding')
def fail(b,m):
 if not b: raise ValueError(m)
def cconj(a):return QQ_I(a.x,-a.y)
def matzero():return [[QQ_I.zero for c in range(8)] for r in range(8)]
def matmul(A,B):return [[sum((A[r][k]*B[k][c] for k in range(8)),QQ_I.zero) for c in range(8)] for r in range(8)]
def matsum(A,B):return [[A[r][c]+B[r][c] for c in range(8)] for r in range(8)]
def enc(a):return [str(a.x),str(a.y)]
def pencil(cycle,gains,edges=()):
 # Direct path construction of sum W^j; positions have destination convention.
 W=[[R.zero for c in range(8)] for r in range(8)]
 for j,d in enumerate(cycle):
  a=R(gains[j]); e=8+j
  if e in edges:a*=VARIABLES[edges.index(e)]
  W[d][cycle[j-1]]=a
 B=[[R.one if r==c else R.zero for c in range(8)] for r in range(8)]
 for c in range(8):
  pos=cycle.index(c); product=R.one
  for distance in range(1,8):
   j=(pos+distance)%8; dest=cycle[j]
   product*=W[dest][cycle[j-1]];B[dest][c]+=product
 h=math.prod(gains);f=1-h*x*y*z if edges else R(1-h)
 # Sparse left and right global inverse identities, no finite interpolation.
 for r in range(8):
  for c in range(8):
   left=B[r][c]-sum((W[r][k]*B[k][c] for k in range(8)),R.zero)
   right=B[r][c]-sum((B[r][k]*W[k][c] for k in range(8)),R.zero)
   expected=f if r==c else R.zero
   fail(left==right==expected,'two-sided Green numerator identity')
 return B,f,h

def build_context(chart):
 gains=[];greens=[];hol=[]
 for s in range(2):
  gs=[QQ_I.one]*7+[QQ_I(a,b)/QQ_I(a,-b) for a,b in chart['stages'][s]['gaussian_pairs']]
  fail(len(gs)==24,'gain count');fail(all(g*cconj(g)==QQ_I.one for g in gs),'unit gains')
  gains.append(gs); gg=[];hh=[]
  for b in range(3):
   B,f,h=pencil(chart['stages'][s]['cycles'][b],gs[8*b:8*b+8])
   fail(bool(1-h),'fixed guard zero')
   gg.append([[v[ONE]/(1-h) if v else QQ_I.zero for v in row] for row in B]);hh.append(h)
  greens.append(gg);hol.append(hh)
 C=matsum(greens[0][0],greens[0][2]);L=matsum(matsum(greens[1][0],greens[1][1]),greens[1][2])
 return gains,C,L,hol

def primitive(poly):
 den=math.lcm(*(int(a.x.denominator) for a in poly.values()),*(int(a.y.denominator) for a in poly.values()))
 vals={e:ZZ_I(int(a.x*den),int(a.y*den)) for e,a in poly.items()}
 content=math.gcd(*(int(a.x) for a in vals.values()),*(int(a.y) for a in vals.values()))
 fail(content>0,'empty polynomial')
 return {e:ZZ_I(int(a.x)//content,int(a.y)//content) for e,a in vals.items()},QQ_I(content)/QQ_I(den)

def construct(edges,chart,ctx):
 gains,C,L,hol=ctx
 B,f,h=pencil(chart['stages'][0]['cycles'][1],gains[0][8:16],edges)
 T=[[B[r][c]+f*C[r][c] for c in range(8)] for r in range(8)]
 N=[[sum((L[r][k]*T[k][c] for k in range(8)),R.zero) for c in range(8)] for r in range(8)]
 scale=math.lcm(*(int(a.x.denominator) for row in N for p in row for a in p.values()),*(int(a.y.denominator) for row in N for p in row for a in p.values()))
 N=[[v*scale for v in row] for row in N]
 fail(all(all(0<=i<=1 for i in e) for row in N for v in row for e in v),'non-triaffine')
 Nt=[[R.from_dict({tuple(1-i for i in e):cconj(a) for e,a in v.items()}) for v in row] for row in N]
 defects=[];quotients=[];scalars=[]
 for r in range(1,8):
  for c in range(1,8):
   defect=N[r][c]*N[0][0]*Nt[r][c]*Nt[0][0]-N[r][0]*N[0][c]*Nt[r][0]*Nt[0][c]
   q,rem=divmod(defect,f)
   fail(not rem and q*f==defect,'defect divisibility')
   qp,scalar=primitive(q)
   fail(R.from_dict(qp)*scalar*f==defect,'primitive bridge')
   defects.append(defect);quotients.append(qp);scalars.append(scalar)
 return f,N,defects,quotients,scalars,scale

def residue(a):return (int(a.x)+IROOT*int(a.y))%P

def basis_columns(columns):
 basis={};inds=[];piv=[]
 for j,col in enumerate(columns):
  v=[residue(a) for a in col]
  for k,b in basis.items():
   m=v[k]
   if m:v=[(aa-m*bb)%P for aa,bb in zip(v,b)]
  at=next((k for k,a in enumerate(v) if a),None)
  if at is not None:
   inv=pow(v[at],-1,P);v=[a*inv%P for a in v]
   basis[at]=v;inds.append(j);piv.append(at)
 return inds,piv

def modular_solution(columns, chosen, piv, target):
 a=[[residue(columns[j][i]) for j in chosen]+[residue(target[i])] for i in piv]
 n=len(chosen)
 for k in range(n):
  r=next(r for r in range(k,n) if a[r][k]);a[k],a[r]=a[r],a[k]
  inv=pow(a[k][k],-1,P);a[k]=[(v*inv)%P for v in a[k]]
  for r in range(n):
   if r==k:continue
   m=a[r][k]
   if m:a[r]=[(v-m*w)%P for v,w in zip(a[r],a[k])]
 return [a[r][-1] for r in range(n)]

def gaussian_bareiss(A,rhs):
 # Fraction-free integer-pair elimination, independently authored here.
 def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
 def sub(a,b):return (a[0]-b[0],a[1]-b[1])
 def div(a,b):
  norm=b[0]*b[0]+b[1]*b[1]
  qr,rr=divmod(a[0]*b[0]+a[1]*b[1],norm)
  qi,ri=divmod(a[1]*b[0]-a[0]*b[1],norm)
  fail(rr==ri==0,'nonexact Bareiss division')
  return qr,qi
 a=[[(int(v.x),int(v.y)) for v in row]+[(int(rhs[i][0].x),int(rhs[i][0].y))] for i,row in enumerate(A)]
 n=len(a);prev=(1,0)
 for k in range(n-1):
  p=next(i for i in range(k,n) if a[i][k]!=(0,0))
  a[k],a[p]=a[p],a[k];pivot=a[k][k]
  for i in range(k+1,n):
   ik=a[i][k]
   for j in range(k+1,n+1):a[i][j]=div(sub(mul(pivot,a[i][j]),mul(ik,a[k][j])),prev)
   a[i][k]=(0,0)
  prev=pivot
 den=a[-1][-2];nums=[(0,0)]*n
 for i in range(n-1,-1,-1):
  v=mul(den,a[i][-1])
  for j in range(i+1,n):v=sub(v,mul(a[i][j],nums[j]))
  nums[i]=div(v,a[i][i])
 # A real common denominator simplifies serialization and independent checking.
 norm=den[0]*den[0]+den[1]*den[1]
 nums=[mul(v,(den[0],-den[1])) for v in nums]
 common=math.gcd(norm,*(c for v in nums for c in v));norm//=common
 nums=[ZZ_I(v[0]//common,v[1]//common) for v in nums]
 return nums,ZZ_I(norm)

def serialize_poly(poly):return [[list(e),enc(a)] for e,a in sorted(poly.items())]
def solve_certificate(edges,chart,ctx):
 t=time.time(); print('BEGIN',edges,flush=True)
 f,N,defects,Q,scalars,scale=construct(edges,chart,ctx)
 print('BUILT',edges,'seconds',round(time.time()-t,2),flush=True)
 # Constants first, then shifts. The order controls only certificate sparsity.
 shifts=[(0,0,0),(0,0,1),(0,1,0),(1,0,0)]
 collabels=[(j,shift) for shift in shifts for j in range(49)]
 supports=sorted(set(e for q in Q for e in q)|set(tuple(a+b for a,b in zip(e,s)) for q in Q for e in q for s in shifts))
 columns=[[Q[j].get(tuple(a-b for a,b in zip(e,s)),ZZ_I.zero) for e in supports] for j,s in collabels]
 chosen,piv=basis_columns(columns)
 # Freeze one full-rank modular selection; exact solve and every coefficient follow.
 print('SCOUT',edges,'equations',len(supports),'columns',len(chosen),flush=True)
 target_den=math.lcm(*(int(a.x.denominator) for a in f.values()),*(int(a.y.denominator) for a in f.values()))
 target=R(f*target_den)
 tv=[ZZ_I.convert(target.get(e,QQ_I.zero)) for e in supports]
 ms=modular_solution(columns,chosen,piv,tv)
 reduced=[j for j,a in zip(chosen,ms) if a]
 ci,piv=basis_columns([columns[j] for j in reduced]);chosen=[reduced[j] for j in ci]
 print('REDUCED',edges,'columns',len(chosen),flush=True)
 A=DomainMatrix([[columns[j][i] for j in chosen] for i in piv],(len(piv),len(chosen)),ZZ_I)
 rhs=DomainMatrix([[ZZ_I.convert(target.get(supports[i],QQ_I.zero))] for i in piv],(len(piv),1),ZZ_I)
 sol,den=gaussian_bareiss(A.to_list(),rhs.to_list())
 fail(bool(den),'zero certificate denominator')
 print('SOLVED',edges,'seconds',round(time.time()-t,2),'den digits',len(str(den)),flush=True)
 total=R.zero;direct=R.zero;terms=[]
 for col,a in zip(chosen,sol):
  if not a:continue
  j,shift=collabels[col];m=R.from_dict({shift:QQ_I.convert(a)})
  total+=m*R.from_dict(Q[j])
  direct+=m*defects[j]/scalars[j]
  terms.append({'window_index':j,'row':j//7+1,'column':j%7+1,'shift':list(shift),'numerator':enc(a)})
 fail(total==target*QQ_I.convert(den),'full coefficient identity failed')
 fail(direct==f*target*QQ_I.convert(den),'full direct defect identity failed')
 cert={'stage':1,'branch':1,'edges':list(edges),'variables_in_edge_order':['x','y','z'],'field':'Q(i), characteristic zero',
 'chart_sha256':hashlib.sha256((ROOT/'sources/CHART.json').read_bytes()).hexdigest(),'target':serialize_poly(target),'original_guard':serialize_poly(f),
 'target_integer_scale':target_den,'numerator_scale':str(scale),'quotient_normalizations':[enc(a) for a in scalars],
 'identity':'sum numerator_j * monomial_shift_j * primitive_Q_j = common_denominator * target_integer_scale * f',
 'common_denominator':enc(den),'terms':terms,'full_expanded_support':[list(e) for e in supports],
 'modular_selection_only':{'prime':P,'sqrt_minus_one':IROOT,'columns':chosen,'equations':piv},
 'checks':{'all_49_divisions':True,'full_Q_identity':True,'full_P_identity':True,'all_128_active_inverse_coefficients':True},
 'elapsed_seconds':time.time()-t}
 path=ROOT/'certificates'/('s1b1_'+'_'.join(map(str,edges))+'.json');path.write_text(json.dumps(cert,indent=2)+'\n')
 (ROOT/'certificates'/('quotients_'+'_'.join(map(str,edges))+'.json')).write_text(json.dumps([serialize_poly(q) for q in Q])+'\n')
 print('PASS',edges,'terms',len(terms),'elapsed',round(time.time()-t,2),flush=True)
 return cert

def main():
 chart=json.loads((ROOT/'sources/CHART.json').read_text());ctx=build_context(chart)
 (ROOT/'GUARDS.json').write_text(json.dumps([[enc(h) for h in row] for row in ctx[3]],indent=2)+'\n')
 targets=[(8,9,15),(8,14,15),(9,10,11),(10,11,12),(11,12,13),(12,13,14),(13,14,15)]
 if len(sys.argv)>1:targets=[tuple(map(int,sys.argv[1].split(',')))]
 for edges in targets:solve_certificate(edges,chart,ctx)
if __name__=='__main__':main()
