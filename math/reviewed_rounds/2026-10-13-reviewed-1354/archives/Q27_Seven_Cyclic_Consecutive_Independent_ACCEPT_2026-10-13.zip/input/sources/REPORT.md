# Independent scientific review: Q27 nonconsecutive branch class

13 October 2026 UTC. Verdict: ACCEPT, restricted to the exact pinned class below.

## Accepted result

All 48 unordered nonconsecutive triples among stage-1, zero-based branch-1 edges 8 through 15 are excluded from external invertible complex row/column monomial equivalence to F8. Here nonconsecutive excludes every cyclic three-edge interval, including wraparound intervals. For each triple, precisely those three original gains receive independent unit-complex multipliers, and the other 31 free phases remain frozen at the pinned witness. All 14 tree-pinned gains, all six cycle masks, both unweighted branch sums, M=S2*S1, no interstage diagonal, and all six Green inverse guards are retained.

The new proof contribution is exactly 44 coordinate labels. The four class members (8,9,11), (8,9,12), (8,9,13), and (8,9,14) are inherited accepted results. The separate consecutive (8,9,10) exclusion remains accepted from its affine-multiplier proof and is not a member of this nonconsecutive class.

Combining the 44 new labels with the established 133 labels gives 177 of choose(34,3)=5,984, leaving 5,807 unclassified. The new labels are disjoint from prior labels; this is coordinate-label accounting, not a claim that the geometric slices are pointwise disjoint. The full Q27 34-phase target fiber remains OPEN and its priority remains 50/100.

No mathematical repair to the candidate is required. One provenance clarification is recorded below: retrieved report copies have exactly one additional final LF and are not literally the Git blob bytes.

## Input binding and execution boundary

Candidate archive: Q27_Nonconsecutive_Branch_Class_and_Full_Coverage_Audit_2026-10-13.zip, 11,126,146 bytes.

SHA-256: e79997f7cfdaec0c412f7eb3702c9ed5f3575bcdd2d64da164bec71b40465ca3.

All 114 ZIP paths are safe and unique; exactly 113 payload files plus MANIFEST.json are present. Every payload length and SHA-256 matches the manifest. The chart hash is 5528afbbd5b4008a5e0f79043870e72a613e0fd421288d2ce1e5dbffee1c9e98.

The new reviewer program review_exact.py imports only Python standard-library modules and installed SymPy 1.14.0, whose QQ(i) and ZZ(i) polynomial rings supply exact arithmetic. It imports no candidate, predecessor, or historical research program. All rejections are explicit checks, not Python assert statements. The candidate's current verifier and three completion/source/coverage audit scripts were separately cold-replayed from its sealed bytes; all four succeeded. The constructor, historical programs, and optional solvers were not executed.

The original Phase40, Phase41, and Phase42 retained source snapshots were inspected only as text. They preserve their stated text-snapshot provenance limitation. The review independently regenerates the source recipe rather than treating the chart's declarations as proof.

No spreadsheet, repository, sharing permission, or other external state was changed. Six Git blob reads were used only to verify inherited source identity.

## Source reconstruction and six guards

A fresh implementation reproduces both seeds 42420 and 42520; shuffled cycles use seed+8, and Gaussian pairs use seed+7919+8. A graph-reachability spanning forest, rather than the source's union-find implementation, reconstructs tree edges 0 through 6 and chords 7 through 23 at each stage. All six masks and all 34 Gaussian pairs agree exactly. Destination-index edge 8b+j is cycle[j-1] -> cycle[j]. Frozen gains are (a+ib)/(a-ib); all 48 have exact norm one.

All six original matrices I-W are directly inverted at the frozen point using exact rational Gaussian elimination, with both matrix products checked. Their determinants are exactly 1-h_sb. The six reconstructed holonomies are:

- h_10=(65+72i)/97
- h_11=(-383187819337037874577+235291331868842780736i)/449660889716782337425
- h_12=(-7219486963274846816853-5897211386485827321196i)/9321914725516081613405
- h_20=(-780+731i)/1069
- h_21=(-4335586066535028372496+1298149621513208810103i)/4525759492081695535625
- h_22=(91471421459307165236012877+37193164409786343925998436i)/98743872835733949286881365

For every reviewed triple the sole moving guard is f=1-h_11 xyz; the other five are nonzero fixed constants. With H=449660889716782337425, F=Hf is the certificate's Gaussian-integer polynomial. H and all scalar normalizations are verified nonzero and positive. The unit-torus pole (1,1,conjugate(h_11)) is a unit-gain point but is excluded from the inverse-defined domain: all 44 attempted exact active inversions there are singular. Clearing denominators does not add that pole.

## Independent inverse, interpolation, and polynomial checks

The reviewer uses direct exact inversions at the shifted cube {-1,2}^3. These eight nodes differ from the candidate verifier's {0,1}^3. For each node, det(I-W)=f is verified and B=f(I-W)^(-1) is formed. Tensor Lagrange interpolation reconstructs B, after which the complete identities (I-W)B=B(I-W)=fI are checked as polynomial matrices. A separate full matrix-power construction also verifies B=I+W+...+W^7 and W^8=h_11 xyz I. Thus finite samples are not treated as proof of a global formula.

Writing C=G_10+G_12 and L=G_20+G_21+G_22, the reviewer reconstructs n=L(B+fC)=fM. The positive recorded scale S clears n into the exact Gaussian-integer triaffine numerator N=S n. It constructs the reciprocal-conjugate numerator Ntilde=xyz conjugate(N)(1/x,1/y,1/z) using actual coefficient conjugation.

All 49 anchored polynomials P_rc are rebuilt from the four-factor expressions. Exact ZZ(i) polynomial division verifies P_rc=F Q_rc, including multiplication back. Each positive integer content g_rc divides both P_rc and Q_rc, and multiplication back also verifies scalar normalization. Every nonzero coefficient of both accumulated identities is checked:

sum_j a_j (Q_j/g_j)=d F,

sum_j a_j (P_j/g_j)=d F^2.

There is no restriction to the square subsystem used to obtain the multipliers. Across the 44 cases this checks 2,156 full quotient identities and 88 complete multiplier identities. No modular rank or numerical residual is used to establish them. No exact rank upper-bound claim is accepted or needed.

At an additional exact Gaussian-rational unit triple, nine total fresh active inversions per certificate are checked, and N=S fM is compared with the directly reconstructed original matrix. All 2,156 anchored evaluations exactly verify the squared-modulus bridge. These evaluations supplement the polynomial proof rather than replace it.

The independent totals are 402 successful direct inversions including the six original frozen inversions, 44 singular pole rejections, 5,632 global active inverse entry identities, 2,816 interpolation/matrix-power numerator entry comparisons, and 2,156 exact direct modulus-defect evaluations.

## Why this is an algebraic-closure exclusion

Let K be any algebraically closed characteristic-zero extension of Q(i). All verified identities are literal coefficient identities over Q(i), hence remain identities over K. Since d and every g_rc are nonzero scalars, the second identity places F^2 in the ideal generated by the original P_rc. Therefore no common zero of those P_rc can have F nonzero. Equivalently the ideal becomes the unit ideal after localizing at F, or at xyz times all six original guards. This is stronger than merely finding no finite-field roots or a full-rank numerical matrix.

For the intended complex unit-torus problem, reciprocal-conjugation represents ordinary conjugation, and

P_rc=S^4 (xyz)^2 |f|^4 (|M_rc M_00|^2-|M_r0 M_0c|^2).

An external invertible row/column monomial image of F8 has rank-one squared-entry moduli, so every anchored defect vanishes. No entry of M is divided out, so vanishing entries cannot evade the necessary condition. The complete multiplier identity would then force F=0, contradicting the active original inverse guard. The same argument excludes any nonzero constant-entry-modulus target.

The formal algebraic-closure statement concerns the necessary polynomial system. It does not extend the original Fourier-equivalence conclusion to nonunit moving gains, where reciprocal-conjugation no longer equals ordinary complex conjugation.

## Adversarial controls

For each of the 44 certificates, independent exact checks reject all nine corruptions:

1. Add one to a nonzero multiplier numerator
2. Omit a nonzero multiplier
3. Increase the denominator by one
4. Use the wrong target power
5. Swap two unequal polynomial-row assignments
6. Change the active guard's constant coefficient
7. Omit coefficient conjugation in the reciprocal numerator
8. Reverse the stage product
9. Add an interpolation-invisible perturbation (x+1)(x-2) to B_00, caught by the global identity

An additional nine admission controls reject the wrong stage, wrong branch, ordinary consecutive triple, wraparound consecutive triple, tree-edge triple, repeated edge, negative polynomial-row index, zero numerator scale, and negative denominator. All 405 controls pass.

## Inherited coverage and provenance

The prior 128 coordinate records are reconstructed exactly as (s;7,a,b), s in {1,2}, a=8..15, b=16..23. The current copies of their chart, accepted decision, exact coverage, and report are byte-identical to the established accepted archive Q27_128_THREE_GREEN_INDEPENDENT_ACCEPTED.zip, SHA-256 b1af0b28d642d4e8cbae4e1aa8390fbb49929cd6dafa3d2eaba7868c83d6cff4. All 32 members of that archive were hash-verified as data. These prior proofs are inherited, not rerun.

Each of the six quoted Git report blobs was independently fetched by its recorded SHA-1. The reviewer recomputed Git's SHA-1 of its actual blob header and UTF-8 bytes; every result exactly matches the quoted blob identifier. Every packaged report equals the retrieved blob bytes plus exactly one LF. INHERITED_REPORT_PROVENANCE.json records both the original blob identity and packaged SHA-256, with complete raw tool responses retained. Thus source identity is established despite the literal packaged-byte/blob-hash mismatch; no byte-identical Git-blob claim is made for the normalized copies.

The accepted same-Green, affine, edge12, edge13, and edge14 reports establish precisely the five extra prior tuples (1;8,9,k), k=10..14. The constant-template report contributes no excluded triple and is used only as context; its template obstruction must not be mistaken for a Fourier exclusion.

The independent checker enumerates the full 5,984-coordinate universe, all 48 selected labels, the four inherited labels, and all 44 fresh labels. It verifies exact set equality, no repeated records, no out-of-scope label, no new/prior overlap, and the final counts. The resulting 177-label union is independently reconstructible without executing original or predecessor code; its 133 inherited exclusion theorems remain dependencies rather than new proofs.

## Scope retained

This accepts one complete bounded class through one frozen N=8 witness. It does not accept every same-Green branch, all nonconsecutive triples elsewhere, other witnesses, the remaining seven unproved cyclic consecutive branch-1 triples, four-or-more moving phases, nonunit internal gains, weighted stage sums, a free interstage diagonal, larger N, a full-fiber obstruction, Fourier synthesis, runtime savings, or historical novelty. There is no new canonical research ID. Q27 remains OPEN at priority 50 with 5,807 unclassified triples.
