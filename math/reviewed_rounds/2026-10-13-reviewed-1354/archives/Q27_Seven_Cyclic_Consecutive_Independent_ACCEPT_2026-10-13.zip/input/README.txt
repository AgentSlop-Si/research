Q27 seven cyclic-consecutive slices: author candidate, 13 October 2026 UTC.

Start with REPORT.md, STATUS.json, COVERAGE.json, and SOURCE_PINS.json.
All seven requested labels have literal affine certificates, but accepted
coverage stays 177/5984 until a separate independent review accepts them.

Reproduction requires Python 3 and installed SymPy; no historical program is run.
From this directory:
  python construct_certificates.py
  python check_coverage.py
  python recheck_serialization.py

The constructor writes its own freshly computed certificate and quotient files.
One tuple can be reconstructed with, for example:
  python construct_certificates.py 8,9,15

Certificate Gaussian numbers use two strings [real,imaginary]. Quotient data
contains integer coefficients. Normalization scalar strings may be rational.
Window index j=7*(r-1)+(c-1), with r,c in 1..7. Moving x,y,z correspond to the
three ascending edge labels, not to an unrecorded cycle rotation.

Only the small first-degree coefficient subsystem is selected modulo a prime.
All proof identities are checked over characteristic zero on every coefficient.
No modular absence-of-roots inference is made.

The independent reviewer should freshly reconstruct the chart and defects and
verify both identities, the torus bridge, all six guards, source identities,
coordinate-label disjointness, and controls. Author rechecks do not substitute
for that review. No external table or repository update is authorized here.
