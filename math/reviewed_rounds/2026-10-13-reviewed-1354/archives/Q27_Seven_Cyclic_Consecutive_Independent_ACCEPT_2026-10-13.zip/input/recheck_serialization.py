"""Fresh author-side serialized-evidence checker; not the independent review."""
import json,math,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent

def need(t,m):
 if not t:raise ValueError(m)
def add(a,b):return(a[0]+b[0],a[1]+b[1])
def mul(a,b):return(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def pairs(a):return tuple(map(int,a))
def poly(rows):
 d={tuple(e):pairs(c) for e,c in rows};need(len(d)==len(rows),'repeated exponent');return d

def identity(c,qs):
 out={}
 for t in c['terms']:
  j=t['window_index'];sh=t['shift'];a=pairs(t['numerator'])
  need(0<=j<49 and sum(sh)<=1 and min(sh)>=0,'bad index/shift')
  need(t['row']==j//7+1 and t['column']==j%7+1,'window relabel')
  for e,b in qs[j].items():
   at=tuple(v+w for v,w in zip(e,sh));out[at]=add(out.get(at,(0,0)),mul(a,b))
 for e,b in poly(c['target']).items():out[e]=add(out.get(e,(0,0)),tuple(-v for v in mul(pairs(c['common_denominator']),b)))
 return not any(a!=(0,0) for a in out.values())

def main():
 import sys,copy
 sys.set_int_max_str_digits(1000000)
 stats=[];files=sorted((R/'certificates').glob('s1b1_*.json'));need(len(files)==7,'incomplete candidate')
 expected={tuple(v) for v in json.loads((R/'COVERAGE.json').read_text())['candidate_new_labels']}
 for p in files:
  c=json.loads(p.read_text());edges=c['edges'];need((1,*edges) in expected,'out-of-scope tuple')
  need(c['stage']==c['branch']==1,'wrong stage/branch')
  need(c['chart_sha256']==hashlib.sha256((R/'sources/CHART.json').read_bytes()).hexdigest(),'chart identity')
  qpath=R/'certificates'/('quotients_'+'_'.join(map(str,edges))+'.json')
  qs=[poly(q) for q in json.loads(qpath.read_text())];need(len(qs)==49,'quotient count')
  need(identity(c,qs),'complete serialized identity')
  controls=[]
  a=copy.deepcopy(c);a['terms'][0]['numerator'][0]=str(int(a['terms'][0]['numerator'][0])+1);controls.append(not identity(a,qs))
  a=copy.deepcopy(c);a['terms'].pop();controls.append(not identity(a,qs))
  a=copy.deepcopy(c);a['common_denominator'][0]=str(int(a['common_denominator'][0])+1);controls.append(not identity(a,qs))
  a=copy.deepcopy(c);a['target'][0][1][0]=str(int(a['target'][0][1][0])+1);controls.append(not identity(a,qs))
  a=copy.deepcopy(c);a['terms']=[v for v in a['terms'] if sum(v['shift'])==0];controls.append(not identity(a,qs))
  need(all(controls),'corruption not detected')
  stats.append({'edges':edges,'terms':len(c['terms']),'constant_terms':sum(sum(t['shift'])==0 for t in c['terms']),
   'affine_terms':sum(sum(t['shift'])==1 for t in c['terms']),'complete_identity':True,'corruption_controls_rejected':len(controls),
   'all_49_quotients':True,'full_support_size':len(c['full_expanded_support']),'certificate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
   'quotients_sha256':hashlib.sha256(qpath.read_bytes()).hexdigest()})
 (R/'AUTHOR_RECHECK.json').write_text(json.dumps({'independent_review':False,'results':stats,'accepted_count_changed':False},indent=2)+'\n')
 print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
