"""Fresh exact coordinate-label accounting; inherited proofs are not re-executed."""
import json,itertools,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
prior128={(s,7,a,b) for s in [1,2] for a in range(8,16) for b in range(16,24)}
cyclic={tuple(sorted(8+(k+j)%8 for j in range(3))) for k in range(8)}
nonconsecutive={(1,*t) for t in itertools.combinations(range(8,16),3) if t not in cyclic}
old=prior128|nonconsecutive|{(1,8,9,10)}
new={(1,*t) for t in cyclic if t!=(8,9,10)}
def require(t,m):
 if not t:raise ValueError(m)
require(len(prior128)==128 and len(nonconsecutive)==48,'inherited components')
require(len(old)==177 and len(new)==7 and not(old&new),'coverage overlap/count')
expected={tuple(t) for t in json.loads((R/'sources/NEXT_GATES.json').read_text())['highest_verified_unassigned_source_ready_gate']['remaining_cyclic_consecutive_labels']}
require({t[1:] for t in new}==expected,'dispatch tuple mismatch')
variables=[(s,e) for s in [1,2] for e in range(7,24)]
universe=set(itertools.combinations(variables,3))
require(len(universe)==5984,'universe')
for s,a,b,c in old|new:require(((s,a),(s,b),(s,c)) in universe,'coordinate missing')
result={'accepted_prior_ledger':[list(t) for t in sorted(old)],'candidate_new_labels':[list(t) for t in sorted(new)],
'coordinates':'[stage,edge_a,edge_b,edge_c]; edge order increasing; all three in indicated stage',
'inherited_128_formula':'(s;7,a,b), s=1,2; a=8..15; b=16..23','inherited_nonconsecutive_formula':'all stage1 branch1 triples of 8..15 except the eight cyclic consecutive triples',
'other_inherited_label':[1,8,9,10],'prior_accepted':177,'universe':5984,'prior_unclassified':5807,
'new_provisional':7,'new_accepted':0,'candidate_old_label_overlap':[],
'conditional_union_if_all_seven_independently_accepted':184,'conditional_unclassified_if_all_seven_independently_accepted':5800,
'geometric_slices_pointwise_disjoint':False,'full_34_phase_fiber':'OPEN','priority_unchanged':50,
'qualification':'Only coordinate-label sets are disjoint. All slices pass through the frozen witness. Seven candidate exclusions remain unaccepted pending separate independent review.'}
(R/'COVERAGE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['accepted_prior_ledger','candidate_new_labels']}))
