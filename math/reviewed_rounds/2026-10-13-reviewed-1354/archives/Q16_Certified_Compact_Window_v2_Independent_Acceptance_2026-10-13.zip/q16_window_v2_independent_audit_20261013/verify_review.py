"""Verify immutable v2 review files relative to the extracted archive root."""
from pathlib import Path
import hashlib,json
here=Path(__file__).resolve().parent;root=here.parent
seal=json.loads((here/'REVIEW_SEAL.json').read_text())
manifest=(here/'REVIEW_MANIFEST.json').read_bytes()
assert hashlib.sha256(manifest).hexdigest()==seal['manifest_sha256']
for item in json.loads(manifest)['files']:
 data=(root/item['path']).read_bytes()
 assert len(data)==item['bytes'],item['path']
 assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
print('PASS sealed v2 independent review; scoped ACCEPT; v1 split verdict preserved')
