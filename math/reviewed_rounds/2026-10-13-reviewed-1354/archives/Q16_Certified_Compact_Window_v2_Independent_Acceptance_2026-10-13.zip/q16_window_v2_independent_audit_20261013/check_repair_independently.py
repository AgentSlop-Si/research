"""Independent v2 accounting regression; never constructs gigantic windows."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import ast,hashlib,importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
P1=BASE/'q16_certified_window_20261013/src/compact_window.py'
P2=BASE/'q16_certified_window_v2_20261013/src/compact_window.py'
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
v1=load('review_frozen_v1',P1);v2=load('review_frozen_v2',P2)
checks=[];rows=[]
def check(name,condition,detail=None):
 if not condition:raise AssertionError((name,detail))
 checks.append({'name':name,'passed':True,'detail':detail})
def reject(call):
 try:call()
 except ValueError:return True
 return False
check('frozen_v1_source_pin',hashlib.sha256(P1.read_bytes()).hexdigest()=='b33451d853b5f136453031be291aa759f08d09f7aeedd9d6c4de2623ef63adee')
check('frozen_v2_source_pin',hashlib.sha256(P2.read_bytes()).hexdigest()=='e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59')

# Check numerical code identity structurally, excluding location metadata.
def definitions(p):return {n.name:n for n in ast.parse(p.read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
a,b=definitions(P1),definitions(P2)
changed=[]
for name in a:
 if ast.dump(a[name],include_attributes=False)!=ast.dump(b[name],include_attributes=False):changed.append(name)
check('only_expected_definitions_changed',set(changed)=={'Ledger','WindowSpec','theorem_spec','prepare_window'},changed)
check('only_beta_validator_added',set(b)-set(a)=={'validate_beta'})
def prep_tail(n):
 for i,s in enumerate(n.body):
  if isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='M' for t in s.targets):return n.body[i:]
 raise AssertionError('M setup missing')
check('preparation_numeric_tail_ast_identical',ast.dump(ast.Module(body=prep_tail(a['prepare_window']),type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=prep_tail(b['prepare_window']),type_ignores=[]),include_attributes=False))

class AuditedLedger(v2.Ledger):
 def __post_init__(self):pass
 def record(self,kind,inputs,output):
  if not hasattr(self,'trace'):self.trace=[]
  sizes=[max(1,abs(x).bit_length()) for x in (*inputs,output)]
  expected=16*(sum(sizes)+2)**2
  before=self.arithmetic_bit_work_upper;stored=self.cumulative_integer_bits
  value=super().record(kind,inputs,output)
  assert self.arithmetic_bit_work_upper-before==expected
  assert self.cumulative_integer_bits-stored==sizes[-1]+1
  self.trace.append({'kind':kind,'operand_and_result_widths':sizes,'charged_bit_work':expected})
  return value

class Intercepted(Exception):pass
def before_coefficients(module,spec,ledger=None):
 original=module.exact_box_power;seen=[]
 def intercept(ell,r,got):
  seen.append({'report':got.report(),'identity':got is ledger if ledger is not None else True})
  raise Intercepted
 module.exact_box_power=intercept
 try:
  try:module.prepare_window(spec,ledger)
  except Intercepted:pass
  else:raise AssertionError('unexpected coefficient construction')
 finally:module.exact_box_power=original
 assert len(seen)==1 and seen[0]['identity']
 return seen[0]['report']

expected_events={'parameter_input':6,'window_validation_call':1,'beta_validation_call':1,'multiply':12,'subtract':6,'add':4,'floor_divide':3,'modulo':1,'binary_power':2}
ns=(16,128,4096,65536,131072)
for family,m,B in [('dyadic',46,1<<35),('odd_denominator',100,1<<51)]:
 previous_work=previous_storage=0
 baseline_report=None
 for n in ns:
  beta=F(1,4)-F(1,1<<n) if family=='dyadic' else F(1,100)-F(1,3*(1<<n))
  fields=(1<<m,B,2*m+1,16*m+16,beta)
  oldspec=v1.WindowSpec(*fields);spec=v2.WindowSpec(*fields)
  old_report=before_coefficients(v1,oldspec)
  if baseline_report is None:baseline_report=old_report
  check(f'{family}_{n}_v1_ledger_ignores_beta_width',old_report==baseline_report)
  L=AuditedLedger();returned=spec.validate(L);report=L.report()
  parameter_values=fields[:4]+(beta.numerator,beta.denominator)
  bit_sizes=[max(1,abs(x).bit_length()) for x in parameter_values]
  check(f'{family}_{n}_validation_returns_same_spec',returned is spec)
  check(f'{family}_{n}_all_parameter_widths_counted',report['parameter_input_bits']==sum(bit_sizes) and report['max_parameter_bits']==max(bit_sizes))
  check(f'{family}_{n}_wide_fields_observed',report['max_observed_integer_bits']>=max(beta.numerator.bit_length(),beta.denominator.bit_length()))
  check(f'{family}_{n}_event_inventory',dict(L.operations)==expected_events and sum(L.operations.values())==36,dict(L.operations))
  E=sum(L.operations.values())+256; envelope_width=report['max_observed_integer_bits']+E.bit_length()+2
  check(f'{family}_{n}_control_envelope_recomputed',report['bookkeeping_bit_work_upper']==512*E*envelope_width**2 and report['total_bit_work_upper']==report['arithmetic_bit_work_upper']+512*E*envelope_width**2)
  produced=sum(x['operand_and_result_widths'][-1]+1 for x in L.trace)
  check(f'{family}_{n}_cumulative_storage_recomputed',report['cumulative_storage_upper_bits']==produced+512*E*envelope_width)
  check(f'{family}_{n}_work_and_storage_grow',report['total_bit_work_upper']>previous_work and report['cumulative_storage_upper_bits']>previous_storage)
  previous_work=report['total_bit_work_upper'];previous_storage=report['cumulative_storage_upper_bits']
  # Actual public standalone entry with no supplied ledger must charge the same prefix.
  standalone=before_coefficients(v2,spec)
  check(f'{family}_{n}_fresh_prepare_prefix_matches_validation',standalone==report)
  check(f'{family}_{n}_no_large_numerical_work',report['allocated_slots']==0 and 'coefficient_cell' not in report['operations'] and 'sine_evaluation' not in report['operations'])
  twice=AuditedLedger();spec.validate(twice);first=twice.report();spec.validate(twice);second=twice.report()
  check(f'{family}_{n}_revalidation_accumulates',second['parameter_input_bits']==2*first['parameter_input_bits'] and second['arithmetic_bit_work_upper']==2*first['arithmetic_bit_work_upper'] and second['operations']=={k:2*v for k,v in first['operations'].items()})
  shared=AuditedLedger();derived=v2.theorem_spec(m,beta,shared);prior=shared.report();after=before_coefficients(v2,derived,shared)
  check(f'{family}_{n}_shared_identity_and_parameters',derived==spec)
  check(f'{family}_{n}_shared_no_reset',after['arithmetic_bit_work_upper']==prior['arithmetic_bit_work_upper']+report['arithmetic_bit_work_upper'] and after['parameter_input_bits']==prior['parameter_input_bits']+report['parameter_input_bits'])
  check(f'{family}_{n}_shared_event_additivity',after['operations']==dict(Counter(prior['operations'])+Counter(report['operations'])))
  check(f'{family}_{n}_explicit_frontend_origin',derived.origin=='ebeta_frontend_sparse_parameters')
  if family=='odd_denominator':check(f'{family}_{n}_outer_beta_guard_not_inferred',derived.beta*derived.m<2 and beta.denominator%3==0 and beta.denominator%5==0)
  rows.append({'family':family,'n':n,'m':m,'beta_numerator_bits':beta.numerator.bit_length(),'beta_denominator_bits':beta.denominator.bit_length(),'v1_standalone_prefix_report':old_report,'v2_validation_and_standalone_prefix_report':report,'v2_shared_prior_report':prior,'v2_shared_after_report':after,'validation_trace':L.trace})

# Front-end semantics plus unchanged domain rejections.
front=v2.theorem_spec(100,F(1,100))
check('outer_dispatch_is_separate',front.beta*front.m==1 and front.origin=='ebeta_frontend_sparse_parameters')
for value in (None,True,0.25,0,F(0),F(-1,100),F(1,2),F(1),F(1<<10000)):
 check(f'reject_invalid_beta_{type(value).__name__}_{len(checks)}',reject(lambda v=value:v2.theorem_spec(46,v)))
for fields in [(True,4,1,8),(64,True,1,8),(64,4,True,8),(64,4,1,True),(64,4,1,8.0),(63,4,1,8),(64,3,1,8),(64,4,2,8)]:
 check(f'reject_invalid_spec_{len(checks)}',reject(lambda f=fields:v2.WindowSpec(*f).validate()))
# Reduced validation contains no beta event and is charged through preparation.
reduced=v2.WindowSpec(64,4,1,8);L=v2.Ledger();reduced.validate(L)
check('reduced_fixture_validation_accounted',L.operations['window_validation_call']==1 and L.operations['parameter_input']==4 and L.operations['beta_validation_call']==0)
check('reduced_prepare_prefix_matches_validation',before_coefficients(v2,reduced)==L.report())
# Crossover remains parameter-only.
first=None
for m in range(1,47):
 try:s=v2.theorem_spec(m,F(1,4))
 except ValueError:continue
 first=m;break
check('same_beta_quarter_first_frontend_exponent',first==46 and s.M==70368744177664 and s.W==51127290691399)
result={'status':'PASS','check_count':len(checks),'checks':checks,'witness_families':rows,'large_preparations_executed':False,'historical_code_executed':False,'v1_new_candidate_validation_only_executed':True,'v1_modified':False,'v2_modified':False}
(ROOT/'independent_repair_results.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',len(checks),'independent v2 repair checks;',len(rows),'growing-width witnesses; no gigantic preparation')
