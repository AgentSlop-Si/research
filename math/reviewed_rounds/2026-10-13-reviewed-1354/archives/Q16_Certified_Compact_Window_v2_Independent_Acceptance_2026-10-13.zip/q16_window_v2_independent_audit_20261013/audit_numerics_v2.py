"""New independent review checks. Imports only the pinned new candidate.
The fresh rational oracle uses pi=8 atan(1/3)+4 atan(1/7),
exact rational uncentered sine polynomials, and a factorial remainder.
"""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
from collections import Counter
from functools import lru_cache
import ast, hashlib, importlib.util, json, sys, time, types
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'q16_certified_window_v2_20261013/src/compact_window.py'
sys.path.insert(0,str(SOURCE.parent))
import compact_window as c
checks=[]; totals=Counter(); started=time.time()
def check(name,yes,details=None):
    if not yes: raise AssertionError((name,details))
    checks.append({'name':name,'passed':True,'details':details})
def rejected(fn,exc=ValueError):
    try:fn()
    except exc:return True
    return False
def bounds(a): return F(a.lo,1<<a.bits),F(a.hi,1<<a.bits)
def encloses(a,b): return a[0]<=b[0]<=b[1]<=a[1]
def mul(a,b):
    t=[x*y for x in a for y in b];return min(t),max(t)
def div(a,b):
    assert not b[0]<=0<=b[1]
    t=[x/y for x in a for y in b];return min(t),max(t)
def plus(a,b):return a[0]+b[0],a[1]+b[1]
def scaled(a,s):return min(a[0]*s,a[1]*s),max(a[0]*s,a[1]*s)
class Oracle:
    def __init__(self,bits=144):
        self.bits=bits
        n=bits//2+16
        def arctan(q):
            x=sum((F((-1)**k,(2*k+1)*q**(2*k+1)) for k in range(n)),F())
            z=F(1,(2*n+1)*q**(2*n+1))
            return (x-z,x) if n%2 else (x,x+z)
        pi=plus(scaled(arctan(3),8),scaled(arctan(7),4))
        scale=1<<bits
        self.pi=(F((pi[0]*scale).__floor__(),scale),F((pi[1]*scale).__ceil__(),scale))
        self.n=bits//2+32
        self.tail=F(7**(2*self.n+1),factorial(2*self.n+1))
    def sin(self,p,q):
        return self._sin(p%(2*q),q)
    @lru_cache(None)
    def _sin(self,p,q):
        # No folding into a quadrant, term-interval recurrence, or production imports.
        p=p%(2*q)
        if p%q==0:return F(0),F(0)
        if (2*p)%q==0 and p*2//q%2:
            z=F(1 if p<q else -1);return z,z
        angle=scaled(self.pi,F(p,q));x=sum(angle,F())/2
        radius=(angle[1]-angle[0])/2
        term=x;value=x
        for k in range(1,self.n):
            term*= -x*x/F(2*k*(2*k+1));value+=term
        e=self.tail+radius
        return value-e,value+e
    def grid(self,a):
        S=1<<self.bits
        return F((a[0]*S).__floor__(),S),F((a[1]*S).__ceil__(),S)
    def d(self,t,M,H):
        if t%M==0:return F(2*H+1),F(2*H+1)
        a=div(self.sin((2*H+1)*t,M),self.sin(t,M))
        return self.grid((max(F(-(2*H+1)),a[0]),min(F(2*H+1),a[1])))
    def phi(self,j,M,ell,r):
        if j%M==0:return F(1),F(1)
        a=div(self.sin(ell*j,M),scaled(self.sin(j,M),ell))
        small=F(0) if a[0]<=0<=a[1] else min(abs(a[0]),abs(a[1]))
        big=max(abs(a[0]),abs(a[1]))
        return self.grid((small**(2*r),min(F(1),big**(2*r))))

def brute_coeff(ell,r):
    a=[1]
    for _ in range(2*r):
        b=[0]*(len(a)+ell-1)
        for i,x in enumerate(a):
            for j in range(ell):b[i+j]+=x
        a=b
    return tuple(a)

# Retained immutable source and archive pins.
check('candidate_source_pin',hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59')
archive=ROOT.parent/'Q16_Certified_Compact_Window_Candidate_v2_2026-10-13.zip'
check('candidate_archive_pin',hashlib.sha256(archive.read_bytes()).hexdigest()=='e587382179dd843136053322db5ed1a15165066d1e7330b9fb036e14c3fb4c7e')
tr=ast.parse(SOURCE.read_text())
check('no_floating_arithmetic_or_hidden_io',not any(isinstance(n,ast.Constant) and isinstance(n.value,(float,complex)) or isinstance(n,ast.BinOp) and isinstance(n.op,ast.Div) for n in ast.walk(tr)) and {n.module for n in ast.walk(tr) if isinstance(n,ast.ImportFrom)}=={'dataclasses','fractions','collections'})

# Exhaustive signed interval corner checks and nearest-even ties.
L=c.Ledger();nq=0
for bits in (0,1,3,8):
 for alo in range(-4,5):
  for ahi in range(alo,5):
   for blo in range(-4,5):
    for bhi in range(blo,5):
     if blo<=0<=bhi:continue
     a=c.Interval(alo,ahi,bits);b=c.Interval(blo,bhi,bits)
     assert encloses(bounds(c.quotient(a,b,L)),div(bounds(a),bounds(b)))
     nq+=1
check('signed_quotient_exhaustive',True,{'interval_pairs':nq});totals['quotient_pairs']=nq
for den in range(1,34):
 for num in range(-1024,1025):assert c.nearest_even(num,den,L)==round(F(num,den))
check('signed_nearest_even_exhaustive',True,{'pairs':33*2049});totals['rounding_pairs']=33*2049
for b1 in range(9):
 for b2 in range(9):
  for lo in range(-5,6):
   a=c.Interval(lo,lo+2,b1);assert encloses(bounds(c.quantize(a,b2,L)),bounds(a))
check('outward_quantization_signed',True,{'interval_pairs':9*9*11})
for lo in range(-16,17):
 for hi in range(lo,17):
  for p in (2,4,6,10):
   a=c.Interval(lo,hi,4);ab=bounds(a)
   low=F(0) if lo<=0<=hi else min(abs(ab[0]),abs(ab[1]))**p
   high=max(abs(ab[0]),abs(ab[1]))**p
   assert encloses(bounds(c.even_power(a,p,L)),(low,high))
check('even_power_zero_crossing_and_signs',True,{'interval_exponents':2244})

# Independent rational scalar comparisons, including minimum supported K.
O=Oracle(144)
args=set([(1,10**12),(10**12-1,10**12),(10**12+1,10**12),(2*10**12-1,10**12),(-1,10**12)])
for q in (1,2,3,4,5,7,8,13,16,31):
 for p in range(-2*q,2*q+1):args.add((p,q))
for K in (16,17,24,64,96):
 S=c.Scalar(K,c.Ledger())
 assert encloses(bounds(S.pi),O.pi)
 for p,q in sorted(args):
  out=S.sin_pi(p,q);oracle=O.sin(p,q)
  assert encloses(bounds(out),oracle),(K,p,q,out)
  assert out.hi-out.lo<=64*(K+9)
  totals['sine_enclosures']+=1
check('scalar_alternate_pi_exact_rational_reference',True,dict(totals))
# All residues across small odd and dyadic moduli, many H values, and +/- wraps.
S=c.Scalar(96,c.Ledger())
for M in (1,2,3,7,8,16,31,64):
 for H in (0,1,3,M//2,M,M+1):
  for t in range(-M-1,M+2):
   D=c.dirichlet(t,M,H,S,64,S.L)
   assert encloses(bounds(D),O.d(t,M,H)),(M,H,t)
   totals['dirichlet_enclosures']+=1
check('dirichlet_singular_odd_dyadic_wrap_and_H',True,{'comparisons':totals['dirichlet_enclosures']})

# Fresh complete window cases spanning minimal M, maximal B/support and low P.
window_cases=[]
for M,B,r,P in [(64,4,1,8),(128,8,1,8),(256,16,1,8),(256,4,4,8),(512,8,4,16),(1024,16,4,8)]:
 spec=c.WindowSpec(M,B,r,P);w=c.prepare_window(spec)
 co=brute_coeff(spec.ell,r)
 assert w.coefficients.numerators==co
 C=(F(1),F(1))
 for j in range(1,spec.g+1):C=plus(C,scaled(O.phi(j,M,spec.ell,r),2))
 assert encloses(bounds(w.C),C)
 for tap in w.taps:
  target=scaled(div(O.d(tap.t,M,spec.H),C),F(M*co[tap.t+w.coefficients.radius],spec.ell**(2*r)))
  assert encloses(bounds(tap.enclosure),target),(spec,tap.t)
  val=F(tap.numerator,1<<P)
  assert max(abs(val-target[0]),abs(val-target[1]))<=F(1,1<<P)
  assert tap.certified_error_grid_units<=16
  totals['fresh_taps']+=1
 assert len({t.t%M for t in w.taps})==spec.W
 assert len(w.taps)==spec.W and w.taps[0].t==-w.coefficients.radius and w.taps[-1].t==w.coefficients.radius
 assert w.ledger['operations']['coefficient_cell']==sum(1+p*(spec.ell-1) for p in range(1,2*r+1))
 window_cases.append({'M':M,'B':B,'r':r,'P':P,'W':spec.W,'max_error_units':w.budget['max_tap_error_grid_units']})
 print('fresh window PASS',M,B,r,P,spec.W,flush=True)
check('fresh_windows_all_taps_and_coefficients',True,window_cases)

# Independent exhaustive component guard predicates and theorem ceiling oracle.
valid=invalid=0
for m in range(4,11):
 for b in range(2,m+2):
  B=1<<b;M=1<<m
  for r in range(1,20):
   want=(M%B==0 and M//B>=4 and 2*r*(8*B-1)+1<M)
   spec=c.WindowSpec(M,B,r,8)
   got=not rejected(spec.validate)
   assert got==want
   valid+=got;invalid+=not got
check('component_guard_grid',True,{'valid':valid,'invalid':invalid})
first={}
for beta in (F(1,100),F(1,4),F(2,5),F(49,100)):
 for m in range(1,301):
  # Direct Fraction floor/ceil instead of the candidate numerator formulas.
  B=2**((F(1,2)+beta)*m).__ceil__();k=2**(2*beta*m).__ceil__();M=2**m
  W=2*(2*m+1)*(8*B-1)+1
  want=B>=4 and M%B==0 and M//B>=4 and B>=4096*k and W<M
  try: s=c.theorem_spec(m,beta);got=True
  except ValueError:got=False
  assert got==want
  if got:
   assert (s.B,s.r,s.P)==(B,2*m+1,16*m+16)
   first.setdefault(str(beta),m)
check('theorem_frontend_guard_enumeration',True,{'first_through_300':first})
assert first['1/4']==46
s=c.theorem_spec(46,F(1,4));check('beta_quarter_huge_crossover',s.M==70368744177664,{'M':s.M,'B':s.B,'W':s.W,'parameter_only':True})
s=c.theorem_spec(100,F(1,100));check('frontend_not_outer_transfer_guard',s.beta*s.m==1,{'outer_transfer_beta_m_ge_2':False,'component_frontend_valid':True})

# In-memory mutants preserve original source and are compared to fresh checks.
source=SOURCE.read_text();mutations=[]
def mutant(old,new):
 assert source.count(old)==1,(old,source.count(old))
 m=types.ModuleType('mutation_'+str(len(mutations)));sys.modules[m.__name__]=m
 exec(compile(source.replace(old,new),'<isolated-candidate-mutation>','exec'),m.__dict__)
 return m
m=mutant('L.mul(L.mul(L.mul(L.mul(M,a),d),Cscale),scale)','L.mul(L.mul(L.mul(L.mul(1,a),d),Cscale),scale)')
w=m.prepare_window(m.WindowSpec(64,4,1,8));mid=w.taps[len(w.taps)//2]
correct=c.prepare_window(c.WindowSpec(64,4,1,8));good=correct.taps[len(correct.taps)//2]
assert not encloses(bounds(mid.enclosure),bounds(good.enclosure));mutations.append('missing_M_factor_rejected')
m=mutant('value=L.mul(n,L.shift(bits))','value=L.mul(L.sub(n,1),L.shift(bits))')
assert bounds(m.dirichlet(0,64,12,m.Scalar(64,m.Ledger()),32,m.Ledger()))!=(F(25),F(25));mutations.append('singular_limit_off_by_one_rejected')
m=mutant('if a>q: a=L.sub(L.mul(2,q),a); sign=-1','if a>q: a=L.sub(L.mul(2,q),a); sign=1')
assert not encloses(bounds(m.Scalar(64,m.Ledger()).sin_pi(-1,3)),O.sin(-1,3));mutations.append('negative_quadrant_sign_rejected')
m=mutant('previous=L.sub(i,ell)','previous=L.sub(i,ell-1)')
assert m.exact_box_power(4,2).numerators!=brute_coeff(4,2);mutations.append('box_boundary_off_by_one_rejected')
m=mutant('if W>=self.M:','if W>2*self.M:')
assert not rejected(lambda:m.WindowSpec(64,4,2,8).validate());mutations.append('no_wrap_guard_loss_detected')
m=mutant('twice==d and a%2','twice==d and not a%2')
assert m.nearest_even(-1,2,m.Ledger())!=round(F(-1,2));mutations.append('signed_tie_even_mutation_rejected')
check('six_targeted_mutations_detected',True,mutations)

# Public API validation boundaries not exercised by original tests.
for fn in [lambda:c.WindowSpec(64,4,True,8).validate(),lambda:c.WindowSpec(64,4,1,True).validate(),lambda:c.WindowSpec(64,4,1,8.0).validate(),lambda:c.theorem_spec(True,F(1,4)),lambda:c.theorem_spec(46,0.25),lambda:c.Scalar(15,c.Ledger()),lambda:c.Scalar(True,c.Ledger()),lambda:c.Interval(0,0,-1),lambda:c.exact_box_power(2,False)]:assert rejected(fn)
check('additional_invalid_type_and_precision_inputs',True,{'cases':9})

out={'status':'PASS','candidate_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'checks':checks,'group_count':len(checks),'totals':dict(totals),'elapsed_seconds':round(time.time()-started,3),'historical_code_executed':False,'candidate_modified':False}
(ROOT/'independent_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
