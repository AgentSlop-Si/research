# Independent regression scope for the Q16 window ledger repair

This review preserves the sealed v1 split verdict and tests a separately frozen producer revision. It does not implement the producer repair.

1. Verify the new archive and source pins; compare the source and documentation diff with v1.
2. Inspect validation data widths, all beta-bearing parameter arithmetic, timing of ledger initialization, ledger reuse and the revised control/storage envelope.
3. Reproduce the original missing-width defect through v1's actual prepare_window entry, intercepting immediately before coefficient construction. No gigantic coefficient allocation occurs.
4. Apply the same interception to v2 for two constant-window families with growing exact rational encodings:
   - beta_n = 1/4 - 2^-n; m=46, B=2^35, r=93, P=752.
   - beta_n = 1/100 - 1/(3*2^n); m=100, B=2^51, r=201, P=1616. This adds odd denominator factors.
   - n = 16, 128, 4096, 65536 and 131072.
5. Check that the standalone ledger sees every input integer width, increases its work/storage allowances with beta width, and has no coefficient/scalar events before interception.
6. Check direct validation, repeated validation and shared theorem_spec/preparation ledgers. No validation charge may be reset or silently depend on prior parameter generation.
7. Retain the exact front-end versus outer-dispatch distinction, including beta*m<2 examples. Confirm that no outer-transfer parameters or full-pipeline labels are inferred.
8. Replay the frozen candidate's tests in a separate copy; compare exact numerical C/tap/budget data against v1, treating elapsed metadata and intentionally changed ledgers separately.
9. Reuse the previously sealed independent numerical oracle against the repaired source without altering its mathematics; add any new boundaries suggested by the frozen diff.
10. Issue a new source-pinned verdict. A successful cost repair will not enlarge the accepted component scope, change the giant crossover or certify Python runtime behavior.
