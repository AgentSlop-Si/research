#!/usr/bin/env python3
"""Independent controls, written for this review. No candidate code imported/read."""
import json, random, hashlib
from pathlib import Path
from collections import defaultdict

COUNTS=defaultdict(int)
RNG=random.Random(202610131039)

def rev(x,t):
    y=0
    for _ in range(t): y=2*y+(x&1); x>>=1
    return y

def gamma(x):
    total=0; prefix=0
    for c in bin(x)[2:]:
        if c=='1': total+=prefix
        prefix=2*prefix+int(c)
    return total

def root(p,N):
    for a in range(1,p):
        w=pow(a,(p-1)//N,p)
        if pow(w,N,p)==1 and (N==1 or pow(w,N//2,p)!=1): return w
    raise AssertionError('root unavailable')

def ab(b,m):
    a=[1]
    for k in range(1,m+1):
        a.append(2**k if k<b else sum(a[k-j] for j in range(1,b+1)))
    return a[m]

def setup(n,b,p):
    N=1<<n; w=root(p,N)
    R=set(range(0,N,1<<b)); A={s for s in range(N) if '0'*b not in format(s,f'0{n}b')}
    T=R|A; F=set(range(N))-T
    edges={s:[((2*s)%N,1),((2*s+1)%N,pow(w,s,p))] for s in range(N)}
    return N,w,R,A,T,F,edges

def step(v,edges,p,allowed=None):
    out=defaultdict(int)
    for s,x in v.items():
        for y,c in edges[s]:
            if allowed is None or y in allowed: out[y]=(out[y]+c*x)%p
    return {y:x for y,x in out.items() if x}

def returns(T,F,edges,p,L):
    # Enumerate individual paths, retaining multiplicity as an independent uniqueness check.
    ks=[{} for _ in range(L+2)]
    for s in sorted(T):
        frontier=[(s,1)]
        for t in range(1,L+2):
            nxt=[]
            for u,a in frontier:
                for y,c in edges[u]:
                    if y in T:
                        assert (y,s) not in ks[t], ('nonunique path',s,t,y)
                        ks[t][y,s]=a*c%p
                    else: nxt.append((y,a*c%p))
            frontier=nxt
        assert not frontier
    return ks

def mul(M,v,p):
    out=defaultdict(int)
    for (y,s),a in M.items(): out[y]=(out[y]+a*v.get(s,0))%p
    return {y:a for y,a in out.items() if a}

def rank(M,p):
    rows=[row[:] for row in M]; rank=0
    if not rows:return 0
    for c in range(len(rows[0])):
        pivot=next((i for i in range(rank,len(rows)) if rows[i][c]%p),None)
        if pivot is None:continue
        rows[pivot],rows[rank]=rows[rank],rows[pivot]
        q=pow(rows[rank][c],-1,p)
        rows[rank]=[q*a%p for a in rows[rank]]
        for i in range(rank+1,len(rows)):
            q=rows[i][c]
            rows[i]=[(a-q*b)%p for a,b in zip(rows[i],rows[rank])]
        rank+=1
        if rank==len(rows):break
    return rank

def circuit(n,b,p,w,u,edges,T):
    N=1<<n; L=n-b
    result=[dict(u)]
    result.append({y:(-a)%p for y,a in step(u,edges,p,T).items()})
    if not L:return result
    r=1<<L; eta=pow(w,1<<b,p)
    sedges={j:[((2*j)%r,1),((2*j+1)%r,pow(eta,j,p))] for j in range(r)}
    v={j:u.get(j<<b,0) for j in range(r)}
    for t in range(1,L+1):
        v=step(v,sedges,p)
        if t>=2:
            out={}
            for a0 in range(r):
                z=a0%(1<<t); bits=format(z,f'0{t}b')
                if bits[0]=='1' and t>=b+1 and bits.find('0'*b)==t-b:
                    y=((a0-z)<<b)+z
                    assert y not in out
                    out[y]=(-pow(w,gamma(z),p)*pow(eta,-gamma(z),p)*v.get(a0,0))%p
            result.append({y:a for y,a in out.items() if a})
    out={}
    for z in range(1<<(L-1)):
        if '0'*b in format(z,f'0{L-1}b') and L>1:continue
        for e in (0,1):
            y=r+2*z+e; q=y//2
            out[y]=(-pow(w,gamma(y),p)*pow(eta,-gamma(q),p)*v.get(q,0))%p
    result.append({y:a for y,a in out.items() if a})
    return result

def direct_action(ks,u,p):
    return [dict(u)]+[{y:(-a)%p for y,a in mul(k,u,p).items()} for k in ks[1:]]

def add(a,b,p):
    c=defaultdict(int,a)
    for y,v in b.items():c[y]=(c[y]+v)%p
    return {y:v for y,v in c.items() if v}

def schur_check(n,b,p,ctx,ks,x):
    N,w,R,A,T,F,edges=ctx
    # Direct all-state trajectory serves as an independent source/solve/recovery target.
    direct=[x]
    for d in range(n):direct.append(step(direct[-1],edges,p))
    rhs=[{s:x[s] for s in T if x.get(s,0)}]
    free={s:x[s] for s in F if x.get(s,0)}
    for d in range(1,n+1):
        moved=step(free,edges,p)
        rhs.append({s:v for s,v in moved.items() if s in T})
        free={s:v for s,v in moved.items() if s in F}
    yt=[]
    for d in range(n+1):
        z=rhs[d]
        for t in range(1,min(d,len(ks)-1)+1):z=add(z,mul(ks[t],yt[d-t],p),p)
        yt.append(z)
        assert z=={s:v for s,v in direct[d].items() if s in T}
        COUNTS['schur_coefficient_identities']+=1
    yf={s:x[s] for s in F if x.get(s,0)}
    for d in range(n+1):
        assert yf=={s:v for s,v in direct[d].items() if s in F}
        COUNTS['recovery_coefficient_identities']+=1
        yf=step(add(yf,yt[d],p),edges,p,F)
    for y in range(N):
        answer=pow(w,gamma(y),p)*sum(v*pow(w,s*rev(y,n),p) for s,v in x.items())%p
        assert answer==direct[n].get(y,0)
        COUNTS['full_Fourier_values']+=1
    COUNTS['fresh_full_input_vectors']+=1

def one_case(n,b,p):
    ctx=setup(n,b,p);N,w,R,A,T,F,edges=ctx;L=n-b
    assert not R&A and len(T)==len(R)+len(A)
    ks=returns(T,F,edges,p,L)
    # Independently check the free horizon from every free basis state.
    for s in F:
        v={s:1}
        for _ in range(L):v=step(v,edges,p,F)
        assert not v
        COUNTS['free_basis_horizon_checks']+=1
    assert len(ks[1])==(len(R)+2*len(A) if L else 2*N)
    if L:
        r=1<<L;h=L+1;eta=pow(w,1<<b,p);a=ab(b,L-1)
        assert sum(map(len,ks[2:]))==r*(1+sum(ab(b,j) for j in range(L)))
        seen=set()
        for k in ks[1:]:
            assert not seen&k.keys();seen.update(k)
        V=[v for v in range(r//2) if L==1 or '0'*b not in format(v,f'0{L-1}b')]
        W=[r+2*v+e for v in V for e in (0,1)]
        assert len(V)==a and set(ks[h])=={(y,s) for y in W for s in R}
        for (y,s),val in ks[h].items():
            v=(y-r)//2;j=s>>b
            expected=pow(w,gamma(y),p)*pow(eta,j*(1+2*rev(v,L-1)),p)%p
            assert expected==val
            COUNTS['top_entry_phase_checks']+=1
        H=[[ks[h][y,s] for s in sorted(R)] for y in W]
        assert rank(H,p)==a
        COUNTS['exact_top_rank_checks']+=1
        zs=list(range(1,p)) if p<=41 else sorted({1,2,p-1,w,pow(w,3,p)})
        for z in zs:
            scalar=defaultdict(int)
            for t,k in enumerate(ks):
                for e,v in k.items():scalar[e]=(scalar[e]+pow(z,t,p)*v)%p
            assert sum(v!=0 for v in scalar.values())==len(seen)
            for s in T:scalar[s,s]=(1-scalar[s,s])%p
            assert sum(v!=0 for v in scalar.values())>=2*a*(r-1)
            COUNTS['nonzero_scalar_specializations']+=1
        # Fold formula, arbitrary inputs, including a top-kernel cancellation vector.
        us=[[RNG.randrange(p) for _ in range(r)], [1]*r]
        for ur in us:
            m=r//2;theta=eta*eta%p
            g=[pow(eta,j,p)*(ur[j]-ur[j+m])%p for j in range(m)]
            hu=mul(ks[h],{j<<b:v for j,v in enumerate(ur)},p)
            for y in W:
                v=(y-r)//2
                val=pow(w,gamma(y),p)*sum(g[j]*pow(theta,j*rev(v,L-1),p) for j in range(m))%p
                assert val==hu.get(y,0)
                COUNTS['fold_output_checks']+=1
        assert not mul(ks[h],{s:1 for s in R},p)
        COUNTS['input_cancellation_guards']+=1
        assert len(ks[h])>=1<<(2*L-(L-1)//b)
        COUNTS['fill_in_cases']+=1
    else:
        assert not F and T==set(range(N));COUNTS['empty_free_boundary_cases']+=1
    us=[{s:RNG.randrange(p) for s in T} for _ in range(3)]
    us=[{s:v for s,v in u.items() if v} for u in us]
    if n<=6:
        us += [{s:1} for s in T]
        COUNTS['all_basis_action_vectors']+=len(T)
    for u in us:
        assert circuit(n,b,p,w,u,edges,T)==direct_action(ks,u,p), (n,b,p,u)
        COUNTS['constant_action_vectors']+=1
    if n<=7:
        xs=[{s:RNG.randrange(p) for s in range(N)}]
        if n<=4:xs += [{s:1} for s in range(N)]
        for x in xs:schur_check(n,b,p,ctx,ks,{s:v for s,v in x.items() if v})
    COUNTS['parameter_cases']+=1
    return {'p':p,'n':n,'b':b,'N':N,'retained':len(T),'free':len(F),'excursion_entries':sum(map(len,ks[2:])),'top_entries':len(ks[-1]) if L else None}


def main():
    cases=[]
    for p in [3,5,17,41,97,193,257,65537]:
        for n in range(1,11):
            if (p-1)%(1<<n):continue
            for b in range(1,n+1):cases.append(one_case(n,b,p))
    for b in range(1,12):
        for m in range(0,20):
            a=ab(b,m);assert a>=1<<(m-m//b)
            if m<=12:assert a==sum('0'*b not in format(v,f'0{m}b') for v in range(1<<m)) if m else a==1
            COUNTS['word_count_bounds']+=1
    # Deliberately wrong trailing-bit frequency must fail at the smallest eliminated case.
    N,w,R,A,T,F,edges=setup(2,1,17);ks=returns(T,F,edges,17,1);eta=w*w%17
    bad=0
    for (y,s),v in ks[2].items():
        false=pow(w,gamma(y),17)*pow(eta,(s>>1)*rev(y%2,1),17)%17
        bad+=false!=v
    assert bad;COUNTS['wrong_trailing_index_detected_entries']=bad
    # Explicit branching and composite Fourier minor witnesses.
    N,w,R,A,T,F,edges=setup(3,1,17)
    incoming=[(s,c) for s in F for y,c in edges[s] if y==3]
    assert {s for s,c in incoming}=={1,5}
    assert pow(w,0*0,17)*pow(w,4*2,17)-pow(w,0*2,17)*pow(w,4*0,17)==0
    COUNTS['branching_guard']=1;COUNTS['composite_minor_guard']=1
    out={'status':'PASS','review_independence':'Fresh program; does not import or read any candidate or historical program','seed':202610131039,'counts':dict(COUNTS),'cases':cases,'scope':'Finite corroboration only; proofs and asymptotic cost model reviewed separately.'}
    print(json.dumps(out,indent=2,sort_keys=True))

if __name__=='__main__':main()
