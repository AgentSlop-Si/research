#!/usr/bin/env python3
"""Fresh exact controls for marker-Schur fill-in and constant-input action.

Standard library only. Does not read/import any historical or downloaded code.
All graph oracles are built directly from Q e_s=e_(2s)+omega^s e_(2s+1).
"""
import json
from math import isqrt

COUNTS = {}
def count(k, v=1): COUNTS[k] = COUNTS.get(k, 0) + v
def clean(x, p): return {k:v % p for k,v in x.items() if v % p}
def add(a, b, p, c=1):
    z = a.copy()
    for k,v in b.items(): z[k] = (z.get(k,0) + c*v) % p
    return clean(z,p)
def root(p,n):
    assert all(p%d for d in range(2,isqrt(p)+1))
    N=1<<n
    assert (p-1)%N==0
    for g in range(2,p):
        w=pow(g,(p-1)//N,p)
        if pow(w,N//2,p)!=1 and pow(w,N,p)==1:return w
    raise AssertionError('root absent')
def gamma(s):
    g=0
    while s:
        g+=(s//2)*(s&1)
        s//=2
    return g
def reverse(s,m):
    z=0
    for _ in range(m):z=(z<<1)|(s&1);s>>=1
    return z
def avoid(s,m,b):return '0'*b not in format(s,'0%db'%m) if m else True
def sets(n,b):
    assert 1<=b<=n
    N=1<<n
    R=set(range(0,N,1<<b))
    A={s for s in range(N) if avoid(s,n,b)}
    T=R|A
    assert not R&A
    return R,A,T,set(range(N))-T
def step(v,n,p,w,allowed=None):
    N=1<<n;out={}
    for s,c in v.items():
        for a,wt in ((0,1),(1,pow(w,s,p))):
            t=(2*s+a)%N
            if allowed is None or t in allowed:out[t]=(out.get(t,0)+c*wt)%p
    return clean(out,p)
def aseq(b,m):
    a=[]
    for j in range(m+1):a.append((1<<j) if j<b else sum(a[j-b:j]))
    return a
def direct_feedback(u,n,b,p,w):
    _,_,T,F=sets(n,b);L=n-b
    C={1:step(u,n,p,w,T)}
    v=step(u,n,p,w,F)
    for t in range(2,L+2):
        C[t]=step(v,n,p,w,T)
        v=step(v,n,p,w,F)
    assert not v
    return C
def first_return_word(w,t,b):
    z=format(w,'0%db'%t)
    return z[0]=='1' and z.endswith('0'*b) and '0'*b not in z[:-1]
def Wset(L,b):
    return {w for w in range(1<<L,1<<(L+1)) if avoid(w>>1,L,b)}
def fast_feedback(u,n,b,p,w):
    R,A,T,F=sets(n,b);L=n-b
    C={1:step(u,n,p,w,T)}
    if not F:return C
    r=1<<L;eta=pow(w,1<<b,p)
    q={j:u.get(j<<b,0) for j in range(r)}
    ratio=w*pow(eta,-1,p)%p
    for t in range(1,L+1):
        q=step(q,L,p,eta)
        if t>=2:
            dest={}
            for a in range(r):
                word=a% (1<<t)
                if first_return_word(word,t,b):
                    y=((a-word)*(1<<b)+word)%(1<<n)
                    assert y in T and y not in dest
                    dest[y]=q.get(a,0)*pow(ratio,gamma(word),p)%p
            C[t]=clean(dest,p)
    dest={}
    for word in Wset(L,b):
        a=word>>1
        dest[word]=q.get(a,0)*pow(w,gamma(word),p)*pow(eta,-gamma(a),p)%p
    C[L+1]=clean(dest,p)
    return C
def rank(rows,p):
    a=[r[:] for r in rows];i=0
    for j in range(len(a[0]) if a else 0):
        pivot=next((k for k in range(i,len(a)) if a[k][j]%p),None)
        if pivot is None:continue
        a[i],a[pivot]=a[pivot],a[i]
        iv=pow(a[i][j],-1,p)
        a[i]=[v*iv%p for v in a[i]]
        for k in range(i+1,len(a)):
            c=a[k][j]
            a[k]=[(x-c*y)%p for x,y in zip(a[k],a[i])]
        i+=1
        if i==len(a):break
    return i

samples=[];root_records=[]
for p,maxn in ((17,4),(97,5),(257,8),(65537,9)):
    for n in range(1,maxn+1):
        w=root(p,n);root_records.append({'p':p,'n':n,'omega':w})
        for b in range(1,n+1):
            N=1<<n;L=n-b;r=1<<L
            R,A,T,F=sets(n,b)
            u={s:(s*s+7*s+11)%p for s in T}
            assert direct_feedback(u,n,b,p,w)==fast_feedback(u,n,b,p,w), (n,b,p,w,direct_feedback(u,n,b,p,w),fast_feedback(u,n,b,p,w))
            count('arbitrary_constant_action_cases')
            if not F:
                assert b==n and T==set(range(N))
                count('empty_boundaries');continue
            aa=aseq(b,L-1);W=Wset(L,b);k=len(W)
            assert k==2*aa[-1]<=r
            total=0;top={};coeff={}
            for s in T:
                d=direct_feedback({s:1},n,b,p,w)
                if n<=7:
                    assert d==fast_feedback({s:1},n,b,p,w)
                    count('all_basis_constant_action_vectors')
                for t,v in d.items():
                    coeff.setdefault(t,{})[s]=v
                    if t>=2:total+=len(v)
                top[s]=d[L+1]
                assert (set(top[s])==W) if s in R else (top[s]=={})
                if s in R:
                    j=s>>b;eta=pow(w,1<<b,p)
                    for y,value in top[s].items():
                        a=y>>1
                        expected=pow(w,gamma(y),p)*pow(eta,j*reverse(a,L),p)%p
                        assert value==expected!=0
                        count('highest_coefficient_entry_checks')
            assert sum(len(v) for v in coeff[1].values())==r+2*len(A)
            assert sum(len(v) for v in top.values())==k*r
            assert total==r*(1+sum(aa))
            assert k*r >= 1<<(2*L-(L-1)//b)
            count('exact_fill_cases')
            if n<=6:
                rows=[[top[s].get(y,0) for s in sorted(R)] for y in sorted(W)]
                assert rank(rows,p)==k//2
                count('exact_rank_cases')
            if p==65537 and (n,b) in ((4,1),(6,2),(8,3),(9,4)):
                samples.append({'n':n,'b':b,'N':N,'r':r,'retained':len(T),'nonzero_rows':k,'rank':k//2,'top_nnz':k*r,'all_excursion_nnz':total})
            seen=set()
            for degree,cols in coeff.items():
                for source,col in cols.items():
                    for target in col:
                        assert (target,source) not in seen
                        seen.add((target,source))
            assert len(seen)==total+r+2*len(A)
            count('disjoint_coefficient_support_cases')
            # Every nonzero scalar specialization of feedback preserves support.
            for z in (1,2,p-1):
                if not z%p:continue
                evaluated={}
                for degree,cols in coeff.items():
                    for source,col in cols.items():
                        for target,c in col.items():
                            key=(target,source)
                            evaluated[key]=(evaluated.get(key,0)+pow(z,degree,p)*c)%p
                assert sum(bool(v) for v in evaluated.values())==len(seen)
                count('nonzero_scalar_support_cases')

# Verify the full all-input Schur source/solve/recovery identity through degree n.
for n in range(1,6):
    p=97 if n<=5 else 65537;w=root(p,n);N=1<<n
    for b in range(1,n+1):
        R,A,T,F=sets(n,b);L=n-b
        for s in range(N):
            x={s:1};xt={s:1} if s in T else {};xf={s:1} if s in F else {}
            f=[{} for _ in range(n+1)];f[0]=xt
            v=xf
            for j in range(L):
                if j+1<=n:f[j+1]=step(v,n,p,w,T)
                v=step(v,n,p,w,F)
            assert not v
            yt=[]
            for d in range(n+1):
                yd=f[d].copy()
                for t in range(1,min(d,L+1)+1):
                    yd=add(yd,fast_feedback(yt[d-t],n,b,p,w).get(t,{}),p)
                yt.append(yd)
            yf=[{} for _ in range(n+1)];v=xf
            for j in range(L):
                yf[j]=add(yf[j],v,p);v=step(v,n,p,w,F)
            for i,ui in enumerate(yt):
                v=step(ui,n,p,w,F)
                for j in range(L):
                    if i+j+1<=n:yf[i+j+1]=add(yf[i+j+1],v,p)
                    v=step(v,n,p,w,F)
                assert not v
            full=x
            for d in range(n+1):
                assert add(yt[d],yf[d],p)==full
                full=step(full,n,p,w)
                count('schur_jet_coefficients')
            ans=add(yt[n],yf[n],p)
            for y in range(N):assert ans.get(y,0)==pow(w,gamma(y)+s*reverse(y,n),p)
            count('schur_all_input_basis_vectors')

# Bound check via independent word enumeration and forced-one positions.
for b in range(1,13):
    aa=aseq(b,32)
    for m in range(33):
        assert aa[m]>=1<<(m-m//b)
        if m<=13:assert aa[m]==sum(avoid(s,m,b) for s in range(1<<m))
        count('word_count_bound_cases')

# Explicit grammar and cancellation guards.
p=17;n=3;b=1;w=root(p,n)
R,A,T,F=sets(n,b)
incoming=[s for s in F if 3 in step({s:1},n,p,w,F)]
assert incoming==[1,5]
branching={'n':n,'b':b,'p':p,'omega':w,'destination':3,'sources':incoming,'weights':[pow(w,s,p) for s in incoming]}
for n in range(2,10):
    N=1<<n;p=65537;w=root(p,n)
    assert (1*pow(w,(N//2)*2,p)-1)%p==0
    count('dyadic_zero_minor_cases')
# A nonzero leading operator may vanish on a particular nonzero input.
n=5;b=2;L=n-b;p=97;w=root(p,n);r=1<<L;y=min(Wset(L,b))
v=reverse(y>>1,L);eta=pow(w,1<<b,p)
u={0:1,1<<b:-pow(eta,-v,p)%p}
assert y not in direct_feedback(u,n,b,p,w)[L+1]
count('input_cancellation_controls')
# Wrong trailing-L-bit formula fails already at n=2,b=1.
n=2;b=1;p=17;w=root(p,n);u={0:1,2:1}
assert direct_feedback(u,n,b,p,w)[2].get(2,0)==0
assert 2%p!=0
count('wrong_top_index_controls')
print(json.dumps({'status':'PASS','counts':COUNTS,'roots':root_records,'samples':samples,'branching_witness':branching,'historical_code_executed':False},indent=2,sort_keys=True))
