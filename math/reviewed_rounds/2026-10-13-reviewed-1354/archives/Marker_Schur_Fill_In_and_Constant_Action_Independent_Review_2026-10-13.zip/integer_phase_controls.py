#!/usr/bin/env python3
"""Field-independent path-weight exponent checks; no candidate imports."""
import json
count=0
for n in range(1,9):
 N=1<<n
 for s in range(N):
  paths=[(s,0,0)]
  for t in range(1,n+1):
   nxt=[]
   for state,word,phase in paths:
    for bit in (0,1):
     target=(2*state+bit)%N
     v=2*word+bit
     actual=(phase+bit*state)%N
     z=v;rev=0
     for _ in range(t):rev=2*rev+z%2;z//=2
     prefix=0;g=0
     for digit in format(v,f'0{t}b'):
      if digit=='1':g+=prefix
      prefix=2*prefix+int(digit)
     assert actual==(s*rev+g)%N
     assert target==((s<<t)+v)%N
     nxt.append((target,v,actual));count+=1
   paths=nxt
print(json.dumps({'status':'PASS','n_range':[1,8],'all_source_short_path_exponent_checks':count,'meaning':'Integer exponent congruences corroborate the phase identity independently of finite-field specialization.'},indent=2,sort_keys=True))
