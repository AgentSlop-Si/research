#!/usr/bin/env python3
"""Seal this independent review. No historical research code is executed."""
import hashlib,json,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent
files=['REVIEW.md','README.md','PROVENANCE.json','PRIOR_ACCEPTED_GRADED_REVIEW.md',
       'review_controls.py','extension_controls.py','CONTROLS.json','REPLAY_CONTROLS.json',
       'EXTENSION_CONTROLS.json','REPLAY_EXTENSION_CONTROLS.json','seal_review.py',
       'candidate/Arbitrary_Free_Source_Compression_Candidate_2026-10-13.zip','candidate/REPORT.md']
manifest={'algorithm':'SHA-256','files':[{'path':f,'bytes':len((base/f).read_bytes()),'sha256':hashlib.sha256((base/f).read_bytes()).hexdigest()} for f in files]}
(base/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=base/'Arbitrary_Free_Source_Compression_Independent_Review_2026-10-13.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in files+['MANIFEST.json']:
        info=zipfile.ZipInfo(name,date_time=(2026,10,13,11,45,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,(base/name).read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(files)+1
    for item in manifest['files']:
        raw=z.read(item['path'])
        assert raw==(base/item['path']).read_bytes()
        assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
    assert z.read('MANIFEST.json')==(base/'MANIFEST.json').read_bytes()
seal={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
      'manifest_sha256':hashlib.sha256((base/'MANIFEST.json').read_bytes()).hexdigest(),
      'review_sha256':hashlib.sha256((base/'REVIEW.md').read_bytes()).hexdigest(),
      'disposition':'Scoped ACCEPT; existing ALG-068 rank 48 and priority unchanged; no external publication'}
(base/'SEAL.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps(seal,indent=2))
