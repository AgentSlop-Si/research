# Independent review of arbitrary free source compression

Reviewed 13 October 2026 UTC. Verdict: **scoped ACCEPT**. No substantive mathematical repair of the frozen candidate is required.

The arbitrary free source C(z)x_F has exactly D=|F|+L|F_L| structural scalar coefficient slots, at most 2|F|. Its complete, coalesced output is computable in O(N+W) exact field and word operations, where W=sum_a a|F_a|. The full free polynomial H(z)x_F has W structural slots and a valid worst-case output-size obstruction, including over finite fields. The GF(17) example correctly disproves reconstruction of the polynomial from C(1)x_F alone.

The distinction between small output and cheap computation remains important: D=O(N) does not prove an O(N) source-only algorithm uniformly in b. The accepted retained inverse remains O(N(m+1)); at Fourier precision m=n it matches O(Nn), and this packet does not improve the complete transform. Existing ALG-068 rank 48 and priority are unchanged.

One clarification concerns parameter comparisons. The condition 2^b=o(L) is sufficient for the stated O(N2^b) bound to improve the blind O(NL) schedule. It is not necessary for the sharper O(N+W) schedule to do so. The frozen candidate correctly says “when,” rather than “only when.” Cheap source work obtained by making the free set tiny must also be reported alongside the resulting retained dimension and the unchanged solve/recovery cost.

## Reviewed bytes and independent method

This review binds to the supplied candidate:

- Archive: Arbitrary_Free_Source_Compression_Candidate_2026-10-13.zip
- Bytes: 14,970
- Archive SHA-256: 64a543ac9cc09a02c9fd44fa8bdf6c912151a8cb458547cf84838b7e7b2e5dc8
- Candidate REPORT.md SHA-256: 1f19aa53ad57960606f14520c9326b239a121edd802631738587c2e910d97ba8
- Candidate Library identity: libfile_ea097ebe63b081919278b7997158e82f

All seven manifest-listed files were independently size-checked and rehashed directly inside the eight-member ZIP. The archived report was compared byte for byte with the supplied report. The unchanged candidate ZIP and report accompany this review.

The accepted graded-action review was read as an antecedent. Its SHA-256 is 6b8ddf506cb534f25fb99a3b8d5c1dc1f85cde397e8e921ec47def4bb4c3ae99, and an unchanged text snapshot is included. It accepts O(N) constant retained action and O(N(m+1)) causal inversion, and explicitly leaves arbitrary free-source compression unresolved. The present result addresses part of that precise boundary.

No candidate, predecessor, downloaded, or historical research program was imported or executed. Two fresh standard-library programs were written for this audit. They use direct path enumeration, independent binary-prefix metadata, literal streaming coefficient arrays, direct full-state propagation, and independently implemented quadratic extension fields. Both programs produced byte-identical isolated replay output. Proofs below, rather than finite tests or timing, establish the asymptotic claims.

## Model and inherited grading

Let n>=1, N=2^n, and let K be any field with a supplied omega of exact multiplicative order N. Destination rows and column-vector action are used:

    Q e_s = e_(2s mod N) + omega^s e_((2s+1) mod N).

All states are n-bit words with leading zeros. For 1<=b<n, write L=n-b and h=L+1. R consists of words ending in 0^b, A of words avoiding 0^b, T=R union A, and F is the complement. If p(s) is the rightmost marker start, counted from the left beginning at zero, a(s)=L-p(s) is the free grade. Put F_a={s:a(s)=a}, f_a=|F_a|, and B=Q_FF.

A state of A cannot enter F: either it stays marker-free or the newly created marker is the retained suffix. Appending one from R enters grade one; appending zero stays retained. A free-to-free shift moves the rightmost marker left by exactly one, without creating a suffix marker or losing the last marker. Therefore a free edge increases grade by one, and B^L=0.

For a retained y with a second-rightmost marker at p2(y), let tau(y)=L-p2(y); otherwise let tau(y)=h. An exit from grade a has tau(y)=a+1. When the old rightmost marker survives, it becomes y's second-rightmost marker behind the new suffix marker. When it disappears, y has at most one marker and the exit was from grade L. Overlapping occurrences are counted separately; they obey the same shift rule.

These are the same conventions and all-size grading facts as the accepted predecessor. Characteristic two is impossible with an element of exact order 2^n. Nothing requires a prime field. Unit-cost exact field arithmetic and O(log(N+q+d+2))-bit address words are the model; field construction, root discovery, bit complexity, and numerical stability are not included.

At b=n, F is empty, T is the full state space, and all free-source outputs and counts are zero. The forced retained source is x_T. This includes n=b=1. Cases b=0, b>n, n=0, characteristic two, and insufficient-order roots are excluded rather than extrapolated.

## Exact grade factorization

Set H(z)=(I-zB)^(-1), G=(I-B)^(-1), C(z)=Q_TF H(z), and D0=Q_TF G. Here C names the free-source map, not the predecessor's differently named direct A-injection map.

Let J(z) have diagonal z^a(s) on F, and let E(z) have diagonal z^(tau(y)-1) on T. Because each B edge raises grade one,

    J(z) B J(z)^(-1) = zB,
    H(z) = J(z) G J(z)^(-1).

At each actual exit from s to y, a(s)=tau(y)-1, so Q_TF J(z)=E(z)Q_TF. Consequently

    C(z) = E(z) D0 J(z)^(-1).

These identities are initially in Laurent polynomials. Every nonzero matrix entry has the required nonnegative net exponent, so the resulting H and C are ordinary polynomials. Values at z=0 are taken after this cancellation, not by substituting into the singular diagonal J(z)^(-1).

If P_g selects grade-g input coordinates, the exact row formulas are

    [H(z)x_F]_s = sum_(g=1)^a(s) z^(a(s)-g) [G P_g x_F]_s,
    [C(z)x_F]_y = sum_(g=1)^(tau(y)-1)
                      z^(tau(y)-g-1) [D0 P_g x_F]_y.

Rows with no free exits are zero. These are linear identities preserving every field cancellation. Removing edge delays leaves source s carrying z^(-a(s))x_s; the input-side diagonal cannot be discarded for arbitrary sources. Different grade injections cannot be collapsed into one scalar payload merely because each edge admits a retiming.

## Exact supports and weights

Define E_t as the retained rows receiving exits from F_(t-1). For 2<=t<=L, E_t consists exactly of the retained rows with tau=t. Each such row has two free predecessors of grade t-1. Both binary predecessor choices preserve the surviving rightmost marker.

The terminal group E_h consists exactly of tau=h rows beginning with 0^(b-1)1. Each has one free predecessor: its leading bit must be zero to complete the marker that disappears on exit. The other binary predecessor lacks that marker. There are no other nonzero C rows.

A free row s of grade a has every structural degree 0 through a-1. For j<a, the origins of its degree-j coefficient are exactly

    r 2^(n-j) + floor(s/2^j),  0<=r<2^j.

They are all free of grade a-j; the prefix of s retained after removing its last j bits still contains the rightmost marker. Every intermediate state is free.

For y in E_t and 1<=k<t, degree k-1 of C has origins

    r 2^(n-k) + floor(y/2^k).

All 2^k prefix choices contribute if t<=L. Only the even choices 0,2,...,2^k-2 contribute if t=h. Their last prefix bit must be zero to complete the disappearing marker with y's initial b-1 zeros. All have grade t-k. Thus C has exactly the structural degrees 0 through t-2 in that row, with multiplicities 2^k and 2^(k-1), respectively.

To check phases, read a length-k appended word v from left to right as v_0,...,v_(k-1), and put

    rev_k(v)=sum_i v_i 2^i,
    gamma_k(v)=sum_(i:v_i=1) prefix_i(v).

A path starting at u has weight omega^(u rev_k(v)+gamma_k(v)). At step i, the current state is congruent modulo N to 2^i u+prefix_i(v); summing these states over the appended one-bits proves the formula. Intermediate reduction modulo N has no effect on omega powers.

All relevant H and C paths have fewer than n edges. For a fixed origin, destination, and length, the appended word is uniquely determined by the destination. Hence each allowed origin has exactly one path and one nonzero field weight. Each claimed structural coefficient is therefore a genuinely nonzero linear form in independent x_F coordinates, over every permitted field. This does not imply that its value, or every coefficient's value simultaneously, is nonzero at an arbitrary input.

## Exact output census

A grade-a word has an arbitrary prefix of length L-a, its rightmost marker, then a one, then an (a-1)-bit word avoiding the marker. If a_b(j) counts avoiding words, then

    f_a = 2^(L-a) a_b(a-1).

Since a_b(j+1)<=2a_b(j), the sequence f_a is nonincreasing. Counting the two outgoing edges of each state in F_a gives

    |E_(a+1)| = f_a-f_(a+1)       for 1<=a<L,
    |E_(L+1)| = 2f_L.

The first identity divides both free-target and retained-target edge counts by two. At the terminal grade, each target has only one free predecessor, so the factor two must remain. This is exactly the factor that also appears in the terminal path formula.

The scalar count for the complete coalesced C output is therefore

    D = sum_(a=1)^L a|E_(a+1)|
      = sum_(a=1)^L f_a + Lf_L
      = |F|+Lf_L <= 2|F|.

The inequality follows from Lf_L<=sum_a f_a. This counts scalar coefficients of the vector C(z)x_F, not entries of the much larger coefficient matrix. Store an interval [0,t-2] on each active row in E_t; inactive rows have zero length. Offsets and descriptors cost O(|T|); payload has exactly D slots, with each slot containing its actual field sum.

For the full forced source x_T+zC(z)x_F, degree zero is supplied independently by x_T and does not overlap the shifted free-source interval. Its count is

    |T|+D = N+Lf_L <= 2N.

For q>=0 and q0=min(q,L), telescoping after clipping gives

    D_q = sum_(a=1)^L min(a,q)|E_(a+1)|
        = sum_(a=1)^q0 f_a + q0 f_L,
    W_q = sum_(a=1)^L min(a,q)f_a.

For a forced-source jet modulo z^q with q>=1, C is needed only modulo z^(q-1). Precision zero gives empty scalar output. Reading a fully supplied input still costs its actual input size. A requested dense rectangular interface must separately pay all otherwise absent zero writes; it is not the O(N)-slot output promised by this theorem.

## Paid algorithm and storage

The O(N) setup is valid. A binary-prefix traversal tracks the clipped trailing-zero run and the last two marker starts. Each appended zero that completes a suffix marker replaces the rightmost start and shifts the previous one to second-rightmost; an appended one resets the run. Fewer than 2N nonempty prefixes suffice. Final leaves give membership, grade, tau, coordinate maps, grade buckets, and row offsets. The powers 1,omega,...,omega^(N-1) cost N-1 field multiplications. No n-bit scan per state, comparison sort, or independent exponentiation at every edge is required.

For the streaming version, list free states in increasing grade using buckets, and retain prefix offsets. On pass j, the current vector is B^j x_F. Only states of grade greater than j can contribute. This active set is a suffix of the bucket list, accessed without rescanning inactive states. Clear only the next suffix, propagate both weighted edges from every current active state, and add each exit to degree j of its retained row. Destination sums are reduced in K immediately.

Each grade-a state is visited on exactly a passes. Thus there are exactly W scalar state visits, W odd-edge multiplications, and 2W weighted-edge additions in the unoptimized ledger. The full-run next-free clear count is W-|F|. Preparation, initial arrays, input reads, and D output initialization/coalescing/serialization add O(N+W). The resulting source-only time is O(N+W), with O(N) working storage and D=O(N) stored output.

The topological ragged-array variant instead reserves a slots at each grade-a state, sets its constant coefficient to x_s, and propagates every completed state array forward. It has the same time bound and O(N+W) storage. It must not count one array operation as one field operation.

If the full H output is requested, append the current free coefficient for every active state on every pass. This emits W actual coefficients and takes W writes. For a precision q run, the visit count is W_q, and clipping the retained intervals gives D_q. The independent executable uses actual bucket offsets and coalesced scalar arrays, and verifies these ledgers. Its separate exact oracle deliberately uses slower path enumeration; that oracle is not presented as the algorithm with the theorem's running time.

## Magnitude and parameter tradeoffs

Let p_j=a_b(j)/2^j. The exact identity is

    W = 2^(L-1) sum_(a=1)^L a p_(a-1).

The avoidance recurrence yields

    P(t)=sum_(j>=0) p_j t^j
        =(1-(t/2)^b)/(1-t+(t/2)^(b+1)).

Its radius of convergence exceeds one: for example, requiring each disjoint b-bit block to avoid being all zero gives p_j<=(1-2^(-b))^floor(j/b). Differentiation at one is therefore legitimate and gives

    P(1)+P'(1)=2^(2b+2)-(b+2)2^(b+1).

Extending a nonnegative finite sum proves

    W <= min(L|F|, N(2^(b+1)-b-2)).

For a matching lower regime, let M=2^(b-1) and suppose L>=M. The union bound on marker starts gives p_j>=1/2 for 0<=j<M. Hence

    W >= 2^(L-2) M(M+1)/2 >= N2^b/32.

Together with the upper bound, this is W=Theta(N2^b) with absolute constants throughout that regime. In particular, b=floor(log2 n) gives W=Theta(Nn) for sufficiently large n. The earlier tuning b=floor(log2(n/(4 ln n))) gives W=Theta(Nn/log n). Those formulas are asymptotic choices and require sufficiently large n for b>=1.

If 2^b=o(L), then O(N+W)=o(NL), so the bound improves the blind schedule. The converse is not claimed and is false. Take L=ceil(log2 n), b=n-L. Eventually L<=b, so a_b(a-1)=2^(a-1) for every grade. Then

    f_a=2^(L-1),
    |F|=L2^(L-1),
    W=2^(L-2)L(L+1),
    |T|=N-L2^(L-1).

Thus W=O(n(log n)^2)=o(N), the source schedule costs O(N), and it improves NL by a growing factor even though 2^b is enormous compared with L. However, here |T|/N tends to one. Nearly the entire problem has been retained. The accepted inverse through degree n still has O(Nn) work; its dense retained-jet output itself has Theta(Nn) slots. This example supplies no complete-transform improvement.

Similarly, fixed b makes the source schedule O(N) with a b-dependent constant, while |R|=N/2^b already forces |T|=Theta(N). In all regimes the exact retained dimension is 2^L+a_b(n). A source-only gain must be assessed with that retained dimension and the paid inverse/recovery schedule. No small-|A| estimate is necessary for the accepted source theorem or the unchanged O(N(m+1)) solve bound.

## Structural support and finite field output lower bounds

The full H vector has exactly W structural slots because every row of grade a has degrees 0,...,a-1. Under a fixed ragged scalar interface, all W slots must be emitted even when some are zero. This is an output-write lower bound for that interface.

For a zero-suppressing interface, it would be invalid to infer that all W forms can be simultaneously nonzero over every finite field merely because each is individually nonzero. The candidate avoids that mistake. Let |K|=q_K and choose x_F uniformly. Each nonzero linear form is surjective onto K: fixing every coordinate except one having a nonzero coefficient leaves exactly one choice producing any prescribed value. Therefore each form is nonzero with probability 1-1/q_K. Linearity of expectation, without any independence assumption between the forms, gives

    E[number of nonzero H coefficients]=(1-1/q_K)W.

Some input attains at least this expectation. Since the permitted finite fields have q_K>=3, this is at least 2W/3 and proves an Omega(W) worst-case output count. The proof applies to extension fields as well as prime fields. It neither requires nor asserts W simultaneous nonzeros. The fresh exhaustive GF(17) and GF(9) controls check the expectation identity over every free input in the three-bit example.

Over an infinite field, a finite union of proper linear hyperplanes cannot cover K^F, so all W forms can indeed be nonzero simultaneously. Equivalently, the product of these nonzero linear polynomials is a nonzero polynomial and cannot vanish on the entire vector space over an infinite field.

These are scalar-output lower bounds. They do not apply if the requested object is an unevaluated circuit, a compressed symbolic representation, the source C alone, or one selected time coefficient. In particular, W can be much larger than D: at the tuned b, full H has Theta(Nn/log n) worst-case output while C has at most 2N scalar slots. The candidate correctly leaves a gap for source-only algorithms and does not turn the H output obstruction into a superlinear lower bound for C.

## Cancellation witness and source injectivity

For n=3, b=1, K=GF(17), omega=2, the free states are 001,011,101 with grades 1,2,1. The exact examples are:

- x_001=x_011=1: H's row 011 and C's row 110 are 1+2z. Arbitrary-source rows need not be monomials.
- x_001=x_101=1: the degree-one coefficient at free row 011 cancels because 2+15=0; both terminal source degree-one coefficients also vanish. C's row 010 is the nonzero constant 2.
- x_001=1, x_011=13, x_101=16: C's only nonzero polynomials are row 110 equal to 13+4z and row 111 equal to 2+15z. Both vanish at z=1, so C(1)x_F=0 even though C(z)x_F is nonzero.

The complete coefficient map x_F -> C(z)x_F is nevertheless injective. If every exit coefficient vanished, the full-state trajectory from (0,x_F) would remain supported in F and equal B^k x_F through time L, when it becomes zero. But Q is invertible: pairing columns s and s+N/2 gives, after row/column permutations, blocks

    [[1,1],[omega^s,-omega^s]]

with nonzero determinant -2omega^s. Thus Q^L(0,x_F)=0 implies x_F=0.

In the example, C(1) has rank two on a three-dimensional free space, whereas the full coefficient map has rank three. Any reconstruction based only on C(1)x_F and fixed metadata receives the same scalar data for the witness and zero, so cannot recover both polynomials. This proves loss in that proposed representation, not impossibility of an O(N) algorithm retaining other information or reading x_F differently.

## Retained solve and recovery boundary

For Y(z)=(I-zQ)^(-1)x, block elimination gives

    S(z)Y_T(z)=x_T+zC(z)x_F,
    Y_F(z)=H(z)x_F+zH(z)Q_FR Y_R(z).

A has no edge into F. With the accepted constant spatial map P=GQ_FR, retained injection has the common grade delay

    [Y_F(z)]_s=[H(z)x_F]_s+z^a(s)[P Y_R(z)]_s.

Consequently degree k requires

    [B^k x_F]_s + [P [z^(k-a(s))Y_R]]_s,

with negative retained times treated as zero. Because a(s) depends on the output row, this is not generally one application of P to a common retained-time vector.

For a supplied retained polynomial U_R of degree at most d, the direct H term occupies 0,...,a-1, while z^a[P U_R]_s occupies a,...,a+d. The P row is nonzero: backwards a-step origins end in the marker and provide retained R origins with nonzero unique path weights. Thus the combined arbitrary-input structural interval is 0,...,a+d, with W+|F|(d+1) slots. One source sweep and d+1 paid spatial passes give O(N+W+N(d+1)) work, including input/output. This is an evaluation of supplied coefficients, not a way to compute unknown retained coefficients for free.

The predecessor's causal solve through m remains O(N(m+1)). At k=n, the direct term B^n x_F is zero because a(s)<=L<n. The retained forcing from x_F at earlier times still affects the answer, and recovery still needs retained times n-a(s). Neither the W output lower bound for the full H polynomial nor the O(N)-slot C census establishes the complexity of extracting this selected coefficient.

The independently checked Fourier convention is

    (Q^n x)_v=omega^gamma_n(v) sum_s x_s omega^(s rev_n(v)).

The sign is positive, reversal uses exactly n bits, and the output phase is retained. This verifies what the existing trajectory computes; it is not a new FFT or a shortcut through the retained inverse.

## Classical comparison and novelty limits

Mohri's weighted-automata chapter explicitly includes semiring addition and multiplication costs in its acyclic topological bound on printed page 10, Section 2. Polynomial payloads therefore cannot be charged as unit-cost scalars by simply changing the semiring. The present paid schedule is a marker-support specialization of that classical path-sum method. [Weighted Automata Algorithms](https://www.cs.brandeis.edu/~cs136a/CS136a_docs/Mohri_WeightedAutomataAlgorithms_Handbook.pdf)

Leiserson and Saxe provide topological processing of acyclic circuit subgraphs in Section 2 and the endpoint-difference law for retimed paths in Section 3, equation (2) and Lemma 1. The two-sided diagonal identities here reflect that telescoping law; neither it nor a scalar evaluation removes arbitrary input grade labels. [Retiming Synchronous Circuitry](https://www.cs.columbia.edu/~cs6861/handouts/leiserson-algorithmica-88.pdf)

Zheng, Kingsford, and Marcais define the prefix-marker-or-marker-avoiding depathing construction in Definition 2 and prove its remaining path bound in Lemma 2. Reversing words gives the suffix orientation here. No new marker-language or nilpotence claim follows from this continuation. [Lower density selection schemes via small universal hitting sets with short remaining path length](https://arxiv.org/html/2001.06550v1)

These primary passages were independently reopened. They establish the stated classical overlap, not an exhaustive novelty search and not prior publication of every exact source census in this review. The appropriate accepted contribution is the source-specific support theorem, a paid improvement over the blind schedule in suitable regimes, and a negative control on scalar compression. No world-first priority, inverse breakthrough, or full-transform result is accepted.

## Fresh controls and final disposition

The main exact suite uses GF(3), GF(5), GF(17), GF(41), GF(97), GF(193), GF(257), and GF(65537), only at n with an exact-order 2^n root. It covers:

- 147 parameter cases through n=10, with 39 empty-free boundaries
- 23,072 marker-metadata comparisons, including the extra three-bit guard setup
- 46,128 grading and exit-edge checks, 319 layer censuses, and 760 clipped census checks
- 11,588 free structural coefficient forms and 6,420 source structural forms
- 66,026 free path weights and 70,286 exit path weights, with every allowed origin and terminal parity checked
- 1,300 complete or clipped sweeps, including 494 actual clipped-output controls and the exact paid visit ledger
- 49,515 H value comparisons and 28,452 C value comparisons
- 98 full-source rank checks through n=6
- 147 complete forced-source/causal-solve/free-recovery cases and 270,328 comparisons to independently propagated full-state trajectories
- 4,120 direct Fourier phase/reversal comparisons
- Exhaustive averaging over all 4,913 GF(17) free inputs in the three-bit case, totaling 18,496 nonzero H coefficients, exactly (16/17) times 4 times 4,913

The separate quadratic-extension suite uses GF(9), GF(25), and GF(49), with irreducibility verified by the nonsquare defining relation. It adds 22 parameter cases, 10 empty-free boundaries, 121 path-weight comparisons, and 498 Fourier comparisons. Exhaustive GF(9) averaging over 729 free inputs totals 2,592 nonzero coefficients, exactly (8/9) times 4 times 729. Both suites replay byte-identically.

**ACCEPT:** the all-input grade factorization; complete row/degree supports and path weights; D=|F|+Lf_L<=2|F|; O(N+W) paid source construction; the stated O(N2^b) upper bound and matching regime; the full-H output obstruction with the finite-field qualification; the exact C(1)-kernel witness; and the stated recovery identities and costs.

**NOT ESTABLISHED:** a source-only O(N) algorithm uniform in b; a superlinear field-operation lower bound for C; a better retained inverse or selected-coefficient recovery; a faster complete Fourier transform; or worldwide novelty. The parameter condition 2^b=o(L) remains sufficient, not necessary. No external Sheet, repository, publication, priority, or research rank was changed.
