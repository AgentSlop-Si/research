# Arbitrary free source compression and recovery

13 October 2026 UTC. Sealed candidate for independent review. Continuation of the accepted graded marker action. Existing ALG-068 priority and rank 48 are unchanged.

## Result and remaining boundary

There is a paid improvement over a blind O(NL) fresh-source sweep, but the accepted O(N) retained-input action does not automatically extend to arbitrary free input.

Write f_a=|F_a| for the number of free states of grade a, and define

    W = sum_(a=1)^L a f_a.

For an arbitrary explicitly supplied x_F, the full source polynomial C(z)x_F=Q_TF(I-zB)^(-1)x_F can be computed in O(N+W) exact field and word operations. Its complete structural scalar-coefficient output has only

    D = |F| + L f_L <= 2|F| <= 2N

slots. The independent free-source recovery polynomial H(z)x_F=(I-zB)^(-1)x_F has exactly W structural scalar slots, and the same sweep computes it if requested. The sweep is output-optimal up to the O(N) setup when this full free polynomial must be emitted. It is not proved optimal for source compression alone.

The exact bound

    W <= min(L|F|, N(2^(b+1)-b-2))

makes the sweep O(N 2^b), which improves O(NL) when 2^b=o(L). At the earlier marker choice b=floor(log2(n/(4 ln n))), W=Theta(N n/log n) asymptotically. The source has only O(N) output there, leaving a genuine gap between known work and required output. A uniformly O(N) source-only algorithm remains open in this packet. For fixed b, the stated bound already is O(N), with a constant depending on b.

A small exact counterexample rules out recovering all source coefficients from the one scalar aggregate C(1)x_F: over GF(17), n=3, b=1, omega=2, take x_1=1, x_3=13, x_5=16 and all other free entries zero. Then C(1)x_F=0, yet the source polynomial has row 6 equal to 13+4z and row 7 equal to 2+15z. This is information loss in that proposed representation, not a lower bound against every O(N) algorithm.

No faster retained inverse or complete Fourier transform is established. The accepted causal solve remains O(N(m+1)); at m=n that matches O(Nn). The direct free-source term vanishes at Fourier coefficient n, so its full polynomial output lower bound cannot be used as a lower bound on computing that one coefficient.

## Domain and conventions

Let n>=1, N=2^n, and K be any field with a supplied omega of exact order N. In particular, char(K) is not 2. A field operation is exact and has unit cost. Addressing uses O(log(N+q+d+2))-bit words. Root discovery, field construction, bit complexity, and numerical stability are outside the model.

For the main case 1<=b<n, set L=n-b and h=L+1. States are fixed-length n-bit words including leading zeros. The destination-row convention is

    Q e_s = e_(2s mod N) + omega^s e_((2s+1) mod N).

R consists of states ending in 0^b. A consists of states avoiding 0^b. T=R union A and F is the complement. Let B=Q_FF. For s in F, p(s) is the start, numbered from zero at the left, of its rightmost marker 0^b; a(s)=L-p(s) is its grade. Thus F_a={s:a(s)=a}, 1<=a<=L.

An R-to-F edge lands at grade 1, an F-to-F edge increases grade by 1, and A has no edge to F. Therefore B^L=0. For retained row y, define tau(y)=L-p2(y) if a second-rightmost marker starts at p2(y), and tau(y)=h otherwise. Direct R returns have tau=1; every free exit s->y has tau(y)=a(s)+1. These accepted grading facts are used as mathematical antecedents and independently checked below.

The letter C in this report always means the free-source map C(z)=Q_TF H(z), where H(z)=(I-zB)^(-1). It does not mean the predecessor packet's constant A-injection map Q_TA.

The boundary b=n has F empty: H and C have no free input or output, and the full forced source is x_T. All W, D, and free-output counts are zero. Invalid b, characteristic 2, or an insufficient-order root are not included.

## Exact origin grade factorization

Let P_g project onto free input coordinates of grade g. Let

    G = (I-B)^(-1),
    D0 = Q_TF G,
    J(z) = diag_(s in F)(z^a(s)),
    E(z) = diag_(y in T)(z^(tau(y)-1)).

The inverses here define constant operators; the algorithm never materializes these matrices. The exact Laurent-diagonal identities are

    H(z) = J(z) G J(z)^(-1),
    C(z) = E(z) D0 J(z)^(-1).

Their products are ordinary polynomials, since every nonzero entry has the required nonnegative exponent. In row form,

    [H(z)x_F]_s
      = sum_(g=1)^a(s) z^(a(s)-g) [G P_g x_F]_s,

    [C(z)x_F]_y
      = sum_(g=1)^(tau(y)-1)
          z^(tau(y)-g-1) [D0 P_g x_F]_y.

A sum is zero for a retained row with no incoming free exit. These formulas count all weighted paths and preserve all field cancellations. Retiming strips edge delays but replaces the arbitrary source at s by the Laurent monomial z^(-a(s))x_s. It does not make those differently graded source injections one scalar payload.

For an individual source and destination, grading fixes the path length. Because every relevant path has fewer than n edges, its appended word is determined by its destination, and there is at most one such path for that fixed source, destination, and length. Thus an individual structural matrix coefficient is one nonzero field weight; cancellations in the vector action arise when distinct source values are added. No generic noncancellation assumption is used.

## Exact rows degrees and path multiplicities

Let E_t be the retained rows receiving a free exit from grade t-1. For 2<=t<=L, these are exactly the retained rows with tau=t. Each such row has two free predecessors of grade t-1. E_(L+1) consists of the tau=h retained rows beginning with 0^(b-1)1; these have one free predecessor. Retained rows outside the union of these sets have zero C row, even though a harmless tau was assigned to them earlier.

For every y in E_t, the structurally possible C degrees are exactly

    0, 1, ..., t-2.

For every s in F_a, the structurally possible H degrees are exactly

    0, 1, ..., a-1.

Here structural means that the coefficient is a nonzero linear form in arbitrary x_F; a particular input may make it zero.

The following closed forms specify every field weight and every source multiplicity. For an appended k-bit word v, read its bits from left to right as v_0,...,v_(k-1), and define

    rev_k(v) = sum_(i=0)^(k-1) v_i 2^i,
    gamma_k(v) = sum_(i:v_i=1) prefix_i(v),

where prefix_i(v) is the integer represented by the first i bits, with prefix_0=0. A length-k path from u has weight

    omega^(u rev_k(v) + gamma_k(v)).

Exponents may be reduced modulo N. This follows by summing the current state at each appended one; reducing an intermediate state modulo N does not change its omega power.

For free destination s in F_a and 0<=j<a, put v=s mod 2^j and u=floor(s/2^j). Then

    [z^j H(z)x_F]_s
      = sum_(r=0)^(2^j-1)
          omega^((r 2^(n-j)+u) rev_j(v)+gamma_j(v))
          x_(r 2^(n-j)+u).

There are exactly 2^j distinct free origins, all of grade a-j, and all intermediate states are free. The j=0 formula is simply x_s.

For y in E_t and 1<=k<t, put v=y mod 2^k and u=floor(y/2^k). Then

    [z^(k-1) C(z)x_F]_y
      = sum_(r in I_(t,k))
          omega^((r 2^(n-k)+u) rev_k(v)+gamma_k(v))
          x_(r 2^(n-k)+u),

where

    I_(t,k) = {0,...,2^k-1}             if t<=L,
    I_(h,k) = {0,2,...,2^k-2}          if t=h.

The exact numbers of contributing origins are therefore 2^k and 2^(k-1), respectively. Every origin has grade t-k. For the final-grade exit, the last bit of the k-bit prefix must be zero: it forms the disappearing marker together with the initial b-1 zeros of y. This accounts for the factor of two difference and must not be dropped.

These formulas are descriptions, not an instruction to enumerate exponentially many paths. The sweep below shares their partial sums.

## Source output census

Let a_b(j) count j-bit words avoiding 0^b. The accepted free-layer census is

    f_a = 2^(L-a) a_b(a-1).

It is nonincreasing in a because a_b(j+1)<=2a_b(j). Count outgoing edges of F_a. For a<L, each free target in F_(a+1) has two predecessors in F_a, and each retained target in E_(a+1) also has two. Hence

    |E_(a+1)| = f_a - f_(a+1),       1<=a<L.

All two outgoing edges of a grade-L state exit. Each resulting retained row has one free predecessor, because a grade-L state starts with a zero marker, whereas the other binary predecessor starts with one. Thus

    |E_(L+1)| = 2 f_L.

Telescoping yields the exact number of structural scalar source coefficients:

    D = sum_(a=1)^L a |E_(a+1)|
      = |F| + L f_L.

Since f_a>=f_L for all a, L f_L<=|F| and D<=2|F|. Store one interval [0,t-2] per active row y in E_t, coalescing all contributions into actual field coefficients; absent rows are represented by zero length. The descriptors cost O(|T|) and the scalar payload costs D. This is a complete output representation, not an unevaluated path list or a scalar evaluation.

For the full initial-state source x, the retained forced source is

    f(z)=x_T + z C(z)x_F.

Its rows have interval [0,t-1] on E_t and degree zero only elsewhere. Its scalar slot count is

    |T|+D = N + L f_L <= N+|F| <= 2N.

If dense rectangles of height |T| and length L, or length L+1 for f, are required instead, their zero writes and storage must be charged separately.

For a source jet modulo z^q, q>=0, set q0=min(q,L). The exact structural count is

    D_q = sum_(a=1)^L min(a,q) |E_(a+1)|
        = sum_(a=1)^q0 f_a + q0 f_L.

For a free-source jet, the exact count is

    W_q = sum_(a=1)^L min(a,q) f_a.

Truncating the full forced source modulo z^q uses C only modulo z^(q-1), for q>=1. Explicitly delivered full input still costs its actual read size.

## Paid support sensitive sweep

Preparation uses the accepted O(N) binary-prefix marker metadata construction, O(N) weight powers by recurrence, free-grade buckets, retained maps, and row interval offsets. No sorting of n-bit strings, independent exponentiation at each edge, or dense path matrix is required. The exact tests deliberately use simpler string metadata to check these mathematical definitions independently.

There are two equivalent paid implementations.

In the ragged topological implementation, allocate a(s) scalar slots at every free state s. Set its degree-zero slot to x_s. Process increasing grades. For each current scalar coefficient, multiply by the edge weight and add at degree j+1 of a free successor, or degree j of the appropriate retained source interval at an exit. Each destination coefficient is an actual sum. All free predecessors have earlier grade, so a state's complete array is available when processed. This has O(N+W+D)=O(N+W) work and O(N+W) storage including free arrays and output.

In a coefficient-streaming implementation, maintain v=B^j x_F in two scalar arrays. At time j only free states with grade greater than j can be nonzero. Bucket order makes these states one suffix of the free-state list. Clear only the next active suffix, apply the two outgoing edges of each current active state, and add its retained exits to degree j. A prefix-offset array avoids rescanning all free states to discover the active suffix. Across all j there are exactly W visited (state,coefficient) pairs and W-|F| next-free reset slots. Output initialization and writes cost D, input reads cost |F|, and setup costs O(N).

The unoptimized field-edge ledger is W odd-edge multiplications and 2W weighted edge additions; copying, resetting, and output coalescing cost O(N+W). The even-edge weights are one and need no multiplication. If the final B^L step is omitted, the work only decreases. The source-only version requires O(N) working storage and O(D)=O(N) stored output. If H(z)x_F must also be delivered, append each visited v_s to its free row: this adds exactly W output slots and writes without changing the time bound. For precision q, stop after min(q,L) passes and replace W by W_q.

This schedule shares all paths that reach the same state at the same degree. It does not share independent degrees by treating a polynomial operation as one field operation. The test program uses bucket suffixes for this sweep and records the exact W scalar visits.

## Magnitude of the free polynomial

Set p_j=a_b(j)/2^j, the fraction of j-bit words avoiding the marker. Then

    W = 2^(L-1) sum_(a=1)^L a p_(a-1).

The generating function of p_j, derived from the b-step avoidance recurrence, is

    P(t) = (1-(t/2)^b)/(1-t+(t/2)^(b+1)).

Its radius of convergence exceeds one. At t=1, direct differentiation gives

    P(1)+P'(1) = 2^(2b+2) - (b+2)2^(b+1).

Extending the nonnegative finite sum to infinity gives

    W <= N(2^(b+1)-b-2).

For a matching regime, if L>=2^(b-1), the union bound gives p_j>=1/2 for 0<=j<2^(b-1). Summing just those terms shows W=Omega(N 2^b); the preceding bound proves W=Theta(N 2^b) in this regime, with absolute constants. In particular, b=floor(log2 n) gives W=Theta(Nn), while the earlier marker tuning gives W=Theta(N n/log n).

Every H structural coefficient is a nonzero linear form, as its exact path formula shows. A fixed ragged output interface therefore requires W writes even when some coefficients are zero. If an interface suppresses zero coefficients, the worst-case lower bound still holds: over a finite field of size qK, a uniformly random x_F makes each such linear form nonzero with probability 1-1/qK, so some input has at least (1-1/qK)W nonzero coefficients. Over an infinite field a finite union of proper linear hyperplanes cannot cover the input space. These are output-size lower bounds, not field-operation lower bounds for C alone or for a selected final coefficient.

## Recovery after the retained solve

For an arbitrary initial vector x, put Y(z)=(I-zQ)^(-1)x. Eliminating the free block gives the exact all-input identities

    S(z)Y_T(z) = x_T + z C(z)x_F,

    Y_F(z) = H(z)x_F + z H(z)Q_FR Y_R(z).

A has no edge to F. Define the constant spatial map P=GQ_FR. The accepted retained-injection grading gives

    [Y_F(z)]_s = [H(z)x_F]_s + z^a(s) [P Y_R(z)]_s.

Thus, for k>=0,

    [z^k Y_F]_s
      = [B^k x_F]_s
        + [P [z^(k-a(s)) Y_R]]_s,

where the first term is zero for k>=a(s), and negative retained times are zero. Computing a different retained input time in each output row is not one ordinary scalar P action on a common input vector.

If an explicitly supplied retained polynomial U_R has degree at most d, full free recovery H(z)x_F+zH(z)Q_FR U_R has contiguous structural support [0,a(s)+d] in free row s. The scalar count is W+|F|(d+1). The source sweep plus d+1 paid constant spatial passes computes it in O(N+W+N(d+1)) work, with its requested input and output charged.

A full free jet through degree m has |F|(m+1) slots under the usual dense per-row interface. The existing O(N(m+1)) solve/recovery route remains available. This packet does not silently require the full H output when the user wants only the Fourier coefficient k=n. In that case n>a(s)-1 for every free state, so B^n x_F=0. The nontrivial final recovery term uses retained times n-a(s), and the retained source still depends on x_F through the earlier forcing coefficients. The present source census does not remove that solve and recovery obligation.

There is also an injectivity check: the complete coefficient map x_F -> C(z)x_F has full column rank |F|. Indeed, if every exit coefficient vanished, Q^k(0,x_F) would stay entirely free and equal B^k x_F; at k=L it would be zero. But Q is invertible: pairing sources s and s+N/2 gives the 2-by-2 block [[1,1],[omega^s,-omega^s]], of determinant -2omega^s. Hence x_F=0. This does not imply that the much smaller scalar evaluation C(1) is injective, as the exact counterexample shows.

## Exact cancellation controls

Use n=3, b=1, K=GF(17), omega=2. The free states are 001, 011, and 101, with grades 1, 2, and 1.

For x_001=x_011=1, H's row 011 and C's row 110 are both 1+2z. A single grade-dependent monomial cannot represent that arbitrary-source row.

For x_001=x_101=1, the two contributions to free row 011 cancel: omega^1+omega^5=2+15=0. The degree-one exit coefficients at 110 and 111 vanish, while C's row 010 is the nonzero constant 2. All paths must be summed in the field, rather than merely counted.

For x_001=1, x_011=13, x_101=16, C's only nonzero polynomials are

    row 110: 13+4z,
    row 111: 2+15z.

Both vanish at z=1, and row 010 is zero. Thus C(1)x_F=0 although the complete polynomial is nonzero. This refutes every proposed reconstruction that uses only C(1)x_F plus fixed row delays, not merely one guessed delay assignment.

## Classical comparison and novelty limit

The basic path-sum algorithm is classical. Mohri's own weighted-automata treatment, Section 2 and page 10, explicitly charges semiring operation costs in its acyclic bound O(|Q|+(T_add+T_multiply)|E|). Taking weights in K[z] does not make polynomial additions constant-time. Our ragged sweep is a support-sensitive specialization of that standard principle; the point needing proof here is the exact marker-dependent support census and its field-operation ledger. [Mehryar Mohri, Weighted Automata Algorithms](https://www.cs.brandeis.edu/~cs136a/CS136a_docs/Mohri_WeightedAutomataAlgorithms_Handbook.pdf)

Leiserson and Saxe give topological processing of acyclic subgraphs in Section 2, and endpoint differences for retimed path delays in Section 3, equation (2) and Lemma 1. The two-sided diagonal identities above are the direct algebraic form of that familiar telescoping structure. With arbitrary initial grades, the input-side diagonal must be retained. Their paper does not supply this marker source census or eliminate its polynomial payload cost. [Retiming Synchronous Circuitry](https://www.cs.columbia.edu/~cs6861/handouts/leiserson-algorithmica-88.pdf)

The marker depathing language itself has prior precedent in Zheng, Kingsford, and Marcais, Definition 2 and Lemma 2, using the opposite prefix orientation. No new marker-language or nilpotence claim is made. [Lower density selection schemes via small universal hitting sets with short remaining path length](https://arxiv.org/html/2001.06550v1)

The displayed finite Fourier sums are exact path formulas; they are not claimed as a new FFT, nor is their direct enumeration the fast schedule. This targeted comparison is not an exhaustive novelty search. The result is best treated as a source-specific support theorem, a paid classical-DAG improvement over an unpruned schedule, and a sharp negative control against an invalid scalar compression extension. Existing ALG-068 priority and rank remain unchanged.

## Fresh controls and disposition

The newly written standard-library program imports or executes no predecessor research code. The predecessor review and report were read as inert text. Exact tests use GF(3), GF(5), GF(17), GF(97), GF(257), and GF(65537), only where the supplied root has exact order N, through n=9.

The suite passed 110 parameter cases plus the independent three-bit guard setup, 492 source vectors including every free basis vector through n=5, 19,467 free-source coefficient checks, 12,539 retained source coefficient checks, 17,218 explicit closed-form path terms, 110 full recovery cases with 24,771 free coefficient comparisons, and 106,869 Schur source identity comparisons against full-state propagation. It checks 237 grade census entries, 570 truncated support censuses, all exit multiplicities, and the exact W visit ledger. Two isolated fresh runs produced byte-identical JSON.

Accept for independent review: exact arbitrary-source grade decomposition; row and degree support; path multiplicities and weights; D=|F|+L f_L<=2|F|; the O(N+W) paid sweep; its O(N 2^b) upper bound; full free-output obstruction; and the C(1)-kernel negative control.

Still open: a uniformly O(N) source-only coefficient algorithm, a better retained inverse at Fourier precision, and a faster complete transform or selected-coefficient recovery. No superlinear lower bound for source compression alone, no generic inverse consequence, no new scalar-cycle representation, and no worldwide novelty or priority claim is made. No external Sheet, repository, or publication was changed.
