#!/usr/bin/env python3
"""Fresh independent exact audit. Imports only Python's standard library.
Does not import/read/execute candidate or historical research programs.
The oracle explicitly follows paths; the paid implementation streams buckets.
"""
import collections
import hashlib
import itertools
import json
import random
from fractions import Fraction
from pathlib import Path

COUNTS=collections.Counter()
RNG=random.Random(202610131132)

def root(p,n):
    N=1<<n
    assert (p-1)%N==0
    for w in range(2,p):
        if pow(w,N,p)==1 and pow(w,N//2,p)!=1:
            return w
    raise AssertionError('no root')

def metadata(n,b):
    N=1<<n; L=n-b
    markers=[]; kind=[]; grade={}; tau={}
    for s in range(N):
        word=format(s,f'0{n}b')
        hits=[i for i in range(L+1) if word[i:i+b]=='0'*b]
        markers.append(hits)
        typ='R' if word.endswith('0'*b) else ('F' if hits else 'A')
        kind.append(typ)
        if typ=='F': grade[s]=L-hits[-1]
        else: tau[s]=L-hits[-2] if len(hits)>=2 else L+1
    # Independently implement the promised linear binary-prefix metadata scan.
    nodes=[(0,0,-1,-1)]
    for depth in range(n):
        new=[]
        for value,run,last,second in nodes:
            nr=min(b,run+1); nl=last; ns=second
            if nr==b: nl=depth+1-b; ns=last
            new.append((2*value,nr,nl,ns))
            new.append((2*value+1,0,last,second))
            COUNTS['prefix_nodes']+=2
        nodes=new
    for value,run,last,second in nodes:
        hits=markers[value]
        assert last==(hits[-1] if hits else -1)
        assert second==(hits[-2] if len(hits)>=2 else -1)
        assert (run==b)==(kind[value]=='R')
        COUNTS['metadata_states']+=1
    return kind,grade,tau

def edges(s,N,w,p):
    return ((2*s%N,1),((2*s+1)%N,pow(w,s,p)))

def avoidance(b,length):
    # Combinatorial suffix-run recurrence, rather than the rational formula.
    v=[1]+[0]*(b-1); out=[1]
    for _ in range(length):
        v=[sum(v)]+v[:-1]; out.append(sum(v))
    return out

def closed_weight(origin,destination,k,N,w,p):
    v=destination% (1<<k); bits=format(v,f'0{k}b') if k else ''
    rev=sum(int(bit)<<i for i,bit in enumerate(bits))
    prefix=gamma=0
    for bit in bits:
        if bit=='1': gamma+=prefix
        prefix=2*prefix+int(bit)
    return pow(w,(origin*rev+gamma)%N,p)

def symbolic_paths(n,b,p,w,kind,grade,tau):
    N=1<<n; L=n-b; H=collections.defaultdict(dict); C=collections.defaultdict(dict)
    for origin in grade:
        stack=[(origin,0,1)]
        while stack:
            s,j,weight=stack.pop()
            assert origin not in H[s,j]  # No parallel paths with a fixed origin and endpoint.
            H[s,j][origin]=weight
            assert j==grade[s]-grade[origin]
            for y,edge in edges(s,N,w,p):
                if kind[y]=='F': stack.append((y,j+1,weight*edge%p))
                else:
                    assert origin not in C[y,j]
                    C[y,j][origin]=weight*edge%p
                    assert j==tau[y]-grade[origin]-1
    for s,a in grade.items():
        assert sorted(j for (y,j) in H if y==s)==list(range(a))
        for j in range(a):
            u=s>>j
            want={r*(1<<(n-j))+u:closed_weight(r*(1<<(n-j))+u,s,j,N,w,p) for r in range(1<<j)}
            assert H[s,j]==want
            assert all(grade[x]==a-j for x in want)
            COUNTS['free_structural_coefficients']+=1
            COUNTS['free_path_weights']+=len(want)
    active={y for y,j in C}
    for y in active:
        t=tau[y]
        assert sorted(j for yy,j in C if yy==y)==list(range(t-1))
        for j in range(t-1):
            k=j+1; u=y>>k
            prefixes=range(1<<k) if t<=L else range(0,1<<k,2)
            want={r*(1<<(n-k))+u:closed_weight(r*(1<<(n-k))+u,y,k,N,w,p) for r in prefixes}
            assert C[y,j]==want
            assert all(grade[x]==t-k for x in want)
            COUNTS['source_structural_coefficients']+=1
            COUNTS['exit_path_weights']+=len(want)
    assert all(weight!=0 for row in list(H.values())+list(C.values()) for weight in row.values())
    return H,C

def paid_sweep(n,b,p,w,kind,grade,tau,x,q=None):
    N=1<<n; L=n-b
    if q is None: q=L
    q=min(q,L)
    buckets=[[] for _ in range(L+1)]
    for s,a in grade.items(): buckets[a].append(s)
    order=[]; off=[0]*(L+2)
    for a in range(L+1): off[a]=len(order); order.extend(buckets[a])
    off[L+1]=len(order)
    length=[0]*N
    for s in grade:
        for y,_ in edges(s,N,w,p):
            if kind[y]!='F': length[y]=min(q,tau[y]-1)
    cout=[[0]*length[y] for y in range(N)]
    hout={s:[] for s in grade}
    powers=[1]*N
    for s in range(1,N): powers[s]=powers[s-1]*w%p
    current=[0]*N; following=[0]*N
    for s in grade: current[s]=x[s]
    visits=resets=mults=adds=0
    for j in range(q):
        for i in range(off[j+2],len(order)):
            following[order[i]]=0; resets+=1
        for i in range(off[j+1],len(order)):
            s=order[i]; value=current[s]; hout[s].append(value); visits+=1
            for y,contribution in ((2*s%N,value),((2*s+1)%N,value*powers[s]%p)):
                if kind[y]=='F': following[y]=(following[y]+contribution)%p
                else: cout[y][j]=(cout[y][j]+contribution)%p
                adds+=1
            mults+=1
        current,following=following,current
    assert visits==sum(min(a,q) for a in grade.values())
    assert resets==sum(min(max(a-1,0),q) for a in grade.values())
    assert adds==2*visits and mults==visits
    COUNTS['sweep_vectors']+=1; COUNTS['paid_scalar_visits']+=visits
    return hout,cout

def action(form,x,p): return sum(v*x[s] for s,v in form.items())%p

def rank(rows,p):
    if not rows:return 0
    A=[list(row) for row in rows]; r=0
    for c in range(len(A[0])):
        k=next((k for k in range(r,len(A)) if A[k][c]),None)
        if k is None:continue
        A[r],A[k]=A[k],A[r]; inv=pow(A[r][c],-1,p)
        A[r]=[v*inv%p for v in A[r]]
        for k in range(r+1,len(A)):
            factor=A[k][c]
            if factor:A[k]=[(a-factor*b)%p for a,b in zip(A[k],A[r])]
        r+=1
        if r==len(A):break
    return r

def scalar_retained(n,p,w,kind,grade,u):
    N=1<<n; free=[0]*N; r_out=[0]*N; a_out=[0]*N
    for s in range(N):
        if kind[s]=='F':continue
        for y,weight in edges(s,N,w,p):
            value=weight*u[s]%p
            if kind[s]=='A':
                assert kind[y]!='F'; a_out[y]=(a_out[y]+value)%p
            elif kind[y]=='F':free[y]=(free[y]+value)%p
            else:r_out[y]=(r_out[y]+value)%p
    for s in sorted(grade,key=grade.get):
        for y,weight in edges(s,N,w,p):
            value=weight*free[s]%p
            if kind[y]=='F':free[y]=(free[y]+value)%p
            else:r_out[y]=(r_out[y]+value)%p
    return free,r_out,a_out

def full_propagate(x,n,p,w,steps):
    N=1<<n; trajectory=[x[:]]
    for _ in range(steps):
        new=[0]*N
        for s,value in enumerate(trajectory[-1]):
            for y,weight in edges(s,N,w,p):new[y]=(new[y]+value*weight)%p
        trajectory.append(new)
    return trajectory

def recovery(n,b,p,w,kind,grade,tau,H,C):
    N=1<<n; m=n+2; x=[RNG.randrange(p) for _ in range(N)]
    direct=full_propagate(x,n,p,w,m)
    y=[[0]*N for _ in range(m+1)]; free=[[0]*N for _ in range(m+1)]
    for s in range(N):
        if kind[s]!='F': y[0][s]=x[s]
    for (s,j),form in H.items():free[j][s]=action(form,x,p)
    for (s,j),form in C.items():y[j+1][s]=action(form,x,p)
    for j in range(m+1):
        fp,rr,aa=scalar_retained(n,p,w,kind,grade,y[j])
        for s in range(N):
            if kind[s]=='F':
                if j+grade[s]<=m:free[j+grade[s]][s]=(free[j+grade[s]][s]+fp[s])%p
            else:
                if j+1<=m:y[j+1][s]=(y[j+1][s]+aa[s])%p
                if j+tau[s]<=m:y[j+tau[s]][s]=(y[j+tau[s]][s]+rr[s])%p
    for j in range(m+1):
        for s in range(N):
            got=free[j][s] if kind[s]=='F' else y[j][s]
            assert got==direct[j][s],(n,b,p,j,s,got,direct[j][s])
            COUNTS['full_recovery_comparisons']+=1
    # Explicit phase and bit reversal, computed independently of closed_weight.
    if n<=7:
        for v in range(N):
            bits=[(v>>(n-1-i))&1 for i in range(n)]
            rev=sum(bit<<i for i,bit in enumerate(bits))
            gamma=sum((v>>(n-i)) for i,bit in enumerate(bits) if bit)
            expected=pow(w,gamma,p)*sum(x[s]*pow(w,s*rev,p) for s in range(N))%p
            assert direct[n][v]==expected
            COUNTS['fourier_phase_comparisons']+=1
    COUNTS['recovery_cases']+=1

def case(n,b,p):
    N=1<<n; L=n-b; w=root(p,n)
    kind,grade,tau=metadata(n,b)
    R={s for s,k in enumerate(kind) if k=='R'}; A={s for s,k in enumerate(kind) if k=='A'}
    F=set(grade); T=set(range(N))-F
    assert not R&A and R|A==T
    f=[0]*(L+1)
    for a in grade.values():f[a]+=1
    av=avoidance(b,max(0,L-1))
    for a in range(1,L+1):
        assert f[a]==(1<<(L-a))*av[a-1]
        if a<L:assert f[a]>=f[a+1]
        COUNTS['layer_census']+=1
    incoming=collections.defaultdict(list)
    for s in range(N):
        for y,_ in edges(s,N,w,p):
            if kind[s]=='A':assert kind[y]!='F'
            if kind[y]=='F':
                assert kind[s]!='A'
                assert grade[y]==(1 if kind[s]=='R' else grade[s]+1)
            if kind[s]=='F' and kind[y]!='F':
                assert tau[y]==grade[s]+1;incoming[y].append(s)
            COUNTS['edge_checks']+=1
    E={a:set() for a in range(2,L+2)}
    for y,preds in incoming.items():
        E[tau[y]].add(y)
        assert len(preds)==(2 if tau[y]<=L else 1)
    if L:
        for a in range(1,L):
            assert len(E[a+1])==f[a]-f[a+1]
            assert E[a+1]=={y for y in T if tau[y]==a+1}
        assert len(E[L+1])==2*f[L]
        assert E[L+1]=={y for y in T if tau[y]==L+1 and format(y,f'0{n}b').startswith('0'*(b-1)+'1')}
    else:assert not grade and not incoming
    W=sum(grade.values());D=sum(len(E[a+1])*a for a in range(1,L+1))
    assert D==len(F)+(L*f[L] if L else 0)<=2*len(F)
    assert W<=L*len(F) and W<=N*((1<<(b+1))-b-2)
    assert N+(L*f[L] if L else 0)==len(T)+D<=2*N
    for q in range(L+3):
        q0=min(q,L)
        assert sum(min(a,q)*len(E[a+1]) for a in range(1,L+1))==sum(f[1:q0+1])+(q0*f[L] if L else 0)
        COUNTS['jet_census']+=1
    H,C=symbolic_paths(n,b,p,w,kind,grade,tau)
    assert len(H)==W and len(C)==D
    vectors=[[0]*N,[int(s in F) for s in range(N)]]
    vectors.extend([[RNG.randrange(p) if s in F else 0 for s in range(N)] for _ in range(2)])
    if n<=5:
        for s in grade:
            x=[0]*N;x[s]=1;vectors.append(x)
    for x in vectors:
        hs,cs=paid_sweep(n,b,p,w,kind,grade,tau,x)
        for (s,j),form in H.items():
            assert hs[s][j]==action(form,x,p);COUNTS['H_value_comparisons']+=1
        for (s,j),form in C.items():
            assert cs[s][j]==action(form,x,p);COUNTS['C_value_comparisons']+=1
        assert sum(map(len,hs.values()))==W and sum(map(len,cs))==D
    # Zero and beyond-horizon precision controls exercise actual output clipping.
    for q in sorted({0,1,max(0,L-1),L+2}):
        hs,cs=paid_sweep(n,b,p,w,kind,grade,tau,vectors[-1],q)
        assert sum(map(len,hs.values()))==sum(min(a,q) for a in grade.values())
        assert sum(map(len,cs))==sum(min(a,q)*len(E[a+1]) for a in range(1,L+1))
        for (s,j),form in H.items():
            if j<q:assert hs[s][j]==action(form,vectors[-1],p)
        for (s,j),form in C.items():
            if j<q:assert cs[s][j]==action(form,vectors[-1],p)
        COUNTS['truncated_sweeps']+=1
    if n<=6:
        columns=sorted(F)
        assert rank([[form.get(s,0) for s in columns] for form in C.values()],p)==len(F)
        COUNTS['full_source_rank_cases']+=1
    recovery(n,b,p,w,kind,grade,tau,H,C)
    COUNTS['parameter_cases']+=1
    if not F:COUNTS['empty_free_cases']+=1
    return kind,grade,tau,H,C

def finite_and_cancellation():
    n=3;b=1;p=17;w=2;N=8
    kind,grade,tau=metadata(n,b); H,C=symbolic_paths(n,b,p,w,kind,grade,tau)
    x=[0]*N;x[1]=1;x[3]=13;x[5]=16
    hc,cc=paid_sweep(n,b,p,w,kind,grade,tau,x)
    nonzero={y:row for y,row in enumerate(cc) if any(row)}
    assert nonzero=={6:[13,4],7:[2,15]}
    assert all(sum(row)%p==0 for row in cc)
    F=sorted(grade)
    c1=[[sum(C.get((y,j),{}).get(s,0) for j in range(n))%p for s in F] for y in range(N) if kind[y]!='F']
    assert rank(c1,p)==2 and len(F)==3
    x=[0]*N;x[1]=x[5]=1
    hs,cs=paid_sweep(n,b,p,w,kind,grade,tau,x)
    assert hs[3]==[0,0] and cs[2]==[2] and cs[6][1]==0 and cs[7][1]==0
    x=[0]*N;x[1]=x[3]=1
    hs,cs=paid_sweep(n,b,p,w,kind,grade,tau,x)
    assert hs[3]==[1,2] and cs[6]==[1,2]
    # Exact counting over every free input, with no claim that all forms must
    # be simultaneously nonzero in an arbitrary finite-field configuration.
    total=0;hist=collections.Counter()
    for entries in itertools.product(range(p),repeat=len(F)):
        x=[0]*N
        for s,v in zip(F,entries):x[s]=v
        nz=sum(action(form,x,p)!=0 for form in H.values())
        total+=nz;hist[nz]+=1
    W=len(H);cases=p**len(F)
    assert total*p==(p-1)*W*cases
    assert max(hist)*p>=(p-1)*W
    return {'field':p,'inputs':cases,'W':W,'nonzero_count_total':total,'distribution':dict(sorted(hist.items())),
            'C1_rank':rank(c1,p),'full_input_dimension':len(F),'kernel_witness':{'x1':1,'x3':13,'x5':16},'witness_C':nonzero}

def numeric_regimes():
    rows=[]
    for n,b in [(64,2),(64,6),(128,7),(256,8),(64,58),(128,121),(256,248)]:
        L=n-b;av=avoidance(b,L-1);f=[(1<<(L-a))*av[a-1] for a in range(1,L+1)]
        W=sum(a*v for a,v in enumerate(f,1));N=1<<n;D=sum(f)+L*f[-1]
        assert D<=2*sum(f) and W<=N*((1<<(b+1))-b-2)
        if L>=1<<(b-1):assert W>=N*(1<<b)//32
        rows.append({'n':n,'b':b,'L':L,'F':str(sum(f)),'T':str(N-sum(f)),
                     'W_over_N':str(Fraction(W,N)),'W_over_NL':str(Fraction(W,N*L)),'D':str(D)})
    return rows

def main():
    for p,maxn in [(3,1),(5,2),(17,4),(41,3),(97,5),(193,6),(257,8),(65537,10)]:
        for n in range(1,maxn+1):
            for b in range(1,n+1):case(n,b,p)
    special=finite_and_cancellation()
    result={'status':'PASS','seed':202610131132,'counts':dict(sorted(COUNTS.items())),
            'finite_field_and_cancellation':special,'numeric_regimes':numeric_regimes(),
            'scope':'Fresh exact controls and proofs; not a benchmark, lower bound for C alone, or complete transform result.',
            'historical_research_code_imported_or_executed':False}
    print(json.dumps(result,sort_keys=True,indent=2))

if __name__=='__main__':main()
