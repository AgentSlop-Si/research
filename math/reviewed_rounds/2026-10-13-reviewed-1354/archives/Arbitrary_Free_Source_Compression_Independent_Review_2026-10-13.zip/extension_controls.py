#!/usr/bin/env python3
"""Fresh extension-field guard, fully independent of all other test programs."""
import collections,itertools,json,random

class Quad:
    def __init__(self,p,d):
        self.p=p;self.d=d;self.q=p*p
        assert d%p not in {x*x%p for x in range(p)}
    def add(self,x,y):
        p=self.p
        return (x%p+y%p)%p+p*((x//p+y//p)%p)
    def mul(self,x,y):
        p=self.p;a,b=x%p,x//p;c,d=y%p,y//p
        return (a*c+self.d*b*d)%p+p*((a*d+b*c)%p)
    def power(self,x,e):
        r=1
        while e:
            if e&1:r=self.mul(r,x)
            x=self.mul(x,x);e>>=1
        return r
    def sum(self,vals):
        r=0
        for x in vals:r=self.add(r,x)
        return r

counts=collections.Counter();spec=[];rng=random.Random(9113213)
for p,d,maxn in [(3,2,3),(5,3,3),(7,3,4)]:
    K=Quad(p,d)
    for x in range(1,K.q):assert K.power(x,K.q-1)==1
    for n in range(1,maxn+1):
        N=1<<n;w=next(x for x in range(1,K.q) if K.power(x,N)==1 and K.power(x,N//2)!=1)
        for b in range(1,n+1):
            L=n-b;F=[];grade={};T=[];tau={}
            for s in range(N):
                word=format(s,f'0{n}b');hits=[i for i in range(L+1) if word[i:i+b]=='0'*b]
                if hits and hits[-1]!=L:F.append(s);grade[s]=L-hits[-1]
                else:T.append(s);tau[s]=L-hits[-2] if len(hits)>1 else L+1
            FS=set(F);TS=set(T)
            H=collections.defaultdict(dict);C=collections.defaultdict(dict)
            for origin in F:
                layer={origin:1}
                for j in range(L):
                    nxt={}
                    for s,v in layer.items():
                        H[s,j][origin]=v
                        for y,factor in ((2*s%N,1),((2*s+1)%N,K.power(w,s))):
                            val=K.mul(v,factor)
                            if y in FS:
                                assert y not in nxt;nxt[y]=val
                            else:
                                assert origin not in C[y,j];C[y,j][origin]=val
                    layer=nxt
                assert not layer
            for yj,form in itertools.chain(H.items(),C.items()):
                y,j=yj;k=j if y in FS else j+1
                bits=[(y>>(k-1-i))&1 for i in range(k)]
                rev=sum(bit<<i for i,bit in enumerate(bits))
                gamma=sum((y%(1<<k))>>(k-i) for i,bit in enumerate(bits) if bit)
                want_origins={r*(1<<(n-k))+(y>>k) for r in range(1<<k)}
                if y in TS and tau[y]==L+1:want_origins={r*(1<<(n-k))+(y>>k) for r in range(0,1<<k,2)}
                assert set(form)==want_origins
                for origin,value in form.items():
                    assert value==K.power(w,origin*rev+gamma) and value!=0
                    counts['path_weight_comparisons']+=1
            for _ in range(3):
                x=[rng.randrange(K.q) for _ in range(N)];layer=x[:];trajectory=[layer]
                for j in range(n):
                    nxt=[0]*N
                    for s,v in enumerate(layer):
                        nxt[2*s%N]=K.add(nxt[2*s%N],v)
                        nxt[(2*s+1)%N]=K.add(nxt[(2*s+1)%N],K.mul(v,K.power(w,s)))
                    layer=nxt;trajectory.append(layer)
                for y in range(N):
                    bits=[(y>>(n-1-i))&1 for i in range(n)]
                    rev=sum(bit<<i for i,bit in enumerate(bits))
                    gamma=sum(y>>(n-i) for i,bit in enumerate(bits) if bit)
                    answer=K.mul(K.power(w,gamma),K.sum(K.mul(x[s],K.power(w,s*rev)) for s in range(N)))
                    assert answer==trajectory[n][y];counts['fourier_phase_comparisons']+=1
            counts['cases']+=1
            if not F:counts['empty_free_cases']+=1
        spec.append({'field':K.q,'characteristic':p,'quadratic_relation':f't^2={d}','n':n,'root_encoded':w})
    if p==3:
        n=3;b=1;N=8;w=next(x for x in range(1,K.q) if K.power(x,N)==1 and K.power(x,N//2)!=1)
        # The four H coefficients are x1,x3,x5,w*x1+w^5*x5.
        hist=collections.Counter()
        for x1,x3,x5 in itertools.product(range(K.q),repeat=3):
            z=K.add(K.mul(w,x1),K.mul(K.power(w,5),x5))
            hist[sum(v!=0 for v in (x1,x3,x5,z))]+=1
        total=sum(k*v for k,v in hist.items())
        assert total*K.q==(K.q-1)*4*K.q**3
        extension_average={'field':K.q,'inputs':K.q**3,'W':4,'nonzero_count_total':total,'distribution':dict(sorted(hist.items()))}
print(json.dumps({'status':'PASS','counts':dict(counts),'fields_and_roots':spec,'finite_field_average':extension_average,'imports_historical_research_code':False},sort_keys=True,indent=2))
