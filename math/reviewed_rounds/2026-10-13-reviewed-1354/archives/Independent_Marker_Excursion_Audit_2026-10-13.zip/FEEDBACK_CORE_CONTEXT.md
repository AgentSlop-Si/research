# Marker feedback core: exact closure and finite-horizon bottleneck

13 October 2026 UTC. Scoped research result. **Recommendation: 67/100 for independent review of the finite-horizon reduction and one paid inverse/recovery gate.** This is a recommendation only; no external research rank or priority is changed.

## Result in one paragraph

The retained set really can be reduced algebraically from T=A union R to R, but eliminating A inserts its cyclic transfer C(I-zD)^(-1)E. This is not a new nilpotent spatial pass. Crucially, at Fourier precision n this transfer is needed only through degree b-2, and often there can be only one A excursion. The exact remaining inverse is H_R=(I-Delta_R M_RR)^(-1). Its existing paid implementation still costs O(N(m+1)); no cheaper uniform complete inverse or selected-output recovery is proved here. A small exact counterexample shows that rank-one input/output ports can conceal a higher-order rational transfer at unrestricted precision. That obstruction is explicitly **not** a lower bound for its n-step truncation.

The useful new target is equation (12) below, with the source and recovery obligations beside it. Schur elimination, state-space realization, scalar recurrence acceleration, and FFT evaluation are classical methods; no worldwide novelty claim is made.

## 1. Model and accepted inputs

Let N=2^n, n>=2, 1<=b<n, L=n-b, h=L+1, and r=2^L. Work over any field K with a supplied omega of exact order N; characteristic two is therefore excluded. All states are fixed-length n-bit words, including leading zeros. Destination rows and column vectors are used:

    Q e_s = e_(2s mod N) + omega^s e_((2s+1) mod N).

R contains words ending in 0^b; A contains words avoiding 0^b; F is the complement of T=A union R. Thus |R|=r and |A|=a_b(n), where a_b(j) counts avoiding j-bit words. Order T as (A,R). The accepted grading is a(s)=L-p(s) for s in F, with p the rightmost marker start. Put B=Q_FF, G=(I-B)^(-1). We use the accepted identities B^L=0, A has no edge into F, and

    M = Q_TR + Q_TF G Q_FR,
    S(z) = I_T - z Q_TA (projection to A) - Delta_T(z) M (projection to R).

Every A row has delay h. For R rows, Delta_R has diagonal z^tau(y), with tau(y)=L-p2(y) when the second-rightmost marker exists, and h otherwise. Markers may overlap. M is defined algebraically and applied by its O(N) spatial circuit; it is not assumed explicitly available.

The accepted predecessor reports are included unchanged and bound by SHA-256 in PROVENANCE.json. They establish O(N) constant retained action, O(N(m+1)) causal retained inversion, and O(N+W) arbitrary free-source construction, where W=sum_(s in F) a(s). This report does not promote those accepted actions into a faster inverse.

The arithmetic model counts exact field operations and word/address operations. O(N) setup includes all root powers, membership, grading, delays, coordinate maps, and buckets. Root discovery, bit complexity, conditioning, and floating-point errors are excluded. No hidden generic-position assumption or scalar nonvanishing hypothesis is used for formal series.

At b=n, F is empty and the ordinary split of I-zQ into A and R still gives the block-elimination formulas below with h=1, E=Q_AR, and M_RR=Q_RR. The terminal-grade port census in Section 4 is restricted to b<n. No small-core complexity consequence is claimed at this boundary. n=b=1 is covered only by this direct boundary statement.

## 2. Exact retained block decomposition and R-only closure

To avoid conflicting notation in the predecessor reports, define

    D = Q_AA                 (|A| by |A|),
    C = Q_RA                 (r by |A|),
    E = M_AR                 (|A| by r),
    Z(z) = Delta_R(z) M_RR   (r by r),
    D_A(z) = I_A-zD.

The exact retained matrix is

    S(z) = [ D_A(z)       -z^h E       ]
           [ -z C        I_R-Z(z)    ].                         (1)

Consequently S Y=f is equivalent over K[[z]] to

    L_R(z) Y_R = g_R,
    L_R(z) = I_R-Z(z)-z^(h+1) Psi(z),
    Psi(z) = C D_A(z)^(-1) E,
    g_R = f_R+z C D_A(z)^(-1) f_A,                             (2)

followed by

    Y_A = D_A(z)^(-1) f_A + z^h D_A(z)^(-1) E Y_R.             (3)

Proof: solve the first row of (1) and substitute into the second. Multiplication order in (2) is essential. D_A(0)=I_A and L_R(0)=I_R, so these are unconditionally valid formal series, including over finite fields. This is an actual causal closure on r output coordinates, but its coefficients need not be polynomial and its hidden state need not have dimension r.

The matrix D is never nilpotent in this domain. The only self-loop of Q inside A is the all-one word, of weight omega^(N-1); hence trace(D)=omega^(-1) is nonzero. A nilpotent matrix has zero trace over any field. Thus the full D_A^(-1) is not a polynomial. A projected transfer Psi could in principle cancel those modes; Section 6 gives an explicit instance where it does not.

### Formal, rational, and scalar charts

Equation (2) is also a rational-function identity. At a scalar alpha, this elimination chart requires det(I-alpha D) nonzero. To invert the complete matrix in this chart additionally requires det L_R(alpha) nonzero. Since det(I-zB)=1,

    det(I-zQ) = det(I-zD) det L_R(z)                           (4)

as a rational identity. Poles in the second factor can cancel zeros in the first. A bad A pivot is not proof that the original full scalar system is singular.

Fresh exact guard: n=3, b=1, K=GF(17), omega=2, alpha=2. Here A={111}, I-alpha D=0, but det(I-alpha Q)=8 in GF(17). The scalar R-only chart fails even though the full scalar matrix is invertible. No inverse samples at such a point may be silently used; an alternate chart or a correctly justified polynomial/formal method is needed. None is needed at z=0.

## 3. Finite-horizon theorem: most of the rational transfer is irrelevant at n

Write

    H_R(z) = (I_R-Z(z))^(-1),
    J(z) = z^(h+1) Psi(z),
    ell = h+1 = n-b+2.

Both H_R and Psi have no negative powers, H_R(0)=I_R, and J has valuation at least ell. From L_R=(I-Z)(I-H_R J),

    L_R^(-1) = sum_(k>=0) (H_R J)^k H_R.                      (5)

Modulo z^(m+1), only k<=floor(m/ell) can survive. This is a finite exact identity, not a convergence or genericity claim. In particular, modulo z^(n+1), only Psi coefficients 0,...,b-2 can occur. A negative upper endpoint means there are none.

**Finite-horizon theorem.** If 2(n-b+2)>n, equivalently b<=floor((n+3)/2), then

    L_R^(-1) = H_R + H_R J H_R       modulo z^(n+1).           (6)

For b=1, J vanishes entirely at this precision. For b=2, only Psi(0)=CE is needed. The usual asymptotic choice b on the scale of log n satisfies the one-excursion condition for all sufficiently large n.

Proof: every factor J adds at least ell to degree, while all other factors have nonnegative degree. Terms with two J factors start after degree n under the displayed condition. The same argument proves (5) at arbitrary finite precision.

There is a further cost-relevant truncation: to compute H_R J H_R g through n, first compute u=H_R g through n. Its appearance inside J needs only u through b-2. The final H_R application acts on a source shifted by ell, so it too is needed only through b-2. It would be an overcharge to run the correction's second H_R solve through n.

This theorem does not make the first H_R solve cheap. It pinpoints it. Likewise, the source-side D_A^(-1) f_A is not multiplied by z^ell: arbitrary original A data still require their full relevant propagation horizon.

## 4. Exact feedback-port ranks and the allowable row compression

Put f_L=|F_L|=a_b(L-1). Then

    rank(C) = rank(E) = f_L.                                  (7)

These are exact field-independent ranks, not merely generic ranks or active-row counts.

For C, the active R rows are exactly y=p 1 0^b, with p an avoiding (L-1)-bit word. A predecessor in A exists, and the two possible predecessor coordinates of distinct rows are disjoint. Every nonzero C coefficient is 1 because the exit appends zero. Hence the f_L nonzero rows are independent. Some rows have only one A predecessor; two must not be assumed universally.

For E, the active A rows are exactly

    y = 0^(b-1) 1 v, with v an avoiding L-bit word.

There are a_b(L) such rows. Let rho=omega^(2^b), a primitive r-th root, and index the input R word as s=2^b u, 0<=u<r. For the appended word w=1v of length h, define rev_h(w)=sum_i w_i 2^i and gamma_h(w) as the sum of the preceding prefixes at the positions where w_i=1. Unique-path weights give

    E_(y,u) = omega^gamma_h(1v) rho^[u rev_h(1v)].              (8)

Every such path begins with the R-to-F one edge, avoids retention until its A exit, and has exactly h edges. If v=v'c, then modulo r,

    rev_h(1v) = 1 + 2 rev_(L-1)(v').

Thus the two permitted last-bit choices c share one Fourier row, multiplied by nonzero row phases. Every avoiding v' has at least the extension c=1. The distinct frequencies are indexed by the f_L avoiding v', and are distinct rows of an invertible r-point DFT. This proves (7).

Equivalently E=J_E F_Omega, where F_Omega has f_L Fourier rows and J_E is a phase/duplication map with at most two nonzero entries per column and one per active row. Similarly C=J_C C_0, where J_C embeds the f_L active R rows. Therefore

    Psi(z)=J_C [ C_0 (I-zD)^(-1) J_E ] F_Omega.                (9)

The external ports have dimension f_L, but the middle f_L-by-f_L transfer is still rational. Section 6 disproves equating its state dimension with its spatial port rank.

An invertible row operation can normalize one E row for each v' and subtract its multiple from the paired row. It costs O(a_b(L)) field operations after metadata is known, and its pivots are powers of omega, hence nonzero. All affected A injection rows have the same delay h. However, changing A coordinates in the whole recurrence also changes D and C. A sparse-looking E alone does not prove that the transformed D is sparse or cheap. Factoring E as above avoids changing D.

On R, row mixing across different tau values does not commute with Delta_R. Conjugating or left-preconditioning must retain the resulting polynomial delay matrix; one cannot transform M_RR to a small-rank form and leave the diagonal delay unchanged. Constant invertible input/output transformations preserve block-Hankel rank and cannot remove the obstruction in Section 6.

For just E applied to one vector, the inherited circuit costs O(N), or a full r-point radix-two transform plus row selection/phases costs O(rL+a_b(L)); the smaller valid bound may be selected. The latter uses the supplied rho and ordinary classical FFT recursion, not a new inverse algorithm. Rank factorization alone would instead charge all entries of its factors if materialized. The complete M_RR application still has only its inherited O(N) circuit bound here.

## 5. The unresolved core is explicit, including its short-return gap

Direct R-to-R edges append zero. They give a map Z_0 on the r labels u,

    Z_0 e_u=e_(2u mod r).

A non-direct return must first append 1 and then create a new marker. At least b zeros after that one are necessary, so every such return has length at least b+1. Hence

    Z(z)=z Z_0 + Z_long(z),      valuation(Z_long)>=b+1.       (10)

This is compatible with zero rows and all weighted cancellations. It does not imply that every delay b+1,...,h occurs. Z_0 has a self-loop at zero, and its remaining functional graph is a merging tree. It is not a permutation or a scalar cycle.

The precise first inverse gate is therefore

    (I_R - z Z_0 - Z_long(z)) u(z) = g(z)
                  modulo z^(n+1).                            (11)

Or, naming the audited operator and input interface directly,

    H_R : g in K[z]^r/(z^(n+1))
          -> (I_R-Delta_R M_RR)^(-1)g modulo z^(n+1).          (12)

The requested dense r-coefficient jet already has r(n+1) scalar inputs and outputs. Any better schedule must charge these, all applications of the weighted return map, row-delay addressing, and setup. Inserting the valid O(N) return circuit once per coefficient gives O(N(n+1)); the equations above do not improve that bound. Eliminating Z_0 again with (I-zZ_0)^(-1) is permissible, but the resulting delayed composition and rational factor must themselves be paid. It is not completed by noting that Z_0 is a tree with one loop.

**Testable next criterion:** produce a uniform circuit for (12) with an explicit bound C_H(n,b), preferably exploiting (10), then provide the arbitrary-source and selected-coordinate recovery costs below. A claimed small scalar recurrence must state its order, coefficient-construction cost, all needed initial values, input/output transforms, and its horizon. A dense rational or matrix inverse hidden in preprocessing does not qualify.

## 6. Certified counterexample: rank-one ports can hide more than r dynamic states

Take n=3, b=2, K=GF(17), omega=2. Then L=1, h=2, r=2,

    A=(010,011,101,110,111), R=(000,100), F=(001).

In that order, the exact matrices are

    D = [ 0  0  1  0  0 ]       C = [ 0 0 0 0 0 ]
        [ 0  0 15  0  0 ]           [ 1 0 0 1 0 ]
        [ 4  0  0 13  0 ]
        [ 0  1  0  0  1 ]       E = [ 1 16 ]
        [ 0  8  0  0  9 ]           [ 2 15 ]
                                     [ 0  0 ]
    M_RR = [ 1 1 ]                  [ 0  0 ]
           [ 0 0 ]                  [ 0  0 ].

Let e=(1,2,0,0,0)^T and c=(1,0,0,1,0). Then

    Psi(z) = [0,1]^T phi(z) [1,-1],
    phi(z) = c(I-zD)^(-1)e
           = (1+10z+15z^2+2z^3+15z^4)
             /(1+8z+13z^2+11z^3+8z^4)                      (13)

in GF(17). The numerator and denominator are coprime. The newly authored verifier checks their polynomial gcd, the first numerator coefficients, and the exact matrix annihilator

    D^5 + 8D^4 + 13D^3 + 11D^2 + 8D = 0,

which proves the rational identity at all degrees, not merely at the sampled terms.

The first coefficients of phi are

    s_0,... = 1,2,3,9,10,9,15,6,3,1,5,2,3,6,4,...

The unshifted 5-by-5 Hankel matrix (s_(i+j)) has determinant 4. The shifted 4-by-4 matrix (s_(i+j+1)) is

    [ 2  3  9 10 ]
    [ 3  9 10  9 ]
    [ 9 10  9 15 ]
    [10  9 15  6 ],

with determinant 15. Therefore an unrestricted time-invariant linear realization of phi with an allowed direct-feedthrough term needs at least four dynamic states. The degree-four rational expression supplies an order-four realization, so the minimum is exactly four. It exceeds both the port rank one and the core coordinate count r=2.

Delay conventions matter. A realization of the form C'(I-zD')^(-1)E' without separately allowed feedthrough has unshifted Hankel rank five. The actual A-feedback scalar branch is z^3 phi(z); its strictly proper standard Markov Hankel has rank seven, checked explicitly. In lambda=z^(-1), its coprime denominator is lambda^3(lambda^4+8lambda^3+13lambda^2+11lambda+8), which also gives order seven. External delays are not free states.

This proves an obstruction to an unrestricted two-state linear closure of this feedback branch. It is **not** an arithmetic-operation lower bound; it does not prohibit higher-order scalar recurrences, sparse realizations, nonlinear arithmetic algorithms, time-varying finite-horizon circuits, or a faster complete transform.

### Why this witness does not block the Fourier horizon

At the requested n=3 horizon,

    z^3 Psi(z) = z^3 [ [0,0], [1,16] ] modulo z^4.

Only s_0 survives. None of the higher-order dynamics used in the Hankel certificate appears. The exact truncated core matrix is simply

    I - z [ [1,1], [0,0] ] - z^3 [ [0,0], [1,16] ] modulo z^4.

Claiming that the rational order-seven branch prevents a cheaper three-step computation would be invalid. The finite-horizon theorem, not the unrestricted realization witness, controls the scope of the n-step problem.

Exploratory fresh instances through n=6 had unshifted block-Hankel rank |A|. Those data are included only as finite evidence. No all-n minimality conjecture is promoted to a theorem, and the corresponding shifted ranks must be distinguished.

## 7. Arbitrary original sources, output interfaces, and recovery

For an arbitrary newly supplied x in K^N, let Y=(I-zQ)^(-1)x. The accepted source is

    f_T=x_T+z Q_TF (I-zB)^(-1)x_F.                            (14)

It has at most 2N structural scalar slots and can be constructed in O(N+W) operations. The source-side part of (2) requires

    a^0=(I-zD)^(-1) f_A,
    g_R=f_R+z C a^0.                                         (15)

A sparse D recurrence computes a^0 through m in O(|A|(m+1)+input slots), including coefficient input and current-state updates. C has at most 2|A| nonzeros, so its propagation fits this bound. A dense g_R jet adds r(m+1) writes and storage. The existence of a small original source does not grant a small representation of all later g_R values.

Free recovery is exactly

    Y_F=(I-zB)^(-1)x_F + diag_(s in F)(z^a(s)) P Y_R,
    P=G Q_FR.                                                (16)

At degree n the first summand is zero, because B^L=0 and L<n, but

    [Y_F]_s,n = [ P [z^(n-a(s))]Y_R ]_s.                     (17)

The required R time depends on the output row. Equation (17) is not one P multiplication on one common vector. The naive paid implementation scatters P Y_R,j for the relevant j, at O(N) work per spatial pass; through the full jet this gives O(N(m+1)), not a smaller bound. A selected-coefficient recovery algorithm with fewer passes remains an additional gate. The actual full transform output has N scalars; no lower bound for emitting an entire polynomial is claimed to rule out a faster selected coefficient.

For A output, (3) has a^0_n plus the R-injected response. At degree n the injected part needs R coefficients only through n-h=b-1. This shorter range is valid for recovery, whereas the A-to-R feedback uses the still shorter range b-2. They must not be conflated.

### Conditional one-excursion ledger

For the parameter range of (6), suppose a routine for H_R through q is available at fully paid cost C_H(q;b,N), with setup shared once. Put C_E=O(min(N,rL+a_b(L))) for one E application. The source plus R-only solution can be computed with the following upper-bound ledger:

- O(N) common setup and O(N+W) original source construction.
- O(|A|(n+1)+r(n+1)) source-side A propagation and dense g_R writes.
- One C_H(n;b,N) solve.
- At most b-1 E applications and O(|A|(b-1)+r(b-1)) causal propagation/assembly for J through n.
- One C_H(b-2;b,N) correction solve when b>=2; no correction solve when b=1.
- Addition/coalescing of the shifted correction, with all requested r(n+1) outputs charged.

The J step may be computed as a short driven D recurrence; no dense Psi_j matrices are required. The displayed bound is a conditional reduction, not a proven faster algorithm. To complete Q^n x, add A and F recovery, including the row-dependent time selection in (17). Using the available O(N(q+1)) routine for C_H and the available recovery never proves a sub-Nn result. If |A| is nearly N, source-side propagation alone returns to that reference bound; if |A| is small, the remaining core and recovery can still dominate.

No source, kernel, characteristic polynomial, rational matrix, FFT, inverse, rank factorization, or change of coordinates is prepared for free. Dense storage of Psi_0,...,Psi_q would have up to r^2(q+1) entries, and constructing it by basis actions costs additional work even when its symbolic definition is short.

## 8. Classical comparisons and novelty boundary

1. **Block elimination.** Sanjay Lall's Stanford EE263 matrix notes give the nonsymmetric block LDU identity and inverse using D-CA^(-1)B (slides 6-7). Equations (1)-(4) are direct specializations, not a new Schur-complement principle. [Matrix facts](https://ee263.stanford.edu/lectures/matrix_facts.pdf)

2. **Rational realizations and Hankel rank.** Fazel, Hindi, and Boyd connect finite impulse responses and LTI realization order through Hankel rank, especially Section V. The lower bound used here is reproved algebraically: an order-d realization factors every appropriate Hankel block through a d-dimensional state, so its rank is at most d over any field. Thus no real-field numerical assumption is imported into the GF(17) certificate. [Rank Minimization and Applications in System Theory](https://web.stanford.edu/~boyd/papers/pdf/rank_min_sys_theory.pdf)

3. **Scalar recurrences.** Fiduccia gives O(M(k) log m) computation of a remote term of a known order-k recurrence using polynomial arithmetic. Applying that classical result here would still require the correct recurrence order, its coefficients, necessary initial terms, and all source/output transforms. Low port rank supplies none of those for free. Only the publisher's abstract was needed for this comparison. [An Efficient Formula for Linear Recurrences](https://epubs.siam.org/doi/10.1137/0214007)

4. **Polynomial/rational system solving.** Storjohann reduces rational-system and related polynomial-matrix computations to polynomial matrix multiplication via high-order lifting. This is relevant precedent if (12) is attacked by polynomial matrix inversion; its matrix dimension, degree, multiplication, and input construction must all be paid. Merely naming lifting is not a complexity improvement for the implicit marker operator. [High-order lifting and integrality certification](https://cs.uwaterloo.ca/~astorjoh/jlift.pdf)

5. **Fourier port evaluation.** The O(r log r) fallback for the Fourier rows in (8) is the classical Cooley-Tukey factorization, whose radix-two algebra works here with the supplied primitive r-th root. The new observation in this packet is the precise marker-port identification and rank, not the transform algorithm. [An Algorithm for the Machine Calculation of Complex Fourier Series](https://www.ece.ucdavis.edu/~bbaas/281/papers/CooleyTukey.1965.pdf)

The accepted marker reviews already document overlap with marker hitting sets, acyclic path summation, and retiming. This packet relies on those accepted results and does not claim a fresh exhaustive literature search. The finite-horizon degree bookkeeping is an elementary Neumann-series specialization, valuable as a scoped reduction rather than evidence of worldwide novelty.

## 9. Fresh exact controls and disposition

No historical or downloaded research program was executed or imported. core_controls.py and verify_core.py were newly authored for this task; the latter imports only the former. They use exact modular arithmetic and the Python standard library. One exploratory symbolic calculation was performed using the installed SymPy package; all delivered certificate checks use the new standard-library code. Current official Library-transfer helpers were used only to preserve the deliverable.

The replay is byte-identical. The all-basis suite covers GF(17), GF(97), and GF(257), 31 parameter cases through n=6, with horizon 2n+2 for source/closure/recovery and horizon n for the finite Neumann identities. It includes:

- 780 original full-state basis sources, covering arbitrary x by linearity.
- 337,756 retained response comparisons to direct full Q propagation.
- 93,336 R-only Schur-closure comparisons.
- 244,420 A and 105,076 F recovery comparisons.
- 15,164 finite-Neumann basis coefficient comparisons; 30 cases satisfy the one-excursion theorem, with 15,136 corresponding comparisons.
- 37,545 literal retained space-time impulse-basis comparisons through n=4, not only constant source tests.
- 490 exact Fourier-port entries, plus both port ranks and the short-return gap in all 31 cases.
- Explicit rational, polynomial-gcd, matrix-annihilator, Hankel determinant, delayed-state-order, and singular-chart certificates.

These are correctness controls, not benchmarks or proofs of asymptotic speed. The all-size proofs above establish the scoped identities and ranks.

**Established here:** exact T=(A,R) decomposition and R-only closure; scalar-chart guard; finite-horizon excursion theorem; exact port ranks and Fourier row factorization; a small unrestricted realization counterexample; and the specific delayed R-return inverse and selected recovery that remain unpaid for any improvement.

**Not established:** a uniform cheaper inverse, uniform O(N) or sub-NlogN full composition, an arithmetic lower bound, an all-size minimal-realization theorem, a scalar-cycle reduction, or worldwide novelty. The current accepted full retained inverse remains O(N(m+1)). No external Sheet, repository, or publication was changed.
