# Independent marker excursion audit

Verdict: ACCEPT of the all-domain valuation lemma, one-correction identity, and O(r(b-1)) final correction solve, with the scope described in INDEPENDENT_REVIEW.md.

Start with INDEPENDENT_REVIEW.md. The reviewed source and original candidate context are included unchanged and bound by MANIFEST.json. This is a private research evidence packet; it makes no research-score, repository, publication, or sharing changes.

The independently authored fresh_verify.py uses Python 3's standard library only. From this extracted folder, run:

    python fresh_verify.py > LOCAL_REPLAY.json

The result should match CONTROLS.json byte for byte. The script checks the frozen strengthening's hash before running. The included REPLAY_CONTROLS.json is already byte-identical to CONTROLS.json. Neither the producer's verifier nor historical research code is needed or executed.

The report includes the full proof, finite-field cancellation boundaries, source/output charges, and a separately identified large-b corollary. The result does not establish a faster complete Fourier algorithm or a uniformly improved first inverse.
