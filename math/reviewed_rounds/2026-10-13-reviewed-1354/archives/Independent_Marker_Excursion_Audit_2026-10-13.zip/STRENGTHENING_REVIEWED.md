# New marker excursion valuation lemma

13 October 2026 UTC. **New review finding, awaiting a separate independent review.** This file is separate from the scoped ACCEPT of the frozen feedback-core candidate. It does not change a research score or establish a faster Fourier algorithm.

## Statement

Use the candidate's domain and notation: n>=2, 1<=b<n, N=2^n, L=n-b, h=L+1, and a field with omega of exact order N. Destination rows and column vectors are used. R consists of n-bit words ending in 0^b, A of words avoiding 0^b, and F is their complement. Let

    D=Q_AA, C=Q_RA, E=M_AR,
    Psi(z)=C(I-zD)^(-1)E,
    J(z)=z^(h+1)Psi(z),
    Z(z)=Delta_R(z)M_RR,
    H_R(z)=(I-Z(z))^(-1).

The following bound holds, including when its actual leading coefficient cancels:

    val J >= d := max(n-b+2, b+1).                         (S1)

Consequently, for every 1<=b<n, not merely the candidate's sufficient subrange,

    (I-Z-J)^(-1) = H_R + H_R J H_R   modulo z^(n+1).        (S2)

Equivalently, Psi has zero coefficients below

    delta := max(0, b-L-1) = max(0, 2b-n-1).               (S3)

These are formal-series statements. No scalar specialization, nonvanishing pivot, or analytic convergence is assumed.

## Proof of the extra delay

The accepted first-return description says that each monomial path represented by E starts in R, passes only through F before reaching A, and has exactly h edges. Such a path cannot start by appending zero: that edge remains in R, so it would already have returned. It therefore starts by appending one.

A coefficient of z^(h+1+k) in J is a weighted sum of paths consisting of this h-edge first passage to A, then k edges within A, then one A-to-R edge. Every such path starts with the same R-to-F append-one edge. Its final state ends in b zeros.

After that first append-one edge, at least b subsequent edge steps are needed before the state can end in b zeros. If fewer than b steps have elapsed, the first appended one still lies among the last b bits. This rules out a final R state, regardless of which of the subsequent bits were appended. Equivalently, any final suffix of b zeros must be formed entirely after that first one. Hence each complete path contributing to J has at least b+1 edges.

The same paths already have at least h+1=L+2 edges by their definition. Thus no path has length below max(L+2,b+1). Summing their weights cannot create a lower-degree term, even over a finite field or when higher-degree terms cancel. This proves (S1), and dividing the fixed factor z^(L+2) yields (S3).

Because H_R(0)=I_R and H_R has no negative powers,

    (I-Z-J)^(-1) = sum_(k>=0) (H_R J)^k H_R.

A term with two J factors has degree at least 2d. Since

    2d >= (L+2)+(b+1) = n+3 > n,

all terms with k>=2 vanish modulo z^(n+1). This proves (S2). The proof neither requires nor asserts that d is always the exact valuation.

## Consequence for the correction solve

This paragraph is an additional new corollary, also awaiting the separate independent review.

The candidate's short-return gap is Z(z)=z Z_0+O(z^(b+1)), where Z_0 e_u=e_(2u mod r). For q=b-2>=0,

    H_R(z) = (I-zZ_0)^(-1) modulo z^(q+1).                 (S4)

The correction can therefore be evaluated with the original shift ell=L+2 by

    u=H_R g through n,
    v=Psi u through q,
    w_t=v_t+Z_0 w_(t-1), 0<=t<=q,
    result = u + z^ell w modulo z^(n+1).

Since a Z_0 application is a single scatter over r entries, this second solve costs O(r(q+1))=O(r(b-1)) exact field/address operations, including its dense input/output, with the coordinate metadata already charged. For b=1 the correction is absent. This only simplifies the short correction solve; it leaves the first arbitrary-source H_R solve through n unresolved.

If one instead factors J=z^d Jbar using (S1), the final H_R solve needs only n-d=min(b-2,L-1) coefficients beyond degree zero. Computing Jbar must still pay for the needed D propagation and port application; the factorization supplies no free preprocessing.

## Fresh finite evidence

The independently authored independent_controls.py builds Q directly from its two outgoing edges, enumerates first returns through F, and forms E, C, and D. It asserts (S1) and (S3) on the actual exact coefficient matrices, then verifies (S2) on full-state sources through the n-step horizon.

The suite contains 37 parameter cases with 2<=n<=7 over GF(17), GF(97), and GF(257). It includes all original full-state basis sources when n<=5, plus two dense polynomial source jets per case. There are 460 constant basis sources, 74 dense forced jets, and 19,732 scalar n-horizon R comparisons for the one-correction formula. Two cases lie outside the candidate's sufficient condition: (n,b)=(6,5) and (7,6), both over GF(257). In those cases d equals 6 and 7 respectively, and the one-correction formula passes.

The controls also verify the short correction solve as originally shifted by ell. A direct Z_0-only recurrence check is included in the subsequent correction-only control file, when present in the final packet. Finite prime-field tests do not replace the all-field path proof above.

## Scope and stopping point

This new lemma expands the parameter domain of an exact reduction. It does not solve the first H_R inverse, remove arbitrary-source propagation in A, supply selected-time free recovery, prove an arithmetic lower bound, or establish a sub-Nn/sub-FFT algorithm. Those gates and their costs remain as stated in the independently reviewed candidate. Treat this strengthening as a separately reviewable candidate, not as already independently accepted.
