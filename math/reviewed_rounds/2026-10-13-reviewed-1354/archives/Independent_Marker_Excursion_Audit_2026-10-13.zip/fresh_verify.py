"""Fresh exact audit; imports no producer or historical research code.

Run with Python 3. Standard-library arithmetic only. Graph entries are built
directly from append-bit transitions. Output is deterministic JSON on stdout.
"""
from collections import defaultdict
import hashlib
import json
from pathlib import Path


SOURCE = Path(__file__).resolve().parent / 'STRENGTHENING_REVIEWED.md'
EXPECTED = '9c43462c56d68c79e1f4e6335c07091c128ba3fb23de2b23e8fc75805f356e2d'


def add(a, b, p):
    return [(x + y) % p for x, y in zip(a, b)]


def apply(edges, v, size, p):
    out = [0] * size
    for i, j, w in edges:
        out[i] = (out[i] + w * v[j]) % p
    return out


def causal(coeff, g, size, p):
    """Solve y = g + K y for K(0)=0 by direct coefficient recurrence."""
    y = []
    for t, source in enumerate(g):
        v = source[:]
        for lag, edges in coeff.items():
            if 1 <= lag <= t:
                v = add(v, apply(edges, y[t-lag], size, p), p)
        y.append(v)
    return y


def convolution(coeff, u, m, size, p):
    v = [[0] * size for _ in range(m+1)]
    for t in range(m+1):
        for lag, edges in coeff.items():
            if 0 <= lag <= t:
                v[t] = add(v[t], apply(edges, u[t-lag], size, p), p)
    return v


def prime(p):
    return p >= 2 and all(p % d for d in range(2, int(p**0.5)+1))


def root(p, n):
    N = 1 << n
    assert prime(p) and (p-1) % N == 0
    for a in range(2, p):
        w = pow(a, (p-1)//N, p)
        if pow(w, N, p) == 1 and pow(w, N//2, p) != 1:
            return w
    raise AssertionError('no primitive root found')


def case(n, b, p, invert=False):
    N, L, r = 1 << n, n-b, 1 << (n-b)
    h, ell, d = L+1, L+2, max(L+2, b+1)
    delta, q = max(0, b-L-1), b-2
    w = root(p, n)
    if invert:
        w = pow(w, p-2, p)
    words = [format(s, f'0{n}b') for s in range(N)]
    R = [s for s in range(N) if s % (1 << b) == 0]
    A = [s for s in range(N) if '0'*b not in words[s]]
    F = [s for s in range(N) if s not in set(A) | set(R)]
    ix = {name: {s:i for i,s in enumerate(group)} for name,group in [('A',A),('R',R),('F',F)]}
    aset, rset, fset = set(A), set(R), set(F)
    edges = [(2*s % N, s, 1) for s in range(N)] + [((2*s+1) % N, s, pow(w,s,p)) for s in range(N)]
    adj = defaultdict(list)
    for dest,src,weight in edges:
        adj[src].append((dest,weight))
    def block(to, fr):
        return [(ix[to][i],ix[fr][j],x) for i,j,x in edges if i in ix[to] and j in ix[fr]]
    D,C,B,QAF,QRF,QFR = block('A','A'),block('R','A'),block('F','F'),block('A','F'),block('R','F'),block('F','R')
    assert not block('F','A')
    E0, Z0, P0 = defaultdict(int), defaultdict(int), defaultdict(int)
    lengths_to_A, lengths_to_R, lengths_to_F = set(), defaultdict(set), defaultdict(set)
    # Enumerate first retention literally, without using the grading or delay theorem.
    for j,s in enumerate(R):
        frontier = [(s,1)]
        for t in range(1,h+1):
            nxt=[]
            for old,weight in frontier:
                for dest,eweight in adj[old]:
                    x = weight*eweight % p
                    if dest in aset:
                        lengths_to_A.add(t)
                        E0[ix['A'][dest],j] += x
                    elif dest in rset:
                        lengths_to_R[dest].add(t)
                        Z0[t,ix['R'][dest],j] += x
                    else:
                        assert dest in fset
                        lengths_to_F[dest].add(t)
                        P0[ix['F'][dest],j] += x
                        nxt.append((dest,x))
            frontier=nxt
        assert not frontier
    assert lengths_to_A == {h}
    tau={}
    grade={}
    for s in R:
        starts=[i for i in range(L+1) if words[s][i:i+b]=='0'*b]
        tau[s] = L-starts[-2] if len(starts)>1 else h
        assert lengths_to_R.get(s,set()) <= {tau[s]}
    for s in F:
        starts=[i for i in range(L+1) if words[s][i:i+b]=='0'*b]
        grade[s]=L-starts[-1]
        assert lengths_to_F.get(s,set()) <= {grade[s]}
    E=[(i,j,x%p) for (i,j),x in E0.items() if x%p]
    P=[(i,j,x%p) for (i,j),x in P0.items() if x%p]
    Z=defaultdict(list)
    for (t,i,j),x in Z0.items():
        if x%p:
            Z[t].append((i,j,x%p))
    scatter=[(2*j%r,j,1) for j in range(r)]
    assert sorted(Z[1])==sorted(scatter)
    assert all(not Z[t] for t in range(2,b+1))
    if b>=L+1:
        assert all(not v for t,v in Z.items() if t>1)
    # Build the actual field-valued transfer, independently of path lower bounds.
    psi=defaultdict(list)
    first_J=None
    cancellation_entries=0
    cancellation_witness=None
    for j in range(r):
        v=apply(E,[int(i==j) for i in range(r)],len(A),p)
        reach={i for i,jj in E0 if jj==j}
        for k in range(n+2):
            c=apply(C,v,r,p)
            structural={i for i,jj,_ in C if jj in reach}
            assert not structural if k<delta else True
            for i,x in enumerate(c):
                cancellation_entries += int(i in structural and x==0)
                if i in structural and x==0 and cancellation_witness is None:
                    cancellation_witness=dict(psi_degree=k,R_destination=R[i],R_source=R[j])
                if x:
                    assert ell+k>=d
                    first_J=min(first_J,ell+k) if first_J is not None else ell+k
                    psi[k].append((i,j,x))
            v=apply(D,v,len(A),p)
            reach={i for i,jj,_ in D if jj in reach}
    assert first_J is None or first_J>=d
    J={ell+k:es for k,es in psi.items() if ell+k<=n}
    kernel={t:list(Z[t])+list(J.get(t,[])) for t in range(1,n+1)}
    def solve(g):
        u=causal(Z,g,r,p)
        exact=causal(kernel,g,r,p)
        corr=causal(Z,convolution(J,u,n,r,p),r,p)
        result=[add(x,y,p) for x,y in zip(u,corr)]
        assert result==exact
        if b==1:
            assert result==u
        else:
            v=convolution(psi,u,q,r,p)
            short=causal({1:scatter},v,r,p)
            full_short=causal(Z,v,r,p)
            assert short==full_short
            original=[row[:] for row in u]
            for t in range(q+1):
                original[ell+t]=add(original[ell+t],short[t],p)
            assert original==exact
        if d<=n:
            bar={t-d:es for t,es in J.items()}
            v=convolution(bar,u,n-d,r,p)
            short=causal({1:scatter},v,r,p)
            shifted=[row[:] for row in u]
            for t in range(n-d+1):
                shifted[d+t]=add(shifted[d+t],short[t],p)
            assert shifted==exact
        return result
    # All R impulse basis sources establish the truncated matrix identity.
    for j in range(r):
        g=[[int(i==j) if t==0 else 0 for i in range(r)] for t in range(n+1)]
        solve(g)
    for seed in range(2):
        solve([[(i*i+13*t+7*i*t+11*seed+3)%p for i in range(r)] for t in range(n+1)])
    # General time-dependent full-state sources exercise source and recovery.
    for seed in range(2):
        x=[[(7*s*s+3*t*t+11*s*t+17*seed+1)%p for s in range(N)] for t in range(n+1)]
        direct=causal({1:edges},x,N,p)
        free=causal({1:B},[[row[s] for s in F] for row in x],len(F),p)
        fA=[[row[s] for s in A] for row in x]
        fR=[[row[s] for s in R] for row in x]
        for t in range(1,n+1):
            fA[t]=add(fA[t],apply(QAF,free[t-1],len(A),p),p)
            fR[t]=add(fR[t],apply(QRF,free[t-1],r,p),p)
        a0=causal({1:D},fA,len(A),p)
        g=[row[:] for row in fR]
        for t in range(1,n+1):
            g[t]=add(g[t],apply(C,a0[t-1],r,p),p)
        yr=solve(g)
        assert yr==[[row[s] for s in R] for row in direct]
        injection=[[0]*len(A) for _ in range(n+1)]
        for t in range(h,n+1):
            injection[t]=apply(E,yr[t-h],len(A),p)
        ya=[add(a,z,p) for a,z in zip(a0,causal({1:D},injection,len(A),p))]
        assert ya==[[row[s] for s in A] for row in direct]
        py=[apply(P,row,len(F),p) for row in yr]
        yf=[[ (free[t][i]+(py[t-grade[s]][i] if t>=grade[s] else 0))%p for i,s in enumerate(F)] for t in range(n+1)]
        assert yf==[[row[s] for s in F] for row in direct]
    return dict(n=n,b=b,p=p,omega=w,r=r,A=len(A),F=len(F),d=d,delta=delta,
                first_J_degree_tested=first_J,old_range=2*ell>n,
                R_basis_sources=r,R_dense_sources=2,full_state_dense_sources=2,
                inverse_scalar_checks=(r+4)*r*(n+1),full_recovery_scalar_checks=2*N*(n+1),
                structural_entries_canceled=cancellation_entries,
                cancellation_witness=cancellation_witness,
                full_H_is_scatter_only=b>=L+1)


def main():
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED
    cases=[]
    for p,nmax in [(5,2),(17,4),(97,5),(257,8),(65537,9)]:
        for n in range(2,nmax+1):
            for b in range(1,n):
                cases.append(case(n,b,p))
    for n in range(6,10):
        for b in range((n+3)//2+1,n):
            cases.append(case(n,b,65537,invert=True))
    report=dict(status='PASS',source_sha256=EXPECTED,historical_research_code_executed=False,
                fresh_code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                parameter_cases=len(cases),outside_old_range=sum(not c['old_range'] for c in cases),
                totals={k:sum(c[k] for c in cases) for k in ['R_basis_sources','R_dense_sources','full_state_dense_sources','inverse_scalar_checks','full_recovery_scalar_checks','structural_entries_canceled']},
                cases=cases)
    print(json.dumps(report,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
