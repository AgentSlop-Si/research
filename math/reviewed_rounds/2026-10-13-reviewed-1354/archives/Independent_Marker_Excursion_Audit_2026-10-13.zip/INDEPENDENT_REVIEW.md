# Independent audit of the all domain marker excursion lemma

13 October 2026 UTC.

## Verdict

**ACCEPT, with scope clarified.** The frozen strengthening correctly proves

    val(J) >= max(n-b+2, b+1)
    (I-Z-J)^(-1) = H_R + H_R J H_R mod z^(n+1)

for every integer n >= 2 and 1 <= b < n, over every field containing the supplied root omega of exact order 2^n. The correction's final H_R application can be implemented in O(r(b-1)) exact field and address operations for b >= 2; for b = 1 it is absent. No mathematical repair to S1–S4 is required. The recurrence uses the standard initialization w_(-1) = 0.

This is acceptance of an exact finite-horizon reduction and its short correction cost. It does not establish a uniformly cheaper first H_R inverse, faster arbitrary-source propagation, cheaper selected-time recovery, an arithmetic lower bound, or a faster full Fourier transform. “The first inverse remains unresolved” should mean a uniform improved inverse in the remaining parameter regimes; a simple large-b subrange is identified separately below.

## Frozen sources and independence

The audited strengthening is bound to SHA-256

    9c43462c56d68c79e1f4e6335c07091c128ba3fb23de2b23e8fc75805f356e2d

The source is copied unchanged as STRENGTHENING_REVIEWED.md. FEEDBACK_CORE_CONTEXT.md is an unchanged copy of the original candidate report, used for its definitions and the previously accepted first-return and source/recovery interfaces. MANIFEST.json binds all included bytes. This audit does not reopen every classical comparison or prior theorem in that report.

The verifier fresh_verify.py was independently written for this audit. It constructs the graph directly from its two outgoing edges, uses Python's standard library, and neither executes nor imports producer or historical research programs. The producer's finite results were read only as context. The new controls and byte-identical replay are independent corroboration, not substitutes for the proof.

## Definitions and accepted first return interface

Let N = 2^n, L = n-b, h = L+1, r = 2^L. States are n-bit words. Destination rows and column vectors use

    Q e_s = e_(2s mod N) + omega^s e_((2s+1) mod N).

R consists of words ending in b zeros; A consists of words avoiding b consecutive zeros; F is the complement of A union R. Let

    D = Q_AA, C = Q_RA, E = M_AR,
    Psi = C(I-zD)^(-1)E,
    Z = Delta_R M_RR, H_R = (I-Z)^(-1),
    J = z^(h+1) Psi.

The accepted retained construction represents every E path as an R-to-A first passage of exactly h edges, with all internal states in F. The accepted return polynomial Z has no constant coefficient and degree at most h. These are explicit premises inherited from the original report, not newly inferred cheap implementation assumptions. The fresh verifier also checks them independently on its finite cases.

## Proof of the valuation bound

An E path cannot begin by appending zero: that would immediately reach R again and hence end the first-return path before reaching A. Thus its first appended bit is one. Because b < n, after that first step the original trailing marker has not yet been shifted completely out; this step indeed lands in F.

The coefficient of z^(L+2+k) in J is C D^k E. Its contributing paths consist of the h-edge first passage to A, then k edges staying in A, then one edge into R. Every such path has at least L+2 edges.

After the initial append-one step, fewer than b additional edge steps cannot produce a state in R. The initial appended one would still occupy one of the last b bit positions. Ending in b zeros therefore requires at least b further steps and at least b+1 total edges. This argument concerns each contributing path before summing field weights. It does not require that paths of any permitted length survive cancellation.

Consequently every coefficient of J below

    d = max(L+2, b+1)

is zero. Equivalently, since J = z^(L+2) Psi,

    val(Psi) >= delta = max(0, b-L-1) = max(0, 2b-n-1).

This proves S1 and S3 for all fields in the stated domain. The valuation of the zero matrix series is taken to be infinity. Matrix-entry cancellations may raise a valuation and cannot create a coefficient in a degree unsupported by paths. The proof does not assert sharpness of d.

## Proof of the all domain inverse identity

Both inverses used here exist formally: I-zD and I-Z have identity constant term. No scalar specialization, nonzero scalar pivot assumption, or convergence is required. Multiplication order is preserved by

    I-Z-J = (I-Z)(I-H_R J).

Therefore

    (I-Z-J)^(-1)
      = sum_(k>=0) (H_R J)^k H_R
      = H_R + H_R J H_R + H_R J H_R J H_R + ... .

All H_R coefficients have nonnegative degree. A term with at least two J factors has valuation at least 2d. Since

    2d >= (L+2)+(b+1) = n+3 > n,

every such term vanishes modulo z^(n+1). This proves S2 for every 1 <= b < n, including the parameters excluded by the original sufficient condition 2(L+2) > n. This formal algebra remains valid for arbitrary polynomial or power-series source vectors, not just constant sources.

## Proof and accounting for the short correction

The accepted short-return gap is

    Z = z Z_0 + O(z^(b+1)),
    Z_0 e_u = e_(2u mod r).

Let K = (I-zZ_0)^(-1). The resolvent identity gives

    H_R - K = H_R (Z-zZ_0) K,

so H_R and K agree in every degree below b+1. In particular they agree modulo z^(q+1), q = b-2 >= 0, as required by S4. This argument also preserves matrix multiplication order.

For an arbitrary core source g through degree n, compute

    u = H_R g through degree n,
    v = Psi u through degree q,
    w_(-1) = 0,
    w_t = v_t + Z_0 w_(t-1), 0 <= t <= q.

Then u + z^(L+2) w is exactly (I-Z-J)^(-1)g through degree n. The leftmost H_R only acts through q after removal of the fixed shift. This cost statement concerns that final solve alone.

A Z_0 application is a merging scatter, not a permutation. Copy v_t to w_t and, for each u label, add the preceding coefficient to destination 2u mod r. There are O(r) reads, writes, address operations, and field additions per time step. Over q+1 = b-1 steps, the cost is O(r(b-1)), including dense correction input and output and the final shifted addition. Coordinate metadata and common setup must already have been charged. No matrix materialization or inverse precomputation is implicit in this bound.

When J is instead factored as z^d Jbar, the final inverse needs degrees zero through

    n-d = min(b-2, L-1).

The corresponding solve costs O(r(n-d+1)) when this endpoint is nonnegative. Obtaining Jbar's coefficients still requires the necessary E applications and D propagation; removing leading zeros is not free kernel construction.

## Boundary and cancellation checks

- **b = 1.** L+2 = n+1, so J contributes nothing modulo z^(n+1). There are no correction coefficients and no short correction solve. The notation q = -1 means an empty truncation, not a degree-zero solve.
- **b = 2.** Only degree zero of Psi is used with the original shift. The short solve is w_0 = v_0 and costs O(r).
- **b = n-1.** L = 1 and d = n. Only J's degree-n coefficient can contribute. Factoring the actual forced shift d leaves only degree zero of the final H_R application. The longer original-shift implementation remains valid but is not tight.
- **Finite fields.** The proof uses support before weighted summation. The controls found 104 structurally supported transfer entries that vanished after exact field summation at tested degrees, while all asserted identities remained true. This number is evidence of entrywise cancellation; it is not evidence that the whole leading coefficient cancels or that the bound is ever strict. In the tested cases the first nonzero J coefficient equalled d.
- **Outside the domain.** No statement here automatically extends the port description or cost bound to b = n, n = 1, fields without a supplied root of the required order, scalar evaluation at a singular pivot, bit complexity, or floating-point accuracy.

## Separate large b corollary

This paragraph is an additional audited consequence of the accepted return-degree ceiling and gap, rather than a premise needed to prove S1–S4.

If 2b > n, equivalently b > L, then b+1 > h. Since Z has degree at most h, while Z-zZ_0 has valuation at least b+1, it follows that

    Z = z Z_0 exactly,
    H_R = (I-zZ_0)^(-1) exactly.

Thus in this subrange the first arbitrary dense-source H_R solve through degree n can itself use the scatter recurrence in O(r(n+1)) field and address operations, including its dense r(n+1)-coefficient input/output. This follows directly from the already stated degree bounds; no rank or generic-position premise is introduced. The verifier checks the exact absence of long returns in every tested case in this subrange.

This does not produce a faster full transform. A union bound gives

    |A| >= N-(L+1)r.

For b > L, b >= 2 and (L+1)/2^b <= b/2^b <= 1/2, hence |A| >= N/2. The inherited source routine explicitly propagating the full A jet therefore still handles Theta(N(n+1)) scalar state slots. A different cheaper source/output algorithm is neither established nor ruled out by this observation. The uniform inverse problem at smaller b also remains open.

## Remaining source and output ledger

The accepted arbitrary original-source construction is

    f_T = x_T + z Q_TF (I-zB)^(-1) x_F,
    a^0 = (I-zD)^(-1) f_A,
    g_R = f_R + z C a^0.

Its inherited ledger retains O(N) common setup, O(N+W) original-source construction, and O(|A|(n+1)+r(n+1)) source-side propagation and dense g_R writes. The source-side D inverse is not shifted by L+2 and is not truncated to b-2 for free.

The short transfer construction remains separately charged: at most b-1 E applications, each with the valid inherited or Fourier-port cost, plus O(|A|(b-1)+r(b-1)) driven D propagation and assembly. The O(r(b-1)) result replaces only the former second inverse gate in this ledger.

For A recovery,

    Y_A = a^0 + z^h (I-zD)^(-1) E Y_R.

The degree-n injected term uses R degrees only through b-1, but the unshifted a^0 term still needs its full relevant horizon. E and D actions and all requested output writes are paid.

For F recovery,

    Y_F = (I-zB)^(-1)x_F + diag(z^a(s)) P Y_R,
    [Y_F]_(s,n) = [P [z^(n-a(s))]Y_R]_s

for constant original x at the Fourier horizon. The selected R time depends on s. This is not one P application to a common vector; the existing implementation may require multiple paid spatial passes, with the available full-jet upper bound O(N(n+1)). Any cheaper selected-output schedule remains an additional gate, also in the large-b subrange. The final N transform outputs must be emitted. None of these observations is an arithmetic lower bound against other algorithms.

## Fresh exact evidence

The new suite passes 87 parameter/root cases with 2 <= n <= 9 over GF(5), GF(17), GF(97), GF(257), and GF(65537), including inverse roots in extra large-b cases. There are 16 cases outside the old sufficient one-excursion range.

The suite independently enumerates first retention through F, checks row delays and F grades, constructs D/C/E/Z directly, and checks the full field-valued transfer matrices through the tested horizon. It verifies both the original-shift and valuation-shift short solves. It includes:

- 1,590 R impulse-basis sources, proving the tested truncated inverse matrices by linearity and time-shift invariance.
- 174 dense polynomial core sources and 174 dense polynomial full-state sources.
- 1,436,652 scalar core inverse comparisons, including the induced full-state sources.
- 219,768 scalar full-state source/recovery comparisons against direct full-Q coefficient propagation.
- 104 exact canceled transfer entries despite structural path support.

CONTROLS.json and REPLAY_CONTROLS.json are byte-identical. The test suite is finite evidence of correctness and indexing, not a complexity benchmark or all-size proof. The all-size claims accepted here are established by the preceding path and formal-series arguments.

## Final disposition

Accept the frozen strengthening as a parameter-domain improvement to the exact marker reduction and as a cheap final correction solve. Keep the original common setup, source construction, first inverse where nontrivial, transfer assembly, and selected-output recovery gates explicit. No external research score, spreadsheet, repository, publication, or sharing permission is changed by this audit.
