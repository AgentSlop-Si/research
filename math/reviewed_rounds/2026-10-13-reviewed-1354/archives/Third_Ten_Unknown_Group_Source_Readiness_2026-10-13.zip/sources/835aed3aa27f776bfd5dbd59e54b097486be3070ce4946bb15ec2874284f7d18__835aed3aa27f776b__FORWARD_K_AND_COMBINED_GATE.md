# Forward-cycle and combined Green-family spectral gates

Independent verification of the companion candidate arguments, 9 October 2026.

These are necessary-condition barriers for the specified factor families. They are not general FFT lower bounds and make no literature-priority claim.

## 1. The forward-cycle spectrum and determinant

Let N>=2 be even. Let M be a unit-modulus weighted full N-cycle whose total cycle weight is -1, so M is unitary and its characteristic polynomial is z^N+1. Set

    K = I+(I-M)^-1 = (2I-M)(I-M)^-1.

The full-cycle hypothesis matters: the equation M^N=-I for an arbitrary unitary matrix alone does not force all N roots to occur once.

The eigenvalues of M are exp(i(2j+1)pi/N), j=0,...,N-1. Because K is a function of the normal matrix M, its singular values are the absolute values of

    (2-exp(i theta))/(1-exp(i theta)).

Their squares equal

    2 + 1/[4 sin^2(theta/2)].

Therefore the maximum and minimum singular values a and b obey

    a^2 = 2 + 1/[4 sin^2(pi/(2N))],
    b^2 = 2 + 1/[4 cos^2(pi/(2N))].                       (1)

Their values are the same for every allowed weighted full cycle, even when the eigenvectors and weights differ. The determinant is

    det K = det(2I-M)/det(I-M) = (2^N+1)/2 = D.           (2)

Let g=D^(1/N) be the geometric mean singular value. Then

    g<2,   b>=3/2,   g/b<4/3.                             (3)

For N>=4 the singular spectrum is nonconstant, so b<g<a. At N=2 all singular values equal sqrt(5/2), and a=b=g.

## 2. Any number of forward K stages

Consider a product of t>=1 forward K stages, arbitrary unitary factors between and around them, and nonzero global scalars. Suppose the product is a nonzero scalar multiple of a unitary matrix. Global scalars can be absorbed into that target, so write the unscaled product as

    W = U_t K_t U_(t-1) ... K_1 U_0 = beta V,

where all U_j and V are unitary. Determinants give

    |beta|=g^t.

Fix any occurrence K_j, and write W=L K_j R. There are t-1 K factors in L and R altogether. Isolating K_j and using operator-norm submultiplicativity gives

    a = ||K_j||_2
      = ||L^-1 W R^-1||_2
      <= b^(-(t-1)) g^t.

Thus the necessary condition is

    a/b <= (g/b)^t.                                      (4)

For even N>=4 this yields the explicit bound

    t >= log(a/b)/log(g/b).                              (5)

The denominator is positive. At N=2 the ratio is 0/0 and must not be used; (4) becomes the vacuous identity 1<=1.

For a simpler asymptotic bound, sin x<=x implies a>=N/pi, while cos(pi/(2N))>=1/sqrt(2) implies b<=sqrt(5/2). Therefore

    (4/3)^t >= N/[pi sqrt(5/2)].                         (6)

This is an Omega(log N) lower bound on the number of forward K stages for a scalar-unitary target, even with arbitrary unitary separators and endpoints. A normalized Fourier matrix is such a target. Nonzero globally scaled Fourier matrices are also covered.

The bound does not concern the zero-K all-unitary case. It does not cover inverse K stages: determinant-normalized inverse K factors can have inverse norm of order N and invalidate the constant bound used here. It also does not cover arbitrary nonunitary coordinate gains.

## 3. Combining forward K with bare Green stages

Now also permit s invertible bare Green stages A_j with kappa_2(A_j)<5, including inverses of the bare Green primitive. Retain t>=1 forward K stages and arbitrary unitary factors. The unitary factors may include any number of Householder reflections.

For any invertible A define its determinant-normalized version by

    Ahat = A / |det A|^(1/N).

This divides by a positive real scalar and makes |det Ahat|=1. If A has least and greatest singular values m and a0, its geometric mean h lies in [m,a0], and

    ||Ahat^-1||_2 = h/m <= a0/m = kappa_2(A).              (7)

Thus a determinant-normalized bare Green stage, or its inverse, has inverse norm less than 5. A normalized forward K has

    ||Khat||_2 = a/g > N/(2pi),
    ||Khat^-1||_2 = g/b < 4/3.                           (8)

If the original product is scalar-unitary, the product of these normalized factors is unitary up to a phase: it is scalar-unitary and its determinant has magnitude one. Call this normalized product W, with ||W||_2=1.

Isolating one normalized K in W, as in section 2, now gives the sharper mixed necessary condition

    a/g <= 5^s (g/b)^(t-1)
        <= 5^s (4/3)^(t-1).                             (9)

The non-strict inequalities in (9) are deliberately safe upper bounds; some are strict whenever a factor using a strict estimate is present. In particular,

    N/(2pi) < 5^(s+t-1),

and consequently

    s+t-1 > log_5[N/(2pi)].                              (10)

Weakening the strict sign to >= is also valid. The exact spectral bound (9) is more informative at small N than the loose estimate (10).

This result still permits arbitrarily many arbitrary unitary factors at no charge. They cannot cancel the large determinant-normalized forward-K singular value without sufficiently many other nonunitary factors of bounded normalized inverse norm. The proof is simply operator-norm submultiplicativity after determinant normalization.

For completeness, the bare Green primitive is M_G=B^-1+(1/20)T^-1, with T=tridiag(-1,3,-1) and B a permutation similarity of T. Both positive-definite inverses have eigenvalues between 1/(3+2c_N) and 1/(3-2c_N), where c_N=cos(pi/(N+1)). Hence

    kappa_2(M_G) <= (3+2c_N)/(3-2c_N) < 5.

The same condition number holds for its inverse. No claim of floating-point algorithmic stability follows from this matrix condition bound alone.

## 4. Unified scope for the current composite family

Consider exactly the following allowed factors:

- s bare Green stages or their inverses, each satisfying kappa_1<=7 and kappa_2<5;
- t forward full-cycle K stages as defined above;
- B rank-one Householder factors;
- permutations, unit-modulus diagonal phases, and nonzero global scalars.

If a product equals Fourier up to a nonzero global scalar:

- If t=0, the low-rank/induced-1 proof in PROOF.md gives 7^s(B+1)^2>=N, hence s+B>=ceil(log_7 N).
- If t>=1, section 3 gives s+t-1>=log_5[N/(2pi)], even after enlarging the allowed unitary factors arbitrarily.

In either case s+t+B is Omega(log N). If these Green, forward-K, and dense Householder factors are evaluated as individually charged full-array passes, their total work is Omega(N log N).

The zero-K branch must retain its narrower unitary scope: rank-one Householders and unitary monomials. If arbitrary unitary factors were free in that branch, Fourier itself would be one allowed factor and the conclusion would be false. Only the branch containing at least one K permits arbitrary unitary separators without further restrictions.

This combined argument excludes a sublogarithmic explicit-stage factorization in this fixed forward-K/bare-Green/rank-one family. It does not rule out a faster general exact Fourier algorithm, inverse-K cancellation architectures, arbitrary large coordinate gains, other nonunitary primitives, or a different execution method that avoids separately charging each displayed factor.

## 5. Checks

`spectral_companion_checks.py` independently checks the closed spectral formulas and determinants against constructed complex weighted cycles, determinant normalization of Green stages, and the isolation inequality on generated products. Its results are in `spectral_results.json`. The numerical results are corroboration; the preceding algebra proves the all-N bounds under the stated assumptions. No uploaded executable code is imported or run.
