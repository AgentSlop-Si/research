THIRD TEN UNKNOWN GROUPS: SOURCE-READINESS AUDIT
13 October 2026 | Private research evidence overlay

Result: 2 ready for a selected bounded next test, 7 need a precise new scope, 1 is source-blocked.
All 23 distinct Catalogue document pins match actual recovered bytes. The ten groups are distinct, disjoint from the prior twenty, and remain at priority 42.

Ready next tests
- ALG-029: exact error-contract comparison with the robust theorem selected in PRIMARY_COMPARATOR_PIN.json. This is separate from the earlier exact-sparse STR-Q5 comparison.
- ALG-049: three-stage, N = 8 mixed-sign scalar-unitarity test with genuinely changing unit-modulus weighted full cycles. The accepted pair and common-cycle proofs remain closed.

Source blocker
- ALG-062: its new bounded Newton/reset dispatcher is already accepted, but the exact accepted replacement API and independent review bytes must be recovered before legacy migration. The old three-branch dispatcher is available and is a different object.

Avoid duplicate work
- ALG-029: the prototype already has scaling and overflow handling; certification is still open.
- ALG-060: Tao’s uncertainty comparison and the characteristic-two nontransfer witness are already resolved.
- ALG-063: all-z resonance repair and Woodbury determinant one are already accepted.
- ALG-064: compare the root-free recurrence extension, not only the old split-node detector.
- ALG-076: nonzero median cross-covariance is already established; marginal oddness is insufficient.
- ALG-081: the STR-Q5 exact-sparse comparison and conservative composition already exist. The original constant-average profile remains distinct.

Per-group next gate

ALG-029 | READY | Deterministic energy-pruned transform
Selected comparison: normalize the energy-pruned contract against Bringmann et al., arXiv:2107.07347v2, Theorem 4, restricted to one dimension. Map the high-SNR promise, error norm, probability, coordinate-oracle access, dense N-vector writing and setup costs. Test implication in each direction, including threshold ties and diffuse spectra. Stop at a qualified theorem mapping or explicit counterexample to a claimed implication.
Source: All three Catalogue-pinned bodies match. The selected primary theorem statement is available at its versioned public URL. No fresh audit of that paper’s full proof or implementation is claimed.

ALG-048 | NEEDS_SCOPE_SELECTION | Bounded-norm and low-rank Green-stage budgets
Select one primary theorem for the low-rank/condition-number branch only and compare the exact flat-unitary target, arbitrary factor ordering, permitted scalar/monomial endpoints and rank-deletion budget. Do not rerun the fixed-strength proof, Cayley guard correction or historical covariance samples. Stop at a theorem-level mapping or a precise nonmatch.
Source: Both Catalogue-pinned proof bodies match; an exact next external comparator is unselected.

ALG-049 | READY | Forward and opposite-sign Green-cycle spectral gates
Selected bounded residual: N=8 and exactly three K or K^-1 stages with both signs present. Allow all unitary monomial separators and genuinely changing full cycles; every cycle has unit-modulus weights of product -1. Form the exact Gram condition A* A=c I with c>0, retaining legal inverses. Seek an exact scalar-unitary witness outside adjacent cancellation/all-pass decompositions, or a certificate excluding that precise family. All six mixed sign patterns must be distinguished unless a proved symmetry identifies them. Stop at the scoped witness/exclusion or a specific unsolved algebraic subproblem. Scalar unitarity alone is not Fourier equality.
Source: All four Catalogue-pinned bodies match; they give the full operator, pair boundary, inverse legality and remaining changing-cycle scope needed to formulate this test. No historical code needs execution.

ALG-050 | NEEDS_SCOPE_SELECTION | Whole-word rational degree and scan-broadcast gates
Choose either an exact new primary theorem for the local-port rational transfer statement or a separately scoped broader-field Fourier-rank extension. Do not repeat nullity-theorem attribution, the accepted complex Frobenius proof, the signed-chirp identity or the three-by-three scalar-scan counterexample. For a field extension, specify characteristic and root assumptions before testing; for comparison, pin one theorem and its endpoint/port grammar.
Source: Both Catalogue-pinned bodies match. The remaining choice is a precise novel comparison or domain extension, not absence of the existing proofs.

ALG-060 | NEEDS_SCOPE_SELECTION | Green-union sparse-inverse and low-rank gate
Select one new primary rigidity/uncertainty theorem matching the sparse-inverse column-support and low-rank perturbation model, or explicitly choose a field-specific uncertainty extension. Preserve invertibility and noncommuting order. Do not redo Tao’s complex additive comparison, the GF(8) counterexample, orbit averaging or the known running-power repair.
Source: The complete Catalogue-pinned audit body matches and includes its proofs and source boundaries. No fresh exact comparator has been selected.

ALG-062 | SOURCE_BLOCKED | Spectral Newton/reset union and dispatcher migration
Selected migration gate: recover the exact accepted bounded Newton/reset dispatcher and its review, then compare its input/configuration/result/error contracts with the pinned legacy transform_if_supported caller before proposing a fresh adapter. Preserve legacy tensor/fiber/chirp semantics and paid rejection/fallback. Stop at a source-bound compatibility map and minimal adapter specification; do not reprove reset optimality or rerun the old rejection witness.
Source: All three original Catalogue bodies, the old source archive and exact legacy fused_fft bytes are available. Required accepted archive aa77ecf5dfc7face4e3c6fb823527f380386b734f0e15ec7c8ee479ca846b6b6, candidate 4769c9676a6f8f6821303bee45bb1a53c648e80ec701aa27612b18ee8297d75f and implementation 0d034d38b51c7d73df717dc8399d95af3a0d8a645a3e706b2cfa2643c093714c remain unrecovered here. This is a bounded source blocker, not denial of the recorded acceptance or proof of global absence.

ALG-063 | NEEDS_SCOPE_SELECTION | All-parameter nearby-permutation geometric transform
Select one precise rational/generating-function theorem for the supplied-order, all-z interface. Map raw membership, arbitrary permutations, sparse defect numerator, one resonant coefficient, field/root supply and all-output cost. Parameter discovery from arbitrary data is a different task. Do not rediscover the determinant-one identity or the already repaired resonance and scalar-hoisting issues.
Source: The complete Catalogue-pinned Woodbury audit and all-z proof match recovered bytes; next external primary theorem remains unselected.

ALG-064 | NEEDS_SCOPE_SELECTION | Root-free order-two recurrence and real-Fourier Green queries
Choose one primary linear-recurrence/rational-evaluation theorem covering repeated or nonsplit characteristic roots, and map full observed-vector certification, boundary numerator, singular Fourier nodes, output normalization and fallback. Do not repeat the García-Armas–Ghorpade–Ram Hankel-count comparison or substitute the old split-node detector for the accepted root-free extension.
Source: Both Catalogue-pinned original theorem and independent extended audit match; the next comparison remains unselected.

ALG-076 | NEEDS_SCOPE_SELECTION | Frequency-shift sketches, nonlinear medians and energy adaptation
Choose one new primary error-guarantee comparison for the nonlinear median, or freeze a specific sharper covariance objective and input class. Do not re-enumerate the known covariance witness, reprove the linear minimax theorem or assume the continuous-rank obstruction applies to finite discrete inputs/adaptive rereads. A numerical implementation needs its own phase/rounding and word-cost contract.
Source: All three Catalogue-pinned bodies match. The long synthesis supplies the accepted proof bodies; the two precursor READMEs alone are not a claim that every original v5/v6 source file was recovered.

ALG-081 | NEEDS_SCOPE_SELECTION | Original aggregate-fiber linear theorem
Select a genuinely new primary theorem for the original constant-average total-budget interface, retaining arbitrary supplied-root fields, adverse rejection, dense individual fibers and complete output. Existing STR-Q5 exact-sparse/tree and pruned-composition comparisons are completed evidence, not a fresh task. If investigating a uniform prerequisite, isolate the specific sample-set constructor rather than rerunning the broad sparse-FFT survey.
Source: Both original Catalogue theorem/review bodies match, and the existing STR-Q5 comparison/repaired-composition review was inspected to prevent duplicate dispatch.

Controls and limits
The 331 stable IDs and 249 open groups are unchanged. Historical 244 eligibility is still unrederived. The arithmetic remainder of 195 means only original UNKNOWN groups not covered by these three audits; it is not a current dispatch total or a live-sheet count.
No accepted proof was reopened. Hash matches establish byte identity, not a new proof verdict. No historical scientific code was run. No Sheet, repository, score, status or sharing changes were made.
SOURCE_READINESS_10_GROUPS.json gives every current premise, accepted boundary, next test and exact location. EXACT_BASELINE_BINDINGS.json preserves the original native wording; source snapshots retain their Catalogue hashes. Supplemental research documents prevent redispatch of completed work.
