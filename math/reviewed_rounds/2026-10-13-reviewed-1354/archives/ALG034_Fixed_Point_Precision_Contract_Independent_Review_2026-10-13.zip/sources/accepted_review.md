# ALG034 independent residual certificate review

13 October 2026. ALG-034 remains OPEN at priority 48.

## Decision

**ACCEPT, within the stated scope, for the checkpoint and output-only residual theorems and the newly authored rational-interval research verifier.** The bounds correctly target the exact sampled row Y = U_N P_(a,beta) x. The supplied implementation includes the source check, intended-root enclosures, normalization and every cyclic residual edge. No substantive counterexample was found.

**REPAIR the README reproduction note only.** Running the candidate's main program unconditionally writes CHECK_RESULTS.json. Shell redirection only controls the printed log. This is a packaging/documentation defect and does not invalidate the certificate. The original sealed candidate was preserved; its test suite was replayed in a separate copy, producing byte-identical results. The corrected safe procedure is given below.

Acceptance closes the bounded residual-interface and reference-verifier obligation, not the stable fast numerical executor, useful uniform precision bound, sampling/decoder contract, or complete paid implementation. In particular, the complete implemented checker is O(NB + B²) interval operations. Only its final Green residual pass is O(N). No fast certified polynomial backend is implemented here.

## Candidate identity and review boundary

The supplied archive is ALG034_Certified_Residual_Interface_Candidate_2026-10-13.zip, 49,898 bytes, with SHA-256:

5a9c6553ad002d76a8e64028279c36d0aa4d70b78477cce470bd25d8f7f9a294

Its existing private Library identity is libfile_75a131d39418819193099f92ac5199a8. This review verified the archive hash, compared all 13 archive members with the supplied candidate directory, and verified every entry of the candidate SHA256SUMS. The newly authored verifier has SHA-256 d7e9458a2d4bdfd3d99dcd2375b724db562499706339c5220e3e42c1ec08030f.

The original historical core and v14 report were read as inert text only. Neither was imported or executed. The earlier missing candidate archive was not recovered by this review. Existing accepted Green and sampling results are retained premises, with the new interface and implementation checked independently. No external Sheet, repository, research index or publication was changed. Original candidate status files retain their original pending-review wording; the decision in this separate sealed review is the new scoped assessment.

The independent oracle uses separate rational interval code, a different identity for pi, a fixed-degree Taylor enclosure, direct time-domain block projection followed by the DFT, exact rational fourth roots, and exact integer cyclotomic quotient rings. It does not call candidate root, phase, interval, producer or DFT routines to define the expected mathematical target. Tests of the verifier necessarily call the candidate certificate APIs. Separately labelled fault tests call the newly authored candidate producer; they never call the historical executor.

## Checkpoint theorem

For valid exact metadata N >= 3, 3 <= B <= N, gcd(a,N)=1 and 0 <= beta < N, the checker reconstructs the longer-blocks-first balanced partition. Local phases, cyclic endpoint phases, start nodes and alpha are all computed from exact integer exponents in the intended complex embedding. The state and frequency-index order are mathematical inputs, not facts inferred from output similarity.

The compression bounds are correct. If e_b encloses the complex modulus of the summary error, the time-domain difference has ell_b entries of that same modulus. Disjoint supports and DFT unitarity give C_2² = sum ell_b e_b². The DFT triangle inequality gives C_inf = sum ell_b e_b / sqrt(N). Thus compression uncertainty need not be amplified through the Green inverse.

The exact comparison source uses the exported summaries and intended boundary phases: w_b = d_hat_b - c_(b-1) d_hat_(b-1). Reindexing the cyclic endpoint nodes into the start-node order is correct, including the last endpoint N mapping to 0. The checked raw source is the exact difference of the two stored rational-complex channel values. Common-mode channel errors may cancel exactly; a certificate for their difference should preserve that cancellation.

For Q(z) = product_b (1 - lambda_b z), Q(0)=1, the exact comparison source satisfies Q*s*=0 from index B onward. At earlier indices, the convolution of individual seed-error radii with coefficient-modulus upper bounds correctly bounds Q*(s_hat-s*). At later indices the fully enclosed recurrence defects bound the same quantity. Hence a bound H on the first N absolute inverse coefficients gives ||s_hat-s*||_inf <= H eta.

Both proposed bounds on H are valid. The complete-homogeneous expansion gives sum_(t<N) |h_t| <= binom(N+B-1,B). Since the intended start nodes are distinct Nth roots, multiplying Q by the product over omitted roots gives 1-z^N. Therefore, below degree N, the reciprocal coefficients equal those of the omitted-root product, whose absolute coefficient sum is at most 2^(N-B). The minimum is sound. This identity applies to the intended exact roots; it is not asserted for rounded roots or approximate coefficients. At B=N, H=1 and the recurrence tail is empty, but evaluating all N seeds directly still costs quadratically.

The normalization term compares stored f_hat with the exact stored channel difference divided by the intended sqrt(N), including interval evaluation error. The final residual compares stored Y_hat with alpha_k Y_hat_(k+a) plus f_hat at every k, including the wrap edge. With the retained inverse norms, the reported bounds follow by linearity and the triangle inequality:

- epsilon_inf = C_inf + (N/2) [R_inf + nu + H eta / sqrt(N)]
- epsilon_2 = C_2 + [R_2 + sqrt(N)(nu + H eta / sqrt(N))] / [2 sin(pi/(2N))]

The implementation's componentwise complex l1 upper bounds are conservative upper bounds on the complex modulus. Squaring and summing these nonnegative upper bounds is safe for the l2 estimate. The checker uses an upper bound on the inverse Green norm by taking a positive lower bound on the sine denominator. It does not mistake an interval midpoint or decimal diagnostic for a certified bound.

A new exact control illustrates why the source check matters: with N=4, B=3, exact fourth roots, and exact rational data, a wrong source is solved with exactly zero final Green residual, zero compression error, zero normalization error and zero recurrence-tail defect. Its seed defect is positive and the output is wrong. The certificate catches it through the seed/source term. A scan-only certificate would miss it even without any rounding.

## Output-only theorem and trust boundary

The output-only construction encloses v=(I-T)Y_hat using all intended alpha values and all wrap edges. It independently forms the true block summaries, normalized true forcing seeds and the same intended Q. The error v-f is then covered by the seed and recurrence defects. Therefore ||Y_hat-Y||_inf <= (N/2)H eta. The stated l2 counterpart follows using sqrt(N) times the forcing infinity bound and the retained spectral inverse norm.

Interval occurrences of v and Q may be dependent. Independent interval evaluation may widen the enclosure, but it does not invalidate inclusion. No step treats an interval midpoint as an exact source sample. Rounded producer roots, coefficients, reciprocal, gauges, scan seeds and checkpoints need not be trusted.

The implemented output_only_certificate API returns the infinity certificate only, as its README explicitly states. The l2 output-only theorem is valid but that bound is not a returned field in this reference API. Relative-tolerance comparison likewise requires a separately certified norm lower bound; the API does not supply a complete status-returning production acceptance wrapper.

The certificate is about the supplied exact x, metadata and final Y. It does not authenticate where those data came from or prove that a particular historical algorithm ran. An adapter must preserve each stored finite component exactly, for example by exact dyadic conversion, and must supply the actual intended state. A mislabeled input or state merely changes the target being certified. An implementation exporting cycle order must first apply the declared exact permutation into frequency order. The API does not infer that permutation automatically.

Independent tests supplied only the six required fields and also supplied unusable objects under checkpoint names. The returned output-only certificate was identical. Direct projected-DFT tests covered incorrect output order, a perturbed final entry and zero output. A separate exact test made all non-wrap residuals vanish while the wrap residual was nonzero; the output-only certificate caught it.

## Interval arithmetic and precision audit

The candidate's rational outward rounding has the correct directions for negative as well as positive values. Real multiplication encloses all endpoint products. Reciprocal reverses the endpoints and excludes zero. Integer-square-root bounds enclose the requested nonnegative rational. Pi uses a valid Machin identity with alternating-series tails. Root evaluation reduces exponents exactly, encloses the resulting angle, uses Taylor remainder bounds at its rational midpoint, and adds the angle-radius contribution by the Lipschitz bound for sine and cosine. Exact quadrant cases are handled separately.

The independent root oracle instead uses pi = 4(atan(1/2)+atan(1/3)), with alternating remainders and separately rounded interval Taylor recurrences. For 3,375 tested phase/precision combinations, its tighter rectangle was wholly inside the candidate root rectangle. Exact root branches, negative exponents and wrap reductions were included. This is a finite implementation control; the inclusion proof rests on the described arithmetic and remainder inequalities.

The input representation contract matters. A binary floating input is its exact stored dyadic value; a displayed decimal is generally a different rational. When x is merely an approximation to physical x_star, the separately certified input uncertainty contributes at most L delta_x in l2 and hence also in infinity norm. Checker precision does not remove that input uncertainty.

The acceptance comparison against tau_num X_lower is sound. If X_lower=0 for a nonzero input, the norm enclosure must be refined before asserting a relative target. Zero input needs an absolute convention or exact-zero certificate. Failure of a sufficient upper-bound test is INCONCLUSIVE, not evidence that the actual error exceeds the requested tolerance. Producer precision and checker precision are different controls.

The bit-planning formula remains conditional on proved stagewise constants and an adequate exponent-range model. No such uniform constants are supplied for the historical NumPy FFT path. The rational reference's fixed-size convergence observation is valid but neither a practical precision recommendation nor an all-size cost guarantee. Inert historical source inspection confirms that a wider decoder scan dtype leaves upstream forcing and gauge construction in complex128; merely widening that argument is not an all-stage precision fix.

The research API assumes valid finite exact rational data and valid integer metadata. It is not a hardened parser, has assertion/exception exits rather than a complete INVALID/INCONCLUSIVE status protocol, and uses mutable global working precision. Concurrent calls with different precisions are outside this audit. Exact rational operations avoid a floating exponent cap, but their actual integer sizes, memory usage and arithmetic costs must be paid. Diagnostic conversion to float is not part of the proof arithmetic and is not a general safe serializer for arbitrarily large rationals.

## Independent controls and replay

All of the following passed in the final independent test run:

- 3,375 root rectangles enclosing a separate rigorous oracle, using denominator values 1 through 25 and checker precisions 4, 12, 32, 64 and 100
- 1,600 exact endpoint arithmetic groups, including 778 reciprocal inclusions and square-root endpoint checks
- 192 exact rational fourth-root rows, including exact target outputs, arbitrary outputs, unrelated checkpoints and input scales 2^-90, 1 and 2^70
- 264 arbitrary unrelated-checkpoint rows for selected valid states, N=3 through 17 and both low and higher checker precision; infinity and l2 checkpoint bounds and infinity output-only bounds were compared with a separate direct interval oracle
- 264 output-only checkpoint-independence controls
- 20 independent output-mutation rows, across odd, even, divisor, nondivisor and B=N cases
- One exact single-wrap-only defect control
- 12 new-producer fault controls covering compression, boundary order, nodes, coefficients, reciprocal, source seed, normalization, forcing, closure, output mapping, final output and parity
- One exact huge common-mode cancellation control, adding the same roughly 2^140 complex offsets to both channels without changing the certificate
- One exact zero-residual wrong-source trap with a positive seed defect
- 190 exact cyclotomic omitted-root product and reciprocal-prefix identities, covering every B=3..N for N=3..21

The separate replay of the candidate's unchanged main program also passed. Its CHECK_RESULTS.json was byte-identical to the original archived file. The original source directory and sealed archive remained unchanged.

These finite controls support implementation confidence. They do not prove a general numerical stability theorem, benchmark the historical executor, certify a fast FFT backend or establish sampling accuracy. The candidate's universal claims rely on its mathematical proofs and the audited interval inclusion rules.

## Cost and the precise remaining implementation gap

The complete reference verifier pays O(N) compression, root-dependent data formation, norm work and final residual evaluation, O(B²) Q construction and direct seeds, and O(NB) recurrence checking. Root generation, exact modular indexing, integer bit sizes and rational arithmetic costs are additional to the scalar-operation ledger. O(N+B) scalar storage is possible for this architecture at one precision, but caching across many precision retries can retain additional values; memory across retries is not free.

The proposed conditional bound O(N + B² + ceil(N/B) M_cert(B,p)) is credible if a rigorously enclosed blocked polynomial product actually supplies M_cert at the needed precision and exponent range, and its padding, overlap, coefficient radii and rounding envelope are charged. It is not instantiated by the current naive loops. The cost of source checking cannot be hidden inside the O(N) residual pass. At bounded B the naive arithmetic count is linear in N; this does not settle growing-B cases.

The next numerical implementation milestone must supply all of the following:

1. A finite-input adapter and explicit acceptance/status interface for actual output arrays, preserving exact dyadics and verified state/output order, with no silent conversion or overflow.
2. A specified certified fast polynomial backend for Q/defect products, including coefficient and root uncertainty, adequate exponent range, all convolution padding/overlap costs and end-to-end validation against the exact target.
3. A useful precision/error contract for the selected producer across every affected stage, or a clearly bounded adaptive certification strategy with the costs of failed checks, root rebuilding and producer reruns charged. Widening only the final scan is insufficient.
4. A complete paid runtime, bit-cost and storage ledger for that implementation. The present arithmetic-operation upper bound establishes no runtime or bit-complexity lower bound.

A sharper H can be useful for practical acceptance but is not required for the current theorem's soundness. Computing a sharper inverse-coefficient norm is additional work, not free conditioning information. A production-quality parser, concurrency-safe precision handling, and a complete output-only l2/status API are engineering work still outside this reference artifact.

## Sampling and broader status

The target remains Y=U_N P x. Nothing in the numerical certificate bounds Y-U_N x without a separate sampling or decoder guarantee. For example, the retained basis-input full squared error ell_b-1 can be present even if this numerical certificate is exactly zero. Numerical precision cannot remove that error. The retained unbiased rank-B worst-input MSE lower bound N/B-1 is unchanged.

Accordingly, this review accepts a numerical-error interface for a sampled row, not full FFT accuracy, a faster exact FFT, worldwide novelty, or completion of ALG-034. Priority 48 and broader OPEN status remain unchanged.

## Corrected reproduction note

The original README incorrectly ties result rewriting to shell redirection. The correct statement is:

“Running checks/certified_checker.py always rewrites CHECK_RESULTS.json beside the checks directory. Redirecting stdout writes a separate log only. To preserve a sealed packet, copy the checker into a new replay/checks directory, run that copy, and compare or reseal the generated results separately.”

For this independent packet, checks/independent_review_tests.py imports replay/certified_checker.py without invoking its main program. It writes INDEPENDENT_RESULTS.json in the packet directory and prints its test log. Reproduce only in a working copy if preserving these sealed bytes matters. No historical source is needed or executed by either independent test route.

## Primary source checks

The following primary references were reopened during this review. They support classical methodology and context, not a new stability result for this implementation.

- LAPACK Users' Guide, Further Details Error Bounds for Linear Equation Solving: residual-to-forward-error analysis and residual-evaluation rounding. https://www.netlib.org/lapack/lug/node81.html
- Arb documentation, Using ball arithmetic: inclusion semantics, conversion uncertainty, dependency overestimation, and sufficient rather than complete predicates. https://fredrikj.net/arb/using.html
- Bostan and Mori, A Simple and Fast Algorithm for Computing the N-th Term of a Linearly Recurrent Sequence: rational generating functions and recurrence arithmetic; its distant-term results do not themselves certify this whole-prefix floating computation. https://arxiv.org/html/2008.08822v1

No external full text is redistributed. The source-specific historical pins remain in the original candidate's SOURCE_AUDIT.json.
