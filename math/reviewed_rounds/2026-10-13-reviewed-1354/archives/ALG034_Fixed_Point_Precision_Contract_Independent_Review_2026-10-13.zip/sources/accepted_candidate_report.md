# ALG034 certified numerical residual interface

13 October 2026. Sealed candidate for independent review. ALG034 remains OPEN at priority 48. This packet does not change a research index, spreadsheet, repository, or publication.

## Result and scope

A deterministic a posteriori certificate can bound the numerical error of an actual all-input ALG034 row. It certifies the distance from the returned vector to the exact sampled estimator Y = U_N P_(a,beta) x. It does not certify proximity to U_N x, improve sampling quality, or establish a sub-N-log-N algorithm.

There are two interfaces:

1. A checkpoint interface explicitly separates compression, forcing, normalization, and final-output errors. Once its forcing envelope is justified, the final residual calculation costs O(N) arithmetic operations.
2. An output-only interface needs only the exact input representation, N, B, a, beta, and the final returned vector. It certifies the forcing implicitly through its order-B recurrence. It needs no trusted internal state and can therefore be applied to the historical decoder's final output without treating its rounded roots as exact roots.

The independently authored executable reference verifier uses O(NB + B^2) rational interval operations. A conditional blocked-convolution implementation can reduce this to O(N + B^2 + ceil(N/B) M_cert(B,p)), with root generation, precision, bit cost, and storage charged separately. No such fast certified backend is implemented in this packet. An unconditional O(N) complete verifier for growing B at arbitrary lengths is not established. This is a cost boundary of the construction, not a lower bound against other verifiers.

The existing sharp Green constants are accepted premises, not new results. Residual-to-forward-error analysis and validated interval arithmetic are classical. The contribution proposed for review is the explicit ALG034 interface, including its full forcing check, normalization, state/output mapping, precision acceptance gate, and failure controls.

## Sources and historical implementation boundary

The accepted reconstructed review and its retained premises were read from the supplied review packet. Its exact energy and Green-norm results remain unchanged. The original v14 report and core were independently recovered through their pinned repository commit, saved as inert text, and SHA-256 verified:

- v14 report: a0a5d23b1ca51bfe2b2734d64ee4cf0cce61e7735eac04a060a99430749113ef
- historical core: 4ad57b9d9f2fc452dccb27466634d4028a1b8fe47a43c2ccb3d8ebdc81836e2a
- repository commit: 8604bdf099c01006e3c18030bbf123a59ead893e

This recovers these two source files only. It does not recover or authenticate the previous missing candidate archive. Neither historical code nor the preceding review's test program was executed.

In the historical core, the seed matrix is explicitly B by B; polynomial and reciprocal construction are quadratic; the two channels use blocked FFT convolution. `dtype` in `decode_projected_spectrum` changes the final scan and output dtype, while compression, node formation, recurrence arrays, convolution, forcing, and gauge construction remain complex128. Inert source lines 213–229, 271–307, and 319–333 verify this. Merely passing a wider scan dtype is not an all-stage precision increase. Lines 321–322 also form a*j in an int64 array; sufficiently large dimensions require an integer-overflow-safe mapping. This is a textual implementation concern, not a new execution failure.

## Exact target and representation contract

Assume N >= 3, 3 <= B <= N, 0 < a < N, gcd(a,N)=1, and 0 <= beta < N. Use the balanced positive contiguous partition with starts s_b and lengths ell_b, the longer blocks first. The checker recomputes it using exact integers. Set L=max ell_b, h=N mod 2, zeta=exp(2 pi i/N), and eta=exp(pi i/N).

For t in block b define

S_(b,t) = zeta^[a t(t-1)/2 + (a s_b+beta)t] eta^(h t),
d_b = sum_t S_(b,t) x_(s_b+t),
c_b = zeta^[-a ell_b(ell_b-1)/2 - a s_b ell_b - beta ell_b] eta^(-h ell_b),
lambda_b = zeta^(-s_b).

Endpoints cycle to the next start, including the final endpoint N -> 0. The merged boundary weights are w_b=d_b-c_(b-1)d_(b-1), where b-1 is modulo B. With the unitary negative-sign DFT,

s_k = sum_b w_b lambda_b^k = D_k-E_k,
f_k = s_k/sqrt(N),
alpha_k = zeta^[-(k+beta)] eta^(-h),
(TY)_k = alpha_k Y_((k+a) mod N),
A = I-T,
A Y = f.

The intended array is in frequency-index order k=0,...,N-1. If an implementation exports cycle order j, the checker must apply and verify k_j=a*j mod N before testing. Permutations are exact integer work, never inferred from data similarity. A returned finite floating number is interpreted as its exact stored dyadic value; decimal display rounding cannot replace that value. NaN, infinity, malformed shapes, invalid state, unbounded root enclosures, or arithmetic overflow yield INVALID or INCONCLUSIVE, never CERTIFIED.

The primary contract treats the supplied x as exact, including its stored floating representation. If a different physical or real input x_star is intended and ||x-x_star||_2 <= delta_x is independently certified, add L delta_x to either the l2 error bound or its implied l-infinity bound. This follows from ||P||_2=L and unitarity. Input uncertainty does not disappear by increasing arithmetic precision.

## Roots and arithmetic certification

There are distinct models:

- Exact intended roots supplied symbolically: the target above applies and root uncertainty is zero, but exact scalar operations still have their actual representation costs.
- Rounded roots: the checker encloses the intended exp(pi i e/N), using exact integer exponents reduced modulo 2N. It must not apply unit-circle or cycle-product identities directly to the rounded numbers. A rounded value need not have modulus one, satisfy zeta^N=1, or produce cycle multiplier -1.
- Arbitrary supplied numbers without certified relation to the intended roots: they do not establish a certificate for the intended DFT. Reject that asserted root premise or independently enclose the intended roots as done here.

All phase entries, including local phases, endpoint phases, nodes, gauge phases if inspected, and alpha, are tied to the same intended embedding and exponents. Merely testing that a number approximately solves z^N=1 does not identify the intended branch.

The reference checker authors its own outward dyadic interval operations using exact rational arithmetic. It obtains pi from Machin's identity with rigorous alternating-series remainder bounds, reduces angles by exact integer arithmetic, and encloses sin/cos with finite rational Taylor polynomials, Lagrange remainder bounds, and the Lipschitz bound for angle uncertainty. Square roots are enclosed by integer-square-root bounds. No ordinary transcendental library is trusted for a certificate. The exact Fraction endpoints and outward rounding, rather than decimal diagnostic printing, carry the proof obligation.

The reference uses complex rectangular intervals. Its |z| upper bound |Re z|+|Im z| is conservative but rigorous. The direct oracle instead computes an outward enclosure of sqrt(Re^2+Im^2), so its check uses the correct complex modulus. Checker-development note: an initial oracle compared a complex l1 upper bound with the complex-modulus certificate; the compression mutation exposed this mismatch, and the oracle was corrected before the final complete run.

Generating O(N) root enclosures is not free. Charge either their supplied certification cost or O(N) root evaluations, or one rigorously enclosed primitive root followed by O(N) interval multiplications with the resulting width growth. The reference uses cached independently enclosed phase values. Elementary arithmetic counts do not include these special-function costs.

## Checkpoint theorem

Let d_hat_b, D_hat_k, E_hat_k, f_hat_k, and Y_hat_k be exported finite values, interpreted exactly. They need not have been produced by a correct algorithm. Let Y(d_hat) denote the exact row produced using d_hat as block summaries and the intended exact phases.

First recompute d_b from the original x in intervals and obtain e_b >= |d_hat_b-d_b|. Define

C_inf = (sum_b ell_b e_b)/sqrt(N),
C_2 = sqrt(sum_b ell_b e_b^2).

Then ||Y(d_hat)-Y||_infinity <= C_inf and ||Y(d_hat)-Y||_2 <= C_2. This direct compression bound avoids unnecessarily amplifying compression error through the Green operator.

Set s_hat_k = D_hat_k-E_hat_k, with subtraction interpreted exactly for the mathematical definition, and define the exact comparison sequence

s*_k = sum_b [d_hat_b-c_(b-1)d_hat_(b-1)] lambda_b^k.

The source certificate below supplies E_s >= ||s_hat-s*||_infinity. Enclose

nu_k >= |f_hat_k-s_hat_k/sqrt(N)|,
R_k >= |Y_hat_k-alpha_k Y_hat_((k+a) mod N)-f_hat_k|.

These calculations must include the checker's own arithmetic enclosure widths. Set nu=max nu_k, R_inf=max R_k, R_2=sqrt(sum R_k^2), and F_err=E_s/sqrt(N)+nu. The inherited Green inverse constants give

epsilon_inf = C_inf + (N/2)(R_inf+F_err),
epsilon_2 = C_2 + [R_2+sqrt(N) F_err]/[2 sin(pi/(2N))].

Then ||Y_hat-Y||_infinity <= epsilon_inf and ||Y_hat-Y||_2 <= epsilon_2.

Proof: A(Y_hat-Y(d_hat)) equals the checked residual plus f_hat-f(d_hat); its componentwise forcing error is bounded by F_err. Apply the accepted inverse norms and add the separately bounded compression difference. No numerical stability premise about the producer is needed.

If the check uses rounded alpha_hat and an arithmetic residual r_hat rather than directly enclosing the exact expression, its bound must include

R_k = upper(|r_hat_k|) + delta_eval,k + delta_alpha,k |Y_hat_((k+a) mod N)|,

where the right side is used as an upper bound on the exact residual and delta_alpha,k >= |alpha_hat_k-alpha_k|. The reference directly encloses exact alpha and thus already includes this term. The output-only mapping also catches wrong gauges, bad scan seeds, closure errors, and wrong output permutations; separate algorithm-specific roundoff proofs of the scan are unnecessary for soundness.

The boundary row k with k+a wrapping modulo N is checked as well. Testing only N-1 local scan steps leaves an uncontrolled cycle seed and is insufficient.

## Forcing certificate with every source cost included

The exact polynomial is Q(z)=product_b(1-lambda_b z)=sum_(j=0)^B q_j z^j, with q_0=1. The comparison sequence s* satisfies Q*s*=0 at every k >= B.

Obtain certified seed errors epsilon_k >= |s_hat_k-s*_k| for 0 <= k < B by independently evaluating the B-node sums. Build certified enclosures of the intended coefficients q_j. Define

eta_seed = max_(0<=k<B) sum_(j=0)^k upper(|q_j|) epsilon_(k-j),
eta_rec = max_(B<=k<N) upper(|sum_(j=0)^B q_j s_hat_(k-j)|),
eta = max(eta_seed,eta_rec),

where an empty recurrence maximum is zero. Coefficient and root errors, as well as arithmetic used to form these defects, are included in the intervals. The inverse polynomial used by the producer need not be trusted or separately checked: any erroneous inverse that changes returned sequence values is reflected in the seeds or recurrence defects. This is an output certificate rather than a certificate of each operation's execution.

Let h_t=[z^t]1/Q(z). A valid explicit bound is

H_(N,B) = min{ binom(N+B-1,B), 2^(N-B) }.

Then E_s=H_(N,B) eta is valid.

Proof: for e=s_hat-s*, the causal convolution defect Q*e has magnitude at most eta at all indices 0,...,N-1; the first B defects are the seed-error convolutions above. Thus e_k=sum_(t=0)^k h_t (Q*e)_(k-t). The complete-homogeneous expansion gives |h_t| <= binom(B+t-1,B-1), whose first-N sum is binom(N+B-1,B). Independently, the lambda_b are distinct members of the full Nth-root set, so

Q(z) Hcomp(z)=1-z^N,
Hcomp(z)=product_(lambda in omitted roots)(1-lambda z).

Below degree N, 1/Q has exactly the coefficients of Hcomp; their absolute sum is at most 2^(N-B). Taking the smaller valid bound proves the result. These elementary formal-series and product estimates are not claimed as novel. They also explain why the certificate may be highly pessimistic. For B=N, H=1 and there is no recurrence tail, but checking all N seeds by direct sums is still quadratic.

One may replace H by any independently certified upper bound on sum_(t=0)^(N-1)|h_t|. Computing that sharper bound is extra paid work. Using coefficients of 1/abs(Q), or treating approximate coefficient cancellations as exact, requires separate justification. Nothing here asserts that the actual floating error attains the H bound.

If q_hat with coefficient radii delta_q is used to accelerate defect evaluation, certify the polynomial-product computation itself and add sum_j delta_q,j |s_hat_(k-j)|. A uniform bound ||delta_q||_1 ||s_hat||_infinity is sufficient. A fast ordinary floating convolution without a rigorous rounding envelope is not a certified convolution.

This merged-source check is deliberate. The historical two channels share Q, and their difference is the actual forcing. Large equal common-mode errors in both channels cancel in that difference and need not be penalized separately. Normalization is then checked against the exact stored difference; it is not assumed merely because a producer claims to divide by sqrt(N).

## Output only theorem

The old routine returns Y_hat but not all checkpoints. This is not an access or mathematical blocker. From x and Y_hat alone, enclose

v_k = Y_hat_k-alpha_k Y_hat_((k+a) mod N).

Independently form d_b and the normalized true seeds f_k=s_k/sqrt(N), 0<=k<B. The exact normalized forcing f obeys the same Q recurrence. Apply the forcing theorem to v-f:

epsilon_seed,k >= |v_k-f_k| for k<B,
eta_seed = max_(k<B) sum_(j=0)^k upper(|q_j|) epsilon_seed,(k-j),
eta_rec = max_(B<=k<N) upper(|sum_(j=0)^B q_j v_(k-j)|),
E_v = H_(N,B) max(eta_seed,eta_rec).

Then

||Y_hat-Y||_infinity <= (N/2) E_v,
||Y_hat-Y||_2 <= sqrt(N) E_v/[2 sin(pi/(2N))].

All operations are interval enclosures; interval v values are not treated as independent exact samples. Inclusion suffices, even though dependencies can widen the bounds. This verifies the returned row against the exact original x, all intended roots, and the exact normalization. It covers arbitrary errors anywhere in the producer. Its source verification still costs O(NB+B^2) in the implemented version. Calling the O(N) construction of v the entire certificate would omit the main cost.

## Exact acceptance and precision condition

Let X_low be a certified lower bound on ||x||_2. For x != 0 and requested numerical tolerance tau_num>0, the checkpoint certificate accepts the energy-relative per-output target exactly when its outward bound satisfies

C_inf + (N/2)[R_inf + nu + H_(N,B) eta/sqrt(N)] <= tau_num X_low.

Every square root and comparison is interpreted with the outward/inward direction needed to make this implication valid. For an l2 target, replace the left side by epsilon_2. For the output-only certificate, accept when (N/2) H_(N,B) eta <= tau_num X_low. An exactly zero input uses an absolute tolerance, or exact-zero output certification; division by ||x|| is never performed. If X_low is zero because its enclosure is too coarse but x is nonzero, refine the norm enclosure before testing a relative claim.

These are the actual a posteriori precision conditions. Increasing the checker precision narrows check uncertainty. Increasing the producer precision can reduce the stored numerical defects. They are separate operations. A failed upper-bound test means INCONCLUSIVE for that requested tolerance, not proof that the actual error is large. If an independent lower bound exceeds tolerance, that is a distinct verified failure.

For a conventional sufficient bit-planning statement, suppose one has already proved, for the specific producer and checker at every p>=p0, bounds

C_inf <= c_c 2^(-p) X,
eta <= c_eta 2^(-p) X,
nu <= c_n 2^(-p) X,
R_inf <= c_r 2^(-p) X,

with constants independent of p and a valid exponent-range model. Then, using an exact X or a separately paid sufficiently accurate norm enclosure,

C_total = c_c + (N/2)[c_r+c_n+H_(N,B)c_eta/sqrt(N)],
p >= max{p0, ceil(log2(C_total/tau_num))}

is sufficient for the true numerical error bound. The certificate comparison must still accommodate X_low rather than silently substituting a lower estimate for X. For example, if X_low>=gamma X for certified 0<gamma<=1, replace tau_num by gamma tau_num in the sufficient bit condition to guarantee the comparison passes. No constants c_c,c_eta,c_n,c_r are proved here for the historical NumPy FFT backend; this conditional formula is not a claim that binary64 or O(log N) bits suffice.

For the newly authored finite rational producer, as p tends to infinity at fixed N,B,state and exact x, its rounded arithmetic converges to the exact two-channel recurrence and Green scan. Its divisions have nonzero limiting gauge denominators and q_0=1. The checker can also be refined independently. Since H_(N,B) is finite, any fixed positive numerical tolerance is eventually certifiable in this reference model. This termination observation does not give a practical bit bound, uniform complexity in N, or a precision upgrade for the historical program.

The reference precision experiment uses absolute dyadic fractional bits, not floating mantissa bits. On one declared small input at tau_num=2^-10, p=8 and 12 fail the sufficient bound, while p=20, 32, and 48 pass. This is one finite control, not a universal precision recommendation.

## Cost ledger

Let M_cert(B,p) be the full cost of a rigorously enclosed length-O(B) polynomial product at the needed precision and exponent range. If measuring scalar arithmetic counts, replace it by the corresponding number of scalar operations and separately charge each one's bit cost.

- Validate state, partition, indices, and phases: O(N+B) integer/arithmetic work plus root-enclosure generation, gcd, and integer bit costs. Use exact modular indexing or prove machine-integer safety.
- Read x, enclose its norm, and form block summaries: O(N) interval arithmetic plus phase costs.
- Boundary weights and normalization setup: O(B) arithmetic plus a certified square root.
- Build intended Q by successive factors: O(B^2) operations and O(B) streaming scalar storage. A faster product tree is optional and must be separately specified and validated.
- First B source values: O(B^2) direct interval arithmetic; use O(B) storage by streaming powers. The historical B-by-B seed matrix instead uses O(B^2) storage.
- Naive recurrence-defect check: O(NB) interval operations. This is the implemented checker.
- Conditional fast recurrence-defect check: split the length-N sequence into blocks and compute the necessary convolutions with fixed Q, costing O(ceil(N/B) M_cert(B,p)+N+B^2), including initial seed-error convolutions. It does not require reproducing the producer's reciprocal or trusting the producer's FFT.
- H bound: one binomial/integer-power comparison with O(B) integer arithmetic in a simple method; the integers can have O(B log(N+B)) bits before taking the minimum. Their bit sizes and storage count.
- Normalization and final Green residual: O(N) interval operations, including all wrap edges, output mapping, root-error effects, and norm aggregation. This is the linear-time residual pass.
- All outputs and reading them: O(N) stored scalars in a straightforward implementation. O(N+B) scalar storage is sufficient for the reference architecture excluding source text, test oracles, and integer/precision-dependent storage. The historical program's seed matrix makes its own footprint O(N+B^2).
- Each retry at a new precision, any root-table rebuild, each validation, and each producer rerun is charged. Reusing Q or root enclosures across rows saves only the verified shared preparation; it does not erase per-row source and output work.

If B is bounded, the naive complete checker has O(N) scalar-operation count, subject to root and bit costs. In equal-block divisor cases Q=1-z^B, checking recurrence tails is O(N), but B seeds still cost O(B^2) directly, or a separately certified B-point transform. These special cases do not imply a general growing-B rough-length O(N) complete checker.

The reference producer deliberately uses naive polynomial convolution and an independently written tree scan. Its scan implementation recomputes subtree sums and can cost O(N log N); no producer speed theorem is asserted for that test scaffold. The direct projected-signal DFT oracle costs O(N^2). All of these test costs are separate from the proposed checker counts. Only a specified and validated fast backend could establish the conditional fast-verifier cost. An arithmetic-operation upper bound establishes no corresponding bit-complexity lower bound.

## Controls and adversarial cases

The final CHECK_RESULTS.json and CHECK_LOG.txt record a complete successful run of the freshly authored checker only:

- 108 ordinary rows, 860 output entries, N=3 through 12, selected B values including B=3 and B=N, states a=1 and a=N-1 with beta=0 and N-1, boundary-supported and cancellation-pattern complex inputs. Every row's infinity and l2 certificates were cross-checked against independently materialized projected signals and direct interval DFTs.
- One exact-zero input and five rejected invalid dimension/state combinations.
- Twelve adversarial mutations: compression, cyclic endpoint order, conjugated nodes, characteristic coefficient, reciprocal coefficient, forcing seed, normalization, forcing value, cycle closure, output mapping, final output, and omission of the odd-length parity twist.
- Five output-only tests, including an ordinary row and corrupt seed, normalization, mapping, and closure cases. They require no producer-state assertions.
- 459 exact complex-rational formal-series identities with a fourth-root node subset, checking e=Q^(-1)(Q e) for independent single-site perturbations.
- A five-precision experiment, explicitly labelled finite and input-specific, and two scaled-input controls at 2^120 and 2^-80. The rational reference has no finite exponent-range cap; a floating implementation must account for its own exponent range.

An important negative control corrupts a source seed and then solves the wrong forcing accurately. Its final Green residual is below 2^-30 while its certified source error exceeds 1/10. Thus an excellent scan residual alone can certify the wrong row if source formation is omitted. This is an actual checked trap, not a hypothetical disclaimer.

Tests do not establish the general theorems; the proofs above do. They do not benchmark historical NumPy stability, validate an FFT interval backend, provide an exhaustive census, or prove sampling accuracy. The reference artifact is a mathematical research checker, not a hardened untrusted-input service or a fully audited numerical library.

## Sampling and publication boundary

The certificate concerns Y=U_N P x. The accepted pointwise basis-input full squared error ell_b-1 and unbiased rank-B worst-input MSE lower bound N/B-1 remain. Increasing numerical precision only reduces ||Y_hat-Y||. It cannot remove ||Y-U_N x||. Any comparison to U_N x must add a separately valid sampling/decoder guarantee under its own normalization and probability assumptions.

This candidate proposes closure only of a bounded residual-interface theorem and a reference small-case verifier, subject to independent review. It does not close the stable fast numerical executor, high-precision FFT-convolution backend, useful growing-B precision bound, stronger decoder, or complete paid implementation gates. ALG034 remains OPEN at priority 48.

## Primary source credit

- LAPACK Users' Guide, Further Details Error Bounds for Linear Equation Solving: the classical distinction between residual, backward error, forward error, and condition amplification; it also explicitly accounts for rounding errors in residual computation. This packet's bounds use analytic inverse constants and rigorous enclosures rather than equating a numerical norm estimate with a proof. https://www.netlib.org/lapack/lug/node81.html
- Fredrik Johansson, Arb documentation, Using Arb: inclusion-preserving arithmetic, input conversion, dependency overestimation, and guess-and-verify precision refinement are prior methodology. The reference checker here is independently authored and does not call Arb. https://fredrikj.net/arb/using.html
- Bostan and Mori, A Simple and Fast Algorithm for Computing the N-th Term of a Linearly Recurrent Sequence, section 2.1: linear recurrence/rational-series representation and associated algebraic cost context. Its distant-term algorithm is not a stability theorem or a whole-prefix certificate. https://arxiv.org/html/2008.08822v1
- Historical project v14 and core: exact row definitions, two-channel recurrence, and scan mapping; the commit-pinned URLs and byte hashes are in SOURCE_AUDIT.json.

All external primary sources were reopened for this candidate. No worldwide novelty or publication-priority claim is made. Third-party full texts are not redistributed.
