ALG034 all-stage fixed-point precision contract

Read REPORT.txt first. It specifies an explicit slow producer, proves its
precision/range bound, and gives a growing-order recurrence conditioning
obstruction. Independent review ACCEPTED the stated narrow scope, with no required repair.
Read INDEPENDENT_REVIEW.txt alongside the frozen author report. ALG-034 remains
OPEN at priority 48; it does not certify the historical FFT/blocked producer,
full DFT accuracy, sampling quality, or an asymptotic speed improvement.

The source report and accepted residual review are byte-preserved under
sources/. SOURCE_IDENTITY.json records the verified exact review identity.
No historical decoder or prior test program was imported or executed.

Fresh controls:
  python3 checks/fresh_controls.py
  python3 checks/exact_planning_controls.py
  python3 checks/independent_controls.py

The first program always rewrites CONTROL_RESULTS.json beside this README
and prints a log. The second similarly writes EXACT_PLANNING_RESULTS.json; the third writes
INDEPENDENT_CONTROL_RESULTS.json. To preserve sealed bytes, first copy the packet to a separate
working directory; run the copied program there and redirect its stdout to
a new log. It uses Python standard-library exact integer/rational arithmetic.
The direct interval oracle deliberately costs more than the producer.

The original author report retains its pre-review wording and exact frozen
bytes. INDEPENDENT_REVIEW.txt supplies the final scoped acceptance. The new
result is recorded separately in LATE_ARRIVAL.txt and leaves the frozen
204-row table proposal unchanged.

The final archive contains a manifest and SHA256SUMS. Library save receipts
and temporary helper files are retained outside the archive to avoid an
impossible self-referential checksum. No sharing permissions are changed.
