#!/usr/bin/env python3
"""Independently authored integer fixed-point and rectangular-interval audit.
No candidate or historical modules are imported. All arithmetic is integer.
"""
from math import comb, factorial, gcd, isqrt
from functools import lru_cache
from pathlib import Path
import json, hashlib
G=224; S=1<<G
class Interval:
 def __init__(self,a,b=None):self.a=a;self.b=a if b is None else b;assert self.a<=self.b
 @classmethod
 def rat(cls,a,b=1):return cls((a*S)//b,-((-a*S)//b))
 def __add__(self,o):return Interval(self.a+o.a,self.b+o.b)
 def __neg__(self):return Interval(-self.b,-self.a)
 def __sub__(self,o):return self+-o
 def __mul__(self,o):
  q=[self.a*o.a,self.a*o.b,self.b*o.a,self.b*o.b]
  return Interval(min(q)//S,-((-max(q))//S))
 def div(self,n):assert n>0;return Interval(self.a//n,-((-self.b)//n))
 def wide(self,r):return Interval(self.a-r,self.b+r)
 def mid(self):return (self.a+self.b)//2
 def contains(self,k):return self.a<=k<=self.b
Z=(Interval(0),Interval(0)); ONE=(Interval(S),Interval(0))
def cadd(z,w):return (z[0]+w[0],z[1]+w[1])
def cneg(z):return (-z[0],-z[1])
def csub(z,w):return cadd(z,cneg(w))
def cmul(z,w):return(z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0])
def realmul(z,c):return(z[0]*c,z[1]*c)
def cconj(z):return(z[0],-z[1])
def upper_l1(z):return max(abs(z[0].a),abs(z[0].b))+max(abs(z[1].a),abs(z[1].b))
def lower_mod(z):
 def near(x):return 0 if x.a<=0<=x.b else min(abs(x.a),abs(x.b))
 return isqrt(near(z[0])**2+near(z[1])**2)
def atan_inv(d):
 v=Interval(0);terms=G//2+24
 for k in range(terms):
  a=Interval.rat(1,(2*k+1)*d**(2*k+1));v=v+a if k%2==0 else v-a
 tail=Interval.rat(1,(2*terms+1)*d**(2*terms+1)).b
 return v.wide(tail)
# Machin is certified algebraically below, while alternating tails enclose atan.
PI=atan_inv(5)*Interval.rat(16)-atan_inv(239)*Interval.rat(4)
assert 3*S<PI.a<PI.b<4*S
@lru_cache(None)
def root(e,n):
 e%=2*n;q=(2*e)//n;rem=2*e-q*n
 if rem==0:return [ONE,(Interval(0),Interval(S)),(Interval(-S),Interval(0)),(Interval(0),Interval(-S))][q]
 theta=PI*Interval.rat(rem,2*n)
 term=Interval(S);re=Interval(0);im=Interval(0);degree=G+40
 for k in range(degree+1):
  if k%4==0:re=re+term
  elif k%4==1:im=im+term
  elif k%4==2:re=re-term
  else:im=im-term
  term=(term*theta).div(k+1)
 # Lagrange remainder since reduced angle <2.
 err=Interval.rat(1<<(degree+1),factorial(degree+1)).b
 z=(re.wide(err),im.wide(err))
 for _ in range(q):z=(-z[1],z[0])
 return z
# Half-up nearest integer division, with exact signed operands.
def nearest(a,b):return (2*a+b)//(2*b)
def iadd(z,w):return(z[0]+w[0],z[1]+w[1])
def ineg(z):return(-z[0],-z[1])
def isub(z,w):return iadd(z,ineg(w))
def imul(z,w,p):
 D=1<<p
 return(nearest(z[0]*w[0]-z[1]*w[1],D),nearest(z[0]*w[1]+z[1]*w[0],D))
def ival(z,p):return(Interval(z[0]<<(G-p)),Interval(z[1]<<(G-p)))
def approx_root(e,n,p):
 box=root(e,n);div=1<<(G-p);z=(nearest(box[0].mid(),div),nearest(box[1].mid(),div))
 er=[max(abs(z[k]*div-box[k].a),abs(z[k]*div-box[k].b)) for k in [0,1]]
 assert er[0]**2+er[1]**2<=(1<<(2*(G-p)))
 return z
cl=lambda x:(x-1).bit_length()
def part(n,b):
 q,r=divmod(n,b);length=[q+(j<r) for j in range(b)];start=[sum(length[:j]) for j in range(b)]
 return start,length

def pipeline(n,b,a,beta,W,t,seed):
 H=min(comb(n+b-1,b),1<<(n-b));p=max(W,t+b+cl(H)+cl(b)+2*cl(n)+7);unit=1<<(G-p)
 K=64*H*n*b*(1<<b);C=K*n;D=4*b*(1<<b)
 st,le=part(n,b);h=n%2
 nums=[(((j*17+seed*7)%31)-15,((j*11+seed*3)%29)-14) for j in range(n)]
 nums[seed%n]=(1<<(W-1),-(1<<(W-1)))
 if seed%2:nums=[(0,0)]*(n-1)+[(1<<(W-1),-(1<<(W-1)))]
 xx=[(v[0]<<(p-W),v[1]<<(p-W)) for v in nums];rx=[ival(v,p) for v in xx]
 rr=lambda e:approx_root(e,n,p)
 prod=lambda z,w:imul(z,w,p)
 d=[];dr=[];projected=[Z for j in range(n)]
 sx=lambda s,k:a*k*(k-1)+2*(a*s+beta)*k+h*k
 for s,l in zip(st,le):
  ac=(0,0);ar=Z
  for k in range(l):ac=iadd(ac,prod(rr(sx(s,k)),xx[s+k]));ar=cadd(ar,cmul(root(sx(s,k),n),rx[s+k]))
  d.append(ac);dr.append(ar)
  for k in range(l):projected[s+k]=cmul(root(-sx(s,k),n),ar)
  assert upper_l1(csub(ar,ival(ac,p)))<=3*l*unit
 w=[];wr=[]
 for j in range(b):
  z=(j-1)%b;e=-sx(st[z],le[z]);w.append(isub(d[j],prod(rr(e),d[z])));wr.append(csub(dr[j],cmul(root(e,n),dr[z])))
 assert sum(upper_l1(csub(v,ival(z,p))) for v,z in zip(wr,w))<=12*n*unit
 q=[(1<<p,0)];qr=[ONE]
 for s in st:
  nq=q+[(0,0)];nr=qr+[Z]
  for j in range(1,len(nq)):nq[j]=isub(nq[j],prod(rr(-2*s),q[j-1]));nr[j]=csub(nr[j],cmul(root(-2*s,n),qr[j-1]))
  q=nq;qr=nr
 assert sum(upper_l1(csub(v,ival(z,p))) for v,z in zip(qr,q))<=D*unit
 seq=[]
 for k in range(n):
  ac=(0,0)
  if k<b:
   for s,z in zip(st,w):ac=iadd(ac,prod(z,rr(-2*s*k)))
  else:
   for j in range(1,b+1):ac=isub(ac,prod(q[j],seq[k-j]))
  seq.append(ac)
  ar=Z
  for s,z in zip(st,wr):ar=cadd(ar,cmul(z,root(-2*s*k,n)))
  assert upper_l1(csub(ar,ival(ac,p)))<=(32*n if k<b else K)*unit
 r=isqrt((1<<(2*(p+16)))//n);rho=nearest(2*r+1,1<<17)
 f=[prod(z,(rho,0)) for z in seq]
 gauge=[rr(a*j*(j-1)+2*beta*j+h*j) for j in range(n)]
 us=[prod((gauge[j][0],-gauge[j][1]),f[(a*j)%n]) for j in range(n)]
 total=(sum(z[0] for z in us),sum(z[1] for z in us));v0=(nearest(total[0],2),nearest(total[1],2));pref=(0,0);out=[None]*n
 for j in range(n):out[(a*j)%n]=prod(gauge[j],isub(v0,pref));pref=iadd(pref,us[j])
 # Direct DFT of the projected time-domain signal is independent of the scan.
 ir=isqrt((1<<(2*G))//n);rho_box=Interval(ir,ir+1)
 maxerr=0
 for k in range(n):
  ar=Z
  for j,z in enumerate(projected):ar=cadd(ar,cmul(z,root(-2*j*k,n)))
  ar=realmul(ar,rho_box);err=upper_l1(csub(ar,ival(out[k],p)));maxerr=max(maxerr,err)
  assert err<=C*unit
  # ||x||2 >=1/2, so 2^(-t-1) is enough.
  assert err<=(1<<(G-t-1))
 I=b+2*cl(n)+10
 for z in d+w+q+seq+f+us+out:assert abs(z[0])+abs(z[1])<(1<<(p+I))
 return {'N':n,'B':b,'a':a,'beta':beta,'p':p,'W':W,'target_bits':t,'certified_l1_error_numerator':maxerr,'interval_scale_bits':G}

def main():
 # Exact tangent identities certify 4 atan(1/5)-atan(1/239)=pi/4,
 # with the quadrant selected by 0<4 atan(1/5)<4/5 and 0<atan(1/239)<1/239.
 from fractions import Fraction as F
 x=F(1,5);tan2=2*x/(1-x*x);tan4=2*tan2/(1-tan2*tan2);tanfinal=(tan4-F(1,239))/(1+tan4*F(1,239));assert tanfinal==1
 assert 4*(F(1,5)-F(1,3*125))-F(1,239)>0 and F(4,5)<F(3,2)
 plans=0
 for n in range(3,513):
  for b in range(3,n+1):
   H=min(comb(n+b-1,b),1<<(n-b));p=b+cl(H)+cl(b)+2*cl(n)+7
   C=64*H*b*(1<<b)*n*n
   assert 2*C<=1<<p
   assert 32*n*(1<<b)+16*n*b*(1<<b)+b<=32*n*b*(1<<b)
   # Normalization and gauge constants, replacing sqrt(N) by exact squared comparisons.
   assert 13*n*n+1<1<<(b+2*cl(n)+10)
   plans+=1
 root_contract=0
 for p in range(1,257):
  terms=p+32;tail=F(16,(2*terms+1)*5**(2*terms+1))+F(4,(2*terms+1)*239**(2*terms+1))
  trig=F(8**(p+65),factorial(p+65));guard=F(3,1<<(p+17))
  # Two times pi rounding plus angle rounding total <=3u/2^17.
  assert 2*tail+trig+guard<F(1,1<<(p+8));root_contract+=1
 rows=[]
 for n,b,a,beta in [(4,3,1,3),(5,3,2,4),(7,4,3,6),(8,6,3,5),(9,5,2,8),(10,7,7,4),(12,9,5,11),(13,6,5,12),(16,12,7,15),(17,3,8,16),(18,9,5,17),(20,15,9,19),(21,21,8,20)]:
  assert gcd(a,n)==1
  for seed in [2,3]:
   row=pipeline(n,b,a,beta,5,0 if seed==2 else 17,seed);rows.append(row);print('ROW PASS',n,b,a,beta,row['p'],flush=True)
 obstruction=[]
 for m in [1,2,3,5,7,10,16,24,32]:
  n=4*m;b=3*m;st,_=part(n,b);omitted=sorted(set(range(n))-set(st));assert omitted==list(range(1,2*m,2))
  poly=[ONE]
  for r in omitted:
   tmp=poly+[Z]
   for j in range(1,len(tmp)):tmp[j]=csub(tmp[j],cmul(root(-2*r,n),poly[j-1]))
   poly=tmp
  lo=sum(lower_mod(z) for z in poly);tail=sum(lower_mod(z) for z in poly[:-1]);assert lo*lo>=(1<<m)*S*S;assert (tail+S)**2>=(1<<m)*S*S
  # Product at -i is also evaluated independently by scalar factor moduli.
  product=ONE
  for r in omitted:product=cmul(product,csub(ONE,cmul(root(-2*r,n),(Interval(0),Interval(-S)))))
  assert lower_mod(product)**2>=(1<<m)*S*S
  # Explicit dyadic defect vectors with independently certified unit modulus.
  P=80;DP=1<<P;response=Z
  for hh in poly[:-1]:
   aa,bb=hh[0].mid(),hh[1].mid();den=isqrt(aa*aa+bb*bb)+1
   trunc=lambda z:(1 if z>=0 else -1)*(abs(z)*DP//den)
   defect=(trunc(aa),trunc(-bb));assert defect[0]**2+defect[1]**2<=DP*DP
   response=cadd(response,cmul(hh,ival(defect,P)))
  realized=lower_mod(response);assert (realized+S)**2>=(1<<m)*S*S
  # Check the full omitted-root product identity by interval convolution.
  Q=[ONE]
  for r in st:
   tmp=Q+[Z]
   for j in range(1,len(tmp)):tmp[j]=csub(tmp[j],cmul(root(-2*r,n),Q[j-1]))
   Q=tmp
  full=[Z for j in range(n+1)]
  for j,z in enumerate(Q):
   for k,w in enumerate(poly):full[j+k]=cadd(full[j+k],cmul(z,w))
  for j,z in enumerate(full):assert z[0].contains(S if j==0 else -S if j==n else 0) and z[1].contains(0)
  obstruction.append({'m':m,'N':n,'B':b,'full_norm_lower_numerator':lo,'tail_norm_lower_numerator':tail,'realized_dyadic_defect_lower_numerator':realized,'defect_fractional_bits':P,'full_product_identity':'PASS','interval_scale_bits':G});print('OBSTRUCTION PASS',m,flush=True)
 report=Path(__file__).resolve().parents[1]/'REPORT.txt'
 results={'status':'PASS','frozen_report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'historical_or_author_control_modules_executed':False,'planning_cases':plans,'root_construction_inequalities':root_contract,'full_integer_pipeline_rows':rows,'obstruction_cases':obstruction}
 (report.parent/'INDEPENDENT_CONTROL_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print('ALL INDEPENDENT PASS',len(rows),plans,len(obstruction),flush=True)
if __name__=='__main__':main()
