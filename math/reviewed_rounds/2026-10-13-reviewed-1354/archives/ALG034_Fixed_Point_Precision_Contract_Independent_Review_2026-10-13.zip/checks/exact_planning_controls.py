#!/usr/bin/env python3
"""Fresh exact integer planning/range and finite dyadic rounding controls."""
from math import comb,gcd
from fractions import Fraction as F
from pathlib import Path
import json
cl=lambda n:(n-1).bit_length()
rows=0;rangechecks=0;phases=0;rounds=0
for n in range(3,257):
 for b in range(3,n+1):
  H=min(comb(n+b-1,b),1<<(n-b));I=b+2*cl(n)+10
  for t,W in [(0,1),(12,53),(53,256)]:
   p=max(W,t+b+cl(H)+cl(b)+2*cl(n)+7);u=F(1,1<<p);C=64*H*b*(1<<b)*n*n;K=64*H*n*b*(1<<b);D=4*b*(1<<b)*u
   assert 2*C<=(1<<(p-t));assert K*u<=F(1,2*n);assert H*D<F(1,2)
   assert 32*n*(1<<b)+16*n*b*(1<<b)+b<=32*n*b*(1<<b)
   for bound in [2**b+D,33*n,5*n*((1<<b)+D)+b*u,13*n*n+1]:assert bound<(1<<I);rangechecks+=1
   rows+=1
 for a in range(1,n):
  if gcd(a,n)!=1:continue
  assert (a*(n-1)+(n%2))%2==1
  for beta in [0,n-1]:
   for j in [0,n//2,n-1]:
    g=lambda r:(a*r*(r-1)+2*beta*r+(n%2)*r)%(2*n)
    assert (g(j+1)-g(j)-2*((a*j)%n+beta)-(n%2))%(2*n)==0
    phases+=1
for p in [1,2,8,53,200]:
 def rnd(v):
  v*=1<<p;return F((2*v.numerator+v.denominator)//(2*v.denominator),1<<p)
 for a in range(-29,30):
  for b in range(1,18):
   z=(F(a,b),F(3*a-2,2*b+1));rr=(rnd(z[0]),rnd(z[1]));assert (rr[0]-z[0])**2+(rr[1]-z[1])**2<=F(1,1<<(2*p));rounds+=1
scales=[]
for W in [1,7,53,200]:
 for inputF in [-1000,-80,0,120,1000]:
  p=max(W,97);m=(1<<(W-1))+int(W>1);e=W-inputF;normalized=F(m,1<<W)
  assert F(1,2)<=normalized<1 and (normalized*(1<<p)).denominator==1
  # Store an output grid integer and a common exponent, without materializing gigantic floating exponents.
  output_grid_integer=(1<<(p+3))+17;scale_exponent=e-p
  if scale_exponent>=0:dyadic=F(output_grid_integer*(1<<scale_exponent))
  else:dyadic=F(output_grid_integer,1<<(-scale_exponent))
  sigma=F(1<<e) if e>=0 else F(1,1<<(-e))
  assert dyadic==sigma*F(output_grid_integer,1<<p)
  scales.append({'W':W,'F':inputF,'p':p,'e':e,'output_scale_exponent':scale_exponent})
out={'status':'PASS','exact_precision_plans':rows,'exact_range_inequalities':rangechecks,'exact_gauge_phase_identities':phases,'complex_nearest_grid_roundings':rounds,'exact_input_and_scaled_output_controls':scales}
Path(__file__).resolve().parents[1].joinpath('EXACT_PLANNING_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
