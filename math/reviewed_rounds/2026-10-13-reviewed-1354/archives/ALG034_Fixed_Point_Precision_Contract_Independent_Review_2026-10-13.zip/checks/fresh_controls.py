#!/usr/bin/env python3
"""Fresh fixed-point ALG034 controls. No historical/candidate module is imported.
Exact Fraction arithmetic, integer square roots, and independently enclosed roots.
"""
from fractions import Fraction as F
from math import comb, factorial, gcd, isqrt
from functools import lru_cache
from pathlib import Path
import json
ZERO=(F(0),F(0)); ONE=(F(1),F(0))
def add(a,b):return(a[0]+b[0],a[1]+b[1])
def neg(a):return(-a[0],-a[1])
def sub(a,b):return add(a,neg(b))
def mul(a,b):return(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,c):return(a[0]*c,a[1]*c)
def conj(a):return(a[0],-a[1])
def rnd(x,p):
 v=x*(1<<p);return F((2*v.numerator+v.denominator)//(2*v.denominator),1<<p)
def rc(z,p):return(rnd(z[0],p),rnd(z[1],p))
def up(x,p):return F(-((-x.numerator*(1<<p))//x.denominator),1<<p)
def nlo(z,p=160):
 t=z[0]*z[0]+z[1]*z[1];return F(isqrt((t.numerator<<(2*p))//t.denominator),1<<p)
def nhi(z,p=160):return nlo(z,p)+F(1,1<<p)
def asum(a):return abs(a[0])+abs(a[1])
def ceilog(n):return (n-1).bit_length()
def atan_mid_rad(d,t):
 s=sum((F((-1)**k,(2*k+1)*d**(2*k+1)) for k in range(t)),F(0))
 return s,F(1,(2*t+1)*d**(2*t+1))
@lru_cache(None)
def pi_box(p,independent):
 t=p+32
 if independent:
  a,ar=atan_mid_rad(2,t);b,br=atan_mid_rad(3,t);return 4*(a+b),4*(ar+br)
 a,ar=atan_mid_rad(5,t);b,br=atan_mid_rad(239,t);return 16*a-4*b,16*ar+4*br
@lru_cache(None)
def root_box(e,n,p,independent=False):
 e%=2*n
 if (2*e)%n==0:
  quad=(2*e//n)%4
  return [ONE,(F(0),F(1)),(F(-1),F(0)),(F(0),F(-1))][quad],F(0)
 pm,pr=pi_box(p,independent)
 old_pm=pm;pm=rnd(pm,p+16);pr+=abs(old_pm-pm)
 raw_theta=pm*F(e,n);theta=rnd(raw_theta,p+16);angle_rad=2*pr+abs(theta-raw_theta);degree=p+64
 assert pm+pr<4 and pm-pr>3
 re=F(0);im=F(0);term=F(1)
 for k in range(degree+1):
  if k%4==0:re+=term
  elif k%4==1:im+=term
  elif k%4==2:re-=term
  else:im-=term
  term*=theta/F(k+1)
 rad=F(8**(degree+1),factorial(degree+1))+angle_rad
 assert rad<F(1,1<<(p+8))
 return (re,im),rad
@lru_cache(None)
def root_fixed(e,n,p):
 c,r=root_box(e,n,p);z=rc(c,p);er=abs(z[0]-c[0])+r;ei=abs(z[1]-c[1])+r
 assert er*er+ei*ei<=F(1,1<<(2*p))
 return z
class Ball:
 P=140
 def __init__(self,c=ZERO,r=F(0)):
  d=rc(c,self.P);self.c=d;self.r=up(r+nhi(sub(c,d),self.P),self.P)
 @classmethod
 def root(cls,e,n):
  c,r=root_box(e,n,cls.P,True);return cls(c,2*r)
 def __add__(self,b):return Ball(add(self.c,b.c),self.r+b.r)
 def __neg__(self):return Ball(neg(self.c),self.r)
 def __sub__(self,b):return self+-b
 def __mul__(self,b):return Ball(mul(self.c,b.c),asum(self.c)*b.r+asum(b.c)*self.r+self.r*b.r)
 def conjugate(self):return Ball(conj(self.c),self.r)
 def times(self,c):return Ball(scale(self.c,c),self.r*abs(c))
 def error(self,z):return nhi(sub(self.c,z),self.P)+self.r
 def upper(self):return nhi(self.c,self.P)+self.r
 def lower(self):return max(F(0),nlo(self.c,self.P)-self.r)
def partition(n,b):
 q,r=divmod(n,b);lens=[q+int(j<r) for j in range(b)];starts=[];s=0
 for le in lens:starts.append(s);s+=le
 return starts,lens
def sexp(a,beta,h,s,t):return a*t*(t-1)+2*(a*s+beta)*t+h*t
def cexp(a,beta,h,s,le):return -a*le*(le-1)-2*(a*s+beta)*le-h*le

def fixed_producer(x,n,b,a,beta,p):
 """x is already exact normalized dyadic data."""
 starts,lens=partition(n,b);h=n%2;R=lambda e:root_fixed(e,n,p);cm=lambda z,w:rc(mul(z,w),p)
 d=[]
 for s,le in zip(starts,lens):
  acc=ZERO
  for t in range(le):acc=add(acc,cm(R(sexp(a,beta,h,s,t)),x[s+t]))
  d.append(acc)
 c=[R(cexp(a,beta,h,s,le)) for s,le in zip(starts,lens)]
 w=[sub(d[j],cm(c[j-1],d[j-1])) for j in range(b)]
 q=[ONE]
 for s in starts:
  old=q;q=old+[ZERO];lam=R(-2*s)
  for j in range(1,len(q)):q[j]=sub(q[j],cm(lam,old[j-1]))
 seq=[]
 for k in range(b):
  acc=ZERO
  for s,ww in zip(starts,w):acc=add(acc,cm(ww,R(-2*s*k)))
  seq.append(acc)
 for k in range(b,n):
  acc=ZERO
  for j in range(1,b+1):acc=add(acc,cm(q[j],seq[k-j]))
  seq.append(neg(acc))
 rp=p+16;rr=isqrt((1<<(2*rp))//n);rho=rnd(F(2*rr+1,2*(1<<rp)),p)
 assert (rho-F(rr,1<<rp))**2<=F(1,1<<(2*p)) and (rho-F(rr+1,1<<rp))**2<=F(1,1<<(2*p))
 f=[cm(v,(rho,F(0))) for v in seq]
 g=[R(a*j*(j-1)+2*beta*j+h*j) for j in range(n)]
 u=[cm(conj(g[j]),f[(a*j)%n]) for j in range(n)]
 total=ZERO
 for v in u:total=add(total,v)
 v0=rc(scale(total,F(1,2)),p);prefix=ZERO;out=[ZERO]*n
 for j in range(n):
  out[(a*j)%n]=cm(g[j],sub(v0,prefix));prefix=add(prefix,u[j])
 return {'d':d,'w':w,'q':q,'s':seq,'f':f,'out':out}

def oracle(x,n,b,a,beta,p):
 Ball.P=p;starts,lens=partition(n,b);h=n%2;d=[];projected=[Ball() for _ in range(n)]
 for s,le in zip(starts,lens):
  acc=Ball()
  for t in range(le):acc=acc+Ball.root(sexp(a,beta,h,s,t),n)*Ball(x[s+t])
  d.append(acc)
  for t in range(le):projected[s+t]=Ball.root(-sexp(a,beta,h,s,t),n)*acc
 c=[Ball.root(cexp(a,beta,h,s,le),n) for s,le in zip(starts,lens)]
 w=[d[j]-c[j-1]*d[j-1] for j in range(b)]
 q=[Ball(ONE)]
 for s in starts:
  old=q;q=old+[Ball()];lam=Ball.root(-2*s,n)
  for j in range(1,len(q)):q[j]=q[j]-lam*old[j-1]
 seq=[]
 for k in range(n):
  acc=Ball()
  for s,ww in zip(starts,w):acc=acc+ww*Ball.root(-2*s*k,n)
  seq.append(acc)
 rr=isqrt((1<<(2*p))//n);rho=Ball((F(2*rr+1,2*(1<<p)),F(0)),F(1,2*(1<<p)))
 out=[]
 for k in range(n):
  acc=Ball()
  for j,v in enumerate(projected):acc=acc+v*Ball.root(-2*k*j,n)
  out.append(acc*rho)
 return {'d':d,'w':w,'q':q,'s':seq,'out':out}

def main():
 results={'historical_or_candidate_code_executed':False,'rows':[],'obstruction':[],'exact_partition_cases':0}
 for n in range(3,14):
  for b in sorted(set([3,(n+3)//2,n])):
   if b>n:continue
   H=min(comb(n+b-1,b),1<<(n-b));targ=12;W=5
   p=max(W,targ+b+ceilog(H)+ceilog(b)+2*ceilog(n)+7)
   eps=F(1,1<<p);K=64*H*n*b*(1<<b);C=64*H*b*(1<<b)*n*n
   for case in range(2):
    a=1 if case==0 else n-1;beta=0 if case==0 else n-1
    nums=[(((-1)**j)*(16+(j*3)%15), ((j*7)%17)-8) for j in range(n)]
    if case:nums=[(0,0)]*(n-1)+[(16,-16)]
    x=[(F(re,1<<W),F(im,1<<W)) for re,im in nums]
    got=fixed_producer(x,n,b,a,beta,p);ref=oracle(x,n,b,a,beta,p+40)
    starts,lens=partition(n,b)
    for dd,ee,le in zip(got['d'],ref['d'],lens):assert ee.error(dd)<=3*le*eps
    werr=sum((z.error(v) for z,v in zip(ref['w'],got['w'])),F(0));assert werr<=12*n*eps
    qerr=sum((z.error(v) for z,v in zip(ref['q'],got['q'])),F(0));assert qerr<=4*b*(1<<b)*eps
    seederr=max(z.error(v) for z,v in zip(ref['s'][:b],got['s'][:b]));assert seederr<=32*n*eps
    serr=max(z.error(v) for z,v in zip(ref['s'],got['s']));assert serr<=K*eps
    outerr=max(z.error(v) for z,v in zip(ref['out'],got['out']));assert outerr<=C*eps<=F(1,1<<(targ+1))
    # Exact finite grid and stored-range controls; scale cases are tested separately.
    for vals in got.values():
     for v in vals:
      for component in v:assert (component*(1<<p)).denominator==1
    maxmag=max(asum(z) for vals in got.values() for z in vals);I=b+2*ceilog(n)+10;assert maxmag<(1<<I)
    results['rows'].append({'N':n,'B':b,'a':a,'beta':beta,'p':p,'target_bits':targ,'H':H,'stage_bounds':'PASS','output_interval_upper':str(outerr),'theorem_upper':str(C*eps),'max_stored_l1':str(maxmag),'integer_bits':I})
    print('PASS',n,b,a,beta,p,flush=True)
 for m in [1,2,3,4,6,8,12,16]:
  n=4*m;b=3*m;Ball.P=100;starts,lens=partition(n,b)
  omitted=sorted(set(range(n))-set(starts));assert omitted==list(range(1,2*m,2))
  poly=[Ball(ONE)]
  for r in omitted:
   old=poly;poly=old+[Ball()];lam=Ball.root(-2*r,n)
   for j in range(1,len(poly)):poly[j]=poly[j]-lam*old[j-1]
  Hlower=sum((x.lower() for x in poly),F(0));tail_lower=sum((x.lower() for x in poly[:-1]),F(0))
  assert Hlower*Hlower>=1<<m
  # Exact dyadic defects align approximately with the final row. Their bound <=1 is rigorously checked.
  defects=[]
  for h in reversed(poly[:-1]):
   upper=h.upper();d=rc(scale(conj(h.c),1/upper),80) if upper else ZERO
   if nlo(d,120)>1:d=scale(d,F(1,2))
   while nhi(d,120)>1:d=scale(d,F((1<<80)-1,1<<80))
   defects.append(d)
  acc=Ball()
  for h,d in zip(poly[:-1],reversed(defects)):acc=acc+h*Ball(d)
  realised_lower=acc.lower()
  # Its magnitude squared exceeds a conservative lower exponential bound, except m=1 with cancellation margin.
  if m>=2:assert (realised_lower+1)**2>=1<<m
  results['obstruction'].append({'m':m,'N':n,'B':b,'H_lower':str(Hlower),'tail_operator_lower':str(tail_lower),'dyadic_defect_amplification_lower':str(realised_lower),'exponential_squared_lower':1<<m})
  print('OBSTRUCTION',m,flush=True)
 for m in range(1,1001):
  s,l=partition(4*m,3*m);assert sorted(set(range(4*m))-set(s))==list(range(1,2*m,2));results['exact_partition_cases']+=1
 # Rational fourth-root exact check of the factor and reciprocal identity for N=4,B=3.
 q=[ONE]
 for lam in [ONE,(-F(1),F(0)),(F(0),F(1))]:
  old=q;q=old+[ZERO]
  for j in range(1,len(q)):q[j]=sub(q[j],mul(lam,old[j-1]))
 omitted=[ONE,(F(0),F(1))];prod=[ZERO]*5
 for i,x in enumerate(q):
  for j,y in enumerate(omitted):prod[i+j]=add(prod[i+j],mul(x,y))
 assert prod==[ONE,ZERO,ZERO,ZERO,(-F(1),F(0))]
 results['exact_fourth_root_identity']='PASS';results['status']='PASS';results['row_count']=len(results['rows'])
 dest=Path(__file__).resolve().parents[1]/'CONTROL_RESULTS.json';dest.write_text(json.dumps(results,indent=2)+'\n')
 print('ALL PASS',len(results['rows']),flush=True)
if __name__=='__main__':main()
