# Independent review request

Review the exact pinned BUCKETS component, not an integrated recovery claim. Start with REPORT.md and sources/ALGORITHM.txt step 4, PROOF.md sections 2, 3 and 6. Preserve the production sources. Give an explicit ACCEPT, REPAIR or BLOCKED verdict with exact source hashes and separate treatment of numerical correctness, finite interface, every-path resource charges and excluded scope.

Please independently test root/scale certificates, affine signs and wrapping, folded FFT normalization, final signed rounding, sparse source access, unbounded beta/source precision, and malformed/corrupted controls. The numerical return intentionally excludes polynomial-width diagnostic integers. The one pre-freeze interface-only cleanup is retained as a diff; only the current source hash is the review target.
