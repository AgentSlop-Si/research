# Q16 certified BUCKETS component candidate

13 October 2026. New producer-authored source and tests, awaiting separate review.

## Result and scope

This packet implements ALGORITHM.txt step 4 using the independently accepted compact-window revision 2 without changing a byte of that dependency. It adds paid certified FFT roots, a paid reciprocal-square-root scale, exact affine sample addressing, exact tap folding, an explicit unnormalized negative-sign radix-two FFT, exact scaling, and one signed nearest-even output rounding per Cartesian component.

The numerical return is exactly B Cartesian numerator pairs with one common exponent P. No error-bound numerator, ledger integer or other polynomial-width diagnostic is passed through that numerical return. The engine retains its separately inspectable accounting and certificates. Source and tests were written for this component; no historical unapproved executable was run.

The mathematical input specification is sufficient for this component. No additional probabilistic premise, amplitude separation or root oracle is introduced. This is a component candidate, not completion of sparse recovery. Location/estimation randomness, ranking, modular inverses, unknown-frequency enumeration, medians, the exceptional dense branch, outer normalization/transfer and an all-length integrated engine remain outside this packet. Host totality and practical speed are not established.

## Exact interface and provenance

Construct BucketEngine(spec, ledger=None). The spec must be an exact WindowSpec from the pinned dependency. Construction starts or adopts its ledger before validation and then actually invokes accepted prepare_window, prepares every required root, prepares the scale and computes the error envelope. No constructor argument accepts supplied taps, supplied roots, an assumed preparation receipt, a callback or a cache.

The underlying reduced domain is M=2^m, B=2^b, B>=4, T=M/B>=4, r>=1, P>=8, ell=8B and W=2r(ell-1)+1<M. A beta-bearing spec additionally checks all accepted E(beta) front-end sparse parameters and guards through the unchanged validator. The accepted r=2m+1 and P=16m+16 are not inferred from reduced fixtures. The separately accepted outer guards, including beta*m>=2 and the outer t<M, remain caller obligations.

Call engine.run(source, sigma, tau). It revalidates the spec with the same cumulative ledger, including beta numerator and denominator widths. Sigma is an exact odd integer in [1,M-1]; tau is an exact integer in [0,M-1]. It neither draws nor rejects random bits. These are precisely the possible affine parameters from the accepted fixed-bit sampling procedure. Every such pair is allowed.

DyadicSource contains an exact tuple of M already represented samples and a nonnegative integer fractional_bits_bound F. Each sample is an exact two-tuple of Cartesian dyadics (n,e), interpreted as n/2^e, with integer n,e, 0<=e<=F and |n|<=2^e. Boolean substitutes and mutable/callable sample representations are not accepted. The immutable tuple prevents an unbounded user callback from hiding arbitrary work in a purported source read. Only selected samples are accessed and checked. Different coordinates and Cartesian components may have different exponents; each queried value is aligned exactly to the F-grid inside the charged call. There is no conversion pass over the source.

The full original-input validation and its source storage already belong to the caller in PROOF.md section 0. This API does not claim to verify unsampled entries, the global norm promise, or the caller's normalization. The BUCKETS numerical error proof needs only the sample magnitude bound; a zero-vector fixture is valid for this component without becoming a full E(beta) input. F=O_d(m) is the accepted finite-input regime. Standalone calls also allow arbitrary represented F and charge the resulting widths rather than imposing a hidden cap.

Return BucketResult(numerators, bits): exactly B distinct bucket positions in index order, each represented by a pair of signed integers on grid 2^-P, and bits=P. Internal private-state mutation and fabricated replacement of prepared objects are not a deserialization API. Frozen source pins and independent test-time certificates detect packet or prepared-payload corruption; this is not a claim of security against arbitrary memory tampering in Python.

## Pinned accepted window

The source src/compact_window.py has SHA256 e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59, the exact independently accepted v2 source. The relevant review and machine verdict are copied into sources. The acceptance Library identity supplied to this task is libfile_9c669121d8e881918106839b5d88659f; the reviewed v2 candidate identity is libfile_cd9e8245dd4c8191843cdb960d779379.

The dependency establishes tap error <=rho=2^-P for the exact w_t=M F_t D_H(t)/C and supplies the finite construction ledger. In particular sum_t |w_t|<=M(2H+1)<=M^2. Construction and retained coefficients/tap certificates are included here. It is not enough merely to copy a prior cost number: this constructor calls preparation using its own cumulative ledger. Revalidation is also charged when it genuinely occurs.

## Certified roots and scale

Set Q=P+2, J=P+8, K=J+2 bit_length(J+1)+16. A new accepted Scalar(K,L) is constructed for root preparation. Even pi preparation is rerun and charged; it is not silently reused from the window's finished scalar object. For j=0,...,B/2-1, compute

    real_j = sin(pi (B+4j)/(2B)),
    imag_j = sin(pi (-2j)/B).

The exact integer argument reductions give exp(-2 pi i j/B), including all axes. Store enclosing intervals on the K-grid, and round each midpoint nearest-even to the Q-grid. The checked inequality 64(K+9)<=2^(K-J) implies each scalar interval has width at most 2^-J. It holds uniformly for P>=8: K+9<=4(J+1), whereas 2^(K-J)>2^16(J+1)^2. Consequently each component's error is at most rho/8+rho/512<rho/4. The exact sum of the squares of the two endpoint-distance bounds is checked against rho^2. Every complex root therefore has absolute complex error at most rho, not merely coordinate error rho.

All stage roots are drawn from this B/2 table. A stage of length l uses root jB/l. No exponentiation of an approximate root is substituted for separately certified table entries.

For the scale, form n=floor(2^(2K)/M). Compute floor(sqrt(n)) by descending greedy root bits. There are exactly ceil(bit_length(n)/2)<=K iterations, each using a charged trial addition, binary power and square. The invariant on termination is a^2<=n<(a+1)^2. If a^2 M=2^(2K), the scale enclosure is exactly a/2^K; otherwise it is [a/2^K,(a+1)/2^K]. This brackets 1/sqrt(M), including the n=0 case and even/odd m. Its Q-grid midpoint rounding has certified absolute error <=rho. There is no built-in transcendental, floating operation, tolerance loop, random retry or external constant table in production.

## Exact affine and FFT data path

Initialize B zero pairs. For every one of the W taps, including taps whose rounded numerator is zero, read precisely

    index = (sigma*t+tau) mod M.

Negative t is not first reinterpreted in fixed-width host arithmetic. The signed multiply, add and nonnegative modulo are exact charged integers. Fold its exact real tap times the aligned complex sample into bin t mod B. Since W<M and sigma is odd, these W addresses are distinct modulo M, but the implementation does not assume or cache this fact to omit a read. There are exactly W source queries and 2W Cartesian alignments per successful run.

After explicit bit reversal, perform b stages. Every butterfly uses four integer multiplications for the complex root product, two more to align the other operand's denominator, and six integer additions/subtractions for products and sum/difference. There are exactly Bb/2 butterflies and Bb bit-reversal iterations. Root indices, stage sizes, strides and addresses are charged integer operations. There is no library FFT.

Folding has common denominator exponent F+P. Each stage raises the exponent by exactly Q, without rounding any intermediate product or sum. Scaling raises it once more by Q. The final denominator exponent is F+P+(b+1)Q. Round each Cartesian numerator exactly once to the P-grid using the accepted signed nearest-even primitive. There are exactly 2B final numerical rounding calls and B output pairs. Root and scale preparation roundings are separately counted. The numerical payload has no additional certificate fields.

## Every-path numerical error

Let A=2M^2, D=2W rho and R=(1+rho)^b. The exact raw supported input has complex l1 norm at most A. Replacing every tap changes that norm by at most D, so the approximate folded input has l1 norm at most A+D.

For each input-to-output FFT path the exact product of unit roots is replaced by a product of at most b approximate roots. The difference is at most R-1. This uses the actual radix-two unique-path expansion and permits any signs in the samples. The unscaled FFT error is at most D+(A+D)(R-1)=(A+D)R-A.

The prepared scale differs from the ideal scale by at most rho and has magnitude <=1+rho. Ideal unscaled output magnitude is <=A. Final Cartesian nearest rounding contributes complex error <=rho. Combining these facts gives the general dyadic upper bound

    E = (A+D)(1+rho)^(b+1) - A + rho.

The constructor computes this exact positive rational as a dyadic integer numerator with exponent P(b+2), using charged binary exponentiation. It is a general reduced-component certificate, including parameter choices where b*rho is not small. No reduced-domain call is refused merely because the simplified accepted bound is unavailable.

In the accepted front-end regime P=16m+16 and b<=m, b*rho<=1/2 and (1+rho)^b-1<=2b rho. Since D<=2M rho, A+D<=4M^2 and 1+rho<2, the same bound is at most (16b+7)M^2 rho, hence at most the required 24(m+1)M^2 rho. This holds for every permitted affine pair and sample vector, independently of any recovery-success event. The constructor records whether its exact E satisfies that simplified inequality. All numerical fixtures in this packet do, but no fixture is relabeled as accepted theorem-parameter execution.

The ideal scaled bucket norm is at most A. The program's output amplitude assertion checks each Cartesian output against A+E using exact integers. It cannot fail on valid-domain arithmetic under the proved certificates. This is an invariant assertion, not a probabilistic or capacity-based abort.

## Finite operations, widths and memory

All exact data arithmetic uses the accepted Ledger. An operation on operand/result widths b_i is charged 16(2+sum b_i)^2 schoolbook units. Retained supplied integer parameters are recorded before use. Source integer fields are recorded before exponent and magnitude validation, so even a malformed enormous numerator cannot be processed at an uncharged width. Beta's two normalized Fraction fields are reread and charged by accepted v2 validation. There is no new uninstrumented Fraction arithmetic in production.

Each source access is one immutable random-access input read, charged as a source_query event plus the four read integer fields, their alignment arithmetic and address arithmetic. A physical storage implementation with an additional I/O cost must add that cost; no arbitrary user callback is asserted to have unit cost. The existing read-only source's M sample cells are input storage, not newly allocated auxiliary memory.

For every event inventory, write E_c=sum(operation_counts)+256 and L=max_observed_integer_bits+bit_length(E_c)+2. The source-model envelope adds 512 E_c L^2 control work and 512 E_c L bits to all produced-integer storage. This bounds fixed-arity field/type tests, signs/comparisons, loop bookkeeping, tuple records/copies, addresses, ledger counters and report metadata. The explicit loop events cover every window/scalar iteration, root, square-root bit, tap, source alignment, reversal bit, butterfly, stage and output. There are no unbounded data-dependent loops in the new source. Allocation events charge initialization and copies cumulatively, not merely the final live list. This is the same conservative finite-arithmetic source model as the accepted dependency, not Python instruction or resident-memory certification.

Let h bound beta's two input-field widths. The new arithmetic width is bounded by a constant multiple of

    h + F + (b+2)(P+2) + m + log(r+1),

together with the dependency's window width bound O(r log ell+r K_window+K_window log K_window+P+m). The FFT estimate follows directly from exponent growth and the crude amplitude bound (1+rho)^b<=2^b: a final unrounded numerator needs at most F+P+(b+1)(P+2)+b+2m+O(1) bits. Index products use at most 2m+O(1) bits. Error-certificate construction has O(Pb+m) bits. Root Taylor/factorial intermediates have O(K_root log K_root) bits. Final bucket numerators have P+2m+b+O(1) bits, hence O_d(m) in the accepted regime, and their sole output exponent is P=O(m).

Beyond accepted window preparation, root preparation has O(B K_root) scalar operations, scale construction O(K_root) root-bit steps and error-bound construction O(log(b+1)) charged multiplications at O(Pb+m)-bit widths. A successful BUCKETS call has O(W+Bb) data/control events plus finite validation. For the accepted r,P,F regime, constructor and one call have O((B+T) poly_d(m+h)) charged bit work and cumulative auxiliary storage. For fixed beta, h is fixed, yielding the separate accepted O_(beta,d)((B+T) poly(m)) form. One must not drop F or h from the arbitrary standalone-input account.

For n repeated calls, the lifetime ledger retains one actual preparation and all n run costs, including repeated validation; it does not restart or subtract earlier work. Scalar checks, invalid-input returns and numerical assertions are finite. Failed-domain inputs are reported by ValueError; valid-domain arithmetic has no timeout, allocation cap, retry or probabilistic refusal. As with the accepted window, real hosts can exhaust memory for enormous valid inputs. That deployment gap is explicitly open.

## Producer tests and negative controls

The fresh test oracle uses pi=4(atan(1/2)+atan(1/3)), direct rational Taylor powers/factorials, a closed inclusion-exclusion formula for box coefficients, rational interval arithmetic, and a direct B-point DFT. It imports no production scalar, coefficient, FFT or rounding implementation. An additional exact Fraction recursive radix-two calculation checks the actual prepared-dyadic computation, independently of the iterative production schedule.

Seven reduced fixtures cover M=64 through 2048, B=4 through 32, r=1 through 4 and P=8 through 40; W includes 63/64, 125/128 and 249/256 near-support cases. Thirty-five bucket runs use zero, constant, impulse, signed axes and bounded variable-exponent pseudo-random sources. All outputs match the independent exact calculation; all 38 prepared roots, seven scales and 1,837 taps receive independent interval checks. Every ideal bucket comparison uses a rational complex-error inequality without a floating tolerance.

All 2,048 odd affine pairs at M=64 are enumerated and checked against the exact calculation, including negative tap indices and wrapped shifts. Every source-query, alignment, stage, butterfly and bucket-output count is checked on the seven five-source fixtures. Isqrt receives 1,031 integer/boundary controls and signed nearest-even receives 33,990 rational controls.

Invalid sigma/tau, booleans, callbacks, mutable sources, source length, exponent bounds, magnitudes and sample shapes are rejected. An invalid 65,537-bit sampled numerator is visibly charged before rejection. Valid F=0,16,128,4096 source cases establish that increasing precision changes the observed widths and costs. Intercepted constructor prefixes use beta_n=1/4-2^-n at n=16,128,4096,65536 and fixed accepted front-end parameters; these charge the beta fields before window construction. No giant coefficient or tap array is allocated by these prefix tests.

Nine separate source mutants are detected: FFT sign, affine shift placement, fold bin, omitted bit reversal, wrong root stride, denominator alignment, omitted final scale, wrong signed rounding, and skipped supported query. A tenth corrupted root-payload control violates the independent complex-rho certificate. The mutation harness uses copies of the new source, never changes either production file, and does not claim the runtime authenticates arbitrary private-state tampering. A separate TraceLedger reconstructs primitive cost and produced-integer storage over 231,903 records and independently recovers the cumulative-storage envelope. A deliberately invalid unsampled coordinate confirms that no dense source-validation pass is hidden.

All tests are producer evidence awaiting independent review. They corroborate, rather than replace, the universal domain/error/resource argument above. Numerical tests remain reduced fixtures; the first beta=1/4 accepted sparse front-end crossover remains m=46 and was not numerically prepared here.

## Reproduction and independent review request

Verify MANIFEST.json with verify_package.py before execution. Work on a copy if preserving the exact sealed receipts; replay writes fresh elapsed times into results. Run tests/run_tests.py and tests/corruption_controls.py with Python 3.12 and the standard library only. No network, plugin, credentials or numerical third-party package is required.

Separate review should check the source pins, scale bracket, complex root-error convention, FFT path/root order, negative affine indexing, absence of intermediate rounding, the exact generic and accepted error bounds, source/parameter width charges, fixed operation counts and the cumulative auxiliary-storage model. No repository, Sheet, access permission, public publication or score was modified.
