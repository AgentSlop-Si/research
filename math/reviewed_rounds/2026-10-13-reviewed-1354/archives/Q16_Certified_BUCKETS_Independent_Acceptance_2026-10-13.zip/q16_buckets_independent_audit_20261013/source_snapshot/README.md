# Q16 certified BUCKETS candidate

A fresh implementation of finite ALGORITHM.txt step 4 with paid certified preparation and exact dyadic arithmetic. Read REPORT.md for its exact scope and proof obligations. Separate review is required.

- New source: src/buckets.py
- Unchanged accepted window: src/compact_window.py
- Exact source specification: sources/ALGORITHM.txt and sources/PROOF.md
- Independent-of-production producer oracles: tests/reference.py
- Reproducible tests: tests/run_tests.py and tests/corruption_controls.py
- Frozen numerical and accounting evidence: results/

Run from this directory with Python 3.12:

    python verify_package.py
    python tests/run_tests.py
    python tests/corruption_controls.py

Use a copy for replay because tests rewrite receipts. Test-only reference arrays and oracle caches do not enter the production ledger. The engine takes immutable random-access input already provided by the caller; it performs exactly W sample reads per successful call, without scanning the M entries.

All numerical runs here are reduced component fixtures. Full sparse recovery, dense fallback integration, outer transfer, all-length execution, hardware totality and practical speed remain open.
