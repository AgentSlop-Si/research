Q16 BUCKETS independent acceptance

Read REVIEW.md for the bounded verdict and VERDICT.json for its machine-readable scope.
This accepts the frozen BUCKETS numerical component and conservative source-level resource model.
It does not accept a complete sparse-recovery or all-length executable.

Independent tests and negative source mutants are under tests; all receipts are under results.
The exact frozen source and specification are under source_snapshot.
Run python3 verify_review.py before replaying the three audit programs listed in REVIEW.md.
