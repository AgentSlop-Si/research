# Q16 BUCKETS independent component review

13 October 2026

## Verdict and exact scope

ACCEPT the frozen BUCKETS numerical component and its conservative finite-arithmetic source-level work and cumulative auxiliary-storage account. There are no required repairs for this bounded acceptance.

The reviewed source is `source_snapshot/buckets.py`, SHA256 `df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1`. Its compact-window dependency is unchanged from accepted revision 2: SHA256 `e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59`. The accepted specification is `source_snapshot/ALGORITHM.txt`, step 4, with `source_snapshot/PROOF.md`, sections 2, 3 and 6. The producer's explanatory report is copied as `source_snapshot/REPORT.md`; it is evidence reviewed, not independent verification.

This acceptance covers paid window, root and scale preparation; affine sample addressing; tap folding; an exact-dyadic negative-sign unnormalized radix-two FFT; scale multiplication; final nearest-even rounding; finite parameter/source-width charges; and the stated mathematical-machine resource model. It does not certify the complete sparse recovery pipeline, random-bit generation, ranking, modular-inverse implementation, frequency enumeration, phase estimation, medians, dense fallback, outer transfer, all-length execution, Python host totality, or practical speed. The existing read-only random-access source is caller-owned input storage.

The producer's source was copied after the numerical-payload cleanup and independently hash-checked. The earlier source hash `8d15d05b792a483253059b0ce3aaf80102926bcb942206154d304cd56c1c73c2` is superseded and is not the acceptance pin. The final numerical return contains only B signed Cartesian numerator pairs and their common exponent P. Polynomial-width error numerators and accounting records remain separate internal diagnostics.

## Independent evidence

The reviewer wrote and ran three new audit programs. No producer test or reference program was imported or executed to establish this verdict. Only the newly authorized production component, its accepted dependency, and reviewer-authored source mutants were executed. No historical unapproved executable was run.

The independent audit recorded 9,062 assertions, all passing. It covered four reduced fixtures: (M,B,r,P) equal to (64,4,1,8), (128,4,2,19), (256,8,1,32), and (512,16,1,24). Sixteen fixture calls checked 128 numerical bucket outputs against an independent recursive exact-Fraction FFT. Ninety-six nonzero-source output comparisons used independent rational intervals for the true ideal buckets. There were also independent enclosures for 570 taps and 16 complex roots, four reciprocal-square-root checks, 3,473 signed nearest-even cases, and 527 integer-square-root cases.

All 2,048 odd affine pairs at M=64 matched the independent exact path. Their source-query, sample-alignment, folding, FFT-stage, butterfly, final-rounding, and output counts also matched fixed identities. The same audit independently verified 2,048 modular-inverse preimages under the exact half-open hash. This validates the mathematical interface that a later decoder must implement; it does not certify an inverse routine in this component, because none is present.

A separate mutation program detected ten fresh production-source changes: reversed root sign, reversed affine shift, shifted fold bin, missing bit reversal, wrong root stride, incorrect denominator alignment, wrong scale factor, omitted source-query charge, omitted parameter charge, and root preparation moved onto an unreported ledger. These mutants are retained only as clearly labeled negative controls under `tests/mutants/`.

The same program independently reconstructed 216,781 primitive records and 262,525 total counted events/slots from a traced constructor plus three calls. Primitive arithmetic labels, all produced-integer storage, maximum observed widths, parameter input widths, allocation slots, and both report envelopes agreed exactly. Thirty-six exact worst-case error-expression checks used b=m and W=M-1 for m=2 through 32 and m=40,46,64,96,128. These supplement the universal argument below.

The third program independently checked the complete spectral identity on all four buckets of an M=64 fixture. Correct positive shift phases produce intersecting rigorous intervals; deliberately negative shift phases produce disjoint intervals. The program includes the exact algebra establishing the identity, so interval agreement is corroboration rather than the proof.

## Affine signs and modular inverse boundary

Let omega=exp(2 pi i/M), z_i=M^(-1/2) sum_x v_x omega^(-ix), and G_k=M^(-1) sum_t w_t omega^(-kt). Substituting the inverse transform into the bucket definition gives

    b_j = M^(-1/2) sum_t w_t v_(sigma*t+tau) omega^(-jTt)
        = sum_i z_i omega^(tau*i) G_(jT-sigma*i).

The producer uses exactly `(sigma*t+tau) mod M` at lines 178–182 and folds by `t mod B` at lines 202–207. Because T=M/B, the B-point negative-sign transform has precisely omega^(-jTt) as its character. Negative t and wrapped shifts are handled by exact signed integer arithmetic and nonnegative modulo. No inverse sigma belongs in the sampling address.

For a later decoder, the exact hash is h_sigma(i)=floor(((sigma*i mod M)+T/2)/T) mod B. Its jth preimage consists of sigma^(-1) times the T residues jT-T/2 through jT+T/2-1. The reviewer computed inverses with an independently written extended Euclidean routine and compared every enumerated set with exhaustive evaluation of h_sigma. Each contained exactly T elements. The source component itself performs neither inversion nor decoding.

## Paid scalar preparation and exact data arithmetic

The constructor calls accepted `prepare_window` using its own cumulative ledger, then constructs a new certified Scalar for its B/2 roots. Even the Machin pi preparation is newly performed and charged. The real root expression is sin(pi(1/2+2j/B)) and the imaginary expression is sin(-2 pi j/B), giving exp(-2 pi i j/B). Endpoint distances are combined by an exact squared complex norm and tested against rho squared, with rho=2^-P. A Cartesian error of rho is not incorrectly substituted for a complex error of rho.

For Q=P+2, J=P+8, and K=J+2 bit_length(J+1)+16, the checked sine-width guard is sufficient for all P>=8. Since K+9<=4(J+1) in this range and 2^(K-J)>2^16(J+1)^2, the guard follows uniformly. Final coordinate error is bounded by rho/8+rho/512, well below rho/4, before combining both coordinates.

The scale routine forms floor(2^(2K)/M) and uses a bounded descending-bit integer square root. If a is that floor root, then a/2^K is the lower endpoint; it is exact when a^2 M=2^(2K), and otherwise (a+1)/2^K is the upper endpoint. This remains sound when the floor target is zero. The result is certified and rounded to Q bits. There is no floating trigonometry, externally supplied root table, tolerance-based refinement, callback, or hidden scalar oracle.

Each sampled Cartesian dyadic n/2^e is aligned exactly to the declared F-grid, with e and n recorded before range and magnitude checks. Folding uses denominator exponent F+P. Each of b=log2 B FFT stages increases the exponent by exactly Q. Scaling increases it once more by Q, so the final unrounded exponent is F+P+(b+1)Q. All data products and sums are integer-exact. The only numerical output roundings are the 2B signed nearest-even operations at lines 246–248. The root and scale construction roundings are separate preparation work.

The independently written ideal oracle uses exact rational Machin bounds, outward-rounded interval Taylor recurrence, an elementary convolution for the box-power distribution, and direct Fourier sums for C and D_H. It does not use the producer's Scalar, coefficient generator, sine-ratio evaluation, FFT, or rounding functions. Its dense root table belongs solely to the reviewer test oracle and is not charged to, or used by, the production algorithm.

## Error constants on every permitted affine pair

The accepted window gives sum_t |w_t|<=M^2, and the Cartesian source bound gives |v_x|<=sqrt(2). Set A=2M^2 and D=2W rho. The ideal raw supported input has l1 norm at most A; replacing the W taps changes it by at most D. Folding cannot increase this l1 norm.

In a radix-two FFT, each input contributes to an output through one path containing at most b roots. Replacing unit roots with approximations of complex error at most rho changes a path coefficient by at most (1+rho)^b-1. Thus the unscaled error is at most (A+D)(1+rho)^b-A. The exact scale is at most one and its approximation has error at most rho. Combining the scale error with a final complex rounding error at most rho proves

    E = (A+D)(1+rho)^(b+1) - A + rho.

The constructor's integer formula at lines 143–153 represents exactly this dyadic E with exponent P(b+2). It also compares E with the accepted simplified bound rather than assuming that an arbitrary reduced fixture has theorem precision. The generic formula remains valid when a reduced fixture does not have b*rho small.

For accepted E(beta) precision P=16m+16 and b<=m, b*rho<=1/2. The elementary series bound (1+rho)^b<=1/(1-b*rho)<=1+2b*rho applies. Using D<=2M rho, A+D<=4M^2, and 1+rho<2 gives the deliberately loose estimate E<=(16b+7)M^2 rho, hence E<=24(m+1)M^2 rho. These inequalities hold for every allowed source and affine pair, with no recovery-success event, spectral gap, norm estimate, or probabilistic conditioning.

The ideal scaled output has magnitude at most A. Therefore A+E bounds the actual complex output magnitude and each Cartesian component. The producer's exact amplitude assertions cannot fire on the proved valid mathematical domain. They are invariant assertions, not an abort probability or a precision cap.

## Input widths and resource model

All M,B,r,P parameter encodings are charged by the accepted validator. Beta-bearing calls additionally charge both normalized Fraction fields, before the calculations that use them. Every run separately charges sigma, tau and F; the supplied sample numerators and exponents are recorded before numerical validation. Wide malformed samples therefore do not disappear from the ledger. Tests rejected an 8,193-bit malformed numerator with its width visible and checked wide beta fields up to 8,195 bits. Repeated validation is paid each time.

For arbitrary standalone F, shifts and aligned numerators can have width proportional to the value F, not merely log F. The report retains this dependence. The reviewer checked F=0,8,127,1024 and found corresponding growth in observed width and finite cost. The accepted theorem regime additionally promises F=O_d(m). Fixed-beta asymptotics may absorb beta-field width h into a beta-dependent constant; a uniform arbitrary-beta account must retain h.

Per successful run, the exact identities are W source reads, 2W alignments, W folds, Bb reversal-bit iterations, B reversal-index events, Bb/2 butterflies, b stages, 2B final roundings and B output pairs. All supported taps are read, even when the rounded tap is zero. There is no M-length initialized working array and no source scan. A deliberately invalid entry outside the W sampled positions confirms the absence of eager source validation; this is a scope check, not acceptance of globally malformed E(beta) inputs.

The bit-work model charges each recorded primitive 16(2+sum of operand and result widths)^2. If C is the total counted event/slot inventory plus 256 and L is maximum observed integer width plus bit_length(C)+2, the bookkeeping envelope is 512 C L^2 and the cumulative storage envelope adds 512 C L bits to all produced-integer bits. Inspection of the bounded loops and fixed-arity actions supports this inherited conservative model. The trace reconstruction checks arithmetic labels and recomputes its complete numerical account without trusting the reported totals.

The retained compact coefficients and certificates, B/2 roots, bins, return tuples, and conservative cumulative allocation are included. Caller-owned existing source storage is excluded as input storage, exactly as in the specification. A different physical source with additional I/O costs must pay those costs separately. The component does not accept an arbitrary source callback whose runtime could be hidden inside a read.

Accepted inputs give polynomial intermediate widths in m and h; the dominant new exact-data width is O(F+P(b+2)+m), with the dependency's already accepted scalar and coefficient width bounds retained. Final bucket numerators have O(P+2m+b) bits, which is O_d(m) in the accepted regime. Constructor plus one run has O((B+T) poly_d(m+h)) bit work and cumulative auxiliary storage, and O_(beta,d)((B+T) poly(m)) for fixed beta. Repeated calls retain one paid preparation and add each complete call. These are source-level mathematical-machine bounds, not Python instruction counts, peak resident memory measurements, or guarantees against host memory exhaustion.

## Fixture boundary and remaining work

No numerical run used valid full theorem parameters. All executable numeric cases are explicitly reduced component fixtures. Zero-vector fixtures need not satisfy the full front-end norm promise; the BUCKETS error argument itself only requires the componentwise magnitude bound.

The first beta=1/4 accepted sparse crossover was separately checked at m=46: M=70,368,744,177,664, B=34,359,738,368, r=93, P=752, W=51,127,290,691,399. Only parameter computation and validation were run. No giant coefficient array, root table, source array, or numerical bucket computation was allocated for that case. Outer guards remain caller obligations.

The next integration work is the finite randomized location and estimation machinery with exact ranking, inverse/hash enumeration, phase preparation, medians, and every-path combined accounting. This review gives no acceptance to those unimplemented components or the dense/all-length dispatch. No repository, Sheet, public publication, permission, or research score was changed.

## Reproduction

Run `python3 verify_review.py`, then `python3 tests/independent_audit.py`, `python3 tests/mutation_and_accounting.py`, and `python3 tests/spectral_identity.py` from this packet's root or by absolute paths. Only the Python standard library is required. The test programs overwrite their result receipts with fresh timings; preserve the original archive if exact sealed receipt bytes matter. The source snapshot and producer files are not edited by these tests.

Detailed receipts are `results/independent_results.json`, `results/assertions.json`, `results/mutations_and_accounting.json`, `results/spectral_identity.json`, `results/static_source_audit.json`, and `results/producer_package_integrity.json`. The machine-readable verdict is `VERDICT.json`.
