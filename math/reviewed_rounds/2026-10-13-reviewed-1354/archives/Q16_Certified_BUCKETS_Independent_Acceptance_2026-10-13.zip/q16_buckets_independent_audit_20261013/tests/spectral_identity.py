"""Independent interval check of Fourier signs and affine frequency identity."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent))
from independent_audit import I,F,S,ROOT,root,ideal_taps,ideal_buckets,mk_source,WindowSpec,cmul,cadd,isqrt
M=64;B=4;T=M//B;sigma=3;tau=5;source=mk_source(M,9,'irregular')
low=isqrt(S*S//M);scale=I(low,low if low*low*M==S*S else low+1)
z=[]
for i in range(M):
    a=(I(0),I(0))
    for t in range(M):
        v=tuple(I.rat(F(n,1<<e)) for n,e in source.values[t])
        a=cadd(a,cmul(v,root(-i*t,M)))
    z.append((a[0]*scale,a[1]*scale))
_,taps=ideal_taps(M,B,1)
G=[]
for j in range(M):
    value=sum((w*root(-j*t,M)[0] for t,w in taps),I(0))/M
    G.append(value)
truth=ideal_buckets(WindowSpec(M,B,1,8),source,sigma,tau)
checks=[]
def overlap(a,b):return max(a.lo,b.lo)<=min(a.hi,b.hi)
for j in range(B):
    recovered=(I(0),I(0));wrong=(I(0),I(0))
    for i in range(M):
        response=G[(j*T-sigma*i)%M]
        a=cmul(z[i],root(tau*i,M));w=cmul(z[i],root(-tau*i,M))
        recovered=cadd(recovered,(a[0]*response,a[1]*response))
        wrong=cadd(wrong,(w[0]*response,w[1]*response))
    assert all(overlap(x,y) for x,y in zip(truth[j],recovered))
    assert any(not overlap(x,y) for x,y in zip(truth[j],wrong))
    checks.append(dict(bucket=j,correct_positive_phase_overlap=True,negative_phase_disjoint=True))
result={'all_passed':True,'M':M,'B':B,'sigma':sigma,'tau':tau,'independent_spectral_identity_checks':checks,
'identity':'b_j = sum_i z_i exp(+2 pi i tau i/M) G_(jT-sigma i)',
'proof':'Substitute v_x=M^(-1/2) sum_i z_i exp(+2 pi i xi/M) into b_j=M^(-1/2) sum_t w_t v_(sigma t+tau) exp(-2 pi i jTt/M), and use G_k=M^(-1) sum_t w_t exp(-2 pi i kt/M).'}
(ROOT/'results/spectral_identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
