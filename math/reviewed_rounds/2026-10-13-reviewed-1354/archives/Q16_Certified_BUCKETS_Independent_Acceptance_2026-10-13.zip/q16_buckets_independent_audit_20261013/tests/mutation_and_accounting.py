"""Fresh source mutations and independent trace-account reconciliation."""
from pathlib import Path
from fractions import Fraction
import importlib.util,sys,json,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
from independent_audit import prod,Ledger,WindowSpec,mk_source,exact_oracle,counts,ROOT
from collections import Counter
class AuditLedger(Ledger):
    def __init__(self):
        super().__init__();self.recomputed_operations=Counter();self.work=0;self.produced=0;self.maximum=1;self.alloc=0;self.fields=0;self.fieldmax=1;self.records=0
    def record(self,kind,inputs,output):
        bitlengths=[len(bin(abs(v)))-2 if v else 1 for v in list(inputs)+[output]]
        self.recomputed_operations[kind]+=1;self.records+=1
        self.work+=16*(2+sum(bitlengths))**2;self.produced+=bitlengths[-1]+1
        self.maximum=max([self.maximum]+bitlengths)
        if kind=='parameter_input':self.fields+=bitlengths[-1];self.fieldmax=max(self.fieldmax,bitlengths[-1])
        # Check that primitive labels actually match their mathematical operation.
        if kind=='add':assert output==inputs[0]+inputs[1]
        if kind=='subtract':assert output==inputs[0]-inputs[1]
        if kind=='multiply':assert output==inputs[0]*inputs[1]
        if kind=='floor_divide':assert output==inputs[0]//inputs[1]
        if kind=='modulo':assert output==inputs[0]%inputs[1]
        if kind=='binary_power':assert output==2**inputs[0]
        return super().record(kind,inputs,output)
    def allocate(self,n):
        self.recomputed_operations['allocated_slots']+=n;self.alloc+=n;self.produced+=n
        return super().allocate(n)
    def event(self,name,count=1):
        self.recomputed_operations[name]+=count
        return super().event(name,count)
    def audit(self):
        assert self.recomputed_operations==self.operations
        assert self.work==self.arithmetic_bit_work_upper
        assert self.produced==self.cumulative_integer_bits
        assert self.maximum==self.max_integer_bits
        assert self.alloc==self.allocated_slots
        assert self.fields==self.parameter_input_bits
        assert self.fieldmax==self.max_parameter_bits
        E=sum(self.recomputed_operations.values())+256
        width=self.maximum+E.bit_length()+2
        r=self.report()
        assert r['total_bit_work_upper']==self.work+512*E*width**2
        assert r['cumulative_storage_upper_bits']==self.produced+512*E*width
        return {'primitive_records':self.records,'events':E-256,'report':r}

src=(ROOT/'source_snapshot/buckets.py').read_text()
spec=WindowSpec(256,8,1,8)
base=prod.BucketEngine(spec);source=mk_source(256,9,'irregular')
expected=exact_oracle(base,source,3,17)
mutations=[
 ('root_sign','imag_interval = scalar.sin_pi(L.mul(-2, j), B)','imag_interval = scalar.sin_pi(L.mul(2, j), B)','numeric'),
 ('affine_shift','L.add(L.mul(sigma, t), tau)','L.sub(L.mul(sigma, t), tau)','numeric'),
 ('fold_offset','slot = L.mod(t, B)','slot = L.mod(t + 1, B)','numeric'),
 ('bit_reversal','if i < reverse:','if False and i < reverse:','numeric'),
 ('root_stride','self._roots[L.mul(j, stride)]','self._roots[L.mul(j, 1)]','numeric'),
 ('denominator_alignment','root_unit = L.shift(self._Q)','root_unit = L.shift(self._Q + 1)','numeric'),
 ('scale_factor','L.mul(real, self._scale.numerator), round_den','L.mul(real, self._scale.numerator + (1 << self._scale.bits)), round_den','numeric'),
 ('no_source_query_charge',"L.event('source_query')","pass # omitted source charge",'query'),
 ('no_parameter_charge','L.parameter(value)','pass # omitted parameter charge','parameter'),
 ('free_root_preparation','prepare_roots(spec.B, spec.P, L)','prepare_roots(spec.B, spec.P, Ledger())','prep'),
]
results=[]
mutdir=ROOT/'tests/mutants';mutdir.mkdir(exist_ok=True)
for name,old,new,kind in mutations:
    assert src.count(old)==1,(name,src.count(old))
    path=mutdir/(name+'.py');path.write_text(src.replace(old,new))
    name_mod='independent_mutant_'+name;specmod=importlib.util.spec_from_file_location(name_mod,path)
    mod=importlib.util.module_from_spec(specmod);sys.modules[name_mod]=mod;specmod.loader.exec_module(mod)
    e=mod.BucketEngine(spec);s=mod.DyadicSource(source.values,9);before=counts(e.ledger)
    try:
        out=e.run(s,3,17)
        if kind=='numeric':detected=out.numerators!=expected
        elif kind=='query':detected=e.ledger.operations['source_query']-before['source_query']!=spec.W
        elif kind=='parameter':detected=e.ledger.operations['parameter_input']-before['parameter_input']!=7
        elif kind=='prep':detected=e.ledger.operations['fft_root_preparation']!=spec.B//2
        reason='independent '+kind+' mismatch'
    except ArithmeticError as ex:
        detected=True;reason='invariant guard: '+str(ex)
    assert detected,name
    results.append({'mutation':name,'detected':detected,'reason':reason,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
trace=AuditLedger();engine=prod.BucketEngine(WindowSpec(128,4,2,8),trace)
for mode,f,sigma,tau in [('zero',0,1,0),('axes',7,127,127),('irregular',127,3,29)]:
    source=mk_source(128,f,mode);v=engine.run(source,sigma,tau)
    assert v.numerators==exact_oracle(engine,source,sigma,tau)
account=trace.audit()
# Exact worst-case generic E checks supplement the algebraic theorem reduction.
errorchecks=[]
for m in list(range(2,33))+[40,46,64,96,128]:
    M=1<<m;b=m;P=16*m+16;rho=Fraction(1,1<<P);W=M-1;A=2*M*M
    E=(A+2*W*rho)*(1+rho)**(b+1)-A+rho
    target=24*(m+1)*M*M*rho
    assert E<=target
    errorchecks.append({'m':m,'worst_b':b,'worst_W':W,'accepted_bound':True})
result={'all_passed':True,'mutants_detected':len(results),'mutations':results,'accounting':account,'accepted_error_exact_checks':errorchecks,
        'production_source_unchanged':hashlib.sha256((ROOT/'source_snapshot/buckets.py').read_bytes()).hexdigest()=='df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1'}
(ROOT/'results/mutations_and_accounting.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
