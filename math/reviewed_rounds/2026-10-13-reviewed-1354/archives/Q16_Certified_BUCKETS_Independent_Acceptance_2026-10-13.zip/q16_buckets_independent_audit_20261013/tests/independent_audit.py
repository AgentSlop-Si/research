"""Fresh independent BUCKETS audit. Does not import author tests or reference code."""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
from math import isqrt, factorial
from collections import Counter
import hashlib, importlib.util, json, sys, time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source_snapshot'))
import buckets as prod
from compact_window import WindowSpec, Ledger, theorem_spec

checks=[]; details=[]
def check(name,condition,info=None):
    checks.append(dict(name=name,passed=bool(condition),info=info))
    if not condition: raise AssertionError(name)
def rnd(x):
    q,r=divmod(x.numerator,x.denominator)
    return q + int(2*r>x.denominator or (2*r==x.denominator and q%2))
def cadd(a,b): return (a[0]+b[0],a[1]+b[1])
def csub(a,b): return (a[0]-b[0],a[1]-b[1])
def cmul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def exact_fft(a,roots,step=1):
    if len(a)==1: return a
    e=exact_fft(a[::2],roots,step*2);o=exact_fft(a[1::2],roots,step*2)
    p=[cmul(v,roots[j*step]) for j,v in enumerate(o)]
    return [cadd(x,y) for x,y in zip(e,p)]+[csub(x,y) for x,y in zip(e,p)]
def exact_oracle(engine,source,sigma,tau,wrong=None):
    spec=engine._spec; out=[(F(0),F(0)) for _ in range(spec.B)]
    for tap in engine._window.taps:
        index=(sigma*tap.t+tau)%spec.M
        if wrong=='affine_sign': index=(sigma*tap.t-tau)%spec.M
        a=tuple(F(n,1<<e) for n,e in source.values[index]); w=F(tap.numerator,1<<tap.bits)
        slot=tap.t%spec.B
        out[slot]=cadd(out[slot],(w*a[0],w*a[1]))
    roots=[(F(r.real.numerator,1<<r.real.bits),F(r.imag.numerator,1<<r.imag.bits)) for r in engine._roots]
    if wrong=='fft_sign': roots=[(a,-b) for a,b in roots]
    out=exact_fft(out,roots)
    scale=F(engine._scale.numerator,1<<engine._scale.bits)
    if wrong=='omit_scale': scale=F(1)
    return tuple((rnd(a*scale*(1<<spec.P)),rnd(b*scale*(1<<spec.P))) for a,b in out)

# The numerical ideal oracle uses independent outward-rounded interval arithmetic,
# rational Machin series, interval Taylor evaluation (no point-midpoint reuse),
# elementary convolution, and direct Fourier sums. Its dense table is test-only.
K=176; S=1<<K
class I:
    def __init__(self,lo,hi=None): self.lo=int(lo);self.hi=int(lo if hi is None else hi)
    @staticmethod
    def rat(q):
        q=F(q); return I(q.numerator*S//q.denominator,-((-q.numerator*S)//q.denominator))
    def __add__(a,b):
        if not isinstance(b,I): b=I.rat(b)
        return I(a.lo+b.lo,a.hi+b.hi)
    __radd__=__add__
    def __neg__(a): return I(-a.hi,-a.lo)
    def __sub__(a,b): return a+-b if isinstance(b,I) else a+(-F(b))
    def __mul__(a,b):
        if not isinstance(b,I): b=I.rat(b)
        z=[x*y for x in (a.lo,a.hi) for y in (b.lo,b.hi)]
        return I(min(z)//S,-((-max(z))//S))
    __rmul__=__mul__
    def __truediv__(a,b):
        if not isinstance(b,I): b=I.rat(b)
        assert b.lo>0 or b.hi<0
        q=[F(x*S,y) for x in (a.lo,a.hi) for y in (b.lo,b.hi)]
        x,y=min(q),max(q)
        return I(x.numerator//x.denominator,-((-y.numerator)//y.denominator))
    def contains(a,q): return a.lo*F(1,S)<=q<=a.hi*F(1,S)
    def far(a,q): return max(abs(F(a.lo,S)-q),abs(F(a.hi,S)-q))

def atan_interval(q,n=100):
    s=sum((F((-1)**j,(2*j+1)*q**(2*j+1)) for j in range(n)),F(0))
    t=F(1,(2*n+1)*q**(2*n+1))
    lo,hi=(s,s+t) if n%2==0 else (s-t,s)
    return I(I.rat(lo).lo,I.rat(hi).hi)
PI=16*atan_interval(5)-4*atan_interval(239)
@lru_cache(None)
def sine(p,q):
    p%=2*q
    sign=1
    if p>q: p=2*q-p;sign=-1
    if 2*p>q:p=q-p
    if p==0:return I(0)
    if 2*p==q:return I(sign*S)
    x=PI*F(p,q); square=x*x; term=x; value=x
    n=80
    for j in range(1,n):
        term=term*square/F(2*j*(2*j+1))
        value=value+term if j%2==0 else value-term
    # Taylor degree 159, |x|<2; exact rational remainder.
    tail=F(2**(2*n+1),factorial(2*n+1))
    units=-((-tail.numerator*S)//tail.denominator)
    value=I(value.lo-units,value.hi+units)
    return value if sign==1 else -value
@lru_cache(None)
def root(j,M): return (sine(M+4*j,2*M),sine(2*j,M))
@lru_cache(None)
def ideal_taps(M,B,r):
    ell=8*B; old=[1]
    for _ in range(2*r):
        new=[0]*(len(old)+ell-1)
        for i,a in enumerate(old):
            for j in range(ell):new[i+j]+=a
        old=new
    radius=r*(ell-1);den=ell**(2*r)
    mass=[F(x,den) for x in old]
    g=M//B//4; H=3*g
    C=I.rat(1)
    for j in range(1,g+1):
        phi=sum((root(j*t,M)[0]*f for t,f in zip(range(-radius,radius+1),mass)),I(0))
        C=C+2*phi
    assert C.lo>0
    taps=[]
    for t,f in zip(range(-radius,radius+1),mass):
        D=I.rat(1)+2*sum((root(u*t,M)[0] for u in range(1,H+1)),I(0))
        taps.append((t,(M*f)*D/C))
    return C,taps

def ideal_buckets(spec,source,sigma,tau):
    C,taps=ideal_taps(spec.M,spec.B,spec.r)
    low=isqrt((S*S)//spec.M)
    scale=I(low,low if low*low*spec.M==S*S else low+1)
    out=[]
    for j in range(spec.B):
        z=(I(0),I(0))
        for t,w in taps:
            a=tuple(I.rat(F(n,1<<e)) for n,e in source.values[(sigma*t+tau)%spec.M])
            rr,ri=root(-j*t,spec.B)
            z=cadd(z,cmul((w*a[0],w*a[1]),(rr,ri)))
        out.append((z[0]*scale,z[1]*scale))
    return out

def mk_source(M,Fmax,mode):
    a=[]
    for t in range(M):
        if mode=='zero': a.append(((0,0),(0,Fmax)));continue
        if mode=='axes': a.append((((t%3)-1,0),(((t//3)%3)-1,0)));continue
        er=(3*t+1)%(Fmax+1);ei=(5*t+2)%(Fmax+1)
        nr=((t*t+7*t+13)%(2*(1<<er)+1))-(1<<er)
        ni=((11*t*t+9*t+3)%(2*(1<<ei)+1))-(1<<ei)
        a.append(((nr,er),(ni,ei)))
    return prod.DyadicSource(tuple(a),Fmax)

def counts(L):return Counter(L.operations)
def resource_check(L):
    r=L.report();e=sum(r['operations'].values())+256
    width=r['max_observed_integer_bits']+e.bit_length()+2
    return (r['bookkeeping_bit_work_upper']==512*e*width*width and
            r['total_bit_work_upper']==r['arithmetic_bit_work_upper']+512*e*width*width and
            r['cumulative_storage_upper_bits']==L.cumulative_integer_bits+512*e*width)
def run_counts(engine,before,source,sigma,tau):
    s=engine._spec;b=s.B.bit_length()-1;d=counts(engine.ledger)-before
    expected={'source_query':s.W,'sample_alignment':2*s.W,'tap_fold':s.W,
        'bit_reverse_bit':s.B*b,'bit_reverse_index':s.B,'fft_butterfly':s.B*b//2,
        'fft_stage':b,'bucket_output':s.B,'nearest_even':2*s.B,
        'window_validation_call':1,'parameter_input':7+(2 if s.beta is not None else 0)}
    return all(d[k]==v for k,v in expected.items()) and d['fft_root_preparation']==0 and d['scale_preparation']==0

def rejects(fn):
    try:fn()
    except (ValueError,TypeError,ArithmeticError):return True
    return False

def extended_inverse(a,M):
    t,nt,r,nr=0,1,M,a
    while nr:
        q=r//nr;t,nt=nt,t-q*nt;r,nr=nr,r-q*nr
    assert r==1
    return t%M

def main():
    start=time.monotonic()
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'source_snapshot').glob('*.py')}
    check('production source pin',hashes['buckets.py']=='df3937a632217a8a1342545b803169ff8da062117b3837796386509b64f650d1')
    check('accepted unchanged dependency pin',hashes['compact_window.py']=='e29741e71c276c156d708f1d9dce6d60ff9d3d2c34a6045b03630c46506dac59')
    # Independent signed ties and sqrt boundary checks.
    for d in range(1,24):
        for n in range(-75,76):check('nearest tie oracle',prod.nearest_even(n,d,Ledger())==rnd(F(n,d)))
    for n in list(range(512))+[2**k+v for k in [16,31,64,127,257] for v in [-1,0,1]]:
        check('sqrt exact bracket',prod.finite_isqrt(n,Ledger())==isqrt(n))
    fixture_specs=[(64,4,1,8),(128,4,2,19),(256,8,1,32),(512,16,1,24)]
    engines=[]; interval_outputs=0;exact_outputs=0;tap_enclosures=0;root_enclosures=0
    for M,B,r,P in fixture_specs:
        spec=WindowSpec(M,B,r,P);engine=prod.BucketEngine(spec);engines.append(engine)
        check('fixture separation',spec.beta is None and spec.origin=='reduced_component_fixture')
        check('paid preparation',engine.ledger.operations['fft_root_preparation']==B//2 and engine.ledger.operations['scale_preparation']==1 and engine.ledger.operations['bucket_engine_constructor']==1)
        C,taps=ideal_taps(M,B,r)
        for own,tap in zip(taps,engine._window.taps):
            check('tap interval independent convolution DFT',own[1].far(F(tap.numerator,1<<P))<=F(1,1<<P));tap_enclosures+=1
        for j,a in enumerate(engine._roots):
            real,imag=root(-j,B)
            check('root independent interval complex error',real.far(F(a.real.numerator,1<<a.real.bits))**2+imag.far(F(a.imag.numerator,1<<a.imag.bits))**2<=F(1,1<<(2*P)));root_enclosures+=1
        scale=engine._scale;val=F(scale.numerator,1<<scale.bits);lo=F(isqrt((S*S)//M),S);hi=lo+F(1,S)
        check('scale independent integer bracket',max(abs(val-lo),abs(val-hi))<=F(1,1<<P))
        R=F(1,1<<P);A=2*M*M;D=2*spec.W*R;b=B.bit_length()-1
        E=(A+D)*(1+R)**(b+1)-A+R
        check('general exact error expression',E==F(engine._error_numerator,1<<engine._error_bits))
        check('accepted error indicator exact',engine._accepted_error==(E<=24*(spec.m+1)*M*M*R))
        for mode,Fmax,sigma,tau in [('zero',0,1,0),('axes',3,M-1,M-1),('irregular',7,3,5),('irregular',23,5,M//2)]:
            source=mk_source(M,Fmax,mode);before=counts(engine.ledger);v=engine.run(source,sigma,tau)
            check('exact recursive FFT bit equality',v.numerators==exact_oracle(engine,source,sigma,tau));exact_outputs+=B
            check('every-path operation identities',run_counts(engine,before,source,sigma,tau))
            check('resource report recomputation',resource_check(engine.ledger))
            check('bounded numerical payload',set(v.__dict__)=={'numerators','bits'} and len(v.numerators)==B)
            if mode!='zero':
                ideal=ideal_buckets(spec,source,sigma,tau)
                for (a,bv),pair in zip(ideal,v.numerators):
                    actual=(F(pair[0],1<<P),F(pair[1],1<<P))
                    check('true ideal forward interval bound',a.far(actual[0])**2+bv.far(actual[1])**2<=E**2);interval_outputs+=1
        details.append(dict(M=M,B=B,r=r,P=P,W=spec.W,fixture=True,ledger=engine.ledger.report()))
        print('FIXTURE',M,B,r,P,'passed',flush=True)
    # Exhaustive affine maps with a second recursive FFT, and exact half-open decoding.
    engine=engines[0];M=64;source=mk_source(M,9,'irregular');maps=0;inverse_preimages=0
    for sigma in range(1,M,2):
        inverse=extended_inverse(sigma,M)
        check('modular inverse identity',sigma*inverse%M==1)
        T=M//engine._spec.B
        for j in range(engine._spec.B):
            images={(inverse*a)%M for a in range(j*T-T//2,j*T+T//2)}
            truth={i for i in range(M) if (((sigma*i)%M+T//2)//T)%engine._spec.B==j}
            check('exact half-open hash inverse enumeration',images==truth and len(images)==T);inverse_preimages+=len(images)
        for tau in range(M):
            before=counts(engine.ledger);v=engine.run(source,sigma,tau)
            check('exhaustive affine exact result',v.numerators==exact_oracle(engine,source,sigma,tau));maps+=1
            check('exhaustive affine path counts',run_counts(engine,before,source,sigma,tau))
    print('AFFINE',maps,'passed',flush=True)
    # Source-width dependence and valid-domain scope.
    widths=[]
    for f in [0,8,127,1024]:
        e=prod.BucketEngine(WindowSpec(64,4,1,8));s=mk_source(64,f,'axes');before=e.ledger.parameter_input_bits
        e.run(s,1,0);record=e.ledger.report()
        check('input encoding charge',record['parameter_input_bits']-before==sum(max(1,x.bit_length()) for x in [64,4,1,8,1,0,f]))
        check('fractional source exponent growth observed',record['max_observed_integer_bits']>=f+8)
        widths.append(dict(F=f,ledger=record))
    check('source width increases finite cost',widths[-1]['ledger']['total_bit_work_upper']>widths[0]['ledger']['total_bit_work_upper'])
    e=engines[0];s=source
    for sig,tau in [(0,0),(2,0),(64,0),(-1,0),(True,0),(1,-1),(1,64),(1,False)]:
        check('malformed affine rejected',rejects(lambda:e.run(s,sig,tau)))
    for sourcebad in [lambda i:0,prod.DyadicSource(list(s.values),9),prod.DyadicSource(s.values[:-1],9),prod.DyadicSource(s.values,-1),prod.DyadicSource(s.values,False)]:
        check('malformed source interface rejected',rejects(lambda:e.run(sourcebad,1,0)))
    for bad in [((2,0),(0,0)),((0,-1),(0,0)),((0,10),(0,0)),((True,0),(0,0)),((0,0),),([0,0],(0,0))]:
        badsrc=prod.DyadicSource(tuple(bad for _ in range(64)),9)
        check('queried malformed encoding rejected',rejects(lambda:e.run(badsrc,1,0)))
    huge=1<<8192
    badsrc=prod.DyadicSource(tuple(((huge,0),(0,0)) for _ in range(64)),9)
    check('wide malformed numerator rejected and charged',rejects(lambda:e.run(badsrc,1,0)) and e.ledger.max_integer_bits>=8193)
    # No eager validation: the one residue outside compact affine support is not read.
    covered={t.t%64 for t in e._window.taps};missing=next(x for x in range(64) if x not in covered)
    vals=list(s.values);vals[missing]=None
    no_scan=prod.DyadicSource(tuple(vals),9)
    before=counts(e.ledger);e.run(no_scan,1,0)
    check('only W queries no dense source validation',e.ledger.operations['source_query']-before['source_query']==63)
    # Valid theorem parameters only, not an impractical construction or execution.
    theta=F(1,4);L=Ledger();sp=theorem_spec(46,theta,L)
    check('valid theorem sparse parameters symbolic only',(sp.M,sp.B,sp.r,sp.P,sp.W)==(70368744177664,34359738368,93,752,51127290691399))
    check('valid theorem outer numeric guards',theta*46>=2 and sp.W<sp.M)
    for h in [8,1024,8192]:
        beta=F((1<<h)+1,(1<<(h+2))+3);LL=Ledger();bad=WindowSpec(64,4,1,8,beta)
        check('wide beta refusal charged',rejects(lambda:prod.BucketEngine(bad,LL)) and LL.max_parameter_bits>=h+3 and LL.parameter_input_bits>=2*h)
    # Wrong algorithm controls; a competent oracle must distinguish each.
    witness=mk_source(64,9,'irregular');truth=e.run(witness,3,5).numerators
    for mutation in ['affine_sign','fft_sign','omit_scale']:
        check('oracle rejects '+mutation,truth!=exact_oracle(e,witness,3,5,mutation))
    result=dict(overall='PASS',named_assertions=len(checks),all_passed=all(x['passed'] for x in checks),
        hashes=hashes,fixtures=details,interval_bucket_outputs=interval_outputs,exact_fixture_outputs=exact_outputs,
        independently_enclosed_taps=tap_enclosures,independently_enclosed_roots=root_enclosures,
        exhaustive_affine_calls=maps,modular_inverse_preimages=inverse_preimages,source_width_cases=widths,
        theorem_parameters_only=dict(m=46,M=sp.M,B=sp.B,r=sp.r,P=sp.P,W=sp.W,numeric_execution=False),
        elapsed_seconds=time.monotonic()-start)
    (ROOT/'results'/'independent_results.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'results'/'assertions.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['fixtures','source_width_cases']},indent=2),flush=True)
if __name__=='__main__':main()
