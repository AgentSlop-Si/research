from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for item in manifest['files']:
    data=(root/item['path']).read_bytes()
    assert len(data)==item['bytes'],item['path']
    assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
print('Verified',len(manifest['files']),'sealed review files')
