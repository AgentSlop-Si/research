#!/usr/bin/env python3
import sys,json,time,random,math,hashlib,platform
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from itertools import product
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'src'))
from q16 import *
from reference import reference_transform, reference_roots

counts=Counter(); cases=[]; failures=[]; rng=random.Random(160013)

def check(condition,group,message=''):
    counts[group]+=1
    if not condition: raise AssertionError(group+': '+message)

def expect_error(fn,group,exc=(ValueError,TypeError,NotImplementedError)):
    try: fn()
    except exc: check(True,group); return
    check(False,group,'expected error absent')

def param_reference(N,f):
    m=0
    while 2**m<4*N: m+=1
    def ceil_r(x):
        q=x.numerator//x.denominator
        return q if F(q)==x else q+1
    k=2**ceil_r(2*f.beta*m); B=2**ceil_r((F(1,2)+f.beta)*m)
    T=F(2**m,B); W=2*(2*m+1)*(8*B-1)+1; t=32*f.D*m+4
    sparse=(T.denominator==1 and B>=4 and T>=4 and B>=4096*k and W<2**m and t<2**m and f.beta*m>=2)
    return m,k,B,T,W,t,sparse

start=time.time()
# Exact parameter/dispatch boundaries including arbitrary, nondyadic N.
betas=[F(1,64),F(1,10),F(1,4),F(1,3),F(49,100),F(1,2)-F(1,2**60),F(1,4)+F(1,2**60)]
Ns=list(range(1,130))
for bit in range(1,130):
    for off in (-1,0,1):
        if 2**bit+off>=1: Ns.append(2**bit+off)
for beta in betas:
    f=Family(alpha=beta/2,beta=beta)
    for N in Ns:
        p=parameters(N,f); m,k,B,T,W,t,sparse=param_reference(N,f)
        check((p['m'],p['k'],p['B'],F(p['M'],p['B']),p['W'],p['t'],p['sparse'])==(m,k,B,T,W,t,sparse),'exact_dispatch')
        check(4*N<=p['M']<8*N,'embedding_length')
        check(p['accum_bits']==p['p']+p['P']+2*p['m']+6+ceil_log2(t),'word_precision_formula')
        if p['sparse']:
            check(p['symbolic']['support_cap_per_run']<=p['M']//4,'sparse_symbolic_support')
            check(p['q']<=p['B'],'sparse_symbolic_selection')
            check(p['M']//(8*p['s'])>=4,'sparse_kernel_regime')
# A deliberately large symbolic case, not a sparse execution.
p4096=parameters(2**4094,Family(beta=F(49,100),alpha=F(1,4)))
check(p4096['m']==4096 and p4096['sparse'],'large_symbolic_parameters')
# Family domain and strict gaps; c witness near integer boundaries.
for alpha,beta in [(F(1,4),F(1,4)),(F(1,3),F(1,4)),(F(0),F(1,4)),(F(1,4),F(1,2))]:
    expect_error(lambda:Family(alpha=alpha,beta=beta),'invalid_family')
expect_error(lambda:Family(beta=.25),'invalid_family')
expect_error(lambda:parameters(0),'invalid_input')
for c in [F(1,100),F(1)-F(1,100),F(1),F(1)+F(1,100),F(5,2),F(7)]:
    for N in [1,2,3,4,5,7,8,9,15,16,17,2**32+1]:
        p=parameters(N,Family(c=c)); r=p['r_amp']; J=p['J']; M=p['M']
        bound=F(2**J,M**r)
        check(r>c+1 and J==2*r-1,'amplification_witness')
        check(bound<=F(1,2*N**r),'amplification_exact_bound')
        check(bound**c.denominator<=F(1,N**c.numerator),'amplification_target')
        check(p['symbolic']['random_bits_amplified']==J*2*(4*p['m']+1)*(2*p['m']-1),'random_budget_formula')
# Exhaustive signed nearest-even, independently using candidate-distance search.
for d in range(1,65):
    for n in range(-257,258):
        x=F(n,d); q=x.__floor__()
        reference=min(range(q-1,q+3),key=lambda z:(abs(F(z)-x),z%2))
        check(nearest_even(n,d)==reference,'signed_nearest_even')
# Normalization power boundaries, near strict half, full magnitude/exponent fields.
f=Family(d=128)
for bits in range(1,257):
    for A in [2**bits-1,2**bits,2**bits+1]:
        p=parameters(3,f); l=Ledger(); s=normalize([(A,-A),(1,0),(0,0)],0,p,f,l)
        mx=F(A,1<<s.k0)
        check(F(1,2)<mx<=1,'normalization_boundary')
        check(s.lambda_exp==s.k0,'normalization_scale')
for N in range(1,66):
    p=parameters(N); l=Ledger(); nums=[(j+1,-j) for j in range(N)]; s=normalize(nums,1,p,Family(),l)
    expected={((j-(N-1)//2)%p['M']):pair for j,pair in enumerate(nums)}
    for residue in range(p['M']):
        check(s.source(residue)==expected.get(residue,(0,0)),'centered_source_adapter')
    check(l.events['input_fields_read']==2*N and l.events['normalization_max_passes']==1,'paid_acquisition')
    check(sum(a*a+b*b for a,b in nums)>F(1,4)*(1<<(2*s.k0)),'normalized_norm_strict')
# Input-domain rejection is separate from valid-domain theorem abort.
for nums,e in [([(1,0)],-1),([(1,0)],99),([(True,0)],0),([(0.5,0)],0),([(1<<100,0)],0)]:
    expect_error(lambda:execute(nums,e),'invalid_input')
# Independent combinatorial fixtures use reduced m; these are not full sparse runs.
for m in range(3,8):
    M=1<<m
    for b in range(1,m):
        B=1<<b; T=M//B
        for sigma in range(1,M,2):
            union=[]
            for j in range(B):
                fiber=inverse_fiber(j,sigma,M,B)
                brute=[i for i in range(M) if hash_index(i,sigma,M,B)==j]
                check(sorted(fiber)==brute and len(fiber)==T,'inverse_fiber_boundaries')
                union+=fiber
            check(sorted(union)==list(range(M)),'fiber_partition')
for vals in [ [(1,0)]*8,[(1,0),(0,1),(-1,0),(0,-1),(0,0)],[(3,4),(0,5),(-5,0),(4,-3)] ]:
    for q in range(len(vals)+1):
        out=select_bins(vals,q)
        check(out==sorted(range(len(vals)),key=lambda j:(-F(vals[j][0]**2+vals[j][1]**2),j))[:q],'magnitude_tie_priority')
expect_error(lambda:select_bins([(0,0)],2),'component_fail_closed')
for L in [1,3,5,9]:
    for _ in range(40):
        rounds=[rng.sample(range(32),8) for _ in range(L)]
        out=votes(rounds,32)
        check(len(out)<=16,'vote_all_tape_support')
        check(out==[i for i in range(32) if sum(i in row for row in rounds)>L//2],'vote_membership')
expect_error(lambda:votes([[1,1]],4),'component_fail_closed')
expect_error(lambda:cartesian_median([(0,0)]*2),'component_fail_closed')
# A concrete median loss witness: all three good complex values have norm <= 1,
# but coordinate median (3/4,3/4) has norm > 1; sqrt(2) loss cannot be dropped.
median_fixture=[(F(3,4),F(1,2)),(F(1,2),F(3,4)),(F(3,4),F(3,4))]
# Third sample may be bad; two good runs suffice for J=3.
check(all(a*a+b*b<=1 for a,b in median_fixture[:2]),'cartesian_median_loss')
v=cartesian_median(median_fixture)
check(v==(F(3,4),F(3,4)) and v[0]**2+v[1]**2>1 and v[0]**2+v[1]**2<=2,'cartesian_median_loss')
for m in range(2,6):
    seen=Counter()
    for bits in product((0,1),repeat=2*m-1):
        tape=BitTape(bits); pair=tape.affine_round(m); seen[pair]+=1
        check(tape.cursor==2*m-1,'fresh_bit_fixture_consumption')
    check(len(seen)==2**(2*m-1) and set(seen.values())=={1},'unbiased_affine_fixture')
expect_error(lambda:BitTape([0]).affine_round(3),'component_fail_closed')
# Zero and identity short paths must not prepare roots or consume bits.
for N in [1,2,3,16,32]:
    result=execute([(0,0)]*N,0)
    check(result['branch']=='zero' and all(v==(0,0) for v in result['values']),'zero_short_path')
    check(result['ledger']['events'].get('root_preparations',0)==0,'zero_no_roots_or_random')
for pair,e in [((1,-1),0),((15,16),4),((-16,0),0)]:
    result=execute([pair],e)
    check(result['values']==[pair] and result['exponent']==e,'identity_exact')
expect_error(lambda:execute([(1,0)]*33,0),'explicit_harness_limit')
# Certified dense path versus the separate rational oracle. Small arbitrary N.
aggregate=Counter(); max_bits=0; max_ratio_sq=F(0)
for N in list(range(2,18))+[19,23,29,31,32]:
    p=parameters(N); bound=1<<(2*p['m'])
    fixtures=[('impulse',[(1,0)]+[(0,0)]*(N-1),0),
              ('constant',[(1,-1)]*N,0),
              ('cancellation',[((-1)**j*(bound if j%3 else bound-1),(-1)**(j+1)*(bound//2+1)) for j in range(N)],2*p['m']),
              ('random',[(rng.randrange(-31,32),rng.randrange(-31,32)) for _ in range(N)],p['m']),
              ('near_half',[(2**(p['m']+1)+1,0)]+[(0,0)]*(N-1),p['m'])]
    for label,nums,e in fixtures:
        result=execute(nums,e); check(result['branch']=='certified_dense','dense_branch_executed')
        reference=reference_transform(nums,result['source_k0'],p['Q'])
        tolerance=F(7*N,1<<p['Q']); worst=F(0)
        for value,((rl,rh),(il,ih)) in zip(result['normalized'],reference):
            vr,vi=(F(v,1<<p['Q']) for v in value)
            er=max(abs(vr-rl),abs(vr-rh)); ei=max(abs(vi-il),abs(vi-ih))
            error_sq=er*er+ei*ei
            check(error_sq<=tolerance*tolerance,'certified_dense_coordinate')
            worst=max(worst,error_sq/(tolerance*tolerance))
        # Exact scale-back identity in the returned nonnegative-exponent format.
        for actual,norm in zip(result['values'],result['normalized']):
            for a,b in zip(actual,norm):
                check(F(a,1<<result['exponent'])==F(b,1<<p['Q'])*F(2)**result['lambda_exp'],'exact_scale_back')
        ev=result['ledger']['events']
        check(ev['root_preparations']==N and ev['scale_preparations']==1,'paid_root_scale_preparation')
        check(ev['dense_complex_terms']==N*N and ev['normalized_coordinate_reads']==N*N,'paid_dense_terms')
        check(ev['final_cartesian_roundings']==2*N and ev['output_fields_written']==2*N,'paid_round_output')
        check(ev['input_fields_read']==2*N and ev['normalization_max_passes']==1,'paid_dense_input')
        aggregate.update(ev); max_bits=max(max_bits,result['ledger']['max_integer_bits']); max_ratio_sq=max(max_ratio_sq,worst)
        cases.append(dict(N=N,fixture=label,e=e,k0=result['source_k0'],Q=p['Q'],m=p['m'],
                          output_max_numerator_bits=max(abs(v).bit_length() for pair in result['values'] for v in pair),
                          output_exponent=result['exponent'],input_numerators=nums,output_numerators=result['values'],ledger=result['ledger'],
                          scalar_K=result['certificate']['K'],scalar_output_grid=result['certificate']['grid'],
                          error_bound_certified=True))
    print('checked dense N='+str(N),flush=True)
# Deliberate known-bad implementation mutations must be detected.
mutation=[]
A=2**53+1
bad_k0=math.ceil(math.log2(A)); correct=ceil_log2(A)
check(bad_k0!=correct and F(A,1<<bad_k0)>1,'mutation_float_normalization')
mutation.append(dict(name='float_log2_normalization',A=A,mutant_k0=bad_k0,correct_k0=correct,detected=True))
beta=F(1,4)+F(1,2**60); m=4
bad_exp=math.ceil(2*float(beta)*m); right=ceil_fraction(2*beta*m)
check(bad_exp!=right,'mutation_float_parameter_ceiling')
mutation.append(dict(name='float_beta_ceiling',beta=str(beta),m=m,mutant_exponent=bad_exp,correct_exponent=right,detected=True))
check(int(F(-3,2)+F(1,2))!=nearest_even(-3,2),'mutation_negative_rounding')
mutation.append(dict(name='naive_negative_half_rounding',detected=True))
check(set(range(-2,3))!=set(range(-2,2)),'mutation_closed_fiber')
mutation.append(dict(name='closed_instead_of_half_open_fiber',detected=True))
# Pin a small-case sign regression by using positive-sign output on imaginary data.
nums=[(0,0),(1,0),(0,0)]; r=execute(nums,0); ref=reference_transform(nums,r['source_k0'],r['params']['Q'])
vr,vi=r['normalized'][1]; mutant=(F(vr,1<<r['params']['Q']),F(-vi,1<<r['params']['Q']))
check(not(ref[1][1][0]<=mutant[1]<=ref[1][1][1]),'mutation_transform_sign')
mutation.append(dict(name='positive_instead_of_negative_transform_sign',N=3,detected=True))
# Exact axes validate the independent reference against elementary rational values.
for N,axes in [(1,[(1,0)]),(2,[(1,0),(-1,0)]),(4,[(1,0),(0,-1),(-1,0),(0,1)])]:
    roots,scale=reference_roots(N,80)
    for root,exact in zip(roots,axes):
        check(all(interval[0]<=value<=interval[1] for interval,value in zip(root,exact)),'reference_exact_axes')
# Disjoint tape-address ranges are tested without claiming physical independence.
m=4; L=4*m+1; J=5; length=J*2*L*(2*m-1)
tape=BitTape([0,1]*(length//2)+[0]*(length%2)); blocks=[]
for run in range(J):
    for phase in range(2):
        start_block=tape.cursor
        for _ in range(L): tape.affine_round(m)
        blocks.append((start_block,tape.cursor))
check(tape.cursor==length,'disjoint_bit_blocks')
check(all(blocks[i][1]==blocks[i+1][0] for i in range(len(blocks)-1)),'disjoint_bit_blocks')
# Failure tapes remain bounded: injected outputs obey only deterministic envelopes.
# This fixture performs no FFT, coefficient generation, or probabilistic recovery.
p=parameters(2**45,Family()); check(p['sparse'],'failed_tape_fixture_dispatch')
cap=3*p['M']**2*(1<<p['P'])
check(validate_frontend_fixture([(0,cap-1,-cap+1),(p['M']-1,0,0)],p),'failed_tape_envelope')
for items in [[(0,cap,0)],[(0,1,0),(0,2,0)],[(-1,0,0)],[(p['M'],0,0)]]:
    expect_error(lambda:validate_frontend_fixture(items,p),'failed_tape_rejection')
cb=4*(1<<p['p'])-1; z=cap-1
for length in [0,1,2,p['t']]:
    for signs in [(1,1,1,1),(1,-1,1,1),(-1,-1,1,-1)]:
        term=tuple(v*sgn for v,sgn in zip((cb,cb,z,z),signs)); l=Ledger()
        raw,rounded=fixture_row_sum([term]*length,p,l)
        a,b,c,d=term; check(raw==(length*(a*c-b*d),length*(a*d+b*c)),'failed_tape_exact_accumulation')
        check(max(abs(v).bit_length()+1 for v in raw)<=p['accum_bits'],'failed_tape_signed_width')
        check(l.events['transfer_fixture_terms']==length,'paid_transfer_fixture_terms')
# Every scalar primitive is finite-loop, but these fixtures do not prove the
# full engine's totality; explicit unsupported branches stay visible.
# Cost claim must remain scoped; this is not a growing-word simulator.
report={'status':'PASS_SCOPED_COMPONENT_AND_DENSE_CONFORMANCE',
        'python':sys.version,'platform':platform.platform(),'elapsed_seconds':time.time()-start,
        'test_counts':dict(counts),'total_assertions':sum(counts.values()),'dense_cases':len(cases),
        'dense_coordinates':counts['certified_dense_coordinate'],'dense_ledger_aggregate':dict(aggregate),
        'max_counted_integer_bits':max_bits,'max_squared_error_fraction_of_7N_rho_bound':str(max_ratio_sq),
        'mutation_controls':mutation,'full_sparse_engine_executed':False,
        'active_transfer_executed':False,'global_tensor_engine_executed':False,
        'universal_probability_tested':False,'historical_code_executed':False,
        'large_symbolic_case':{'m':4096,'N_description':'2^4094','sparse_guard':p4096['sparse'],'allocation_performed':False},
        'cost_scope':'Root/scale construction, fixed scalar loops, exact dense arithmetic, field scans, roundings and output are charged by semantic counters and conservative arithmetic proxy; host interpreter, serialization, exact peak live memory and a full growing-word proof remain open.'}
(BASE/'results'/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
(BASE/'results'/'dense_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','elapsed_seconds','total_assertions','dense_cases','dense_coordinates','max_counted_integer_bits']},indent=2))
