"""Independent rational-interval oracle, not imported by production module.

Pi uses 4*(atan(1/2)+atan(1/3)), rather than the production Machin formula.
Roots use a complex exponential Taylor recurrence over Fraction intervals,
rather than the production separate sine/cosine recurrences. Reciprocal square
root uses fixed-depth rational bisection, rather than integer square root.
"""
from fractions import Fraction as R
from math import factorial
from functools import lru_cache


def add(a,b): return a[0]+b[0],a[1]+b[1]
def neg(a): return -a[1],-a[0]
def mul(a,b):
    v=[x*y for x in a for y in b]
    return min(v),max(v)
def outward(a,K):
    S=1<<K
    return R((a[0]*S).__floor__(),S),R((a[1]*S).__ceil__(),S)

def atan(q,n):
    z=R(0)
    for j in range(n): z+=R((-1)**j,(2*j+1)*q**(2*j+1))
    err=R(1,(2*n+1)*q**(2*n+1))
    return z-err,z+err

@lru_cache(None)
def reference_roots(N,Q):
    K=Q+48; S=1<<K; terms=K+24
    a=atan(2,K+4); b=atan(3,K+4)
    pi=4*(a[0]+b[0]),4*(a[1]+b[1])
    roots=[]
    for residue in range(N):
        # Deliberately use the uncentered angle in [-2*pi,0].
        theta=mul(pi,(-R(2*residue,N),)*2)
        midpoint=(theta[0]+theta[1])/2
        center=R((midpoint*S).__floor__(),S)
        angle_error=max(abs(center-theta[0]),abs(center-theta[1]))
        re=(R(1),)*2; im=(R(0),)*2
        sr=re; si=im
        for n in range(1,terms+1):
            factor=(center/n,)*2
            re,im=outward(neg(mul(im,factor)),K),outward(mul(re,factor),K)
            sr=add(sr,re); si=add(si,im)
        # Integral remainder for real-parameter exp(i*x); derivative modulus=1.
        tail=R(7**(terms+1),factorial(terms+1))+angle_error
        roots.append(((sr[0]-tail,sr[1]+tail),(si[0]-tail,si[1]+tail)))
    low=0; high=S
    for _ in range(K+1):
        mid=(low+high)//2
        if mid*mid*N<=S*S: low=mid
        else: high=mid
    scale=(R(low,S),R(high,S))
    if low*low*N==S*S: scale=(R(low,S),)*2
    return tuple(roots),scale


def reference_transform(nums,k0,Q):
    N=len(nums); roots,scale=reference_roots(N,Q); out=[]
    for ell in range(N):
        re=(R(0),)*2; im=(R(0),)*2
        for j,(a,b) in enumerate(nums):
            u,v=roots[(j*ell)%N]; a=R(a,1<<k0); b=R(b,1<<k0)
            re=add(re,add(mul((a,a),u),neg(mul((b,b),v))))
            im=add(im,add(mul((a,a),v),mul((b,b),u)))
        out.append((mul(re,scale),mul(im,scale)))
    return out
