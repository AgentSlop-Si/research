"""New, bounded Q16 conformance implementation. No historical code imported.

Only the dense branch is executable end-to-end, for N <= 32. Sparse branch
parameters and several small combinatorial components are executable; the
sparse recovery/transfer engine is deliberately unsupported.
"""
from dataclasses import dataclass, field, asdict
from fractions import Fraction as F
from math import isqrt, factorial
from collections import Counter

MAX_DENSE_N = 32


def ceil_div(a, b):
    if b <= 0: raise ValueError('positive divisor required')
    return -((-a) // b)


def ceil_fraction(x):
    return ceil_div(x.numerator, x.denominator)


def ceil_log2(a):
    if type(a) is not int or a < 1: raise ValueError('positive integer required')
    return (a-1).bit_length()


def nearest_even(n, d):
    """Signed exact quotient rounding; d > 0; tie goes to even integer."""
    if d <= 0: raise ValueError('positive divisor required')
    q, r = divmod(n, d)
    return q + (2*r > d or (2*r == d and q % 2 != 0))


@dataclass(frozen=True)
class Family:
    alpha: F = F(1, 8)
    beta: F = F(1, 4)
    c: F = F(1)
    d: int = 2
    D: int = 5
    def __post_init__(self):
        if not all(type(x) is F for x in (self.alpha,self.beta,self.c)):
            raise TypeError('rational fixture parameters required; no float parsing')
        if not (0 < self.alpha < self.beta < F(1,2) and self.c > 0):
            raise ValueError('strict alpha/beta/c domain')
        if type(self.d) is not int or self.d < 1: raise ValueError('d >= 1')
        if type(self.D) is not int or not self.D > self.alpha+4:
            raise ValueError('integer D > alpha+4')


def parameters(N, family=Family()):
    if type(N) is not int or N < 1: raise ValueError('N >= 1')
    m = ceil_log2(4*N); M = 1 << m
    k = 1 << ceil_fraction(2*family.beta*m)
    B = 1 << ceil_fraction((F(1,2)+family.beta)*m)
    T = M//B if M % B == 0 else None
    r_win=2*m+1; ell_win=8*B; W=2*r_win*(ell_win-1)+1
    q=512*k; L=4*m+1; P=16*m+16
    s=family.D*m; h=16*s+1; t=2*h+2
    r_amp=family.c.numerator//family.c.denominator+2; J=2*r_amp-1
    b=ceil_fraction((family.beta+2)*m)
    eta_exponent=(family.D+3)*m; p=eta_exponent+3
    w=P+2*m+2; accum_bits=p+w+4+ceil_log2(t)
    guards = {'B_divides_M':M%B==0, 'B_ge_4':B>=4,
              'T_ge_4':T is not None and T>=4, 'B_ge_4096k':B>=4096*k,
              'W_lt_M':W<M, 't_lt_M':t<M, 'beta_m_ge_2':family.beta*m>=2}
    # These are formal allocation/workload counts, not evidence of execution.
    symbolic = {'random_bits_per_frontend':2*L*(2*m-1),
                'random_bits_amplified':J*2*L*(2*m-1),
                'rounds_amplified':J*2*L,
                'source_queries_amplified':J*2*L*W,
                'normalizer_scalar_terms_per_preparation':T//2+1 if T is not None else None,
                'tap_scalar_evaluations_per_preparation':W,
                'window_passes':2*r_win,
                'fft_butterflies_amplified':J*2*L*(B//2)*ceil_log2(B),
                'temporary_memberships_per_run':L*q*T if T is not None else None,
                'support_cap_per_run':2*q*T if T is not None else None,
                'phase_evaluations_amplified_max':J*L*2*q*T if T is not None else None,
                'active_coefficients_amplified_max':J*2*q*T*t if T is not None else None,
                'dense_accumulator_initializations':J*N,
                'dense_final_complex_rounds':J*N,
                'dense_cartesian_medians':2*N,
                'dense_output_fields':2*N,
                'accumulator_signed_bits_per_cartesian':accum_bits}
    return dict(N=N,m=m,M=M,k=k,B=B,T=T,r_win=r_win,ell_win=ell_win,W=W,
                q=q,L=L,P=P,s=s,h=h,t=t,r_amp=r_amp,J=J,b=b,p=p,
                eta_exponent=eta_exponent,w=w,accum_bits=accum_bits,Q=P,
                sparse=all(guards.values()),guards=guards,symbolic=symbolic)


@dataclass
class Ledger:
    events: Counter = field(default_factory=Counter)
    max_integer_bits: int = 0
    conservative_arithmetic_proxy: int = 0
    def event(self, name, count=1): self.events[name] += count
    def charge(self, kind, *values):
        bits=[max(1,abs(v).bit_length()) for v in values]
        self.max_integer_bits=max([self.max_integer_bits]+bits)
        self.events['integer_'+kind]+=1
        if kind in ('add','sub','compare','shift'): cost=max(bits)
        elif kind=='mul': cost=bits[0]*bits[1]
        else: cost=sum(bits)**3 # conservative abstract division/sqrt proxy
        self.conservative_arithmetic_proxy+=cost
    def add(self,a,b):
        self.charge('add',a,b); z=a+b; self.max_integer_bits=max(self.max_integer_bits,abs(z).bit_length()); return z
    def mul(self,a,b):
        self.charge('mul',a,b); z=a*b; self.max_integer_bits=max(self.max_integer_bits,abs(z).bit_length()); return z
    def summary(self):
        return dict(events=dict(sorted(self.events.items())),
                    max_integer_bits=self.max_integer_bits,
                    conservative_arithmetic_proxy=self.conservative_arithmetic_proxy,
                    scope='Explicit scalar/dense arithmetic and semantic workload counters; not CPython instruction, serializer, memory, or full bit-complexity certification.')


@dataclass
class Normalized:
    nums: tuple
    k0: int
    lambda_exp: int
    M: int
    a0: int
    zero: bool
    ledger: Ledger
    def source(self,r):
        if type(r) is not int or not 0<=r<self.M: raise ValueError('source residue range')
        self.ledger.event('source_queries')
        j=(r+self.a0)%self.M
        return self.nums[j] if j<len(self.nums) else (0,0)


def normalize(nums, e, params, family, ledger):
    N=params['N']; limit=1 << (family.d*params['m'])
    if type(e) is not int or not 0<=e<=family.d*params['m']:
        raise ValueError('input exponent outside finite domain')
    if len(nums)!=N: raise ValueError('input length mismatch')
    A=0
    checked=[]
    for pair in nums:
        if not isinstance(pair,(list,tuple)) or len(pair)!=2: raise ValueError('complex pair required')
        for a in pair:
            ledger.event('input_fields_read')
            if type(a) is not int or abs(a)>limit: raise ValueError('numerator outside finite domain')
            A=max(A,abs(a))
        checked.append(tuple(pair))
    k0=ceil_log2(A) if A else 0
    ledger.event('normalization_max_passes')
    return Normalized(tuple(checked),k0,k0-e,params['M'],(N-1)//2,A==0,ledger)


@dataclass(frozen=True)
class DI:
    lo: int
    hi: int


class DyadicIntervals:
    """Outward fixed-grid interval arithmetic, grid 2^-K."""
    def __init__(self,K,ledger): self.K=K; self.S=1<<K; self.l=ledger
    def exact(self,n): return DI(n*self.S,n*self.S)
    def rat(self,n,d):
        a=self.l.mul(n,self.S); self.l.charge('div',a,d)
        return DI(a//d,ceil_div(a,d))
    def add(self,a,b): return DI(self.l.add(a.lo,b.lo),self.l.add(a.hi,b.hi))
    def neg(self,a): return DI(-a.hi,-a.lo)
    def sub(self,a,b): return self.add(a,self.neg(b))
    def mul(self,a,b):
        z=[self.l.mul(x,y) for x in (a.lo,a.hi) for y in (b.lo,b.hi)]
        lo=min(z); hi=max(z); self.l.charge('div',lo,self.S); self.l.charge('div',hi,self.S)
        return DI(lo//self.S,ceil_div(hi,self.S))
    def div_int(self,a,n):
        if n<=0: raise ValueError('positive divisor')
        self.l.charge('div',a.lo,n); self.l.charge('div',a.hi,n)
        return DI(a.lo//n,ceil_div(a.hi,n))
    def inflate(self,a,r): return DI(self.l.add(a.lo,-r),self.l.add(a.hi,r))
    def atan_recip(self,q):
        # Alternating rational series. Exactly K+4 terms; next term encloses tail.
        z=self.exact(0); power=q; n=self.K+4
        for j in range(n):
            self.l.event('machin_terms')
            den=self.l.mul(2*j+1,power)
            term=self.rat(1,den); z=self.add(z,term if j%2==0 else self.neg(term))
            power=self.l.mul(power,q*q)
        den=self.l.mul(2*n+1,power)
        tail=self.rat(1,den)
        # Symmetric tail is deliberately conservative.
        return self.inflate(z,tail.hi)
    def pi(self):
        a=self.atan_recip(5); b=self.atan_recip(239)
        return self.sub(self.mul(self.exact(16),a),self.mul(self.exact(4),b))
    def sincos(self,x):
        # Taylor polynomials at interval x, with |x| <= 4 checked exactly.
        if max(abs(x.lo),abs(x.hi))>4*self.S: raise ValueError('argument not reduced')
        x2=self.mul(x,x); negx2=self.neg(x2)
        sin=x; st=x; cos=self.exact(1); ct=cos; n=self.K+4
        for j in range(1,n):
            self.l.event('trig_iterations')
            st=self.div_int(self.mul(st,negx2),(2*j)*(2*j+1))
            ct=self.div_int(self.mul(ct,negx2),(2*j-1)*(2*j))
            sin=self.add(sin,st); cos=self.add(cos,ct)
        # Global Lagrange bounds for real sin/cos (all derivatives <= 1).
        self.l.event('factorial_tail_bounds',2)
        sin_tail=ceil_div((4**(2*n+1))*self.S,factorial(2*n+1))
        cos_tail=ceil_div((4**(2*n))*self.S,factorial(2*n))
        # Tail-bound construction has full integer bit-size conservative charge.
        self.l.charge('div',4**(2*n+1)*self.S,factorial(2*n+1))
        self.l.charge('div',4**(2*n)*self.S,factorial(2*n))
        return self.inflate(sin,sin_tail),self.inflate(cos,cos_tail)
    def rounded(self,a,out_bits):
        shift=self.K-out_bits
        if shift<0: raise ValueError('output precision exceeds internal grid')
        den=1 << (shift+1)
        n=self.l.add(a.lo,a.hi); self.l.charge('div',n,den)
        v=nearest_even(n,den)
        err=max(abs((v<<shift)-a.lo),abs((v<<shift)-a.hi))
        return v,err


def prepare_dense(N,Q,ledger):
    # Fixed, conservative precision and iteration counts; no refinement loop.
    K=Q+64; g=Q+4; I=DyadicIntervals(K,ledger); pi=I.pi(); roots=[]; certs=[]
    for a in range(N):
        ledger.event('root_preparations')
        a_signed=a if 2*a<=N else a-N
        angle=I.mul(pi,I.rat(-2*a_signed,N))
        sine,cosine=I.sincos(angle)
        re,er=I.rounded(cosine,g); im,ei=I.rounded(sine,g)
        if er*er+ei*ei > 1 << (2*(K-Q)): raise ArithmeticError('root target unproved')
        roots.append((re,im)); certs.append((er,ei))
    S=1 << K
    ledger.event('scale_preparations'); ledger.charge('div',S*S,N); ledger.charge('isqrt',S*S//N)
    a=isqrt(S*S//N); exact=(a*a*N==S*S)
    scale_interval=DI(a,a if exact else a+1)
    scale,err=I.rounded(scale_interval,g)
    if err > 1 << (K-Q): raise ArithmeticError('scale target unproved')
    return roots,scale,dict(K=K,grid=g,root_errors_in_internal_units=certs,
                            scale_error_in_internal_units=err,pi_interval=[pi.lo,pi.hi])


def dense_normalized(source,params,ledger):
    N=params['N']; Q=params['Q']
    if N>MAX_DENSE_N: raise NotImplementedError('bounded harness dense limit; not theorem abort')
    roots,scale,cert=prepare_dense(N,Q,ledger); g=cert['grid']
    out=[]; den_exp=source.k0+2*g; shift=den_exp-Q
    for ell in range(N):
        re=im=0; ledger.event('dense_row_initializations')
        for j,(a,b) in enumerate(source.nums):
            ledger.event('dense_complex_terms'); ledger.event('normalized_coordinate_reads')
            u,v=roots[(j*ell)%N]
            re=ledger.add(re,ledger.add(ledger.mul(a,u),-ledger.mul(b,v)))
            im=ledger.add(im,ledger.add(ledger.mul(a,v),ledger.mul(b,u)))
        rr=ledger.mul(re,scale); ii=ledger.mul(im,scale)
        ledger.event('final_cartesian_roundings',2)
        ledger.charge('div',rr,1<<shift); ledger.charge('div',ii,1<<shift)
        out.append((nearest_even(rr,1<<shift),nearest_even(ii,1<<shift)))
    return out,cert


def execute(nums,e,family=Family()):
    p=parameters(len(nums),family); ledger=Ledger(); ledger.event('parameter_constructions')
    source=normalize(nums,e,p,family,ledger)
    if source.zero:
        ledger.event('output_fields_written',2*p['N'])
        return dict(branch='zero',values=[(0,0)]*p['N'],exponent=0,normalized=None,
                    params=p,ledger=ledger.summary(),certificate=None)
    if p['N']==1:
        ledger.event('output_fields_written',2)
        return dict(branch='identity',values=list(source.nums),exponent=e,normalized=None,
                    params=p,ledger=ledger.summary(),certificate=None)
    if p['sparse']: raise NotImplementedError('sparse engine and active transfer not implemented')
    normalized,cert=dense_normalized(source,p,ledger)
    exponent=p['Q']-source.lambda_exp
    if exponent<0:
        values=[(a<<-exponent,b<<-exponent) for a,b in normalized]; exponent=0
    else: values=normalized
    ledger.event('scale_back_fields',2*p['N']); ledger.event('output_fields_written',2*p['N'])
    return dict(branch='certified_dense',values=values,exponent=exponent,normalized=normalized,
                normalized_exponent=p['Q'],source_k0=source.k0,lambda_exp=source.lambda_exp,
                params=p,ledger=ledger.summary(),certificate=cert)


def select_bins(values,q):
    if not 0<=q<=len(values): raise ValueError('selection q range')
    return sorted(range(len(values)),key=lambda j:(-(values[j][0]**2+values[j][1]**2),j))[:q]


def hash_index(i,sigma,M,B):
    if M%B or M//B%2 or sigma%2!=1: raise ValueError('power-two compatible fixture required')
    T=M//B
    return (((sigma*i)%M+T//2)//T)%B


def inverse_fiber(j,sigma,M,B):
    if not 0<=j<B: raise ValueError('bucket range')
    T=M//B; inv=pow(sigma,-1,M)
    return [(inv*r)%M for r in range(j*T-T//2,j*T+T//2)]


def votes(rounds,M):
    for round_ in rounds:
        if len(set(round_))!=len(round_) or any(not 0<=i<M for i in round_):
            raise ValueError('duplicate or invalid membership in one round')
    counts=Counter(i for row in rounds for i in row)
    return sorted(i for i,c in counts.items() if c>=ceil_div(len(rounds),2))


def cartesian_median(values):
    if not values or len(values)%2==0: raise ValueError('odd positive sample count')
    j=len(values)//2
    return sorted(v[0] for v in values)[j],sorted(v[1] for v in values)[j]


class BitTape:
    """Finite fixture reader: tests draw boundaries, not physical entropy."""
    def __init__(self,bits):
        if any(type(b) is not int or b not in (0,1) for b in bits): raise ValueError('non-bit')
        self.bits=tuple(bits); self.cursor=0
    def word(self,n):
        if self.cursor+n>len(self.bits): raise ValueError('fixture tape exhausted')
        out=0
        for b in self.bits[self.cursor:self.cursor+n]: out=2*out+b
        self.cursor+=n; return out
    def affine_round(self,m): return 2*self.word(m-1)+1,self.word(m)


def validate_frontend_fixture(items,params):
    """Validate an injected finite-output envelope, never generate a sparse output."""
    if not params['sparse']: raise ValueError('sparse parameters required')
    if len(items)>params['symbolic']['support_cap_per_run']: raise ValueError('support cap')
    seen=set(); cap=3*params['M']**2*(1<<params['P'])
    for i,re,im in items:
        if type(i) is not int or not 0<=i<params['M'] or i in seen:
            raise ValueError('invalid or duplicate support')
        seen.add(i)
        if any(type(a) is not int or abs(a)>=cap for a in (re,im)):
            raise ValueError('all-tape Cartesian magnitude envelope')
    return True


def fixture_row_sum(terms,params,ledger):
    """Exact arithmetic component only. Coefficients are supplied fixtures.

    Each term is (coefficient_real, coefficient_imag, z_real, z_imag),
    on grids p and P. This does not evaluate an interpolation coefficient.
    """
    if len(terms)>params['t']: raise ValueError('row contribution cap')
    re=im=0; cb=4*(1<<params['p']); zb=1<<params['w']
    for a,b,c,d in terms:
        if any(type(x) is not int for x in (a,b,c,d)): raise ValueError('integer numerator')
        if abs(a)>=cb or abs(b)>=cb or abs(c)>=zb or abs(d)>=zb:
            raise ValueError('fixture numerator envelope')
        ledger.event('transfer_fixture_terms')
        re=ledger.add(re,ledger.add(ledger.mul(a,c),-ledger.mul(b,d)))
        im=ledger.add(im,ledger.add(ledger.mul(a,d),ledger.mul(b,c)))
    limit=1<<(params['accum_bits']-1)
    if not (-limit<=re<limit and -limit<=im<limit): raise OverflowError('proved signed width exceeded')
    shift=params['p']+params['P']-params['b']
    return (re,im),(nearest_even(re,1<<shift),nearest_even(im,1<<shift))
