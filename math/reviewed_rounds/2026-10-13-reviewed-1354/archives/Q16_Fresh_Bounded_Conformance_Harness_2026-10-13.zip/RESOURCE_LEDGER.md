# Complete-path resource inventory and what was measured

All counts below distinguish implemented work from symbolic specifications.
The fixed parameters alpha, beta, c, d, D describe a family; alpha, beta and c
are exact rational specimens in this harness. It does not parse arbitrary real
parameters. The fixed witness is r_amp=floor(c)+2, J=2r_amp-1.

## Executed dense path

For nonzero 2 <= N <= 32:

- m=ceil(log2(4N)), M=2^m, Q=16m+16, K=Q+64, root/scale grid Q+4.
- Exactly 2N input numerator fields are validated, plus the common exponent and
  length. One max scan gives k0=ceil(log2 A); no norm query occurs.
- Two Machin arctangent calls, each K+4 terms, per complete call.
- N root preparations, each with K+3 sine/cosine recurrence iterations and two
  factorial remainder bounds. All interval outputs use common grid K.
- One reciprocal-square-root preparation.
- N^2 normalized coordinate reads and N^2 complex terms; each term has four
  explicit integer products, two inner signed sums and two accumulator adds.
- Two exact scale products per row; 2N nearest-even final rounds; 2N exact
  scale-back/output fields. No random bits, retries or scalar refinements.
- Zero and N=1 identity branches perform no roots, FFTs or random draws.
- Explicit integer add/mul/div/isqrt counters and observed maximum operand/result
  width are returned. Add cost proxy is linear in operand width; multiply uses
  the product of widths; div/isqrt use a deliberately conservative cubic proxy.

The proxy is diagnostic, not an independently certified elementary-instruction
bound. It omits an exact decomposition of Python/Fraction parameter work,
comparison/control flow, index arithmetic, power/factorial construction,
allocation/garbage collection, reference-oracle work and serializer bit volume.
These omissions are disclosed rather than charged as zero-cost theorem work.
The executable semantic workload checks close paid-preparation/counting
regressions but do not close the machine-cost theorem gate.

## Symbolic sparse/outer allocation and workload only

The parameter object explicitly records:

- k, B, T, r_win, ell_win, W, q=512k, L=4m+1, P=16m+16;
- s=Dm, h=16s+1, t=32Dm+4, eta exponent (D+3)m, p=(D+3)m+3,
  b=ceil((beta+2)m), w=P+2m+2;
- signed row accumulator allocation p+w+4+ceil(log2 t);
- 2L(2m-1) bits per front end; J times that budget overall;
- J*2L*W supported source accesses; J*2L*(B/2)*log2 B butterflies;
- 2r_win coefficient-convolution passes; W taps; T/2+1 normalizer terms;
- LqT temporary memberships per run; S_max=2qT distinct candidates;
- J*L*S_max candidate phase evaluations; J*S_max*t active coefficient
  evaluations as a conservative retained-incidence upper bound;
- JN dense accumulator initializations and final complex rounds; 2N
  Cartesian medians with J entries each; 2N final Cartesian output fields.

Additional paid operations required by the proof, not yet implemented, are:
sliding-window coefficient integer work (at most twice the sum of the growing
vector lengths), exact normalizer/tap/phase scalar work and certified division,
all root setup, modular inverses, source address computation, exact magnitude
comparisons/sorting, candidate sorting/counting, active incidence enumeration
and deduplication, coefficient products/sums, all-tape output serialization and
full peak storage. Each coefficient integer has the stated bound
2r_win*log2(ell_win)+1 bits. FFT scratch has O_d(m^2) bits; scalar scratch has
polynomial bit width. No numerical polynomial exponent or primitive count for
those unimplemented stages is certified here.

## Failure tapes and randomness

The exact upper probability 2^(2r_amp-1)/M^r_amp is checked against
(1/2)N^-r_amp and N^-c using rational inequalities. This verifies budgeting,
not independence or a probability theorem. Small complete bit enumerations
validate the odd-slope/uniform-shift mapping, and a fixture verifies that
location, estimation and repetition consume disjoint address blocks. No claim
is made about physical entropy or a pseudorandom generator.

Supplied failed-output fixtures exercise distinct/ranged support and strict
Cartesian magnitude <3M^2 on the P grid. Extreme signed row sums respect the
allocated accumulator width even without any accuracy assumption. This proves
those individual fixture computations; it neither generates E(beta) failure
tapes nor establishes the unimplemented front end's universal envelopes.
