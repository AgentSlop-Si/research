"""Read-only verification of delivered manifest and included result status."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent
manifest=json.loads((B/'MANIFEST.json').read_text())
seal=json.loads((B/'SEAL.json').read_text())
assert hashlib.sha256((B/'MANIFEST.json').read_bytes()).hexdigest()==seal['manifest_sha256']
for row in manifest['files']:
    p=B/row['path']
    assert p.is_file(), row['path']
    assert p.stat().st_size==row['bytes'], row['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'], row['path']
result=json.loads((B/'results/checks.json').read_text())
assert result['status']=='PASS_SCOPED_COMPONENT_AND_DENSE_CONFORMANCE'
assert not any(result[k] for k in ['full_sparse_engine_executed','active_transfer_executed','global_tensor_engine_executed','historical_code_executed'])
print(json.dumps({'status':'PASS_MANIFEST_AND_SCOPE','payload_files':len(manifest['files']),'assertions':result['total_assertions'],'dense_coordinates':result['dense_coordinates']},indent=2))
