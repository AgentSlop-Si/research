NEXT TEN UNKNOWN GROUPS: SOURCE-READINESS INVENTORY
13 October 2026 | private evidence overlay

Result: 0 ready, 0 currently source-blocked, 10 require selection of one precise new comparison.
The original claim/proof bodies are available. That does not by itself select a new research task or establish novelty.
These are ALG-006,007,008,009,010,011,013,015,025 and026, each at unchanged priority42. The ten groups are distinct.

Key findings
- All25 distinct Catalogue document pins match recovered bytes.
- Phase19 original Theorem C, proof and implementation body were recovered; all48 source-manifest entries match.
- The exact ALG009 current audit matches its native archive pin; all27 listed payloads match. The legacy resonance correction is already known, with no source patch made.
- ALG011 uses the extended zero/root-shift theorem. Its earlier detector exclusions are superseded.
- ALG025/026 already contain substantial primary-work comparisons. Do not repeat the Mailman/sampling/pruned-FFT survey. The saved Reif work did not include a full-paper read; selecting a precise theorem and recovering that body is one bounded candidate.
- The dyadic pruned comparator already beats ALG026 second tradeoff. Neither approximation theorem gives relative-l2 output accuracy; the first shrinking-error linear point is the relevant remaining comparison.

ALG-006 | Unknown shear/Newton, exact-g orbit union, and fixed-total-order confluence
Gate: No primary comparator theorem/edition or single branch has been selected. Do not rerun finite confluence controls or reopen the accepted conditional proof. The historical unified dispatcher omits these branches; implementation integration is a separate task.
Bounded next step: Pick one primary repeated-pole/generalized-Prony theorem and one branch only, preferably the fixed-total-order-D confluent bridge. Compare unknown multiplicities, clean-pilot/nondegeneracy requirements, field/root supply, raw rejection, complete outputs and all D-dependent work. Stop at a hypothesis/formula/cost mapping or exact nonmatch.

ALG-007 | Raw-input common sparse phase support
Gate: No exact primary theorem is selected. Do not repeat the accepted coverage/entropy tests or claim that ordinary Hankel rank characterizes this class. The source returns rejection rather than supplying the prose fallback; free padding and growing chirp search are excluded.
Bounded next step: Select one primary common-support/multiple-signal sparse interpolation theorem. Compare its input interface and support recovery with the blockwise certificate, then separately account for the full Green output bank, rejection, supplied factorization/chirp/roots and possible fallback. Stop at a model-matched mapping or qualified nonmatch.

ALG-008 | Blind sparse circular-inverse recovery
Gate: Own original theorem and implementation body are now available; no primary comparator theorem has been pinned. Do not redo blind-inverse correctness or turn the K>=2 sparse-rational successor into the same solved theorem. Delay orientation/factorization is not unique.
Bounded next step: Freeze Phase19 Theorem C only. Choose an exact primary Prony/sparse-interpolation theorem and map reciprocal-probe construction, root enumeration without a discrete-log oracle, full cyclic soundness certificate and O(Ns+s^3) work. The source names Plonka–Tasche as a possible lead, but no theorem text has yet been selected or checked. Stop at a precise comparison or access blocker.

ALG-009 | Unknown shifted two-defect recognition and exact pole-budget boundary
Gate: No primary comparison theorem is selected. The old resonance finding is complete and must not be rediscovered or promoted as a new bug. Predicate-scan counts are not counts of nondegenerate fast-family inputs; extra Bluestein roots and Green invertibility remain engine requirements.
Bounded next step: Select one primary sparse-rational interpolation theorem for an unknown binomial denominator and at-most-two-term numerator. Map the eight-probe uniqueness statement separately from arbitrary-input acceptance, resultant/gcd genericity, root enumeration, full certificate and exact zero/one-pole repair. Stop at an exact mapping/nonmatch; any source patch is separately scoped and independently reviewed.

ALG-010 | First-order q-linear cold evaluator
Gate: No model-matched primary theorem/edition is selected. Keep numerical recognition, bit complexity and root construction separate. The lower-level solver source has not been re-executed or newly certified here.
Bounded next step: Select one primary finite q-difference/recurrence transform theorem with the same degree-one coefficient family. Compare unknown coefficient discovery and finite cyclic boundary, then the singular input-side constraint and full-output ledger. Stop at a source-bound equivalence/nonmatch; generic references to Prony alone do not establish a match.

ALG-011 | Cold sparse recurrence-defect discovery
Gate: No exact primary theorem is selected. The earlier nonzero/nonresonant theorem remains historical only. Do not reopen the zero/root-shift acceptance or treat zero defect as zero output.
Bounded next step: Choose one primary annihilating-filter/recurrence-defect theorem that actually covers unknown scalar shift and singular reconstruction. Map the complete union, majority discovery, raw full certificate, input-side missing-coordinate recovery and sparse forcing cost. Stop at a qualified match/nonmatch; do not compare only the superseded detector.

ALG-013 | Binary-index rank-one tensor certificate and shared full-output evaluator
Gate: No exact primary comparator theorem is selected. The residual l1 numerical certificate and magnitude-pivot stability discussion are not the shipped exact recognizer. A paid fallback is separate.
Bounded next step: Select one primary separable-tensor/multilinear-polynomial evaluation theorem, rather than assuming a Prony match. Compare raw rank-one certification, all-output suffix reuse, principal-root/ring-unit guards and cold cost. Stop at an exact theorem mapping or qualified nonmatch.

ALG-015 | Ordered noncommuting affine-cycle filter fusion
Gate: No exact primary theorem is selected. Keep the separate sparse-surrogate fusion obstruction closed; neither its dimension gate nor standard ingredients alone settle historical priority.
Bounded next step: Select one primary operator-intertwining/filter-cascade theorem with noncommuting order and supplied parameters. Map reverse solve order, shared preparation, singular exclusion, full source validation and paid fallback. Stop at one exact comparison; do not conflate it with commuting sparse-polynomial factorization.

ALG-025 | Fixed-error packed all-output approximation
Gate: No new primary theorem is selected. Existing Mailman, empirical sampling, pruned-FFT, sparse-Fourier error-scale and Four-Russians comparisons are already documented; do not rerun that broad survey. Full evaluator benchmarking remains separate. This is not exact output or relative-l2 accuracy.
Bounded next step: Choose one precise new primary exponential-sum/multipoint-evaluation theorem and compare fixed error, N inputs/N outputs, bounded common-scale representation and charged setup. The saved Reif comparison had only abstract/indexed access; obtaining that exact full paper and fixing one theorem is a bounded candidate, not an already verified blocker. Stop at a primary-theorem match/nonmatch or recorded access failure.

ALG-026 | Shrinking-error packed finite-word evaluator
Gate: No next primary theorem or unrestricted-length mechanism is selected. The shrinking-rate, random-sign zero-output caveat and dyadic pruned comparison are completed and should not be repeated. The saved Reif full-text gap is a possible recovery target, not proof of novelty or general source absence.
Bounded next step: Select a new primary theorem for the first fully charged linear-time shrinking-error point, or explicitly select the unresolved unrestricted-length sampling/NUFFT comparison. Freeze its output/error/representation and cold-setup contract before comparing. Stop at an exact theorem mapping/nonmatch/access blocker, without silently padding the requested DFT.

Meaning and limits
Readiness is for a new bounded scientific comparison, separate from source availability and the recorded scoped proof verdict. None of these ten is declared closed, disproved or newly proved. Selecting a comparator can be done as a bounded next research step; this is not automatically a request for a user decision.
The historical244 eligibility count remains unrecovered. The complete331-ID/249-group operational ledger is unchanged. No current partial live-sheet view was used.
Hash matches establish source identity. Saved scientific tests were read as evidence and not rerun; no inherited source or review code executed. No ranking, status, spreadsheet, repository, publication or sharing change was made.
The JSON gives exact claim/model boundaries, native next actions and stop conditions, research-source hashes, known archive identities and bounded nonduplicative next steps.
