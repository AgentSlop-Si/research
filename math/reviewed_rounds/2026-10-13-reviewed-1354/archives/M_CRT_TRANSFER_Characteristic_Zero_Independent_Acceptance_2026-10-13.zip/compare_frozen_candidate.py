#!/usr/bin/env python3
import csv,json,hashlib,collections
from pathlib import Path
import independent_bigint_replay as replay
D=Path(__file__).resolve().parent
C=D/'frozen_candidate'/'unpacked'
expected={'REPORT.md':'08ca060233a14f48d3e7ec204d270fa0a6c86aa63e28847eb8ea81a107268f3b','check_certificate.py':'f8552872e58480772a2c0d3ccf7efe8d3ffa10f03864d4671751d33207f776a4','certificate.json':'30425dab98ff8c7e24b9769fba7f623f7cd5b3d9f38cc235bbd15daaa96e5426','MANIFEST.sha256':'7bfcd9c6282b8364256ea6b4f98a27c90760d574046be28099467ceb5122d6b7','PHASE8_AUDIT_SOURCE.md':'c477aca2753343360a9fbdc734389741ea14a043c4dc6d8cd06e63b681fdd04d'}
for name,digest in expected.items():assert hashlib.sha256((C/name).read_bytes()).hexdigest()==digest
c=json.loads((C/'certificate.json').read_text())
individual={};total={};domain=set()
for row in csv.DictReader(open(D/'all_balanced_pair_counts.csv')):
    for mask_key,score_key in [('mask','nnz_A'),('complement','nnz_complement')]:
        m=int(row[mask_key]);individual[m]=int(row[score_key]);total[m]=int(row['total'])
        if row['eligible']=='1':domain.add(m)
seen=set();vectors=0;oh=collections.Counter()
for record in c['records']:
    a=record['mask'];b=a^65535
    # Independently compare exact raw coefficients, not just source checksums.
    for mask,pkey,rkey,nkey in [(a,'P_A','R_A','nnz_A'),(b,'P_B','R_B','nnz_B')]:
        p=replay.poly(mask); cols=replay.columns(p)
        assert record[pkey]==[list(k) for k in p]
        assert record[rkey]==[[list(cols[j][i]) for j in range(8)] for i in range(8)]
        assert record[nkey]==individual[mask]
        vectors+=9+64
    orbit=set()
    for u in range(1,16,2):
        for t in range(16):
            im=sum(1<<((u*i+t)%16) for i in range(16) if a>>i&1)
            orbit.add(im);orbit.add(im^65535)
    assert record['orbit_masks']==sorted(orbit) and record['orbit_size']==len(orbit)
    assert min(orbit)==a and not seen&orbit and orbit<=domain
    assert all(total[m]==record['score'] for m in orbit)
    seen|=orbit;oh[len(orbit)]+=1
assert seen==domain
hist=collections.Counter(total[m] for m in domain)
assert {str(k):v for k,v in sorted(hist.items())}==c['score_histogram_ordered_subsets']
assert min(hist)==c['minimum']==112 and hist[112]==64
assert c['minimizer_orbit_representatives']==[5019]
assert c['minimizer_subsets_count']==64 and c['minimizer_unordered_pairs_count']==32
assert c['counts']['orbit_size_histogram']=={str(k):v for k,v in sorted(oh.items())}
result={'status':'PASS','candidate_digests':expected,'compared_orbits':len(c['records']),'compared_eight_integer_vectors':vectors,'compared_integer_coordinates':8*vectors,'covered_eligible_subsets':len(seen),'minimum':112,'ordered_histogram':dict(sorted(hist.items())),'orbit_size_histogram':dict(sorted(oh.items()))}
(D/'candidate_comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
