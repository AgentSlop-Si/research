"""Fresh exact integer arithmetic in Z[z]/(z^8+1). No historical imports."""
ZERO = (0,)*8
ONE = (1,)+(0,)*7

def add(a,b): return tuple(x+y for x,y in zip(a,b))
def neg(a): return tuple(-x for x in a)
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def mul(a,b):
    out=[0]*8
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b):
                if y:
                    k=i+j
                    if k<8: out[k]+=x*y
                    else: out[k-8]-=x*y
    return tuple(out)
def root(k):
    k%=16
    out=[0]*8; out[k%8]=1 if k<8 else -1
    return tuple(out)
def roots_poly(A):
    p=[ONE]
    for a in sorted(A):
        q=[ZERO]*(len(p)+1)
        for i,c in enumerate(p):
            q[i]=sub(q[i],mul(c,root(a)))
            q[i+1]=add(q[i+1],c)
        p=q
    return p

def poly_mul(a,b):
    out=[ZERO]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): out[i+j]=add(out[i+j],mul(x,y))
    return out

def poly_rem(a,p):
    if p[-1]!=ONE: raise ValueError('monic polynomial required')
    a=list(a)
    for d in range(len(a)-1,len(p)-2,-1):
        for j,c in enumerate(p): a[d-(len(p)-1)+j]=sub(a[d-(len(p)-1)+j],mul(a[d],c))
    return (a+[ZERO]*(len(p)-1))[:len(p)-1]

def translate_mask(mask,t):
    return ((mask<<t)|(mask>>(16-t)))&65535 if t else mask

def affine_mask(mask,u,t):
    return sum(1<<((u*a+t)%16) for a in range(16) if mask>>a&1)

def stabilizer(mask): return [t for t in range(16) if translate_mask(mask,t)==mask]

def orbit(mask):
    ans=set()
    for u in range(1,16,2):
        b=affine_mask(mask,u,0)
        for t in range(16):
            c=translate_mask(b,t); ans.add(c); ans.add(c^65535)
    return ans

def tests():
    assert mul(root(1),root(7))==neg(ONE)
    assert mul(root(7),root(9))==ONE
    for i in range(16):
        for j in range(16): assert mul(root(i),root(j))==root(i+j)
    assert roots_poly(range(16))==[neg(ONE)]+[ZERO]*15+[ONE]
    assert roots_poly(range(0,16,2))==[neg(ONE)]+[ZERO]*7+[ONE]
    assert roots_poly(range(1,16,2))==[ONE]+[ZERO]*7+[ONE]
    assert stabilizer(255)==[0]
    assert stabilizer(0x5555)==list(range(0,16,2))
    assert poly_rem([ZERO]*8+[ONE],roots_poly(range(0,16,2)))==[ONE]+[ZERO]*7

if __name__=='__main__': tests(); print('exact ring boundary tests passed')
