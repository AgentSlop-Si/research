# Exact N16 nonperiodic remainder transfer minimum

## Result

For every eight-element subset A of Z/16Z whose additive translation stabilizer is {0}, let B be its complement. In the monomial quotient bases 1,x,...,x^7, set

    P_A(x) = product_{a in A}(x - t^a),
    R_A[i,j] = [x^i] rem(x^(8+j), P_A(x)),  0 <= i,j < 8,

and define P_B and R_B analogously. Here t is a primitive sixteenth root and all entries are computed exactly in Q[t]/(t^8+1).

The exhaustive characteristic-zero result is

    min (nnz(R_A) + nnz(R_B)) = 112.

A minimizing set is A={0,1,3,4,7,8,9,12}; its complement is B={2,5,6,10,11,13,14,15}. Both matrices have 56 nonzero entries. There are exactly 64 ordered minimizing subsets, or 32 unordered complementary pairs. They form one orbit under odd affine maps A -> uA+s modulo 16 and complementation.

This is a fresh candidate certificate submitted for separate independent review. The packet contains an independently checkable exact certificate, a self-contained alternate-method verifier, and a full direct recomputation without symmetry reduction. Independent review is a separate artifact and is not asserted here.

## Definition and provenance

The binding is Sections 2 through 4 of PHASE8_AUDIT_SOURCE.md. Its SHA-256 is c477aca2753343360a9fbdc734389741ea14a043c4dc6d8cd06e63b681fdd04d. The cited original archive is fft_hero17_phase8_multistage_crt_union_2026-10-10.zip, Library libfile_bc4996ed034481919bd8367302539890, SHA-256 63ef28d1ef4f52cc4348e8e75737ec9ef080b8e92231118a9206e2ca929b2ec3.

The already accepted GF(17) nonperiodic minimum of 94 remains a valid characteristic-zero lower bound. It is not sharp: the exact characteristic-zero minimum is 112. No historical source program was executed or imported in this work. The source report was read only to pin the mathematical definitions and accepted boundary.

## Exact zero test

Every coefficient is represented by an eight-integer vector (c0,...,c7), denoting c0+c1*t+...+c7*t^7. Multiplication uses t^8=-1. The polynomial t^8+1 is irreducible over Q: replacing t by y+1 gives an Eisenstein polynomial at 2. Thus the vector is zero in the field exactly when all eight integers are zero. Python's unbounded integers avoid overflow. There is no floating-point tolerance, sampled evaluation, or modular lifting assumption.

The divisor P_A is monic. Its root coefficients are cyclotomic integers, and every remainder computation therefore remains in Z[t]/(t^8+1). No field inversion is needed.

The generator constructs each root polynomial directly in the eight-coordinate ring and performs monic long division on x^(8+j). The verifier does not import the generator or its arithmetic. It first constructs root polynomials in the 16-coordinate cyclic group ring Z[t]/(t^16-1), then reduces coefficient pairs ck-c(k+8). It forms the transfer by repeated companion steps

    v'0 = -v7*p0,
    v'i = v(i-1) - v7*pi,  1 <= i <= 7,

where P_A=x^8+p7*x^7+...+p0. Starting at v=(1,0,...,0), the states at powers 8 through 15 are the columns of R_A. This supplies a second algorithm for the exact matrix entries.

## Coverage and symmetry proof

There are binomial(16,8)=12,870 balanced subsets. Direct enumeration yields translation stabilizer orders and counts:

- Order 1: 12,800 subsets
- Order 2: 64 subsets
- Order 4: 4 subsets
- Order 8: 2 subsets

Only the 12,800 order-one subsets belong to the requested domain. Complementation pairs them into 6,400 unordered pairs.

For an odd u, the map sigma_u:t -> t^u is a field automorphism. Write lambda=t^s. For A'=uA+s,

    P_A'(x) = lambda^8 * sigma_u(P_A)(x/lambda),
    R_A'[i,j] = lambda^(8+j-i) * sigma_u(R_A[i,j]).

The latter identity follows by substituting x/lambda in the monic remainder identity for x^(8+j). Every lambda power is nonzero and sigma_u preserves zero exactly. Therefore entry support is invariant. The same argument applies to B. Complementation exchanges the two matrices and preserves their combined support. The stabilizer of uA+s is u times the stabilizer of A, so eligibility is also invariant.

The certificate partitions the eligible domain into 70 disjoint complete orbits, always using the least integer bitmask as representative:

- 8 orbits of size 64
- 28 orbits of size 128
- 34 orbits of size 256

Their sizes sum to 12,800. The checker constructs the eligible domain independently from eight-element combinations, reconstructs every orbit independently, checks disjointness and exact coverage, and recomputes every representative matrix. The optional --full run additionally reconstructs R_A separately for every one of the 12,800 eligible subsets, without using symmetry to infer any support score.

## Complete support histogram

The exact combined support histogram on ordered eligible subsets is:

- 112 nonzeros: 64 subsets, 32 complementary pairs
- 116 nonzeros: 128 subsets, 64 complementary pairs
- 120 nonzeros: 64 subsets, 32 complementary pairs
- 124 nonzeros: 320 subsets, 160 complementary pairs
- 128 nonzeros: 12,224 subsets, 6,112 complementary pairs

The counts sum to 12,800 subsets and 6,400 pairs. Every representative's exact two root polynomials, both 8 by 8 transfer matrices, orbit members, and support counts are in certificate.json. This is a lower-bound certificate by exhaustive finite-domain coverage, with an explicit attaining witness.

## Attaining witness

For A={0,1,3,4,7,8,9,12}, the exact polynomial is

    P_A(x) = x^8 - (t^3+t^7)*x^7 - 2*t^2*x^6
             + (-t+t^5)*x^5 + (-1+t^4)*x^4
             + (t^3+t^7)*x^3 + 2*t^2*x^2
             + (t-t^5)*x - t^4.

The complementary polynomial is

    P_B(x) = x^8 + (t^3+t^7)*x^7
             + (-t+t^5)*x^5 + (1-t^4)*x^4
             + (t^3+t^7)*x^3 + (-t+t^5)*x - t^4.

Their product is x^16-1. Both sets have trivial translation stabilizer. With zero-based row and column indices, the exact zero entries are:

    R_A: (0,2), (0,6), (3,1), (3,5),
         (4,2), (4,6), (7,1), (7,5).

    R_B: (1,3), (1,7), (2,0), (2,4),
         (5,3), (5,7), (6,0), (6,4).

All other entries have a nonzero exact eight-integer vector. Hence the witness attains 56+56=112. Its canonical bitmask is 5019.

## Replay and controls

Run using Python 3 and the standard library:

    python3 check_certificate.py
    python3 check_certificate.py --full
    python3 test_corruption.py

To regenerate the certificate using the separately authored primary algorithm:

    python3 build_certificate.py

The frozen full-check log reports PASS and direct reconstruction of all 12,800 eligible subsets. The exact ring boundary tests include t^8=-1, all products of primitive-root powers, the full root polynomial, and a monic-quotient convention fixture. The stabilizer tests distinguish a trivial-stabilizer interval from an excluded periodic set. These are implementation boundary checks, not new optimization or invertibility claims.

All 19 corruption cases are rejected: altered coefficients, invented zero/nonzero entries, a floating-point coefficient, missing/duplicate orbits, omitted orbit members, ineligible representatives, out-of-range exponents, a false minimum of 94, wrong histogram, orbit size, source hash, basis, field, matrix dimension, polynomial, nonzero count, and minimizer count. The original uncorrupted certificate is accepted. See corruption_results.json for the complete case results.

## Scope

The conclusion is solely the exact N=16 minimum of literal matrix support in the specified monomial quotient bases, restricted to balanced root subsets with trivial additive translation stabilizer. It does not compare other bases, rank, arithmetic circuits, numerical stability, FFT operation counts, asymptotic complexity, or historical priority. It does not rerun or claim as new the accepted complementary-difference invertibility theorem or the parity-split global optimum. No Sheet or GitHub state was changed.
