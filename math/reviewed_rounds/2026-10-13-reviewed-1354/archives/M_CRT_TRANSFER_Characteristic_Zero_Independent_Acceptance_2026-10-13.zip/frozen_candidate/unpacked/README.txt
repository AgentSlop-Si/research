M-CRT-TRANSFER characteristic-zero N16 candidate certificate

Result: minimum 112 for balanced eight-root subsets with trivial translation
stabilizer. One witness is {0,1,3,4,7,8,9,12}; support 56+56.

Read REPORT.md, then run:
  python3 check_certificate.py
  python3 check_certificate.py --full
  python3 test_corruption.py

Only Python 3 and its standard library are required. All executable code in
this packet was newly authored for this computation. The source audit file is
provenance text, not executable historical code. The checker imports no
candidate arithmetic. Independent third-party review is a separate step.

MANIFEST.sha256 binds every included payload file. Check before replay:
  sha256sum -c MANIFEST.sha256
