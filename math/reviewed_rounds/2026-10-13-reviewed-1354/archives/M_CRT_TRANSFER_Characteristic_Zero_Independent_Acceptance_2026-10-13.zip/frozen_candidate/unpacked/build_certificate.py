#!/usr/bin/env python3
"""Fresh characteristic-zero computation. Uses only own ring16 and stdlib."""
import json, hashlib, time
from collections import Counter
from pathlib import Path
from ring16 import *
BASE=Path(__file__).resolve().parent
SOURCE=BASE/'PHASE8_AUDIT_SOURCE.md'
SOURCE_SHA='c477aca2753343360a9fbdc734389741ea14a043c4dc6d8cd06e63b681fdd04d'
def transfer(A):
    p=roots_poly(A)
    cols=[poly_rem([ZERO]*(8+j)+[ONE],p) for j in range(8)]
    return p, [[cols[j][i] for j in range(8)] for i in range(8)]
def main():
    start=time.time(); tests()
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==SOURCE_SHA
    domain={m for m in range(65536) if m.bit_count()==8}
    stable=Counter(len(stabilizer(m)) for m in domain)
    valid={m for m in domain if stabilizer(m)==[0]}
    unseen=set(valid); records=[]; hist=Counter(); minval=129; minreps=[]
    while unseen:
        m=min(unseen); o=orbit(m)
        assert o<=valid and o<=unseen
        A=[i for i in range(16) if m>>i&1]; B=[i for i in range(16) if not(m>>i&1)]
        p,ra=transfer(A); q,rb=transfer(B)
        assert poly_mul(p,q)==[neg(ONE)]+[ZERO]*15+[ONE]
        na=sum(c!=ZERO for row in ra for c in row); nb=sum(c!=ZERO for row in rb for c in row)
        score=na+nb
        records.append({'mask':m,'A':A,'orbit_size':len(o),'orbit_masks':sorted(o),'P_A':p,'P_B':q,'R_A':ra,'R_B':rb,'nnz_A':na,'nnz_B':nb,'score':score})
        hist[score]+=len(o)
        if score<minval: minval=score; minreps=[m]
        elif score==minval: minreps.append(m)
        unseen-=o
    cert={'schema':'M-CRT-TRANSFER-charzero-v1','N':16,'m':8,'field':'Q[zeta16] = Q[t]/(t^8+1)','basis':[f't^{i}' for i in range(8)],'quotient_basis':[f'x^{i}' for i in range(8)],'matrix_entry':'R_A[i][j] = coefficient x^i of rem(x^(8+j), P_A(x))','domain':'size-8 subsets A of Z/16Z with translation stabilizer {0}', 'source_sha256':SOURCE_SHA,'counts':{'balanced_subsets':len(domain),'by_stabilizer_order':dict(sorted(stable.items())),'eligible_subsets':len(valid),'eligible_unordered_pairs':len(valid)//2,'symmetry_orbits':len(records),'orbit_size_histogram':dict(sorted(Counter(r['orbit_size'] for r in records).items()))},'score_histogram_ordered_subsets':dict(sorted(hist.items())),'minimum':minval,'minimizer_orbit_representatives':minreps,'minimizer_subsets_count':hist[minval],'minimizer_unordered_pairs_count':hist[minval]//2,'records':records}
    (BASE/'certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
    print(json.dumps({k:v for k,v in cert.items() if k!='records'},indent=2))
    print('seconds',time.time()-start)
if __name__=='__main__': main()
