#!/usr/bin/env python3
"""Self-contained verifier; no imports from the candidate generator.

Arithmetic route: multiply root factors in the integer group ring C16,
reduce coefficient pairs, then form remainder columns by companion steps.
"""
import argparse, hashlib, itertools, json, sys, time
from collections import Counter
from pathlib import Path

ZERO=(0,)*8; ONE=(1,)+(0,)*7
SOURCE_SHA='c477aca2753343360a9fbdc734389741ea14a043c4dc6d8cd06e63b681fdd04d'

def require(ok, message):
    if not ok: raise ValueError(message)
def plus(a,b): return tuple(a[i]+b[i] for i in range(8))
def minus(a,b): return tuple(a[i]-b[i] for i in range(8))
def product(a,b):
    conv=[0]*16
    for i,x in enumerate(a):
        for j,y in enumerate(b): conv[i+j]+=x*y
    return tuple(conv[k]-conv[k+8] for k in range(8))
def polynomial(indices):
    group=[[1]+[0]*15]
    for a in indices:
        out=[[0]*16 for _ in range(len(group)+1)]
        for degree,coeff in enumerate(group):
            for k,value in enumerate(coeff):
                out[degree+1][k]+=value
                out[degree][(k+a)%16]-=value
        group=out
    return [tuple(c[k]-c[k+8] for k in range(8)) for c in group]
def companion_columns(p):
    v=[ONE]+[ZERO]*7
    cols=[]
    for power in range(1,16):
        high=v[7]
        v=[minus(ZERO,product(high,p[0]))]+[minus(v[i-1],product(high,p[i])) for i in range(1,8)]
        if power>=8: cols.append(v)
    return [[cols[j][i] for j in range(8)] for i in range(8)]
def tstab(A):
    return tuple(t for t in range(16) if tuple(sorted((a+t)%16 for a in A))==A)
def mask(A): return sum(2**a for a in A)
def image_orbit(A):
    universe=set(range(16)); images=set()
    for u in (1,3,5,7,9,11,13,15):
        for t in range(16):
            B={(u*a+t)%16 for a in A}
            images.add(mask(B)); images.add(mask(universe-B))
    return images

def basic_tests():
    require(product((0,1,0,0,0,0,0,0),(0,0,0,0,0,0,0,1))==(-1,0,0,0,0,0,0,0),'z^8 test')
    require(polynomial(range(16))==[(-1,0,0,0,0,0,0,0)]+[ZERO]*15+[ONE],'complete roots test')
    # Boundary fixture only, not a rerun of an optimization or rank claim.
    p=polynomial(range(0,16,2)); r=companion_columns(p)
    require(all(r[i][j]==(ONE if i==j else ZERO) for i in range(8) for j in range(8)),'monic quotient convention')
    require(tstab(tuple(range(8)))==(0,),'trivial stabilizer fixture')
    require(tstab(tuple(range(0,16,2)))==tuple(range(0,16,2)),'excluded stabilizer fixture')

def compare_matrix(raw, expected, label):
    require(type(raw) is list and len(raw)==8,label+' row count')
    for i,row in enumerate(raw):
        require(type(row) is list and len(row)==8,label+' column count')
        for j,v in enumerate(row):
            require(type(v) is list and len(v)==8 and all(type(x) is int for x in v),label+' exact vector format')
            require(tuple(v)==expected[i][j],label+f' entry {i},{j}')

def validate(c, full=False):
    basic_tests()
    require(c['schema']=='M-CRT-TRANSFER-charzero-v1','schema')
    require(c['N']==16 and c['m']==8,'size')
    require(c['field']=='Q[zeta16] = Q[t]/(t^8+1)','field')
    require(c['basis']==[f't^{i}' for i in range(8)],'field basis')
    require(c['quotient_basis']==[f'x^{i}' for i in range(8)],'quotient basis')
    require(c['matrix_entry']=='R_A[i][j] = coefficient x^i of rem(x^(8+j), P_A(x))','matrix definition')
    require(c['domain']=='size-8 subsets A of Z/16Z with translation stabilizer {0}','domain')
    require(c['source_sha256']==SOURCE_SHA,'source binding')
    universe={}; eligible={}; stabilizer_counts=Counter()
    for A in itertools.combinations(range(16),8):
        m=mask(A); universe[m]=A; s=tstab(A); stabilizer_counts[len(s)]+=1
        if s==(0,): eligible[m]=A
    require(len(universe)==12870 and len(eligible)==12800,'independent enumeration count')
    seen=set(); rep_masks=[]; scores={}; orbit_sizes=Counter(); histogram=Counter(); minimum_reps=[]; minimum=129
    for record in c['records']:
        m=record['mask']; require(type(m) is int and m in eligible,'eligible representative')
        A=eligible[m]; require(record['A']==list(A),'representative A')
        orb=image_orbit(A)
        require(m==min(orb),'canonical representative')
        require(not(seen & orb),'overlapping orbit')
        require(orb<=eligible.keys(),'ineligible orbit member')
        require(record['orbit_masks']==sorted(orb),'orbit member coverage')
        require(record['orbit_size']==len(orb),'orbit size')
        B=tuple(i for i in range(16) if i not in A)
        pa=polynomial(A); pb=polynomial(B); ra=companion_columns(pa); rb=companion_columns(pb)
        require(record['P_A']==[list(x) for x in pa],'P_A')
        require(record['P_B']==[list(x) for x in pb],'P_B')
        compare_matrix(record['R_A'],ra,'R_A'); compare_matrix(record['R_B'],rb,'R_B')
        na=sum(v!=ZERO for row in ra for v in row); nb=sum(v!=ZERO for row in rb for v in row); score=na+nb
        require((record['nnz_A'],record['nnz_B'],record['score'])==(na,nb,score),'nonzero counts')
        histogram[score]+=len(orb); orbit_sizes[len(orb)]+=1
        for mm in orb: scores[mm]=score
        if score<minimum: minimum=score; minimum_reps=[m]
        elif score==minimum: minimum_reps.append(m)
        seen|=orb; rep_masks.append(m)
    require(seen==eligible.keys(),'complete eligible domain coverage')
    require(rep_masks==sorted(rep_masks),'record order')
    stringify=lambda d:{str(k):v for k,v in sorted(d.items())}
    counts={'balanced_subsets':len(universe),'by_stabilizer_order':stringify(stabilizer_counts),'eligible_subsets':len(eligible),'eligible_unordered_pairs':len(eligible)//2,'symmetry_orbits':len(rep_masks),'orbit_size_histogram':stringify(orbit_sizes)}
    require(c['counts']==counts,'summary counts')
    require(c['score_histogram_ordered_subsets']==stringify(histogram),'support histogram')
    require(c['minimum']==minimum,'minimum')
    require(c['minimizer_orbit_representatives']==minimum_reps,'minimizer representatives')
    require(c['minimizer_subsets_count']==histogram[minimum] and c['minimizer_unordered_pairs_count']==histogram[minimum]//2,'minimizer multiplicities')
    if full:
        # No symmetry reduction in this optional recomputation. Each eligible
        # set's matrix is reconstructed independently from its own root list.
        individual={}
        for m,A in eligible.items():
            R=companion_columns(polynomial(A))
            individual[m]=sum(v!=ZERO for row in R for v in row)
        actual=Counter(individual[m]+individual[m^65535] for m in eligible)
        require(actual==histogram,'full direct histogram')
        require(all(individual[m]+individual[m^65535]==scores[m] for m in eligible),'full direct class scores')
    return {'verdict':'PASS','minimum':minimum,'minimizer_A':list(eligible[minimum_reps[0]]),'counts':counts,'score_histogram_ordered_subsets':stringify(histogram),'full_direct_recomputation':full}

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('certificate',nargs='?',default=str(Path(__file__).with_name('certificate.json'))); parser.add_argument('--full',action='store_true'); args=parser.parse_args()
    start=time.time()
    try:
        c=json.loads(Path(args.certificate).read_text()); result=validate(c,args.full)
        result['elapsed_seconds']=round(time.time()-start,3)
        print(json.dumps(result,indent=2))
    except (ValueError,KeyError,TypeError,IndexError) as error:
        print('FAIL: '+str(error),file=sys.stderr); return 1
    return 0
if __name__=='__main__': sys.exit(main())
