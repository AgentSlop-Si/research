# Hero #17 Phase8: independent CRT and fixed-cut review

Date: 2026-10-09 UTC. No uploaded program was executed or imported.

## Verdict

Accept the fixed-cut rank budget, the full-rank complementary remainder-transfer identity, and the uniqueness of the sparsest literal monomial-basis transfer. The last result returns the classical even/odd root split and radix-2 butterflies. The independent N16 exhaustive polynomial and transfer histograms match the source exactly.

One finite-field boundary claim needs correction: the optional rank-sharp decomposition with an invertible block-diagonal baseline fails at N=2 over GF(3). Its complex version is sound, and the finite-field existence argument works for N≥4 in the source's splitting prime fields. This exception does not affect the CRT theorem, sparse-transfer uniqueness, fixed-cut lower bound, or any of the source's tested Schur sizes.

These results concern particular interfaces, bases, and circuit grammars. They are not an unrestricted Fourier arithmetic lower bound, a new generic FFT speedup, or a historical-priority claim.

## Source

Library `libfile_bc4996ed034481919bd8367302539890`; `fft_hero17_phase8_multistage_crt_union_2026-10-10.zip`; 29,708 bytes; SHA-256 `63ef28d1ef4f52cc4348e8e75737ec9ef080b8e92231118a9206e2ca929b2ec3`.

All 11 source manifest entries verify. The package contains source, source-reported logs and tables, and mathematical documents. It does not contain the earlier Phase3–7 packages, so its recorded 116 predecessor passes are publisher-supplied history rather than a self-contained independently rerun regression suite. Our checks use no uploaded imports. Source dates are retained as source metadata, not authenticated execution dates.

## 1. Fixed-cut transport and rank-only sharpness

Let every stage have a decomposition `T_i=B_i+E_i`, with each B_i block diagonal relative to the same fixed cut and rank(E_i)≤r_i. The ordered telescoping formula

    T_L ... T_1 − B_L ... B_1
      = sum_i T_L ... T_(i+1) E_i B_(i−1) ... B_1

is correct without commutation or invertibility assumptions. Each term has rank at most r_i. The product of the B_i remains block diagonal, so the target's cross block has rank at most sum r_i. For the consecutive Fourier cut rows 0,...,m−1 and columns m,...,N−1, that cross block is a rectangular Vandermonde at distinct nodes. Its rank is min(m,N−m). The stated lower bound follows.

The correction rank is the rank of the entire E_i. It must not be silently replaced by one directional off-diagonal rank. Likewise the fixed cut cannot change from stage to stage without a new argument. Summing this bound over many dyadic cuts would double-count work unless a separate charging lemma is supplied. Arbitrary free basis changes, permutations moving the cut, auxiliary registers, and general circuits are outside the theorem.

For even N=2m, writing F in four m-by-m blocks A,B,C,D and H=C A^(−1)B gives a rank-m residual after subtraction of `diag(0,D−H)`. All required block invertibilities follow from consecutive-row Vandermonde structure. This proves rank sharpness, not a cheap evaluator: the blocks and dense inverse are computational objects whose cost cannot be erased.

The stronger baseline `diag(tA,D−H/(1−t))` has a rank-m residual for t≠0,1 when its lower block is invertible. Over complex numbers its determinant is a nonzero rational function, so a valid t exists. In a finite field, the polynomial in λ=(1−t)^(−1) has at most m bad roots, while permissible λ form a set of size p−2. The counting argument requires p−2>m. For N≥4 and p≥N+1 this is satisfied.

At N=2, p=3 it is not: F=[[1,1],[1,2]], and the sole allowed t=2 makes the lower baseline block zero. More strongly, every invertible diagonal baseline diag(a,b), a,b∈{1,2}, leaves F−diag(a,b) of rank two. Thus the source's unrestricted finite-field sharpness wording and its `schur_cut_certificate(2,3,2)` expectation need this exception. Our checker exhausts all four baselines without executing the source function.

## 2. Every balanced complementary remainder difference is invertible

Let N=2m and partition the distinct Fourier roots into sets A,B of size m. Let P_A and P_B be their monic root polynomials. For a coefficient vector split as `f=low+z^m high`, define R_A and R_B as the multiplication-by-z^m remainder maps in the monomial quotient bases. Then the two remainder vectors are

    low+R_A high,  low+R_B high.

The coefficient transfer is `T=[[I,R_A],[I,R_B]]`. Evaluation of each remainder at its own m roots factors the row-permuted full Fourier/Vandermonde matrix as `diag(V_A,V_B)T`. The full matrix and both V blocks are invertible; therefore T is invertible. Subtracting its first block row from its second gives the invertibility of R_B−R_A.

This is an exact all-balanced-partition theorem over a field containing N distinct roots, including the complex field. It does not depend on subgroup structure or a numerical rank heuristic. The result excludes a low-rank complementary transfer difference in this interface; it does not exclude a compact circuit for a dense, full-rank difference.

## 3. Unique minimum literal transfer support

Multiplication by z^m is invertible in either quotient, because every root is nonzero. Consequently both m-by-m matrices R_A,R_B are invertible and each contains at least m nonzero entries.

If the combined support equals 2m, both matrices are monomial. The first column of R_A is the negative vector of the lower coefficients of P_A. Its constant component is nonzero, so a one-entry first column forces all other lower coefficients to vanish: `P_A=z^m−c`. Among the roots of z^(2m)−1, the mth powers are ±1; hence A is exactly the even or odd exponent class, and B is its complement. Conversely that split gives R_A=I and R_B=−I, up to exchange.

The bound is therefore attained uniquely by the parity split, up to child exchange. The shared reductions are ordinary sum/difference butterflies. The theorem minimizes matrix entries in the specified monomial bases. It permits no conclusion that every alternative multi-stage arithmetic circuit has at least that many gates, or that a basis change is free.

## 4. Exhaustive N16 evidence independently reproduced

Our checker does not call the uploaded cyclotomic routines or transfer builders. It first multiplies in the integer ring Z[y]/(y^16−1), then reduces each coefficient modulo y^8+1. This is an exact characteristic-zero zero test in Z[ζ16]. It also verifies that each resulting polynomial reduces to the separately constructed finite-field root polynomial under ζ16→3^(−1) modulo 17.

All 12,870 eight-root subsets were checked. The exact root-polynomial support histogram is:

    support 2: 2 subsets
    support 3: 4
    support 4: 8
    support 5: 56
    support 6: 32
    support 7: 32
    support 8: 224
    support 9: 12,512

For all 6,435 unordered complementary pairs, the minimum combined polynomial support is four, attained only by parity; the nonperiodic minimum is 15, with 32 pairs at that value. Here “nonperiodic” means the root-index set has no nonzero translation stabilizer. It does not mean every possible lack of algebraic structure.

Our finite-field transfer constructor uses companion-operator powers rather than the source's long division. Every pair independently has rank(R_A)=rank(R_B)=rank(R_B−R_A)=8 over GF(17). The full transfer-support histogram matches the source, with unique minimum 16 at parity and minimum 94 over the nonperiodic pairs.

The number 94 is a valid lower bound for the corresponding characteristic-zero transfer supports: all transfer entries are cyclotomic integers, since reductions use monic polynomials; an entry nonzero after the fixed reduction to GF(17) was nonzero before reduction. A finite-field zero can be accidental, so this does not certify that the characteristic-zero minimum equals 94. The exact transfer-support equality claim should remain limited to the modular computation; the complex conclusion is a lower bound.

`SOURCE_RESULT_COMPARISON.json` records equality of all three complete source histograms with our newly generated results, rather than merely comparing their minima.

## 5. Executable branches and charged work

Static inspection confirms that the shared-binomial source evaluator is the classical recursive radix-2 DIF algorithm. Every butterfly executes one field multiplication and two additions/subtractions, including trivial twiddles. For dyadic N it has `(N/2)log2 N` butterflies and an additional N−1 products to build a supplied root's power table. A complete output vector is materialized. The unoptimized count is an attainable implementation ledger, not the minimum possible FFT operation count.

The generic evaluator constructs root polynomials by multiplying linear factors and performs ordinary monic remainder divisions. Its plan wrappers charge the products and additions used in these polynomial constructions. Building all child polynomials at every binary-tree depth requires exactly

    (3/2)(N²−N+N log2 N)

field operations in that literal builder. At N16 this is 456, matching the source plan subtotal. This quadratic setup must not be hidden by reporting only input-dependent divisions. A reusable plan may be amortized only under an explicitly repeated-input model; it remains relevant to the source's fully charged first-transform comparison.

The generic online ledger is data-dependent: zero high coefficients and zero divisor coefficients skip operations. Thus the saved N16 totals are examples for particular inputs and policies, not general worst-case constants or lower bounds. We inspected but did not execute those saved benchmark programs. Root discovery in test fixtures, modular bit complexity, indexing, allocation, and internal memory traffic are not equivalent to scalar field operations. The `inputs` and `writes` counters describe the external input/output scan, not every internal access.

Our independent conventional DIT implementation matches complete direct DFTs at nine dyadic lengths N2 through N512. A separately authored recursive transfer evaluator matches 24 additional complete arbitrary-input transforms under alternating and contiguous root partitions. These controls verify the algebraic evaluators, not source-code timing or a new asymptotic algorithm.

## 6. Ancillary claims and their exact limits

At ordinary FFT stage boundaries, each linear form has support exactly 2^s. Different stages have different support sizes; within one stage the transformation is invertible, so distinct row forms cannot be proportional. The equality-only semantic merge stop rule is correct for these stored stage wires, including the bit-reversed input ordering. It is not a claim about every temporary twiddle product or about circuits synthesizing new shared expressions. Our stage-form controls at N4 through N64 find the predicted distinct projective forms.

The dense-star counterexample is sound: first sum all inputs into one register, then add it to each of the other registers. These are 2(N−1) invertible in-place additions; the resulting dense full-rank matrix is not Fourier. Density and rank alone are therefore insufficient arithmetic lower-bound measures.

For literal complete lookup tables over GF(p), r inputs have p^r possible keys. Since an Nth root requires p≥N+1, a budget of N^c entries bounds r by a constant (indeed r<c for integer c and positive N). This is a statement about complete explicit tables; it excludes compressed or algebraic representations and does not transfer to unrestricted exact-complex arithmetic.

The unitary entropy argument is also correctly scoped. A two-row unitary update preserves the per-column sum of squared magnitudes of the two rows. Its conditional binary entropy contribution changes by at most two bits in total. The normalized Fourier matrix has potential N log2 N, yielding the historical `(N/2)log2 N` two-row gate bound. The source's floating entropy runs are illustrations, not the proof, and the bound cannot be extended to arbitrary nonunitary operations or quantum readout.

## 7. Prior art and comparator

The [official ACM record for Fiduccia's 1972 paper](https://doi.org/10.1145/800152.804900) explicitly describes evaluation via polynomial division and sparse root polynomials, including the FFT case. The [Ailon 2013 primary preprint](https://arxiv.org/abs/1305.4745) identifies the restricted two-by-two unitary model and matrix-entropy lower bound. We verified these sources; neither ingredient is new historical work here.

The current [official OpenAI Math #130 scope statement](https://github.com/openai/math/blob/main/lean/docs/130.md) distinguishes a subsequential circuit statement from a separate uniform exact-complex arithmetic bound of O(N(log N)^(1−10^(−13))), including root-order selection and scalar preparation with a chosen root supplied. The model permits unrestricted complex coefficients and does not imply a finite-field bit bound or stable numerical FFT. This review checked the stated scope, not an independent re-verification of that formalization. The narrow Phase8 obstructions do not contradict it.

## Independent replay and final disposition

In addition to the exhaustive N16 controls, our checker verifies 198 balanced CRT splits across nine lengths, all consecutive Fourier cut ranks at twelve lengths, nine fixed-cut innovation networks, finite-field sharpness witnesses and the GF(3) exception, classical FFT and generic remainder controls, stage-form non-merging, dense-star examples, and literal table-width bounds. It uses only the Python standard library. No uploaded code or predecessor suite was executed.

Accept the main scoped theorems and exact finite-width evidence. Retain the N2/GF(3) sharpness correction, literal-basis/cut restrictions, paid setup, one-direction modular support inference, and historical attributions. A general faster FFT remains unproved by this package.
