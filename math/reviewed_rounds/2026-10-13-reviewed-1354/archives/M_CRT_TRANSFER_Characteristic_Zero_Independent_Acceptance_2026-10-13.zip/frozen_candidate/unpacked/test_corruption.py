#!/usr/bin/env python3
"""Corruption tests for the fresh self-contained certificate verifier."""
import copy,json
from pathlib import Path
from check_certificate import validate
BASE=Path(__file__).resolve().parent
c=json.loads((BASE/'certificate.json').read_text())
tests=[]
def reject(name, mutate):
    cc=copy.deepcopy(c); mutate(cc)
    try: validate(cc)
    except (ValueError,KeyError,TypeError,IndexError) as e: tests.append({'test':name,'outcome':'rejected','reason':str(e)})
    else: raise AssertionError('corruption accepted: '+name)
reject('changed nonzero coefficient', lambda d:d['records'][0]['R_A'][0][0].__setitem__(0,d['records'][0]['R_A'][0][0][0]+1))
reject('invented zero', lambda d:d['records'][0]['R_A'][0].__setitem__(0,[0]*8))
reject('invented nonzero at minimizer zero', lambda d:next(r for r in d['records'] if r['mask']==5019)['R_A'][0][2].__setitem__(0,1))
reject('floating point coefficient', lambda d:d['records'][0]['R_A'][0][0].__setitem__(0,0.0))
reject('missing orbit', lambda d:d['records'].pop())
reject('duplicate orbit', lambda d:d['records'].append(copy.deepcopy(d['records'][0])))
reject('missing orbit member', lambda d:d['records'][0]['orbit_masks'].pop())
reject('ineligible representative', lambda d:d['records'][0].__setitem__('mask',21845))
reject('out of range exponent', lambda d:d['records'][0]['A'].__setitem__(0,16))
reject('false minimum94', lambda d:d.__setitem__('minimum',94))
reject('wrong score histogram', lambda d:d['score_histogram_ordered_subsets'].__setitem__('112',62))
reject('wrong orbit size', lambda d:d['records'][0].__setitem__('orbit_size',1))
reject('wrong source digest', lambda d:d.__setitem__('source_sha256','0'*64))
reject('wrong quotient basis', lambda d:d['quotient_basis'].reverse())
reject('wrong cyclotomic field', lambda d:d.__setitem__('field','Q[t]/(t^16-1)'))
reject('wrong matrix dimensions', lambda d:d['records'][0]['R_A'].pop())
reject('wrong polynomial', lambda d:d['records'][0]['P_A'][0].__setitem__(0,123))
reject('wrong nnz', lambda d:d['records'][0].__setitem__('nnz_A',0))
reject('wrong minimizer count', lambda d:d.__setitem__('minimizer_subsets_count',128))
result={'uncorrupted_certificate':validate(c)['verdict'],'corruptions_rejected':len(tests),'tests':tests}
(BASE/'corruption_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
