// Fresh independent N=16 review implementation, authored 2026-10-13.
// Uses the complementary-factor quotient identity, not a companion recurrence.
// Cyclotomic arithmetic is exact signed 64 bit integer arithmetic in Z[T]/(T^8+1).
// Root-product l1 norms are <=256; every convolution/quotient partial sum has
// absolute coefficient <=65536 (or <=131072 when adding the remainder).
// Thus these operations cannot approach signed 64 bit overflow.
#include <algorithm>
#include <cstdlib>
#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <cstdint>
#include <cassert>
using Z = int64_t;
using K = std::array<Z,8>;
using Poly = std::vector<K>;
using Matrix = std::array<std::array<K,8>,8>;
K add(K a,const K&b){for(int i=0;i<8;i++)a[i]+=b[i];return a;}
K neg(K a){for(auto &x:a)x=-x;return a;}
K mul(const K&a,const K&b){K r{};for(int i=0;i<8;i++)if(a[i]!=0)for(int j=0;j<8;j++)if(b[j]!=0){if(i+j<8)r[i+j]+=a[i]*b[j];else r[i+j-8]-=a[i]*b[j];}return r;}
K rootmul(const K&a,int e){K r{};for(int i=0;i<8;i++){int j=(i+e)%16;if(j<8)r[j]+=a[i];else r[j-8]-=a[i];}return r;}
bool nz(const K&a){for(const auto&x:a)if(x!=0)return true;return false;}
int specialize17(const K&a){Z r=0;int w=1;for(int i=0;i<8;i++){r+=a[i]*w;w=w*3%17;}return int((r%17+17)%17);}
Poly factor(unsigned mask){Poly p(1);p[0][0]=1;for(int a=0;a<16;a++)if(mask&(1u<<a)){Poly q(p.size()+1);for(size_t i=0;i<p.size();i++){q[i]=add(q[i],neg(rootmul(p[i],a)));q[i+1]=add(q[i+1],p[i]);}p=q;}return p;}
void verify_product(const Poly&p,const Poly&q){Poly c(17);for(int i=0;i<=8;i++)for(int j=0;j<=8;j++)c[i+j]=add(c[i+j],mul(p[i],q[j]));for(int i=0;i<=16;i++)for(int k=0;k<8;k++){int target=k==0?(i==16?1:(i==0?-1:0)):0;assert(c[i][k]==target);}}
Matrix transfer(const Poly&p,const Poly&q){Matrix r{};for(int j=0;j<8;j++)for(int i=0;i<8;i++)for(int ell=0;ell<=j;ell++){int pi=i-j+ell;if(pi>=0&&pi<=8)r[i][j]=add(r[i][j],neg(mul(p[pi],q[8-ell])));}return r;}
// Certify the quotient identity independently at the polynomial level for every column.
void verify_remainder(const Poly&p,const Poly&q,const Matrix&r){for(int j=0;j<8;j++){Poly identity(16);for(int ell=0;ell<=j;ell++)for(int i=0;i<=8;i++)identity[i+j-ell]=add(identity[i+j-ell],mul(p[i],q[8-ell]));for(int i=0;i<8;i++)identity[i]=add(identity[i],r[i][j]);for(int i=0;i<16;i++)for(int k=0;k<8;k++)assert(identity[i][k]==(i==8+j&&k==0?1:0));}}
unsigned transform(unsigned mask,int u,int t){unsigned r=0;for(int a=0;a<16;a++)if(mask&(1u<<a))r|=1u<<((u*a+t)&15);return r;}
bool eligible(unsigned mask){for(int t=1;t<16;t++)if(transform(mask,1,t)==mask)return false;return true;}
struct Stat{int n=0,f=0;uint64_t support=0;};
Stat stats(const Matrix&m,Z&maximum){Stat r;for(int i=0;i<8;i++)for(int j=0;j<8;j++){if(nz(m[i][j])){r.n++;r.support|=uint64_t(1)<<(8*i+j);}if(specialize17(m[i][j]))r.f++;for(const auto&v:m[i][j])if(std::abs(v)>maximum)maximum=std::abs(v);}return r;}
void emitK(std::ostream&o,const K&k){o<<'[';for(int t=0;t<8;t++){if(t)o<<',';o<<k[t];}o<<']';}
void emitM(std::ostream&o,const Matrix&m){o<<'[';for(int i=0;i<8;i++){if(i)o<<',';o<<'[';for(int j=0;j<8;j++){if(j)o<<',';emitK(o,m[i][j]);}o<<']';}o<<']';}
int main(int argc,char**argv){assert(argc==2);std::string dir=argv[1];std::ofstream csv(dir+"/all_balanced_pair_counts.csv"), witness(dir+"/independent_witness.json");csv<<"mask,complement,eligible,nnz_A,nnz_complement,total,GF17_A,GF17_complement,GF17_total,support_A,support_complement\n";std::array<Stat,65536> all{};int pairs=0,epairs=0,min=129,fmin=129;Z maxcoeff=0;std::vector<unsigned> minimizers;for(unsigned a=0;a<65536;a++){if(__builtin_popcount(a)!=8||a>(a^65535))continue;unsigned b=a^65535;auto p=factor(a),q=factor(b);verify_product(p,q);auto ra=transfer(p,q),rb=transfer(q,p);verify_remainder(p,q,ra);verify_remainder(q,p,rb);auto sa=stats(ra,maxcoeff),sb=stats(rb,maxcoeff);all[a]=sa;all[b]=sb;bool e=eligible(a);assert(e==eligible(b));pairs++;int n=sa.n+sb.n,f=sa.f+sb.f;if(e){epairs++;if(n<min){min=n;minimizers.clear();}if(n==min){minimizers.push_back(a);minimizers.push_back(b);}if(f<fmin)fmin=f;}csv<<a<<','<<b<<','<<e<<','<<sa.n<<','<<sb.n<<','<<n<<','<<sa.f<<','<<sb.f<<','<<f<<','<<sa.support<<','<<sb.support<<'\n';if(a==5019){witness<<"{\"mask\":"<<a<<",\"complement\":"<<b<<",\"P_A\":[";for(int k=0;k<=8;k++){if(k)witness<<',';emitK(witness,p[k]);}witness<<"],\"P_complement\":[";for(int k=0;k<=8;k++){if(k)witness<<',';emitK(witness,q[k]);}witness<<"],\"R_A\":";emitM(witness,ra);witness<<",\"R_complement\":";emitM(witness,rb);witness<<"}\n";}}
unsigned long symchecks=0;for(unsigned a=0;a<65536;a++)if(__builtin_popcount(a)==8&&eligible(a)){for(int u=1;u<16;u+=2)for(int t=0;t<16;t++){unsigned b=transform(a,u,t);assert(eligible(b));assert(all[a].support==all[b].support);assert(all[a^65535].support==all[b^65535].support);symchecks++;}}
std::vector<unsigned> orbit;for(int u=1;u<16;u+=2)for(int t=0;t<16;t++){unsigned b=transform(5019,u,t);orbit.push_back(b);orbit.push_back(b^65535);}std::sort(orbit.begin(),orbit.end());orbit.erase(std::unique(orbit.begin(),orbit.end()),orbit.end());std::sort(minimizers.begin(),minimizers.end());assert(orbit==minimizers);
std::ofstream out(dir+"/independent_summary.json");out<<"{\n\"method\":\"complementary factor quotient identity with bounded exact integer cyclotomic coefficients\",\n\"balanced_pairs\":"<<pairs<<",\n\"eligible_pairs\":"<<epairs<<",\n\"eligible_subsets\":"<<2*epairs<<",\n\"minimum_total\":"<<min<<",\n\"GF17_minimum\":"<<fmin<<",\n\"minimizer_subsets\":"<<minimizers.size()<<",\n\"orbit_representative\":5019,\n\"orbit_size\":"<<orbit.size()<<",\n\"symmetry_checks\":"<<symchecks<<",\n\"max_abs_transfer_basis_coefficient\":"<<maxcoeff<<",\n\"minimizers\":[";for(size_t i=0;i<minimizers.size();i++){if(i)out<<',';out<<minimizers[i];}out<<"]\n}\n";std::cout<<"PASS balanced_pairs="<<pairs<<" eligible_pairs="<<epairs<<" exact_minimum="<<min<<" GF17_minimum="<<fmin<<" minimizers="<<minimizers.size()<<" symmetry_checks="<<symchecks<<" max_coefficient="<<maxcoeff<<'\n';}
