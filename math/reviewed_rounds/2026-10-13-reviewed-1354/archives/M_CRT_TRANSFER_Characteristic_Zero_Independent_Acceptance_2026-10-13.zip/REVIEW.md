# Independent review of the exact N16 remainder transfer minimum

## Verdict

ACCEPT, with the finite-domain and fixed-basis scope below. The frozen candidate correctly certifies that the minimum of nnz(R_A) + nnz(R_Ac) is 112 over all eight-element subsets A of Z/16Z with trivial additive translation stabilizer. The field is Q(zeta16), and column j of R_A is the coefficient vector of rem(x^(8+j), P_A(x)) in the ascending basis 1,x,...,x^7. The 64 minimizing subsets comprise 32 complementary pairs and one orbit under odd affine transformations and complementation. A canonical witness is mask 5019, A={0,1,3,4,7,8,9,12}, with 56+56 nonzeros.

The candidate needs no mathematical repair within that scope. This acceptance is an independently recomputed finite exhaustive result. It is not an unrestricted arithmetic-circuit lower bound, an asymptotic algorithm, a claim about other quotient bases, a numerical-stability result, or a worldwide novelty or historical-priority determination.

## Frozen target and provenance

The reviewed candidate is M_CRT_TRANSFER_Exact_Characteristic_Zero_Minimum_Candidate_2026-10-13.zip, 137,218 bytes, SHA-256 5d7a093a94008f0fca720e7e6eaac996c1980f01993674bb4c0ea32c673d7978. Its private Library identity is libfile_8ee295d969ec81918f7421449b3baa01, version 0.

The principal payload digests are:

- certificate.json: 30425dab98ff8c7e24b9769fba7f623f7cd5b3d9f38cc235bbd15daaa96e5426
- REPORT.md: 08ca060233a14f48d3e7ec204d270fa0a6c86aa63e28847eb8ea81a107268f3b
- check_certificate.py: f8552872e58480772a2c0d3ccf7efe8d3ffa10f03864d4671751d33207f776a4
- MANIFEST.sha256: 7bfcd9c6282b8364256ea6b4f98a27c90760d574046be28099467ceb5122d6b7

All 12 manifest payload entries matched. The mathematical definition was bound to Sections 2–4 of PHASE8_AUDIT_SOURCE.md, SHA-256 c477aca2753343360a9fbdc734389741ea14a043c4dc6d8cd06e63b681fdd04d. That report was inspected as text. No historical program was executed or imported. The candidate's newly authored checker and corruption suite were statically inspected before replay. No spreadsheet, repository, sharing permission, or historical source file was changed by this review.

## Independent methods and execution order

The primary independent implementation and the arbitrary-integer replay were authored and run from the mathematical definition before inspecting the frozen candidate implementation or certificate. The candidate archive was copied, hashed, unpacked and inspected only after the author announced its freeze.

The main independent implementation is independent_quotient_certificate.cpp. It does not import or translate the candidate code. It uses the complementary-factor quotient identity, a different transfer-construction route from the candidate generator's monic long division and the candidate checker's companion recurrence.

Write P=P_A and Q=P_Ac. Since P Q=x^16-1, write their reversed polynomials as P*(y)=y^8 P(1/y) and Q*(y)=y^8 Q(1/y). Then P*(y) Q*(y)=1-y^16. Consequently the first eight coefficients of the reciprocal series 1/P*(y) equal those of Q*(y). If Q(x)=sum q_k x^k, the quotient in division of x^(8+j) by P is

    H_j(x) = sum_{ell=0}^j q_(8-ell) x^(j-ell).

Thus the remainder entries are

    R_A[i,j] = -sum_{ell=0}^j p_(i-j+ell) q_(8-ell),

where a coefficient with an index outside 0,...,8 is zero. The implementation computes this expression directly. For every balanced complementary pair it separately checks P Q=x^16-1 and, for every column of both transfer matrices, P H_j + R_j = x^(8+j), including the vanished high coefficients. Monic division makes each checked degree-below-eight remainder unique.

All ring elements use the eight-coordinate basis 1,t,...,t^7 with t^8=-1. The C++ implementation uses signed 64-bit integers, with a conservative arithmetic proof: the total coefficient l1 norm of a product of eight monic root factors is at most 2^8=256. Every P-Q convolution or quotient-construction partial sum has coefficient magnitude at most 256^2=65,536; adding a remainder for the identity check gives at most 131,072. Specialization at t=3 modulo 17 uses bounded powers and remains below 8,388,608 in magnitude under these estimates. These bounds are far below signed 64-bit limits. The largest absolute transfer-coordinate value actually encountered was 83. A complete replay compiled with undefined-behavior and signed-overflow sanitization passed and produced byte-identical count data.

The second independent program, independent_bigint_replay.py, uses Python arbitrary-precision integers, full degree-14 convolution followed by reduction, and literal monic long division. It independently reconstructed all 12,870 balanced subsets. Every individual nnz, all 64 exact support positions, and both finite-field specialization counts matched the primary computation. All coordinates of the canonical witness also matched. It imports no candidate code.

## Exact zero test

The polynomial t^8+1 is irreducible over Q. After t=y+1, all non-leading coefficients are even and the constant coefficient is 2, so Eisenstein at 2 applies. Therefore the eight coordinates are a genuine field basis, and a represented element is zero exactly when all eight integer coordinates are zero.

There is no floating-point threshold, probabilistic zero test, root approximation or finite-field reconstruction in the characteristic-zero result. Because the divisors are monic and their coefficients are cyclotomic integers, remainder computation requires no inversion or denominators. In particular, a zero cannot be lost through approximate evaluation or integer overflow.

## Domain and symmetry

All binomial(16,8)=12,870 balanced subsets were enumerated, with each complementary pair processed exactly once by the condition mask < (mask XOR 65535). The primary enumeration did not prune by affine symmetry. Eligibility was independently tested against every translation 1,...,15.

As a separate combinatorial check, any nontrivial subgroup of Z/16Z contains 8. Thus every nontrivially periodic subset is fixed by translation by 8, and an eight-element such subset is a union of four of the eight opposite-point pairs. There are binomial(8,4)=70 excluded subsets, leaving 12,800 eligible subsets and 6,400 unordered complementary pairs. Their stabilizer-order counts are 12,800 of order 1, 64 of order 2, 4 of order 4, and 2 of order 8.

For odd u and shift s, let sigma_u(t)=t^u and lambda=t^s. The root polynomial satisfies

    P_(uA+s)(x) = lambda^8 sigma_u(P_A)(x/lambda).

Substitution in the unique remainder identity gives

    R_(uA+s)[i,j] = lambda^(8+j-i) sigma_u(R_A[i,j]).

The automorphism is injective and lambda is nonzero, so every support position is invariant. The translation stabilizer is multiplied by u, preserving eligibility. Complementation exchanges the two transfer matrices. These facts justify the candidate's orbit reduction and objective invariance.

The independent program additionally checked exact support-mask equality for all 12,800 eligible sets and all 128 odd affine maps, a total of 1,638,400 checks, for both members of each complementary pair. The 64 minimizers equal the full affine-plus-complement orbit of mask 5019. The candidate's 70 disjoint orbits were independently reconstructed: 8 have size 64, 28 size 128, and 34 size 256, summing to 12,800. No symmetry assumption was needed to infer the primary enumerated scores.

## Exact result and witness

The complete histogram, stated as unordered complementary pairs, is:

- 112 nonzeros: 32 pairs
- 116 nonzeros: 64 pairs
- 120 nonzeros: 32 pairs
- 124 nonzeros: 160 pairs
- 128 nonzeros: 6,112 pairs

These total 6,400 pairs. Doubling gives the ordered-subset histogram in the candidate. This supplies the exhaustive lower bound; the witness supplies attainment.

For mask 5019, the independent witness file contains both root polynomials and all 128 transfer entries as exact eight-integer vectors. Its zero-based zero coordinates are:

    R_A: (0,2), (0,6), (3,1), (3,5),
         (4,2), (4,6), (7,1), (7,5).

    R_Ac: (1,3), (1,7), (2,0), (2,4),
          (5,3), (5,7), (6,0), (6,4).

Each matrix therefore has exactly 56 nonzeros. Both witness polynomials and every matrix coordinate agree with the frozen candidate.

## Characteristic-zero and GF17 conclusions

The former GF(17) minimum 94 is a valid lower bound for characteristic-zero support under the same domain and basis, but is not the characteristic-zero minimum. Specialization is a ring homomorphism, so an element nonzero modulo 17 was nonzero before reduction; the converse fails.

The independent complete computation at t=3 modulo 17 recovers minimum 94. There are 16 minimizing complementary pairs in this specialization, and every one has characteristic-zero total 128. The characteristic-zero minimizer has total 112 in both this specialization and characteristic zero. The older source uses t=3^(-1); changing from 3 to its inverse permutes the full domain via A -> -A, so the complete finite-field minimum is unchanged.

An explicit accidental modular zero occurs for mask 4845, A={0,2,3,5,6,7,9,12}, at R_A[0,4]. Its exact coefficient vector is (-1,-2,2,-2,-1,2,0,-2), which is nonzero in the characteristic-zero field and evaluates to zero at t=3 modulo 17. Each of the two matrices in that example has 64 exact nonzeros but only 47 after specialization.

This establishes a sharp distinction rather than merely a difference in numerical tolerance. The exact 112 result is accepted independently of all modular tests.

## Frozen certificate comparison and controls

compare_frozen_candidate.py compares the candidate directly with the independently authored arbitrary-integer arithmetic. It checks both polynomials and both matrices for each of the 70 representatives: 10,220 eight-integer vectors, or 81,760 integer coordinates. It reconstructs every orbit, verifies canonical representatives, disjointness and coverage, and compares the score of every eligible subset with the independently generated non-symmetry enumeration. All checks passed.

The candidate checker was also replayed with --full and independently returned PASS for 12,800 directly reconstructed eligible subsets. Its 19 corruption cases all rejected and its uncorrupted certificate passed. The candidate manifest remained intact after replay. This review's acceptance rests on its independent computations and mathematical checks, not on treating the author's stored logs as execution evidence.

## Reproducibility and limits

README.txt gives commands for the independent quotient computation, arbitrary-integer replay, certificate comparison and candidate controls. The package includes complete per-pair count and support data, the independent witness, source code, run results, and the exact frozen candidate archive and payload. SHA256SUMS.json binds the review payload.

All computations are finite, deterministic, exact and specific to N=16. This work does not extend the minimum to other N, other root-set restrictions, optimized circuit cost, free changes of basis, or a general FFT complexity theorem. It does not reopen the already accepted complementary-difference invertibility theorem or the unrestricted parity-split optimum. The appropriate downstream status is ACCEPT for the stated characteristic-zero minimum and its complete finite-domain certificate.
