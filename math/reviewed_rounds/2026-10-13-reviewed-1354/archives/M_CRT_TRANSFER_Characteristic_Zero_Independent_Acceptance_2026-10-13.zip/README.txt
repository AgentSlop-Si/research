M-CRT-TRANSFER exact characteristic-zero N16 independent acceptance

Read REVIEW.md for the verdict, definitions, proof checks, provenance and scope.
The result is ACCEPT: minimum 112 over 12,800 eligible subsets, with one orbit
of 64 minimizing subsets and the canonical 56+56 witness at mask 5019.

The main independent route uses the complementary-factor quotient identity;
it is not imported from either candidate computation route. A separate
arbitrary-integer long-division replay checks every balanced subset.

Reproduce from this directory without Python optimization flags:

  g++ -std=c++17 -O2 -Wall -Wextra -pedantic independent_quotient_certificate.cpp -o quotient_review
  ./quotient_review .
  python3 independent_bigint_replay.py
  python3 compare_frozen_candidate.py
  python3 frozen_candidate/unpacked/check_certificate.py --full
  python3 frozen_candidate/unpacked/test_corruption.py

Optional undefined-behavior and signed-overflow sanitizer replay:

  g++ -std=c++17 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all independent_quotient_certificate.cpp -o quotient_review_ubsan
  mkdir -p sanitizer_replay
  ./quotient_review_ubsan sanitizer_replay
  cmp all_balanced_pair_counts.csv sanitizer_replay/all_balanced_pair_counts.csv

Assertions must remain enabled: do not compile with -DNDEBUG or run Python
with -O. C++ requires a compiler compatible with the ordinary GCC/Clang
__builtin_popcount intrinsic. No Boost dependency is required. The Python
programs use only the standard library.

all_balanced_pair_counts.csv contains 6,435 rows, one per balanced unordered
complement pair, including the 35 excluded periodic pairs. Each support mask
has bit (8*i+j) set exactly when R[i,j] is nonzero. Exact support is independent
of the listed GF17 specialization values.

frozen_candidate contains the exact reviewed candidate ZIP and its extracted
payload. The author's report and fresh code are preserved unchanged. Historical
source text is provenance only; no historical source program was run.

This review was saved privately to Library. No Sheet or GitHub updates were made.
