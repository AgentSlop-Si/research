#!/usr/bin/env python3
"""Fresh Python arbitrary-integer replay of all pair counts via long division.
Does not import the candidate package or the independent C++ program.
"""
import csv,json,time,pathlib
from collections import Counter
D=pathlib.Path(__file__).resolve().parent
Z=(0,)*8; ONE=(1,)+(0,)*7

def plus(a,b):return tuple(x+y for x,y in zip(a,b))
def minus(a):return tuple(-x for x in a)
def times(a,b):
    # Ordinary degree-at-most-14 convolution followed by Phi16 reduction.
    c=[0]*15
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b):
                if y:c[i+j]+=x*y
    return tuple(c[k]-(c[k+8] if k<7 else 0) for k in range(8))
def root(a):
    v=[0]*8;v[a%8]=1 if a<8 else -1;return tuple(v)
def poly(mask):
    p=[ONE]
    for a in range(16):
        if mask>>a&1:
            q=[Z]*(len(p)+1)
            for i,c in enumerate(p):
                q[i]=plus(q[i],minus(times(c,root(a))))
                q[i+1]=plus(q[i+1],c)
            p=q
    return p

def remainder(p,n):
    # Literal independent monic polynomial long division.
    v=[Z]*n+[ONE]
    for k in range(n,7,-1):
        lead=v[k]
        if any(lead):
            for i in range(9):v[k-8+i]=plus(v[k-8+i],minus(times(lead,p[i])))
    assert all(not any(c) for c in v[8:])
    return v[:8]
def columns(p):return [remainder(p,n) for n in range(8,16)]
def support(cols):return sum(any(cols[j][i])<<(8*i+j) for i in range(8) for j in range(8))
def mod17(k):return sum(a*pow(3,i,17) for i,a in enumerate(k))%17
def main():
    start=time.time();rows=list(csv.DictReader(open(D/'all_balanced_pair_counts.csv')))
    verified=0
    for row in rows:
        for mkey,nkey,skey,fkey in [('mask','nnz_A','support_A','GF17_A'),('complement','nnz_complement','support_complement','GF17_complement')]:
            mask=int(row[mkey]);p=poly(mask);c=columns(p)
            assert sum(bool(any(x)) for col in c for x in col)==int(row[nkey]),(mask,'nnz')
            assert support(c)==int(row[skey]),(mask,'support')
            assert sum(bool(mod17(x)) for col in c for x in col)==int(row[fkey]),(mask,'GF17')
            if mask==5019:
                w=json.load(open(D/'independent_witness.json'))
                assert [list(x) for x in p]==w['P_A']
                assert [[list(c[j][i]) for j in range(8)] for i in range(8)]==w['R_A']
            verified+=1
    result={'status':'PASS','verified_balanced_subsets':verified,'method':'independent Python arbitrary-integer long division','checks':['exact nnz','complete support locations','GF17 specialization counts','full 5019 witness coefficients'],'elapsed_seconds':round(time.time()-start,3)}
    (D/'bigint_replay_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__':main()
