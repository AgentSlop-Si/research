import json,pathlib,hashlib,zipfile,datetime,shutil
P=pathlib.Path(__file__).resolve().parent;R=P.parent;Q=R/'free_singleton_proposal_0133';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(pathlib.Path(p).read_text())
ver=read(P/'FINAL_AFTER_VERIFICATION.json');assert ver['status']=='PASS'
for name in ['SOURCE_BINDINGS.json','GUARDED_DELTA.json','EXACT_REQUEST.json','PROPOSAL.md','VALIDATION.json','SOURCE_LINK_SEGMENT_CHECK.json','PUBLICATION_EDITION_CHECK.json','PUBLICATION_PROJECTION.json']:
 shutil.copyfile(Q/name,P/('REVIEWED_'+name))
summary={'status':'APPLIED_AND_FULLY_VERIFIED','spreadsheet_id':'1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU','spreadsheet_url':'https://docs.google.com/spreadsheets/d/1BHaGJHkXxf_UfZdyTKF2zrWNFzIP4IvhaqFMj-83BjU/edit','scope':'Separate free-cross-singleton reconciliation after frozen 20-note quadratic/Q29 update','applied_text_cells':12,'new_source_link_spans':12,'existing_source_link_spans_preserved_in_edited_cells':13,'pending_text_cells':0,'stable_id_guards':11,'full_native_cells_compared':19795,'unexpected_native_differences':0,'prior_three_link_repairs_preserved':True,'numeric_scores_formulas_cell_styles_history_and_existing_links_preserved':True,'batches':2,'new_cancellations':0,'new_denials':0,'source_acceptance':read(Q/'SOURCE_BINDINGS.json'),'reviewed_proposal_zip_sha256':'7921abb44ebf6204e561c444f7771f0eaf4c6741c01ec879ff85e19f66746d8b','reviewed_request_sha256':sha((Q/'EXACT_REQUEST.json').read_bytes()),'reviewed_delta_sha256':sha((Q/'GUARDED_DELTA.json').read_bytes()),'full_verification_sha256':sha((P/'FINAL_AFTER_VERIFICATION.json').read_bytes()),'completion_verified_at':ver['verified_at'],'scientific_limits':['Exact minimum 14 original banks over F23 at N=11, q=13, retaining exactly one effective alpha node in each cross-sign orientation. The two locations are independently free; all legal beta values are allowed.','The matching witness has cross locations (7,7). Equality 14 is the optimum over free locations, not an attainment assertion for every pinned pair.','The fixed (4,4) minimum 16 and all prior other-field statements remain intact.','Unrestricted orientation allocations and novelty remain unresolved; no numeric-priority or general FFT-speed change.'],'publication_edition_boundary':'Original review SHA 76c32dca199e7ab557e8e614cd3140c8da49912aaca8adda85c3acbccd96e51a and published review SHA 86f23acadb0ad7fb9b65eeb1a0e66f541e03453eef7bddff00fde67f172110e7 are distinct. Exact comparison proves only three directory-locator replacements, with mathematical text unchanged; both are bound by the published projection map.'}
(P/'APPLICATION_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(P/'README.md').write_text('''# Free-cross-singleton table reconciliation: applied and verified

14 October 2026. Twelve short dated notes were applied to the same eleven bank views and Progress. Each new review label links to the verified immutable publication edition. Two small batches each passed fresh native-cell and stable-ID guards and readback. The final full comparison covers 19,795 native cells and spreadsheet metadata, with zero unexpected differences and nothing pending.

The exact accepted optimum is 14 original banks over F23 at N=11, q=13, retaining exactly one effective alpha node per cross-sign orientation with independently free locations and arbitrary legal beta. The witness attains 14 at (7,7). This is not a claim of 14 at every pinned pair. The fixed-(4,4) minimum 16 and all earlier other-field statements remain valid. Unrestricted orientation allocations and novelty remain unresolved; numeric priorities are unchanged.

All previous text remains verbatim. All 13 existing source-link spans in edited cells were shifted to the correct UTF-16 offsets with their full formatting preserved, alongside 12 new review links. Cell formats, formulas, notes, validation and all other links are unchanged. The three earlier rich-text repairs are intact. Earlier 229-cell, 38-cell and 20-note receipts remain separate immutable records; their overlapping edit counts are not distinct-cell or discovery totals.

## Source editions

The sealed original independent review and its published edition have different byte hashes. An exact comparison found only three directory-locator replacements; all mathematical text is identical. REVIEWED_SOURCE_BINDINGS.json records the original archive/review hashes, the publication-review hash, verified immutable review URL and projection URL. REVIEWED_PUBLICATION_EDITION_CHECK.json and REVIEWED_PUBLICATION_PROJECTION.json preserve that distinction explicitly.

## Evidence

APPLICATION_SUMMARY.json binds the exact request, source versions and verification. REVIEWED_PROPOSAL.md lists the short notes by cell. REVIEWED_GUARDED_DELTA.json preserves complete before/after strings, stable IDs and requested rich-text runs. REVIEWED_SOURCE_LINK_SEGMENT_CHECK.json verifies all retained link labels, targets, formatting and offsets. BATCH_* files preserve precise requests, guards, receipts and native readbacks. BEFORE_* and FINAL_AFTER_* are lossless JSON DAG snapshots. FINAL_AFTER_VERIFICATION.json reports the complete comparison.

Included scripts perform table-data auditing only. No historical scientific program was executed by this task. No visual layout redesign was attempted or claimed. All evidence files are hashed in MANIFEST.json.
''')
files=sorted(p for p in P.iterdir() if p.is_file() and p.name not in ['MANIFEST.json','ORCHESTRATION_FUNCTIONS.json']);entries=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files];(P/'MANIFEST.json').write_text(json.dumps(entries,indent=2)+'\n')
dest=R/'Table_Free_Singleton_12_Cell_Applied_Verified_Receipt_2026-10-14.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[P/'MANIFEST.json']:z.write(p,p.name)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for e in entries:
  b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256']
seal={'archive':dest.name,'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size,'manifest_entries':len(entries),'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'APPLIED_AND_FULLY_VERIFIED','applied_text_cells':12,'new_source_link_spans':12,'retained_source_link_spans':13,'pending_text_cells':0,'full_native_cells_compared':19795,'unexpected_native_differences':0,'summary_sha256':sha((P/'APPLICATION_SUMMARY.json').read_bytes()),'verification_sha256':sha((P/'FINAL_AFTER_VERIFICATION.json').read_bytes()),'source_bindings_sha256':sha((P/'REVIEWED_SOURCE_BINDINGS.json').read_bytes())};dest.with_suffix('.zip.seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
