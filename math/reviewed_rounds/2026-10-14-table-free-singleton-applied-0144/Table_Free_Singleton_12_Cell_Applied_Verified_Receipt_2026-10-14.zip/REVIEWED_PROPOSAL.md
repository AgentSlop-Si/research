# Free-cross-singleton minimum: small table proposal

Not applied. Twelve concise dated notes update the same eleven exact bank views and Progress. The frozen 20-note update remains preserved. Every older text span, source link, numerical priority and cell format is retained. The new source label gets one immutable review link; all thirteen existing source-link spans shift intact. No historical scientific code was executed.

{
  "status": "PROPOSAL_NOT_APPLIED",
  "cells": 12,
  "signed_bank_views": 11,
  "progress_cells": 1,
  "one_note_per_view": true,
  "stable_id_guards": 11,
  "new_note_characters": 5052,
  "maximum_note_characters": 421,
  "new_source_link_spans": 12,
  "existing_source_link_spans_preserved": 13,
  "numeric_formula_cell_format_changes": 0,
  "all_old_text_and_rich_text_formats_preserved": true,
  "external_writes": 0,
  "requires_root_scope_review": true
}

The accepted optimization retains exactly one effective alpha node in each cross-sign orientation. The two locations vary independently; the lower bound does not assume they are equal. Equality 14 is attained at (7,7), not asserted for every pinned pair. Fixed (4,4) minimum 16 and the quadratic/extension-field results are separate preserved statements. Unrestricted orientation allocations and novelty remain unresolved.

## 'Catalogue'!AE10 (M-MAGNETIC-SPAN)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'Research queue'!F38 (Q35)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'Next cycle'!K10 (NEXT-MAGNETIC-SIGNED)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'New results'!D20 (NEW-17)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'novelity breakthough'!Y8 (NEW-17)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'novelity breakthough'!Y9 (M-MAGNETIC-SPAN)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'novelity breakthough'!Y10 (Q35)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'Research overview'!C10 (M-MAGNETIC-SPAN)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'Research overview'!C11 (NEW-17)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'Research overview'!C12 (Q35)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'Research overview'!C13 (NEXT-MAGNETIC-SIGNED)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

## 'Progress'!A1 (None)

[2026-10-14; free-singleton scoped review] Independent ACCEPT: minimum 14 original banks over F23, N=11, q=13, with exactly one effective alpha node in each cross-sign orientation, locations independently free and arbitrary legal beta. Attained at (7,7). Fixed (4,4) minimum 16 and other-field results remain intact. Unrestricted allocations remain open; novelty unresolved and priorities unchanged. Independent review.

Immutable review URL: https://github.com/AgentSlop-Si/research/blob/afe7229766cb596023db7998202926d8962d71df/math/reviewed_rounds/2026-10-14-free-singleton-fourteen-0127/independent_acceptance/REVIEW.md
