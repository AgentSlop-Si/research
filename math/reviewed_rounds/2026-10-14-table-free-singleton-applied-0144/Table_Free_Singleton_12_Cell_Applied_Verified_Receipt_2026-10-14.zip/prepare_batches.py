import pathlib,json,hashlib
P=pathlib.Path(__file__).resolve().parent;Q=P.parent/'free_singleton_proposal_0133'
read=lambda p:json.loads(pathlib.Path(p).read_text())
def unpack(p):
 d=read(p);o=[]
 for t,n in d['nodes']:o.append(n if t==0 else [o[i] for i in n] if t==1 else {k:o[i] for k,i in n})
 return o[d['root']]
def flatten(docs):
 out={}
 for d in docs:
  for s in d['data']['sheets']:
   for b in s.get('data',[]):
    for ri,r in enumerate(b.get('rowData',[]),b.get('startRow',0)+1):
     for ci,c in enumerate(r.get('values',[]),b.get('startColumn',0)+1):out[s['properties']['title'],ri,ci]=c
 return out
files=sorted(P.glob('BEFORE_??_PACKED.json'));assert len(files)==17
fresh=flatten([unpack(p) for p in files]);old=flatten([unpack(p) for p in sorted((P.parent/'later_table_apply_0123').glob('FINAL_AFTER_??_PACKED.json'))]);g=read(Q/'GUARDED_DELTA.json');req=read(Q/'EXACT_REQUEST.json');meta=read(P/'BEFORE_METADATA.json');assert meta==g['metadata'];assert len(fresh)==len(old)==19795
for e in g['edits']:assert fresh[e['sheet'],e['row'],e['col']]==e['before'],e['a1']
for e in g['stable_id_guards']:assert fresh[e['sheet'],e['row'],e['col']]['userEnteredValue']==e['before'],e['a1']
native=['userEnteredValue','userEnteredFormat','textFormatRuns','chipRuns','dataValidation','note','hyperlink']
batches=[];cur=[];size=0
for e,r in zip(g['edits'],req['requests']):
 sz=len(json.dumps(r).encode())
 if cur and (len(cur)>=8 or size+sz>45000):batches.append(cur);cur=[];size=0
 cur.append((e,r));size+=sz
if cur:batches.append(cur)
plan=[]
for i,batch in enumerate(batches):
 stem=f'BATCH_{i:02d}';rows=[];ids=[]
 for e,r in batch:
  rows.append({'key':[e['sheet'],e['row'],e['col']],'a1':e['a1'],'before':{k:v for k,v in e['before'].items() if k in native}})
  if e['stable_id']:
   x=next(x for x in g['stable_id_guards'] if x['sheet']==e['sheet'] and x['row']==e['row'])
   z={'key':[x['sheet'],x['row'],x['col']],'a1':x['a1'],'value':x['before']}
   if z not in ids:ids.append(z)
 request={'spreadsheet_id':req['spreadsheet_id'],'requests':[r for e,r in batch]}
 (P/(stem+'_REQUEST.json')).write_text(json.dumps(request,ensure_ascii=False))
 (P/(stem+'_GUARDS.json')).write_text(json.dumps({'targets':rows,'ids':ids,'ranges':[r['a1'] for r in rows]+[r['a1'] for r in ids]},ensure_ascii=False))
 plan.append({'batch':i,'cells':len(batch),'request_bytes':len(json.dumps(request).encode()),'a1':[e['a1'] for e,r in batch]})
(P/'BATCH_PLAN.json').write_text(json.dumps(plan,indent=2));report={'status':'PASS','full_native_cells':len(fresh),'changes_since_completed_20_checkpoint':sum(old.get(k)!=fresh.get(k) for k in set(old)|set(fresh)),'guarded_targets':len(g['edits']),'stable_id_guards':len(g['stable_id_guards']),'batches':len(batches),'text_changes':12,'all_other_fields_preserved':True};(P/'PREWRITE_VERIFICATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print(json.dumps(plan,indent=2))
