"""Fresh independent finite audit. Does not import or execute archive code."""
from itertools import product
from math import prod
from pathlib import Path
import json, hashlib

HERE = Path(__file__).resolve().parent

def matmul(a,b,p):
    cols=list(zip(*b))
    return [[sum(x*y for x,y in zip(row,col))%p for col in cols] for row in a]

def sub(a,b,p,scale=1):
    return [[(x-scale*y)%p for x,y in zip(ar,br)] for ar,br in zip(a,b)]

def elimination(matrix,p):
    a=[list(row) for row in matrix]
    r=0; determinant=1
    height=len(a); width=len(a[0]) if height else 0
    for j in range(width):
        pivots=[i for i in range(r,height) if a[i][j]%p]
        if not pivots: continue
        i=pivots[0]
        if i!=r: a[i],a[r]=a[r],a[i]; determinant=-determinant
        v=a[r][j]%p; determinant=determinant*v%p
        a[r]=[(z*pow(v,-1,p))%p for z in a[r]]
        for i in range(height):
            if i!=r:
                v=a[i][j]%p
                a[i]=[(x-v*y)%p for x,y in zip(a[i],a[r])]
        r+=1
        if r==height: break
    return r, determinant%p if height==width==r else 0

def fixture(n,p,q):
    assert pow(q,n,p)==1 and all(pow(q,j,p)!=1 for j in range(1,n))
    f=[prod(1-pow(q,j,p) for j in range(1,i+1))%p for i in range(n)]
    t=[pow(x,-1,p) for x in f]
    d=[pow(-1,i,p)*pow(q,i*(i-1)//2,p)*t[i]%p for i in range(n)]
    l=[[int(i==j+1) for j in range(n)] for i in range(n)]
    m=[[d[i] if i+j==n-1 else 0 for j in range(n)] for i in range(n)]
    mi=[[pow(d[j],-1,p) if i+j==n-1 else 0 for j in range(n)] for i in range(n)]
    h=[[t[i-j] if i>=j else 0 for j in range(n)] for i in range(n)]
    b=matmul(matmul(m,l,p),mi,p)
    assert b==[[(q-pow(q,-i,p))%p if j==i+1 else 0 for j in range(n)] for i in range(n)]
    for i,j in product(range(n),repeat=2):
        actual=f[i]*f[j]*sum(t[i-k]*d[k]*t[j-k] for k in range(min(i,j)+1))%p
        assert actual==pow(q,i*j,p)
    # Check the pair-collapse coefficient identity through degree N-1.
    f2=[prod(1-pow(q,2*j,p) for j in range(1,i+1))%p for i in range((n+1)//2)]
    for r in range(n):
        value=sum(t[i]*t[r-i]*(-1)**(r-i) for i in range(r+1))%p
        target=pow(f2[r//2],-1,p) if r%2==0 else 0
        assert value==target
    return f,t,d,l,m,h,b

source=json.loads((HERE/'VERIFICATION.json').read_text())
source_det=source_correction=source_negative=0
source_minimum=[]
for case in source['cases']:
    n,p,q=[case[k] for k in ['N','p','q']]
    f,t,d,l,m,h,b=fixture(n,p,q)
    ml=matmul(m,l,p); lm=matmul(l,m,p)
    dm=elimination(m,p)[1]
    phases=sorted({pow(q,a,p) for a in range(n)}|{2,3})
    for c in phases:
        assert elimination(sub(b,l,p,c),p)==(n,-2*pow(c,n//2,p)%p)
        assert elimination(sub(ml,lm,p,c),p)[1]==(-2*pow(c,n//2,p)*dm)%p
        source_det+=1
    ranks=[]
    polynomials=[[0]*n,[int(j==0) for j in range(n)],[int(j==1) for j in range(n)],[(j*j+3*j)%p for j in range(n)]]
    for c in sorted({1,p-1,2}):
        hc=[[t[i-j]*pow(c,i-j,p)%p if i>=j else 0 for j in range(n)] for i in range(n)]
        for a in polynomials:
            k=[[pow(c,i,p)*a[i-j]%p if i>=j else 0 for j in range(n)] for i in range(n)]
            assert matmul(k,h,p)==matmul(hc,k,p)
            e=sub(m,k,p)
            rank=elimination(e,p)[0]
            assert rank>=n//2
            corner=[row[n//2:] for row in e[:n//2]]
            assert elimination(corner,p)[0]==n//2
            ranks.append(rank); source_correction+=1
    assert min(ranks)==case['minimum_sampled_correction_rank']
    source_minimum.append({'N':n,'p':p,'q':q,'minimum_rank':min(ranks)})
    assert elimination(b,p)[1]==0
    corrupted_d=d[:]; corrupted_d[1]=2*corrupted_d[1]%p
    altered_b=[[(corrupted_d[i]*pow(corrupted_d[j],-1,p))%p if j==i+1 else 0 for j in range(n)] for i in range(n)]
    assert altered_b!=b
    assert f[1]*(t[1]+1)%p!=1
    source_negative+=3
assert source_det==source['determinant_phase_cases']==283
assert source_correction==source['transport_correction_cases']==180
for case in source['odd_dimension_controls']:
    n,p=case['N'],case['p']
    q=next(q for q in range(2,p) if pow(q,n,p)==1 and all(pow(q,j,p)!=1 for j in range(1,n)))
    _,_,_,l,_,_,b=fixture(n,p,q)
    assert elimination(sub(b,l,p),p)[1]==0
    source_negative+=1
assert source_negative==source['negative_controls']==48

# Different, exhaustive prime-field phase/root coverage.
fresh_pairs=fresh_det=0
for p in [3,5,7,11,13,17,19,23,29,31,37,41,43]:
    for n in range(2,min(p,13),2):
        if (p-1)%n: continue
        for q in range(2,p):
            if pow(q,n,p)!=1 or any(pow(q,j,p)==1 for j in range(1,n)): continue
            _,_,_,l,m,_,b=fixture(n,p,q)
            fresh_pairs+=1
            for c in range(1,p):
                assert elimination(sub(b,l,p,c),p)==(n,-2*pow(c,n//2,p)%p)
                fresh_det+=1
            assert elimination(b,p)[1]==0

# Exhaust every polynomial transporter over F5 in dimension 4.
exhaustive=0; minima=[]
for q in [2,3]:
    _,t,d,l,m,h,b=fixture(4,5,q)
    for c in range(1,5):
        minimum=4; witness=None
        for a in product(range(5),repeat=4):
            k=[[pow(c,i,5)*a[i-j]%5 if i>=j else 0 for j in range(4)] for i in range(4)]
            rank=elimination(sub(m,k,5),5)[0]
            assert rank>=2
            if rank<minimum: minimum=rank; witness=a
            exhaustive+=1
        minima.append({'q':q,'c':c,'minimum_rank':minimum,'witness':witness})

# Audit the dimension of the full linear solution space, not just sampled K.
space_cases=[]
for n,p,q in [(2,5,4),(4,5,2),(6,7,3),(8,17,2)]:
    _,t,_,_,_,h,_=fixture(n,p,q)
    for c in [1,p-1,2]:
        hc=[[t[i-j]*pow(c,i-j,p)%p if i>=j else 0 for j in range(n)] for i in range(n)]
        equations=[]
        for i,j in product(range(n),repeat=2):
            equations.append([((h[b][j] if i==a else 0)-(hc[i][a] if b==j else 0))%p for a,b in product(range(n),repeat=2)])
        dimension=n*n-elimination(equations,p)[0]
        assert dimension==n
        space_cases.append({'N':n,'p':p,'q':q,'c':c,'dimension':dimension})

# Odd-size controls: determinant vanishes but corner-rank proof still applies.
odd_controls=[]
for n,p,q in [(3,7,2),(5,11,3),(7,29,7)]:
    _,_,_,l,m,_,b=fixture(n,p,q)
    assert elimination(sub(b,l,p),p)[1]==0
    odd_controls.append({'N':n,'p':p,'q':q,'defect_rank':elimination(sub(b,l,p),p)[0]})

report={'status':'PASS','archive_code_executed':False,
        'source_report_counts_freshly_reproduced':{'determinant_phase_cases':source_det,'transport_correction_cases':source_correction,'negative_controls':source_negative},
        'additional_exhaustive_primitive_root_field_size_cases':fresh_pairs,
        'additional_all_nonzero_phase_determinants':fresh_det,
        'exhaustive_F5_dimension4_transporter_cases':exhaustive,
        'exhaustive_F5_minima':minima,'full_transport_space_dimension_cases':space_cases,
        'source_minimum_ranks_reproduced':source_minimum,'odd_controls':odd_controls,
        'conclusion':'Finite checks support the independently audited algebraic proof; they are not an asymptotic proof.'}
(HERE/'INDEPENDENT_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
