#!/usr/bin/env python3
"""Exact finite checks accompanying PROOF.txt. Standard library only.

This is a small, dense mathematical verifier, NOT a proposed fast FFT.
Run: python3 verify_transport.py --output VERIFICATION.json
"""
import argparse
import json
from pathlib import Path


def zero(n):
    return [[0] * n for _ in range(n)]


def identity(n):
    a = zero(n)
    for i in range(n):
        a[i][i] = 1
    return a


def mul(a, b, p):
    n = len(a)
    out = zero(n)
    for i in range(n):
        for k in range(n):
            if a[i][k]:
                for j in range(n):
                    out[i][j] = (out[i][j] + a[i][k] * b[k][j]) % p
    return out


def difference(a, b, c, p):
    return [[(x - c * y) % p for x, y in zip(ar, br)]
            for ar, br in zip(a, b)]


def rank(a, p):
    a = [row[:] for row in a]
    n = len(a)
    r = 0
    for col in range(n):
        pivot = next((i for i in range(r, n) if a[i][col]), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        inv = pow(a[r][col], -1, p)
        for j in range(col, n):
            a[r][j] = a[r][j] * inv % p
        for i in range(r + 1, n):
            factor = a[i][col]
            for j in range(col, n):
                a[i][j] = (a[i][j] - factor * a[r][j]) % p
        r += 1
    return r


def determinant(a, p):
    a = [row[:] for row in a]
    n = len(a)
    d = 1
    for col in range(n):
        pivot = next((i for i in range(col, n) if a[i][col]), None)
        if pivot is None:
            return 0
        if pivot != col:
            a[col], a[pivot] = a[pivot], a[col]
            d = -d
        v = a[col][col]
        d = d * v % p
        inv = pow(v, -1, p)
        for i in range(col + 1, n):
            factor = a[i][col] * inv % p
            for j in range(col, n):
                a[i][j] = (a[i][j] - factor * a[col][j]) % p
    return d % p


def primitive_root_of_order(n, p):
    # Only test-fixture preparation; no cost claim is based on this search.
    assert (p - 1) % n == 0
    divisors = [d for d in range(1, n) if n % d == 0]
    for a in range(2, p):
        q = pow(a, (p - 1) // n, p)
        if pow(q, n, p) == 1 and all(pow(q, d, p) != 1 for d in divisors):
            return q
    raise AssertionError("No root of the requested order")


def matrices(n, p):
    q = primitive_root_of_order(n, p)
    f = [1]
    for j in range(1, n):
        f.append(f[-1] * (1 - pow(q, j, p)) % p)
    t = [pow(v, -1, p) for v in f]
    d = [((-1) ** j) * pow(q, j * (j - 1) // 2, p) * t[j] % p
         for j in range(n)]
    lower = zero(n)
    middle = zero(n)
    middle_inv = zero(n)
    kernel = zero(n)
    for i in range(n):
        middle[i][n - 1 - i] = d[i]
        middle_inv[n - 1 - i][i] = pow(d[i], -1, p)
        if i:
            lower[i][i - 1] = 1
        for j in range(i + 1):
            kernel[i][j] = t[i - j]
    assert mul(middle, middle_inv, p) == identity(n)
    return q, f, t, d, lower, middle, middle_inv, kernel


def check_even(n, p):
    q, f, t, d, lower, middle, middle_inv, kernel = matrices(n, p)
    # Construct B from the original d_j and conjugation, independently of
    # the claimed superdiagonal formula and claimed determinant formula.
    ml = mul(middle, lower, p)
    lm = mul(lower, middle, p)
    b = mul(ml, middle_inv, p)
    expected_b = zero(n)
    for i in range(n - 1):
        expected_b[i][i + 1] = (q - pow(q, -i, p)) % p
    assert b == expected_b

    # All matrix entries of the Fourier factorization, not one sample input.
    left = [[f[i] * kernel[i][j] * d[j] % p for j in range(n)]
            for i in range(n)]
    right = [[kernel[j][i] * f[j] % p for j in range(n)]
             for i in range(n)]
    fourier = [[pow(q, i * j, p) for j in range(n)] for i in range(n)]
    assert mul(left, right, p) == fourier

    phases = sorted({pow(q, a, p) for a in range(n)} | {2, 3})
    det_m = determinant(middle, p)
    for c in phases:
        defect = difference(b, lower, c, p)
        assert rank(defect, p) == n
        assert determinant(defect, p) == (-2 * pow(c, n // 2, p)) % p
        original_defect = difference(ml, lm, c, p)
        assert determinant(original_defect, p) == (
            -2 * pow(c, n // 2, p) * det_m) % p

    # Valid transporters K=diag(c^i) P(L), including singular and zero K.
    polynomials = [[0] * n, [1] + [0] * (n - 1),
                   [0, 1] + [0] * (n - 2),
                   [(j * j + 3 * j) % p for j in range(n)]]
    correction_ranks = []
    for c in sorted({1, p - 1, 2}):
        shifted_kernel = [[pow(c, i - j, p) * t[i - j] % p
                           if i >= j else 0 for j in range(n)]
                          for i in range(n)]
        for coefficients in polynomials:
            k = [[pow(c, i, p) * coefficients[i - j] % p
                  if i >= j else 0 for j in range(n)] for i in range(n)]
            assert mul(k, kernel, p) == mul(shifted_kernel, k, p)
            assert difference(mul(k, lower, p), mul(lower, k, p), c, p) == zero(n)
            correction = difference(middle, k, 1, p)
            r = rank(correction, p)
            assert 2 * r >= n
            correction_ranks.append(r)

    # Boundary control: c=0 does not satisfy the nonzero determinant claim.
    assert determinant(b, p) == 0
    # Mutation controls: the checks must reject a changed middle coefficient
    # and a changed coefficient in the actual Fourier kernel.
    wrong_middle = [row[:] for row in middle]
    wrong_middle[1][n - 2] = (2 * wrong_middle[1][n - 2]) % p
    wrong_inv = [row[:] for row in middle_inv]
    wrong_inv[n - 2][1] = wrong_inv[n - 2][1] * pow(2, -1, p) % p
    assert mul(mul(wrong_middle, lower, p), wrong_inv, p) != expected_b
    wrong_left = [row[:] for row in left]
    wrong_left[1][0] = (wrong_left[1][0] + f[1] * d[0]) % p
    assert mul(wrong_left, right, p) != fourier
    return {"N": n, "p": p, "q": q, "determinant_phase_cases": len(phases),
            "transport_correction_cases": len(correction_ranks),
            "minimum_sampled_correction_rank": min(correction_ranks),
            "proved_lower_bound": n // 2, "negative_controls": 3}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("VERIFICATION.json"))
    args = parser.parse_args()
    cases = ([(n, 97) for n in (2, 4, 6, 8, 12, 16, 24, 32)]
             + [(n, 241) for n in (10, 20, 30)]
             + [(n, 337) for n in (14, 28)]
             + [(n, 65537) for n in (16, 32)])
    results = [check_even(n, p) for n, p in cases]
    odd_controls = []
    for n, p in [(3, 97), (5, 241), (7, 337)]:
        _, _, _, _, lower, middle, middle_inv, _ = matrices(n, p)
        b = mul(mul(middle, lower, p), middle_inv, p)
        assert determinant(difference(b, lower, 1, p), p) == 0
        odd_controls.append({"N": n, "p": p, "determinant": 0})
    report = {"status": "PASS", "arithmetic": "exact prime-field arithmetic",
              "new_sub_fft_algorithm": False,
              "checks_are_not_an_asymptotic_proof": True,
              "even_size_field_cases": len(results),
              "determinant_phase_cases": sum(x["determinant_phase_cases"] for x in results),
              "transport_correction_cases": sum(x["transport_correction_cases"] for x in results),
              "negative_controls": sum(x["negative_controls"] for x in results) + len(odd_controls),
              "cases": results, "odd_dimension_controls": odd_controls}
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("cases", "odd_dimension_controls")}, indent=2))


if __name__ == "__main__":
    main()
