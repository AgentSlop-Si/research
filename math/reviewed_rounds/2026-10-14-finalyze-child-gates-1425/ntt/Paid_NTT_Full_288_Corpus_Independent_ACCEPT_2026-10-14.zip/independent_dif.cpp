// Fresh independent reviewer: natural-input decimation-in-frequency NTT.
// Authored without viewing the producer implementation. No inherited code used.
#include <algorithm>
#include <array>
#include <chrono>
#include <climits>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
using U=std::uint32_t; using W=std::uint64_t;
constexpr U P=998244353, G=3; constexpr std::size_t CAP=262144;
static W assertions=0,butterflies=0,pow_calls=0,ntt_calls=0,direct_coordinates=0,closed_coordinates=0,negatives=0;
void need(bool ok,const std::string& s){++assertions;if(!ok)throw std::runtime_error(s);}
U add(U a,U b){U c=a+b;return c>=P?c-P:c;}
U sub(U a,U b){return a>=b?a-b:a+P-b;}
U mul(U a,U b){return U(W(a)*b%P);}
U power(U a,W e){++pow_calls;U r=1;for(;e;e>>=1,a=mul(a,a))if(e&1)r=mul(r,a);return r;}
void guard_length(std::int64_t n){if(n<2||n>std::int64_t(CAP)||(n&(n-1))||((P-1)%n))throw std::invalid_argument("length");}
U root(std::size_t n){guard_length(std::int64_t(n));U r=power(G,(P-1)/n);need(power(r,n)==1&&power(r,n/2)==P-1,"root exact order");if(n>=4)need(mul(power(r,n/4),power(r,n/4))==P-1,"quarter root");return r;}
std::size_t reverse_bits(std::size_t x,unsigned bits){std::size_t r=0;for(unsigned k=0;k<bits;++k){r=2*r+(x&1);x>>=1;}return r;}
std::vector<U> dif(const std::vector<U>& input){
 guard_length(std::int64_t(input.size()));for(U x:input)if(x>=P)throw std::invalid_argument("noncanonical");
 std::size_t n=input.size();need(n<=std::numeric_limits<std::size_t>::max()/sizeof(U),"byte representability");
 ++ntt_calls;std::vector<U> v=input;unsigned bits=0;for(std::size_t t=n;t>1;t>>=1)++bits;
 for(std::size_t width=n;width>=2;width>>=1){
  U step=root(width);std::size_t half=width/2;
  for(std::size_t begin=0;begin<n;begin+=width){
   U phase=1;for(std::size_t j=0;j<half;++j){U a=v[begin+j],b=v[begin+j+half];v[begin+j]=add(a,b);v[begin+j+half]=mul(sub(a,b),phase);phase=mul(phase,step);++butterflies;}
  }
 }
 // DIF produces the frequencies in bit-reversed order. Scatter into natural order.
 std::vector<U> ordered(n);for(std::size_t i=0;i<n;++i)ordered[reverse_bits(i,bits)]=v[i];return ordered;
}
U direct(const std::vector<U>& x,std::size_t k){U r=power(G,(P-1)/x.size()),point=power(r,k),value=0;for(std::size_t j=x.size();j-->0;)value=add(mul(value,point),x[j]);++direct_coordinates;return value;}
bool equal(const std::vector<U>& a,const std::vector<U>& b){if(a.size()!=b.size())return false;for(std::size_t i=0;i<a.size();++i)if(a[i]>=P||b[i]>=P||a[i]!=b[i])return false;return true;}
void reject_controls(){
 for(std::int64_t n:{-1LL,0LL,1LL,3LL,6LL,262145LL,8388609LL,16777216LL}){bool caught=false;try{guard_length(n);}catch(const std::invalid_argument&){caught=true;}need(caught,"bad length accepted");++negatives;}
 for(U x:{P,P+1,std::numeric_limits<U>::max()}){bool caught=false;try{(void)dif({x,0});}catch(const std::invalid_argument&){caught=true;}need(caught,"bad residue accepted");++negatives;}
 for(std::size_t n:{2U,4U}){W count=1;for(std::size_t i=0;i<n;++i)count*=3;for(W c=0;c<count;++c){W t=c;std::vector<U>x(n);for(auto&v:x){v=std::array<U,3>{0,1,P-1}[t%3];t/=3;}auto y=dif(x);for(std::size_t k=0;k<n;++k)need(y[k]==direct(x,k),"exhaustive small");}}
 std::vector<U>x={1,2,7,11,13,19,23,29};auto y=dif(x);
 need(y[0]==105,"literal DC");for(std::size_t k=0;k<x.size();++k)need(y[k]==direct(x,k),"literal asymmetric anchor");
 auto bad=y;bad[1]=add(bad[1],1);need(!equal(bad,y),"single mutation");++negatives;
 bad=y;bad[1]=add(bad[1],1);bad[2]=sub(bad[2],1);need(!equal(bad,y),"sum-preserving mutation");++negatives;
 bad=y;std::reverse(bad.begin()+1,bad.end());need(!equal(bad,y),"wrong sign");++negatives;
 bad=y;U inv=power(U(x.size()),P-2);for(auto&v:bad)v=mul(v,inv);need(!equal(bad,y),"wrong normalization");++negatives;
 bad=y;for(std::size_t i=0;i<8;++i)bad[i]=y[reverse_bits(i,3)];need(!equal(bad,y),"wrong order");++negatives;
 bad=y;bad.pop_back();need(!equal(bad,y),"short output");++negatives;
 bad=y;bad.push_back(0);need(!equal(bad,y),"long output");++negatives;
 bad=y;bad[0]=P;need(!equal(bad,y),"noncanonical output");++negatives;
 bad=y;for(auto&v:bad)v=((v&255)<<24)|((v&65280)<<8)|((v>>8)&65280)|(v>>24);need(!equal(bad,y),"wrong endian");++negatives;
}
U read_word(std::istream& in){unsigned char b[4];in.read(reinterpret_cast<char*>(b),4);if(in.gcount()!=4)throw std::runtime_error("short wire");U x=U(b[0])|(U(b[1])<<8)|(U(b[2])<<16)|(U(b[3])<<24);if(x>=P)throw std::runtime_error("noncanonical wire");return x;}
void write_word(std::ostream& out,U x){need(x<P,"noncanonical output wire");unsigned char b[4]={static_cast<unsigned char>(x),static_cast<unsigned char>(x>>8),static_cast<unsigned char>(x>>16),static_cast<unsigned char>(x>>24)};out.write(reinterpret_cast<const char*>(b),4);if(!out)throw std::runtime_error("output I/O");}
int main(int argc,char**argv){try{
 need(argc==4,"arguments: input output per_vector_tsv");need(CHAR_BIT==8&&sizeof(U)==4&&sizeof(W)==8&&sizeof(int)==4,"integer widths");
 for(U d=2;W(d)*d<=P;++d)need(P%d!=0,"modulus composite");
 need((W(1)<<23)*7*17==P-1,"p-1 factorization");for(U d:{2U,7U,17U})need(power(G,(P-1)/d)!=1,"generator order");
 reject_controls();
 std::ifstream in(argv[1],std::ios::binary);std::ofstream out(argv[2],std::ios::binary);std::ofstream log(argv[3]);need(bool(in)&&bool(out)&&bool(log),"file open");
 log<<"index\tn\tcase_index\tcoordinates\tdirect_checks\tclosed_form_coordinates\n";
 W vectors=0,coords=0,newcoords=0,fullcompares=0;
 for(unsigned e=1;e<=18;++e){std::size_t n=std::size_t(1)<<e;U w=root(n);
  for(unsigned c=0;c<16;++c){std::vector<U>x(n);for(U&v:x)v=read_word(in);const auto original=x;auto y=dif(x);need(x==original,"input changed");
   need(y.size()==n,"output length");for(U v:y)need(v<P,"output range");
   W d0=direct_coordinates,h0=closed_coordinates;
   if(n<=256){for(std::size_t k=0;k<n;++k)need(y[k]==direct(x,k),"full small direct mismatch");}
   else for(std::size_t k:std::array<std::size_t,5>{0,1,n/3,n/2,n-1})need(y[k]==direct(x,k),"large direct-coordinate mismatch");
   if(c<7){std::size_t pos=c==4?1:c==5?n/3:0;U step=power(w,pos),phase=1;for(std::size_t k=0;k<n;++k){U expected=0;
     if(c==1&&k==0)expected=U(n);
     if(c==2&&k==0)expected=P-U(n);
     if(c>=3&&c<=5){expected=phase;phase=mul(phase,step);}
     if(c==6&&k==n/2)expected=U(n);
     need(y[k]==expected,"complete closed form");++closed_coordinates;
    }}
   U sum=0;for(U v:y)sum=add(sum,v);need(sum==mul(U(n),x[0]),"output sum");U sx=0;for(U v:x)sx=add(sx,v);need(y[0]==sx,"DC");
   auto yy=dif(y);for(std::size_t k=0;k<n;++k){need(yy[k]==mul(U(n),x[(n-k)%n]),"F+ squared");++fullcompares;}
   auto reversed=y;std::reverse(reversed.begin()+1,reversed.end());auto inv=dif(reversed);U scale=power(U(n),P-2);for(std::size_t k=0;k<n;++k){need(mul(inv[k],scale)==x[k],"inverse roundtrip");++fullcompares;}
   // Exact one-coordinate corruption at each vector endpoint and one interior point.
   for(std::size_t k:std::array<std::size_t,3>{0,n/2,n-1}){auto changed=y;changed[k]=add(changed[k],1);need(!equal(changed,y),"corruption undetected");++negatives;}
   for(U v:y)write_word(out,v);
   log<<vectors<<'\t'<<n<<'\t'<<c<<'\t'<<n<<'\t'<<direct_coordinates-d0<<'\t'<<closed_coordinates-h0<<'\n';
   if(vectors>=160)newcoords+=n;
   coords+=n;++vectors;
  }
 }
 char extra;need(!in.get(extra),"long wire");out.flush();log.flush();need(bool(out)&&bool(log),"final flush");
 std::cout<<"{\"status\":\"PASS\",\"vectors\":"<<vectors<<",\"coordinates\":"<<coords<<",\"new_coordinates\":"<<newcoords<<",\"new_vectors\":128,\"assertions\":"<<assertions<<",\"negative_controls\":"<<negatives<<",\"direct_coordinates\":"<<direct_coordinates<<",\"closed_form_coordinates\":"<<closed_coordinates<<",\"roundtrip_coordinates\":"<<fullcompares<<",\"transform_calls\":"<<ntt_calls<<",\"butterflies\":"<<butterflies<<",\"modular_power_calls\":"<<pow_calls<<",\"char_bit\":"<<CHAR_BIT<<",\"uint32_bytes\":"<<sizeof(U)<<",\"uint64_bytes\":"<<sizeof(W)<<",\"int_bytes\":"<<sizeof(int)<<"}\n";
 return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}}
