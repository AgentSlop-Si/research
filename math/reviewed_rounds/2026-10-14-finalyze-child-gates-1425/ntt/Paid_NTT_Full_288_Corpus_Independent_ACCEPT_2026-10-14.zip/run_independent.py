"""Fresh bounded launcher and inert input integrity audit. No producer code is run."""
import array,datetime,hashlib,json,pathlib,resource,subprocess,sys,time
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent
SOURCE=ROOT/'paid_ntt_contract_v2_1622'
P=998244353
CPU=180; AS=512*1024*1024; FS=64*1024*1024

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def caps():
 resource.setrlimit(resource.RLIMIT_CPU,(CPU,CPU))
 resource.setrlimit(resource.RLIMIT_AS,(AS,AS))
 resource.setrlimit(resource.RLIMIT_FSIZE,(FS,FS))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))

caps()
manifest=json.loads((SOURCE/'CORPUS_MANIFEST.json').read_text())
protocol=json.loads((SOURCE/'PROTOCOL.json').read_text())
assert digest(SOURCE/'PROTOCOL.json')=='e97f0f3da08ed17804169262fb8f31872032f53ab708091419af4b2eec28f3dd'
assert manifest['sha256']=='f07e9e1c550420ae431ee64a60e73449b1dcffce105bf452653972dbb7a7bba7'
assert digest(SOURCE/'corpus_inputs.bin')==manifest['sha256']
assert manifest['bytes']==33554304==(SOURCE/'corpus_inputs.bin').stat().st_size
assert manifest['modulus']==protocol['modulus']==P
assert protocol['primitive_root']==3
assert manifest['lengths']==[2**e for e in range(1,19)]
cases=['zero','ones','minus_ones','impulse_0','impulse_1','impulse_floor_n3','alternating','ramp']+['dense_'+str(i) for i in range(8)]
assert manifest['case_ids']==cases and len(manifest['vectors'])==288
pos=0; bindings=[]
with (SOURCE/'corpus_inputs.bin').open('rb') as f:
 for index,v in enumerate(manifest['vectors']):
  n=2**(1+index//16);c=index%16
  assert v['n']==n and v['case']==cases[c]
  assert v['offset_bytes']==pos and v['length_bytes']==4*n
  wire=f.read(4*n);assert len(wire)==4*n and hashlib.sha256(wire).hexdigest()==v['sha256']
  vals=array.array('I');vals.frombytes(wire)
  assert vals.itemsize==4
  if sys.byteorder!='little':vals.byteswap()
  assert len(vals)==n and all(x<P for x in vals)
  if c==0:assert all(x==0 for x in vals)
  elif c in (1,2):assert all(x==(1 if c==1 else P-1) for x in vals)
  elif c in (3,4,5):
   at=0 if c==3 else 1 if c==4 else n//3
   assert all(x==int(j==at) for j,x in enumerate(vals))
  elif c==6:assert all(x==(1 if j%2==0 else P-1) for j,x in enumerate(vals))
  elif c==7:assert all(x==j for j,x in enumerate(vals))
  bindings.append({'index':index,'n':n,'case':v['case'],'sha256':v['sha256'],'all_coefficients_canonical':True})
  pos+=4*n
 assert f.read(1)==b''
assert pos==33554304
prior=[('paid_ntt_oracle_candidate_1751/tiny_expected_outputs.bin','1401cb324cf991f4eb69db4e962f78f3d2881b5bb9116d8fd629a08f04134091',32640),('paid_ntt_extension_candidate_2013/extension_expected_outputs.bin','7ad3b732c3be717408ca2634a86a1518530225bd6428de043410655bc527863f',98304)]
for path,sha,length in prior:assert digest(ROOT/path)==sha and (ROOT/path).stat().st_size==length
input_files=[SOURCE/'CORPUS_MANIFEST.json',SOURCE/'PROTOCOL.json',SOURCE/'PAID_NTT_CONTRACT.md',SOURCE/'corpus_inputs.bin']+[ROOT/p for p,_,_ in prior]
input_hashes={str(p.relative_to(ROOT)):digest(p) for p in input_files}
(HERE/'INPUT_BINDINGS.json').write_text(json.dumps({'status':'PASS','inputs':input_hashes,'vectors':bindings},indent=2)+'\n')
exe=HERE/'independent_dif';output=HERE/'independent_expected_outputs.bin';tsv=HERE/'PER_VECTOR.tsv'
seal={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_source_read':False,'source_hash':digest(HERE/'independent_dif.cpp'),'launcher_hash':digest(pathlib.Path(__file__)),'executable_hash':digest(exe),'input_hashes':input_hashes,'caps':{'cpu_seconds':CPU,'address_space_bytes':AS,'file_size_bytes':FS,'core_bytes':0},'argv':[str(exe),str(SOURCE/'corpus_inputs.bin'),str(output),str(tsv)],'compiler':'g++ (Debian 14.2.0-19) 14.2.0','compile_arguments':['-std=c++17','-O2','-Wall','-Wextra','-Wpedantic']}
(HERE/'PREEXECUTION_SEAL.json').write_text(json.dumps(seal,indent=2)+'\n')
start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
with (HERE/'RUN_STDOUT.json').open('wb') as out,(HERE/'RUN_STDERR.log').open('wb') as err:
 proc=subprocess.run(seal['argv'],stdout=out,stderr=err,preexec_fn=caps,timeout=240)
end=time.monotonic();after=resource.getrusage(resource.RUSAGE_CHILDREN)
receipt={'exit_code':proc.returncode,'wall_seconds':end-start,'user_cpu_seconds':after.ru_utime-before.ru_utime,'system_cpu_seconds':after.ru_stime-before.ru_stime,'max_rss_kib':after.ru_maxrss,'limits':seal['caps'],'measurements_are_verifier_resources_not_transform_benchmark':True}
(HERE/'EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert proc.returncode==0,(HERE/'RUN_STDERR.log').read_text()
result=json.loads((HERE/'RUN_STDOUT.json').read_text());assert result['status']=='PASS'
assert result['vectors']==288 and result['coordinates']==8388576 and result['new_coordinates']==8355840
assert output.stat().st_size==33554304
with output.open('rb') as f:
 for path,sha,length in prior:assert f.read(length)==(ROOT/path).read_bytes()
for p in input_files:assert digest(p)==input_hashes[str(p.relative_to(ROOT))]
result.update({'output_sha256':digest(output),'output_bytes':output.stat().st_size,'previous_160_output_vectors_byte_identical':True,'all_inputs_unchanged':True,'corpus_bindings_verified':288,'execution':receipt})
(HERE/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
