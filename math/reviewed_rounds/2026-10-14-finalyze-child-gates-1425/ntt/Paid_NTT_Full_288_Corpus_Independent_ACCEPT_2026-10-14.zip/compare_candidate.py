"""Compare every independently reconstructed coordinate; producer code stays inert."""
import array,hashlib,json,pathlib,resource,sys
for key,cap in [(resource.RLIMIT_CPU,180),(resource.RLIMIT_AS,512*2**20),(resource.RLIMIT_FSIZE,64*2**20),(resource.RLIMIT_CORE,0)]:resource.setrlimit(key,(cap,cap))
H=pathlib.Path(__file__).resolve().parent;R=H.parent;C=R/'ntt_full_frozen_corpus_candidate_1414'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def values(wire,n):
 assert len(wire)==4*n
 a=array.array('I');a.frombytes(wire)
 assert a.itemsize==4
 if sys.byteorder!='little':a.byteswap()
 assert len(a)==n and all(v<998244353 for v in a)
 return a
expected_code={'src/fresh_radix4.cpp':'5137ca0470688b54a4913ed30bfc0219ba753b57f47898e233e852a24bc0a8a9','replay_candidate.py':'6a7465a2dd51ad39dde5b6a24e222364ec56a328468f5e693d4a0d5933bc4898'}
for f,h in expected_code.items():assert sha(C/f)==h
m=json.loads((R/'paid_ntt_contract_v2_1622/CORPUS_MANIFEST.json').read_text())
claimed=json.loads((C/'PER_VECTOR_RESULTS.json').read_text());assert len(claimed)==288
candidate=C/'artifacts/full_expected_outputs.bin';independent=H/'independent_expected_outputs.bin'
assert candidate.stat().st_size==independent.stat().st_size==33554304
rows=[];coords=0
with candidate.open('rb') as ca, independent.open('rb') as ine:
 for index,entry in enumerate(m['vectors']):
  n=entry['n'];a=ca.read(4*n);b=ine.read(4*n);av=values(a,n);bv=values(b,n)
  assert len(av)==len(bv)==n
  for k,(x,y) in enumerate(zip(av,bv)):
   assert x==y,(index,n,k,x,y)
  assert a==b
  rec=claimed[index]
  for key,want in [('index',index),('n',n),('case',entry['case']),('offset_bytes',entry['offset_bytes']),('length_bytes',4*n),('input_sha256',entry['sha256']),('output_sha256',hashlib.sha256(a).hexdigest()),('canonical_coordinates',n)]:assert rec[key]==want,(index,key)
  rows.append({'index':index,'n':n,'case':entry['case'],'compared_coordinates':n,'output_sha256':hashlib.sha256(a).hexdigest(),'full_byte_equality':True})
  coords+=n
 assert ca.read(1)==ine.read(1)==b''
assert coords==8388576
bindings=json.loads((C/'INPUT_BINDINGS.json').read_text())
for row in bindings:
 p=C/row['snapshot'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
seal=json.loads((C/'PREEXECUTION_SOURCE_SEAL.json').read_text())
for file,hash in seal['files'].items():assert sha(C/file)==hash
build=json.loads((C/'BUILD_IDENTITY.json').read_text());assert build['source_sha256']==expected_code['src/fresh_radix4.cpp']
assert build['binary_sha256']==sha(C/'artifacts/fresh_radix4')
claimed_result=json.loads((C/'CANDIDATE_RESULT.json').read_text())
assert claimed_result['vectors']==288 and claimed_result['new_vectors']==128 and claimed_result['coordinates']==coords and claimed_result['new_coordinates']==8355840
assert claimed_result['output_bytes']==33554304 and claimed_result['full_output_sha256']==sha(candidate)
result={'decision':'PASS_INDEPENDENT_ALL_COORDINATE_COMPARISON','vectors':288,'coordinates':coords,'new_vectors':128,'new_coordinates':8355840,'old_vectors_unchanged':160,'expected_output_gate':'COMPLETE_288_OF_288','full_output_sha256':sha(candidate),'source_hashes':expected_code,'candidate_input_bindings_verified':len(bindings),'candidate_code_executed':False,'historical_code_executed':False,'whole_engineering_parent_closed':False,'per_vector':rows}
(H/'ALL_COORDINATE_COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='per_vector'},indent=2))
